export const meta = {
  name: 'model-probe-3',
  description: 'Check whether Fable 5.2 can run now: one tiny agent',
  phases: [{ title: 'Probe' }],
}
const SCHEMA = { type: 'object', properties: { ok: { type: 'boolean' } }, required: ['ok'] }
const r = await agent('Reply with the structured result ok: true. Do nothing else.', { label: 'probe claude-fable-5-2', schema: SCHEMA, model: 'claude-fable-5-2', effort: 'low' })
return { claude_fable_5_2: r ? 'ok' : 'failed' }
