export const meta = {
  name: 'review-fifth-round',
  description: 'Check commit 5ae1430 for regressions in three areas, findings reproduced',
  phases: [
    { title: 'Check', detail: 'three reviewers, each reproduces every finding' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review10'

const CONTEXT = `
You are checking one commit of EVA, a Spanish health app (Next.js + Supabase), repository /home/user/eva-health, branch claude/wonderful-meitner-l4g7p5. The commit is 5ae1430 (see \`git -C /home/user/eva-health show 5ae1430 --stat\` and \`git -C /home/user/eva-health diff a1f9ea9 5ae1430 -- <path>\`). It fixes findings from an earlier review of a1f9ea9. Your job: find what this commit broke or got wrong. Only report what you reproduced yourself.

Product context: biological age has three figures (lab page KDM Reference, dashboard KDM Comprehensive rolling average, version 3 in shadow). A declared daily creatine dose (free text, read by readCreatineDose in src/lib/biomarkers/supplements.ts) divides creatinine by 1 + 0.13 x min(g/day, 3)/3, so a misread only matters below 3 g/day, or when a real dose becomes none or the reverse; null means the form asks the client for grams a day. Decisions already taken (not findings): ranges read their lower end; schedules without a count of days, irregular intake, "antes y después de entrenar" and stopped doses make the form ask; more than 50 g/day asks; a lab with an implausible creatinine (outside 0.2-15 mg/dL) or two creatinine values that are not the same result gives no creatinine to any figure; the cron stamps the client's latest context.

Rules: read-only on the repository (never edit, commit, push, checkout, stash or reset there). Scratch work only under ${SCRATCH}/<your area>/. Run repo code with \`npx tsx --tsconfig tsconfig.json <script>\` from /home/user/eva-health (import modules by absolute path), or vitest with a scratch vitest.config.mts ({ root: __dirname, test: { include: ["**/*.test.ts"], exclude: ["node_modules/**"] }, resolve: { alias: { "@": "/home/user/eva-health/src" } } }) plus a node_modules symlink to /home/user/eva-health/node_modules. No patient data, no database calls, no network except PubMed eutils for citations.
Report each finding with the input or state, the observed output, the expected one, why it is caused or worsened by this commit, and the fix you would make. Report nothing you could not reproduce. Rank by effect.
`

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          file: { type: 'string' },
          severity: { type: 'string', enum: ['high', 'medium', 'low'] },
          evidence: { type: 'string' },
          fix: { type: 'string' },
        },
        required: ['title', 'file', 'severity', 'evidence', 'fix'],
      },
    },
    checked: { type: 'string' },
  },
  required: ['findings', 'checked'],
}

const AREAS = [
  {
    key: 'dose-reader',
    prompt: `Area: readCreatineDose and its helpers in src/lib/biomarkers/supplements.ts, changed a lot in this commit: a count of intakes written both as a count and as a list is divided once (listSize, INTAKE_SERVING, Intake.intakes); times of day or meals joined by "o" are one intake (EITHER_TIMES, EITHER_MEALS); TIME_OF_DAY plurals and AT_TIME "al/a/de/las"; slash no longer joins a times-of-day list; ranges read min of both ends; "a las N" clock times are replaced by a mark (CLOCK_TIME); years and hh:mm before an amount are ignored by the digit-before check (YEAR_OR_CLOCK); IRREGULAR_INTAKE is always checked; NEGATED_CYCLING; more STOPPED forms (parad[oa], hasta hace, until ... ago, llevo ... sin tomar, estaba/estuve tomando); "un par de"/"a couple of" = 2; "N y ½"; "y media hora"; v for veces; "día de por medio"; DAILY "todos los días de la semana"; "esta semana" as a duration; more than 50 g/day returns null.
Compare a1f9ea9 and 5ae1430 side by side: copy the old module with \`git -C /home/user/eva-health show a1f9ea9:src/lib/biomarkers/supplements.ts > old.ts\` (it has no repo imports). Existing harness and corpora you can reuse: ${SCRATCH}/../review8/dose-reader/cmp.ts with cases1.ts, cases2.ts, cases3.ts, diff.ts (random differential) and ${SCRATCH}/../review5/find-dose-fuzz/fuzz.ts. Write many new inputs aimed at the new rules (e.g. "o" inside other phrases, "a" as a preposition before a time of day, plurals that are not times, ranges whose lower end is not the dose, "@" interacting with other rules, irregular words in clear daily doses, "parada"/"parado" in other senses, the 50 g limit with mg or capsules). Report only changes for the worse, and misreads the new rules introduced.`,
  },
  {
    key: 'creatinine-and-flows',
    prompt: `Area: the creatinine rule and the flows changed in this commit. labCreatinineReadable (src/lib/biomarkers/creatinine-plausibility.ts: tolerance 0.011 mg/dL + 0.11% of the higher value, max minus min); version 3 giving the same result once (assembleBioAgeV3Inputs in src/lib/biomarkers/biological-age-v3-adapter.ts: mg/dL rows, creatinineOnce); explainBiologicalAge collapsing creatinine rows (src/lib/biomarkers/biological-age-explain.ts, creatinineOnce); the reprocess dedup key for creatinine (src/app/api/lab-results/reprocess/route.ts); the cron's reset filter .eq("transient_context->>auto_resolved", "true") (src/app/api/cron/auto-resolve-pending-context/route.ts; transient_context is jsonb; check that every path where resolvePendingLab throws after its own claim still leaves auto_resolved in transient_context, and that the client's claim never carries it: TransientContextSchema in src/lib/patient-context/schema.ts); the context route's release reporting (src/app/api/lab-results/[id]/context/route.ts). Also check the new tests (src/lib/lab-results/pending-race.test.ts, src/lib/biomarkers/process-results.supplements-option.test.ts, the additions to biological-age-kdm.creatinine.test.ts, biological-age-v3-adapter.test.ts, context-route.test.ts, ready-routes.test.ts) actually fail when the fix they cover is reverted (mutate a scratch copy of src, never the repo).`,
  },
  {
    key: 'copy',
    prompt: `Area: the client-facing and document wording changed in this commit. src/app/[locale]/(marketing)/metodologia/page.tsx and metodologia/completa/page.tsx (Spanish and English must say the same thing), docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md, CALIBRATION-AND-CREATINE.md, ml/biological-age/PHYSICIAN-SIGNOFF.md item 12, src/lib/biomarkers/bio-age-method.ts and supabase/migrations/20261030090000_bio_age_method_r2.sql. Check each changed claim against the code and the sources: the creatinine sentence (lab page and dashboard, the same result in two units); the 1.65 marker examples (every named marker trained in src/lib/biomarkers/data/marker_library_v2_2.json and never mapped in src/lib/biomarkers/kdm-adapter.ts; is "PSA" right for both total and free; is "colesterol no HDL" a trained marker EVA receives); the Vilar Neto 2020 within-group rise (PMID 32670557) and Kondo 2016 (PMID 26907087); the r2 tag text about the earlier rule ("with two creatinine rows the last was read, with no plausibility check": check src/lib/biomarkers/kdm-adapter.ts and the code before 6c3d251 with git show 6c3d251^:<path>). Also JSX escaping: run eslint on both pages here and at a1f9ea9 and compare counts.`,
  },
]

const results = await parallel(AREAS.map((a) => () =>
  agent(`${CONTEXT}\n${a.prompt}`, { label: `check:${a.key}`, phase: 'Check', schema: FINDINGS })
    .then((r) => ({ area: a.key, ...(r || { findings: [], checked: 'agent returned nothing' }) }))
))
return results.filter(Boolean)
