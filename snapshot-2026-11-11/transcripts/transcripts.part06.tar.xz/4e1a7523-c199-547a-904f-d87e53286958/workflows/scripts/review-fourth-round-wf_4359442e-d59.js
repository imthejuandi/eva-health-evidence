export const meta = {
  name: 'review-fourth-round',
  description: 'Review commit a1f9ea9 through four lenses, then adversarially verify each lens',
  phases: [
    { title: 'Find', detail: 'four reviewers, one per lens' },
    { title: 'Verify', detail: 'one skeptic per lens tries to refute each finding' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review8'

const CONTEXT = `
You are reviewing one commit of EVA, a Spanish health app (Next.js + Supabase), repository /home/user/eva-health, branch claude/wonderful-meitner-l4g7p5.
The change under review is commit a1f9ea9: see it with \`git -C /home/user/eva-health show a1f9ea9 --stat\` and \`git -C /home/user/eva-health diff 432441f a1f9ea9 -- <path>\`. Earlier commits on the branch (6c3d251 to 432441f) were reviewed in three earlier rounds; read them only as context.

What the product does here:
- Biological age has three figures: the lab page's KDM v2.2 Reference figure (lab_results.biological_age, tag KDM_v2.2_ReferenceBA_r2), the dashboard's KDM Comprehensive rolling average over recent ready labs (profiles.current_ba, src/lib/biomarkers/rolling-average-ba.ts), and version 3 in shadow mode (src/lib/biomarkers/biological-age-v3-adapter.ts, stored in bio_age_v3_shadow).
- Creatine raises serum creatinine. When a client declares a daily creatine dose in their patient context (free text, read by readCreatineDose in src/lib/biomarkers/supplements.ts), creatinine is divided by 1 + 0.13 x min(g/day, 3) / 3 before any figure reads it. So a misread dose only matters below 3 g/day, or when it turns a real dose into no dose (divisor 1) or the reverse. At the typical man of 45, the full 13% correction moves the lab-page figure about 1.3 years.
- Each lab is read under the patient context recorded with it, else the client's latest version created on or before the lab (src/lib/patient-context/lab-context.ts).
- Labs from EVA's laboratory arrive as pending_context; the client confirms their context (POST /api/lab-results/[id]/context), or a daily cron resolves the lab after 72 hours (src/lib/lab-results/auto-resolve.ts, src/app/api/cron/auto-resolve-pending-context/route.ts).

Decisions already taken, not findings unless the code fails to implement them:
- The cron stamps the client's latest context version, as the client's "Sigue siendo correcto" answer does.
- One per-lab creatinine rule in every figure: if any creatinine row of a lab is outside 0.2-15 mg/dL, or two rows disagree, that lab gives no creatinine (no lab-page figure; the dashboard drops that lab's creatinine; version 3 withholds it). Conservative on purpose.
- The dose reader reads the lower end of ranges; schedules without a count of days a week (weekday names, "cuando entreno", "cada 2 semanas") make the form ask (null); a null or zero dose means no adjustment and the form shows a message.
- The 3 g cap and the proportional rule below it are EVA's stated assumptions.
- Issues that existed before this commit count only if this commit makes them worse or claims to fix them and does not.

Rules for you:
- Read-only on the repository: never edit files under /home/user/eva-health, never commit, push, checkout, stash or reset.
- Do scratch work only under ${SCRATCH}/<your lens>/ (create it). To run repo code: a tsx script run from /home/user/eva-health with \`npx tsx --tsconfig tsconfig.json <script>\`, importing repo modules by absolute path; or a vitest file in your scratch folder with a vitest.config.mts there containing
  import { defineConfig } from "vitest/config"; export default defineConfig({ root: __dirname, test: { include: ["**/*.test.ts"], exclude: ["node_modules/**"] }, resolve: { alias: { "@": "/home/user/eva-health/src" } } });
  plus a symlink node_modules -> /home/user/eva-health/node_modules, run with \`npx vitest run --config <that config>\` from /home/user/eva-health. The repo's own scripted database for tests is src/lib/testing/fake-supabase.ts.
- No patient data, no database or Supabase calls. Network only where your lens says so.
- Every finding needs concrete evidence: an input and the wrong output you observed, or a code path with file:line and the state that triggers it. No style nits, no speculation.
`

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          file: { type: 'string' },
          line: { type: 'number' },
          severity: { type: 'string', enum: ['high', 'medium', 'low'] },
          evidence: { type: 'string', description: 'input and observed output, or code path and triggering state' },
          fix: { type: 'string', description: 'the concrete change you would make' },
        },
        required: ['title', 'file', 'severity', 'evidence', 'fix'],
      },
    },
    checked: { type: 'string', description: 'what you checked and found sound, briefly' },
  },
  required: ['findings', 'checked'],
}

const VERDICTS = {
  type: 'object',
  properties: {
    verdicts: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          verdict: { type: 'string', enum: ['confirmed', 'refuted', 'partly'] },
          severity: { type: 'string', enum: ['high', 'medium', 'low'] },
          reasoning: { type: 'string', description: 'what you ran or read, and what it showed' },
          fix: { type: 'string', description: 'the corrected fix to apply, if confirmed or partly' },
        },
        required: ['title', 'verdict', 'reasoning'],
      },
    },
  },
  required: ['verdicts'],
}

const LENSES = [
  {
    key: 'dose-reader',
    prompt: `Lens: the creatine dose reader, readCreatineDose and its helpers in src/lib/biomarkers/supplements.ts (diff 432441f..a1f9ea9), and its tests in src/lib/biomarkers/supplements.test.ts.
Find texts a Spanish or English-speaking client could plausibly type into a field labelled "Gramos al día, p. ej. 5 g" for which the reader returns a wrong number, a number where a careful human would have to ask (ambiguous), or null for a common, clear dose. Prioritise misreads that change the divisor (below 3 g/day, or a real dose read as none, or none read as a dose). Also look for regressions against 432441f: run the same inputs through both versions (\`git -C /home/user/eva-health show 432441f:src/lib/biomarkers/supplements.ts > <scratch>/old.ts\`, it has no imports from other repo modules except relative ones you may need to copy). Also check for throws, NaN, negative numbers and super-linear time on inputs up to 120 characters.
Existing tools: an adversarial corpus at ${SCRATCH}/../review5/find-dose-fuzz/fuzz.ts (usage: npx tsx --tsconfig tsconfig.json <fuzz.ts> [path to a supplements.ts]); a check list at ${SCRATCH}/../review7/check.ts. Write your own new inputs too: durations, frequencies, times of day, servings, units, Spanish informal spellings, negations, stopped doses, loading phases.`,
  },
  {
    key: 'creatinine-rule',
    prompt: `Lens: the per-lab creatinine rule and the figures that use it. Read labCreatinineReadable (src/lib/biomarkers/creatinine-plausibility.ts), withReadableCreatinine and prepareKdmInputs (src/lib/biomarkers/biological-age-kdm.ts), explainBiologicalAge (src/lib/biomarkers/biological-age-explain.ts), adjustCreatinineByLab (src/lib/biomarkers/rolling-average-ba.ts), assembleBioAgeV3Inputs (src/lib/biomarkers/biological-age-v3-adapter.ts), and where processing calls them (src/lib/biomarkers/process-results.ts, including the new options.supplements).
Check that the rule is the same in all paths and implemented as decided: both creatinine codes ("creatinine", "CREATININE"), non-finite or string values, rows without a lab id on the dashboard, the creatinineAlreadyAdjusted path, the order of rows, creatinine in another unit in version 3, identical duplicates, the explanation's contributions summing to the figure. Look for any path where an implausible value still reaches a figure, or where valid data is dropped beyond the decided rule, or where the explanation and the figure disagree or crash. Write small vitest or tsx checks against the real modules.`,
  },
  {
    key: 'flows',
    prompt: `Lens: the request and job flows changed in this commit. POST /api/lab-results/[id]/context (src/app/api/lab-results/[id]/context/route.ts: claim and stamp in one conditional update, maxDuration, a failed ready write now releases the lab), the 72-hour cron (src/lib/lab-results/auto-resolve.ts and its route: conditional claim, skipped labs, failure reset), client reprocess (src/app/api/lab-results/reprocess/route.ts: the lab's supplements read before anything is deleted and passed to processLabResults), the lab bridge's replaceResults (src/lib/lab-bridge/store.ts), processLabResults' new options.supplements (undefined vs null), and the context form's summary-view notice (src/components/dashboard/PatientContextGate.tsx).
Look for races between the client and the cron, a lab left stuck in "processing", an email sent for a lab that is not ready, data deleted without being re-inserted, a context read after a delete, RLS problems (the context route now writes status, patient_context_version_id and transient_context in one update with the client's session: check the lab_results policies under supabase/migrations), wrong status codes, and tests that would still pass if the fix were reverted (mutation-check the new tests by reverting a line in a scratch copy, never in the repo).`,
  },
  {
    key: 'copy',
    prompt: `Lens: client-facing copy and documents changed in this commit, for factual accuracy against the code and the sources. Files: src/app/[locale]/(marketing)/metodologia/page.tsx and metodologia/completa/page.tsx (Spanish and English must say the same), the strings in src/components/dashboard/PatientContextGate.tsx, ml/biological-age/PHYSICIAN-SIGNOFF.md item 12, docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md, CALIBRATION-AND-CREATINE.md and CYSTATIN-C-FIX-OPTIONS.md headers, supabase/migrations/20261030090000_bio_age_method_r2.sql, src/lib/biomarkers/bio-age-method.ts, and comments in biological-age-kdm.ts and supplements.ts.
Check each changed claim: the "kidney filtration markers" sentence (does EVA file another marker that enters under kidneys, and is urea really entering both KDM figures?); the 1.65 caveat's list of markers EVA's calculation does not use (verify against src/lib/biomarkers/kdm-adapter.ts and data/marker_library_v2_2.json: is each named marker trained, and never mapped? does lymphocyte percentage enter? does blood lead?), "at most 46 markers, 12 with the Base Panel"; the 3 g sentence and its two trials (Vilar Neto 2020, PMID 32670557; Kondo 2016, PMID 26907087; you may fetch their PubMed records with curl from eutils.ncbi.nlm.nih.gov to check what they found and the citation details); the new sentence that two different creatinine values on one report give no biological age (true for which figure?); the provenance-tag history (read the code before 6c3d251 with git show 6c3d251^:<path> to check what the earlier rules did). Also JSX escaping of apostrophes and quotes in the pages (npx eslint on the file, compared with the file at 432441f).`,
  },
]

const results = await pipeline(
  LENSES,
  (lens) => agent(`${CONTEXT}\n${lens.prompt}\nReturn your findings, most severe first.`, {
    label: `find:${lens.key}`, phase: 'Find', schema: FINDINGS,
  }),
  (found, lens) => {
    if (!found || found.findings.length === 0) return { lens: lens.key, found, verdicts: [] }
    return agent(`${CONTEXT}
You are the skeptic for the "${lens.key}" lens. Another reviewer reported the findings below about commit a1f9ea9. For each one, try to REFUTE it: reproduce it yourself from scratch (do not trust their evidence), check whether it is real, whether it is caused or worsened by this commit, whether it contradicts a decision listed above, and whether its severity is right. Default to refuted when you cannot reproduce it. For each confirmed or partly confirmed finding, give the fix you would apply, corrected if theirs is wrong or incomplete.

Findings:
${JSON.stringify(found.findings, null, 2)}`, {
      label: `verify:${lens.key}`, phase: 'Verify', schema: VERDICTS,
    }).then((v) => ({ lens: lens.key, found, verdicts: v ? v.verdicts : null }))
  },
)

return results.filter(Boolean).map((r) => ({
  lens: r.lens,
  checked: r.found ? r.found.checked : null,
  findings: r.found ? r.found.findings : [],
  verdicts: r.verdicts,
}))
