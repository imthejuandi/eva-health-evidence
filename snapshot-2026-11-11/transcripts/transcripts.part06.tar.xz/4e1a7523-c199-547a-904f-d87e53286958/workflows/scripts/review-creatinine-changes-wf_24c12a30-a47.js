export const meta = {
  name: 'review-creatinine-changes',
  description: 'Adversarial review of the creatinine-only and creatine adjustment changes before commit',
  phases: [
    { title: 'Review', detail: 'three lenses over the uncommitted diff' },
    { title: 'Verify', detail: 'a skeptic per lens tries to refute each finding' },
  ],
}

const SP = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review3'

const CTX = `You are reviewing an uncommitted change in the repository at /home/user/eva-health (a Next.js app; read AGENTS.md before relying on framework knowledge). Run "git diff" and "git status" there to see it; the new file src/lib/biomarkers/biological-age-kdm.creatinine.test.ts is untracked.

WHAT THE CHANGE IS MEANT TO DO (the CEO's decision of 30 October 2026):
1. Kidney function enters EVA's biological age through creatinine only, in both versions of the deployed KDM v2.2 model (src/lib/biomarkers/biological-age-kdm.ts). Cystatin C and a laboratory's printed eGFR ("TFGe (basada en Creatinina)") are stored and shown as results but never enter the estimator (KIDNEY_MARKERS_NOT_USED). The gate requires albumin and creatinine, with nothing standing in, and counts only base-panel markers. Before, cystatin C deleted creatinine and the Reference version was left with no kidney marker.
2. A declared creatine dose divides serum creatinine by 1 + 0.13 x min(g/day, 3) / 3 (src/lib/biomarkers/supplements.ts), replacing the old min(0.05 + 0.025 x g/day, 0.40) mg/dL subtraction. Evidence: pooled trial rise 0.13 mg/dL, 95% CI 0.07 to 0.18 (Tsiaras 2026, PMID 42035842); 0.14 (de Souza Almeida 2026, PMID 42507286); no dose gradient above 3 g/day (Vilar Neto 2020, PMID 32670557; Naeini 2025, PMID 41199218; Chun 2026, PMID 42578920); muscle saturation with 3 g/day in about four weeks (Hultman 1996, PMID 8828669). Below 3 g/day the proportional part is a stated assumption. No declared dose: no adjustment. The dose parser now reads Spanish units, decimal commas and thousands separators.
3. Each lab uses the supplements recorded with it (lab_results.patient_context_version_id), else the latest: processing (loadLabSupplements in process-results.ts), the dashboard's rolling average (adjustCreatinineByLab in rolling-average-ba.ts, which adjusts each lab before averaging and then runs KDM with supplements null), and version 3's shadow adapter (biological-age-v3-adapter.ts, version 1.2.0, new record fields creatine_g_per_day and creatinine_divisor).
4. A new provenance tag for Reference figures: KDM_v2.2_ReferenceBA_r2. The dashboard checks bioAgeMethod.startsWith("KDM_v2.2").
5. Client copy: a creatine warning on the dashboard, the lab result page and the supplement form (PatientContextGate.tsx); both methodology pages (src/app/[locale]/(marketing)/metodologia/page.tsx and completa/page.tsx, Spanish and English) updated; documents updated (METHODOLOGY-CLAIMS-FOR-COUNSEL.md, CYSTATIN-C-FIX-OPTIONS.md, CALIBRATION-AND-CREATINE.md, ml/biological-age/PROPOSAL.md, PHYSICIAN-SIGNOFF.md item 12, integration/APPLIED.md).
6. Verified by the author: typecheck clean, 821 of 821 tests pass, no new lint errors. On the synthetic typical man and woman of 45 (docs/biomarker-evidence/longevity/base-panel/panels.json, Base Panel): with cystatin C 0.85 the lab page reads 51.29 and 47.83 again (52.34 and 48.85 before); a creatine user whose creatinine rose 13% reads 52.56 and 49.06 undeclared, and 51.29 and 47.83 when any dose of 3 g/day or more is declared; version 3 reads 45.25 / 42.80 without creatine, 47.03 / 44.58 undeclared, back to 45.25 / 42.80 declared.

RULES: read-only. Do not edit, create or delete files under /home/user/eva-health, and do not commit, push or stash. Scratch files go under ${SP}/<your label>/. Run TypeScript with: cd /home/user/eva-health && npx tsx <script>. Never query any database or call app routes. Cite file:line for every finding, and give a concrete failing input or scenario. Report only real problems: bugs, wrong numbers or claims, regressions, missing cases, inconsistencies between code and copy. No style nits.`

const FINDINGS = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          file_line: { type: 'string' },
          severity: { type: 'string', enum: ['high', 'medium', 'low'] },
          problem: { type: 'string' },
          scenario: { type: 'string' },
          suggested_fix: { type: 'string' },
        },
        required: ['id', 'file_line', 'severity', 'problem', 'scenario', 'suggested_fix'],
      },
    },
  },
  required: ['findings'],
}

const VERDICTS = {
  type: 'object',
  properties: {
    verdicts: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          real: { type: 'boolean' },
          evidence: { type: 'string' },
          corrected_fix: { type: 'string' },
        },
        required: ['id', 'real', 'evidence'],
      },
    },
  },
  required: ['verdicts'],
}

const LENSES = [
  { key: 'code', text: 'Code correctness and edge cases. Check every changed function: the gate and marker count; applyLifestyleAdjustments; resolveKdmParams; the dose parser (Spanish words, accents, decimal commas, thousands separators, bare numbers, ranges like "3-5 g", "5g x2", negative or zero, very large values); creatineDoseGramsPerDay; creatineCreatinineDivisor; loadLabSupplements (null rows, wrong user, missing version); adjustCreatinineByLab (keys, labs without rows, rows without lab id, duplicate keys, the fallback); the version 3 adapter changes (bounded creatinine, units, the pregnancy path, the record shape); the new method tag and every place that reads bio_age_method. Write and run small scratch scripts to test edge cases against the real code.' },
  { key: 'clinical', text: 'Clinical, scientific and copy accuracy. Check that every number and claim in the changed client copy and documents matches the code and the cited evidence: the methodology pages in Spanish and English, the warnings on the dashboard, lab page and supplement form, PROPOSAL.md, PHYSICIAN-SIGNOFF.md, APPLIED.md, the counsel note and the two research memos. Recompute the quoted figures (1.2 to 1.3 years undeclared on the lab page, 1.8 in version 3, 79 of 81 trained markers, seven extra Spanish-adjusted markers, the divisor values) with your own scripts. Open the cited PubMed records through the Europe PMC REST API (https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:<pmid>%20AND%20SRC:MED&format=json&resultType=core) and check the stated effect sizes. Check Spanish grammar and accents in the new Spanish strings, and that Spanish and English say the same thing. Flag any claim a physician or counsel could not defend.' },
  { key: 'dataflow', text: 'Data flow, integration and tests. Trace how a lab result moves through processLabResults and recomputeLabMetrics, the rolling average cache (profiles.current_ba), the dashboard fallback to the stored Reference figure, the explanation module (biological-age-explain.ts), and the version 3 shadow write; look for any path that still uses the latest supplements, any path where creatinine is adjusted twice or not at all, and any consumer that breaks on the new tag or the dropped markers (search the whole src tree, scripts and SQL). Then judge the tests: do the new and changed tests actually pin the intended behaviour, or could they pass with a broken implementation? Name missing tests concretely.' },
]

phase('Review')
const results = await pipeline(
  LENSES,
  l => agent(`${CTX}

YOUR LABEL: review-${l.key}

YOUR LENS: ${l.text}

Return every real problem you find as a finding, with an id like ${l.key}-1.`, { label: `review:${l.key}`, phase: 'Review', schema: FINDINGS }),
  (r, l) => {
    const findings = (r && r.findings) || []
    if (findings.length === 0) return { lens: l.key, findings: [], verdicts: [] }
    return agent(`${CTX}

YOUR LABEL: verify-${l.key}

TASK: Adversarially check each finding below. For each one, try to refute it: reproduce the scenario against the real code or text, and decide whether the problem is real. Default to real=false when you cannot reproduce it. When it is real, give the minimal correct fix in corrected_fix.

FINDINGS (JSON):
${JSON.stringify(findings, null, 1)}`, { label: `verify:${l.key}`, phase: 'Verify', schema: VERDICTS }).then(v => ({ lens: l.key, findings, verdicts: (v && v.verdicts) || [] }))
  },
)

const out = results.filter(Boolean).map(x => {
  const byId = Object.fromEntries((x.verdicts || []).map(v => [v.id, v]))
  return {
    lens: x.lens,
    confirmed: x.findings.filter(f => byId[f.id] && byId[f.id].real).map(f => ({ ...f, verdict: byId[f.id] })),
    rejected: x.findings.filter(f => !(byId[f.id] && byId[f.id].real)).map(f => ({ id: f.id, problem: f.problem, why: byId[f.id] ? byId[f.id].evidence : 'not verified' })),
  }
})
log(out.map(o => `${o.lens}: ${o.confirmed.length} confirmed, ${o.rejected.length} rejected`).join(' | '))
return out
