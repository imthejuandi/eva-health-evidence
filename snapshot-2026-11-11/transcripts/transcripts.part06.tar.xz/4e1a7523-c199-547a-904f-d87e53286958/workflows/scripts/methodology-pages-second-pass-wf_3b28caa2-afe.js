export const meta = {
  name: 'methodology-pages-second-pass',
  description: 'Correct every issue an independent reviewer found in the methodology-page fix, then re-review adversarially and fix again if needed',
  phases: [
    { title: 'Fix', detail: 'apply the reviewer findings with code evidence, ES and EN' },
    { title: 'Review', detail: 'fresh adversarial review of the full diff' },
    { title: 'Fix again', detail: 'only if the review finds blocking or important issues' },
  ],
}

const REVIEW_JSON = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/methfix/review.json'
const PAGES = [
  'src/app/[locale]/(marketing)/metodologia/page.tsx',
  'src/app/[locale]/(marketing)/metodologia/completa/page.tsx',
  'src/app/[locale]/(marketing)/science/page.tsx',
  'src/app/[locale]/(dashboard)/dashboard/dashboard-client.tsx',
]

const RULES = `
Repository: /home/user/eva-health (Next.js app; read AGENTS.md first: this Next.js version differs from what you know). EVA Health is a Spanish preventive-health company. These pages are public and client-facing. They describe the model in production today, KDM v2.2.2 (a Klemera-Doubal biological age, src/lib/biomarkers/biological-age-kdm.ts, data in src/lib/biomarkers/data/). On 29 October 2026 the CEO decided to replace it with a new model ("version 3") once that model passes its validation and release conditions; the new model is not live.

Commit 029dbac applied replacement text for unsupported claims. An independent reviewer then found remaining problems; its findings are in ${REVIEW_JSON} (read the whole file).

Rules for every change:
- Every statement on these pages must be supported by the code, the data files, or EVA's documents (ml/biological-age/MODEL-CARD.md, ml/biological-age/REPORT.md, docs/biomarker-evidence/bioage-model-selection/DECISION.md and evidence.json, docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md). Check the code yourself before writing any technical statement. When something cannot be supported, remove it or state it more modestly. Never add a new claim you have not checked.
- Cautious wording: no "validated", "prediction", "predicts" or risk-discrimination claims about this model. Use "tested against recorded deaths" in English and "evaluada frente a la mortalidad" or "se evaluó" in Spanish (not "comprobada", which means verified).
- Spanish and English must say the same thing. Spanish needs correct accents and ñ, decimal commas, and "mayo de 2026".
- Plain, short sentences. Do not add em dashes to new text.
- Do not change behaviour: only text, string literals, code comments, the reference list, and citation text or links in data files when no test or hash pins them (check first, and report what you did not change and why). Do not touch model coefficients.
- Do not commit and do not push. Run: npm run -s typecheck; npx eslint on every file you change (compare against the errors present before your change, with git stash only if needed, and add no new errors); npx vitest run (all must pass).
`

const FIX_TASK = `
TASK: Fix every issue in the reviewer's findings that applies to these files: ${PAGES.join(', ')}, plus docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md, stale code comments that state old figures (the reviewer lists them), and the marker library citations if safe. In particular:
1. The hazard ratio: describe 1.39 and 1.65 correctly, as per standard deviation of biological age in a model that also contains age and sex (check scripts/comprehensive_ba_mortality_validation.py), not per SD of acceleration.
2. The C-statistic card and section 06: do not present 0.77 as the model's own discrimination. Age and sex alone give about 0.77; the biological age adds about 0.009 (MODEL-CARD.md and REPORT.md, the sealed 2007-2014 comparison). Reframe section 06's question as whether it adds information beyond chronological age, and answer it with that gain. Keep the card honest; if a third trust number is needed, choose one that is true and supported.
3. Sources of the Spanish means: name them correctly and modestly (PESA, PMID 25882487, adults aged 40 to 54; the vitamin D study is Díaz-López et al. 2021, PMID 33866793, primary-care patients at risk of deficiency; Alonso et al. 2025, PMID 41419981, euthyroid adults). Remove the wrong n. Do not call them population means. Fix the PESA link (it points to an unrelated paper). Update the reference list: remove references no longer cited or that are wrong (ENRICA, Di@bet.es, the Cohen 2010 attribution, the Mayer and Mannion search link), add the two new sources, fix titles that differ from PubMed.
4. The short page's per-sex sentence: name only the four base markers with sex-specific means; keep hemoglobin and testosterone out of the base-panel sentence.
5. The two versions and the dashboard: describe what clients actually see (the rolling average shows the Comprehensive value first, for every client; check rolling-average-ba.ts, biological-age-kdm.ts and dashboard-client.tsx), how many of the model's 14 markers EVA's 13-test Base Panel supplies, and that measured fructosamine is set aside by default if the code shows it. Avoid calling the model's 14 markers "panel base" where it can be confused with EVA's 13-test product.
6. The hero's promise to explain limits: add a short, honest limits list in the transparency section (for example the repeat-draw variation of about 4 years, that a large part of the result reflects chronological age, that it has not been evaluated against mortality in Spain), each item backed by EVA's files.
7. Technical details on the full page: the Spanish-mean formula for log-scale markers, the plausibility check (remove if no code or record exists), the number of log-transformed markers, the weighting, the number of sex-stratified markers, "every marker refitted" (Path B covers 80 of 81 trained markers), and "n = 18,570 adults with complete panel" (the gate needs 8 of 14).
8. The roadmap (section 09): it plans KDM work although the model will be replaced. Say, without dates or results, that EVA is evaluating a new model trained against mortality that will replace this one once it passes its validation.
9. The dashboard badge "Calibrado para población española" / "Calibrated for the Spanish population": replace with accurate wording such as "Ajustado con medias españolas publicadas" / "Adjusted with published Spanish means", or remove it.
10. The Spanish science page: add the missing accents and ñ across its Spanish strings (for example "años", "riñones", "señal", "sueño", "biológica", "análisis"), and correct the claims the reviewer lists as wrong about how the model works ("compared against thousands of others in your age group", "every result is folded into your biological age", the systems list), with the most modest accurate wording. Leave pure taglines unless they state a false fact.
11. The counsel file: fix its header (say "the marker library shows", not "engineering confirmed"), and mark that line 16's "Nothing on these pages was changed" was true when written.
Finish by returning: a list of every change (file, before, after, evidence), anything you did not change and why, and the check results.`

const CHANGE_SCHEMA = {
  type: 'object',
  properties: {
    changes: { type: 'array', items: { type: 'object', properties: {
      file: { type: 'string' }, before: { type: 'string' }, after: { type: 'string' }, evidence: { type: 'string' } },
      required: ['file', 'after', 'evidence'] } },
    not_changed: { type: 'array', items: { type: 'string' } },
    checks: { type: 'string' },
  },
  required: ['changes', 'not_changed', 'checks'],
}
const REVIEW_SCHEMA = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['ready', 'minor_changes', 'major_changes'] },
    issues: { type: 'array', items: { type: 'object', properties: {
      severity: { type: 'string', enum: ['blocking', 'important', 'minor'] }, where: { type: 'string' },
      problem: { type: 'string' }, fix: { type: 'string' } }, required: ['severity', 'where', 'problem', 'fix'] } },
    summary: { type: 'string' },
  },
  required: ['verdict', 'issues', 'summary'],
}

phase('Fix')
const fix1 = await agent(RULES + FIX_TASK, { label: 'fix:round1', phase: 'Fix', schema: CHANGE_SCHEMA })

phase('Review')
const reviewPrompt = (round) => RULES + `
TASK: You are a fresh, adversarial reviewer. Review the uncommitted changes in the working tree (git -C /home/user/eva-health diff) together with commit 029dbac, for these files: ${PAGES.join(', ')} and the counsel file. Read ${REVIEW_JSON} to know what the first reviewer asked for.
Check, against the code and EVA's files yourself: every number and technical statement on the changed pages (Spanish and English), the sources and links (open them: PubMed records must match the cited paper), ES and EN parity, Spanish grammar and accents, that no new unsupported claim was added, that nothing user-visible elsewhere still contradicts the pages, and that typecheck, lint (no new errors) and tests pass. This is review round ${round}.
Return every remaining issue with severity, where, problem and the exact fix.`
const review1 = await agent(reviewPrompt(1), { label: 'review:round1', phase: 'Review', schema: REVIEW_SCHEMA })

let fix2 = null
let review2 = null
const serious = (r) => r && r.issues && r.issues.some(i => i.severity === 'blocking' || i.severity === 'important')
if (serious(review1)) {
  phase('Fix again')
  fix2 = await agent(RULES + `
TASK: Apply every blocking and important issue from this review, and the minor ones that are clearly right, to the working tree (the previous round's changes are already there, uncommitted). Where the reviewer is wrong, leave it and say why.
REVIEW (JSON): ${JSON.stringify(review1).slice(0, 60000)}
Return every change, what you did not change and why, and the check results.`, { label: 'fix:round2', phase: 'Fix again', schema: CHANGE_SCHEMA })
  review2 = await agent(reviewPrompt(2), { label: 'review:round2', phase: 'Fix again', schema: REVIEW_SCHEMA })
}
return { fix1, review1, fix2, review2 }
