export const meta = {
  name: 'signoff-final-frozen-review',
  description: 'Final adversarial review of the whole runner change, and a first review of the five frozen files changed before 7 November',
  phases: [{ title: 'Review', detail: 'runner final review; earlier frozen changes review' }],
}

const SCR = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/final-review'
const C = 'docs/signoff/work/central'
const BASE = [
  'You review changes to the acceptance-test runner and tooling of EVA\'s physician sign-off programme, in the repository at',
  '/home/user/eva-health (branch claude/wonderful-meitner-l4g7p5). The acceptance test is docs/signoff/ACCEPTANCE-TEST.md (the',
  'DSRT); its runner is scripts/signoff/ (npm run dsrt -- ...; --work-dir takes a scratch copy of docs/signoff/work); the loop',
  'tooling is docs/signoff/tools/. Both were frozen at round 0, commit 2cec485; check G1 fails until the CEO approves each',
  'changed file. A change is approvable only if it fixes a defect (the code did not do what the frozen specification text says,',
  'or could not work with the frozen schemas and the files the loop produces) and does not let any check pass more easily than',
  'its specification text allows. You did not write these changes. All of this is AI work product a licensed physician reviews.',
  '',
  'Rules: write only your verdict file and scratch files under ' + SCR + '/<your part>/; run no git command that changes the',
  'working tree or index (git show <commit>:<path> for old versions); never query a database, apply a migration, send a',
  'message or call the app\'s API; every claim comes from a command you ran or a line you read; no AI model names in files.',
].join('\n')

const VERDICT = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['accept', 'reject'] },
    findings: { type: 'array', items: { type: 'object', properties: {
      file: { type: 'string' }, line: { type: 'integer' },
      severity: { type: 'string', enum: ['blocking', 'residual'] },
      kind: { type: 'string' }, detail: { type: 'string' }, required_change: { type: 'string' } },
      required: ['severity', 'kind', 'detail', 'required_change'] } },
    per_file: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, verdict: { type: 'string' }, reason: { type: 'string' } }, required: ['file', 'verdict', 'reason'] } },
    tests: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] } },
    notes: { type: 'string' },
  },
  required: ['verdict', 'findings', 'per_file', 'tests'],
}

const runner = [
  BASE,
  '',
  'Part: the whole runner change. Files: scripts/signoff/checks/data.ts, scripts/signoff/checks/governance.ts,',
  'scripts/signoff/lib/seed.ts, with their tests in src/lib/signoff/. Diff: git diff 2cec485 -- those files. History: the fix',
  `reports in ${C}/runner.json and the five earlier reviews ${C}/runner-verify.json, runner-verify-2.json, runner-verify-3.json`,
  `and runner-verify-3b.json. The last review's one required change (an ALTER clause may carry only the compile's own`,
  'sign-off columns with their exact types; tests for a cascading foreign key and a default) was made by the orchestrator in',
  'commit f5ec41a.',
  '',
  'Do this:',
  '1. Confirm every required change of the five reviews is met, each with a command.',
  '2. Try to break checks G2, D5, D3 and G1 as changed: build seed and migration copies of docs/signoff/work/compiled/B01-r3 and',
  '   run the DSRT on them. Rate each finding. "blocking": the pack could be wrong and still pass through something the loop',
  '   or a person could plausibly produce: the compile\'s own output, an ordinary hand edit of a seed or migration file, a',
  '   decisions or verify file the validators accept. "residual": it needs SQL or text crafted to fool the reader, or an object',
  '   defined outside the file (a trigger, a rule or a function already in the database); the report already lists such writes',
  '   as R2R-2. Give a precise required change for each.',
  '3. Run npx vitest run src/lib/signoff, npx tsc --noEmit -p ., and the DSRT on docs/signoff/work/compiled/B01-r3.',
  'Verdict "accept" if no finding is blocking. per_file: a verdict for each of the three files.',
  `Write ${C}/runner-verify-final.json (verdict, findings, per_file, tests) and reply with the structured result.`,
].join('\n')

const earlier = [
  BASE,
  '',
  'Part: five frozen files changed before 7 November and never reviewed: docs/signoff/tools/build-inputs.js (changed in',
  'commit 5ad2fa5), docs/signoff/tools/build-briefs.js and docs/signoff/tools/test/build-briefs.test.js (added in f36b1f0 for',
  'the lean batch loop; new optional fields added on 7 November), scripts/signoff/checks/bioage.ts and',
  'scripts/signoff/checks/personas.ts (changed in c00e5dc, the version 3 workstream, when its refusal rules changed: lactation',
  'refused, a venous collection method required). Diff each against round 0: git diff 2cec485 -- <file> (for the added files,',
  'read them whole). Read docs/signoff/ACCEPTANCE-TEST.md groups B and Q, and docs/signoff/work/v3/ for the version 3 rules.',
  '',
  'For each file decide: is the change a defect fix or new tooling that does what the specification and the plan ask, or does',
  'it let a check pass more easily than its specification text allows (for example a version 3 check that now expects a',
  'refusal where the specification wants a result, or fixtures changed to match the code rather than the rule)? For the',
  'tooling files: does a brief or input ever change a clinical number, drop a value without a pointer, or hide something an',
  'author needs? Run node --test docs/signoff/tools/test/*.test.js, npx vitest run src/lib/signoff, and the DSRT groups B and',
  'Q (npm run dsrt -- --only B1,B2,B3,B4,B5,B6,Q1,Q2,Q3 --round 3 --seed-dir docs/signoff/work/compiled/B01-r3 --out <scratch>).',
  'Rate findings blocking or residual as above. Verdict "accept" if no finding is blocking; per_file: a verdict for each file.',
  `Write ${C}/earlier-frozen-verify.json and reply with the structured result.`,
].join('\n')

phase('Review')
const [r, e] = await parallel([
  () => agent(runner, { label: 'final review runner', phase: 'Review', schema: VERDICT, effort: 'max' }),
  () => agent(earlier, { label: 'review earlier frozen changes', phase: 'Review', schema: VERDICT, effort: 'max' }),
])
return { runner: r, earlier: e }
