export const meta = {
  name: 'signoff-runner-round-4',
  description: 'Runner round 4 in an isolated worktree: D5 compares every column and checks the change list, G2 compares messages and explanatory numbers, B2 probes isolate their rule; adversarial review',
  phases: [
    { title: 'Fix', detail: 'one engineer in its own worktree, commits on branch signoff-runner-r4' },
    { title: 'Verify', detail: 'adversarial review of the branch; one repair pass if rejected' },
  ],
}

const SCR = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/runner-r4'
const MAIN = '/home/user/eva-health'
const BASE_COMMIT = '15f04bb'
const BRANCH = 'signoff-runner-r4'
const FILES = ['scripts/signoff/checks/data.ts', 'scripts/signoff/checks/governance.ts', 'scripts/signoff/checks/bioage.ts', 'scripts/signoff/lib/seed.ts', 'src/lib/signoff/dsrt-core.test.ts', 'src/lib/signoff/dsrt-checks.test.ts', 'docs/signoff/work/v3/refusals.json', 'docs/signoff/work/central/runner.json']

const SETUP = [
  'You work in an isolated git worktree, not in the main checkout at ' + MAIN + ', where other agents are running the loop.',
  'First: run pwd and git rev-parse --show-toplevel and report the worktree path. If node_modules is missing in the worktree,',
  `create a symlink to ${MAIN}/node_modules. Never edit files under ${MAIN} itself, and never push.`,
].join('\n')

const SHARED = [
  'Context. EVA\'s physician sign-off programme has an acceptance test, docs/signoff/ACCEPTANCE-TEST.md (the DSRT); its runner is',
  'scripts/signoff/ (npm run dsrt -- ...; --work-dir takes a copy of docs/signoff/work). The runner was frozen at round 0; check',
  'G1 fails until the CEO approves each change, which is approvable only if it fixes a defect and lets no check pass more easily',
  'than its specification text allows. The runner change has been reviewed six times: docs/signoff/work/central/runner.json holds',
  'the fix reports; runner-verify.json, -2, -3, -3b and runner-verify-final.json hold the reviews. All of it is AI work product a',
  'licensed physician reviews. Never query a database, apply a migration, send a message or call the app\'s API. Every claim',
  'comes from a command you ran or a line you read. No AI model names in files. Scratch files only under ' + SCR + '.',
].join('\n')

const TASK = [
  SETUP, '', SHARED, '',
  `Your files: ${FILES.join(', ')}. Base: commit ${BASE_COMMIT}. Read docs/signoff/work/central/runner-verify-final.json and docs/signoff/work/central/earlier-frozen-verify.json first; their required changes are the task:`,
  '1. D5, every column. Compare the seed with production plus the forward migration on every column both carry, not only the',
  '   six bounds and the unit. Build each seed row\'s database row with compile-rows.js dbRowFromPair from its English and',
  '   Spanish pair, keeping the last of duplicate keys; take production with every column from compile-baseline.js',
  '   buildBaseline (sign-off columns null) and apply the migration\'s upserts and deletes. Fail each column where the two',
  '   differ, naming the row, the column and both values. Keep the rule that a bound or unit difference also needs a listed',
  '   change with a stated reason and source. Tests: a migration\'s clinical note, a message, marker_class or unit_es differs',
  '   from the seed; a seed message differs from the migration; each must fail D5.',
  '2. D5, the change list. Every listed change must be what the migration does: a row "add" is upserted, a row "remove" is',
  '   deleted, a field "modify" is written with its "to" value (sameValue for bounds and unit, exact otherwise). Fail each',
  '   listed change the migration does not make, naming its row and field. On the reconciliation-diff path, check at least',
  '   that each listed row is written or deleted as its op says. Tests: a listed added row missing from both seed and',
  '   migration; a listed field that both leave at production\'s value; each must fail D5.',
  '3. G2, the message columns. In finalRowMismatches (or traceRows) also compare the columns the compile writes from the',
  '   final row and other checks read from the seed: the five English and five Spanish message columns (compile-rows.js MSGS',
  '   and pairFromLoopRow) and Explanatory_Numbers in order. The simplest exact form rebuilds the pair with pairFromLoopRow,',
  '   using the seed pair as the template, and compares every column it writes from the row. Report each difference as',
  '   "differs from its final row". Tests: a message in either language, and Explanatory_Numbers, differing from the final',
  '   row; each must fail G2.',
  '4. B2 probes (earlier-frozen-verify.json, first finding): since adapter 1.3.0 refuses an unknown collection method, six',
  '   GAP_PROBES in scripts/signoff/checks/bioage.ts pass whether or not their own rule holds. Pass collection_method',
  '   "venous" in every GAP_PROBE except the capillary one and in B5\'s fallback probe, or have probeOutcome require the',
  '   expected reason code (and a provisional figure for hs_crp_30). Fix the stale comment near line 152, and update',
  '   meta.probes_note in docs/signoff/work/v3/refusals.json.',
  'Constraints: docs/signoff/work/compiled/B01-r3 must keep D5 19 keys and 33 explained, and G2 must stay at 0 untraced of 15;',
  'report the same for docs/signoff/work/compiled/B01-r4 if present. Run npx vitest run src/lib/signoff, npx tsc --noEmit -p .,',
  'and the DSRT on both compiles. Add a "round_4" section to docs/signoff/work/central/runner.json, with the specification text',
  'each change implements.',
  `Finally: git checkout -b ${BRANCH} (if you are not on it), git add your files, and git commit -m "Sign-off runner round 4: D5 compares every column and the change list; G2 compares messages and explanatory numbers; B2 probes isolate their rule". Report the branch, the commit hash and the worktree path.`,
].join('\n')

const FIX_SCHEMA = { type: 'object', properties: {
  worktree: { type: 'string' }, branch: { type: 'string' }, commit: { type: 'string' },
  files_changed: { type: 'array', items: { type: 'string' } },
  fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, fix: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'fix', 'evidence'] } },
  tests: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] } },
  notes: { type: 'string' } }, required: ['worktree', 'branch', 'commit', 'files_changed', 'fixed', 'tests'] }
const VERIFY_SCHEMA = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['accept', 'reject'] },
  findings: { type: 'array', items: { type: 'object', properties: { severity: { type: 'string', enum: ['blocking', 'residual'] }, file: { type: 'string' }, line: { type: 'integer' }, detail: { type: 'string' }, required_change: { type: 'string' } }, required: ['severity', 'detail', 'required_change'] } },
  tests: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] } },
  notes: { type: 'string' } }, required: ['verdict', 'findings', 'tests'] }

const verifyPrompt = (fix, tag) => [
  SETUP, '', SHARED, '',
  `You review the runner's round 4. You did not write it. In your worktree: git checkout ${fix.commit} (branch ${fix.branch}). Diff: git diff ${BASE_COMMIT} ${fix.commit}; the whole runner change since round 0: git diff 2cec485 ${fix.commit} -- scripts/signoff.`,
  `The fix agent's task was:\n---\n${TASK.slice(SETUP.length)}\n---\nIts result: ${JSON.stringify(fix).slice(0, 5000)}`,
  '',
  'Try to break D5, G2 and the B2 probes on copies of docs/signoff/work/compiled/B01-r3 (and B01-r4 if present), and confirm',
  'every required change of runner-verify-final.json and earlier-frozen-verify.json is met, each with a command. Rate each',
  'finding: "blocking" when the pack could be wrong and still pass through something the loop or a person could plausibly',
  'produce (the compile\'s own output, an ordinary hand edit of a seed or migration file, a decisions or verify file the',
  'validators accept); "residual" when it needs SQL or text crafted to fool the reader, or an object defined outside the file.',
  'Run npx vitest run src/lib/signoff, npx tsc --noEmit -p ., and the DSRT on the compiles. Verdict "accept" if no finding is',
  `blocking. Write your verdict to docs/signoff/work/central/runner-verify-r4${tag}.json in your worktree, commit it on the same branch, and reply with the structured result.`,
].join('\n')

phase('Fix')
const fix = await agent(TASK, { label: 'fix runner r4', phase: 'Fix', schema: FIX_SCHEMA, effort: 'max', isolation: 'worktree' })
if (!fix) return { verdict: 'no_result' }
phase('Verify')
const v = await agent(verifyPrompt(fix, ''), { label: 'verify runner r4', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max', isolation: 'worktree' })
if (!v) return { verdict: 'unverified', fix }
if (v.verdict === 'accept') return { verdict: 'accept', fix, verify: v }
const blocking = v.findings.filter((f) => f.severity === 'blocking')
log(`verify runner r4: rejected, ${blocking.length} blocking; one repair pass`)
const fix2 = await agent(`${TASK}\n\nThe reviewer rejected round 4. Start from commit ${fix.commit} (git checkout ${fix.commit}; then git checkout -b ${BRANCH}-repair). Its blocking findings, verbatim:\n${JSON.stringify(blocking, null, 1)}\n\nAddress each, or show with evidence why it is wrong. Add "round_4_repair" to runner.json, commit on ${BRANCH}-repair, and reply with the structured result.`, { label: 'repair runner r4', phase: 'Verify', schema: FIX_SCHEMA, effort: 'max', isolation: 'worktree' })
if (!fix2) return { verdict: 'rejected_no_repair', fix, verify: v }
const v2 = await agent(verifyPrompt(fix2, '-repair'), { label: 're-verify runner r4', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max', isolation: 'worktree' })
return { verdict: v2 ? v2.verdict : 'unverified', fix: fix2, first_fix: fix, first_verify: v, verify: v2 }
