export const meta = {
  name: 'fable-approval-tools',
  description: 'Fable 5.2 reviews the frozen tool files changed since round 0 and the eight publication decisions CEO-1 to CEO-8, with adversarial challenges',
  phases: [
    { title: 'Review', detail: 'one Fable 5.2 reviewer per tools area; two decision reviewers with different lenses' },
    { title: 'Challenge', detail: 'an adversarial Fable 5.2 reviewer per tools area tries to overturn each verdict' },
  ],
}

const A = args
const MODEL = 'claude-fable-5-2'
const EFFORT = 'max'
const BASE = A.base
const SCR = A.scratch

const FINDING = {
  type: 'object',
  properties: {
    summary: { type: 'string' },
    evidence: { type: 'string' },
    failure_scenario: { type: 'string' },
    smallest_fix: { type: 'string' },
  },
  required: ['summary', 'evidence', 'failure_scenario', 'smallest_fix'],
}
const TESTS = { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } }
const REVIEW = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    files: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          sha256_matches: { type: 'boolean' },
          recommendation: { type: 'string', enum: ['approve', 'reject'] },
          plain_rationale: { type: 'string' },
          changes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                what: { type: 'string' },
                defect_fixed: { type: 'string' },
                spec_basis: { type: 'string' },
                direction: { type: 'string', enum: ['tightens', 'loosens', 'neutral', 'new check'] },
                justified: { type: 'boolean' },
              },
              required: ['what', 'defect_fixed', 'spec_basis', 'direction', 'justified'],
            },
          },
          blocking_findings: { type: 'array', items: FINDING },
          notes: { type: 'array', items: { type: 'string' } },
        },
        required: ['file', 'sha256_matches', 'recommendation', 'plain_rationale', 'changes', 'blocking_findings', 'notes'],
      },
    },
    tests_run: TESTS,
  },
  required: ['area', 'files', 'tests_run'],
}
const CHALLENGE = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    files: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          recommendation: { type: 'string', enum: ['approve', 'reject'] },
          agrees_with_reviewer: { type: 'boolean' },
          new_blocking_findings: { type: 'array', items: FINDING },
          reviewer_findings_assessed: {
            type: 'array',
            items: { type: 'object', properties: { summary: { type: 'string' }, stands: { type: 'boolean' }, why: { type: 'string' } }, required: ['summary', 'stands', 'why'] },
          },
          plain_rationale: { type: 'string' },
        },
        required: ['file', 'recommendation', 'agrees_with_reviewer', 'new_blocking_findings', 'reviewer_findings_assessed', 'plain_rationale'],
      },
    },
    tests_run: TESTS,
  },
  required: ['area', 'files', 'tests_run'],
}
const DECISIONS = {
  type: 'object',
  properties: {
    lens: { type: 'string' },
    decisions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          recommendation: { type: 'string', enum: ['keep_default', 'take_alternative', 'other'] },
          rule: { type: 'string' },
          plain_rationale: { type: 'string' },
          risk_if_wrong: { type: 'string' },
          effect_check: { type: 'string' },
          code_location: { type: 'string' },
          confidence: { type: 'string', enum: ['high', 'medium', 'low'] },
        },
        required: ['id', 'recommendation', 'rule', 'plain_rationale', 'risk_if_wrong', 'effect_check', 'code_location', 'confidence'],
      },
    },
  },
  required: ['lens', 'decisions'],
}

const BACKGROUND = [
  'Background.',
  '- EVA is a preventive-health app. Before launch, a licensed physician will review and sign its optimal biomarker ranges, its biological age model and its score. An AI sign-off programme prepares that material. The Doctor Sign-off Readiness Test (DSRT), specified in docs/signoff/ACCEPTANCE-TEST.md, is the acceptance test the material must pass before it goes to the physician. The runner in scripts/signoff/ and the tools in docs/signoff/tools/ grade and compile the material: the tools validate the programme\'s research, verify and decisions files against docs/signoff/tools/schema/, build the briefs and inputs the agents read, and compile the decisions into the published rows, the published summaries (biomarker-sources.json) and the change list (CHANGES.md, with a reason and a source for every change).',
  `- So that the programme cannot pass its own work by changing the test, the specification, runner, thresholds, judge prompts and tools were hashed at round 0 (docs/signoff/work/checks/round-0.json; baseline commit ${BASE}). Check G1 fails while any of them differs from round 0 without an entry in docs/signoff/work/governance/approved-changes.json ({file, sha256, commit, approved_by: "CEO"}). The specification itself (ACCEPTANCE-TEST.md) is unchanged since round 0.`,
  '- After the pilot batch B01, the programme\'s orchestrator changed 22 frozen files to fix defects the pilot exposed. The defects and their status are in docs/signoff/work/central/known-issues.md; the proposed approvals are in docs/signoff/work/governance/pending-approvals.json. The orchestrator\'s own work is graded by these files, so the main risk is a change that makes the test easier to pass than the specification allows, or a compile that publishes something nobody checked. Several AI review rounds already looked at these changes; their records are named below.',
  '- Your recommendation will be recorded as the CEO\'s decision. Be exact and independent.',
].join('\n')

const STANDARD = [
  'The approval standard. Recommend "approve" for a file only if all four hold:',
  '1. Purpose: every change fixes a real defect of the round-0 version against the written specification (ACCEPTANCE-TEST.md; for formats, docs/signoff/LOOP-PROMPT.md and docs/signoff/workflows/README.md), or adds checking the specification asks for. For each change, name the defect and quote the specification text.',
  '2. No unjustified loosening: no check passes more easily than the specification allows, and the compile does not publish a clinical statement that no reviewer checked against the row it now describes. A change that lets something pass that failed at round 0 is a loosening; it is acceptable only where the round-0 code was stricter than the specification\'s text, and you quote that text. Tightening within the specification is acceptable.',
  '3. Correctness: the code does what it claims, including edge cases (missing or empty files, malformed data, Spanish fields, state rows such as pregnancy, added rows, ties at bounds, idempotency of the compile). Read the code paths; do not rely on test names.',
  '4. Scope and no bypass: no edit outside the stated purpose, and no hidden way to skip a check or a validation (a key, an environment variable, a file whose presence or absence turns a failure into a pass, a swallowed error).',
  'Reject when any of the four fails in a way that matters for what the physician will sign or for the integrity of the test. A cosmetic or documentation flaw is a note, not a reason to reject. When you reject, give the smallest change that would make the file approvable.',
  'Eight publication rules that the compile code implements (CEO-1 to CEO-8 in docs/signoff/work/governance/central-fix-decisions.md) are decided separately. Judge whether the code implements the default stated there correctly; do not reject a file because you prefer the alternative.',
].join('\n')

const RULES = (dir) => [
  'How to work.',
  `- Diff each file against round 0: \`git diff ${BASE} -- <file>\`. An added file has no base; review it whole. Check its sha256 with \`sha256sum <file>\`; if it differs from the one listed, set sha256_matches false and reject that file.`,
  '- Read the specification and the formats for what the file implements, and the known-issues entry the change addresses.',
  `- Run the tool tests: \`node --test docs/signoff/tools/test/*.test.js\`. You may run a tool on existing data to exercise a behaviour, writing output only under ${dir}/: for example \`node docs/signoff/tools/compile.js --out-dir ${dir}/compiled --families f01_albumin_proteins\` (the inputs are docs/signoff/work/decisions/, research/ and verify/; earlier compiled copies are under docs/signoff/work/compiled/).`,
  `- Read-only: do not modify, create or delete any file in the repository, and run no git command that changes state (no add, commit, checkout, stash, reset, restore). Write scratch files only under ${dir}/ (create it with mkdir -p). Another programme run is working in the same repository; ignore files it changes under docs/signoff/work/.`,
  '- plain_rationale: two to five sentences in plain words a CEO without a coding background can follow. Technical evidence goes in changes and findings, with file:line references.',
].join('\n')

function reviewPrompt(area) {
  const files = area.files.map((f) => `- ${f.file} (${f.kind}; sha256 ${f.sha256}; area: ${f.area})`).join('\n')
  return [
    `You review changes to frozen files of EVA's acceptance test for the CEO's approval. Area: ${area.name}.`,
    '',
    BACKGROUND,
    '',
    `Files of your area:\n${files}`,
    '',
    `Specification focus: ${area.focus}`,
    `Earlier AI review records for this area: ${area.reviews.join(', ')}. Use them only to learn which defects were raised and check each one yourself; their acceptance is not evidence.`,
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}`),
    '',
    'Reply with the structured result: one entry in files for each file listed, in the same order.',
  ].join('\n')
}

function challengePrompt(area, review) {
  const files = area.files.map((f) => `- ${f.file} (${f.kind}; sha256 ${f.sha256})`).join('\n')
  return [
    `You are the adversarial second reviewer of frozen-file changes of EVA's acceptance test, area ${area.name}, for the CEO's approval. A first reviewer gave the verdicts below. Try to overturn them.`,
    '- For each file the reviewer recommends approving, hunt for a blocking defect they missed: a way a check or a validation now passes more easily than the specification allows; a compile path that publishes a statement no reviewer checked against the current row; a code path that silently skips (missing file, empty list, early return, caught error); wrong results on edge cases; a test that asserts the wrong thing or passes vacuously.',
    '- For each blocking finding the reviewer raised, try to refute it: reproduce it, or show with evidence that it is wrong or does not matter.',
    'A finding needs evidence: file:line, a command and its output, or a concrete input and the wrong output. Agree with the reviewer only after your own search finds nothing.',
    '',
    BACKGROUND,
    '',
    `Files of your area:\n${files}`,
    `Specification focus: ${area.focus}`,
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}-challenge`),
    '',
    `The first reviewer's result:\n${JSON.stringify(review, null, 1)}`,
    '',
    'Reply with the structured result: one entry in files for each file listed, in the same order.',
  ].join('\n')
}

function decisionPrompt(lens) {
  return [
    'You advise EVA\'s CEO on eight publication rules, CEO-1 to CEO-8, raised by the compile fixes of 7 November 2026. Your recommendation will be recorded as the CEO\'s decision.',
    '',
    BACKGROUND,
    '',
    'What to read: docs/signoff/work/governance/central-fix-decisions.md (each question, the default the orchestrator took for now, the alternative, and the stated effect on the pilot batch B01); docs/signoff/work/central/compile-sources.json and its reviews compile-sources-verify.json and compile-sources-verify-2.json; the code that implements each rule in docs/signoff/tools/lib/compile-sources.js and docs/signoff/tools/lib/compile-diff.js (find the lines); the specification docs/signoff/ACCEPTANCE-TEST.md (G6, D5, D6, M3, M5 and any other check a rule touches); the B01 compile in docs/signoff/work/compiled/B01-r4/ and the family files in docs/signoff/work/decisions/, research/ and verify/ for f01 to f04; the September 2026 published summaries in the repository (find biomarker-sources.json outside docs/signoff/work/).',
    '',
    'Terms. A "recompiled entry" is a biomarker whose rows the programme changed. Its September 2026 summary (a confidence rating, caveats, unit notes) was written and rated for the old ranges. A "loosening" widens an optimal or reference range or relaxes a critical limit. A "verdict" is the independent verifier\'s judgement of a row in verify/<family>.json. CHANGES.md is the change list the physician reads, with a reason and a source for each change.',
    '',
    `Your lens: ${lens.text}`,
    '',
    'For each decision: recommend keeping the default, taking the alternative, or another rule (then state it exactly, as one line a developer can implement). Check the effect stated in the table against the data and say whether it is right. Weigh what a client reads, what the physician must review and sign, whether a rule can publish a statement nobody checked against the current range, and whether it hides information a physician or a client needs. Prefer the rule that never publishes an unchecked clinical statement, unless withholding it removes safety information a client needs; then say what must replace it. Name the code location that implements the rule (file:line).',
    '',
    `Read-only: do not modify, create or delete any file in the repository, and run no git command that changes state. Write scratch files only under ${SCR}/decisions-${lens.key}/ (create it with mkdir -p). You may run the compile into that folder to see an effect.`,
    '',
    'plain_rationale: two to five sentences in plain words a CEO without a coding background can follow. Reply with the structured result: one entry per decision, CEO-1 to CEO-8 in order.',
  ].join('\n')
}

const AREAS = A.areas
const LENSES = A.lenses

const [areas, decisions] = await Promise.all([
  pipeline(
    AREAS,
    (area) => agent(reviewPrompt(area), { label: `review ${area.key}`, phase: 'Review', schema: REVIEW, model: MODEL, effort: EFFORT }),
    (review, area) => review
      ? agent(challengePrompt(area, review), { label: `challenge ${area.key}`, phase: 'Challenge', schema: CHALLENGE, model: MODEL, effort: EFFORT }).then((ch) => ({ area: area.key, review, challenge: ch }))
      : { area: area.key, review: null, challenge: null },
  ),
  parallel(LENSES.map((lens) => () => agent(decisionPrompt(lens), { label: `decisions ${lens.key}`, phase: 'Review', schema: DECISIONS, model: MODEL, effort: EFFORT }))),
])
const missing = [
  ...AREAS.filter((a, i) => !areas[i] || !areas[i].review || !areas[i].challenge).map((a) => a.key),
  ...LENSES.filter((l, i) => !decisions[i]).map((l) => `decisions ${l.key}`),
]
if (missing.length) log(`incomplete: ${missing.join(', ')}`)
return { results: areas, decisions, missing }
