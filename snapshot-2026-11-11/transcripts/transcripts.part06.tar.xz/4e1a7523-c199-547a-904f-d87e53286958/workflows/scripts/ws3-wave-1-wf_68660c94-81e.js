export const meta = {
  name: 'ws3-wave-1',
  description: 'Workstream 3, wave 1: implement WS3-01, 02, 03, 07 (chain A) and WS3-05, 06 (chain B) in worktrees, each reviewed adversarially and fixed',
  phases: [
    { title: 'Implement', detail: 'one implementer per package, in its chain\'s worktree, committing on the chain\'s branch' },
    { title: 'Review', detail: 'an adversarial reviewer per package checks the commit against the package, the tests and the target checks' },
    { title: 'Fix', detail: 'up to two fix rounds on blocking findings, each re-reviewed' },
  ],
}

const A = args
const DESIGN = A.design_path
const SCR = A.scratch

const RESULT = {
  type: 'object',
  properties: {
    package: { type: 'string' },
    commit: { type: 'string' },
    files_changed: { type: 'array', items: { type: 'string' } },
    tests_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } },
    dsrt: { type: 'array', items: { type: 'object', properties: { check: { type: 'string' }, before: { type: 'string' }, after: { type: 'string' } }, required: ['check', 'before', 'after'] } },
    deviations_from_package: { type: 'array', items: { type: 'string' } },
    client_visible_effect: { type: 'string' },
    notes: { type: 'array', items: { type: 'string' } },
  },
  required: ['package', 'commit', 'files_changed', 'tests_run', 'dsrt', 'deviations_from_package', 'client_visible_effect', 'notes'],
}
const REVIEW = {
  type: 'object',
  properties: {
    package: { type: 'string' },
    commit_reviewed: { type: 'string' },
    verdict: { type: 'string', enum: ['approve', 'reject'] },
    blocking: { type: 'array', items: { type: 'object', properties: { summary: { type: 'string' }, evidence: { type: 'string' }, smallest_fix: { type: 'string' } }, required: ['summary', 'evidence', 'smallest_fix'] } },
    tests_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } },
    notes: { type: 'array', items: { type: 'string' } },
  },
  required: ['package', 'commit_reviewed', 'verdict', 'blocking', 'tests_run', 'notes'],
}

const RULES = (wt, branch) => [
  'Context. EVA is a preventive-health app (Next.js, TypeScript, Supabase). A licensed physician will sign its ranges, its biological age model and its EVA score before launch; the acceptance test is docs/signoff/ACCEPTANCE-TEST.md, its runner scripts/signoff/ (`npx tsx scripts/signoff/dsrt.ts --round 9 --only <ids> --seed-dir docs/signoff/work/compiled/B05-r2 --out <scratch file>`). Workstream 3 makes the score consistent with the ranges and the biological age. The design you implement from is ' + DESIGN + ' (keys maps and design; design.work_packages, design.decisions, design.summary): read your package there, and the maps of the checks it names.',
  `Work only in the worktree ${wt} (branch ${branch}); every path below is relative to it. node_modules is linked. Never touch /home/user/eva-health itself or another worktree. Scratch files only under ${SCR}/ (mkdir -p).`,
  'Hard rules:',
  '- No database access of any kind, no migration applied, no data written, no recalculation or backfill; a migration, where a package asks for one, is a file only.',
  '- Do not modify frozen acceptance-test files: anything under scripts/signoff/ or docs/signoff/tools/, docs/signoff/ACCEPTANCE-TEST.md, docs/signoff/LOOP-PROMPT.md, docs/signoff/PLAN.md, docs/signoff/thresholds.json, docs/signoff/work/judges/lenses.json. The runner imports calculateLongevityScoreV2, reviewedPenalty, REVIEWED_ROW_KEY and the engine types (scripts/signoff/checks/score.ts, personas.ts, consistency.ts): keep those exports and their signatures working (an extra optional argument is fine). docs/signoff/tools/inputs/readers.js reads the engine source: after your change run `node docs/signoff/tools/build-inputs.js --check`; it may report stale inputs (say which and why), but it must not crash.',
  '- Clinical numbers come from the families and governance files, never invented in code. Client-facing copy follows docs/signoff/work/governance/wording-rules.md in English and Spanish.',
  '- This Next.js version differs from what you may know: before changing a route or a page, read the relevant guide in node_modules/next/dist/docs/.',
  '- Tests must exercise behaviour (call the code, assert outcomes), not just mention numbers. Run, and report: the vitest files you touched and `npx vitest run src/lib` (and any other suite your files reach), `npx tsc --noEmit`, `npx eslint <changed files>` (do not add lint errors; report pre-existing ones as pre-existing), and the DSRT checks your package names, before and after.',
  `- Commit your work on ${branch} in that worktree with a clear message: a subject starting with the package id, a short body of what changed and why, and these two trailer lines at the end: "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>" and "Claude-Session: https://claude.ai/code/session_016mEXZE6RheLMXSZTgYDUrW". No AI model names anywhere in the message, the code or comments. Do not push.`,
  '- Decisions D-01 to D-27 in the design are not yet ruled; implement the design\'s recommendation where your package needs one, and say so in notes ("provisional on D-xx").',
].join('\n')

function implPrompt(p, wt, branch, prior) {
  return [
    `You implement work package ${p} of EVA's workstream 3.`,
    RULES(wt, branch),
    prior.length ? `Packages already committed on this branch before yours: ${prior.join(', ')}. Build on them.` : 'You are the first package on this branch.',
    `Implement ${p} exactly as the design's work package describes (steps, files, tests), no more. If the repository contradicts the design, follow the repository's truth, keep the package's intent, and list the deviation with evidence. Reply with the structured result (commit = the hash you committed).`,
  ].join('\n\n')
}
function reviewPrompt(p, wt, branch, impl) {
  return [
    `You are the adversarial reviewer of work package ${p} of EVA's workstream 3. The implementer reports the result below. Try to reject it: find where the commit does not do what the package asks, does more than it asks, breaks a reader or a test elsewhere, weakens a test, changes a frozen file, writes data, changes client copy against wording-rules.md, or moves a check the wrong way. Verify claims yourself: read the diff (\`git -C ${wt} show --stat <commit>\`, \`git -C ${wt} diff <commit>~1 <commit>\`), run the tests and the DSRT checks the package names. Approve only when nothing blocking remains; a cosmetic point is a note.`,
    RULES(wt, branch).replace(/Commit your work[^\n]*\n/, 'Read-only: do not modify, create or delete files in the worktree, and make no commit.\n'),
    `Implementer's result:\n${JSON.stringify(impl, null, 1)}`,
    'Reply with the structured result.',
  ].join('\n\n')
}
function fixPrompt(p, wt, branch, impl, review) {
  return [
    `You fix work package ${p} of EVA's workstream 3 after an adversarial review rejected it. Address every blocking finding, or show with evidence that it is wrong. Commit the fix on top (do not amend).`,
    RULES(wt, branch),
    `The implementer's last result:\n${JSON.stringify(impl, null, 1)}`,
    `The review:\n${JSON.stringify(review, null, 1)}`,
    'Reply with the structured result (commit = your new commit; list in notes how each finding was handled).',
  ].join('\n\n')
}

async function runPackage(p, chain, prior) {
  const { worktree: wt, branch } = chain
  let impl = await agent(implPrompt(p, wt, branch, prior), { label: `implement ${p}`, phase: 'Implement', schema: RESULT })
  if (!impl) return { package: p, status: 'implementer returned nothing' }
  let rev = await agent(reviewPrompt(p, wt, branch, impl), { label: `review ${p}`, phase: 'Review', schema: REVIEW })
  let rounds = 0
  while (rev && rev.verdict === 'reject' && rounds < 2) {
    rounds++
    const fix = await agent(fixPrompt(p, wt, branch, impl, rev), { label: `fix ${p} r${rounds}`, phase: 'Fix', schema: RESULT })
    if (!fix) break
    impl = fix
    rev = await agent(reviewPrompt(p, wt, branch, impl), { label: `review ${p} r${rounds + 1}`, phase: 'Review', schema: REVIEW })
  }
  const status = !rev ? 'review returned nothing' : rev.verdict === 'approve' ? 'approved' : 'rejected after fixes'
  log(`${p}: ${status} (commit ${impl.commit}, fix rounds ${rounds})`)
  return { package: p, status, fix_rounds: rounds, impl, review: rev }
}

async function runChain(chain) {
  const out = []
  const done = []
  for (const p of chain.packages) {
    const r = await runPackage(p, chain, done)
    out.push(r)
    if (r.status !== 'approved') { log(`chain ${chain.branch}: stopped after ${p} (${r.status}); later packages not started: ${chain.packages.slice(chain.packages.indexOf(p) + 1).join(', ') || 'none'}`); break }
    done.push(p)
  }
  return { branch: chain.branch, worktree: chain.worktree, results: out }
}

const chains = await parallel(A.chains.map((c) => () => runChain(c)))
return { chains }
