export const meta = {
  name: 'signoff-central-fixes',
  description: 'Fix the shared infrastructure defects found by the B01 pilot, verify each adversarially, then re-check B01',
  phases: [
    { title: 'Fix', detail: 'runner, bounded results, compile rows, compile sources, limits table' },
    { title: 'Verify', detail: 'one adversarial reviewer per area, one repair pass if rejected' },
    { title: 'Recheck', detail: 'tests, compile B01, DSRT round 4, before and after' },
  ],
}

const SCR = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/central'
const C = 'docs/signoff/work/central'
const B01 = '--families f01_albumin_proteins,f03_kidney,f04_inflammation'

const SHARED = [
  'You are a senior engineer fixing shared infrastructure for EVA\'s physician sign-off programme, in the repository at',
  '/home/user/eva-health on branch claude/wonderful-meitner-l4g7p5. EVA is a longevity blood-test app; the programme prepares',
  'biomarker ranges, a biological age model and a score for a licensed physician\'s sign-off. All of it is AI work product',
  'that the physician reviews.',
  '',
  'Background. The acceptance test is docs/signoff/ACCEPTANCE-TEST.md (the DSRT); its runner is scripts/signoff/dsrt.ts with',
  'checks in scripts/signoff/checks/ (run it with npm run dsrt -- ...). The loop tooling is in docs/signoff/tools/ (compile.js,',
  'validate.js, schemas in tools/schema/). The pilot batch B01 (families f01_albumin_proteins, f03_kidney, f04_inflammation) ran',
  'three rounds of author, verifier, judges, refuters and fixer. Its families could not pass, largely because of defects in',
  'shared infrastructure that no family may touch. Evidence: the round-3 results docs/signoff/work/checks/f01_albumin_proteins-r3.json,',
  'f03_kidney-r3.json, f04_inflammation-r3.json and docs/signoff/work/checks/B01-r3.json; the judges\' files in',
  'docs/signoff/work/judges/round-1/, round-2/ and round-3/; the ledgers in docs/signoff/work/ledger/; the decisions in',
  'docs/signoff/work/decisions/; and the round-3 compile in docs/signoff/work/compiled/B01-r3/.',
  '',
  'Rules.',
  '- Write only the files listed as yours. Other agents edit other files at the same time: do not touch theirs, and run no git',
  '  command that changes the working tree or the index (no checkout, stash, reset, add, commit).',
  '- Never query a database, apply a migration, send a message or call the app\'s API.',
  '- These specification files never change: docs/signoff/ACCEPTANCE-TEST.md, docs/signoff/LOOP-PROMPT.md, docs/signoff/PLAN.md,',
  '  docs/signoff/thresholds.json.',
  '- Runner and tool files (scripts/signoff/**, docs/signoff/tools/**) are frozen by check G1 at round 0. You may change one only',
  '  to fix a defect: the code does not do what the frozen specification text says, or it cannot work with the frozen schemas',
  '  and the files the loop produces. A change that lets a check pass more easily than the specification text allows is a',
  '  loosening and is forbidden. For every frozen file you change, your report quotes the specification text the change',
  '  implements and names the defect. The CEO approves these changes afterwards; do not edit',
  '  docs/signoff/work/governance/approved-changes.json.',
  '- App code under src/ is not frozen. Keep changes minimal and covered by tests.',
  '- Every claim in your report comes from a command you ran or a line you read. Report test results truthfully, failures included.',
  '- Do not write AI model names into any file.',
  `- Scratch files go only under ${SCR}/<your area>/.`,
  '- Write your report file before you reply, and write a partial one if you run short of time.',
].join('\n')

const AREAS = {
  runner: {
    files: ['scripts/signoff/checks/governance.ts', 'scripts/signoff/checks/data.ts', 'scripts/signoff/lib/', 'src/lib/signoff/dsrt-checks.test.ts', 'src/lib/signoff/dsrt-core.test.ts'],
    tests: 'npx vitest run src/lib/signoff',
    task: [
      `Area: runner. Your files: scripts/signoff/checks/governance.ts, scripts/signoff/checks/data.ts, scripts/signoff/lib/*.ts (only if a fix needs it), src/lib/signoff/dsrt-checks.test.ts, src/lib/signoff/dsrt-core.test.ts, and your report ${C}/runner.json.`,
      '',
      '1. G2, traceability. Specification (ACCEPTANCE-TEST.md, G2): "Every row traces to decisions/<family>.json with a verifier',
      '   verdict, and every decisions file to research and verify files that validate. Every ledger item is in a known state."',
      '   traceRows in governance.ts matches decisions final_rows by d.row_key, but final_rows items follow',
      '   docs/signoff/tools/schema/common.schema.json $defs/row, which has additionalProperties false and no row_key, so every',
      '   compiled row is reported untraced (f01: "4 untraced rows of 4"). Derive a final row\'s key the same way as the seed row\'s',
      '   trace key (marker_key|sex|age_group|physiological_state). Keep every other requirement (decisions file exists, verifier',
      '   verdict exists). Add unit tests.',
      '2. D5, one source of truth. Specification: "Seed English = seed Spanish = migration files = latest production snapshot plus',
      '   the documented pack changes. Every production-only marker either enters the seed or is retired by a recorded decision."',
      '   Pass rule: "0 unexplained differences". checkSourceOfTruth in data.ts counts every difference against the snapshot plus',
      '   MIGRATIONS_AFTER_SNAPSHOT as unexplained and never reads the documented pack changes, so every intended change fails D5',
      '   forever. The pack\'s documented changes are produced by docs/signoff/tools/compile.js: changes.json and CHANGES.md in the',
      '   compile output directory, and diff.json in --reconciliation-dir, the file check D6 reads (rows {key, reason, source}).',
      '   Read compile.js and docs/signoff/tools/lib/compile-diff.js for the exact format; do not edit them. Another agent is',
      '   improving how compile fills reasons and sources right now, so code to the format, not to today\'s reason texts.',
      '   Implement: a difference is explained only when the documented change list that belongs to the seed being checked (the',
      '   changes.json next to it, or the reconciliation diff) lists that row and field with a non-empty reason and a non-empty',
      '   source; "unexplained" placeholders count as missing. Rows only in the seed or only in production follow the same rule',
      '   (a documented added or retired row). A production-only marker still needs a recorded decision. Every difference that is',
      '   not documented stays a failure. Add unit tests for documented, undocumented and placeholder cases.',
      '3. Scan. Read every check in scripts/signoff/checks/ against the frozen schemas in docs/signoff/tools/schema/ and the B01',
      '   round-3 results. List every other place where the runner reads a field or a file that the loop cannot produce, or reads',
      '   it under a different name than the loop writes it. Known examples you only report, because other agents own the fixes:',
      '   L1 reads docs/signoff/work/governance/critical-limits.json by marker_key while the table uses key; P3\'s appBoundedZone in',
      '   preanalytical.ts reimplements the app\'s bounded-result path instead of calling it; D2 compares Spanish and English',
      '   age-group labels where state rows are "Embarazo" and "Pregnancy". Fix only further defects of the same kind as 1 and 2',
      '   that sit in your files; report the rest with evidence and a proposed fix.',
      '4. Run npx vitest run src/lib/signoff, and the DSRT on the round-3 compile:',
      `   npm run dsrt -- --round 3 ${B01} --seed-dir docs/signoff/work/compiled/B01-r3 --out ${SCR}/runner/after.json`,
      '   Use docs/signoff/work/checks/B01-r3.json as "before". Report G2 and D5 failure counts before and after, and why each',
      '   remaining D5 failure remains.',
    ].join('\n'),
  },
  bounded: {
    files: ['src/lib/biomarkers/bounded-result.ts', 'src/lib/biomarkers/bounded-result.test.ts', 'src/lib/biomarkers/process-results.ts', 'scripts/signoff/checks/preanalytical.ts'],
    tests: 'npx vitest run src/lib/biomarkers src/lib/signoff',
    task: [
      `Area: bounded results. Your files: a new module src/lib/biomarkers/bounded-result.ts and its test file src/lib/biomarkers/bounded-result.test.ts; src/lib/biomarkers/process-results.ts; any existing test of process-results that your change breaks; scripts/signoff/checks/preanalytical.ts (only the function appBoundedZone and its imports); and your report ${C}/bounded.json. The runner agent worked before you on governance.ts, data.ts and src/lib/signoff tests; do not edit those, except a test in src/lib/signoff/dsrt-checks.test.ts that asserts the old appBoundedZone behaviour.`,
      '',
      'Specification (ACCEPTANCE-TEST.md, P3): "Reportable range. Every optimal bound sits at or above the assay\'s lowest',
      'reportable value. A bounded result such as "<5" resolves to the bound itself and is never classified above optimal." The',
      'check builds, for every seed row with an optimal ceiling, a fixture "<X" with X between the optimal ceiling and the',
      'reference ceiling, and fails when it is classified above_optimal or critical_high. Today process-results.ts (around line',
      '430) classifies a bounded result\'s parsed value with classifyZone and ignores the comparator; B01 has violations for bun,',
      'cystatin_c, egfr_creatinine_based 18-39 and 40-84, urea and hs_crp.',
      '',
      'Implement the rule once, in the app:',
      '- export a function that takes the parsed value, its comparator ("<", "<=", ">", ">=" or none) and the row\'s four bounds',
      '  and returns the zone; process-results.ts uses it for every result;',
      '- the value stays the bound itself;',
      '- a result without a comparator is classified exactly as classifyZone does today;',
      '- "<X" means the true value lies below X. Return the zone of the values just below X only when every value below X falls',
      '  in that one zone; otherwise the result cannot be placed and the zone is "unclassified". So "<0.2" mg/L hs-CRP with an',
      '  optimal ceiling of 0.5 and no floor is optimal; "<5" for a marker whose reference floor is 10 keeps today\'s low zone;',
      '  "<1.75" for hs-CRP is unclassified, never above_optimal;',
      '- ">X" mirrors it: the zone of the values just above X when they all fall in one zone, else unclassified;',
      '- do not change classifyZone, zone-config, the zone names or anything about critical zones (separate work).',
      'Check every consumer of the zone for what "unclassified" does there (display, score, the biological age adapter,',
      'auto-resolve) and say in the report what a client would see. Do not change those consumers unless the result would crash',
      'or be scored.',
      '',
      'Then make the runner test the app\'s real path: change appBoundedZone in scripts/signoff/checks/preanalytical.ts to call',
      'your exported function with the parser\'s value and comparator instead of reimplementing the classification. This is a',
      'frozen-file change: quote the specification text in your report.',
      '',
      'Tests: unit tests for the function (each comparator, a bound exactly at a threshold, rows with and without floors and',
      'ceilings, null bounds); npx vitest run src/lib/biomarkers src/lib/signoff; and',
      `npm run dsrt -- --only P3 --round 3 ${B01} --seed-dir docs/signoff/work/compiled/B01-r3 --out ${SCR}/bounded/p3.json.`,
      'Report the P3 result before (docs/signoff/work/checks/B01-r3.json) and after.',
    ].join('\n'),
  },
  compile_rows: {
    files: ['docs/signoff/tools/lib/compile-rows.js', 'docs/signoff/tools/compile.js', 'docs/signoff/tools/schema/', 'docs/signoff/tools/validate.js', 'docs/signoff/tools/build-briefs.js', 'docs/signoff/tools/test/'],
    tests: 'node --test docs/signoff/tools/test/',
    task: [
      `Area: compile rows. Your files: docs/signoff/tools/lib/compile-rows.js, docs/signoff/tools/compile.js, docs/signoff/tools/schema/*.json, docs/signoff/tools/validate.js, docs/signoff/tools/build-briefs.js, the tests under docs/signoff/tools/test/ for these files, and your report ${C}/compile-rows.json. A second compile agent works after you on lib/compile-sources.js and lib/compile-diff.js; do not edit those.`,
      '',
      'Defects reported by the B01 judges (docs/signoff/work/judges/round-3/ and the ledgers):',
      '1. D2 parity. Spanish state rows carry Grupo_Edad "Embarazo"/"Lactancia" while English carries "Pregnancy"/"Lactation";',
      '   check D2 ("English and Spanish parity: same rows, keys, sex, age group, unit and the six bounds") counts a mismatch.',
      '   Find the convention the app relies on: the Grupo_Edad values of every other row in today\'s',
      '   supabase/seed-data/rangos-biomarcadores-es.json, the production snapshot',
      '   docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json, and the code that selects a',
      '   reference row by age group or state (search src/ for age_group, Grupo_Edad, reference-row). Make the compile follow that',
      '   convention. If the convention is that Spanish labels are translated and the runner is wrong, do not change the runner;',
      '   report it.',
      '2. M5. The compiled Spanish file, the version the physician signs, carries English text in physician-facing fields:',
      '   Nota_Método, Fuente_Referencia, Motivo_Sin_Crítico and any other field compile fills from an English-only row field.',
      '   List every such field. Add optional Spanish counterparts to the row schema, optional so that every existing research,',
      '   verify and decisions file still validates. Make compile write them into the Spanish file when present; when absent,',
      '   write the English text as today and list the row and field under an "untranslated" warning in compile-report.json.',
      '   Make build-briefs.js show the new fields to authors and fixers.',
      '3. Stale Clinical_Notes. Rows compiled from decisions keep today\'s Clinical_Notes (and any other seed text column the row',
      '   schema cannot carry), which now contradict the new bounds. Examples: BUN "a BUN between 7 and 10 mg/dL reads below the',
      '   BUN range while the same blood is within the urea range"; urea "Its reference interval starts at 15 mg/dL". Add optional',
      '   clinical notes in English and Spanish to the row schema; compile writes them when present. When absent on a row compiled',
      '   from decisions, compile keeps today\'s text but lists it in compile-report.json under "notes_not_reviewed", and under',
      '   "notes_stale_numbers" when the text contains a number equal to a bound that changed in this compile. Do not delete or',
      '   rewrite clinical text yourself.',
      '4. Critical-tier columns. Judges found rows with a numeric critical limit but no critical zone or critical message in the',
      '   compiled seed, because today\'s Msg_Critical_* columns hold the out-of-reference messages. Do not fix this; it needs app',
      '   and data-model changes in a later workstream. Report what the compile writes today and a proposal.',
      '',
      'Keep compile deterministic: run it twice into two scratch dirs and diff them. Validate every existing file with',
      'node docs/signoff/tools/validate.js research|verify|decision <family> for f01_albumin_proteins, f03_kidney and',
      'f04_inflammation. Run the tools\' tests (node --test docs/signoff/tools/test/). Compile B01:',
      `node docs/signoff/tools/compile.js --out-dir ${SCR}/compile_rows/b01 ${B01}`,
      'and report the new warnings by kind and count.',
    ].join('\n'),
  },
  compile_sources: {
    files: ['docs/signoff/tools/lib/compile-sources.js', 'docs/signoff/tools/lib/compile-diff.js', 'docs/signoff/tools/lib/compile-sql.js', 'docs/signoff/tools/test/'],
    tests: 'node --test docs/signoff/tools/test/',
    task: [
      `Area: compile sources and changes. Your files: docs/signoff/tools/lib/compile-sources.js, docs/signoff/tools/lib/compile-diff.js, docs/signoff/tools/lib/compile-sql.js (only if the reconciliation output needs it), their tests under docs/signoff/tools/test/, and your report ${C}/compile-sources.json. The compile-rows agent changed compile.js, lib/compile-rows.js and the schemas before you: read its report ${C}/compile-rows.json first and do not edit its files; report any change you need there.`,
      '',
      'Defects:',
      '1. G6 published summaries. The compiled biomarker-sources.json keeps the September summaries and caveats for every B01',
      '   marker, and they contradict the new rows: albumin "optimal ... from 42 g/L ... within a reference range of 35–48 g/L"',
      '   while the row is 41 and 32-48; cystatin C "up to 0.85 mg/L" while the row is 0.72; fibrinogen "Optimal is up to',
      '   300 mg/dL" while the row has no optimal band; hs-CRP caveats cite [S1]-[S17], which are absent from its source list.',
      '   Specification G6: "Every number in the pack that exists in a result file matches it, and no two statements give',
      '   different values for the same quantity." Make the compile never publish a summary that contradicts the compiled rows.',
      '   When a family\'s decisions supply a summary, use it. Otherwise build a deterministic summary in English and Spanish from',
      '   the compiled rows (bounds, units, sex and age groups, basis), drop citations that are not in the marker\'s compiled',
      '   source list, and list each replaced summary in compile-report.json. If the decision schema has no field for a',
      '   family-supplied summary, do not change the schema (the compile-rows agent owns it); use the deterministic summary and',
      '   report the proposal.',
      '2. D6 explained changes. changes.json and CHANGES.md mark many changes "**unexplained**" (for example albumin normal_low',
      '   35 to 32 and optimal_high 48 to null; cystatin C), because only decisions "changes" entries are read, while the reason',
      '   and source of many changes are recorded in the verify file (its corrections and row verdicts) or in the row itself',
      '   (reference_source, the evidence records). Specification D6: "A diff against the production snapshot gives a reason and',
      '   source for every changed row." Make the diff take the documented reason and source from the whole chain, in this',
      '   order: decisions changes, then verify corrections or verdicts, then the row\'s reference_source and its evidence',
      '   records for that bound. Record which one it used. Keep "unexplained" only when nothing in the chain documents the',
      '   change. The reconciliation diff written by --reconciliation-dir must carry, per changed row and field, a non-empty',
      '   reason and source whenever one exists. The runner agent is teaching check D5 to read this documented change list, so',
      '   keep the row key format and field names stable, and document them in your report.',
      '',
      'Keep compile deterministic (two runs, byte-identical). Run the tools\' tests and validate the B01 files as the',
      'compile-rows agent did. Compile B01 with a reconciliation dir:',
      `node docs/signoff/tools/compile.js --out-dir ${SCR}/compile_sources/b01 ${B01} --reconciliation-dir ${SCR}/compile_sources/b01-recon`,
      'and report how many changes are explained, by which source, and which remain unexplained.',
    ].join('\n'),
  },
  limits_table: {
    files: ['docs/signoff/work/governance/critical-limits.json', 'docs/signoff/work/governance/critical-limits.md'],
    tests: `npm run dsrt -- --only L1 --round 3 ${B01} --seed-dir docs/signoff/work/compiled/B01-r3 --out ${SCR}/limits_table/l1-verify.json`,
    task: [
      `Area: critical limits table. Your files: docs/signoff/work/governance/critical-limits.json, docs/signoff/work/governance/critical-limits.md, and your report ${C}/limits-table.json.`,
      '',
      'Check L1 (scripts/signoff/checks/limits.ts: l1Analytes, entriesOf, criticalEntryProblems) reads the table by marker_key,',
      'using the seed biomarker keys in docs/signoff/work/families.json base_panel plus L1_EXTRA_ANALYTES. Per entry it needs: a',
      'numeric critical_low or critical_high, or none_because starting "none, because"; sources (a non-empty array);',
      'alternatives (an array); and, when there is a numeric limit, action_en, action_es and recipient_role. Today\'s table uses',
      'key, not marker_key; some keys differ from the seed keys the runner asks for (for example calcium vs calcium_serum,',
      'glucose vs glucose_fasting, platelets vs platelet_count, bilirubin_total vs total_bilirubin, wbc vs',
      'white_blood_cell_count: confirm each against the runner and supabase/seed-data/biomarker-ranges-en.json); and the fields',
      'have other names (critical_low_none_because, range_across_sources and so on). So L1 reports all 26 analytes as missing.',
      '',
      'Restructure the table to the runner\'s format without changing any clinical content. Every value, unit, source, rationale',
      'and alternative stays as it is; only names and structure change. You may keep the existing fields too, but the runner\'s',
      'fields must be present. Build none_because from the existing none-because texts. Take sources, alternatives, action',
      'wording (EN and ES) and the recipient role from the existing entry and critical-limits.md. If one is genuinely absent for',
      'an analyte with a numeric limit, do not invent it: leave the field empty and list it in your report as a gap for the',
      'physician. Update critical-limits.md only where it names the old keys.',
      '',
      `Then run npm run dsrt -- --only L1 --round 3 ${B01} --seed-dir docs/signoff/work/compiled/B01-r3 --out ${SCR}/limits_table/l1.json`,
      'and report every remaining L1 failure. Expected to remain: the classifier failures (zone-classifier.ts derives critical',
      'from reference limits; a later workstream fixes it) and seed rows without critical fields (family content).',
      'Finally prove no clinical content changed: write a script that compares, analyte by analyte, every numeric value and',
      'every source identifier in the old table (git show HEAD:docs/signoff/work/governance/critical-limits.json) with the new',
      'one, and include its output in your report.',
    ].join('\n'),
  },
}

const TEST_ROW = { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] }
const FIX_SCHEMA = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    files_changed: { type: 'array', items: { type: 'string' } },
    frozen_files_changed: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, spec_text: { type: 'string' }, defect: { type: 'string' }, change: { type: 'string' } }, required: ['file', 'spec_text', 'defect', 'change'] } },
    fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, check: { type: 'string' }, root_cause: { type: 'string' }, fix: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'check', 'root_cause', 'fix', 'evidence'] } },
    reported_not_fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, check: { type: 'string' }, owner: { type: 'string' }, root_cause: { type: 'string' }, proposal: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'check', 'owner', 'root_cause', 'proposal', 'evidence'] } },
    tests: { type: 'array', items: TEST_ROW },
    report_file: { type: 'string' },
    notes: { type: 'string' },
  },
  required: ['area', 'files_changed', 'frozen_files_changed', 'fixed', 'reported_not_fixed', 'tests', 'report_file'],
}
const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    verdict: { type: 'string', enum: ['accept', 'reject'] },
    problems: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, line: { type: 'integer' }, kind: { type: 'string', enum: ['loosening', 'defect_not_fixed', 'regression', 'test_failure', 'ownership', 'determinism', 'clinical_content_changed', 'other'] }, detail: { type: 'string' }, required_change: { type: 'string' } }, required: ['kind', 'detail', 'required_change'] } },
    tests: { type: 'array', items: TEST_ROW },
    notes: { type: 'string' },
  },
  required: ['area', 'verdict', 'problems', 'tests'],
}
const RECHECK_SCHEMA = {
  type: 'object',
  properties: {
    tests: { type: 'array', items: TEST_ROW },
    compile_ok: { type: 'boolean' },
    dsrt_file: { type: 'string' },
    checks: { type: 'array', items: { type: 'object', properties: { check: { type: 'string' }, before_status: { type: 'string' }, before_failures: { type: 'integer' }, after_status: { type: 'string' }, after_failures: { type: 'integer' } }, required: ['check', 'before_status', 'before_failures', 'after_status', 'after_failures'] } },
    remaining_by_owner: { type: 'array', items: { type: 'object', properties: { owner: { type: 'string' }, check: { type: 'string' }, count: { type: 'integer' }, examples: { type: 'array', items: { type: 'string' } } }, required: ['owner', 'check', 'count'] } },
    summary_file: { type: 'string' },
    notes: { type: 'string' },
  },
  required: ['tests', 'compile_ok', 'checks', 'remaining_by_owner', 'summary_file'],
}

const fixPrompt = (key, repair) => [SHARED, '', AREAS[key].task, repair ? `\n\nA verifier rejected your area's change. Its findings, verbatim:\n${JSON.stringify(repair, null, 1)}\n\nAddress every required change, or show with evidence why it is wrong. Keep your file ownership. Update your report ${C}/${key.replace('_', '-')}.json (add a "repair" section) and reply with the full structured result.` : ''].join('\n')

const verifyPrompt = (key, fix) => [
  SHARED,
  '',
  `Area under review: ${key}. You did not write this change. Find what is wrong with it before the CEO is asked to approve it.`,
  '',
  `The fix agent's task was:\n---\n${AREAS[key].task}\n---`,
  `Its structured result: ${JSON.stringify(fix || {}, null, 1).slice(0, 6000)}`,
  `Its files: ${AREAS[key].files.join(', ')}. Read its report and the diff: git diff -- ${AREAS[key].files.join(' ')}; for new files, git status --porcelain -uall and read them whole.`,
  '',
  'Try to show each of these, and default to "reject" when you cannot confirm the opposite:',
  '1. Loosening: a check now passes in a case the specification text in docs/signoff/ACCEPTANCE-TEST.md would fail. Quote the line.',
  '2. Defect not fixed: re-run the command that showed the defect and compare.',
  `3. Regression: run ${AREAS[key].tests} and any other test that imports a touched module.`,
  '4. Clinical content changed where the task said it must not (numbers, sources, clinical wording).',
  '5. Ownership: changes outside the files listed for this area.',
  '6. Determinism, for compile changes: two runs give byte-identical outputs.',
  'Minor style points are not problems. A problem is something that would make the CEO wrong to approve the change.',
  `Write your verdict to ${C}/${key.replace('_', '-')}-verify.json (verdict, problems, tests) and reply with the structured result. Write only that file and scratch files.`,
].join('\n')

const ORCH_FIXED = new Set(['compile_rows', 'limits_table'])

async function runArea(key) {
  const fix = await agent(fixPrompt(key, null), { label: `fix ${key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'max' })
  if (!fix) { log(`fix ${key}: returned nothing`); return { key, fix: null, verdict: 'no_result' } }
  let v = await agent(verifyPrompt(key, fix), { label: `verify ${key}`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max' })
  if (!v) { log(`verify ${key}: returned nothing`); return { key, fix, verdict: 'unverified' } }
  if (v.verdict === 'accept') return { key, fix, verify: v, verdict: 'accept' }
  // report-only findings, repaired and checked by the orchestrator after the usage limit stopped the repair pass
  if (ORCH_FIXED.has(key)) { log(`verify ${key}: report-only findings, repaired by the orchestrator`); return { key, fix, verify: v, verdict: 'accept_after_report_repair' } }
  log(`verify ${key}: rejected with ${v.problems.length} problems; one repair pass`)
  const fix2 = await agent(fixPrompt(key, v.problems), { label: `repair ${key}`, phase: 'Verify', schema: FIX_SCHEMA, effort: 'max' })
  if (!fix2) return { key, fix, verify: v, verdict: 'rejected_no_repair' }
  const v2 = await agent(verifyPrompt(key, fix2), { label: `re-verify ${key}`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max' })
  return { key, fix: fix2, first_verify: v, verify: v2, verdict: v2 ? v2.verdict : 'unverified' }
}

phase('Fix')
// Chains that share files run in order; the chains run in parallel.
const chains = [['runner', 'bounded'], ['compile_rows', 'compile_sources'], ['limits_table']]
const chainResults = await parallel(chains.map((chain) => async () => {
  const out = []
  for (const key of chain) out.push(await runArea(key))
  return out
}))
const results = chainResults.filter(Boolean).flat()
for (const r of results) log(`${r.key}: ${r.verdict}`)

phase('Recheck')
const recheck = await agent([
  SHARED,
  '',
  `Area: integration recheck. Write only ${C}/recheck-B01.json, ${C}/recheck-B01.md, docs/signoff/work/checks/B01-c1.json, the compile output docs/signoff/work/compiled/B01-c1/, and scratch files.`,
  `The fix areas and their verdicts: ${JSON.stringify(results.map((r) => ({ area: r.key, verdict: r.verdict, files: r.fix ? r.fix.files_changed : [] })))}`,
  '1. Run the test suites: npx vitest run src/lib/signoff src/lib/biomarkers, and node --test docs/signoff/tools/test/*.test.js (the directory form fails on this Node). Report pass and fail counts.',
  `2. Compile B01: node docs/signoff/tools/compile.js --out-dir docs/signoff/work/compiled/B01-c1 ${B01} --reconciliation-dir docs/signoff/work/compiled/B01-c1/reconciliation`,
  `3. Run the DSRT: npm run dsrt -- --round 4 ${B01} --seed-dir docs/signoff/work/compiled/B01-c1 --out docs/signoff/work/checks/B01-c1.json`,
  '4. Compare with docs/signoff/work/checks/B01-r3.json check by check: status and failure count before and after, counting only failures whose key names a B01 marker (albumin, total_protein, globulin, albumin_globulin_ratio, creatinine, egfr_creatinine_based, cystatin_c, bun, urea, bun_creatinine_ratio, hs_crp, fibrinogen), plus G1 and G2 in full.',
  '5. Classify every remaining B01 failure by owner: "family content" (the family\'s next fixer can fix it in decisions/<family>.json), "cross-family" (K1 accepted reasons, N1 resolutions, X1 exceptions; workstream 1-K), "app and score" (classifier critical zone, state-aware rows, score; workstream 3), "external data" (Echevarne tables), "CEO approval" (G1).',
  '6. The .md is a one-page summary for the orchestrator: a table of checks before and after, and the owner list with counts.',
].join('\n'), { label: 'recheck B01', phase: 'Recheck', schema: RECHECK_SCHEMA, effort: 'high' })

return { areas: results.map((r) => ({ area: r.key, verdict: r.verdict, files: r.fix ? r.fix.files_changed : [], frozen: r.fix ? r.fix.frozen_files_changed.map((f) => f.file) : [], problems: r.verify ? r.verify.problems : [] })), recheck }
