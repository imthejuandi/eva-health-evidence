export const meta = {
  name: 'cmo-reassessment',
  description: 'CMO reassessment of EVA biological age program: six lenses, fact-check, critic, memo',
  phases: [
    { title: 'Assess', detail: 'six independent lenses read the repo, the live site and sources' },
    { title: 'Challenge', detail: 'adversarial fact-check and a skeptical medical director' },
    { title: 'Synthesize', detail: 'CMO memo with ordered next steps' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/cmo'

const CONTEXT = `You are one reviewer in a CMO-level reassessment of EVA Health's biological age program and the clinical, regulatory and operational state around it. Today is 3 November 2026. The CEO asked: "What would you do as of now? Reassess everything as a Chief Medical Officer and recommend the next steps."

EVA Health, S.L. is a Spanish preventive-health startup. Clients buy a 99 euro Base Panel blood test of 13 serum tests run by EVA's partner laboratory Echevarne, from venous draws, with Tasso capillary home kits under study. Clients can also upload other laboratories' results, and they see biomarker results, a Longevity Score, AI-written summaries and a biological age on a dashboard. The repo is /home/user/eva-health. README.md orients you.

Facts the orchestrator verified on 3 November 2026. Build on them; tell us if you find any of them wrong:
1. Deployed code is origin/main at c472974, PR #61, merged 22 Sep 2026; the public site https://evahealth.es serves it. The work branch claude/wonderful-meitner-l4g7p5, HEAD e7c1540, checked out in the repo, is 648 commits ahead of main and 2 behind, with no pull request. Read what is live with: git show origin/main:<path>. Read the branch in the working tree.
2. The live page https://evahealth.es/es/metodologia still says "Es una predicción de mortalidad validada en 18.570 personas", "Validación fuera de muestra (5-fold CV); intervalo de confianza 95% [1.20, 1.40]" and "Recalibrado para España con 11 de 14 marcadores del panel base". The CEO's decision memo of 29 Oct 2026, docs/biomarker-evidence/bioage-model-selection/DECISION.md section 5.1 item 3, says EVA's own files do not support these and they must be corrected now. The corrections exist only on the branch; replacement text is in docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md, waiting for counsel.
3. Version 3, in ml/biological-age/ with PROPOSAL.md, MODEL-CARD.md and PHYSICIAN-SIGNOFF.md, and its shadow computation exist only on the branch. Release to clients is gated by PROPOSAL.md conditions 1 to 7; none is recorded as met. The 12-item physician sign-off sheet is unsigned.
4. Supabase reports both the production project "eva-health" in eu-west-1 and "eva-health-staging" as INACTIVE, which means paused. Whether any client currently uses the app is unknown.
5. The UK Biobank access email and the Toledo Study for Healthy Aging email exist only as Gmail drafts dated 29 Oct 2026; they were not sent.
6. On the branch, 1,307 tests pass and the typecheck is clean. Known open bugs that predate the creatine work: a lab can stay stuck in "processing" if the AI summary step hangs past the platform limit, audit item F37; retrying a failed upload confirmation stores that lab's values twice.
7. Recent CEO decisions: 29 Oct, go with version 3. 30 Oct, creatinine is the kidney filtration marker used, cystatin C and a laboratory's eGFR never enter the biological age, urea stays; a creatine warning; adjustment by declared daily dose, creatinine divided by 1 + 0.13 x min(g/day, 3)/3. The CEO wants the average Spaniard to read their own age; version 3 estimates read about 0.9 years young for men and 0.8 for women on a population-weighted transported sample, see docs/biomarker-evidence/longevity/CALIBRATION-AND-CREATINE.md.
8. A June 2026 pre-launch audit in docs/audit/ said NO-GO for public launch with 12 P0 blockers, mostly regulatory and trust: see 00-executive-summary.md, FINDINGS.md, REMEDIATION-PLAN.md, PRODUCTION-READINESS-REPORT.md, COUNSEL-INPUTS-CHECKLIST.md, PM-DECISION-LOG.md and drafts/. Legal documents are drafts for counsel.

Rules:
- Read-only. Do not edit, create, commit or push anything in the repo. Do not run SQL or any database tool, do not query patient data, do not call any /api endpoint, do not send email or messages, do not create drafts. You may write scratch files only under ${SCRATCH}/.
- You may use web search and fetch to verify external facts such as regulation, guidance, papers and the live public site. Cite the URL.
- Every finding needs evidence: a repo path with line number, saying whether it is main or the branch; a URL; or a command and its output. Mark confidence "verified" only if you checked it yourself in this task.
- Separate what is live today, affecting real people or the public now, from what affects a future release.
- Be concrete: who does what next, how long it takes, what it unblocks. Owners: CEO, licensed physician, counsel, engineering, Echevarne, CMO. CMO means the AI orchestrator acting as CMO, who cannot sign, send or approve anything.
- No generic advice. Fewer, sharper findings. At most 12 findings.`

const FINDINGS = {
  type: 'object',
  properties: {
    lens: { type: 'string' },
    summary: { type: 'string', description: 'Plain-language state of play for this lens, 3 to 6 sentences' },
    strengths: { type: 'array', items: { type: 'string' }, description: 'What is solid and should be kept' },
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string', description: 'Short id such as SCI-1' },
          title: { type: 'string' },
          severity: { type: 'string', enum: ['critical', 'high', 'medium', 'low'] },
          live_exposure: { type: 'boolean', description: 'true if it affects real people or the public today' },
          status_now: { type: 'string', description: 'What is true today, with specifics' },
          why_it_matters: { type: 'string' },
          recommendation: { type: 'string', description: 'The concrete next step' },
          owner: { type: 'string' },
          effort: { type: 'string' },
          when: { type: 'string', enum: ['this week', 'next 2-6 weeks', 'next 1-3 months', '3-12 months'] },
          depends_on: { type: 'string' },
          needs_ceo_decision: { type: 'boolean' },
          evidence: { type: 'array', items: { type: 'string' } },
          confidence: { type: 'string', enum: ['verified', 'likely', 'uncertain'] },
        },
        required: ['id', 'title', 'severity', 'live_exposure', 'status_now', 'why_it_matters', 'recommendation', 'owner', 'when', 'needs_ceo_decision', 'evidence', 'confidence'],
      },
    },
    open_questions_for_ceo: { type: 'array', items: { type: 'string' } },
  },
  required: ['lens', 'summary', 'strengths', 'findings', 'open_questions_for_ceo'],
}

const LENSES = [
  { key: 'science', label: 'lens:science', prompt: `Your lens: scientific validity of every biological age figure EVA shows or plans to show.
Cover:
1. What is live on main: the KDM v2.2 Reference figure on the lab page and the Comprehensive rolling-average figure on the dashboard. Their validation status, repeat-draw noise, known biases such as cystatin C, laboratory eGFR, creatine, Spanish normal values, and the fact that the dashboard figure's marker set was never tested against mortality. Use ml/biological-age/REPORT-baselines.md, ml/biological-age/PROPOSAL.md, docs/biomarker-evidence/longevity/CALIBRATION-AND-CREATINE.md, CYSTATIN-C-FIX-OPTIONS.md, BA-INPUT-FIXES.md, KDM-DIRECTION.md, METHODOLOGY-CLAIMS-FOR-COUNSEL.md, and the code under src/lib/biomarkers/ on main compared with the branch.
2. Version 3: what its charter tests show and do not show. It is internal NHANES evidence; check whether the sealed test was reused, and what is unknown about transport to Spain, to Echevarne's methods and to capillary samples. Use MODEL-CARD.md, CHARTER.md, REPORT.md, ATTEMPTS.md and verifier/.
3. The creatine rule's assumptions and error, PHYSICIAN-SIGNOFF.md item 12.
4. The Spanish centring question: is shifting version 3's intercepts now justified, or should the rule be pre-registered and applied to real Spanish data? What do DECISION.md sections 5.2 and 5.5 say?
Give the CMO a clear view: which figure, if any, is fit to show a client today, with what labels, and what evidence is still missing, in order.` },
  { key: 'safety', label: 'lens:safety', prompt: `Your lens: patient safety and what clients are told.
Look at the client-facing surfaces on main, which is live, and on the branch: dashboard, lab result page, biological age explanation, methodology pages under src/app/[locale]/, results-ready emails, the AI summary pipeline and its prompts and guardrails (search src/lib for generateSummary and the prompt files), laboratory notes and observations, and the context and supplement form.
Questions:
- Can a client be falsely reassured or alarmed?
- Is any change over time shown that is within noise? KDM v2.2 repeat-draw noise is about 3.7 to 4.3 years, one SD; version 3's reliable change is about 4.3 years.
- Are clinically significant values flagged and escalated, for example very high potassium, creatinine or glucose, haemoglobin abnormalities, CRP above 10? Who contacts the client, and how fast? What does Echevarne do with critical values?
- Does the creatine adjustment ever change the displayed creatinine or its flag? It must not.
- Pregnancy, chronic kidney disease, age limits, missing sex.
- What happens to a client whose result is stuck in processing, F37, or whose values are duplicated by a confirmation retry?
Check docs/audit/06-ai-governance-safety.md and docs/audit/FINDINGS.md for patient-safety items still open. Rank by potential harm.` },
  { key: 'regulatory', label: 'lens:regulatory', prompt: `Your lens: regulatory and legal exposure, as a CMO would flag it for counsel.
Cover:
1. The live public claims on evahealth.es. Fetch https://evahealth.es/es/metodologia, https://evahealth.es/es/metodologia/completa and the home page. Compare with docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md, docs/audit/04-health-claims-marketing.md and docs/audit/drafts/marketing-claims-rewrite.md. Say whether wording such as "predicción de mortalidad" makes a medical-purpose claim relevant to EU MDR qualification under Rule 11 and MDCG 2019-11 rev.1, and to Spanish health-advertising rules such as Real Decreto 1907/1996.
2. Medical-device software qualification of the biological age and of version 3: docs/audit/03-medical-device-regulatory.md, docs/audit/drafts/mdsw-classification-memo.md and docs/audit/drafts/mdsw-memo-addendum-ba-v3.md. Check the EU AI Act timeline for health AI on the web, including any 2025 or 2026 changes.
3. GDPR for special-category data: the DPIA draft, international transfers such as the AI provider and any US Supabase projects, and research uses such as UK Biobank and TSHA. What agreements and ethics steps are needed?
4. The state of counsel engagement per docs/audit/COUNSEL-INPUTS-CHECKLIST.md and PRODUCTION-READINESS-REPORT.md section 3.
Say which items are live exposure today and which gate a future release, and give the exact questions counsel must answer.` },
  { key: 'release', label: 'lens:release', prompt: `Your lens: how the branch's work reaches clients safely.
Cover:
1. The branch is 648 commits ahead of main with no PR. What is in it? Group the commits with git log origin/main..HEAD --format='%cs %s' and git diff --stat origin/main...HEAD. Separate client-facing behaviour from docs and research artefacts. Propose a split into reviewable pull requests in a safe order, starting with the smallest possible PR that removes the unsupported public claims.
2. Database migrations on the branch that are not on main, under supabase/migrations: their order, what they change, and whether they are reversible.
3. Staging: both Supabase projects are paused. What has to happen before a staging shadow period?
4. Recalculation and backfill: what changes for existing clients' stored figures when the branch ships, such as the KDM_v2.2_ReferenceBA_r2 tag, dashboard changes from removing eGFR, and the creatine adjustment. How past results are labelled, PROPOSAL.md condition 6, and what communication is needed.
5. Open bugs F37 and confirmation-retry duplicates: read the code paths, src/app/api/lab-results/[id]/context/route.ts, src/lib/lab-results/auto-resolve.ts and the confirm route, and say whether they must be fixed before relaunch.
6. Monitoring and alerting for model drift and pipeline failures.
Do not run the app against any real database. You may run read-only git commands and the test suite.` },
  { key: 'validation', label: 'lens:validation', prompt: `Your lens: the evidence program version 3 needs, and its critical path.
Cover:
1. UK Biobank: find the drafted application in the repo and note that the Gmail draft is unsent. Realistic timeline, fees, who must sign as applicant institution, and what to pre-register first. Verify fees and timelines on the UK Biobank site and cite them.
2. TSHA Toledo and the Spanish datasets in DECISION.md section 5.3: Di@bet.es, ENRICA, AEGIS, CORDELIA. What each gives, the National Death Index access restriction, and the need for a public research partner.
3. PROPOSAL.md conditions 1 to 7. For each: what has been done (search docs/biomarker-evidence/interlab, docs/biomarker-evidence/capillary, ml/biological-age/integration and docs/audit/2026-09-21-auditoria-final-integracion-echevarne.md), what is missing, who owns it, how long. Especially condition 1, Echevarne method alignment for albumin by bromocresol green or purple, enzymatic or Jaffe creatinine, ALP, GGT, BUN and hs-CRP; and condition 2, the Tasso capillary against venous study.
4. The Spanish centring of version 3: how and when real Spanish data could settle it; the sample sizes are 340 men and 410 women for plus or minus 0.5 years.
Produce the critical path: the ordered steps from today to the first client seeing a version 3 number, with the earliest realistic date for each and what can run in parallel. Mark which dates are estimates.` },
  { key: 'governance', label: 'lens:governance', prompt: `Your lens: clinical governance, as the first thing a new medical director would set up.
Cover:
1. Who is clinically accountable today. Read the sign-off sheets such as ml/biological-age/PHYSICIAN-SIGNOFF.md and any other countersignature requirement. Search the repo for a named licensed physician: medical director, director médico, colegiado, facultativo, responsible physician. What does Spanish law require of a company offering laboratory tests and medical interpretation to consumers, such as authorisation as a centro sanitario, a responsible physician, and Echevarne's role? Verify on the web and cite.
2. Decision records and change control for models: versions, tags such as KDM_v2.2_ReferenceBA_r2, the bio_age_method migration, and who approves a change. Is the process used so far, an AI acting as CMO with review workflows, adequate without a human clinical owner?
3. Incident and complaint handling, adverse-event and safety reporting, post-market surveillance if the software is a medical device, and a monitoring plan for the figures, for example the monthly mean of biological age minus age by sex and age band, and the share of results withheld and why.
4. The AI summary: who reviews its prompts and outputs clinically?
5. What the CEO must decide, and what can be delegated.
Recommend a minimal governance setup EVA can stand up in 2 to 4 weeks, with roles to hire or contract.` },
]

const CHECK = {
  type: 'object',
  properties: {
    checks: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          finding_id: { type: 'string' },
          claim: { type: 'string' },
          verdict: { type: 'string', enum: ['confirmed', 'partly', 'refuted', 'unverifiable'] },
          correction: { type: 'string', description: 'What is actually true, if partly or refuted' },
          evidence: { type: 'array', items: { type: 'string' } },
        },
        required: ['finding_id', 'claim', 'verdict', 'evidence'],
      },
    },
    orchestrator_facts_wrong: { type: 'array', items: { type: 'string' }, description: 'Any of the orchestrator facts 1 to 8 that turned out wrong' },
  },
  required: ['checks', 'orchestrator_facts_wrong'],
}

const CRITIC = {
  type: 'object',
  properties: {
    missing: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          why: { type: 'string' },
          severity: { type: 'string', enum: ['critical', 'high', 'medium', 'low'] },
          recommendation: { type: 'string' },
          evidence: { type: 'array', items: { type: 'string' } },
        },
        required: ['title', 'why', 'severity', 'recommendation', 'evidence'],
      },
    },
    priority_challenges: { type: 'array', items: { type: 'string' } },
    disagreements: { type: 'array', items: { type: 'string' }, description: 'Where reviewers disagree, and which side is right' },
    top_five: { type: 'array', items: { type: 'string' }, description: 'The five actions you would insist on first, in order' },
  },
  required: ['missing', 'priority_challenges', 'disagreements', 'top_five'],
}

phase('Assess')
const lensResults = await parallel(LENSES.map(l => () =>
  agent(`${CONTEXT}\n\n${l.prompt}`, { label: l.label, phase: 'Assess', schema: FINDINGS })
    .then(r => (r ? { ...r, lens: l.key } : null))
))
const lenses = lensResults.filter(Boolean)
const dropped = LENSES.filter((l, i) => !lensResults[i]).map(l => l.key)
if (dropped.length) log(`Lenses with no result: ${dropped.join(', ')}`)
const all = lenses.flatMap(r => r.findings.map(f => ({ ...f, lens: r.lens })))
log(`${all.length} findings from ${lenses.length} lenses`)

phase('Challenge')
const toCheck = all.filter(f => f.severity === 'critical' || f.severity === 'high' || f.live_exposure)
log(`${toCheck.length} findings sent to the fact-check`)
const [checks, critic] = await parallel([
  () => agent(`${CONTEXT}\n\nYou are an adversarial fact-checker. Below are findings from six reviewers. For every finding listed, check its key factual claims yourself against the repo (main via git show origin/main:<path>; the branch in the working tree), the live site, or the cited source. Try to refute each one. Use "refuted" or "partly" when the evidence does not support the claim as written, and give the correction. Check every number a finding quotes. Also report any of the orchestrator's facts 1 to 8 that you find wrong.\n\nFINDINGS TO CHECK:\n${JSON.stringify(toCheck, null, 1)}`,
    { label: 'fact-check', phase: 'Challenge', schema: CHECK }),
  () => agent(`${CONTEXT}\n\nYou are a skeptical senior medical director joining EVA next week. You are reading these six reviews before your first board meeting.\n1. What is missing that you would expect in a CMO reassessment of this program? Confirm each gap in the repo or on the web before you report it.\n2. Challenge the priorities: what is ranked too high or too low, and why.\n3. Where do the reviewers disagree with each other, and which side is right?\n4. The five actions you would insist on first, in order.\nBe specific and cite evidence.\n\nREVIEWS:\n${JSON.stringify(lenses, null, 1)}`,
    { label: 'critic', phase: 'Challenge', schema: CRITIC }),
])

phase('Synthesize')
const memo = await agent(`${CONTEXT}\n\nYou write the final CMO reassessment memo for the CEO of EVA Health, from six reviews, an adversarial fact-check of their key claims, and a skeptical medical director's critique, all below.

Rules for using the inputs:
- Drop any claim the fact-check marked refuted. Use the correction for any marked partly. Do not use a claim marked unverifiable as a fact; say it is unconfirmed if you need it.
- Use only numbers, dates, fees and timelines that a reviewer or the fact-check verified with a source. Mark planning estimates as estimates.
- Where the critic found something missing and gave evidence, include it.
- Resolve disagreements; say which way you decided and why.

Write the memo in Markdown, in English, for a CEO who is not a clinician:
- Title, then: Date 3 November 2026. For: the CEO. Prepared by: the orchestrator, an AI acting as CMO; a licensed physician must review and countersign the clinical decisions in it.
- 1. Bottom line: 5 to 8 short sentences. Lead with what to do this week.
- 2. Where we stand: a table with columns Area, Live today, On the branch, Gap.
- 3. What I would do, in order: groups This week, Next 2 to 6 weeks, Next 1 to 3 months, 3 to 12 months. Each step: what, owner, effort, what it unblocks, evidence pointer. Number the steps continuously.
- 4. Decisions for the CEO: numbered, each with my recommendation and the reason in one or two sentences.
- 5. Risk register: a table with columns Risk, Live or future, Severity, Mitigation, Owner.
- 6. What I would not do.
- 7. Evidence: the repo files with line numbers and the URLs relied on.
Style: plain English, short sentences, lead with outcomes, numbers in tables. No em dashes, no arrows, avoid parentheses. About 2,000 to 2,800 words. Do not invent names of people, firms or prices.

Write the memo to ${SCRATCH}/CMO-REASSESSMENT.md and also return the full Markdown as your final answer.

REVIEWS:
${JSON.stringify(lenses, null, 1)}

FACT-CHECK:
${JSON.stringify(checks, null, 1)}

CRITIC:
${JSON.stringify(critic, null, 1)}`, { label: 'memo', phase: 'Synthesize' })

return { lenses, checks, critic, memo, dropped }
