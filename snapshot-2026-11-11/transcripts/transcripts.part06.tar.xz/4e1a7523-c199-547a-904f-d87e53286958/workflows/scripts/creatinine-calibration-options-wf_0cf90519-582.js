export const meta = {
  name: 'creatinine-calibration-options',
  description: 'Check whether average values give back the age, and weigh creatine and cystatin C options with creatinine as the base',
  phases: [
    { title: 'Gather', detail: 'other models and evidence; Spanish averages; NHANES audit' },
    { title: 'Analyse', detail: 'calibration fix; creatine and cystatin C options' },
    { title: 'Verify', detail: 'adversarial check of each analysis' },
    { title: 'Synthesize', detail: 'answer for the CEO; critic; revision' },
  ],
}

const SP = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/cal'
const PY = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/venv/bin/python'

const CTX = `You are working on EVA Health's blood-test biological age, in the repository at /home/user/eva-health (a Next.js app; read AGENTS.md before relying on framework knowledge). EVA is a Spanish preventive-health company. Its CEO asked:

"Most tests will almost never include cystatin C in Spain, as it is not that common, so relying on it is not a good idea. We need creatinine as the base, but have a way to take cystatin C into account when we have the value, in case the person is taking creatine; or a way to adjust creatinine in the biological age for people taking creatine; or at least warn them that if they supplement with creatine the model gives them a higher reading. See how other models manage this and weigh the options to move forward. What we are trying to give is the most accurate age according to the average population. If a value that we ourselves call average makes the age read higher, we did not train the model correctly. Check that what we consider an average value for an age actually gives back that age."

THE TWO MODELS
- Deployed today: KDM v2.2.2, a Klemera-Doubal estimator (src/lib/biomarkers/biological-age-kdm.ts). Two versions. Reference: 14 base markers (albumin, creatinine, BUN, uric acid, ALP, GGT, total cholesterol, HDL, triglycerides, hs-CRP, ferritin, vitamin D, TSH, fructosamine), shown on the lab-result page. Comprehensive: up to 81 trained markers, shown on the dashboard as a rolling average of recent labs. Per marker the model assumes x = q + k*age + noise with spread s; BA_E = sum((x-q)*k/s^2) / sum((k/s)^2); the final BA shrinks BA_E toward chronological age with s_CA (about 24 years Reference, 14 Comprehensive). Log-scale markers include triglycerides, hs-CRP, GGT, ferritin, TSH and fructosamine. Parameters: src/lib/biomarkers/data/marker_library_v2_2.json (original fits), src/lib/biomarkers/data/path_b_overrides.json (May 2026 refit of k, q and s on unwinsorised NHANES 1999-2018), and a 'Spanish recalibration' that replaces q for 18 markers. resolveKdmParams() takes k and s from Path B and keeps q_spain when one exists. Fructosamine is derived from HbA1c (19.97*HbA1c - 39.4); a measured fructosamine is set aside by default.
- The Spanish recalibration rule (scripts/fix_spanish_recalibration_bug.py, scripts/fix_log_scale_q_spain.py; per-marker spanish_recalibration blocks in the library): slope = mean_spain / mean_NHANES; linear markers q_spain = slope * q_NHANES; log markers q_spain = q_NHANES + ln(slope). mean_NHANES appears to be an all-ages NHANES mean and q_NHANES the pre-Path-B intercept. Sources: PESA (Fernandez-Friera 2015; bank employees aged 40-54, Madrid); a 400-person PESA subsample in the supplement of Mastrangelo et al. 2025 (mean age 56, 78% men, 75% with atherosclerosis; creatinine, GGT and hs-CRP are medians there; both sexes pooled, so the per-sex values used are not in the source); Diaz-Lopez 2021 (vitamin D, at-risk primary-care users); Alonso 2025 (TSH, median); Cepeda 2010 Rev Esp Cardiol, PMID 20334807 (cystatin C; the library mis-cites its authors).
- Coming: version 3 (src/lib/biomarkers/biological-age-v3.ts, computeBiologicalAgeV3; frozen artifact ml/biological-age/model-v3.json), a PhenoAge-type Gompertz model re-estimated on NHANES with albumin, ALP, hs-CRP, creatinine, BUN and GGT, plus HbA1c when available. It has no creatine handling and ignores cystatin C. The CEO chose it to replace KDM once its launch conditions are met (ml/biological-age/PROPOSAL.md). Documents: ml/biological-age/MODEL-CARD.md, REPORT.md, REPORT-baselines.md, sensitivity/WEIGHTED.md.

KNOWN FACTS FROM EARLIER RESEARCH (verify before relying on them; details in docs/biomarker-evidence/longevity/CYSTATIN-C-FIX-OPTIONS.md)
- EVA's own laboratory (Echevarne) does not deliver cystatin C; it reaches the model only from uploaded results. Today, when cystatin C is present the code deletes creatinine, and the Reference version is left with no kidney marker.
- EVA's creatine offset is its own estimate: min(0.05 + 0.025*g/day, 0.40) mg/dL subtracted from creatinine (src/lib/biomarkers/supplements.ts), applied only without cystatin C; doses written '5 gramos', '5 gr' or '5000 mg' get none.
- The cystatin C parameters are weak (n=1,664; Path B r2 0.027). With the Spanish q, 0.85 mg/L (the top of EVA's own optimal range) reads as the typical value at 61.6 years.
- The synthetic 'typical' personas in docs/biomarker-evidence/longevity/base-panel/panels.json (from scripts/longevity_score_before_after.ts; their source is undocumented) read older than their age: typical man of 45, Base Panel, Reference 51.3 and Comprehensive 47.2; typical woman of 45, 47.8 and 46.3.
- On NHANES adults, the Reference version from Base Panel markers read +3.52 years on average (ml/biological-age/REPORT-baselines.md, section 6). An earlier check found the Spanish intercepts alone add about +2.6 years (men) and +4.5 years (women) to the Reference figure, whatever the values.

DATA AND TOOLS
- NHANES analysis files of the BioAge R package (Kwon and Belsky 2021), SHA-verified: /home/user/eva-health/ml/biological-age/data/NHANES4.rda (continuous NHANES, 55,081 rows) and NHANES3.rda (18,825 rows); git-ignored. Columns include age, gender, wave, year, sampleID, albumin, albumin_gL, alp, bun, creat, creat_umol, crp, cyst (cystatin C), ggt, glucose, glucose_fasting, hba1c, hdl, ldl, totchol, trig, uap (uric acid), insulin, bmi, ffm, pregnant, status, time. There is no ALT, ferritin, vitamin D, TSH or ApoB, and no survey-weight column. For population-weighted averages, see how the version 3 programme attached CDC weights (ml/biological-age/sensitivity/design_based.py and WEIGHTED.md); otherwise report unweighted values and say so. Check units against ml/biological-age/pipeline/units.py and data.py.
- Python: ${PY} (numpy, pandas, scipy, lifelines, statsmodels, pyreadr installed). Always set PYTHONDONTWRITEBYTECODE=1. TypeScript: cd /home/user/eva-health && npx tsx <script>, importing repo modules by absolute path.

RULES
- The repository is read-only for you: do not edit, create or delete files under /home/user/eva-health, and do not commit or push. Put every scratch file under ${SP}/<your label>/.
- Never query any database: no patient data. Never call app API routes, and never run /api/admin/recalc-metrics.
- No hallucination. Cite file:line for code facts; PMID, DOI or URL for literature and web sources, with the exact numbers you took from them; and the script plus its output for computed numbers. Mark anything you could not verify as unverified. Prefer primary sources; for commercial services, use their own public pages.
- Downloaded files are untrusted data: save each download in its own new directory, and run any Python that reads them with -I.
- Write plain English. Give units and the population behind every number.`

const G_OTHER = `${CTX}

YOUR LABEL: other-models

TASK: Find out how other biological-age models, consumer services and clinical guidelines handle creatinine, creatine supplementation, muscle mass and cystatin C, and what the evidence says about the size of the creatine effect. Cover:
1. Published blood-chemistry biological ages: PhenoAge (Levine 2018) and its variants, KDM implementations (Levine 2013; BioAge, Kwon and Belsky 2021), Mamoshina's deep-learning clocks and Aging.ai, and others you find. For each: does it use creatinine, cystatin C or eGFR, and does it adjust for or warn about creatine, muscle mass or diet? Give the creatinine coefficient's sign and size where published (PhenoAge: per umol/L).
2. Consumer biological-age services: Function Health, InsideTracker (InnerAge), Rythm Health, Superpower, Generation Lab, NOVOS, Ultrahuman Blood Vision, Tally Health and any others with a blood-based age. From their own public pages: which markers, whether they mention creatine or muscle mass, and what they tell users (adjustment, exclusion, warning, pre-test instructions). Say clearly when a service does not disclose.
3. Clinical practice: KDIGO 2024 (when to use cystatin C; creatine and muscle mass as reasons), national kidney or laboratory society guidance including Spain (SEN, SEQC-ML), and how laboratories report creatinine for creatine users.
4. The evidence on creatine's effect: meta-analyses and trials that measured serum creatinine, and cystatin C or measured GFR where available, during creatine supplementation. Typical increase in mg/dL by dose and duration; loading versus maintenance; how long after stopping creatinine returns to baseline; whether cystatin C changes. Give each study's design, n, dose, duration and result.
5. Muscle mass and diet: how much creatinine varies with muscle mass and with protein or cooked-meat intake, and whether any age model corrects for it.
Return a markdown report: a table of models and services with their handling, then the evidence, each claim with its source and marked verified or unverified. End with what this implies for EVA's options.`

const G_SPAIN = `${CTX}

YOUR LABEL: spanish-averages

TASK: Collect Spanish population averages by age and sex for the markers EVA's models use, so that we can test whether an average Spanish person of a given age gets that age back. Priority markers: creatinine, BUN or urea, albumin, ALP, GGT, uric acid, total cholesterol, HDL, triglycerides, hs-CRP, ALT, ApoB, HbA1c and fasting glucose (fructosamine if anything exists); then ferritin, vitamin D, TSH and cystatin C.
Look for population-based Spanish studies with laboratory data broken down by age group and sex: for example ENRICA, Di@bet.es, EPIRCE (kidney), DARIOS, IBERICAN, the Aragon Workers' Health Study, the Hortega study, PESA, reference-interval studies of Spanish laboratory societies, and any national or regional health survey with blood tests. Use Europe PMC, PubMed, SciELO and open full texts (Revista Espanola de Cardiologia, Nefrologia, Medicina Clinica, Endocrinologia y Nutricion, Revista del Laboratorio Clinico, Advances in Laboratory Medicine).
For each value record: study, PMID or DOI, years of data collection, region, sampling (population-based or not), age group, sex, n, statistic (mean, median or geometric mean), value, unit, SD or IQR when given, and the assay when stated (creatinine: enzymatic or Jaffe, IDMS-traceable or not). Copy numbers exactly from tables and note the table number. Mark each row verified (you read the table) or unverified.
Also report the Spanish source values behind the current recalibration (PESA Table 1 for total cholesterol, HDL and triglycerides; the Mastrangelo supplement; Diaz-Lopez; Alonso; Cepeda 2010) with their age range and statistic.
Save the rows as JSON at ${SP}/spanish-averages/spanish_averages.json, one object per row, and return a markdown summary with the path. Flag the gaps: markers or ages with no Spanish data.`

const G_NHANES = `${CTX}

YOUR LABEL: nhanes-audit

TASK: Test, with real population data, whether EVA's models give back the age for a person with average values for that age, and find exactly why they do not when they do not.
1. Load NHANES4.rda and NHANES3.rda. Map the columns to EVA's markers and units as the pipeline does. Use survey weights for population averages if you can attach them reliably; otherwise use unweighted values and say so.
2. For each available marker, sex and age band (5-year bands from 20 to 84, and single ages where n allows): the mean, the median and, for log markers, the geometric mean. Use the continuous-NHANES waves the model was trained on (1999-2018) as the main set.
3. Compare with each KDM marker's model-expected value at those ages, under the parameters the code actually uses (resolveKdmParams: Path B k and s, q_spain where it exists) and under pure NHANES parameters (Path B q, no Spanish q). For log markers compare on the log scale: exp(q + k*age) against the geometric mean and the median. Report the gap per marker and age band, in marker units and in years, (observed - expected)/k.
4. Build average-for-age profiles from the NHANES medians, and separately from the means (geometric means for log markers), for each sex at ages 25, 35, 45, 55, 65 and 75: for the Base Panel markers available, and for the full set available. Compute the deployed Reference and Comprehensive BA (computeReferenceBA, computeComprehensiveBA) and the same with pure NHANES q. Apply the fructosamine rule (derived from HbA1c). For markers missing from NHANES (ferritin, vitamin D, TSH, ALT, ApoB), leave them out and say so. Report BA - age in tables.
5. Decompose each profile's BA - age into marker contributions, and attribute the total to causes: the Spanish q, Path B q versus the original q, the mean/median mismatch in the Spanish rule, log handling, and lack of fit (nonlinear change with age).
6. Calibration-in-the-large on individuals: for NHANES adults with the needed markers, the mean of BA - age by sex and age band, with the deployed parameters and with pure NHANES q.
7. Version 3: compute it for the same average-for-age profiles (read computeBiologicalAgeV3's input format in src/lib/biomarkers/biological-age-v3.ts) and report BA - age. Also give its sensitivity to creatinine, in years per 0.1 mg/dL, at ages 35, 45 and 55 by sex.
8. The typical personas in panels.json: compare their values with the NHANES medians at age 45 by sex, marker by marker, to show whether they are average.
Save scripts and outputs under ${SP}/nhanes-audit/ and return a markdown report with tables, script paths and findings.`

const VERDICT = {
  type: 'object',
  properties: {
    confirmed_claims: { type: 'array', items: { type: 'string' } },
    refuted_claims: { type: 'array', items: { type: 'string' } },
    corrections: { type: 'array', items: { type: 'string' } },
    caveats: { type: 'array', items: { type: 'string' } },
    independent_numbers_md: { type: 'string' },
    overall: { type: 'string', enum: ['sound', 'sound_with_corrections', 'unsound'] },
  },
  required: ['confirmed_claims', 'refuted_claims', 'corrections', 'caveats', 'overall'],
}

const CRITIC = {
  type: 'object',
  properties: {
    needs_revision: { type: 'boolean' },
    errors: { type: 'array', items: { type: 'string' } },
    gaps: { type: 'array', items: { type: 'string' } },
  },
  required: ['needs_revision', 'errors', 'gaps'],
}

phase('Gather')
const [other, spain, nhanes] = await parallel([
  () => agent(G_OTHER, { label: 'other-models', phase: 'Gather' }),
  () => agent(G_SPAIN, { label: 'spanish-averages', phase: 'Gather' }),
  () => agent(G_NHANES, { label: 'nhanes-audit', phase: 'Gather' }),
])
if (!other || !spain || !nhanes) log('Warning: a Gather agent returned nothing; later stages see a partial picture.')

const R_OTHER = `=== OTHER MODELS AND EVIDENCE REPORT ===\n${other || '(missing)'}`
const R_SPAIN = `=== SPANISH AVERAGES REPORT ===\n${spain || '(missing)'}`
const R_NHANES = `=== NHANES AUDIT REPORT ===\n${nhanes || '(missing)'}`

const ANALYSES = [
  {
    key: 'calibration',
    prompt: `${CTX}

YOUR LABEL: calibration

TASK: Answer the CEO's calibration question for the deployed model and for version 3: does a person with average values for their age get that age back, against the average Spanish population? If not, how should the model be fixed?
Beware of circularity. A Klemera-Doubal model returns exactly the age when every marker equals the model's own expected value q + k*age; that proves nothing. The test must use averages measured independently: the Spanish population values in the spanish-averages report (rows in ${SP}/spanish-averages/spanish_averages.json) and the NHANES values in the nhanes-audit report.
1. Spanish test: build average-for-age Spanish profiles at every age and sex the Spanish data allow. Fill markers without Spanish data from the NHANES medians, and say which. Compute the deployed Reference and Comprehensive BA and version 3. Report BA - age.
2. Diagnose each gap marker by marker: the recalibration rule (multiplicative intercept, an all-ages NHANES mean, means against medians, log handling), the Path B mix (q_spain derived from the pre-Path-B q but combined with Path B k), the sources (age, sex mix, health of the samples), and EVA's own documents.
3. Propose a corrected calibration rule and test it. For example: set each marker's Spanish intercept so that the model's expected value at the Spanish sample's mean age and sex equals the Spanish central value, on the model's own scale (linear, or log with geometric means or medians), on top of the deployed Path B k; use only values you can trace. Compute the corrected q for every recalibrated marker. Show that independent Spanish average profiles return their age within a stated tolerance, what happens at ages outside the Spanish samples, and the effect on the synthetic personas and on the NHANES average profiles. Test the corrected q with a scratch copy of the code, never by editing the repository.
4. Weigh the alternatives: no Spanish adjustment (NHANES q); one age- and sex-specific recentring of the final BA; waiting for version 3 with a Spanish recentring. For version 3, say whether average Spanish profiles return their age, and what a Spanish recentring would need (data, method).
5. Say what EVA currently calls average (the personas, the reference and optimal ranges in the seed data, the Spanish sources) and which of these should define 'average' for the CEO's test.
Save the corrected parameters as JSON and your scripts under ${SP}/calibration/. Return a markdown report with tables, script paths and a clear verdict.

${R_SPAIN}

${R_NHANES}`,
  },
  {
    key: 'creatine',
    prompt: `${CTX}

YOUR LABEL: creatine-options

TASK: Weigh the options for creatine users and for cystatin C, with creatinine as the base marker, for the deployed KDM model (both versions) and for version 3. Quantify at least:
C1. Warning only: tell declared creatine users that creatine raises creatinine and makes the age read older, with the size of the effect for them.
C2. An evidence-based creatinine adjustment by dose, replacing EVA's current min(0.05 + 0.025*g/day, 0.40) mg/dL with values from the trial evidence in the other-models report, applied in both models.
C3. Leave creatinine out for declared creatine users without cystatin C. KDM: treat it as missing, with the gate change this needs. Version 3: say what is possible, for example replacing creatinine with its age- and sex-expected value.
C4. When cystatin C is available and the person declares creatine (or always), replace creatinine with the creatinine value cystatin C implies: compute eGFR from cystatin C (CKD-EPI 2012 cystatin C equation; give coefficients and source), then invert the CKD-EPI 2021 creatinine equation at the person's age and sex. This keeps the model's creatinine parameters. Check the assumptions: IFCC-standardised cystatin C, and non-GFR causes of high cystatin C such as inflammation, thyroid dysfunction, steroids, obesity and smoking.
C5. Cystatin C as its own marker, today's dashboard approach, with properly calibrated parameters.
C6. Pre-test instruction: ask creatine users to declare the dose, or to pause creatine for a stated period before the draw, with the evidence on washout.
For each option: the residual error for a creatine user at 5 g/day and at 20 g/day loading against the same person not taking creatine, for men and women aged 30, 45 and 60, in years, for KDM Reference, KDM Comprehensive and version 3; its behaviour with and without cystatin C; failure modes (wrong unit, undeclared creatine, high muscle mass without creatine, inflammation raising cystatin C); the data and code it needs; the client message; and what a physician would need to sign. Use creatinine increases from the literature (state which), not EVA's own estimate. Say which options also handle high muscle mass without creatine. Start from realistic profiles: the NHANES average-for-age medians in the nhanes-audit report.
Save scripts and outputs under ${SP}/creatine-options/ and return a markdown report with tables and a ranked view.

${R_OTHER}

${R_NHANES}`,
  },
]

const VERIFY = {
  calibration: `YOUR LABEL: verify-calibration

TASK: Adversarially check the calibration report below. Re-run at least five of its numbers yourself, by a different code path where possible. Check for circularity (averages that are really model-expected values), unit errors, mix-ups between means, medians and geometric means, the corrected intercept formula (derive it yourself), whether the Spanish sources really are population averages for the stated ages and sexes, and whether the claimed tolerance holds at every tested age. Default to refuted for any claim you cannot confirm. Put your own numbers in independent_numbers_md.`,
  creatine: `YOUR LABEL: verify-creatine

TASK: Adversarially check the creatine-options report below. Open the cited sources and check the creatine effect sizes and washout claims. Recompute the CKD-EPI 2012 cystatin C and 2021 creatinine equations and the inversion. Re-run at least five residual errors yourself. Check the version 3 claims against src/lib/biomarkers/biological-age-v3.ts and ml/biological-age/model-v3.json, and the failure modes. Default to refuted for any claim you cannot confirm. Put your own numbers in independent_numbers_md.`,
}

phase('Analyse')
const analysed = await pipeline(
  ANALYSES,
  a => agent(a.prompt, { label: a.key, phase: 'Analyse' }),
  (res, a) => {
    if (!res) return { key: a.key, report: null, verdict: null }
    return agent(`${CTX}

${VERIFY[a.key]}

=== REPORT TO CHECK ===
${res}

${a.key === 'calibration' ? R_SPAIN + '\n\n' + R_NHANES : R_OTHER + '\n\n' + R_NHANES}`, { label: `verify:${a.key}`, phase: 'Verify', schema: VERDICT }).then(v => ({ key: a.key, report: res, verdict: v }))
  },
)

const done = analysed.filter(Boolean)
log(`Analyses: ${done.map(d => `${d.key}=${d.verdict ? d.verdict.overall : 'unverified'}`).join(', ')}`)

phase('Synthesize')
const byKey = k => done.find(d => d.key === k) || { report: '(missing)', verdict: null }
const cal = byKey('calibration')
const cre = byKey('creatine')
const EVIDENCE = `=== CALIBRATION REPORT ===
${cal.report}

=== CALIBRATION VERIFIER (JSON) ===
${JSON.stringify(cal.verdict, null, 1)}

=== CREATINE AND CYSTATIN C OPTIONS REPORT ===
${cre.report}

=== CREATINE VERIFIER (JSON) ===
${JSON.stringify(cre.verdict, null, 1)}

${R_OTHER}

${R_SPAIN}

${R_NHANES}`

const STYLE = 'Write in plain English for a CEO. Lead with the outcome. Short sentences. No em dashes, no parentheses in prose, no arrows. Put numbers in tables. At most three headings.'

let report = await agent(`${CTX}

YOUR LABEL: synthesize

TASK: Write the answer to the CEO's question. Use only facts the evidence supports; where a verifier refuted or corrected a claim, use the corrected version or drop it. ${STYLE}
Cover, in this order:
1. The calibration answer: does a person with average values for their age get that age back, in the deployed model and in version 3, against Spanish averages and NHANES averages? Why not, marker by marker in a table, and the recommended fix with its tested effect.
2. How other models and services handle creatinine, creatine and cystatin C: a short table.
3. The options for creatine users and for cystatin C, with creatinine as the base, weighed in a table: residual error, what it needs, risks, and the client message. Give a recommended path for the deployed model now and for version 3.
4. What needs the CEO's decision and the physician's signature, and what can be done right away without changing any client figure, such as the warning.
End with a short list of sources and the unverified points.

${EVIDENCE}`, { label: 'synthesize', phase: 'Synthesize' })

const crit = await agent(`${CTX}

YOUR LABEL: critic

TASK: Check this answer against the evidence. List factual errors (numbers that do not match the reports, claims a verifier refuted, citations that do not support the claim, circular calibration tests), gaps (an option not considered or wrongly dismissed, a risk or approval missing, the CEO's questions not fully answered) and style violations (${STYLE}). Set needs_revision to true if there is any factual error or important gap.

ANSWER:
${report}

${EVIDENCE}`, { label: 'critic', phase: 'Synthesize', schema: CRITIC })

if (crit && crit.needs_revision) {
  report = await agent(`${CTX}

YOUR LABEL: revise

TASK: Revise the answer to fix every error and gap below. Keep everything that is correct. ${STYLE} Return only the revised answer.

ERRORS: ${JSON.stringify(crit.errors)}
GAPS: ${JSON.stringify(crit.gaps)}

ANSWER:
${report}

${EVIDENCE}`, { label: 'revise', phase: 'Synthesize' })
}

return { report, critic: crit, verdicts: done.map(d => ({ key: d.key, verdict: d.verdict })) }
