export const meta = {
  name: 'eva-access-requests-and-rythm',
  description: 'UK Biobank application and email, Toledo Study email, Rythm Health comparison, and an independent review of the methodology-page fix',
  phases: [
    { title: 'Research', detail: 'UK Biobank process, Toledo Study contacts, Rythm biological age, methodology diff review' },
    { title: 'Write', detail: 'application pack and emails, Rythm comparison' },
    { title: 'Review', detail: 'lens reviewers and fact-checkers per deliverable' },
    { title: 'Revise', detail: 'final versions' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/access-work'

const CONTEXT = `
You work for EVA Health (written "Eva Health" or "EVA"), a Spanish preventive-health company. The CEO and co-founder is Juan Diego Lago; he signs every email. EVA's clients are adults in Spain; their blood is analysed by Echevarne, a Spanish laboratory, from a home Tasso capillary kit or a clinic draw. EVA's Base Panel is one serum tube with 13 tests: albumin, ALP, hs-CRP, creatinine, BUN (urea), uric acid, total cholesterol, HDL cholesterol, triglycerides, apolipoprotein B, ALT, GGT, fructosamine.

On 29 October 2026 the CEO decided to adopt EVA's biological age "version 3" and to seek external validation in UK Biobank and in Spanish data (the Toledo Study for Healthy Aging, TSHA). Version 3 is the PhenoAge method (Levine 2018: Gompertz proportional hazards on all-cause mortality, elastic net, conversion to years) re-estimated on US NHANES with six Base Panel tests: albumin, ALP, hs-CRP, creatinine, urea/BUN and GGT, plus an optional HbA1c tier. It was built under a charter pre-registered in git: training NHANES III 1988-1994, validation 1999-2006, sealed test 2007-2014, independent check 2015-2018. Sealed-test results: hazard ratio 1.52 per SD of acceleration, gain in C-statistic over age and sex 0.022, calibration within 0.74 years in every sex and age band. It is not published, not validated outside NHANES and not yet shown to clients.

Facts about EVA must come from these repository files (read only): /home/user/eva-health/ml/biological-age/REPORT.md, MODEL-CARD.md, PROPOSAL.md, CHARTER.md, sensitivity/WEIGHTED.md, addons/REPORT.md; /home/user/eva-health/docs/ukbiobank/APPLICATION-DRAFT.md; /home/user/eva-health/docs/biomarker-evidence/bioage-model-selection/DECISION.md and evidence.json; /home/user/eva-health/docs/market/rythm-health.md and rythm-health.json; /home/user/eva-health/docs/context/correspondence/ (earlier emails, for tone and signature).

RULES:
- Every external fact needs a source you opened in this task (URL, PMID or DOI). Never state a fact from memory. Say "not found" when you cannot find something.
- Never invent EVA staff, credentials, partnerships, funding, results or approvals. Do not mention artificial intelligence or any AI system. Do not describe anyone at EVA as a doctor or scientist unless a repository file says so.
- Do not commit EVA to money, legal terms or dates. Where an offer is a business choice for the CEO (for example paying for analyst time), write it and list it under decisions_for_ceo.
- Do not create or modify files in the repository; do not run git commands that change anything; do not send any email or message. Write working files only under ${SCRATCH}/ (each download in its own new empty folder; never run downloaded code).
- Web access: open web through a proxy. PubMed, PMC (pmc.ncbi.nlm.nih.gov), Europe PMC REST API, Crossref and NCBI E-utilities work. Some publisher pages answer 403 to scripts: use PMC or Europe PMC copies. You may load WebSearch and WebFetch with ToolSearch (query "select:WebSearch,WebFetch").
- Plain language, short sentences, no em dashes.
`

const RESEARCH_SCHEMA = {
  type: 'object',
  properties: {
    findings: { type: 'array', items: { type: 'object', properties: {
      topic: { type: 'string' }, fact: { type: 'string' }, source: { type: 'string' }, quote: { type: 'string' } },
      required: ['topic', 'fact', 'source'] } },
    summary: { type: 'string' },
    not_found: { type: 'array', items: { type: 'string' } },
  },
  required: ['findings', 'summary', 'not_found'],
}

const DOC_SCHEMA = {
  type: 'object',
  properties: {
    files: { type: 'array', items: { type: 'object', properties: {
      name: { type: 'string' }, content: { type: 'string' } }, required: ['name', 'content'] } },
    email_subject: { type: 'string' },
    email_to: { type: 'string' },
    email_cc: { type: 'string' },
    email_body: { type: 'string' },
    decisions_for_ceo: { type: 'array', items: { type: 'string' } },
    open_items: { type: 'array', items: { type: 'string' } },
    sources: { type: 'array', items: { type: 'string' } },
  },
  required: ['files', 'decisions_for_ceo', 'open_items', 'sources'],
}

const REVIEW_SCHEMA = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['ready', 'minor_changes', 'major_changes'] },
    issues: { type: 'array', items: { type: 'object', properties: {
      severity: { type: 'string', enum: ['blocking', 'important', 'minor'] }, where: { type: 'string' },
      problem: { type: 'string' }, fix: { type: 'string' } }, required: ['severity', 'where', 'problem', 'fix'] } },
    strengths: { type: 'array', items: { type: 'string' } },
    summary: { type: 'string' },
  },
  required: ['verdict', 'issues', 'summary'],
}

const j = (x, n) => { const s = JSON.stringify(x); return s.length > n ? s.slice(0, n) + '...[truncated]' : s }

// ─── Deliverable chains: research -> write -> review(s) -> revise, run as independent pipelines ───

const CHAINS = [
  {
    key: 'methodology-review',
    research: `
TASK: Independently review a change EVA just made to its public methodology pages. Run "git -C /home/user/eva-health show 029dbac" (read only) to see the diff.
Check every changed sentence, Spanish and English, against the evidence: /home/user/eva-health/docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md (the replacement text and its sources), /home/user/eva-health/src/lib/biomarkers/biological-age-kdm.ts, /home/user/eva-health/src/lib/biomarkers/data/path_b_overrides.json and marker_library_v2_2.json (the spanish_recalibration blocks), and /home/user/eva-health/docs/biomarker-evidence/bioage-model-selection/DECISION.md section 4.
Report: any changed claim that is wrong or unsupported; any remaining unsupported claim on the three pages (src/app/[locale]/(marketing)/metodologia/page.tsx, metodologia/completa/page.tsx, science/page.tsx); Spanish grammar and accents; whether the English and Spanish say the same thing; and whether the claims now risk breaking anything (for example a number shown elsewhere in the app that still says 1.29, 1.41, 5-fold, "11 of 14" or "validated in 18,570"). Search the whole src folder for leftovers. Put each issue in findings with topic "issue" or "ok".`,
    reviewOnly: true,
  },
  {
    key: 'ukbiobank',
    research: `
TASK: Establish, from UK Biobank's own current pages, exactly how a company like EVA applies for data access in 2026.
Find and quote: who may apply (commercial companies, non-UK companies, required researcher status of the applicant, institution registration), the registration and application steps (Access Management System), every section of the application form with its word limits, what makes an application acceptable ("health-related research in the public interest" and any other criteria), fees and tiers and what they cover, the Research Analysis Platform (whether data must be analysed there, and its compute costs), typical timelines, obligations (returning results, publication, confidentiality, no re-identification), and whether ethics approval is needed.
Also verify the exact UK Biobank field IDs and names for: the 13 Base Panel tests (albumin, alkaline phosphatase, C-reactive protein, creatinine, urea, urate, cholesterol, HDL cholesterol, triglycerides, apolipoprotein B, alanine aminotransferase, gamma glutamyltransferase; and note fructosamine is not measured), plus cystatin C, glycated haemoglobin, glucose, the blood count fields used by the original PhenoAge (lymphocyte percentage, mean corpuscular volume, red cell distribution width, white blood cell count), date and cause of death, age at recruitment, sex, date of attending the assessment centre, assessment centre, ethnic background, pregnancy, and the repeat-assessment instance. Use the UK Biobank showcase (biobank.ndph.ox.ac.uk/showcase) and ukbiobank.ac.uk.`,
    write: `
TASK: Write EVA's UK Biobank application pack and an email to UK Biobank's access team, using the research findings below and EVA's files (start from /home/user/eva-health/docs/ukbiobank/APPLICATION-DRAFT.md; keep its scientific content where still correct).
Return these files:
1. "APPLICATION.md": submission-ready text for every section of the current application form, in the order and within the word limits the research found, written to meet UK Biobank's approval criteria. Make the public-interest health purpose, the pre-registered analysis plan, the commitment to publish whatever the result, and the return of derived data explicit. Include the exact field list with IDs. Name the applicant as Juan Diego Lago, Eva Health, and mark with [TO CONFIRM] anything EVA must supply (legal entity, address, researcher credentials, any academic collaborator). If the rules need a researcher or academic collaborator EVA does not have, say so plainly and propose how to satisfy it (for example inviting the Toledo Study team or a Spanish university statistician as collaborator).
2. "STEPS.md": the step-by-step actions the CEO must take to register and submit, with the costs and timeline found.
Also return the email: to UK Biobank's access team at the address the research found, in English, from Juan Diego Lago. Its job: introduce EVA briefly, say that EVA is preparing an application, and ask only the questions that genuinely need an answer before submitting (from the research's open points). Warm, precise, short (under 220 words).`,
    reviews: [
      { lens: 'a UK Biobank Access Management Team officer who decides whether applications are approved, checking eligibility, the public-interest purpose, the field list, the analysis plan, the commitments, and anything that would cause a rejection or a request for revision' },
      { lens: 'a senior epidemiologist who has had many UK Biobank applications approved, checking scientific clarity, feasibility, the pre-registered validation design, overclaiming, and whether the email asks the right questions politely' },
    ],
  },
  {
    key: 'toledo',
    research: `
TASK: Find out exactly whom EVA should contact about the Toledo Study for Healthy Aging (Estudio Toledo de Envejecimiento Saludable, TSHA) and how to approach them.
Find and quote, from the papers (PMC full texts list corresponding authors and emails) and institutional pages: the principal investigators and the current corresponding authors of TSHA papers from 2020 to 2026, their institutions (for example Hospital Virgen del Valle, Complejo Hospitalario Universitario de Toledo, SESCAM, Hospital Universitario de Getafe, CIBERFES, Universidad de Castilla-La Mancha GENUD Toledo, Fundación para la Investigación Sanitaria de Castilla-La Mancha) and verified email addresses. Also find: how TSHA handles data requests ("available on reasonable request" or a committee), the ethics committee that approved it, its funders and past collaborations (including with companies, if any), the baseline blood tests (albumin, alkaline phosphatase, CRP, creatinine, urea, GGT) and when they were drawn, whether serum was stored, the mortality follow-up (National Death Index, years, number of deaths), and the team's research interests and recent papers, so the email can speak to them.
Rank the best first contact and say why.`,
    write: `
TASK: Write EVA's first email to the Toledo Study for Healthy Aging team, in Spanish, from Juan Diego Lago (CEO, Eva Health), using the research findings below and EVA's files.
Goal: a reply and a 30-minute call to explore a pre-registered external validation of EVA's frozen biological age model in TSHA's baseline data, with mortality follow-up.
Make it as likely as possible that a busy Spanish academic geriatrician replies:
- formal and warm ("Estimado Dr. ..."/"Estimada Dra. ...", usted); specific to their work (cite one or two of their papers by title or topic, verified);
- the scientific value for them first: the first validation of a blood-chemistry biological age in Spanish older adults, publishable, in line with the 2026 systematic review that calls for validating clocks in target populations (PMID 41678247);
- minimal burden and maximal control for them: the model is frozen and its code and analysis plan can be shared in advance; their team can run it inside their institution so individual data never leave; only aggregate results are shared; they lead the publication with co-authorship for their team; EVA's commercial interest is disclosed; the plan can go through their ethics committee and data-protection rules (RGPD);
- one clear ask (a short call) and two or three precise questions (whether baseline albumin, ALP, CRP, creatinine, urea and GGT are available for most participants; deaths recorded to date; the usual route for a collaboration);
- under 300 words. Subject line in Spanish.
Also return a file "ONE-PAGER.md" in Spanish: a one-page collaboration proposal they could read after the email (what EVA asks, what EVA offers, the analysis plan in five lines, timeline, data protection).
Address the email to the best first contact the research found, with the next most relevant people in CC if appropriate, using only verified addresses. List any offer that is a business commitment under decisions_for_ceo (for example paying analyst time or covering laboratory costs).`,
    reviews: [
      { lens: 'the TSHA principal investigator: a senior Spanish geriatrician and researcher who receives many requests, is wary of companies using public cohorts, and decides in thirty seconds whether to reply; judge tone, credibility, what is in it for the team, data protection, ethics, workload and anything that would make you ignore or refuse it' },
      { lens: 'a native Spanish editor and research-ethics adviser: grammar, accents, register, clarity, correct names and titles, GDPR and ethics framing, and any overpromise or claim that EVA cannot back' },
    ],
  },
  {
    key: 'rythm',
    research: `
TASK: Find out, as of today, what biological age model Rythm Health (rythmhealth.com, the US monthly at-home blood test using Tasso) uses, and everything that can be established about it.
Start from EVA's profile of 7 October 2026 (/home/user/eva-health/docs/market/rythm-health.md and rythm-health.json): it found the method unpublished and the Biological Age page empty.
Search again, in every way you can: Rythm's own pages now (biological age, Rythm Score, how it works, science, FAQ, blog, help centre, terms, privacy, clinical advisors), app store listings, press and interviews with the founders, podcasts, LinkedIn or X posts, job postings (data science or clinical roles naming PhenoAge, Levine, Klemera-Doubal or a vendor), patents (Google Patents, USPTO), FDA or CLIA records, user reports (Reddit, YouTube, Trustpilot, review blogs) describing what the biological age shows and what moves it, and any partnership with a biological age vendor. Record what changed since 7 October.
For each fact: source and quote. Then state plainly what is known, what is inferred (and from what), and what is unknown about Rythm's method, inputs, outputs, validation, cadence, and claims.`,
    write: `
TASK: Write a full comparison of Rythm Health's biological age with EVA's version 3, for EVA's CEO, as "COMPARISON.md".
Use the research findings below, EVA's Rythm profile (/home/user/eva-health/docs/market/rythm-health.md), and EVA's own files for version 3.
Cover, each with a table where numbers are involved:
1. The answer in five sentences: what Rythm uses (or that it is undisclosed), and how version 3 compares.
2. Method: what is known about Rythm's model against version 3's (training data, outcome, method, transparency, pre-registration, independent verification).
3. Inputs: Rythm's panel against EVA's Base Panel and against version 3's six inputs; which published models each panel could and could not run (for example the original PhenoAge needs glucose and a blood count; version 3 needs BUN).
4. Validation and performance: what each has published or verified, with version 3's numbers from its report (sealed test, calibration, repeat-draw noise, survey-weighted result) and Rythm's (none published, unless the research found some).
5. Sample, laboratory and noise: Tasso and lithium-heparin plasma against EVA's serum tube; monthly against quarterly cadence; what change is real against biological variation.
6. Claims, regulation and presentation: what each says publicly and what it can support.
7. Price and cadence.
8. Where Rythm is ahead, where EVA is ahead, and what EVA should do about it.
9. Unknowns and how EVA could learn them legitimately.
10. Sources.
Mark inference clearly and never present a guess about Rythm's method as fact.`,
    reviews: [
      { lens: 'an adversarial fact-checker: open every source cited for Rythm and every EVA file cited for version 3; flag any claim that is unsupported, misquoted, outdated or presented as fact when it is inference; check every number' },
    ],
  },
]

phase('Research')
const results = await pipeline(CHAINS,
  // Stage 1: research (or the review of the methodology diff)
  (c) => agent(CONTEXT + c.research, { label: 'research:' + c.key, phase: 'Research', schema: RESEARCH_SCHEMA })
    .then(r => ({ key: c.key, research: r })),
  // Stage 2: write
  (prev, c) => {
    if (c.reviewOnly || !prev || !prev.research) return prev
    return agent(CONTEXT + c.write + `
RESEARCH FINDINGS (JSON): ${j(prev.research, 90000)}`, { label: 'write:' + c.key, phase: 'Write', schema: DOC_SCHEMA })
      .then(d => ({ ...prev, draft: d }))
  },
  // Stage 3: reviews (each lens independently)
  (prev, c) => {
    if (c.reviewOnly || !prev || !prev.draft) return prev
    return parallel(c.reviews.map((rv, i) => () => agent(CONTEXT + `
TASK: Review this draft as ${rv.lens}.
Be specific and constructive: for each issue give where, the problem and the exact fix. Verify facts yourself where you can (open sources). Say what already works.
RESEARCH FINDINGS (JSON): ${j(prev.research, 50000)}
DRAFT (JSON): ${j(prev.draft, 90000)}`, { label: 'review:' + c.key + ':' + i, phase: 'Review', schema: REVIEW_SCHEMA })))
      .then(rs => ({ ...prev, reviews: rs.filter(Boolean) }))
  },
  // Stage 4: revise
  (prev, c) => {
    if (c.reviewOnly || !prev || !prev.draft) return prev
    return agent(CONTEXT + `
TASK: Produce the final version of this deliverable. Apply every blocking and important issue from the reviews below, and the minor ones that improve it. Where a reviewer is wrong, keep the original and say why in open_items. Keep the original task's requirements:
ORIGINAL TASK: ${c.write}
RESEARCH FINDINGS (JSON): ${j(prev.research, 50000)}
DRAFT (JSON): ${j(prev.draft, 90000)}
REVIEWS (JSON): ${j(prev.reviews, 40000)}`, { label: 'revise:' + c.key, phase: 'Revise', schema: DOC_SCHEMA })
      .then(f => ({ ...prev, final: f }))
  },
)

return { results: results.filter(Boolean) }
