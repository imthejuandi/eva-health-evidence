export const meta = {
  name: 'signoff-central-fixes-3',
  description: 'Third round for the runner: D5 reads only migration statements PostgreSQL runs as written, the G1 report wording; adversarial review',
  phases: [
    { title: 'Fix', detail: 'runner round 3' },
    { title: 'Verify', detail: 'adversarial review, one repair pass if rejected' },
  ],
}

const SCR = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/central3'
const C = 'docs/signoff/work/central'
const B01 = '--families f01_albumin_proteins,f03_kidney,f04_inflammation'
const FILES = ['scripts/signoff/checks/data.ts', 'scripts/signoff/checks/governance.ts', 'scripts/signoff/lib/seed.ts', 'src/lib/signoff/dsrt-core.test.ts', 'src/lib/signoff/dsrt-checks.test.ts']

const SHARED = [
  'You are a senior engineer fixing the acceptance-test runner of EVA\'s physician sign-off programme, in the repository at',
  '/home/user/eva-health on branch claude/wonderful-meitner-l4g7p5. All of it is AI work product a licensed physician reviews.',
  '',
  'Background. The acceptance test is docs/signoff/ACCEPTANCE-TEST.md (the DSRT); its runner is scripts/signoff/dsrt.ts with',
  'checks in scripts/signoff/checks/ (npm run dsrt -- ...; --work-dir takes a scratch copy of docs/signoff/work). Two earlier',
  'rounds of fixes to the runner\'s checks D5 (one source of truth), G1 (governance) and G2 (traceability) were reviewed',
  `adversarially: read ${C}/runner.json (the fix reports), ${C}/runner-verify.json (round 1) and ${C}/runner-verify-2.json (round 2).`,
  '',
  'Rules.',
  `- Write only these files: ${FILES.join(', ')}, and the report ${C}/runner.json (add a "round_3" section; keep the earlier sections). Scratch files only under ${SCR}/.`,
  '- Run no git command that changes the working tree or the index. Use git show <commit>:<path> for older versions.',
  '- Never query a database, apply a migration, send a message or call the app\'s API.',
  '- docs/signoff/ACCEPTANCE-TEST.md, LOOP-PROMPT.md, PLAN.md and thresholds.json never change.',
  '- The runner files are frozen by check G1; you may change them only to fix a defect, never to make a check pass more easily',
  '  than the specification text allows. Your report quotes the specification text for each change. The CEO approves later.',
  '- Every claim in your report comes from a command you ran or a line you read. Report test results truthfully.',
  '- Do not write AI model names into any file. Write your report before you reply.',
].join('\n')

const TASK = [
  SHARED,
  '',
  'Task (the required changes of runner-verify-2.json):',
  '1. D5 migration reader. parseForwardMigration takes values from statements PostgreSQL does not run when it applies the file:',
  '   an upsert inside a BEGIN ATOMIC function or procedure body, and an INSERT or DELETE inside a parenthesised rule action',
  '   (DO ALSO ( ... ; ... )). Make it take values only from a file in which every statement is one D5 reads or one that',
  '   cannot hold another statement: the INSERT and DELETE forms it reads, the ALTER of the sign-off columns, and BEGIN, START',
  '   TRANSACTION and COMMIT. List every other statement as unreadable, whether or not it names biomarker_references; at',
  '   minimum any CREATE [OR REPLACE] FUNCTION, PROCEDURE or RULE, and any semicolon cut inside parentheses or between BEGIN',
  '   ATOMIC and END. An unreadable file must make D5 fail for the rows it would explain, never pass. Add tests: an upsert in a',
  '   BEGIN ATOMIC function body, the same in a procedure body, and a DELETE in a parenthesised rule action; each must be',
  '   unreadable. The compiled migrations must stay readable: on docs/signoff/work/compiled/B01-r3 D5 still explains 33',
  '   differences and keeps the same 19 failure keys. Correct the doc comment at data.ts lines 849-851 and every claim in your',
  '   report that D5 reads exactly what PostgreSQL writes; say what it reads and what it refuses.',
  '2. G1 report wording, no code change: correct runner.json (round 2 lines about G1 being "blocked on the record, never pass"):',
  '   G1 is blocked only while no readable round-<n>-changes.json exists. Note that the orchestrator corrected',
  '   docs/signoff/workflows/README.md so the family-filtered batch records are no longer merged into round-<n>-changes.json.',
  '3. Confirm with a command each that the earlier required changes still hold: G2 compares bounds, unit, critical limits,',
  '   Reference_Basis and Reference_Source with the final row; D5 compares critical limits; retirement needs an explicit',
  '   record; added rows and diff-listed fields are compared with documented values; placeholder words count as missing.',
  `Run npx vitest run src/lib/signoff and npm run dsrt -- --round 3 ${B01} --seed-dir docs/signoff/work/compiled/B01-r3 --out ${SCR}/after3.json; report D3, D5, G1 and G2.`,
].join('\n')

const TEST_ROW = { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] }
const FIX_SCHEMA = {
  type: 'object',
  properties: {
    files_changed: { type: 'array', items: { type: 'string' } },
    fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, fix: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'fix', 'evidence'] } },
    tests: { type: 'array', items: TEST_ROW },
    notes: { type: 'string' },
  },
  required: ['files_changed', 'fixed', 'tests'],
}
const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    verdict: { type: 'string', enum: ['accept', 'reject'] },
    problems: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, line: { type: 'integer' }, kind: { type: 'string', enum: ['loosening', 'defect_not_fixed', 'regression', 'test_failure', 'ownership', 'other'] }, detail: { type: 'string' }, required_change: { type: 'string' } }, required: ['kind', 'detail', 'required_change'] } },
    tests: { type: 'array', items: TEST_ROW },
    notes: { type: 'string' },
  },
  required: ['verdict', 'problems', 'tests'],
}

const verifyPrompt = (fix, n) => [
  SHARED.replace(/- Write only these files:[^\n]*\n/, `- Write only ${C}/runner-verify-3${n > 1 ? 'b' : ''}.json and scratch files.\n`),
  '',
  'You did not write this change. Review the runner\'s round 3 before the CEO is asked to approve the whole runner change.',
  `The fix agent's task was:\n---\n${TASK.slice(SHARED.length)}\n---`,
  `Its result: ${JSON.stringify(fix || {}, null, 1).slice(0, 5000)}`,
  `Diffs: git diff 574a00a -- ${FILES.join(' ')} (this round), and git diff 2cec485 -- the same files (the whole change since round 0).`,
  '',
  'Try to show, and default to "reject" when you cannot confirm the opposite: a loosening against the specification text of D5,',
  'G1 or G2 (build the case and run it); a required change of runner-verify.json or runner-verify-2.json not met; a regression',
  '(npx vitest run src/lib/signoff, and the DSRT on docs/signoff/work/compiled/B01-r3); changes outside the listed files.',
  'Minor style points are not problems. A problem is something that would make the CEO wrong to approve the whole runner change.',
  `Write your verdict to ${C}/runner-verify-3${n > 1 ? 'b' : ''}.json and reply with the structured result.`,
].join('\n')

phase('Fix')
const fix = await agent(TASK, { label: 'fix runner r3', phase: 'Fix', schema: FIX_SCHEMA, effort: 'max' })
if (!fix) return { verdict: 'no_result' }
phase('Verify')
const v = await agent(verifyPrompt(fix, 1), { label: 'verify runner r3', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max' })
if (!v) return { verdict: 'unverified', fix }
if (v.verdict === 'accept') return { verdict: 'accept', fix, verify: v }
log(`verify runner r3: rejected with ${v.problems.length} problems; one repair pass`)
const fix2 = await agent(`${TASK}\n\nThe reviewer rejected this round. Its findings, verbatim:\n${JSON.stringify(v.problems, null, 1)}\n\nAddress every required change, or show with evidence why it is wrong. Update the report (add "round_3_repair") and reply with the structured result.`, { label: 'repair runner r3', phase: 'Verify', schema: FIX_SCHEMA, effort: 'max' })
if (!fix2) return { verdict: 'rejected_no_repair', fix, verify: v }
const v2 = await agent(verifyPrompt(fix2, 2), { label: 're-verify runner r3', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max' })
return { verdict: v2 ? v2.verdict : 'unverified', fix: fix2, first_verify: v, verify: v2 }
