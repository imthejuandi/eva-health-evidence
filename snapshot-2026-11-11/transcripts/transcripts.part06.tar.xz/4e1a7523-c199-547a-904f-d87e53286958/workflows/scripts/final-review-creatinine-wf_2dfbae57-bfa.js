export const meta = {
  name: 'final-review-creatinine',
  description: 'Five-lens review of the creatinine and creatine changes, each finding verified by two skeptics',
  phases: [
    { title: 'Find', detail: 'five independent lenses over 82fd5cc..a9310cc' },
    { title: 'Verify', detail: 'reproduce and design-intent skeptics per finding' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5'

const BRIEF = `Repository: /home/user/eva-health (Next.js + Supabase health app; read AGENTS.md first, its Next.js differs from what you know).
Range under review: \`git diff 82fd5cc..a9310cc\` (four commits: 6c3d251, cb017a5, 54ead22, a9310cc). Read \`git log 82fd5cc..a9310cc\` for what each claims.

What the change intends:
- Of the kidney filtration markers, only creatinine enters EVA's biological age (KDM v2.2 Reference figure on the lab page, KDM Comprehensive rolling average on the dashboard, and version 3, a shadow-only PhenoAge-type model). Cystatin C and a laboratory eGFR never enter. Creatinine is mandatory.
- Creatinine outside 0.2-15 mg/dL (measured value) gives no biological age (src/lib/biomarkers/creatinine-plausibility.ts). The dashboard checks each lab's measured value before averaging.
- A declared creatine dose divides creatinine by 1 + 0.13 x min(g/day, 3)/3 (src/lib/biomarkers/supplements.ts). The 13% ratio, the 3 g cap and the proportional part below 3 g are EVA's stated assumptions. The free-text dose is read by readCreatineDose; a dose it cannot read confidently returns null, and the context form (src/components/dashboard/PatientContextGate.tsx) then shows "No podemos leer esta dosis".
- Each lab is read under one patient context (src/lib/patient-context/lab-context.ts): the version recorded on the lab, else the client's latest version created on or before the lab's created_at. Reads throw on database errors.
- Labs from EVA's own laboratory arrive as pending_context and are processed on arrival; when the client confirms the context (src/app/api/lab-results/[id]/context/route.ts) or the 72-hour cron resolves it (src/lib/lab-results/auto-resolve.ts), recomputeLabMetrics reruns the figures after the lab is ready. Every route that marks a lab ready refreshes profiles.current_ba (the dashboard cache), which reads only ready labs.
- Client copy: dashboard-client.tsx, labs-client.tsx (the creatine note only under bio_age_method "KDM_v2.2_ReferenceBA_r2"), PatientContextGate.tsx; methodology pages src/app/[locale]/(marketing)/metodologia/page.tsx and completa/page.tsx; documents ml/biological-age/PHYSICIAN-SIGNOFF.md item 12, ml/biological-age/PROPOSAL.md, docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md, CALIBRATION-AND-CREATINE.md and CYSTATIN-C-FIX-OPTIONS.md headers.

Deliberate decisions, not defects unless you can show real harm: ambiguous doses (two amounts, conflicting frequencies, slashes, per-kg) return null so the form asks; KDM-EXPLAIN-PANELS.md is a historical snapshot; the pages say earlier figures follow earlier rules "mientras no se recalculen" without a date; cached dashboard figures are not recomputed until the CEO approves a backfill at deploy; nothing is deployed yet; version 3 is shadow-only; the stored lab-page figures are not recomputed in bulk.

Already found and fixed by two earlier reviews (do not re-report unless the fix is wrong): context recompute after confirmation, dashboard refresh after ready, per-lab context rule, read errors, parser forms (ranges, products, servings, separators, frequencies), plausibility in both models and per lab on the dashboard, wiring tests, copy hedging and citations.

Rules: no calls to any database or external service except reading public PubMed/Europe PMC abstracts if your lens needs sources; no patient data; never modify files under /home/user/eva-health. Work in your own scratch folder (given below); to experiment on code, copy files or the repo there (symlink node_modules). You may run npx vitest run, npx tsc --noEmit -p tsconfig.json and npx tsx scripts from the repo root, pointing at scratch files.`

const FINDINGS_SCHEMA = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          file_line: { type: 'string' },
          severity: { type: 'string', enum: ['high', 'medium', 'low'] },
          problem: { type: 'string' },
          scenario: { type: 'string' },
          reproduction: { type: 'string' },
          suggested_fix: { type: 'string' },
        },
        required: ['title', 'file_line', 'severity', 'problem', 'scenario', 'reproduction', 'suggested_fix'],
      },
    },
    checked_and_correct: { type: 'array', items: { type: 'string' } },
  },
  required: ['findings', 'checked_and_correct'],
}

const VERDICT_SCHEMA = {
  type: 'object',
  properties: {
    real: { type: 'boolean' },
    evidence: { type: 'string' },
    corrected_fix: { type: 'string' },
  },
  required: ['real', 'evidence', 'corrected_fix'],
}

const LENSES = [
  {
    key: 'logic',
    prompt: `Lens: pure logic. Read the changed logic in src/lib/biomarkers/supplements.ts (readCreatineDose and helpers), src/lib/patient-context/lab-context.ts, src/lib/biomarkers/creatinine-plausibility.ts, applyLifestyleAdjustments in biological-age-kdm.ts, adjustCreatinineByLab and computeRollingAverageBA in rolling-average-ba.ts, and the creatinine path of assembleBioAgeV3Inputs/bioAgeV3Record in biological-age-v3-adapter.ts. Find inputs that give a wrong result: wrong divisor, wrong context chosen, a figure that should be null and is not, or the reverse. Compute expected values independently.`,
  },
  {
    key: 'flow',
    prompt: `Lens: data flow and state. List every code path that writes lab_results.biological_age, biological_age_comprehensive, bio_age_method, bio_age_v3_shadow, or profiles.current_ba*, and every route that changes lab_results.status. For each, check which patient context and which client (user-scoped under row-level security, or service role) it uses, whether it runs before or after the lab is ready, what happens on an error at each step, and races between flows (context confirmation vs the auto-resolve cron, a corrected report from the lab bridge src/lib/lab-bridge/store.ts arriving while pending or after ready, a value edit through regenerate-master). Report paths that store a wrong figure, skip a needed recompute, or leave state inconsistent.`,
  },
  {
    key: 'tests',
    prompt: `Lens: test strength. For each test file added or changed in the range, check that every test asserts what its title claims. Then copy the repo to your scratch folder (symlink node_modules) and run targeted mutations of the changed production code (remove a call, reorder, invert a condition, change a constant, drop a filter) to find behaviour no test pins. Report only mutations that survive the full suite and correspond to behaviour that matters to a client's figure, with the exact mutation and the suite result.`,
  },
  {
    key: 'clinical',
    prompt: `Lens: clinical and copy accuracy. Read every client-facing and physician-facing text changed in the range (the methodology pages in both languages, the three in-app notes, PHYSICIAN-SIGNOFF.md item 12 and its limitation line, PROPOSAL.md's declared creatine row, the counsel note's 30 October section, the two memo headers). Rerun every number against the code (profiles in docs/biomarker-evidence/longevity/base-panel/panels.json; the Base Panel is scripts/base_panel_assessment.ts BASE_KEYS plus fructosamine 200). Check every cited source supports the exact sentence it is attached to (PubMed or Europe PMC abstracts: Tsiaras 2026 PMID 42035842, de Souza Almeida 2026 PMID 42507286, Kreider 2017 PMID 28615996, Hultman 1996 PMID 8828669, Vilar Neto 2020 PMID 32670557, Naeini 2025 PMID 41199218, Chun 2026 PMID 42578920). Check the Spanish and English versions say the same thing. Report statements that are false, unsupported, misleading to a client or physician, or inconsistent between texts.`,
  },
  {
    key: 'dose-fuzz',
    prompt: `Lens: adversarial inputs to readCreatineDose (src/lib/biomarkers/supplements.ts), which reads the free-text daily creatine dose a client types into the context form. Write at least 150 realistic dose strings, in Spanish and English, as real people type them (typos, missing spaces, accents or not, brand words, scoops, capsules, loading phases, weekly schedules, decimals with comma or point, thousands separators, units in words). For each, decide what a careful human reading gives in grams per day, or that it is ambiguous; then run the function (npx tsx with the repo's tsconfig). Report misreads that change the divisor 1 + 0.13 x min(g, 3)/3 by more than 0.005, and cases where the function returns a number for a text a careful reader would call ambiguous. Group similar misreads into one finding each, with the inputs listed.`,
  },
]

function findPrompt(lens) {
  return `${BRIEF}

${lens.prompt}

Your scratch folder: ${SCRATCH}/find-${lens.key}/ (create it).
Report at most 6 findings, most severe first. Only defects you reproduced or can point to exactly; no style, no nits, nothing already fixed. For each give file:line, severity, the problem, a concrete scenario with inputs and outcome, the reproduction (script path in your scratch folder and its output), and a suggested fix. Also list, one line each, what you checked and found correct.`
}

function verifyPrompt(f, lensKey, mode) {
  const task = mode === 'reproduce'
    ? `Try to REFUTE this finding by reproducing it yourself from scratch: write your own script or test in your scratch folder; do not reuse the finder's script. If it does not reproduce exactly as stated, or the stated outcome is not what the code does, set real=false. Default to real=false if you cannot reproduce it.`
    : `Judge whether the behaviour described is actually wrong, given the intended design and deliberate decisions above, the clinical context, and what the app and documents promise clients and the physician. A documented deliberate choice with no real harm is not a defect. If the finding is real but its suggested fix is wrong or incomplete, set real=true and give a corrected fix. Default to real=false if it is a matter of taste.`
  return `${BRIEF}

A reviewer (lens: ${lensKey}) reported this finding:
Title: ${f.title}
Where: ${f.file_line}
Severity: ${f.severity}
Problem: ${f.problem}
Scenario: ${f.scenario}
Reproduction: ${f.reproduction}
Suggested fix: ${f.suggested_fix}

${task}

Your scratch folder: ${SCRATCH}/verify-${mode}-${lensKey}-${f.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40)}/ (create it).
Return real (boolean), evidence (what you ran or read, with file:line and outputs) and corrected_fix (the fix you would apply, or "none").`
}

const perLens = await pipeline(
  LENSES,
  (lens) => agent(findPrompt(lens), { label: `find:${lens.key}`, phase: 'Find', schema: FINDINGS_SCHEMA }),
  (found, lens) => {
    const findings = (found && found.findings) || []
    log(`${lens.key}: ${findings.length} finding(s) to verify`)
    return parallel(findings.map((f) => () =>
      parallel(['reproduce', 'intent'].map((mode) => () =>
        agent(verifyPrompt(f, lens.key, mode), { label: `verify:${lens.key}:${mode}`, phase: 'Verify', schema: VERDICT_SCHEMA })))
        .then((vs) => ({ ...f, lens: lens.key, verdicts: vs.filter(Boolean) }))
    )).then((verified) => ({ lens: lens.key, verified, checked: (found && found.checked_and_correct) || [] }))
  },
)

const all = perLens.filter(Boolean).flatMap((r) => r.verified.filter(Boolean))
const confirmed = all.filter((f) => f.verdicts.length === 2 && f.verdicts.every((v) => v.real))
const split = all.filter((f) => f.verdicts.some((v) => v.real) && !confirmed.includes(f))
const rejected = all.filter((f) => f.verdicts.length > 0 && f.verdicts.every((v) => !v.real))
log(`${all.length} findings: ${confirmed.length} confirmed by both skeptics, ${split.length} split, ${rejected.length} rejected`)
return {
  confirmed,
  split,
  rejected: rejected.map((f) => ({ lens: f.lens, title: f.title, file_line: f.file_line, why: f.verdicts.map((v) => v.evidence) })),
  checked: perLens.filter(Boolean).map((r) => ({ lens: r.lens, checked: r.checked })),
}
