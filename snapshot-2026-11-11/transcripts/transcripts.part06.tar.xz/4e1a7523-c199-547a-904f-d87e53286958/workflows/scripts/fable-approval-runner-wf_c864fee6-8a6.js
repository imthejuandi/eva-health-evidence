export const meta = {
  name: 'fable-approval-runner',
  description: 'Fable 5.2 reviews the frozen runner files changed since round 0 and recommends approve or reject per file, with an adversarial challenge per area',
  phases: [
    { title: 'Review', detail: 'one Fable 5.2 reviewer per runner area, read-only, against the written specification' },
    { title: 'Challenge', detail: 'an adversarial Fable 5.2 reviewer per area tries to overturn each verdict' },
  ],
}

const A = args
const MODEL = 'claude-fable-5-2'
const EFFORT = 'max'
const BASE = A.base
const SCR = A.scratch

const FINDING = {
  type: 'object',
  properties: {
    summary: { type: 'string' },
    evidence: { type: 'string' },
    failure_scenario: { type: 'string' },
    smallest_fix: { type: 'string' },
  },
  required: ['summary', 'evidence', 'failure_scenario', 'smallest_fix'],
}
const REVIEW = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    files: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          sha256_matches: { type: 'boolean' },
          recommendation: { type: 'string', enum: ['approve', 'reject'] },
          plain_rationale: { type: 'string' },
          changes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                what: { type: 'string' },
                defect_fixed: { type: 'string' },
                spec_basis: { type: 'string' },
                direction: { type: 'string', enum: ['tightens', 'loosens', 'neutral', 'new check'] },
                justified: { type: 'boolean' },
              },
              required: ['what', 'defect_fixed', 'spec_basis', 'direction', 'justified'],
            },
          },
          blocking_findings: { type: 'array', items: FINDING },
          notes: { type: 'array', items: { type: 'string' } },
        },
        required: ['file', 'sha256_matches', 'recommendation', 'plain_rationale', 'changes', 'blocking_findings', 'notes'],
      },
    },
    tests_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } },
  },
  required: ['area', 'files', 'tests_run'],
}
const CHALLENGE = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    files: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          recommendation: { type: 'string', enum: ['approve', 'reject'] },
          agrees_with_reviewer: { type: 'boolean' },
          new_blocking_findings: { type: 'array', items: FINDING },
          reviewer_findings_assessed: {
            type: 'array',
            items: { type: 'object', properties: { summary: { type: 'string' }, stands: { type: 'boolean' }, why: { type: 'string' } }, required: ['summary', 'stands', 'why'] },
          },
          plain_rationale: { type: 'string' },
        },
        required: ['file', 'recommendation', 'agrees_with_reviewer', 'new_blocking_findings', 'reviewer_findings_assessed', 'plain_rationale'],
      },
    },
    tests_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } },
  },
  required: ['area', 'files', 'tests_run'],
}

const BACKGROUND = [
  'Background.',
  '- EVA is a preventive-health app. Before launch, a licensed physician will review and sign its optimal biomarker ranges, its biological age model and its score. An AI sign-off programme prepares that material. The Doctor Sign-off Readiness Test (DSRT), specified in docs/signoff/ACCEPTANCE-TEST.md, is the acceptance test the material must pass before it goes to the physician. The runner in scripts/signoff/ and the tools in docs/signoff/tools/ grade the material.',
  `- So that the programme cannot pass its own work by changing the test, the specification, runner, thresholds, judge prompts and tools were hashed at round 0 (docs/signoff/work/checks/round-0.json; baseline commit ${BASE}). Check G1 fails while any of them differs from round 0 without an entry in docs/signoff/work/governance/approved-changes.json ({file, sha256, commit, approved_by: "CEO"}). The specification itself (ACCEPTANCE-TEST.md) is unchanged since round 0.`,
  '- After the pilot batch B01, the programme\'s orchestrator changed 22 frozen files to fix defects the pilot exposed. The defects and their status are in docs/signoff/work/central/known-issues.md; the proposed approvals are in docs/signoff/work/governance/pending-approvals.json. The orchestrator\'s own work is graded by these files, so the main risk is a change that makes the test easier to pass than the specification allows. Several AI review rounds already looked at these changes; their records are named below.',
  '- Your recommendation will be recorded as the CEO\'s approval decision for the exact sha256 listed. Be exact and independent.',
].join('\n')

const STANDARD = [
  'The approval standard. Recommend "approve" for a file only if all four hold:',
  '1. Purpose: every change fixes a real defect of the round-0 version against the written specification (ACCEPTANCE-TEST.md; for formats, docs/signoff/LOOP-PROMPT.md and docs/signoff/workflows/README.md), or adds checking the specification asks for. For each change, name the defect and quote the specification text.',
  '2. No unjustified loosening: no check passes more easily than the specification allows. A change that lets something pass that failed at round 0 is a loosening. It is acceptable only where the round-0 code was stricter than the specification\'s text, and you quote that text. Tightening within the specification is acceptable.',
  '3. Correctness: the code does what it claims, including edge cases (missing or empty files, malformed data, Spanish fields, state rows such as pregnancy, added rows, ties at bounds). Read the code paths; do not rely on test names.',
  '4. Scope and no bypass: no edit outside the stated purpose, and no hidden way to skip a check (a key, an environment variable, a file whose presence or absence turns a failure into a pass, a swallowed error, a status other than fail for a real failure).',
  'Reject when any of the four fails in a way that matters for what the physician will sign or for the integrity of the test. A cosmetic or documentation flaw is a note, not a reason to reject. When you reject, give the smallest change that would make the file approvable.',
].join('\n')

const RULES = (dir) => [
  'How to work.',
  `- Diff each file against round 0: \`git diff ${BASE} -- <file>\`. An added file has no base; review it whole. Check its sha256 with \`sha256sum <file>\`; if it differs from the one listed, set sha256_matches false and reject that file.`,
  '- Read the specification rows and text for every check the file implements, and the known-issues entry the change addresses.',
  '- Run the runner tests: `npx vitest run src/lib/signoff`. You may also run `npx tsc --noEmit` and the runner on existing compiled data to exercise a behaviour, for example `npm run dsrt -- --round 99 --families f01_albumin_proteins --seed-dir docs/signoff/work/compiled/B01-r4 --out ' + dir + '/r.json` (compiled batch copies are under docs/signoff/work/compiled/; batch results under docs/signoff/work/checks/).',
  `- Read-only: do not modify, create or delete any file in the repository, and run no git command that changes state (no add, commit, checkout, stash, reset, restore). Write scratch files only under ${dir}/ (create it with mkdir -p). Another programme run is working in the same repository; ignore files it changes under docs/signoff/work/.`,
  '- plain_rationale: two to five sentences in plain words a CEO without a coding background can follow. Technical evidence goes in changes and findings, with file:line references.',
].join('\n')

const AREAS = A.areas

function reviewPrompt(area) {
  const files = area.files.map((f) => `- ${f.file} (${f.kind}; sha256 ${f.sha256}; area: ${f.area})`).join('\n')
  return [
    `You review changes to frozen files of EVA's acceptance test for the CEO's approval. Area: ${area.name}.`,
    '',
    BACKGROUND,
    '',
    `Files of your area:\n${files}`,
    '',
    `Specification focus: ${area.focus}`,
    `Earlier AI review records for this area: ${area.reviews.join(', ')}. Use them only to learn which defects were raised and check each one yourself; their acceptance is not evidence.`,
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}`),
    '',
    'Reply with the structured result: one entry in files for each file listed, in the same order.',
  ].join('\n')
}

function challengePrompt(area, review) {
  const files = area.files.map((f) => `- ${f.file} (${f.kind}; sha256 ${f.sha256})`).join('\n')
  return [
    `You are the adversarial second reviewer of frozen-file changes of EVA's acceptance test, area ${area.name}, for the CEO's approval. A first reviewer gave the verdicts below. Try to overturn them.`,
    '- For each file the reviewer recommends approving, hunt for a blocking defect they missed: a way a check now passes more easily than the specification allows; a code path that silently skips a check (missing file, empty list, early return, caught error, a pass or blocked status for a real failure); wrong results on edge cases; a test that asserts the wrong thing or passes vacuously.',
    '- For each blocking finding the reviewer raised, try to refute it: reproduce it, or show with evidence that it is wrong or does not matter.',
    'A finding needs evidence: file:line, a command and its output, or a concrete input and the wrong output. Agree with the reviewer only after your own search finds nothing.',
    '',
    BACKGROUND,
    '',
    `Files of your area:\n${files}`,
    `Specification focus: ${area.focus}`,
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}-challenge`),
    '',
    `The first reviewer's result:\n${JSON.stringify(review, null, 1)}`,
    '',
    'Reply with the structured result: one entry in files for each file listed, in the same order.',
  ].join('\n')
}

const out = await pipeline(
  AREAS,
  (area) => agent(reviewPrompt(area), { label: `review ${area.key}`, phase: 'Review', schema: REVIEW, model: MODEL, effort: EFFORT }),
  (review, area) => review
    ? agent(challengePrompt(area, review), { label: `challenge ${area.key}`, phase: 'Challenge', schema: CHALLENGE, model: MODEL, effort: EFFORT }).then((ch) => ({ area: area.key, review, challenge: ch }))
    : { area: area.key, review: null, challenge: null },
)
const missing = AREAS.filter((a, i) => !out[i] || !out[i].review || !out[i].challenge).map((a) => a.key)
if (missing.length) log(`incomplete areas: ${missing.join(', ')}`)
return { results: out, missing }
