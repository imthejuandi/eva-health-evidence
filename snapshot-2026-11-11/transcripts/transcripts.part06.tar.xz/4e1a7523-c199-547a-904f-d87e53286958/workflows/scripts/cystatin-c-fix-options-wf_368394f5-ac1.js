export const meta = {
  name: 'cystatin-c-fix-options',
  description: 'Research the KDM cystatin C defect and produce three ranked, measured fix options',
  phases: [
    { title: 'Understand', detail: 'code map, current numbers, literature' },
    { title: 'Design', detail: 'three angles propose fixes; merge into candidates' },
    { title: 'Measure', detail: 'simulate each candidate on the synthetic panels' },
    { title: 'Verify', detail: 'adversarial check of each candidate' },
    { title: 'Synthesize', detail: 'rank three options; completeness critic' },
  ],
}

const SP = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/cysc'

const CTX = `You are researching a defect in EVA Health's deployed biological age model, KDM v2.2.2 (Klemera-Doubal), in the repository at /home/user/eva-health (a Next.js app; read AGENTS.md before relying on framework knowledge). EVA is a Spanish preventive-health company. Its CEO wants three options to fix the defect, with a recommendation.

THE DEFECT (already confirmed):
- src/lib/biomarkers/biological-age-kdm.ts, applyLifestyleAdjustments(): when 'Cistatina C' is present it deletes 'Creatinina' from the inputs (the 'Cystatin-C-preferred' rule, described in comments as a Path B / v2.2.1 addition) and skips the creatine offset.
- The Reference version (computeReferenceBA) calls resolveKdmParams(..., restrictToBasePanel=true), which keeps only BASE_PANEL markers (library meta.base_panel, 14 markers: Albúmina, Creatinina, BUN, Ácido Úrico, ALP, GGT, Colesterol Total, Colesterol HDL, Triglicéridos, hs-PCR, Ferritina, Vitamina D, TSH, Fructosamina). 'Cistatina C' is not in it. So with cystatin C present the Reference version uses no kidney marker at all.
- passesKdmGate() and countBasePanelMarkers() count cystatin C in the creatinine slot, so a Reference result can pass the 8-of-14 gate while using only 7 base markers.
- Measured on 29 October 2026 (Base Panel tests of the synthetic panels in docs/biomarker-evidence/longevity/base-panel/panels.json, cystatin C 0.85 mg/L added, no supplements): typical man 45, Reference 51.3 without cystatin C and 52.3 with it, 9 markers, creatinine gone and cystatin C unused; typical woman 45, Reference 47.8 and 48.9. The Comprehensive version (computeComprehensiveBA, restrictToBasePanel=false) does use cystatin C: man 47.9, woman 47.1 with cystatin C.

RELATED FACTS FOUND WHILE SCOUTING (verify before relying on them):
- Library src/lib/biomarkers/data/marker_library_v2_2.json, 'Cistatina C': tier B, not base panel, not sex-stratified, NHANES cycles listed as '1999-2002, 2007-2018', n=1,664, Spanish q from Comas et al. 2010 Rev Esp Cardiol (n=359). Path B override in src/lib/biomarkers/data/path_b_overrides.json: k=0.00684, q=0.602, s=0.543, r2=0.027, n=1,664. resolveKdmParams keeps the Spanish q when one exists and takes k and s from Path B.
- 'Creatinina': base panel, sex-stratified, n=9,186 men and 9,446 women; Path B men k=0.00402, s=0.389; women k=0.00396, s=0.300; Spanish per-sex q.
- 'TFGe (basada en Creatinina)', creatinine-based eGFR (CKD-EPI, reported by the laboratory; a comment in biological-age-v3-adapter.ts says the app computes no eGFR): a Comprehensive-only trained marker, Path B k=-0.842, q=136.3, s=16.06, r2=0.33, n=18,632. It is not dropped when cystatin C is present, and when a lab reports both creatinine and eGFR the Comprehensive version counts creatinine's information twice.
- EVA's own laboratory (Echevarne) does not deliver cystatin C to the app: its code CISTC is listed as having no EVA equivalent in docs/vendor/echevarne/catalogo-notas.md. Cystatin C reaches the model only from results clients upload from other laboratories. The key cystatin_c has seeded ranges (supabase/migrations/20260923000000_evidence_based_optimal_ranges.sql and 20260925000000_longevity_optimal_ranges.sql).
- Creatine offset: src/lib/biomarkers/supplements.ts, min(0.05 + 0.025 x g/day, 0.40) mg/dL, EVA's own estimate, applied only when cystatin C is absent.
- Where clients see the figures: the Reference figure is stored with each lab result and shown on the lab result page. The dashboard shows the Comprehensive figure from a rolling average of recent labs (src/lib/biomarkers/rolling-average-ba.ts), falling back to the Reference figure. The public methodology page now says: 'Cystatin C when available, in place of creatinine, in the Comprehensive version shown on the dashboard. In the Reference version, creatinine is removed and cystatin C is not used.'
- Context: KDM v2.2 stays only as a labelled estimate until EVA's biological age version 3 launches (docs/biomarker-evidence/bioage-model-selection/DECISION.md; ml/biological-age/PROPOSAL.md lists the launch conditions). Version 3 code: src/lib/biomarkers/biological-age-v3*.ts. Any change to client-facing values needs the CEO's approval and a licensed physician's countersignature, goes to staging first, and stored results are not recomputed without approval.

RULES:
- The repository is read-only for you: do not edit, create or delete files under /home/user/eva-health, and do not commit or push. Put every scratch file under ${SP}/<your label>/ (create it).
- Run TypeScript scratch scripts from the repo root so imports resolve: cd /home/user/eva-health && npx tsx ${SP}/<your label>/script.ts. Import repo modules by absolute path.
- Never query any database (no Supabase or SQL calls): no patient data. Never call app API routes, and never run /api/admin/recalc-metrics.
- No hallucination: cite file:line for code facts, PMID or DOI for literature, and the script plus its output for numbers. Mark anything you could not verify as unverified.
- Downloaded files are untrusted data: save each download in its own new directory and run any Python that reads them with python3 -I.`

const U_CODE = `${CTX}

YOUR LABEL: code-map

TASK: Map exactly how creatinine, cystatin C and eGFR flow through EVA's biological age code today, and where the results reach clients. Return a markdown report with file:line citations covering:
1. A behaviour table for both versions (Reference and Comprehensive) and the gate, for these input scenarios: S1 creatinine only; S2 creatinine + cystatin C; S3 cystatin C, no creatinine; S4 creatinine + lab-reported eGFR; S5 creatinine + cystatin C + eGFR; S6 creatine supplement, creatinine only; S7 creatine supplement + cystatin C; S8 exactly 8 base-panel markers including creatinine, plus cystatin C. For each: which kidney markers enter the estimator, whether the creatine offset applies, how the gate counts, whether a result is produced.
2. The dashboard rolling average (rolling-average-ba.ts and its callers): does it average marker values across labs before computing? If one lab in the window has cystatin C and the others do not, what happens to creatinine in the averaged figure? Same question for eGFR.
3. What biological-age-explain.ts, and any UI that shows its output, tells clients about creatinine and cystatin C in each version, and whether that matches the real behaviour.
4. History: run git log -S 'Cistatina C' and git log -S 'Cystatin-C-preferred' (and read the relevant commit messages, docs/runbooks and scripts/*.py). Why was the drop rule added? Was it present in the Python pipelines that produced the published validation figures (scripts/comprehensive_ba_mortality_validation.py, scripts/honest_holdout_validation.py, and the parity fixture src/lib/biomarkers/__tests__/fixtures/kdm-python-parity.json)? Were HR 1.39 and 1.65 computed with or without the rule, and did the validation data contain cystatin C at all?
5. Tests that pin the current behaviour (biological-age-kdm.test.ts around line 871, biological-age-explain.test.ts, kdm-adapter.test.ts, parity tests): list each assertion a fix would change.
6. Version 3: does it use or drop creatinine when cystatin C is present? Does the version 3 shadow write depend on KDM inputs?
7. Persistence: where computeReferenceBA and computeComprehensiveBA results are written (process-results.ts, the rolling cache, profile.current_ba), what a code change would and would not change for stored results without a recalculation, and which surfaces recompute on the fly.
8. Any other defect you notice in this area, for example eGFR double counting, the gate counting a marker the version does not use, unit handling for uploaded cystatin C, or the plausibility bounds for cystatin C in src/lib/biomarkers/data/plausibility_bounds.json.`

const U_NUM = `${CTX}

YOUR LABEL: current-numbers

TASK: Measure the current behaviour with numbers, using the deployed code unchanged.
Write scratch TypeScript scripts that import from /home/user/eva-health/src/lib/biomarkers/biological-age-kdm.ts (computeReferenceBA, computeComprehensiveBA, applyLifestyleAdjustments, passesKdmGate, countBasePanelMarkers, resolveKdmParams, BASE_PANEL, and any other export you need; check what is exported) and use the synthetic panels in docs/biomarker-evidence/longevity/base-panel/panels.json. See scripts/base_panel_assessment.ts for how EVA runs them. The Base Panel test keys are albumin, alp, hs_crp, creatinine, bun, uric_acid, total_cholesterol, hdl_cholesterol, triglycerides, apolipoprotein_b_apob, alt, ggt, fructosamine. Inputs are passed as [{code, value}] with the keys the adapter accepts (src/lib/biomarkers/kdm-adapter.ts; cystatin C is cystatin_c, eGFR is egfr_creatinine_based).
Grid: all 7 personas; Base Panel only, and the full panel; cystatin C absent, 0.70, 0.85, 1.00, 1.20 and 1.50 mg/L; eGFR absent or present (when present, compute it with the CKD-EPI 2021 race-free creatinine equation from the panel's creatinine, sex and age, as a laboratory would report it, and cite the coefficients from Inker et al., NEJM 2021); creatine supplement none or 5 g/day (find the supplement format the code expects in supplements.ts).
Report for each case: Reference and Comprehensive BA, BA_E, s_BA, the number of markers and which kidney markers were used, and the gate count.
Also report:
(a) For the typical man and woman of 45: each kidney marker's information weight (k/s)^2 with the parameters the code actually uses (after the Spanish q and Path B; use resolveKdmParams), its share of the summed weight in each version, and the BA sensitivity to each kidney marker (years of BA per 0.1 mg/dL creatinine, per 0.1 mg/L cystatin C, per 10 mL/min eGFR), by finite differences on the full functions.
(b) The size of the defect: Reference BA with cystatin C present minus Reference BA without it, for each persona and cystatin C value.
(c) The cystatin C value that is 'typical for age' under the model's own parameters (q + k x age, with the Spanish q), so the scenario values can be read against it; the same for creatinine by sex.
Return markdown tables, the script paths, and short findings.`

const U_LIT = `${CTX}

YOUR LABEL: literature

TASK: Research the science behind the options, with verified sources. Use the Europe PMC REST API (https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&format=json&resultType=core) or PubMed E-utilities through curl; read abstracts or full text where open. Cover:
1. Which published blood-chemistry biological-age algorithms include cystatin C, creatinine, eGFR, or more than one of them (for example Levine 2013 KDM; Kwon and Belsky 2021 BioAge; UK Biobank KDM or PhenoAge studies that use cystatin C; other KDM studies), and how they handle two kidney markers: both included, one chosen, or a composite eGFR.
2. Cystatin C versus creatinine as markers of ageing and mortality (for example Shlipak et al., NEJM 2005; other cohorts), including how strongly each correlates with age.
3. Non-GFR determinants of each marker: creatinine (muscle mass, diet, creatine supplementation; trials that measured both creatinine and cystatin C during creatine supplementation) and cystatin C (inflammation, obesity, thyroid dysfunction, corticosteroids, smoking, diabetes).
4. The CKD-EPI 2021 equations (Inker et al., NEJM 2021), including the combined creatinine-cystatin C equation, and KDIGO 2024 guidance on when to use cystatin C.
5. The Klemera-Doubal method's assumption that markers are conditionally independent given age, and what correlated markers (such as creatinine and eGFR, or creatinine and cystatin C) do to the estimate; cite Klemera and Doubal 2006 and any methodological critique.
6. NHANES cystatin C: which survey cycles measured it (surplus sera 1999-2002, any later cycles), any calibration or standardisation of the 1999-2002 values, and what this implies for a training sample of n=1,664.
7. Spanish cystatin C reference values (Comas et al. 2010 Rev Esp Cardiol and any others), and how the assay (nephelometric, turbidimetric, IFCC-standardised ERM-DA471) changes values.
Return a markdown report of claims, each with PMID or DOI and marked verified (you read the record) or unverified. End with the implications for the fix options.`

const PROPOSALS = {
  type: 'object',
  properties: {
    options: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string' },
          one_line: { type: 'string' },
          reference_behavior: { type: 'string' },
          comprehensive_behavior: { type: 'string' },
          gate_behavior: { type: 'string' },
          egfr_handling: { type: 'string' },
          creatine_handling: { type: 'string' },
          code_changes: { type: 'string' },
          scientific_basis: { type: 'string' },
          client_impact: { type: 'string' },
          pros: { type: 'array', items: { type: 'string' } },
          cons: { type: 'array', items: { type: 'string' } },
          risks: { type: 'array', items: { type: 'string' } },
        },
        required: ['name', 'one_line', 'reference_behavior', 'comprehensive_behavior', 'gate_behavior', 'code_changes', 'pros', 'cons'],
      },
    },
  },
  required: ['options'],
}

const CANDIDATES = {
  type: 'object',
  properties: {
    candidates: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          name: { type: 'string' },
          definition: { type: 'string' },
          code_sketch: { type: 'string' },
          origin: { type: 'string' },
          why_distinct: { type: 'string' },
        },
        required: ['id', 'name', 'definition', 'code_sketch'],
      },
    },
    baseline_note: { type: 'string' },
    dropped: { type: 'array', items: { type: 'string' } },
  },
  required: ['candidates'],
}

const MEASURE = {
  type: 'object',
  properties: {
    id: { type: 'string' },
    harness_check: { type: 'string' },
    summary_table_md: { type: 'string' },
    key_findings: { type: 'array', items: { type: 'string' } },
    tests_to_change: { type: 'array', items: { type: 'string' } },
    diff_sketch: { type: 'string' },
    lines_changed_estimate: { type: 'number' },
    scripts: { type: 'array', items: { type: 'string' } },
    problems_found: { type: 'array', items: { type: 'string' } },
  },
  required: ['id', 'harness_check', 'summary_table_md', 'key_findings', 'diff_sketch'],
}

const VERDICT = {
  type: 'object',
  properties: {
    id: { type: 'string' },
    verdict: { type: 'string', enum: ['viable', 'viable_with_caveats', 'not_viable'] },
    fatal_flaws: { type: 'array', items: { type: 'string' } },
    refuted_claims: { type: 'array', items: { type: 'string' } },
    confirmed_claims: { type: 'array', items: { type: 'string' } },
    caveats: { type: 'array', items: { type: 'string' } },
    independent_numbers_md: { type: 'string' },
  },
  required: ['id', 'verdict', 'fatal_flaws', 'refuted_claims', 'confirmed_claims', 'caveats'],
}

const CRITIC = {
  type: 'object',
  properties: {
    needs_revision: { type: 'boolean' },
    errors: { type: 'array', items: { type: 'string' } },
    gaps: { type: 'array', items: { type: 'string' } },
  },
  required: ['needs_revision', 'errors', 'gaps'],
}

phase('Understand')
const [codeMap, current, lit] = await parallel([
  () => agent(U_CODE, { label: 'code-map', phase: 'Understand' }),
  () => agent(U_NUM, { label: 'current-numbers', phase: 'Understand' }),
  () => agent(U_LIT, { label: 'literature', phase: 'Understand' }),
])
if (!codeMap || !current || !lit) log('Warning: an Understand agent returned nothing; later stages see a partial picture.')

const REPORTS = `=== CODE MAP REPORT ===
${codeMap || '(missing)'}

=== CURRENT NUMBERS REPORT ===
${current || '(missing)'}

=== LITERATURE REPORT ===
${lit || '(missing)'}`

phase('Design')
const ANGLES = [
  { key: 'minimal', text: 'Minimal risk and minimal code change. KDM will be replaced by version 3, so prefer fixes that restore the intended behaviour with the smallest diff and the least change to values clients already see. Also judge whether changing nothing in code and only disclosing the behaviour is defensible.' },
  { key: 'science', text: 'Scientific correctness of the Klemera-Doubal estimator: use all valid information, avoid double counting correlated markers (KDM assumes markers are conditionally independent given age), stay consistent with how the parameters were trained and how the published validation was run, and judge the quality of the cystatin C parameters (n=1,664, r2=0.027 after Path B) against creatinine and eGFR.' },
  { key: 'client', text: "Client trust and product consistency: the lab page shows the Reference figure and the dashboard the Comprehensive one; a client's figure should not jump when one lab includes cystatin C and the next does not; creatine users; what the explanation and the methodology pages say; what a licensed physician would be willing to countersign; how stored values and the rolling average behave." },
]
const proposals = await parallel(ANGLES.map(a => () => agent(`${CTX}

YOUR LABEL: design-${a.key}

TASK: Propose two or three concrete fixes for the defect, from this angle: ${a.text}
Each option must be defined precisely enough for another engineer to simulate it without guessing: the exact behaviour of applyLifestyleAdjustments, the gate (passesKdmGate and countBasePanelMarkers), the Reference version, the Comprehensive version, lab-reported eGFR, and the creatine offset. Say which functions change and how. Ground every claim in the reports below; do not invent numbers.

${REPORTS}`, { label: `design:${a.key}`, phase: 'Design', schema: PROPOSALS })))

const allOptions = proposals.filter(Boolean).flatMap((p, i) => (p.options || []).map(o => ({ angle: ANGLES[i] ? ANGLES[i].key : 'unknown', ...o })))
log(`${allOptions.length} proposed options from ${proposals.filter(Boolean).length} angles`)

const merged = await agent(`${CTX}

YOUR LABEL: merge

TASK: Merge the proposed options below into at most four distinct, concrete candidate fixes, excluding 'change nothing in code'. Combine near-duplicates. Each candidate needs an id (A, B, C, D), a name, a precise definition (the exact behaviour of applyLifestyleAdjustments, the gate, Reference, Comprehensive, lab-reported eGFR and the creatine offset), a code sketch (which functions change, and how), and where it came from. Prefer a set that spans the real choices: for example keeping creatinine in the Reference version, letting cystatin C stand in for creatinine in the Reference version, using both markers or a combined creatinine-cystatin C eGFR, and fixing the eGFR double count, whichever the evidence supports. Add a note on the 'disclose only and wait for version 3' baseline. List anything you dropped and why.

PROPOSED OPTIONS (JSON):
${JSON.stringify(allOptions, null, 1)}

${REPORTS}`, { label: 'merge', phase: 'Design', schema: CANDIDATES })

const cands = merged && merged.candidates ? merged.candidates.slice(0, 4) : []
if (merged && merged.candidates && merged.candidates.length > 4) log(`Dropped ${merged.candidates.length - 4} candidates beyond the first four: ${merged.candidates.slice(4).map(c => c.id).join(', ')}`)
log(`Candidates: ${cands.map(c => `${c.id} ${c.name}`).join(' | ')}`)

const results = await pipeline(
  cands,
  c => agent(`${CTX}

YOUR LABEL: measure-${c.id}

TASK: Simulate candidate ${c.id} and measure its effect. Do not modify the repository. Implement the candidate in scratch code: compose the exported functions where you can; if the candidate needs internal changes, copy src/lib/biomarkers/biological-age-kdm.ts into your scratch folder, change the copy, and rewrite its relative imports to absolute paths.
1. First prove your harness matches the deployed code: with the unmodified functions, reproduce the typical man of 45, Base Panel, Reference 51.3 without cystatin C and 52.3 with cystatin C 0.85 mg/L, and two more numbers from the current-numbers report. Report this in harness_check.
2. Run the same grid as the current-numbers report and give before and after tables (Reference and Comprehensive) for each persona at cystatin C absent, 0.85 and 1.20 mg/L, with and without lab-reported eGFR, and with and without creatine 5 g/day.
3. Report gate outcomes, any case where the candidate gives no result, and any case where a figure moves more than 1 year from the value without cystatin C.
4. List the repository tests (file:line) that would need to change, and how.
5. Write a unified-diff sketch of the real change (not applied) and estimate the lines changed.

CANDIDATE ${c.id}: ${c.name}
DEFINITION: ${c.definition}
CODE SKETCH: ${c.code_sketch}

${REPORTS}`, { label: `measure:${c.id}`, phase: 'Measure', schema: MEASURE }),
  (m, c) => {
    if (!m) return { c, m: null, v: null }
    return agent(`${CTX}

YOUR LABEL: verify-${c.id}

TASK: Adversarially review candidate ${c.id}. Try to refute every claim in its definition and in its measurement, and look for fatal flaws. Use three lenses:
1. Science: is the option consistent with the Klemera-Doubal method's assumptions, with how the parameters were trained, and with the literature report?
2. Code: re-run at least three of the measured numbers yourself with your own scratch script, and look for edge cases: cystatin C only, both kidney markers missing, eGFR present, creatine users, the gate, the dashboard's rolling average across labs with and without cystatin C, units.
3. Client and approvals: does it change values clients already saw; does it need a recalculation, the CEO's approval or the physician's countersignature; does it keep the public methodology page true or need new text?
Default to refuted for any claim you cannot confirm. Put your own numbers in independent_numbers_md.

CANDIDATE ${c.id}: ${c.name}
DEFINITION: ${c.definition}
CODE SKETCH: ${c.code_sketch}

MEASUREMENT (JSON):
${JSON.stringify(m, null, 1)}

${REPORTS}`, { label: `verify:${c.id}`, phase: 'Verify', schema: VERDICT }).then(v => ({ c, m, v }))
  },
)

const done = results.filter(Boolean)
log(`Measured and verified: ${done.map(r => `${r.c.id}=${r.v ? r.v.verdict : 'unverified'}`).join(', ')}`)

phase('Synthesize')
const EVIDENCE = `CANDIDATES WITH MEASUREMENTS AND VERDICTS (JSON):
${JSON.stringify(done, null, 1)}

BASELINE NOTE: ${merged && merged.baseline_note ? merged.baseline_note : '(none)'}

${REPORTS}`

const STYLE = 'Write in plain English for a CEO. Lead with the outcome. Short sentences. No em dashes, no parentheses in prose, no arrows. Put numbers in tables. At most three headings.'

let report = await agent(`${CTX}

YOUR LABEL: synthesize

TASK: Write the answer for EVA's CEO: three options to fix the cystatin C problem, ranked, with one recommendation. Use only facts confirmed in the evidence below; where a verifier refuted a claim, drop or correct it. ${STYLE}
Include: a short summary of the problem and the recommendation; for each option what it changes, a table of effects (typical man and woman of 45, Base Panel, cystatin C 0.85 and 1.20 mg/L: the lab-page figure and the dashboard figure, before and after), who is affected, pros, cons, effort (lines changed, tests to update) and the approvals it needs; a comparison table of the three; related issues found, each with a one-line suggestion; what happens to stored results and to the public methodology page under the recommended option; and a short list of sources (file:line, PMIDs) at the end. If two candidates are near-identical, merge them. If fewer than three viable candidates exist, use the 'disclose only' baseline as the third and say so.

${EVIDENCE}`, { label: 'synthesize', phase: 'Synthesize' })

const crit = await agent(`${CTX}

YOUR LABEL: critic

TASK: Check this report against the evidence. List factual errors (numbers that do not match the measurements, claims a verifier refuted, citations that do not support the claim), gaps (an option class not considered or wrongly dismissed, a risk not mentioned, an approval missing) and style violations (${STYLE}). Set needs_revision to true if there is any factual error or important gap.

REPORT:
${report}

${EVIDENCE}`, { label: 'critic', phase: 'Synthesize', schema: CRITIC })

if (crit && crit.needs_revision) {
  report = await agent(`${CTX}

YOUR LABEL: revise

TASK: Revise the report to fix every error and gap below. Keep everything that is correct. ${STYLE} Return only the revised report.

ERRORS: ${JSON.stringify(crit.errors)}
GAPS: ${JSON.stringify(crit.gaps)}

REPORT:
${report}

${EVIDENCE}`, { label: 'revise', phase: 'Synthesize' })
}

return { report, critic: crit, candidates: done.map(r => ({ id: r.c.id, name: r.c.name, verdict: r.v ? r.v.verdict : null, fatal_flaws: r.v ? r.v.fatal_flaws : null, refuted: r.v ? r.v.refuted_claims : null, caveats: r.v ? r.v.caveats : null, harness_check: r.m ? r.m.harness_check : null, table: r.m ? r.m.summary_table_md : null, tests: r.m ? r.m.tests_to_change : null, lines: r.m ? r.m.lines_changed_estimate : null })), baseline_note: merged ? merged.baseline_note : null, dropped: merged ? merged.dropped : null }
