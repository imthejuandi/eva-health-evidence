export const meta = {
  name: 'ws2-v3',
  description: 'Workstream 2: version 3 refusal and gating rules, validation-only computations, display behind a flag, physician documents',
  phases: [
    { title: 'Build', detail: 'refusal and gating rules in code; validation-only harness computations' },
    { title: 'Present', detail: 'display and copy behind a flag, hiding the old figure; physician documents split signable and conditional' },
    { title: 'Verify', detail: 'tests, type check, parity, integration' },
  ],
}

const ROOT = '/home/user/eva-health'
const COMMON = `You work in EVA Health's physician sign-off programme on version 3 of the biological age. Repository ${ROOT}, branch claude/wonderful-meitner-l4g7p5 (checked out). Today is ${args.today}. EVA has not launched; nothing is deployed from this branch.

Read first: docs/signoff/PLAN.md (sections 2, 4, 8, 10), docs/signoff/ACCEPTANCE-TEST.md (groups B and X), ml/biological-age/PROPOSAL.md, MODEL-CARD.md, CHARTER.md, PHYSICIAN-SIGNOFF.md, docs/audit/2026-11-03-cmo-reassessment.md and the version 3 findings in docs/audit/2026-11-03-cmo-reassessment-findings.md (SCI-5 to SCI-10, EVP-7), and docs/signoff/work/plan-judges.json (the judges' points on version 3: refusal table, ages 80-84, kidney rule, collection method, creatine, model card wording, replication, consistency). Code: src/lib/biomarkers/biological-age-v3.ts, biological-age-v3-adapter.ts, their tests, src/lib/biomarkers/data/ba_v3_model.json, plausibility_bounds.json, creatinine-plausibility.ts, process-results.ts (the shadow step), supplements.ts.

Hard rules:
- Version 3 is frozen: never change ba_v3_model.json, ml/biological-age/model-v3.json, the coefficients, transforms or clamps, or the math in biological-age-v3.ts. Check B1 hashes them. Never run ml/biological-age/harness/final_test.py.
- Write ONLY the files you are told you own; other agents work at the same time. Do not commit or push.
- No database, no SQL, no emails, no app API calls.
- Clinical values that a physician must confirm go in a configuration file with a 'pending physician confirmation' flag and a source; never bury them in code.
- Run what you write: npx tsc --noEmit -p . and the relevant vitest files; report exact results.
- Work incrementally; aim for about 30 minutes; if short of time stop at a consistent state and list what is missing.

Resuming: an earlier run of this same task was stopped by an account usage limit. Some files you own may already exist from it. Read them first, keep what is correct, and complete the task; do not start over and do not delete files other agents own.

File formats: the acceptance-test modules scripts/signoff/checks/bioage.ts and consistency.ts document in their header comments the exact formats they read (docs/signoff/work/v3/refusals.json, validation-reruns.json, ages-80-84.json, display-copy.json, consistency-exceptions.json). Write your files in those formats. Check your work with npm run dsrt -- --only B1,B2,B3,B4,B5,B6,X1,X2 --out /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/ws2-dsrt.json and report the results. Do not create docs/signoff/work/v3/consistency-exceptions.json: accepting an exception is the physician's and the biostatistician judge's decision, not yours.`

const RESULT = {
  type: 'object',
  properties: {
    files_written: { type: 'array', items: { type: 'string' } },
    commands_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, result: { type: 'string' } }, required: ['command', 'result'] } },
    status: { type: 'string', enum: ['complete', 'partial'] },
    missing: { type: 'array', items: { type: 'string' } },
    decisions_for_physician: { type: 'array', items: { type: 'string' } },
    notes: { type: 'string' },
  },
  required: ['files_written', 'commands_run', 'status', 'missing', 'decisions_for_physician', 'notes'],
}

const V1 = `${COMMON}

Your task: the refusal and gating rules. You own src/lib/biomarkers/biological-age-v3-rules.ts (new), src/lib/biomarkers/data/ba_v3_rules.json (new), src/lib/biomarkers/biological-age-v3-adapter.ts, src/lib/biomarkers/biological-age-v3-rules.test.ts (new), src/lib/biomarkers/biological-age-v3-adapter.test.ts, docs/signoff/work/v3/refusals.json (new), and the shadow-step lines in src/lib/biomarkers/process-results.ts that call the adapter (only those).

1. ba_v3_rules.json: the numeric refusal table, each rule with value, unit, reason code, source, and pending_physician_confirmation true: plausibility for all six Base markers and HbA1c (start from plausibility_bounds.json; albumin 10 to 60 g/L); creatinine above the upper reference limit of the person's creatinine row, or declared chronic kidney disease in the patient context, gives no result (reason kidney); albumin below 30 g/L gives no result; hs-CRP above 10 mg/L is provisional (existing rule) and above 50 mg/L gives no result; ALP or GGT above 3 times the upper reference limit gives no result (the multiple is for the physician to confirm); declared pregnancy or lactation gives no result; ages from 20 to 79 (max_age 79, with a note that 84 is possible only if check B5 passes); collection method other than venous at EVA's laboratory gives no result (reason collection_method; unknown counts as not venous until the app records it); a bounded laboratory result such as '<5' resolves to the bound itself, never to half of it.
2. biological-age-v3-rules.ts: a pure function that, given the adapted inputs, the person's sex, age, context (conditions, pregnancy, lactation) and collection method, returns { eligible, reasons: [{code, marker?, detail}], provisional }. Wire it into the adapter so every refusal returns no figure with its reason codes (the adapter already has reasons such as implausible_value and duplicate_marker; extend them consistently), and the shadow record stores the reasons. Read how bounded results are stored today (lab notes comparator, src/lib/lab-bridge and process-results) and make the adapter resolve them to the bound.
3. refusals.json: one fixture per rule (inputs and expected reason) plus passing controls, and tests that run every fixture through the adapter. The tests must include albumin 0 g/L and 4.3 g/L (refused), creatinine 2.0 mg/dL in a man (refused, kidney), hs-CRP 60 mg/L (refused), age 82 (refused), pregnancy (refused), collection method unknown (refused), GGT '<5' resolving to 5.
4. Keep every existing test green; update expectations only where a rule intentionally changes behaviour, and list each such change.`

const V3 = `${COMMON}

Your task: validation-only computations on the program's harness. You own ml/biological-age/signoff/v3_validation.py, ml/biological-age/signoff/test_v3_validation.py (do not touch other files in that folder), and docs/signoff/work/v3/validation-reruns.json, ages-80-84.json, interval-sensitivity.json. Use ml/biological-age/.venv (built) and the harness modules; use at most 2 worker processes; never touch the sealed test split (read pipeline/data.py and harness/final_test_budget.py to make sure your code cannot load it, and assert that in a test).

Compute on the validation waves only, with the frozen version 3 model (models.candidates.phenoage_v3:build_a4_crp_clamp, or by loading model-v3.json; read harness/candidate.py and run_validation.py):
1. ages-80-84.json (check B5): for ages 80 to 84, per sex: n, deaths, the T3-style calibration (mean biological age minus age, with its confidence interval, as the charter defines T3), and the hazard ratio per SD of acceleration with 95% CI (Cox adjusted as T2/T8 define it). Pass rule from ACCEPTANCE-TEST.md B5: band mean within 1.5 years per sex, HR lower bound above 1.0, at least 100 deaths. Report pass or fail and every number.
2. validation-reruns.json (check B4): re-run T6, T7 and T9 on validation data or fixtures as the charter defines them, plus T11 parity (the TypeScript port against Python: reuse integration/build_ts_parity_fixture.py logic and the existing fixture in src/lib/biomarkers/__tests__/fixtures/ba-v3-python-parity.json; regenerate a fixture of at least 500 rows covering every clamp and the CRP cap into docs/signoff/work/v3/parity-fixture.json, without overwriting the existing one). Record the model_sha256 the results belong to.
3. interval-sensitivity.json: the client's 95% interval and T7's reliable change with the hs-CRP within-subject CV of 34.1% (current) and 58.9% (the EFLM hs-CRP entry), at the typical profiles, with the analytical CV of 3% marked as a placeholder until Echevarne's per-marker CVA arrives.
Write a test that the sealed split is never loaded. Report every number.`

const V2 = `${COMMON}

Your task: the display behind a flag, and hiding the old figure. You own src/lib/biomarkers/bio-age-flags.ts (new), src/components/dashboard/BiologicalAgeV3Card.tsx (new), src/lib/biomarkers/bio-age-v3-display.ts (new, pure formatting logic), src/lib/biomarkers/bio-age-v3-display.test.ts (new), docs/signoff/work/v3/display-copy.json (new), and the minimal edits needed in the files that show or send the old KDM biological age: the dashboard and lab pages under src/app/[locale]/(dashboard)/, src/lib/email/templates/results-ready.ts, src/app/api/ai/chat/route.ts (only the lines that read or show the biological age). Read docs/signoff/work/governance/wording-rules.md if it exists (another agent writes it now; otherwise follow ACCEPTANCE-TEST.md B6 and M3).

1. bio-age-flags.ts: BIO_AGE_KDM_VISIBLE and BIO_AGE_V3_VISIBLE read from the server environment, both false by default (the CEO's decision 4 in PLAN.md section 10 recommends no biological age until version 3 is released; document that the default implements the recommendation and that the CEO can flip it).
2. When BIO_AGE_KDM_VISIBLE is false, the old figure appears nowhere: dashboard (including its fallback to the stored lab figure), lab page, results email, AI chat context. Values are still computed and stored as today; only display and sending change.
3. bio-age-v3-display.ts and the card: whole years with the 95% range always; 'younger' or 'older' only when the interval excludes the chronological age; a change between two results called real only above the reliable-change threshold (read it from the model card or ba_v3_model.json; about 4.3 years); provisional marker for hs-CRP above 10 mg/L; the refusal reasons shown to the client in plain words; 'compared with US adults of your sex and age; not yet validated in Spain'; no 'validated', 'predicts', 'mortality' or risk wording. Copy in Spanish and English in display-copy.json, which also lists every flat segment of the model (hs-CRP below 2.1 mg/L, BUN below 10 mg/dL, creatinine below its floor by sex, ALP below 40 U/L, albumin above 50 g/L, HbA1c below 4.5%) in client wording, for check X2. Rendered only when BIO_AGE_V3_VISIBLE is true.
4. Tests for the formatting rules and for the hidden old figure (the email template and chat context omit it when the flag is false). Keep all existing tests green; list every expectation you changed and why.`

const V4 = `${COMMON}

Your task: the physician documents for version 3. You own docs/signoff/work/v3/signable-vs-conditional.md, replication-brief.md, reproducibility.md, spanish-centring-preregistration.md, shadow-plan.md, creatine-rule.md, and edits to ml/biological-age/PROPOSAL.md, ml/biological-age/MODEL-CARD.md and ml/biological-age/PHYSICIAN-SIGNOFF.md.

1. signable-vs-conditional.md (Spanish first, then English): every item of PHYSICIAN-SIGNOFF.md and PROPOSAL.md conditions 1 to 7 classified as 'sign now' (clinical rules, display, refusals, consistency rule, wording, calibration disclosure) or 'conditional on X', with X's acceptance criterion in numbers: the human replication (HR 1.516 within 0.005, C gain 0.0217 within 0.001, every T3 band within 0.01 years, S1 spreads within 0.01, signed attestation with software versions); the Echevarne alignment (target scale per marker = the NHANES cycle-specific methods; residual offset within 0.5 years at the typical profiles); counsel's device opinion; the shadow report with a lawful basis; the capillary study for home kits; the 80-84 rule (check B5).
2. Edit PHYSICIAN-SIGNOFF.md accordingly: split the sheet into part 1 'rules signable now' and part 2 'release conditions agreed in advance, not signed now'; add the kidney rule, collection-method gate, refusal table pointer (src/lib/biomarkers/data/ba_v3_rules.json), age 20-79 recommendation, creatine 'approve with changes' (start date or loading week, provisional flag, the individual error of 2 to 3 years stated), the consistency rule and its accepted exceptions (albumin 48-50 g/L; GGT floor removal is a ranges decision), and the label that every review behind it is AI work product.
3. MODEL-CARD.md: correct the line saying a typical woman and man read their own age against the later numbers (47.0 and 46.6 at 48) and the weighted -0.43 years; remove 'EVA's physicians' and product-facing 'prognostic' wording; qualify every 'passed every pre-registered test' with 'on a second sealed run after a diagnosed fix, under a release rule amended after an independent check'; state that no human has reproduced the numbers yet. Make the same qualification in PROPOSAL.md wherever the claim appears.
4. replication-brief.md and reproducibility.md: what an independent human biostatistician receives (public data, the one-command pipeline, expected numbers with tolerances, environment versions, the attestation form) and how to run it.
5. spanish-centring-preregistration.md: the rule written in advance: target (population-weighted Spanish adults read their own age on average, the CEO's goal), data (Spanish serum measured on Echevarne-aligned methods, re-assayed if needed), weights, age bands, tolerance 0.5 years, sample sizes (about 340 men and 410 women), applied once, checked on data not used to set it; and that at launch the copy discloses US centring.
6. shadow-plan.md: the shadow's purpose (integration check, not calibration), entry and exit criteria (for example 30 consecutive real venous results with no unexplained refusal and parity on each), what needs counsel (lawful basis, REG-8) before any production shadow.
7. creatine-rule.md: the rule, its known errors (loaded 2 g, first weeks without loading, fixed absolute rise in women), the proposed changes (start date or loading week in the context form; divisor only after 28 days or a loading week; provisional flag) as a decision for the physician.`

const VERIFY = `${COMMON}

Your task: verification of workstream 2. Other agents wrote the rules, the display, the computations and the documents. You may fix faults only in the files those agents owned (listed in docs/signoff/PLAN.md WS2 and in the files below), never ba_v3_model.json, model-v3.json or biological-age-v3.ts.
Files: src/lib/biomarkers/biological-age-v3-rules.ts, ba_v3_rules.json, biological-age-v3-adapter.ts and tests, bio-age-flags.ts, bio-age-v3-display.ts and tests, BiologicalAgeV3Card.tsx, the edited dashboard, lab page, email and chat files, ml/biological-age/signoff/v3_validation.py and its test, docs/signoff/work/v3/*.
1. Run npx tsc --noEmit -p ., npx vitest run (full suite), and the Python test; fix faults until green, without weakening tests.
   The refusal rules intentionally changed three expectations owned by other files; update them minimally and say so: src/lib/biomarkers/process-results.bio-age-v3.test.ts (the plus_hba1c case now needs a venous collection method in its source); src/lib/signoff/dsrt-checks.test.ts (lactation is now refused; the healthy persona needs a venous collection method); scripts/signoff/checks/bioage.ts (the B2 probe 'bounded_crp' needs collection_method 'venous'); scripts/signoff/checks/personas.ts and scripts/signoff/fixtures/personas.json (carry a collection method per persona, venous for Echevarne draws). Change nothing else in those files.
2. Confirm the frozen hashes (sha256 of ml/biological-age/model-v3.json content field model_sha256 equals dc60ee29...; ba_v3_model.json source hashes unchanged; git diff on those files is empty).
3. If npm run dsrt exists (another workflow builds it), run it with --only B1,B2,B3,B4,B5,B6,X1,X2 and report the results; otherwise report that it is not available yet.
4. Write docs/signoff/work/v3/ws2-status.md: what was built, test results, the B and X check results, decisions pending the physician, and anything missing.`

phase('Build')
const [v1, v3] = await parallel([
  () => agent(V1, { label: 'V1 refusal and gating rules', phase: 'Build', schema: RESULT, model: 'opus', effort: 'high' }),
  () => agent(V3, { label: 'V3 validation-only computations', phase: 'Build', schema: RESULT, model: 'opus', effort: 'high' }),
])
log(`Build: V1 ${v1 ? v1.status : 'null'}, V3 ${v3 ? v3.status : 'null'}`)
if (!v1 && !v3) return { stopped_at: 'Build' }

phase('Present')
const [v2, v4] = await parallel([
  () => agent(V2, { label: 'V2 display and hiding the old figure', phase: 'Present', schema: RESULT, model: 'opus', effort: 'high' }),
  () => agent(V4, { label: 'V4 physician documents', phase: 'Present', schema: RESULT, model: 'fable', effort: 'high' }),
])
log(`Present: V2 ${v2 ? v2.status : 'null'}, V4 ${v4 ? v4.status : 'null'}`)
if (!v2 && !v4) return { stopped_at: 'Present', v1, v3 }

phase('Verify')
const ver = await agent(VERIFY, { label: 'verify workstream 2', phase: 'Verify', schema: RESULT, model: 'opus', effort: 'high' })

return { v1, v3, v2, v4, verify: ver }
