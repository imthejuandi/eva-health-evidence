export const meta = {
  name: 'signoff-runner-round-5',
  description: 'Runner round 5 in a worktree: G1 tests that the compile is idempotent and hashes the judge prompts, G2 holds added rows to a template, E1 follows its specified scope; adversarial review',
  phases: [
    { title: 'Fix', detail: 'one engineer in its own worktree, branch signoff-runner-r5' },
    { title: 'Verify', detail: 'adversarial review; one repair pass if rejected' },
  ],
}

const SCR = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/runner-r5'
const MAIN = '/home/user/eva-health'
const BASE_COMMIT = '94fa6e67eff495187a1dbe0c32c98ce340f77f5d'
const BRANCH = 'signoff-runner-r5'

const SETUP = [
  'You work in an isolated git worktree, not in the main checkout at ' + MAIN + ', where a batch run is in progress.',
  `First: pwd; git checkout -b BRANCHNAME ${BASE_COMMIT}; if node_modules is missing, symlink ${MAIN}/node_modules. Never edit files under ${MAIN} itself, and never push.`,
].join('\n')

const SHARED = [
  'Context. EVA\'s physician sign-off programme has an acceptance test, docs/signoff/ACCEPTANCE-TEST.md (the DSRT); its runner is',
  'scripts/signoff/ (npm run dsrt -- ...; --work-dir takes a copy of docs/signoff/work); the loop tooling, compile.js included, is',
  'docs/signoff/tools/. Both were frozen at round 0; check G1 fails until the CEO approves each change, which is approvable only if',
  'it fixes a defect and lets no check pass more easily than its specification text allows. The runner change has had seven',
  'reviews: docs/signoff/work/central/runner.json holds the fix reports (round_4_repair is the latest), and runner-verify*.json the',
  'reviews; the last one is docs/signoff/work/central/runner-verify-r4-repair.json. All of it is AI work product a licensed',
  'physician reviews. Never query a database, apply a migration, send a message or call the app\'s API. Every claim comes from a',
  'command you ran or a line you read. No AI model names in files. Scratch files only under ' + SCR + '.',
].join('\n')

const TASK = [
  SETUP.replace('BRANCHNAME', BRANCH), '', SHARED, '',
  'Your files: scripts/signoff/** and src/lib/signoff/*.test.ts, and the report section "round_5" in docs/signoff/work/central/runner.json.',
  'Task:',
  '1. G1, "The compile is idempotent" (ACCEPTANCE-TEST.md line 122). The runner never tests it (runner.json, the scan finding that',
  '   cites hash.ts inputFiles). Implement it: when the seed directory is a compile output (it holds compile-report.json), rerun',
  '   docs/signoff/tools/compile.js with the same families and inputs into a temporary directory and compare every output file it',
  '   writes, byte for byte, with the seed directory\'s (the seed files, biomarker-sources.json, changes.json, CHANGES.md,',
  '   migration.sql, rollback.sql, and the reconciliation files when present). Fail each file that differs, naming it. When the',
  '   seed directory is not a compile output, report that part as blocked, never pass. Read compile-report.json for what the',
  '   compile records about its own run; do not edit compile.js. This catches any hand edit of the compile\'s outputs after the',
  '   compile, the class of the last two reviews\' findings.',
  '2. G1, "judge prompts": add docs/signoff/work/judges/lenses.json to the hashed inputs G1 compares with round 0 (it is the',
  '   frozen lens role texts of LOOP-PROMPT.md 2.3). It is new to the hash list, so G1 lists it until the CEO approves it; say so.',
  '3. G2, added rows (runner-verify-r4-repair.json, blocking finding, required change verbatim): in traceRows, take each seed row',
  '   whose database key is not in compile-baseline.js buildBaseline; rebuild its pair with pairFromLoopRow from its final row,',
  '   using as template the row pickTemplate picks among the seed\'s rows of the same marker that production has, or among',
  '   production\'s rows of the marker built with pairFromDbRow when there are none; fail each column of either file that differs',
  '   ("differs from its template row"). The review measured 0 differences on the compile\'s output.',
  '4. E1 scope. ACCEPTANCE-TEST.md line 39: "Every optimal bound, every reference bound with a non-laboratory basis, and every',
  '   age, sex or state split has a record: identifier, verbatim quote of at most 60 words containing the number, design, size,',
  '   ...". The runner (scripts/signoff/checks/evidence.ts, around line 191) requires a number in every evidence record\'s quote,',
  '   including records for class, method or pre-analytical rules, which docs/signoff/tools/lib/row-checks.js exempts. Make E1',
  '   require the number exactly for the records that support the bounds and splits the specification names, through the rows\'',
  '   evidence links, and keep every other E1 requirement. Report how many B01 E1 failures fall outside the scope; the evidence',
  '   repair of 8 November listed F01-E24, f03-E36, f04-E03, f04-E04, f04-V01 and f03-D04 as outside it.',
  'Constraints: on docs/signoff/work/compiled/B01-r3 and B01-r4, D5 and G2 keep their results; G1 adds no idempotency failure',
  '(they are unedited compile outputs; if a recompile today differs because work files changed since, compile into a scratch',
  'directory first and use that as the seed directory, and say which you used). Tests for each change, including a hand edit of',
  'an added row in the seed and the migration that G1 and G2 now catch. Run npx vitest run src/lib/signoff, npx tsc --noEmit -p .,',
  `and the DSRT. Then git add your files and git commit -m "Sign-off runner round 5: G1 tests that the compile is idempotent and hashes the judge prompts; G2 holds added rows to a template; E1 follows its specified scope". Report the worktree, branch and commit.`,
].join('\n')

const FIX_SCHEMA = { type: 'object', properties: {
  worktree: { type: 'string' }, branch: { type: 'string' }, commit: { type: 'string' },
  files_changed: { type: 'array', items: { type: 'string' } },
  fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, fix: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'fix', 'evidence'] } },
  tests: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] } },
  notes: { type: 'string' } }, required: ['worktree', 'branch', 'commit', 'files_changed', 'fixed', 'tests'] }
const VERIFY_SCHEMA = { type: 'object', properties: {
  verdict: { type: 'string', enum: ['accept', 'reject'] },
  findings: { type: 'array', items: { type: 'object', properties: { severity: { type: 'string', enum: ['blocking', 'residual'] }, file: { type: 'string' }, line: { type: 'integer' }, detail: { type: 'string' }, required_change: { type: 'string' } }, required: ['severity', 'detail', 'required_change'] } },
  tests: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] } },
  verdict_commit: { type: 'string' },
  notes: { type: 'string' } }, required: ['verdict', 'findings', 'tests'] }

const verifyPrompt = (fix, tag) => [
  SETUP.replace('BRANCHNAME', `${BRANCH}-verify${tag}`).replace(BASE_COMMIT, fix.commit), '', SHARED, '',
  `You review the runner's round 5${tag ? ' repair' : ''}. You did not write it. Diff: git diff ${BASE_COMMIT} ${fix.commit}; the whole runner change since round 0: git diff 2cec485 ${fix.commit} -- scripts/signoff.`,
  `The fix agent's task was:\n---\n${TASK.slice(SETUP.length)}\n---\nIts result: ${JSON.stringify(fix).slice(0, 5000)}`,
  '',
  'Try to break G1, G2, D5 and E1 on copies of docs/signoff/work/compiled/B01-r3 and B01-r4. Confirm each required change of this',
  'task and of runner-verify-r4-repair.json is met, each with a command. Rate each finding: "blocking" when the pack could be',
  'wrong and still pass every check, G1\'s idempotency included, through something the loop or a person could plausibly',
  'produce (the compile\'s own output, an ordinary hand edit, a decisions or verify file the validators accept); "residual" when',
  'it needs text crafted to fool a reader, an object defined outside the files, or edits to the frozen inputs themselves.',
  'Also check E1 is neither looser than its specification text nor stricter in a way that fails records the text excludes.',
  'Run npx vitest run src/lib/signoff, npx tsc --noEmit -p ., and the DSRT. Verdict "accept" if no finding is blocking.',
  `Write docs/signoff/work/central/runner-verify-r5${tag}.json, commit it on your branch, and reply with the structured result (verdict_commit: that commit).`,
].join('\n')

phase('Fix')
const fix = await agent(TASK, { label: 'fix runner r5', phase: 'Fix', schema: FIX_SCHEMA, effort: 'max', isolation: 'worktree' })
if (!fix) return { verdict: 'no_result' }
phase('Verify')
const v = await agent(verifyPrompt(fix, ''), { label: 'verify runner r5', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max', isolation: 'worktree' })
if (!v) return { verdict: 'unverified', fix }
if (v.verdict === 'accept') return { verdict: 'accept', fix, verify: v }
const blocking = v.findings.filter((f) => f.severity === 'blocking')
log(`verify runner r5: rejected, ${blocking.length} blocking; one repair pass`)
const fixRepair = await agent([
  SETUP.replace('BRANCHNAME', `${BRANCH}-repair`).replace(BASE_COMMIT, fix.commit), '', SHARED, '',
  `The reviewer rejected round 5. Your base is ${fix.commit}. Its blocking findings, verbatim:\n${JSON.stringify(blocking, null, 1)}`,
  'Address each, or show with evidence why it is wrong. Keep every earlier required change met. Add "round_5_repair" to',
  'runner.json, run the tests and the DSRT, commit on your branch, and reply with the structured result.',
].join('\n'), { label: 'repair runner r5', phase: 'Verify', schema: FIX_SCHEMA, effort: 'max', isolation: 'worktree' })
if (!fixRepair) return { verdict: 'rejected_no_repair', fix, verify: v }
const v2 = await agent(verifyPrompt(fixRepair, '-repair'), { label: 're-verify runner r5', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max', isolation: 'worktree' })
return { verdict: v2 ? v2.verdict : 'unverified', fix: fixRepair, first_fix: fix, first_verify: v, verify: v2 }
