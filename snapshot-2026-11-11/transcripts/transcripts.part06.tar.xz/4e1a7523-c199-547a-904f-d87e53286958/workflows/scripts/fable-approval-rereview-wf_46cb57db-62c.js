export const meta = {
  name: 'fable-approval-rereview',
  description: 'Fable 5.2 second review of the changed frozen files (and the app and loop changes) against the required changes of its own ruling, with challengers and an arbiter on disagreement',
  phases: [
    { title: 'Review', detail: 'one Fable 5.2 reviewer per area checks each required change is made exactly and nothing else changed' },
    { title: 'Challenge', detail: 'an adversarial Fable 5.2 reviewer per area tries to overturn each verdict' },
    { title: 'Arbitrate', detail: 'a Fable 5.2 arbiter rules on each file where reviewer and challenger disagree' },
  ],
}

const A = args
const MODEL = 'claude-fable-5-2'
const EFFORT = 'max'
const WT = A.worktree
const SCR = A.scratch

const FINDING = { type: 'object', properties: { summary: { type: 'string' }, evidence: { type: 'string' }, smallest_fix: { type: 'string' } }, required: ['summary', 'evidence', 'smallest_fix'] }
const TESTS = { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } }
const FILE_VERDICT = {
  type: 'object',
  properties: {
    file: { type: 'string' },
    sha256: { type: 'string' },
    sha256_matches: { type: 'boolean' },
    recommendation: { type: 'string', enum: ['approve', 'reject'] },
    required_change_done: { type: 'string', enum: ['yes', 'partly', 'no', 'not applicable'] },
    out_of_scope_edits: { type: 'array', items: { type: 'string' } },
    plain_rationale: { type: 'string' },
    blocking_findings: { type: 'array', items: FINDING },
    notes: { type: 'array', items: { type: 'string' } },
  },
  required: ['file', 'sha256', 'sha256_matches', 'recommendation', 'required_change_done', 'out_of_scope_edits', 'plain_rationale', 'blocking_findings', 'notes'],
}
const REVIEW = { type: 'object', properties: { area: { type: 'string' }, files: { type: 'array', items: FILE_VERDICT }, tests_run: TESTS }, required: ['area', 'files', 'tests_run'] }
const ARBITER = {
  type: 'object',
  properties: {
    file: { type: 'string' },
    sha256: { type: 'string' },
    recommendation: { type: 'string', enum: ['approve', 'reject'] },
    plain_rationale: { type: 'string' },
    standing_findings: { type: 'array', items: FINDING },
  },
  required: ['file', 'sha256', 'recommendation', 'plain_rationale', 'standing_findings'],
}

const BACKGROUND = [
  'Background.',
  '- EVA is a preventive-health app. Before launch, a licensed physician will review and sign its optimal biomarker ranges, its biological age model and its score. The Doctor Sign-off Readiness Test (DSRT), docs/signoff/ACCEPTANCE-TEST.md, is the acceptance test the material must pass first; the runner (scripts/signoff/) and the tools (docs/signoff/tools/) grade and compile it. These files were hashed at round 0 (baseline commit 7602f9d); check G1 fails while a hashed file differs without a CEO approval at its sha256.',
  '- The CEO instructed that Fable 5.2 recommends on the changed files and that its recommendations serve as the approval. On 10 November a Fable 5.2 ruling (/home/user/eva-health/docs/signoff/work/governance/fable-approval-review.json; readable summary fable-approval-review.md beside it) approved 11 files as they stood and required exact changes to 11 others, and ruled decisions CEO-1 to CEO-17 (/home/user/eva-health/docs/signoff/work/governance/central-fix-decisions.md). The reviews it rests on: /home/user/eva-health/docs/signoff/work/central/fable-approval-runner.json and fable-approval-tools.json.',
  `- The orchestrator made the required changes in a git worktree: ${WT}, branch approval-fixes-wip, commit ${A.head}. The version the ruling reviewed is commit ${A.reviewed} (the same files as on the main branch today). Your verdict decides whether each changed file is approved at its new sha256, so it carries the CEO's authority: be exact and independent.`,
].join('\n')

const STANDARD = [
  'What to decide for each file of your area:',
  '1. Required change: is the change the ruling required for this file (its required_change text in fable-approval-review.json, and the decisions it names) made exactly and correctly? Quote the requirement and point to the lines that meet it. Where the implementation departs from the wording but meets its purpose, say so and judge whether the departure matters.',
  '2. Nothing else: list every edit since the reviewed version that the requirement does not call for (out_of_scope_edits). An edit that serves the requirement directly (for example a comment or a help text the change makes stale) is in scope; anything else is not, and makes the file rejectable if it changes behaviour.',
  '3. The approval standard still holds for the whole file: no check passes more easily than the specification allows, no published text that nobody checked, correct on edge cases, no hidden way to skip a check.',
  'Recommend approve only when all three hold. A cosmetic flaw is a note, not a reason to reject. When you reject, give the smallest change that would make the file approvable.',
].join('\n')

const RULES = (dir) => [
  'How to work.',
  `- Work in ${WT}. Diff each file against the reviewed version: \`git -C ${WT} diff ${A.reviewed} ${A.head} -- <file>\`, and against round 0 for context: \`git -C ${WT} diff 7602f9d ${A.head} -- <file>\`. Check its sha256: \`sha256sum ${WT}/<file>\`; if it differs from the one listed, set sha256_matches false and reject.`,
  `- Run the tests from ${WT}: \`node --test docs/signoff/tools/test/*.test.js\` and \`npx vitest run src/lib/signoff\`; for the app, \`npx vitest run\` and \`npx tsc --noEmit\`. You may run the tools on the worktree's data, writing only under ${dir}/: for example \`node docs/signoff/tools/compile.js --out-dir ${dir}/c\` or \`npm run dsrt -- --round 99 --families f01_albumin_proteins --seed-dir <a compile output> --out ${dir}/r.json\`. The main checkout /home/user/eva-health holds the newest family files (batch B04 is running there); read them if useful, never write there.`,
  `- Read-only: do not modify, create or delete any file in either checkout, and run no git command that changes state. Scratch files only under ${dir}/ (create it with mkdir -p).`,
  '- plain_rationale: two to five sentences in plain words a CEO without a coding background can follow; technical evidence in findings, with file:line references.',
].join('\n')

function reviewPrompt(area) {
  const files = area.files.map((f) => `- ${f.file} (new sha256 ${f.sha256})`).join('\n')
  return [
    `You are the second Fable 5.2 reviewer of frozen-file changes of EVA's acceptance test, area ${area.name}.`,
    '',
    BACKGROUND,
    '',
    `Files of your area:\n${files}`,
    area.context ? `\nContext for this area: ${area.context}` : '',
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}`),
    '',
    'Reply with the structured result: one entry in files for each file listed, in the same order, with its sha256.',
  ].join('\n')
}

function challengePrompt(area, review) {
  const files = area.files.map((f) => `- ${f.file} (new sha256 ${f.sha256})`).join('\n')
  return [
    `You are the adversarial challenger of the second review of frozen-file changes of EVA's acceptance test, area ${area.name}. A reviewer gave the verdicts below. Try to overturn them: for each file it approves, hunt for a required change not made, made wrongly or only partly, an out-of-scope edit it missed, or a way a check now passes more easily or a published text goes unchecked; for each blocking finding it raised, try to refute it with evidence. A finding needs evidence: file:line, a command and its output, or a concrete input and the wrong output. Agree only after your own search finds nothing.`,
    '',
    BACKGROUND,
    '',
    `Files of your area:\n${files}`,
    area.context ? `\nContext for this area: ${area.context}` : '',
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}-challenge`),
    '',
    `The reviewer's result:\n${JSON.stringify(review, null, 1)}`,
    '',
    'Reply with the structured result: one entry in files for each file listed, in the same order, with its sha256 and your own recommendation.',
  ].join('\n')
}

function arbiterPrompt(area, file, review, challenge) {
  return [
    `You arbitrate one file of the second review of frozen-file changes of EVA's acceptance test: ${file.file} (new sha256 ${file.sha256}), area ${area.name}. The reviewer and the challenger disagree. Check every disputed point yourself in the code, run what you need, and rule approve or reject. Your ruling is recorded as the CEO's decision on this file.`,
    '',
    BACKGROUND,
    area.context ? `\nContext for this area: ${area.context}` : '',
    '',
    STANDARD,
    '',
    RULES(`${SCR}/${area.key}-arbiter`),
    '',
    `The reviewer on this file:\n${JSON.stringify(review, null, 1)}`,
    '',
    `The challenger on this file:\n${JSON.stringify(challenge, null, 1)}`,
    '',
    'Reply with the structured result.',
  ].join('\n')
}

const AREAS = A.areas
const out = await pipeline(
  AREAS,
  (area) => agent(reviewPrompt(area), { label: `rereview ${area.key}`, phase: 'Review', schema: REVIEW, model: MODEL, effort: EFFORT }),
  (review, area) => review
    ? agent(challengePrompt(area, review), { label: `challenge ${area.key}`, phase: 'Challenge', schema: REVIEW, model: MODEL, effort: EFFORT }).then((ch) => ({ review, ch }))
    : { review: null, ch: null },
  async (rc, area) => {
    const finals = []
    for (const f of area.files) {
      const r = rc.review && rc.review.files.find((x) => x.file === f.file)
      const c = rc.ch && rc.ch.files.find((x) => x.file === f.file)
      if (!r || !c) { finals.push({ file: f.file, sha256: f.sha256, verdict: 'reject', basis: 'incomplete review', reviewer: r || null, challenger: c || null }); continue }
      if (r.recommendation === c.recommendation && r.sha256_matches && c.sha256_matches) { finals.push({ file: f.file, sha256: f.sha256, verdict: r.recommendation, basis: 'reviewer and challenger agree', reviewer: r, challenger: c }); continue }
      const arb = await agent(arbiterPrompt(area, f, r, c), { label: `arbiter ${f.file.split('/').pop()}`, phase: 'Arbitrate', schema: ARBITER, model: MODEL, effort: EFFORT })
      finals.push({ file: f.file, sha256: f.sha256, verdict: arb ? arb.recommendation : 'reject', basis: arb ? 'arbiter' : 'arbiter returned nothing', reviewer: r, challenger: c, arbiter: arb })
    }
    return { area: area.key, review: rc.review, challenge: rc.ch, files: finals }
  },
)
const files = out.filter(Boolean).flatMap((a) => a.files)
log(`verdicts: ${files.map((f) => `${f.file.split('/').pop()} ${f.verdict}`).join('; ')}`)
return { head: A.head, reviewed: A.reviewed, files: files.map((f) => ({ file: f.file, sha256: f.sha256, verdict: f.verdict, basis: f.basis })), areas: out }
