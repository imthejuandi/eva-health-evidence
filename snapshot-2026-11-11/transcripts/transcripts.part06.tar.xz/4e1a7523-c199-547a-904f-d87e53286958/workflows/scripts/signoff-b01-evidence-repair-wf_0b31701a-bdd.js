export const meta = {
  name: 'signoff-b01-evidence-repair',
  description: 'Repair the B01 quotes that checks E1 and E2 flag, in an isolated worktree, without changing any number, grade or row',
  phases: [{ title: 'Repair', detail: 'one agent, three families, commits on branch signoff-b01-evidence' }],
}

const MAIN = '/home/user/eva-health'
const BASE = 'c654500'
const W = 'docs/signoff/work'
const T = 'docs/signoff/tools'
const prompt = [
  'You work in an isolated git worktree, not in the main checkout at ' + MAIN + ', where a batch run is in progress.',
  `First: pwd; git checkout -b signoff-b01-evidence ${BASE}; if node_modules is missing, symlink ${MAIN}/node_modules. Never edit files under ${MAIN} itself and never push.`,
  '',
  'Context: EVA\'s physician sign-off programme. Each biomarker family has a research file (the author\'s rows and evidence records)',
  'and a verify file (the verifier\'s verdicts and its own evidence records). Check E2 confirms every quote against the cached',
  'source text (at least 98% found by normalised match); check E1 needs each quote to contain the number it supports. All of',
  'this is AI work product a licensed physician reviews; write so he can check every claim. Never query a database, send a',
  'message or call the app\'s API. No AI model names in files.',
  '',
  'Role: the evidence-repair pass for the B01 families. You repair evidence quotes and nothing else.',
  `Your files: ${W}/research/<family>.json and ${W}/verify/<family>.json for f01_albumin_proteins, f03_kidney and f04_inflammation, and the source cache ${W}/sources-cache/ (written by the quote check).`,
  'Flagged by the last checks (docs/signoff/work/checks/<family>-r4.json):',
  '- f01_albumin_proteins: E1 on F01-E16, F01-E19, F01-E24, F01-E44 and F01-V01 (quote contains no number).',
  '- f03_kidney: E1 on f03-D04 and f03-E36. If f03-D04 sits in the decisions file, leave it and say so: the fixer owns that file.',
  '- f04_inflammation: E2 on f04-E01, f04-E03, f04-E04 and f04-V01, all citing a university mirror PDF of the 2003 CDC/AHA',
  '  statement on markers of inflammation (Pearson and colleagues, Circulation 2003), whose text the cache cannot read; E1 on f04-V01.',
  '',
  `1. For each family run node ${T}/quote-check.js on the research and the verify file (online; it fills the cache), and`,
  `   node ${T}/validate.js research <family> and verify <family>, and note every flagged quote.`,
  '2. For each flagged quote open the source through these endpoints, which need no search budget:',
  '   https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=<PMID>&rettype=abstract&retmode=text and',
  '   https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&resultType=core&format=json (full text:',
  '   https://www.ebi.ac.uk/europepmc/webservices/rest/<PMCID>/fullTextXML). Copy, exactly, the sentence that holds the number',
  '   the record supports. For the f04 records, switch the identifier to the PubMed record of the same publication (find its',
  '   PMID through the endpoints; do not guess it) and quote from its abstract or PMC text. If no source sentence holds the',
  '   number, keep the closest exact sentence and say in the record\'s notes that the number is not in the opened text.',
  '3. Change nothing else: no evidence id, row, bound, grade, verdict, message or note other than the record\'s own quote,',
  '   identifier and a short note. Never raise a grade.',
  '4. Re-run the quote check and both validators for each family; fix every error.',
  '5. Prove the scope: for each changed file, a script that compares the old (git show ' + BASE + ':<path>) and the new JSON',
  '   and lists every changed path. Only evidence-record quote, identifier and notes fields may differ.',
  `6. git add the changed research, verify and sources-cache files; git commit -m "Sign-off programme: B01 evidence repair: quotes that E1 and E2 flagged, copied from the PubMed or Europe PMC record". Report the worktree, branch, commit, and per family the quote-check and E1 counts before and after.`,
].join('\n')

const SCHEMA = { type: 'object', properties: {
  worktree: { type: 'string' }, branch: { type: 'string' }, commit: { type: 'string' },
  families: { type: 'array', items: { type: 'object', properties: {
    family: { type: 'string' }, e2_before: { type: 'string' }, e2_after: { type: 'string' }, e1_before: { type: 'integer' }, e1_after: { type: 'integer' },
    changed_paths: { type: 'array', items: { type: 'string' } }, left: { type: 'array', items: { type: 'string' } } },
    required: ['family', 'e2_before', 'e2_after', 'e1_before', 'e1_after', 'changed_paths', 'left'] } },
  notes: { type: 'string' } }, required: ['worktree', 'branch', 'commit', 'families'] }

phase('Repair')
const r = await agent(prompt, { label: 'evidence repair B01', phase: 'Repair', schema: SCHEMA, effort: 'max', isolation: 'worktree' })
return r
