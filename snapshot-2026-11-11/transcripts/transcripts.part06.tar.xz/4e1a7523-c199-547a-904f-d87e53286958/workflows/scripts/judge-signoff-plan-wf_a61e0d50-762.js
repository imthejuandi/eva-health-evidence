export const meta = {
  name: 'judge-signoff-plan',
  description: 'Five independent expert judges critique the physician sign-off readiness plan',
  phases: [{ title: 'Judge', detail: 'five lenses in parallel, most capable model, maximum effort' }],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/plan'

const COMMON = `You are one of five independent judges of a plan. Today is 5 November 2026.

Read the plan first: ${SCRATCH}/PLAN-draft.md

Context: EVA Health is a Spanish preventive and longevity medicine startup that has not launched. Clients get a 13-test serum Base Panel from the partner laboratory Echevarne, can upload other laboratories' results, and see each biomarker as optimal, in range or out of range, an EVA score from 1 to 100, and a biological age. Production holds only test uploads from the founders' friends. The CEO wants one pack a licensed physician can sign with no changes before launch, covering: (1) optimal levels per biomarker, sex and age group, backed by clinical data and coherent on their own and together; (2) the biological age model, version 3, as close to production as possible; (3) the EVA score consistent with both, so the score and the biological age agree whenever a value is not optimal. The CEO asked for a self-improving loop with a test the result must pass, with no timeouts and no endless loop. Work is done by AI agents in Workflow scripts (parallel subagents, bounded loops, resumable from a journal); the most capable model is available and cost is not a constraint.

Repository: /home/user/eva-health, branch claude/wonderful-meitner-l4g7p5. Useful files:
- supabase/seed-data/biomarker-ranges-en.json and rangos-biomarcadores-es.json (173 rows, 108 biomarkers), supabase/seed-data/biomarker-sources.json
- docs/biomarker-evidence/README.md, docs/biomarker-evidence/longevity/README.md, brief.md, verify-brief.md, GATE-1-DECISIONS.md, THREE-CATEGORIES.md, CONSISTENCY.md, SCORE-BEFORE-AFTER.md (the September evidence reviews)
- src/lib/biomarkers/longevity-score.ts (score v1 and v2), zone-classifier.ts, reference-row.ts
- ml/biological-age/PROPOSAL.md, MODEL-CARD.md, CHARTER.md, PHYSICIAN-SIGNOFF.md, REPORT.md; src/lib/biomarkers/biological-age-v3.ts and biological-age-v3-adapter.ts; src/lib/biomarkers/data/ba_v3_model.json
- docs/audit/2026-11-03-cmo-reassessment.md and docs/audit/2026-11-03-cmo-reassessment-findings.md (the latest reassessment)

Rules: read-only. Do not edit, commit or push anything in the repo; do not run SQL or any database tool; do not send email. You may write scratch files only under ${SCRATCH}/judges/. You may use web search to check standards and guidance; cite URLs. Ground every point in a file you read or a source you found; say which.

Judge hard. The goal is the best possible result, not a polite review. Prefer concrete changes over general advice: what to add, remove or reorder in the plan, which acceptance-test checks to add or tighten, with pass thresholds. Up to 12 improvements, ranked.`

const SCHEMA = {
  type: 'object',
  properties: {
    judge: { type: 'string' },
    overall_score: { type: 'number', description: '1 to 10' },
    would_approve_plan_as_is: { type: 'boolean' },
    summary: { type: 'string', description: '3 to 6 sentences' },
    blocking_issues: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, why: { type: 'string' }, fix: { type: 'string' }, evidence: { type: 'array', items: { type: 'string' } } }, required: ['title', 'why', 'fix', 'evidence'] } },
    improvements: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, change: { type: 'string' }, priority: { type: 'string', enum: ['must', 'should', 'could'] }, evidence: { type: 'array', items: { type: 'string' } } }, required: ['title', 'change', 'priority'] } },
    acceptance_test_changes: { type: 'array', items: { type: 'object', properties: { check: { type: 'string', description: 'existing id such as A4, or NEW' }, change: { type: 'string' }, pass_threshold: { type: 'string' }, why: { type: 'string' } }, required: ['check', 'change', 'why'] } },
    loop_design_changes: { type: 'array', items: { type: 'string' } },
    missing_scope: { type: 'array', items: { type: 'string' } },
    risks: { type: 'array', items: { type: 'object', properties: { risk: { type: 'string' }, mitigation: { type: 'string' } }, required: ['risk', 'mitigation'] } },
  },
  required: ['judge', 'overall_score', 'would_approve_plan_as_is', 'summary', 'blocking_issues', 'improvements', 'acceptance_test_changes', 'loop_design_changes', 'missing_scope', 'risks'],
}

const JUDGES = [
  { key: 'longevity-physician', lens: `Your lens: a senior physician in preventive and longevity medicine who will be asked to sign this pack. Would the plan produce optimal targets that are clinically sensible, safe, not over-medicalising, appropriate by sex and age including older adults, menopause and pregnancy, and honest about evidence? Are the right biomarkers getting age bands? Is anything a signing physician would insist on missing, for example critical limits, the meaning of each category for a client, follow-up advice, and what the score and biological age should never say? Check a sample of the current rows in the seed file to ground your view.` },
  { key: 'clinical-biochemist', lens: `Your lens: a clinical biochemist and laboratory medicine specialist. Judge the plan's handling of reference intervals versus decision limits, units and conversions, Echevarne's methods and the risk that EVA's optimal bands assume different assay methods (albumin BCG versus BCP, enzymatic versus Jaffe creatinine, standardised HbA1c), biological variation and reference change values for "change over time", critical limits practice (for example EFLM and ISO 15189 guidance), calculated metrics, fasting state, capillary home-kit samples, and pre-analytical issues. Check the seed rows and the v3 model file for concrete problems the plan would or would not catch.` },
  { key: 'biostatistician', lens: `Your lens: an epidemiologist and biostatistician. Judge the evidence standard and grading, how optimal bands are derived from dose-response outcome data, how age groups are justified, the population sense check, the version 3 validation and what the plan must still do before a physician can rely on it (sealed test reuse, ages 80 to 84, calibration in Spain, replication by a human statistician), the consistency rule between score and biological age as a mathematical property, and whether the acceptance test can be gamed by the agents that are tested against it. Propose stronger, measurable pass criteria.` },
  { key: 'clinical-governance', lens: `Your lens: a Spanish physician responsible for clinical governance and patient safety who must be able to defend this pack. Judge what a signing physician is accountable for, how the pack documents decisions, versions and change control, how disagreements and uncertainty are presented to him, what he must not be asked to sign, the client wording rules, safety-netting, the parallel launch track, and whether the plan's handover format would let a busy physician review it in a few sessions. Check the reassessment documents for items the plan dropped.` },
  { key: 'agentic-delivery', lens: `Your lens: an expert in running large AI-agent programmes with Workflow scripts: parallel subagents, bounded loops, structured outputs, resumable journals, judges and fixers. Judge feasibility and design: task sizing so no agent times out, how fixers avoid conflicting edits on the same files, how state and evidence files are organised, how the loop avoids reward hacking against its own test, how judge independence is protected, how progress is measured each round, the stop rules, model and effort allocation, the order of workstreams, and how the orchestrator verifies agent output. Propose the concrete loop structure, the file layout and the round limits you would use.` },
]

phase('Judge')
const results = await parallel(JUDGES.map(j => () =>
  agent(`${COMMON}\n\n${j.lens}`, { label: `judge:${j.key}`, phase: 'Judge', schema: SCHEMA, model: 'fable', effort: 'max' })
))
const ok = results.filter(Boolean)
const missing = JUDGES.filter((j, i) => !results[i]).map(j => j.key)
if (missing.length) log(`Judges with no result: ${missing.join(', ')}`)
return { judges: ok, missing }
