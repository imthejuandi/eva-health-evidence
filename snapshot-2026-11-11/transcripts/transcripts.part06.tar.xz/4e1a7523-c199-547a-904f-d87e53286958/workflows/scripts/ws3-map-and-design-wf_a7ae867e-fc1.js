export const meta = {
  name: 'ws3-map-and-design',
  description: 'Workstream 3: map the score engine, classification paths and their acceptance checks, then design the change set (read-only)',
  phases: [
    { title: 'Map', detail: 'three readers: score engine (S1-S6), classification and limits (K1, L1, L2, C1, C2, P1-P3), personas and cross-checks (Q1, X1, X2, N1)' },
    { title: 'Design', detail: 'one designer merges the maps into ordered work packages with decisions and tests' },
  ],
}

const REPO = '/home/user/eva-health'
const SCR = args.scratch

const CHECK_MAP = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    checks: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          spec: { type: 'string', description: 'the acceptance-test row, quoted' },
          runner_tests: { type: 'string', description: 'what the runner actually tests, with file:line' },
          runner_gaps: { type: 'array', items: { type: 'string' }, description: 'ways the runner passes more easily than the spec allows, or fails on something the spec does not ask; evidence' },
          status_today: { type: 'string', description: 'status and summary from your own DSRT run' },
          root_causes: { type: 'array', items: { type: 'object', properties: { cause: { type: 'string' }, evidence: { type: 'string' }, owner: { type: 'string', enum: ['app code', 'governance file', 'family data (WS1)', 'runner', 'harness or fixture', 'CEO decision'] } }, required: ['cause', 'evidence', 'owner'] } },
          proposed_changes: { type: 'array', items: { type: 'object', properties: { what: { type: 'string' }, files: { type: 'array', items: { type: 'string' } }, tests: { type: 'string' }, client_visible_effect: { type: 'string' }, needs_db_change: { type: 'boolean' }, depends_on_final_ranges: { type: 'boolean' } }, required: ['what', 'files', 'tests', 'client_visible_effect', 'needs_db_change', 'depends_on_final_ranges'] } },
          decisions_needed: { type: 'array', items: { type: 'object', properties: { question: { type: 'string' }, options: { type: 'array', items: { type: 'string' } }, recommendation: { type: 'string' }, why: { type: 'string' } }, required: ['question', 'options', 'recommendation', 'why'] } },
        },
        required: ['id', 'spec', 'runner_tests', 'runner_gaps', 'status_today', 'root_causes', 'proposed_changes', 'decisions_needed'],
      },
    },
    cross_cutting: { type: 'array', items: { type: 'string' } },
    files_read: { type: 'array', items: { type: 'string' } },
  },
  required: ['area', 'checks', 'cross_cutting', 'files_read'],
}

const COMMON = [
  'Context. EVA is a preventive-health app (Next.js, TypeScript, Supabase). Before launch a licensed physician reviews and signs its optimal biomarker ranges, its biological age model (version 3) and its EVA score. The Doctor Sign-off Readiness Test (DSRT), docs/signoff/ACCEPTANCE-TEST.md, is the acceptance test the material must pass; its runner is scripts/signoff/ (checks in scripts/signoff/checks/*.ts, run with `npx tsx scripts/signoff/dsrt.ts`). The plan is docs/signoff/PLAN.md (section 4 definitions, section 5 evidence standard, section 8 workstreams). Workstream 1 (ranges by family) is still running in batches; workstream 2 (biological age version 3) is done; workstream 3 is the score and its consistency with the ranges and the biological age. Governance inputs live in docs/signoff/work/governance/ (marker-classes.json, critical-limits.json, action-limits.json, state-rules.md, base-panel.md, decision-register.md, hazard-log.md, wording-rules.md); known central issues in docs/signoff/work/central/known-issues.md; decisions CEO-1 to CEO-17 in docs/signoff/work/governance/central-fix-decisions.md.',
  `Work read-only in ${REPO}: do not modify, create or delete any file in the repository, run no git command that changes state, query no database, send nothing. Scratch files only under ${SCR}/ (mkdir -p). Run the checks of your area yourself on the latest batch compile: \`npx tsx scripts/signoff/dsrt.ts --round 9 --only <ids comma-separated> --seed-dir docs/signoff/work/compiled/B05-r2 --out ${SCR}/<area>.json\` from ${REPO}, and read the failures in the output file. The app's own unit tests: \`npx vitest run <path>\`.`,
  'Constraints the design must respect: no database migration applied, no recalculation or backfill of stored results, no data writes (the CEO: "until we have them final don\'t reprocess anything"); staging before production; no patient-table queries (GDPR). Code changes on the branch are allowed. The frozen acceptance-test files (the runner, thresholds, docs/signoff/ACCEPTANCE-TEST.md) change only with a CEO approval; say so when a change touches them. Clinical numbers come from the families (workstream 1) and the governance files, never from code constants invented here.',
  'For each check: quote its spec row; say exactly what the runner tests (file:line) and any gap where it passes more easily than the spec allows; report today\'s status from your own run; give each root cause with evidence and an owner; propose concrete changes (files and functions, the tests that prove them, the effect a client would see, whether a DB change is needed, whether it depends on the final ranges); list decisions the CEO must take, with options and a recommendation. Be exact; cite file:line. Do not propose loosening a check.',
].join('\n\n')

const AREAS = [
  { key: 'score', prompt: `Area: the score engine, checks S1 to S6 (and their links to X1 and Q1). Start from src/lib/biomarkers/longevity-score.ts, process-results.ts (the score parts), engine-inputs.ts, index.ts and their tests (longevity-score*.test.ts, process-results.score.test.ts); scripts/signoff/checks/score.ts; docs/signoff/work/governance/marker-classes.json; the S rows of ACCEPTANCE-TEST.md and PLAN.md's definitions of marker classes, redundancy groups and evidence-grade weights. Today's summaries: S1 fail "8 lines still reference score v1 or its switch"; S2 fail "18 non-class-a markers scored of 37 scored; 3 class-a markers scored although may_be_scored is false"; S3 fail "10 double-counted groups on the fixture panels (engine has 2 redundancy groups)"; S4 blocked "docs/signoff/work/score/weights.json is missing"; S5 fail "299 property violations: 298 of 1000 critical panels reach Elite"; S6 blocked "docs/signoff/work/score/population-validity.json is missing". Also find every place the app reads or displays the score (dashboard, emails, API routes) so a change of engine reaches all of them, and how a stored score is recomputed (it must not be recomputed now).` },
  { key: 'classify', prompt: `Area: classification and limits, checks K1, L1, L2, C1, C2, P1, P2 and P3. Start from src/lib/biomarkers/zone-classifier.ts, reference-row.ts, bounded-result.ts, zone-config.ts, process-results.ts (classification), src/lib/patient-context/ (states such as pregnancy and lactation, fasting), the upload and admin paths named in known issue C-06 (src/app/api/lab-results/upload*, the admin manual-entry route, src/lib/lab-provider/manual.ts); the runner files scripts/signoff/checks/consistency.ts (K1), limits.ts (L1, L2), coverage.ts (C1, C2, C3), preanalytical.ts (P1, P2, P3); docs/signoff/work/governance/critical-limits.json, action-limits.json, state-rules.md. Today's summaries: K1 fail "6 opposite-category patterns and 9 one-step patterns (0 with an accepted reason) over 12061 evaluations"; L1 fail "26 of 26 analytes complete; 2 classifier lines derive 'critical' from reference limits"; L2 fail "0 of 17 action-limit entries complete; 7 required entries checked"; C1 fail "2 labelled picks by age proxy, 4 unreachable rows"; C2 blocked "docs/signoff/work/checks/state-fixtures-result.json (state fixture results from the harness) is missing"; P1 fail "3 of 4 pre-analytical inputs missing in the app"; P2 blocked "docs/signoff/work/rcv.json is missing"; P3 fail "3 app paths that classify or hand on a result without its comparator". Separate what the app must change from what the families (workstream 1) or the governance files must supply.` },
  { key: 'personas', prompt: `Area: personas, population and cross-consistency, checks Q1, X1, X2 and N1 (and how they depend on S1-S6, K1, L1, C2). Start from scripts/signoff/checks/personas.ts (Q1), consistency.ts (X1, X2), population.ts (N1); the biological age version 3 code (src/lib/biomarkers/biological-age-v3*.ts, bio-age-v3-display.ts, bio-age-flags.ts) and ml/biological-age/ where the runner reads it; the NHANES material under docs/signoff/work/nhanes/; the persona definitions the runner uses. Today's summaries: Q1 fail "42 personas: 36 healthy see a critical message; 4 pregnant or lactating see an optimal category, score or biological age"; X1 fail "8 violation segments outside accepted exceptions (0 excepted of 0 accepted, cap 2) over 26 scans"; X2 pass "6 of 6 flat segments documented"; N1 fail "75 unresolved population rules over 128 marker, sex and age-band entries". For each failing persona or segment, find whether the cause is the classifier, the score engine, the ranges (families) or the persona definition, with evidence.` },
]

phase('Map')
const maps = await parallel(AREAS.map((a) => () => agent(`You map one area of EVA's workstream 3 for the orchestrator.\n\n${COMMON}\n\n${a.prompt}\n\nReply with the structured result (area "${a.key}").`, { label: `map ${a.key}`, phase: 'Map', schema: CHECK_MAP })))
const got = maps.filter(Boolean)
log(`maps returned: ${got.map((m) => m.area).join(', ')}${got.length < AREAS.length ? `; missing ${AREAS.length - got.length}` : ''}`)

const DESIGN = {
  type: 'object',
  properties: {
    summary: { type: 'string' },
    work_packages: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          title: { type: 'string' },
          checks_turned_green: { type: 'array', items: { type: 'string' } },
          owner: { type: 'string' },
          files: { type: 'array', items: { type: 'string' } },
          steps: { type: 'array', items: { type: 'string' } },
          tests: { type: 'array', items: { type: 'string' } },
          client_visible_effect: { type: 'string' },
          touches_frozen_files: { type: 'boolean' },
          needs_db_change: { type: 'boolean' },
          depends_on: { type: 'array', items: { type: 'string' } },
          can_start_before_final_ranges: { type: 'boolean' },
          risk: { type: 'string' },
          size: { type: 'string', enum: ['small', 'medium', 'large'] },
        },
        required: ['id', 'title', 'checks_turned_green', 'owner', 'files', 'steps', 'tests', 'client_visible_effect', 'touches_frozen_files', 'needs_db_change', 'depends_on', 'can_start_before_final_ranges', 'risk', 'size'],
      },
    },
    decisions: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, question: { type: 'string' }, options: { type: 'array', items: { type: 'string' } }, recommendation: { type: 'string' }, why: { type: 'string' }, blocks: { type: 'array', items: { type: 'string' } } }, required: ['id', 'question', 'options', 'recommendation', 'why', 'blocks'] } },
    runner_gaps: { type: 'array', items: { type: 'string' } },
    order: { type: 'array', items: { type: 'string' } },
    open_questions: { type: 'array', items: { type: 'string' } },
  },
  required: ['summary', 'work_packages', 'decisions', 'runner_gaps', 'order', 'open_questions'],
}

phase('Design')
const design = await agent([
  'You are the design lead for EVA\'s workstream 3 (the score and its consistency with the ranges and the biological age). Three readers mapped the area; their maps are below. Turn them into an ordered set of work packages the orchestrator can implement and test, each small enough for one implementer in an isolated worktree, with the acceptance checks it turns green. Verify any claim you rely on in the repository yourself before you build on it; where readers disagree, check and say which is right.',
  COMMON,
  'Rules for the design: (1) app code first where it does not depend on the final ranges (one score engine, class gating, redundancy groups, critical tier from the critical-limits table, state handling, comparator paths), with tests; (2) governance files the orchestrator writes (weights mapping, rcv, action limits) only from sources already in the repository or marked as placeholders the checks keep failing on; (3) family content belongs to workstream 1; (4) list each CEO decision with options and a recommendation; (5) no database change is applied; if one is needed, the package writes the migration file only and says so; (6) mark every package that touches a frozen acceptance-test file.',
  `Maps:\n${JSON.stringify(got, null, 1)}`,
  'Reply with the structured result.',
].join('\n\n'), { label: 'design ws3', phase: 'Design', schema: DESIGN })

return { maps: got, design }
