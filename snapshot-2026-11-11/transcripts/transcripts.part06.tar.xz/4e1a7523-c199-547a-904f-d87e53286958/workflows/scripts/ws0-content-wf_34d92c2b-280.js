export const meta = {
  name: 'ws0-content',
  description: 'Workstream 0 clinical content: governance drafts, marker classes, state rules, critical and action limits, judge lenses, family inputs, NHANES distributions',
  phases: [
    { title: 'Drafts', detail: 'governance documents and clinical rule drafts for physician session 1' },
    { title: 'Inputs', detail: 'family input files and NHANES distributions' },
    { title: 'Limits', detail: 'critical and action limits with sources' },
    { title: 'Refresh', detail: 'rebuild family inputs with every new file' },
  ],
}

const ROOT = '/home/user/eva-health'
const COMMON = `You work in EVA Health's physician sign-off programme. Repository ${ROOT}, branch claude/wonderful-meitner-l4g7p5 (checked out). Today is ${args.today}. EVA is a Spanish preventive and longevity medicine startup that has not launched; clients get a 13-test serum Base Panel from the partner laboratory Echevarne (sold as a mailed home kit; venous clinic draws are the planned first channel for version 3), can upload other laboratories' results, and see each biomarker as optimal, in range or out of range, an EVA score and a biological age (version 3, frozen).

Read first: docs/signoff/PLAN.md, docs/signoff/ACCEPTANCE-TEST.md, docs/signoff/LOOP-PROMPT.md, docs/signoff/work/families.json, and the reassessment docs/audit/2026-11-03-cmo-reassessment.md. The judges' review of the plan is in docs/signoff/work/plan-judges.json: it contains concrete material you should use (for example the 75 'prompt medical attention' messages, the pregnancy and menopause rules, the critical-limit analyte list, the marker classes, the benign variants such as Duffy-null neutrophil counts, the Echevarne interval deviations).

Rules:
- Write ONLY the files you are told you own. Other agents write other files at the same time. Do not commit or push. Do not edit the plan documents, src/, supabase/ or scripts/.
- No database, no SQL, no emails, no app API calls.
- Every clinical number comes from a source you opened in this task (PubMed or Europe PMC abstract via https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=<PMID>&rettype=abstract&retmode=text or https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&resultType=core&format=json, PMC full text, or a guideline page), cited with identifier and a verbatim quote; nothing from memory. WebSearch at most the cap in your task.
- Everything you write is AI work product for a licensed physician to review; say so at the top of each document and write so he can check every claim. Spanish documents are the signed version; English is the translation.
- Work incrementally, write files as soon as they are usable, aim to finish in about 30 minutes; if short of time, stop at a consistent state and list what is missing.

Resuming: an earlier run of this same task was stopped by an account usage limit. Some files you own may already exist from it. Read them first, keep what is correct, and complete the task; do not start over and do not delete files other agents own.`

const RESULT = {
  type: 'object',
  properties: {
    files_written: { type: 'array', items: { type: 'string' } },
    commands_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, result: { type: 'string' } }, required: ['command', 'result'] } },
    status: { type: 'string', enum: ['complete', 'partial'] },
    missing: { type: 'array', items: { type: 'string' } },
    searches_used: { type: 'number' },
    notes: { type: 'string' },
  },
  required: ['files_written', 'commands_run', 'status', 'missing', 'searches_used', 'notes'],
}

const T7A = `${COMMON}

Role: EVA's acting CMO drafting the governance documents for the physician's first session. You own docs/signoff/work/governance/wording-rules.md, cover-scope.md, change-control.md, decision-register.md, hazard-log.md, launch-track.md. WebSearch cap 10.

1. wording-rules.md ('Normas de redacción para el cliente', Spanish first, English translation): the client-wording rulebook. Allowed and forbidden lexicon per tier; no disease label applied to the client; no individual risk, prognosis or mortality wording; no prescription drug or supplement dose; 'crítico/critical', 'atención médica pronta/prompt medical attention', 'inmediato/immediate', 'urgencias/emergency' only in the critical tier; second person; no clinician imperatives ('evaluar', 'descartar', 'consider screening'); the four elements of every out-of-range message (meaning; common benign or spurious causes; confirmation or repeat rule; who to see and how soon: routine / soon / today); the standard safety-net sentence that closes every out-of-range message; the pregnancy note; the trend rule (no 'improving/worsening' or 'tendiendo' below the reference change value or from a single value); biological age and score wording rules from PLAN.md and the acceptance test (95% range always, younger/older only when the interval excludes the age, no 'validated', 'predicts', 'mortality'). Include a fenced json block named banned_terms with, per language (es, en) and tier (any, non_critical), the exact terms and regexes a script can scan for; the DSRT check M3 parses that block. Base the lexicon on the current texts: scan supabase/seed-data/*.json messages and src/lib/biomarkers/zone-config.ts, src/components/dashboard/MedicalDisclaimer.tsx, src/lib/email/templates/*.ts and list today's offending phrases with counts at the end.
2. cover-scope.md ('Alcance de la firma', Spanish then English): the physician's role (Model A: approves product rules and releases, has a veto, is incident lead for clinical content, does not act on individual clients' results; the alternative Model B needs counsel and a health-service authorisation), what his signature covers (the artefacts listed by name, with a placeholder for their SHA-256 from the manifest), what it does not cover (launch, AI text, individual results, the items still conditional), the statement that every review in the pack is AI-generated and that judge verdicts are 'AI pre-review', and the signature block (name, colegiado number, date).
3. change-control.md: after signature, any change to a bound, message, weight, prompt, model or rule reopens the signature for that family or part only, through a reviewed pull request with the decision register entry; emergency changes; versioning (rules-version id such as ranges 2026.11, score 2.0, v3 dc60ee29) on every stored figure.
4. decision-register.md: the template (id, change, evidence, risk class, approver name, role, colegiado, date, 'AI-generated review' label) and the entries known today: the CEO decisions of 29 and 30 October (version 3; creatinine as the kidney marker, cystatin C and laboratory eGFR excluded, creatine warning and dose adjustment), Gate 1 of 25 September (ApoB, LDL-C, non-HDL-C, HOMA-IR, vitamin D, white-cell percentages, labels), the 23 to 29 September production changes applied without a physician (from docs/biomarker-evidence/snapshots/APPLIED.md), each marked 'pending physician countersignature'.
5. hazard-log.md: ISO 14971-style, one row per hazard with cause, harm, severity, probability, control, verification, residual risk, owner, status. Seed it from the reassessment and the plan judges: fructosamine on the wrong scale in the live biological age, vitamin D unit error in the old figure, laboratory eGFR weight, cystatin C substitution, albumin 0 accepted by version 3, duplicate rows, stuck labs and duplicated values, no critical tier or call path, AI prompts naming prescription drugs and doses, 'prompt medical attention' on non-critical values, pregnancy not handled, capillary samples not validated, method offsets at Echevarne, Duffy-null and other benign variants flagged as abnormal, over-medicalisation of older adults, trend wording within noise, misleading public claims.
6. launch-track.md: the items outside the pack with owner and status (website claims, safe mode, Echevarne contract and call path and methods letter, AI prompts hidden until signed, counsel lots, backups and MFA, DPIA, incident and complaint procedures, production reconciliation), and the statement that the pack's signature does not open the service.`

const T7B = `${COMMON}

Role: EVA's acting CMO drafting the clinical rule sets. You own docs/signoff/work/governance/marker-classes.json, state-rules.md, base-panel.md, docs/signoff/work/judges/lenses.json, docs/signoff/work/cold-reader-questions.json. WebSearch cap 15.

1. marker-classes.json: for every marker key in docs/signoff/work/families.json (126 keys) plus the two non-rows, a draft class (a modifiable risk marker with outcome evidence; b fixed or genetic; c screening or action-threshold; d descriptive or state hormone; e reference only), a one-sentence reason, and whether it may be scored. These are drafts the family auditors confirm or change with evidence; mark each 'draft'. Use the judges' material in plan-judges.json (J1's five classes) and the seed rows.
2. state-rules.md (Spanish then English): the physiological-state rules of PLAN.md section 4 made precise for the app: pregnancy (by trimester when known) and lactation; perimenopause and postmenopause from the record with age 50 as the stated fallback; hormone therapy and oral contraception and the markers they move (SHBG, estradiol, TSH, fT4, hs-CRP, triglycerides, others with sources); cycle-phase rows; what the app shows in each state (laboratory interval only, no optimal, no score, no biological age, fixed note); the recorded fields in src/lib/patient-context/options.ts the rules read; and the benign variants (Duffy-null associated neutrophil count, Gilbert syndrome, thalassaemia trait, race-free CKD-EPI 2021) with their effect on messages. Cite sources for each numeric statement (for example WHO haemoglobin thresholds in pregnancy, ATA 2017 TSH in pregnancy, the Duffy-null neutrophil reference range).
3. base-panel.md (Spanish then English): the 13 tests EVA orders (from src/lib/lab-bridge/panel-codes.ts), the clinical rationale per test, what the panel does not test (glucose, HbA1c, thyroid, blood count) and what follows (the copy must state the panel is not a diabetes screen; fructosamine not scored until Echevarne confirms its method), the venous option with HbA1c against the home kit, and the decision the physician is asked to take, with options and a recommendation.
4. lenses.json: the six judge role texts J1-J6 named in LOOP-PROMPT.md section 2.3, each about 120 to 200 words, sharp and specific to what that specialist would refuse to sign, including the blocking criteria fixed in advance (unsafe wording, wrong evidence class, cross-marker contradiction, state or age gap, population share outside limits, missing critical or action limit, numbers that disagree). These are frozen at round 0.
5. cold-reader-questions.json: the 12 fixed questions of check G7 (what am I signing; what am I not signing; my role; where is the evidence for a given bound; what changes against production; which decisions are open; who receives a critical value; what the AI label means; what happens in pregnancy; what version 3 may and may not say; what is conditional and on what; how a change after signature is handled), each with the pack section expected to answer it.`

const T1 = `${COMMON}

Role: data engineer. You own docs/signoff/tools/build-inputs.js, docs/signoff/tools/inputs/*.js (helpers, if any), docs/signoff/tools/test/build-inputs.test.js, and docs/signoff/work/inputs/*.json. No WebSearch needed.

build-inputs.js (CommonJS, deterministic, no timestamps) writes docs/signoff/work/inputs/<family>.json for every family in families.json, containing:
- the family's rows from both seed files (supabase/seed-data/biomarker-ranges-en.json and rangos-biomarcadores-es.json, matched by the seeder's key rule slugify(name) in src/lib/biomarkers/seed-references.ts), with their index, and the production snapshot rows for the same keys (docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json) plus a note of later applied changes from APPLIED.md;
- for each key, the Echevarne catalogue entries (docs/vendor/echevarne/catalogo-2026-08-25.tsv, matched through the code map in src/lib/lab-provider/echevarne.ts): code, test name, unit, reference interval and age or sex bands, method (TÉCNICA), specimen;
- the September evidence for each key: the paths and the parsed content of docs/biomarker-evidence/research/*.json, verify/*.json, docs/biomarker-evidence/longevity/research/*.json and verify/*.json whose keys cover the marker (find the mapping inside those files), and the entry in supabase/seed-data/biomarker-sources.json;
- the score facts: whether the score v2 uses the key (REVIEWED_ROW_KEY in src/lib/biomarkers/longevity-score.ts) and its tier (BIOMARKER_TIER);
- for version 3 markers (families.json v3_markers): the clamp, transform, linear weight per tier from src/lib/biomarkers/data/ba_v3_model.json, the plausibility bounds from src/lib/biomarkers/data/plausibility_bounds.json, and today's consistency failures (albumin 48-50 g/L rewarded because the clamp is 5.0 g/dL; GGT below 5 U/L with no floor);
- the locked decisions (PLAN.md section 2) that touch the family;
- NHANES distributions for the family's keys from docs/signoff/work/nhanes/distributions.json if it exists (another agent is producing it; leave the field null with a note if absent; the orchestrator re-runs the builder later);
- governance pointers: wording-rules.md, state-rules.md, marker-classes.json entries for the keys if they exist.
Also write docs/signoff/work/inputs/_index.json with per-family counts and missing pieces. Test with node --test (a family file has every key of its family; deterministic output). Run it and report counts and any key that has no seed row, no Echevarne entry or no September evidence.`

const T2 = `${COMMON}

Role: biostatistician. You own ml/biological-age/signoff/ (new folder: nhanes_distributions.py, README.md, test_nhanes_distributions.py) and docs/signoff/work/nhanes/distributions.json. No WebSearch needed. Use the program's virtual environment ml/biological-age/.venv (already built) and its data loaders (ml/biological-age/pipeline/data.py, units.py); read ml/biological-age/README.md and CHARTER.md for the data and splits. Never touch the sealed test split's outcomes; you need no mortality at all.

nhanes_distributions.py computes, for every EVA marker NHANES measures in the program's data (map columns to EVA keys and EVA units with pipeline/units.py), on NHANES 2015-2018 (waves 9-10) and, separately, on the validation waves, among healthy adults aged 20-79 (define healthy with the variables available and write the definition: not pregnant, no diagnosed diabetes and HbA1c below 6.5%, no other exclusions you cannot apply), by sex and age band (20-39, 40-59, 60-69, 70-79), survey-weighted where weights are available (state it): n, weighted percentiles 1, 2.5, 5, 10, 25, 50, 75, 90, 95, 97.5, 99, and for EVA's current rows (seed, picked as the app picks: the row for that sex and age band) the share below the normal low, inside the optimal band, above the normal high. Record known method notes (NHANES albumin by bromocresol purple; the CDC 2017-2018 analyser change with its bridging equations, BIOPRO_J) and flag markers whose EVA band would shift by more than 10 points under the documented offsets. Write docs/signoff/work/nhanes/distributions.json (deterministic, sorted, rounded) and a README with the definitions. Test with pytest-style asserts runnable as .venv/bin/python -m pytest if pytest exists, else a plain script; run it and report the markers covered and the bands with shares outside 2-15% (reference) or below 10% inside optimal.`

const T7C = `${COMMON}

Role: a clinical pathologist drafting EVA's critical and action limits. You own docs/signoff/work/governance/critical-limits.json, action-limits.json and critical-limits.md (Spanish then English). WebSearch cap 30.

1. critical-limits.json: for the 13 Base Panel analytes (src/lib/lab-bridge/panel-codes.ts) plus potassium, sodium, calcium, glucose, haemoglobin, haematocrit, platelets, WBC, absolute neutrophils, creatinine, bilirubin, ALT, AST, TSH and HbA1c: low and high critical limits or 'none, because', in EVA's unit, with at least two published institutional or consensus lists as sources (for example the Spanish SEQC-ML recommendations on critical values, the Royal College of Pathologists alert limits, published hospital lists, the CAP/Q-Probes surveys), the range across sources, your recommendation for the physician with the reason, the action wording (contact a doctor today / go to an emergency department) in Spanish and English, and the recipient model (Echevarne's facultativo first line by contract, EVA's medical director second line, every call logged). Each value cites its sources with identifier and a verbatim quote containing the number.
2. action-limits.json: action limits inside or beyond the reference interval with the follow-up they trigger, from guidelines, each with source and quote: TSAT above 45% (women) or 50% (men) with ferritin above 200/300 ng/mL and HFE testing (EASL 2022); PSA at or above 3 ng/mL in men 50-69 and the risk pathway; urine albumin-to-creatinine ratio at or above 30 mg/g (KDIGO); haemoglobin above 16.5 g/dL (men) / 16 (women) for polycythaemia work-up (WHO 2016/2022); calcium above the upper limit and PTH; fasting glucose at or above 126 mg/dL or HbA1c at or above 6.5% on two samples (ADA 2026 or the current ADA standards); TSH below 0.1 mIU/L in older adults; others you find essential for the 126 markers, at most 20 entries.
3. critical-limits.md: the physician-facing summary table and the alternatives he chooses between.`

const REFRESH = `${COMMON}

Role: data engineer. Re-run node docs/signoff/tools/build-inputs.js so the family inputs include the NHANES distributions and the governance files now present (docs/signoff/work/nhanes/distributions.json, governance/*.json and *.md). You own docs/signoff/work/inputs/*.json for this run; if the builder fails, fix it (you own docs/signoff/tools/build-inputs.js now) and re-run. Report the per-family counts and what is still missing.`

phase('Drafts')
const [a, b] = await parallel([
  () => agent(T7A, { label: 'T7a governance documents', phase: 'Drafts', schema: RESULT, model: 'fable', effort: 'high' }),
  () => agent(T7B, { label: 'T7b clinical rule sets', phase: 'Drafts', schema: RESULT, model: 'fable', effort: 'high' }),
])
log(`Drafts: T7a ${a ? a.status : 'null'}, T7b ${b ? b.status : 'null'}`)
if (!a && !b) return { stopped_at: 'Drafts' }

phase('Inputs')
const [i1, i2] = await parallel([
  () => agent(T1, { label: 'T1 family inputs', phase: 'Inputs', schema: RESULT, model: 'opus', effort: 'high' }),
  () => agent(T2, { label: 'T2 NHANES distributions', phase: 'Inputs', schema: RESULT, model: 'opus', effort: 'high' }),
])
log(`Inputs: T1 ${i1 ? i1.status : 'null'}, T2 ${i2 ? i2.status : 'null'}`)
if (!i1 && !i2) return { stopped_at: 'Inputs', t7a: a, t7b: b }

phase('Limits')
const c = await agent(T7C, { label: 'T7c critical and action limits', phase: 'Limits', schema: RESULT, model: 'fable', effort: 'high' })
log(`Limits: T7c ${c ? c.status : 'null'}`)
if (!c) return { stopped_at: 'Limits', t7a: a, t7b: b, t1: i1, t2: i2 }

phase('Refresh')
const r = await agent(REFRESH, { label: 'refresh family inputs', phase: 'Refresh', schema: RESULT, model: 'opus', effort: 'medium' })

return { t7a: a, t7b: b, t1: i1, t2: i2, t7c: c, refresh: r }
