export const meta = {
  name: 'model-probe',
  description: 'Check which Fable model names agents can run on now, and whether the usage limit lets them run',
  phases: [{ title: 'Probe' }],
}
const SCHEMA = { type: 'object', properties: { model_id: { type: 'string' } }, required: ['model_id'] }
const ask = 'Reply with the exact model id you are running on, as you know it (for example claude-...). Do nothing else: no tools, no files.'
phase('Probe')
const out = await parallel([
  () => agent(ask, { label: 'probe claude-fable-5-2', model: 'claude-fable-5-2', effort: 'low', schema: SCHEMA }),
  () => agent(ask, { label: 'probe fable', model: 'fable', effort: 'low', schema: SCHEMA }),
])
return { claude_fable_5_2: out[0], fable: out[1] }
