export const meta = {
  name: 'fable-approval-synthesis',
  description: 'Fable 5.2 reconciles the reviews and challenges into one recommendation per frozen file and per decision, used as the CEO approval',
  phases: [{ title: 'Synthesize', detail: 'one Fable 5.2 agent rules on every file and decision, spot-checking disputes in the code' }],
}

const FINDING = { type: 'object', properties: { summary: { type: 'string' }, evidence: { type: 'string' }, smallest_fix: { type: 'string' } }, required: ['summary', 'evidence', 'smallest_fix'] }
const SCHEMA = {
  type: 'object',
  properties: {
    files: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          sha256: { type: 'string' },
          verdict: { type: 'string', enum: ['approve', 'reject'] },
          action: { type: 'string', enum: ['approve_current', 'change_then_rereview'] },
          plain_rationale: { type: 'string' },
          standing_findings: { type: 'array', items: FINDING },
          required_change: { type: 'string' },
          tests_to_change: { type: 'array', items: { type: 'string' } },
          followups: { type: 'array', items: { type: 'string' } },
        },
        required: ['file', 'sha256', 'verdict', 'action', 'plain_rationale', 'standing_findings', 'required_change', 'tests_to_change', 'followups'],
      },
    },
    decisions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          recommendation: { type: 'string', enum: ['keep_default', 'take_alternative', 'other'] },
          rule: { type: 'string' },
          plain_rationale: { type: 'string' },
          code_change_needed: { type: 'boolean' },
          code_change: { type: 'string' },
          table_correction: { type: 'string' },
        },
        required: ['id', 'recommendation', 'rule', 'plain_rationale', 'code_change_needed', 'code_change', 'table_correction'],
      },
    },
    new_decisions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          question: { type: 'string' },
          recommendation: { type: 'string' },
          rule: { type: 'string' },
          plain_rationale: { type: 'string' },
          code_change_needed: { type: 'boolean' },
          code_change: { type: 'string' },
        },
        required: ['id', 'question', 'recommendation', 'rule', 'plain_rationale', 'code_change_needed', 'code_change'],
      },
    },
    known_issue_updates: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, update: { type: 'string' } }, required: ['id', 'update'] } },
    summary: { type: 'string' },
  },
  required: ['files', 'decisions', 'new_decisions', 'known_issue_updates', 'summary'],
}

const prompt = [
  'You write the recommendation that EVA\'s CEO adopts as the approval decision on 22 frozen-file changes and 8 publication rules (CEO-1 to CEO-8) of the AI sign-off programme. The CEO\'s instruction: Fable 5.2 recommends on these decisions, and its recommendations serve as the approval. Your result is recorded as written, so it carries the CEO\'s authority. Be exact and independent.',
  '',
  'Background.',
  '- EVA is a preventive-health app. Before launch, a licensed physician will review and sign its optimal biomarker ranges, its biological age model and its score. The Doctor Sign-off Readiness Test (DSRT), docs/signoff/ACCEPTANCE-TEST.md, is the acceptance test that material must pass first. The runner (scripts/signoff/) and the tools (docs/signoff/tools/) grade and compile it.',
  '- The specification, runner, thresholds, judge prompts and tools were hashed at round 0 (docs/signoff/work/checks/round-0.json; baseline commit 7602f9d). Check G1 fails while any of them differs without an entry in docs/signoff/work/governance/approved-changes.json ({file, sha256, commit, approved_by: "CEO"}). After the pilot, the programme\'s orchestrator, whose work these files grade, changed 22 of them: docs/signoff/work/governance/pending-approvals.json lists each with its sha256; docs/signoff/work/central/known-issues.md lists the defects; docs/signoff/work/governance/central-fix-decisions.md holds CEO-1 to CEO-8.',
  '- Fable 5.2 reviewers, one per area, and an adversarial Fable 5.2 challenger per area reviewed every file against this standard: a change must fix a real defect against the written specification, must not let any check pass more easily than the specification allows, must be correct, and must stay in scope with no bypass. Two Fable 5.2 reviewers, one with a clinical-safety lens and one with a provenance lens, reviewed CEO-1 to CEO-8. Their full records: docs/signoff/work/central/fable-approval-runner.json (runner areas) and docs/signoff/work/central/fable-approval-tools.json (tool areas and the decisions). Read both in full.',
  '',
  'Your task.',
  '1. For each of the 22 files in pending-approvals.json: rule approve or reject at its listed sha256. Where reviewer and challenger agree, adopt their verdict unless you find it wrong in the code. Where they disagree (scripts/signoff/checks/data.ts), or where a finding is disputed, check it yourself in the code (`git diff 7602f9d -- <file>`, the specification text, and a run where useful) and rule. Then set action: approve_current when the file should be approved as it is now and nothing else forces it to change; change_then_rereview when it is rejected, or when a change required elsewhere (a rejected sibling file, a decision taken below, a test that must follow a library change) must edit it. For change_then_rereview, required_change states exactly what must change, specific enough for a developer to implement and for a second review to verify; tests_to_change lists the test files that must follow, frozen or not. Prefer the reviewers\' tested fixes when they are right; say where you depart from them and why.',
  '2. For each of CEO-1 to CEO-8: give the final rule, reconciling the two lenses and the file reviews (the compile-sources.js rejection bears on CEO-2; the CEO-3 wording and the CEO-4 verify-correction point bear on those rules). Say whether code must change and exactly how, and correct the table text where the reviewers found it wrong (for example the stated effects).',
  '3. The reviewers raised questions that are not among CEO-1 to CEO-8 (for example: whether a clinical note a family does not supply is kept or withheld; whether a reconciliation/reasons.json entry may explain a bound or a unit of a decided row; what replaces the withheld caveats and unit notes). List each as a new decision with your recommendation and rule, numbered CEO-9 onward. Only questions the CEO must settle; implementation details are not decisions.',
  '4. known_issue_updates: changes to docs/signoff/work/central/known-issues.md that follow, for example an issue reopened or added (an app path that still drops a bounded result\'s comparator), with status and owner.',
  '5. summary: five to ten sentences in plain words for a CEO without a coding background: what is approved now, what must change before approval, and what the decisions mean for what the physician reads.',
  '',
  'After you, the orchestrator implements exactly the required changes, and a second Fable 5.2 review and challenge verify them before any approval of a changed file is recorded. So be precise about what must change; leave out wishes that are not required for approval (put those in followups).',
  '',
  'Rules: read-only. Do not modify, create or delete any file in the repository and run no git command that changes state. Scratch files only under /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/fable-review/synthesis/ (create it with mkdir -p). Another programme run (batch B04) is writing files under docs/signoff/work/; ignore them. plain_rationale: two to five sentences in plain words per item. Reply with the structured result: one entry per file, in the order of pending-approvals.json, and one per decision, CEO-1 to CEO-8 in order.',
].join('\n')

phase('Synthesize')
const out = await agent(prompt, { label: 'synthesis', phase: 'Synthesize', schema: SCHEMA, model: 'claude-fable-5-2', effort: 'max' })
return out
