export const meta = {
  name: 'ws0-tools',
  description: 'Workstream 0 tooling: schemas, validators, quote checker, compiler, DSRT runner and the batch loop script',
  phases: [
    { title: 'Core', detail: 'schemas, validators and quote checker; DSRT runner with data, coverage, message, coherence and governance checks' },
    { title: 'Checks', detail: 'compiler; evidence, limits, measurement, score, biological age, consistency, population and persona checks' },
    { title: 'Loop', detail: 'the ws1 batch workflow script, ledger and scorecard tools' },
    { title: 'Integrate', detail: 'run everything, fix integration faults, baseline round 0' },
  ],
}

const ROOT = '/home/user/eva-health'
const COMMON = `You are a senior engineer in EVA Health's physician sign-off programme. Repository ${ROOT}, branch claude/wonderful-meitner-l4g7p5 (already checked out). Today is ${args.today}.

Read first: docs/signoff/PLAN.md, docs/signoff/ACCEPTANCE-TEST.md (the DSRT, the test you are building tools for), docs/signoff/LOOP-PROMPT.md, docs/signoff/work/families.json. Also look at the existing tools you should reuse rather than reinvent: docs/biomarker-evidence/tools/ (validate-research.js, validate-verify.js, assemble-decisions.js, compile.js, consistency-audit.js, three-categories.js, inrange-spec.js, verify-copy.js, check-published.js) and the app modules src/lib/biomarkers/reference-row.ts, zone-classifier.ts, zone-config.ts, seed-references.ts, longevity-score.ts, biological-age-v3.ts, biological-age-v3-adapter.ts, name-matcher.ts, canonical-units.ts. Seed data: supabase/seed-data/biomarker-ranges-en.json, rangos-biomarcadores-es.json, biomarker-sources.json. Production snapshot: docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json (and APPLIED.md for what came after). Echevarne catalogue: docs/vendor/echevarne/catalogo-2026-08-25.tsv and the code map in src/lib/lab-provider/echevarne.ts.

This repo runs a customised Next.js fork; read AGENTS.md. Tooling conventions: Node scripts under docs/signoff/tools/ are CommonJS like the existing tools; TypeScript under scripts/signoff/ runs with npx tsx and may import from src via relative paths; tests for TypeScript go in src/lib/signoff/*.test.ts (vitest only collects src/**/*.test.ts); tests for Node tools go in docs/signoff/tools/test/*.test.js runnable with node --test.

Rules:
- Write ONLY the files you are told you own. Other agents are writing other files at the same time. Never edit files under src/ other than your own test files, never edit package.json except where told, never edit supabase/, ml/ or the plan documents.
- Do not commit or push; the orchestrator commits.
- No database access, no SQL, no emails, no calls to the app's API. Network only for the source endpoints named in your task.
- Work incrementally: write each file as soon as it is usable, so partial work survives. Aim to finish in about 30 minutes of work. If you run short, stop at a consistent state and list what is missing in your final answer.
- Every script must be deterministic: no current-time stamps in outputs unless passed in; stable key order; sorted lists.
- Run what you write. Report exact commands and their results; never claim a test passed that you did not run.

Resuming: an earlier run of this same task was stopped by an account usage limit. Some files you own may already exist from it. Read them first, keep what is correct, and complete the task; do not start over and do not delete files other agents own.`

const CONTRACT = `Check module contract, shared by every DSRT check module (scripts/signoff/types.ts defines it; follow it exactly):
export type Status = "pass" | "fail" | "blocked";
export interface Failure { key: string; detail: string }
export interface CheckResult { id: string; status: Status; summary: string; failures: Failure[]; metrics?: Record<string, number | string | boolean>; blocked_on?: string }
export interface Ctx { root: string; seedDir: string; workDir: string; round: number; thresholds: Record<string, unknown>; load<T = unknown>(relPath: string): T | null }
export interface Check { id: string; group: string; title: string; how: "script" | "judge" | "audit" | "script+judge"; run(ctx: Ctx): Promise<CheckResult> | CheckResult }
Each module file scripts/signoff/checks/<module>.ts exports: export const checks: Check[] = [...].
- seedDir defaults to supabase/seed-data and can be overridden (--seed-dir) so the loop can check a scratch compile; workDir defaults to docs/signoff/work.
- A check whose inputs do not exist yet (for example no research files, no results file from the harness, no Echevarne data) returns status "blocked" with blocked_on naming what is missing. Blocked is never pass.
- Judge or audit checks (how "judge"/"audit") read the latest result file the loop writes (for example docs/signoff/work/judges/final/*.json, docs/signoff/work/audit/round-<n>-result.json) and are blocked when it is absent.
- Failures are sorted by key; summaries name counts.
Modules: data (D1-D6), coverage (C1-C3), messages (M1-M5), coherence (K1), governance (G1-G7 except G8), evidence (E1-E6), limits (L1-L2), preanalytical (P1-P3), score (S1-S6), bioage (B1-B6), consistency (X1-X2), population (N1), personas (Q1), prereview (G8).`

const RESULT = {
  type: 'object',
  properties: {
    files_written: { type: 'array', items: { type: 'string' } },
    commands_run: { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, result: { type: 'string' } }, required: ['command', 'result'] } },
    status: { type: 'string', enum: ['complete', 'partial'] },
    missing: { type: 'array', items: { type: 'string' } },
    notes: { type: 'string' },
  },
  required: ['files_written', 'commands_run', 'status', 'missing', 'notes'],
}

const T3 = `${COMMON}

Your task: evidence tooling. You own docs/signoff/tools/schema/*.json, docs/signoff/tools/validate.js, docs/signoff/tools/quote-check.js, docs/signoff/tools/lib/*.js, docs/signoff/tools/test/schema.test.js, docs/signoff/tools/test/quote-check.test.js, and docs/signoff/work/sources-cache/ (created by your tool).

1. JSON Schemas (draft 2020-12) for the loop's files, extending the September research and verify formats (read validate-research.js and validate-verify.js and a sample of docs/biomarker-evidence/longevity/research/*.json and verify/*.json first):
   - research.schema.json: the family auditor's output. Per family: rows (marker key, sex, age group, physiological state, unit, marker_class a-e, reference_low/high with reference_basis enum [echevarne_interval, decision_limit, population_study] and reference_source, optimal_low/high with band_rule enum [nadir_ci, within_10pct_of_min_hr, lowest_risk_category, none], critical_low/high or critical_none_reason, action limits list, pre-analytical rules list, method note, rcv inputs, messages in en and es for each reachable zone, explanatory_numbers), evidence records per bound (id, bound it supports, identifier type pmid|pmcid|doi|url and value, quote at most 60 words, location, design, n, follow_up_years, outcome, population_age, population_sex, assay, band_rule, basis_class enum [laboratory_interval, guideline_decision_limit, outcome_nadir, treatment_tier, expert_opinion], proposed_grade A-D, age_stratified_statement), age-split justification per split, v3_consistency block for version 3 markers (resolution enum [row_change, accepted_exception, none_needed] with reason), locked-decision questions, physician questions, searches_used, fetches_used.
   - verify.schema.json: verdict per row and per evidence record (confirmed | corrected | refuted | unverifiable), verifier-assigned grade, final_rows in the research row format, corrections with evidence, physician questions.
   - decision.schema.json: the fixer's output: final_rows, changes (row key, field, from, to, direction tighten|loosen|neutral, reason, evidence ids), issues addressed (ledger ids).
   - judge.schema.json: blocking and minor issues, each with family, row key, check id or definition, value disputed, evidence (file:line or source+quote), resolution.
   - refutation.schema.json and ledger.schema.json (issue id, source judge and lens, family, check id, row key, side, status open|confirmed|disputed|refuted|fixed|closed|unreviewed|physician_question, rounds opened/closed, evidence paths).
2. validate.js: node docs/signoff/tools/validate.js <research|verify|decision|judge|refutation|ledger> <family-or-path> validates against the schema (implement a small validator yourself or reuse one already in node_modules; check with ls node_modules first; do not add dependencies) plus semantic checks: ordering of bounds, quotes at most 60 words, every bound has an evidence record unless class e, grade D means no optimal band, version 3 markers carry the v3_consistency block. Exit code 0 when valid; errors printed one per line.
3. quote-check.js: node docs/signoff/tools/quote-check.js <research-or-verify-file> [--offline]. For each evidence record, fetch the source text and cache it: PubMed abstract via https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=<PMID>&rettype=abstract&retmode=text ; PMCID via https://www.ebi.ac.uk/europepmc/webservices/rest/<PMCID>/fullTextXML (fall back to the abstract) ; DOI via Europe PMC search (https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=DOI:<doi>&resultType=core&format=json, abstractText) ; URL fetched as text with tags stripped. Cache under docs/signoff/work/sources-cache/<sha1-of-identifier>.txt with a small JSON sidecar (identifier, fetched_from, bytes, sha256). Match the quote with normalisation (case, whitespace, unicode dashes and quotes, en/es decimal separators) and a token-based similarity; report found (score at least 0.9), weak, not found, unopenable. --offline uses only the cache. Output JSON to stdout and a summary line. Be polite: at most 3 requests per second, retry twice with backoff.
4. Tests with node --test covering the schemas on a valid and an invalid example, and quote matching on a cached fixture (no network in tests).
Run the tests and a live smoke test of quote-check on one PMID from docs/biomarker-evidence/longevity/research/apob.json (or any research file with a PMID).`

const T5 = `${COMMON}

${CONTRACT}

Your task: the DSRT runner and five check modules. You own scripts/signoff/types.ts, scripts/signoff/dsrt.ts, scripts/signoff/lib/*.ts, scripts/signoff/checks/data.ts, coverage.ts, messages.ts, coherence.ts, governance.ts, docs/signoff/thresholds.json, src/lib/signoff/dsrt-core.test.ts, and you may add one line to package.json: "dsrt": "tsx scripts/signoff/dsrt.ts" in scripts (check that tsx is available via npx).

1. types.ts exactly as the contract. dsrt.ts: CLI flags --round N (default 0), --seed-dir, --work-dir, --only <ids comma>, --families <ids comma> (restricts row-level checks to those families' keys from families.json), --out <file> (default docs/signoff/work/checks/round-<N>.json). It loads every module listed in the contract that exists (fs.existsSync, dynamic import), runs the checks in id order, and writes JSON { round, git_commit (from git rev-parse HEAD), inputs: { sha256 of the seed files, ACCEPTANCE-TEST.md, LOOP-PROMPT.md, thresholds.json, PLAN.md, every file under scripts/signoff/ and docs/signoff/tools/ }, results: [...], counts: {pass, fail, blocked} }, deterministic (no timestamps). Missing modules: their check ids (from ACCEPTANCE-TEST.md, which you parse for the ids) appear as blocked "module not implemented". Exit code 0 always; print a one-line summary per check.
2. thresholds.json: every numeric pass rule in ACCEPTANCE-TEST.md as a named value (for example E2_quote_found_min_share 0.98, E2_match_score 0.9, E5_agreement_min 0.95, X1_tolerance_years 0.05, X1_max_exceptions 2, N1_reference_outside_min 0.02, N1_reference_outside_max 0.15, N1_minority_label_below 0.10, S6_rho_min 0.2, grade C table cap 20, open-question caps 20/8/5, persona minimum 40, G7 reading hours 10 and 3).
3. Modules, implementing the checks as written in ACCEPTANCE-TEST.md against the current data, so they report today's real failures:
   - data.ts D1-D6: D1 row integrity including duplicate keys (expect hs-CRP, DHEA-S female 18-29 and male 18-29, calcium), non-analyte rows (the Biological Age row), ordering with critical fields when present, unit vs Echevarne reported unit where mapped; D2 EN/ES parity; D3 laboratory concordance against the Echevarne catalogue via the code map in src/lib/lab-provider/echevarne.ts (parse the catalogue TSV; report deviations; a row with reference_basis decision_limit or population_study and a source is exempt); D4 conversions: inventory every unit conversion in src/lib/biomarkers (canonical-units.ts and friends), list factor and source, and fail on approximations such as Lp(a) mass-molar; D5 one source of truth: seed EN vs ES vs the production snapshot plus the migrations after it listed in APPLIED.md, reporting markers only in production (20 today) and only in the seed; D6 reconciliation: blocked until docs/signoff/work/reconciliation/ exists.
   - coverage.ts C1-C3: C1 must call the app's own picker (import pickReferenceRows or referenceRowFor from src/lib/biomarkers/reference-row.ts) for every marker, sex, age 18-120 and the states the app records (read src/lib/patient-context/options.ts); report gaps, overlaps and unreachable rows; C2 and C3 read docs/signoff/work/governance/state-rules.md presence and family pages; blocked where the inputs do not exist yet.
   - messages.ts M1-M4 (M5 is a judge check: blocked until a judge file exists): reachability per zone from the row's bounds with the classifier's rules (import from zone-classifier.ts); M3 lexicon from docs/signoff/work/governance/wording-rules.md (parse a fenced json block of banned terms per language and tier; blocked if absent) applied to rows and to app notices in src/lib/biomarkers/zone-config.ts, src/components/dashboard/MedicalDisclaimer.tsx and src/lib/email/templates/*.ts; M4 numbers in messages vs bounds with en and es decimal formats and an explanatory_numbers allowance.
   - coherence.ts K1: port the relationships of docs/biomarker-evidence/tools/consistency-audit.js into a grid over synthetic people using the app's classifier and picker; report opposite-category pairs and one-step pairs.
   - governance.ts G1-G7: G1 hashes vs docs/signoff/work/checks/round-0.json inputs (pass at round 0 by construction; fail later if frozen files changed) and an ownership check helper; G2 traceability (blocked until decisions exist); G3 determinism (run the runner twice in-process on the same data and compare hashes of results); G4 manifest (blocked until docs/signoff/pack/manifest.json); G5 cover labels (blocked until pack); G6 number consistency (blocked until pack); G7 cold reader (blocked until docs/signoff/work/cold-reader.json).
4. src/lib/signoff/dsrt-core.test.ts: unit tests of the runner and of each of your modules on small in-memory fixtures (a duplicate key fails D1; a gap fails C1; an unreachable zone message is reported but not failed in M1; an opposite pair fails K1).
Run: npx vitest run src/lib/signoff; npx tsc --noEmit -p .; npm run dsrt -- --round 0 --out /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/dsrt-try.json and report the counts and the failing check ids.`

const T4 = `${COMMON}

Your task: the compiler. You own docs/signoff/tools/compile.js, docs/signoff/tools/lib/compile-*.js, docs/signoff/tools/test/compile.test.js, and the output folder docs/signoff/work/compiled/ (scratch output) and the template for docs/signoff/work/reconciliation/.

compile.js --out-dir <dir> [--families ...] [--write-seed] builds, from the per-family decisions (docs/signoff/work/decisions/<family>.json, else verify final_rows, else research rows, else today's seed rows for that family, recording which source each family came from), the following outputs in <dir>:
- biomarker-ranges-en.json and rangos-biomarcadores-es.json in the existing seed format, extended with new columns: Critical_Low, Critical_High, Critical_None_Reason, Marker_Class, Reference_Basis, Reference_Source, State, Method_Note, Explanatory_Numbers (and the Spanish names Crítico_Bajo, Crítico_Alto, Motivo_Sin_Crítico, Clase_Marcador, Base_Referencia, Fuente_Referencia, Estado, Nota_Método, Números_Explicativos), keeping today's key order and the calculated_metrics and app_schema_guide blocks;
- biomarker-sources.json updated per family from the evidence records (verifier grades);
- changes.json and CHANGES.md against the production snapshot docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json plus later applied changes (read APPLIED.md; where a later state is only in a migration file, apply that migration's row values by parsing it if feasible, else record 'post-snapshot migration not reconstructed'), one entry per changed row and field with direction tighten/loosen/neutral and the evidence ids;
- migration.sql (a new migration file, NOT placed in supabase/migrations, adding the new columns and upserting the rows) and rollback.sql restoring the snapshot state. Nothing is applied.
- compile-report.json: per family, the source used, counts, warnings.
--write-seed overwrites supabase/seed-data/ instead of <dir>; never use it in tests. The compile must be idempotent: running it twice gives byte-identical files. Reuse the logic of docs/biomarker-evidence/tools/assemble-decisions.js and compile.js where it fits (read them). Use the schemas in docs/signoff/tools/schema/ if they exist (another agent is writing them; read them at the end and align field names; if absent, use the field names in docs/signoff/LOOP-PROMPT.md and note the assumption).
Tests with node --test: idempotence, a fixture family with a decision file overriding a row, EN/ES column parity. Run compile.js on today's data with no decisions (every family falls back to today's seed rows): the compiled seed must equal today's seed rows except for the added empty columns; report the diff summary.`

const T6 = `${COMMON}

${CONTRACT}

Your task: nine check modules. You own scripts/signoff/checks/evidence.ts, limits.ts, preanalytical.ts, score.ts, bioage.ts, consistency.ts, population.ts, personas.ts, prereview.ts, scripts/signoff/fixtures/personas.json, and src/lib/signoff/dsrt-checks.test.ts. Another agent writes scripts/signoff/types.ts and the runner at the same time; import types from "../types" exactly as in the contract (if the file does not exist yet when you start, write against the contract and check at the end).

Implement the checks as written in ACCEPTANCE-TEST.md:
- evidence.ts E1-E6: read research/verify/decisions files for each family in docs/signoff/work/families.json; E1 record completeness; E2 runs the quote matcher in offline mode against docs/signoff/work/sources-cache (shell out to node docs/signoff/tools/quote-check.js --offline when it exists, else blocked); E3 grade rules and the grade C table at docs/signoff/work/grade-c-table.json; E4 age-split statements; E5 reads docs/signoff/work/audit/round-<n>-result.json; E6 locked decisions: compare the compiled rows for apolipoprotein_b_apob, ldl_cholesterol, non_hdl_cholesterol, glucose_fasting, vitamin_d_25_oh, homa_ir with today's seed and the creatine rule in src/lib/biomarkers/supplements.ts (CREATINE_SATURATING_DOSE_G, the 0.13 divisor) unless docs/signoff/work/questions/ceo-locked.md records a CEO question. Blocked where files are absent (expected today for E1-E5).
- limits.ts L1-L2: read the critical fields in the seed rows and docs/signoff/work/governance/critical-limits.json and action-limits.json; L1 coverage of the analyte list in the acceptance test and a static check that the app classifier does not derive 'critical' from normal bounds (today it does: report it as a failure with the file and line from src/lib/biomarkers/zone-classifier.ts).
- preanalytical.ts P1-P3: P1 rule tests via fixtures once the app supports fasting, draw time, haemolysis and collection method (today: fail with what is missing, found by inspecting src/lib/biomarkers and src/lib/lab-provider); P2 reads docs/signoff/work/rcv.json (blocked if absent) and checks bands narrower than the RCV; P3 the bounded-result rule (how src/lib/biomarkers resolves '<5' today; test it) and the LoQ part blocked on Echevarne data.
- score.ts S1-S6: S1 static check that v1 and LONGEVITY_SCORE_VERSION are gone (fails today); S2 classes from docs/signoff/work/governance/marker-classes.json against the scored set (REVIEWED_ROW_KEY in longevity-score.ts); S3 redundancy groups from the acceptance test against the score code's REDUNDANT_GROUPS; S4 the weights table docs/signoff/work/score/weights.json (blocked if absent); S5 properties computed with calculateLongevityScoreV2 on the seed rows: 100 when all optimal, zero penalty inside optimal and monotone outside on 200 points per marker, no top grade with a critical value over 1,000 seeded random panels, no score in pregnancy (fails today if the code has no pregnancy rule), regression fixtures; S6 reads docs/signoff/work/score/population-validity.json (blocked if absent).
- bioage.ts B1-B6: B1 compute sha256 and model_sha256 of ml/biological-age/model-v3.json and the source hashes in src/lib/biomarkers/data/ba_v3_model.json, and count runs in ml/biological-age/harness/final_test_log.jsonl (expect 2 started runs; read the file's record types); B2 runs the refusal fixtures in docs/signoff/work/v3/refusals.json through the adapter or the module (blocked if absent) and reports today's gaps by probing: albumin 0 and 4.3 g/L, creatinine 2.0 mg/dL, hs-CRP 60 mg/L, age 82, pregnancy, collection method; B3 parity: reuse the existing parity fixture test src/lib/biomarkers/__tests__/fixtures/ba-v3-python-parity.json (report its size and the max difference); B4 and B5 read docs/signoff/work/v3/validation-reruns.json and ages-80-84.json (blocked if absent); B6 display rules from docs/signoff/work/v3/display-copy.json (blocked if absent).
- consistency.ts X1-X2: X1 exactly as specified: for each tier (base, plus_hba1c), sex and v3 marker, 400 points from the plausibility floor to the ceiling (src/lib/biomarkers/data/plausibility_bounds.json), compute the marker's contribution with the module's own transform and clamp (import from biological-age-v3.ts; if the internals are not exported, recompute from ba_v3_model.json with the same formula and verify against the module on sample points), and compare with the zone classifier and the score v2 penalty for the person's row; tolerance and exception cap from thresholds.json; exceptions listed in docs/signoff/work/v3/consistency-exceptions.json. Today it must report albumin 48-50 g/L and GGT below 5 U/L. X2 lists flat segments and checks docs/signoff/work/v3/display-copy.json mentions each (blocked if absent).
- population.ts N1: reads docs/signoff/work/nhanes/distributions.json (another agent produces it; blocked if absent) and applies the rules with thresholds.json.
- personas.ts Q1: scripts/signoff/fixtures/personas.json with at least 40 personas as the acceptance test lists (values plausible for each, a short note each, physiological state and context fields); run them through the picker, classifier, score v2 and the v3 module; report the four pass rules; today several fail (no pregnancy rule, no critical tier).
- prereview.ts G8: reads docs/signoff/work/judges/final/*.json and the ledger; blocked if absent.
Tests in src/lib/signoff/dsrt-checks.test.ts for X1 on a synthetic row set (albumin optimal 42-48 fails at 49 g/L), S5 monotonicity, B1 hash, and the personas fixture size. Run npx vitest run src/lib/signoff and npx tsc --noEmit -p . and report.`

const T8 = `${COMMON}

${CONTRACT}

Your task: the loop. You own docs/signoff/workflows/ws1-batch.js, docs/signoff/tools/ledger.js, docs/signoff/tools/scorecard.js, docs/signoff/tools/ownership.js, docs/signoff/tools/test/ledger.test.js, and docs/signoff/workflows/README.md.

First read the Workflow tool's script rules, which you must follow exactly: the script is plain JavaScript (no TypeScript), begins with export const meta = { name, description, phases } as a pure literal, uses only the hooks agent(prompt, opts), parallel(thunks), pipeline(items, ...stages), phase(title), log(msg), args and budget; no filesystem or Node APIs inside the script, no Date.now(), Math.random() or argless new Date(). Agents do the file work and run the scripts; the script orchestrates. agent() returns null when an agent dies: handle null. Use opts { label, phase, schema, model: 'fable', effort } (effort 'max' for author, verifier, judges, refuters, fixer; 'medium' for the mechanical runner agent).

ws1-batch.js implements docs/signoff/LOOP-PROMPT.md sections 1 to 4 for one batch: args { batch, started_at, max_rounds (default 3), agent_cap (default 120), search_cap_author (22), search_cap_verifier (16), families (optional override) }. Families come from a runner agent that reads docs/signoff/work/families.json and returns the batch's families with keys (the script cannot read files itself). Per family, as a pipeline:
1. author agent (role prompt 2.1 filled in) writes research/<family>.json, then runs the validator; the script gets a structured result {file, valid, errors, searches_used}; one repair pass by a second call if invalid.
2. verifier agent (2.2) writes verify/<family>.json; validated the same way.
3. a mechanical runner agent compiles into docs/signoff/work/compiled/<batch>-r<n>/ with docs/signoff/tools/compile.js --families <family> and runs npm run dsrt -- --families <family> --seed-dir <that dir> --round <n> --out docs/signoff/work/checks/<family>-r<n>.json, returning the failing check ids and details as structured data.
4. judges: the six lenses J1-J6 from docs/signoff/work/judges/lenses.json (the role text is read by the agent from that file), one agent per lens over the batch's families (a shard of at most 3 families), with the round's check file and a sample list; each writes judges/round-<n>/<lens>-<batch>.json.
5. refuters: two per blocking issue (A reproduce, B definitions), default refuted; a mechanical agent or the ledger tool records the outcome.
6. ledger in code inside the script for the decision of what to fix: issue id = a stable string of family|check-or-lens|row key|side (no hashing API is available in the script; build the id by concatenation), deduplicated against every issue seen in this run; confirmed issues per family go to one fixer agent (2.5) writing decisions/<family>.json; the ledger file itself is written by an agent running docs/signoff/tools/ledger.js with the issues passed as JSON in the prompt.
7. stop rules exactly as LOOP-PROMPT section 1 (pass, round limit, no net progress counting new issues, agent cap with log of what was left), per family; null policy (retry once at half scope, then unreviewed + physician question).
8. at the end, a runner agent writes docs/signoff/work/scorecard-<batch>.md with docs/signoff/tools/scorecard.js.
Put all prompts in the script built from the role prompts in LOOP-PROMPT.md with the placeholders filled; round-varying content lives in files the agents read.
ledger.js: add/update issues from a JSON payload, compute states, print the open list; scorecard.js: render a scorecard from the checks files and the ledger; ownership.js: given a family and a list of changed paths (from git diff --name-only), exit non-zero if any path is outside owned_paths in families.json (glob support for the * patterns).
README.md: how to run a batch (the batch session prompt is in LOOP-PROMPT.md section 3), resume, and read the scorecard.
Validate the script syntax by running node --check on a copy with the export meta line converted to a plain const (write the copy under /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/ws1check.mjs), and test ledger.js and ownership.js with node --test.`

const INTEGRATE = `${COMMON}

${CONTRACT}

Your task: integration and round 0. Other agents wrote the evidence tools (docs/signoff/tools/), the compiler, the DSRT runner and its modules (scripts/signoff/), and the loop script (docs/signoff/workflows/ws1-batch.js). You may fix integration faults in any file under docs/signoff/tools/, scripts/signoff/ and src/lib/signoff/ (not the plan documents, not docs/signoff/work/governance/, not src/lib/biomarkers).
1. Run: npx tsc --noEmit -p .; npx vitest run src/lib/signoff; node --test docs/signoff/tools/test/; node docs/signoff/tools/compile.js --out-dir docs/signoff/work/compiled/round-0 (twice, confirm identical); npm run dsrt -- --round 0. Fix every fault until all run cleanly. Do not weaken a check to make it pass: a check that fails on today's data is correct if the data fails it.
2. The round-0 output docs/signoff/work/checks/round-0.json must exist with the input hashes; run the runner twice and confirm byte-identical output (G3).
3. Write docs/signoff/work/checks/round-0-summary.md: a table of every check id with status and the one-line summary, then the failure counts by group, then the top failures with keys. This is the baseline the physician programme starts from.
4. Run the full app test suite once (npx vitest run) and report the totals; it must stay green.`

phase('Core')
const [t3, t5] = await parallel([
  () => agent(T3, { label: 'T3 evidence tools', phase: 'Core', schema: RESULT, model: 'opus', effort: 'high' }),
  () => agent(T5, { label: 'T5 runner and core checks', phase: 'Core', schema: RESULT, model: 'opus', effort: 'high' }),
])
log(`Core: T3 ${t3 ? t3.status : 'null'}, T5 ${t5 ? t5.status : 'null'}`)
if (!t3 && !t5) return { stopped_at: 'Core' }

phase('Checks')
const [t4, t6] = await parallel([
  () => agent(T4, { label: 'T4 compiler', phase: 'Checks', schema: RESULT, model: 'opus', effort: 'high' }),
  () => agent(T6, { label: 'T6 check modules', phase: 'Checks', schema: RESULT, model: 'opus', effort: 'high' }),
])
log(`Checks: T4 ${t4 ? t4.status : 'null'}, T6 ${t6 ? t6.status : 'null'}`)
if (!t4 && !t6) return { stopped_at: 'Checks', t3, t5 }

phase('Loop')
const t8 = await agent(T8, { label: 'T8 loop script', phase: 'Loop', schema: RESULT, model: 'opus', effort: 'high' })
log(`Loop: T8 ${t8 ? t8.status : 'null'}`)
if (!t8) return { stopped_at: 'Loop', t3, t5, t4, t6 }

phase('Integrate')
const integ = await agent(INTEGRATE, { label: 'integration round 0', phase: 'Integrate', schema: RESULT, model: 'opus', effort: 'high' })

return { t3, t5, t4, t6, t8, integ }
