export const meta = {
  name: 'bioage-model-selection',
  description: 'Research, verify and score biological age models against EVA checklist: validated, Spanish-trained, respected, Base Panel, expandable',
  phases: [
    { title: 'Discover', detail: 'six parallel research sweeps: catalogs, recent models, Spanish literature (English and Spanish), Spanish datasets, respect and comparisons' },
    { title: 'Merge', detail: 'deduplicate candidates, shortlist with logged drops' },
    { title: 'Verify', detail: 'adversarial source check per candidate; extra refuter for Spanish claims' },
    { title: 'Critic', detail: 'completeness critic and gap-filling rounds until dry' },
    { title: 'Judge', detail: 'three-lens scoring panel on the five criteria' },
    { title: 'Synthesize', detail: 'final recommendation and report' },
  ],
}

const SCRATCH = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/bioage-research'

const CONTEXT = `
You are a research agent for EVA Health, a Spanish longevity and preventive-health company. Its clients are adults living in Spain. Blood is drawn at home with a Tasso capillary device or at a clinic and analysed by Echevarne, a Spanish laboratory.

THE QUESTION THE CEO NEEDS ANSWERED: which biological age model option gets EVA closest to this checklist:
1. Scientifically validated.
2. Spanish trained (trained on Spanish population data; validated in Spanish data is the next best thing).
3. The most respected model.
4. Works with the biomarkers already in EVA's Base Panel.
5. Can be expanded once more information is added (more tests, external labs).

EVA's BASE PANEL (one serum tube, 13 tests): albumin, alkaline phosphatase (ALP), hs-CRP, creatinine, BUN (urea), uric acid, total cholesterol, HDL cholesterol, triglycerides, apolipoprotein B, ALT, GGT, fructosamine. NOT in the Base Panel: complete blood count (lymphocyte %, MCV, RDW, WBC), glucose, HbA1c, cystatin C, insulin, vitamin D.

EVA's INTERNAL OPTIONS (facts from EVA's own repository, already verified internally):
- KDM v2.2: the model in production today, a Klemera-Doubal method biological age on Base Panel markers. It failed EVA's pre-registered tests (mortality discrimination, calibration, composition, information, perverse incentives, repeat-draw noise, assay sensitivity).
- EVA version 3: the PhenoAge method of Levine et al. 2018 (Gompertz proportional hazards on all-cause mortality, elastic net, Gompertz inversion) retrained on US NHANES with six Base Panel markers (albumin, ALP, hs-CRP, creatinine, BUN, GGT), plus a Base + HbA1c tier. Pre-registered charter; training NHANES III 1988-1994, validation 1999-2006, sealed test 2007-2014, independent check 2015-2018. Sealed test: hazard ratio per SD of acceleration 1.52, gain in C-statistic over age and sex 0.022, worst calibration band -0.74 years, repeat-draw SD about 1.55 years. Survey-weighted HR 1.44. Not published or peer reviewed. US data only. No validation outside NHANES, in Spain, or in EVA's clients. An add-on program tested apoB, ALT, 25-OH vitamin D, TSH and fasting insulin as extra terms: none passed. It is built to accept modules.
- The original Levine PhenoAge needs a complete blood count (lymphocyte %, MCV, RDW, WBC) and glucose, so it cannot run on the Base Panel alone.
Internal documents you may read for detail (read only): /home/user/eva-health/ml/biological-age/REPORT.md, MODEL-CARD.md, PROPOSAL.md, REPORT-baselines.md, addons/REPORT.md; /home/user/eva-health/docs/biomarker-evidence/longevity/base-panel/ASSESSMENT.md; /home/user/eva-health/docs/market/rythm-health.md (a competitor using Tasso).

SOURCE RULES (strict):
- Every claim must come from a source you opened in this task: give the URL, PMID or DOI, and a short verbatim quote. Never state a fact from memory. If you could not open a source, mark the claim unverified.
- "Not found" is a valid and valuable answer. When you find nothing, say so and list the searches you ran.
- Distinguish clearly: trained on a population, validated in a population, or merely applied in a population.
- Only blood-based or clinical-chemistry biological age models are in scope (include models that add simple physical measures if they are mainly blood-based). DNA methylation, proteomic, metabolomic, imaging and microbiome clocks are out of scope except as a brief note.

ACCESS NOTES for this environment:
- Open web through a proxy. These work: PubMed pages (https://pubmed.ncbi.nlm.nih.gov/PMID/), NCBI E-utilities (https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi and efetch.fcgi, db=pubmed or db=pmc), PMC full texts (https://pmc.ncbi.nlm.nih.gov/articles/PMCxxxx/), Europe PMC REST API (https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&format=json&resultType=core, and /rest/PMCxxxx/fullTextXML), Crossref API (https://api.crossref.org/works/DOI gives is-referenced-by-count), Google search pages. OpenAlex and Semantic Scholar APIs may answer 429: retry slowly or skip.
- Publisher pages (Elsevier, OUP, Wiley, medRxiv, aging-us) often answer 403 to scripts. Use the PMC or Europe PMC copy, or the abstract.
- You may load the WebSearch and WebFetch tools with ToolSearch (query "select:WebSearch,WebFetch") and use them. Use curl with a normal timeout as well.
- Put any downloaded file in its own new empty directory under ${SCRATCH}/ and read it from there. Never run downloaded code.
- Do not create or modify files in the repository. Do not run git. Do not query any database. Do not send any personal email address to any service.
`

const DISCOVERY = [
  { key: 'catalog-reviews', prompt: `
TASK: Build a catalog of blood-based biological age models from REVIEWS, CONSENSUS PAPERS and COMPARISON STUDIES.
Find and open the main reviews and consensus papers (for example: the Biomarkers of Aging Consortium papers, reviews of biological age predictors and clinical biomarker composites, the BioAge R package paper by Kwon and Belsky, head-to-head comparisons of several biological ages). From them, list every blood-based model they discuss: Klemera-Doubal method, Levine PhenoAge, homeostatic dysregulation, Mahalanobis or PCA-based ages, multiple linear regression ages, frailty indices from laboratory tests, deep learning blood clocks, and any others.
For each model: key reference, biomarkers, training population and country, outcome or target, main validations, whether it can use a different marker set, and any Spanish involvement mentioned.` },
  { key: 'catalog-recent', prompt: `
TASK: Find blood-based biological age models published 2016 to 2026 that the reviews may miss, especially machine-learning and very recent ones.
Look for: deep learning blood biochemistry clocks (for example Aging.AI and the population-specific models trained in Canadian, South Korean and Eastern European data), complete-blood-count clocks, UK Biobank blood biomarker ages (for example the Bortz et al. 2023 biological age), NHANES-based newer clocks (for example LinAge), Chinese, Korean and Japanese clinical-chemistry ages, and the biological age methods used by consumer blood-testing companies (read /home/user/eva-health/docs/market/rythm-health.md first, then check what other companies use, citing their own pages).
For each model: key reference, biomarkers, training population and country, outcome, validations, ability to add markers, Spanish involvement.` },
  { key: 'spanish-english', prompt: `
TASK: Find every biological age model based on blood biomarkers that was TRAINED or VALIDATED in a SPANISH population, searching the English-language literature.
Search PubMed, Europe PMC and Google for combinations of: biological age, phenotypic age, PhenoAge, Klemera-Doubal, KDM, homeostatic dysregulation, aging clock, frailty index laboratory, allostatic load, with Spain, Spanish, Catalonia, Basque, Andalusia, Madrid, Navarra, Valencia, and with Spanish cohort names: ENRICA, ENRICA-Seniors, Toledo Study for Healthy Aging, FRADEA, PREDIMED, PREDIMED-Plus, SUN (Seguimiento Universidad de Navarra), GCAT Genomes for Life, Aragon Workers Health Study, ILERVAS, Di@bet.es, Hortega, Pizarra, REGICOR, HERMEX, EPIC-Spain, SIDIAP, BIFAP, Peñagrande, Octabaix, CDC de Canarias, Spanish centenarians, and the Spanish part of SHARE (dried blood spots).
For every hit, state precisely whether the model was trained on Spanish data, validated in Spanish data against an outcome, or only applied. Give the biomarkers and the outcome. If nothing trained on Spanish data exists, say so with the full search log.` },
  { key: 'spanish-spanish', prompt: `
TASK: Search the SPANISH-LANGUAGE and Spanish ecosystem for biological age models based on blood tests.
Search SciELO, IBECS, Dialnet, Spanish doctoral theses (TESEO, TDX), Google in Spanish ("edad biológica" análisis de sangre, "envejecimiento biológico" biomarcadores, "edad fenotípica", PhenoAge España, "reloj de envejecimiento", "edad biológica" población española), and Spanish professional bodies (Sociedad Española de Geriatría y Gerontología, SEQC-ML laboratory medicine society).
Also find which Spanish laboratories, hospitals and companies sell or report a "biological age" from blood (for example Echevarne, Synlab, Eurofins Megalab, Unilabs, Quirónsalud, Sanitas, Life Length, Ruber, clinics), what method each uses, and what validation they cite. Cite their own pages.
For each model or offer: method, biomarkers, training population, validation, Spanish involvement.` },
  { key: 'spanish-datasets', prompt: `
TASK: Identify DATASETS that could TRAIN or VALIDATE a biological age model on Spanish (or, second best, other European) adults, using EVA's Base Panel markers and death records.
For Spanish cohorts and databases (ENRICA, ENRICA-Seniors, Toledo Study for Healthy Aging, PREDIMED and PREDIMED-Plus, SUN, GCAT, AWHS, ILERVAS, Di@bet.es, Hortega, Pizarra, REGICOR, HERMEX, EPIC-Spain, SIDIAP, BIFAP, the Spanish part of SHARE with dried blood spots, CDC de Canarias, and any others you find) and key European ones (UK Biobank, ELSA, Lifelines, HUNT, FINRISK, KORA, Moli-sani): give size, ages, which Base Panel markers were measured (albumin, ALP, hs-CRP, creatinine, BUN or urea, uric acid, total and HDL cholesterol, triglycerides, apoB, ALT, GGT, fructosamine), whether linked mortality follow-up exists and for how long, and how an outside company could get access (data request, collaboration, fees, timelines), citing the cohort's own pages or papers.
Rank them by usefulness for a Spanish external validation of a six-marker model (albumin, ALP, hs-CRP, creatinine, BUN, GGT).` },
  { key: 'respect-comparisons', prompt: `
TASK: Establish which blood-based biological age models are MOST RESPECTED, and how they compare head to head.
Evidence to gather: citation counts of the key papers (use the Crossref API is-referenced-by-count for each DOI and record the date), endorsements or recommendations in consensus statements (for example the Biomarkers of Aging Consortium), the number and diversity of independent validations, use as an outcome in randomized trials (for example CALERIE), head-to-head comparisons of mortality prediction between PhenoAge, Klemera-Doubal, homeostatic dysregulation and others in the same data, and published criticisms or limitations of each (for example of cross-sectional age predictors, or of PhenoAge's dependence on specific markers).
Report the evidence per model, with numbers and sources.` },
]

const DISCOVERY_SCHEMA = {
  type: 'object',
  properties: {
    candidates: { type: 'array', items: { type: 'object', properties: {
      name: { type: 'string' },
      aliases: { type: 'array', items: { type: 'string' } },
      model_type: { type: 'string' },
      key_reference: { type: 'string' },
      biomarkers: { type: 'array', items: { type: 'string' } },
      training_population: { type: 'string' },
      outcome_or_target: { type: 'string' },
      validations: { type: 'array', items: { type: 'string' } },
      spanish_involvement: { type: 'string' },
      expandability: { type: 'string' },
      evidence: { type: 'array', items: { type: 'object', properties: {
        claim: { type: 'string' }, source: { type: 'string' }, quote: { type: 'string' } }, required: ['claim', 'source'] } },
    }, required: ['name', 'key_reference', 'biomarkers', 'training_population', 'spanish_involvement', 'evidence'] } },
    datasets: { type: 'array', items: { type: 'object', properties: {
      name: { type: 'string' }, country: { type: 'string' }, description: { type: 'string' },
      base_panel_markers: { type: 'string' }, mortality_followup: { type: 'string' }, access: { type: 'string' },
      source: { type: 'string' } }, required: ['name', 'description', 'source'] } },
    findings: { type: 'array', items: { type: 'object', properties: {
      finding: { type: 'string' }, source: { type: 'string' }, quote: { type: 'string' } }, required: ['finding', 'source'] } },
    search_log: { type: 'array', items: { type: 'string' } },
    not_found: { type: 'array', items: { type: 'string' } },
  },
  required: ['candidates', 'search_log'],
}

const MERGE_SCHEMA = {
  type: 'object',
  properties: {
    shortlist: { type: 'array', items: { type: 'object', properties: {
      id: { type: 'string' }, name: { type: 'string' }, aliases: { type: 'array', items: { type: 'string' } },
      dossier: { type: 'string' }, claims_to_verify: { type: 'array', items: { type: 'string' } },
      spanish_claim: { type: 'boolean' } }, required: ['id', 'name', 'dossier', 'claims_to_verify', 'spanish_claim'] } },
    dropped: { type: 'array', items: { type: 'object', properties: {
      name: { type: 'string' }, reason: { type: 'string' } }, required: ['name', 'reason'] } },
    datasets_digest: { type: 'string' },
    cross_cutting_findings: { type: 'array', items: { type: 'string' } },
  },
  required: ['shortlist', 'dropped', 'datasets_digest'],
}

const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    id: { type: 'string' },
    verified_facts: { type: 'array', items: { type: 'object', properties: {
      fact: { type: 'string' }, source: { type: 'string' }, quote: { type: 'string' } }, required: ['fact', 'source', 'quote'] } },
    refuted_or_unverified: { type: 'array', items: { type: 'object', properties: {
      claim: { type: 'string' }, status: { type: 'string', enum: ['refuted', 'unverified'] }, note: { type: 'string' } }, required: ['claim', 'status'] } },
    biomarkers_verified: { type: 'array', items: { type: 'string' } },
    base_panel_fit: { type: 'string' },
    training_country: { type: 'string' },
    spanish_status: { type: 'string', enum: ['trained_on_spanish_data', 'validated_in_spanish_data', 'applied_in_spanish_data_only', 'none_found', 'unverified'] },
    respect_indicators: { type: 'string' },
    expandability: { type: 'string' },
    summary: { type: 'string' },
  },
  required: ['id', 'verified_facts', 'refuted_or_unverified', 'spanish_status', 'base_panel_fit', 'summary'],
}

const REFUTE_SCHEMA = {
  type: 'object',
  properties: {
    id: { type: 'string' },
    spanish_status_after_refutation: { type: 'string', enum: ['trained_on_spanish_data', 'validated_in_spanish_data', 'applied_in_spanish_data_only', 'none_found', 'unverified'] },
    reasoning: { type: 'string' },
    sources_opened: { type: 'array', items: { type: 'string' } },
  },
  required: ['id', 'spanish_status_after_refutation', 'reasoning', 'sources_opened'],
}

const CRITIC_SCHEMA = {
  type: 'object',
  properties: {
    gaps: { type: 'array', items: { type: 'object', properties: {
      gap: { type: 'string' }, search_instructions: { type: 'string' } }, required: ['gap', 'search_instructions'] } },
    assessment: { type: 'string' },
  },
  required: ['gaps', 'assessment'],
}

const JUDGE_SCHEMA = {
  type: 'object',
  properties: {
    lens: { type: 'string' },
    scores: { type: 'array', items: { type: 'object', properties: {
      option: { type: 'string' },
      validated: { type: 'number' }, spanish: { type: 'number' }, respected: { type: 'number' },
      base_panel: { type: 'number' }, expandable: { type: 'number' }, total: { type: 'number' },
      rationale: { type: 'string' } },
      required: ['option', 'validated', 'spanish', 'respected', 'base_panel', 'expandable', 'total', 'rationale'] } },
    recommendation: { type: 'string' },
    conditions: { type: 'array', items: { type: 'string' } },
    risks: { type: 'array', items: { type: 'string' } },
  },
  required: ['lens', 'scores', 'recommendation', 'conditions', 'risks'],
}

const SYNTH_SCHEMA = {
  type: 'object',
  properties: {
    answer: { type: 'string' },
    report_markdown: { type: 'string' },
    ranked_options: { type: 'array', items: { type: 'object', properties: {
      option: { type: 'string' }, rank: { type: 'number' }, criteria_met: { type: 'string' }, why: { type: 'string' } },
      required: ['option', 'rank', 'criteria_met', 'why'] } },
    open_questions: { type: 'array', items: { type: 'string' } },
  },
  required: ['answer', 'report_markdown', 'ranked_options', 'open_questions'],
}

function compact(x, max) {
  const s = JSON.stringify(x)
  return s.length > max ? s.slice(0, max) + ' ...[truncated]' : s
}

// ─── Discover ───
phase('Discover')
const disc = (await parallel(DISCOVERY.map(d => () =>
  agent(CONTEXT + d.prompt, { label: 'discover:' + d.key, phase: 'Discover', schema: DISCOVERY_SCHEMA })
    .then(r => r ? { key: d.key, ...r } : null)))).filter(Boolean)
log(`Discovery: ${disc.length} of ${DISCOVERY.length} sweeps returned, ${disc.reduce((n, d) => n + (d.candidates || []).length, 0)} candidate entries`)

// ─── Merge (barrier: dedup across all sweeps) ───
phase('Merge')
const mergePrompt = (payload) => CONTEXT + `
TASK: Merge the research sweeps below into one deduplicated SHORTLIST of candidate models for verification.
- Merge entries that are the same model under different names. Keep every source and quote.
- Always include these, with ids exactly: "eva-v3" (EVA version 3), "kdm-v2-2" (EVA's current KDM v2.2), "phenoage-levine" (original Levine PhenoAge).
- Include every published blood-based model that is relevant to at least two checklist criteria, and EVERY model with any claimed Spanish involvement, however small.
- Drop the rest, and list each drop with its reason (no silent drops).
- For each shortlisted model write a dossier (all facts with their sources) and the specific claims a skeptic must verify: biomarkers, training population and country, validations, Spanish involvement, citation counts, ability to add markers.
- Set spanish_claim true when any sweep claims training or validation in Spanish data.
- datasets_digest: a compact digest of the datasets found (Spanish first), with markers, mortality follow-up, access and sources.
- cross_cutting_findings: findings that matter for the decision (for example, no Spanish-trained model found), with sources.

SWEEPS (JSON):
${payload}
`
let merged = await agent(mergePrompt(compact(disc, 180000)), { label: 'merge', phase: 'Merge', schema: MERGE_SCHEMA })
if (!merged) throw new Error('merge failed')
log(`Shortlist: ${merged.shortlist.length} models; dropped ${merged.dropped.length}: ${merged.dropped.map(d => d.name).join(', ')}`)

// ─── Verify (pipeline: each candidate verified as soon as possible) ───
const verifyPrompt = (c) => CONTEXT + `
TASK: You are an adversarial verifier. Default to "unverified" or "refuted" unless a source you open in this task supports a claim. Do not trust the dossier below; it was written by other agents and may contain errors or invented facts.
Model: ${c.name} (id ${c.id}; aliases ${(c.aliases || []).join(', ')})
Dossier: ${c.dossier}
Claims to verify: ${JSON.stringify(c.claims_to_verify)}
Do all of this:
1. Open the key primary paper (PMC or PubMed or Europe PMC copy). Confirm the exact biomarkers, the training population and country, the outcome or target, and the sample size.
2. Check the main validations claimed, opening at least the abstract of each.
3. Compare the biomarkers with EVA's Base Panel. base_panel_fit: list which required markers the Base Panel lacks, and whether the model can run on the Base Panel alone.
4. Spanish involvement: decide trained on Spanish data, validated in Spanish data against an outcome, applied only, none found, or unverified. Search specifically for Spanish uses of this model if the dossier claims none.
5. Respect indicators: the Crossref citation count of the key paper (https://api.crossref.org/works/DOI, field is-referenced-by-count), consensus endorsements, number of independent validations.
6. Expandability: can new markers be added, and how (retraining, modules)?
Return verified facts with verbatim quotes, and every refuted or unverified claim.
For "eva-v3" and "kdm-v2-2", verify against EVA's internal documents (paths in the context) instead of publications, and say they are unpublished.`

const refutePrompt = (c, v) => CONTEXT + `
TASK: Try to REFUTE the claim that the model below was trained or validated on SPANISH data. Default to "unverified" when you cannot open a source that shows Spanish data was used. Open the original papers yourself.
Model: ${c.name} (id ${c.id})
First verifier's conclusion: ${v ? v.spanish_status : 'none'}; its facts: ${compact(v ? v.verified_facts : [], 6000)}
Dossier: ${c.dossier}
Decide the Spanish status after your own check, list the sources you opened, and explain.`

phase('Verify')
const verifyOne = (c) => agent(verifyPrompt(c), { label: 'verify:' + c.id, phase: 'Verify', schema: VERIFY_SCHEMA })
const refuteStage = (v, c) => {
  if (!v) return null
  const claims = c.spanish_claim || ['trained_on_spanish_data', 'validated_in_spanish_data'].includes(v.spanish_status)
  if (!claims) return { ...v, id: c.id, name: c.name }
  return agent(refutePrompt(c, v), { label: 'refute-spanish:' + c.id, phase: 'Verify', schema: REFUTE_SCHEMA })
    .then(r => ({ ...v, id: c.id, name: c.name, spanish_refutation: r,
      spanish_status: r ? r.spanish_status_after_refutation : 'unverified' }))
}
let verified = (await pipeline(merged.shortlist, verifyOne, refuteStage)).filter(Boolean)
log(`Verified ${verified.length} of ${merged.shortlist.length} shortlisted models`)

// ─── Critic and gap-filling, loop until dry (at most 2 rounds) ───
phase('Critic')
const searchLogs = disc.map(d => ({ sweep: d.key, log: d.search_log, not_found: d.not_found }))
let rounds = 0
let dry = false
const criticNotes = []
while (!dry && rounds < 1) {
  rounds++
  const critic = await agent(CONTEXT + `
TASK: You are a completeness critic. Find what is MISSING before EVA's CEO gets a final answer.
Look for: models or Spanish studies not covered, Spanish-language sources not searched, datasets not considered, claims left unverified that matter to the decision, criteria with no evidence (especially "Spanish trained" and "most respected"), and any internal option missing.
Verified models so far: ${compact(verified.map(v => ({ id: v.id, name: v.name, spanish: v.spanish_status, fit: v.base_panel_fit, summary: v.summary })), 40000)}
Dropped: ${compact(merged.dropped, 8000)}
Search logs: ${compact(searchLogs, 30000)}
Return at most 4 gaps, each with precise search instructions. Return an empty list if nothing important is missing.`, { label: 'critic:round' + rounds, phase: 'Critic', schema: CRITIC_SCHEMA })
  if (critic && critic.assessment) criticNotes.push(critic.assessment)
  if (!critic || !critic.gaps || critic.gaps.length === 0) { dry = true; log(`Critic round ${rounds}: nothing important missing`); break }
  log(`Critic round ${rounds}: ${critic.gaps.length} gaps: ${critic.gaps.map(g => g.gap).join(' | ')}`)
  const gapResults = (await pipeline(critic.gaps,
    g => agent(CONTEXT + `
TASK: Fill this gap in EVA's research on biological age models.
Gap: ${g.gap}
Instructions: ${g.search_instructions}
Known models already verified (do not repeat them unless you have new facts): ${verified.map(v => v.name).join(', ')}
Return new candidates, datasets and findings with sources and quotes, and your search log.`, { label: 'gap:' + rounds, phase: 'Critic', schema: DISCOVERY_SCHEMA }),
    (r, g) => {
      if (!r) return null
      const known = new Set(verified.map(v => v.name.toLowerCase()))
      const fresh = (r.candidates || []).filter(c => !known.has(String(c.name).toLowerCase()))
      if (!fresh.length) return { gap: g.gap, result: r, verified: [] }
      return parallel(fresh.slice(0, 3).map((c, i) => () => agent(verifyPrompt({
        id: 'gap' + rounds + '-' + i + '-' + String(c.name).toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30),
        name: c.name, aliases: c.aliases || [], dossier: compact(c, 8000),
        claims_to_verify: ['biomarkers', 'training population and country', 'validations', 'Spanish involvement', 'citation count', 'expandability'],
        spanish_claim: /spain|spanish|españ/i.test(String(c.spanish_involvement || '')),
      }), { label: 'verify-gap:' + c.name, phase: 'Critic', schema: VERIFY_SCHEMA })))
        .then(vs => ({ gap: g.gap, result: r, verified: vs.filter(Boolean).map(v => ({ ...v, name: v.name || v.id })) }))
    })).filter(Boolean)
  for (const gr of gapResults) {
    verified = verified.concat(gr.verified)
    searchLogs.push({ sweep: 'gap: ' + gr.gap, log: gr.result.search_log, not_found: gr.result.not_found, findings: gr.result.findings, datasets: gr.result.datasets })
  }
  const added = gapResults.reduce((n, g) => n + g.verified.length, 0)
  log(`Gap round ${rounds}: ${added} new models verified`)
  if (added === 0 && gapResults.every(g => !(g.result.findings || []).length)) dry = true
}

// ─── Judge (barrier: each judge needs every verified model) ───
phase('Judge')
const OPTIONS = `
Options to score (add any verified published model that is a realistic option for EVA as its own option):
O1 Keep KDM v2.2 (current production).
O2 EVA version 3 as it is (PhenoAge method retrained on US NHANES, six Base Panel markers, HbA1c tier).
O3 EVA version 3 plus an external validation and level recalibration on Spanish data (future work, needs a dataset).
O4 The original Levine PhenoAge, adding a complete blood count and glucose to the panel.
O5 A new model trained by EVA with the PhenoAge method on a Spanish cohort with death records (future work, needs a dataset).
O6 onward: published models from the verified list below, used as published or adapted.`
const cut = (t, n) => { const x = String(t == null ? '' : t); return x.length > n ? x.slice(0, n) + '...' : x }
const CORE = new Set(['eva-v3', 'kdm-v2-2', 'phenoage-levine', 'kdm-method', 'homeostatic-dysregulation', 'bioage-toolkit', 'bortz-ukb', 'linage', 'fi-lab', 'insilico-aging-ai', 'mark-age'])
const evidencePack = compact({
  verified: verified.map(v => {
    const core = CORE.has(v.id)
    return { id: v.id, name: v.name, spanish_status: v.spanish_status, base_panel_fit: cut(v.base_panel_fit, core ? 900 : 350),
      training_country: cut(v.training_country, 200), respect: cut(v.respect_indicators, core ? 900 : 300),
      expandability: cut(v.expandability, core ? 600 : 200), summary: cut(v.summary, core ? 1500 : 600),
      facts: (v.verified_facts || []).slice(0, core ? 12 : 5).map(f => ({ fact: cut(f.fact, core ? 400 : 250), source: cut(f.source, 160) })),
      unverified: (v.refuted_or_unverified || []).slice(0, core ? 8 : 4).map(u => cut(u.claim, 160) + ' [' + u.status + ']'),
      spanish_refutation: v.spanish_refutation ? cut(v.spanish_refutation.reasoning, 500) : undefined }
  }),
  critic_notes: criticNotes,
  datasets: merged.datasets_digest,
  cross_cutting: merged.cross_cutting_findings,
  gap_findings: searchLogs.filter(s => s.findings).map(s => ({ gap: s.sweep, findings: s.findings, datasets: s.datasets })),
}, 260000)
log(`Evidence pack: ${evidencePack.length} characters for ${verified.length} models`)
const LENSES = [
  { key: 'science', text: 'a senior epidemiologist and journal reviewer in gerontology: what would pass peer review, the strength of validation, transportability from the US to Spain, and statistical soundness' },
  { key: 'product', text: "EVA's head of product and laboratory operations in Spain: runs on the Base Panel tube from a Tasso capillary draw, works for Spanish clients, can grow with more tests and external labs, cost and time to deliver" },
  { key: 'credibility', text: 'a clinical and regulatory adviser: what a countersigning physician, an EU medical-device regulator and a skeptical journalist would accept as the most respected and defensible choice, and how to describe it honestly' },
]
const judges = (await parallel(LENSES.map(l => () => agent(CONTEXT + `
TASK: You are a judge on a panel. Your lens: ${l.text}.
Score every option 0 to 5 on each checklist criterion (validated, spanish, respected, base_panel, expandable), where 5 fully meets it. total = the sum. Use ONLY the verified evidence below and EVA's internal facts; say when evidence is missing. Do not reward claims marked unverified or refuted.
${OPTIONS}
Then give your recommendation: the option that gets EVA closest to the checklist now, the conditions to attach, and the risks.
VERIFIED EVIDENCE (JSON):
${evidencePack}`, { label: 'judge:' + l.key, phase: 'Judge', schema: JUDGE_SCHEMA })))).filter(Boolean)
log(`Judges returned: ${judges.length} of ${LENSES.length}`)

// ─── Synthesize ───
phase('Synthesize')
const final = await agent(CONTEXT + `
TASK: Write EVA's final answer: which biological age option gets EVA closest to the checklist.
Reconcile the three judges below. Where they disagree, explain why and decide.
Write report_markdown as a decision memo for the CEO, in plain English, with short sentences, no em dashes, numbers in tables. Structure:
1. The answer, in three to five sentences.
2. A table: each option against the five criteria (met, partly, not met), with one-line reasons.
3. "Spanish trained": what exists, verified, and what does not. If no Spanish-trained blood model exists, say so plainly with the search coverage.
4. "Most respected": the evidence (citations, consensus, validations, comparisons).
5. The recommended path, with the steps to close each unmet criterion (for example, which Spanish dataset to use for validation or training, how to access it, and the time it takes).
6. Risks and what would change the recommendation.
7. Sources: every source used, with URL, PMID or DOI.
answer: the one-paragraph answer for the CEO.
Use only verified facts; label anything unverified.
JUDGES (JSON): ${compact(judges, 60000)}
VERIFIED EVIDENCE (JSON): ${evidencePack}`, { label: 'synthesize', phase: 'Synthesize', schema: SYNTH_SCHEMA })

return {
  final,
  judges,
  verified,
  shortlist: merged.shortlist.map(s => ({ id: s.id, name: s.name, spanish_claim: s.spanish_claim })),
  dropped: merged.dropped,
  datasets_digest: merged.datasets_digest,
  cross_cutting: merged.cross_cutting_findings,
  search_logs: searchLogs,
  critic_rounds: rounds,
}
