export const meta = {
  name: 'model-probe-2',
  description: 'Check which models can run now: one tiny agent per model',
  phases: [{ title: 'Probe' }],
}
const SCHEMA = { type: 'object', properties: { ok: { type: 'boolean' } }, required: ['ok'] }
const models = ['claude-fable-5-2', 'opus', 'fable']
const res = await parallel(models.map((m) => () => agent('Reply with the structured result ok: true. Do nothing else.', { label: `probe ${m}`, schema: SCHEMA, model: m, effort: 'low' })))
return Object.fromEntries(models.map((m, i) => [m, res[i] ? 'ok' : 'failed']))
