export const meta = {
  name: 'signoff-central-fixes-2',
  description: 'Second round of the central fixes: the runner (D5 critical limits, G1 ownership, G2 basis) and the compile change reasons, each verified adversarially, then a B01 recheck',
  phases: [
    { title: 'Fix', detail: 'runner round 2; compile change reasons round 2' },
    { title: 'Verify', detail: 'one adversarial reviewer per area, one repair pass if rejected' },
    { title: 'Recheck', detail: 'tests, compile B01, DSRT, before and after' },
  ],
}

const SCR = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/central2'
const C = 'docs/signoff/work/central'
const B01 = '--families f01_albumin_proteins,f03_kidney,f04_inflammation'

const SHARED = [
  'You are a senior engineer fixing shared infrastructure for EVA\'s physician sign-off programme, in the repository at',
  '/home/user/eva-health on branch claude/wonderful-meitner-l4g7p5. EVA is a longevity blood-test app; the programme prepares',
  'biomarker ranges, a biological age model and a score for a licensed physician\'s sign-off. All of it is AI work product',
  'that the physician reviews.',
  '',
  'Background. The acceptance test is docs/signoff/ACCEPTANCE-TEST.md (the DSRT); its runner is scripts/signoff/dsrt.ts with',
  'checks in scripts/signoff/checks/ (npm run dsrt -- ...; it takes --work-dir for a scratch copy of docs/signoff/work). The',
  'loop tooling is in docs/signoff/tools/ (compile.js, validate.js, schemas in tools/schema/). The pilot batch B01 (families',
  'f01_albumin_proteins, f03_kidney, f04_inflammation) exposed defects in shared infrastructure. A first round of central fixes',
  'ran today; its reports and reviews are in docs/signoff/work/central/ (read them), and the B01 recheck is',
  'docs/signoff/work/central/recheck-B01.md. Evidence files: docs/signoff/work/checks/B01-r3.json (before) and B01-c1.json,',
  'the round-3 compile docs/signoff/work/compiled/B01-r3/, the decisions, verify and research files of the three families.',
  '',
  'Rules.',
  '- Write only the files listed as yours. Another agent edits other files at the same time: do not touch theirs, and run no',
  '  git command that changes the working tree or the index (no checkout, stash, reset, add, commit). To see an older',
  '  version of a file use git show <commit>:<path>.',
  '- Never query a database, apply a migration, send a message or call the app\'s API.',
  '- These specification files never change: docs/signoff/ACCEPTANCE-TEST.md, docs/signoff/LOOP-PROMPT.md, docs/signoff/PLAN.md,',
  '  docs/signoff/thresholds.json.',
  '- Runner and tool files (scripts/signoff/**, docs/signoff/tools/**) are frozen by check G1 at round 0. You may change one only',
  '  to fix a defect: the code does not do what the frozen specification text says, or it cannot work with the frozen schemas',
  '  and the files the loop produces. A change that lets a check pass more easily than the specification text allows is a',
  '  loosening and is forbidden. For every frozen file you change, your report quotes the specification text the change',
  '  implements and names the defect. The CEO approves these changes afterwards; do not edit',
  '  docs/signoff/work/governance/approved-changes.json.',
  '- Every claim in your report comes from a command you ran or a line you read. Report test results truthfully, failures included.',
  '- Do not write AI model names into any file.',
  `- Scratch files go only under ${SCR}/<your area>/.`,
  '- Write your report file before you reply, and write a partial one if you run short of time.',
].join('\n')

const AREAS = {
  runner: {
    report: `${C}/runner.json`,
    verifyFile: `${C}/runner-verify-2.json`,
    files: ['scripts/signoff/checks/data.ts', 'scripts/signoff/checks/governance.ts', 'scripts/signoff/lib/seed.ts', 'src/lib/signoff/dsrt-core.test.ts', 'src/lib/signoff/dsrt-checks.test.ts'],
    tests: 'npx vitest run src/lib/signoff',
    task: [
      `Area: runner, round 2. Your files: scripts/signoff/checks/data.ts, scripts/signoff/checks/governance.ts, scripts/signoff/lib/seed.ts, src/lib/signoff/dsrt-core.test.ts, src/lib/signoff/dsrt-checks.test.ts (runner tests only), and your report ${C}/runner.json (add a "round_2" section; keep the earlier sections). Another agent edits docs/signoff/tools/compile.js and docs/signoff/tools/lib/compile-diff.js at the same time; do not edit them.`,
      '',
      `The earlier change and its repair were reviewed twice. The last review, ${C}/runner-verify.json, rejected it for three`,
      'loosenings. Read it first; its required changes are the task.',
      '1. D5 compares only the four bounds and the unit. Compare critical_low and critical_high the same way: seed against',
      '   production plus the forward migration, each difference documented with a stated reason, a source and from/to values;',
      '   a seed value that differs from what the migration writes fails. Add a test where the migration writes a different',
      '   critical limit.',
      '2. G1. Your change made G1 take checks/<batch>-r<n>-changes.json as the complete record of the fixers\' diffs, but the',
      '   loop builds those records only from paths that contain the family id, so edits elsewhere are never recorded. Restore',
      '   G1\'s ownership part to its behaviour at commit 2cec485: blocked unless there is a complete record of every changed path',
      '   with its agent. Do not try to complete the record here. In the report, say exactly what the batch workflow',
      '   (docs/signoff/workflows/ws1-batch.js, the orchestrator\'s file) would have to record for G1 to judge ownership. If you keep',
      '   any other part of your G1 change, justify it against the specification text.',
      '3. G2. finalRowMismatches compares only the six bounds and the unit. Also compare the seed\'s Reference_Basis and',
      '   Reference_Source with the final row\'s reference_basis and reference_source, because D3\'s exemption from the catalogue',
      '   and N1 read the seed\'s basis. Add a test with a row that matches its final row on key, bounds and unit but has a',
      '   different basis.',
      'Then confirm that the findings of the first review are still met, and say how in the report: a production-only marker is',
      'retired only on an explicit record; added rows are compared with documented values; the diff path compares values;',
      'placeholder words count as missing.',
      `Run npx vitest run src/lib/signoff and npm run dsrt -- --round 3 ${B01} --seed-dir docs/signoff/work/compiled/B01-r3 --out ${SCR}/runner/after2.json.`,
      'Report D3, D5, G1 and G2 before (docs/signoff/work/checks/B01-r3.json) and after, and why each remaining failure remains.',
    ].join('\n'),
  },
  compile_reasons: {
    report: `${C}/compile-sources.json`,
    verifyFile: `${C}/compile-sources-verify-2.json`,
    files: ['docs/signoff/tools/compile.js', 'docs/signoff/tools/lib/compile-diff.js', 'docs/signoff/tools/lib/compile-sources.js', 'docs/signoff/tools/test/compile-diff.test.js', 'docs/signoff/tools/test/compile.test.js', 'docs/signoff/tools/test/compile-sources.test.js'],
    tests: 'node --test docs/signoff/tools/test/*.test.js',
    task: [
      `Area: compile change reasons, round 2. Your files: docs/signoff/tools/compile.js, docs/signoff/tools/lib/compile-diff.js, docs/signoff/tools/lib/compile-sources.js (only if needed), docs/signoff/tools/test/compile-diff.test.js, docs/signoff/tools/test/compile.test.js, docs/signoff/tools/test/compile-sources.test.js, and your report ${C}/compile-sources.json (add a "round_2" section; keep the earlier sections). The runner agent edits scripts/signoff/** at the same time; do not edit those.`,
      '',
      `The earlier change (compile-sources.js for the published summaries, compile-diff.js for the reasons of changes) was reviewed: ${C}/compile-sources-verify.json rejected it. Read it first. The summaries part was not faulted. The task:`,
      '1. The verdict step of documentedReason uses a verifier row verdict even when the fixer changed a bound after the',
      '   verdict. Use a row verdict only when the verified row also holds the compiled row\'s six bounds and unit',
      '   (verifiedSame(\'row\', ...)); otherwise publish a neutral reason for the field that states no bound. Add a test in which',
      '   the decided row changes a bound after a confirmed verdict (the shape of the B01 BUN/creatinine ratio row).',
      '2. The reason chain and the reconciliation diff were never called, because their wiring belongs in compile.js (your report\'s',
      '   hunks RS-1 and RS-2). You now own compile.js: apply them. Keep the compile deterministic and every other output',
      '   byte-identical where nothing changed. compile.js also carries the compile-rows area\'s accepted changes (optional Spanish',
      '   fields and clinical notes, commit ed30ec5); keep them.',
      '3. Compile B01 with --reconciliation-dir into your scratch dir, twice, and diff the runs. Report: changes in all, explained',
      '   by each source (decisions, verify, row), unexplained, and the diff rows with reason and source. Then run the DSRT\'s D5',
      '   and D6 on it. D6 reads <work dir>/reconciliation/, so use --work-dir with a scratch copy of docs/signoff/work whose',
      '   reconciliation/ holds your diff, forward and rollback (copy; never write the real docs/signoff/work/reconciliation/).',
      '   Report D5 and D6 before and after. The runner\'s D5 is being changed at the same time; report what you see.',
      '4. In your report, list for the CEO which frozen files this area changes, each with the specification text and the defect.',
    ].join('\n'),
  },
}

const TEST_ROW = { type: 'object', properties: { command: { type: 'string' }, passed: { type: 'boolean' }, summary: { type: 'string' } }, required: ['command', 'passed', 'summary'] }
const FIX_SCHEMA = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    files_changed: { type: 'array', items: { type: 'string' } },
    frozen_files_changed: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, spec_text: { type: 'string' }, defect: { type: 'string' }, change: { type: 'string' } }, required: ['file', 'spec_text', 'defect', 'change'] } },
    fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, check: { type: 'string' }, root_cause: { type: 'string' }, fix: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'check', 'root_cause', 'fix', 'evidence'] } },
    reported_not_fixed: { type: 'array', items: { type: 'object', properties: { id: { type: 'string' }, check: { type: 'string' }, owner: { type: 'string' }, root_cause: { type: 'string' }, proposal: { type: 'string' }, evidence: { type: 'string' } }, required: ['id', 'check', 'owner', 'root_cause', 'proposal', 'evidence'] } },
    tests: { type: 'array', items: TEST_ROW },
    report_file: { type: 'string' },
    notes: { type: 'string' },
  },
  required: ['area', 'files_changed', 'frozen_files_changed', 'fixed', 'reported_not_fixed', 'tests', 'report_file'],
}
const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    area: { type: 'string' },
    verdict: { type: 'string', enum: ['accept', 'reject'] },
    problems: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, line: { type: 'integer' }, kind: { type: 'string', enum: ['loosening', 'defect_not_fixed', 'regression', 'test_failure', 'ownership', 'determinism', 'clinical_content_changed', 'other'] }, detail: { type: 'string' }, required_change: { type: 'string' } }, required: ['kind', 'detail', 'required_change'] } },
    tests: { type: 'array', items: TEST_ROW },
    notes: { type: 'string' },
  },
  required: ['area', 'verdict', 'problems', 'tests'],
}
const RECHECK_SCHEMA = {
  type: 'object',
  properties: {
    tests: { type: 'array', items: TEST_ROW },
    compile_ok: { type: 'boolean' },
    dsrt_file: { type: 'string' },
    checks: { type: 'array', items: { type: 'object', properties: { check: { type: 'string' }, before_status: { type: 'string' }, before_failures: { type: 'integer' }, after_status: { type: 'string' }, after_failures: { type: 'integer' } }, required: ['check', 'before_status', 'before_failures', 'after_status', 'after_failures'] } },
    remaining_by_owner: { type: 'array', items: { type: 'object', properties: { owner: { type: 'string' }, check: { type: 'string' }, count: { type: 'integer' }, examples: { type: 'array', items: { type: 'string' } } }, required: ['owner', 'check', 'count'] } },
    approvals: { type: 'array', items: { type: 'object', properties: { file: { type: 'string' }, area: { type: 'string' }, verdict: { type: 'string' }, sha256: { type: 'string' } }, required: ['file', 'area', 'verdict', 'sha256'] } },
    summary_file: { type: 'string' },
    notes: { type: 'string' },
  },
  required: ['tests', 'compile_ok', 'checks', 'remaining_by_owner', 'approvals', 'summary_file'],
}

const fixPrompt = (key, repair) => [SHARED, '', AREAS[key].task, repair ? `\n\nThe reviewer rejected this round. Its findings, verbatim:\n${JSON.stringify(repair, null, 1)}\n\nAddress every required change, or show with evidence why it is wrong. Keep your file ownership. Update your report ${AREAS[key].report} (add a "round_2_repair" section) and reply with the full structured result.` : ''].join('\n')

const verifyPrompt = (key, fix) => [
  SHARED,
  '',
  `Area under review: ${key}, round 2. You did not write this change. Find what is wrong with it before the CEO is asked to approve it.`,
  '',
  `The fix agent's task was:\n---\n${AREAS[key].task}\n---`,
  `Its structured result: ${JSON.stringify(fix || {}, null, 1).slice(0, 6000)}`,
  `Its files: ${AREAS[key].files.join(', ')}. The area's state before this round is commit 975fae3; read the round's diff with git diff 975fae3 -- ${AREAS[key].files.join(' ')}, and the whole change against round 0 with git diff 2cec485 -- <the same files>. Read new files whole (git status --porcelain -uall).`,
  '',
  'Try to show each of these, and default to "reject" when you cannot confirm the opposite:',
  '1. Loosening: a check now passes in a case the specification text in docs/signoff/ACCEPTANCE-TEST.md would fail. Quote the line. Build the case and run it.',
  '2. Defect not fixed: re-run the command that showed the defect and compare. Check that every required change of the earlier review files in docs/signoff/work/central/ for this area is met.',
  `3. Regression: run ${AREAS[key].tests} and any other test that imports a touched module.`,
  '4. Ownership: changes outside the files listed for this area.',
  '5. Determinism, for compile changes: two runs give byte-identical outputs.',
  'Minor style points are not problems. A problem is something that would make the CEO wrong to approve the change.',
  `Write your verdict to ${AREAS[key].verifyFile} (verdict, problems, tests) and reply with the structured result. Write only that file and scratch files.`,
].join('\n')

async function runArea(key) {
  const fix = await agent(fixPrompt(key, null), { label: `fix ${key} r2`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'max' })
  if (!fix) { log(`fix ${key} r2: returned nothing`); return { key, fix: null, verdict: 'no_result' } }
  const v = await agent(verifyPrompt(key, fix), { label: `verify ${key} r2`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max' })
  if (!v) { log(`verify ${key} r2: returned nothing`); return { key, fix, verdict: 'unverified' } }
  if (v.verdict === 'accept') return { key, fix, verify: v, verdict: 'accept' }
  log(`verify ${key} r2: rejected with ${v.problems.length} problems; one repair pass`)
  const fix2 = await agent(fixPrompt(key, v.problems), { label: `repair ${key} r2`, phase: 'Verify', schema: FIX_SCHEMA, effort: 'max' })
  if (!fix2) return { key, fix, verify: v, verdict: 'rejected_no_repair' }
  const v2 = await agent(verifyPrompt(key, fix2), { label: `re-verify ${key} r2`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'max' })
  return { key, fix: fix2, first_verify: v, verify: v2, verdict: v2 ? v2.verdict : 'unverified' }
}

phase('Fix')
const results = (await parallel(Object.keys(AREAS).map((k) => () => runArea(k)))).filter(Boolean)
for (const r of results) log(`${r.key}: ${r.verdict}`)

phase('Recheck')
const recheck = await agent([
  SHARED,
  '',
  `Area: integration recheck, round 2. Write only ${C}/recheck-B01-2.json, ${C}/recheck-B01-2.md, docs/signoff/work/checks/B01-c2.json, the compile output docs/signoff/work/compiled/B01-c2/, and scratch files.`,
  `The round-2 areas and their verdicts: ${JSON.stringify(results.map((r) => ({ area: r.key, verdict: r.verdict, files: r.fix ? r.fix.files_changed : [] })))}. Round-1 verdicts: bounded results accepted; compile rows and the limits table accepted after report repairs; see ${C}/recheck-B01.md.`,
  '1. Run the test suites: npx vitest run src/lib/signoff src/lib/biomarkers, and node --test docs/signoff/tools/test/*.test.js. Report pass and fail counts.',
  `2. Compile B01: node docs/signoff/tools/compile.js --out-dir docs/signoff/work/compiled/B01-c2 ${B01} --reconciliation-dir docs/signoff/work/compiled/B01-c2/reconciliation`,
  `3. Run the DSRT: npm run dsrt -- --round 4 ${B01} --seed-dir docs/signoff/work/compiled/B01-c2 --out docs/signoff/work/checks/B01-c2.json. Also run D5 and D6 with --work-dir on a scratch copy of docs/signoff/work whose reconciliation/ holds the B01-c2 reconciliation set, and report them separately (the real reconciliation set is written later, by the single compile of workstream 1-K).`,
  '4. Compare with docs/signoff/work/checks/B01-r3.json and B01-c1.json check by check, counting only failures whose key names a B01 marker or family, plus G1 and G2 in full.',
  '5. Classify every remaining B01 failure by owner: "family content" (the next fixer can fix it in decisions/<family>.json), "cross-family" (K1, N1, X1: workstream 1-K), "app and score" (workstream 3), "external data" (Echevarne tables), "CEO approval" (G1).',
  `6. For the CEO approval list: every frozen file (scripts/signoff/**, docs/signoff/tools/**) that differs from round 0 (git diff --name-only 2cec485 -- scripts/signoff docs/signoff/tools, plus files added since), with its sha256 (sha256sum), the area it belongs to, and the area's final verdict (accepted, accepted after report repair, rejected). Include the files changed before today that G1 already lists (build-inputs.js, build-briefs.js and its test, bioage.ts, personas.ts) with verdict "earlier change, not reviewed today".`,
  '7. The .md is a one-page summary for the orchestrator: a table of checks before and after, the owner list with counts, and the approval list.',
].join('\n'), { label: 'recheck B01 r2', phase: 'Recheck', schema: RECHECK_SCHEMA, effort: 'high' })

return { areas: results.map((r) => ({ area: r.key, verdict: r.verdict, files: r.fix ? r.fix.files_changed : [], problems: r.verify ? r.verify.problems : [] })), recheck }
