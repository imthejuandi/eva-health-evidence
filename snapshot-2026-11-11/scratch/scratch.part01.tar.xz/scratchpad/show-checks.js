// Print E1 and E2 entries of a check file.
const fs = require("fs");
const file = process.argv[2];
const d = JSON.parse(fs.readFileSync(file, "utf8"));
console.log("keys:", Object.keys(d));
console.log("counts:", JSON.stringify(d.counts));
const checks = d.checks || d.results || [];
const arr = Array.isArray(checks) ? checks : Object.entries(checks).map(([k, v]) => ({ id: k, ...v }));
for (const c of arr) {
  const id = c.id || c.check_id;
  if (["E1", "E2"].includes(id)) console.log(JSON.stringify(c, null, 1).slice(0, 8000));
}
