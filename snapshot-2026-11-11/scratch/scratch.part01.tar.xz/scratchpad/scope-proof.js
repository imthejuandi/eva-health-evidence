// Scope proof: for each file, compare the JSON at commit c654500 with the working copy and list every changed leaf path.
// Passes only if every changed path is evidence[<i>].quote, evidence[<i>].identifier(.type|.value) or evidence[<i>].notes,
// the evidence ids and their order are unchanged, and no key was added or removed anywhere.
// Usage (from the worktree root): node scope-proof.js <base-commit> <file>...
"use strict";
const fs = require("fs");
const { execFileSync } = require("child_process");
const [base, ...files] = process.argv.slice(2);

function leaves(v, p, out) {
  if (v !== null && typeof v === "object") {
    const keys = Array.isArray(v) ? v.map((_, i) => i) : Object.keys(v);
    if (!keys.length) out.set(p, JSON.stringify(v));
    for (const k of keys) leaves(v[k], Array.isArray(v) ? `${p}[${k}]` : `${p}.${k}`, out);
  } else out.set(p, JSON.stringify(v));
  return out;
}
const ALLOWED = /^\$\.evidence\[\d+\]\.(quote|notes|identifier\.type|identifier\.value)$/;
let bad = 0;
for (const f of files) {
  const oldDoc = JSON.parse(execFileSync("git", ["show", `${base}:${f}`], { encoding: "utf8", maxBuffer: 64 * 1024 * 1024 }));
  const newDoc = JSON.parse(fs.readFileSync(f, "utf8"));
  const a = leaves(oldDoc, "$", new Map()), b = leaves(newDoc, "$", new Map());
  const changed = [];
  for (const k of new Set([...a.keys(), ...b.keys()])) {
    if (!a.has(k)) changed.push({ k, kind: "added" });
    else if (!b.has(k)) changed.push({ k, kind: "removed" });
    else if (a.get(k) !== b.get(k)) changed.push({ k, kind: "changed" });
  }
  const oldIds = (oldDoc.evidence || []).map((e) => e.id).join(","), newIds = (newDoc.evidence || []).map((e) => e.id).join(",");
  console.log(`${f}: ${changed.length} changed paths; evidence ids ${oldIds === newIds ? "identical and in the same order" : "DIFFER"}`);
  if (oldIds !== newIds) bad++;
  for (const c of changed) {
    const m = c.k.match(/^\$\.evidence\[(\d+)\]/);
    const id = m ? newDoc.evidence[Number(m[1])]?.id : "-";
    const ok = c.kind === "changed" && ALLOWED.test(c.k);
    if (!ok) bad++;
    console.log(`  ${ok ? "ok " : "OUT OF SCOPE"} ${c.kind} ${c.k} (${id})`);
  }
}
console.log(bad ? `FAIL: ${bad} out-of-scope differences` : "PASS: only evidence-record quote, identifier and notes fields differ");
process.exit(bad ? 1 : 0);
