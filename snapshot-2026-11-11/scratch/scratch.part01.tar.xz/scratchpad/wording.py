import json, re, sys
exec(open('/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/dump.py').read().split("which=sys.argv")[0])
txt=open('/home/user/eva-health/docs/signoff/work/governance/wording-rules.md').read()
block=txt.split('```json banned_terms')[1].split('```')[0]
B=json.loads(block)
en_fields=['Clinical_Notes','Msg_Critical_Low','Msg_Below_Optimal','Msg_Optimal','Msg_Above_Optimal','Msg_Critical_High']
es_fields=['Notas_Clínicas','Msg_Crítico_Bajo','Msg_Debajo_Óptimo','Msg_Óptimo','Msg_Encima_Óptimo','Msg_Crítico_Alto']
def scan(lang, text):
    hits=[]
    cfg=B[lang]
    for tier in ['any','non_critical']:
        t=text
        for a in cfg[tier].get('allow',[]):
            t=re.sub(re.escape(a),' ',t,flags=re.I)
        for rx in cfg[tier]['regex']:
            for m in re.finditer(rx,t,flags=re.I|re.M):
                hits.append((tier,rx,t[max(0,m.start()-60):m.end()+60]))
    return hits
for idx,((r,s,fl),(re_,se,fle)) in enumerate(zip(en,es)):
    k=slug(r['Biomarker'])
    if k not in fam_of: continue
    rk='%s|%s|%s|%s'%(k,r['Sex'].lower(),r['Age_Group'],r.get('State'))
    for f in en_fields:
        if r.get(f):
            for h in scan('en',r[f]): print('EN',rk,f,'L%s'%fl.get(f),h)
    for f in es_fields:
        if re_.get(f):
            for h in scan('es',re_[f]): print('ES',rk,f,'L%s'%fle.get(f),h)
    # closers
    for f in ['Msg_Critical_Low','Msg_Critical_High']:
        if r.get(f) and not r[f].endswith(B['en']['required']['out_of_range_closer']): print('NO CLOSER EN',rk,f)
    for f in ['Msg_Crítico_Bajo','Msg_Crítico_Alto']:
        if re_.get(f) and not re_[f].endswith(B['es']['required']['out_of_range_closer']): print('NO CLOSER ES',rk,f)
print('done')
