import subprocess, shutil, sys
from pathlib import Path
PR = "src/lib/biomarkers/process-results.ts"
RA = "src/lib/biomarkers/rolling-average-ba.ts"
LC = "src/lib/patient-context/lab-context.ts"
muts = [
 ("M1 processing ignores the context", PR, "supplements: await loadLabSupplements(supabase, userId, labResultId),", "supplements: null,", 1),
 ("M2 recompute ignores the context", PR, "supplements: await loadLabSupplements(supabase, userId, labResultId),", "supplements: null,", 2),
 ("M3 double adjustment", RA, "const context: KdmPatientContext = { supplements: null };", "const context: KdmPatientContext = { supplements: [{ key: \"creatine\", dose: \"5 g\" }] };", 1),
 ("M4 no per-lab adjustment", RA, "averageBiomarkers(adjustCreatinineByLab(rows, labs, versions))", "averageBiomarkers(rows)", 1),
 ("M7 rows without lab id", RA, '.select("lab_result_id, biomarker_key, value")', '.select("biomarker_key, value")', 1),
 ("M6 versions without user filter", RA, '.select("id, version_number, created_at, supplements")\n    .eq("user_id", userId);', '.select("id, version_number, created_at, supplements");', 1),
 ("M5 no fallback cutoff", LC, 'if (lab.created_at) query = query.lte("created_at", lab.created_at);', '', 1),
 ("M10 lab read by wrong id", PR, '.eq("id", labResultId)\n    .eq("user_id", userId)\n    .maybeSingle();\n  if (error) throw new Error(`loadLabSupplements', '.eq("id", userId)\n    .eq("user_id", userId)\n    .maybeSingle();\n  if (error) throw new Error(`loadLabSupplements', 1),
]
tests = ["src/lib/biomarkers/biological-age-kdm.creatinine.test.ts", "src/lib/lab-results/context-route.test.ts"]
for name, f, old, new, nth in muts:
    p = Path(f); orig = p.read_text()
    idx = -1
    for _ in range(nth):
        idx = orig.index(old, idx + 1)
    p.write_text(orig[:idx] + new + orig[idx+len(old):])
    try:
        r = subprocess.run(["npx", "vitest", "run", *tests], capture_output=True, text=True)
        out = r.stdout + r.stderr
        line = [l for l in out.splitlines() if "Tests " in l]
        print(f"{name}: {'CAUGHT' if r.returncode else 'SURVIVED'} {line[-1].strip() if line else ''}")
    finally:
        p.write_text(orig)
