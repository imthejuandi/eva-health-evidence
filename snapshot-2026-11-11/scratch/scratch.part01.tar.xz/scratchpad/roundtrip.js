// Check that each JSON file is byte-identical to JSON.stringify(parse(file), null, indent) (+ "\n" when the file ends with one),
// trying indents of 2 and 1, so that a parse-modify-serialise edit changes only the edited values.
// Usage (from the worktree root): node roundtrip.js <file>...
"use strict";
const fs = require("fs");
for (const f of process.argv.slice(2)) {
  const raw = fs.readFileSync(f, "utf8");
  const nl = raw.endsWith("\n") ? "\n" : "";
  const hit = [2, 1].find((ind) => JSON.stringify(JSON.parse(raw), null, ind) + nl === raw);
  console.log(hit ? `round-trips exactly with indent ${hit}${nl ? " and a final newline" : ", no final newline"}` : "DIFFERS", f);
}
