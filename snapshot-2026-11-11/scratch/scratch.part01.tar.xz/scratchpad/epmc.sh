#!/bin/bash
# usage: epmc.sh "query"
q="$1"
curl -sS --max-time 40 -G "https://www.ebi.ac.uk/europepmc/webservices/rest/search" --data-urlencode "query=$q" --data-urlencode "resultType=lite" --data-urlencode "format=json" --data-urlencode "pageSize=6" | node -e '
let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const j=JSON.parse(s);for(const r of j.resultList.result){console.log(`${r.pmid||"-"} | ${r.pmcid||"-"} | ${r.pubYear} | ${(r.journalTitle||"").slice(0,30)} | ${(r.title||"").slice(0,120)}`)}}catch(e){console.log("ERR",s.slice(0,200))}})'
