import json,re
base='/home/user/eva-health/docs/signoff/work/compiled/B04-r1/'
en=json.load(open(base+'biomarker-ranges-en.json'))['biomarker_ranges']
d=json.load(open(base+'rangos-biomarcadores-es.json')); k=list(d.keys())[0]; es=d[k]
print('ES top key:',k, 'EN rows',len(en),'ES rows',len(es))
# map by index (same order?) check names
keys_en=re.compile(r'^(Hematocrit|Hemoglobin|Red Blood Cell Count|MCV|MCH|MCHC|RDW|Platelet Count|MPV)$')
def nums(s):
    if not s: return []
    s=s.replace(' ',' ')
    return re.findall(r'\d[\d.,]*',s)
def norm_en(n): return n.replace(',','')
def norm_es(n):
    # Spanish: thousands '.', decimals ','
    if re.fullmatch(r'\d{1,3}(\.\d{3})+(,\d+)?',n): n=n.replace('.','').replace(',','.')
    elif ',' in n: n=n.replace('.','').replace(',','.')
    return n
pairs=[('Msg_Critical_Low','Msg_Crítico_Bajo'),('Msg_Below_Optimal','Msg_Debajo_Óptimo'),('Msg_Optimal','Msg_Óptimo'),('Msg_Above_Optimal','Msg_Encima_Óptimo'),('Msg_Critical_High','Msg_Crítico_Alto'),('Clinical_Notes','Notas_Clínicas')]
for i,r in enumerate(en):
    if not keys_en.match(r['Biomarker']): continue
    e=es[i]
    print('\n###',i,r['Biomarker'],r['Sex'],r['Age_Group'],'| ES:',e.get('Biomarcador'),e.get('Sexo'),e.get('Grupo_Edad'))
    for a,b in [('Unit','Unidad'),('Normal_Low','Normal_Bajo'),('Normal_High','Normal_Alto'),('Optimal_Low','Óptimo_Bajo'),('Optimal_High','Óptimo_Alto'),('Critical_Low','Crítico_Bajo'),('Critical_High','Crítico_Alto'),('Marker_Class','Clase_Marcador'),('Reference_Basis','Base_Referencia'),('State','Estado')]:
        if r.get(a)!=e.get(b): print('  BOUND DIFF',a,r.get(a),'vs',b,e.get(b))
    for a,b in pairs:
        ne=[float(norm_en(x).rstrip('.')) for x in nums(r.get(a)) if norm_en(x).rstrip('.')]
        ns=[float(norm_es(x).rstrip('.')) for x in nums(e.get(b)) if norm_es(x).rstrip('.')]
        if (r.get(a) is None)!=(e.get(b) is None): print('  PRESENCE DIFF',a,r.get(a) is None,b,e.get(b) is None)
        if sorted(ne)!=sorted(ns): print('  NUM DIFF',a,ne,'| ES',ns)
    # ES-only keys
    extra=[kk for kk in e.keys() if kk not in ('Categoría','Biomarcador','Unidad','Sexo','Grupo_Edad','Normal_Bajo','Normal_Alto','Óptimo_Bajo','Óptimo_Alto','Analizado_2x_Año','Notas_Clínicas','Msg_Crítico_Bajo','Msg_Debajo_Óptimo','Msg_Óptimo','Msg_Encima_Óptimo','Msg_Crítico_Alto','Crítico_Bajo','Crítico_Alto','Motivo_Sin_Crítico','Clase_Marcador','Base_Referencia','Fuente_Referencia','Estado','Nota_Método','Números_Explicativos')]
    if extra: print('  ES extra keys',extra)
