import json

OUT = "/home/user/eva-health/docs/signoff/work/judges/round-1/J5-B05.f12_white_cells_core.f13_white_cells_other.f14_iron.json"
EN = "docs/signoff/work/compiled/B05-r1/biomarker-ranges-en.json"
CHK = "docs/signoff/work/checks/B05-r1.json"

blocking = [
    {
        "family": "f14_iron",
        "row_key": "ferritin|female|All Adults|pregnancy",
        "side": "low",
        "check_id": "C2",
        "value_disputed": (
            "Normal_Low 31 ng/mL (ASH decision limit) and 'below the interval EVA uses in pregnancy ... Book an "
            "appointment', where state-rules 2.1 and C2 give a declared pregnancy only the laboratory's printed "
            "interval (Echevarne women 10-291 ng/mL) and no out-of-range; f13 uses the printed interval "
            "(eosinophils 575, not 500). Lactation row: same."
        ),
        "evidence": {
            "kind": "file_line",
            "file": EN,
            "line": 3094,
            "quote": "Your ferritin is below the interval EVA uses in pregnancy, which starts at 31 ng/mL.",
        },
        "resolution": (
            "B4: the physician cannot sign both this row and state-rules.md section 2.1 as written. For the same "
            "pregnant client the two give different outputs. The signed rule (Spanish line 43: 'el intervalo de "
            "referencia impreso por el laboratorio (Echevarne, o el laboratorio que subió el cliente), y nada más: "
            "sin categoría óptima, sin color, sin \"fuera de rango\"') shows Echevarne's printed 10-291 ng/mL "
            "(docs/vendor/echevarne/catalogo-2026-08-25.tsv line 146) with no out-of-range. The row shows 31-291 "
            "with an out-of-range message (Spanish file rangos-biomarcadores-es.json line 3094: 'por debajo del "
            "intervalo que EVA usa en el embarazo'). The fixed note (wording-rules.md line 315) says 'We show only "
            "the laboratory's reference interval'. In the same batch, f13 reads the rule the other way: its "
            "eosinophil pregnancy and lactation rows drop EVA's 500/µL for Echevarne's printed 575/µL "
            "(biomarker-ranges-en.json line 878: 'Pregnancy row (PLAN section 4; state-rules.md section 2.1): "
            "Echevarne's printed interval only'). Resolve it with one physician decision, written into "
            "state-rules.md 2.1 and 2.4 and wording-rules.md section 5 and applied to every family. "
            "Option (a): allow a named guideline's pregnancy-specific decision limit, copied exactly, with its "
            "follow-up. Here that is ASH 2026 recommendation 4 (PMC13743953, cached full text): 'For pregnant "
            "individuals, the ASH guideline panel suggests using a serum ferritin threshold of ≤30 ng/mL', applied "
            "'at any gestational age'. The fixed note then stops saying 'only the laboratory's reference interval'. "
            "Option (b): set the pregnancy and lactation rows to Echevarne's 10-291 ng/mL with no out-of-range "
            "message. The pregnancy_t3 persona's ferritin of 18 ng/mL (scripts/signoff/fixtures/personas.json "
            "line 2421) would then read inside the interval. Option (a) keeps iron deficiency in pregnancy visible. "
            "Either way, ferritin|female|All Adults|lactation (biomarker-ranges-en.json line 3121) needs a "
            "state-split record or the laboratory interval. E1 finds none (checks/B05-r1.json line 684), and the "
            "row says 'the guideline has no lactation-specific threshold' (line 3137). Align f13's eosinophil "
            "state rows to the same rule."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "white_blood_cell_count|female|All Adults|none",
        "side": "high",
        "check_id": "N1",
        "value_disputed": (
            "Optimal_High 6,000/µL: 61.8% of healthy women aged 70-79 are non-optimal (NHANES 2015-2018 median "
            "6,405/µL, n = 357), and 72.0% of men on the male row. There is no physician question: no "
            "n1-resolutions.json exists, and neither WBC row names a question or a 70-84 and 85+ policy."
        ),
        "evidence": {
            "kind": "file_line",
            "file": CHK,
            "line": 3135,
            "quote": "61.8% non-optimal at 70-79: must be a physician question",
        },
        "resolution": (
            "B5 as written in lenses.json: 'more than 60% non-optimal at 70 to 79 with no physician question'. "
            "Known issue C-14 makes this question the family's to supply. Write a physician question covering "
            "white_blood_cell_count|female and |male. Record it in docs/signoff/work/nhanes/n1-resolutions.json, "
            "kind 'physician_question', under the keys white_blood_cell_count|female|70-79|non_optimal_70_79 and "
            "white_blood_cell_count|male|70-79|non_optimal_70_79 (checks/B05-r1.json lines 3136 and 3140). Give "
            "the shares (61.8% of women, 72.0% of men; NHANES 2015-2018 medians 6,405 and 6,897/µL, "
            "docs/signoff/work/nhanes/distributions.json, nonoutcome split) and the options. (1) Keep 6,000 at 70 "
            "and over: Shah 2017 (PMC5318564, cached) found the high-count association stronger in older people: "
            "'the adjusted HR in CALIBER was 1.61 (95% CI 1.36 to 1.90) among those aged 30–45 and 2.56 (95% CI "
            "2.40 to 2.72) among those aged 60 or over'. (2) Raise the ceiling from age 70. (3) Show 70 and over "
            "as in range or out of range only. Then write the 70-84 and 85+ policy for both WBC rows on the f12 "
            "page. marker-classes.json already says 'the population check must stop 'WBC above 6,000' flagging "
            "healthy adults (J1)'."
        ),
    },
]

minor = [
    {
        "family": "f12_white_cells_core",
        "row_key": "nlr|both|65-74|none",
        "side": "high",
        "check_id": "N1",
        "value_disputed": (
            "Optimal ceiling 2.0 is held from 18 to 85+ with no N1 test (distributions.json has no NLR). "
            "Rotterdam means are 1.82 at 65-74, 2.02 at 75-84 and 2.13 at 85+, so from 75 the typical ratio "
            "is at or above 2.0. Song 2021's NHANES HR falls to 1.03 (0.98-1.08) after 94 months, so 'best long-term "
            "health' is not shown above 70."
        ),
        "evidence": {
            "kind": "source_quote",
            "identifier": {"type": "pmcid", "value": "PMC6043609"},
            "quote": (
                "The mean NLR was generally higher in the higher age categories, with the highest age category >85 "
                "years of age having a mean NLR of 2.13 versus those in the youngest age category of 45–54 years "
                "of age of 1.63"
            ),
        },
        "resolution": (
            "Compute the NLR share above 2.0 at 70-79 from NHANES neutrophil and lymphocyte counts, or state why "
            "N1 cannot, and add a physician question if it exceeds 60%. On the f12 page, state whether the 2.0 "
            "ceiling holds above 70, citing an age-stratified estimate or saying that none exists. No "
            "age-stratified estimate was found in the cached full texts of Fest 2019 (PMC6456469) or Larsen 2024 "
            "(PMC10853217). Larsen's counts were 'taken by clinical indication', and its 1–1.9 reference category "
            "was set in advance. The 75-84 and 85+ rows (Table 2 of PMC6043609: 75–84 mean 2.02) need the same "
            "statement. Song 2021 is PMC7801737, Table 3."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "nlr|both|65-74|none",
        "side": "low",
        "check_id": "K1",
        "value_disputed": (
            "No lower limit, so a ratio under 2 reads 'optimal' ('adults with a ratio below 2 had the best "
            "long-term health') even when neutrophils are below their interval and lymphocytes above theirs. "
            "K1 finds this opposite pattern at every age (e.g. 375 and 5,330/µL), with no accepted reason."
        ),
        "evidence": {
            "kind": "file_line",
            "file": CHK,
            "line": 804,
            "quote": "seen at 83 ages from 18 to 100; e.g. neutrophils_absolute 375, lymphocytes_absolute 5330 gives nlr 0.07035",
        },
        "resolution": (
            "Do not show an NLR category when either count lies outside its own interval: show the value and "
            "point to the count messages. Write the rule into the Method_Note of the four NLR rows and into the "
            "classifier change list, then re-run K1. Do not fix it with a lower limit. The rows cite f12-E46 and "
            "f12-E53 (Azab 2014, racial differences in NLR) for having none, and a lower limit near the "
            "Rotterdam 2.5th centiles (0.79 to 0.96 at ages 45-84, PMC6043609) would flag the Duffy-null persona's benign 0.58 "
            "(scripts/signoff/fixtures/personas.json, duffy_null)."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "lymphocytes|both|All Adults|none",
        "side": "low",
        "check_id": "M2",
        "value_disputed": (
            "The below-interval message names infection, stress, a meal, pregnancy and corticosteroids, but not "
            "age. In NHANES 2015-2018, healthy men aged 70-79 have a 10th centile of 16.6% and a 25th of 21.3%, "
            "so about one in five is below 20%. N1 reports 23.2% of men aged 70-79 outside the interval."
        ),
        "evidence": {
            "kind": "file_line",
            "file": CHK,
            "line": 3015,
            "quote": "23.2% outside the reference limits (rule 2% to 15%)",
        },
        "resolution": (
            "Add to the low message, in English and Spanish, that a lower percentage is more common at older "
            "ages, as the lymphocyte-count rows already say ('lower counts are more common at older ages', "
            f"{EN} line 985). The N1 justification itself belongs to known issue C-14 (workstream 1-K) and is "
            "not raised again here."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "neutrophils_absolute|male|All Adults|none",
        "side": "low",
        "check_id": "M2",
        "value_disputed": (
            "The Duffy-null line says only 'a benign inherited variant (Duffy-null phenotype) with no "
            "consequences for health'. It omits two elements state-rules 6.1 requires: that it does not raise "
            "infection risk, and that a Duffy test clarifies it. The female row has the same gap."
        ),
        "evidence": {
            "kind": "file_line",
            "file": "docs/signoff/work/governance/state-rules.md",
            "line": 179,
            "quote": "que no aumenta el riesgo de infección y que una analítica con genotipo Duffy lo aclara",
        },
        "resolution": (
            "Add both sentences to the male and female below-interval messages (biomarker-ranges-en.json lines "
            "1297 and 1331, and the same lines in the Spanish file), or have the physician drop them from 6.1 "
            "(Spanish lines 177-180, English lines 413-415), so the rule and the rows agree. For the infection "
            "sentence, state-rules 6.1 quotes Merz (S15): 'The Duffy-null phenotype is clinically insignificant'."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "white_blood_cell_count|female|All Adults|none",
        "side": "high",
        "check_id": "definition:physiological state",
        "value_disputed": (
            "The women's above-optimal message lists time of day, exercise, stress, infection and smoking, but "
            "not pregnancy, although Dockree 2021 puts the pregnancy interval at 5.7-15.0×10^9/L. A woman who has "
            "not yet declared a pregnancy is told counts above about 6,000/µL 'went with somewhat poorer "
            "long-term health'."
        ),
        "evidence": {
            "kind": "source_quote",
            "identifier": {"type": "pmid", "value": "34826802"},
            "quote": "The upper reference limit for total WBC was elevated by 36% in pregnancy (RI 5.7-15.0×109/L)",
        },
        "resolution": (
            f"Add pregnancy to the harmless causes in the women's above-optimal message ({EN} line 1398 and the "
            "Spanish line 1398), as the women's above-interval message already does ('smoking, pregnancy and "
            "medicines such as corticosteroids', line 1399). Once pregnancy is declared, state-rules 2.1 removes "
            "the optimal category, so this covers only the undeclared case. Dockree 2021 is the row's own "
            "state-split record f12-E56."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "nlr|both|18-64|none",
        "side": "high",
        "check_id": "C2",
        "value_disputed": (
            "In a declared pregnancy, state-rules 2.1 shows 'the laboratory's printed reference interval', but no "
            "laboratory prints one for the EVA-calculated NLR, so its pregnancy output is undefined. The row's "
            "state-split source (f12-E54) gives a mean of 4.0±1.4 in the second trimester, above the row's 3.53."
        ),
        "evidence": {
            "kind": "source_quote",
            "identifier": {"type": "pmid", "value": "29787560"},
            "quote": (
                "Mean PLR and NLR values were 136.3±44.3, 2.6±1, respectively during the first trimester, "
                "144.6±47.1, 4.0±1.4 respectively during the second trimester"
            ),
        },
        "resolution": (
            "State the NLR output in pregnancy and lactation in state-rules.md 2.1 or on the f12 page, for "
            "example value only, with no interval and no category. Otherwise the 18-64 row's population limit "
            f"of 3.53 ({EN} line 1061: 'No laboratory interval') appears as if it were a laboratory interval, "
            "and a typical second-trimester ratio reads above it."
        ),
    },
    {
        "family": "f14_iron",
        "row_key": "iron_binding_capacity_tibc|both|All Adults|none",
        "side": "high",
        "check_id": "C2",
        "value_disputed": (
            "The oral-oestrogen note of state-rules 4.2 sits only on SHBG, estradiol, TSH, free T4, hs-CRP and "
            "triglycerides. This row's own source f14-E31 (Campesi 2012) found that oral contraceptive use "
            "increased TIBC, and the row only names the pill as a cause in its above-interval message."
        ),
        "evidence": {
            "kind": "source_quote",
            "identifier": {"type": "pmid", "value": "22284681"},
            "quote": (
                "the use of OCs changed numerous parameters: the number of lymphocytes, iron levels, total "
                "iron-binding capacity of transferrin, triglycerides, high-density lipoprotein, total cholesterol, "
                "and C-reactive protein increased"
            ),
        },
        "resolution": (
            "Ask the physician whether the oral contraception and oral hormone therapy note of state-rules 4.2 "
            "should also sit on TIBC and serum iron. The evidence is mixed: Campesi 2012 found an increase, while "
            "Rosenmund 1986 (f14-E32, PMID 3787224) found 'No significant difference was found with respect to "
            "total iron-binding capacity and transferrin concentration' in 6 women on low-oestrogen "
            "contraception. If yes, add the flag to the state-rules 4.1 table, rule 4.2 and the C2 fixtures; if "
            "no, record the reason."
        ),
    },
    {
        "family": "f14_iron",
        "row_key": "iron_saturation_tsat|female|All Adults|premenopausal",
        "side": None,
        "check_id": "C1",
        "value_disputed": (
            "No unlabelled female TSAT or ferritin row exists, so every woman without a recorded menopause "
            "status is put on a Premenopausal or Postmenopausal row by the age-50 proxy. C1 fails this, while "
            "state-rules 3.2 allows it as the stated fallback with its note."
        ),
        "evidence": {
            "kind": "file_line",
            "file": CHK,
            "line": 634,
            "quote": "labelled row \"Premenopausal\" is picked by the age proxy at age 18, not through a recorded state (2 labelled rows match)",
        },
        "resolution": (
            "Settle the conflict between C1 ('Labelled rows are reachable only through their state') and "
            "state-rules 3.2 once, centrally. Either add female 'All Adults|none' rows for women with no recorded "
            "status (for TSAT, choose which EASL ceiling, 45% or 50%, applies without a status), or record in C1 "
            "that the age-50 fallback of 3.2, with its fixed note, is the allowed route to labelled rows. "
            "Ferritin's two female rows have the same bounds (31-291 ng/mL), so only its messages depend on the "
            "choice. The same failure is listed for ferritin (checks/B05-r1.json line 622)."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "neutrophils_absolute|male|All Adults|none",
        "side": None,
        "check_id": "definition:marker classes",
        "value_disputed": (
            "governance/action-limits.json AL-14 gives the neutrophil count as 'a (ANC is scored)', while this "
            "row (class c) and marker-classes.json (draft_class c, may_be_scored false) do not score it."
        ),
        "evidence": {
            "kind": "file_line",
            "file": "docs/signoff/work/governance/action-limits.json",
            "line": 278,
            "quote": "a (ANC is scored); the benign-cause element is mandatory in the message (check M2, element 2)",
        },
        "resolution": (
            "Correct AL-14's marker_class to c (not scored), so that the action-limit table the physician reads "
            f"in session 1 matches marker-classes.json and the f12 rows ({EN} lines 1305 and 1339). This is a "
            "governance-file correction for the orchestrator."
        ),
    },
    {
        "family": "f12_white_cells_core",
        "row_key": "white_blood_cell_count|female|All Adults|none",
        "side": "low",
        "check_id": "Q1",
        "value_disputed": (
            "WBC is the scored class a member of the leukocyte group (marker-classes.json may_be_scored true). "
            "The Duffy-null persona's WBC of 3,400/µL is below the women's 3,800, so a benign variant lowers the "
            "score under either band (score 2.0 uses 4,000-7,000). State-rules 6 makes benign variants a "
            "message line only and says nothing about the score."
        ),
        "evidence": {
            "kind": "file_line",
            "file": "scripts/signoff/fixtures/personas.json",
            "line": 245,
            "quote": "\"white_blood_cell_count\": 3400,",
        },
        "resolution": (
            "Physician question for workstream 3: whether a recorded Duffy-null phenotype, asked through the "
            "context-form question state-rules 6.1 proposes, keeps a low WBC (and neutrophil count) from "
            "lowering the score. Until it is decided, the low message keeps its benign-variant line, as it does "
            f"now ({EN} line 1395)."
        ),
    },
]

notes = (
    "AI pre-review (lens J5, geriatrics and women's health), round 1, 2026-11-10. Material read: the 32 compiled "
    "rows of f12, f13 and f14 in both languages; CHANGES.md and compile-report.json for these families; the "
    "compiled source entries; checks/B05-r1.json; state-rules.md; wording-rules.md; marker-classes.json; "
    "action-limits.json; known-issues.md. These families have no decisions files and no family pages (C3 is "
    "blocked), so the older-adult and 18-19 policies were reviewed from the rows only. "
    "State trace on the sampled rows. (1) Pregnancy, all trimesters (one state; the app records no gestational "
    "week): only eosinophils_absolute and ferritin have pregnancy rows, so each resolves to exactly one row by "
    "state; every other marker falls to rule 2.1. The ferritin row conflicts with 2.1 (blocking 1). NLR has no "
    "laboratory interval to show (minor). (2) Lactation: as pregnancy. (3) Perimenopause and postmenopause, "
    "with and without a recorded status: only ferritin and TSAT split; each resolves to one row (peri to the "
    "premenopausal row, per 3.1; no status to the age-50 proxy, per 3.2). The white-cell, iron and TIBC rows "
    "do not change with menopause. (4) Oral and transdermal hormone therapy, oral contraception: none of the "
    "six flagged markers is in these families; TIBC is a candidate (minor). (5) Luteal phase: no cycle-phase "
    "rows here. (6) Ages 70-84 and 85+: NLR has upper limits by age band up to 85+; WBC fails B5 (blocking 2); "
    "the ferritin high messages address 70+; the f13 method notes cite healthy limits at 80-89 and PQ-f13-01. "
    "(7) Benign variants: Duffy-null is present on the WBC and neutrophil low messages (minor gaps); Gilbert, "
    "thalassaemia trait and race-free eGFR are outside these families. "
    "Not raised again (known issues): C-08 (the picker never reaches the ferritin and eosinophil Pregnancy and "
    "Lactation rows, C1 lines 627 and 631; Q1 pregnant personas see optimal categories); C-12 (D2 Spanish "
    "state labels); C-14 (lymphocyte % outside 2-15% at 60-79); C-04 and C-20 (out-of-range coded "
    "'critical', for example ferritin 22 in Q1). On C-27: a scan of every Clinical_Notes and message field of "
    "these 32 rows, in both languages, against the wording-rules Part III regexes found no hit. The f12 NLR "
    "notes now read 'goes with poorer long-term health', not 'mortality'. "
    "Numbers checked in this task: ASH 2026 thresholds (PMID 42747316 abstract; PMC13743953 cached full text); "
    "Rosenmund 1986 (PMID 3787224), Campesi 2012 (PMID 22284681), Dockree 2021 (PMID 34826802) and Hershko "
    "Klement 2018 (PMID 29787560) abstracts via eutils efetch; Fest 2018 (PMC6043609), Shah 2017 (PMC5318564), "
    "Fest 2019 (PMC6456469), Larsen 2024 (PMC10853217) and Song 2021 (PMC7801737) from the repository source "
    "cache; NHANES centiles from docs/signoff/work/nhanes/distributions.json (nonoutcome split, waves "
    "2015-2018); Echevarne catalogue lines 146 and 202. WebSearch calls: 0. "
    "Tool note for the orchestrator: ledger.js extract (line 312) prints a source_quote evidence as "
    "'[object Object]', because common.schema.json makes identifier an object. The ledger entries for the four "
    "source-quote minor issues therefore lose their identifiers: PMC6043609, PMID 34826802, PMID 29787560 and "
    "PMID 22284681, as given in this file."
)

doc = {
    "schema_version": "1",
    "round": 1,
    "lens": "J5",
    "shard": "B05.f12_white_cells_core.f13_white_cells_other.f14_iron",
    "families_reviewed": ["f12_white_cells_core", "f13_white_cells_other", "f14_iron"],
    "sample_file": "docs/signoff/work/judges/round-1/sample-B05.f12_white_cells_core.f13_white_cells_other.f14_iron.json",
    "blocking": blocking,
    "minor": minor,
    "model": "claude-opus-5-5",
    "notes": notes,
}

for lst in ("blocking", "minor"):
    for it in doc[lst]:
        s = f"J5: {it['check_id']} {it['row_key'] or ''} {it['value_disputed']}"
        if len(s) > 400:
            print("SUMMARY TRUNCATED", lst, it["row_key"], len(s))
        assert "would sign" not in json.dumps(it)
assert "would sign" not in notes

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
    f.write("\n")
print("written", OUT)
