import json, os
OUT = "/home/user/eva-health/docs/signoff/work/refutations/round-3"
M = "claude-opus-5-5"
CHK = "docs/signoff/work/checks/B01-r3.json"
DEC = "docs/signoff/work/decisions/f03_kidney.json"
VER = "docs/signoff/work/verify/f03_kidney.json"
EN = "docs/signoff/work/compiled/B01-r3/biomarker-ranges-en.json"
ES = "docs/signoff/work/compiled/B01-r3/rangos-biomarcadores-es.json"
SRC = "docs/signoff/work/compiled/B01-r3/biomarker-sources.json"
PLAN = "docs/signoff/PLAN.md"
AT = "docs/signoff/ACCEPTANCE-TEST.md"
MD = "src/components/dashboard/MedicalDisclaimer.tsx"
ZC = "src/lib/biomarkers/zone-classifier.ts"

def fl(f, l, t): return {"kind": "file_line", "file": f, "line": l, "text": t}
def df(f, l, t): return {"kind": "definition", "file": f, "line": l, "text": t}
def cr(f, l, t): return {"kind": "check_result", "file": f, "line": l, "text": t}

def w(issue, verdict, reason, evidence, notes=None):
    d = {"schema_version": "1", "issue_id": issue, "round": 3, "refuter": "b", "family": "f03_kidney",
         "verdict": verdict, "reason": reason, "evidence": evidence, "model": M, "notes": notes}
    p = os.path.join(OUT, issue + "-b.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2); f.write("\n")
    print(p)

G6_SCOPE = ("G6 itself reports 'blocked' because docs/signoff/pack/ does not exist yet, so I tested whether the defect sits outside G6's scope. It does not: biomarker-sources.json is one of the three seed files that compile.js writes (SEED_FILES, compile.js line 40) and that scripts/signoff/lib/hash.ts line 52 lists among the frozen inputs. It is part of the signed ranges deliverable, so G6's second clause ('no two statements give different values for the same quantity') applies to it now. A missing pack does not excuse a contradiction inside an artefact the pack will carry.")

# 1 E3 urea
w("f03_kidney--E3--urea.both.All_Adults.none--high", "confirmed",
  "Reproduced, and the definitions do not allow it. The urea row narrows the optimal ceiling to 34 mg/dL inside the 21-54 mg/dL reference interval and records grade C with grade_c_table_entry true (decisions/f03_kidney.json lines 806-807). The verifier's row verdict for urea is grade B (verify/f03_kidney.json lines 51-53). The round-3 fixer set C, not the verifier. PLAN.md section 5 says the verifier assigns the grade, 'never the author'. It also says that at grade C the optimal band equals the reference interval unless the band is listed in the grade C decision table. docs/signoff/work/grade-c-table.json does not exist, so the band is not listed. Either way the row breaks E3. If the recorded grade C stands, the narrowed band sits outside the table. If the verifier's B stands, the row's recorded grade was not assigned by the verifier. The E3 runner lists both failures for this row (urea|both|All Adults|none|grade_author and |grade_c). E3 shows 'blocked' rather than 'fail' only because the table file is missing. The table is a programme artefact, not 'named external data' (ACCEPTANCE-TEST.md, blocked definition), so the label does not neutralise the violation. Lowering the grade is the cautious direction, and the fixer flagged the row for the table (f03-DQ08), but neither step meets the rule until the verifier confirms C and the physician lists the entry, or the optimal band is set to 21-54.",
  [df(PLAN, 110, "the grade. The verifier assigns it, never the author."),
   df(PLAN, 118, "| C | Optimal equals the reference interval, unless the band is listed in the grade C decision table for the physician, at most 20 entries |"),
   df(AT, 41, "E3 ... A grade C band appears only in the grade C decision table, at most 20 entries ... The verifier, not the author, assigns grades | script | 0 violations"),
   fl(DEC, 806, "urea row: \"grade\": \"C\", \"grade_c_table_entry\": true; optimal_low 21, optimal_high 34 inside reference 21-54"),
   fl(VER, 51, "row_verdicts: urea|both|All Adults|none, verdict corrected, grade B ('Same evidence and grade as BUN')"),
   cr(CHK, 1148, "E3 failures: urea|both|All Adults|none|grade_author 'final grade C differs from the verifier's B'; urea|both|All Adults|none|grade_c 'grade C narrowed high bound not in the grade C decision table'; status blocked on docs/signoff/work/grade-c-table.json (absent on disk, 7 November 2026)")])

# 2 G6 bun
w("f03_kidney--G6--bun.both.All_Adults.none--both", "confirmed",
  "Reproduced. Both statements contradict the compiled BUN row (reference 10-25, optimal 10-16 mg/dL; biomarker-ranges-en.json lines 4309-4312). (1) The BUN Clinical_Notes (EN line 4314, ES line 4314) say a BUN between 7 and 10 mg/dL reads below the BUN range 'while the same blood is within the urea range'. The compiled urea row now starts at 21 mg/dL. BUN 7 to 9.8 mg/dL times 2.14 is urea 15.0 to 21.0 mg/dL, so it is below the urea range too, and the sentence is false in both languages. (2) The published BUN summary in biomarker-sources.json line 12564 says the optimal BUN runs 'up to 18 mg/dL', against the row's 16. That is two statements giving different values for the same quantity. " + G6_SCOPE,
  [df(AT, 127, "G6 | Every number in the pack that exists in a result file matches it, and no two statements give different values for the same quantity | script, judge | 0 mismatches"),
   fl(EN, 4314, "Clinical_Notes: '... a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range.'"),
   fl(ES, 4314, "Notas_Clínicas: '... un BUN entre 7 y 10 mg/dL queda por debajo del intervalo del BUN aunque la misma sangre esté dentro del intervalo de la urea.'"),
   fl(EN, 4343, "urea row Optimal_High 34; urea Normal_Low 21 (decision row: reference 21-54). BUN 7-9.8 x 2.14 = 15.0-21.0 mg/dL, below 21"),
   fl(SRC, 12564, "summary_en: 'EVA's optimal BUN runs from the lower reference limit up to 18 mg/dL for all adults' (row Optimal_High 16, biomarker-ranges-en.json line 4312)"),
   fl("docs/signoff/tools/compile.js", 40, "const SEED_FILES = [\"biomarker-ranges-en.json\", \"rangos-biomarcadores-es.json\", \"biomarker-sources.json\"];")])

# 3 G6 cystatin
w("f03_kidney--G6--cystatin_c.both.All_Adults.none--high", "confirmed",
  "Reproduced. The compiled cystatin C row has optimal_high 0.72 mg/L (biomarker-ranges-en.json line 4678; decisions/f03_kidney.json, cystatin_c row at line 625). The published summary in biomarker-sources.json line 13548 says the optimal range runs 'up to 0.85 mg/L'. The other summaries the judge lists are also stale against the rows, and I checked each: BUN 'up to 18' (line 12564, row 16); urea 'optimal 21–39 ... reference range of 15–54' (line 15100, rows 21-34 and 21-54); creatinine 'optimal 0.8–1.1 ... 0.6–0.9' (line 13197, rows have no optimal band); eGFR '75 or above at 40–59 and 65–105 ... at 60 and over' (line 13831, 40-84 row 75-105); BUN/creatinine 'optimal 11–18 ... 10–20' (line 12807, row 7.6-45.5 with no band). The cause is that compile-sources keeps the previous production entry's summary_en and summary_es. " + G6_SCOPE,
  [df(AT, 127, "G6 ... no two statements give different values for the same quantity | 0 mismatches"),
   fl(SRC, 13548, "summary_en: 'EVA's optimal cystatin C has no lower limit of its own: it runs from the lower reference limit up to 0.85 mg/L'"),
   fl(EN, 4678, "cystatin C compiled row \"Optimal_High\": 0.72"),
   fl(DEC, 625, "cystatin_c|both|All Adults|none final row: reference 0.62-1.11, optimal_high 0.72, grade B"),
   fl("docs/signoff/tools/lib/compile-sources.js", 53, "entry = prev ? { ...prev } : {... summary_en: null ...} — the previous published summary is carried forward")])

# 4 G6 egfr 40-84
w("f03_kidney--G6--egfr_creatinine_based.both.40-84.none--both", "confirmed",
  "Reproduced. The compiled 40-84 eGFR row has Normal_Low 60 and optimal 75-105 (biomarker-ranges-en.json lines 4554-4558, Normal_Low at 4555; decisions/f03_kidney.json line 369). The published summary in biomarker-sources.json line 13831 says the optimal eGFR is '75 or above at 40–59 and 65–105 mL/min/1.73m² at 60 and over'. It also says 'the reference range starts at 75 at ages 18–39'. In fact the 18-39 row's reference_low is 60 (decision line 238), and the summary is silent on the 85-and-over row, which has no optimal band. So a 75-year-old with eGFR 70 is optimal in the published summary and below optimal in the app. Those are different values for the same quantity, which G6 forbids. " + G6_SCOPE,
  [df(AT, 127, "G6 ... no two statements give different values for the same quantity | 0 mismatches"),
   fl(SRC, 13831, "summary_en: 'EVA's optimal eGFR is 90 ... or above at ages 18–39, 75 or above at 40–59 and 65–105 mL/min/1.73m² at 60 and over; the reference range starts at 75 at ages 18–39 and at 60 from age 40'"),
   fl(EN, 4554, "eGFR row Age_Group 40-84: Normal_Low 60, Normal_High null, Optimal_Low 75, Optimal_High 105"),
   fl(DEC, 238, "egfr_creatinine_based|both|18-39: reference_low 60 (decision_limit), optimal 90-110; line 500: 85+ row, no optimal band, grade D")])

# 5 K1 ratio
w("f03_kidney--K1--bun_creatinine_ratio.both.All_Adults.none--none", "confirmed",
  "Reproduced against the frozen K1 rule. BUN 9.7 mg/dL is below Echevarne's 10-25 (stored code critical_low). Creatinine 1.051 mg/dL is above the female 0.55-1.02 (critical_high). Both push the ratio down (BUN sign +1, creatinine sign -1 in coherence.ts line 87). The ratio 9.7/1.051 = 9.23 sits inside the row's 7.6-45.5, and the app's classifyZone returns 'optimal' for any in-range value when both optimal bounds are null (zone-classifier.ts line 90). The runner's rule (coherence.ts header lines 13-15; judge() line 138) makes a derived 'optimal' with every input out of range an opposite pair. ACCEPTANCE-TEST K1 requires 0 opposite pairs, and only one-step disagreements can carry an accepted reason. The mirror case also reproduces: BUN 25.75 / creatinine 0.679 (male) gives 37.92, also 'optimal'. I tested whether the definitions allow this. The 7.6-45.5 limits are derived from in-interval extremes (10/1.3 = 7.69, 25/0.55 = 45.45), so an in-range ratio from two out-of-range inputs is arithmetically expected. The contradiction is the 'Optimal' label, which PLAN.md section 4 does not allow for a class e marker ('in range or out of range'). Nothing in the definitions excuses an opposite pair, and f03-DQ07 is unanswered.",
  [df(AT, 50, "K1 ... BUN/creatinine ... | script | 0 opposite-category pairs; every one-step disagreement listed with an accepted reason"),
   df(PLAN, 81, "e, reference only, such as amylase, lipase, chloride, TIBC, MPV, globulin, white-cell percentages: in range or out of range."),
   cr(CHK, 1260, "opposite|bun_creatinine|female|bun:critical_low,creatinine:critical_high->bun_creatinine_ratio:optimal; 'seen at 83 ages from 18 to 100; e.g. bun 9.7, creatinine 1.051 gives bun_creatinine_ratio 9.233'"),
   fl("scripts/signoff/checks/coherence.ts", 138, "if (ds === 0) return minL === 2 ? \"opposite\" : \"one_step\"; — derived optimal with every input out of range is opposite"),
   fl(ZC, 90, "return \"optimal\"; — reached for any in-range value when optimal_low and optimal_high are null"),
   fl(DEC, 892, "bun_creatinine_ratio|both|All Adults|none: marker_class e, reference 7.6-45.5, optimal null, grade D")])

# 6 K1 creatinine female low
w("f03_kidney--K1--creatinine.female.All_Adults.none--low", "confirmed",
  "Reproduced. I recomputed CKD-EPI 2021 with the runner's own function (coherence.ts lines 55-60). For a woman with creatinine 0.5335 mg/dL, 3% below Echevarne's 0.55 floor and so stored critical_low ('Below Range'), the function gives eGFR 105.64 at 60, 104.99 at 61 and 90.99 at 84. That is inside the 40-84 optimal band 75-105 from 61 onwards. At 85 and over the row has no optimal band, so classifyZone again returns 'optimal'. For a man with creatinine 0.679 it gives 105.14 at 62 and 104.49 at 63. The runner records 'seen at 40 ages from 61 to 100', and by its rule (input out of range, derived optimal) this is an opposite pair. K1's pass rule allows no accepted reason for an opposite pair. I tested the definitions for an exemption. Both bounds are binding: Echevarne's printed interval for creatinine, and outcome-derived optimal for eGFR (grade B). The pattern comes from that combination. But PLAN.md does not exempt K1, and the fixer's own f03-DQ04 says no row bound can remove it, so the issue stands until the app rule in f03-DQ04 option 1 or a CEO-approved K1 change.",
  [df(AT, 50, "K1 ... eGFR by CKD-EPI 2021 ... | 0 opposite-category pairs"),
   cr(CHK, 1267, "'seen at 40 ages from 61 to 100; e.g. creatinine 0.5335 gives egfr_creatinine_based 105 (eGFR by CKD-EPI 2021; derived row 40-84 optimal [75, 105], reference [60, ])' — listed as an opposite pattern"),
   fl("scripts/signoff/checks/coherence.ts", 55, "ckdEpi2021: 142 * min(r,1)^a * max(r,1)^-1.2 * 0.9938^age * 1.012 (female, k 0.7, a -0.241); recomputed: 0.5335 mg/dL -> 104.99 at 61, 90.99 at 84; male 0.679 -> 104.49 at 63"),
   fl(DEC, 124, "creatinine|female|All Adults|none: reference 0.55-1.02 (echevarne_interval), no optimal band"),
   fl(DEC, 369, "egfr_creatinine_based|both|40-84: reference_low 60, optimal 75-105, grade B")],
  notes="f03-DQ04 (decisions/f03_kidney.json physician_questions) states the pattern and offers the app rule; it is unanswered, so no resolution is recorded.")

# 7 L1 creatinine female high
w("f03_kidney--L1--creatinine.female.All_Adults.none--high", "confirmed",
  "Reproduced. The decision row for creatinine (female) carries critical_high 4.0 mg/dL and a critical-tier message: 'Contact a doctor today' (decisions/f03_kidney.json line 214). compile-rows.js line 37 says that 'the loop's true critical-tier zones ... have no seed column yet'. compile-report.json line 51 confirms that this row's critical-tier messages are 'not carried into the seed'. classifyZone (zone-classifier.ts lines 70-91) takes no critical fields and returns critical_high for any value above Normal_High (line 87). So creatinine 6 mg/dL and 1.05 mg/dL get the same out-of-range text. The schema guide in the compiled EN seed still names every out-of-range zone 'Critical Low' / 'Critical High' with condition value < Normal_Low / > Normal_High (lines 4930-4952). This is exactly what PLAN.md section 4 forbids: a critical limit has 'its own field, its own zone and its own message' and is 'never derived from the reference interval'. L1 fails on these classifier lines. The fix is in the compile and the app, not in the family file, but the row as it will reach the client breaks the definition.",
  [df(PLAN, 70, "Critical limit: a value that needs same-day medical contact. Its own field, its own zone and its own message. Never derived from the reference interval."),
   df(AT, 66, "L1 ... The classifier emits \"critical\" only from these fields, as its own zone | 100% coverage; 0 critical labels derived from reference limits"),
   fl(DEC, 214, "creatinine female messages.en.critical_high: 'Your creatinine is far above the reference interval ... Contact a doctor today; if you cannot, go to an emergency department.'"),
   fl("docs/signoff/tools/lib/compile-rows.js", 37, "// The loop's true critical-tier zones (critical_low / critical_high) have no seed column yet."),
   fl("docs/signoff/work/compiled/B01-r3/compile-report.json", 51, "creatinine|female|All Adults|none: critical-tier messages (critical_high) have no seed column; not carried into the seed"),
   cr(CHK, 1421, "L1 failures: zone-classifier.ts:86 and :87 derive critical_low / critical_high from normal limits; zone-classifier.ts|own_zone 'classifyZone takes no critical-limit fields'"),
   fl(EN, 4950, "app_schema_guide zone 'Critical High', condition 'value > Normal_High'")],
  notes="L1 also reports 'no entry in critical-limits.json' for creatinine and bun, but docs/signoff/work/governance/critical-limits.json does hold creatinine (4.0) and bun (100) entries; I did not rely on that line of the L1 output.")

# 8 L1 urea
w("f03_kidney--L1--urea.both.All_Adults.none--high", "confirmed",
  "Reproduced. The compiled urea row has Critical_High 214 (biomarker-ranges-en.json line 4352). The decision row's critical_high message, 'Contact a doctor today' (decisions/f03_kidney.json line 870), is not in the seed: compile-report.json line 56 says 'urea|both|All Adults|none: critical-tier messages (critical_high) have no seed column; not carried into the seed'. The app's classifyZone returns critical_high for any urea above Normal_High 54 (zone-classifier.ts line 87), and the only text there is Msg_Critical_High at line 4350: 'Book an appointment with your doctor in the next few weeks'. So a urea of 214 mg/dL or more gets the same routine message as 55 mg/dL. PLAN.md section 4 requires a critical limit to have its own field, zone and message, never derived from the reference interval, and L1 requires 0 critical labels derived from reference limits. Nothing in the definitions allows it.",
  [df(PLAN, 70, "Critical limit: ... Its own field, its own zone and its own message. Never derived from the reference interval."),
   df(AT, 66, "L1 ... The classifier emits \"critical\" only from these fields, as its own zone | 0 critical labels derived from reference limits"),
   fl(EN, 4352, "urea \"Critical_High\": 214"),
   fl(EN, 4350, "urea Msg_Critical_High: '... Book an appointment with your doctor in the next few weeks ...' (the out-of-range text, used for every value above 54)"),
   fl(DEC, 870, "urea messages.en.critical_high: 'Your urea is far above the reference interval ... Contact a doctor today'"),
   fl("docs/signoff/work/compiled/B01-r3/compile-report.json", 56, "urea|both|All Adults|none: critical-tier messages (critical_high) have no seed column; not carried into the seed"),
   fl(ZC, 87, "if (normalHigh != null && value > normalHigh) return \"critical_high\";")])

# 9 M3 bun low
w("f03_kidney--M3--bun.both.All_Adults.none--low", "confirmed",
  "Reproduced. A BUN below 10 mg/dL is stored as critical_low (zone-classifier.ts line 86). The labs page renders CriticalValueNotice whenever actionCount (critical_low plus critical_high) is above 0 (labs-client.tsx lines 917-921), and the dashboard does the same at dashboard-client.tsx line 1424. Its text says 'may need prompt medical attention' / 'podría necesitar atención médica pronta' (MedicalDisclaimer.tsx lines 189-193). BUN has no critical-low limit (decision row critical_low null; governance critical-limits.json gives 'No opened list carries a low BUN or urea limit'). So the critical-tier words appear outside the critical tier, which PLAN.md section 4 and M3 forbid. M3 fails with these strings. N1 also finds 25.0% of healthy NHANES women aged 20-39 and 17.5% of men aged 20-39 below 10 mg/dL (B01-r3.json lines 3911 and 3919), so the notice would reach many healthy clients. wording-rules.md lines 260-262 already say the notice breaks the rule and is removed in safe mode. That is a plan, not a fix: the app code that M3 checks still renders it.",
  [df(PLAN, 71, "\"Prompt medical attention\" appears only here [the critical limit]."),
   df(AT, 58, "M3 ... \"Prompt medical attention\", \"immediate\", \"emergency\" and \"critical\" appear only in the critical tier ... | 0 hits"),
   fl(MD, 190, "'Uno de tus marcadores está fuera del rango de referencia y podría necesitar atención médica pronta.' / line 192-193 'may need prompt medical attention'"),
   fl("src/app/[locale]/(dashboard)/labs/labs-client.tsx", 917, "{actionCount > 0 && (<CriticalValueNotice locale={locale} count={actionCount} />)} — actionCount = critical_low + critical_high"),
   fl(ZC, 86, "if (normalLow != null && value < normalLow) return \"critical_low\";"),
   cr(CHK, 1392, "M3 fail: banned 'atención médica pronta' and 'prompt medical attention' hits in MedicalDisclaimer.tsx (6 hits over 200 texts)"),
   cr(CHK, 3911, "N1: bun|female|20-39|reference_outside 25.0% outside the reference limits; line 3919 bun|male|20-39 17.5%"),
   fl("docs/signoff/work/governance/wording-rules.md", 260, "Today the app notice CriticalValueNotice ... tells every client with a value outside the reference interval that it 'may need prompt medical attention'. That breaks this rule and is removed in safe mode.")])

# 10 M3 creatinine female high
w("f03_kidney--M3--creatinine.female.All_Adults.none--high", "confirmed",
  "Reproduced. A woman's creatinine above Echevarne's 1.02 mg/dL is stored as critical_high (zone-classifier.ts line 87), even though the signed critical limit is 4.0 mg/dL (decision line 124 row: critical_high 4). Any critical_high zone makes the labs page render CriticalValueNotice (labs-client.tsx line 917), whose text is 'may need prompt medical attention' / 'podría necesitar atención médica pronta' (MedicalDisclaimer.tsx lines 189-193). That wording is reserved for the critical tier, so it breaks PLAN.md section 4 and M3, and M3 fails with these hits. The judge's population figure also checks out: docs/signoff/work/nhanes/distributions.json, cell creatinine female|70-79 (from line 4823, normal 0.55-1.02), shares_pct critical_high 18.43 at line 4874. I did not re-derive the judge's estimate of 21-24% with eGFR under 60, and the verdict does not rest on it. The fix sits in the app notice, not in the row bounds, but the defect is real for this row.",
  [df(PLAN, 71, "\"Prompt medical attention\" appears only here [the critical limit]."),
   df(AT, 58, "M3 ... \"Prompt medical attention\" ... appear only in the critical tier | 0 hits"),
   fl(MD, 190, "CriticalValueNotice body: '... fuera del rango de referencia y podría necesitar atención médica pronta' / 'outside the reference range and may need prompt medical attention'"),
   fl("src/app/[locale]/(dashboard)/labs/labs-client.tsx", 917, "{actionCount > 0 && ( ... <CriticalValueNotice locale={locale} count={actionCount} /> )}"),
   fl(DEC, 124, "creatinine|female|All Adults|none: reference 0.55-1.02, critical_high 4"),
   fl("docs/signoff/work/nhanes/distributions.json", 4874, "creatinine female|70-79 shares_pct: \"critical_high\": 18.43, \"outside_reference\": 21.09"),
   cr(CHK, 1392, "M3 fail: 'prompt medical attention' / 'atención médica pronta' hits in MedicalDisclaimer.tsx")])

# 11 definition:marker_classes ratio
w("f03_kidney--definition:marker_classes--bun_creatinine_ratio.both.All_Adults.none--none", "confirmed",
  "Reproduced, and the definition is explicit. PLAN.md section 4 gives class e markers 'in range or out of range' only. The BUN/creatinine ratio row is class e with no optimal band (decisions/f03_kidney.json line 892). The app's classifyZone returns 'optimal' for an in-range value when both optimal bounds are null (zone-classifier.ts line 90). ZONE_CONFIG labels that zone 'Optimal' / 'Optimo' with a positive tone (zone-config.ts line 18). The compile also maps the in-range text into Msg_Optimal (compile-rows.js line 41; biomarker-ranges-en.json line 4379). So the ratio is shown as Optimal, including when both inputs are out of range (K1, B01-r3.json line 1259: BUN 9.7, creatinine 1.051 gives 9.233 'optimal'). The row's message text itself is neutral ('within the range ... for information only'), which partly mitigates it. But the label the client sees is the zone label, and that label is a category the definition does not give class e. The fix is app-level (an in_range zone with a neutral label), shared with the other class e rows.",
  [df(PLAN, 81, "e, reference only, such as amylase, lipase, chloride, TIBC, MPV, globulin, white-cell percentages: in range or out of range."),
   fl(DEC, 892, "bun_creatinine_ratio|both|All Adults|none: marker_class e, optimal_low null, optimal_high null, reference 7.6-45.5"),
   fl(ZC, 90, "return \"optimal\"; — the in-range result for a row with no optimal bounds"),
   fl("src/lib/biomarkers/zone-config.ts", 18, "optimal: { ... label: \"Optimal\", label_es: \"Optimo\", tone: \"positive\" }"),
   fl(EN, 4379, "Msg_Optimal: 'Your BUN-to-creatinine ratio is within the range that a BUN and a creatinine inside their own laboratory intervals can give (7.6 to 45.5)...'"),
   cr(CHK, 1259, "K1: 'e.g. bun 9.7, creatinine 1.051 gives bun_creatinine_ratio 9.233 (... derived row All Adults optimal [, ], reference [7.6, 45.5])' classified optimal")])
