import subprocess
from pathlib import Path
muts = [
 ("confirm without refresh", "src/app/api/lab-results/confirm/route.ts", "await recomputeAndCacheUserBA(user.id, supabase).catch((err) =>", "await Promise.resolve().catch((err) =>"),
 ("reprocess without refresh", "src/app/api/lab-results/reprocess/route.ts", "await recomputeAndCacheUserBA(user.id, writer).catch((err) =>", "await Promise.resolve().catch((err) =>"),
 ("admin reprocess without refresh", "src/app/api/admin/reprocess/route.ts", "await recomputeAndCacheUserBA(labResult.user_id, supabase).catch((err) =>", "await Promise.resolve().catch((err) =>"),
 ("enter-results without refresh", "src/app/api/admin/enter-results/route.ts", "await recomputeAndCacheUserBA(userId, supabase).catch((err) =>", "await Promise.resolve().catch((err) =>"),
 ("enter-results without stamp", "src/app/api/admin/enter-results/route.ts", "patient_context_version_id: context?.id ?? null,", ""),
 ("refresh before ready (confirm)", "src/app/api/lab-results/confirm/route.ts", "    if (readyError) {\n      console.error(\"[confirm] Failed to set ready status:\", readyError);\n    } else {", "    await recomputeAndCacheUserBA(user.id, supabase);\n    if (readyError) {\n      console.error(\"[confirm] Failed to set ready status:\", readyError);\n    } else {"),
 ("recompute without finally", "src/lib/biomarkers/process-results.ts", "  try {\n    await recomputeLabFigures(userId, labResultId, supabase);\n  } finally {", "  {\n    await recomputeLabFigures(userId, labResultId, supabase);\n  } {"),
 ("auto-resolve swallows context error", "src/lib/lab-results/auto-resolve.ts", "const current = await deps.getCurrentVersion(userId, admin);", "const current = await deps.getCurrentVersion(userId, admin).catch(() => null);"),
 ("dashboard skips per-lab check", "src/lib/biomarkers/rolling-average-ba.ts", "    if (!isPlausibleCreatinineMgDl(r.value)) return [];\n", ""),
 ("KDM rechecks the averaged value", "src/lib/biomarkers/rolling-average-ba.ts", "{ supplements: null, creatinineAlreadyAdjusted: true }", "{ supplements: null }"),
]
tests = ["src/lib/lab-results/ready-routes.test.ts", "src/lib/lab-results/context-route.test.ts", "src/lib/lab-results/auto-resolve.test.ts", "src/lib/biomarkers/biological-age-kdm.creatinine.test.ts"]
for name, f, old, new in muts:
    p = Path(f); orig = p.read_text()
    assert orig.count(old) == 1, (name, orig.count(old))
    p.write_text(orig.replace(old, new))
    try:
        r = subprocess.run(["npx", "vitest", "run", *tests], capture_output=True, text=True)
        line = [l for l in (r.stdout + r.stderr).splitlines() if "Tests " in l]
        print(f"{name}: {'CAUGHT' if r.returncode else 'SURVIVED'} {line[-1].strip() if line else ''}")
    finally:
        p.write_text(orig)
