import json,re,sys
rules_md=open(sys.argv[1],encoding='utf-8').read()
m=re.search(r'```json banned_terms\n(.*?)\n```',rules_md,re.S)
rules=json.loads(m.group(1))
doc=json.load(open(sys.argv[2],encoding='utf-8'))
def scan(lang,tier,text):
    hits=[]
    t=text
    for a in rules[lang]['any'].get('allow',[]): t=t.replace(a,' ')
    for rx in rules[lang]['any']['regex']:
        if re.search(rx,t,re.I): hits.append(('any',rx))
    if tier!='critical':
        t2=text
        for a in rules[lang]['non_critical'].get('allow',[]): t2=t2.replace(a,' ')
        for rx in rules[lang]['non_critical']['regex']:
            if re.search(rx,t2,re.I): hits.append(('non_critical',rx))
    return hits
total=0
for r in doc['rows']:
    k=f"{r['marker_key']}|{r['sex']}|{r['age_group']}|{r['physiological_state']}"
    for lang in ['en','es']:
        for z,txt in r['messages'][lang].items():
            h=scan(lang,'critical' if z.startswith('critical') else 'non',txt)
            closer=rules[lang]['required']['out_of_range_closer']
            needs_closer = z in ('above_range','below_range')
            has_closer = closer in txt
            nums=sorted(set(float(x.replace(',','.')) for x in re.findall(r'\d+(?:[.,]\d+)?',txt)))
            allowed=set(x for x in [r['reference_low'],r['reference_high'],r['optimal_low'],r['optimal_high'],r['critical_low'],r['critical_high']] if x is not None)|set(r.get('explanatory_numbers',[]))|set(a['value'] for a in r['action_limits'])
            bad=[n for n in nums if n not in allowed]
            print(f"{k} {lang} {z}: hits={h} closer={'ok' if (has_closer or not needs_closer) else 'MISSING'} numbers={nums} unexplained={bad}")
            total+=len(h)
        for a in r['action_limits']:
            h=scan(lang,'non',a['follow_up_'+lang]); print(f"{k} {lang} action[{a['name']}]: hits={h}"); total+=len(h)
        for p in r['pre_analytical']:
            h=scan(lang,'non',p['text_'+lang]); print(f"{k} {lang} pre[{p['rule']}]: hits={h}"); total+=len(h)
print('TOTAL HITS',total)
