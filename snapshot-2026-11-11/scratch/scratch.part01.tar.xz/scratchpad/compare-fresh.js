// Compare freshly fetched PubMed abstracts with the repository cache copies, ignoring whitespace differences.
// Usage (from the worktree root): node compare-fresh.js <fresh-dir>
"use strict";
const fs = require("fs");
const path = require("path");
const { canonicalIdentifier, cachePaths } = require(path.resolve("docs/signoff/tools/lib/sources"));
const dir = process.argv[2];
const squash = (s) => s.replace(/\s+/g, " ").trim();
for (const f of fs.readdirSync(dir).filter((x) => x.endsWith(".txt")).sort()) {
  const pmid = f.replace(/\.txt$/, "");
  const id = canonicalIdentifier({ type: "pmid", value: pmid });
  const p = cachePaths(id.key);
  const cached = fs.existsSync(p.txt) ? fs.readFileSync(p.txt, "utf8") : null;
  const fresh = fs.readFileSync(path.join(dir, f), "utf8");
  console.log(pmid, cached == null ? "NOT CACHED" : squash(cached) === squash(fresh) ? "same text as cache" : "DIFFERS from cache");
}
