const fs=require("fs");
function find(file, rowsKey, idx, fields){
  const lines=fs.readFileSync(file,"utf8").split("\n");
  // locate the idx-th object in the array rowsKey: count lines that are exactly "    {" after the array start
  let start=lines.findIndex(l=>l.includes('"'+rowsKey+'"'));
  let count=-1, objStart=-1;
  for (let i=start+1;i<lines.length;i++){ if (/^    \{\s*$/.test(lines[i])) { count++; if (count===idx){ objStart=i; break; } } }
  const out={};
  for (let i=objStart;i<lines.length;i++){ if (/^    \},?\s*$/.test(lines[i])) break; for (const f of fields){ if (lines[i].startsWith('      "'+f+'"')) out[f]=i+1; } }
  return {objStart:objStart+1, ...out};
}
const en="/home/user/eva-health/docs/signoff/work/compiled/B02-r1/biomarker-ranges-en.json";
const es="/home/user/eva-health/docs/signoff/work/compiled/B02-r1/rangos-biomarcadores-es.json";
const F=["Biomarker","Sex","Age_Group","Normal_Low","Normal_High","Optimal_Low","Optimal_High","Msg_Optimal","Msg_Critical_High","Msg_Critical_Low","Msg_Above_Optimal","Method_Note","Reference_Source","Critical_High","Clinical_Notes"];
const FS=["Biomarcador","Normal_Alto","Msg_Óptimo","Msg_Crítico_Alto","Nota_Método","Fuente_Referencia"];
for (const i of [88,89,91,92,93,94,95,132,142,145,149,183,185]) { console.log(i, JSON.stringify(find(en,"biomarker_ranges",i,F))); console.log("   es", JSON.stringify(find(es,"rangos_biomarcadores",i,FS))); }
