import json, re, sys
REPO='/home/user/eva-health/'
KEYS={'f12_white_cells_core':["white_blood_cell_count","neutrophils_absolute","lymphocytes_absolute","nlr","neutrophils","lymphocytes"],
'f13_white_cells_other':["monocytes_absolute","eosinophils_absolute","basophils_absolute","monocytes","eosinophils","basophils"],
'f14_iron':["ferritin","iron_serum","iron_saturation_tsat","iron_binding_capacity_tibc"]}
def slug(n):
    n=n.lower(); n=re.sub(r'[()]','',n); n=re.sub(r'[^a-z0-9]+','_',n); return n.strip('_')
def load(fn):
    p=REPO+'docs/signoff/work/compiled/B05-r1/'+fn
    txt=open(p).read()
    d=json.loads(txt)
    return d, txt.split('\n')
en, enl = load('biomarker-ranges-en.json')
print(list(en.keys()))
rows=en['biomarker_ranges']
print(len(rows))
# print all biomarker names to find slug mapping
names=sorted(set(r['Biomarker'] for r in rows))
allkeys=[k for v in KEYS.values() for k in v]
for n in names:
    s=slug(n)
    if s in allkeys: print('MATCH',s,'<-',n)
missing=[k for k in allkeys if k not in [slug(n) for n in names]]
print('missing', missing)
