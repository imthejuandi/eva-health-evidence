// Summarise a Europe PMC search response (resultType=core): ids, title, journal, abstract presence, full-text flags.
// Usage: node epmc-summary.js <result.json> [--abstract]
"use strict";
const fs = require("fs");
const file = process.argv[2];
const showAbstract = process.argv.includes("--abstract");
const d = JSON.parse(fs.readFileSync(file, "utf8"));
console.log("hitCount:", d.hitCount);
for (const r of d.resultList?.result || []) {
  console.log("---");
  console.log({
    id: r.id, source: r.source, pmid: r.pmid, pmcid: r.pmcid, doi: r.doi, title: r.title,
    journal: r.journalInfo?.journal?.title, year: r.pubYear, volume: r.journalInfo?.volume, issue: r.journalInfo?.issue, pages: r.pageInfo,
    pubType: r.pubTypeList, hasAbstract: !!r.abstractText, abstractChars: (r.abstractText || "").length,
    isOpenAccess: r.isOpenAccess, inEPMC: r.inEPMC, inPMC: r.inPMC, hasPDF: r.hasPDF,
    fullTextUrls: (r.fullTextUrlList?.fullTextUrl || []).map((u) => `${u.documentStyle}/${u.availability}: ${u.url}`),
  });
  if (showAbstract && r.abstractText) console.log("ABSTRACT:", r.abstractText);
}
