import { readCreatineDose } from "@/lib/biomarkers/supplements";
const cases: [string, number | null][] = [
 ["5 g",5],["5g/día",5],["5 gramos al día",5],["5000 mg",5],["5",5],["5000",5],["5 al día",5],["5/día",5],["5 diarios",5],["5 daily",5],
 ["3 a 5 g",3],["entre 3 y 5 g",3],["3 o 5 g",3],["3-5 g",3],["2 x 5 g",10],["2x5g",10],["5 g x 2",10],
 ["1 cacito de 5 g",5],["1 medida de 5 g",5],["1 cucharadita (5 g)",5],["1 cacito (5 g)",5],["1 scoop (5 g)",5],["2 tomas de 2,5 g",5],["2 cápsulas de 750 mg",1.5],
 ["3 días a la semana, 5 g",15/7],["5 gm",5],["5 gms",5],["5 grms",5],["5 mgs",null],["1,250 g",1.25],["1.500 g",1.5],["2,500 g",2.5],["0.500 g",0.5],
 ["2 500 mg",2.5],["2 500 mg",2.5],["2 500 mg",2.5],["1 500 mg",1.5],[".5 g",0.5],[",5 g",0.5],
 ["0,3 g/kg/día",null],["0,1 g/kg",null],["1/2 g",null],["3/5 g",null],["-5 g",5],["1 scoop",null],["daily",null],["0 g",0],
 ["2,5 g 2 veces al día",5],["5 g a la semana",5/7],["5 g/semana",5/7],["5 g cada dos días",2.5],["5 g en días alternos",2.5],
 ["5 g al día durante 2 semanas",5],["5 g al día durante la semana",5],["20 g durante 5 días y luego 5 g",null],["creatina 5g",5],["5.000 mg",5],["1,5",1.5],
 ["2 cacitos (10 g)",null],["5 g por la mañana",5],["4 días/semana 5 g",20/7],
 // reviewer's cases
 ["4 cápsulas x 750 mg",3],["5 g tres días a la semana",15/7],["5 g, 3 por semana",15/7],["5 g three times a week",15/7],["5 g 3x/week",15/7],
 ["5 g al día (entreno 3 días a la semana)",null],["5 g x 3 días a la semana",15/7],["2,5 g x 30 días",2.5],["2,5 g dos veces al día",5],["2.5 g twice a day",5],
 ["2-3 cápsulas de 750 mg",1.5],["2 o 3 cápsulas de 750 mg",1.5],
 // more
 ["una cucharadita de 5 g",5],["media cucharadita de 5 g",2.5],["35 g a la semana",5],["5 g semanales",5/7],["5 g weekly",5/7],["5 g per week",5/7],
 ["5g/d",5],["3g/día",3],["5 g, 2x/día",10],["5 g 2 x día",10],["2 tomas al día de 2,5 g",5],["2 tomas de 2,5 g al día",5],["twice daily 2.5 g",5],
 ["5 a la semana",null],["5 g al día en días alternos",null],["5 g, 3 días a la semana, 2 veces al día",30/7],["5 g x 4 semanas",5],["5 g desde hace 2 meses",5],
 ["5 g x 2 veces al día",10],["1 cacito (5 g) 2 veces al día",10],["10 g/día x 7 días, luego 3 g/día",null],["8 días a la semana 5 g",null],
];
let bad = 0;
for (const [c, want] of cases) {
  const got = readCreatineDose(c);
  const ok = want === null ? got === null : got !== null && Math.abs(got - want) < 1e-9;
  if (!ok) { bad++; console.log("MISMATCH", JSON.stringify(c), "got", got, "want", want); }
}
console.log(`${cases.length - bad}/${cases.length} as intended`);
