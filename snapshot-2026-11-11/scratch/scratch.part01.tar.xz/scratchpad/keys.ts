import { loadSeed } from "/home/user/eva-health/scripts/signoff/lib/seed";
const s = loadSeed("/home/user/eva-health/supabase/seed-data")!;
console.log([...new Set(s.rows.map(r=>r.biomarker_key+"("+r.unit_en+")"))].sort().join(" "));
