#!/usr/bin/env bash
# Usage: fetch_pmc2.sh <outdir> PMC1 PMC2 ...
# Tries Europe PMC fullTextXML first, then NCBI efetch db=pmc. Converts to text.
OUT="$1"; shift
SCRIPTS="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$OUT"
for P in "$@"; do
  F="$OUT/$P.xml"
  if [ ! -s "$F" ] || ! grep -q "<article" "$F"; then
    curl -sS --max-time 90 -o "$F" "https://www.ebi.ac.uk/europepmc/webservices/rest/$P/fullTextXML"
    if ! grep -q "<article" "$F" 2>/dev/null; then
      sleep 1
      N="${P#PMC}"
      curl -sS --max-time 90 -o "$F" "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id=$N&rettype=xml"
    fi
  fi
  python3 -I "$SCRIPTS/xml2txt.py" "$F" "$OUT/$P.txt"
  NOTE=""
  grep -q "does not allow down" "$F" && NOTE="(PUBLISHER BLOCKS XML)"
  echo "$P: $(wc -c < "$F") bytes xml, $(wc -w < "$OUT/$P.txt") words $NOTE; $(head -1 "$OUT/$P.txt" | cut -c1-150)"
done
