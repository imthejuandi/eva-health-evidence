import sys, xml.etree.ElementTree as ET
t = ET.parse(sys.argv[1])
for art in t.getroot().iter('PubmedArticle'):
    pmid = art.findtext('.//PMID')
    title = ''.join(art.find('.//ArticleTitle').itertext())
    journal = art.findtext('.//Journal/Title')
    year = art.findtext('.//JournalIssue/PubDate/Year') or art.findtext('.//JournalIssue/PubDate/MedlineDate')
    dois = [e.text for e in art.iter('ArticleId') if e.get('IdType') == 'doi']
    pmc = [e.text for e in art.iter('ArticleId') if e.get('IdType') == 'pmc']
    authors = [ (a.findtext('LastName') or '') + ' ' + (a.findtext('Initials') or '') for a in art.iter('Author')]
    print('PMID', pmid, '|', year, '|', journal)
    print('TITLE', title)
    print('AUTHORS', ', '.join(authors[:8]))
    print('DOI', dois[:1], 'PMC', pmc)
    for ab in art.iter('AbstractText'):
        lab = ab.get('Label')
        print(('['+lab+'] ' if lab else '') + ''.join(ab.itertext()))
    print('-----')
