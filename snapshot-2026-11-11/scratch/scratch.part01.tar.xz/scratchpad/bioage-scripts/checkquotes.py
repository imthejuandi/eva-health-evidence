"""Check that candidate quotes appear verbatim in downloaded text files.
Usage: python3 -I checkquotes.py <dir> <quotes_file>
quotes_file lines: FILEID<TAB>quote
"""
import sys, os, re

d, qf = sys.argv[1], sys.argv[2]

def norm(s):
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    s = s.replace("–", "-").replace("—", "-").replace("−", "-")
    return " ".join(s.split())

cache = {}
for line in open(qf, encoding="utf-8"):
    line = line.rstrip("\n")
    if not line.strip() or "\t" not in line:
        continue
    fid, q = line.split("\t", 1)
    if fid not in cache:
        p = os.path.join(d, fid + ".txt")
        cache[fid] = norm(open(p, encoding="utf-8").read()) if os.path.exists(p) else ""
    ok = norm(q) in cache[fid]
    print(("OK   " if ok else "MISS ") + fid + " | " + q[:110])
