#!/usr/bin/env bash
# Usage: fetch_pmc.sh <outdir> PMC1 PMC2 ...
# Downloads Europe PMC full-text XML for each PMCID into outdir and converts to text.
OUT="$1"; shift
SCRIPTS="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$OUT"
for P in "$@"; do
  if [ ! -s "$OUT/$P.xml" ]; then
    curl -sS --max-time 90 -o "$OUT/$P.xml" "https://www.ebi.ac.uk/europepmc/webservices/rest/$P/fullTextXML"
  fi
  python3 -I "$SCRIPTS/xml2txt.py" "$OUT/$P.xml" "$OUT/$P.txt"
  echo "$P: $(wc -c < "$OUT/$P.xml") bytes xml, $(wc -w < "$OUT/$P.txt") words txt; $(head -c 200 "$OUT/$P.txt" | head -1)"
done
