#!/usr/bin/env bash
# Usage: epmc.sh "<query>" [pageSize]
# Queries Europe PMC REST search and prints compact results.
Q="$1"
N="${2:-15}"
ENC=$(python3 -I -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$Q")
curl -sS --max-time 60 "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${ENC}&format=json&resultType=lite&pageSize=${N}&sort=CITED%20desc" \
 | jq -r '"hits: \(.hitCount)", (.resultList.result[] | "\(.citedByCount // 0) cites | \(.pubYear) | \(.authorString[0:60]) | \(.title) | \(.journalTitle // .bookOrReportDetails.publisher // "") | PMID:\(.pmid // "-") PMC:\(.pmcid // "-") DOI:\(.doi // "-")")'
