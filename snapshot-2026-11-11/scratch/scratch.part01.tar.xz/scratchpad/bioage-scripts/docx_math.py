import sys, zipfile, re
z = zipfile.ZipFile(sys.argv[1])
x = z.read('word/document.xml').decode('utf8')
# find oMath blocks
blocks = re.findall(r'<m:oMathPara>.*?</m:oMathPara>|<m:oMath>.*?</m:oMath>', x, re.S)
print("n math blocks:", len(blocks))
def render(s):
    s = re.sub(r'<m:f>', ' FRAC( ', s)
    s = re.sub(r'</m:num>', ' ) OVER ( ', s)
    s = re.sub(r'</m:f>', ' ) ', s)
    s = re.sub(r'<m:sSup>', ' SUP[ ', s)
    s = re.sub(r'</m:sSup>', ' ] ', s)
    s = re.sub(r'<m:sSub>', ' SUB[ ', s)
    s = re.sub(r'</m:sSub>', ' ] ', s)
    s = re.sub(r'<m:nary>', ' NARY[ ', s)
    s = re.sub(r'</m:nary>', ' ] ', s)
    s = re.sub(r'<m:chr m:val="([^"]+)"/>', r' \1 ', s)
    s = re.sub(r'<[^>]+>', '', s)
    s = re.sub(r'\s+', ' ', s)
    return s
for b in blocks:
    print(render(b))
    print('----')
