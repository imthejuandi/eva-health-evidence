import sys, re
txt = open(sys.argv[1], encoding='utf-8', errors='replace').read()
txt = re.sub(r'<[^>]+>', ' ', txt)
txt = re.sub(r'\s+', ' ', txt)
pats = sys.argv[2].split('|')
w = int(sys.argv[3]) if len(sys.argv) > 3 else 250
seen = 0
for p in pats:
    for m in re.finditer(p, txt, flags=re.I):
        s = max(0, m.start()-w); e = min(len(txt), m.end()+w)
        print('...'+txt[s:e]+'...')
        print('---')
        seen += 1
        if seen > 12: sys.exit()
