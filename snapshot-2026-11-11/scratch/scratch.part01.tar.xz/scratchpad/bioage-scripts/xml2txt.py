"""Convert a JATS full-text XML file (Europe PMC) to plain text.
Usage: python3 -I xml2txt.py <in.xml> <out.txt>
Keeps section titles, paragraphs, table cells and figure captions.
Reference list is kept at the end in compact form.
"""
import sys
import xml.etree.ElementTree as ET

src, dst = sys.argv[1], sys.argv[2]
try:
    tree = ET.parse(src)
except ET.ParseError as e:
    with open(dst, "w") as f:
        f.write("PARSE ERROR: %s\n" % e)
    sys.exit(0)
root = tree.getroot()

out = []

def text_of(el):
    return " ".join("".join(el.itertext()).split())

# title
for t in root.iter("article-title"):
    out.append("TITLE: " + text_of(t))
    break
# abstract
for ab in root.iter("abstract"):
    out.append("ABSTRACT: " + text_of(ab))

body = root.find(".//body")
if body is not None:
    for el in body.iter():
        tag = el.tag
        if tag == "title":
            out.append("\n## " + text_of(el))
        elif tag == "p":
            out.append(text_of(el))
        elif tag == "caption":
            out.append("[CAPTION] " + text_of(el))
        elif tag == "tr":
            cells = [text_of(c) for c in el if c.tag in ("td", "th")]
            out.append("| " + " | ".join(cells) + " |")

# floats-group (tables/figures outside body)
fg = root.find(".//floats-group")
if fg is not None:
    out.append("\n## FLOATS")
    for el in fg.iter():
        if el.tag == "caption":
            out.append("[CAPTION] " + text_of(el))
        elif el.tag == "tr":
            cells = [text_of(c) for c in el if c.tag in ("td", "th")]
            out.append("| " + " | ".join(cells) + " |")
        elif el.tag == "table-wrap-foot":
            out.append("[TABLE FOOT] " + text_of(el))

back = root.find(".//back")
if back is not None:
    out.append("\n## BACK")
    for el in back.iter():
        if el.tag in ("ref",):
            out.append("REF " + (el.get("id") or "") + ": " + text_of(el)[:400])
        elif el.tag == "table-wrap-foot":
            out.append("[TABLE FOOT] " + text_of(el))
        elif el.tag == "tr":
            cells = [text_of(c) for c in el if c.tag in ("td", "th")]
            out.append("| " + " | ".join(cells) + " |")
        elif el.tag == "caption":
            out.append("[CAPTION] " + text_of(el))
        elif el.tag == "p" and el.getparent() if hasattr(el, "getparent") else False:
            pass

with open(dst, "w") as f:
    f.write("\n".join(out))
