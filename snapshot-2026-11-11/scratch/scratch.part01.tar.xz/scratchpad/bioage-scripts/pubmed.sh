#!/usr/bin/env bash
# Usage: pubmed.sh "<pubmed query>" [retmax]
# Runs a PubMed esearch, then esummary to print PMID | year | first author | title | journal.
Q="$1"
N="${2:-20}"
ENC=$(python3 -I -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1]))' "$Q")
IDS=$(curl -sS --max-time 60 "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${ENC}&retmax=${N}&retmode=json&sort=relevance")
COUNT=$(echo "$IDS" | jq -r '.esearchresult.count')
LIST=$(echo "$IDS" | jq -r '.esearchresult.idlist | join(",")')
echo "count: $COUNT"
if [ -n "$LIST" ]; then
  sleep 0.5
  curl -sS --max-time 60 "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${LIST}&retmode=json" \
   | jq -r '.result as $r | $r.uids[] | "PMID:\(.) | \($r[.].pubdate[0:4]) | \($r[.].sortfirstauthor) | \($r[.].title) | \($r[.].source)"'
fi
