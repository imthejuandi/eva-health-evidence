import sys, zipfile, re
p = sys.argv[1]
z = zipfile.ZipFile(p)
print("FILES:", [n for n in z.namelist() if not n.startswith('word/media')][:50])
x = z.read('word/document.xml').decode('utf8')
# paragraphs and table cells
x = x.replace('</w:p>', '\n').replace('</w:tc>', ' | ').replace('</w:tr>', '\n')
x = re.sub(r'<w:tab/>', '\t', x)
t = re.sub(r'<[^>]+>', '', x)
import html
t = html.unescape(t)
t = re.sub(r'\n\s*\n+', '\n', t)
print(t)
