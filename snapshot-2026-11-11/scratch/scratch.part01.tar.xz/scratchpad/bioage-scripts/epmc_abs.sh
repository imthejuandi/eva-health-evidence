#!/usr/bin/env bash
# Usage: epmc_abs.sh <PMID>
# Fetches the abstract and metadata of one PubMed record from Europe PMC.
P="$1"
curl -sS --max-time 60 "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:${P}%20AND%20SRC:MED&format=json&resultType=core" \
 | jq -r '.resultList.result[] | "TITLE: \(.title)\nAUTHORS: \(.authorString)\nJOURNAL: \(.journalInfo.journal.title // "") \(.journalInfo.yearOfPublication // "") \(.journalInfo.volume // ""):\(.pageInfo // "")\nPMID:\(.pmid // "-") PMC:\(.pmcid // "-") DOI:\(.doi // "-") CITED:\(.citedByCount)\nAFFIL: \((.authorList.author // []) | map(.authorAffiliationDetailsList.authorAffiliation[0].affiliation // "") | unique | join(" || ") | .[0:1500])\nABSTRACT: \(.abstractText // "")\n"'
