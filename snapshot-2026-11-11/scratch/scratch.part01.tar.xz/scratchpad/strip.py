import re, sys, html
def strip(x):
    x = re.sub(r'<!--.*?-->', ' ', x, flags=re.S)
    x = re.sub(r'</?(p|div|br|li|tr|td|th|h[1-6]|sec|title|abstract|table|caption|label|section|article|fig|table-wrap)\b[^>]*>', '\n', x, flags=re.I)
    x = re.sub(r'<[^>]+>', ' ', x)
    x = html.unescape(x)
    x = re.sub(r'[ \t]+', ' ', x)
    x = re.sub(r'\n\s*\n+', '\n', x)
    return x
for f in sys.argv[1:]:
    t = strip(open(f, encoding='utf-8').read())
    open(f.replace('.xml','.txt'),'w',encoding='utf-8').write(t)
    print(f, len(t))
