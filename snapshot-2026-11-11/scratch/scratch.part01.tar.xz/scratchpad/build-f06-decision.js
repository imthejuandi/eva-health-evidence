// Builds docs/signoff/work/decisions/f06_lipids_core.json (round 2) from the verify file's final_rows.
// Every text edit replaces an exact substring and throws if it is missing.
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = "/home/user/eva-health";
const VERIFY = path.join(ROOT, "docs/signoff/work/verify/f06_lipids_core.json");
const OUT = path.join(ROOT, "docs/signoff/work/decisions/f06_lipids_core.json");

const verifyBuf = fs.readFileSync(VERIFY);
const verify = JSON.parse(verifyBuf.toString("utf8"));
const verifySha = crypto.createHash("sha256").update(verifyBuf).digest("hex");
const rows = JSON.parse(JSON.stringify(verify.final_rows));
const key = (r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
const row = (k) => {
  const r = rows.find((x) => key(x) === k);
  if (!r) throw new Error(`no row ${k}`);
  return r;
};
function swap(obj, field, oldStr, newStr) {
  const v = obj[field];
  if (typeof v !== "string" || !v.includes(oldStr)) throw new Error(`substring not found in ${field}: ${oldStr.slice(0, 80)}`);
  if (v.split(oldStr).length !== 2) throw new Error(`substring not unique in ${field}: ${oldStr.slice(0, 80)}`);
  obj[field] = v.replace(oldStr, newStr);
}

const TC = "total_cholesterol|both|All Adults|none";
const LDL = "ldl_cholesterol|both|All Adults|none";
const HDLM = "hdl_cholesterol|male|All Adults|none";
const HDLF = "hdl_cholesterol|female|All Adults|none";
const TG = "triglycerides|both|All Adults|none";
const RATIO = "total_cholesterol_hdl_ratio|both|All Adults|none";

const changes = [];
const add = (c) => changes.push(c);

// ─── Total cholesterol: reference floor 0 -> null ───
const tc = row(TC);
const tcSrcOld = tc.reference_source, tcSrcEsOld = tc.reference_source_es;
if (tc.reference_low !== 0) throw new Error("TC reference_low is not 0");
tc.reference_low = null;
swap(tc, "reference_source", "One-sided limit: nothing is printed below, and EVA stores 0, which reads as no lower limit.",
  "One-sided limit: nothing is printed below and the NCEP limit defines no lower limit, so EVA stores none (null; production stored 0, which classifies every possible result the same way).");
swap(tc, "reference_source_es", "Límite de un solo lado: no se imprime nada por debajo, y EVA guarda 0, que equivale a no tener límite inferior.",
  "Límite de un solo lado: no se imprime nada por debajo y el límite del NCEP no define límite inferior, así que EVA no guarda ninguno (nulo; producción guardaba 0, que clasifica igual cualquier resultado posible).");
swap(tc, "change_vs_production", "The below-range message is dropped (no lower limit, unreachable).",
  "The below-range message is dropped, and in round 2 the reference floor 0 is stored as null (no lower limit printed or defined), so the below-range zone is unreachable for the classifier as well (decisions file, changes).");
tc.notes = `${tc.notes} Round 2 (decisions file): check N1 on the compiled ceiling of 180 gives 73.2% non-optimal in women aged 70-79 (docs/signoff/work/checks/f06_lipids_core-r1.json); physician question F06-DQ-2 replaces the figures of f06-Q05.`;

add({
  row_key: TC, field: "reference_low", from: 0, to: null, direction: "loosen",
  reason: "Checks M1 and D5 (against both the verify file and production, which store 0). The row's only limit is the NCEP decision limit 'less than 200 mg/dL--\"desirable blood cholesterol\"' (f06-E58, grade B), which Echevarne prints as '<200' mg/dL with nothing below (B0001, catalogue line 109 of docs/vendor/echevarne/catalogo-2026-08-25.tsv). Neither defines a lower limit, and PLAN.md section 4 takes the limit from the printed interval or the named guideline, so the faithful value is no lower limit (null). The stored 0 made the runner's M1 probe a negative value and count a below-range zone with no message, while the validator (docs/signoff/tools/lib/row-checks.js, reachableZones) and check D3 already read 0 as no lower limit. No possible result changes zone: classifyZone returns below range only for value < normal_low (src/lib/biomarkers/zone-classifier.ts line 86), and no cholesterol result is below 0. Counted as a loosening because a bound is removed; low values need no flag: in the PSC meta-analysis of 61 cohorts, 1 mmol/L lower total cholesterol went with lower IHD mortality at ages 40-49, 50-69 and 70-89 (hazard ratios 0.44, 0.66 and 0.83) 'with no apparent threshold' (f06-E13, grade B). The same change was made for GGT (f02), hs-CRP (f04) and fasting insulin (f05).",
  evidence_ids: ["f06-E58", "f06-E13"],
  issue_ids: ["f06_lipids_core--M1--total_cholesterol.both.All_Adults.critical_low--none", "f06_lipids_core--M1--total_cholesterol.both.All_Adults.none--low"],
});
add({ row_key: TC, field: "reference_source", from: tcSrcOld, to: tc.reference_source, direction: "neutral",
  reason: "Text follows the reference floor change (0 to null): the last sentence now says EVA stores no lower limit. No number changes.", evidence_ids: ["f06-E58"], issue_ids: ["f06_lipids_core--M1--total_cholesterol.both.All_Adults.critical_low--none"] });
add({ row_key: TC, field: "reference_source_es", from: tcSrcEsOld, to: tc.reference_source_es, direction: "neutral",
  reason: "Spanish text of the same sentence (C-11), same meaning and numbers as the English.", evidence_ids: ["f06-E58"], issue_ids: ["f06_lipids_core--M1--total_cholesterol.both.All_Adults.critical_low--none"] });

// ─── Triglycerides: reference floor 0 -> null ───
const tg = row(TG);
const tgSrcOld = tg.reference_source, tgSrcEsOld = tg.reference_source_es;
if (tg.reference_low !== 0) throw new Error("TG reference_low is not 0");
tg.reference_low = null;
swap(tg, "reference_source", "One-sided limit: 0 reads as no lower limit.",
  "One-sided limit: no lower limit is printed or defined, so EVA stores none (null; production stored 0, which classifies every possible result the same way).");
swap(tg, "reference_source_es", "Límite de un solo lado: 0 equivale a no tener límite inferior.",
  "Límite de un solo lado: no se imprime ni se define límite inferior, así que EVA no guarda ninguno (nulo; producción guardaba 0, que clasifica igual cualquier resultado posible).");
swap(tg, "change_vs_production", "Bounds unchanged (0-150, optimal up to 80).",
  "Reference floor 0 -> null in round 2 (no lower limit printed or defined; no possible result changes zone); ceiling 150 and optimal up to 80 unchanged.");
swap(tg, "notes", "above the N1 60% bar (f06-Q05).", "above the N1 60% bar (f06-Q05; round 2: F06-DQ-2 carries these shares from check N1).");

add({
  row_key: TG, field: "reference_low", from: 0, to: null, direction: "loosen",
  reason: "Checks M1 and D5 (against both the verify file and production, which store 0). The row's limit is the EAS/EFLM decision limit for fasting samples, 'abnormal concentrations correspond to triglycerides ≥1.7 mmol/L (150 mg/dL)' (f06-E07, grade B), which Echevarne prints as '<150' mg/dL with nothing below (B0004, catalogue line 422). Neither defines a lower limit, so under PLAN.md section 4 the faithful value is none (null). The stored 0 made the runner's M1 probe a negative value and count a below-range zone with no message; the validator (row-checks.js reachableZones) and check D3 already read 0 as no lower limit. No possible result changes zone (zone-classifier.ts line 86; no triglyceride result is below 0). Counted as a loosening because a bound is removed; low values need no flag: in 13,957 Copenhagen adults, non-fasting triglycerides below 89 mg/dL had the lowest all-cause mortality, hazard ratio 0.59 (0.51-0.68) against 266-442 mg/dL (f06-E37, grade B).",
  evidence_ids: ["f06-E07", "f06-E37"],
  issue_ids: ["f06_lipids_core--M1--triglycerides.both.All_Adults.critical_low--none", "f06_lipids_core--M1--total_cholesterol.both.All_Adults.none--low"],
});
add({ row_key: TG, field: "reference_source", from: tgSrcOld, to: tg.reference_source, direction: "neutral",
  reason: "Text follows the reference floor change (0 to null). No number changes.", evidence_ids: ["f06-E07"], issue_ids: ["f06_lipids_core--M1--triglycerides.both.All_Adults.critical_low--none"] });
add({ row_key: TG, field: "reference_source_es", from: tgSrcEsOld, to: tg.reference_source_es, direction: "neutral",
  reason: "Spanish text of the same sentence (C-11), same meaning and numbers as the English.", evidence_ids: ["f06-E07"], issue_ids: ["f06_lipids_core--M1--triglycerides.both.All_Adults.critical_low--none"] });

// ─── LDL cholesterol: 'reached by a minority' label (confirmed N1 issue) ───
const ldl = row(LDL);
const LDL_ISSUE = "f06_lipids_core--N1--ldl_cholesterol.both.All_Adults.none--high";
const labelReason = "Confirmed issue f06_lipids_core--N1--ldl_cholesterol.both.All_Adults.none--high (both refuters): check N1 gives an optimal band reached by fewer than 10% the 'reached by a minority' label (ACCEPTANCE-TEST.md, N1; judge criterion B5), and central item C-14 makes the label the family's part. The programme's NHANES 2015-2018 input has no LDL, so the share comes from NLA 2024 Table 1 (f06-F01, PMC full text opened in this task): in 12,696 US adults aged 18-85 not receiving lipid-modifying therapy (NHANES 2005-2016; LDL-C by the Friedewald equation) the LDL-C 1st percentile is 45 mg/dL and the 5th is 63 mg/dL, so fewer than 5%, 'fewer than 1 in 20', have 60 mg/dL or less. The sentence is a population statement under wording rules section 3.1; the locked bounds (0-100, optimal up to 60) are unchanged. Physician question F06-DQ-1.";
const old = {
  en_opt: ldl.messages.en.optimal, en_above: ldl.messages.en.above_optimal,
  es_opt: ldl.messages.es.optimal, es_above: ldl.messages.es.above_optimal,
  nums: [...ldl.explanatory_numbers],
};
swap(ldl.messages.en, "optimal", "Your LDL cholesterol is in EVA's optimal band (60 mg/dL or less). ",
  "Your LDL cholesterol is in EVA's optimal band (60 mg/dL or less). Only a minority of adults reach this band: in a US survey of adults not taking cholesterol-lowering medicine, fewer than 1 in 20 had a value this low. ");
swap(ldl.messages.en, "above_optimal", "but above EVA's optimal band (60 mg/dL or less). ",
  "but above EVA's optimal band (60 mg/dL or less). The optimal band is reached by only a minority: in a US survey of adults not taking cholesterol-lowering medicine, fewer than 1 in 20 had an LDL cholesterol of 60 mg/dL or less. ");
swap(ldl.messages.es, "optimal", "Tu colesterol LDL está en la banda óptima de EVA (60 mg/dL o menos). ",
  "Tu colesterol LDL está en la banda óptima de EVA (60 mg/dL o menos). Solo una minoría de adultos alcanza esta banda: en una encuesta de Estados Unidos en adultos que no tomaban medicación para bajar el colesterol, menos de 1 de cada 20 tenía un valor tan bajo. ");
swap(ldl.messages.es, "above_optimal", "pero por encima de la banda óptima de EVA (60 mg/dL o menos). ",
  "pero por encima de la banda óptima de EVA (60 mg/dL o menos). La banda óptima solo la alcanza una minoría: en una encuesta de Estados Unidos en adultos que no tomaban medicación para bajar el colesterol, menos de 1 de cada 20 tenía un colesterol LDL de 60 mg/dL o menos. ");
ldl.explanatory_numbers = [...new Set([...ldl.explanatory_numbers, 1, 20])].sort((a, b) => a - b);
swap(ldl, "notes", "No NHANES distribution in the bundle for LDL; the share of healthy adults at 60 mg/dL or less is expected to be small (check N1 'reached by a minority' label; f06-Q09).",
  "No NHANES distribution in the bundle for LDL. NLA 2024 Table 1 (f06-F01; NHANES 2005-2016, 12,696 adults aged 18-85 not receiving lipid-modifying therapy, LDL-C by the Friedewald equation): 1st percentile 45 mg/dL, 5th percentile 63 mg/dL, so fewer than 5% reach the band; round 2 adds the 'reached by a minority' label to the optimal and above-optimal messages in both languages (confirmed N1 issue; physician question F06-DQ-1, which takes over the label request of f06-Q09 and f06-VQ01).");
ldl.change_vs_production = `${ldl.change_vs_production} Round 2: the 'reached by a minority' label is added to the optimal and above-optimal messages, English and Spanish (f06-F01); 1 and 20 join the explanatory numbers.`;

add({ row_key: LDL, field: "messages.en.optimal", from: old.en_opt, to: ldl.messages.en.optimal, direction: "neutral", reason: labelReason, evidence_ids: ["f06-F01"], issue_ids: [LDL_ISSUE] });
add({ row_key: LDL, field: "messages.en.above_optimal", from: old.en_above, to: ldl.messages.en.above_optimal, direction: "neutral", reason: labelReason, evidence_ids: ["f06-F01"], issue_ids: [LDL_ISSUE] });
add({ row_key: LDL, field: "messages.es.optimal", from: old.es_opt, to: ldl.messages.es.optimal, direction: "neutral", reason: `${labelReason} Spanish text of the English label, same numbers.`, evidence_ids: ["f06-F01"], issue_ids: [LDL_ISSUE] });
add({ row_key: LDL, field: "messages.es.above_optimal", from: old.es_above, to: ldl.messages.es.above_optimal, direction: "neutral", reason: `${labelReason} Spanish text of the English label, same numbers.`, evidence_ids: ["f06-F01"], issue_ids: [LDL_ISSUE] });
add({ row_key: LDL, field: "explanatory_numbers", from: old.nums, to: ldl.explanatory_numbers, direction: "neutral",
  reason: "The minority label quotes '1 in 20' ('1 de cada 20'); these are a share, not bounds, so check M4 needs them in the explanatory numbers. The other numbers in the label (60) are the row's optimal ceiling.", evidence_ids: ["f06-F01"], issue_ids: [LDL_ISSUE] });

// ─── HDL women: notes only (N1 share; physician question F06-DQ-3) ───
const hf = row(HDLF);
hf.notes = `${hf.notes} Round 2 (decisions file): check N1 puts 33.3%, 29.5%, 21.7% and 20.7% of healthy women aged 20-39, 40-59, 60-69 and 70-79 below 50 mg/dL (docs/signoff/work/checks/f06_lipids_core-r1.json); physician question F06-DQ-3 carries the shares and the justification text for docs/signoff/work/nhanes/n1-resolutions.json.`;

// ─── Bound differences from production that the verify file already holds (check D5; C-02, C-21) ───
add({
  row_key: HDLF, field: "reference_high", from: 115, to: null, direction: "loosen",
  reason: "Against production (the verify file already has null; recorded here because no earlier file carries a change record, and check D5 lists it 'without a reason'). Echevarne prints only '>50' mg/dL for women (B0017, catalogue line 246), and PLAN.md section 4 takes the printed interval unless a named guideline defines the limit; no opened guideline sets an upper HDL limit, and production's 115 mg/dL matches no printed value. High HDL is still not called optimal: above the optimal ceiling of 90 mg/dL the value reads 'above optimal' with a routine message. In the Copenhagen cohorts the women's all-cause mortality was lowest at 93 mg/dL (95% CI 69-97) (f06-E31, grade B), with hazard ratios 1.10 (0.83-1.46) at 116-134 mg/dL and 1.68 (1.09-2.58) at 135 mg/dL or more (f06-E56, grade B); genetically higher HDL did not lower myocardial infarction (LIPG 396Ser, OR 0·99, 0·88-1·11; f06-E36, grade A), which is why the above-optimal message says higher HDL adds no protection. Keeping 115 as an outcome-based exception is option 2 of physician question f06-Q02.",
  evidence_ids: ["f06-E31", "f06-E56", "f06-E36"],
  issue_ids: ["f06_lipids_core--D5--hdl_cholesterol.female.All_Adults.bounds--none"],
});
add({
  row_key: HDLM, field: "reference_high", from: 100, to: null, direction: "loosen",
  reason: "Against production (the verify file already has null; recorded for check D5). Echevarne prints only '>40' mg/dL for men (B0017, catalogue line 247), and PLAN.md section 4 takes the printed interval unless a named guideline defines the limit; no opened guideline sets an upper HDL limit. High HDL is still not called optimal: above the optimal ceiling of 80 mg/dL the value reads 'above optimal' with a routine message. In the Copenhagen cohorts the men's all-cause mortality was lowest at 73 mg/dL (54-77) (f06-E31, grade B) and higher at 97-115 mg/dL (hazard ratio 1.36, 1.09-1.70) and at 116 mg/dL or more (2.06, 1.44-2.95) (f06-E32, grade B): this outcome evidence supports flagging values above 80 mg/dL as above optimal, which the row does, but it is not a guideline limit, so it cannot set the reference ceiling under PLAN.md section 4. Genetically higher HDL did not lower myocardial infarction (f06-E36, grade A). Keeping 100 as an outcome-based exception is option 2 of physician question f06-Q02.",
  evidence_ids: ["f06-E31", "f06-E32", "f06-E36"],
  issue_ids: ["f06_lipids_core--D5--hdl_cholesterol.male.All_Adults.bounds--none"],
});
add({
  row_key: TC, field: "optimal_high", from: 190, to: 180, direction: "tighten",
  reason: "Against production (the verify file already has 180; recorded for check D5). Lowest-risk category for coronary death: in 361,662 MRFIT men, CHD mortality 'increased progressively' above the 20th percentile, greater than 181 mg/dl (f06-E14, grade B), and 46% of CHD deaths were attributed to levels of 180 mg/dL or more (f06-E15, grade B); in the PSC meta-analysis lower total cholesterol went with lower IHD mortality at every age band to 89 'with no apparent threshold' (f06-E13, grade B). The former 190 was the European prevention target (f06-E17, grade C), a guideline target rather than outcome evidence. It also keeps the locked rows coherent (check K1, non-HDL = total - HDL): with 190, total 184 and HDL 52, both optimal, give non-HDL 132, above the locked reference ceiling of 130; with 180 the largest non-HDL from optimal total and HDL is 130 in men and 120 in women. Total cholesterol is not a locked marker (PLAN.md section 2; check E6); the Gate 1 entry that set 190 (DR-2026-09-25-02) is what this changes, so the physician confirms it in f06-Q01.",
  evidence_ids: ["f06-E14", "f06-E15", "f06-E13"],
  issue_ids: ["f06_lipids_core--D5--total_cholesterol.both.All_Adults.bounds--none"],
});
add({
  row_key: RATIO, field: "optimal_high", from: 3.5, to: null, direction: "loosen",
  reason: "Against production (the verify file already has null; recorded for check D5). PLAN.md section 4 gives an optimal band only to class a markers, and section 5 gives a grade D row no optimal band; the verifier graded this row D and marker-classes.json makes the ratio class e (reference only). The 3.5 matched only the men's secondary-prevention target of the one opened cut-off table ('<3.5', Millán 2009 Table 1, f06-E49, grade C), a treatment tier, and PLAN.md section 4 forbids an optimal bound that rests only on a treatment tier. The ratio adds no measurement: it divides total by HDL cholesterol, which carry their own bands. No lowest-risk band of the ratio itself was found: lower total cholesterol went with lower IHD mortality 'with no apparent threshold' (f06-E13, grade B), and genetically higher HDL did not lower myocardial infarction (f06-E36, grade A), so a lower ratio reached through higher HDL has no shown benefit. Values from 3.5 to 5 move from 'above optimal' to 'in range'. Physician question f06-Q06.",
  evidence_ids: ["f06-E13", "f06-E36", "f06-E49"],
  issue_ids: ["f06_lipids_core--D5--total_cholesterol_hdl_ratio.both.All_Adults.bounds--none"],
});
add({
  row_key: TG, field: "critical_high", from: null, to: 1000, direction: "tighten",
  reason: "Against production, whose snapshot has no critical-limit column (check D5 reads it as null); the verify file already has 1,000. It equals the governance draft docs/signoff/work/governance/critical-limits.json entries[15] (critical_high 1000, action 'Contact a doctor today; if you cannot, go to an emergency department.'), which central item C-04 asks the family's rows to match. The Endocrine Society guideline says 'severe and very severe hypertriglyceridemia (triglycerides of > 1000 mg/dl) be considered a risk for pancreatitis' (f06-E10, grade B); EAS/EFLM 2016 asks for separate referral 'when triglycerides >10 mmol/L (880 mg/dL)' (f06-E12, grade B), the alternative in physician question f06-Q04.",
  evidence_ids: ["f06-E10", "f06-E12"],
  issue_ids: ["f06_lipids_core--D5--triglycerides.both.All_Adults.bounds--none"],
});

// ─── Text fields of the total cholesterol and triglyceride rows, against production ───
// Round 2 changed these rows' reference floor after the verifier's verdict, so the compile no longer lets the verdict
// document their other fields (compile-diff.js, VERDICT_BEFORE_CHANGE). Each record below documents a field the
// round leaves exactly as the verifier saw it.
const AFTER = "This record exists because round 2 changed the row's reference floor (0 to null) after the verifier's verdict, so the compile no longer lets the verdict document the row's other fields (docs/signoff/tools/lib/compile-diff.js); round 2 does not change this field.";
const TCV = "unchanged in round 2 from the verify file, where the verifier confirmed the row (grade B)";
const TGV = "unchanged in round 2 from the verify file, where the verifier gave the row 'corrected', grade B (its two corrections concern the notes and the medication text)";
const doc1 = (k, field, reason, ev) => add({ row_key: k, field, from: "production value (snapshot 2026-09-25 with Gate 1 applied)", to: "the verify file's final row value", direction: "neutral", reason: `${reason} ${AFTER}`, evidence_ids: ev, issue_ids: [] });

doc1(TC, "messages", `Against production; ${TCV}, whose note reads 'Messages: 0 hits on M1 to M4 and the closer, and their claims match the sources'. The research author rewrote production's messages to the wording rules (docs/signoff/work/governance/wording-rules.md: second person, the four elements in the out-of-range message, the standard closer) for this row's bounds: optimal up to 180 mg/dL, reference ceiling 200 mg/dL, action limit 290 mg/dL. Production's below-range message is dropped because the row has no lower limit, so that zone holds no possible value.`, ["f06-E58", "f06-E14", "f06-E61"]);
doc1(TC, "clinical_notes", `Against production; ${TCV}. Rewritten for this row (central item C-10): total cholesterol is the sum of the plaque-forming part and HDL, and non-HDL cholesterol and ApoB show the plaque-forming part more clearly; the note quotes no bound.`, ["f06-E13"]);
doc1(TC, "method_note", `Against production, which has no method-note column; ${TCV}. It records Echevarne's code, tube and method (B0001, catalogue line 109), that the ceiling is the NCEP decision limit (f06-E58), the marker's class and redundancy group (marker-classes.json: class a, may_be_scored false, group atherogenic_lipids) and that score v2 does not use the key.`, ["f06-E58"]);
doc1(TC, "reference_basis", `Against production, which has no basis column; ${TCV}: decision_limit, the NCEP classification 'less than 200 mg/dL--"desirable blood cholesterol"' (f06-E58, grade B), which Echevarne prints as '<200' mg/dL (catalogue line 109).`, ["f06-E58"]);
doc1(TC, "explanatory_numbers", `Against production, which has no such column; ${TCV}: 2 and 4 are the repeat interval ('2 to 4 weeks') and 290 the action limit quoted in the above-range message (check M4).`, ["f06-E61"]);
doc1(TC, "marker_class", `Against production, which has no class column; ${TCV}: class a (modifiable, with outcome evidence; PLAN.md section 4), as docs/signoff/work/governance/marker-classes.json drafts it, not scored because it is redundant with non-HDL, LDL and ApoB (group atherogenic_lipids).`, ["f06-E13", "f06-E14"]);
doc1(TC, "physiological_state", `Against production, which has no state column; ${TCV}: 'none', the adult row outside pregnancy and lactation, which use the app-level rule (state-rules.md section 2.1; f06-Q07).`, []);
doc1(TC, "critical_none_reason", `Against production, which has no critical columns; ${TCV}: the 'none, because' text follows docs/signoff/work/governance/critical-limits.json entries[20] (no opened list carries a cholesterol limit; a very high value is a 'soon' finding handled by the action limit at 290 mg/dL), as central item C-04 asks.`, ["f06-E61"]);

doc1(TG, "messages", `Against production; ${TGV}; its note reads 'Messages: 0 hits on M1 to M4 and the closers; the critical message carries the critical closer'. The research author rewrote production's messages to the wording rules for this row's bounds: optimal up to 80 mg/dL, fasting reference ceiling 150 mg/dL, action limits at 150 and 500 mg/dL, critical limit 1,000 mg/dL. Production's above-range text ended with critical-tier wording ('prompt medical attention') outside the critical tier; that content now sits in its own critical zone.`, ["f06-E07", "f06-E37", "f06-E10"]);
doc1(TG, "clinical_notes", `Against production; ${TGV}. Rewritten for this row (central item C-10): triglycerides are the main circulating fat, rise after meals and with alcohol, extra weight and refined carbohydrates, and so are measured after an overnight fast; the note quotes no bound.`, ["f06-E09"]);
doc1(TG, "method_note", `Against production, which has no method-note column; ${TGV}. It records Echevarne's code, tube and method (B0004, catalogue line 422), the critical limit of critical-limits.json entries[15] (f06-E10; EAS/EFLM's 880 mg/dL is the alternative, f06-E12, f06-Q04), action limit AL-11 split at 500 mg/dL (f06-E62), the marker's class and redundancy group (marker-classes.json: class a, scored, priority member of group triglycerides) and the score v2 difference that workstream 3 aligns.`, ["f06-E10", "f06-E12", "f06-E62"]);
doc1(TG, "reference_basis", `Against production, which has no basis column; ${TGV}: decision_limit, EAS/EFLM 'for fasting samples, abnormal concentrations correspond to triglycerides ≥1.7 mmol/L (150 mg/dL)' (f06-E07, grade B), which Echevarne prints as '<150' mg/dL (catalogue line 422).`, ["f06-E07"]);
doc1(TG, "explanatory_numbers", `Against production, which has no such column; ${TGV}: 2 and 4 are the repeat interval ('2 to 4 weeks') and 500 the 'soon' action limit quoted in the above-range message (check M4).`, ["f06-E62"]);
doc1(TG, "marker_class", `Against production, which has no class column; ${TGV}: class a (modifiable, with outcome evidence; PLAN.md section 4), as marker-classes.json drafts it, scored as the priority member of group triglycerides.`, ["f06-E37", "f06-E47"]);
doc1(TG, "physiological_state", `Against production, which has no state column; ${TGV}: 'none', the adult row outside pregnancy and lactation (state-rules.md section 2.1; f06-Q07); oral oestrogen is a note on this row (state-rules.md section 4.2; f06-Q08).`, ["f06-E48"]);

// ─── New evidence record ───
const evidence = [{
  id: "f06-F01",
  supports: [{ row_key: LDL, bound: "optimal_high" }],
  identifier: { type: "url", value: "https://pmc.ncbi.nlm.nih.gov/articles/PMC11734832/" },
  citation: "Soffer DE, Marston NA, Maki KC, et al. Role of apolipoprotein B in the clinical management of cardiovascular risk in adults: An Expert Clinical Consensus from the National Lipid Association. J Clin Lipidol 2024;18(5):e647-e663. PMID 39256087; PMCID PMC11734832; doi 10.1016/j.jacl.2024.08.013.",
  year: 2024,
  quote: "Population percentiles of LDL-C, non-HDL-C, and apoB levels in untreated U.S. adults * (NHANES 2005–2016, n=12,696) Percentiles in the untreated population LDL-C † (mg/dL) Non-HDL-C (mg/dL) ApoB (mg/dL) 1 45 59 41 5 63 79 54 10 72 88 61",
  location: "Table 1 and its footnotes: '* Adults 18–85 years of age not receiving lipid-modifying therapy. † Calculated using the Friedewald equation. TG levels in the participants were 12–400 mg/dL.'",
  design: "expert clinical consensus of the National Lipid Association reporting population percentiles from the US National Health and Nutrition Examination Survey (cross-sectional, nationally representative)",
  n: 12696,
  follow_up_years: null,
  outcome: "distribution of LDL-C, non-HDL-C and apoB in untreated US adults (the share of adults at or below a level); not an outcome",
  population_age: "18 to 85 years",
  population_sex: "both",
  assay: "LDL-C calculated with the Friedewald equation (triglycerides 12-400 mg/dL); non-HDL-C and apoB as measured in NHANES 2005-2016",
  band_rule: "none",
  basis_class: "expert_opinion",
  proposed_grade: "C",
  age_stratified_statement: "Table 1 gives no age- or sex-specific percentiles: it pools adults aged 18 to 85, so the share at 70-79 or 80 and over cannot be read from it.",
  notes: "Used only for the N1 'reached by a minority' label of the locked LDL band: it measures how many untreated adults reach 60 mg/dL or less and does not support the value 60 (the band's outcome records are f06-E18 to f06-E26). The 5th percentile (63 mg/dL) is above 60, so fewer than 5% reach the band; the 1st percentile is 45. For non-HDL the 10th percentile is 88 and the 20th 103 mg/dL, so at least 10% reach the non-HDL band of 90 or less (no label; the J3 issue on non-HDL was refuted). Identifier: the PMC article page, because Europe PMC's fullTextXML endpoint, which quote-check.js uses for a PMCID, returned HTTP 500 for PMC11734832 in this task, and its fallback abstract does not hold Table 1; the PubMed record is PMID 39256087. The quote was read from the PMC page with the repository's stripTags (docs/signoff/tools/lib/sources.js). Proposed grade C: descriptive survey data in a society consensus, not outcome evidence; the verifier grades it.",
}];

// ─── Physician questions ───
const physician_questions = [
  {
    id: "F06-DQ-1",
    row_key: LDL,
    question: "LDL cholesterol, locked band (optimal up to 60 mg/dL): approve the 'reached by a minority' label now written into the optimal and above-optimal messages in both languages, and keep the band and its wording unchanged at 70 to 84 and at 85 and over? (Adds the population share to f06-VQ02; takes over the label request of f06-Q09 and f06-VQ01.)",
    why: "Check N1 gives an optimal band reached by fewer than 10% of adults the 'reached by a minority' label (ACCEPTANCE-TEST.md, N1; judge criterion B5); both refuters confirmed that the LDL messages lacked it (ledger issue f06_lipids_core--N1--ldl_cholesterol.both.All_Adults.none--high). The programme's NHANES 2015-2018 input (docs/signoff/work/nhanes/distributions.json) holds no LDL, so N1 cannot compute the share. The label rests on NLA 2024 Table 1 (f06-F01, PMC full text opened in this task): in 12,696 US adults aged 18-85 not receiving lipid-modifying therapy (NHANES 2005-2016, LDL-C by the Friedewald equation), the LDL-C 1st percentile is 45 mg/dL and the 5th is 63 mg/dL, so fewer than 5% have 60 mg/dL or less. The table has no age or sex strata, so no share at 70-79 or at 80 and over is available. When LDL is added to the N1 input (central item C-14), N1's own share replaces this one; N1's healthy-adult definition keeps people on medication, so its share may differ. For non-HDL cholesterol the same table puts 90 mg/dL between the 10th (88) and 20th (103) percentiles, so at least 10% reach that band and N1 asks no label (the J3 issue on non-HDL was refuted). The age evidence for the band is set out in f06-VQ02 and f06-Q05 (f06-V03, f06-V04, f06-E24, f06-E22). The band is locked (DR-2026-09-25-03), so only the display or wording can change here. Label as written (English): 'Only a minority of adults reach this band: in a US survey of adults not taking cholesterol-lowering medicine, fewer than 1 in 20 had a value this low.'",
    evidence_ids: ["f06-F01", "f06-E22", "f06-E24", "f06-V03", "f06-V04"],
    options: [
      "Approve the label as written and keep the locked band and wording at all ages (recommended).",
      "Approve the label and, from 80 years, add one sentence to the above-optimal message saying that the evidence for lower values is weaker at that age (option 2 of f06-VQ02).",
      "Approve the label and raise a CEO question on how the locked band is shown to healthy adults (option 2 of f06-Q09).",
    ],
  },
  {
    id: "F06-DQ-2",
    row_key: null,
    question: "Older adults, total cholesterol and triglycerides (check N1; replaces the figures of f06-Q05): keep the optimal bands (total cholesterol up to 180 mg/dL; fasting triglycerides up to 80 mg/dL) and their wording unchanged at 70 to 84 and at 85 and over, although most healthy adults aged 70-79 read non-optimal: 73.2% of women for total cholesterol, and 67.5% of women and 63.8% of men for triglycerides?",
    why: "N1 makes more than 60% non-optimal at 70-79 a physician question (ACCEPTANCE-TEST.md, N1). The shares are the N1 failures in docs/signoff/work/checks/f06_lipids_core-r1.json (keys total_cholesterol|female|70-79, triglycerides|female|70-79 and triglycerides|male|70-79, rule non_optimal_70_79), which the check interpolates on the compiled rows from the percentiles of NHANES 2015-2018 healthy adults in docs/signoff/work/nhanes/distributions.json (input bundle, not literature). Women aged 70-79, total cholesterol: n 351, 25th percentile 178 mg/dL, median 206 mg/dL. Triglycerides come from the fasting subsample: n 77 women and 82 men aged 70-79, medians 94.9 and 88 mg/dL; 67.5% and 63.8% are the exact shares the NHANES producer computed on this row as stored in round 1 (optimal 32.48% and 36.19% in the input bundle). Check N1 uses those exact shares only while the stored row equals the producer's row; round 2 stores the triglyceride floor as null instead of 0, which classifies every possible value the same way, so N1 now interpolates from the percentiles instead: in a scratch run of the checks on this file's compile it gives 70.8% for women and no longer flags men (its interpolated share is at or below 60%). The exact shares are the better figures, and the question stands for both sexes. f06-Q05 gave 65.7% for women's total cholesterol on the former ceiling of 190 mg/dL; the 180 ceiling (f06-Q01) raises it to 73.2%. Men aged 70-79 are not flagged for total cholesterol. The outcome evidence does not show a different band at older ages: per 1 mmol/L lower total cholesterol, IHD mortality hazard ratios were 0.44, 0.66 and 0.83 at ages 40-49, 50-69 and 70-89, 'with no apparent threshold' (f06-E13): a weaker but persisting association. No source opened in this family gives an older-adult triglyceride nadir; the band rests on f06-E37 and the records listed in the row notes. PLAN.md section 4 splits age groups only where outcome or reference-interval evidence differs by age. Justification offered for docs/signoff/work/nhanes/n1-resolutions.json, which this file cannot write (central item C-14), kind physician_question, for the three keys: 'More than 60% of healthy NHANES 2015-2018 adults aged 70-79 are non-optimal: total cholesterol, women 73.2%; triglycerides, women 67.5% and men 63.8%. The bands rest on outcome evidence without an age-specific nadir (f06-E13); the physician decides the display at 70 and over in F06-DQ-2.'",
    evidence_ids: ["f06-E13", "f06-E37"],
    options: [
      "Keep the bands and wording at all ages (recommended; option 1 of f06-Q05).",
      "Add an older-adult sentence to the above-optimal messages of total cholesterol and triglycerides from 70 (to be written and checked against the wording rules).",
      "Show total cholesterol and triglycerides as in range or out of range only from 85 (display rule; no row change).",
    ],
  },
  {
    id: "F06-DQ-3",
    row_key: HDLF,
    question: "HDL cholesterol in women (check N1; adds to f06-Q02): keep Echevarne's printed lower limit of 50 mg/dL as the reference limit, although 20.7% to 33.3% of healthy NHANES 2015-2018 women fall below it where N1 expects 2% to 15% outside a laboratory interval; or record the same 50 mg/dL as a guideline decision limit; or use 45 mg/dL?",
    why: "PLAN.md section 4 makes Echevarne's printed interval the reference interval unless a named guideline defines the threshold, copied exactly. Echevarne prints '>50' mg/dL for women (B0017, catalogue line 246 of docs/vendor/echevarne/catalogo-2026-08-25.tsv) and '>40' for men (line 247). Check N1 (docs/signoff/work/checks/f06_lipids_core-r1.json) puts 33.3%, 29.5%, 21.7% and 20.7% of healthy women aged 20-39, 40-59, 60-69 and 70-79 below 50 mg/dL. Their 2.5th percentiles are 34 to 40 mg/dL and their 25th percentiles 47 to 52 mg/dL (input bundle, docs/signoff/work/nhanes/distributions.json, n 351 to 1,522 per band), so the printed limit sits near the lower quartile of healthy women, not at the edge of a central 95% interval. The men's row is recorded as a decision limit (EAS/EFLM flags 'HDL cholesterol ≤1 mmol/L (40 mg/dL)', f06-E08; the Polish laboratory-report table prints '> 40 mg/dl (1.0 mmol/l) for men', f06-E63), so N1 reports it without testing the share. For women no opened guideline text states 50: the harmonised metabolic-syndrome statement that uses it (Alberti 2009, PMID 19805654) has no number in its abstract and no PMC copy, and the value appears in secondary restatements of the NCEP ATP III criteria, for example PMID 39296924 (a cross-sectional study, read in this task: 'fasting high-density lipoprotein (HDL) cholesterol of <40 mg/dL for men and <50 mg/dL for women'), which is not a guideline. The Polish table, which follows ESC/EAS, prints '> 45 mg/dl (1.2 mmol/l) for women' (f06-E63). The women's below-range message already calls the value the laboratory's lower limit, points to triglycerides and non-HDL cholesterol and asks for a routine follow-up. Justification offered for docs/signoff/work/nhanes/n1-resolutions.json, which this file cannot write (central item C-14), kind justification, for the four keys hdl_cholesterol|female|20-39, 40-59, 60-69 and 70-79|reference_outside: 'Echevarne's printed interval is binding under PLAN section 4 (B0017, catalogue line 246: women >50 mg/dL, ages 0-999). It is a cardiometabolic cut-point, the women's low-HDL criterion of the metabolic-syndrome definitions, not a central 95% interval: healthy NHANES 2015-2018 women have a 2.5th percentile of 34-40 mg/dL by age band, so 20.7% to 33.3% fall below 50 mg/dL. The physician decides the basis in F06-DQ-3.'",
    evidence_ids: ["f06-E08", "f06-E63"],
    options: [
      "Keep Echevarne's '>50' mg/dL as the women's reference limit (basis echevarne_interval), with the N1 justification above (recommended; PLAN.md section 4).",
      "Record the same 50 mg/dL as a guideline decision limit (basis decision_limit: the NCEP ATP III and harmonised metabolic-syndrome criterion) once a copy of the guideline text that states the number is added and checked; N1 then reports the share without testing it.",
      "Use 45 mg/dL for women, the value of the Polish laboratory-report table that follows ESC/EAS (f06-E63), as a decision limit; this departs from Echevarne's printed value and needs your explicit exception.",
    ],
  },
];

const issues_addressed = [
  "f06_lipids_core--N1--ldl_cholesterol.both.All_Adults.none--high",
  "f06_lipids_core--D5--hdl_cholesterol.female.All_Adults.bounds--none",
  "f06_lipids_core--D5--hdl_cholesterol.male.All_Adults.bounds--none",
  "f06_lipids_core--D5--total_cholesterol.both.All_Adults.bounds--none",
  "f06_lipids_core--D5--total_cholesterol_hdl_ratio.both.All_Adults.bounds--none",
  "f06_lipids_core--D5--triglycerides.both.All_Adults.bounds--none",
  "f06_lipids_core--G2--row.hdl_cholesterol.female.All_Adults.none--none",
  "f06_lipids_core--G2--row.hdl_cholesterol.male.All_Adults.none--none",
  "f06_lipids_core--G2--row.ldl_cholesterol.both.All_Adults.none--none",
  "f06_lipids_core--G2--row.non_hdl_cholesterol.both.All_Adults.none--none",
  "f06_lipids_core--G2--row.total_cholesterol.both.All_Adults.none--none",
  "f06_lipids_core--G2--row.total_cholesterol_hdl_ratio.both.All_Adults.none--none",
  "f06_lipids_core--G2--row.triglycerides.both.All_Adults.none--none",
  "f06_lipids_core--M1--total_cholesterol.both.All_Adults.critical_low--none",
  "f06_lipids_core--M1--triglycerides.both.All_Adults.critical_low--none",
  "f06_lipids_core--N1--hdl_cholesterol.female.20-39.reference_outside--none",
  "f06_lipids_core--N1--hdl_cholesterol.female.40-59.reference_outside--none",
  "f06_lipids_core--N1--hdl_cholesterol.female.60-69.reference_outside--none",
  "f06_lipids_core--N1--hdl_cholesterol.female.70-79.reference_outside--none",
  "f06_lipids_core--N1--total_cholesterol.female.70-79.non_optimal_70_79--none",
  "f06_lipids_core--N1--triglycerides.female.70-79.non_optimal_70_79--none",
  "f06_lipids_core--N1--triglycerides.male.70-79.non_optimal_70_79--none",
  "f06_lipids_core--G2--none--none",
  "f06_lipids_core--M1--total_cholesterol.both.All_Adults.none--low",
];

const notes = fs.readFileSync(path.join(__dirname, "f06-notes.txt"), "utf8").trim().replace("{{VERIFY_SHA}}", verifySha);

const doc = {
  schema_version: "1",
  family: "f06_lipids_core",
  round: 2,
  decided_at: "2026-11-08",
  verify_sha256: verifySha,
  fixer_role: "physician fixer, round 2, batch B03 (AI work product for review by a licensed physician)",
  final_rows: rows,
  changes,
  issues_addressed,
  evidence,
  physician_questions,
  notes,
};
fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + "\n");
console.log(`wrote ${OUT}: ${rows.length} rows, ${changes.length} changes, ${issues_addressed.length} issues, ${evidence.length} evidence, ${physician_questions.length} questions; verify sha ${verifySha}`);
