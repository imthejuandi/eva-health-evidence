// Round 3 fixer transform for docs/signoff/work/decisions/f03_kidney.json (reads the round-2 file, writes round 3).
const fs = require("fs");
const path = require("path");
const ROOT = "/home/user/eva-health/docs/signoff/work";
const FILE = path.join(ROOT, "decisions/f03_kidney.json");
const VERIFY_SHA = process.argv[2];
const d = JSON.parse(fs.readFileSync(FILE, "utf8"));
if (d.round !== 2) throw new Error("expected the round-2 file as input, got round " + d.round);

function rep(obj, field, from, to) {
  const s = obj[field];
  const n = s.split(from).length - 1;
  if (n !== 1) throw new Error(`replace in ${field}: found ${n} times: ${from.slice(0, 70)}`);
  obj[field] = s.replace(from, to);
}
const row = (k, sex, age) => d.final_rows.find((r) => r.marker_key === k && (!sex || r.sex === sex) && (!age || r.age_group === age));

const RK = {
  bun: "bun|both|All Adults|none",
  urea: "urea|both|All Adults|none",
  e1839: "egfr_creatinine_based|both|18-39|none",
  e4084: "egfr_creatinine_based|both|40-84|none",
  e85: "egfr_creatinine_based|both|85+|none",
  crm: "creatinine|male|All Adults|none",
  crf: "creatinine|female|All Adults|none",
  ratio: "bun_creatinine_ratio|both|All Adults|none",
};
const I = {
  e3bun: "f03_kidney--E3--bun.both.All_Adults.none--high",
  k1none: "f03_kidney--K1--egfr_creatinine_based.both.40-84.none--none",
  k1both: "f03_kidney--K1--egfr_creatinine_based.both.40-84.none--both",
  c2: "f03_kidney--C2--bun.both.All_Adults.none--none",
  e3rm: "f03_kidney--E3--bun_creatinine_ratio.male.All_Adults.none.grade_author--none",
  e3rf: "f03_kidney--E3--bun_creatinine_ratio.female.All_Adults.none.grade_author--none",
  d5rb: "f03_kidney--D5--bun_creatinine_ratio.both.All_Adults.row_only_in_production--none",
  d5rm: "f03_kidney--D5--bun_creatinine_ratio.male.All_Adults.row_only_in_seed--none",
  d5rf: "f03_kidney--D5--bun_creatinine_ratio.female.All_Adults.row_only_in_seed--none",
  g2rm: "f03_kidney--G2--row.bun_creatinine_ratio.male.All_Adults.none--none",
  g2rf: "f03_kidney--G2--row.bun_creatinine_ratio.female.All_Adults.none--none",
};
const newChanges = [];

// ── 1. BUN and urea: grade B -> C, kept in the grade C decision table (ledger E3, judge J1, both refuters) ──
const GRADE_C_REASON =
  "Round 3, ledger f03_kidney--E3--bun.both.All_Adults.none--high (judge J1, confirmed by both refuters): the ceiling's only edge source, Hong 2023 (PMC9865447, f03-E41, f03-E41b, f03-D05), adjusts for neither eGFR nor creatinine, excludes no early deaths and reports no sensitivity analysis, so reverse causation is not handled and PLAN.md section 5 tier 2 is not met. The other cited records do not give the edge: f03-E42 (Shen 2024) handles reverse causation but studies adults with hyperlipidaemia, reports no follow-up and its within-10% band ends at 6.09 mmol/L = 17.1 mg/dL; f03-E45 (Mendelian randomisation, coronary disease) gives no threshold. A Europe PMC search in this task (BUN or urea with all-cause mortality in general-population cohorts adjusted for eGFR) returned no qualifying cohort. Grade C applies. Grade C allows a band narrower than the interval only as a grade C decision table entry for the physician, so the band is kept, flagged grade_c_table_entry, and put to the physician in f03-DQ08. Widening it to the reference interval would be a loosening, which needs a grade A or B quote, and no such quote was found. The verifier must confirm the grade; until then check E3 reports this row's grade as differing from the verifier's B.";
for (const [k, key, ceiling] of [["bun", RK.bun, "16 mg/dL"], ["urea", RK.urea, "34 mg/dL"]]) {
  const r = row(k);
  newChanges.push({ row_key: key, field: "grade", from: "B", to: "C", direction: "neutral", reason: GRADE_C_REASON + (k === "urea" ? " Urea is the BUN band x 2.14 and takes the same grade." : ""), evidence_ids: ["f03-E41", "f03-E41b", "f03-D05", "f03-E42", "f03-E45"], issue_ids: [I.e3bun] });
  newChanges.push({ row_key: key, field: "grade_c_table_entry", from: null, to: true, direction: "neutral", reason: `The grade C optimal ceiling ${ceiling} stays only as a grade C decision table entry for the physician (PLAN.md section 5); entry proposed in this file's notes for docs/signoff/work/grade-c-table.json, which this fixer may not write. Physician question f03-DQ08.`, evidence_ids: ["f03-E41", "f03-E41b"], issue_ids: [I.e3bun] });
  r.grade = "C";
  r.grade_c_table_entry = true;
}
{
  const b = row("bun");
  rep(b, "notes", "Grade B for the ceiling: general-population NHANES cohort, n = 17,719, mean follow-up 11.65 years (f03-E41, f03-E41b), band rule within 10% of the minimum (Q2 and Q3 within 10% of Q1, Q4 not).",
    "Grade C for the ceiling from round 3 (was B): the general-population NHANES cohort (n = 17,719, mean follow-up 11.65 years, f03-E41, f03-E41b; band rule within 10% of the minimum, Q2 and Q3 within 10% of Q1, Q4 not) adjusts for no kidney-function term, excludes no early deaths and reports no sensitivity analysis, so reverse causation is not handled (PLAN.md section 5, tier 2; ledger E3, judge J1). The band 10-16 is kept only as a grade C decision table entry for the physician (grade_c_table_entry true; f03-DQ08); the verifier must confirm the grade.");
  rep(b, "notes", "Pregnancy: urea falls (f03-E35): laboratory interval only.", "Pregnancy and lactation: BUN falls in pregnancy (f03-E35); the app-level state rule (laboratory interval only, no category, no score, the fixed note) applies and is not in the app yet: physician question f03-DQ09 and F01-DQ-5. The below-range message no longer names pregnancy as a cause (round 3, ledger C2).");
  rep(b, "change_vs_production", "Optimal floor 10 unchanged", "Round 3: grade B lowered to C (reverse causation not handled in Hong 2023), band kept as a grade C decision table entry (f03-DQ08). Optimal floor 10 unchanged");
  rep(b.rcv, "narrow_band_justification", "against outcome-derived quartile boundaries (f03-E41, f03-E42)", "against outcome-derived quartile boundaries (f03-E41; grade C from round 3, f03-DQ08)");
  b.messages.en.optimal = "Your BUN is in EVA's optimal band of 10 to 16 mg/dL. In a large population study, values in this band were linked to more favourable long-term outcomes than higher values; the evidence is limited, so EVA's doctor reviews this band. It reflects protein intake and hydration as well as kidney clearance.";
  b.messages.es.optimal = "Tu BUN está en la banda óptima de EVA, de 10 a 16 mg/dL. En un gran estudio de población, los valores de esta banda se asociaron a resultados a largo plazo más favorables que los valores más altos; la evidencia es limitada, así que el médico de EVA revisa esta banda. Refleja la ingesta de proteínas y la hidratación además de la depuración renal.";
  rep(b.messages.en, "below_range", "from a low protein intake or a large fluid intake, and it is common in pregnancy; less often", "from a low protein intake or a large fluid intake; less often");
  rep(b.messages.es, "below_range", "por una baja ingesta de proteínas o una alta ingesta de líquidos, y es frecuente en el embarazo; con menos frecuencia", "por una baja ingesta de proteínas o una alta ingesta de líquidos; con menos frecuencia");
  newChanges.push({ row_key: RK.bun, field: "messages", from: "optimal text 'the band with the most favourable long-term outcomes in population studies'; below-range text 'it is common in pregnancy'", to: "optimal text states one population study and limited evidence (grade C); below-range text names no pregnancy cause", direction: "neutral", reason: "The optimal text claimed more than a grade C band supports (ledger E3). Under PLAN.md section 4 and state-rules.md 2.1 a client who declares pregnancy sees the laboratory interval only and no out-of-range text, so an out-of-range message must not address pregnancy (ledger C2, refuter b).", evidence_ids: ["f03-E41", "f03-E35"], issue_ids: [I.e3bun, I.c2] });
}
{
  const u = row("urea");
  rep(u, "notes", "Grade, age pass", "Grade C from round 3, as the BUN row (reverse causation not handled in the BUN edge source; grade C decision table entry, f03-DQ08). Age pass");
  rep(u, "notes", "questions follow the BUN row (f03-DQ05, f03-Q08).", "questions follow the BUN row (f03-DQ05, f03-DQ08, f03-Q08). Pregnancy and lactation: as the BUN row (f03-DQ09).");
  rep(u, "change_vs_production", "New: critical_high 214 mg/dL (f03-E23).", "Round 3: grade B lowered to C with the BUN row, band kept as a grade C decision table entry (f03-DQ08). New: critical_high 214 mg/dL (f03-E23).");
  rep(u.rcv, "narrow_band_justification", "against outcome-derived quartile boundaries (f03-E41, f03-E42)", "against outcome-derived quartile boundaries (f03-E41; grade C from round 3, f03-DQ08)");
  u.messages.en.optimal = "Your urea is in EVA's optimal band of 21 to 34 mg/dL. In a large population study, values in this band were linked to more favourable long-term outcomes than higher values; the evidence is limited, so EVA's doctor reviews this band. It reflects protein intake and hydration as well as kidney clearance. This marker does not count toward the score.";
  u.messages.es.optimal = "Tu urea está en la banda óptima de EVA, de 21 a 34 mg/dL. En un gran estudio de población, los valores de esta banda se asociaron a resultados a largo plazo más favorables que los valores más altos; la evidencia es limitada, así que el médico de EVA revisa esta banda. Refleja la ingesta de proteínas y la hidratación además de la depuración renal. Este marcador no entra en la puntuación.";
  rep(u.messages.en, "below_range", "from a low protein intake or a large fluid intake, and it is common in pregnancy; less often", "from a low protein intake or a large fluid intake; less often");
  rep(u.messages.es, "below_range", "por una baja ingesta de proteínas o una alta ingesta de líquidos, y es frecuente en el embarazo; con menos frecuencia", "por una baja ingesta de proteínas o una alta ingesta de líquidos; con menos frecuencia");
  newChanges.push({ row_key: RK.urea, field: "messages", from: "optimal text 'the band with the most favourable long-term outcomes in population studies'; below-range text 'it is common in pregnancy'", to: "optimal text states one population study and limited evidence (grade C); below-range text names no pregnancy cause", direction: "neutral", reason: "As the BUN row: grade C wording (ledger E3) and no out-of-range text addressed to pregnancy (ledger C2; state-rules.md 2.1).", evidence_ids: ["f03-E41", "f03-E35"], issue_ids: [I.e3bun, I.c2] });
}

// ── 2. Creatinine and eGFR: no pregnancy cause in category texts (ledger C2) ──
for (const [k, sex, age, key] of [["creatinine", "male", null, RK.crm], ["creatinine", "female", null, RK.crf]]) {
  const r = row(k, sex, age);
  rep(r.messages.en, "below_range", "a low-protein or vegetarian diet or pregnancy; it also falls", "or a low-protein or vegetarian diet; it also falls");
  rep(r.messages.es, "below_range", "una dieta baja en proteínas o vegetariana, o un embarazo; también baja", "o una dieta baja en proteínas o vegetariana; también baja");
  newChanges.push({ row_key: key, field: "messages", from: "below-range text names pregnancy as a common cause", to: "pregnancy removed from the below-range text", direction: "neutral", reason: "A client who declares pregnancy sees the laboratory interval only and no out-of-range text (PLAN.md section 4, state-rules.md 2.1), so category texts must not address pregnancy (ledger C2). The state rule is physician question f03-DQ09.", evidence_ids: [], issue_ids: [I.c2] });
}
const APP_EGFR_SRC = "Echevarne prints no eGFR interval and the app computes eGFR itself (CKD-EPI 2021).";
const APP_EGFR_SRC_NEW = "Echevarne prints no eGFR interval. The design computes eGFR in the app from Echevarne's creatinine with CKD-EPI 2021; today the app computes none and holds only laboratory-reported eGFR (method note; src/lib/biomarkers/biological-age-v3-adapter.ts: 'the app computes no eGFR').";
for (const r of d.final_rows.filter((x) => x.marker_key === "egfr_creatinine_based")) rep(r, "reference_source", APP_EGFR_SRC, APP_EGFR_SRC_NEW);
{
  const r = row("egfr_creatinine_based", "both", "18-39");
  rep(r.messages.en, "above_optimal", "a small muscle mass, a low-protein or vegetarian diet or pregnancy, which lower creatinine,", "a small muscle mass or a low-protein or vegetarian diet, which lower creatinine,");
  rep(r.messages.es, "above_optimal", "poca masa muscular, una dieta baja en proteínas o vegetariana, o un embarazo, que bajan la creatinina,", "poca masa muscular o una dieta baja en proteínas o vegetariana, que bajan la creatinina,");
  rep(r, "notes", "a creatinine below its interval now gives an above-optimal eGFR at 18-39 (one step) instead of an optimal one; at 85 and over the pattern remains (f03-DQ04).",
    "a creatinine below its interval gives an above-optimal eGFR at 18-39 (one step) instead of an optimal one (CKD-EPI 2021 as in scripts/signoff/checks/coherence.ts: man 0.699 mg/dL gives 120.3 at 39, woman 0.5499 gives 119.5). The opposite pattern remains in the 40-84 row from about age 60 and as 'in range' at 85 and over (f03-DQ04).");
  newChanges.push({ row_key: RK.e1839, field: "messages", from: "above-optimal text names pregnancy as a cause", to: "pregnancy removed", direction: "neutral", reason: "No eGFR equation is valid in pregnancy (state-rules.md 2.2); a declared pregnancy gets no category (ledger C2, f03-DQ09).", evidence_ids: [], issue_ids: [I.c2] });
}
{
  const r = row("egfr_creatinine_based", "both", "40-84");
  rep(r.messages.en, "above_optimal", "a small muscle mass, a low-protein or vegetarian diet or pregnancy rather than better kidneys.", "a small muscle mass or a low-protein or vegetarian diet rather than better kidneys.");
  rep(r.messages.es, "above_optimal", "poca masa muscular, una dieta baja en proteínas o vegetariana, o un embarazo, y no unos riñones mejores.", "poca masa muscular o una dieta baja en proteínas o vegetariana, y no unos riñones mejores.");
  r.messages.en.optimal = "Your eGFR (CKD-EPI 2021 equation) is in EVA's optimal band for your age (75 to 105 mL/min/1.73 m²). This usually reflects preserved kidney filtration, but creatinine-based eGFR depends on muscle mass: if your creatinine is below its reference interval, often from low muscle mass, eGFR can overstate filtration and this reading is not reassuring by itself. Cystatin C gives a check that does not depend on muscle. This marker does not count toward the score.";
  r.messages.es.optimal = "Tu TFGe (ecuación CKD-EPI 2021) está en la banda óptima de EVA para tu edad (75 a 105 mL/min/1,73 m²). Suele reflejar una filtración renal conservada, pero la TFGe basada en creatinina depende de la masa muscular: si tu creatinina está por debajo de su intervalo de referencia, a menudo por poca masa muscular, la TFGe puede sobrestimar la filtración y esta lectura no es tranquilizadora por sí sola. La cistatina C da una comprobación que no depende del músculo. Este marcador no entra en la puntuación.";
  rep(r, "notes", "Round 2, check K1: Echevarne's creatinine interval has no age bands while CKD-EPI 2021 falls with age, so a creatinine inside the interval gives an eGFR under 60 from about age 68 (top of either sex's interval); the eGFR row owns the filtration reading, both the creatinine in-range message and this row's below-range message say so, and the choice between accepting this and an app rule is physician question f03-DQ04.",
    "Check K1, two opposite patterns on this row (recomputed in round 3 with the CKD-EPI 2021 function of scripts/signoff/checks/coherence.ts): (1) Echevarne's creatinine interval has no age bands while CKD-EPI 2021 falls with age, so a creatinine at the top of either sex's interval (man 1.3, woman 1.02 mg/dL) gives an eGFR under 60 from age 68 (59.8 and 59.9) and 54.2 at 84; (2) a creatinine just below its interval (man 0.699, woman 0.5499 mg/dL) gives an eGFR inside the optimal band 75-105 from age 61 in men (104.9) and 60 in women (104.9) to 84 (90.9 and 90.3); lower creatinines enter the band later (the check's examples: woman 0.5335 from 61, man 0.679 from 63). Pattern (2) reads creatinine below range and eGFR 'optimal' in a person who may have low muscle mass. No optimal ceiling can remove it: the ceiling would have to fall below 90 at 84, under the outcome evidence (f03-E02, f03-E06). Round 3 rewrote the optimal message to say a low creatinine makes the eGFR reading not reassuring by itself and names cystatin C; the app rule or acceptance is physician question f03-DQ04 (restated with these ages; ledger K1 J5).");
  newChanges.push({ row_key: RK.e4084, field: "messages", from: "optimal text 'which reflects preserved kidney filtration' with a note only for a 'very high value'; above-optimal text names pregnancy", to: "optimal text says a creatinine below its interval makes the reading not reassuring and names cystatin C; pregnancy removed", direction: "neutral", reason: "Ledger K1 (judges J1 and J5): from age 60-61 to 84 a creatinine below its interval gives an eGFR inside 75-105, which the old text called preserved filtration; the new text states the muscle-mass limit (f03-E10, f03-E17). Pregnancy removed as for the other rows (ledger C2).", evidence_ids: ["f03-E10", "f03-E17"], issue_ids: [I.k1none, I.k1both, I.c2] });
  newChanges.push({ row_key: RK.e4084, field: "notes", from: "K1 described as one pattern (eGFR under 60 from about 68)", to: "both K1 patterns stated with recomputed ages; f03-DQ04 restated", direction: "neutral", reason: "Ledger f03_kidney--K1--egfr_creatinine_based.both.40-84.none--none: the physician question and the notes placed the low-creatinine/optimal-eGFR pattern only at 85 and over.", evidence_ids: [], issue_ids: [I.k1none] });
}
{
  const r = row("egfr_creatinine_based", "both", "85+");
  rep(r, "notes", "Round 2, check K1: at 85 and over this row has no optimal band,", "Check K1: the low-creatinine pattern starts in the 40-84 row (from about age 60) and continues here; at 85 and over this row has no optimal band,");
}

// ── 3. BUN-to-creatinine ratio: one row for both sexes, the verifier's grade D (script E3 and D5) ──
{
  const iM = d.final_rows.findIndex((r) => r.marker_key === "bun_creatinine_ratio" && r.sex === "male");
  const iF = d.final_rows.findIndex((r) => r.marker_key === "bun_creatinine_ratio" && r.sex === "female");
  const m = JSON.parse(JSON.stringify(d.final_rows[iM]));
  m.sex = "both";
  m.reference_low = 7.6;
  m.reference_high = 45.5;
  m.reference_source = "No printed interval: Echevarne reports no BUN-to-creatinine ratio and no named guideline sets a decision limit for it in adults who are not acutely ill (PLAN.md section 4). The limits are derived only from Echevarne's printed intervals, as the urea row is: BUN 10-25 mg/dL (code B0150) and creatinine 0.7-1.3 mg/dL (code B0003, Hombre) and 0.55-1.02 mg/dL (Mujeres). The lowest ratio two in-interval values can give for either sex is 10 / 1.3 = 7.69 (men; women 10 / 1.02 = 9.80), rounded down to 7.6; the highest is 25 / 0.55 = 45.45 (women; men 25 / 0.7 = 35.71), rounded up to 45.5. So the ratio is out of range only when BUN or creatinine is itself out of range, for either sex. The former convention 10-20 is dropped: 20 is the acute-care pre-renal threshold (f03-E49) and 10 is unsourced (f03-E52); in the general-population NHANES cohort neither tail carried excess all-cause mortality after full adjustment (f03-D01).";
  m.messages = {
    en: {
      below_range: "Your BUN-to-creatinine ratio is below 7.6, the lowest value that a BUN and a creatinine inside their own laboratory intervals can give, so either your BUN is low or your creatinine is high. It can reflect a low protein intake or a large fluid intake (low BUN), or a large muscle mass, creatine supplements or a lower kidney filtration (high creatinine); your BUN and creatinine messages carry the detail. Repeat both tests in 2 to 4 weeks if you have no similar earlier result. Discuss it with your doctor at your next check-up. This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.",
      in_range: "Your BUN-to-creatinine ratio is within the range that a BUN and a creatinine inside their own laboratory intervals can give (7.6 to 45.5). EVA shows this derived index for information only; your BUN and creatinine messages carry the detail. This marker does not count toward the score.",
      above_range: "Your BUN-to-creatinine ratio is above 45.5, the highest value that a BUN and a creatinine inside their own laboratory intervals can give, so either your BUN is high or your creatinine is low. It can reflect dehydration or a high protein intake (high BUN), or a small muscle mass (low creatinine), and less often bleeding in the digestive tract or heart failure; your BUN and creatinine messages carry the detail. Repeat both tests in 2 to 4 weeks, well hydrated. Discuss it with your doctor at your next check-up. This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.",
    },
    es: {
      below_range: "Tu cociente BUN/creatinina está por debajo de 7,6, el valor más bajo que pueden dar un BUN y una creatinina dentro de sus propios intervalos de laboratorio, así que o tu BUN está bajo o tu creatinina está alta. Puede reflejar una ingesta baja de proteínas o una ingesta alta de líquidos (BUN bajo), o mucha masa muscular, suplementos de creatina o una filtración renal menor (creatinina alta); los mensajes de tu BUN y tu creatinina llevan el detalle. Conviene repetir las dos pruebas en 2 a 4 semanas si no tienes un resultado previo parecido. Coméntalo con tu médico en tu próxima revisión. Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.",
      in_range: "Tu cociente BUN/creatinina está dentro del margen que pueden dar un BUN y una creatinina dentro de sus propios intervalos de laboratorio (7,6 a 45,5). EVA muestra este índice derivado solo a título informativo; los mensajes de tu BUN y tu creatinina llevan el detalle. Este marcador no entra en la puntuación.",
      above_range: "Tu cociente BUN/creatinina está por encima de 45,5, el valor más alto que pueden dar un BUN y una creatinina dentro de sus propios intervalos de laboratorio, así que o tu BUN está alto o tu creatinina está baja. Puede reflejar deshidratación o una ingesta alta de proteínas (BUN alto), o poca masa muscular (creatinina baja), y con menos frecuencia un sangrado digestivo o una insuficiencia cardíaca; los mensajes de tu BUN y tu creatinina llevan el detalle. Conviene repetir las dos pruebas en 2 a 4 semanas, bien hidratado. Coméntalo con tu médico en tu próxima revisión. Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.",
    },
  };
  m.change_vs_production = "Production row (both sexes): reference 10-20, optimal 11-18. Round 2 split it by sex; round 3 merges it back into one row for both sexes, as in production and the verify file, with reference 7.6-45.5, the extremes that in-interval BUN and creatinine can give for either sex (reference_source); optimal band removed (class e; f03-E48, f03-D01); messages rewritten (production said 'prompt medical attention').";
  m.notes = "Round 3: one row for both sexes again. The round-2 male and female rows had no verifier grade (check E3) and no production counterpart (check D5); this row keeps the verifier's grade D for bun_creatinine_ratio|both|All Adults|none. Merging widens each sex's derived limits (men 7.6-35.8 and women 9.8-45.5 in round 2) to 7.6-45.5: no in-interval BUN and creatinine pair of either sex gives a ratio outside it, so the K1 opposite pattern fixed in round 2 does not return; a man's ratio between 35.8 and 45.5 now reads in range, which always means his creatinine is below its interval and his creatinine message carries it. Physician question f03-DQ07 (supersedes f03-Q09): keep these derived limits, go back to sex-specific rows once the verifier grades them, retire the ratio from the client view (the row format and the family-key rule do not allow a value-only row or a missing key, so that needs a harness change), or name a sourced interval. Explicit age pass (check C3): the limits follow Echevarne's adult intervals, which have no age bands, so ages 18-19, 70-84 and 85 and over use this row; older adults and women run higher (f03-E48). Not in the Base Panel.";
  m.grade = "D";
  d.final_rows.splice(Math.max(iM, iF), 1);
  d.final_rows.splice(Math.min(iM, iF), 1, m);
  // Old change records for the split rows go; the merged row gets records against the verify row (10-20, grade D).
  d.changes = d.changes.filter((c) => !/^bun_creatinine_ratio\|/.test(c.row_key));
  const merge = [I.e3rm, I.e3rf, I.d5rb, I.d5rm, I.d5rf];
  newChanges.push({ row_key: RK.ratio, field: "row", from: "round 2: two rows, male (7.6-35.8) and female (9.8-45.5)", to: "one row for both sexes, 7.6-45.5, grade D", direction: "neutral", reason: "The sex rows had no verifier grade (check E3) and no production counterpart (check D5). One row with the verifier's grade D and limits that cover the in-interval extremes of both sexes keeps check K1's ratio fix (round 2) and matches the production and verify row keys. The ratio is class e, not scored.", evidence_ids: ["f03-D01"], issue_ids: merge });
  newChanges.push({ row_key: RK.ratio, field: "reference_low", from: 10, to: 7.6, direction: "loosen", reason: "Echevarne prints no ratio interval and no guideline sets one; 10 is a convention with no opened source (f03-E52). The new limit is the lowest ratio in-interval BUN and creatinine can give (10 / 1.3 = 7.69), so the ratio never reads out of range while both inputs are in range (check K1). Reference bound, not an optimal band; f03-D01 (general-population NHANES, n = 42,038) finds no excess all-cause mortality in the lowest quartile after full adjustment.", evidence_ids: ["f03-D01", "f03-E52"], issue_ids: merge });
  newChanges.push({ row_key: RK.ratio, field: "reference_high", from: 20, to: 45.5, direction: "loosen", reason: "20 is the acute-care pre-renal threshold (f03-E49), not a limit for adults who are not acutely ill. The new limit is the highest ratio in-interval BUN and creatinine can give for either sex (25 / 0.55 = 45.45, women). Reference bound, not an optimal band; f03-D01 finds no excess all-cause mortality in the highest quartile after full adjustment.", evidence_ids: ["f03-D01", "f03-E49"], issue_ids: merge });
  newChanges.push({ row_key: RK.ratio, field: "messages", from: "verify texts on the 10-20 convention", to: "texts naming the derived limits 7.6 and 45.5 and pointing to the BUN and creatinine messages", direction: "neutral", reason: "The texts must match the row's limits (check M4) and carry no pregnancy cause (ledger C2).", evidence_ids: [], issue_ids: [I.c2] });
  // Evidence f03-D01 supported the split rows; point it at the merged row.
  const d01 = d.evidence.find((e) => e.id === "f03-D01");
  d01.supports = [{ row_key: RK.ratio, bound: "reference_low" }, { row_key: RK.ratio, bound: "reference_high" }];
}

// ── 4. Physician questions ──
{
  const q4 = d.physician_questions.find((q) => q.id === "f03-DQ04");
  q4.row_key = RK.e4084;
  q4.question = "Check K1 keeps two opposite patterns between creatinine and eGFR that no row bound can remove within the definitions (CKD-EPI 2021, recomputed in round 3): (1) a creatinine at the top of Echevarne's interval (man 1.3, woman 1.02 mg/dL) gives an eGFR under 60 from age 68 in both sexes, so creatinine reads in range while eGFR reads below the KDIGO limit; (2) a creatinine just below its interval (man 0.699, woman 0.5499 mg/dL) gives an eGFR inside the 75-105 optimal band from age 61 in men and 60 in women up to 84, and 'in range' at 85 and over, so a person with low muscle mass reads creatinine below range and eGFR optimal. Round 2 told you pattern (2) occurred only at 85 and over; that was wrong. Should the app apply a rule (eGFR owns the filtration call; when creatinine is below its interval, eGFR is shown as a value with a muscle-mass note and a cystatin C suggestion), or do you accept the patterns as documented in the messages (the 40-84 optimal text now says a low creatinine makes the reading not reassuring)?";
  q4.why = "Echevarne's creatinine interval has no age bands while the KDIGO 60 floor is a guideline decision limit copied exactly; both are binding under PLAN.md section 4. Removing pattern (2) with a ceiling would need an optimal ceiling under 90 at 84, below the outcome evidence (f03-E02, f03-E06). K1 accepts no reason for opposite patterns, so the answer decides whether the app or the acceptance-test rule changes. Ledger issues K1 (judges J1 and J5, round 2).";
  q4.evidence_ids = ["f03-E01", "f03-E02", "f03-E05", "f03-E06", "f03-E07", "f03-E10", "f03-E19"];
  const q5 = d.physician_questions.find((q) => q.id === "f03-DQ05");
  q5.question = q5.question.replace("and the 16 mg/dL optimal ceiling,", "and the 16 mg/dL optimal ceiling (grade C from round 3, f03-DQ08),");
  if (!q5.question.includes("grade C from round 3")) throw new Error("DQ05 edit failed");
  const q7 = d.physician_questions.find((q) => q.id === "f03-DQ07");
  q7.row_key = RK.ratio;
  q7.question = "BUN-to-creatinine ratio: the 10-20 convention is replaced by limits derived only from Echevarne's BUN and creatinine intervals, the extremes that in-interval inputs can give. Round 2 used sex-specific rows (men 7.6-35.8, women 9.8-45.5); round 3 merges them into one row for both sexes, 7.6-45.5, because the sex rows had no verifier grade and no production counterpart. Keep the merged limits, return to sex-specific rows after the verifier grades them, retire the ratio from the client view, or name a sourced interval?";
  q7.why = "PLAN.md section 4 admits only Echevarne's interval or a named guideline limit as a reference interval and neither exists for the ratio; the 10-20 convention comes from acute care (f03-E49, f03-E52) and gave an out-of-range ratio for people whose BUN and creatinine were both optimal (check K1). f03-D01 finds no excess all-cause mortality in either outer quartile. With the merged row, a man's ratio between 35.8 and 45.5 reads in range; it always means a creatinine below his interval, which his creatinine message carries. Retiring the ratio, or a value-only display, needs a harness change. Supersedes f03-Q09.";
  q7.options = ["Keep the merged derived limits 7.6-45.5 (as written)", "Sex-specific rows once the verifier grades them", "Retire the ratio from the client view", "Name a sourced interval"];
  d.physician_questions.push({
    id: "f03-DQ08",
    row_key: RK.bun,
    question: "BUN optimal ceiling 16 mg/dL (urea 34 mg/dL): its only edge source, Hong 2023 (NHANES 1999-2006, n = 17,719, mean follow-up 11.65 years; all-cause mortality HR 1.06, 1.05 and 1.48 for quartiles 2 to 4 versus quartile 1, Q4 from 5.71 mmol/L = 16.0 mg/dL), adjusts for no kidney-function term and does not exclude early deaths, so the band is grade C. Do you list BUN 10-16 and urea 21-34 in the grade C decision table (the band stays, with the optimal text saying the evidence is limited), or set the optimal band equal to Echevarne's interval (10-25 and 21-54), which shows BUN and urea as in range or out of range only?",
    why: "PLAN.md section 5: at grade C the optimal band equals the reference interval unless the physician lists it in the grade C table (at most 20 entries). Widening the band is a loosening and needs a grade A or B quote, which this fixer did not find (Europe PMC search, 7 November 2026), so the file keeps the band flagged grade_c_table_entry and the choice is yours. Consequence: under the band, 63.3% of healthy NHANES men aged 70-79 read non-optimal (check N1, f03-DQ05); Shen 2024 (f03-E42, hyperlipidaemia, eGFR-adjusted, early deaths excluded) puts the within-10% edge at 6.09 mmol/L = 17.1 mg/dL. Ledger f03_kidney--E3--bun.both.All_Adults.none--high.",
    evidence_ids: ["f03-E41", "f03-E41b", "f03-D05", "f03-E42", "f03-E45", "f03-E21"],
    options: ["List BUN 10-16 and urea 21-34 in the grade C table (as written)", "Optimal equals Echevarne's interval: in range or out of range only", "List with a higher ceiling such as 17 mg/dL (urea 36) once the verifier accepts Shen 2024"],
  });
  d.physician_questions.push({
    id: "f03-DQ09",
    row_key: null,
    question: "Pregnancy and lactation on the kidney rows: do you confirm that the single app-level rule of state-rules.md 2.1 (laboratory interval only, no optimal category, no score, no biological age, the fixed note, critical limits still active) covers creatinine, eGFR, cystatin C, BUN, urea and the BUN-to-creatinine ratio, that eGFR is shown as a value only in declared pregnancy because no equation is valid then (state-rules.md 2.2), and that the kidney range pages are not released for pregnant or lactating clients until that rule passes the C2 fixtures and the Q1 pregnancy personas? This is the kidney part of F01-DQ-5.",
    why: "Ledger f03_kidney--C2--bun.both.All_Adults.none--none (judge J5, confirmed by both refuters): src/lib/biomarkers/reference-row.ts picks a row by sex and age only, so the T2 and T3 pregnancy personas' BUN of 8 mg/dL reads below range (critical_low code) and their eGFR of 105 reads optimal. BUN falls in normal pregnancy (f03-E35). The fix is in the app, outside this decision file; round 3 removed the pregnancy wording from the kidney out-of-range and above-optimal texts so no category text addresses a pregnant client.",
    evidence_ids: ["f03-E35"],
    options: ["Confirm the single app-level rule, value-only eGFR in pregnancy, and the release block (recommended)", "Ask for trimester-specific kidney rows, which needs a gestational-week field the app does not record"],
  });
}

// ── 5. File header, changes, issues, notes ──
d.round = 3;
d.decided_at = "2026-11-07";
d.verify_sha256 = VERIFY_SHA;
d.fixer_role = "physician fixer, round 3 (AI work product for review by the licensed physician)";
d.changes = d.changes.concat(newChanges);

const ledger = JSON.parse(fs.readFileSync(path.join(ROOT, "ledger/f03_kidney.json"), "utf8"));
const status = new Map(ledger.issues.map((i) => [i.id, i.status]));
const keptClosed = d.issues_addressed.filter((id) => status.get(id) === "closed");
const resolvedNow = [I.e3bun, I.k1none, I.e3rm, I.e3rf, I.d5rb, I.d5rm, I.d5rf];
for (const id of resolvedNow) if (!status.has(id)) throw new Error("not in ledger: " + id);
d.issues_addressed = [...new Set([...keptClosed, ...resolvedNow])].sort();

const r2notes = d.notes;
const oldFixText = r2notes.slice(r2notes.indexOf("Out of this file's reach"), r2notes.indexOf("Check K1 after this decision (expected)"));
d.notes = [
  "Round 3 fixer (AI work product for physician review; AI pre-review only). Started from the round-2 decision file; verify file unchanged (sha256 above). Searches: 0 WebSearch calls; 3 Europe PMC searches for a BUN or urea outcome cohort that handles reverse causation, none qualifying.",
  "Resolved in this file (issues_addressed, new this round): (1) f03_kidney--E3--bun.both.All_Adults.none--high: BUN and urea grade B lowered to C, bands kept only as grade C decision table entries (grade_c_table_entry true), optimal texts say the evidence is limited, physician question f03-DQ08. Not widened: widening is a loosening and no grade A or B quote was found. Proposed entries for docs/signoff/work/grade-c-table.json (not writable here): {row_key 'bun|both|All Adults|none', bound 'optimal_high', value 16, question 'f03-DQ08'} and {row_key 'urea|both|All Adults|none', bound 'optimal_high', value 34, question 'f03-DQ08'}. Expected check E3 output until the verifier regrades and the table exists: 'final grade C differs from the verifier's B' and 'grade C narrowed high bound not in the grade C decision table' for both rows; these state the open step, they are not new defects. (2) f03_kidney--K1--egfr_creatinine_based.both.40-84.none--none: f03-DQ04 and the 18-39, 40-84 and 85+ notes now state both K1 patterns with recomputed ages (low creatinine gives an optimal eGFR from age 60-61 to 84, not only at 85 and over). (3) Script E3 grade_author for the two ratio rows and script D5 row_only for the ratio (three ids): the ratio is one row for both sexes again (7.6-45.5, the verifier's grade D). Side effect: D5 will report 'bun_creatinine_ratio|both|All Adults|bounds' (seed 7.6-45.5 vs production 10-20), a recorded change versus production like the BUN and urea bounds.",
  "Worked on but not claimed as resolved: (a) f03_kidney--C2--bun.both.All_Adults.none--none: the pregnancy wording is gone from every kidney category text (creatinine, eGFR 18-39 and 40-84, BUN, urea) and f03-DQ09 asks the physician to confirm the app-level rule (kidney part of F01-DQ-5); pregnant personas still read BUN below range and eGFR optimal until reference-row.ts applies the state rule, so the defect remains at app level. (b) f03_kidney--K1--egfr_creatinine_based.both.40-84.none--both: the patterns remain by construction (f03-DQ04); the 40-84 optimal text now says a low creatinine makes the reading not reassuring. (c) f03_kidney--L1--egfr_creatinine_based.both.40-84.none--low, L1 BUN and creatinine: the classifier derives critical codes from reference limits and the seed has no critical-message column (app and compile work). (d) E2--none--none: the repository source cache holds no f03 source; the harness must run quote-check online. (e) G6 and M3/M4 Clinical_Notes and biomarker-sources summaries: compiled from the seed template, not from final_rows; replacement texts below.",
  "Script issues outside this file: G2 (10 rows 'not among the final_rows'): scripts/signoff/checks/governance.ts traceRows compares d.row_key, but decision final_rows carry no row_key field and common.schema.json row forbids additional properties, so G2 cannot match any decision row; the check should build the key from marker_key, sex, age_group and physiological_state (as checks.rowKey does). D5 bounds and row differences for BUN, urea, cystatin C, creatinine and eGFR are recorded changes versus production (change_vs_production) that close only with a prepared migration. N1 needs docs/signoff/work/nhanes/n1-resolutions.json (proposals below), L1 table needs critical-limits.json entries for BUN and creatinine, P3 and S2 are app and governance items.",
  "Other correction: the eGFR rows' reference_source said 'the app computes eGFR itself'; today the app computes none and holds only laboratory-reported eGFR (src/lib/biomarkers/biological-age-v3-adapter.ts), as each row's method note already said. Text corrected; no bound changed.",
  "Carried from round 2. " + oldFixText.trim(),
  "Proposed N1 resolutions for docs/signoff/work/nhanes/n1-resolutions.json (unchanged from round 2): bun|female|20-39|reference_outside, bun|female|40-59|reference_outside, bun|male|20-39|reference_outside: justification 'Echevarne's printed General interval 10-25 mg/dL is binding (PLAN.md section 4); below-range message is soft; physician question f03-DQ05.' bun|male|70-79|non_optimal_70_79: physician_question 'f03-DQ05' (with f03-DQ08: if the physician sets the BUN optimal band equal to the interval, this share falls). creatinine|female|70-79|reference_outside: physician_question 'f03-DQ02'.",
  "Proposed accepted reasons for docs/signoff/work/coherence/accepted-reasons.json, one-step patterns only (unchanged from round 2): 'egfr_ckd_epi_2021|*|creatinine:optimal->egfr_creatinine_based:above_optimal' and '...:below_optimal': 'Echevarne's creatinine interval is age-independent while the eGFR bands are age-specific; the eGFR row owns the filtration reading (f03-DQ04).' and 'bun_creatinine|*|bun:above_optimal,creatinine:critical_low->bun_creatinine_ratio:optimal': 'The ratio's limits are the extremes of in-interval inputs; a high-normal BUN with a low creatinine stays inside them and the creatinine message carries the low reading (f03-DQ07).'",
].join("\n\n");

fs.writeFileSync(FILE, JSON.stringify(d, null, 2) + "\n");
console.log("written", FILE, "rows", d.final_rows.length, "changes", d.changes.length, "issues", d.issues_addressed.length);
