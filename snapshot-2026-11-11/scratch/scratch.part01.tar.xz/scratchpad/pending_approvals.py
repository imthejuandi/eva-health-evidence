"""Build docs/signoff/work/governance/pending-approvals.json: every frozen file (G1 inputs) that differs from round 0."""
import hashlib, json, subprocess, sys, os
os.chdir('/home/user/eva-health')
runner_verdict = sys.argv[1] if len(sys.argv) > 1 else 'pending'
runner_review = sys.argv[2] if len(sys.argv) > 2 else 'docs/signoff/work/central/runner-verify-3.json'
r0 = json.load(open('docs/signoff/work/checks/round-0.json'))['inputs']
def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()
tracked = subprocess.run(['git','ls-files','scripts/signoff','docs/signoff/tools'],capture_output=True,text=True).stdout.split()
spec = {'docs/signoff/ACCEPTANCE-TEST.md','docs/signoff/LOOP-PROMPT.md','docs/signoff/PLAN.md','docs/signoff/thresholds.json'}
changed = []
for p in sorted(set(tracked) | {'docs/signoff/work/judges/lenses.json'} | set(k for k in r0 if k.startswith(('scripts/signoff','docs/signoff/tools')))):
    if not os.path.exists(p):
        changed.append((p, None, 'deleted')); continue
    h = sha(p)
    old = r0.get(p)
    if old is None: changed.append((p, h, 'added'))
    elif old != h: changed.append((p, h, 'modified'))
AREA = [
  ('scripts/signoff/checks/data.ts','runner'),('scripts/signoff/checks/governance.ts','runner'),('scripts/signoff/lib/seed.ts','runner'),
  ('scripts/signoff/checks/preanalytical.ts','bounded results'),
  ('docs/signoff/tools/lib/compile-diff.js','compile change reasons'),('docs/signoff/tools/test/compile-diff.test.js','compile change reasons'),
  ('docs/signoff/tools/lib/compile-sources.js','compile summaries'),('docs/signoff/tools/test/compile-sources.test.js','compile summaries'),
  ('docs/signoff/tools/compile.js','compile rows and change reasons'),('docs/signoff/tools/test/compile.test.js','compile rows and change reasons'),
  ('docs/signoff/tools/lib/compile-rows.js','compile rows'),('docs/signoff/tools/schema/common.schema.json','compile rows'),
  ('docs/signoff/tools/test/schema.test.js','compile rows'),('docs/signoff/tools/validate.js','compile rows'),
  ('docs/signoff/tools/build-briefs.js','briefs (added 6 Nov for the lean loop; new fields 7 Nov)'),('docs/signoff/tools/test/build-briefs.test.js','briefs'),
  ('docs/signoff/tools/build-inputs.js','inputs (changed 6 Nov)'),
  ('scripts/signoff/checks/bioage.ts','runner (version 3 probes; earlier change of 6 Nov reviewed too)'),('scripts/signoff/checks/personas.ts','version 3 personas (changed 6 Nov, workstream 2)'),
  ('scripts/signoff/checks/evidence.ts','runner'),('scripts/signoff/lib/hash.ts','runner'),
  ('docs/signoff/work/judges/lenses.json','judge prompts, newly hashed by G1'),
]
area = dict(AREA)
REVIEW = {
  'runner': (runner_verdict, runner_review),
  'runner (version 3 probes; earlier change of 6 Nov reviewed too)': ('accepted', 'docs/signoff/work/central/runner-verify-r5-repair.json; earlier-frozen-verify.json'),
  'version 3 personas (changed 6 Nov, workstream 2)': ('accepted', 'docs/signoff/work/central/earlier-frozen-verify.json'),
  'inputs (changed 6 Nov)': ('accepted', 'docs/signoff/work/central/earlier-frozen-verify.json'),
  'briefs (added 6 Nov for the lean loop; new fields 7 Nov)': ('accepted, with common.schema.json', 'docs/signoff/work/central/earlier-frozen-verify.json'),
  'briefs': ('accepted, with common.schema.json', 'docs/signoff/work/central/earlier-frozen-verify.json'),
  'judge prompts, newly hashed by G1': ('unchanged since round 0; listed because G1 now hashes it', 'docs/signoff/work/central/runner-verify-r5-repair.json'),
  'bounded results': ('accepted', 'docs/signoff/work/central/bounded-verify.json'),
  'compile change reasons': ('accepted', 'docs/signoff/work/central/compile-sources-verify-2.json'),
  'compile summaries': ('accepted (not faulted in either review)', 'docs/signoff/work/central/compile-sources-verify.json, compile-sources-verify-2.json'),
  'compile rows and change reasons': ('accepted', 'docs/signoff/work/central/compile-rows-verify.json (report-only findings, repaired), compile-sources-verify-2.json'),
  'compile rows': ('accepted after report repair', 'docs/signoff/work/central/compile-rows-verify.json'),
}
head = subprocess.run(['git','rev-parse','--short','HEAD'],capture_output=True,text=True).stdout.strip()
files = []
for p, h, kind in changed:
    a = area.get(p, 'unassigned')
    v, rv = REVIEW.get(a, ('earlier change, not reviewed on 7 November', None))
    files.append({'file': p, 'kind': kind, 'sha256': h, 'area': a, 'review_verdict': v, 'review_file': rv})
doc = {
  '_doc': 'Frozen files (inputs of check G1) that differ from round 0, for the CEO\'s approval. AI work product; nothing is approved until the CEO says so. On approval each entry moves to approved-changes.json with the commit that holds this sha256 and approved_by "CEO". A file whose verdict is not accepted is not proposed for approval.',
  'prepared_at_commit': head,
  'status': 'awaiting the CEO',
  'decisions': 'docs/signoff/work/governance/central-fix-decisions.md (CEO-1 to CEO-8, conservative defaults taken)',
  'files': files,
}
json.dump(doc, open('docs/signoff/work/governance/pending-approvals.json','w'), indent=2, ensure_ascii=False)
open('docs/signoff/work/governance/pending-approvals.json','a').write('\n')
for f in files: print(f['kind'][:3], f['review_verdict'][:28].ljust(28), f['area'][:30].ljust(30), f['file'])
