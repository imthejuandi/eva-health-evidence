import { loadSeed } from "/home/user/eva-health/scripts/signoff/lib/seed";
const s = loadSeed("/home/user/eva-health/supabase/seed-data")!;
const keys=["apolipoprotein_b_apob","ldl_cholesterol","non_hdl_cholesterol","glucose_fasting","vitamin_d_25_oh","homa_ir"];
for (const r of s.rows) if (keys.includes(r.biomarker_key)) console.log(JSON.stringify({k:r.biomarker_key,sex:r.sex,age:r.age_group_en,unit:r.unit_en,nl:r.normal_low,nh:r.normal_high,ol:r.optimal_low,oh:r.optimal_high}));
