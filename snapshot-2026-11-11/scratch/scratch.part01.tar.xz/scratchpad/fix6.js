const fs = require("fs");
const f = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/f11gen.js";
let s = fs.readFileSync(f, "utf8");
function rep(o, n, k = 1) { const c = s.split(o).length - 1; if (c !== k) throw new Error(`count ${c} != ${k}: ${o.slice(0, 90)}`); s = s.split(o).join(n); }
rep("so a mildly low value is common and usually harmless. Platelets clumping in the tube can also make the count read falsely low.",
    "so a value just below the interval is common and usually harmless; a count below 100,000/µL is uncommon in pregnancy and needs another explanation. Platelets clumping in the tube can also make the count read falsely low.");
rep("así que un valor algo bajo es frecuente y suele ser inofensivo. Que las plaquetas se agrupen en el tubo también puede dar un recuento falsamente bajo.",
    "así que un valor algo por debajo del intervalo es frecuente y suele ser inofensivo; un recuento por debajo de 100.000/µL es poco frecuente en el embarazo y necesita otra explicación. Que las plaquetas se agrupen en el tubo también puede dar un recuento falsamente bajo.");
fs.writeFileSync(f, s); console.log("ok");
