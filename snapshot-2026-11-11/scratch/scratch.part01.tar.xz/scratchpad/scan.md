Método: el bloque `banned_terms` de este archivo se aplicó con un script (`python3 -I`, expresiones regulares sin distinción de mayúsculas, lista `allow` eliminada antes de comparar) a: 911 textos en español y 945 en inglés, que son todos los campos `Msg_*` y las notas clínicas de los dos archivos semilla (180 filas cada uno, 726 mensajes y 180 notas por idioma), las etiquetas de `zone-config.ts`, las cadenas de `MedicalDisclaimer.tsx`, las etiquetas de tendencia de `detail-client.tsx` y las cadenas de las 8 plantillas de correo. Un "hit" es un texto (mensaje, nota o cadena) con al menos una coincidencia. / Method: the `banned_terms` block of this file was run by script over the same corpus; a hit is one text with at least one match.

| Idioma / Language | Nivel / Tier | Regla (regex) | Textos con coincidencia / Hits | Marcadores (semilla) / Markers | Por fuente / By source |
|---|---|---|---|---|---|
| en | non_critical | `\b(prompt\|immediate\|urgent)\s+medical\s+(attention\|care\|contact)\b` | 77 | 39 | seed 75, src/components/dashboard/MedicalDisclaimer.tsx 2 |
| en | any | `(^\|[.;:!?]\s+\|\n\s*)(evaluate\|rule out\|assess\|consider\|screen\|monitor\|track\|investigate\|order\|check for\|work up\|workup)\b` | 48 | 27 | seed 48 |
| en | any | `\bmortalit(y\|ies)\b` | 20 | 10 | seed 20 |
| en | trend (section 6) | `\b(trending\|improving\|worsening\|trend\|velocity)\b` | 17 | 3 | seed 16, detail-client.tsx 1 |
| en | any | `\btrack(ing)?\s+(the\s+)?velocity\b` | 4 | 1 | seed 4 |
| en | any | `\bmonitor\s+(the\s+)?trend\b` | 4 | 1 | seed 4 |
| en | any | `\bsuggest(s\|ing)?\s+(a\s+\|an\s+)?(prediabetes\|diabetes\|hypothyroidism\|hyperthyroidism\|hemochromatosis\|haemochromatosis\|autoimmune thyroiditis\|anemia\|anaemia\|cirrhosis\|cancer\|thyroiditis)\b` | 3 | 3 | seed 3 |
| en | any | `\b(hemochromatosis\|haemochromatosis)\s+screening\b` | 3 | 1 | seed 3 |
| en | any | `\b(death\|deaths\|dying\|die\|survival)\b` | 2 | 1 | seed 2 |
| en | any | `\brule out\b` | 2 | 2 | seed 2 |
| en | any | `\bscreen(ing)?\s+for\b` | 2 | 2 | seed 2 |
| en | any | `\bpredict(s\|ed\|ion\|ions\|or\|ors\|ive)?\b` | 1 | 1 | seed 1 |
| en | any | `\bprognos\w*` | 1 | 1 | seed 1 |
| en | any | `\b(rosuvastatin\|atorvastatin\|simvastatin\|pravastatin\|ezetimibe\|metformin\|levothyroxine\|allopurinol\|febuxostat\|bempedoic\|inclisiran\|evolocumab\|alirocumab)\b` | 1 | 1 | seed 1 |
| es | non_critical | `atenci[oó]n m[eé]dica (pronta\|inmediata\|urgente\|sin demora)` | 77 | 39 | seed 75, src/components/dashboard/MedicalDisclaimer.tsx 2 |
| es | non_critical | `\bsin demora\b` | 75 | 39 | seed 75 |
| es | any | `(^\|[.;:!?]\s+\|\n\s*)(evaluar\|descartar\|valorar\|considerar\|monitorizar\|vigilar\|cribar\|solicitar\|realizar\|seguir\|explorar\|investigar)\b` | 47 | 27 | seed 47 |
| es | any | `\bmortalidad\b` | 20 | 10 | seed 20 |
| es | trend (section 6) | `\b(tendiendo\|mejorando\|empeorando\|tendencia\|velocidad)\b` | 16 | 4 | seed 15, detail-client.tsx 1 |
| es | any | `\bcribado\b` | 9 | 4 | seed 9 |
| es | any | `\bseguir (la )?velocidad\b` | 4 | 1 | seed 4 |
| es | any | `\bdescart\w*` | 3 | 2 | seed 3 |
| es | any | `\b(muerte\|morir\|fallec\w*\|supervivencia)\b` | 2 | 1 | seed 2 |
| es | any | `\bpredi(ce\|cen\|cción\|cciones\|ctor\|ctora\|ctores)\b` | 2 | 2 | seed 2 |
| es | any | `\bpron[oó]stic\w*` | 1 | 1 | seed 1 |
| es | any | `\b(rosuvastatina\|atorvastatina\|simvastatina\|pravastatina\|ezetimiba\|metformina\|levotiroxina\|alopurinol\|febuxostat\|bempedoico\|inclisir[aá]n\|evolocumab\|alirocumab)\b` | 1 | 1 | seed 1 |

Frase de red de seguridad estándar presente hoy: español 0 de 290 mensajes fuera de rango; inglés 0 de 290. (Hoy 212 de 290 mensajes fuera de rango en cada idioma cierran con "Coméntalo con tu médico" / "Discuss it with your doctor", que no es la frase estándar.) / Standard safety-net sentence present today: Spanish 0 of 290 out-of-range messages; English 0 of 290.

Ejemplos (un texto por regla) / Examples (one text per rule):

- `es` `any` `\bmortalidad\b` … seed:HDL Grande:Msg_Crítico_Alto: "…os estudios se han asociado a una mayor mortalidad. Coméntalo con tu médico.…"
- `es` `any` `\b(muerte\|morir\|fallec\w*\|supervivencia)\b` … seed:Índice Neutrófilo-Linfocito (INL):Msg_Óptimo: "…ptimo. En grandes cohortes europeas, la supervivencia fue mejor en la parte baja del interval…"
- `es` `any` `\bpredi(ce\|cen\|cción\|cciones\|ctor\|ctora\|ctores)\b` … seed:Número de Partículas LDL:Notas_Clínicas: "…artículas muy distintas — y el recuento predice el riesgo mejor que la cifra de coleste…"
- `es` `any` `\bpron[oó]stic\w*` … seed:None:Notas_Clínicas: "…orio elevado. Asociado con eventos CV y pronóstico oncológico.…"
- `es` `any` `\b(rosuvastatina\|atorvastatina\|simvastatina\|pravas` … seed:Homocisteína:Msg_Crítico_Alto: "…l, hipotiroidismo, medicamentos como la metformina o los inhibidores de la bomba de proton…"
- `es` `any` `(^\|[.;:!?]\s+\|\n\s*)(evaluar\|descartar\|valorar\|con` … seed:Anticuerpos Antitiroglobulina (TgAb):Msg_Encima_Óptimo: "…r actividad autoinmune tiroidea temprana. Monitorizar.…"
- `es` `any` `\bdescart\w*` … seed:Hierro (Sérico):Msg_Encima_Óptimo: "…itina y saturación de transferrina para descartar sobrecarga de hierro.…"
- `es` `any` `\bcribado\b` … seed:PSA, Total:Notas_Clínicas: "…a convierte en el principal marcador de cribado de la salud prostática en hombres.…"
- `es` `any` `\bseguir (la )?velocidad\b` … seed:PSA, Total:Msg_Óptimo: "…ando bajo riesgo de cáncer de próstata. Seguir velocidad en el tiempo.…"
- `es` `non_critical` `atenci[oó]n m[eé]dica (pronta\|inmediata\|urgente\|si` … seed:PCR de Alta Sensibilidad (hs-PCR):Msg_Crítico_Alto: "…alor muy alejado del intervalo requiere atención médica sin demora.…"
- `es` `non_critical` `\bsin demora\b` … seed:PCR de Alta Sensibilidad (hs-PCR):Msg_Crítico_Alto: "… del intervalo requiere atención médica sin demora.…"
- `en` `any` `\bmortalit(y\|ies)\b` … seed:HDL Large:Msg_Critical_High: "…he heart and have been linked to higher mortality in some studies. Discuss it with your d…"
- `en` `any` `\b(death\|deaths\|dying\|die\|survival)\b` … seed:NLR:Msg_Optimal: "…timal range. In large European cohorts, survival was best at the lower end of the usual …"
- `en` `any` `\bpredict(s\|ed\|ion\|ions\|or\|ors\|ive)?\b` … seed:RDW:Msg_Above_Optimal: "…ll size. Elevated RDW is an independent predictor of mortality.…"
- `en` `any` `\bprognos\w*` … seed:None:Clinical_Notes: "…e. Associated with CV events and cancer prognosis.…"
- `en` `any` `\bsuggest(s\|ing)?\s+(a\s+\|an\s+)?(prediabetes\|diab` … seed:Thyroid Peroxidase Antibodies (TPO):Msg_Above_Optimal: "…TPO antibodies are elevated, suggesting autoimmune thyroiditis. Monitor thyroid function over time as …"
- `en` `any` `\b(rosuvastatin\|atorvastatin\|simvastatin\|pravastat` … seed:Homocysteine:Msg_Critical_High: "…ease, hypothyroidism, medicines such as metformin or proton pump inhibitors, and delayed …"
- `en` `any` `(^\|[.;:!?]\s+\|\n\s*)(evaluate\|rule out\|assess\|cons` … seed:Thyroglobulin Antibodies (TgAb):Msg_Above_Optimal: "…uggest early autoimmune thyroid activity. Monitor over time.…"
- `en` `any` `\brule out\b` … seed:Vitamin B12:Msg_Above_Optimal: "…supplement, evaluate liver function and rule out hematologic conditions.…"
- `en` `any` `\bscreen(ing)?\s+for\b` … seed:Iron % Saturation (TSAT):Msg_Critical_High: "…s it with your doctor, who may consider screening for hemochromatosis.…"
- `en` `any` `\b(hemochromatosis\|haemochromatosis)\s+screening\b` … seed:Ferritin:Msg_Above_Optimal: "…flammation. If truly elevated, consider hemochromatosis screening.…"
- `en` `any` `\btrack(ing)?\s+(the\s+)?velocity\b` … seed:PSA, Total:Msg_Optimal: "…e, reflecting low prostate cancer risk. Track velocity over time.…"
- `en` `any` `\bmonitor\s+(the\s+)?trend\b` … seed:PSA, Total:Msg_Above_Optimal: "…get for your age. While not diagnostic, monitor trend and velocity carefully.…"
- `en` `non_critical` `\b(prompt\|immediate\|urgent)\s+medical\s+(attention` … seed:hs-CRP:Msg_Critical_High: "…or. A value far outside the range needs prompt medical attention.…"
