// Generates scripts/signoff/fixtures/personas.json (deterministic; run once, the JSON is the fixture).
const fs = require("fs");
const BASE = {
  male: { albumin: 45, alp: 70, hs_crp: 0.8, creatinine: 1.0, bun: 15, ggt: 22, hba1c: 5.3, glucose_fasting: 88, insulin_fasting: 6, homa_ir: 1.3, apolipoprotein_b_apob: 85, ldl_cholesterol: 110, hdl_cholesterol: 52, triglycerides: 100, total_cholesterol: 185, non_hdl_cholesterol: 133, hemoglobin: 15.0, hematocrit: 44, red_blood_cell_count: 5000000, white_blood_cell_count: 6000, neutrophils_absolute: 3500, lymphocytes_absolute: 1900, nlr: 1.8, platelet_count: 240000, mcv: 90, rdw: 12.8, ferritin: 120, iron_serum: 100, iron_saturation_tsat: 30, tsh: 1.8, free_t4_thyroxine: 1.2, alt: 24, ast: 22, total_bilirubin: 0.7, egfr_creatinine_based: 100, uric_acid: 5.5, vitamin_d_25_oh: 32, vitamin_b12: 450, potassium: 4.3, sodium: 140, calcium_serum: 95, magnesium_serum: 2.1, testosterone_total: 5.5, shbg: 40 },
  female: { albumin: 43, alp: 60, hs_crp: 1.0, creatinine: 0.75, bun: 13, ggt: 16, hba1c: 5.2, glucose_fasting: 85, insulin_fasting: 6, homa_ir: 1.25, apolipoprotein_b_apob: 80, ldl_cholesterol: 105, hdl_cholesterol: 62, triglycerides: 85, total_cholesterol: 185, non_hdl_cholesterol: 123, hemoglobin: 13.5, hematocrit: 40, red_blood_cell_count: 4500000, white_blood_cell_count: 6000, neutrophils_absolute: 3500, lymphocytes_absolute: 1900, nlr: 1.8, platelet_count: 260000, mcv: 89, rdw: 13.0, ferritin: 60, iron_serum: 90, iron_saturation_tsat: 28, tsh: 1.8, free_t4_thyroxine: 1.2, alt: 17, ast: 19, total_bilirubin: 0.6, egfr_creatinine_based: 105, uric_acid: 4.3, vitamin_d_25_oh: 30, vitamin_b12: 450, potassium: 4.2, sodium: 139, calcium_serum: 94, magnesium_serum: 2.0, estradiol: 80, shbg: 60 },
};
const r = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;
function healthy(sex, age) {
  const v = { ...BASE[sex] };
  const dec = (age - 25) / 10;
  v.hba1c = r(v.hba1c + 0.05 * Math.max(dec, 0));
  v.glucose_fasting = r(v.glucose_fasting + 1 * Math.max(dec, 0), 0);
  v.alp = r(v.alp + 3 * Math.max(dec, 0), 0);
  v.bun = r(v.bun + 1 * Math.max(dec, 0), 0);
  v.ldl_cholesterol = r(v.ldl_cholesterol + 5 * Math.min(Math.max(dec, 0), 4), 0);
  v.apolipoprotein_b_apob = r(v.apolipoprotein_b_apob + 4 * Math.min(Math.max(dec, 0), 4), 0);
  v.total_cholesterol = r(v.total_cholesterol + 6 * Math.min(Math.max(dec, 0), 4), 0);
  v.non_hdl_cholesterol = r(v.total_cholesterol - v.hdl_cholesterol, 0);
  if (age >= 40) v.egfr_creatinine_based = r(v.egfr_creatinine_based - 8 * ((age - 40) / 10), 0);
  if (age >= 60) v.albumin = r(v.albumin - 0.8 * ((age - 60) / 10), 1);
  if (sex === "male" && age >= 70) v.hemoglobin = r(v.hemoglobin - 0.4 * ((age - 70) / 10) - 0.3, 1);
  if (sex === "male" && age >= 40) v.testosterone_total = r(v.testosterone_total - 0.3 * ((age - 40) / 10), 1);
  if (sex === "female" && age >= 52) {
    v.estradiol = 15;
    v.ldl_cholesterol += 15;
    v.apolipoprotein_b_apob += 10;
    v.total_cholesterol += 15;
    v.non_hdl_cholesterol = v.total_cholesterol - v.hdl_cholesterol;
    v.alp += 15;
    v.ferritin = 110;
  }
  if (age >= 70) v.vitamin_b12 = 380;
  return v;
}
const base = (o) => ({ fasting: true, collection_method: "venous", lab_source: "echevarne", conditions: [], medications: [], supplements: [], ...o });
const P = [];
const add = (id, sex, age, group, healthyFlag, note, values, state = {}, context = {}) =>
  P.push({ id, sex, age, group, healthy: healthyFlag, note, state: { physiological_state: "none", ...state }, context: base(context), values });

for (const sex of ["female", "male"]) for (const age of [25, 35, 45, 55, 65, 75, 85])
  add(`healthy_${sex}_${age}`, sex, age, "healthy_by_decade", true, `Healthy ${sex} aged ${age}: typical values for a well adult of that age and sex, no medication.`, healthy(sex, age), sex === "female" && age >= 55 ? { physiological_state: "postmenopausal" } : {});
add("healthy_female_19", "female", 19, "age_edge", true, "Healthy 19-year-old woman: tests the 18-19 policy and the biological age's lower age limit (20).", healthy("female", 19));
add("healthy_male_19", "male", 19, "age_edge", true, "Healthy 19-year-old man: tests the 18-19 policy and the biological age's lower age limit (20).", healthy("male", 19));
add("healthy_male_79", "male", 79, "age_edge", true, "Healthy 79-year-old man: last age of the fallback signed range 20-79.", healthy("male", 79));
add("healthy_female_82", "female", 82, "age_edge", true, "Healthy 82-year-old woman: inside the module's 20-84 range, outside the fallback signed range 20-79 until B5 holds.", healthy("female", 82), { physiological_state: "postmenopausal" });
add("healthy_female_95", "female", 95, "age_edge", true, "Healthy 95-year-old woman: tests the 85-and-over policy; no biological age.", { ...healthy("female", 95), albumin: 40, egfr_creatinine_based: 55, creatinine: 0.9, hemoglobin: 12.4, hematocrit: 37.5 }, { physiological_state: "postmenopausal" });
const f30 = healthy("female", 30);
add("pregnancy_t1", "female", 30, "pregnancy", true, "First trimester, 10 weeks: haemodilution starting, creatinine and urea fall.", { ...f30, hemoglobin: 12.2, hematocrit: 36, albumin: 39, creatinine: 0.55, bun: 9, white_blood_cell_count: 8000, neutrophils_absolute: 5200, nlr: 2.7, tsh: 1.2 }, { physiological_state: "pregnancy", trimester: 1 }, { conditions: ["pregnancy_current"] });
add("pregnancy_t2", "female", 31, "pregnancy", true, "Second trimester, 24 weeks: lower albumin and haemoglobin, placental ALP rising, lipids rising.", { ...f30, hemoglobin: 11.5, hematocrit: 34, albumin: 34, creatinine: 0.5, bun: 8, alp: 110, white_blood_cell_count: 9500, neutrophils_absolute: 6800, nlr: 3.4, triglycerides: 180, ldl_cholesterol: 140, apolipoprotein_b_apob: 105, total_cholesterol: 240, non_hdl_cholesterol: 175, ferritin: 25 }, { physiological_state: "pregnancy", trimester: 2 }, { conditions: ["pregnancy_current"] });
add("pregnancy_t3", "female", 32, "pregnancy", true, "Third trimester, 34 weeks: albumin near 31 g/L, ALP about 200 U/L, triglycerides high, mild neutrophilia; all physiological.", { ...f30, hemoglobin: 11.3, hematocrit: 33.5, albumin: 31, creatinine: 0.55, bun: 8, alp: 200, white_blood_cell_count: 10500, neutrophils_absolute: 7800, nlr: 3.9, triglycerides: 230, ldl_cholesterol: 155, apolipoprotein_b_apob: 120, total_cholesterol: 265, non_hdl_cholesterol: 195, hs_crp: 4, ferritin: 18, platelet_count: 200000 }, { physiological_state: "pregnancy", trimester: 3 }, { conditions: ["pregnancy_current"] });
add("lactation", "female", 32, "lactation", true, "Exclusively breastfeeding, 4 months post partum.", { ...f30, alp: 85, triglycerides: 110, ferritin: 35, hemoglobin: 12.8 }, { physiological_state: "lactation" }, { conditions: ["lactating"] });
add("perimenopause", "female", 48, "menopause", true, "Perimenopausal, irregular cycles; oestradiol fluctuating.", { ...healthy("female", 48), estradiol: 150 }, { physiological_state: "perimenopausal" });
add("postmenopause_oral_ht", "female", 56, "menopause", true, "Postmenopausal on oral oestradiol: hs-CRP, triglycerides and SHBG raised by the oral route.", { ...healthy("female", 56), estradiol: 45, hs_crp: 2.5, triglycerides: 140, shbg: 95 }, { physiological_state: "postmenopausal", hormone_therapy: "oral" }, { medications: ["oral_estradiol"] });
add("postmenopause_transdermal_ht", "female", 57, "menopause", true, "Postmenopausal on transdermal oestradiol: neutral on CRP and triglycerides.", { ...healthy("female", 57), estradiol: 50 }, { physiological_state: "postmenopausal", hormone_therapy: "transdermal" }, { medications: ["transdermal_estradiol"] });
add("postmenopause_no_ht", "female", 60, "menopause", true, "Postmenopausal, no hormone therapy.", healthy("female", 60), { physiological_state: "postmenopausal" });
add("oral_contraception", "female", 26, "contraception", true, "Combined oral contraceptive: SHBG, triglycerides and hs-CRP raised.", { ...healthy("female", 26), hs_crp: 2.2, triglycerides: 120, shbg: 110, ferritin: 50 }, { oral_contraception: true }, { medications: ["combined_oral_contraceptive"] });
add("duffy_null", "female", 32, "benign_variant", true, "Duffy-null phenotype (ACKR1): neutrophils 1.1 x10^9/L, benign; must not be told this is dangerous.", { ...healthy("female", 32), white_blood_cell_count: 3400, neutrophils_absolute: 1100, lymphocytes_absolute: 1900, nlr: 0.58 });
add("gilbert", "male", 28, "benign_variant", true, "Gilbert syndrome: unconjugated bilirubin 2.4 mg/dL, otherwise healthy; benign.", { ...healthy("male", 28), total_bilirubin: 2.4 });
add("thalassaemia_trait", "male", 34, "benign_variant", true, "Beta-thalassaemia trait: microcytosis with a high red cell count and normal ferritin; benign.", { ...healthy("male", 34), mcv: 68, hemoglobin: 12.9, hematocrit: 41, red_blood_cell_count: 6000000, rdw: 14.5, ferritin: 110 });
add("endurance_athlete_male", "male", 31, "lifestyle", true, "Marathon runner, sample two days after a long run: AST and creatinine raised, high HDL, low hs-CRP.", { ...healthy("male", 31), ast: 45, alt: 30, creatinine: 1.25, bun: 20, hemoglobin: 14.0, hdl_cholesterol: 70, hs_crp: 0.4, ferritin: 45, glucose_fasting: 80 });
add("endurance_athlete_female", "female", 29, "lifestyle", true, "Triathlete: low ferritin, high HDL, low resting glucose.", { ...healthy("female", 29), ferritin: 22, iron_saturation_tsat: 20, hdl_cholesterol: 80, glucose_fasting: 78, creatinine: 0.9 });
add("vegetarian_female", "female", 34, "lifestyle", true, "Lacto-ovo vegetarian: lower B12, ferritin, LDL and uric acid.", { ...healthy("female", 34), vitamin_b12: 230, ferritin: 22, ldl_cholesterol: 85, apolipoprotein_b_apob: 65, total_cholesterol: 160, non_hdl_cholesterol: 98, uric_acid: 3.8 });
add("vegetarian_male", "male", 40, "lifestyle", true, "Vegetarian for 15 years: B12 at the low end, low LDL.", { ...healthy("male", 40), vitamin_b12: 260, ferritin: 70, ldl_cholesterol: 90, apolipoprotein_b_apob: 72, total_cholesterol: 165, non_hdl_cholesterol: 113 });
add("statin_male", "male", 58, "treated", false, "On atorvastatin 20 mg for primary prevention: LDL and apoB lowered, ALT slightly up.", { ...healthy("male", 58), ldl_cholesterol: 70, apolipoprotein_b_apob: 65, total_cholesterol: 140, non_hdl_cholesterol: 88, alt: 35 }, {}, { medications: ["statin"] });
add("statin_female", "female", 62, "treated", false, "On rosuvastatin after a raised LDL at 60.", { ...healthy("female", 62), ldl_cholesterol: 75, apolipoprotein_b_apob: 68, total_cholesterol: 150, non_hdl_cholesterol: 88 }, { physiological_state: "postmenopausal" }, { medications: ["statin"] });
add("levothyroxine", "female", 45, "treated", false, "On levothyroxine for Hashimoto's: TSH in range, free T4 high-normal.", { ...healthy("female", 45), tsh: 1.5, free_t4_thyroxine: 1.5 }, {}, { medications: ["levothyroxine"], conditions: ["hypothyroidism"] });
add("ckd_g3a", "male", 66, "condition", false, "Chronic kidney disease G3a: eGFR 52, urea and uric acid raised, mild anaemia.", { ...healthy("male", 66), egfr_creatinine_based: 52, creatinine: 1.45, bun: 26, uric_acid: 7.2, hemoglobin: 13.0, hematocrit: 39, potassium: 4.9 }, {}, { conditions: ["chronic_kidney_disease"] });
add("acute_infection", "female", 38, "condition", false, "Acute respiratory infection: hs-CRP 40 mg/L, neutrophilia, ferritin up as an acute-phase reactant.", { ...healthy("female", 38), hs_crp: 40, white_blood_cell_count: 13500, neutrophils_absolute: 11000, lymphocytes_absolute: 1300, nlr: 8.5, ferritin: 260, albumin: 37 });
add("creatine_user", "male", 30, "supplement", true, "Takes creatine 5 g/day for the gym: creatinine 1.35 mg/dL from the supplement, kidneys normal.", { ...healthy("male", 30), creatinine: 1.35, egfr_creatinine_based: 72 }, {}, { supplements: [{ key: "creatine", dose: "5 g" }] });
add("non_fasting_male", "male", 44, "preanalytical", true, "Healthy man, sample taken after breakfast: non-fasting glucose and triglycerides.", { ...healthy("male", 44), glucose_fasting: 112, triglycerides: 190, insulin_fasting: 22, homa_ir: 6.1 }, {}, { fasting: false });
P.sort((a, b) => a.id.localeCompare(b.id));
const doc = {
  _doc: "Synthetic personas for DSRT check Q1 (docs/signoff/ACCEPTANCE-TEST.md). Values are plausible for each persona, in EVA's canonical units (the seed rows' units: albumin g/L, counts per microlitre, calcium mg/L). state carries the physiological state; context the conditions (patient-context keys), medications, supplements, fasting status and collection method. 'healthy' marks the personas the healthy rules of Q1 apply to. Synthetic, no real person.",
  version: "1, 2026-11-06",
  personas: P,
};
fs.writeFileSync(process.argv[2], JSON.stringify(doc, null, 1) + "\n");
console.log(P.length);
