import re,sys
src=" ".join(open(p,encoding='utf-8').read() for p in ["src1/batch1.txt","src1/batch2.txt","src1/batch3.txt"])
src=re.sub(r'\s+',' ',src)
quotes={
"yi":"In the age groups of 18-34, 35-44, 45-54, 55-64, 65-74, and 75-99 years, each 1 mmol/L higher TC increased mortality by 14%, 13%, 8%, 7%, 6%, and 3%, respectively (P < 0.001 for each age group), for TC ≥ 200 mg/dL, while the corresponding TC changes decreased mortality by 13%, 27%, 34%, 31%, 20%, and 13%, respectively, in the range < 200 mg/dL (P < 0.001 for each age group). TC had U-curve associations with mortality in each age-sex group. TC levels associated with lowest mortality were 210-249 mg/dL, except for men aged 18-34 years (180-219 mg/dL) and women aged 18-34 years (160-199 mg/dL) and 35-44 years (180-219 mg/dL).",
"psc1":"a sixth (0.83 [0.81-0.85]) lower IHD mortality in both sexes at ages 40-49, 50-69, and 70-89 years, respectively",
"psc2":"at older ages (70-89 years) and, particularly, for those with systolic blood pressure over about 145 mm Hg, total cholesterol was negatively related to haemorrhagic and total stroke mortality",
"aspree":"Restricted cubic splines found a U-shaped relation for LDL-c and all-cause mortality, cancer mortality, and noncancer/non-CVE mortality (nadir: 3.3-3.4 mmol/L); the risk of CVD mortality was similar at LDL-c below 3.3 mmol/L and increased above 3.3 mmol/L.",
"fu":"We observed significant interactions between non-HDL-C and age for all-cause and cardiovascular mortality (P interaction<0.05 for each).",
"mort":"Risk of myocardial infarction per 1·0 mmol/L increase in LDL cholesterol was augmented for the overall population (HR 1·34, 95% CI 1·27-1·41) and was amplified for all age groups, particularly those aged 70-100 years.",
"bathum_tg":"For triglycerides, ratios compared with the group < 1 mmol/L in the females aged 60-70 years ranged from 1.04 (95% CI 0.88-1.23) to 1.35 (95% CI 1.10-1.66) and 1.25 (95% CI 1.05-1.48) for triglycerides 1-1.39 mmol/L, 1.4-1.69 mmol/L, and ≥ 1.7 mmol/L, respectively.",
"bathum_tc":"All-cause mortality was lower in the groups with TC or LDL-C above the recommended levels.",
"johan":"The concentration of LDL-C associated with the lowest risk of all cause mortality was 3.6 mmol/L (140 mg/dL) in the overall population and in individuals not receiving lipid lowering treatment",
"simony":"In women, levels were 27% higher after menopause (p = 4∙10-61) and 12% lower during hormone replacement therapy (p = 2∙10-19).",
"wu":"During pregnancy, we observed significant increases in total cholesterol (TC), triglycerides (TG), high density lipoprotein cholesterol (HDL-C), low density lipoprotein cholesterol (LDL-C), apolipoprotein-A1 (Apo-A1), apolipoprotein-B (Apo-B), cystatin C (Cys-C), and estimated glomerular filtration rate (eGFR).",
"kornelius":"However, no significant increase in risk was observed for the same category in older age groups.",
}
for k,q in quotes.items():
    print(k, q in src, len(q.split()))
