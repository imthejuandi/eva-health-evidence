#!/usr/bin/env node
// Scratch helper: fetch a source the same way the programme's quote check does (into a scratch cache, never the repo cache),
// grep it, and check a quote. Usage:
//   node src.js get <type> <value>            -> prints bytes and the cache path
//   node src.js grep <type> <value> <regex> [ctx] -> prints matches with context chars
//   node src.js quote <type> <value> <quote>  -> prints match score
"use strict";
const path = require("path");
const REPO = "/home/user/eva-health/docs/signoff/tools/lib";
const { getSourceText } = require(path.join(REPO, "sources.js"));
const { matchQuote, statusForMatch, wordCount, normaliseText } = require(path.join(REPO, "text-normalise.js"));
const CACHE = path.join(__dirname, "cache");
(async () => {
  const [cmd, type, value, arg, ctxArg] = process.argv.slice(2);
  const r = await getSourceText({ type, value }, { cacheDir: CACHE });
  if (!r.from_cache) require("fs").appendFileSync(path.join(__dirname,"fetch.log"), `helper ${type} ${value}\n`);
  if (!r.ok) { console.log("FETCH FAILED:", r.error, r.fetched_from || ""); process.exit(2); }
  if (cmd === "get") { console.log(`ok bytes=${r.text.length} from_cache=${r.from_cache} path=${r.cache_path} from=${r.fetched_from}`); return; }
  if (cmd === "print") { console.log(r.text); return; }
  if (cmd === "grep") {
    const ctx = Number(ctxArg || 300);
    const re = new RegExp(arg, "gi");
    const flat = r.text.replace(/\s+/g, " ");
    let m, n = 0;
    while ((m = re.exec(flat)) && n < 60) {
      n++;
      console.log(`[@${m.index}] ...${flat.slice(Math.max(0, m.index - ctx), m.index + m[0].length + ctx)}...\n`);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
    console.log(`${n} match(es)`);
    return;
  }
  if (cmd === "quote") {
    const m = matchQuote(arg, r.text);
    console.log(JSON.stringify({ words: wordCount(arg), score: m.score, method: m.method, status: statusForMatch(m), missing_numbers: m.missing_numbers }, null, 0));
    if (m.score < 1) console.log("snippet:", m.snippet);
    return;
  }
})();
