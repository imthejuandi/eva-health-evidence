// Fetch helper for the f03_kidney audit. Free endpoints only (Europe PMC REST, NCBI efetch, plain URLs).
// Usage: node fetch.js <jobs.json>   where jobs = [{name, type: epmc|pmid|pmc|url, value, pageSize?, print?}]
// Writes raw text to src/<name>.txt and prints a compact summary (title, ids, abstract head) for epmc jobs.
"use strict";
const fs = require("fs");
const path = require("path");
const OUT = path.join(__dirname, "src");
fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const EPMC = "https://www.ebi.ac.uk/europepmc/webservices/rest";
function strip(s) {
  return String(s || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/[ \t]+/g, " ").trim();
}
async function get(url) {
  const r = await fetch(url, { headers: { "user-agent": "eva-health-signoff-f03/1.0", accept: "text/plain, application/json, application/xml, text/html;q=0.9, */*;q=0.5" }, redirect: "follow" });
  const text = await r.text();
  return { ok: r.ok, status: r.status, text };
}
(async () => {
  const jobs = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  for (const job of jobs) {
    await sleep(400);
    try {
      let url;
      if (job.type === "epmc") url = `${EPMC}/search?query=${encodeURIComponent(job.value)}&resultType=core&format=json&pageSize=${job.pageSize || 10}`;
      else if (job.type === "pmid") url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${job.value}&rettype=abstract&retmode=text`;
      else if (job.type === "pmc") url = `${EPMC}/${job.value}/fullTextXML`;
      else if (job.type === "url") url = job.value;
      const r = await get(url);
      const file = path.join(OUT, `${job.name}.txt`);
      console.log(`\n##### ${job.name} [${job.type}] HTTP ${r.status} bytes=${r.text.length}`);
      if (!r.ok) { fs.writeFileSync(file, r.text); console.log(r.text.slice(0, 300)); continue; }
      if (job.type === "epmc") {
        const j = JSON.parse(r.text);
        const res = j.resultList?.result || [];
        console.log(`hits=${j.hitCount}`);
        const lines = [];
        for (const x of res) {
          const head = `- ${x.pmid || "-"} | ${x.pmcid || "-"} | ${x.doi || "-"} | ${x.pubYear} | ${x.journalTitle || x.bookOrReportDetails?.publisher || ""}\n  ${x.title}\n  ${x.authorString || ""}`;
          lines.push(head + "\n  ABSTRACT: " + strip(x.abstractText));
          console.log(head + (job.print === false ? "" : "\n  ABSTRACT: " + strip(x.abstractText).slice(0, job.abstractChars || 1800)));
        }
        fs.writeFileSync(file, lines.join("\n\n"));
      } else if (job.type === "pmc") {
        const txt = strip(r.text.replace(/<\/(p|sec|title|abstract|table|caption|label|tr|td|th|li)>/gi, "\n"));
        fs.writeFileSync(file, txt);
        console.log(txt.slice(0, job.head || 600));
      } else {
        const txt = /^\s*</.test(r.text) ? strip(r.text.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<\/(p|div|br|li|tr|td|th|h[1-6]|table)>/gi, "\n")) : r.text;
        fs.writeFileSync(file, txt);
        console.log(txt.slice(0, job.head || 2500));
      }
    } catch (e) {
      console.log(`\n##### ${job.name} ERROR ${e.message}`);
    }
  }
})();
