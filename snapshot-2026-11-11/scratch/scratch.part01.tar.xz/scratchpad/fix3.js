const fs = require("fs");
const f = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/f11gen.js";
let s = fs.readFileSync(f, "utf8");
function rep(o, n, k = 1) { const c = s.split(o).length - 1; if (c !== k) throw new Error(`count ${c} != ${k}: ${o.slice(0, 80)}`); s = s.split(o).join(n); }
rep("Repeat the test in 2 to 4 weeks and ask your doctor for one sample to be taken in a citrate tube, which shows whether clumping was the cause.",
    "Repeat the test in 2 to 4 weeks to confirm it, and ask your doctor for one sample to be taken in a citrate tube, which shows whether clumping was the cause.");
rep("Repite el análisis en 2 a 4 semanas y pide a tu médico que una de las muestras se tome en un tubo de citrato, que muestra si la causa fue que las plaquetas se agruparon.",
    "Repite el análisis en 2 a 4 semanas para confirmarlo, y pide a tu médico que una de las muestras se tome en un tubo de citrato, que muestra si la causa fue que las plaquetas se agruparon.");
rep("and the critical-limit list asks the laboratory to exclude EDTA-induced clumping before it calls ({{THOMAS}}).",
    "and the IFCC list of limits for urgent notification asks the laboratory to exclude EDTA-induced clumping before it calls ({{THOMAS}}).");
rep("y la lista de límites críticos pide al laboratorio que descarte la agregación inducida por EDTA antes de llamar ({{THOMAS}}).",
    "y la lista de la IFCC de límites para aviso urgente pide al laboratorio que compruebe que no hay agregación inducida por EDTA antes de llamar ({{THOMAS}}).");
fs.writeFileSync(f, s); console.log("ok");
