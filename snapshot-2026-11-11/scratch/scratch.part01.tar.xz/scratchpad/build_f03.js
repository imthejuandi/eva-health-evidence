#!/usr/bin/env node
// Builds docs/signoff/work/research/f03_kidney.json (scratch builder; the JSON is the owned deliverable).
"use strict";
const fs = require("fs");
const path = require("path");

const OUT = "/home/user/eva-health/docs/signoff/work/research/f03_kidney.json";

// ---------- shared text ----------
const CLOSER_EN = "This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.";
const CLOSER_ES = "Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.";
const CRIT_EN = "This value is beyond the critical limit set by EVA's responsible physician. Contact a doctor today; if you cannot, go to an emergency department. This result is not a diagnosis.";
const CRIT_ES = "Este valor supera el límite crítico fijado por el médico responsable de EVA. Contacta hoy con un médico; si no puedes, acude a urgencias. Este resultado no es un diagnóstico.";
const ROUTINE_EN = "Discuss it with your doctor at your next check-up.";
const ROUTINE_ES = "Coméntalo con tu médico en tu próxima revisión.";
const SOON_EN = "Book an appointment with your doctor in the next few weeks.";
const SOON_ES = "Pide cita con tu médico en las próximas semanas.";

// ---------- pre-analytical rules (shared) ----------
const PRE_CREAT = [
  { rule: "fasting", effect: "note", non_fasting_high: null,
    text_en: "A meal with cooked meat raises creatinine for a few hours (median rise from 80.5 to 101.0 µmol/L at 1 to 2 hours in one study) and the effect is gone after 12 hours of fasting. Give the sample fasting or without cooked meat on the day; if you ate meat shortly before the draw, a borderline high value should be repeated fasting.",
    text_es: "Una comida con carne cocinada sube la creatinina durante unas horas (en un estudio, la mediana pasó de 80,5 a 101,0 µmol/L a la 1 o 2 horas) y el efecto desaparece tras 12 horas de ayuno. Da la muestra en ayunas o sin carne cocinada ese día; si comiste carne poco antes de la extracción, un valor alto en el límite debe repetirse en ayunas.",
    evidence_ids: ["f03-E26", "f03-E27"] },
  { rule: "exercise", effect: "note", non_fasting_high: null,
    text_en: "Hard or prolonged exercise raises creatinine for about a day: after a marathon 68.9% of collapsed runners and most non-collapsed runners had a value above the reference range, back to baseline within 24 hours. Avoid hard exercise in the 48 hours before the draw.",
    text_es: "El ejercicio intenso o prolongado sube la creatinina durante aproximadamente un día: tras un maratón, el 68,9% de los corredores que se desplomaron y la mayoría de los que no tenían un valor por encima del intervalo, que volvió a su nivel en 24 horas. Evita el ejercicio intenso en las 48 horas previas a la extracción.",
    evidence_ids: ["f03-E28"] },
  { rule: "medication", effect: "note", non_fasting_high: null,
    text_en: "Creatine supplements raise creatinine by about 0.13 mg/dL in pooled trials without changing urea or eGFR (the locked creatine rule adjusts the version 3 input, not the displayed value). Trimethoprim blocks creatinine secretion and raises it reversibly (median 87 to 107 µmol/L in young adults, 89 to 134 µmol/L in older adults) without any change in filtration; cimetidine and some newer drugs do the same. Declare supplements and medicines in the context form.",
    text_es: "Los suplementos de creatina suben la creatinina unos 0,13 mg/dL en los ensayos agrupados, sin cambiar la urea ni la TFGe (la regla de creatina bloqueada ajusta la entrada de la versión 3, no el valor mostrado). El trimetoprim bloquea la secreción de creatinina y la sube de forma reversible (mediana de 87 a 107 µmol/L en adultos jóvenes y de 89 a 134 µmol/L en mayores) sin ningún cambio en la filtración; la cimetidina y algunos fármacos nuevos hacen lo mismo. Declara suplementos y medicamentos en el formulario de contexto.",
    evidence_ids: ["f03-E25", "f03-E29"] },
  { rule: "haemolysis", effect: "note", non_fasting_high: null,
    text_en: "Creatinine is not on the P1 haemolysis list (potassium, AST, LDH, bilirubin, iron, magnesium). No usable interference source was opened in this task; Echevarne's haemolysis, lipaemia and icterus limits are requested in the methods letter (launch track L4). Until then a haemolysed sample is reported as the laboratory reports it.",
    text_es: "La creatinina no está en la lista de hemólisis de P1 (potasio, AST, LDH, bilirrubina, hierro, magnesio). En esta tarea no se abrió ninguna fuente útil sobre interferencia; los límites de hemólisis, lipemia e ictericia de Echevarne se piden en la carta de métodos (vía de lanzamiento L4). Hasta entonces una muestra hemolizada se informa como la informa el laboratorio.",
    evidence_ids: [] },
  { rule: "capillary", effect: "values_only", non_fasting_high: null,
    text_en: "Ranges, score and version 3 are checked for venous Echevarne serum only. A capillary kit result is shown as a value with no category until the paired capillary-venous study passes (PLAN.md section 10, decision 2).",
    text_es: "Los rangos, la puntuación y la versión 3 están comprobados solo para suero venoso de Echevarne. Un resultado de kit capilar se muestra como valor sin categoría hasta que la comparación capilar-venosa supere su prueba (PLAN.md sección 10, decisión 2).",
    evidence_ids: [] },
  { rule: "draw_time", effect: "note", non_fasting_high: null,
    text_en: "No draw-time rule: creatinine has no clinically relevant diurnal rhythm in the sources opened; the within-day variation seen in healthy people is driven by meat meals, not by the hour.",
    text_es: "Sin regla de hora de extracción: la creatinina no tiene un ritmo diurno relevante en las fuentes abiertas; la variación dentro del día en personas sanas se debe a las comidas con carne, no a la hora.",
    evidence_ids: ["f03-E31"] }
];

const PRE_EGFR = [
  { rule: "fasting", effect: "note", non_fasting_high: null,
    text_en: "eGFR is computed from creatinine, so a meal with cooked meat lowers it for a few hours (median eGFR fell from 84.0 to 59.5 mL/min/1.73 m² at 1 to 2 hours after cooked meat in one study) and the effect is gone after 12 hours of fasting. A borderline low eGFR taken after a meat meal is repeated fasting before anything else.",
    text_es: "La TFGe se calcula a partir de la creatinina, así que una comida con carne cocinada la baja durante unas horas (en un estudio la mediana de TFGe bajó de 84,0 a 59,5 mL/min/1,73 m² a la 1 o 2 horas tras carne cocinada) y el efecto desaparece tras 12 horas de ayuno. Una TFGe baja en el límite tomada tras una comida con carne se repite en ayunas antes de nada.",
    evidence_ids: ["f03-E26", "f03-E27"] },
  { rule: "exercise", effect: "note", non_fasting_high: null,
    text_en: "Hard exercise in the previous 48 hours raises creatinine and lowers eGFR for about a day (resolved within 24 hours after a marathon).",
    text_es: "El ejercicio intenso en las 48 horas previas sube la creatinina y baja la TFGe durante aproximadamente un día (se resolvió en 24 horas tras un maratón).",
    evidence_ids: ["f03-E28"] },
  { rule: "medication", effect: "note", non_fasting_high: null,
    text_en: "Creatine supplements (about 0.13 mg/dL of creatinine) and trimethoprim lower the creatinine-based eGFR without changing true filtration; cystatin C is not affected and is the confirmation test.",
    text_es: "Los suplementos de creatina (unos 0,13 mg/dL de creatinina) y el trimetoprim bajan la TFGe basada en creatinina sin cambiar la filtración real; la cistatina C no se ve afectada y es la prueba de confirmación.",
    evidence_ids: ["f03-E25", "f03-E29"] },
  { rule: "capillary", effect: "values_only", non_fasting_high: null,
    text_en: "Capillary kit results are values only until the paired study passes (PLAN.md section 10, decision 2).",
    text_es: "Los resultados de kit capilar se muestran solo como valor hasta que la comparación capilar-venosa supere su prueba (PLAN.md sección 10, decisión 2).",
    evidence_ids: [] },
  { rule: "other", effect: "note", non_fasting_high: null,
    text_en: "The app computes eGFR with one declared equation, CKD-EPI 2021 (race-free). A laboratory's own eGFR is never used for the category, the score or version 3 (DR-2026-10-30-01). In pregnancy no equation is valid and the pregnancy rule applies.",
    text_es: "La app calcula la TFGe con una única ecuación declarada, CKD-EPI 2021 (sin raza). La TFGe del propio laboratorio nunca se usa para la categoría, la puntuación ni la versión 3 (DR-2026-10-30-01). En el embarazo ninguna ecuación es válida y se aplica la regla de embarazo.",
    evidence_ids: ["f03-E08", "f03-E35"] }
];

const PRE_CYS = [
  { rule: "fasting", effect: "note", non_fasting_high: null,
    text_en: "No fasting rule: cystatin C was unaffected by meat meals in two studies, so it does not need a fasting sample.",
    text_es: "Sin regla de ayuno: la cistatina C no cambió con las comidas con carne en dos estudios, así que no necesita muestra en ayunas.",
    evidence_ids: ["f03-E26", "f03-E31"] },
  { rule: "draw_time", effect: "note", non_fasting_high: null,
    text_en: "Cystatin C shows some diurnal rhythmic variation within the day (hourly sampling study); a morning draw is preferred but no draw time is required for the category.",
    text_es: "La cistatina C muestra cierta variación rítmica diurna dentro del día (estudio con muestras cada hora); se prefiere la extracción por la mañana, pero la categoría no exige una hora.",
    evidence_ids: ["f03-E31"] },
  { rule: "medication", effect: "note", non_fasting_high: null,
    text_en: "Thyroid state moves cystatin C in the opposite direction to creatinine: lower in an underactive thyroid and higher in an overactive thyroid (0.84 to 1.1 mg/L on treating hypothyroidism; 1.32 to 0.95 mg/L on treating hyperthyroidism). Glucocorticoids (methylprednisolone) raise it. Declare thyroid treatment and corticosteroids in the context form.",
    text_es: "El estado tiroideo mueve la cistatina C en sentido contrario a la creatinina: más baja con una tiroides poco activa y más alta con una tiroides hiperactiva (de 0,84 a 1,1 mg/L al tratar el hipotiroidismo; de 1,32 a 0,95 mg/L al tratar el hipertiroidismo). Los glucocorticoides (metilprednisolona) la suben. Declara el tratamiento tiroideo y los corticoides en el formulario de contexto.",
    evidence_ids: ["f03-E33", "f03-E34"] },
  { rule: "other", effect: "note", non_fasting_high: null,
    text_en: "Older age, male sex, greater weight and height, smoking and higher CRP raise cystatin C independently of filtration. Echevarne's assay (nephelometry, code I0650, not mapped in the app at present) has no stated traceability to ERM-DA471/IFCC; the methods letter asks for it.",
    text_es: "La edad, el sexo masculino, más peso y estatura, el tabaco y una PCR más alta suben la cistatina C con independencia de la filtración. El método de Echevarne (nefelometría, código I0650, por ahora sin mapear en la app) no declara trazabilidad a ERM-DA471/IFCC; la carta de métodos la pide.",
    evidence_ids: ["f03-E36", "f03-E20"] },
  { rule: "capillary", effect: "values_only", non_fasting_high: null,
    text_en: "Capillary kit results are values only until the paired study passes (PLAN.md section 10, decision 2).",
    text_es: "Los resultados de kit capilar se muestran solo como valor hasta que la comparación capilar-venosa supere su prueba (PLAN.md sección 10, decisión 2).",
    evidence_ids: [] }
];

const PRE_BUN = (name_en, name_es) => [
  { rule: "fasting", effect: "note", non_fasting_high: null,
    text_en: `${name_en} rises with protein intake and dehydration and falls with a large fluid intake; no numeric non-fasting limit was opened in this task, so the row keeps one interval and the message names diet and hydration as common causes. Creatine supplements do not change urea in pooled trials.`,
    text_es: `${name_es} sube con la ingesta de proteínas y la deshidratación y baja con una ingesta alta de líquidos; en esta tarea no se abrió ningún límite numérico sin ayuno, así que la fila mantiene un solo intervalo y el mensaje nombra la dieta y la hidratación como causas frecuentes. Los suplementos de creatina no cambian la urea en los ensayos agrupados.`,
    evidence_ids: ["f03-E25"] },
  { rule: "capillary", effect: "values_only", non_fasting_high: null,
    text_en: "Capillary kit results are values only until the paired study passes (PLAN.md section 10, decision 2).",
    text_es: "Los resultados de kit capilar se muestran solo como valor hasta que la comparación capilar-venosa supere su prueba (PLAN.md sección 10, decisión 2).",
    evidence_ids: [] },
  { rule: "haemolysis", effect: "note", non_fasting_high: null,
    text_en: "Not on the P1 haemolysis list; Echevarne's interference limits are requested in the methods letter (L4).",
    text_es: "No está en la lista de hemólisis de P1; los límites de interferencia de Echevarne se piden en la carta de métodos (L4).",
    evidence_ids: [] }
];

// ---------- RCV ----------
const RCV_CREAT = { cvi_pct: 4.4, cva_pct: 1.1, rcv_pct: 12.6, placeholder: true,
  source: "CVI 4.4% enzymatic (EuBIVAS, f03-E30; cv.json carries 4.5% from the EFLM database). CVA 1.1% is EuBIVAS's enzymatic analytical CV used as a stand-in until Echevarne's CVA arrives (methods letter L4); Echevarne's method is unknown (catalogue says only UV-Vis spectrophotometry; alkaline picrate CVA was 4.4%, which would give RCV 17.2%). RCV = 1.96 x 2^0.5 x sqrt(CVI^2 + CVA^2) = 12.6%.",
  narrow_band_justification: null };
const RCV_EGFR = { cvi_pct: null, cva_pct: null, rcv_pct: 20, placeholder: true,
  source: "Derived marker: the reference change values of all eGFR equations were within 13% to 20% in people with and without CKD (f03-E31); the upper value is used until Echevarne's creatinine CVA arrives.",
  narrow_band_justification: null };
const RCV_CYS = { cvi_pct: 8.6, cva_pct: 2.0, rcv_pct: 24.5, placeholder: true,
  source: "CVI 8.6% and analytical CV 2.0% in healthy subjects (f03-E32; Dade Behring N Latex assay, 20 subjects); the EFLM meta-analysis abstract (Jonker 2022, PMID 32970605) reports no number. RCV = 1.96 x 2^0.5 x sqrt(8.6^2 + 2.0^2) = 24.5%. Placeholder until Echevarne's CVA arrives.",
  narrow_band_justification: null };
const RCV_BUN = (band) => ({ cvi_pct: 13.9, cva_pct: null, rcv_pct: 38.5, placeholder: true,
  source: "CVI 13.9% for urea from the EFLM biological variation database as recorded in cv.json (version 3 input bundle; the EuBIVAS urea abstract, PMID 29941472, gives no number). CVA unknown until Echevarne answers; RCV with CVA = 0 is 1.96 x 2^0.5 x 13.9 = 38.5% and will rise once the CVA is known.",
  narrow_band_justification: `The optimal band ${band} is ${band === "10-16 mg/dL" ? "37.5" : "38.2"}% of its upper bound, slightly narrower than the provisional RCV of 38.5%. The band classifies one value against outcome-derived quartile boundaries (f03-E41, f03-E42) and does not infer change; change between two results is only called above the RCV (P2 trend rule). The large CVI of urea reflects day-to-day protein intake and hydration, which the message names.` });
const RCV_NULL = { cvi_pct: null, cva_pct: null, rcv_pct: null, placeholder: true,
  source: "Derived index (BUN / creatinine); no biological variation estimate opened; no trend message is produced for it.",
  narrow_band_justification: null };

// ---------- rows ----------
function creatinineRow(sex, nl, nh, ol, oh, es) {
  const nlEs = es(nl), nhEs = es(nh), olEs = es(ol), ohEs = es(oh);
  return {
    marker_key: "creatinine", sex, age_group: "All Adults", physiological_state: "none",
    unit: "mg/dL", marker_class: "a",
    reference_low: nl, reference_high: nh, reference_basis: "echevarne_interval",
    reference_source: `Echevarne result code B0003 (test B0030, synonym CR1, Creatinina /suero), catalogue 2026-08-25, interval dated 01/06/2020, ${sex === "male" ? "Hombre" : "Mujeres"} 0-999 y: ${nl}-${nh} mg/dL, serum, Espectrofotometría Ultravioleta-Visible (Jaffe or enzymatic not stated; methods letter L4).`,
    optimal_low: ol, optimal_high: oh, band_rule: "lowest_risk_category",
    critical_low: null, critical_high: 4,
    critical_none_reason: null,
    action_limits: [],
    pre_analytical: PRE_CREAT,
    method_note: "Creatinine is produced by muscle and cleared by the kidney, so one value mixes two signals: low values track low muscle mass (adverse in population cohorts), high values track low filtration unless the person is muscular, has eaten cooked meat, exercised hard, takes creatine or trimethoprim. Kidney filtration is read from the app's eGFR (CKD-EPI 2021) and, where available, cystatin C; a cystatin C-based eGFR at least 30% below the creatinine-based one carries higher mortality in 821,327 outpatients (f03-E12). Echevarne's method is not stated (UV-Vis spectrophotometry only); IDMS traceability is asked in the methods letter. Reference interval has no age bands at Echevarne; in NHANES 18% of healthy women aged 70-79 sit above 1.02 mg/dL (input bundle), which is a physician question, not a row change. Version 3 refuses a biological age above the reference interval (check B2) and clamps below the optimal floor (flat segment, check X2).",
    rcv: RCV_CREAT,
    messages: {
      en: {
        below_range: `Your creatinine is below the laboratory's reference interval (${nl} to ${nh} mg/dL). Creatinine comes from muscle, so a low value most often means a small muscle mass, a low-protein or vegetarian diet or pregnancy; it also falls with a large fluid intake and, less often, with liver disease. After 70 a low value usually reflects loss of muscle rather than good kidney function. Repeat the test in 2 to 4 weeks if you have no similar earlier result. ${ROUTINE_EN} ${CLOSER_EN}`,
        below_optimal: `Your creatinine is within the reference interval but below EVA's optimal band of ${ol} to ${oh} mg/dL. Creatinine reflects muscle mass as well as kidney filtration, so a value in this zone usually means less muscle rather than a kidney problem; in population studies a lower creatinine for the same cystatin C is linked to lower muscle mass and frailty, and after 70 it usually reflects loss of muscle. It can also follow a low-protein diet or a large fluid intake. Kidney filtration is read from your eGFR and, where available, cystatin C. ${ROUTINE_EN}`,
        optimal: `Your creatinine is in EVA's optimal band of ${ol} to ${oh} mg/dL. Creatinine reflects muscle mass as well as kidney filtration, so kidney filtration itself is read from your eGFR, which adjusts creatinine for age and sex, and from cystatin C where available.`,
        above_optimal: `Your creatinine is within the reference interval but above EVA's optimal band of ${ol} to ${oh} mg/dL. Creatinine rises with muscle mass, after a meal of cooked meat, after hard exercise in the previous 48 hours, with creatine supplements and with some medicines such as trimethoprim, so a muscular person can have a value like this without any kidney problem. Kidney filtration is read from your eGFR and, where available, cystatin C and a urine albumin test. ${ROUTINE_EN}`,
        above_range: `Your creatinine is above the laboratory's reference interval (${nl} to ${nh} mg/dL). It can mean reduced kidney filtration, but it also rises with dehydration, a meal of cooked meat in the hours before the draw, hard exercise in the previous 48 hours, creatine supplements, a large muscle mass and some medicines such as trimethoprim. Repeat the test in 2 to 4 weeks, fasting, without creatine and without hard exercise in the previous 48 hours, with cystatin C and a urine albumin test if your doctor agrees. ${SOON_EN} ${CLOSER_EN}`,
        critical_high: `Your creatinine is far above the reference interval, at a level that can mean a serious loss of kidney filtration. ${CRIT_EN}`
      },
      es: {
        below_range: `Tu creatinina está por debajo del intervalo de referencia del laboratorio (${nlEs} a ${nhEs} mg/dL). La creatinina procede del músculo, así que un valor bajo suele indicar poca masa muscular, una dieta baja en proteínas o vegetariana, o un embarazo; también baja con una ingesta alta de líquidos y, con menos frecuencia, por una enfermedad del hígado. A partir de los 70 años un valor bajo suele reflejar pérdida de músculo y no una buena función renal. Repite el análisis en 2 a 4 semanas si no tienes un resultado previo parecido. ${ROUTINE_ES} ${CLOSER_ES}`,
        below_optimal: `Tu creatinina está dentro del intervalo de referencia, pero por debajo de la banda óptima de EVA, de ${olEs} a ${ohEs} mg/dL. La creatinina refleja la masa muscular además de la filtración renal, así que un valor en esta zona suele indicar menos músculo y no un problema renal; en estudios de población, una creatinina más baja para una misma cistatina C se asocia a menos masa muscular y a fragilidad, y a partir de los 70 años suele reflejar pérdida de músculo. También puede deberse a una dieta baja en proteínas o a una ingesta alta de líquidos. La filtración renal se lee en tu TFGe y, cuando la tienes, en la cistatina C. ${ROUTINE_ES}`,
        optimal: `Tu creatinina está en la banda óptima de EVA, de ${olEs} a ${ohEs} mg/dL. La creatinina refleja la masa muscular además de la filtración renal, así que la filtración en sí se lee en tu TFGe, que ajusta la creatinina por edad y sexo, y en la cistatina C cuando la tienes.`,
        above_optimal: `Tu creatinina está dentro del intervalo de referencia, pero por encima de la banda óptima de EVA, de ${olEs} a ${ohEs} mg/dL. La creatinina sube con la masa muscular, tras una comida con carne cocinada, tras ejercicio intenso en las 48 horas previas, con suplementos de creatina y con algunos medicamentos como el trimetoprim, así que una persona musculada puede tener un valor así sin ningún problema renal. La filtración renal se lee en tu TFGe y, cuando las tienes, en la cistatina C y en una prueba de albúmina en orina. ${ROUTINE_ES}`,
        above_range: `Tu creatinina está por encima del intervalo de referencia del laboratorio (${nlEs} a ${nhEs} mg/dL). Puede indicar una filtración renal reducida, pero también sube con la deshidratación, una comida con carne cocinada en las horas previas a la extracción, ejercicio intenso en las 48 horas previas, suplementos de creatina, mucha masa muscular y algunos medicamentos como el trimetoprim. Repite el análisis en 2 a 4 semanas, en ayunas, sin creatina y sin ejercicio intenso en las 48 horas previas, con cistatina C y una prueba de albúmina en orina si tu médico está de acuerdo. ${SOON_ES} ${CLOSER_ES}`,
        critical_high: `Tu creatinina está muy por encima del intervalo de referencia, en un nivel que puede indicar una pérdida importante de la filtración renal. ${CRIT_ES}`
      }
    },
    explanatory_numbers: [2, 4, 48, 70],
    decimals: 2,
    change_vs_production: `Bounds unchanged from the production snapshot (${nl}-${nh}; optimal ${ol}-${oh}). New: critical_high 4.0 mg/dL as its own zone (critical-limits draft, f03-E22, f03-E23, f03-E24); messages rewritten to the wording rules (production text said 'prompt medical attention' for any value above the interval and 'higher mortality'); pre-analytical rules, RCV inputs and the creatine and trimethoprim causes added; every message still defers kidney filtration to eGFR (K2) but names the app's own CKD-EPI 2021 eGFR, never a laboratory eGFR (DR-2026-10-30-01).`,
    notes: `Class a kept (draft class a; priority member of the kidney_filtration redundancy group). Optimal band proposed grade C: the only numeric nadirs are the in-hospital mortality categories of f03-E15 (men 0.9-1.0, women 0.7-0.8 mg/dL) and the general-population quartiles of f03-E14 (lowest all-cause mortality at 0.8 to <1.0 mg/dL, sexes pooled, n = 9,894); low creatinine is adverse in direction in f03-E16, f03-E17 and f03-E14 and creatinine alone is not an independent predictor after adjustment in f03-E18. Under PLAN.md section 5 a grade C band appears only in the grade C decision table: see physician question f03-Q01. Sex split: Echevarne prints sex-specific intervals and healthy means differ (0.90 vs 0.70 mg/dL, f03-E19). Ages 70-84 and 85+: no separate row, because neither Echevarne nor the outcome sources partition by age; the below-range and below-optimal messages say that after 70 a low value usually reflects loss of muscle (class note), and f03-E21 shows community-dwelling adults over 70 run 0.9-1.3 (men) and 0.7-1.1 (women), so older women will often read above optimal; that is a prompt to check eGFR and cystatin C, not a diagnosis. Pregnancy and lactation: laboratory interval only with the fixed note (state rules section 2; creatinine falls in pregnancy, f03-E35). Menopause, hormone therapy, oral contraception: no row change; no source opened reports an effect on creatinine (cystatin C unaffected by hormonal status, f03-E34).`
  };
}

function egfrRow(age_group, ol, flavour) {
  const isOld = flavour === "85plus";
  const optimalBand = ol != null ? `${ol} mL/min/1.73 m² or more` : null;
  const optimalBandEs = ol != null ? `${ol} mL/min/1,73 m² o más` : null;
  const ageNote = {
    young: { en: "Kidney filtration is usually higher at your age, so a cystatin C test and a urine albumin test give a clearer picture.", es: "A tu edad la filtración renal suele ser más alta, así que una cistatina C y una prueba de albúmina en orina dan una imagen más clara." },
    mid: { en: "eGFR falls slowly with age; values a little below this band are common after 60 and usual after 75, and in large population studies they carry only a small extra long-term risk at older ages. Cystatin C and a urine albumin test give a clearer picture.", es: "La TFGe baja despacio con la edad; los valores algo por debajo de esta banda son frecuentes a partir de los 60 años y habituales a partir de los 75, y en grandes estudios de población suponen solo un pequeño exceso a largo plazo en edades avanzadas. La cistatina C y una prueba de albúmina en orina dan una imagen más clara." }
  }[flavour] || null;
  const msgs = isOld ? {
    en: {
      below_range: `Your estimated kidney filtration (eGFR, CKD-EPI 2021 equation) is below 60 mL/min/1.73 m², the limit the KDIGO guidelines use to speak of chronic kidney disease only when it persists for more than three months. One value does not confirm it: creatinine-based eGFR falls after a meal of cooked meat, hard exercise in the previous 48 hours, dehydration, creatine supplements and some medicines such as trimethoprim, and values near this limit are common after 85. Repeat the test in about three months, fasting, together with cystatin C and a urine albumin test. ${SOON_EN} ${CLOSER_EN}`,
      in_range: `Your estimated kidney filtration (eGFR, CKD-EPI 2021 equation) is at or above 60 mL/min/1.73 m², the limit used by the KDIGO guidelines. After 85 EVA sets no optimal band for eGFR, because the creatinine-based estimate depends strongly on muscle mass at this age and a higher value does not reliably mean better kidney function. Cystatin C and a urine albumin test give a clearer picture. This marker does not count toward the score.`
    },
    es: {
      below_range: `Tu filtración renal estimada (TFGe, ecuación CKD-EPI 2021) está por debajo de 60 mL/min/1,73 m², el límite que las guías KDIGO usan para hablar de enfermedad renal crónica solo cuando se mantiene más de tres meses. Un solo valor no lo confirma: la TFGe basada en creatinina baja tras una comida con carne cocinada, ejercicio intenso en las 48 horas previas, deshidratación, suplementos de creatina y algunos medicamentos como el trimetoprim, y los valores cerca de este límite son frecuentes a partir de los 85 años. Repite el análisis en unos tres meses, en ayunas, junto con cistatina C y una prueba de albúmina en orina. ${SOON_ES} ${CLOSER_ES}`,
      in_range: `Tu filtración renal estimada (TFGe, ecuación CKD-EPI 2021) está en 60 mL/min/1,73 m² o más, el límite que usan las guías KDIGO. A partir de los 85 años EVA no fija una banda óptima para la TFGe, porque a esta edad la estimación basada en creatinina depende mucho de la masa muscular y un valor más alto no significa de forma fiable una mejor función renal. La cistatina C y una prueba de albúmina en orina dan una imagen más clara. Este marcador no entra en la puntuación.`
    }
  } : {
    en: {
      below_range: `Your estimated kidney filtration (eGFR, CKD-EPI 2021 equation) is below 60 mL/min/1.73 m², the limit the KDIGO guidelines use to speak of chronic kidney disease only when it persists for more than three months. One value does not confirm it: creatinine-based eGFR falls after a meal of cooked meat, hard exercise in the previous 48 hours, dehydration, creatine supplements, some medicines such as trimethoprim, and with a large muscle mass. Repeat the test in about three months, fasting, together with cystatin C and a urine albumin test. ${SOON_EN} ${CLOSER_EN}`,
      below_optimal: `Your eGFR (CKD-EPI 2021 equation) is within the reference interval but below EVA's optimal band for your age (${optimalBand}). Creatinine-based eGFR also depends on muscle mass, so a muscular build, a meal of cooked meat or hard exercise before the draw can lower the estimate without any kidney problem. ${ageNote.en} ${ROUTINE_EN}`,
      optimal: `Your eGFR (CKD-EPI 2021 equation) is in EVA's optimal band for your age (${optimalBand}), which reflects preserved kidney filtration. A very high value together with a low creatinine can reflect low muscle mass rather than better kidneys; your creatinine message covers that. This marker does not count toward the score.`
    },
    es: {
      below_range: `Tu filtración renal estimada (TFGe, ecuación CKD-EPI 2021) está por debajo de 60 mL/min/1,73 m², el límite que las guías KDIGO usan para hablar de enfermedad renal crónica solo cuando se mantiene más de tres meses. Un solo valor no lo confirma: la TFGe basada en creatinina baja tras una comida con carne cocinada, ejercicio intenso en las 48 horas previas, deshidratación, suplementos de creatina, algunos medicamentos como el trimetoprim, y con mucha masa muscular. Repite el análisis en unos tres meses, en ayunas, junto con cistatina C y una prueba de albúmina en orina. ${SOON_ES} ${CLOSER_ES}`,
      below_optimal: `Tu TFGe (ecuación CKD-EPI 2021) está dentro del intervalo de referencia, pero por debajo de la banda óptima de EVA para tu edad (${optimalBandEs}). La TFGe basada en creatinina también depende de la masa muscular, así que una constitución musculosa, una comida con carne cocinada o ejercicio intenso antes de la extracción pueden rebajar la estimación sin que haya ningún problema renal. ${ageNote.es} ${ROUTINE_ES}`,
      optimal: `Tu TFGe (ecuación CKD-EPI 2021) está en la banda óptima de EVA para tu edad (${optimalBandEs}), lo que refleja una filtración renal conservada. Un valor muy alto junto con una creatinina baja puede reflejar poca masa muscular y no unos riñones mejores; el mensaje de tu creatinina lo explica. Este marcador no entra en la puntuación.`
    }
  };
  return {
    marker_key: "egfr_creatinine_based", sex: "both", age_group, physiological_state: "none",
    unit: "mL/min/1.73m²", marker_class: "a",
    reference_low: 60, reference_high: null, reference_basis: "decision_limit",
    reference_source: "KDIGO CKD definition, eGFR under 60 mL/min/1.73 m2 for over three months, copied from f03-E01 (Jonsson 2020, applying the KDIGO guideline verbatim) and f03-E02 (CKD-PC 2010: eGFR less than 60 is an independent predictor of mortality). Echevarne prints no eGFR interval and the app computes eGFR itself (CKD-EPI 2021). The KDIGO 2024 guideline text (PMID 38490803) has no openable abstract text; see physician question f03-Q14.",
    optimal_low: ol, optimal_high: null, band_rule: ol != null ? "within_10pct_of_min_hr" : "none",
    critical_low: null, critical_high: null,
    critical_none_reason: "none, because the critical limit sits on creatinine (4.0 mg/dL), from which the app computes eGFR; no opened critical-value list carries an eGFR limit (critical-limits draft, f03-E22, f03-E23, f03-E24).",
    action_limits: [
      { name: "AL-17 KDIGO CKD G3-G5: eGFR below 60 mL/min/1.73 m2 persisting more than three months", direction: "below", value: 60,
        condition: "on two occasions at least three months apart, or with urine albumin-to-creatinine ratio 30 mg/g or more (AL-03)",
        follow_up_en: "A value below 60 that persists for more than three months is what the KDIGO guidelines call chronic kidney disease. One value does not confirm it. Repeat the test in about three months with cystatin C and a urine albumin test, and take both results to your doctor, who can apply a kidney-failure risk equation and decide whether a kidney specialist should see you.",
        follow_up_es: "Un valor por debajo de 60 que se mantiene más de tres meses es lo que las guías KDIGO llaman enfermedad renal crónica. Un solo valor no lo confirma. Repite el análisis en unos tres meses con cistatina C y una prueba de albúmina en orina, y lleva los dos resultados a tu médico, que puede aplicar una ecuación de fallo renal y decidir si debe verte un especialista del riñón.",
        evidence_ids: ["f03-E01", "f03-E09", "f03-E02"] }
    ],
    pre_analytical: PRE_EGFR,
    method_note: "Derived marker: the app computes eGFR from Echevarne's creatinine with the race-free CKD-EPI 2021 creatinine equation (K1; f03-E08); a laboratory's own eGFR never enters the category, the score or version 3 (DR-2026-10-30-01, hazard H03). Not scored separately: duplicate of creatinine in the kidney_filtration redundancy group (draft class a, may_be_scored false). The reference floor is the KDIGO disease threshold for all adults (18-19 included); the September rows used 75 for ages 18-39, which is a proposed age-adapted threshold (Delanaye), not a guideline, and is dropped (physician question f03-Q03). Optimal floors follow age-specific outcome data (f03-E03, f03-E03b: within 10% of the lowest-risk referent) and the pooled CKD-PC band 75-105 (f03-E02); no optimal ceiling because hyperfiltration is a percentile concept whose absolute value ranges 94.7 to 146.7 across studies (f03-E10) and a high creatinine-eGFR mostly signals low muscle mass, which the creatinine row flags. EFLM prefers EKFC in Europe (state rules 6.4): open physician question f03-Q02.",
    rcv: RCV_EGFR,
    messages: msgs,
    explanatory_numbers: isOld ? [48, 85, 1.73, 2021] : (flavour === "mid" ? [48, 60, 75, 1.73, 2021] : [48, 1.73, 2021]),
    decimals: 0,
    change_vs_production: isOld
      ? "New row (production had 60+ with normal_low 60, optimal 65-105). Ages 85 and over: reference floor 60 (KDIGO) kept, optimal band removed because creatinine-based eGFR is U-shaped with mortality in the oldest old and dominated by muscle mass (f03-E07), and no cohort reports a nadir above 85; messages rewritten to the wording rules."
      : (age_group === "18-39"
        ? "Reference floor 75 (age-adapted proposal) replaced by the KDIGO decision limit 60 copied exactly (f03-E01, f03-E02); optimal floor 90 kept, now with the age-specific outcome record (f03-E03b: eGFR 90-100 HR 1.05 vs 100-110 at ages 18-39); no optimal ceiling (unchanged); messages rewritten (production above-range text said 'prompt medical attention'); action limit AL-17 attached."
        : "Production rows 40-59 (normal_low 60, optimal 75) and 60+ (normal_low 60, optimal 65-105) merged into 40-84 with optimal floor 75 (f03-E02 pooled general-population band 75-105; f03-E03 age-specific referents) and no ceiling (105 dropped: no outcome nadir supports an absolute ceiling, f03-E10, and low muscle mass is flagged by the creatinine row); messages rewritten; action limit AL-17 attached."),
    notes: isOld
      ? "Explicit 85+ policy (check C3): reference only against the KDIGO floor; no optimal band; the in-range message says why. Evidence above 70: f03-E04 (relative risk of low eGFR persists at 75 and over, absolute risk highest), f03-E07 (U-shape at 90 and over), f03-E05 (5th to 95th percentiles 46-84 at age 80)."
      : (age_group === "18-39"
        ? "Within-10% rule on f03-E03b (Hussain 2023, table 3, ages 18-39: all-cause mortality HR 1.05 for eGFR 90-100 and 1.15 for 80-90 versus the 100-110 referent): optimal floor 90. Population share: the 5th percentile of healthy 20-year-olds is 78-81 (EKFC, f03-E05), so a minority of healthy young adults will read below optimal; a muscular build lowers the estimate (message). Ages 18-19: adult KDIGO categories and the adult equation apply from 18."
        : "Within-10% rule: f03-E02 (mortality unrelated to eGFR between 75 and 105 in general-population cohorts, all ages pooled) and f03-E03 (ages 40-49: HR 1.02 for 80-90 versus 90-100; 70-80 HR 1.13; ages 50-65: HR 1.08 for 70-80 versus 80-90). 75 is the pooled lowest-risk floor; the age-specific data would put 40-49 at 80 and 50-65 at 70 to 80, differences within creatinine-eGFR imprecision (physician question f03-Q04). Ages 70-84 pass: no cohort reports a nadir for 70-84; f03-E06 places the minimum-mortality eGFR in people 65 and over at 86-90 mL/min/1.73 m2, so the evidence does not support lowering the floor, while f03-E05 shows the healthy median at age 80 is 63-66, so most healthy adults over 75 will read 'below optimal, in range' and the message says it is usual at that age; check N1 will raise it as a physician question (f03-Q04)."),
  };
}

const rows = [
  creatinineRow("male", 0.7, 1.3, 0.8, 1.1, (x) => String(x).replace(".", ",")),
  creatinineRow("female", 0.55, 1.02, 0.6, 0.9, (x) => String(x).replace(".", ",")),
  egfrRow("18-39", 90, "young"),
  egfrRow("40-84", 75, "mid"),
  egfrRow("85+", null, "85plus"),
  {
    marker_key: "cystatin_c", sex: "both", age_group: "All Adults", physiological_state: "none",
    unit: "mg/L", marker_class: "a",
    reference_low: 0.62, reference_high: 1.11, reference_basis: "echevarne_interval",
    reference_source: "Echevarne result code I0650 (test I5047, synonym CISTC, CISTATINA C SUERO), catalogue 2026-08-25, interval dated 27/02/2013, General 0-999 y: 0.62-1.11 mg/L, nephelometry, Técnicas Especiales. Candidate code: not mapped in src/lib/lab-provider/echevarne.ts today; production row carries the same interval.",
    optimal_low: null, optimal_high: 0.72, band_rule: "within_10pct_of_min_hr",
    critical_low: null, critical_high: null,
    critical_none_reason: "none, because no opened critical-value list (f03-E22, f03-E23, f03-E24) carries a cystatin C limit; a very high value is covered by the creatinine limit on the same sample and by the out-of-range tier with 'soon' urgency.",
    action_limits: [],
    pre_analytical: PRE_CYS,
    method_note: "Cystatin C is produced by all nucleated cells at a near-constant rate and is not associated with muscle mass (f03-E17); KDIGO uses it with creatinine (eGFRcr-cys) when creatinine is unreliable, and a cystatin C-based eGFR at least 30% below the creatinine-based one carries higher mortality (f03-E12). It is a marker, not a target: Mendelian randomisation finds no causal effect of the protein on cardiovascular disease (f03-E37). Non-filtration determinants: age, male sex, weight, height, smoking, CRP (f03-E36), thyroid state and glucocorticoids (f03-E33, f03-E34). The outcome cut-offs come from NHANES 1999-2004 (Siemens Dade Behring assay, before ERM-DA471/IFCC standardisation), so 0.72 is approximate; standardised healthy medians are 0.78-0.79 mg/L (f03-E20). Echevarne's traceability is unknown (methods letter). Never enters version 3 or the biological age (DR-2026-10-30-01); not scored (duplicate of creatinine in the kidney_filtration group).",
    rcv: RCV_CYS,
    messages: {
      en: {
        below_range: `Your cystatin C is below the laboratory's reference interval (0.62 to 1.11 mg/L). A low value usually reflects a high kidney filtration and is not harmful in itself; an underactive thyroid also lowers it. Repeat it with a TSH test at your next blood draw if you have no similar earlier result. ${ROUTINE_EN} ${CLOSER_EN}`,
        optimal: `Your cystatin C is in EVA's optimal band (up to 0.72 mg/L), the band in which large population studies found the most favourable long-term outcomes. Cystatin C does not depend on muscle mass, so it is a good check of kidney filtration when creatinine is doubtful. This marker does not count toward the score.`,
        above_optimal: `Your cystatin C is within the laboratory's reference interval (0.62 to 1.11 mg/L) but above EVA's optimal band (up to 0.72 mg/L). In large population studies the most favourable long-term outcomes were seen below 0.72 mg/L; values in this zone become more common with age as kidney filtration slowly falls, and cystatin C also rises with smoking, a larger body size, inflammation, an overactive thyroid and corticosteroid treatment. A combined creatinine and cystatin C eGFR and a urine albumin test give a clearer picture. ${ROUTINE_EN}`,
        above_range: `Your cystatin C is above the laboratory's reference interval (0.62 to 1.11 mg/L). It can mean reduced kidney filtration, but it also rises with an overactive thyroid, corticosteroid treatment, smoking, inflammation and a larger body size, and it rises gradually with age. Repeat the test in 2 to 4 weeks together with creatinine, a combined eGFR and a urine albumin test. ${SOON_EN} ${CLOSER_EN}`
      },
      es: {
        below_range: `Tu cistatina C está por debajo del intervalo de referencia del laboratorio (0,62 a 1,11 mg/L). Un valor bajo suele reflejar una filtración renal alta y no es perjudicial en sí mismo; una tiroides poco activa también la baja. Repítela con una TSH en tu próxima extracción si no tienes un resultado previo parecido. ${ROUTINE_ES} ${CLOSER_ES}`,
        optimal: `Tu cistatina C está en la banda óptima de EVA (hasta 0,72 mg/L), la banda en la que grandes estudios de población encontraron los resultados más favorables a largo plazo. La cistatina C no depende de la masa muscular, así que es una buena comprobación de la filtración renal cuando la creatinina deja dudas. Este marcador no entra en la puntuación.`,
        above_optimal: `Tu cistatina C está dentro del intervalo de referencia del laboratorio (0,62 a 1,11 mg/L), pero por encima de la banda óptima de EVA (hasta 0,72 mg/L). En grandes estudios de población los resultados más favorables a largo plazo se vieron por debajo de 0,72 mg/L; los valores en esta zona son más frecuentes con la edad, porque la filtración renal baja despacio, y la cistatina C también sube con el tabaco, un cuerpo más grande, la inflamación, una tiroides hiperactiva y el tratamiento con corticoides. Una TFGe combinada de creatinina y cistatina C y una prueba de albúmina en orina dan una imagen más clara. ${ROUTINE_ES}`,
        above_range: `Tu cistatina C está por encima del intervalo de referencia del laboratorio (0,62 a 1,11 mg/L). Puede indicar una filtración renal reducida, pero también sube con una tiroides hiperactiva, el tratamiento con corticoides, el tabaco, la inflamación y un cuerpo más grande, y sube poco a poco con la edad. Repite el análisis en 2 a 4 semanas junto con creatinina, una TFGe combinada y una prueba de albúmina en orina. ${SOON_ES} ${CLOSER_ES}`
      }
    },
    explanatory_numbers: [2, 4],
    decimals: 2,
    change_vs_production: "Reference interval 0.62-1.11 unchanged (equals the Echevarne candidate code I0650). Optimal ceiling 0.85 (production, September reviews) lowered to 0.72: the within-10% rule on the NHANES 20-year quintiles (f03-E18, f03-E18b: quintile 2, 0.640-0.717 mg/L, HR 1.05; quintile 3, 0.718-0.799, HR 1.29) and the quartile analysis of the same survey (f03-E40: fourth quartile 0.877 mg/L or more HR 2.71 for all-cause death); 0.85 lies inside the fourth quintile (0.800-0.932, HR 1.46) and was never a nadir. Messages rewritten; the production above-range text said 'prompt medical attention'. Physician question f03-Q06.",
    notes: "Class a kept: outcome evidence is graded and consistent (f03-E18, f03-E38, f03-E39, f03-E40), but the test is not in the Base Panel and is redundant with creatinine for scoring (draft: may_be_scored false). No lower optimal bound: low values carry no excess risk in any opened cohort. No sex split: standardised intervals barely differ (women 0.58-1.00, men 0.62-1.04 mg/L, f03-E20) and Echevarne prints one interval. No age split: the same strata carry higher relative hazards in people over 59 (f03-E18b, Yuan table: >0.932 mg/L HR 3.458 in that age group, as reported in the September review and not re-quoted here), so the nadir does not move with age, but healthy values rise after 60 (f03-E34) and in NHANES the 10th percentile at 60-69 is 0.73-0.79 mg/L (input bundle), so most adults over 60 will read 'above optimal, in range' and the 70-79 cell will trip check N1: physician question f03-Q06. Ages 85+: same row; the message explains the age effect. Pregnancy: cystatin C rises in normal pregnancy (f03-E35): laboratory interval only. Menopause, hormone therapy, oral contraception: no effect found (f03-E34): no row change."
  },
  bunRow("bun", "BUN", "BUN", "mg/dL", 10, 25, 10, 16, 100, "Echevarne result code B0150 (test B1120, synonym BUN, NITROGENO UREICO (BUN) EN SUER), catalogue 2026-08-25, interval dated 21/09/2020, General 0-999 y: 10-25 mg/dL, serum, Espectrofotometría Ultravioleta-Visible.", true),
  bunRow("urea", "Urea", "Urea", "mg/dL", 21, 54, 21, 34, 214, "Echevarne prints no urea interval (urea is reported as BUN, code B0150). The urea row is the Echevarne BUN interval 10-25 mg/dL multiplied by 2.14 (urea 60.06 g/mol over 2 x 14.01 g/mol of nitrogen; the same factor appears in f03-E23: urea 214 mg/dl = BUN 100 mg/dl = 35.6 mmol/l): 21.4-53.6, rounded to 21-54 mg/dL. Physician question f03-Q08.", false),
  ratioRow()
];

function bunRow(key, name_en, name_es, unit, nl, nh, ol, oh, crit, refSource, isBun) {
  const band = `${ol}-${oh} mg/dL`;
  const sixty = isBun ? "60" : "60";
  return {
    marker_key: key, sex: "both", age_group: "All Adults", physiological_state: "none",
    unit, marker_class: "a",
    reference_low: nl, reference_high: nh, reference_basis: "echevarne_interval",
    reference_source: refSource,
    optimal_low: ol, optimal_high: oh, band_rule: "within_10pct_of_min_hr",
    critical_low: null, critical_high: crit,
    critical_none_reason: null,
    action_limits: [],
    pre_analytical: PRE_BUN(name_en, name_es),
    method_note: isBun
      ? "BUN and urea are the same measurement reported two ways (urea = BUN x 2.14); Echevarne reports BUN. BUN reflects protein intake and hydration as well as kidney clearance, and healthy values are higher in men and rise with age (median 4.6 vs 4.1 mmol/L; +0.21 to +0.282 mmol/L per decade, f03-E46; community-dwelling adults over 70 run 14-23 mg/dL, f03-E21), yet no outcome source reports a sex- or age-specific nadir, so one adult band is kept. Version 3 marker: lower clamp 10 mg/dL = optimal floor = Echevarne lower limit; below 10 the biological age does not move (flat segment, check X2). NHANES healthy adults: 16-38% of women aged 20-59 sit below 10 mg/dL (input bundle), outside the 2-15% rule of check N1; that follows from Echevarne's printed lower limit, which the plan makes binding (physician question f03-Q07)."
      : "Same analyte as BUN (urea = BUN x 2.14); never scored twice (urea_bun redundancy group, priority member BUN). Reaches EVA only from uploaded reports of other laboratories, because Echevarne reports BUN; the uploaded laboratory's own interval may differ and is not stored. Outcome evidence is the BUN evidence converted (f03-E41, f03-E42, f03-E43, f03-E44, f03-E45). Critical limit 214 mg/dL is Thomas's urea value, the same sample as BUN 100 (f03-E23).",
    rcv: RCV_BUN(band),
    messages: {
      en: {
        below_range: `Your ${name_en.toLowerCase() === "bun" ? "BUN" : "urea"} is below the laboratory's reference interval (${nl} to ${nh} mg/dL). This is usually dietary, from a low protein intake or a large fluid intake, and it is common in pregnancy; less often it reflects liver disease. In large population studies a low value by itself was not linked to worse long-term outcomes. Repeat the test in 2 to 4 weeks if you have no similar earlier result. ${ROUTINE_EN} ${CLOSER_EN}`,
        optimal: `Your ${isBun ? "BUN" : "urea"} is in EVA's optimal band of ${ol} to ${oh} mg/dL, the band with the most favourable long-term outcomes in population studies. It reflects protein intake and hydration as well as kidney clearance. ${isBun ? "" : "This marker does not count toward the score."}`.trim(),
        above_optimal: `Your ${isBun ? "BUN" : "urea"} is within the laboratory's reference interval (${nl} to ${nh} mg/dL) but above EVA's optimal band of ${ol} to ${oh} mg/dL. It rises with a high protein intake and with dehydration, and it rises gradually with age, so values in this zone are common after ${sixty}. It can also reflect a lower kidney clearance, which your eGFR shows better. Drink normally and eat as usual before your next test. ${ROUTINE_EN}`,
        above_range: `Your ${isBun ? "BUN" : "urea"} is above the laboratory's reference interval (${nl} to ${nh} mg/dL). It can mean a lower kidney clearance, but it also rises with dehydration, a very high protein intake, bleeding in the digestive tract and heart failure. Repeat the test in 2 to 4 weeks, well hydrated, together with creatinine and eGFR. ${SOON_EN} ${CLOSER_EN}`,
        critical_high: `Your ${isBun ? "BUN" : "urea"} is far above the reference interval, at a level that can mean a serious loss of kidney clearance. ${CRIT_EN}`
      },
      es: {
        below_range: `Tu ${isBun ? "BUN" : "urea"} está por debajo del intervalo de referencia del laboratorio (${nl} a ${nh} mg/dL). Suele deberse a la dieta, por una baja ingesta de proteínas o una alta ingesta de líquidos, y es frecuente en el embarazo; con menos frecuencia refleja una enfermedad del hígado. En grandes estudios de población un valor bajo por sí solo no se asoció a peores resultados a largo plazo. Repite el análisis en 2 a 4 semanas si no tienes un resultado previo parecido. ${ROUTINE_ES} ${CLOSER_ES}`,
        optimal: `Tu ${isBun ? "BUN" : "urea"} está en la banda óptima de EVA, de ${ol} a ${oh} mg/dL, la banda con los resultados más favorables a largo plazo en los estudios de población. Refleja la ingesta de proteínas y la hidratación además de la depuración renal. ${isBun ? "" : "Este marcador no entra en la puntuación."}`.trim(),
        above_optimal: `Tu ${isBun ? "BUN" : "urea"} está dentro del intervalo de referencia del laboratorio (${nl} a ${nh} mg/dL), pero por encima de la banda óptima de EVA, de ${ol} a ${oh} mg/dL. Sube con una ingesta alta de proteínas y con la deshidratación, y sube poco a poco con la edad, así que los valores en esta zona son frecuentes a partir de los ${sixty} años. También puede reflejar una depuración renal algo menor, que tu TFGe muestra mejor. Bebe con normalidad y come como siempre antes de tu próximo análisis. ${ROUTINE_ES}`,
        above_range: `Tu ${isBun ? "BUN" : "urea"} está por encima del intervalo de referencia del laboratorio (${nl} a ${nh} mg/dL). Puede indicar una depuración renal menor, pero también sube con la deshidratación, una ingesta muy alta de proteínas, un sangrado digestivo y la insuficiencia cardíaca. Repite el análisis en 2 a 4 semanas, bien hidratado, junto con creatinina y TFGe. ${SOON_ES} ${CLOSER_ES}`,
        critical_high: `Tu ${isBun ? "BUN" : "urea"} está muy por encima del intervalo de referencia, en un nivel que puede indicar una pérdida importante de la depuración renal. ${CRIT_ES}`
      }
    },
    explanatory_numbers: [2, 4, 60],
    decimals: 0,
    change_vs_production: isBun
      ? "Reference 10-25 unchanged (Echevarne). Optimal ceiling 18 (production) lowered to 16: within-10% rule on the general-population NHANES quartiles (f03-E41: all-cause mortality HR 1.06, 1.05 and 1.48 for 3.57-4.59, 4.60-5.70 and 5.71 mmol/L or more versus below 3.57; 5.71 mmol/L = 16.0 mg/dL), supported by the hyperlipidaemia quintiles (f03-E42: lowest risk 3.60-6.09 mmol/L = 10.1-17.1 mg/dL), the diabetes inflection at 5 mmol/L = 14 mg/dL (f03-E43) and Mendelian randomisation for coronary disease (f03-E45). Optimal floor 10 unchanged (= Echevarne lower limit = version 3 clamp; f03-E42 quintile 1 below 3.60 mmol/L HR 1.26). New: critical_high 100 mg/dL (f03-E23, f03-E24); messages rewritten (production said 'prompt medical attention' and 'Consider high protein intake'); the K1 note about the BUN-urea contradiction removed because the urea row now derives from the Echevarne BUN interval."
      : "Reference 15-54 and optimal 21-39 (production) replaced by 21-54 and 21-34: the Echevarne BUN row converted exactly (x2.14), so BUN and urea never contradict each other at either end (K1 coherence); the former lower limit 15 came from a Spanish population study the September review could not quote from an openable source. New: critical_high 214 mg/dL (f03-E23). Messages rewritten.",
    notes: isBun
      ? "Class a kept (version 3 and Base Panel marker; priority member of urea_bun). Proposed grade B for the ceiling: general-population NHANES cohort, n = 17,719, 11.65 years (f03-E41), replicated in direction by f03-E42 (n = 28,122) and f03-E44 (1,337,452 veterans, incident diabetes above 25 mg/dL) and with Mendelian randomisation for coronary disease (f03-E45, East Asians, direction only). The low side rests on Echevarne's printed limit; f03-E41 found no excess risk below 3.57 mmol/L in the general population while f03-E42 did in hyperlipidaemia (HR 1.26), so the below-range message calls a low value usually dietary. Ages 70-84 and 85+: no split; healthy adults over 70 run 14-23 mg/dL (f03-E21) and in NHANES 70-79 the median is 16-17 mg/dL (input bundle), so about half of healthy older adults will read 'above optimal, in range' and the message says it is common after 60; check N1 at 70-79 is a physician question (f03-Q07). Pregnancy: urea falls (f03-E35): laboratory interval only. Hormonal state: no source opened reports an effect; no row change."
      : "Mirror of the BUN row (same analyte, same evidence, x2.14). Shown for uploaded results only; not scored. Grade and questions follow the BUN row."
  };
}

function ratioRow() {
  return {
    marker_key: "bun_creatinine_ratio", sex: "both", age_group: "All Adults", physiological_state: "none",
    unit: "ratio", marker_class: "e",
    reference_low: 10, reference_high: 20, reference_basis: "population_study",
    reference_source: "No laboratory interval (derived index, not an Echevarne code). Upper limit 20: the conventional threshold that separates pre-renal from intrinsic kidney causes and defines dehydration in the opened sources (f03-E49, f03-E50, f03-E51). Lower limit 10: convention only; the opened sources give a lowest-mortality quartile of 11.43-14.64 (f03-E48) and one 1998 review calls 8:1 to 10:1 normal (f03-E52), so 10 is weakly sourced (physician question f03-Q09).",
    optimal_low: null, optimal_high: null, band_rule: "none",
    critical_low: null, critical_high: null,
    critical_none_reason: "none, because the ratio is a derived index; the critical limits sit on creatinine (4.0 mg/dL) and BUN (100 mg/dL) themselves and no opened list carries a ratio limit.",
    action_limits: [],
    pre_analytical: [
      { rule: "other", effect: "note", non_fasting_high: null,
        text_en: "Derived from the BUN and creatinine on the same sample; every pre-analytical rule of those two markers applies (cooked meat and exercise lower it by raising creatinine; dehydration and protein raise it).",
        text_es: "Se deriva del BUN y la creatinina de la misma muestra; se aplican todas las reglas preanalíticas de esos dos marcadores (la carne cocinada y el ejercicio lo bajan al subir la creatinina; la deshidratación y las proteínas lo suben).",
        evidence_ids: ["f03-E26", "f03-E28"] },
      { rule: "capillary", effect: "values_only", non_fasting_high: null,
        text_en: "Capillary kit results are values only until the paired study passes (PLAN.md section 10, decision 2).",
        text_es: "Los resultados de kit capilar se muestran solo como valor hasta que la comparación capilar-venosa supere su prueba (PLAN.md sección 10, decisión 2).",
        evidence_ids: [] }
    ],
    method_note: "Class e (reference only), as drafted: a derived index with no outcome-based optimal band and no laboratory interval. The only general-population outcome study (NHANES, n = 42,038, f03-E48) is U-shaped for all-cause mortality with the lowest mortality at 11.43-14.64, and older people and women run higher. Computed as BUN (mg/dL) / creatinine (mg/dL); with urea, divide urea by 2.14 first. Not scored; never enters version 3.",
    rcv: RCV_NULL,
    messages: {
      en: {
        below_range: `Your BUN-to-creatinine ratio is below the reference interval of 10 to 20. A low ratio usually reflects a low protein intake or a large fluid intake relative to your muscle mass; it is more common in young muscular people and in pregnancy. It is a derived index that EVA shows for information only; your BUN and creatinine messages carry the detail. Repeat both tests in 2 to 4 weeks if you have no similar earlier result. ${ROUTINE_EN} ${CLOSER_EN}`,
        in_range: `Your BUN-to-creatinine ratio is within the reference interval of 10 to 20. EVA shows this derived index for information only; your BUN and creatinine messages carry the detail. This marker does not count toward the score.`,
        above_range: `Your BUN-to-creatinine ratio is above the reference interval of 10 to 20. A high ratio is most often seen with dehydration or a high protein intake, and sometimes with bleeding in the digestive tract, heart failure or a reduced blood flow to the kidneys; it also rises with age and is higher in women. Repeat both tests in 2 to 4 weeks, well hydrated. ${ROUTINE_EN} ${CLOSER_EN}`
      },
      es: {
        below_range: `Tu cociente BUN/creatinina está por debajo del intervalo de referencia de 10 a 20. Un cociente bajo suele reflejar una ingesta baja de proteínas o una ingesta alta de líquidos en relación con tu masa muscular; es más frecuente en personas jóvenes musculadas y en el embarazo. Es un índice derivado que EVA muestra solo a título informativo; los mensajes de tu BUN y tu creatinina llevan el detalle. Repite las dos pruebas en 2 a 4 semanas si no tienes un resultado previo parecido. ${ROUTINE_ES} ${CLOSER_ES}`,
        in_range: `Tu cociente BUN/creatinina está dentro del intervalo de referencia de 10 a 20. EVA muestra este índice derivado solo a título informativo; los mensajes de tu BUN y tu creatinina llevan el detalle. Este marcador no entra en la puntuación.`,
        above_range: `Tu cociente BUN/creatinina está por encima del intervalo de referencia de 10 a 20. Un cociente alto se ve sobre todo con la deshidratación o una ingesta alta de proteínas, y a veces con un sangrado digestivo, la insuficiencia cardíaca o un menor flujo de sangre a los riñones; también sube con la edad y es más alto en mujeres. Repite las dos pruebas en 2 a 4 semanas, bien hidratado. ${ROUTINE_ES} ${CLOSER_ES}`
      }
    },
    explanatory_numbers: [2, 4],
    decimals: 1,
    change_vs_production: "Reference 10-20 unchanged. Optimal band 11-18 (production) removed: class e per the marker-classes draft (derived index, no outcome-based optimum; the single NHANES study gives a lowest-mortality quartile, not a target). Messages rewritten (production said 'prompt medical attention').",
    notes: "Physician question f03-Q09: keep the ratio as a reference-only index or retire it from the client view; the lower limit 10 is convention and the opened sources are thin (f03-E52 even calls 8:1 to 10:1 normal). Older adults and women run higher (f03-E48), so above-range readings will be more frequent in women over 70; the message says so. Not in the Base Panel."
  };
}

// ---------- evidence ----------
const E = [];
function ev(o) { E.push(o); }
const CR_M = "creatinine|male|All Adults|none", CR_F = "creatinine|female|All Adults|none";
const EG1 = "egfr_creatinine_based|both|18-39|none", EG2 = "egfr_creatinine_based|both|40-84|none", EG3 = "egfr_creatinine_based|both|85+|none";
const CYS = "cystatin_c|both|All Adults|none", BUN = "bun|both|All Adults|none", URE = "urea|both|All Adults|none", RAT = "bun_creatinine_ratio|both|All Adults|none";
const sup = (rows, bounds) => rows.flatMap((r) => bounds.map((b) => ({ row_key: r, bound: b })));

ev({ id: "f03-E01", supports: sup([EG1, EG2, EG3], ["reference_low", "action_limit"]),
  identifier: { type: "pmid", value: "32622831" }, citation: "Jonsson AJ, Lund SH, Eriksen BO, Palsson R, Indridason OS. The prevalence of chronic kidney disease in Iceland according to KDIGO criteria and age-adapted estimated glomerular filtration rate thresholds. Kidney Int 2020;98(5):1286-1295.", year: 2020,
  quote: "CKD was defined according to the Kidney Disease: Improving Global Outcomes (KDIGO) clinical practice guideline using diagnoses indicative of a chronic kidney disease, proteinuria and/or an eGFR under 60 mL/min/1.73 m2 for over three months.",
  location: "abstract, methods sentence", design: "nationwide registry study applying the KDIGO CKD definition (guideline decision limit quoted through this abstract because the KDIGO 2024 guideline, PMID 38490803, has no openable abstract text)", n: 218437, follow_up_years: null, outcome: "CKD prevalence (definition only; no outcome)", population_age: "18 and over, median 63", population_sex: "both", assay: "serum creatinine, CKD-EPI eGFR; equation not stated in the abstract", band_rule: "none", basis_class: "guideline_decision_limit", proposed_grade: "A",
  age_stratified_statement: "The KDIGO threshold is age-independent; the study also reports age-adapted cut-offs (prevalence 3.27% vs 5.13% in men), which are a proposal, not the guideline.", notes: "Supports the reference floor 60 on every eGFR row and the AL-17 trigger. The physician confirms the wording against the KDIGO 2024 guideline PDF (f03-Q14)." });

ev({ id: "f03-E02", supports: sup([EG2], ["optimal_low", "age_split"]).concat(sup([EG1, EG2, EG3], ["reference_low"])),
  identifier: { type: "pmid", value: "20483451" }, citation: "Chronic Kidney Disease Prognosis Consortium; Matsushita K, et al. Association of estimated glomerular filtration rate and albuminuria with all-cause and cardiovascular mortality in general population cohorts: a collaborative meta-analysis. Lancet 2010;375(9731):2073-81.", year: 2010,
  quote: "risk of mortality was unrelated to eGFR between 75 mL/min/1.73 m(2) and 105 mL/min/1.73 m(2) and increased at lower eGFRs. Compared with eGFR 95 mL/min/1.73 m(2), adjusted HRs for all-cause mortality were 1.18 (95% CI 1.05-1.32) for eGFR 60 mL/min/1.73 m(2), 1.57 (1.39-1.78) for 45 mL/min/1.73 m(2)",
  location: "abstract, findings", design: "collaborative individual-level meta-analysis of 21 general-population cohorts (pooled consortium)", n: 1234182, follow_up_years: 7.5, outcome: "all-cause and cardiovascular mortality", population_age: "adults, all ages pooled", population_sex: "both", assay: "creatinine-based eGFR (MDRD, standardised creatinine)", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "The abstract reports no age-stratified estimate; the companion CKD-PC analysis (f03-E04) shows the association holds in every age category with lower relative but higher absolute risk at older ages.", notes: "Lowest-risk band 75-105 supports the optimal floor 75 for ages 40-84. n = 105,872 (ACR studies) + 1,128,310 (dipstick studies); follow-up approximated from 730,577 + 4,732,110 person-years." });

ev({ id: "f03-E03", supports: sup([EG1, EG2], ["optimal_low", "age_split"]),
  identifier: { type: "pmid", value: "37353230" }, citation: "Hussain J, Grubic N, Akbari A, et al. Associations between modest reductions in kidney function and adverse outcomes in young adults: retrospective, population based cohort study. BMJ 2023;381:e075062.", year: 2023,
  quote: "For modest reductions (eGFR 70-80 mL/min/1.73m2), the hazard ratio for ages 18-39 years was 1.42 (95% confidence interval 1.35 to 1.49), 4.39 per 1000 person years; for ages 40-49 years was 1.13 (1.10 to 1.16), 9.61 per 1000 person years; and for ages 50-65 years was 1.08 (1.07 to 1.09)",
  location: "abstract, results", design: "retrospective population-based cohort (Ontario administrative data), age-specific referents 100-110 (18-39), 90-100 (40-49), 80-90 (50-65)", n: 8703871, follow_up_years: 9.2, outcome: "composite of all-cause mortality, cardiovascular events and kidney failure", population_age: "18-65 (mean 41.3)", population_sex: "both", assay: "outpatient creatinine-based eGFR (equation not stated in the abstract)", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "Reports age-stratified estimates: the lowest-risk referent shifts from 100-110 at 18-39 to 90-100 at 40-49 and 80-90 at 50-65; relative hazards for the same eGFR are highest in the young.", notes: "Justifies the split at 40: 70-80 carries HR 1.42 at 18-39 but 1.13 and 1.08 later." });

ev({ id: "f03-E03b", supports: sup([EG1], ["optimal_low", "age_split"]),
  identifier: { type: "pmcid", value: "PMC10286512" }, citation: "Hussain J, et al. BMJ 2023;381:e075062, table 3 (all cause mortality by eGFR category and age group).", year: 2023,
  quote: "90-100 mL/min/1.73m 2 (reference for 40-50 years) Event frequency 2990/416 431 7595/385 729 57740/750 625 Crude incidence rate 0.993 2.21 8.24 Adjusted HR 1.05 (1.00 to 1.10) 1.00 (reference) 1.11 (1.09 to 1.12)",
  location: "table 3, all cause mortality, row eGFR 90-100; columns ages 18-39, 40-49, 50-65", design: "as f03-E03 (full text table)", n: 8703871, follow_up_years: 9.2, outcome: "all-cause mortality", population_age: "18-65", population_sex: "both", assay: "creatinine-based eGFR", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "Age-stratified: at ages 18-39 eGFR 90-100 has HR 1.05 (within 10% of the 100-110 referent) and 80-90 has HR 1.15 (same table, next row), so the optimal floor is 90 for 18-39; at 40-49, 80-90 has HR 1.02 versus 90-100.", notes: "The adjacent row '80-90 mL/min/1.73m 2 (reference for 50-65 years) ... Adjusted HR 1.15 (1.08 to 1.22) 1.02 (0.98 to 1.05) 1.00 (reference)' gives the 80-90 hazards." });

ev({ id: "f03-E04", supports: sup([EG2, EG3], ["age_split"]).concat(sup([EG2], ["optimal_low"])),
  identifier: { type: "pmid", value: "23111824" }, citation: "Hallan SI, Matsushita K, Sang Y, et al.; Chronic Kidney Disease Prognosis Consortium. Age and association of kidney measures with mortality and end-stage renal disease. JAMA 2012;308(22):2349-60.", year: 2012,
  quote: "adjusted HRs at an eGFR of 45 mL/min/1.73 m2 vs 80 mL/min/1.73 m2 were 3.50 (95% CI, 2.55-4.81), 2.21 (95% CI, 2.02-2.41), 1.59 (95% CI, 1.42-1.77), and 1.35 (95% CI, 1.23-1.48) in age categories 18-54, 55-64, 65-74, and ≥75 years, respectively",
  location: "abstract, results", design: "individual-level meta-analysis, 33 general-population or high-risk cohorts and 13 CKD cohorts (pooled consortium)", n: 2051244, follow_up_years: 5.8, outcome: "all-cause mortality and end-stage renal disease", population_age: "18 and over, four age categories up to 75 and over", population_sex: "both", assay: "creatinine-based eGFR", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "Age-stratified: relative risk of low eGFR falls with age but absolute risk rises (9.0, 12.2, 13.3 and 27.2 excess deaths per 1000 person-years at 45 vs 80); the association holds at 75 and over, so the optimal floor is not lowered for older adults on outcome grounds.", notes: "Evidence above age 70 for the 40-84 and 85+ rows." });

ev({ id: "f03-E05", supports: sup([EG2, EG3], ["age_split"]).concat(sup([EG1], ["age_split"])),
  identifier: { type: "pmid", value: "40122341" }, citation: "Astley ME, Chesnaye NC, Hallan S, et al.; European Chronic Kidney Disease Burden Consortium. Age- and sex-specific reference values of estimated glomerular filtration rate for European adults. Kidney Int 2025;107(6):1076-1087.", year: 2025,
  quote: "in men aged 80 years old, the 5th, 50th and 95th eGFR percentiles were 49 ml/min per 1.73 m2, 66 ml/min per 1.73 m2, and 84 ml/min per 1.73 m2. In 80 year old women this was 46 ml/min per 1.73 m2, 63 ml/min per 1.73 m2, and 81 ml/min per 1.73 m2.",
  location: "abstract, results", design: "cross-sectional reference values from nine European population studies (healthy subset)", n: 1535253, follow_up_years: null, outcome: "none (distribution)", population_age: "18-107, median 43", population_sex: "both", assay: "EKFC equation, standardised creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Age-specific percentiles: at 20 the 5th/50th/95th percentiles are 78/99/119 (men) and 81/101/121 (women); at 80 they are 49/66/84 and 46/63/81. Population share, not outcome.", notes: "Shows that most healthy adults over 75 sit below the 75 floor (population check N1), and that the 95th percentile at 80 is 81-84, far below the former ceiling 105." });

ev({ id: "f03-E06", supports: sup([EG2], ["optimal_low", "age_split"]),
  identifier: { type: "pmid", value: "33959265" }, citation: "Kim Y, Lee S, Lee Y, et al. The minimum-mortality estimated glomerular filtration rate percentile shifts upward in the aged population: a nationwide population-based study. Clin Kidney J 2021;14(5):1356-1363.", year: 2021,
  quote: "the minimum-mortality eGFR percentiles were the 28th percentile (83.8 mL/min/1.73 m2) for middle-aged males, the 63rd percentile (86.2 mL/min/1.73 m2) for elderly males, the 42nd percentile (102.8 mL/min/1.73 m2) for middle-aged females and the 75th percentile (90.1 mL/min/1.73 m2) for elderly females",
  location: "abstract, results", design: "retrospective nationwide health-screening cohort (Korean NHIS 2009-2012)", n: null, follow_up_years: null, outcome: "all-cause mortality by eGFR percentile", population_age: "45 and over; 45-64 and 65 and over", population_sex: "both", assay: "creatinine-based eGFR", band_rule: "nadir_ci", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "Age-stratified: the minimum-mortality eGFR is 86-90 mL/min/1.73 m2 in people 65 and over, i.e. the nadir does not move to lower eGFR with age; it moves to a higher percentile of the age distribution.", notes: "Sample size and follow-up not in the abstract (grade C proposed). Used only to show that older-adult evidence does not support a floor below 75." });

ev({ id: "f03-E07", supports: sup([EG3], ["age_split", "class"]),
  identifier: { type: "pmid", value: "24664801" }, citation: "Montesanto A, De Rango F, Berardelli M, et al. Glomerular filtration rate in the elderly and in the oldest old: correlation with frailty and mortality. Age (Dordr) 2014;36(3):9641.", year: 2014,
  quote: "In the latter group, a not significant trend for increasing mortality was also observed among people with eGFR > 60 (HR = 1.28, 95% CI = 0.72-2.26). In addition, the oldest old subjects with eGFR > 60 and eGFR < 30 had the lowest hand-grip strength and ADL values.",
  location: "abstract, results", design: "two prospective cohorts, 65-89 and 90 and over (Calabria)", n: null, follow_up_years: null, outcome: "all-cause mortality, frailty", population_age: "65-89 and 90 and over", population_sex: "both", assay: "creatinine-based eGFR", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "Age-stratified: U-shaped eGFR-mortality in the oldest old (90 and over) but not at 65-89; the authors conclude eGFR needs adjustment for muscle mass in people 90 and over.", notes: "Basis for the 85+ policy: no optimal band, reference floor only." });

ev({ id: "f03-E08", supports: sup([EG1, EG2, EG3], ["method"]),
  identifier: { type: "pmid", value: "34554658" }, citation: "Inker LA, Eneanya ND, Coresh J, et al. New Creatinine- and Cystatin C-Based Equations to Estimate GFR without Race. N Engl J Med 2021;385(19):1737-1749.", year: 2021,
  quote: "A new equation using age and sex and omitting race underestimated measured GFR in Blacks (median, 3.6 ml per minute per 1.73 m2; 95% confidence interval [CI], 1.8 to 5.5) and overestimated measured GFR in non-Blacks (median, 3.9 ml per minute per 1.73 m2; 95% CI, 3.4 to 4.4).",
  location: "abstract, results", design: "equation development (10 studies, 8,254 participants) and validation (12 studies, 4,050)", n: 12304, follow_up_years: null, outcome: "measured GFR accuracy", population_age: "adults", population_sex: "both", assay: "IDMS-traceable creatinine; CKD-EPI 2021", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "A",
  age_stratified_statement: "Not applicable (equation).", notes: "The equation the app uses (K1). The EKFC alternative is an open physician question (f03-Q02)." });

ev({ id: "f03-E09", supports: sup([EG1, EG2, EG3], ["action_limit"]),
  identifier: { type: "pmcid", value: "PMC11792658" }, citation: "KDIGO 2024 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease in Children and Adults: a commentary from the European Renal Best Practice. Nephrol Dial Transplant 2025;40(2):273-282.", year: 2025,
  quote: "Recommendation 2.2.1: In people with CKD G3–G5, we recommend using an externally validated risk equation to estimate the absolute risk of kidney failure (1A)",
  location: "table of KDIGO 2024 recommendations and practice points (chapter 2, risk assessment)", design: "guideline commentary quoting KDIGO 2024 verbatim", n: null, follow_up_years: null, outcome: "kidney failure risk prediction (recommendation)", population_age: "adults with CKD G3-G5", population_sex: "both", assay: "not applicable", band_rule: "none", basis_class: "guideline_decision_limit", proposed_grade: "A",
  age_stratified_statement: "Not applicable.", notes: "Follow-up for AL-17: the physician applies a validated kidney-failure risk equation in persistent G3-G5; the client text names it without a number." });

ev({ id: "f03-E10", supports: sup([EG2], ["method"]),
  identifier: { type: "pmid", value: "41608441" }, citation: "Yang Q, Lei K, Sun P, Chen A, Su B. Glomerular hyperfiltration defined by eGFR and long-term clinical outcomes: a systematic review and meta-analysis. Front Med (Lausanne) 2026;12:1714170.", year: 2026,
  quote: "The 95th percentile eGFR values among healthy individuals ranged from 94.7 to 146.7 mL/min/1.73 m2. A total of 17 studies, including 11,563,332 participants, were included in the systematic review. GHF was significantly associated with an increased risk of all-cause mortality (HR, 1.30; 95% CI, 1.18-1.42)",
  location: "abstract, results", design: "systematic review and meta-analysis of 17 cohort studies", n: 11563332, follow_up_years: null, outcome: "all-cause mortality, incident albuminuria", population_age: "adults", population_sex: "both", assay: "creatinine-based eGFR, hyperfiltration defined by percentile", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "Hyperfiltration is defined as above the 95th age- and sex-specific percentile; no single absolute value applies across ages.", notes: "Reason no optimal ceiling is set: the harmful zone is a percentile, 94.7 to 146.7 across studies; the creatinine row flags low muscle mass." });

ev({ id: "f03-E11", supports: sup([EG1, EG2], ["optimal_low"]),
  identifier: { type: "pmid", value: "38151225" }, citation: "Shan Y, Zhang J, Lu Y, et al. Kidney Function Measures and Mortality: A Mendelian Randomization Study. Am J Kidney Dis 2024;83(6):772-783.e1.", year: 2024,
  quote: "MR analysis suggested that a genetically predicted lower eGFRcyst was linearly associated with a higher rate of cardiovascular mortality (HR, 1.43; 95% CI, 1.18-1.75) across the entire measurement range (every 10-mL/min/1.73m2 decrement).",
  location: "abstract, results", design: "one-sample Mendelian randomisation in UK Biobank (linear and non-linear)", n: 436214, follow_up_years: 12.1, outcome: "cardiovascular, all-cause and cause-specific mortality", population_age: "56.8 ± 8.0 at baseline", population_sex: "both", assay: "cystatin C-based eGFR", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "No age stratification; causal direction only (lower filtration raises cardiovascular mortality linearly), no causal link with all-cause mortality.", notes: "Supports the direction of the optimal floor, not its value." });

ev({ id: "f03-E12", supports: sup([CR_M, CR_F, CYS], ["method"]),
  identifier: { type: "pmid", value: "41202182" }, citation: "Estrella MM, Ballew SH, Sang Y, et al.; CKD Prognosis Consortium. Discordance in Creatinine- and Cystatin C-Based eGFR and Clinical Outcomes: A Meta-Analysis. JAMA 2025;334(21):1915-1926.", year: 2025,
  quote: "a large negative eGFRdiff, compared with an eGFRdiff between -30% and 30%, was associated with higher rates of all-cause mortality (28.4 vs 16.8 per 1000 person-years [PY]; hazard ratio [HR], 1.69 [95% CI, 1.57-1.82])",
  location: "abstract, results", design: "individual-level meta-analysis, 23 outpatient cohorts", n: 821327, follow_up_years: 11, outcome: "all-cause and cardiovascular mortality, cardiovascular events, kidney failure", population_age: "mean 59 ± 12", population_sex: "both", assay: "creatinine- and cystatin C-based eGFR", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "No age stratification in the abstract.", notes: "Why the messages send doubtful creatinine values to cystatin C." });

ev({ id: "f03-E14", supports: sup([CR_M, CR_F], ["optimal_low", "optimal_high"]),
  identifier: { type: "pmcid", value: "PMC11267836" }, citation: "Wang T, Zhu Y, Liu X, et al. Cystatin C and sarcopenia index are associated with cardiovascular and all-cause death among adults in the United States. BMC Public Health 2024;24:1972 (table 3 footnote and results).", year: 2024,
  quote: "the Q1-Q4 of serum creatinine represent < 0.7, < 0.8, < 1.0 and ≥ 1.0",
  location: "table 3 footnote (quartile definitions); table 3 serum creatinine, all-cause death, Model 3: Ref, 0.87 (0.75-1.01), 0.74 (0.62-0.89), 0.83 (0.67-1.02)", design: "prospective cohort, NHANES 1999-2004 linked to mortality to 2019, restricted cubic splines", n: 9894, follow_up_years: 15.62, outcome: "all-cause and cardiovascular death", population_age: "mean 45.64", population_sex: "both", assay: "serum creatinine (NHANES, Jaffe rate, standardised)", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "No age-stratified estimate for creatinine; a significant creatinine-by-sex interaction is reported (P = 0.002) without sex-specific cut-offs in the text; the all-cause curve is described as J-shaped.", notes: "Sexes pooled, n just under 10,000: grade C. The quartile 0.8 to <1.0 mg/dL carries the lowest fully adjusted all-cause hazard (0.74 versus <0.7), supporting the floors 0.8 (men) and 0.6 (women, with f03-E15 and f03-E16) and ceilings near 1.0." });

ev({ id: "f03-E14b", supports: sup([CR_M, CR_F], ["optimal_low"]),
  identifier: { type: "pmcid", value: "PMC11267836" }, citation: "Wang T, et al. BMC Public Health 2024;24:1972, table 3 (serum creatinine, all-cause death).", year: 2024,
  quote: "All-cause death Model 1 Ref 0.89 (0.77–1.03) 0.83 (0.68–1.01) 1.16 (0.93–1.44) 0.311 Model 2 Ref 0.93 (0.81–1.06) 0.88 (0.73–1.05) 1.21 (0.99–1.48) 0.124 Model 3 Ref 0.87 (0.75–1.01) 0.74 (0.62–0.89)",
  location: "table 3, serum creatinine block, all-cause death rows (quartiles Q1 <0.7, Q2 <0.8, Q3 <1.0, Q4 ≥1.0 mg/dL)", design: "as f03-E14", n: 9894, follow_up_years: 15.62, outcome: "all-cause death", population_age: "mean 45.64", population_sex: "both", assay: "serum creatinine", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "As f03-E14.", notes: "Fully adjusted (Model 3) hazards versus creatinine <0.7 mg/dL: 0.87 (0.7-0.8), 0.74 (0.8-1.0), 0.83 (1.0 and over)." });

ev({ id: "f03-E15", supports: sup([CR_M, CR_F], ["optimal_low", "optimal_high", "sex_split"]),
  identifier: { type: "pmid", value: "27998681" }, citation: "Thongprayoon C, Cheungpasitporn W, Kittanamongkolchai W, Harrison AM, Kashani K. Prognostic Importance of Low Admission Serum Creatinine Concentration for Mortality in Hospitalized Patients. Am J Med 2017;130(5):545-554.e1.", year: 2017,
  quote: "using a creatinine value of 0.7 to 0.8 mg/dL as the reference group in the analysis of all patients and female patients and of 0.9 to 1.0 mg/dL in the analysis of male patients because it was associated with the lowest in-hospital mortality.",
  location: "abstract, methods", design: "retrospective single-centre cohort of hospitalised adults (not a general population)", n: 73994, follow_up_years: 0, outcome: "in-hospital mortality", population_age: "adults", population_sex: "both", assay: "admission serum creatinine", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "No age stratification; sex-specific nadirs reported (men 0.9-1.0, women 0.7-0.8 mg/dL).", notes: "Inpatient cohort, in-hospital outcome: supportive only. Both nadirs sit inside EVA's bands." });

ev({ id: "f03-E16", supports: sup([CR_M, CR_F], ["optimal_low"]),
  identifier: { type: "pmid", value: "19074997" }, citation: "Harita N, Hayashi T, Sato KK, et al. Lower serum creatinine is a new risk factor of type 2 diabetes: the Kansai healthcare study. Diabetes Care 2009;32(3):424-6.", year: 2009,
  quote: "The multiple-adjusted odds ratio for those who had serum creatinine levels between 0.40 and 0.60 mg/dl was 1.91 (95% CI 1.44-2.54) compared with those who had levels between 0.71 and 0.80 mg/dl.",
  location: "abstract, results", design: "prospective occupational cohort of Japanese men", n: 8570, follow_up_years: 4, outcome: "incident type 2 diabetes", population_age: "40-55 at entry", population_sex: "male", assay: "serum creatinine", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "No age stratification (40-55 only); men only.", notes: "Supports harm below 0.6 mg/dL (the women's floor) in direction; under 10,000 participants and 4 years: grade C." });

ev({ id: "f03-E17", supports: sup([CR_M, CR_F], ["optimal_low", "class"]).concat(sup([CYS], ["method"])),
  identifier: { type: "pmid", value: "38898741" }, citation: "Groothof D, Shehab NBN, Erler NS, et al. Creatinine, cystatin C, muscle mass, and mortality: Findings from a primary and replication population-based cohort. J Cachexia Sarcopenia Muscle 2024;15(4):1528-1538.", year: 2024,
  quote: "Median (Q1-Q3) serum creatinine and cystatin C were 71 (61-80) and 80 (62-88) μmol/L and 0.87 (0.78-0.98) and 0.91 (0.80-1.10) mg/L, respectively. Higher serum creatinine was associated with greater muscle mass, while serum cystatin C was not associated with muscle mass.",
  location: "abstract, results", design: "two prospective population cohorts (PREVEND, Netherlands; NHANES replication)", n: 13470, follow_up_years: 12.9, outcome: "all-cause mortality; muscle mass surrogates", population_age: "mean 49.8 and 48.7", population_sex: "both", assay: "serum creatinine (enzymatic), cystatin C", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "No age stratification in the abstract.", notes: "When adjusted for each other, higher creatinine was associated with decreased mortality (abstract): the low-side floor is a muscle-mass flag." });

ev({ id: "f03-E18", supports: sup([CYS], ["optimal_high"]).concat(sup([CR_M, CR_F], ["class"])),
  identifier: { type: "pmid", value: "40983592" }, citation: "Yuan Y, Guo Z, Dong X, Gao J, Wang Z, Yang Y. Association of cystatin C with 20-year mortality risk in the general US population: a cohort study. Ren Fail 2025;47(1):2549401.", year: 2025,
  quote: "second quintile, 1.05 (0.82-1.34); third quintile, 1.29 (1.03-1.60); fourth quintile, 1.46 (1.17-1.83); and fifth quintile, 2.32 (1.86-2.89).",
  location: "abstract, results (all-cause mortality hazard ratios versus the first quintile)", design: "prospective cohort, NHANES 1999-2004 linked to mortality", n: 12340, follow_up_years: 17.25, outcome: "all-cause and cardiovascular mortality", population_age: "median 44 (IQR 33-57)", population_sex: "both", assay: "Siemens Dade Behring cystatin C immunoassay (pre ERM-DA471 standardisation)", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "The abstract reports no age interaction; the full text reports the same strata with larger hazards in people over 59 (September review), so the nadir does not shift with age. Creatinine and eGFR quintiles were not associated with death after adjustment.", notes: "Within-10% rule: quintile 2 (HR 1.05) is inside the band, quintile 3 (HR 1.29) is not; cut-offs in f03-E18b. Median follow-up 207 months." });

ev({ id: "f03-E18b", supports: sup([CYS], ["optimal_high"]),
  identifier: { type: "pmcid", value: "PMC12456039" }, citation: "Yuan Y, et al. Ren Fail 2025;47(1):2549401, results (quintile cut-offs).", year: 2025,
  quote: "quintile 1 (<0.640 mg/L), quintile 2 (0.640–0.717 mg/L), quintile 3 (0.718–0.799 mg/L), quintile 4 (0.800–0.932 mg/L), and quintile 5 (>0.932 mg/L)",
  location: "results, first paragraph (baseline characteristics by quintile)", design: "as f03-E18", n: 12340, follow_up_years: 17.25, outcome: "all-cause mortality", population_age: "median 44", population_sex: "both", assay: "as f03-E18", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "As f03-E18.", notes: "Optimal ceiling 0.72 mg/L = upper bound of quintile 2 (0.717), rounded to the reporting precision." });

ev({ id: "f03-E19", supports: sup([CR_M, CR_F], ["sex_split", "age_split"]),
  identifier: { type: "pmid", value: "18621041" }, citation: "Pottel H, Vrydags N, Mahieu B, Vandewynckele E, Croes K, Martens F. Establishing age/sex related serum creatinine reference intervals from hospital laboratory data based on different statistical methods. Clin Chim Acta 2008;396(1-2):49-55.", year: 2008,
  quote: "We show that the Scr-age pattern is constant between 20 and 70 years with a mean of 0.90 mg/dL [0.63-1.16 mg/dL] for men and 0.70 mg/dL [0.48-0.93 mg/dL] for women. Above 70, Scr starts to slowly increase again.",
  location: "abstract, results", design: "indirect reference intervals from hospital laboratory data (Belgian, Caucasian)", n: null, follow_up_years: null, outcome: "none (distribution)", population_age: "birth to 100", population_sex: "both", assay: "IDMS-traceable enzymatic creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Age-stratified distribution: constant 20-70, slowly rising above 70 (reference-interval effect of falling filtration, not a different optimum).", notes: "Why creatinine rows are sex-specific and not age-split; the older-adult pass notes the slow rise above 70." });

ev({ id: "f03-E20", supports: sup([CYS], ["method", "sex_split"]),
  identifier: { type: "pmid", value: "29573343" }, citation: "Erlandsen EJ, Randers E. Reference intervals for plasma cystatin C and plasma creatinine in adults using methods traceable to international calibrators and reference methods. J Clin Lab Anal 2018;32(6):e22433.", year: 2018,
  quote: "The nonparametric reference intervals for plasma cystatin C were 0.58-1.00 mg/L in women (median 0.78 mg/L, range 0.56-1.06 mg/L) and 0.62-1.04 mg/L in men (median 0.79 mg/L, range 0.61-1.07 mg/L).",
  location: "abstract, results", design: "reference-interval study, 304 healthy blood donors", n: 304, follow_up_years: null, outcome: "none (reference interval)", population_age: "17-66", population_sex: "both", assay: "Gentian cystatin C traceable to ERM-DA471/IFCC; IDMS-traceable creatinine", band_rule: "none", basis_class: "laboratory_interval", proposed_grade: "C",
  age_stratified_statement: "No age partition reported in the abstract; no sex difference (P = .21).", notes: "Standardised interval close to Echevarne's 0.62-1.11; standardised healthy medians 0.78-0.79 mg/L, above the outcome ceiling 0.72." });

ev({ id: "f03-E21", supports: sup([CR_M, CR_F, BUN], ["age_split"]),
  identifier: { type: "pmid", value: "8207875" }, citation: "Aono T, Matsubayashi K, Kawamoto A, Kimura S, Doi Y, Ozawa T. [Normal ranges of blood urea nitrogen and serum creatinine levels in the community-dwelling elderly subjects aged 70 years or over]. Nihon Ronen Igakkai Zasshi 1994;31(3):232-6.", year: 1994,
  quote: "The estimated normal range of BUN was 14-23 mg/dl both in male and female elderly subjects, and that of Cr was 0.9-1.3 mg/dl in male and was 0.7-1.1 mg/dl in female.",
  location: "abstract (English), results", design: "cross-sectional, community-dwelling elderly (Kahoku Longitudinal Aging Study)", n: 332, follow_up_years: null, outcome: "none (distribution, mean ± SD)", population_age: "70 and over", population_sex: "both", assay: "BUN and creatinine (method not stated)", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Age-specific (70 and over): BUN and creatinine run higher than in young controls; the older-adult pass uses it to say that above-optimal readings are usual after 70.", notes: "Small, Japanese, 1994; qualitative use only." });

ev({ id: "f03-E22", supports: sup([CR_M, CR_F], ["critical_high"]),
  identifier: { type: "url", value: "https://mft.nhs.uk/the-trust/other-departments/laboratory-medicine/information-for-gps/laboratory-medicines-newsletter-for-gps/the-communication-of-critical-biochemistry-results/" }, citation: "Adaway J. The communication of critical biochemistry results. Manchester University NHS Foundation Trust, Laboratory Medicine newsletter for GPs, March 2025 (limits stated to be based on Royal College of Pathologists guidance).", year: 2025,
  quote: "Creatinine (if no AKI stage available) µmol/L NA 354",
  location: "table of critical or phoning limits for adult patients, row Creatinine (columns Analyte, Units, Below or equal to, Above or equal to)", design: "published primary-care critical-value list (RCPath-based, secondary)", n: null, follow_up_years: null, outcome: "none (institutional critical limit)", population_age: "adults", population_sex: "both", assay: "serum creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable.", notes: "354 µmol/L ÷ 88.4 = 4.0 mg/dL (conversion from the critical-limits draft). The same table carries 'Urea (unless patient is on dialysis) mmol/L NA 30' = BUN 84 mg/dL, the alternative to 100 for BUN. Alternatives for creatinine: 7.4 mg/dL (f03-E23) and the 2024 US median 7.5 (f03-E24); see f03-Q10." });

ev({ id: "f03-E23", supports: sup([BUN, URE], ["critical_high"]).concat(sup([URE], ["method"])).concat(sup([CR_M, CR_F], ["critical_high"])),
  identifier: { type: "pmcid", value: "PMC6178782" }, citation: "Thomas L. Critical limits of laboratory results for urgent clinician notification. eJIFCC 2003;14(1), table 1.", year: 2003,
  quote: "Urea BUN > 214 mg/dl (35.6 mmol/l) > 100 mg/dl (35.6 mmol/l) Indicative of acute renal failure; unlike pre-renal and post-renal kidney failure, no disproportionate increase in urea compared to creatinine in serum.",
  location: "table 1, row Urea / BUN", design: "IFCC-published expert list of critical limits (adults)", n: null, follow_up_years: null, outcome: "none (critical limit)", population_age: "adults", population_sex: "both", assay: "serum urea / BUN", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable.", notes: "BUN 100 mg/dL and urea 214 mg/dL are the same sample (35.6 mmol/L), which also fixes the conversion urea = BUN x 2.14. The creatinine row of the same table reads 'Creatinine > 7.4 mg/dl (654 mmol/l) Acute renal failure, e.g. in multiple organ failure or sepsis.' (alternative to 4.0)." });

ev({ id: "f03-E24", supports: sup([CR_M, CR_F, BUN], ["critical_high"]),
  identifier: { type: "pmcid", value: "PMC11899349" }, citation: "Shah A, Dohner J, Cheng K, Garcia M, Kost GJ. Visualization of critical limits and critical values facilitates interpretation. Diagnostics (Basel) 2025;15(5):604, table (creatinine and urea nitrogen rows).", year: 2025,
  quote: "Creatinine 12 10 µmol/L … … … … 654 (380) 636 (265) 884 (177–1326) 663 (177–884) mg/dL … … … … 7.4 (4.3) 7.2 (3.0) 10 (2.0–15.0) 7.5 (2.0–10.0)",
  location: "table of high critical limits across surveys, rows Creatinine (µmol/L and mg/dL); the Urea Nitrogen rows read '… 104 (59) 91 (28) 95 (40–300) 101 (40–120)' in mg/dL", design: "survey of 50 US medical-centre lists (2024) compared with earlier surveys", n: 50, follow_up_years: null, outcome: "none (critical limits)", population_age: "adults", population_sex: "both", assay: "serum creatinine, urea nitrogen", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable.", notes: "2024 medians: creatinine 7.5 mg/dL (range 2.0-10.0), urea nitrogen 101 mg/dL (40-120). The draft chooses the stricter primary-care limit 4.0 for an unsupervised client (f03-Q10)." });

ev({ id: "f03-E25", supports: sup([CR_M, CR_F, EG1, EG2, EG3, BUN, URE], ["pre_analytical"]),
  identifier: { type: "pmid", value: "42035842" }, citation: "Tsiaras A, Loufopoulos G, Theodoridis X, Liakopoulos V, Poulia KA, Chourdakis M. The Effect of Creatine Supplementation on Kidney Function: A Systematic Review and Meta-Analysis of Randomized Controlled Trials. J Ren Nutr 2026 (online ahead of print).", year: 2026,
  quote: "Cre supplementation was associated with an increase in serum Crn (mean difference (MD) = 0.13 mg/dL, 95% confidence interval [CI]: 0.07 to 0.18",
  location: "abstract, results", design: "systematic review and meta-analysis of 19 RCTs and one crossover trial", n: null, follow_up_years: null, outcome: "serum creatinine, urea, eGFR", population_age: "adults", population_sex: "both", assay: "serum creatinine", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "A",
  age_stratified_statement: "Not applicable.", notes: "Consistent with the locked creatine rule (0.13 mg/dL; DR-2026-10-30-03): no CEO question. The abstract reports no change in urea (CI -2.15 to 0.96) or eGFR (MD -5.20, CI -15.00 to 4.60)." });

ev({ id: "f03-E26", supports: sup([CR_M, CR_F, EG1, EG2, EG3, CYS, RAT], ["pre_analytical"]),
  identifier: { type: "pmid", value: "17270090" }, citation: "Preiss DJ, Godber IM, Lamb EJ, Dalton RN, Gunn IR. The influence of a cooked-meat meal on estimated glomerular filtration rate. Ann Clin Biochem 2007;44(Pt 1):35-42.", year: 2007,
  quote: "median serum creatinine concentration (kinetic Jaffe) increased from 80.5 micromol/L preprandially to 101.0 micromol/L 1-2 h postprandially (P<0.0001), and 99.0 micromol/L 3-4 h postprandially (P<0.0001). Median eGFR decreased from 84.0 mL/min/1.73 m2 preprandially to 59.5 mL/min/1.73 m2 1-2 h postprandially",
  location: "abstract, results", design: "crossover feeding study, 17 healthy volunteers and 15 outpatients", n: 32, follow_up_years: null, outcome: "serum creatinine, eGFR, cystatin C after cooked meat", population_age: "adults", population_sex: "both", assay: "kinetic Jaffe, enzymatic and IDMS creatinine; cystatin C", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "B",
  age_stratified_statement: "Not applicable.", notes: "The abstract adds that cystatin C concentration was generally uninfluenced by food intake." });

ev({ id: "f03-E27", supports: sup([CR_M, CR_F, EG1, EG2, EG3], ["pre_analytical"]),
  identifier: { type: "pmid", value: "24062331" }, citation: "Nair S, O'Brien SV, Hayden K, et al. Effect of a cooked meat meal on serum creatinine and estimated glomerular filtration rate in diabetes-related kidney disease. Diabetes Care 2014;37(2):483-7.", year: 2014,
  quote: "This effect of cooked meat on serum creatinine disappears after 12 h of fasting in all study participants.",
  location: "abstract, results", design: "standardised meal study, 80 subjects (healthy volunteers and CKD stages 1-4)", n: 80, follow_up_years: null, outcome: "serum creatinine and eGFR after cooked meat", population_age: "adults", population_sex: "both", assay: "kinetic alkaline picrate creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "B",
  age_stratified_statement: "Not applicable.", notes: "Basis of the 12-hour fasting advice." });

ev({ id: "f03-E28", supports: sup([CR_M, CR_F, EG1, EG2, EG3, RAT], ["pre_analytical"]),
  identifier: { type: "pmid", value: "32976313" }, citation: "Fitzpatrick D, Walter E, Leckie T, et al. Association between collapse and serum creatinine and electrolyte concentrations in marathon runners: a 9-year retrospective study. Eur J Emerg Med 2021;28(1):34-42.", year: 2021,
  quote: "Serum creatinine was greater than the normal range in 68.9%.",
  location: "abstract, results (collapsed runners); the same abstract reports that in the control group 55.4% met acute kidney injury criteria but had resolved to baseline after 24 h", design: "retrospective series of collapsed marathon runners with a control group of non-collapsed runners", n: 224, follow_up_years: null, outcome: "creatinine and electrolytes after a marathon", population_age: "adults", population_sex: "both", assay: "point-of-care and laboratory creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable.", notes: "Basis of the 48-hour exercise rule." });

ev({ id: "f03-E29", supports: sup([CR_M, CR_F, EG1, EG2, EG3], ["pre_analytical"]),
  identifier: { type: "pmid", value: "4005491" }, citation: "Kastrup J, Petersen P, Bartram R, Hansen JM. The effect of trimethoprim on serum creatinine. Br J Urol 1985;57(3):265-8.", year: 1985,
  quote: "In group A (median age 78 years), serum creatinine increased significantly from median 89 to 134 mumol/l (P less than 0.01) during the first week and returned to normal 1 week after termination of treatment",
  location: "abstract", design: "two volunteer groups treated with trimethoprim 200 mg twice daily for 14 days", n: null, follow_up_years: null, outcome: "serum creatinine, 51Cr-EDTA GFR", population_age: "median 78 (group A) and 29 (group B)", population_sex: "not_reported", assay: "serum creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Two age groups: the rise occurs at both ages; GFR by 51Cr-EDTA did not change.", notes: "Group B (young): 87 to 107 mumol/l." });

ev({ id: "f03-E30", supports: sup([CR_M, CR_F], ["rcv"]),
  identifier: { type: "pmid", value: "28720681" }, citation: "Carobene A, Marino I, Coşkun A, et al. The EuBIVAS Project: Within- and Between-Subject Biological Variation Data for Serum Creatinine Using Enzymatic and Alkaline Picrate Methods and Implications for Monitoring. Clin Chem 2017;63(9):1527-1536.", year: 2017,
  quote: "The within-subject BV estimates [CVI (95% CI)] were similar for enzymatic [4.4% (4.2-4.7)] and alkaline picrate [4.7% (4.4-4.9)] methods and lower than the estimate presently available online (CVI = 5.9%).",
  location: "abstract, results; the same abstract gives CVA 1.1% enzymatic and 4.4% alkaline picrate", design: "EFLM European Biological Variation Study, 91 healthy adults, 10 weekly samples", n: 91, follow_up_years: 0.2, outcome: "biological variation", population_age: "21-69", population_sex: "both", assay: "enzymatic and alkaline picrate creatinine, ADVIA 2400", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "A",
  age_stratified_statement: "Not applicable.", notes: "RCV input (CVI 4.4%)." });

ev({ id: "f03-E31", supports: sup([EG1, EG2, EG3], ["rcv"]).concat(sup([CR_M, CR_F, CYS], ["pre_analytical"])),
  identifier: { type: "pmid", value: "29483105" }, citation: "Hilderink JM, van der Linden N, Kimenai DM, et al. Biological Variation of Creatinine, Cystatin C, and eGFR over 24 Hours. Clin Chem 2018;64(5):851-860.", year: 2018,
  quote: "Unlike creatinine, cystatin C concentrations were unaffected by meat consumption. Cystatin C showed some diurnal rhythmic variation and less in people with CKD. Reference change values (RCVs) of all eGFR equations were within 13% to 20% in both study groups.",
  location: "abstract, results", design: "24-hour hourly sampling study, 17 people without and 20 with CKD", n: 37, follow_up_years: null, outcome: "biological variation", population_age: "adults", population_sex: "both", assay: "enzymatic creatinine and cystatin C, Cobas 8000", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "B",
  age_stratified_statement: "Not applicable.", notes: "eGFR RCV 13-20% (upper value used); meat drives the within-day creatinine variation (CVI 6.4% without CKD)." });

ev({ id: "f03-E32", supports: sup([CYS], ["rcv"]),
  identifier: { type: "pmid", value: "19929276" }, citation: "Reinhard M, Erlandsen EJ, Randers E. Biological variation of cystatin C and creatinine. Scand J Clin Lab Invest 2009;69(8):831-6.", year: 2009,
  quote: "The analytical variance was 2.0% for cystatin C and 1.6% for creatinine. The intra-individual variance was greater for cystatin C than for creatinine (8.6% vs. 4.7%).",
  location: "abstract, results (healthy subjects)", design: "eight weekly samples in 20 healthy subjects and 19 patients with impaired renal function", n: 39, follow_up_years: 0.15, outcome: "biological variation", population_age: "25-61 (healthy), 35-70 (patients)", population_sex: "both", assay: "Dade Behring N Latex cystatin C; enzymatic creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable.", notes: "RCV input for cystatin C (CVI 8.6%, CVA 2.0%)." });

ev({ id: "f03-E33", supports: sup([CYS], ["pre_analytical"]),
  identifier: { type: "pmid", value: "12675875" }, citation: "Fricker M, Wiesli P, Brändle M, Schwegler B, Schmid C. Impact of thyroid dysfunction on serum cystatin C. Kidney Int 2003;63(5):1944-7.", year: 2003,
  quote: "CysC increased from 0.84 +/- 0.17 mg/L (reference, 0.63 to 1.33) to 1.1 +/- 0.28 mg/L (P < 0.001). In patients with hyperthyroidism, mean fT4 was 54.6 +/- 22.7 pmol/L",
  location: "abstract, results", design: "prospective case series, 22 patients with thyroid dysfunction treated to euthyroidism", n: 22, follow_up_years: null, outcome: "cystatin C and creatinine before and after treatment", population_age: "adults", population_sex: "both", assay: "cystatin C (method not stated in abstract)", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable.", notes: "Hyperthyroid patients: cystatin C fell from 1.32 to 0.95 mg/L on treatment. Thyroid state moves cystatin C opposite to creatinine." });

ev({ id: "f03-E34", supports: sup([CYS], ["state_split", "pre_analytical", "age_split"]),
  identifier: { type: "pmid", value: "11601685" }, citation: "Galteau MM, Guyon M, Gueguen R, Siest G. Determination of serum cystatin C: biological variation and reference values. Clin Chem Lab Med 2001;39(9):850-7.", year: 2001,
  quote: "We did not find any effect of age or gender in children, hormonal status in women (puberty, menopause, oral contraceptives or hormone replacement therapy) or alcohol intake. Cystatin C concentration was slightly lower in female than in male adults below the age of 60 years. Cystatin C levels significantly increased above the age of 60",
  location: "abstract, results", design: "cross-sectional reference-value study, 1223 apparently healthy subjects (Nancy, France)", n: 1223, follow_up_years: null, outcome: "none (reference values)", population_age: "4-79", population_sex: "both", assay: "particle-enhanced nephelometric assay", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Age-stratified reference values: 0.74 (men) and 0.65 (women) mg/L at 20-59; 0.83 mg/L at 60 and over.", notes: "Menopause, oral contraception and hormone replacement therapy do not move cystatin C: no state row. Methylprednisolone raises it (literature cited in the abstract)." });

ev({ id: "f03-E35", supports: sup([CR_M, CR_F, EG1, EG2, EG3, CYS, BUN, URE], ["state_split"]).concat(sup([EG1, EG2, EG3], ["pre_analytical"])),
  identifier: { type: "pmid", value: "35971117" }, citation: "Wu L, Wu Q, Li Q, et al. Consecutive reference intervals for biochemical indices related to serum lipid levels and renal function during normal pregnancy. BMC Pregnancy Childbirth 2022;22(1):642.", year: 2022,
  quote: "During pregnancy, we observed significant increases in total cholesterol (TC), triglycerides (TG), high density lipoprotein cholesterol (HDL-C), low density lipoprotein cholesterol (LDL-C), apolipoprotein-A1 (Apo-A1), apolipoprotein-B (Apo-B), cystatin C (Cys-C), and estimated glomerular filtration rate (eGFR). We also observed clear reductions in urea, creatinine (Crea), and uric acid (UA).",
  location: "abstract, results", design: "longitudinal reference-interval study, 120 women sampled at ten time points from pre-pregnancy to 40 weeks", n: 120, follow_up_years: 0.8, outcome: "none (pregnancy reference intervals)", population_age: "pregnant women (adult)", population_sex: "female", assay: "routine serum chemistry (China)", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Not applicable (pregnancy).", notes: "Basis of the pregnancy and lactation rule for this family: creatinine and urea fall, cystatin C and eGFR rise, so declared pregnancy or lactation shows the laboratory interval only with the fixed note (state rules section 2). No pregnancy rows are created." });

ev({ id: "f03-E36", supports: sup([CYS], ["method", "pre_analytical"]),
  identifier: { type: "pmid", value: "15086483" }, citation: "Knight EL, Verhave JC, Spiegelman D, et al. Factors influencing serum cystatin C levels other than renal function and the impact on renal function measurement. Kidney Int 2004;65(4):1416-21.", year: 2004,
  quote: "Older age, male gender, greater weight, greater height, current cigarette smoking, and higher serum C-reactive protein (CRP) levels were independently associated with higher serum cystatin C levels after adjusting for creatinine clearance.",
  location: "abstract, results", design: "cross-sectional population study (PREVEND, Groningen)", n: 8058, follow_up_years: null, outcome: "determinants of cystatin C", population_age: "28-75", population_sex: "both", assay: "serum cystatin C", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Age is an independent determinant of cystatin C beyond filtration.", notes: "Non-filtration causes named in the above-optimal message." });

ev({ id: "f03-E37", supports: sup([CYS], ["class"]),
  identifier: { type: "pmid", value: "27561768" }, citation: "van der Laan SW, Fall T, Soumaré A, et al. Cystatin C and Cardiovascular Disease: A Mendelian Randomization Study. J Am Coll Cardiol 2016;68(9):934-45.", year: 2016,
  quote: "Mendelian randomization analysis did not provide evidence for a causal role of cystatin C, with a causal relative risk for CVD of 1.00 per doubling cystatin C (95% CI: 0.82 to 1.22; p = 0.994)",
  location: "abstract, results", design: "Mendelian randomisation, 16 prospective cohorts (n = 76,481) plus genetic data from 43 studies (n = 252,216)", n: 252216, follow_up_years: null, outcome: "cardiovascular disease", population_age: "adults", population_sex: "both", assay: "cystatin C; CST3 rs911119", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "A",
  age_stratified_statement: "Not applicable.", notes: "Cystatin C is a marker of filtration and other states, not a treatment target: class a for display (outcome gradient) but the message never asks the client to lower the protein." });

ev({ id: "f03-E38", supports: sup([CYS], ["optimal_high"]),
  identifier: { type: "pmid", value: "34847805" }, citation: "Jung E, Ro YS, Ryu HH, Kong SY, Shin SD, Hwang SO. Cystatin C and mortality risk in the general population: systematic review and dose response meta-analysis. Biomarkers 2022;27(3):222-229.", year: 2022,
  quote: "the highest compared with lowest cystatin C level was associated with an increase of all-cause mortality (hazard ratio [HR]: 2.01; 95% confidence intervals [CI]: 1.60-2.53; I2=89%) and cardiovascular mortality (2.62 [1.96-3.51]; I2=52%)",
  location: "abstract, results; the same abstract reports 7.3% higher cardiovascular mortality per 0.1 mg/L", design: "systematic review and dose-response meta-analysis of 13 prospective cohorts", n: 57214, follow_up_years: null, outcome: "all-cause and cardiovascular mortality", population_age: "adults (general population)", population_sex: "both", assay: "various cystatin C assays", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "No age-stratified estimate reported.", notes: "Supports a monotonic ceiling (no lower bound); gives no absolute cut-off." });

ev({ id: "f03-E39", supports: sup([CYS], ["optimal_high", "age_split"]),
  identifier: { type: "pmid", value: "15901858" }, citation: "Shlipak MG, Sarnak MJ, Katz R, et al. Cystatin C and the risk of death and cardiovascular events among elderly persons. N Engl J Med 2005;352(20):2049-60.", year: 2005,
  quote: "second quintile, 1.08 (0.86 to 1.35); third quintile, 1.23 (1.00 to 1.53); fourth quintile, 1.34 (1.09 to 1.66); quintile 5a, 1.77 (1.34 to 2.26); 5b, 2.18 (1.72 to 2.78); and 5c, 2.58 (2.03 to 3.27).",
  location: "abstract, results (hazard ratios for death versus the first quintile)", design: "prospective cohort of community-dwelling elderly (Cardiovascular Health Study)", n: 4637, follow_up_years: 8, outcome: "all-cause and cardiovascular death, myocardial infarction, stroke", population_age: "65 and over", population_sex: "both", assay: "Dade Behring cystatin C (1992-93 samples)", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "Elderly-only cohort (65 and over): the gradient is monotonic from the second quintile, so the nadir is the lowest category in older adults too; the two lowest quintiles combined are 0.99 mg/L or less and the top quintile 1.29 mg/L or more.", notes: "Evidence above age 70 that the cystatin C gradient persists; absolute cut-offs are from a pre-standardisation assay." });

ev({ id: "f03-E40", supports: sup([CYS], ["optimal_high"]),
  identifier: { type: "pmid", value: "39044229" }, citation: "Wang T, Zhu Y, Liu X, et al. Cystatin C and sarcopenia index are associated with cardiovascular and all-cause death among adults in the United States. BMC Public Health 2024;24(1):1972.", year: 2024,
  quote: "compared with the first quartile of cystatin C (< 0.659 mg/L), the risk of cardiovascular and all-cause death increased 2.36-fold and 1.71-fold for participants in the fourth quartile (≥ 0.877 mg/L) (HR: 3.36, 95% CI: 2.06-5.46, P < 0.001; HR: 2.71, 95% CI: 2.17-3.38, P < 0.001; respectively).",
  location: "abstract, results", design: "prospective cohort, NHANES 1999-2004 linked to mortality to 2019", n: 9894, follow_up_years: 15.62, outcome: "cardiovascular and all-cause death", population_age: "mean 45.64", population_sex: "both", assay: "NHANES cystatin C (Dade Behring)", band_rule: "lowest_risk_category", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "No age-stratified estimate in the abstract.", notes: "Same survey as f03-E18 with quartiles (Q2 <0.753 HR 1.29, Q3 <0.877 HR 1.67 in the full text), so a ceiling above 0.75 is not supported by this analysis either." });

ev({ id: "f03-E41", supports: sup([BUN, URE], ["optimal_high"]),
  identifier: { type: "pmcid", value: "PMC9865447" }, citation: "Hong C, Zhu H, Zhou X, et al. Association of Blood Urea Nitrogen with Cardiovascular Diseases and All-Cause Mortality in USA Adults: Results from NHANES 1999-2006. Nutrients 2023;15(2):461, table 2 (all-cause mortality by BUN quartile).", year: 2023,
  quote: "Model 4 1 [Reference] 1.06 (0.92,1.21) 1.05 (0.91,1.22) 1.48 (1.28,1.72)",
  location: "table 2, all-cause mortality, fully adjusted Model 4 row; quartiles defined in table 1 as 'Q1 <3.57 Q2 3.57–4.59 Q3 4.60–5.70 Q4 ≥5.71' mmol/L", design: "prospective cohort, NHANES 1999-2006 linked to mortality to 2015 (general population)", n: 17719, follow_up_years: 11.65, outcome: "all-cause and cardiovascular mortality", population_age: "20 and over", population_sex: "both", assay: "NHANES serum urea nitrogen", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "Stratified analyses by age (<60 vs 60 and over) are reported in figure 2 without a shift of the cut-off; the Q4 association was stronger in people 60 and over and in women.", notes: "Within-10% rule: quartiles 1-3 (<5.71 mmol/L = <16.0 mg/dL; 5.71 x 2.801 = 15.99) are within 10% of the minimum; quartile 4 (16.0 mg/dL and over) has HR 1.48. Hence optimal ceiling 16 mg/dL (urea 34)." });

ev({ id: "f03-E41b", supports: sup([BUN, URE], ["optimal_high"]),
  identifier: { type: "pmcid", value: "PMC9865447" }, citation: "Hong C, et al. Nutrients 2023;15(2):461, table 1 (quartile cut-offs).", year: 2023,
  quote: "Blood Urea Nitrogen (mmol/L) p Value Q1 <3.57 Q2 3.57–4.59 Q3 4.60–5.70 Q4 ≥5.71",
  location: "table 1 header and quartile labels", design: "as f03-E41", n: 17719, follow_up_years: 11.65, outcome: "as f03-E41", population_age: "20 and over", population_sex: "both", assay: "as f03-E41", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "As f03-E41.", notes: "Conversion BUN mmol/L x 2.801 = mg/dL: 3.57 = 10.0, 4.59 = 12.9, 5.70 = 16.0, 5.71 = 16.0." });

ev({ id: "f03-E42", supports: sup([BUN, URE], ["optimal_low", "optimal_high"]),
  identifier: { type: "pmcid", value: "PMC11145831" }, citation: "Shen J, Wang Z, Liu Y, et al. Association of blood urea nitrogen with all-cause and cardiovascular mortality in hyperlipidemia: NHANES 1999-2018. Lipids Health Dis 2024;23(1):164, results (quintile hazards) and table 1 (quintile cut-offs).", year: 2024,
  quote: "Multivariable-adjusted HRs (95% CI) for quintiles of BUN levels were 1.26 (1.09, 1.45), 1.08 (0.93, 1.25), 1(ref), 1.02 (0.89, 1.17), and 1.22 (1.09, 1.37) ( P for trend < 0.001), respectively.",
  location: "results, association of BUN with mortality; table 1 defines the quintiles as 'Q1 < 3.60 Q2 3.60-4.29 Q3 4.30-5.00 Q4 5.01-6.09 Q5 > 6.09' mmol/L", design: "prospective cohort, NHANES 1999-2018 participants with hyperlipidaemia, restricted cubic splines", n: 28122, follow_up_years: null, outcome: "all-cause and cardiovascular mortality", population_age: "mean 48.52", population_sex: "both", assay: "NHANES serum urea nitrogen", band_rule: "within_10pct_of_min_hr", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "No age-specific cut-off; subgroup analyses by income, alcohol and medication reported.", notes: "Within-10% band: quintiles 2-4 = 3.60-6.09 mmol/L = 10.1-17.1 mg/dL. Quintile 1 (<3.60 mmol/L = <10.1 mg/dL) HR 1.26 supports the floor 10; quintile 5 (>17.1 mg/dL) HR 1.22 supports a ceiling of 16-17 (the general-population f03-E41 gives 16). Hyperlipidaemic subpopulation (about half of US adults)." });

ev({ id: "f03-E43", supports: sup([BUN, URE], ["optimal_high"]),
  identifier: { type: "pmid", value: "38755538" }, citation: "Liu H, Xin X, Gan J, Huang J. The long-term effects of blood urea nitrogen levels on cardiovascular disease and all-cause mortality in diabetes: a prospective cohort study. BMC Cardiovasc Disord 2024;24(1):256.", year: 2024,
  quote: "Moreover, BUN showed a nonlinear association with all-cause and CVD mortality. Their curves all showed that the inflection points were close to the BUN level of 5 mmol/L.",
  location: "abstract, results", design: "prospective cohort, NHANES 1999-2018 adults with diabetes", n: 10507, follow_up_years: 8.2, outcome: "all-cause and cardiovascular mortality", population_age: "adults with diabetes", population_sex: "both", assay: "NHANES serum urea nitrogen", band_rule: "nadir_ci", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "No age stratification in the abstract.", notes: "Inflection 5 mmol/L = 14 mg/dL (diabetes only); supportive of a ceiling in the mid-teens. Follow-up from 86,601 person-years / 10,507." });

ev({ id: "f03-E44", supports: sup([BUN, URE], ["reference_high"]),
  identifier: { type: "pmid", value: "29241622" }, citation: "Xie Y, Bowe B, Li T, Xian H, Yan Y, Al-Aly Z. Higher blood urea nitrogen is associated with increased risk of incident diabetes mellitus. Kidney Int 2018;93(3):741-752.", year: 2018,
  quote: "the risk was significantly increased in those with a BUN over 25 mg/dl at all eGFR levels, even in those with an eGFR of 60 ml/min/1.73m2 or more (hazard ratio 1.27; confidence interval 1.24-1.31).",
  location: "abstract", design: "national cohort of US veterans without diabetes", n: 1337452, follow_up_years: 4.93, outcome: "incident diabetes", population_age: "adults (veterans)", population_sex: "both", assay: "serum urea nitrogen", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "No age stratification in the abstract.", notes: "Echevarne's upper limit 25 mg/dL coincides with the level above which incident diabetes rose; supportive, the reference bound itself is Echevarne's." });

ev({ id: "f03-E45", supports: sup([BUN, URE], ["optimal_high"]),
  identifier: { type: "pmid", value: "40097334" }, citation: "Shen L, Zhang Q, Zhu Z, Huang Z. Genetic insights into blood urea nitrogen as a risk factor for coronary artery disease: a Mendelian randomization study in East Asians. Ren Fail 2025;47(1):2477318.", year: 2025,
  quote: "The IVW approach showed that a higher level of BUN was associated with an increased risk of coronary artery disease (CAD) (OR = 1.42, 95% CI = 1.226 - 1.644, p = 2.89 × 10-6).",
  location: "abstract, results", design: "two-sample Mendelian randomisation (East Asian GWAS)", n: 148767, follow_up_years: null, outcome: "coronary artery disease; null for atrial fibrillation, arrhythmia, heart failure", population_age: "adults", population_sex: "both", assay: "genetic instruments for BUN", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "B",
  age_stratified_statement: "Not applicable.", notes: "Causal direction only (higher BUN raises coronary disease); East Asian ancestry; no threshold." });

ev({ id: "f03-E46", supports: sup([BUN], ["sex_split", "age_split"]),
  identifier: { type: "pmid", value: "33980952" }, citation: "Liu Q, Wang Y, Chen Z, Guo X, Lv Y. Age- and sex-specific reference intervals for blood urea nitrogen in Chinese general population. Sci Rep 2021;11(1):10058.", year: 2021,
  quote: "Males had a higher median BUN value compared to females (4.6 mmol/L vs. 4.1 mmol/L).",
  location: "abstract, results; the same abstract reports a rise of 0.21 mmol/L (males) and 0.282 mmol/L (females) per 10 years", design: "cross-sectional reference-interval study, 24,006 healthy adults", n: 24006, follow_up_years: null, outcome: "none (distribution)", population_age: "adults", population_sex: "both", assay: "serum urea nitrogen (China)", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "Age- and sex-specific percentiles exist for the distribution; no outcome source gives a sex- or age-specific optimum, so one band is kept.", notes: "Why no sex or age split for BUN despite distribution differences." });

ev({ id: "f03-E48", supports: sup([RAT], ["reference_low", "class"]),
  identifier: { type: "pmid", value: "35166184" }, citation: "Shen S, Yan X, Xu B. The blood urea nitrogen/creatinine (BUN/cre) ratio was U-shaped associated with all-cause mortality in general population. Ren Fail 2022;44(1):184-190.", year: 2022,
  quote: "BUN/Cre ratio between 11.43 and 14.64 was associated with the lowest all-cause mortality compared with the participants with the lowest quartile (HR 0.83 [0.76, 0.91]; p < 0.001).",
  location: "abstract, results", design: "prospective cohort, NHANES 1999-2014 linked to mortality", n: 42038, follow_up_years: 8.13, outcome: "all-cause, cardiovascular and cancer mortality", population_age: "adults", population_sex: "both", assay: "NHANES urea nitrogen and creatinine", band_rule: "none", basis_class: "outcome_nadir", proposed_grade: "C",
  age_stratified_statement: "Older people and women have a higher ratio (abstract); no age-specific cut-off.", notes: "Class e: a U-shape with a lowest-mortality quartile is not a target; the lower reference limit 10 is convention near the first quartile boundary (11.43)." });

ev({ id: "f03-E49", supports: sup([RAT], ["reference_high", "reference_low"]),
  identifier: { type: "pmcid", value: "PMC8856064" }, citation: "Shen S, Yan X, Xu B. Ren Fail 2022;44(1):184-190, discussion and table 1.", year: 2022,
  quote: "BUN/Cre ratio is one of the common indices used to separate pre-renal azotemia and acute tubular necrosis, with a threshold of 20",
  location: "discussion, first paragraph; table 1 quartiles 'BUN/Cr e < 11.43 ( n = 10514) BUN/Cr e < 14.64 ( n = 10542) BUN/Cr e < 18.57 ( n = 10412) BUN/Cr e ≥ 18.57 ( n = 10570)'", design: "as f03-E48", n: 42038, follow_up_years: 8.13, outcome: "as f03-E48", population_age: "adults", population_sex: "both", assay: "as f03-E48", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "C",
  age_stratified_statement: "As f03-E48.", notes: "Upper reference limit 20 = the conventional threshold; quartile boundaries show 25% of US adults above 18.57." });

ev({ id: "f03-E50", supports: sup([RAT], ["reference_high"]),
  identifier: { type: "pmid", value: "19855842" }, citation: "Tariq M, Memon M, Jafferani A, et al. Massive fluid requirements and an unusual BUN/creatinine ratio for pre-renal failure in patients with cholera. PLoS One 2009;4(10):e7552.", year: 2009,
  quote: "Instead of presenting with a classical BUN/Creatinine ratio of >20:1, patients with pre-renal failure in cholera may present with a BUN/Creatinine ratio of <15:1.",
  location: "abstract, conclusion", design: "retrospective hospital series (191 cholera patients)", n: 191, follow_up_years: null, outcome: "none (clinical convention stated)", population_age: "mean 42.3", population_sex: "both", assay: "serum urea nitrogen and creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "D",
  age_stratified_statement: "Not applicable.", notes: "Names the classical >20:1 convention only." });

ev({ id: "f03-E51", supports: sup([RAT], ["reference_high"]),
  identifier: { type: "pmid", value: "42668465" }, citation: "Hamrick I, Bauer ML. Prevalence of dehydration and a quality improvement initiative in nursing home residents. JAR Life 2026;15:100084.", year: 2026,
  quote: "We identified dehydration based on blood urea nitrogen and creatinine (BUN/Creat) ratio as ≥20:1 because of convenience and availability.",
  location: "abstract, methods", design: "quality-improvement series in one nursing home", n: 48, follow_up_years: 3, outcome: "dehydration prevalence", population_age: "older adults (nursing home)", population_sex: "both", assay: "serum urea nitrogen and creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "D",
  age_stratified_statement: "Not applicable.", notes: "Convention only (20:1 as dehydration)." });

ev({ id: "f03-E52", supports: sup([RAT], ["reference_low"]),
  identifier: { type: "pmid", value: "9855390" }, citation: "Jurado R, Mattix H. The decreased serum urea nitrogen-creatinine ratio. Arch Intern Med 1998;158(22):2509-11.", year: 1998,
  quote: "A normal ratio is 8:1 to 10:1. It is well known that an elevated ratio is seen in cases of prerenal or postrenal uremia. Less appreciated are the diagnostic possibilities suggested by a decreased serum urea nitrogen-creatinine ratio (ie, <8).",
  location: "abstract", design: "narrative review", n: null, follow_up_years: null, outcome: "none", population_age: "adults", population_sex: "both", assay: "serum urea nitrogen and creatinine", band_rule: "none", basis_class: "expert_opinion", proposed_grade: "D",
  age_stratified_statement: "Not applicable.", notes: "Conflicts with the 10-20 convention on the low side (calls 8:1 to 10:1 normal and <8 decreased); recorded for transparency, see f03-Q09." });

// ---------- age splits ----------
const age_splits = [
  { marker_key: "egfr_creatinine_based", sex: "both", physiological_state: "none", split_at: 40,
    justification: "Age-specific outcome referents differ: at ages 18-39 the lowest-risk band is 100-110 mL/min/1.73 m2 and eGFR 90-100 is within 10% of it (HR 1.05) while 80-90 is not (HR 1.15); at 40-49 the referent is 90-100 and 80-90 is within 10% (HR 1.02); at 50-65 the referent is 80-90 (f03-E03, f03-E03b). The pooled general-population band 75-105 (f03-E02) sets the floor from 40. The reference floor (60) does not change with age.",
    evidence_ids: ["f03-E03", "f03-E03b", "f03-E02", "f03-E05"], nadir_shift_pct: null, evidence_above_70: false },
  { marker_key: "egfr_creatinine_based", sex: "both", physiological_state: "none", split_at: 85,
    justification: "Explicit 85+ policy: no optimal band, reference floor only. Creatinine-based eGFR is U-shaped with mortality in the oldest old and dominated by muscle mass (f03-E07); the relative risk of low eGFR falls with age although the absolute risk rises (f03-E04, 75 and over); healthy percentiles at 80 are 46-84 (f03-E05) and no cohort reports a lowest-risk eGFR above 85. The within-band shift from 40-84 cannot be expressed as a percentage of band width because the bands are open-ended at the top.",
    evidence_ids: ["f03-E07", "f03-E04", "f03-E05", "f03-E06"], nadir_shift_pct: null, evidence_above_70: true }
];

// ---------- v3 consistency ----------
const v3_consistency = [
  { marker_key: "creatinine", resolution: "none_needed",
    reason: "Version 3 reads creatinine with a positive log weight (lower value, younger age) down to a lower clamp equal to the optimal floor (0.8 mg/dL men, 0.6 mg/dL women, in both tiers); the rows keep those floors, so the biological age never rewards a value the score penalises: inside the optimal band the age improves while the score is flat (allowed), above the optimal band both worsen, above the reference interval version 3 refuses a result (check B2), and below the optimal floor the age is flat while the score penalises below-optimal and below-range values (documented flat segment, check X2). The creatine rule (locked, DR-2026-10-30-03) divides the model input, not the displayed value; the pooled trial rise of 0.13 mg/dL (f03-E25) is consistent with it. Input bundle: consistency_facts_vs_seed empty, known_consistency_failures empty.",
    evidence_ids: ["f03-E14", "f03-E15", "f03-E16", "f03-E17", "f03-E25"],
    flat_segments: ["creatinine below 0.8 mg/dL (men) and below 0.6 mg/dL (women): the biological age does not move (lower clamp) while the page shows below optimal or below range; client copy: 'Below 0.8 mg/dL (men) or 0.6 mg/dL (women), creatinine does not change your biological age.'", "creatinine above the reference interval (1.3 men, 1.02 women): no biological age (refusal, check B2)"] },
  { marker_key: "bun", resolution: "none_needed",
    reason: "Version 3 reads BUN with a positive log weight down to a lower clamp of 10 mg/dL in both tiers, equal to the optimal floor and to Echevarne's lower limit; above 10 a higher BUN gives an older age and the score penalises above-optimal (over 16) and above-range (over 25) values, so the two never contradict; the ceiling change 18 to 16 does not touch the model. Below 10 the age is flat while the page shows below range (documented flat segment, check X2). Input bundle: consistency_facts_vs_seed empty, known_consistency_failures empty.",
    evidence_ids: ["f03-E41", "f03-E42"],
    flat_segments: ["BUN below 10 mg/dL: the biological age does not move (lower clamp) while the page shows below range; client copy: 'Below 10 mg/dL, BUN does not change your biological age.'"] }
];

// ---------- questions ----------
const physician_questions = [
  { id: "f03-Q01", row_key: CR_M, question: "Creatinine optimal bands (men 0.8-1.1, women 0.6-0.9 mg/dL): keep them as grade C decision-table entries, or show creatinine as in range / out of range only?",
    why: "The bands bracket the lowest-mortality categories of a general-population NHANES cohort (0.8 to under 1.0 mg/dL, sexes pooled, n = 9,894, f03-E14/E14b) and an inpatient cohort (men 0.9-1.0, women 0.7-0.8, f03-E15), with low creatinine adverse in direction in f03-E16 and f03-E17; no source meets the grade A or B bar (10,000 adults, 5 years, sex-specific nadir), and creatinine alone was not an independent predictor after adjustment in f03-E18. PLAN.md section 5 lets a grade C band stand only in the grade C decision table (at most 20 entries). Version 3's lower clamp sits at the optimal floor, so removing the band changes no model input but removes the 'below optimal' muscle-mass flag.",
    evidence_ids: ["f03-E14", "f03-E14b", "f03-E15", "f03-E16", "f03-E17", "f03-E18"], options: ["keep both bands as grade C decision-table entries (recommended)", "no optimal band; in range or out of range only"] },
  { id: "f03-Q02", row_key: EG2, question: "Which equation computes the app's eGFR: CKD-EPI 2021 (race-free, today's code) or EKFC, which EFLM prefers in Europe?",
    why: "The rows are written for CKD-EPI 2021 (f03-E08). EKFC reads lower in young adults (the European reference values in f03-E05 are EKFC), which would move the 18-39 population share below the 90 floor. State rules 6.4 leave the question open.",
    evidence_ids: ["f03-E08", "f03-E05"], options: ["CKD-EPI 2021 (recommended until Echevarne's method and traceability are confirmed)", "EKFC"] },
  { id: "f03-Q03", row_key: EG1, question: "eGFR reference floor for ages 18-39: the KDIGO decision limit 60 (as written) or the age-adapted 75 used since September?",
    why: "PLAN.md section 4 allows only a named guideline decision limit to replace a laboratory interval; the KDIGO definition is 60 for over three months (f03-E01, f03-E02). The 75 floor is a proposed age-adapted threshold, not a guideline, and 60-74 at ages 18-39 now reads 'below optimal, in range' with a cystatin C and urine albumin follow-up rather than 'out of range'.",
    evidence_ids: ["f03-E01", "f03-E02", "f03-E03"], options: ["60, KDIGO (recommended)", "75, age-adapted proposal, recorded as a decision limit with the physician as its source"] },
  { id: "f03-Q04", row_key: EG2, question: "eGFR optimal floor for ages 40-84: 75 (as written), 80, or an age-adapted lower value for 65-84 (70 or 65)?",
    why: "75 is the pooled general-population lowest-risk band (f03-E02). Age-specific data put 40-49 at 80 (f03-E03b) and 50-65 at 70-80 (f03-E03); no cohort reports a nadir above 65, where the minimum-mortality eGFR is 86-90 (f03-E06) and low eGFR still carries higher absolute risk (f03-E04). The healthy median at 80 is 63-66 (f03-E05), so most healthy adults over 75 will read 'below optimal, in range'; check N1 will raise the 70-79 share as a question.",
    evidence_ids: ["f03-E02", "f03-E03", "f03-E03b", "f03-E04", "f03-E05", "f03-E06"], options: ["75 for 40-84 (recommended)", "80 for 40-64 and 75 for 65-84", "75 for 40-69 and 65 for 70-84 (population-share compromise without outcome support)"] },
  { id: "f03-Q05", row_key: EG3, question: "Confirm the 85+ policy for eGFR: reference floor 60 only, no optimal band.",
    why: "U-shaped eGFR-mortality in the oldest old and dependence on muscle mass (f03-E07); no outcome nadir above 85.",
    evidence_ids: ["f03-E07", "f03-E04"], options: ["confirm (recommended)", "extend the 40-84 band to 85+"] },
  { id: "f03-Q06", row_key: CYS, question: "Cystatin C optimal ceiling: 0.72 mg/L (evidence, as written) or 0.85 mg/L (September rows)?",
    why: "The within-10% rule on 20-year NHANES quintiles gives 0.717 (f03-E18, f03-E18b); the quartile analysis of the same survey shows risk from 0.75 (f03-E40); 0.85 sits inside a quintile with HR 1.46. But the cut-offs come from a pre-standardisation assay, standardised healthy medians are 0.78-0.79 (f03-E20), healthy values rise after 60 (f03-E34), and in NHANES fewer than 10% of adults over 60 sit at or below 0.72, so the band will carry the 'reached by a minority' label and trip check N1 at 70-79. Echevarne's assay traceability (code I0650, not mapped in the app) is unconfirmed.",
    evidence_ids: ["f03-E18", "f03-E18b", "f03-E40", "f03-E20", "f03-E34", "f03-E39"], options: ["0.72 (recommended: evidence rule)", "0.85 with a recorded reason (grade C decision-table entry)", "no optimal band until Echevarne confirms ERM-DA471 traceability"] },
  { id: "f03-Q07", row_key: BUN, question: "BUN optimal ceiling 16 mg/dL (general-population quartiles, as written) or 17 (hyperlipidaemia quintiles) or keep 18; and accept that 16-38% of healthy women aged 20-59 read 'below range' under Echevarne's lower limit 10?",
    why: "f03-E41 gives HR 1.48 from 5.71 mmol/L (16.0 mg/dL) with no excess below; f03-E42 gives HR 1.22 above 6.09 mmol/L (17.1 mg/dL) and HR 1.26 below 3.60 (10.1). The lower limit is Echevarne's and binding under the plan, but check N1 (2-15% outside) fails for young women; the September review documented the same. Echevarne could be asked for the source of its lower limit in the methods letter.",
    evidence_ids: ["f03-E41", "f03-E41b", "f03-E42", "f03-E43", "f03-E45"], options: ["16 (recommended)", "17", "18 (production, grade C table)", "ask Echevarne to justify or revise the lower limit 10"] },
  { id: "f03-Q08", row_key: URE, question: "Urea row: derive it from the Echevarne BUN interval (21-54, optimal 21-34, as written) or keep the population interval 15-54 with optimal 21-39?",
    why: "Echevarne reports BUN only; urea reaches EVA from other laboratories. Deriving from BUN keeps the two markers coherent at both ends (K1), which the former rows did not (urea 15-21 in range while BUN 7-9.8 out of range). The population lower limit 15 came from a Spanish study that no openable source could quote.",
    evidence_ids: ["f03-E23", "f03-E41"], options: ["derive from Echevarne BUN (recommended)", "keep 15-54 / 21-39 and list the low-end disagreement as an accepted K1 exception"] },
  { id: "f03-Q09", row_key: RAT, question: "BUN-to-creatinine ratio: keep it as a reference-only index with the conventional interval 10-20, or retire it from the client view?",
    why: "No laboratory interval and no outcome-based optimum; the upper limit 20 is the conventional pre-renal and dehydration threshold (f03-E49, f03-E50, f03-E51), the lower limit 10 is convention only and one review calls 8:1 to 10:1 normal (f03-E52); the only general-population study shows a U-shape with the lowest mortality at 11.43-14.64 (f03-E48). It adds little to the BUN and creatinine messages and will read out of range often in young muscular men (low) and older women (high).",
    evidence_ids: ["f03-E48", "f03-E49", "f03-E50", "f03-E51", "f03-E52"], options: ["retire from the client view (recommended)", "keep as class e with 10-20", "keep with a lower limit of 8"] },
  { id: "f03-Q10", row_key: CR_M, question: "Critical limits: creatinine 4.0 mg/dL (primary-care RCPath-based list) versus 5.0 (Spanish outpatient median) or 7.4-7.5 (inpatient lists); BUN 100 mg/dL versus 80 (urea 30 mmol/L).",
    why: "Same question as the critical-limits draft Q-CL-4 (f03-E22, f03-E23, f03-E24). An unsupervised, self-sampled client with creatinine 4.0 and no diagnosis needs same-day assessment; the hospital medians are set for known kidney failure.",
    evidence_ids: ["f03-E22", "f03-E23", "f03-E24"], options: ["creatinine 4.0 and BUN 100 (recommended)", "creatinine 5.0 and BUN 80", "creatinine 7.4 and BUN 100"] },
  { id: "f03-Q11", row_key: CR_F, question: "Echevarne's female creatinine interval has no age bands and 18% of healthy NHANES women aged 70-79 sit above 1.02 mg/dL (input bundle). Accept the 'above range' reading for older women, or ask Echevarne for age-partitioned intervals?",
    why: "Creatinine rises slowly above 70 (f03-E19; community-dwelling women over 70 run 0.7-1.1, f03-E21). The plan makes the printed interval binding; check N1 (2-15% outside) will fail for this cell. The above-range message names muscle mass, meat, exercise, creatine and trimethoprim as benign causes and sends the client to eGFR and cystatin C.",
    evidence_ids: ["f03-E19", "f03-E21"], options: ["accept as written and list under N1 (recommended until the methods letter is answered)", "ask Echevarne for age-partitioned creatinine intervals"] },
  { id: "f03-Q12", row_key: CR_M, question: "When fasting is not confirmed and the client reports cooked meat before the draw, should creatinine and eGFR be left unclassified (check P1) rather than shown with a note?",
    why: "Cooked meat raises creatinine by about a quarter for 2 to 4 hours (80.5 to 101.0 µmol/L, f03-E26) and the effect clears after 12 hours of fasting (f03-E27). The rows use 'note'; the Base Panel draw is fasting, but uploaded results may not be.",
    evidence_ids: ["f03-E26", "f03-E27"], options: ["note only (as written)", "unclassified when not fasted and meat reported"] },
  { id: "f03-Q13", row_key: CR_M, question: "Should the zone shown for creatinine use the raw laboratory value (as written) or the creatine-adjusted value that the locked rule feeds to version 3?",
    why: "The locked rule divides creatinine by 1 + 0.13 × min(g/day, 3)/3 before the model reads it (DR-2026-10-30-03; f03-E25 pooled rise 0.13 mg/dL). The lab report shows the raw value, so the zone follows the raw value and the message names creatine as a cause; a different choice would make the page disagree with the report.",
    evidence_ids: ["f03-E25"], options: ["raw value for the zone, adjusted value for version 3 only (recommended)", "adjusted value for both"] },
  { id: "f03-Q14", row_key: EG1, question: "Please confirm the KDIGO CKD threshold wording (eGFR under 60 mL/min/1.73 m2 for over three months; G3a 45-59) against the KDIGO 2024 guideline PDF, which the quote checker cannot open.",
    why: "The KDIGO 2024 record (PMID 38490803) has no abstract text and the guideline is a PDF; the threshold is quoted through a registry study that applies the KDIGO criterion verbatim (f03-E01) and through the CKD-PC meta-analysis (f03-E02), and the ERBP commentary (f03-E09) quotes the G3-G5 recommendation.",
    evidence_ids: ["f03-E01", "f03-E02", "f03-E09"], options: ["confirmed", "replace the source"] }
];

const doc = {
  schema_version: "1",
  family: "f03_kidney",
  generated_at: "2026-11-06",
  author_role: "family auditor, physician specialised in preventive and longevity medicine (AI work product; batch B01)",
  scope: {
    statement_en: "Adults aged 18 and over, not pregnant or breastfeeding, not acutely ill, with a venous serum result from Echevarne (creatinine B0003, BUN B0150, cystatin C I0650 as a candidate code) or an uploaded result from another laboratory; eGFR is computed by the app from creatinine with CKD-EPI 2021. Urea and the BUN-to-creatinine ratio reach EVA only from uploaded reports. Capillary kit results are shown as values only.",
    statement_es: "Adultos de 18 años o más, sin embarazo ni lactancia, sin enfermedad aguda, con un resultado en suero venoso de Echevarne (creatinina B0003, BUN B0150, cistatina C I0650 como código candidato) o un resultado subido de otro laboratorio; la TFGe la calcula la app a partir de la creatinina con CKD-EPI 2021. La urea y el cociente BUN/creatinina llegan a EVA solo desde informes subidos. Los resultados de kit capilar se muestran solo como valor.",
    ages_18_19_policy: "Adult rows apply from 18: Echevarne's creatinine, BUN and cystatin C intervals are printed for ages 0-999 without an adult partition, the KDIGO eGFR categories and the CKD-EPI 2021 equation apply from 18, and the outcome sources (f03-E03: 18-39) include 18-19-year-olds.",
    ages_85_plus_policy: "Creatinine, BUN, urea, cystatin C and the ratio keep their adult rows (no source partitions them at 85, and Echevarne prints none); their messages say that after 70 a low creatinine usually reflects loss of muscle and that BUN and cystatin C run higher with age. eGFR has an explicit 85+ row: KDIGO reference floor 60 only, no optimal band (f03-E07). Version 3 is not computed above 84 (signed age range).",
    treated_patients_note: "Trimethoprim, cimetidine and some newer drugs raise creatinine and lower the creatinine-based eGFR without changing true filtration (f03-E29); creatine supplements raise creatinine by about 0.13 mg/dL (f03-E25, locked creatine rule for version 3); thyroid treatment moves cystatin C opposite to creatinine and glucocorticoids raise it (f03-E33, f03-E34); a declared kidney disease refuses version 3 (check B2). Clients on treatment for kidney disease, heart failure or with a transplant are outside the scope of the optimal bands: their doctor's targets apply."
  },
  rows,
  evidence: E,
  age_splits,
  v3_consistency,
  locked_decision_questions: [],
  physician_questions,
  searches_used: 0,
  fetches_used: 100,
  unverified_sources: [],
  notes: "Method: no WebSearch call was used; every number comes from a PubMed abstract (eutils efetch), a Europe PMC record, a PMC full text (Europe PMC fullTextXML) or the NHS MFT page opened in this task, about 100 fetches in all. Sources the September reviews cited but that could not be opened through those endpoints (the Spanish urea reference study in Rev Lab Clin 2014; the NKF equation page; the SEQC critical-values PDF) are not used for any number. Decisions in short: creatinine bands kept (grade C, decision table); eGFR re-banded 18-39 / 40-84 / 85+ with the KDIGO floor 60, optimal floors 90 / 75 / none and no ceiling; cystatin C ceiling 0.85 to 0.72; BUN ceiling 18 to 16 with urea derived from the Echevarne BUN interval (21-54, optimal 21-34); ratio reclassified as class e (reference only). Critical limits: creatinine 4.0, BUN 100, urea 214 mg/dL, none for eGFR, cystatin C and the ratio. Version 3: no row change and no exception needed for creatinine or BUN (clamps equal the optimal floors; flat segments documented). Locked creatine rule: consistent with the pooled trial rise of 0.13 mg/dL; no CEO question. Pregnancy and lactation: laboratory interval only with the fixed note on every row of the family (f03-E35); menopause, hormone therapy and oral contraception move none of these markers in the sources opened (f03-E34). Known population-check consequences (N1), raised as physician questions rather than loosened: BUN below 10 in 16-38% of healthy young women (Echevarne limit), creatinine above 1.02 in 18% of healthy women 70-79 (Echevarne limit), cystatin C over 0.72 and eGFR under 75 in most healthy adults over 70 (evidence-based bands)."
};

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(doc, null, 2) + "\n");
console.log(`wrote ${OUT}: ${rows.length} rows, ${E.length} evidence records, ${physician_questions.length} physician questions`);
