// Print source context around an evidence quote. Usage: node ctx.js <qc.json> <research.json> <id> [chars]
const fs=require("fs"), path=require("path");
const qc=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
const rs=JSON.parse(fs.readFileSync(process.argv[3],"utf8"));
const id=process.argv[4]; const n=Number(process.argv[5]||500);
const r=qc.results.find(x=>x.evidence_id===id); const ev=rs.evidence.find(e=>e.id===id);
const cachePath=path.resolve("/home/user/eva-health", r.cache);
const text=fs.readFileSync(cachePath,"utf8").replace(/\s+/g," ");
const norm=s=>s.replace(/\s+/g," ").trim();
const q=norm(ev.quote);
// find by first 40 chars of the quote, loosely
let probe=q.slice(0,40); let i=text.indexOf(probe);
if(i<0){ probe=q.slice(0,20); i=text.indexOf(probe); }
if(i<0){ const w=q.split(" ").slice(0,4).join(" "); i=text.indexOf(w); probe=w; }
console.log("== "+id+" | "+r.identifier+" | cache "+r.cache+" | len "+text.length+" | probe at "+i);
if(i>=0) console.log(text.slice(Math.max(0,i-n), i+q.length+n));
