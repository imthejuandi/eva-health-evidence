// Replica of checks E1 and E2 of scripts/signoff/checks/evidence.ts for one family, run from the repository root.
// E1: validator errors on research, verify and decision files, plus per-record word count and "quote contains no number".
// E2: quote-check --offline on the three files against docs/signoff/work/sources-cache, deduplicated by evidence id.
// Usage (from the worktree root): node e1e2.js <family>
"use strict";
const path = require("path");
const fs = require("fs");
const root = process.cwd();
const family = process.argv[2];
const work = path.join(root, "docs/signoff/work");
const { validateFile } = require(path.join(root, "docs/signoff/tools/validate.js"));
const { checkFile } = require(path.join(root, "docs/signoff/tools/quote-check.js"));

(async () => {
  const files = [
    ["research", path.join(work, "research", `${family}.json`)],
    ["verify", path.join(work, "verify", `${family}.json`)],
    ["decision", path.join(work, "decisions", `${family}.json`)],
  ].filter(([, f]) => fs.existsSync(f));
  const e1 = [];
  const records = new Map();
  for (const [kind, file] of files) {
    const v = validateFile(kind, file, { workDir: work, families: path.join(work, "families.json") });
    v.errors.forEach((e) => e1.push(`${kind}: ${e}`));
    for (const ev of JSON.parse(fs.readFileSync(file, "utf8")).evidence || []) records.set(ev.id, { ...ev, _file: kind });
  }
  for (const ev of records.values()) {
    const q = String(ev.quote ?? "");
    const words = q.trim() ? q.trim().split(/\s+/).length : 0;
    if (words > 60) e1.push(`${ev.id} (${ev._file}): quote has ${words} words (max 60)`);
    if (!/\d/.test(q)) e1.push(`${ev.id} (${ev._file}): quote contains no number`);
  }
  const seen = new Set();
  let total = 0, found = 0, unopenable = 0;
  const e2 = [];
  for (const [kind, file] of files) {
    const rep = await checkFile(file, { offline: true, cacheDir: path.join(work, "sources-cache") });
    for (const r of rep.results) {
      if (seen.has(r.evidence_id)) continue;
      seen.add(r.evidence_id);
      total++;
      if (r.status === "found") found++;
      else {
        if (r.status === "unopenable") unopenable++;
        e2.push(`${r.evidence_id} (${kind}): ${r.status} in ${r.identifier} (score ${r.score})${r.error ? " " + r.error : ""}`);
      }
    }
  }
  console.log(`${family} E1: ${e1.length} problems, ${records.size} evidence records`);
  for (const x of e1) console.log(`  E1 ${x}`);
  console.log(`${family} E2: ${found} of ${total} quotes found (${((found / total) * 100).toFixed(1)}%), ${unopenable} unopenable`);
  for (const x of e2) console.log(`  E2 ${x}`);
})();
