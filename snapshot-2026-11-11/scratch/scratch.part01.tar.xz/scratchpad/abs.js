// Print a cached PubMed abstract compactly (drop author affiliations). Usage: node abs.js <qc.json> <id>...
const fs=require("fs"),path=require("path");
const qc=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
for (const id of process.argv.slice(3)) {
  const r=qc.results.find(x=>x.evidence_id===id);
  let t=fs.readFileSync(path.resolve("/home/user/eva-health",r.cache),"utf8");
  t=t.replace(/Author information:[\s\S]*?\n\n/,"[affiliations dropped]\n\n").replace(/\n{2,}/g,"\n").replace(/[ \t]+/g," ");
  console.log("######## "+id+" "+r.identifier+"\n"+t.slice(0,4000)+"\n");
}
