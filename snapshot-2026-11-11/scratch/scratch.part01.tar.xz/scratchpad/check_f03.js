#!/usr/bin/env node
// Offline self-checks for the research file: quotes vs cached source texts, banned wording, message numbers.
"use strict";
const fs = require("fs");
const path = require("path");
const { matchQuote, statusForMatch, wordCount } = require("/home/user/eva-health/docs/signoff/tools/lib/text-normalise");
const { canonicalIdentifier } = require("/home/user/eva-health/docs/signoff/tools/lib/sources");

const FILE = "/home/user/eva-health/docs/signoff/work/research/f03_kidney.json";
const LIT = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/lit";
const doc = JSON.parse(fs.readFileSync(FILE, "utf8"));

function sourceText(identifier) {
  const id = canonicalIdentifier(identifier);
  if (id.type === "pmid") { const f = path.join(LIT, `pmid_${id.value}.txt`); return fs.existsSync(f) ? fs.readFileSync(f, "utf8") : null; }
  if (id.type === "pmcid") { const f = path.join(LIT, `${id.value}.txt`); return fs.existsSync(f) ? fs.readFileSync(f, "utf8") : null; }
  if (id.type === "url") { const f = path.join(LIT, "mft.txt"); return fs.existsSync(f) ? fs.readFileSync(f, "utf8") : null; }
  return null;
}

let bad = 0;
console.log("=== quotes ===");
for (const ev of doc.evidence) {
  const n = wordCount(ev.quote);
  const text = sourceText(ev.identifier);
  if (!text) { console.log(`${ev.id}: NO CACHED TEXT (${ev.identifier.type}:${ev.identifier.value})`); bad++; continue; }
  const m = matchQuote(ev.quote, text);
  const st = statusForMatch(m);
  if (st !== "found" || n > 60) { bad++; console.log(`${ev.id}: ${st} score=${m.score} exact=${m.exact} words=${n} missing=${JSON.stringify(m.missing_numbers)}\n   snippet: ${m.snippet.slice(0, 300)}`); }
  else console.log(`${ev.id}: found exact=${m.exact} words=${n}`);
}

// banned wording (from wording-rules.md, Part III)
const md = fs.readFileSync("/home/user/eva-health/docs/signoff/work/governance/wording-rules.md", "utf8");
const block = md.match(/```json banned_terms\n([\s\S]*?)\n```/)[1];
const banned = JSON.parse(block);
function scan(lang, zone, text) {
  const cfg = banned[lang];
  let t = text;
  for (const a of cfg.any.allow || []) t = t.split(a).join(" ");
  const hits = [];
  for (const tier of ["any", "non_critical"]) {
    if (tier === "non_critical" && (zone === "critical_low" || zone === "critical_high")) continue;
    for (const term of cfg[tier].terms) { if (t.toLowerCase().includes(term.toLowerCase())) hits.push(`${tier} term '${term}'`); }
    for (const re of cfg[tier].regex) { if (new RegExp(re, "i").test(t)) hits.push(`${tier} regex ${re}`); }
  }
  return hits;
}
console.log("=== wording ===");
let whits = 0;
for (const r of doc.rows) {
  const key = `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
  for (const lang of ["en", "es"]) {
    for (const [zone, text] of Object.entries(r.messages[lang])) {
      const hits = scan(lang, zone, text);
      if (hits.length) { whits++; console.log(`${key} ${lang} ${zone}: ${hits.join("; ")}`); }
      const closer = lang === "en" ? banned.en.required.out_of_range_closer : banned.es.required.out_of_range_closer;
      const crit = lang === "en" ? banned.en.required.critical_closer : banned.es.required.critical_closer;
      if (["below_range", "above_range"].includes(zone) && !text.endsWith(closer)) { whits++; console.log(`${key} ${lang} ${zone}: missing out-of-range closer`); }
      if (["critical_low", "critical_high"].includes(zone) && !text.endsWith(crit)) { whits++; console.log(`${key} ${lang} ${zone}: missing critical closer`); }
    }
    for (const pr of r.pre_analytical) { const hits = scan(lang, "note", pr[`text_${lang}`]); if (hits.length) { whits++; console.log(`${key} ${lang} pre_analytical ${pr.rule}: ${hits.join("; ")}`); } }
    for (const a of r.action_limits) { const hits = scan(lang, "note", a[`follow_up_${lang}`]); if (hits.length) { whits++; console.log(`${key} ${lang} action ${a.name}: ${hits.join("; ")}`); } }
  }
}
console.log(`wording hits: ${whits}`);

// numbers in messages (check M4)
console.log("=== message numbers ===");
let nhits = 0;
for (const r of doc.rows) {
  const key = `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
  const bounds = [r.reference_low, r.reference_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high].filter((x) => x != null);
  const allowed = new Set([...bounds, ...r.explanatory_numbers].map(Number));
  for (const lang of ["en", "es"]) {
    for (const [zone, text] of Object.entries(r.messages[lang])) {
      let t = text;
      if (lang === "es") t = t.replace(/(\d),(\d)/g, "$1.$2");
      t = t.replace(/CKD-EPI 2021/g, "CKD-EPI 2021"); // kept as a number, must be in explanatory list
      const nums = (t.match(/\d+(?:\.\d+)?/g) || []).map(Number);
      const missing = nums.filter((n) => !allowed.has(n));
      if (missing.length) { nhits++; console.log(`${key} ${lang} ${zone}: numbers not in bounds/explanatory: ${[...new Set(missing)].join(", ")}`); }
    }
  }
}
console.log(`number hits: ${nhits}`);
console.log(`quote problems: ${bad}`);
