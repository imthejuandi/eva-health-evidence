export const meta = {
  name: 'fable-approval-rereview-2',
  description: 'Fable 5.2 finishes the second review: challenges the runner files and app routes, reviews and challenges data.ts (C-12, C-11), messages.ts and the validator rule (C-27), the fixed compile-sources.js, its test and the loop file, with an arbiter on disagreement',
  phases: [
    { title: 'Review', detail: 'Fable 5.2 reviewer for the files changed after the second review (data.ts, messages.ts, row-checks.js, validate.js, schema.test.js, compile-sources.js, its test, ws1-batch.js)' },
    { title: 'Challenge', detail: 'adversarial Fable 5.2 challenger per area, against the stored or new reviewer result' },
    { title: 'Arbitrate', detail: 'Fable 5.2 arbiter on each file where reviewer and challenger disagree' },
  ],
}

// args: { repo, scratch, ruling, rereview, areas: [{ key, name, context, files: [{ file, sha256 }], stored_review: <per-file verdicts or null>, stored_review_file?: <path of the full stored review> }] }
const A = args
const MODEL = 'claude-fable-5-2'
const EFFORT = 'max'
const REPO = A.repo
const SCR = A.scratch

const FINDING = { type: 'object', properties: { summary: { type: 'string' }, evidence: { type: 'string' }, smallest_fix: { type: 'string' } }, required: ['summary', 'evidence', 'smallest_fix'] }
const TESTS = { type: 'array', items: { type: 'object', properties: { command: { type: 'string' }, outcome: { type: 'string' } }, required: ['command', 'outcome'] } }
const FILE_VERDICT = {
  type: 'object',
  properties: {
    file: { type: 'string' },
    sha256: { type: 'string' },
    sha256_matches: { type: 'boolean' },
    recommendation: { type: 'string', enum: ['approve', 'reject'] },
    required_change_done: { type: 'string', enum: ['yes', 'partly', 'no', 'not applicable'] },
    out_of_scope_edits: { type: 'array', items: { type: 'string' } },
    plain_rationale: { type: 'string' },
    blocking_findings: { type: 'array', items: FINDING },
    notes: { type: 'array', items: { type: 'string' } },
  },
  required: ['file', 'sha256', 'sha256_matches', 'recommendation', 'required_change_done', 'out_of_scope_edits', 'plain_rationale', 'blocking_findings', 'notes'],
}
const REVIEW = { type: 'object', properties: { area: { type: 'string' }, files: { type: 'array', items: FILE_VERDICT }, tests_run: TESTS }, required: ['area', 'files', 'tests_run'] }
const ARBITER = {
  type: 'object',
  properties: { file: { type: 'string' }, sha256: { type: 'string' }, recommendation: { type: 'string', enum: ['approve', 'reject'] }, plain_rationale: { type: 'string' }, standing_findings: { type: 'array', items: FINDING } },
  required: ['file', 'sha256', 'recommendation', 'plain_rationale', 'standing_findings'],
}

const BACKGROUND = [
  'Background.',
  '- EVA is a preventive-health app. Before launch, a licensed physician will review and sign its optimal biomarker ranges, its biological age model and its score. The Doctor Sign-off Readiness Test (DSRT), docs/signoff/ACCEPTANCE-TEST.md, is the acceptance test the material must pass first; the runner (scripts/signoff/) and the tools (docs/signoff/tools/) grade and compile it. These files were hashed at round 0 (baseline commit 7602f9d); check G1 fails while a hashed file differs without a CEO approval at its sha256.',
  `- The CEO instructed that Fable 5.2 recommends on the changed files and that its recommendations serve as the approval. A Fable 5.2 ruling of 10 November (${A.ruling}; readable summary fable-approval-review.md beside it) approved 11 files and required exact changes to 11 others; decisions CEO-1 to CEO-17 are in docs/signoff/work/governance/central-fix-decisions.md. A second Fable 5.2 review (${A.rereview}) approved 5 of the changed files, rejected compile-sources.js (an entry the compile adds lost its 'signoff' mark on a later compile) and rejected the loop file docs/signoff/workflows/ws1-batch.js (exit status 1 counted as the notes stop even when the compile did not start); its challengers for the runner files and the app routes did not run, because the Fable models ran out of usage credits. The orchestrator has since made the fixes the second review named.`,
  `- Work in the repository ${REPO} (branch claude/wonderful-meitner-l4g7p5). Your verdict decides whether each file is approved at its sha256, so it carries the CEO's authority: be exact and independent. Batch runs of the programme write under docs/signoff/work/; ignore those files.`,
].join('\n')

const STANDARD = [
  'What to decide for each file of your area:',
  '1. Required change: is the change required for this file (its required_change in the ruling, and for the files changed after the second review the fix that review named) made exactly and correctly? Quote the requirement and point to the lines that meet it.',
  '2. Nothing else: list every edit the requirement does not call for (out_of_scope_edits); an edit that serves the requirement directly is in scope.',
  '3. The approval standard holds for the whole file: no check passes more easily than the specification allows, no published text that nobody checked, correct on edge cases, no hidden way to skip a check.',
  'Recommend approve only when all three hold. A cosmetic flaw is a note. When you reject, give the smallest change that would make the file approvable.',
].join('\n')

const RULES = (dir) => [
  'How to work.',
  `- Diff against round 0: \`git -C ${REPO} diff 7602f9d -- <file>\`, and against the version the ruling reviewed: \`git -C ${REPO} diff 4d5f830 -- <file>\`; \`git -C ${REPO} log --oneline -- <file>\` shows the commits since. Check the sha256 with \`sha256sum ${REPO}/<file>\`; if it differs from the one listed, set sha256_matches false and reject.`,
  `- Run the tests from ${REPO}: \`node --test docs/signoff/tools/test/*.test.js\`, \`npx vitest run src/lib/signoff\`, and for app files \`npx vitest run\` and \`npx tsc --noEmit\`. Run the tools only into ${dir}/ (for example \`node docs/signoff/tools/compile.js --out-dir ${dir}/c\`).`,
  `- Read-only: do not modify, create or delete any file in the repository, and run no git command that changes state. Scratch files only under ${dir}/ (mkdir -p).`,
  '- plain_rationale: two to five sentences in plain words a CEO without a coding background can follow; technical evidence in findings, with file:line references.',
].join('\n')

const fileList = (area) => area.files.map((f) => `- ${f.file} (sha256 ${f.sha256})`).join('\n')

function reviewPrompt(area) {
  return [`You are a Fable 5.2 reviewer of changed files of EVA's acceptance test, area ${area.name}.`, '', BACKGROUND, '', `Files of your area:\n${fileList(area)}`, area.context ? `\nContext: ${area.context}` : '', '', STANDARD, '', RULES(`${SCR}/${area.key}`), '', 'Reply with the structured result: one entry per file listed, in the same order, with its sha256.'].join('\n')
}
function challengePrompt(area, review) {
  return [
    `You are the adversarial challenger for area ${area.name} of the review of changed files of EVA's acceptance test. A reviewer gave the verdicts below. Try to overturn them: for each file it approves, hunt for a required change not made or made wrongly, an out-of-scope edit it missed, or a way a check now passes more easily or a published text goes unchecked; for each blocking finding it raised, try to refute it with evidence. A finding needs evidence: file:line, a command and its output, or a concrete input and the wrong output. Agree only after your own search finds nothing.`,
    '', BACKGROUND, '', `Files of your area:\n${fileList(area)}`, area.context ? `\nContext: ${area.context}` : '', '', STANDARD, '', RULES(`${SCR}/${area.key}-challenge`), '',
    area.stored_review_file ? `The reviewer's full result is in ${area.stored_review_file}: read it first. Its verdicts per file: ${JSON.stringify(review.files)}` : `The reviewer's result:\n${JSON.stringify(review, null, 1)}`, '', 'Reply with the structured result: one entry per file listed, in the same order, with its sha256 and your own recommendation.',
  ].join('\n')
}
function arbiterPrompt(area, file, r, c) {
  return [
    `You arbitrate one file: ${file.file} (sha256 ${file.sha256}), area ${area.name}. The reviewer and the challenger disagree. Check every disputed point yourself and rule approve or reject; your ruling is recorded as the CEO's decision on this file.`,
    '', BACKGROUND, area.context ? `\nContext: ${area.context}` : '', '', STANDARD, '', RULES(`${SCR}/${area.key}-arbiter`), '',
    area.stored_review_file ? `The reviewer's verdict on this file: ${JSON.stringify(r)}; its full result is in ${area.stored_review_file}.` : `The reviewer:\n${JSON.stringify(r, null, 1)}`, '', `The challenger:\n${JSON.stringify(c, null, 1)}`, '', 'Reply with the structured result.',
  ].join('\n')
}

const out = await pipeline(
  A.areas,
  (area) => (area.stored_review ? Promise.resolve(area.stored_review) : agent(reviewPrompt(area), { label: `review ${area.key}`, phase: 'Review', schema: REVIEW, model: MODEL, effort: EFFORT })),
  (review, area) => (review ? agent(challengePrompt(area, review), { label: `challenge ${area.key}`, phase: 'Challenge', schema: REVIEW, model: MODEL, effort: EFFORT }).then((ch) => ({ review, ch })) : { review: null, ch: null }),
  async (rc, area) => {
    const finals = []
    for (const f of area.files) {
      const r = rc.review && rc.review.files.find((x) => x.file === f.file)
      const c = rc.ch && rc.ch.files.find((x) => x.file === f.file)
      if (!r || !c) { finals.push({ file: f.file, sha256: f.sha256, verdict: 'reject', basis: 'incomplete review', reviewer: r || null, challenger: c || null }); continue }
      if (r.recommendation === c.recommendation && r.sha256_matches && c.sha256_matches) { finals.push({ file: f.file, sha256: f.sha256, verdict: r.recommendation, basis: 'reviewer and challenger agree', reviewer: r, challenger: c }); continue }
      const arb = await agent(arbiterPrompt(area, f, r, c), { label: `arbiter ${f.file.split('/').pop()}`, phase: 'Arbitrate', schema: ARBITER, model: MODEL, effort: EFFORT })
      finals.push({ file: f.file, sha256: f.sha256, verdict: arb ? arb.recommendation : 'reject', basis: arb ? 'arbiter' : 'arbiter returned nothing', reviewer: r, challenger: c, arbiter: arb })
    }
    return { area: area.key, review: rc.review, challenge: rc.ch, files: finals }
  },
)
const files = out.filter(Boolean).flatMap((a) => a.files)
log(`verdicts: ${files.map((f) => `${f.file.split('/').pop()} ${f.verdict} (${f.basis})`).join('; ')}`)
return { files: files.map((f) => ({ file: f.file, sha256: f.sha256, verdict: f.verdict, basis: f.basis })), areas: out }
