import fs from "node:fs";
import { computeReferenceBA } from "@/lib/biomarkers/biological-age-kdm";
import { bioAgeV3Record } from "@/lib/biomarkers/biological-age-v3-adapter";
import { getCanonicalUnit } from "@/lib/biomarkers/canonical-units";
const BASE_KEYS = ["albumin", "creatinine", "bun", "uric_acid", "alp", "ggt", "total_cholesterol", "hdl_cholesterol", "triglycerides", "hs_crp", "apolipoprotein_b_apob", "alt", "fructosamine"];
const { panels } = JSON.parse(fs.readFileSync("docs/biomarker-evidence/longevity/base-panel/panels.json", "utf8"));
const NOW = new Date("2026-10-30T12:00:00Z");
const fmt = (x: number) => `${x >= 0 ? "+" : ""}${x.toFixed(2)}`;
for (const p of panels as Array<{ label: string; sex: "male" | "female"; age: number; values: Record<string, number> }>) {
  const all = { ...p.values, fructosamine: 200 };
  const v = Object.fromEntries(BASE_KEYS.filter((k) => k in all).map((k) => [k, all[k]]));
  const c0 = v.creatinine;
  const ref = (c: number, dose: string | null) => computeReferenceBA(Object.entries({ ...v, creatinine: c }).map(([code, value]) => ({ code, value })), p.sex, p.age, { supplements: dose ? [{ key: "creatine", dose }] : null })?.BA ?? NaN;
  const v3 = (c: number, dose: string | null) => bioAgeV3Record({ values: Object.entries({ ...v, creatinine: c }).map(([k, x]) => ({ biomarker_key: k, value: x, unit: getCanonicalUnit(k) })), drawDate: "2026-10-01", otherResults: [], dateOfBirth: `${2026 - p.age}-01-01`, sex: p.sex, conditionKeys: [], now: NOW, supplements: dose ? [{ key: "creatine", dose }] : null }).ba ?? NaN;
  const r0 = ref(c0, null), w0 = v3(c0, null);
  console.log(`${p.label.padEnd(60)} cr ${c0} | 13%: ${fmt(ref(c0 * 1.13, null) - r0)} v3 ${fmt(v3(c0 * 1.13, null) - w0)} | +0.13: ${fmt(ref(c0 + 0.13, null) - r0)} v3 ${fmt(v3(c0 + 0.13, null) - w0)} | +0.13 decl: ${fmt(ref(c0 + 0.13, "5 g") - r0)} v3 ${fmt(v3(c0 + 0.13, "5 g") - w0)} | 2g loaded: ${fmt(ref(c0 * 1.13, "2 g") - r0)} v3 ${fmt(v3(c0 * 1.13, "2 g") - w0)} | no rise 5g: ${fmt(ref(c0, "5 g") - r0)} v3 ${fmt(v3(c0, "5 g") - w0)}`);
}
