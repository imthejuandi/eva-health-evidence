// Builds round 4 of docs/signoff/work/decisions/f03_kidney.json from the round-3 file.
// Usage: node build.js <repo-root>
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const root = process.argv[2];
const decFile = path.join(root, "docs/signoff/work/decisions/f03_kidney.json");
const verFile = path.join(root, "docs/signoff/work/verify/f03_kidney.json");
const d = JSON.parse(fs.readFileSync(decFile, "utf8"));
if (d.round !== 3) throw new Error("expected the round-3 file as the starting point, found round " + d.round);

d.round = 4;
d.decided_at = "2026-11-08";
d.verify_sha256 = crypto.createHash("sha256").update(fs.readFileSync(verFile)).digest("hex");
d.fixer_role = "physician fixer, round 4 (reopened batch B01; AI work product for review by the licensed physician)";

const row = (k, sex, age) => {
  const r = d.final_rows.find((x) => x.marker_key === k && x.sex === sex && x.age_group === age);
  if (!r) throw new Error("row not found " + k + sex + age);
  return r;
};
const rk = (r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
const replaceIn = (s, from, to) => {
  if (!s.includes(from)) throw new Error("text not found: " + from.slice(0, 80));
  return s.replace(from, to);
};
const changes = [];
const ch = (r, field, from, to, direction, reason, evidence_ids = [], issue_ids = []) =>
  changes.push({ row_key: rk(r), field, from, to, direction, reason, evidence_ids, issue_ids });

const SAFETY_EN = "This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.";
const SAFETY_ES = "Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.";

// ───────────────────────── BUN ─────────────────────────
const bun = row("bun", "both", "All Adults");
bun.optimal_low = null;
ch(bun, "optimal_low", 10, null, "loosen",
  "The optimal floor 10 mg/dL equalled Echevarne's reference floor 10 mg/dL and rested only on that laboratory interval, which PLAN.md section 4 does not allow for an optimal bound ('An optimal bound may not rest only on a laboratory interval'). The outcome source has no floor: in Hong 2023 the lowest quartile (<3.57 mmol/L = <10.0 mg/dL, f03-E41b) is the reference category and quartiles 2 and 3 sit within 10% of it (all-cause HR 1.06 and 1.05, f03-E41; both records verifier grade B). Removing the bound changes no value's zone: below 10 mg/dL a value is below the reference interval either way (classifyZone checks the reference limits first), so the optimal zone stays 10-16 mg/dL. Same form as the albumin row's optimal_high null.",
  ["f03-E41", "f03-E41b"],
  ["f03_kidney--E3--bun.both.All_Adults.none--low", "f03_kidney--definition:optimal_band--bun.both.All_Adults.none--low", "f03_kidney--definition:basis_of_each_bound--bun.both.All_Adults.none--low"]);

bun.critical_none_reason = "none, because no opened list carries a low BUN or urea limit (docs/signoff/work/governance/critical-limits.json, entry bun, critical_low_none_because); this covers the low side only, the high side carries the critical limit 100 mg/dL.";
bun.critical_none_reason_es = "ninguno, porque ninguna lista consultada recoge un límite bajo de BUN o de urea (docs/signoff/work/governance/critical-limits.json, entrada bun, critical_low_none_because); vale solo para el lado bajo, el lado alto lleva el límite crítico de 100 mg/dL.";
ch(bun, "critical_none_reason", null, bun.critical_none_reason, "neutral",
  "Ledger L1 (judge J5): the row had no 'none, because' for its empty low critical limit while the critical-limits table gives one. Copied from the table; no bound changes.",
  [], ["f03_kidney--L1--bun.both.All_Adults.none--low"]);

const bunEn = bun.messages.en, bunEs = bun.messages.es;
const oldBun = { b: bunEn.below_range, o: bunEn.optimal, a: bunEn.above_optimal };
bunEn.below_range = "Your BUN is below the laboratory's reference interval (10 to 25 mg/dL). This is common and usually dietary, from a low protein intake or a large fluid intake; less often it reflects liver disease. Repeat the test in 2 to 4 weeks if you have no similar earlier result. Discuss it with your doctor at your next check-up. " + SAFETY_EN;
bunEs.below_range = "Tu BUN está por debajo del intervalo de referencia del laboratorio (10 a 25 mg/dL). Es frecuente y suele deberse a la dieta, por una baja ingesta de proteínas o una alta ingesta de líquidos; con menos frecuencia refleja una enfermedad del hígado. Conviene repetir el análisis en 2 a 4 semanas si no tienes un resultado previo parecido. Coméntalo con tu médico en tu próxima revisión. " + SAFETY_ES;
bunEn.optimal = "Your BUN is in EVA's optimal band, from the laboratory's lower limit of 10 up to 16 mg/dL. The band comes from one large population study and the evidence is limited, so EVA's doctor reviews it. BUN reflects protein intake and hydration as well as kidney clearance.";
bunEs.optimal = "Tu BUN está en la banda óptima de EVA, desde el límite inferior del laboratorio, 10, hasta 16 mg/dL. La banda procede de un solo gran estudio de población y la evidencia es limitada, así que el médico de EVA la revisa. El BUN refleja la ingesta de proteínas y la hidratación además de la depuración renal.";
bunEn.above_optimal = replaceIn(bunEn.above_optimal, "but above EVA's optimal band of 10 to 16 mg/dL.", "but above EVA's optimal ceiling of 16 mg/dL.");
bunEs.above_optimal = replaceIn(bunEs.above_optimal, "pero por encima de la banda óptima de EVA, de 10 a 16 mg/dL.", "pero por encima del techo óptimo de EVA, 16 mg/dL.");
ch(bun, "messages", "below-range text without a benign-cause word the M2 heuristic reads and with an outcome claim; optimal text 'linked to more favourable long-term outcomes'; above-optimal text naming the floor 10 as an optimal bound",
  "below-range text says a low value is common and usually dietary (EN 'common', ES 'frecuente'); the long-term outcome sentence is removed from the below-range and optimal texts; optimal and above-optimal texts describe the band as the laboratory's floor 10 up to the ceiling 16 mg/dL",
  "neutral",
  "Check M2 (script, round 3: below-range EN and ES lack a benign-cause element) and wording-rules.md section 3.1: the outcome behind the BUN band is all-cause mortality (f03-E41), which client text omits with no substitute, so 'more favourable long-term outcomes' and 'not linked to worse long-term outcomes' go (judge J1, ledger M3). Diet and fluid intake are the benign causes the row already named.",
  ["f03-E41", "f03-E25"],
  ["f03_kidney--M2--bun.both.All_Adults.critical_low.en--none", "f03_kidney--M2--bun.both.All_Adults.critical_low.es--none", "f03_kidney--M3--bun.both.All_Adults.none--none"]);

bun.clinical_notes_en = "Blood urea nitrogen, a waste product the kidneys filter out. Levels reflect kidney function but also shift with hydration and protein intake. BUN and urea are the same test reported two ways: urea = BUN × 2.14. EVA derives its urea interval from the laboratory's BUN interval, so the same blood normally falls in the same zone on both.";
bun.clinical_notes_es = "Nitrógeno ureico en sangre, un producto de desecho que los riñones filtran. Sus niveles reflejan la función renal, pero también varían con la hidratación y la ingesta de proteínas. El BUN y la urea son la misma prueba expresada de dos formas: urea = BUN × 2,14. EVA calcula su intervalo de la urea a partir del intervalo del BUN del laboratorio, así que la misma sangre queda normalmente en la misma zona en los dos.";
if (!bun.explanatory_numbers.includes(2.14)) bun.explanatory_numbers.push(2.14);
ch(bun, "clinical_notes_en, clinical_notes_es", "seed Clinical_Notes (T31/T32): 'a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range'",
  "new notes in both languages: urea = BUN × 2.14 and the urea interval derived from the BUN interval, so the same blood normally falls in the same zone",
  "neutral",
  "Ledger M4 (judge J1): the seed note quoted 7 and a urea interval starting at 15 mg/dL, while the urea row starts at 21 mg/dL (BUN 10 x 2.14), so the same blood is below range on both rows. Known issue C-10: rows now take clinical_notes_en and clinical_notes_es. 2.14 added to explanatory_numbers (check M4).",
  [], ["f03_kidney--M4--bun.both.All_Adults.none--low"]);

bun.method_note = replaceIn(bun.method_note, "Version 3 marker: lower clamp 10 mg/dL = optimal floor = Echevarne lower limit;", "Version 3 marker: lower clamp 10 mg/dL = Echevarne lower limit (the row sets no optimal floor of its own from round 4, because a floor equal to the laboratory limit has no outcome basis);");
bun.rcv.narrow_band_justification = replaceIn(bun.rcv.narrow_band_justification, "The optimal band 10-16 mg/dL is 37.5% of its upper bound", "The reachable optimal zone, from the reference floor 10 to the optimal ceiling 16 mg/dL, is 37.5% of its upper bound");
bun.notes = bun.notes + " Round 4: optimal floor removed (it equalled Echevarne's 10 mg/dL and had no outcome basis; f03-E41b puts the lowest-risk quartile below 10.0 mg/dL); no value changes zone. Sex split (check E1, judge J3): Hong 2023 tested interactions and reports 'P for interaction is only significant in the sex hierarchy', with a stronger association in women (f03-D10, f03-D05), but its quartile cut-offs are pooled across sexes and its sex-stratified hazards appear only in a figure, so no sex-specific edge can be read; Echevarne prints one interval. No sex split; the record is f03-D10. Low critical side: 'none, because' copied from critical-limits.json (ledger L1, J5). Client texts carry no outcome claim (wording-rules.md 3.1).";
ch(bun, "notes", "no sex-split record; optimal floor described as Echevarne's limit", "sex-split record f03-D10 (no split, with reason); floor removal and critical none-reason recorded", "neutral",
  "Ledger E1 (judge J3): the row had no sex-split record although the outcome source reports a significant interaction by sex only. PLAN.md section 5 asks for one record per age or sex split; f03-D10 is that record (Hong 2023 full text, PMC9865447, opened in this task).",
  ["f03-D10", "f03-D05"], ["f03_kidney--E1--bun.both.All_Adults.none--none"]);

// ───────────────────────── UREA ─────────────────────────
const urea = row("urea", "both", "All Adults");
urea.optimal_low = null;
ch(urea, "optimal_low", 21, null, "loosen",
  "Mirror of the BUN row: the optimal floor 21 mg/dL equalled the reference floor 21 mg/dL (Echevarne BUN 10 x 2.14) and rested only on the laboratory interval (PLAN.md section 4); the BUN outcome source has its lowest-risk quartile below 3.57 mmol/L (urea below 21.4 mg/dL) (f03-E41, f03-E41b, verifier grade B). No value changes zone.",
  ["f03-E41", "f03-E41b"],
  ["f03_kidney--E3--bun.both.All_Adults.none--low"]);
urea.critical_none_reason = "none, because no opened list carries a low BUN or urea limit (docs/signoff/work/governance/critical-limits.json, entry bun, critical_low_none_because); this covers the low side only, the high side carries the critical limit 214 mg/dL (BUN 100 mg/dL).";
urea.critical_none_reason_es = "ninguno, porque ninguna lista consultada recoge un límite bajo de BUN o de urea (docs/signoff/work/governance/critical-limits.json, entrada bun, critical_low_none_because); vale solo para el lado bajo, el lado alto lleva el límite crítico de 214 mg/dL (BUN 100 mg/dL).";
ch(urea, "critical_none_reason", null, urea.critical_none_reason, "neutral",
  "As the BUN row (ledger L1, judge J5): the empty low critical limit now carries the critical-limits table's 'none, because'.", [], []);
const uEn = urea.messages.en, uEs = urea.messages.es;
uEn.below_range = "Your urea is below the laboratory's reference interval (21 to 54 mg/dL). This is common and usually dietary, from a low protein intake or a large fluid intake; less often it reflects liver disease. Repeat the test in 2 to 4 weeks if you have no similar earlier result. Discuss it with your doctor at your next check-up. " + SAFETY_EN;
uEs.below_range = "Tu urea está por debajo del intervalo de referencia del laboratorio (21 a 54 mg/dL). Es frecuente y suele deberse a la dieta, por una baja ingesta de proteínas o una alta ingesta de líquidos; con menos frecuencia refleja una enfermedad del hígado. Conviene repetir el análisis en 2 a 4 semanas si no tienes un resultado previo parecido. Coméntalo con tu médico en tu próxima revisión. " + SAFETY_ES;
uEn.optimal = "Your urea is in EVA's optimal band, from the laboratory's lower limit of 21 up to 34 mg/dL. The band comes from one large population study and the evidence is limited, so EVA's doctor reviews it. Urea reflects protein intake and hydration as well as kidney clearance. This marker does not count toward the score.";
uEs.optimal = "Tu urea está en la banda óptima de EVA, desde el límite inferior del laboratorio, 21, hasta 34 mg/dL. La banda procede de un solo gran estudio de población y la evidencia es limitada, así que el médico de EVA la revisa. La urea refleja la ingesta de proteínas y la hidratación además de la depuración renal. Este marcador no entra en la puntuación.";
uEn.above_optimal = replaceIn(uEn.above_optimal, "but above EVA's optimal band of 21 to 34 mg/dL.", "but above EVA's optimal ceiling of 34 mg/dL.");
uEs.above_optimal = replaceIn(uEs.above_optimal, "pero por encima de la banda óptima de EVA, de 21 a 34 mg/dL.", "pero por encima del techo óptimo de EVA, 34 mg/dL.");
ch(urea, "messages", "below-range text without a benign-cause word and with an outcome claim; optimal text 'linked to more favourable long-term outcomes'",
  "as the BUN row: 'common' / 'frecuente', no long-term outcome sentence, band described as the laboratory's floor 21 up to 34 mg/dL",
  "neutral",
  "Check M2 (script, round 3) and wording-rules.md section 3.1 (mortality omitted with no substitute; judge J1, ledger M3).",
  ["f03-E41"],
  ["f03_kidney--M2--urea.both.All_Adults.critical_low.en--none", "f03_kidney--M2--urea.both.All_Adults.critical_low.es--none"]);
urea.clinical_notes_en = "Urea is the whole molecule the kidneys filter out as the end-product of protein metabolism. European laboratories report urea directly; U.S. laboratories usually report only its nitrogen fraction, BUN. Levels reflect kidney clearance but also shift with hydration and protein intake. EVA's urea interval, 21 to 54 mg/dL, is the laboratory's BUN interval (10 to 25 mg/dL) multiplied by 2.14, so urea and BUN normally fall in the same zone. A report from another laboratory may print a slightly different interval.";
urea.clinical_notes_es = "La urea es la molécula completa que los riñones filtran como producto final del metabolismo de las proteínas. Los laboratorios europeos informan la urea directamente; los estadounidenses suelen informar solo su fracción de nitrógeno, el BUN. Sus niveles reflejan la depuración renal, pero también varían con la hidratación y la ingesta de proteínas. El intervalo de la urea de EVA, de 21 a 54 mg/dL, es el intervalo del BUN del laboratorio (10 a 25 mg/dL) multiplicado por 2,14, así que la urea y el BUN quedan normalmente en la misma zona. El informe de otro laboratorio puede imprimir un intervalo algo distinto.";
for (const n of [2.14, 10, 25]) if (!urea.explanatory_numbers.includes(n)) urea.explanatory_numbers.push(n);
ch(urea, "clinical_notes_en, clinical_notes_es", "seed Clinical_Notes (T41/T42): interval said to start at 15 mg/dL; 'lower all-cause mortality' / 'menor mortalidad por todas las causas'; 'Longevity-optimal ranges'",
  "new notes in both languages: the 21-54 mg/dL interval derived from BUN 10-25 x 2.14, no outcome claim, another laboratory's interval may differ",
  "neutral",
  "Ledger M3 (judge J1: 'mortalidad' is banned in client text, wording-rules.md 3.1) and M4 (judge J1: 15 is not the row's floor, which is 21). Known issue C-10. 2.14, 10 and 25 added to explanatory_numbers (check M4).",
  [], ["f03_kidney--M3--urea.both.All_Adults.none--none", "f03_kidney--M4--urea.both.All_Adults.none--low"]);
urea.rcv.narrow_band_justification = replaceIn(urea.rcv.narrow_band_justification, "The optimal band 21-34 mg/dL is 38.2% of its upper bound", "The reachable optimal zone, from the reference floor 21 to the optimal ceiling 34 mg/dL, is 38.2% of its upper bound");
urea.notes = urea.notes + " Round 4: optimal floor removed as on the BUN row (no outcome basis; no value changes zone); low critical side 'none, because' copied from critical-limits.json; clinical notes now in clinical_notes_en and clinical_notes_es (the replacement text formerly carried in the decision notes). Uploaded urea is classified against EVA's derived 21-54 mg/dL, not the uploading laboratory's printed interval, which the app does not store: physician question f03-Q08 (ledger D3) stays open, because storing and using the uploading laboratory's interval is an app change.";

// ───────────────────────── CREATININE ─────────────────────────
for (const sex of ["male", "female"]) {
  const c = row("creatinine", sex, "All Adults");
  const [lo, hi] = sex === "male" ? ["0.7", "1.3"] : ["0.55", "1.02"];
  const [loEs, hiEs] = [lo.replace(".", ","), hi.replace(".", ",")];
  c.critical_none_reason = "none, because no opened list carries a low creatinine limit; a low creatinine is a plausibility or muscle-mass question, not an emergency (docs/signoff/work/governance/critical-limits.json, entry creatinine, critical_low_none_because). This covers the low side only; the high side carries the critical limit 4.0 mg/dL.";
  c.critical_none_reason_es = "ninguno, porque ninguna lista consultada recoge un límite bajo de creatinina; una creatinina baja es una cuestión de plausibilidad o de masa muscular, no una urgencia (docs/signoff/work/governance/critical-limits.json, entrada creatinine, critical_low_none_because). Vale solo para el lado bajo; el lado alto lleva el límite crítico de 4,0 mg/dL.";
  ch(c, "critical_none_reason", null, c.critical_none_reason, "neutral",
    "Ledger L1 (judge J5): the empty low critical limit had no 'none, because'; copied from the critical-limits table.",
    [], sex === "male" ? ["f03_kidney--L1--bun.both.All_Adults.none--low"] : []);
  const en = c.messages.en, es = c.messages.es;
  en.below_range = replaceIn(en.below_range, `(${lo} to ${hi} mg/dL). Creatinine comes from muscle, so a low value most often means`, `(${lo} to ${hi} mg/dL). This is common and usually harmless: creatinine comes from muscle, so a low value most often means`);
  es.below_range = replaceIn(es.below_range, `(${loEs} a ${hiEs} mg/dL). La creatinina procede del músculo, así que un valor bajo suele indicar`, `(${loEs} a ${hiEs} mg/dL). Es frecuente y suele ser inofensivo: la creatinina procede del músculo, así que un valor bajo suele indicar`);
  en.in_range = replaceIn(en.in_range, "EVA sets no narrower optimal band for creatinine, because the population studies it reviewed did not show one with better long-term outcomes: creatinine reflects muscle mass as well as kidney filtration.", "EVA sets no narrower optimal band for creatinine, because creatinine reflects muscle mass as well as kidney filtration and the population studies EVA reviewed do not support a narrower band.");
  es.in_range = replaceIn(es.in_range, "EVA no fija una banda óptima más estrecha para la creatinina, porque los estudios de población que revisó no mostraron ninguna con mejores resultados a largo plazo: la creatinina refleja la masa muscular además de la filtración renal.", "EVA no fija una banda óptima más estrecha para la creatinina, porque la creatinina refleja la masa muscular además de la filtración renal y los estudios de población que EVA revisó no respaldan una banda más estrecha.");
  ch(c, "messages", "below-range text without a benign-cause word the M2 heuristic reads; in-range text 'did not show one with better long-term outcomes'",
    "below-range text opens with 'This is common and usually harmless' / 'Es frecuente y suele ser inofensivo'; in-range text gives the muscle-mass reason without an outcome claim",
    "neutral",
    "Check M2 (script, round 3: below-range EN and ES lack a benign-cause element; the causes named, muscle mass and diet, are benign) and wording-rules.md section 3.1 (no mortality substitute).",
    ["f03-D04"],
    [`f03_kidney--M2--creatinine.${sex}.All_Adults.critical_low.en--none`, `f03_kidney--M2--creatinine.${sex}.All_Adults.critical_low.es--none`]);
  c.clinical_notes_en = "A waste product from normal muscle activity that the kidneys clear. It is the standard input for estimating kidney filtration (eGFR), but it also varies with muscle mass, diet and hydration, so EVA reads kidney filtration from your eGFR and, where available, from cystatin C.";
  c.clinical_notes_es = "Un producto de desecho de la actividad muscular normal que los riñones eliminan. Es el dato estándar para estimar la filtración renal (TFGe), pero también varía con la masa muscular, la dieta y la hidratación, así que EVA lee la filtración renal en tu TFGe y, cuando la tienes, en la cistatina C.";
  ch(c, "clinical_notes_en, clinical_notes_es", "seed Clinical_Notes (T1/T2), not reviewed for the round-2 bounds", "notes in both languages naming eGFR and cystatin C as the filtration reading", "neutral",
    "Known issue C-10: rows carry their own clinical notes; the seed note was compliant but did not say that eGFR, not creatinine, carries the filtration reading under the round-2 rows.", [], []);
  c.notes = c.notes + " Round 4: low critical side 'none, because' copied from critical-limits.json (ledger L1, J5); below-range text names its benign causes as common (check M2); clinical notes added (C-10).";
}

// ───────────────────────── eGFR ─────────────────────────
const S64_EN = "Between 60 and 90, a value without albumin in the urine does not by itself define kidney disease.";
const S64_ES = "Entre 60 y 90, un valor sin albúmina en la orina no define por sí solo una enfermedad renal.";
const NOTE_EN = "An estimate of how much blood your kidneys filter each minute, calculated from creatinine, age and sex with the CKD-EPI 2021 equation. It falls slowly with age. Because it is built from creatinine, it also depends on muscle mass, so cystatin C and a urine albumin test give a clearer picture.";
const NOTE_ES = "Una estimación de cuánta sangre filtran tus riñones cada minuto, calculada a partir de la creatinina, la edad y el sexo con la ecuación CKD-EPI 2021. Baja despacio con la edad. Como se calcula a partir de la creatinina, también depende de la masa muscular, así que la cistatina C y una prueba de albúmina en orina dan una imagen más clara.";

const e18 = row("egfr_creatinine_based", "both", "18-39");
e18.messages.en.below_optimal = replaceIn(e18.messages.en.below_optimal, "(90 to 110 mL/min/1.73 m²). ", `(90 to 110 mL/min/1.73 m²). ${S64_EN} `);
e18.messages.es.below_optimal = replaceIn(e18.messages.es.below_optimal, "(90 a 110 mL/min/1,73 m²). ", `(90 a 110 mL/min/1,73 m²). ${S64_ES} `);
e18.messages.en.above_optimal = replaceIn(e18.messages.en.above_optimal, " In a large population study of adults aged 18 to 39, values above 110 were linked to slightly less favourable long-term outcomes than values of 100 to 110.", " EVA's band comes from a large population study of adults aged 18 to 39.");
e18.messages.es.above_optimal = replaceIn(e18.messages.es.above_optimal, " En un gran estudio de población de adultos de 18 a 39 años, los valores por encima de 110 se asociaron a resultados a largo plazo algo menos favorables que los de 100 a 110.", " La banda de EVA procede de un gran estudio de población de adultos de 18 a 39 años.");
ch(e18, "messages", "below-optimal text without the state-rules.md 6.4 sentence; above-optimal text 'linked to slightly less favourable long-term outcomes'",
  "below-optimal text adds 'Between 60 and 90, a value without albumin in the urine does not by itself define kidney disease.' (and the Spanish equivalent); above-optimal text names the source population without an outcome claim",
  "neutral",
  "state-rules.md section 6.4 requires the eGFR message to say that a value between 60 and 90 without albuminuria does not by itself define kidney disease (judge J5, ledger M2); in this row values from 60 to 90 fall in the below-optimal zone. The below-range zone holds only values under 60, where that sentence does not apply; it keeps the KDIGO three-month persistence rule. The outcome behind the 110 ceiling is all-cause mortality (Hussain 2023 table 3, f03-D03), which client text omits (wording-rules.md 3.1).",
  ["f03-D03"], ["f03_kidney--M2--egfr_creatinine_based.both.18-39.none--none"]);

const e40 = row("egfr_creatinine_based", "both", "40-84");
e40.messages.en.below_optimal = replaceIn(e40.messages.en.below_optimal, "values a little below this band are common after 60 and usual after 75, and in large population studies they carry only a small extra long-term risk at older ages.", `values a little below this band are common after 60 and usual after 75. ${S64_EN}`);
e40.messages.es.below_optimal = replaceIn(e40.messages.es.below_optimal, "los valores algo por debajo de esta banda son frecuentes a partir de los 60 años y habituales a partir de los 75, y en grandes estudios de población suponen solo un pequeño exceso a largo plazo en edades avanzadas.", `los valores algo por debajo de esta banda son frecuentes a partir de los 60 años y habituales a partir de los 75. ${S64_ES}`);
e40.messages.en.above_optimal = replaceIn(e40.messages.en.above_optimal, " In large population studies, values above 105 were linked to slightly less favourable long-term outcomes, mostly when the kidneys filter more than usual with diabetes, obesity or a very high protein intake.", " EVA's band comes from large population studies.");
e40.messages.es.above_optimal = replaceIn(e40.messages.es.above_optimal, " En grandes estudios de población, los valores por encima de 105 se asociaron a resultados a largo plazo algo menos favorables, sobre todo cuando los riñones filtran más de lo habitual por diabetes, obesidad o una ingesta muy alta de proteínas.", " La banda de EVA procede de grandes estudios de población.");
if (!e40.explanatory_numbers.includes(90)) e40.explanatory_numbers.push(90);
ch(e40, "messages", "below-optimal text without the state-rules.md 6.4 sentence and with 'a small extra long-term risk'; above-optimal text attributing the higher values' outcomes to hyperfiltration with diabetes, obesity or protein intake",
  "below-optimal text adds the 6.4 sentence; above-optimal text keeps the muscle-mass explanation and names the source without an outcome claim or a hyperfiltration attribution",
  "neutral",
  "state-rules.md 6.4 (judge J5, ledger M2 low); judge J1 (ledger M2 high): the cited all-cause mortality table (Hussain 2023 table 3, opened in this task: 110-120 HR 1.28 at ages 40-49 and 1.60 at 50-65) attributes nothing to hyperfiltration and 'slightly' understates it; wording-rules.md 3.1 omits mortality, so the outcome sentence goes. 90 added to explanatory_numbers (check M4).",
  ["f03-D03", "f03-D08"], ["f03_kidney--M2--egfr_creatinine_based.both.40-84.none--low", "f03_kidney--M2--egfr_creatinine_based.both.40-84.none--high"]);
const oldRule = e40.band_rule;
e40.band_rule = "lowest_risk_category";
ch(e40, "band_rule", oldRule, "lowest_risk_category", "neutral",
  "Judge J3 (ledger E1): 75-105 is the CKD-PC 2010 flat region ('risk of mortality was unrelated to eGFR between 75 mL/min/1.73 m(2) and 105', f03-E02, all ages pooled), a lowest-risk category, not a within-10% band. Applied to Hussain 2023 table 3 (all-cause mortality, CKD-EPI 2021, opened in this task) the within-10% rule gives 80-100 at ages 40-49 (70-80 HR 1.22, 80-90 HR 1.02, 100-110 HR 1.12 against the 90-100 referent) and a floor of 80 at ages 50-65 (70-80 HR 1.14 against 80-90; 90-100 HR 1.11, 100-110 HR 1.09, 110-120 HR 1.60), and Hussain has no data above 65. The bounds stay 75-105 (no loosening, no tightening by the author); the choice between the pooled band and the age-specific one is physician question f03-DQ10.",
  ["f03-E02", "f03-D07", "f03-D08"], ["f03_kidney--E1--egfr_creatinine_based.both.40-84.none--both", "f03_kidney--E1--egfr_creatinine_based.both.40-84.none--low"]);
e40.notes = replaceIn(e40.notes, "Within-10% rule: f03-E02 (mortality unrelated to eGFR between 75 and 105 in general-population cohorts, all ages pooled) and f03-E03 (ages 40-49: HR 1.02 for 80-90 versus 90-100; 70-80 HR 1.13; ages 50-65: HR 1.08 for 70-80 versus 80-90). 75 is the pooled lowest-risk floor; the age-specific data would put 40-49 at 80 and 50-65 at 70 to 80, differences within creatinine-eGFR imprecision (physician question f03-Q04).",
  "Band rule (round 4, judge J3): lowest-risk category, the CKD-PC 2010 flat region (f03-E02: mortality unrelated to eGFR between 75 and 105 in general-population cohorts with urine albumin, all ages pooled, eGFR by the MDRD Study equation). Same-equation check (Hussain 2023 table 3, all-cause mortality, CKD-EPI 2021, PMC10286512 opened in this task; f03-D07, f03-D08, f03-V01): ages 40-49 against the 90-100 referent, 70-80 HR 1.22 (1.17 to 1.28), 80-90 HR 1.02 (0.98 to 1.05), 100-110 HR 1.12 (1.09 to 1.15), 110-120 HR 1.28 (1.25 to 1.32), so the within-10% band is 80-100; ages 50-65 against the 80-90 referent, 70-80 HR 1.14 (1.12 to 1.15), 90-100 HR 1.11 (1.09 to 1.12), 100-110 HR 1.09 (1.08 to 1.11), 110-120 HR 1.60 (1.57 to 1.63), so the floor is 80 and the ceiling 110 (90-100 sits 0.01 above the 10% limit); no data above 65. Earlier rounds cited 1.13 (40-49) and 1.08 (50-65) for 70-80: those are the abstract's composite-outcome HRs (death, cardiovascular event, kidney failure), not mortality (ledger E1, J1). The row keeps the pooled 75-105; floor 75 or 80 and an age split at 50 or 66 are physician question f03-DQ10 (with f03-Q04).");
e40.method_note = replaceIn(e40.method_note, "Derived marker: the app computes eGFR from Echevarne's creatinine with the race-free CKD-EPI 2021 creatinine equation (K1; f03-E08);", "Derived marker: the row is written for an eGFR computed from Echevarne's creatinine with the race-free CKD-EPI 2021 creatinine equation (K1; f03-E08), which the app does not compute yet (verifier note below);");
e40.method_note = replaceIn(e40.method_note, "and the pooled CKD-PC band 75-105 (f03-E02);", "and the pooled CKD-PC band 75-105 (f03-E02), whose cohorts estimated GFR with the MDRD Study equation, which 'is known to underestimate measured GFR at the range of GFR ≥60' in healthy individuals (f03-D06), while EVA's row reads race-free CKD-EPI 2021; the size of the difference at 75 and 105 is not reported in the opened source, and the same-equation table (Hussain 2023, f03-D07, f03-D08) gives 80-100 at 40-49 and 80-110 at 50-65 (physician question f03-DQ10);");
ch(e40, "method_note", "band stated as following the within-10% rule; eGFR equation of the band source not stated; opening sentence said the app computes eGFR",
  "band stated as CKD-PC 2010 lowest-risk category on MDRD eGFR, with the MDRD caveat quoted and the same-equation alternative; opening sentence says the app does not compute eGFR yet",
  "neutral",
  "Judge J2 (ledger definition:optimal band, both and low sides): the 75-105 band rests on MDRD-based eGFR while the row classifies CKD-EPI 2021 eGFR and the method note did not say so. The CKD-PC full text (PMC3993088, opened in this task) states the MDRD equation and its underestimation in healthy individuals (f03-D06).",
  ["f03-D06", "f03-E02"], ["f03_kidney--definition:optimal_band--egfr_creatinine_based.both.40-84.none--both", "f03_kidney--definition:optimal_band--egfr_creatinine_based.both.40-84.none--low"]);

const e85 = row("egfr_creatinine_based", "both", "85+");
e85.messages.en.in_range = replaceIn(e85.messages.en.in_range, "the limit used by the KDIGO guidelines. ", `the limit used by the KDIGO guidelines. ${S64_EN} `);
e85.messages.es.in_range = replaceIn(e85.messages.es.in_range, "el límite que usan las guías KDIGO. ", `el límite que usan las guías KDIGO. ${S64_ES} `);
if (!e85.explanatory_numbers.includes(90)) e85.explanatory_numbers.push(90);
ch(e85, "messages", "in-range text without the state-rules.md 6.4 sentence", "in-range text adds the 6.4 sentence (values of 60 and over fall in this zone)", "neutral",
  "state-rules.md section 6.4; 90 added to explanatory_numbers (check M4).", [], []);

for (const e of [e18, e40, e85]) {
  e.clinical_notes_en = NOTE_EN;
  e.clinical_notes_es = NOTE_ES;
  ch(e, "clinical_notes_en, clinical_notes_es", "seed Clinical_Notes (T13/T14): 'a faster decline signals risk' / 'un descenso más rápido indica riesgo'",
    "notes in both languages: what eGFR estimates, the CKD-EPI 2021 equation, the slow fall with age and the muscle-mass caveat, with no individual risk statement",
    "neutral",
    "Ledger M3 (judge J1): 'signals risk' reads as an individual risk statement (wording-rules.md 3.1); state-rules.md 6.4 asks the text to name the equation. Known issue C-10.",
    [], e === e18 ? ["f03_kidney--M3--egfr_creatinine_based.both.18-39.none--none"] : []);
}

// ───────────────────────── CYSTATIN C ─────────────────────────
const cys = row("cystatin_c", "both", "All Adults");
cys.rcv.narrow_band_justification = "The reachable optimal zone runs from the reference floor 0.62 to the optimal ceiling 0.72 mg/L, 0.10 mg/L or 13.9% of 0.72, narrower than the provisional RCV of 24.5%. The band classifies one value against outcome-derived quintile boundaries (f03-E18, f03-E18b: quintile 2 ends at 0.717 mg/L) and does not infer change; change between two results is only called above the RCV (P2 trend rule). The row has no optimal floor: values under 0.62 are below Echevarne's interval, not below an outcome band, and the below-range message calls them usually harmless.";
ch(cys, "rcv.narrow_band_justification", null, "justification for a reachable optimal zone (0.62-0.72 mg/L) narrower than the RCV", "neutral",
  "Judge J2 (ledger P2): the reachable optimal zone is narrower than the row's own RCV and the justification was null, while the BUN and urea rows give one.",
  ["f03-E18", "f03-E18b"], ["f03_kidney--P2--cystatin_c.both.All_Adults.none--high"]);
const cEn = cys.messages.en, cEs = cys.messages.es;
cEn.below_range = replaceIn(cEn.below_range, "A low value is usually harmless: it most often reflects a high kidney filtration, and an underactive thyroid also lowers it.", "A low value is common and usually harmless: it most often reflects a high kidney filtration, as is usual in young adults, and an underactive thyroid also lowers it.");
cEs.below_range = replaceIn(cEs.below_range, "Un valor bajo suele ser inofensivo: casi siempre refleja una filtración renal alta, y una tiroides poco activa también la baja.", "Un valor bajo es frecuente y suele ser inofensivo: casi siempre refleja una filtración renal alta, como es habitual en adultos jóvenes, y una tiroides poco activa también la baja.");
cEn.optimal = "Your cystatin C is in EVA's optimal band (up to 0.72 mg/L), set from a large population study. Cystatin C does not depend on muscle mass, so it is a good check of kidney filtration when creatinine is doubtful. This marker does not count toward the score.";
cEs.optimal = "Tu cistatina C está en la banda óptima de EVA (hasta 0,72 mg/L), fijada a partir de un gran estudio de población. La cistatina C no depende de la masa muscular, así que es una buena comprobación de la filtración renal cuando la creatinina deja dudas. Este marcador no entra en la puntuación.";
cEn.above_optimal = replaceIn(cEn.above_optimal, "In large population studies the most favourable long-term outcomes were seen below 0.72 mg/L; values in this zone become more common with age", "Values in this zone become more common with age");
cEs.above_optimal = replaceIn(cEs.above_optimal, "En grandes estudios de población los resultados más favorables a largo plazo se vieron por debajo de 0,72 mg/L; los valores en esta zona son más frecuentes con la edad", "Los valores en esta zona son más frecuentes con la edad");
ch(cys, "messages", "optimal and above-optimal texts 'the most favourable long-term outcomes'; below-range text with one benign cause besides high filtration",
  "outcome sentences removed; below-range text says a low value is common and usually harmless, as high filtration is usual in young adults",
  "neutral",
  "wording-rules.md 3.1 (the band's outcome is all-cause mortality, f03-E18; judge J1, ledger M3 BUN 'none', which names cystatin C too). Judge J1 (ledger M2, cystatin C low) asked for one more benign cause; in Hussain 2023 table 3 (opened in this task) 2,526,509 of the 3,834,657 adults aged 18-39 had an eGFR above 110, so high filtration is usual in young adults.",
  ["f03-E18", "f03-D03"], ["f03_kidney--M2--cystatin_c.both.All_Adults.none--low"]);
cys.clinical_notes_en = "A kidney-function marker that, unlike creatinine, does not depend on muscle mass. It is especially useful in people with high or low muscle mass, or those taking creatine supplements, where creatinine can mislead.";
cys.clinical_notes_es = "Un marcador de función renal que, a diferencia de la creatinina, no depende de la masa muscular. Resulta especialmente útil en personas con masa muscular alta o baja, o que toman suplementos de creatina, donde la creatinina puede engañar.";
ch(cys, "clinical_notes_en, clinical_notes_es", "production Clinical_Notes: 'Cystatin-C-based eGFR predicts mortality better than the creatinine-only version' / 'predice mortalidad'",
  "the sentence is removed; the rest of the production note is kept",
  "neutral",
  "Ledger M3 (judge J1): 'predice' and 'mortalidad' are banned in client text (wording-rules.md 3.1). Known issue C-10.",
  [], ["f03_kidney--M3--cystatin_c.both.All_Adults.none--none"]);
cys.notes = replaceIn(cys.notes, "Band rule: within 10% of the lowest quintile in Yuan 2025 (12,340 NHANES adults, median follow-up 207 months, all-cause mortality): quintile 2 (0.640-0.717 mg/L) HR 1.05 inside, quintile 3 HR 1.29 outside, so the ceiling is 0.717, shown as 0.72.",
  "Band rule: within 10% of the lowest quintile in Yuan 2025 (12,340 NHANES adults, median follow-up 207 months); the outcome behind the rule is all-cause mortality: quintile 2 (0.640-0.717 mg/L) HR 1.05 (0.82-1.34) inside, quintile 3 HR 1.29 (1.03-1.60) outside. The edge is 0.717 mg/L; the row shows 0.72 because the row's precision is two decimals, and a value reported as 0.72 can be 0.715 to 0.724, so a result of exactly 0.72 counts as optimal although 0.718 to 0.724 belong to quintile 3 (judge J3, rounding stated). Cardiovascular mortality in the same abstract (f03-D09, opened in this task): quintile 2 HR 1.78 (1.11-2.86), quintile 4 1.85, quintile 5 2.97 against quintile 1, so with cardiovascular mortality as the outcome the band would hold only quintile 1 (<0.640 mg/L), barely above Echevarne's floor 0.62; the outcome choice is physician question f03-DQ06. Assay: Siemens immunoassay on a Dimension Vista 1500 (method note), traceability to the IFCC reference material not stated, Echevarne's method unknown (f03-DQ06).");
cys.notes = cys.notes + " Round 4: P2 narrow-band justification added; outcome sentences removed from the client texts; production clinical note's mortality sentence removed (C-10). Reference interval (judge J3, ledger definition:reference interval): Echevarne's 0.62-1.11 mg/L stays, because PLAN.md section 4 makes the printed interval binding; the share of healthy older adults above it is part of f03-DQ06.";
ch(cys, "notes", "outcome behind the band rule not named; rounding 0.717 to 0.72 not stated; cardiovascular result not given", "all-cause mortality named as the band's outcome, rounding stated, cardiovascular mortality result and assay caveat given to the physician (f03-DQ06)", "neutral",
  "Judge J3 (ledger E1, cystatin C high), whose stated resolution was: name the outcome behind the band rule, keep 0.717 or state the rounding, and give the physician the cardiovascular result and the assay caveat.",
  ["f03-E18", "f03-E18b", "f03-D09"], ["f03_kidney--E1--cystatin_c.both.All_Adults.none--high"]);

// ───────────────────────── RATIO ─────────────────────────
const ratio = row("bun_creatinine_ratio", "both", "All Adults");
ratio.messages.en.in_range = "Your BUN-to-creatinine ratio is between 7.6 and 45.5, the span that a BUN and a creatinine inside their own laboratory intervals can give. A ratio in this span does not mean that your BUN and your creatinine are each in range: their own messages carry the detail. EVA shows this derived index for information only. This marker does not count toward the score.";
ratio.messages.es.in_range = "Tu cociente BUN/creatinina está entre 7,6 y 45,5, el margen que pueden dar un BUN y una creatinina dentro de sus propios intervalos de laboratorio. Un cociente dentro de este margen no significa que tu BUN y tu creatinina estén cada uno dentro de su intervalo: sus propios mensajes llevan el detalle. EVA muestra este índice derivado solo a título informativo. Este marcador no entra en la puntuación.";
ch(ratio, "messages", "in-range text 'within the range that a BUN and a creatinine inside their own laboratory intervals can give'", "in-range text says that a ratio inside the span does not mean BUN and creatinine are each in range", "neutral",
  "Judge J5 (ledger definition:marker_classes, round 3): a BUN below range with a creatinine above range gives a ratio inside 7.6-45.5 (woman BUN 9.7, creatinine 1.051 mg/dL, check K1), and the old text implied both inputs were in range. The 'Optimal' label the app puts on this text is an app fix (zone-classifier.ts, zone-config.ts), not a row change.",
  [], []);
ratio.clinical_notes_en = "Compares two kidney waste products, BUN and creatinine. EVA shows it for information only: a ratio inside its span does not mean that BUN and creatinine are each in range, so read their own results.";
ratio.clinical_notes_es = "Compara dos productos de desecho renales, el BUN y la creatinina. EVA lo muestra solo a título informativo: un cociente dentro de su margen no significa que el BUN y la creatinina estén cada uno dentro de su intervalo, así que mira sus propios resultados.";
ch(ratio, "clinical_notes_en, clinical_notes_es", "seed Clinical_Notes (T53/T54): the ratio helps tell dehydration from an intrinsic kidney problem", "notes in both languages: information only, read BUN and creatinine", "neutral",
  "The seed note claimed a diagnostic use (dehydration versus intrinsic kidney disease) that the derived limits 7.6-45.5 do not support (f03-E49 is an acute-care threshold); known issue C-10.", ["f03-E49"], []);
ratio.critical_none_reason_es = "ninguno, porque el cociente es un índice derivado; los límites críticos están en el BUN (100 mg/dL) y la creatinina (4,0 mg/dL) de la misma muestra.";
ratio.notes = ratio.notes + " Round 4: in-range and clinical texts no longer imply that both inputs are in range (judge J5). Shen 2022 (f03-D01, PMC8856064 re-opened in this task, table 2, Model 3, all-cause mortality) puts the lowest risk in quartiles 2 and 3 (HR 0.83 and 0.87 against quartile 1 below 11.43; quartile 4, 18.57 and over, 1.03), a band close to production's 11-18; whether the ratio stays class e (no band, as written) or becomes class a with that band is part of f03-DQ07. Production's optimal 11-18 is not recorded as a change in this file: removing it is a loosening, and no grade A or B quote supports removal (the verifier's grade D and the class e draft are the reasons); D5 keeps listing it until the physician answers f03-DQ07.";

// ───────────────────────── EVIDENCE ─────────────────────────
const ev = (o) => d.evidence.push(o);
ev({
  id: "f03-D06",
  supports: [{ row_key: "egfr_creatinine_based|both|40-84|none", bound: "method" }],
  identifier: { type: "pmcid", value: "PMC3993088" },
  citation: "Chronic Kidney Disease Prognosis Consortium; Matsushita K, van der Velde M, Astor BC, et al. Association of estimated glomerular filtration rate and albuminuria with all-cause and cardiovascular mortality in general population cohorts: a collaborative meta-analysis. Lancet 2010;375(9731):2073-81, discussion.",
  year: 2010,
  quote: "The MDRD Study equation is known to underestimate measured GFR at the range of GFR ≥60 ml/min/1.73m2 in healthy individuals",
  location: "Discussion, paragraph on the U-shaped association (PMC author manuscript, opened through NCBI eutils efetch db=pmc id=3993088); the methods state 'GFR was estimated using the Modification of Diet in Renal Disease (MDRD) Study equation using age, sex, race, and serum creatinine concentration.'",
  design: "Collaborative meta-analysis of general-population cohorts (pooled individual data), Cox models.",
  n: 105872,
  follow_up_years: 6.9,
  outcome: "All-cause and cardiovascular mortality (this record supports the eGFR-equation caveat only)",
  population_age: "Adults, general-population cohorts, all ages pooled",
  population_sex: "both",
  assay: "Serum creatinine, eGFR by the MDRD Study equation (not CKD-EPI 2021)",
  band_rule: "lowest_risk_category",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "Not in this passage; the band 75-105 is pooled over ages (f03-E02).",
  notes: "n is the ACR-study set (105,872 participants, 730,577 person-years, so 6.9 years mean, as the verifier computed for f03-E02). The superscript 2 of m2 is plain text here; the source prints it as a superscript."
});
ev({
  id: "f03-D07",
  supports: [{ row_key: "egfr_creatinine_based|both|40-84|none", bound: "optimal_low" }, { row_key: "egfr_creatinine_based|both|40-84|none", bound: "age_split" }],
  identifier: { type: "pmcid", value: "PMC10286512" },
  citation: "Hussain J, Grubic N, Akbari A, et al. Associations between modest reductions in kidney function and adverse outcomes in young adults: retrospective, population based cohort study. BMJ 2023;381:e075062, table 3 (all cause mortality by eGFR category and age group).",
  year: 2023,
  quote: "70-80 mL/min/1.73m 2 Event frequency 630/61 781 2476/102 090 24 521/313 400 Crude incidence rate 1.47 2.83 8.51 Adjusted HR 1.42 (1.30 to 1.54) 1.22 (1.17 to 1.28) 1.14 (1.12 to 1.15)",
  location: "Table 3 (all cause mortality), row 70-80 mL/min/1.73m2; columns ages 18-39, 40-49, 50-65; referents 100-110 (18-39), 90-100 (40-49), 80-90 (50-65). Europe PMC fullTextXML of PMC10286512, opened in this task.",
  design: "Retrospective population-based cohort from routinely collected outpatient creatinine (Ontario), age-specific referents, Cox models adjusted for sex, hypertension, diabetes, past cardiovascular disease, obesity, smoking and other covariates (table 3 footnote).",
  n: 8703871,
  follow_up_years: 9.2,
  outcome: "All-cause mortality",
  population_age: "Adults 18-65 with no history of kidney disease; columns 40-49 and 50-65 used here",
  population_sex: "both",
  assay: "Outpatient serum creatinine, eGFR by the race-free CKD-EPI 2021 equation (as recorded for f03-D03)",
  band_rule: "within_10pct_of_min_hr",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "Yes: at 70-80, HR 1.22 at 40-49 and 1.14 at 50-65 (both outside the 10% rule), so the same-equation floor is 80 at 40-65; the adjacent 80-90 row reads 1.02 (0.98 to 1.05) at 40-49 and is the 50-65 referent. No data above 65.",
  notes: "n and median follow-up 9.2 years are the whole cohort's (abstract). Supports physician question f03-DQ10, not the row's current floor 75."
});
ev({
  id: "f03-D08",
  supports: [{ row_key: "egfr_creatinine_based|both|40-84|none", bound: "optimal_high" }, { row_key: "egfr_creatinine_based|both|40-84|none", bound: "age_split" }],
  identifier: { type: "pmcid", value: "PMC10286512" },
  citation: "Hussain J, Grubic N, Akbari A, et al. BMJ 2023;381:e075062, table 3 (all cause mortality by eGFR category and age group).",
  year: 2023,
  quote: "100-110 mL/min/1.73m 2 (reference for 18-40 years) Event frequency 4199/619 115 14 851/626 279 73 379/971 402 Crude incidence rate 0.926 2.59 8.10 Adjusted HR 1.00 (reference) 1.12 (1.09 to 1.15) 1.09 (1.08 to 1.11)",
  location: "Table 3 (all cause mortality), row 100-110 mL/min/1.73m2; columns ages 18-39, 40-49, 50-65. Europe PMC fullTextXML of PMC10286512, opened in this task.",
  design: "As f03-D07.",
  n: 8703871,
  follow_up_years: 9.2,
  outcome: "All-cause mortality",
  population_age: "Adults 18-65; columns 40-49 and 50-65 used here",
  population_sex: "both",
  assay: "Outpatient serum creatinine, eGFR by the race-free CKD-EPI 2021 equation",
  band_rule: "within_10pct_of_min_hr",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "Yes: at 100-110, HR 1.12 at 40-49 (outside the 10% rule, so the ceiling there is 100) and 1.09 at 50-65 (inside); the 110-120 row reads 1.28 and 1.60 (f03-D03), so the same-equation ceiling is 100 at 40-49 and 110 at 50-65. No data above 65.",
  notes: "Supports physician question f03-DQ10, not the row's current ceiling 105 (which rests on f03-E02 and f03-V01)."
});
ev({
  id: "f03-D09",
  supports: [{ row_key: "cystatin_c|both|All Adults|none", bound: "optimal_high" }],
  identifier: { type: "pmid", value: "40983592" },
  citation: "Yuan Y, Guo Z, Dong X, Gao J, Wang Z, Yang Y. Association of cystatin C with 20-year mortality risk in the general US population: a cohort study. Ren Fail 2025;47(1):2549401, abstract.",
  year: 2025,
  quote: "Furthermore, the second quintile had a 1.78-fold risk (HR: 1.78, 95%CI: 1.11-2.86), the fourth quintile had a 1.85-fold risk (HR: 1.85, 95% CI: 1.17-2.92), and the fifth quintile had a 2.97-fold risk of cardiovascular mortality (HR: 2.97, 95% CI: 1.89-4.68).",
  location: "Abstract, results (PubMed record opened through eutils in this task).",
  design: "Prospective cohort (NHANES 1999-2004 with mortality linkage), multivariable Cox models.",
  n: 12340,
  follow_up_years: 17.25,
  outcome: "Cardiovascular mortality",
  population_age: "Adults 20 and over, median baseline age 44 (IQR 33-57)",
  population_sex: "both",
  assay: "Siemens cystatin C immunoassay on a Dimension Vista 1500 (as recorded for f03-D02); IFCC traceability not stated",
  band_rule: "lowest_risk_category",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "The abstract reports no age-stratified cardiovascular estimate; the all-cause subgroup over 59 keeps <0.718 mg/L as the lowest-risk category (f03-D02).",
  notes: "n and follow-up are those the verifier confirmed for f03-E18 (full text). With cardiovascular mortality as the outcome, the lowest-risk category is quintile 1 alone (<0.640 mg/L, f03-E18b); the row keeps the all-cause band (ceiling 0.717, shown 0.72). Context for physician question f03-DQ06."
});
ev({
  id: "f03-D10",
  supports: [{ row_key: "bun|both|All Adults|none", bound: "sex_split" }, { row_key: "urea|both|All Adults|none", bound: "sex_split" }],
  identifier: { type: "pmcid", value: "PMC9865447" },
  citation: "Hong C, Zhu H, Zhou X, et al. Association of Blood Urea Nitrogen with Cardiovascular Diseases and All-Cause Mortality in USA Adults: Results from NHANES 1999-2006. Nutrients 2023;15(2):461, section 3.3 (stratification analyses).",
  year: 2023,
  quote: "A negative correlation was found between only two groups of factors and CVD mortality: age ≥60 years Q2 group (3.57–4.59 mmol/L) and current drinker Q3 group (4.60–5.70 mmol/L). P for interaction is only significant in the sex hierarchy.",
  location: "Results, section 3.3 Stratification Analyses, last sentences before figure 2 (Europe PMC fullTextXML of PMC9865447, opened in this task). The abstract adds: 'In subgroup analyses, we found that the trend in the association of BUN with the risk of death remained strong in female subjects.'",
  design: "Prospective cohort (NHANES 1999-2006 with mortality linkage), weighted Cox models; interactions tested in Model 4; strata by age, sex, BMI, smoking, drinking, hypertension and diabetes.",
  n: 17719,
  follow_up_years: 11.65,
  outcome: "All-cause and cardiovascular mortality",
  population_age: "Adults 20-85",
  population_sex: "both",
  assay: "NHANES serum BUN (mmol/L in the source; x 2.801 to mg/dL)",
  band_rule: "within_10pct_of_min_hr",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "Sex: the interaction test is significant for sex only and the association is stronger in women, but the quartile cut-offs are pooled across sexes (table 1) and the sex-specific hazards are shown only in figure 2, so no sex-specific edge can be read; a stronger association in women does not move the pooled edge 5.71 mmol/L (16.0 mg/dL). Age: stronger at 60 and over (f03-D05). Decision: no sex split.",
  notes: "Record for the 'no sex split' decision on the BUN and urea rows (PLAN.md section 5: every age or sex split carries one record; ledger E1, judge J3). Quote copied from the PMC text; P is italic in the source."
});

// ───────────────────────── PHYSICIAN QUESTIONS ─────────────────────────
const q = (id) => d.physician_questions.find((x) => x.id === id);
q("f03-DQ06").question = "Cystatin C: the 0.72 mg/L ceiling applies the within-10% rule to all-cause mortality (Yuan 2025, NHANES 1999-2004: quintile 2, 0.640-0.717 mg/L, HR 1.05; quintile 3 HR 1.29; still lowest-risk over 59). Three things are open. (1) Outcome: the same abstract gives quintile 2 a cardiovascular-mortality HR of 1.78 (1.11-2.86) against quintile 1, so on cardiovascular mortality the band would hold only quintile 1 (<0.640 mg/L), barely above Echevarne's floor 0.62. (2) Reach: almost no healthy adult aged 70-79 is under 0.72 (NHANES 1999-2002 2.5th percentile 0.74 mg/L in women, 0.78 in men), and Echevarne's interval leaves many healthy older adults above 1.11. (3) Assay: the source used a Siemens Dimension Vista immunoassay with no stated IFCC traceability; Echevarne's method and calibration are unknown. Keep the all-cause ceiling 0.72 for all adults, show cystatin C against the reference interval only from age 70, or hold the ceiling until Echevarne states its calibration?";
q("f03-DQ06").why = "PLAN.md section 4 defines the optimal band by the lowest risk of hard outcomes without naming which outcome when they disagree; that choice and the assay offset are clinical judgement, not something the definitions settle. Ledger E1 and definition:optimal band (judges J3 and J2), definition:reference interval (J3). Check N1 does not test cystatin C today (no 2015-2018 data). Extends f03-Q06.";
q("f03-DQ06").evidence_ids = ["f03-E18", "f03-E18b", "f03-D02", "f03-D09", "f03-E20", "f03-E34"];
q("f03-DQ06").options = ["Keep 0.72 for all adults on all-cause mortality (as written)", "Quintile 1 only on cardiovascular mortality (in effect no optimal band)", "Reference interval only from 70", "Hold until Echevarne's traceability is known"];

q("f03-DQ07").question = q("f03-DQ07").question + " Round 4 adds one point: Shen 2022 (f03-D01; NHANES 1999-2014, n = 42,038, table 2 Model 3, all-cause mortality) finds the lowest risk in ratio quartiles 2 and 3 (HR 0.83 and 0.87 against quartile 1 below 11.43; quartile 4, 18.57 and over, 1.03), close to production's optimal 11-18. Is the ratio class e (no band, as written, the marker-classes.json draft) or class a with an outcome band near 11.4-18.6?";
q("f03-DQ07").options = [...q("f03-DQ07").options, "Class a with an outcome band from Shen 2022 once the verifier grades it"];

q("f03-DQ08").question = replaceIn(q("f03-DQ08").question, "Do you list BUN 10-16 and urea 21-34 in the grade C decision table", "Do you list the BUN ceiling 16 and the urea ceiling 34 (optimal zones 10-16 and 21-34, from the laboratory floor; the rows set no optimal floor of their own from round 4) in the grade C decision table");
q("f03-DQ08").options = ["List the BUN ceiling 16 and urea ceiling 34 in the grade C table (as written)", "Optimal equals Echevarne's interval: in range or out of range only", "List with a higher ceiling such as 17 mg/dL (urea 36) once the verifier accepts Shen 2024"];

d.physician_questions.push({
  id: "f03-DQ10",
  row_key: "egfr_creatinine_based|both|40-84|none",
  question: "eGFR at ages 40-84: the row keeps 75-105, the CKD-PC 2010 lowest-risk category (all ages pooled, eGFR by the MDRD Study equation, which underestimates measured GFR at 60 and above in healthy people). The same-equation table EVA would use (Hussain 2023 table 3, all-cause mortality, race-free CKD-EPI 2021, ages 18-65 only) gives, by the within-10% rule, 80-100 at ages 40-49 (70-80 HR 1.22, 100-110 HR 1.12) and 80-110 at ages 50-65 (70-80 HR 1.14, 90-100 HR 1.11, 100-110 HR 1.09, 110-120 HR 1.60), and nothing above 65. Keep one 40-84 row at 75-105, split it (for example 40-49 at 80-100, 50-65 at 80-110 and 66-84 at 75-105), or keep 40-84 with the floor 80?",
  why: "Both sources meet PLAN.md section 5 tier 2 and they disagree by age and by equation; an age split is a clinical judgement (PLAN.md section 4: split only where the outcome evidence differs by age, which it does here). A floor of 80 or a ceiling of 100 tightens the band and adds below-optimal readings; check N1 already finds most healthy adults over 75 below 75. Ledger E1 (judges J3 and J1), E4 (J1), definition:optimal band (J2). Extends f03-Q04.",
  evidence_ids: ["f03-E02", "f03-D06", "f03-D07", "f03-D08", "f03-D03", "f03-E03", "f03-E04"],
  options: ["Keep 40-84 at 75-105 (as written)", "Split 40-49 (80-100), 50-65 (80-110), 66-84 (75-105)", "Keep 40-84 with floor 80"]
});

// ───────────────────────── CHANGES, ISSUES, NOTES ─────────────────────────
d.changes.push(...changes);

const prevKeep = d.issues_addressed.filter((id) => id !== "f03_kidney--E3--bun.both.All_Adults.none--high");
const newIds = new Set();
for (const c of changes) for (const id of c.issue_ids || []) newIds.add(id);
for (const id of ["f03_kidney--E3--bun_creatinine_ratio.female.All_Adults.none--none"]) newIds.add(id);
d.issues_addressed = [...new Set([...prevKeep, ...newIds])].sort();

module.exports = { d, changes };
fs.writeFileSync(decFile, JSON.stringify(d, null, 2) + "\n");
console.log("written", decFile, "changes", d.changes.length, "issues", d.issues_addressed.length);
