const fs = require("fs");
const f = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/f11gen.js";
let s = fs.readFileSync(f, "utf8");
function rep(o, n, k = 1) { const c = s.split(o).length - 1; if (c !== k) throw new Error(`count ${c} != ${k}: ${o.slice(0, 90)}`); s = s.split(o).join(n); }
// a. explanatory numbers
rep(`  explanatory_numbers: [2, 4],
  decimals: 0,`, `  explanatory_numbers: [2, 4, 100000],
  decimals: 0,`);
rep(`explanatory_numbers: [1, 10, 150000],`, `explanatory_numbers: [1, 10, 100, 100000, 150000],`);
// b. below_range wording
rep("Healthy adults in Spain tend to have somewhat lower counts than people in northern Europe, older adults too, and the count falls a little in pregnancy.",
    "Healthy adults in Spain tend to have somewhat lower counts than people in northern Europe, as do older adults, and the count falls a little in pregnancy.");
rep("Los adultos sanos en España tienden a tener recuentos algo más bajos que en el norte de Europa, también las personas mayores, y el recuento baja un poco durante el embarazo.",
    "Los adultos sanos en España tienden a tener recuentos algo más bajos que en el norte de Europa, igual que las personas mayores, y el recuento baja un poco durante el embarazo.");
// c. in_range wording
rep("The count is shown against the laboratory interval only, because a value inside it is not a target to aim for.",
    "EVA shows it against the laboratory interval only, with no optimal band.");
rep("El recuento se muestra solo frente al intervalo del laboratorio, porque un valor dentro de él no es un objetivo que haya que alcanzar.",
    "EVA lo muestra solo frente al intervalo del laboratorio, sin banda óptima.");
// d. MPV association wording
rep("Population studies have linked a higher MPV with heart disease, but MPV is not known to cause it and is not a treatment target.",
    "Population studies have linked a higher MPV with heart attacks, but MPV is not known to cause them and is not a treatment target.");
rep("Estudios de población han asociado un VPM más alto con enfermedad cardíaca, pero no se sabe que el VPM la cause y no es un objetivo de tratamiento.",
    "Estudios de población han asociado un VPM más alto con el infarto de miocardio, pero no se sabe que el VPM lo cause y no es un objetivo de tratamiento.");
// e. exact 'soon' phrase in pregnancy texts
rep("Book an appointment with your doctor, obstetrician or midwife in the next few weeks, sooner if you notice unusual bruising or bleeding or feel unwell.",
    "Book an appointment with your doctor in the next few weeks, or with your obstetrician or midwife, sooner if you notice unusual bruising or bleeding or feel unwell.", 2);
rep("Book an appointment with your doctor, obstetrician or midwife in the next few weeks.",
    "Book an appointment with your doctor in the next few weeks, or with your obstetrician or midwife.");
rep("Pide cita con tu médico, tu obstetra o tu matrona en las próximas semanas, antes si notas moratones o sangrados sin motivo o te encuentras mal.",
    "Pide cita con tu médico en las próximas semanas, o con tu obstetra o matrona, antes si notas moratones o sangrados sin motivo o te encuentras mal.", 2);
rep("Pide cita con tu médico, tu obstetra o tu matrona en las próximas semanas.",
    "Pide cita con tu médico en las próximas semanas, o con tu obstetra o matrona.");
// f. oral contraception statement
rep("Menopause, hormone therapy and oral contraception: no flag; the only studies found are small (PMID 8937589: in 38 postmenopausal women the platelet count rose, not significantly, after 6 weeks of hormone therapy) and do not move the interval.",
    "Menopause, hormone therapy and oral contraception: no flag; no study of oral contraception and the platelet count was found, and the only hormone-therapy study found is small (PMID 8937589: in 38 postmenopausal women the platelet count rose, not significantly, after 6 weeks of hormone therapy) and does not move the interval.");
rep("Menopause, hormone therapy and oral contraception: no flag; two small studies disagree",
    "Menopause, hormone therapy and oral contraception: no flag; no study of oral contraception and MPV was found, and two small hormone-therapy studies disagree");
fs.writeFileSync(f, s); console.log("ok");
