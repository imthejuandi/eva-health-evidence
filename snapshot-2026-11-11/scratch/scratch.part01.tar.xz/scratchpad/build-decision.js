// Builds docs/signoff/work/decisions/f05_glycaemia.json from the verify file's final_rows (round 2 fixer).
// Run from the repository root: node <this file>
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = process.cwd();
const VERIFY = path.join(ROOT, "docs/signoff/work/verify/f05_glycaemia.json");
const OUT = path.join(ROOT, "docs/signoff/work/decisions/f05_glycaemia.json");

const verifyBuf = fs.readFileSync(VERIFY);
const verify = JSON.parse(verifyBuf.toString("utf8"));
const verifySha = crypto.createHash("sha256").update(verifyBuf).digest("hex");

const rows = JSON.parse(JSON.stringify(verify.final_rows));
const key = (r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
const row = (k) => {
  const r = rows.find((x) => key(x) === k);
  if (!r) throw new Error(`no row ${k}`);
  return r;
};

const K = {
  glu: "glucose_fasting|both|All Adults|none",
  a1c: "hba1c|both|All Adults|none",
  a1cP: "hba1c|female|All Adults|pregnancy",
  fru: "fructosamine|both|All Adults|none",
  ins: "insulin_fasting|both|All Adults|none",
  homa: "homa_ir|both|All Adults|none",
};

// Ledger ids
const L = {
  confA1c: "f05_glycaemia--definition:reference_interval--hba1c.both.All_Adults.none--both",
  confIns: "f05_glycaemia--definition:optimal_band--insulin_fasting.both.All_Adults.none--none",
  d5Fru: "f05_glycaemia--D5--fructosamine.both.All_Adults.bounds--none",
  d5Glu: "f05_glycaemia--D5--glucose_fasting.both.All_Adults.bounds--none",
  d5A1cP: "f05_glycaemia--D5--hba1c.female.Pregnancy.row_only_in_seed--none",
  d5Ins: "f05_glycaemia--D5--insulin_fasting.both.All_Adults.bounds--none",
  g2: [
    "f05_glycaemia--G2--row.fructosamine.both.All_Adults.none--none",
    "f05_glycaemia--G2--row.glucose_fasting.both.All_Adults.none--none",
    "f05_glycaemia--G2--row.hba1c.both.All_Adults.none--none",
    "f05_glycaemia--G2--row.hba1c.female.All_Adults.pregnancy--none",
    "f05_glycaemia--G2--row.homa_ir.both.All_Adults.none--none",
    "f05_glycaemia--G2--row.insulin_fasting.both.All_Adults.none--none",
  ],
  n1: [
    "f05_glycaemia--N1--glucose_fasting.female.70-79.non_optimal_70_79--none",
    "f05_glycaemia--N1--glucose_fasting.male.70-79.non_optimal_70_79--none",
    "f05_glycaemia--N1--hba1c.female.70-79.non_optimal_70_79--none",
    "f05_glycaemia--N1--hba1c.male.70-79.non_optimal_70_79--none",
  ],
  k1: [
    "f05_glycaemia--K1--opposite.homa_ir.female.glucose_fasting:optimal_insulin_fasting:optimal-_homa_ir:critical_high--none",
    "f05_glycaemia--K1--opposite.homa_ir.male.glucose_fasting:optimal_insulin_fasting:optimal-_homa_ir:critical_high--none",
  ],
};

// ─── Text changes in this round ───

const a1c = row(K.a1c);
const a1cP = row(K.a1cP);
const ins = row(K.ins);

const A1C_RULE_EN =
  " Classification precision (round 2; for engineering, check D1, decimals 1): a result in % is rounded to one decimal before it is compared with the row's limits, so 5.64% reads 5.6% (in range) and 5.65% reads 5.7% (above range). A result in mmol/mol is converted as value x 0.0915 + 2.15 (unit-conversions.ts line 434) and the converted value is rounded the same way: 23 mmol/mol, Echevarne's printed floor, then reads 4.3% (in range), 38 mmol/mol reads 5.6% (in range) and 39 mmol/mol, where the ADA prediabetes band starts ('A1C 5.7–6.4% (39–47 mmol/mol)', f05-E03), reads 5.7% (above range). One exception: 47 mmol/mol converts to 6.45% and would round to 6.5%, while the ADA diabetes criterion is 'A1C ≥6.5% (≥48 mmol/mol)' (f05-E04), so AL-06 is applied to a mmol/mol result from 48 mmol/mol. Today the app classifies the unrounded converted value (process-results.ts lines 364 and 433-435; zone-classifier.ts lines 86-87), so 23 mmol/mol reads below range and 38 mmol/mol above range; the rounding step is an app change outside this file (workstream 3).";
const A1C_RULE_ES =
  " Precisión de la clasificación (ronda 2; para ingeniería, comprobación D1, decimales 1): un resultado en % se redondea a un decimal antes de compararlo con los límites de la fila, así que 5,64 % se lee 5,6 % (en rango) y 5,65 % se lee 5,7 % (por encima del rango). Un resultado en mmol/mol se convierte como valor x 0,0915 + 2,15 (unit-conversions.ts, línea 434) y el valor convertido se redondea igual: 23 mmol/mol, el límite inferior impreso por Echevarne, se lee entonces 4,3 % (en rango), 38 mmol/mol se lee 5,6 % (en rango) y 39 mmol/mol, donde empieza la banda de prediabetes de la ADA ('A1C 5.7–6.4% (39–47 mmol/mol)', f05-E03), se lee 5,7 % (por encima del rango). Una excepción: 47 mmol/mol se convierte en 6,45 % y se redondearía a 6,5 %, mientras que el criterio de diabetes de la ADA es 'A1C ≥6.5% (≥48 mmol/mol)' (f05-E04), así que AL-06 se aplica a un resultado en mmol/mol a partir de 48 mmol/mol. Hoy la app clasifica el valor convertido sin redondear (process-results.ts, líneas 364 y 433-435; zone-classifier.ts, líneas 86-87), así que 23 mmol/mol se lee por debajo del rango y 38 mmol/mol por encima; el paso de redondeo es un cambio de la app fuera de este archivo (workstream 3).";
const A1CP_RULE_EN =
  " Classification precision (round 2): as on the general HbA1c row, a % result is rounded to one decimal before comparison, and a mmol/mol result is converted (value x 0.0915 + 2.15) and rounded the same way, so Echevarne's printed mmol/mol interval, 23-43 (catalogue line 244), reads 4.3-6.1%, the same as its % interval (line 243). Unrounded, as the app works today, 23 mmol/mol (4.2545%) reads below range.";
const A1CP_RULE_ES =
  " Precisión de la clasificación (ronda 2): como en la fila general de la HbA1c, un resultado en % se redondea a un decimal antes de compararlo, y un resultado en mmol/mol se convierte (valor x 0,0915 + 2,15) y se redondea igual, así que el intervalo impreso por Echevarne en mmol/mol, 23-43 (línea 244 del catálogo), se lee 4,3-6,1 %, igual que su intervalo en % (línea 243). Sin redondear, como funciona hoy la app, 23 mmol/mol (4,2545 %) se lee por debajo del rango.";

const old = {
  a1cNote: a1c.method_note,
  a1cNoteEs: a1c.method_note_es,
  a1cPNote: a1cP.method_note,
  a1cPNoteEs: a1cP.method_note_es,
  insEn: ins.messages.en.in_range,
  insEs: ins.messages.es.in_range,
  insExpl: ins.explanatory_numbers.slice(),
};

a1c.method_note = old.a1cNote + A1C_RULE_EN;
a1c.method_note_es = old.a1cNoteEs + A1C_RULE_ES;
a1cP.method_note = old.a1cPNote + A1CP_RULE_EN;
a1cP.method_note_es = old.a1cPNoteEs + A1CP_RULE_ES;

const INS_EN_ANCHOR = "and shows no optimal band for insulin on its own.";
const INS_ES_ANCHOR = "y no muestra banda óptima para la insulina sola.";
if (!old.insEn.includes(INS_EN_ANCHOR) || !old.insEs.includes(INS_ES_ANCHOR)) throw new Error("insulin anchors not found");
ins.messages.en.in_range = old.insEn.replace(
  INS_EN_ANCHOR,
  INS_EN_ANCHOR + " An insulin in the upper part of this interval can give a HOMA-IR above EVA's reference limit of 3.46 even when your glucose is normal, so read this result together with your HOMA-IR.",
);
ins.messages.es.in_range = old.insEs.replace(
  INS_ES_ANCHOR,
  INS_ES_ANCHOR + " Una insulina en la parte alta de este intervalo puede dar un HOMA-IR por encima del límite de referencia de EVA, 3,46, aunque tu glucosa sea normal, así que interpreta este resultado junto con tu HOMA-IR.",
);
ins.explanatory_numbers = [2, 3.46, 4, 8];

// ─── New evidence ───

const evidence = [
  {
    id: "f05-F01",
    supports: [{ row_key: K.fru, bound: "optimal_high" }],
    identifier: { type: "url", value: "https://pmc.ncbi.nlm.nih.gov/articles/PMC4212648/" },
    citation:
      "Selvin E, Rawlings AM, Grams M, Klein R, Sharrett AR, Steffes M, Coresh J. Fructosamine and glycated albumin for risk stratification and prediction of incident diabetes and microvascular complications: a prospective cohort analysis of the Atherosclerosis Risk in Communities (ARIC) study. Lancet Diabetes Endocrinol 2014;2(4):279-288. PMID 24703046, PMCID PMC4212648 (NIH author manuscript).",
    year: 2014,
    quote:
      "Because there are no established clinical cut-points for fructosamine or glycated albumin, we divided persons without diabetes into three categories defined by the <75 th , 75 th to 95 th , and >95 th percentiles.",
    location: "Methods, statistical analysis (PMC article page; the page prints the ordinal suffixes as separate superscripts, 'th')",
    design: "prospective cohort (ARIC, visit 2 in 1990-1992; fructosamine measured in 2012-2013 on stored serum)",
    n: 11348,
    follow_up_years: 17.7,
    outcome: "incident diagnosed diabetes (2,882 cases among 10,946 participants without diagnosed diabetes); chronic kidney disease and retinopathy in the same paper",
    population_age: "middle-aged black and white US adults attending ARIC visit 2 (age range not read in this task)",
    population_sex: "both",
    assay: "fructosamine, Roche Diagnostics, on a Roche Modular P800 system (inter-assay coefficient of variation 3.0%)",
    band_rule: "none",
    basis_class: "outcome_nadir",
    proposed_grade: "B",
    age_stratified_statement: "No age-stratified fructosamine estimates in the abstract or in the passages read; the categories are percentiles of the whole cohort.",
    notes:
      "Opened in this task on the PMC article page (docs/signoff/tools/quote-check.js, run online with a scratch cache directory, found this quote exactly) and in the NCBI eutils XML of PMC4212648; Europe PMC's fullTextXML returned HTTP 500, and the programme's cache holds only the abstract under the PMCID, so this record cites the page URL. The same page gives the cohort's percentiles on the Roche assay: 'All models are centered at the 50 th percentile (fructosamine: 228 umol/L', and 'above the 95 th percentile (fructosamine of 264 umol/L', against Echevarne's upper limit of 236 µmol/L; and 'a median of 17.7 years of follow-up' for incident diabetes. It supports the removal of production's optimal ceiling of 200 µmol/L (changes): the outcome cohort had no clinical cut-point to use and built its categories from its own distribution on another assay. Proposed grade B (prospective cohort of more than 10,000 adults followed for more than 5 years); the verifier graded f05-E44 and f05-E45, from the same paper, B. Grade to be assigned by the verifier.",
  },
];

// ─── Change records ───

const changes = [
  {
    row_key: K.glu,
    field: "critical_low",
    from: null,
    to: 50,
    direction: "tighten",
    reason:
      "Against production, whose snapshot has no critical-limit column (check D5 reads production's critical limits as null). The verify file already has 50 mg/dL; this record carries the change because no earlier file records it, and D5 listed it 'without a reason'. 50 mg/dL equals the governance draft docs/signoff/work/governance/critical-limits.json entries[3] (critical_low 50, critical_high 400), which central item C-04 asks the family's rows to match. In 417 US hospitals the median low glucose critical limit rose from 45 mg/dL in 1990 to 50 mg/dL (range 35-60) in 2025, below the 54 mg/dL threshold for neuroglycopenic loss of awareness (f05-E23, f05-E24); the point-of-care lists in Table 8 of PMC11899349 (Diagnostics 2025) give a low median of 50 mg/dL (f05-E25), and the 2026 point-of-care survey also 50 mg/dL (f05-E26). Abstracts of PMID 42551888 and 42072765 and the cached full text of PMC11899349 were opened in this task. A critical limit is its own field and never derives from the reference interval (PLAN section 4). The alternatives 45/450 and 54/450 are physician question f05-Q04 (research file). Tighten: a bound added where production had none.",
    evidence_ids: ["f05-E23", "f05-E24", "f05-E25", "f05-E26"],
    issue_ids: [L.d5Glu],
  },
  {
    row_key: K.glu,
    field: "critical_high",
    from: null,
    to: 400,
    direction: "tighten",
    reason:
      "Against production (no critical-limit column; D5 reads null). The verify file already has 400 mg/dL; recorded here for check D5. 400 mg/dL equals critical-limits.json entries[3], whose recommendation reads '400 is the Spanish outpatient median; the hospital medians (450-500) are set for supervised patients'. Of the sources opened in this task, the point-of-care lists in Table 8 of PMC11899349 (Diagnostics 2025, read in the programme's cache) give a high median of 400 mg/dL (range 200-500; f05-E25), while the 2025 network-hospital median (f05-E24) and the 2026 point-of-care median (f05-E26) are 450 mg/dL; the Spanish outpatient survey (Llopis 2010) was not opened by the research, the verifier or this fixer. The choice between 400 and 450 mg/dL is physician question f05-Q04. Tighten: a bound added where production had none.",
    evidence_ids: ["f05-E25", "f05-E24", "f05-E26"],
    issue_ids: [L.d5Glu],
  },
  {
    row_key: K.fru,
    field: "optimal_high",
    from: 200,
    to: null,
    direction: "loosen",
    reason:
      "Against production (the verify file already has null; recorded here because no earlier file carries the change, and check D5 lists it). PLAN section 4 links an optimal band to the lowest risk of hard outcomes in prospective data, and section 5 gives a bound without such a source no band. No source opened gives an outcome bound at 200 µmol/L. The only outcome cohort with cut-points, ARIC, divided people by its own percentiles 'Because there are no established clinical cut-points for fructosamine or glycated albumin' (f05-F01), on a Roche assay whose 50th and 95th percentiles were 228 and 264 µmol/L (same page); incident diabetes was raised above that 95th percentile, HR 4.96 (4.36-5.64) (f05-E44), and chronic kidney disease, HR 1.50 (1.22-1.85), against people below the 75th percentile (f05-E45). Echevarne's 122-236 µmol/L equals the 95% range of the enzymatic GlyPro assay, which its authors call 'lower' than the NBT range (f05-E42), so the cohort's percentiles do not transfer to Echevarne's scale before the methods letter is answered. Low values also carried excess mortality (AMORIS, 215,011 adults without diabetes, lowest decile HR 1.20, 1.11 after six other biomarkers; f05-E46), so a ceiling alone would not describe the evidence. Gate 1 decision G2 (DR-2026-09-25-05, decision-register.md line 168) kept 200 as provisional; it is not one of the CEO's locked decisions. Grade A or B quotes: f05-E44, f05-E45 and f05-E46 (verifier grade B), and f05-F01 (proposed B, same ARIC paper); all abstracts and the ARIC full text were opened in this task. Not scored either way (marker-classes.json, may_be_scored false). Physician question f05-Q06.",
    evidence_ids: ["f05-F01", "f05-E44", "f05-E45", "f05-E46", "f05-E42"],
    issue_ids: [L.d5Fru],
  },
  {
    row_key: K.ins,
    field: "optimal_high",
    from: 8,
    to: null,
    direction: "loosen",
    reason:
      "Against production (the verify file already has null; recorded for check D5). No source opened gives 8 µU/mL. The only outcome-linked value is a definition, 'a fasting insulin level of ≥10 μU/mL', in one NHANES cohort of 9,778 adults (cancer death, adjusted HR 2.04, 1.24-3.34; f05-E50, grade C). In a meta-analysis of seven articles (prospective studies only) with 26,976 adults without diabetes, the highest against the lowest fasting-insulin category gave an all-cause RR of 1.13 (1.00-1.27; P=0.058) (f05-E51, grade C). Genetically predicted insulin raised coronary artery disease, OR 1.79 (1.34-2.40) (f05-E53, grade A), which supports class a but defines no threshold. Twelve commercial immunoassays from nine manufacturers differed from mass spectrometry (LC-MS) by -298.2 to +302.6 pmol/L, and 'Only one assay method showed full agreement with the IDMS method' (f05-E52, grade B), so a cut-point set on one assay does not transfer to Echevarne's chemiluminescence assay (catalogue line 278). Under PLAN sections 4 and 5 the row has no optimal band (verifier grade D); HOMA-IR, the locked member of the insulin-resistance group, carries the band. Grade A or B quotes: f05-E53 (A) and f05-E52 (B); the four abstracts were opened in this task. Physician question f05-Q07.",
    evidence_ids: ["f05-E52", "f05-E53", "f05-E50", "f05-E51"],
    issue_ids: [L.d5Ins],
  },
  {
    row_key: K.ins,
    field: "reference_low",
    from: 0,
    to: null,
    direction: "neutral",
    reason:
      "Against production (the verify file already has null; recorded for check D5). Echevarne prints '<29.1' µU/mL with no lower limit for B5600/D0154 (docs/vendor/echevarne/catalogo-2026-08-25.tsv line 278, read in this task), and PLAN section 4 makes Echevarne's printed interval the reference interval. Null and 0 classify every possible insulin value the same way: classifyZone returns below range only for a value under a non-null lower limit (zone-classifier.ts line 86), and no insulin result is below 0. No client value changes category, so no grade A or B quote applies; the compile's arithmetic labels any removed bound 'loosen', but nothing flagged before becomes unflagged. The same change was made for hs-CRP in f04 (B01).",
    evidence_ids: [],
    issue_ids: [L.d5Ins],
  },
  {
    row_key: K.a1cP,
    field: "row",
    from: null,
    to: "row added: female, All Adults, pregnancy; reference 4.3-6.1% (Echevarne), no optimal band, no action limits, no critical limit, grade D",
    direction: "neutral",
    reason:
      "Against production, which has no state rows (check D5: 'row only in seed'). PLAN section 4 shows declared pregnancy against 'the laboratory interval only, no optimal category, no score, no biological age', and state-rules.md section 2.1 makes the app show 'the laboratory's printed reference interval'. For HbA1c that interval is Echevarne's 4.3-6.1% (H1420/B0031, catalogue line 243; 23-43 mmol/mol for B0826, line 244; both read in this task), while the general row's ceiling of 5.6% is the ADA decision limit, taken from 'Criteria defining prediabetes in nonpregnant individuals' (ADA 2026, Table 2.2, f05-E03). The general row cannot show the laboratory's interval, so this row carries it; it adds no optimal band and no action limit. HbA1c changes in pregnancy: trimester intervals of 4.3-5.4%, 4.4-5.4% and 4.7-5.7% against 4.8-5.5% outside pregnancy (f05-E40, PMID 22117781, abstract opened in this task), and the ADA lists pregnancy among conditions 'associated with an altered relationship between A1C and glycemia' (f05-E08). The app picks this row only once it reads the declared state (central item C-08); the row's C1, D2 and D3 failures come from that and from the runner's state labels, not from the row. Physician questions f05-Q05 (research file) and f05-VQ4 (verify file).",
    evidence_ids: ["f05-E14", "f05-E03", "f05-E40", "f05-E08", "f05-E12"],
    issue_ids: [L.d5A1cP],
  },
];

const A1C_REASON =
  "Confirmed ledger issue (J2, definition:reference interval; both refuters confirmed): the row's limits copy ADA's 5.7% (39 mmol/mol) and Echevarne's 4.3% (23 mmol/mol) exactly only when results are compared at one decimal, and the app compares the unrounded converted value (process-results.ts line 364; zone-classifier.ts lines 86-87, read in this task). The rule is written into the row, as the judge's resolution asks; its implementation (rounding before classifyZone, AL-06 at 48 mmol/mol for mmol/mol results, fixtures for 23, 38, 39, 47 and 48 mmol/mol and for 5.6, 5.65 and 5.7%, and the check D1 decimals table) is an app change outside this file. Every pair was recomputed in this task with the app's equation (value x 0.0915 + 2.15): 22 gives 4.163, 23 gives 4.2545, 25 gives 4.4375, 26 gives 4.529, 36 gives 5.444, 37 gives 5.5355, 38 gives 5.627, 39 gives 5.7185, 43 gives 6.0845, 44 gives 6.176, 47 gives 6.4505 and 48 gives 6.542. One-decimal rounding reproduces the ADA pairs 5.7% = 39 and 6.5% = 48 mmol/mol (f05-E03, f05-E04), Echevarne's 4.3-6.1% = 23-43 mmol/mol (catalogue lines 243-244, f05-E14) and the eight dual-unit limits of f05-E40 (for example 29-37 mmol/mol = 4.8-5.5%), and fails only at 47 mmol/mol against the 6.5% limit, hence the stated exception. No bound changes.";

changes.push(
  { row_key: K.a1c, field: "method_note", from: old.a1cNote, to: a1c.method_note, direction: "neutral", reason: A1C_REASON, evidence_ids: ["f05-E03", "f05-E04", "f05-E14", "f05-E40"], issue_ids: [L.confA1c] },
  { row_key: K.a1c, field: "method_note_es", from: old.a1cNoteEs, to: a1c.method_note_es, direction: "neutral", reason: "Spanish text of the method-note change above (central item C-11): the same rule, numbers and sources, with decimal commas.", evidence_ids: ["f05-E03", "f05-E04", "f05-E14"], issue_ids: [L.confA1c] },
  { row_key: K.a1cP, field: "method_note", from: old.a1cPNote, to: a1cP.method_note, direction: "neutral", reason: "The same defect as the confirmed HbA1c issue (J2) reaches this row's lower limit: Echevarne prints 23 mmol/mol as the floor of B0826 (catalogue line 244), which converts to 4.2545% and reads below the 4.3% floor unless rounded. The rule of the general row is written here too; 43 mmol/mol converts to 6.0845% and reads 6.1%, in range, as the laboratory prints it. No bound changes.", evidence_ids: ["f05-E14"], issue_ids: [L.confA1c] },
  { row_key: K.a1cP, field: "method_note_es", from: old.a1cPNoteEs, to: a1cP.method_note_es, direction: "neutral", reason: "Spanish text of the method-note change above (central item C-11).", evidence_ids: ["f05-E14"], issue_ids: [L.confA1c] },
  {
    row_key: K.ins,
    field: "messages.en.in_range",
    from: old.insEn,
    to: ins.messages.en.in_range,
    direction: "neutral",
    reason:
      "Confirmed ledger issue (J5, definition:optimal band, insulin) and check K1: today the app labels any in-range insulin 'Optimal' because the row has no band (zone-classifier.ts line 90, zone-config.ts line 18; a central fix, workstream 3), and the same draw can show HOMA-IR 'Above Range'. The added sentence tells the client that this combination is expected: HOMA-IR is glucose x insulin / 405 (the app's formula; f05-E58 for the model), so with glucose at 74 to 90 mg/dL any insulin above 3.46 x 405 / glucose, about 18.9 down to 15.6 µU/mL, gives a HOMA-IR above its reference limit of 3.46, well inside Echevarne's '<29.1' µU/mL. The sentence names no condition and asks for no action; the rest of the text is unchanged. It removes the contradiction between the two texts, not the label, which only the central in_range zone removes.",
    evidence_ids: ["f05-E58"],
    issue_ids: [L.confIns, ...L.k1],
  },
  { row_key: K.ins, field: "messages.es.in_range", from: old.insEs, to: ins.messages.es.in_range, direction: "neutral", reason: "Spanish text of the in-range change above, with the same meaning and the number written 3,46.", evidence_ids: ["f05-E58"], issue_ids: [L.confIns, ...L.k1] },
  { row_key: K.ins, field: "explanatory_numbers", from: old.insExpl, to: ins.explanatory_numbers, direction: "neutral", reason: "The new in-range sentence quotes 3.46, HOMA-IR's reference limit, which is not a bound of this row (check M4).", evidence_ids: [], issue_ids: [L.confIns] },
);

// ─── Physician questions ───

const physician_questions = [
  {
    id: "f05-Q01",
    row_key: K.glu,
    question:
      "Fasting glucose at 70 and over (check N1): the optimal band of 74 to 90 mg/dL is a locked CEO decision and applies at every adult age. Keep the messages as they are, or add an older-adult sentence to the above-optimal message? (Carried from the research file into the decisions file in round 2, with the evidence below.)",
    why:
      "NHANES 2015-2018 healthy adults (docs/signoff/work/nhanes/distributions.json, fasting subsample, read in this task from the family input bundle): at 70-79, 69.64% of women (n 174) and 83.92% of men (n 163) fall outside the optimal band, and 32.33% and 51.78% are above 99 mg/dL; check N1 makes more than 60% non-optimal at 70-79 a physician question. The band's outcome source includes the oldest adults: in 12,455,361 Korean adults, 'The fasting glucose levels associated with the lowest mortality were 80-94 mg/dL regardless of sex and age'; at 100-125 mg/dL each 18 mg/dL rise went with 30% more mortality at 18-34 years against 10% (HR 1.10, 1.02 to 1.19) at 75-99 years, and 'The associations of hyperglycemia with mortality were stronger at younger ages' (f05-E15, PMID 28811570, abstract opened in this task). So 91 to 94 mg/dL lies inside that cohort's lowest-mortality category at every age but reads above optimal here; no source opened gives a separate estimate for 85 and over. Any change to the band needs a CEO question with grade A or B evidence from 2024 to 2026 (PLAN section 2); the verifier opened two 2024-2025 papers and found none.",
    evidence_ids: ["f05-E15", "f05-E16"],
    options: [
      "Keep the band and the messages as they are (the research file's recommendation).",
      "Keep the band and add to the above-optimal message that values a little above 90 mg/dL are common after 70; the physician approves the exact sentence.",
      "Ask the CEO to reopen the band for 70 and over (no 2024-2026 grade A or B evidence was found, so this is not recommended).",
    ],
  },
  {
    id: "f05-Q03",
    row_key: K.a1c,
    question:
      "HbA1c in adults of 70 and over, and in women (check N1): keep one optimal band, 4.5 to 5.4%, for all adults, or show HbA1c from age 70 as in range or out of range only? The 5.6% reference limit is the ADA decision limit and stays at every age. (Carried from the research file into the decisions file in round 2.)",
    why:
      "NHANES 2015-2018 healthy adults (input bundle, read in this task): at 70-79, 69.92% of women (n 360) and 71.11% of men (n 331) fall outside the optimal band, and 46.4% and 45.47% are above 5.6%; check N1 makes more than 60% a physician question. HbA1c rises with age without diabetes: 'A1C levels are positively associated with age in nondiabetic populations even after exclusion of subjects with IFG and/or IGT', with 97.5th percentiles of 6.6% and 6.2% at 70 and over against 6.0% and 5.6% under 40 (f05-E37); 'For people aged ≥60 years the URL was 47.5 mmol/Mol (6.5%)' (f05-E38); 'Almost half of the sample aged 65 years or older had median values >5.7%' in a Spanish sample (f05-E39). The outcome sources behind the band include older adults but give no estimate by age: NHANES III adults aged 20 and older (f05-V01, PMID 20923991), four pooled US cohorts with a mean age of 57.1 years (f05-E32), adults aged 50 and over in CHANCES (f05-E34) and adults aged 40 to under 80 in Alberta (f05-E36, grade C). None gives a band for 70 and over or 85 and over, so a separate older-adult band has no outcome basis (PLAN section 4) and is not offered. Sex: in Alberta, 5.5-5.9% raised cardiovascular hospitalisation in men (aHR 1.12, 1.07-1.19) but not in women (aHR 1.01, 0.95-1.08) (f05-E36, retrospective, grade C). The above-optimal message already says that HbA1c rises slowly with age, and the above-range message keeps the ADA bands apart from age drift. All the abstracts cited here were opened in this task.",
    evidence_ids: ["f05-E37", "f05-E38", "f05-E39", "f05-V01", "f05-E32", "f05-E34", "f05-E36"],
    options: [
      "One band for all adults, with the age-drift sentence already in the messages (the research file's recommendation).",
      "From age 70, show HbA1c as in range or out of range only (a display rule; no bound changes; the app needs an age rule for it).",
      "For women, an optimal ceiling equal to the reference limit, 5.6% (a sex split resting on grade C evidence only, f05-E36).",
    ],
  },
  {
    id: "f05-Q06",
    row_key: K.fru,
    question:
      "Fructosamine: confirm that production's optimal ceiling of 200 µmol/L (Gate 1 decision G2, provisional) is removed until Echevarne confirms its method, so that fructosamine shows in range or out of range only? (Carried from the research file into the decisions file in round 2.)",
    why:
      "No source opened gives an outcome bound at 200 µmol/L. The outcome cohort, ARIC (10,946 adults without diagnosed diabetes, median 17.7 years), divided people by its own percentiles 'Because there are no established clinical cut-points for fructosamine or glycated albumin' (f05-F01), on a Roche assay whose 50th and 95th percentiles were 228 and 264 µmol/L; incident diabetes was raised above the 95th percentile (HR 4.96, 4.36-5.64; f05-E44). Echevarne's 122-236 µmol/L equals the 95% range of the enzymatic GlyPro assay, 'lower' than the NBT range (f05-E42), so the cohort's cut-points do not transfer. Low values also carried excess mortality in AMORIS (lowest decile HR 1.20, 1.11 after six other biomarkers; f05-E46). PLAN section 4 defines an optimal band by the lowest risk of hard outcomes in prospective data and says an optimal bound may not rest only on a laboratory interval; under section 5 a bound with no source is grade D, which gives no optimal band. G2 (DR-2026-09-25-05) was provisional, not a locked CEO decision. Fructosamine is not scored either way (marker-classes.json, may_be_scored false).",
    evidence_ids: ["f05-F01", "f05-E44", "f05-E45", "f05-E42", "f05-E46"],
    options: [
      "Confirm the removal until the methods letter is answered, then re-derive a band if an outcome source on Echevarne's method exists (recommended).",
      "Keep 200 µmol/L as expert opinion; no source supports it, which PLAN section 5 grades D, so this needs the physician's explicit exception.",
    ],
  },
  {
    id: "f05-Q07",
    row_key: K.ins,
    question:
      "Fasting insulin: confirm no optimal band (production had 8 µU/mL), and read Echevarne's '<29.1' as an upper limit of 29.1 µU/mL (today) or 29.0 µU/mL? (Carried from the research file into the decisions file in round 2.)",
    why:
      "No source opened gives 8 µU/mL. The only outcome-linked value is a definition, 'a fasting insulin level of ≥10 μU/mL', in one NHANES cohort of 9,778 adults (cancer death, adjusted HR 2.04, 1.24-3.34; f05-E50, grade C); in a meta-analysis of 26,976 adults the highest against the lowest fasting-insulin category gave an all-cause RR of 1.13 (1.00-1.27; P=0.058) (f05-E51, grade C); genetically predicted insulin raised coronary artery disease (OR 1.79, 1.34-2.40; f05-E53, grade A) without defining a threshold; and 12 commercial immunoassays differed from mass spectrometry (LC-MS) by -298.2 to +302.6 pmol/L, with 'Only one assay method showed full agreement with the IDMS method' (f05-E52, grade B), so a cut-point from one assay does not transfer to Echevarne's chemiluminescence assay. HOMA-IR, the locked member of the insulin-resistance group, carries the band. Echevarne prints '<29.1' µU/mL (catalogue line 278): read as 29.1, a result of exactly 29.1 is in range in EVA while the laboratory flags it; read as 29.0, it is above range in both.",
    evidence_ids: ["f05-E50", "f05-E51", "f05-E52", "f05-E53"],
    options: [
      "No optimal band; upper limit 29.1 µU/mL (recommended in the research file; matches check D3's reading of the catalogue).",
      "No optimal band; upper limit 29.0 µU/mL (matches the laboratory's flag for a result of exactly 29.1).",
    ],
  },
  {
    id: "f05-DQ1",
    row_key: K.ins,
    question:
      "Fasting insulin inside its interval with a HOMA-IR above 3.46 (check K1): accept this as an expected one-step disagreement once the app shows rows without an optimal band as 'in range', with the insulin text pointing to HOMA-IR (recommended), or give insulin an upper limit derived from HOMA-IR?",
    why:
      "Check K1 finds glucose 76.22 mg/dL (optimal) with insulin 21.82 µU/mL giving HOMA-IR 4.107, above the 3.46 limit, at 83 ages from 18 to 100 in both sexes (docs/signoff/work/checks/f05_glycaemia-r1.json). It counts as an opposite pair only because the app labels any in-range insulin 'optimal' when the row has no band (zone-classifier.ts line 90), a confirmed central defect: PLAN section 4 shows a marker without outcome evidence as in range or out of range only. HOMA-IR is glucose x insulin / 405, so with glucose at 74 to 90 mg/dL any insulin above 3.46 x 405 / glucose, about 18.9 down to 15.6 µU/mL, gives a HOMA-IR above 3.46, inside Echevarne's '<29.1' µU/mL. No bound can move inside the definitions: glucose and HOMA-IR are locked (PLAN section 2), 29.1 µU/mL is Echevarne's printed interval (catalogue line 278), and insulin has no outcome band (grade D; assays differ by -298.2 to +302.6 pmol/L against mass spectrometry (LC-MS), f05-E52). Round 2 adds to the insulin in-range message that an insulin in the upper part of its interval can give a HOMA-IR above 3.46 even with a normal glucose. The 3.46 limit is the 90th-percentile value reported for Spanish adults (f05-E55).",
    evidence_ids: ["f05-E52", "f05-E58", "f05-E55"],
    options: [
      "Keep every bound; once the app has the in-range zone (workstream 3), record the pattern as an accepted one-step disagreement (check K1, docs/signoff/work/coherence/accepted-reasons.json), with the insulin text as written (recommended).",
      "Set an insulin upper limit of 15.5 µU/mL (the highest one-decimal value that keeps HOMA-IR at or below 3.46 with a glucose of 90 mg/dL) as expert opinion; it would replace Echevarne's interval without a named guideline, which PLAN section 4 does not allow, so it needs the physician's explicit exception.",
    ],
  },
];

// ─── Issues resolved by this file ───

const issues_addressed = [L.confA1c, L.confIns, L.d5Fru, L.d5Glu, L.d5A1cP, L.d5Ins, ...L.g2, ...L.n1];

const notes = [
  `Round 2 fixer decision for f05_glycaemia (batch B02), written 2026-11-08 from verify file sha256 ${verifySha}; no earlier decision file existed. AI work product for review by a licensed physician; AI pre-review, not a sign-off.`,
  "",
  "What changed. The six final_rows are the verifier's, with no bound, band, grade, class or band-rule change against the verify file. Text changes in this round: a classification-precision rule in the method notes of both HbA1c rows (English and Spanish), one sentence in the insulin in-range message (English and Spanish) and 3.46 in its explanatory numbers. One new source record, f05-F01. The bound changes listed in changes (glucose critical limits 50 and 400 mg/dL; fructosamine optimal ceiling 200 µmol/L and insulin optimal ceiling 8 µU/mL removed; insulin floor 0 to null; the HbA1c pregnancy row) are against production and were already in the verify file; they are recorded here so that check D5 and the change report have a reason and a source for each (central items C-02 and C-21). The two loosenings rest on grade A or B quotes: f05-E44, f05-E45 and f05-E46 for fructosamine, f05-E52 and f05-E53 for insulin. The insulin floor (0 to null) is recorded as neutral because no possible insulin value changes category; the compile labels any removed bound 'loosen' by arithmetic and lists that difference as a warning, so the change report shows both.",
  "",
  "Confirmed issues (both in issues_addressed):",
  "(1) definition:reference interval, HbA1c (J2): the rounding rule is written into both HbA1c rows. Still needed outside this file: the app must round before classifyZone (process-results.ts line 364; zone-classifier.ts lines 86-87), apply AL-06 to a mmol/mol result from 48 mmol/mol, add fixtures for 23, 38, 39, 47 and 48 mmol/mol and for 5.6, 5.65 and 5.7%, and build the check D1 decimals table. Not yet in known-issues.md; proposed as a central item for workstream 3.",
  "(2) definition:optimal band, insulin (J5): the f05 rows already meet PLAN section 4 (insulin, fructosamine and the HbA1c pregnancy row have no optimal bound, band_rule none and grade D, and give their text under in_range). Still needed outside this file: an in_range zone with a neutral label in zone-classifier.ts and zone-config.ts, fed by Msg_Optimal of the rows without a band, as both refuters ask for the known-issues list. The insulin in-range text now explains why insulin can be in range while HOMA-IR is above range.",
  "",
  "Script issues resolved here (in issues_addressed): G2 for the six rows (this file holds a final row for each, central item C-01); D5 for the glucose critical limits, the fructosamine optimal ceiling, the insulin bounds and the HbA1c pregnancy row (change records with reason and source); N1 for glucose and HbA1c at 70-79 (physician questions f05-Q01 and f05-Q03 carried into this file with the 2015-2018 shares and the age evidence; the n1-resolutions.json entry is central item C-14).",
  "",
  "Script issues left open, with the reason (not in issues_addressed):",
  "- K1, two patterns (glucose optimal with insulin read as optimal giving HOMA-IR above 3.46): no bound can move inside the definitions (glucose and HOMA-IR locked; 29.1 µU/mL is Echevarne's printed interval; insulin grade D, no band). The pattern is an opposite pair only because of the label in confirmed issue (2); with the in_range zone it becomes a one-step disagreement for docs/signoff/work/coherence/accepted-reasons.json (central item C-13). Physician question f05-DQ1; the insulin text is changed.",
  "- M1, HOMA-IR below range: HOMA-IR is glucose x insulin / 405 and cannot fall below its locked floor of 0, so the zone holds no possible value. The programme's validator (docs/signoff/tools/lib/row-checks.js, reachableZones) and check D3 (sameBound) already read a floor of 0 as no lower limit, while the runner's M1 probes a negative value. A message for an impossible value would only satisfy that probe, and the validator would list it for deletion; writing reference_low as null would change a locked row, which check E6 compares literally. Proposed central fix: M1 to follow row-checks.js for a floor of 0.",
  "- S2, fructosamine: the row is class a with may_be_scored false, as marker-classes.json says (C-16); the failure is the version 2 score engine still scoring it (longevity-score.ts line 196), which workstream 3 removes.",
  "- C1, D2 and D3 on the HbA1c pregnancy row: the app's picker does not read the declared state (C-08); D2's expected-label table has no entry for 'Pregnancy' and 'Embarazo' (the defect C-12 describes); D3 maps rows to ages through ageGroupContains (reference-row.ts), which knows no pregnancy label. The row is kept because PLAN section 4 shows declared pregnancy against the laboratory interval, and the general HbA1c row's 5.6% is the ADA decision limit, not Echevarne's printed 4.3-6.1%.",
  "Disputed issue left as it is: K1 on homa_ir (J1). Judge issues that are open but not confirmed are not worked in this round.",
  "",
  "Age pass (check C3; judge J5 asked for it in the decisions file):",
  "- 18-19: the adult rows apply. Echevarne prints glucose from age 16 (74-106 mg/dL, catalogue line 173) and HbA1c, fructosamine and insulin for ages 0-999 (lines 243, 150 and 278).",
  "- Fasting glucose: the locked band (74-90 mg/dL) and limits (74-99 mg/dL) apply unchanged at 70-84 and at 85 and over. The outcome source includes ages 75-99 (f05-E15: lowest mortality at 80-94 mg/dL 'regardless of sex and age'); no source opened gives a separate estimate for 85 and over. Question f05-Q01.",
  "- HbA1c: one band (4.5-5.4%) at every age; the 5.6% ADA limit is not age-adjusted. The outcome sources reach adults under 80 (f05-E36) and adults of 50 and over or 20 and over with no upper age (f05-E34, f05-V01); none gives an older-adult band. HbA1c drifts upward with age without diabetes (f05-E37, f05-E38, f05-E39). Question f05-Q03.",
  "- Fructosamine and insulin: the laboratory interval only, at every age (no band).",
  "- HOMA-IR: the locked band applies at every age. EPIRCE (adults aged 20-92) found 'a significant non-linear effect of age on the accuracy of HOMA-IR' in non-diabetic women but not in men (f05-E55, abstract opened in this task); no outcome band by age exists.",
  "",
  "Physician questions in this file: f05-Q01 and f05-Q03 (N1, updated), f05-Q06 and f05-Q07 (the two removed optimal ceilings), f05-DQ1 (K1, new). Still standing as written in the research and verify files: f05-Q04, f05-Q05, f05-Q08, f05-Q09, f05-Q10, CEO question f05-L01, and f05-VQ1 to f05-VQ4 (f05-VQ1 replaces the rationale of f05-Q02).",
  "",
  "For the orchestrator: (a) f05-F01 cites the PMC page URL of PMC4212648, because the programme's cache holds only the abstract under that PMCID; docs/signoff/tools/quote-check.js found the quote exactly in this task with a scratch cache directory (docs/signoff/work/sources-cache was not written). (b) In declared pregnancy and lactation the app must show Echevarne's printed interval for the markers whose general row uses a decision limit (HbA1c 4.3-6.1% and glucose 74-106 mg/dL; state-rules.md 2.1): f05 has an HbA1c pregnancy row, no HbA1c lactation row, and its glucose rows are locked (CEO question f05-L01). (c) Research records f05-E13 and f05-E14 remain unopenable to the script (private catalogue URL); the vendored catalogue in the repository holds both lines. Research record f05-E06 (a pre-analytical rule) still fails E1 for lack of a number, which its source does not print; E1's specification leaves such records outside its scope (C-22). (d) A scratch compile of this file (compile.js --families f05_glycaemia, output outside the repository) and an offline scratch run of checks D2, D3, D5, C1, E1 to E4, E6, K1, L1, M1 to M4, N1, S2 and G2 on it gave: no f05 failure in D5, G2, M2, M4, E4 or E6; still failing, as described above, K1, M1, S2, and C1, D2 and D3 on the pregnancy row; N1 still fails until central item C-14 records the two questions in n1-resolutions.json; E3 is blocked on the grade C table; E1 flags research record f05-E06, and E2 flags research records f05-E13 and f05-E14 and, offline only, f05-F01, whose page this fixer did not write into the programme's cache (the check step's online cache fill fetches it; quote-check found it exactly online).",
  "",
  "Sources opened in this task: PubMed efetch abstracts of PMIDs 28811570, 18628569, 30755204, 31836306, 38639364, 26867584, 20200384, 41137002, 20923991, 24703046, 27751668, 11474831, 40802520, 40442727, 28811358, 28390156, 24131857, 22117781, 42551888 and 42072765; the NCBI eutils XML of PMC4212648 and its PMC article page (Europe PMC fullTextXML returned HTTP 500); from the programme's source cache, the ADA Standards of Care 2026 section 2 page (PMC12690183; Tables 2.1 and 2.2) and the full text of PMC11899349 (Table 8). Repository files read: the Echevarne catalogue (lines 150, 169-173, 243, 244 and 278), unit-conversions.ts, process-results.ts, zone-classifier.ts, zone-config.ts, longevity-score.ts, the NHANES 2015-2018 cells in the input bundle, critical-limits.json, decision-register.md, marker-classes.json and state-rules.md. WebSearch calls: 0.",
].join("\n");

const decision = {
  schema_version: "1",
  family: "f05_glycaemia",
  round: 2,
  decided_at: "2026-11-08",
  verify_sha256: verifySha,
  fixer_role: "physician fixer, round 2, batch B02 (AI work product for review by a licensed physician)",
  final_rows: rows,
  changes,
  issues_addressed,
  evidence,
  physician_questions,
  notes,
};

fs.writeFileSync(OUT, JSON.stringify(decision, null, 2) + "\n");
console.log(`wrote ${path.relative(ROOT, OUT)}; verify sha256 ${verifySha}; ${rows.length} rows, ${changes.length} changes, ${issues_addressed.length} issues, ${evidence.length} evidence, ${physician_questions.length} questions`);
