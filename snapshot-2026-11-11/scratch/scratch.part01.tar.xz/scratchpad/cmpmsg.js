const W='/home/user/eva-health/docs/signoff/work';
const en=require(W+'/compiled/B01-r4/biomarker-ranges-en.json').biomarker_ranges;
const es=require(W+'/compiled/B01-r4/rangos-biomarcadores-es.json').rangos_biomarcadores;
const idx={'albumin|both|All Adults':131,'albumin_globulin_ratio|both|All Adults':132,'globulin|both|All Adults':139,'total_protein|both|All Adults':143,'bun|both|All Adults':158,'urea|both|All Adults':159,'bun_creatinine_ratio|both|All Adults':160,'creatinine|male|All Adults':163,'creatinine|female|All Adults':164,'egfr_creatinine_based|both|18-39':165,'egfr_creatinine_based|both|40-84':166,'egfr_creatinine_based|both|85+':167,'cystatin_c|both|All Adults':170,'hs_crp|both|All Adults':4,'fibrinogen|both|All Adults':16};
const mapEN={below_range:'Msg_Critical_Low',below_optimal:'Msg_Below_Optimal',optimal:'Msg_Optimal',in_range:'Msg_Optimal',above_optimal:'Msg_Above_Optimal',above_range:'Msg_Critical_High'};
const mapES={below_range:'Msg_Crítico_Bajo',below_optimal:'Msg_Debajo_Óptimo',optimal:'Msg_Óptimo',in_range:'Msg_Óptimo',above_optimal:'Msg_Encima_Óptimo',above_range:'Msg_Crítico_Alto'};
let bad=0;
for(const f of ['f01_albumin_proteins','f03_kidney','f04_inflammation']){ const d=require(W+'/decisions/'+f+'.json');
 for(const r of d.final_rows){ const k=[r.marker_key,r.sex,r.age_group].join('|'); const i=idx[k]; const E=en[i], S=es[i];
  for(const z of Object.keys(r.messages.en)){ if(!mapEN[z]) { console.log(k,'zone not compiled:',z); continue;} if(E[mapEN[z]]!==r.messages.en[z]){bad++;console.log(k,'EN differs',z);} if(S[mapES[z]]!==r.messages.es[z]){bad++;console.log(k,'ES differs',z);} }
  if(E.Clinical_Notes!==r.clinical_notes_en){bad++;console.log(k,'EN note differs');}
  if(S['Notas_Clínicas']!==r.clinical_notes_es){bad++;console.log(k,'ES note differs');}
  if(E.Method_Note!==r.method_note){bad++;console.log(k,'method note differs');}
  if((S['Nota_Método']||null)!==(r.method_note_es||null)){bad++;console.log(k,'ES method note differs');}
 }}
console.log('differences',bad);
