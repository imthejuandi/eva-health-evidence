import { readCreatineDose, creatineCreatinineDivisor } from "@/lib/biomarkers/supplements";
const cases = ["5 g","5g/día","5 gramos al día","5000 mg","5","5000","5 al día","5/día","5 diarios","5 daily","3 a 5 g","entre 3 y 5 g","3 o 5 g","3-5 g","2 x 5 g","2x5g","5 g x 2","1 cacito de 5 g","1 medida de 5 g","1 cucharadita (5 g)","1 cacito (5 g)","1 scoop (5 g)","2 tomas de 2,5 g","2 cápsulas de 750 mg","3 días a la semana, 5 g","5 gm","5 gms","5 grms","5 mgs","1,250 g","1.500 g","2,500 g","0.500 g","2 500 mg","2 500 mg","2 500 mg","1 500 mg",".5 g",",5 g","0,3 g/kg/día","0,1 g/kg","1/2 g","3/5 g","-5 g","1 scoop","daily","0 g","2,5 g 2 veces al día","5 g a la semana","5 g/semana","5 g cada dos días","5 g en días alternos","5 g al día durante 2 semanas","5 g al día durante la semana","20 g durante 5 días y luego 5 g","creatina 5g","5.000 mg","1,5","2 cacitos (10 g)","5 g por la mañana","4 días/semana 5 g"];
for (const c of cases) {
  const g = readCreatineDose(c);
  console.log(JSON.stringify(c).padEnd(36), g === null ? "null" : +g.toFixed(4), g === null ? "" : creatineCreatinineDivisor(g).toFixed(4));
}
