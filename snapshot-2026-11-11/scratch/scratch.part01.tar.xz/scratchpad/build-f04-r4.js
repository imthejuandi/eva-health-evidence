// Builds round 4 of docs/signoff/work/decisions/f04_inflammation.json from the round 3 file.
"use strict";
const fs = require("fs");
const path = "/home/user/eva-health/docs/signoff/work/decisions/f04_inflammation.json";
const d = JSON.parse(fs.readFileSync(path, "utf8"));
const HS = "hs_crp|both|All Adults|none";
const FB = "fibrinogen|both|All Adults|none";
const hs = d.final_rows.find((r) => r.marker_key === "hs_crp");
const fb = d.final_rows.find((r) => r.marker_key === "fibrinogen");
const changes = [];
const ch = (row_key, field, from, to, direction, reason, evidence_ids, issue_ids) =>
  changes.push({ row_key, field, from, to, direction, reason, evidence_ids, issue_ids });

const I = {
  m5: "f04_inflammation--M5--hs_crp.both.All_Adults.none--none",
  m3fb: "f04_inflammation--M3--fibrinogen.both.All_Adults.none--none",
  m3hs: "f04_inflammation--M3--hs_crp.both.All_Adults.none--none",
  g6hs: "f04_inflammation--G6--hs_crp.both.All_Adults.none--none",
  e2hs: "f04_inflammation--E2--hs_crp.both.All_Adults.none--high",
  e4hs: "f04_inflammation--E4--hs_crp.both.All_Adults.none--high",
  defband: "f04_inflammation--definition:optimal_band--hs_crp.both.All_Adults.none--high",
  defclass: "f04_inflammation--definition:marker_classes--fibrinogen.both.All_Adults.none--none",
  p2: "f04_inflammation--P2--hs_crp.both.All_Adults.none--high",
  d3j1: "f04_inflammation--D3--hs_crp.both.All_Adults.none--high",
};

// ---------- hs-CRP: method note (seed duplicate sentence, J1 G6) ----------
const oldSeed = "Seed duplicate: rows 4 (category Heart) and 31 (Immune Regulation) carry identical bounds and texts; the seeder keeps row 31, and row 4 should be removed at compile. ";
const newSeed = "Seed duplicate, resolved at compile: the September seed held two hs-CRP rows with identical bounds and texts (index 4, category Heart; index 31, category Immune Regulation), and the seeder kept index 31; the compiled file docs/signoff/work/compiled/B01-r3/f04_inflammation/biomarker-ranges-en.json holds one hs-CRP row, index 4, category Heart, which is the row signed here. ";
if (!hs.method_note.includes(oldSeed)) throw new Error("seed sentence not found");
const hsMethodFrom = hs.method_note;
hs.method_note = hs.method_note.replace(oldSeed, newSeed);
ch(HS, "method_note", hsMethodFrom, hs.method_note, "neutral",
  "J1 (G6, minor): the note said the seeder keeps row 31 and row 4 should be removed at compile, but the compiled seed holds a single hs-CRP row, index 4 (category Heart), checked in docs/signoff/work/compiled/B01-r3/f04_inflammation/biomarker-ranges-en.json in this task. The sentence now states what the compile did. No bound changes.",
  [], [I.g6hs]);

// ---------- hs-CRP: reference source (J1 D3 minor; C-17 cite the PubMed record) ----------
const hsRefFrom = hs.reference_source;
hs.reference_source = "Decision limit 3.0 mg/L from the CDC/AHA 2003 scientific statement (Pearson TA et al., 'Markers of inflammation and cardiovascular disease: application to clinical and public health practice', Circulation 2003;107(3):499-511; PubMed record PMID 12551878, DOI 10.1161/01.cir.0000052939.59093.45): high relative-risk category '>3.0 mg/L' (f04-E01). The PubMed record has no abstract, the article is not in PMC, and the publisher page refused access in round 4 (HTTP 403), so the only full text opened is the PDF mirror that f04-E01 cites, which the source cache holds as a binary PDF the quote script cannot read. The same threshold is relayed in a PubMed abstract that the cache confirms: 'a uniform threshold to define high relative risk (>3 mg/l)' (f04-E02, PMID 16053959). Identical in effect to Echevarne B0851 '<3.01' mg/L (catalogue line 308, dated 01/06/2020) read at two decimals.";
ch(HS, "reference_source", hsRefFrom, hs.reference_source, "neutral",
  "J1 (D3, minor) and central item C-17 (cite the PubMed record, not a PDF mirror): the source now leads with the PubMed record of the named guideline and the cache-confirmed relay f04-E02 (PMID 16053959), and says plainly why the guideline quote itself cannot be confirmed by script (no abstract, not in PMC, publisher page 403 in this task, mirror cached as binary PDF). The bound 3 mg/L is unchanged. Whether the physician accepts this basis or prefers the Echevarne basis is F04-DQ-7.",
  ["f04-E01", "f04-E02"], []);
hs.reference_source_es = "Límite de decisión de 3,0 mg/L de la declaración científica CDC/AHA de 2003 (Pearson TA et al., 'Markers of inflammation and cardiovascular disease: application to clinical and public health practice', Circulation 2003;107(3):499-511; registro de PubMed PMID 12551878, DOI 10.1161/01.cir.0000052939.59093.45): categoría de riesgo relativo alto '>3,0 mg/L' (f04-E01). El registro de PubMed no tiene resumen, el artículo no está en PMC y la página del editor denegó el acceso en la ronda 4 (HTTP 403), así que el único texto completo abierto es la copia en PDF que cita f04-E01, que la caché de fuentes guarda como PDF binario que el script de citas no puede leer. El mismo umbral aparece en un resumen de PubMed que la caché confirma: 'a uniform threshold to define high relative risk (>3 mg/l)' (f04-E02, PMID 16053959). Equivale en la práctica al intervalo de Echevarne B0851 '<3,01' mg/L (línea 308 del catálogo, fechado el 01/06/2020) leído con dos decimales.";

// ---------- hs-CRP: Spanish physician-facing fields (J3 M5) ----------
hs.critical_none_reason_es = "Ninguno, porque una PCR ultrasensible baja no tiene significado clínico, y para valores altos solo una lista abierta (NHS Manchester, S8 en critical-limits.json) da un límite (300 mg/L), mientras que el límite superior informable del método de alta sensibilidad de Echevarne es desconocido (comprobación P3). Los valores por encima de 10 mg/L llevan el límite de acción (repetir en 2 semanas, buscar una infección); la versión 3 marca 10-50 mg/L como provisional y rechaza por encima de 50 mg/L (comprobación B2). Borrador de gobierno: critical-limits.json entries[17], recomendación 'Ninguno en el lanzamiento; revisar con el rango informable y la lista de Echevarne.'";
hs.method_note_es = "Echevarne B0851 (PCUL, prueba B3180), turbidimetría, suero (tubo con gel), intervalo '<3,01' mg/L para edades 0-999, línea 308 del catálogo, fechado el 01/06/2020; EVA lo lee como 3 mg/L (valores con dos decimales, así que 3,00 es el valor más alto dentro de '<3,01'). Se desconoce el valor mínimo informable del método (comprobación P3, carta de métodos); el techo óptimo de 0,5 mg/L debe quedar en ese valor o por encima. La PCR es un marcador de inflamación, no una causa de enfermedad (aleatorización mendeliana: f04-E10, f04-E11); la banda óptima señala el grupo de menor riesgo en las cohortes, no un objetivo de tratamiento. Versión 3: transformación logarítmica, límites de 2,1 a 10 mg/L (0,21 a 1 mg/dL), peso positivo en los dos niveles (valor más bajo, edad más joven hasta 2,1 mg/L); 10-50 mg/L provisional y por encima de 50 mg/L rechazado (B2). Duplicado de la semilla, resuelto en la compilación: la semilla de septiembre tenía dos filas de PCR ultrasensible con los mismos límites y textos (índice 4, categoría Corazón; índice 31, categoría Regulación Inmune), y el cargador conservaba el índice 31; el archivo compilado docs/signoff/work/compiled/B01-r3/f04_inflammation/biomarker-ranges-en.json tiene una sola fila de PCR ultrasensible, índice 4, categoría Corazón, que es la fila que se firma aquí. Embarazo o lactancia declarados: no hay filas propias (eliminadas en la ronda 2). El tratamiento previsto es la regla única de la app de state-rules.md sección 2.1 (solo el intervalo del laboratorio, sin categoría, sin puntuación, sin edad biológica, una nota fija), pero no está activa: reference-row.ts elige la fila solo por sexo y edad y no lee ningún estado declarado, así que hoy una clienta embarazada o lactante se clasifica con esta fila, ve la categoría óptima y puntúa (comprobación Q1: la persona del tercer trimestre con 4 mg/L aparece por encima del rango). La PCR ultrasensible sube de forma normal en el embarazo (mediana del tercer trimestre 4,12 mg/L, del primero 2,39 y del segundo 2,44, f04-E12; límite superior de referencia específico del embarazo 19 mg/L, f04-E13), así que las categorías de la fila general no deben mostrarse en el embarazo; la lactancia en sí no subió la PCR en una encuesta de población (f04-E14). Hasta que la regla de estado exista, los mensajes por encima del óptimo y por encima del rango nombran el embarazo como causa de un valor alto; construirla es la condición de lanzamiento F04-DQ-1. Resultados acotados: un resultado '<x' con x por encima de 0,5 mg/L no puede situarse dentro ni por encima de la banda óptima; debe mostrarse dentro del rango y sin categoría óptima, nunca por encima del óptimo (comprobación P3; hoy process-results.ts clasifica el propio límite; F04-DQ-4).";
ch(HS, "method_note_es", null, "(new Spanish text, see final_rows)", "neutral",
  "J3 (M5, minor) and central item C-11: the Spanish file is the version the physician signs, and Nota_Método was English. The Spanish text says the same as method_note, sentence by sentence, with decimal commas; no number differs.",
  [], [I.m5]);
ch(HS, "critical_none_reason_es", null, "(new Spanish text, see final_rows)", "neutral",
  "J3 (M5, minor; the judge's example was this field, Motivo_Sin_Crítico beginning 'None, because ...') and central item C-11: Spanish text of critical_none_reason; no number differs.",
  [], [I.m5]);
ch(HS, "reference_source_es", null, "(new Spanish text, see final_rows)", "neutral",
  "J3 (M5, minor) and central item C-11: Spanish text of the new reference_source (Fuente_Referencia); the quoted English source sentence is kept verbatim.",
  ["f04-E01", "f04-E02"], [I.m5]);

// ---------- hs-CRP: clinical notes (J5 M3 minor; C-10) ----------
hs.clinical_notes_en = "A high-sensitivity measure of C-reactive protein, a protein the liver releases when there is inflammation anywhere in the body. It is a marker of inflammation, not a cause of disease: in large population studies, people with lower hs-CRP had fewer cardiovascular events, while genetic studies found that CRP itself does not cause heart disease. A recent infection, an injury, excess body weight and smoking raise it, and it rises normally in pregnancy.";
hs.clinical_notes_es = "Una medición de alta sensibilidad de la proteína C reactiva, una proteína que el hígado libera cuando hay inflamación en cualquier parte del cuerpo. Es un marcador de inflamación, no una causa de enfermedad: en grandes estudios de población, las personas con la PCR ultrasensible más baja tuvieron menos episodios cardiovasculares, mientras que los estudios genéticos indican que la propia PCR no causa enfermedad del corazón. Una infección reciente, una lesión, el exceso de peso y el tabaco la suben, y también sube de forma normal en el embarazo.";
ch(HS, "clinical_notes_en", "A high-sensitivity measure of C-reactive protein, which the liver releases in response to inflammation. It reveals the low-grade, silent inflammation that quietly accelerates aging and cardiovascular disease.", hs.clinical_notes_en, "neutral",
  "J5 (M3, minor): today's note says the inflammation hs-CRP reveals 'quietly accelerates aging and cardiovascular disease', a causal claim the row's own method note denies (Mendelian randomisation, f04-E10: risk ratio 1.00 per 1 SD of genetically raised CRP; f04-E11). The new note keeps the description, states the association (f04-E08) and the absence of a causal effect, and names the causes already in the messages (pregnancy, f04-E12). Central item C-10: rows take clinical_notes_en and clinical_notes_es. No number.",
  ["f04-E08", "f04-E10", "f04-E11", "f04-E12"], [I.m3hs]);
ch(HS, "clinical_notes_es", "Una medición de alta sensibilidad de la proteína C reactiva, que el hígado libera en respuesta a la inflamación. Revela la inflamación silenciosa y de bajo grado que acelera el envejecimiento y la enfermedad cardiovascular.", hs.clinical_notes_es, "neutral",
  "J5 (M3, minor): Spanish note with the same meaning as the English one; the causal claim 'acelera el envejecimiento y la enfermedad cardiovascular' is removed.",
  ["f04-E08", "f04-E10", "f04-E11", "f04-E12"], [I.m3hs]);

// ---------- hs-CRP: RCV narrow-band justification (J3 P2 minor) ----------
const rcvFrom = hs.rcv.narrow_band_justification;
hs.rcv.narrow_band_justification = "The optimal band (up to 0.5 mg/L) is narrower than the reference change value, so a single result can move between optimal and above optimal with no real change. The band is kept because it classifies a level, not a change: the outcome cohorts behind it placed people in categories from a single baseline measurement (f04-E06, f04-E07, F04-F04), so the evidence itself rests on one value, and within-person variation weakens, rather than creates, the gradient they report. Three rules limit the effect of the variation (f04-E17: median within-subject CV 0.44, ICC 0.62): no trend or change message between two hs-CRP results unless their difference exceeds the RCV once Echevarne's CVA arrives (check P2); a raised value is confirmed by the average of two tests about 2 weeks apart, never by one value (pre-analytical rule); and a value above 10 mg/L is set aside and repeated (action limit).";
ch(HS, "rcv.narrow_band_justification", rcvFrom, hs.rcv.narrow_band_justification, "neutral",
  "J3 (P2, minor) and ACCEPTANCE-TEST P2 ('An optimal band narrower than the reference change value needs a justification'): the field was null. The justification states why the band is kept (single-measurement cohort categories) and which rules limit misclassification from within-person variation; it adds no number besides the CVI and ICC quoted in f04-E17. Whether these rules are enough is still for the physician to sign with the row.",
  ["f04-E06", "f04-E07", "f04-E17", "F04-F04"], [I.p2]);

// ---------- hs-CRP: sex statement in notes (J3 E4, J3 definition optimal band, J1 E2) ----------
const hsNotesFrom = hs.notes;
const sexStatement = "Sex (one band for both sexes, no sex split): women: the 0.5 mg/L ceiling is the lowest-risk category of the Women's Health Study (f04-E06, 27,939 women, cardiovascular events; crude RR 1.0 below 0.5 against 2.2 at 0.5 to <1.0) and lies inside its lowest 30-year quintile (<0.65 mg/L, f04-E07). Men: EPIC-Norfolk (F04-F04, PMID 23821244: 16,850 men and women aged 40-79 without known cancer, myocardial infarction or stroke at baseline, median follow-up 14.3 years, 1,452 of 2,603 deaths in men) used CRP below 0.5 mg/L as the reference category in each sex; the hazard ratio of all-cause death in men was 1.56 (1.26-1.93) at 3-10 mg/L and 1.87 (1.43-2.43) above 10 mg/L against below 0.5 mg/L, and in women 1.34 and 1.98, with an association 'less positively graded in women'. The abstract does not report the 0.5 to 3 mg/L categories and the article is not in PMC, so it shows that men below 0.5 mg/L are in the lowest-risk reference group, not where between 0.5 and 3 mg/L men's risk starts to rise. Neither source reports a different lowest-risk category by sex, and the mixed-sex gradients are log-linear without a threshold (f04-E08, f04-E09), so the same ceiling applies to men and women. ";
hs.notes = sexStatement + hs.notes;
ch(HS, "notes", hsNotesFrom, hs.notes, "neutral",
  "J3 (E4 and definition 'optimal band', minor) and J1 (E2, minor): the 0.5 mg/L ceiling rested on women-only sources and the row recorded no sex statement. A male-inclusive prospective cohort that uses below 0.5 mg/L as its reference category, EPIC-Norfolk (F04-F04, PubMed abstract opened in this task; 16,850 adults, median 14.3 years, prospective evidence tier 2 of PLAN.md section 5), is added, and the row now states the sex policy and the limit of that source. The J1 E2 point that f04-E06 and f04-E07 were unconfirmed is resolved by the central cache fill (C-17): an offline quote check in this task found both quotes in the cache. No bound changes, so no loosening.",
  ["f04-E06", "f04-E07", "f04-E08", "f04-E09", "F04-F04"], [I.e4hs, I.defband, I.e2hs]);

// ---------- fibrinogen ----------
fb.reference_source_es = "Echevarne H0028 (FB, prueba H0050 FIBRINÓGENO), código candidato no asignado en ECH_CODE_TO_BIOMARKER, 200-400 mg/dL, General, 0-999 años, línea 145 del catálogo, fechado el 09/03/2020, plasma citratado, método coagulativo ('Coagulativa').";
fb.critical_none_reason_es = "Ninguno, porque el fibrinógeno no está en la lista de límites críticos de L1, no tiene entrada de gobierno, hoy no se asigna desde Echevarne (solo llega a EVA desde informes subidos por personas sin enfermedad aguda) y en esta tarea no se abrió ninguna lista de valores críticos que dé un límite para el fibrinógeno. Un fibrinógeno muy bajo es un problema de sangrado en la práctica hospitalaria; si EVA necesita un límite crítico bajo cuando se asigne el código es la pregunta al médico f04-Q05.";
const fbMethodFrom = fb.method_note;
fb.method_note = fb.method_note + " Class: docs/signoff/work/governance/marker-classes.json lists fibrinogen as draft class a, not scored, 'pending the family's grade'. The family's grade is D for any optimal band (no outcome-derived band), and PLAN.md section 4 gives an optimal band only to class a markers and shows a marker without one as in range or out of range only, which is class e; the governance entry should read e.";
fb.method_note_es = "Clase e (solo referencia), sin puntuación. El fibrinógeno tiene una asociación continua, aproximadamente log-lineal, con los desenlaces vasculares y no vasculares y sin umbral a ninguna edad (f04-E20); los estudios genéticos no apoyan un papel causal en la enfermedad coronaria (f04-E21, f04-E22; la aleatorización mendeliana de una sola variante para el ictus de f04-E24 discrepa); en las mujeres de Moli-sani el quintil más bajo (por debajo de 264 mg/dL) tuvo más muertes que el central (f04-E23). No existe una banda derivada de desenlaces, así que se elimina el techo óptimo de producción de 300 mg/dL (f04-Q04). Hoy la app no asigna el código H0028 de Echevarne. Clase: docs/signoff/work/governance/marker-classes.json da al fibrinógeno la clase provisional a, sin puntuación, 'pendiente del grado de la familia'. El grado de la familia es D para cualquier banda óptima (sin banda derivada de desenlaces), y la sección 4 de PLAN.md solo da banda óptima a los marcadores de clase a y muestra un marcador sin ella como dentro o fuera del rango, que es la clase e; la entrada de gobierno debería decir e.";
ch(FB, "method_note", fbMethodFrom, fb.method_note, "neutral",
  "J5 (definition 'marker classes', minor): the row says class e while marker-classes.json gives draft class a. PLAN.md section 4 decides it: an optimal band belongs only to class a, and a marker with no outcome-derived band shows in range or out of range only. Fibrinogen has no threshold at any age (f04-E20: 'no evidence of a threshold ... at any age'), genetic studies do not support a causal role (f04-E21), and the lowest quintile was not the lowest-risk group in Moli-sani women (f04-E23), so no grade A or B band exists and the class is e. marker-classes.json itself says the draft is 'pending the family's grade' and sets may_be_scored false, so e changes no score. The governance file is not this fixer's to edit; the note states the line to change.",
  ["f04-E20", "f04-E21", "f04-E23"], [I.defclass]);
ch(FB, "marker_class", "a (draft, docs/signoff/work/governance/marker-classes.json)", "e", "neutral",
  "Recorded so the class difference is a documented change (central items C-16 and C-21): the governance draft class a becomes e for the reason given in the method-note change above. Not a loosening of any bound: the optimal ceiling removal is its own change (optimal_high 300 -> null, grade A and B quotes f04-E20 and f04-E21), and fibrinogen was not scored in either class (may_be_scored false).",
  ["f04-E20", "f04-E21", "f04-E23"], [I.defclass]);
ch(FB, "method_note_es", null, "(new Spanish text, see final_rows)", "neutral",
  "J3 (M5, minor; the finding covers the sampled rows' Nota_Método, Motivo_Sin_Crítico and Fuente_Referencia) and central item C-11: Spanish text of method_note; no number differs.",
  [], [I.m5]);
ch(FB, "critical_none_reason_es", null, "(new Spanish text, see final_rows)", "neutral",
  "J3 (M5, minor) and central item C-11: Spanish text of critical_none_reason.", [], [I.m5]);
ch(FB, "reference_source_es", null, "(new Spanish text, see final_rows)", "neutral",
  "J3 (M5, minor) and central item C-11: Spanish text of reference_source.", [], [I.m5]);

fb.clinical_notes_en = "A clotting protein made by the liver that also rises with inflammation. In population studies, higher levels go with more cardiovascular events, but genetic studies do not show that fibrinogen itself causes heart disease, so it is shown against the laboratory's reference interval only and does not count toward the score. Infection, inflammation, age, pregnancy, excess body weight and smoking raise it.";
fb.clinical_notes_es = "Una proteína de la coagulación que fabrica el hígado y que también sube con la inflamación. En estudios de población, los niveles más altos se asocian con más episodios cardiovasculares, pero los estudios genéticos no muestran que el propio fibrinógeno cause enfermedad del corazón, así que se muestra solo frente al intervalo de referencia del laboratorio y no cuenta para la puntuación. La infección, la inflamación, la edad, el embarazo, el exceso de peso y el tabaco lo suben.";
ch(FB, "clinical_notes_en", "A clotting protein that also rises in response to inflammation. Persistently high levels increase both blood viscosity and cardiovascular risk, while regular exercise tends to lower them.", fb.clinical_notes_en, "neutral",
  "J1 and J5 (M3, minor): today's note says high levels 'increase both blood viscosity and cardiovascular risk', a causal claim the row's method note denies (f04-E21: fibrinogen genotype not associated with myocardial infarction, RR 1.00 per allele), and that regular exercise lowers fibrinogen, which no source opened for this family supports, so that clause is dropped. The new note states the association (f04-E20) and the causes already named in the above-range message (f04-E26: age, body weight, smoking; F04-F01: pregnancy). Central item C-10. No number.",
  ["f04-E20", "f04-E21", "f04-E26", "F04-F01"], [I.m3fb, I.m3hs]);
ch(FB, "clinical_notes_es", "Una proteína de la coagulación que también se eleva en respuesta a la inflamación. Niveles persistentemente altos aumentan tanto la viscosidad de la sangre como el riesgo cardiovascular, mientras que el ejercicio regular tiende a reducirlos.", fb.clinical_notes_es, "neutral",
  "J1 and J5 (M3, minor): Spanish note with the same meaning as the English one; the causal claim and the unsourced exercise clause are removed.",
  ["f04-E20", "f04-E21", "f04-E26", "F04-F01"], [I.m3fb, I.m3hs]);

// ---------- new evidence record ----------
d.evidence.push({
  id: "F04-F04",
  supports: [
    { row_key: HS, bound: "optimal_high" },
    { row_key: HS, bound: "sex_split" },
  ],
  identifier: { type: "pmid", value: "23821244" },
  citation: "Ahmadi-Abhari S, Luben RN, Wareham NJ, Khaw KT. Seventeen year risk of all-cause and cause-specific mortality associated with C-reactive protein, fibrinogen and leukocyte count in men and women: the EPIC-Norfolk study. Eur J Epidemiol 2013;28(7):541-50. DOI 10.1007/s10654-013-9819-6.",
  year: 2013,
  quote: "The hazard ratio of all-cause mortality (95 % CI) for participants with CRP in the range of 3-10 and >10 mg/l (vs. <0.5 mg/l) was 1.56 (1.26-1.93) and 1.87 (1.43-2.43) respectively in men and 1.34 (1.07-1.68) and 1.98 (1.50-2.63) in women.",
  location: "abstract (PubMed record, efetch, opened 2026-11-08)",
  design: "prospective population cohort (EPIC-Norfolk), Cox models by CRP category with below 0.5 mg/L as reference, analysed separately in men and women",
  n: 16850,
  follow_up_years: 14.3,
  outcome: "all-cause mortality (2,603 deaths, 1,452 in men), also cardiovascular and cause-specific mortality",
  population_age: "40-79 at recruitment (1993-1997)",
  population_sex: "both",
  assay: "high-sensitivity CRP (assay not named in the abstract)",
  band_rule: "lowest_risk_category",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "The abstract reports interactions tested by sex, smoking, BMI and physical activity (the association was less positively graded in women and did not vary by BMI or physical activity) but no age-stratified estimates or age interaction; the cohort covers ages 40-79 at recruitment, so it gives no evidence for 18-39 or above 79.",
  notes: "Male-inclusive source for the 0.5 mg/L ceiling (sex statement, checks E4 and the optimal-band definition). Reverse causation partly handled: people with known cancer, myocardial infarction or stroke at baseline were excluded. Limits: the abstract gives only the 3-10 and above 10 mg/L categories against below 0.5 mg/L, not the 0.5-3 mg/L categories; the full text is not in PMC. The quote was copied from the PubMed efetch abstract fetched in this task; the source cache does not hold it yet (this fixer may not write the cache). Grade proposed by the fixer; the verifier assigns it.",
});

// ---------- physician question on the reference basis ----------
d.physician_questions.push({
  id: "F04-DQ-7",
  row_key: HS,
  question: "hs-CRP reference limit: keep the basis 'decision limit, CDC/AHA 2003, >3.0 mg/L high relative risk' even though the statement's own text cannot be confirmed by the quote script (PubMed record without abstract, not in PMC, publisher page refused access, only a PDF mirror opened), or relabel the 3 mg/L limit as Echevarne's printed interval '<3.01' mg/L read at two decimals? The classification is the same either way: 3.00 mg/L is in range and 3.01 mg/L is above it.",
  why: "PLAN.md section 4 lets a named guideline decision limit replace Echevarne's interval only when copied exactly, and section 5 grades an unopenable source D. The 3.0 mg/L category is relayed in a confirmed PubMed abstract (f04-E02) but the guideline quote itself (f04-E01) sits in a binary PDF the script cannot read (J1, D3 minor). Relabelling to Echevarne's interval would make check D3 compare 3 with the catalogue's 3.01 and report a deviation that the method note explains. The message 'the cut-off that cardiology guidelines use' depends on the answer.",
  evidence_ids: ["f04-E01", "f04-E02"],
  options: [
    "Keep the decision-limit basis, cited to PMID 12551878 with the f04-E02 relay (recommended: the messages name the guideline cut-off)",
    "Relabel as Echevarne's interval and record the 3 versus 3.01 reading as an explained D3 deviation",
  ],
});

// ---------- header, issues, notes ----------
d.round = 4;
d.decided_at = "2026-11-08";
d.verify_sha256 = "b4191bac810c54e8b0bfcce11fd45457c693182a47dd92e9edf146a012f863ba";
d.fixer_role = "physician fixer, round 4 (AI work product for physician review)";
d.changes = d.changes.concat(changes);
const add = [I.m5, I.m3fb, I.m3hs, I.g6hs, I.e2hs, I.e4hs, I.defband, I.defclass, I.p2];
for (const id of add) if (!d.issues_addressed.includes(id)) d.issues_addressed.push(id);

d.notes = fs.readFileSync(process.argv[2], "utf8").trim();
fs.writeFileSync(path, JSON.stringify(d, null, 2) + "\n");
console.log("written", d.changes.length, "changes,", d.issues_addressed.length, "issues addressed");
