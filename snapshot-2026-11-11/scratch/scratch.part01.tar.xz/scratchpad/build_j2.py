import json, sys

OUT = sys.argv[1]
EN = "docs/signoff/work/compiled/B01-r3/biomarker-ranges-en.json"
SRC = "docs/signoff/work/compiled/B01-r3/biomarker-sources.json"
REP = "docs/signoff/work/compiled/B01-r3/compile-report.json"
CHK = "docs/signoff/work/checks/B01-r3.json"
CAT = "docs/vendor/echevarne/catalogo-2026-08-25.tsv"

CR_F = "creatinine|female|All Adults|none"
BUN = "bun|both|All Adults|none"
UREA = "urea|both|All Adults|none"
CYS = "cystatin_c|both|All Adults|none"
EGFR = "egfr_creatinine_based|both|40-84|none"
RATIO = "bun_creatinine_ratio|both|All Adults|none"
ALB = "albumin|both|All Adults|none"
TP = "total_protein|both|All Adults|none"
GLOB = "globulin|both|All Adults|none"
AG = "albumin_globulin_ratio|both|All Adults|none"
CRP = "hs_crp|both|All Adults|none"
FIB = "fibrinogen|both|All Adults|none"


def fl(file, line):
    return {"kind": "file_line", "file": file, "line": line}


def sq(t, v, quote):
    return {"kind": "source_quote", "identifier": {"type": t, "value": v}, "quote": quote}


def issue(family, row_key, side, check_id, value, evidence, resolution):
    return {
        "family": family,
        "row_key": row_key,
        "side": side,
        "check_id": check_id,
        "value_disputed": value,
        "evidence": evidence,
        "resolution": resolution,
    }


CRIT_RES = (
    "Add a critical-tier message column (EN and ES) to the seed files and the migration and carry the decision's "
    "critical_high messages into it; make classifyZone emit a separate critical zone fed only by Critical_Low and "
    "Critical_High, and stop storing values outside the reference interval under the codes critical_low and "
    "critical_high (check L1: 0 critical labels derived from reference limits); name the recipient role for the "
    "call; re-run L1, M1 and the Q1 personas with a value above the critical limit."
)

blocking = [
    issue(
        "f03_kidney", CR_F, "high", "L1",
        "Critical_High 4 mg/dL (compiled EN line 4500) reaches the seed with no critical-tier message. The decision's "
        "critical_high message ('This value is beyond the critical limit set by EVA's responsible physician. Contact a "
        "doctor today; if you cannot, go to an emergency department.' / 'Contacta hoy con un médico; si no puedes, acude "
        "a urgencias.') is dropped by the compile; the column Msg_Critical_High (line 4498) holds the out-of-range text, "
        "whose urgency is 'Book an appointment with your doctor in the next few weeks'. src/lib/biomarkers/"
        "zone-classifier.ts line 87 returns 'critical_high' for any value above Normal_High 1.02, so a creatinine of "
        "4.0 mg/dL or more gets the 'next few weeks' message, and a value of 1.03 carries the critical code. The "
        "governance table also disagrees with the row on what the client is told: docs/signoff/work/governance/"
        "critical-limits.json lines 387-389 give creatinine action_class 'emergency', 'Go to an emergency department "
        "today.', while the row's critical message uses the 'contact a doctor today' wording.",
        fl(REP, 51),
        CRIT_RES + " Make the creatinine action wording at 4.0 mg/dL the same in the row and in critical-limits.json.",
    ),
    issue(
        "f03_kidney", BUN, "high", "L1",
        "Critical_High 100 mg/dL (compiled EN line 4321; Thomas 2003, PMC6178782: 'Urea BUN > 214 mg/dl (35.6 mmol/l) "
        "> 100 mg/dl (35.6 mmol/l)') has no critical-tier message in the compiled seed: the decision's critical_high "
        "message is dropped, and a BUN of 100 mg/dL or more is coded 'critical_high' from Normal_High 25 "
        "(zone-classifier.ts line 87) and shown Msg_Critical_High (line 4319), which ends 'Book an appointment with "
        "your doctor in the next few weeks'.",
        fl(REP, 49),
        CRIT_RES,
    ),
    issue(
        "f03_kidney", UREA, "high", "L1",
        "Critical_High 214 mg/dL (compiled EN line 4352; Thomas 2003, PMC6178782, 'Urea ... > 214 mg/dl') has no "
        "critical-tier message in the compiled seed: a urea of 214 mg/dL or more is coded 'critical_high' from "
        "Normal_High 54 and shown the out-of-range message at line 4350 ('Book an appointment with your doctor in the "
        "next few weeks'); the decision's critical_high message never reaches the seed.",
        fl(REP, 56),
        CRIT_RES,
    ),
    issue(
        "f01_albumin_proteins", None, None, "G6",
        "The compiled biomarker-sources.json summaries state bounds the compiled rows do not carry. Albumin: 'EVA's "
        "optimal albumin runs from 42 g/L up to the upper reference limit (48 g/L), within a reference range of "
        "35–48 g/L' (line 15291) against the row's 41 and 32–48 g/L. Total protein: 'EVA's optimal total protein is "
        "65–80 g/L' (line 17477) against a class e row with no optimal band. Globulin: 'EVA's optimal globulin is "
        "2.2–3.0 g/dL' (line 17003) against no optimal band. Albumin/globulin ratio: 'optimal ... from 1.4 up to ... "
        "2.5 ... within a reference range of 1.0–2.5, a conventional adult interval used because the partner "
        "laboratory (Echevarne) prints none for this ratio' (line 15742) against the row's 0.99–2.53 with no optimal "
        "band, while Echevarne's catalogue line 345 does print 0.99–1.81. summary_es lines 15292, 17478, 17004 and "
        "15743 carry the same numbers.",
        fl(SRC, 15291),
        "Regenerate summary_en, summary_es and the caveats of the four f01 markers from the signed rows. "
        "docs/signoff/tools/lib/compile-sources.js copies the previous summary text and replaces only the ranges, so "
        "either the decision supplies the summary text or the compile blanks a summary whose numbers no longer match; "
        "re-run G6.",
    ),
    issue(
        "f03_kidney", None, None, "G6",
        "The compiled biomarker-sources.json summaries contradict the compiled rows. Creatinine: 'EVA's optimal "
        "creatinine is 0.8–1.1 mg/dL for men and 0.6–0.9 mg/dL for women' (line 13197); the rows have no optimal band. "
        "eGFR: 'EVA's optimal eGFR is 90 mL/min/1.73m² or above at ages 18–39, 75 or above at 40–59 and 65–105 "
        "mL/min/1.73m² at 60 and over; the reference range starts at 75 at ages 18–39' (line 13831); the rows are 60 "
        "with 90–110 at 18–39, 60 with 75–105 at 40–84 and 60 with no band at 85+. Cystatin C: 'up to 0.85 mg/L' "
        "(line 13548) against 0.72. BUN: 'up to 18 mg/dL' (line 12564) against 16. Urea: 'EVA's optimal urea is "
        "21–39 mg/dL ... within a reference range of 15–54 mg/dL' (line 15100) against 21–34 and 21–54. "
        "BUN/creatinine ratio: 'optimal ... 11–18 ... within a reference range of 10–20' (line 12807) against "
        "7.6–45.5 with no optimal band. summary_es lines 13198, 13832, 13549, 12565, 15101 and 12808 carry the same "
        "numbers.",
        fl(SRC, 13548),
        "Regenerate summary_en, summary_es and the caveats of the six f03 markers from the signed rows (the compile "
        "keeps the previous text and updates only the ranges); re-run G6.",
    ),
    issue(
        "f04_inflammation", FIB, "high", "G6",
        "biomarker-sources.json line 6437: 'Optimal is up to 300 mg/dL, with no separate lower optimal bound, within "
        "a reference range of 200–400 mg/dL' (summary_es line 6438 the same), while the compiled fibrinogen row is "
        "class e with Optimal_High null. The row's own question F04-DQ-5 drafts the corrected text, but the compiled "
        "file still states 300 mg/dL.",
        fl(SRC, 6437),
        "Replace the fibrinogen summary in EN and ES with the F04-DQ-5 text or regenerate it from the row; re-run G6.",
    ),
    issue(
        "f03_kidney", UREA, None, "M3",
        "Compiled Clinical_Notes, which wording-rules.md section 1 names as client text, biomarker-ranges-en.json line "
        "4345: 'lower steady-state Urea within the healthy band associates with better kidney trajectory and lower "
        "all-cause mortality'; rangos-biomarcadores-es.json line 4345: 'menor mortalidad por todas las causas'. "
        "Mortality wording is forbidden in any tier (wording-rules.md 3.1, 'No mortality').",
        fl(EN, 4345),
        "Replace the urea Clinical_Notes in EN and ES with text that has no mortality claim (the decision notes say "
        "replacement text was drafted, but the compile keeps the seed text); include compiled Clinical_Notes in the M3 "
        "scan and re-run it.",
    ),
    issue(
        "f03_kidney", CYS, None, "M3",
        "Compiled Clinical_Notes line 4680, EN: 'Cystatin-C-based eGFR predicts mortality better than the "
        "creatinine-only version.'; ES line 4680: 'La eGFR basada en cistatina C predice mortalidad mejor que la basada "
        "solo en creatinina.' 'predicts'/'predice' and 'mortality'/'mortalidad' are forbidden in any tier "
        "(wording-rules.md 3.1).",
        fl(EN, 4680),
        "Rewrite the cystatin C Clinical_Notes in EN and ES without prediction or mortality wording; re-run M3 over "
        "the compiled Clinical_Notes.",
    ),
    issue(
        "f03_kidney", UREA, "low", "M4",
        "Compiled Clinical_Notes line 4345, EN: 'Its reference interval starts at 15 mg/dL, while the BUN interval "
        "starts at 10 mg/dL, which equals urea 21 mg/dL; so urea between 15 and 21 mg/dL is within range here'; ES "
        "line 4345: 'Su intervalo de referencia empieza en 15 mg/dL'. The compiled row's Normal_Low is 21 (line 4340), "
        "so a urea of 15 to 20 mg/dL is classified below range while the note tells the client it is within range.",
        fl(EN, 4345),
        "Rewrite the urea Clinical_Notes in EN and ES to the row's 21–54 mg/dL; include Clinical_Notes numbers in the "
        "M4 and G6 checks and re-run them.",
    ),
    issue(
        "f03_kidney", BUN, "low", "M4",
        "Compiled Clinical_Notes line 4314, EN: 'Their reference intervals come from different sources, so a BUN "
        "between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range' (ES line 4314 "
        "the same). The compiled urea row is now Echevarne's BUN interval x 2.14, 21–54 mg/dL (line 4340), so a BUN of "
        "7 to 9.7 mg/dL (urea 15 to 20.8 mg/dL) reads below the urea range as well; the note describes the superseded "
        "urea floor of 15 mg/dL.",
        fl(EN, 4314),
        "Rewrite the BUN Clinical_Notes in EN and ES: both intervals now come from Echevarne's BUN interval; re-run "
        "M4 and G6 over Clinical_Notes.",
    ),
    issue(
        "f01_albumin_proteins", TP, "high", "K1",
        "K1 opposite pair with no accepted reason, both sexes, 83 ages from 18 to 100: albumin 46.56 g/L (optimal) and "
        "globulin 3.88 g/dL (in range) give total protein 85.36 g/L, above the 82 g/L ceiling. Echevarne's printed "
        "intervals (albumin 32–48 g/L, globulins 19–40 g/L) sum to 51–88 g/L against total protein 57–82 g/L, so the "
        "pattern cannot be removed by any bound within the printed intervals. K1's pass rule is 0 opposite-category "
        "pairs.",
        fl(CHK, 1288),
        "Build the rule the physician chooses in F01-DQ-3 (for example, total protein shown with the laboratory "
        "interval but without its own out-of-range zone when albumin and globulin are on the same report) and re-run "
        "K1 to 0 opposite pairs; if the pattern is to be accepted instead, K1 itself needs a CEO-approved change, "
        "because it allows no accepted reason for opposite pairs.",
    ),
    issue(
        "f03_kidney", EGFR, "both", "K1",
        "K1 opposite pairs with no accepted reason on this row: creatinine 0.9894 mg/dL (woman, in range) gives eGFR "
        "59.88, below the 60 limit, at ages 74 to 100, and creatinine 1.261 mg/dL (man) gives 59.79; creatinine "
        "0.5335 mg/dL (woman, below range) gives eGFR 105, inside the 75–105 optimal band, at ages 61 to 100, and "
        "0.679 mg/dL (man) gives 104.5. The person with low muscle mass reads creatinine out of range and eGFR optimal.",
        fl(CHK, 1268),
        "Build the rule the physician chooses in f03-DQ04 (for example, no optimal eGFR category while creatinine is "
        "below its interval, and a creatinine in-range reading that defers to eGFR where the top of the interval gives "
        "an eGFR under 60, or age-partitioned creatinine intervals obtained from Echevarne) and re-run K1 to 0 "
        "opposite pairs.",
    ),
    issue(
        "f03_kidney", RATIO, "both", "K1",
        "K1 opposite pairs, 83 ages from 18 to 100: BUN 9.7 mg/dL (below range) with creatinine 1.051 mg/dL (woman, "
        "above range) gives a ratio of 9.233, read in range; BUN 25.75 mg/dL (above range) with creatinine 0.679 mg/dL "
        "(man, below range) gives 37.92, read in range. The derived 7.6–45.5 limits remove the in-range-inputs case "
        "but leave this one.",
        fl(CHK, 1260),
        "Show the ratio as a value without its own zone when BUN and creatinine are on the same report (f03-DQ07; "
        "needs the harness to accept a value-only row), or another rule that brings K1 to 0 opposite pairs.",
    ),
    issue(
        "f01_albumin_proteins", AG, "high", "definition:reference interval",
        "Normal_High 2.53 is recorded with Reference_Basis 'echevarne_interval' (compiled EN lines 3595 and 3609), but "
        "Echevarne's only interval for the ratio is B0288 ALBÚMINA/GLOBULINAS TOTALES '.99'–'1.81' (catalogue line "
        "345). 2.53 = 48/19 is computed by EVA and printed by no laboratory, as the row's own Reference_Source (line "
        "3610) says, and it is not a guideline decision limit, so it meets neither basis PLAN section 4 allows for an "
        "'in range' interval. The floor 0.99 is taken from the same B0288 line that the row calls 'a different "
        "measurand' when it sets the 1.81 ceiling aside.",
        fl(CAT, 345),
        "Either show the ratio as a value only when albumin and globulin are on the report (F01-DQ-4 option b; needs "
        "the harness to accept a value-only row), or have the physician and the CEO add a signed basis for "
        "component-derived limits to PLAN section 4 and record that basis on the row; a computed ceiling must not be "
        "labelled as Echevarne's printed interval.",
    ),
    issue(
        "f03_kidney", RATIO, "both", "definition:reference interval",
        "Normal_Low 7.6 and Normal_High 45.5 are recorded with Reference_Basis 'echevarne_interval' (compiled EN line "
        "4386), while the row's Reference_Source (line 4387) states 'No printed interval: Echevarne reports no "
        "BUN-to-creatinine ratio'. The catalogue holds BUN (line 97) and creatinine (lines 113–115) but no ratio; 7.6 "
        "(10/1.3 rounded down) and 45.5 (25/0.55 rounded up) are extremes of quotients of two intervals, not a "
        "reference interval of the ratio and not a guideline decision limit.",
        fl(EN, 4386),
        "Same resolution as for the albumin/globulin ratio: value-only display (f03-DQ07) or a signed PLAN section 4 "
        "basis for derived limits recorded on the row instead of 'echevarne_interval'.",
    ),
    issue(
        "f03_kidney", BUN, "high", "E3",
        "Optimal_High 16 mg/dL is a narrowed band carried at grade C with grade_c_table_entry true, but the grade was "
        "set by the fixer against the verifier's B ('final grade C differs from the verifier's B') and "
        "docs/signoff/work/grade-c-table.json does not exist, so the band sits in no grade C decision table. E3 is "
        "blocked on an internal file, not on named external data, and PLAN section 5 says the verifier assigns the "
        "grade, never the author.",
        fl(CHK, 1136),
        "The verifier assigns the grade; if it is C, the orchestrator builds the grade C decision table (at most 20 "
        "entries) with this entry for the physician (f03-DQ08), otherwise the band follows the verifier's grade; "
        "re-run E3.",
    ),
    issue(
        "f03_kidney", UREA, "high", "E3",
        "Optimal_High 34 mg/dL (the BUN ceiling 16 x 2.14) is carried at grade C set by the fixer against the "
        "verifier's B, with grade_c_table_entry true and no grade C decision table file, as for BUN.",
        fl(CHK, 1144),
        "As for BUN: verifier-assigned grade, then a grade C table entry or a band that follows the verifier's grade; "
        "re-run E3.",
    ),
]

minor = [
    issue(
        "f04_inflammation", CRP, "high", "P3",
        "The 0.5 mg/L optimal ceiling needs a high-sensitivity assay, but src/lib/biomarkers/name-matcher.ts lines 148 "
        "and 151 map 'pcr', 'proteina c reactiva', 'crp' and 'c-reactive protein', the names of a conventional CRP on "
        "uploaded reports, to hs_crp; the app does not know such an assay's lowest reportable value, and "
        "src/lib/biomarkers/process-results.ts line 430 classifies a '<x' result as x (P3 fixture '<1.75' mg/L read "
        "above optimal). P3 requires every optimal bound to sit at or above the assay's lowest reportable value.",
        fl("src/lib/biomarkers/name-matcher.ts", 148),
        "Map to hs_crp only names that state high sensitivity ('ultrasensible', 'alta sensibilidad', 'hs') and show "
        "other CRP results as values only; fix bounded-result handling; obtain the lowest reportable value of "
        "Echevarne B0851 (F04-DQ-4).",
    ),
    issue(
        "f04_inflammation", CRP, "high", "P2",
        "The row's CVI of 44% (decisions/f04_inflammation.json line 102) gives, by the row's own arithmetic, an RCV of "
        "about 122% with CVA 0, so the optimal band from 0 to 0.5 mg/L is narrower than the RCV at its edge; "
        "narrow_band_justification is null (line 107), which P2 does not allow. The two-test average rule in the row "
        "covers raised values only.",
        fl("docs/signoff/work/decisions/f04_inflammation.json", 107),
        "Add the justification, or read a single value between 0.5 mg/L and the next category with its repeat (the "
        "CDC/AHA average of two tests about two weeks apart) before 'above optimal' is shown.",
    ),
    issue(
        "f04_inflammation", CRP, "high", "D3",
        "D3 fails on hs_crp ('seed reference null–3 vs catalogue none–3.01 mg/L (catalogue line 308); reference_basis "
        "decision_limit without a source') although the row records the CDC/AHA decision limit: "
        "scripts/signoff/checks/data.ts line 229 exempts a row only when r.source is set, and the compiled row carries "
        "Reference_Source instead. Substance holds (3.00 is the highest two-decimal value inside '<3.01'), but the "
        "decision-limit quote f04-E01 is taken from a course-site PDF mirror (eclass.uoa.gr) rather than the "
        "publisher's page for PMID 12551878.",
        fl(CHK, 112),
        "Make D3 read the field the compile writes; cite and cache the publisher's page (DOI "
        "10.1161/01.cir.0000052939.59093.45) for f04-E01; re-run D3.",
    ),
    issue(
        "f03_kidney", EGFR, "both", "definition:optimal band",
        "The 75–105 band rests on CKD-PC 2010 ('risk of mortality was unrelated to eGFR between 75 mL/min/1.73 m(2) "
        "and 105', PMID 20483451), whose eGFR came from the MDRD Study equation, while the row classifies race-free "
        "CKD-EPI 2021 eGFR; the method note does not state the difference. Today the app computes no eGFR "
        "(src/lib/biomarkers/biological-age-v3-adapter.ts line 57) and name-matcher.ts lines 176–179 send a "
        "laboratory eGFR of any equation to this row, while the row's 'values only' rule for laboratory eGFR has no "
        "app implementation, so CKD-EPI 2021 messages would be shown for MDRD or CKD-EPI 2009 values.",
        sq("pmcid", "PMC3993088",
           "GFR was estimated using the Modification of Diet in Renal Disease (MDRD) Study equation using age, sex, "
           "race, and serum creatinine concentration."),
        "State the source equation on the row and family page and ask the physician whether 75–105 holds for "
        "CKD-EPI 2021 (Hussain 2023, PMID 37353230, uses CKD-EPI 2021 with age-specific referents); build the in-app "
        "CKD-EPI 2021 computation or the values-only rule for laboratory eGFR before the band is applied.",
    ),
    issue(
        "f03_kidney", CYS, "high", "P2",
        "The optimal band runs from the reference floor 0.62 to 0.72 mg/L (0.10 mg/L, about 14% of 0.72) while the "
        "row's RCV is 24.5% (decisions/f03_kidney.json line 699) and narrow_band_justification is null (line 702). "
        "The ceiling comes from quintiles measured with a Siemens immunoassay on a Dimension Vista 1500 (Yuan 2025, "
        "PMC12456039: quintile 2, 0.640–0.717 mg/L, HR 1.05; quintile 3, 0.718–0.799 mg/L, HR 1.29), against "
        "Echevarne's nephelometric I0650 interval dated 27/02/2013 (catalogue line 107) with unknown traceability; "
        "at two decimals a result of 0.718–0.720 mg/L, quintile 3 in the source, reads optimal.",
        fl("docs/signoff/work/decisions/f03_kidney.json", 702),
        "Add the P2 justification; keep f03-DQ06 open until Echevarne states calibration and traceability; classify "
        "against 0.717 on the unrounded value or state the rounding.",
    ),
    issue(
        "f01_albumin_proteins", ALB, "low", "definition:optimal band",
        "Optimal_Low 41 g/L depends on the albumin method, which is unknown for Echevarne (catalogue line 55 gives "
        "only UV-visible spectrophotometry). J-MICC's 4.1 g/dL boundary is a cut-off of the Japanese Committee for "
        "Clinical Laboratory Standards, not an outcome-derived edge, with albumin measured by bromocresol green or "
        "modified bromocresol purple; Moli-sani's comparison "
        "group is '>40 g/L' (PMID 39010980). The row's own method note says the dye must be settled 'before the band "
        "is signed as final'.",
        sq("pmcid", "PMC12622803",
           "Serum total protein and albumin levels comprised three groups, using cutoff values of the Japanese "
           "Committee for Clinical Laboratory Standards: < 6.6, 6.6–8.1 and >8.1 g/dL for serum total protein; and "
           "<4.1, 4.1–5.1 and >5.1 g/dL for albumin"),
        "Mark the 41 g/L floor in the pack as conditional on Echevarne's dye (methods letter), state the offset the "
        "physician accepts between bromocresol purple and green, and keep F01-VQ-1 (the floor is a convention on a "
        "linear association).",
    ),
    issue(
        "f01_albumin_proteins", ALB, "low", "E4",
        "Msg_Optimal (compiled EN line 3564) says the band is 'linked to the best long-term health, in both sexes and "
        "at every age studied', but the Moli-sani abstract reports the hypoalbuminaemia association with total "
        "mortality only at 65 and over, with a significant age interaction.",
        sq("pmid", "39010980",
           "Upon stratifying by age, hypoalbuminemia was associated with total mortality solely in those aged ≥65 "
           "years (HR = 1.83; 1.33-2.50) but not in the <65 years group (HR = 1.03; 0.53-2.00; P < 0.0001 for "
           "difference)."),
        "Remove 'at every age studied' from the EN and ES optimal message and record the age interaction in the "
        "row's E4 statement.",
    ),
    issue(
        "f01_albumin_proteins", AG, "high", "M2",
        "Msg_Critical_High (compiled EN line 3604; ES the same) gives 'a sample of concentrated blood (not drinking "
        "enough before the draw, a long tourniquet time)' as 'the usual cause' of a ratio above 2.53. Concentration "
        "raises albumin and globulin by the same factor and leaves their ratio unchanged (the total-protein row's own "
        "posture note says total protein rises 'like albumin'), so the benign cause offered cannot explain a high "
        "ratio and may lead a client to set aside a low globulin.",
        fl(EN, 3604),
        "Name causes that do move the ratio (an albumin method that reads high, a low globulin) and keep the "
        "immunoglobulin follow-up, in EN and ES.",
    ),
    issue(
        "f01_albumin_proteins", GLOB, "low", "L2",
        "The action limit 'calculated globulin below 18 g/L' (value 1.8 g/dL, decisions/f01_albumin_proteins.json "
        "line 246) is the bromocresol-green cut-off; with bromocresol purple the published cut-off is 23 g/L, and the "
        "app does not record the uploading laboratory's albumin method, so a BCP-based globulin of 1.9 to 2.2 g/dL "
        "reads in range with no screen. The row also applies Echevarne's electrophoretic B0278 interval (19–40 g/L, "
        "catalogue line 335) to calculated globulin, a different measurand, and stores g/dL where Echevarne reports "
        "g/L.",
        sq("pmid", "24784320",
           "Using bromocresol purple, 74% of samples had an IgG of < 6 g/l using a cut-off of < 23 g/l."),
        "Record the albumin method with uploaded results, or apply the action limit only when the method is known; "
        "state the measurand difference on the family page; settle the unit (PQ-5).",
    ),
    issue(
        "f01_albumin_proteins", None, None, "E2",
        "E2 confirms none of the family's quotes because docs/signoff/work/sources-cache holds one source; every grade "
        "B record reads 'must be D'. Opened in this review, the bound numbers are present: Moli-sani 'compared to "
        "serum albumin >40 g/L' and 'serum albumin levels ≤35 g/L' (PMID 39010980); J-MICC '<4.1, 4.1–5.1 and >5.1 "
        "g/dL for albumin' (PMC12622803); Jolles 'cut-off < 18 g/l' and '< 23 g/l' (PMID 24784320).",
        fl(CHK, 556),
        "Fetch and cache the cited sources and re-run E2 before the pack is assembled.",
    ),
    issue(
        "f03_kidney", None, None, "E2",
        "E2 confirms none of the family's quotes (cache empty). Opened in this review, the bound numbers are present: "
        "Yuan 2025 quintile 2 0.640–0.717 mg/L HR 1.05 (0.82–1.34) and quintile 3 0.718–0.799 mg/L HR 1.29 "
        "(1.03–1.60) (PMC12456039); Hong 2023 Model 4 all-cause HRs 1.06, 1.05 and 1.48 with Q4 ≥5.71 mmol/L "
        "(PMC9865447); CKD-PC 'unrelated to eGFR between 75 ... and 105' (PMID 20483451); Hussain 2023 composite HR "
        "1.13 at 40–49 and 1.08 at 50–65 for eGFR 70–80 (PMID 37353230); Thomas 2003 'Urea BUN > 214 mg/dl (35.6 mmol/l) > "
        "100 mg/dl (35.6 mmol/l)' (PMC6178782); Manchester NHS critical list 'Creatinine (if no AKI stage available) µmol/L NA 354'.",
        fl(CHK, 860),
        "Fetch and cache the cited sources and re-run E2 before the pack is assembled.",
    ),
    issue(
        "f04_inflammation", None, None, "E2",
        "E2 confirms none of the family's quotes (cache empty). Opened in this review: Ridker and Cook 2004 give crude "
        "RRs 1.0 and 2.2 for hs-CRP <0.5 and 0.5 to <1.0 mg/L and FRS-adjusted 1.0 and 1.6, in 27,939 women only "
        "(PMID 15051634), which supports the 0.5 mg/L ceiling; the CDC/AHA statement (PMID 12551878) has no abstract "
        "and its cited mirror was not opened.",
        fl(CHK, 1036),
        "Fetch and cache the cited sources, including the publisher's page of the CDC/AHA statement, and re-run E2.",
    ),
]

doc = {
    "schema_version": "1",
    "round": 3,
    "lens": "J2",
    "shard": "B01.f01_albumin_proteins.f03_kidney.f04_inflammation",
    "families_reviewed": ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"],
    "sample_file": "docs/signoff/work/judges/round-3/sample-B01.f01_albumin_proteins.f03_kidney.f04_inflammation.json",
    "blocking": blocking,
    "minor": minor,
    "model": "claude-opus-5-5",
    "notes": (
        "AI pre-review, lens J2 (clinical biochemist), round 3, 2026-11-07. AI work product for review by a licensed "
        "physician. Rows inspected: the 12 seeded rows (f01 all four; f03 bun_creatinine_ratio, bun, creatinine "
        "female, cystatin_c, eGFR 40-84, urea; f04 both), in the decisions files and in the B01-r3 compiled EN, ES and "
        "sources files, against checks/B01-r3.json. WebSearch calls: 0. Sources opened through PubMed/PMC efetch, the "
        "Europe PMC search endpoint and one guideline page: PMID 39010980, PMC12622803 (PMID 41248155), PMID "
        "32378436, PMID 24784320, PMID 20483451 and PMC3993088, PMID 37353230, PMID 40983592 and PMC12456039, "
        "PMC9865447, PMC6178782, PMID 15051634, and the Manchester University NHS FT page on communicating critical "
        "biochemistry results. Catalogue comparison at printed precision (docs/vendor/echevarne/"
        "catalogo-2026-08-25.tsv): albumin 32-48 g/L (line 55), total protein 57-82 g/L (line 366), total globulins "
        "19-40 g/L = 1.9-4.0 g/dL (line 335), creatinine women 0.55-1.02 mg/dL (line 115), BUN 10-25 mg/dL (line 97), "
        "cystatin C 0.62-1.11 mg/L (line 107) and fibrinogen 200-400 mg/dL (line 145) match the rows; none of these "
        "has an Echevarne age band. hs-CRP 3 mg/L against '<3.01' (line 308) is recorded as the CDC/AHA decision "
        "limit. The albumin/globulin ceiling 2.53 (printed 1.81, line 345), the urea interval (no Echevarne urea; "
        "BUN x 2.14) and the BUN/creatinine ratio (no Echevarne ratio) are not printed intervals. Conversion factors "
        "in src/lib/biomarkers/unit-conversions.ts that feed these rows (creatinine umol/L x 0.0113, urea mmol/L x "
        "6.006, BUN mmol/L x 2.801, globulin g/L x 0.1, hs-CRP mg/dL x 10) agree with the row units. Critical limits "
        "checked against their sources: creatinine 354 umol/L = 4.0 mg/dL (Manchester list), BUN 100 and urea 214 "
        "mg/dL (Thomas 2003). Not reviewed: rows outside the seeded sample (creatinine male, eGFR 18-39 and 85+)."
    ),
}

with open(OUT, "w", encoding="utf8") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
    f.write("\n")
print("written", OUT, len(blocking), "blocking", len(minor), "minor")
