import json, re, sys
sys.path.insert(0,'/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad')
exec(open('/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/dump.py').read().split("which=sys.argv")[0])
fam=sys.argv[1]; skip=set(sys.argv[2].split(',')) if len(sys.argv)>2 and sys.argv[2] else set()
lang=sys.argv[3] if len(sys.argv)>3 else 'EN'
for idx,((r,s,fl),(re_,se,fle)) in enumerate(zip(en,es)):
    k=slug(r['Biomarker'])
    if k not in fam_of or fam_of[k]!=fam: continue
    if str(idx) in skip: continue
    state=(r.get('State') or 'none')
    rk='%s|%s|%s|%s'%(k,r['Sex'].lower(),r['Age_Group'],state)
    print('='*60)
    print('IDX',idx,'ROWKEY',rk,'line',s)
    src = r if lang=='EN' else re_
    fls = fl if lang=='EN' else fle
    for f,v in src.items():
        if v is None: continue
        print('  %-20s L%-5s %s'%(f,fls.get(f),json.dumps(v,ensure_ascii=False)))
