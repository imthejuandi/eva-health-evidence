const fs=require('fs');
const md=fs.readFileSync('docs/signoff/work/governance/wording-rules.md','utf8');
const m=md.match(/```json banned_terms\n([\s\S]*?)\n```/);
const rules=JSON.parse(m[1]);
const doc=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const hits=[];
function scan(lang,text,where,critical){
  const r=rules[lang]; let t=text;
  for(const a of r.any.allow) t=t.split(a).join(' ');
  for(const a of r.non_critical.allow) t=t.split(a).join(' ');
  for(const re of r.any.regex){ const x=new RegExp(re,'i'); const mm=t.match(x); if(mm) hits.push(`${where} [any] /${re}/ -> "${mm[0]}"`); }
  if(!critical) for(const re of r.non_critical.regex){ const x=new RegExp(re,'i'); const mm=t.match(x); if(mm) hits.push(`${where} [non_critical] /${re}/ -> "${mm[0]}"`); }
}
const closer={en:rules.en.required.out_of_range_closer, es:rules.es.required.out_of_range_closer};
const ccloser={en:rules.en.required.critical_closer, es:rules.es.required.critical_closer};
for(const row of doc.rows||doc.final_rows){
  const k=`${row.marker_key}|${row.sex}|${row.age_group}|${row.physiological_state}`;
  for(const lang of ['en','es']){
    for(const [z,txt] of Object.entries(row.messages[lang])){
      const crit=z==='critical_low'||z==='critical_high';
      scan(lang,txt,`${k} ${lang}.${z}`,crit);
      if((z==='below_range'||z==='above_range') && !txt.endsWith(closer[lang])) hits.push(`${k} ${lang}.${z}: missing out-of-range closer`);
      if(crit && !txt.endsWith(ccloser[lang])) hits.push(`${k} ${lang}.${z}: missing critical closer`);
      if((z==='below_range'||z==='above_range')){ const ok = lang==='en' ? /(next few weeks|next check-up)/.test(txt) : /(próximas semanas|próxima revisión)/.test(txt); if(!ok) hits.push(`${k} ${lang}.${z}: no urgency phrase`); const rep = lang==='en' ? /(repeat|Repeat|two .* samples|single value)/.test(txt) : /(Repite|repetir|único valor)/.test(txt); if(!rep) hits.push(`${k} ${lang}.${z}: no repeat rule`); }
    }
    for(const f of [`clinical_notes_${lang}`]) if(row[f]) scan(lang,row[f],`${k} ${f}`,false);
    for(const a of row.action_limits) scan(lang,a[`follow_up_${lang}`],`${k} action ${a.name}`,false);
    for(const p of row.pre_analytical) scan(lang,p[`text_${lang}`],`${k} pre_analytical ${p.rule}`,false);
  }
}
console.log(hits.length? hits.join('\n') : 'no hits');
