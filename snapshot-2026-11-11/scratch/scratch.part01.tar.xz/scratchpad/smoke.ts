import { computeBiologicalAgeV3 } from "/home/user/eva-health/src/lib/biomarkers/biological-age-v3";
const o = computeBiologicalAgeV3([
 {code:"albumin",value:44,unit:"g/L"},{code:"alp",value:70,unit:"U/L"},{code:"hs_crp",value:1.8,unit:"mg/L"},
 {code:"creatinine",value:0.96,unit:"mg/dL"},{code:"bun",value:13,unit:"mg/dL"},{code:"ggt",value:28,unit:"U/L"}], "male", 48);
console.log(JSON.stringify(o));
