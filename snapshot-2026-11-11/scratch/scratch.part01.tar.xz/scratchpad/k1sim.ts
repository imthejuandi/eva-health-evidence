// Run the DSRT K1 coherence code (scripts/signoff/checks/coherence.ts) on the TSAT relationship using the rows of a
// research or verify file, labelled as the compile labels state rows. Usage: tsx k1sim.ts <file.json> <rows|final_rows>
import fs from "node:fs";
import { runCoherence } from "/home/user/eva-health/scripts/signoff/checks/coherence";

const [file, key] = process.argv.slice(2);
const rows = JSON.parse(fs.readFileSync(file, "utf8"))[key];
const LABEL: Record<string, string> = { none: "", premenopausal: "Premenopausal", postmenopausal: "Postmenopausal", pregnancy: "Pregnancy", lactation: "Lactation" };
const UNIT: Record<string, string> = { iron_serum: "µg/dL", iron_binding_capacity_tibc: "µg/dL", iron_saturation_tsat: "%", ferritin: "ng/mL" };
const out = rows.map((r: any, i: number) => ({
  index: i, biomarker_key: r.marker_key, name_en: r.marker_key, name_es: r.marker_key, category_en: "", unit_en: UNIT[r.marker_key] ?? r.unit, unit_es: r.unit,
  sex: r.sex, sex_raw_en: r.sex, sex_raw_es: r.sex,
  age_group_en: r.physiological_state === "none" ? r.age_group : LABEL[r.physiological_state], age_group_es: "",
  normal_low: r.reference_low, normal_high: r.reference_high, optimal_low: r.optimal_low, optimal_high: r.optimal_high,
  critical_low: r.critical_low, critical_high: r.critical_high, reference_basis: r.reference_basis, source: null, marker_class: r.marker_class,
  explanatory_numbers: r.explanatory_numbers, clinical_notes_en: null, clinical_notes_es: null,
  msg: { critical_low: { en: null, es: null }, below_optimal: { en: null, es: null }, optimal: { en: null, es: null }, above_optimal: { en: null, es: null }, critical_high: { en: null, es: null } },
  es_normal_low: null, es_normal_high: null, es_optimal_low: null, es_optimal_high: null, es_critical_low: null, es_critical_high: null, es_present: true,
}));
const rep = runCoherence(out as any);
const tsat = rep.patterns.filter((p) => p.key.startsWith("tsat|"));
for (const p of tsat) console.log(`${p.verdict}\t${p.key}\tages ${p.age_min}-${p.age_max}\te.g. ${p.example.slice(0, 170)}`);
console.log(`tsat patterns: ${tsat.length} (opposite ${tsat.filter((p) => p.verdict === "opposite").length}, one_step ${tsat.filter((p) => p.verdict === "one_step").length})`);
