import { loadSeed } from "/home/user/eva-health/scripts/signoff/lib/seed";
const s = loadSeed("/home/user/eva-health/supabase/seed-data")!;
console.log(s.rows.length);
for (const r of s.rows) if (["albumin","alp","ggt","creatinine","bun","hs_crp","hba1c","potassium","glucose_fasting"].includes(r.biomarker_key)) console.log(r.biomarker_key, r.sex, r.age_group_en, r.unit_en, r.normal_low, r.normal_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high);
console.log(Object.keys(s.en[0]));
