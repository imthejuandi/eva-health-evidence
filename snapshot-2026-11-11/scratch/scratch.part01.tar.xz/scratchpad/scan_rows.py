import json, re, sys
rules_md = open('docs/signoff/work/governance/wording-rules.md', encoding='utf-8').read()
m = re.search(r'```json[^\n]*\n([\s\S]*?)\n```', rules_md)
lex = json.loads(m.group(1))
doc = json.load(open(sys.argv[1], encoding='utf-8'))
rows = doc.get('final_rows') or doc.get('rows')
def hits(text, lang):
    t = text
    tiers = [lex[lang]['any'], lex[lang]['non_critical']]
    for tier in tiers:
        for a in tier.get('allow', []):
            t = re.sub(re.escape(a), ' ', t, flags=re.I)
    out = set()
    for tier in tiers:
        for term in tier['terms']:
            if re.search(r'(?<![^\W\d_])' + re.escape(term) + r'(?![^\W\d_])', t, flags=re.I):
                out.add(term.lower())
        for pat in tier['regex']:
            mm = re.search(pat, t, flags=re.I)
            if mm: out.add(mm.group(0).strip(' .;:!?').lower())
    return sorted(out)
ELEMENTS = {
 'en': [('meaning', r"\b(may|can|could|might|reflect|suggest|indicat|mean|linked|associated|sign of|is consistent)"),
        ('benign_causes', r"\b(infection|dehydrat|exercise|workout|training|fasting|non-fasting|supplement|medication|pregnan|sample|haemolys|hemolys|spurious|benign|harmless|temporar|transient|recent meal|alcohol|stress|time of day|morning|creatine|common|many (healthy )?(adults|people))"),
        ('confirm_repeat', r"\b(repeat|confirm|re-?test|recheck|second (test|sample|result)|another (test|sample|result)|persist|stays|remains|on two|follow-up test|next test)"),
        ('who_when', r"\b(doctor|physician|GP|clinician|specialist|medical attention|medical contact|same day|within (a )?(day|days|week|weeks|month|months)|soon|promptly|without delay|today|at your next)")],
 'es': [('meaning', r"\b(puede|podría|refleja|sugiere|indica|significa|asociad|relacionad|vinculad|señal de|es compatible)"),
        ('benign_causes', r"\b(infecci|deshidrat|ejercicio|entrenamiento|ayuno|sin ayuno|suplemento|medicamento|medicación|embaraz|muestra|hemóli|hemoli|espuri|benign|inofensiv|temporal|transitori|comida reciente|alcohol|estrés|hora del día|mañana|creatina|frecuente|muchas personas|muchos adultos)"),
        ('confirm_repeat', r"\b(repet|repít|confirm|segunda (prueba|muestra|analítica)|otra (prueba|muestra|analítica)|persist|se mantiene|sigue|en dos|próxima (prueba|analítica)|nuevo análisis)"),
        ('who_when', r"\b(médico|medica|profesional sanitario|especialista|atención médica|contacto médico|el mismo día|en (un |una )?(día|días|semana|semanas|mes|meses)|pronto|sin demora|hoy|en tu próxima)")]}
CLOSER = {'en': lex['en']['required']['out_of_range_closer'], 'es': lex['es']['required']['out_of_range_closer']}
URG = {'en': ["Discuss it with your doctor at your next check-up.", "Book an appointment with your doctor in the next few weeks."],
       'es': ["Coméntalo con tu médico en tu próxima revisión.", "Pide cita con tu médico en las próximas semanas."]}
def numbers(text, lang):
    t = re.sub(r'\b[A-Za-z]+\d+\b', ' ', text)  # drop tokens like B12 (checked separately)
    if lang == 'es':
        t = re.sub(r'(\d)\.(\d{3})\b', r'\1\2', t); t = t.replace(',', '.')
    else:
        t = re.sub(r'(\d),(\d{3})\b', r'\1\2', t)
    return [float(x) for x in re.findall(r'\d+(?:\.\d+)?', t)]
problems = 0
for r in rows:
    key = f"{r['marker_key']}|{r['sex']}|{r['age_group']}|{r['physiological_state']}"
    bounds = {r.get(k) for k in ['reference_low','reference_high','optimal_low','optimal_high','critical_low','critical_high']} | set(r.get('explanatory_numbers', []))
    bounds = {float(b) for b in bounds if b is not None}
    texts = []
    for lang in ['en','es']:
        for z, txt in (r.get('messages', {}).get(lang) or {}).items():
            texts.append((lang, f'messages.{lang}.{z}', txt, z))
        if r.get(f'clinical_notes_{lang}'): texts.append((lang, f'clinical_notes_{lang}', r[f'clinical_notes_{lang}'], None))
        for i, p in enumerate(r.get('pre_analytical', [])):
            texts.append((lang, f'pre_analytical[{i}].text_{lang}', p[f'text_{lang}'], None))
        for i, a in enumerate(r.get('action_limits', [])):
            texts.append((lang, f'action_limits[{i}].follow_up_{lang}', a[f'follow_up_{lang}'], None))
    mn = r.get('method_note'); 
    if mn: texts.append(('en','method_note', mn, None))
    if r.get('method_note_es'): texts.append(('es','method_note_es', r['method_note_es'], None))
    for lang, field, txt, z in texts:
        h = hits(txt, lang)
        if h: problems += 1; print(f"BANNED {key} {field}: {h}")
        if z in ('below_range','above_range','critical_low','critical_high'):
            miss = [e for e, pat in ELEMENTS[lang] if not re.search(pat, txt, flags=re.I)]
            if miss: problems += 1; print(f"M2 {key} {field}: lacks {miss}")
            if not txt.rstrip().endswith(CLOSER[lang]): problems += 1; print(f"CLOSER {key} {field}: missing required closer")
            if not any(u in txt for u in URG[lang]): problems += 1; print(f"URGENCY {key} {field}: no fixed urgency phrase")
        if field.startswith('messages'):
            bad = [n for n in numbers(txt, lang) if not any(abs(n-b) < 1e-9 for b in bounds)]
            if bad: problems += 1; print(f"M4 {key} {field}: numbers {sorted(set(bad))} not bounds {sorted(bounds)}")
            toks = sorted(set(re.findall(r'\b[A-Za-z]+\d+\b', txt)))
            if toks: print(f"NOTE {key} {field}: letter-digit tokens {toks}")
            if z == 'in_range' and r.get('marker_class') != 'a':
                need = 'does not count toward the score' if lang=='en' else 'no entra en la puntuación'
                if need not in txt: problems += 1; print(f"CLASS-E {key} {field}: missing '{need}'")
print('problems:', problems)
