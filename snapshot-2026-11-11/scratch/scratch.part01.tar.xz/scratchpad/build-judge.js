const fs = require("fs");
const EN = "docs/signoff/work/compiled/B01-r1/biomarker-ranges-en.json";
const ES = "docs/signoff/work/compiled/B01-r1/rangos-biomarcadores-es.json";
const SRC = "docs/signoff/work/compiled/B01-r1/biomarker-sources.json";
const CK = "docs/signoff/work/checks/B01-r1.json";
const fl = (file, line) => ({ kind: "file_line", file, line });
const sq = (type, value, quote) => ({ kind: "source_quote", identifier: { type, value }, quote });

const blocking = [
  {
    family: "f01_albumin_proteins", row_key: "albumin|both|All Adults|none", side: "low", check_id: "G6",
    value_disputed: "optimal_low 42 g/L and reference 35-48 g/L in biomarker-sources.json summary_en/summary_es, against optimal_low 41 and normal_low 32 in the compiled row",
    evidence: fl(SRC, 15243),
    resolution: "B7. Regenerate summary_en (line 15243) and summary_es (line 15244) from the compiled ranges so every number in the pack matches the row: 41 g/L floor, Echevarne 32-48 g/L (catalogue line 55)."
  },
  {
    family: "f01_albumin_proteins", row_key: "albumin|both|All Adults|none", side: null, check_id: "N1",
    value_disputed: "reference interval 32-48 g/L leaves 17.5% of healthy men aged 20-39 outside (rule 2% to 15%) and the row carries no physician question on it",
    evidence: fl(CK, 4089),
    resolution: "B5. Either record a physician question in the family decision (Echevarne's General 0-999 interval, bromocresol-purple NHANES data) with the physician's acceptance, or ask Echevarne for its dye and a sex-partitioned interval through the methods letter before the row is signed."
  },
  {
    family: "f01_albumin_proteins", row_key: "albumin|both|All Adults|none", side: "high", check_id: "X1",
    value_disputed: "albumin 48.05 to 60 g/L (above the laboratory interval 32-48) gives a biological age up to 1.49 years younger than at the optimal bound, with no accepted X1 exception",
    evidence: fl(CK, 4027),
    resolution: "B3. Judge J3 either accepts an X1 exception for albumin high (cap 2) with the reason written in the pack, or the display rule flattens the age above 48 g/L. The version 3 coefficients and clamps are frozen and are not what is asked to change."
  },
  {
    family: "f01_albumin_proteins", row_key: "albumin_globulin_ratio|both|All Adults|none", side: "both", check_id: "K1",
    value_disputed: "reference interval 0.8-2.5 labelled echevarne_interval although Echevarne prints 0.99-1.81 for the ratio (catalogue line 345); 0.8-2.5 is the quotient of extreme albumin and globulin bounds (48/19 = 2.53 recorded as 2.5), and K1 shows globulin 4.12 g/dL out of range while the ratio 0.97 reads in range",
    evidence: fl(CK, 1222),
    resolution: "B3 and B7. The quotient of two intervals' extremes is not a reference interval and no laboratory prints it. Physician decides PQ-4: either show the uploaded ratio as a value only (class e, no interval), or adopt a sourced interval for the calculated ratio (albumin/(total protein - albumin)) and record the accepted reason in K1; Echevarne's 0.99-1.81 is electrophoretic and fits only if the measurand matches. Relabel reference_basis away from echevarne_interval in any case."
  },
  {
    family: "f01_albumin_proteins", row_key: "albumin|female|All Adults|pregnancy", side: null, check_id: "C1",
    value_disputed: "pregnancy and lactation rows for albumin and total protein are never picked by the app's picker (states_ignored_by_picker 12, unreachable_rows 6); the pregnancy persona sees 31 optimal categories and score 100",
    evidence: fl(CK, 544),
    resolution: "B4. The picker (src/lib/biomarkers/reference-row.ts) must read pregnancy_current and lactating from the record and resolve to these rows (laboratory interval only, no optimal, no score, no biological age, fixed note), with C1 and Q1 green. Until then the rows cannot be signed as delivering what they say; see also Q1 line 4504."
  },
  {
    family: "f01_albumin_proteins", row_key: "globulin|both|All Adults|none", side: null, check_id: "G6",
    value_disputed: "biomarker-sources.json summaries state optimal bands that the compiled rows do not have: globulin 'optimal 2.2-3.0 g/dL' (line 16979), total protein 'optimal 65-80 g/L' (line 17441), albumin/globulin ratio 'optimal 1.4 up to 2.5, reference 1.0-2.5' (line 15778); the rows are class e with no optimal band and the ratio reference is 0.8-2.5",
    evidence: fl(SRC, 16979),
    resolution: "B7. Regenerate every summary_en and summary_es in the compiled sources file from the compiled ranges, or drop the summaries from the signed pack; the physician cannot sign two different numbers for the same quantity."
  },
  {
    family: "f03_kidney", row_key: "urea|both|All Adults|none", side: "low", check_id: "G6",
    value_disputed: "Clinical_Notes say 'Its reference interval starts at 15 mg/dL ... so urea between 15 and 21 mg/dL is within range here' while Normal_Low is 21 (Spanish 'Su intervalo de referencia empieza en 15 mg/dL', same line of the Spanish file)",
    evidence: fl(EN, 4522),
    resolution: "B7. Rewrite Clinical_Notes and Notas_Clinicas to the compiled interval 21-54 mg/dL (Echevarne BUN 10-25 x 2.14) and remove the 15 mg/dL sentence; the Spanish is the signed version."
  },
  {
    family: "f03_kidney", row_key: "urea|both|All Adults|none", side: null, check_id: "M3",
    value_disputed: "'menor mortalidad por todas las causas' in Notas_Clinicas (English 'lower all-cause mortality'), a banned term in any client text under wording-rules.md section 3.1 and the banned_terms block",
    evidence: fl(ES, 4522),
    resolution: "B1. Remove the mortality sentence from Notas_Clinicas and Clinical_Notes; express any association at population level without mortality wording. Extend check M3 to the Clinical_Notes fields, which section 1 of the wording rules places in scope."
  },
  {
    family: "f03_kidney", row_key: "bun|both|All Adults|none", side: "low", check_id: "G6",
    value_disputed: "Clinical_Notes say 'a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range', but the compiled urea interval 21-54 mg/dL equals BUN 10-25, so no such blood exists (Spanish line 4491 says the same)",
    evidence: fl(EN, 4491),
    resolution: "B7. Rewrite the sentence: the urea row is the BUN interval converted (x 2.14), so the two rows agree; state the conversion and nothing else."
  },
  {
    family: "f03_kidney", row_key: "cystatin_c|both|All Adults|none", side: null, check_id: "M3",
    value_disputed: "'predice la mortalidad mejor' in Notas_Clinicas (English 'predicts mortality better than the creatinine-only version'): 'predice' and 'mortalidad' are banned in any client text",
    evidence: fl(ES, 4851),
    resolution: "B1. Remove the sentence from Notas_Clinicas and Clinical_Notes; say only that cystatin C does not depend on muscle mass."
  },
  {
    family: "f03_kidney", row_key: "creatinine|male|All Adults|none", side: "both", check_id: "E3",
    value_disputed: "optimal band 0.8-1.1 mg/dL narrowed inside 0.7-1.3 at grade C with no entry in the grade C decision table (table missing); the only numeric lowest-mortality source is hospitalised patients, whose male nadir is 0.9-1.0, not 0.8-1.1",
    evidence: sq("pmid", "27998681", "using a creatinine value of 0.7 to 0.8 mg/dL as the reference group in the analysis of all patients and female patients and of 0.9 to 1.0 mg/dL in the analysis of male patients because it was associated with the lowest in-hospital mortality"),
    resolution: "B2. Either the physician lists creatinine (male) in docs/signoff/work/grade-c-table.json with the band and the reason, or the optimal band is removed (optimal equals the reference interval) and filtration is read from eGFR and cystatin C as the message already says. Note the source is in-hospital mortality on admission creatinine, not an ambulatory cohort, and Echevarne's creatinine method (Jaffe or enzymatic) is still unknown."
  },
  {
    family: "f03_kidney", row_key: "creatinine|female|All Adults|none", side: "both", check_id: "E3",
    value_disputed: "optimal band 0.6-0.9 mg/dL narrowed inside 0.55-1.02 at grade C with no entry in the grade C decision table",
    evidence: fl(CK, 1169),
    resolution: "B2. Same as the male row: list it in the grade C table with the physician's reason, or drop the optimal band to the reference interval."
  },
  {
    family: "f03_kidney", row_key: "creatinine|female|All Adults|none", side: "high", check_id: "N1",
    value_disputed: "21.1% of healthy women aged 70-79 sit above Echevarne's 1.02 mg/dL (rule 2% to 15%); the Method_Note calls it 'a physician question, not a row change' but no question id exists in the row",
    evidence: fl(CK, 4117),
    resolution: "B5. Record the question in the family decision file (Echevarne prints no age bands; an age-partitioned interval or an explicit acceptance of the share is needed) and answer it before signature."
  },
  {
    family: "f03_kidney", row_key: "bun|both|All Adults|none", side: "low", check_id: "N1",
    value_disputed: "25.0% of healthy women 20-39, 17.5% of women 40-59 and 17.5% of men 20-39 sit below Echevarne's lower limit 10 mg/dL (rule 2% to 15%)",
    evidence: fl(CK, 4101),
    resolution: "B5. Physician answers f03-Q07 in the decision file: accept Echevarne's printed General limit with the share documented and the out-of-range low message kept soft, or ask Echevarne for a sex-partitioned BUN interval. Until answered the laboratory limit leaves a quarter of young women outside."
  },
  {
    family: "f03_kidney", row_key: "bun|both|All Adults|none", side: "high", check_id: "N1",
    value_disputed: "63.3% of healthy men aged 70-79 are non-optimal under the 16 mg/dL ceiling with no physician question in the row",
    evidence: fl(CK, 4113),
    resolution: "B5. Add the physician question (age drift of BUN, f03-E46; community-dwelling adults over 70 run 14-23 mg/dL, f03-E21) and the physician's answer, or an age split above 70, before signature."
  },
  {
    family: "f03_kidney", row_key: "egfr_creatinine_based|both|40-84|none", side: "low", check_id: "K1",
    value_disputed: "creatinine 0.99 mg/dL (female, inside 0.55-1.02) gives eGFR 59.9 (out of range, below 60) at ages 74-100; same for male creatinine 1.26 inside 0.7-1.3; K1 records no accepted reason",
    evidence: fl(CK, 1233),
    resolution: "B3. Record the accepted reason in K1 (Echevarne's creatinine interval has no age bands, while CKD-EPI 2021 falls with age, so an in-range creatinine gives an eGFR under 60 after about 74), and make the creatinine out-of-range and eGFR messages say so, or add age-partitioned creatinine rows. One of the two rows must own the call."
  },
  {
    family: "f03_kidney", row_key: "egfr_creatinine_based|both|18-39|none", side: "low", check_id: "Q1",
    value_disputed: "every eGFR message names 'the CKD-EPI 2021 equation' (line 4702) while the Method_Note (line 4714) says the app computes no eGFR today and shows a laboratory-reported eGFR of unknown equation 'as values only'; Q1 nevertheless classifies a persona's eGFR 55 as critical_low",
    evidence: fl(CK, 4428),
    resolution: "B7. The pack says two different things about the same row. Either the K1 computation from Echevarne creatinine is built in the app before signature and the rows apply only to that value, or the rows are held back and uploaded eGFR is displayed with no category, no equation name and no message until then. The optimal floors 90 and 75 move by 5 to 10 units between MDRD, CKD-EPI 2009, CKD-EPI 2021 and EKFC, so a band written for one equation cannot classify a value of another."
  },
  {
    family: "f03_kidney", row_key: "bun|both|All Adults|none", side: null, check_id: "G6",
    value_disputed: "biomarker-sources.json summaries disagree with the compiled rows: BUN 'up to 18 mg/dL' (line 12588) vs 16; urea 'optimal 21-39, reference 15-54' (line 15064) vs 21-34 and 21-54; BUN/creatinine ratio 'optimal 11-18' (line 12819) vs none; cystatin C 'up to 0.85 mg/L' (line 13536) vs 0.72; eGFR 'reference starts at 75 at ages 18-39 ... 65-105 at 60 and over' (line 13807) vs 60 and 75-105 for 40-84",
    evidence: fl(SRC, 12588),
    resolution: "B7. Regenerate summary_en and summary_es for every f03 marker from the compiled ranges, or remove the summaries from the signed pack."
  },
  {
    family: "f04_inflammation", row_key: "hs_crp|both|All Adults|none", side: "high", check_id: "N1",
    value_disputed: "optimal ceiling 0.5 mg/L is reached by 9.5% of healthy women 60-69 and 9.6% at 70-79 with no 'reached by a minority' label in the optimal message, and 90.4% of women and 90.0% of men aged 70-79 are non-optimal with no physician question",
    evidence: fl(CK, 4217),
    resolution: "B5. Add the minority label to Msg_Optimal and Msg_Above_Optimal in both languages for the affected ages, and record a physician question on the 70-79 share (age split or a wider ceiling, with the Ridker and Cook 2004 data: 15.1% of the whole women's cohort under 0.5 mg/L). See also line 4221."
  },
  {
    family: "f04_inflammation", row_key: "hs_crp|female|All Adults|pregnancy", side: null, check_id: "C1",
    value_disputed: "hs-CRP pregnancy and lactation rows are never picked (file indexes 5 and 6 unreachable); the pregnancy persona sees optimal categories and score 100",
    evidence: fl(CK, 552),
    resolution: "B4. As for f01: the picker must resolve declared pregnancy and lactation to these rows before they can be signed; C1 and Q1 green."
  },
  {
    family: "f04_inflammation", row_key: "fibrinogen|both|All Adults|none", side: "high", check_id: "G6",
    value_disputed: "biomarker-sources.json summary 'Optimal is up to 300 mg/dL' (line 6437) while the compiled row is class e with no optimal band (production ceiling 300 dropped, f04-Q04)",
    evidence: fl(SRC, 6437),
    resolution: "B7. Regenerate the fibrinogen summary_en and summary_es from the compiled ranges."
  }
];

const minor = [
  {
    family: "f04_inflammation", row_key: "hs_crp|both|All Adults|none", side: "high", check_id: "D3",
    value_disputed: "reference_basis decision_limit 3 mg/L rests on f04-E01 cited as a university mirror PDF (unopenable, E2 line 1050, grade must be D); the CDC/AHA 2003 statement has PMID 12551878 and its PubMed record carries no abstract text",
    evidence: sq("pmid", "12551878", "Markers of inflammation and cardiovascular disease: application to clinical and public health practice: A statement for healthcare professionals from the Centers for Disease Control and Prevention and the American Heart Association. Circulation. 2003 Jan 28;107(3):499-511. doi: 10.1161/01.cir.0000052939.59093.45"),
    resolution: "Replace the identifier with the DOI 10.1161/01.cir.0000052939.59093.45 (Circulation page) and cache that text so the '3.0 mg/L' quote can be confirmed. The limit itself stands either way: Echevarne prints '<3.01' mg/L (catalogue line 308)."
  },
  {
    family: "f04_inflammation", row_key: "hs_crp|both|All Adults|none", side: "high", check_id: "P3",
    value_disputed: "optimal ceiling 0.5 mg/L on a turbidimetric hs-CRP assay whose lowest reportable value is unknown; the optimal band exists only if Echevarne reports below 0.5 mg/L",
    evidence: fl(EN, 120),
    resolution: "Methods letter: Echevarne's limit of quantitation for B0851 and how a '<x' result is reported; if the lowest reportable value is at or above 0.5 mg/L, the optimal band becomes '<x' and the message must say so."
  },
  {
    family: "f03_kidney", row_key: "cystatin_c|both|All Adults|none", side: "high", check_id: "N1",
    value_disputed: "optimal ceiling 0.72 mg/L is the top of quintile 2 (0.640-0.717) of NHANES 1999-2002, a pre-ERM-DA471 calibration; on an ERM-DA471-traceable method the median healthy adult (blood donors 17-66) is 0.78-0.79 mg/L, so more than half of healthy adults read above optimal on a standardised assay, and Echevarne's nephelometry (interval dated 2013) is of unknown traceability",
    evidence: sq("pmid", "29573343", "The nonparametric reference intervals for plasma cystatin C were 0.58-1.00 mg/L in women (median 0.78 mg/L, range 0.56-1.06 mg/L) and 0.62-1.04 mg/L in men (median 0.79 mg/L, range 0.61-1.07 mg/L)."),
    resolution: "Ask Echevarne for the assay's traceability in the methods letter and estimate the 70-79 non-optimal share before signature; if the share exceeds 60% the ceiling needs a physician question under B5. Also correct the Method_Note: Yuan 2025 (PMC12456039) states a Siemens immunoassay on a Dimension Vista 1500, not the Dade Behring BN II the note names, and reports quintile 2 (0.640-0.717 mg/L) with HR 1.05 (0.82-1.34), which is the band rule the ceiling should cite."
  },
  {
    family: "f03_kidney", row_key: "bun|both|All Adults|none", side: "low", check_id: "E3",
    value_disputed: "optimal_low 10 mg/dL equals normal_low 10 (and urea optimal_low 21 equals normal_low 21): an optimal floor resting on the laboratory interval only, while the albumin row expresses the same situation as optimal_high null",
    evidence: fl(EN, 4488),
    resolution: "Set optimal_low to null on the BUN and urea rows (Hong 2023 quartile 1 below 3.57 mmol/L is the referent with no excess), so no optimal bound rests on a laboratory limit; the messages already read 'from the lower reference limit'. The 16 mg/dL ceiling converts correctly: quartile 4 starts at 5.71 mmol/L x 2.801 = 16.0 mg/dL."
  },
  {
    family: "f03_kidney", row_key: "urea|both|All Adults|none", side: "both", check_id: "D3",
    value_disputed: "reference_basis echevarne_interval although Echevarne prints no urea interval; 21-54 is the BUN interval x 2.14 rounded (21.4-53.6)",
    evidence: fl(EN, 4532),
    resolution: "Label the basis as a conversion of the Echevarne BUN interval (physician question f03-Q08) rather than echevarne_interval, and state in the message that an uploaded laboratory's own urea interval may differ."
  },
  {
    family: "f03_kidney", row_key: "bun_creatinine_ratio|both|All Adults|none", side: "low", check_id: "K1",
    value_disputed: "BUN 9.7 mg/dL (out of range) with creatinine 0.93 gives a ratio 10.46 that reads in range; the lower limit 10 is 'convention only' (f03-Q09) and the only outcome study gives a lowest-mortality quartile of 11.43-14.64",
    evidence: fl(CK, 1230),
    resolution: "Physician answers f03-Q09; record the accepted reason in K1 (a derived index can be in range while a component is out) or show the ratio as a value only."
  },
  {
    family: "f03_kidney", row_key: "creatinine|male|All Adults|none", side: "high", check_id: "S5",
    value_disputed: "creatinine 6 mg/dL (above the critical limit 4.0) with score 95 and grade Elite in 288 of 985 critical panels",
    evidence: fl(CK, 2794),
    resolution: "Score workstream: no top grade with any critical value (S5 property); out of this shard's scope but the physician will see it next to the creatinine row."
  },
  {
    family: "f01_albumin_proteins", row_key: "albumin|both|All Adults|none", side: "low", check_id: "D3",
    value_disputed: "optimal floor 41 g/L signed against an Echevarne method listed only as 'Espectrofotometria Ultravioleta-Visible' (dye not stated); bromocresol purple reads about 6 g/L lower than bromocresol green, and the cohorts behind 41 g/L are mixed-method (J-MICC) or unstated (Moli-sani)",
    evidence: fl(EN, 3627),
    resolution: "Methods letter (L4) must return the dye before the band is final; PQ-1 stays open on the sheet. Moli-sani's own categories are ≤35 vs >40 g/L (PMC11247150 abstract), which supports 40, not 41, as the cohort boundary."
  },
  {
    family: "f01_albumin_proteins", row_key: "globulin|both|All Adults|none", side: "both", check_id: "D4",
    value_disputed: "row unit g/dL (1.9-4.0) while Echevarne prints 19-40 g/L and every other protein row is in g/L; the app converts uploaded g/L by x 0.1 and the deferred change to g/L (PQ-5) needs the conversion flipped in the same release",
    evidence: fl(EN, 3898),
    resolution: "Decide PQ-5 before signature so the signed unit is the one the app stores; keep the A/G ratio arithmetic (globulin x 10) consistent with it."
  },
  {
    family: "f01_albumin_proteins", row_key: "albumin|female|All Adults|pregnancy", side: null, check_id: "D2",
    value_disputed: "Spanish Grupo_Edad 'Embarazo'/'Lactancia' where check D2 expects the English keys 'Pregnancy'/'Lactation' (6 mismatches across albumin, total protein and hs-CRP)",
    evidence: fl(CK, 5),
    resolution: "Agree one key convention for state rows in both files (the other state rows already use translated labels) and update D2 or the Spanish file accordingly."
  },
  {
    family: "f01_albumin_proteins", row_key: null, side: null, check_id: "E2",
    value_disputed: "0 of 131 quotes could be confirmed in this round (cache offline, all sources 'unopenable'); this judge opened PMC11247150, PMC12622803, PMC9865447, PMC12456039, PMC6178782, PMC11711015, PMC11145831 and PMIDs 40983592, 12551878, 34847805, 15051634, 27998681, 29573343 directly and found the numbers cited for BUN quartiles, cystatin C quintiles, Thomas's urea/BUN limits and hs-CRP <0.5 mg/L",
    evidence: fl(CK, 1050),
    resolution: "Re-run E2 with the source cache populated; the verifier grades cannot stand at B while the check reads D."
  }
];

const out = {
  schema_version: "1",
  round: 1,
  lens: "J2",
  shard: "B01.f01_albumin_proteins.f03_kidney.f04_inflammation",
  families_reviewed: ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"],
  sample_file: "docs/signoff/work/judges/round-1/sample-B01.f01_albumin_proteins.f03_kidney.f04_inflammation.json",
  blocking,
  minor,
  model: "claude-fable-5-1",
  notes: "AI pre-review by the clinical biochemist lens (J2), 2026-11-07. Catalogue concordance at printed precision: albumin 32-48 g/L (line 55), total protein 57-82 g/L (line 366), globulin 19-40 g/L (line 335), fibrinogen 200-400 mg/dL (line 145), hs-CRP '<3.01' mg/L (line 308), BUN 10-25 mg/dL (line 97), creatinine 0.7-1.3 men and 0.55-1.02 women (lines 114-115), cystatin C 0.62-1.11 mg/L (line 107): all rows match. EN/ES bounds, units, explanatory numbers and message numbers match for every row of the three families. Critical limits are their own numeric fields (creatinine 4.0, BUN 100, urea 214 from Thomas 2003, PMC6178782: 'Urea BUN > 214 mg/dl (35.6 mmol/l) > 100 mg/dl'); the remaining markers carry 'none, because' with a source. WebSearch calls used: 0; all sources were fetched from Europe PMC and PubMed efetch."
};
fs.writeFileSync("docs/signoff/work/judges/round-1/J2-B01.f01_albumin_proteins.f03_kidney.f04_inflammation.json", JSON.stringify(out, null, 2) + "\n");
console.log("written", blocking.length, "blocking", minor.length, "minor");
