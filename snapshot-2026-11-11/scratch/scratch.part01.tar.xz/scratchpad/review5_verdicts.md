## [confirmed] (medium) [logic] A one-week duration is read as one day a week (dose divided by 7), or as a frequency conflict (null). Regression in a9310cc
verdicts: [True, True]
-- [True] fix: In src/lib/biomarkers/supplements.ts, make two changes and do not strip durations before reading frequencies.

(1) DAYS_PER_WEEK: require a times word or a connector between the count and the week word. This fixes the a9310cc regression.
const PER_WEEK = String.raw`(?:\/|a|al|por|per|each|cada|en)`;
const DAYS_PER_WEEK = new RegExp(`(${COUNT})\\s*(?:(?:d[ií]as?|veces|days?|times|x)\\s*(?:${PER_WEEK}\\s*)?|${PER_WEEK}\\s*)(?:la\\s+)?(?:semana|week|wk)(?![${LETTER}])`);

(2) WEEKLY_AMOUNT: do not take "a week" right after a word that opens a duration. This fixes "for a week", wrong since cb017a5, and "5 g a day for a week", which reads null at HEAD.
const DURATION_OPENER = String.raw`(?<![${LETTER}])(?:for|during|since|durante|hace|llevo)\s+`;
In WEEKLY_AMOUNT, insert `(?<!${DURATION_OPENER})` right after the existing `(?<![${LETTER}])` that precedes `(?:a\\s+la|a|al|por|per|cada|each|every)`.

Do not add the suggested step that removes "(durante|desde hace|hace|llevo|for|during|since) COUNT unit" before the frequency reads. It turns "5 g durante 3 días a la semana" (2.1429, correct today) into 0.7143.

Add these to supplements.test.ts.
- Should read 5 (20 where noted): "5 g durante una semana", "5 g, 1 semana", "5 g x 1 semana", "5 g desde hace una semana", "5 g for one week", "5 g for a week", "5 g for 1 week", "5 g (1 semana)", "5 g/día desde hace una semana", "5 g al día, llevo 1 semana", "20 g/día durante una semana" (20), "5 g diarios desde hace 1 semana", "5 g a day for a week".
- Should read 3: "3 g, hace una semana que empecé".
- Controls that must keep their frequency: "5 g durante 3 días a la semana" (15/7), "5 g 3x semana" (15/7), "5 g, 1 día a la semana" (5/7), "5 g una vez por semana" (5/7), "5 g a week" (5/7), "5 g, 2 veces por semana" (10/7), "5 g tres por
-- [True] fix: In src/lib/biomarkers/supplements.ts:
(1) DAYS_PER_WEEK: require a times word or a connector between the count and the week word (as the finding suggests):
  const WEEK_CONNECTOR = String.raw`(?:\/|a|al|por|per|each|cada|en)`;
  const DAYS_PER_WEEK = new RegExp(`(${COUNT})\\s*(?:(?:d[ií]as?|veces|days?|times|x)\\s*(?:${WEEK_CONNECTOR}\\s*)?|${WEEK_CONNECTOR}\\s*)(?:la\\s+)?(?:semana|week|wk)(?![${LETTER}])`);
(2) Add LEAD_DURATION = new RegExp(`(?<![${LETTER}])(?:durante|desde\\s+hace|hace|llevo|for|during|since)\\s+(?:${COUNT}|an?)\\s*(?:d[ií]as?|semanas?|mes(?:es)?|años?|days?|weeks?|months?|years?)(?![${LETTER}])`, "g"). Strip it AFTER TIMES_PER_DAY and DAYS_PER_WEEK are taken and BEFORE EVERY_OTHER_DAY, WEEKLY_AMOUNT and DAILY. In readFrequency, add `rest = rest.replace(LEAD_DURATION, " ");` right after `const days = take(DAYS_PER_WEEK);`. Do not strip it before every frequency as the finding suggests: that turns "durante 3 días a la semana" / "for 3 days a week" into a weekly amount (0.7143 instead of 2.1429). Keep the trailing DURATION pass for "x 4 semanas", "5 g, 1 semana".
(3) So the fix does not flip "35 g en una semana" (a weekly total, 5 g/day at head) to 35 g/day, add `|(?:en|in)\\s+(?:una|un|1|one|a)` inside WEEKLY_AMOUNT's word alternation: (?:a\\s+la|a|al|por|per|cada|each|every|(?:en|in)\\s+(?:una|un|1|one|a)).
(4) Update the header comment at supplements.ts:249-257 to say that one-week forms are durations, and that lead durations are stripped after days a week.
(5) Add to the readCreatineDose cases in supplements.test.ts:
  - Expect 5: "5 g durante una semana", "5 g, 1 semana", "5 g x 1 semana", "5 g desde hace una semana", "5 g for one week", "5 g for a week", "5g (1 semana)", "llevo una semana tomando 5 g", "5 g/día desde hace una semana", "5 g al dí

## [confirmed] (medium) [logic] A count before 'semanales' or 'weekly' is dropped: N days a week is read as one weekly dose (divided by 7 instead of multiplied by N/7)
verdicts: [True, True]
-- [True] fix: In src/lib/biomarkers/supplements.ts, give DAYS_PER_WEEK a second alternative where a required count comes before "semanal(es)" or "weekly", accept "d" as a days word, and read whichever capture group matched:

  /** Words between a count and "semana": "días", "veces", "times", "x", "d" ("3 d/semana"). */
  const DAYS_WORD = `(?:d[ií]as?|veces|days?|times|x|d(?![${LETTER}]))`;
  const DAYS_PER_WEEK = new RegExp(
    `(${COUNT})\\s*${DAYS_WORD}?\\s*(?:(?:\\/|a|al|por|per|each|cada|en)\\s*)?(?:la\\s+)?(?:semana|week|wk)(?![${LETTER}])` +
      `|(${COUNT})\\s*${DAYS_WORD}?\\s*(?:semanal(?:es)?|weekly)(?![${LETTER}])`,
  );

and in readFrequency: `daysPerWeek: days ? readCount(days[1] ?? days[2]) : null`.

This is the finder's fix, plus a no-letter guard on the bare "d" so it cannot be the first letter of a word ("2 dosis a la semana de 5 g" still reads 10/7). Because the count is required, "5 g semanales", "5 g weekly" and "35 g semanales" stay weekly amounts. "5 g al día, 3 días semanales" and "8 días semanales 5 g" now return null, so the form asks.

Side effect to accept and pin in a test: a bare number before the word ("5 semanales", "35 weekly") now returns null and the form asks; HEAD reads 0.714 and 5. That fits the stated policy for ambiguous doses.

Add the six strings from the finding, plus "3 días semanales, 5 g", "5 g 3 days weekly", "5 g 3 d a la semana" and "5 g 3 días semanales, 2 veces al día" (30/7), to supplements.test.ts. Extend the "days a week" bullet in the readFrequency comment to match.

Optional, separate gap: "5 g 3 d/sem" still reads 5 g/day, because "/sem" is not a week word; adding sem(?![letters]) to the week words would cover it.
-- [True] fix: The suggested fix is right but incomplete. In src/lib/biomarkers/supplements.ts, use one list of intake words for both forms of DAYS_PER_WEEK. It adds "d", "tomas", "dosis" and "doses", and the second form allows hyphens:

/** What is counted before "a week": days, times, intakes ("3 días", "3 d", "3 veces", "3 tomas", "3x"). */
const INTAKES = String.raw`(?:d[ií]as?|d|veces|tomas|dosis|days?|times|doses|x)`;
const DAYS_PER_WEEK = new RegExp(
  `(${COUNT})\\s*${INTAKES}?\\s*(?:(?:\\/|a|al|por|per|each|cada|en)\\s*)?(?:la\\s+)?(?:semana|week|wk)(?![${LETTER}])` +
    `|(${COUNT})[\\s-]*(?:${INTAKES}[\\s-]*)?(?:semanal(?:es)?|weekly)(?![${LETTER}])`,
);

In readFrequency: daysPerWeek: days ? readCount(days[1] ?? days[2]) : null,

The count stays required, so "5 g semanales", "35 g semanales", "5 g weekly" and "2 x 5 g semanales" stay weekly amounts. Two things change:
- A bare number before the word ("5 semanales", "5 weekly") now returns null, so the form asks. It is ambiguous, and asking is the documented behaviour.
- "8 días semanales" and "0 días semanales" now return null.

Update the header comment (:250-256):
- Days a week also covers "3 días semanales", "3 d/semana", "3 tomas a la semana", "twice weekly" and "3x-weekly".
- "semanales" and "weekly" are a weekly amount only with no count before them ("5 g semanales").

Add to the "How often" cases in supplements.test.ts:
["5 g, 3 días semanales", 15/7], ["5 g 3 veces semanales", 15/7], ["3 días semanales, 5 g", 15/7], ["5 g 3x weekly", 15/7], ["5 g three times weekly", 15/7], ["5 g twice weekly", 10/7], ["5 g twice-weekly", 10/7], ["5 g 3 d/semana", 15/7], ["5 g 3 d semanales", 15/7], ["5 g 3 tomas a la semana", 15/7], ["5 g 2 días semanales, 2 veces al día", 20/7], ["5 g weekly", 5/7], ["35 g semanales", 5], ["2 x 

## [confirmed] (medium) [logic] Frequencies the reader does not recognise are read as once a day ('x' for 'por', 'sem', 'cada N días', 'every N days', 'mañana y noche', 'cada 12 horas', 'veces diarias')
verdicts: [True, True]
-- [True] fix: The prototype is in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-reproduce-logic-frequencies-the-reader-does-not-recognis/fix/supplements.diff. The changes are to src/lib/biomarkers/supplements.ts.

(1) Read the unambiguous forms:
- Add X_POR = `(?<![LETTER])x` as a "por" connector in TIMES_PER_DAY, DAYS_PER_WEEK and WEEKLY_AMOUNT.
- Add WEEK = `(?:semana|week|wk|sem)(?![LETTER])` as the week word in DAYS_PER_WEEK and WEEKLY_AMOUNT.
- Add "vez" to the times words.
- After a times count in TIMES_PER_DAY, accept `d[ií]a|day|diari[oa]s?|daily`.
- Add EVERY_N_HOURS, `(?:cada|every\s+|c\s*/\s*)(COUNT)\s*(?:horas?|hours?|hrs?|h)`, giving timesPerDay = 24/N.
- Add EVERY_N_DAYS, `(?<![LETTER])(?:cada|every)\s+(COUNT)\s*(?:d[ií]as?|days?)(?![LETTER])`. Read it after EVERY_OTHER_DAY and before DAILY and DURATION, as a factor of 1/N (N >= 1). It counts as a weekly-type flag in the existing conflict check.
- Add `(?:cada|every)\s+(?:mañana|noche|morning|night|evening)` to DAILY.

(2) Make the default "ask", not "once a day":
- In readFrequency, set unread when TIMES_PER_DAY and EVERY_N_HOURS both match.
- Also set unread when the leftover text has two or more time-of-day words (mañana/tarde/noche/desayuno/comida/cena/morning/evening/night...).
- Also set unread when the leftover still holds a frequency word: veces|vez|times|semanas?|sem|weeks?|wk|cada|every|horas?|hours?|alternos?|alternate|other|s[ií]|tercer|third|weekday names.
- readCreatineDose returns null when unread is set.
- Result: "1,5 g mañana y noche", "día sí, día no", "cada tercer día", "lunes, miércoles y viernes" and "1 g 2 veces" make the form ask. Earlier, rules 1 and 2 above read all nine of the finding's phrases correctly, except "1,5 g mañana y noche", which
-- [True] fix: Keep the reviewer's additions, add the missing readings, and return null for any frequency word left unread. All changes are in src/lib/biomarkers/supplements.ts. The full diff, which I checked, is at /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-logic-frequencies-the-reader-does-not-recognis/fix.diff.

Forms to read:
(a) Times a day. In TIMES_PER_DAY add "vez" and "toma" to the times words and "x" to the connectors. Use DAY_WORD = (?:d[ií]a|day|diari[oa]s?|daily), so "2 veces diarias" and "2 times daily" read 2.
(b) Every N hours. Add EVERY_N_HOURS: (?:cada|every|each)\s+ or c\s*/\s*, then COUNT, then (h|hs|hr|hrs|horas?|hours?). It gives 24/N times a day. If both TIMES_PER_DAY and EVERY_N_HOURS match, return null.
(c) Every N days. Add EVERY_N_DAYS: (?:cada|every)\s+COUNT\s*(?:d[ií]as?|days?). Take it before DAYS_PER_WEEK and before DURATION.
   - Keep it as its own field, multiply by 1/N, and require N >= 1.
   - Count it in the weekly conflict list, so "cada 3 días, 2 veces por semana" and "al día cada 3 días" return null.
(d) Days a week and weekly amounts.
   - DAYS_PER_WEEK: add "vez" to the words, "x" to the connectors, and "sem" to the week words.
   - WEEKLY_AMOUNT: add "x" (behind the existing non-letter lookbehind) and "sem".
(e) Split totals. At the start of readFrequency, remove SPLIT_TOTAL: (?:en|in)\s+COUNT\s*(vez|veces|tomas?|dosis|doses?|times|goes?). "5 g en 2 tomas al día" is a total split in two and reads 5.

Return null for a frequency word left unread (the form then asks):
(f) Before DURATION runs, null when (?:cada|every|each)\s+COUNT plus a time unit remains, e.g. "cada 2 semanas".
(g) Change gramsPerIntake to return {grams, rest}, so these checks run after the amount form is removed. "

## [confirmed] (low) [logic] Per-kilogram doses written '/kilo', '/kilogramo', 'x kg' or 'kg-1' are read as a small daily dose instead of null, so the form never asks
verdicts: [True, True]
-- [True] fix: In src/lib/biomarkers/supplements.ts:244, replace PER_KG with:

const PER_KG = /\/\s*k(?:g|ilo)|(?:\b(?:por|per|cada|each)|(?<![a-zµμáéíóúñü])x)\s*k(?:g|ilo)|\bkg\s*\^?\s*[-−–⁻]\s*[1¹](?![.,]?\d)/;

This is the finder's regex with one change: the exponent alternative also accepts the Unicode minus, the en dash, the superscripts ⁻¹ and a caret, and it does not match "kg - 1,80". Add to the null cases of supplements.test.ts ("Not readable as grams a day"): "0,3 g/kilo", "0,3 g/kilo/día", "0.3 g kg-1 día-1", "0,1 g/kilogramo", "0,1 g x kg", "0,3g x kilo", "300 mg/kilo", "0,3 g kg−1", "0,3 g kg⁻¹". Add as still read: "5 g (bote de 1 kilo)" → 5 and "5 g x 2" → 10.
-- [True] fix: In src/lib/biomarkers/supplements.ts, replace lines 243-244 with the following. LETTER is declared at line 232, before this.

/**
 * A dose per unit of body weight: it cannot be read without the weight. A slash, "por", "per", "cada", "each" or "x"
 * before kg, kilo(s), kilogramo(s), lb or libra ("0,3 g/kg/día", "0,3 g/kilo", "0,1 g x kg", "0,1 g/lb"), or kg with
 * a power of -1 ("0,3 g·kg-1·día-1", "0,3 g·kg⁻¹").
 */
const PER_KG = new RegExp(
  String.raw`(?:\/|(?<![${LETTER}])(?:por|per|cada|each|x))\s*(?:kg|kilo|lb|libra|pound)|(?<![${LETTER}])kg\^?[-−⁻][1¹](?!\d)`,
);

In readCreatineDose's doc (:403-404), list "0,3 g/kilo" and "0,1 g x kg" next to "0,3 g/kg/día".

In supplements.test.ts:193, in the "Not readable as grams a day" group, add these as null: "0,3 g/kilo", "0,3 g/kilo/día", "0,1 g/kilogramo", "0,1 g x kg", "0.3 g kg-1 día-1", "0.3 g·kg⁻¹·d⁻¹", "0.1 g/lb". Add non-regression cases: "5 g (bote de 1 kg)" → 5, "5 g, peso 80 kg" → 5, "10 g (tengo 90 kg)" → 10.

The reviewer's regex alone is an acceptable minimum for the five cited spellings. It still reads "kg⁻¹", "kg^-1", "kg−1" and per-pound doses as a daily dose, and it nulls "peso 80 kg - 1 toma".

## [confirmed] (low) [logic] With two creatinine rows in one lab, the lab-page figure is null or computed depending on row order, while version 3 and the dashboard always use the plausible row
verdicts: [True, True]
-- [True] fix: Use the finder's first option and check each creatinine row on the lab page too, as version 3 and the dashboard already do. I applied and tested this in a scratch copy (`.../fixed/repo`); the diff is saved at `.../verify-reproduce-logic-with-two-creatinine-rows-in-one-lab-the-/fix.diff`.

1. **src/lib/biomarkers/creatinine-plausibility.ts:** export `CREATININE_KEYS = new Set(["creatinine","CREATININE"])`, moved here from rolling-average-ba.ts so there is one definition. Add `withoutImplausibleCreatinine(rows)`, which removes each creatinine row whose finite value is outside 0.2-15 mg/dL.
2. **biological-age-kdm.ts, prepareKdmInputs:** filter before the adapter: `const checked = context?.creatinineAlreadyAdjusted ? values : withoutImplausibleCreatinine(values); const adapted = kdmInputsFromBiomarkerValues(checked).inputs;`.
   - Skip the filter when creatinineAlreadyAdjusted. Otherwise a dashboard average already divided for creatine (for example 0.2/1.13) would be wrongly dropped.
   - Keep the existing check in applyLifestyleAdjustments for direct callers.
3. **rolling-average-ba.ts:** import CREATININE_KEYS instead of defining it.
4. **Tests:** add one to biological-age-kdm.creatinine.test.ts and one to process-results. Rows [1.0, 88.4] and [88.4, 1.0] must give the same Reference and Comprehensive figures as [1.0] alone, [88.4] alone must give null, and recomputeLabMetrics must store the same figure for both DB orders.

Results with the patch:
- Both orders give lab page 51.29 / 47.20, v3 45.25 and dashboard 47.20 with the finder's panel, and 41.99 / 44.34, 43.45 and 44.34 with mine.
- [88.4] alone is still null everywhere.
- The full vitest suite passes (48 files, 942 tests) and `tsc --noEmit` is clean.

Not fixed by this patch, and older than this change: two plaus
-- [True] fix: Use the reporter's second option: one per-lab rule, applied in all three paths through one shared helper. Do not use the first option (drop only the implausible rows). It goes against the stated promise that an out-of-range creatinine gives no figure. It lets a plausible but wrong row through, for example dilute urine at 12 mg/dL next to a misread serum value of 105, which shows 158 on the lab page. And if only prepareKdmInputs filters, explainBiologicalAge crashes.

1. creatinine-plausibility.ts:
   - Export CREATININE_KEYS (move it from rolling-average-ba.ts:129).
   - Add labCreatinineUsable(valuesMgDl): true when every finite value is plausible.

2. biological-age-kdm.ts, prepareKdmInputs:
   - Before kdmInputsFromBiomarkerValues, unless context.creatinineAlreadyAdjusted is set, check every value whose code is in CREATININE_KEYS.
   - If any is implausible, drop all creatinine values for that lab. The gate then fails and the result is null.
   - Keep the single-value check in applyLifestyleAdjustments as a backstop. explainBiologicalAge then returns null together with the figure.

3. biological-age-v3-adapter.ts, assembleBioAgeV3Inputs:
   - If any creatinine row in mg/dL is implausible, withhold every creatinine row and push "creatinine" to implausibleMarkers, which gives reason implausible_value.
   - Otherwise keep the current behaviour: two different plausible values still reach the module, which returns duplicate_marker.
   - Fix the comment at :416. Version 1.2.0 is undeployed, so no version bump is needed.

4. rolling-average-ba.ts, adjustCreatinineByLab:
   - Collect the lab_result_ids that have any implausible creatinine row and drop all creatinine rows of those labs.
   - Other labs are unchanged.

5. Tests, each in both row orders ([1.0,88.4], [88.4,1.0],

## [confirmed] (low) [logic] A range of frequencies reads its upper end, while ranges of amounts and servings read their lower end
verdicts: [True, True]
-- [True] fix: In src/lib/biomarkers/supplements.ts:

1. After RANGE_SEPARATOR (line 241), add:
   `const COUNT_RANGE = `(${COUNT})(?:\\s*${RANGE_SEPARATOR}\\s*${COUNT})?`;`
   Only the first count is captured, so times[1], times[2] and days[1] keep their indices.
2. Use `${COUNT_RANGE}` in place of the leading `(${COUNT})` in TIMES_PER_DAY (line 259) and DAYS_PER_WEEK (line 262). This reads the lower end and removes the whole range from the text, which also fixes the case where the frequency comes before the amount ("2-3 veces por semana 5 g").
3. Handle English "once or twice", which the finder's regex misses: the `twice` alternative and the count word "twice" leave "once or" behind and read 2. Start readFrequency with:
   `let rest = text.replace(/(?<![a-z])once\s+or\s+twice(?![a-z])/g, "1 or 2 times");`
   Do not add "once" to COUNT_WORDS, because in Spanish "once" means eleven.
4. Update the frequency comment (lines 249-256) to say that a range of frequencies reads its lower end.
5. Add tests, for example:
   - "5 g, 2-3 veces por semana" → 10/7
   - "5 g 2 o 3 días a la semana" → 10/7
   - "1 g 2-3 veces al día" → 2
   - "1 g, 1 o 2 veces al día" → 1
   - "5 g dos o tres veces por semana" → 10/7
   - "2-3 veces por semana 5 g" → 10/7
   - "2-3 veces al día 1 g" → 2
   - "5 g 2 or 3 times a week" → 10/7
   - "1 g once or twice a day" → 1
   - "5 g once or twice a week" → 5/7

The alternative is to return null for any range of frequencies so the form asks. That also works, but reading the lower end matches what the module already does for ranges of amounts and servings.
-- [True] fix: In src/lib/biomarkers/supplements.ts:

1. After RANGE_SEPARATOR and above the frequency doc block, add:
   const COUNT_OR_RANGE = `(${COUNT})(?:\\s*${RANGE_SEPARATOR}\\s*${COUNT})?`;
   Doc comment: "a count, or a range of counts ('2-3', '2 o 3', 'dos a tres'); a range reads its first count, as ranges of amounts and servings do".

2. Start TIMES_PER_DAY, DAYS_PER_WEEK and DURATION with ${COUNT_OR_RANGE} instead of (${COUNT}). The capture group numbers stay the same. This removes the whole range from the text before the amount is read, which fixes both word orders. DURATION has the same problem: "durante 2-3 semanas 5 g" reads 2 g/day, and "1 g x 2-3 semanas" multiplies.

3. Change the TIMES_PER_DAY "twice" branch to `(once\\s+or\\s+)?(twice)\\s+(?:a\\s+|per\\s+)?(?:day|daily)` and read it as:
   timesPerDay: times ? (times[1] !== undefined ? readCount(times[1]) : times[2] !== undefined ? 1 : 2) : null
   Do not add "once" to COUNT_WORDS: in Spanish it means eleven.

4. Add one line to the frequency doc block (:249-257) and to readCreatineDose's doc: a range of frequencies or durations reads its lower end.

5. Add cases to readCreatineDose's table in supplements.test.ts.
   Amount first:
   - "5 g, 2-3 veces por semana" → 10/7
   - "5 g 2 o 3 días a la semana" → 10/7
   - "5 g dos o tres veces por semana" → 10/7
   - "5 g 2-3x/semana" → 10/7
   - "1 g 2-3 veces al día" → 2
   - "1 g, 1 o 2 veces al día" → 1
   - "1 g once or twice a day" → 1
   Frequency first, with no comma:
   - "2-3 veces por semana 5 g" → 10/7
   - "2 o 3 días a la semana 5 g" → 10/7
   - "2-3 times a week 5 g" → 10/7
   - "1-2 veces al día 5 g" → 5
   - "2-3 veces al día 1 g" → 2
   Durations:
   - "durante 2-3 semanas 5 g" → 5
   - "desde hace 2-3 meses 5 g" → 5
   - "1 g x 2-3 semanas" → 1

The pr

## [confirmed] (medium) [flow] The context route records a new context on a lab that is already ready, but recomputes none of its figures
verdicts: [True, True]
-- [True] fix: 1. **Context route (`src/app/api/lab-results/[id]/context/route.ts`).** Replace `snapshotToLab`, the `lab.status !== "pending_context"` early return and the unconditional move to processing with one conditional update that stamps and claims the lab together:

   ```ts
   const { data: claimed, error } = await supabase
     .from("lab_results")
     .update({ patient_context_version_id: contextVersionId, transient_context: transientContext, status: "processing" })
     .eq("id", labResultId)
     .eq("user_id", user.id)
     .eq("status", "pending_context")
     .select("id")
     .maybeSingle();
   ```

   - On error, return 500.
   - If no row was claimed, return 409 `{ error: "This result is no longer waiting for context", status: lab.status }`.
   - Alternatively, give `snapshotToLab` an expected-status parameter.
   - Drop the stale "any other status: upload-flow lab" branch and its comment. The upload flow stamps through `/confirm`.

2. **Context page client (`lab-context-client.tsx`).** On 409, call `router.replace(`/${locale}/labs`)` or `router.refresh()`, so the page's redirect runs, instead of showing an error on a stale gate.

3. **Cron (`src/lib/lab-results/auto-resolve.ts:70-78`).** Make its stamp conditional the same way: add `.eq("status", "pending_context").select("id").maybeSingle()` and return without running when nothing is claimed. Then the route and the cron can never both run the pipeline, and the cron cannot overwrite a context the client just confirmed.

4. **Tests (`src/lib/lab-results/context-route.test.ts`).** Change the "outside pending_context" case to expect 409 and an unchanged recorded context, for processing, ready and error labs. Add the race case.

My scratch patch passes all of these:
- A pending lab behaves as before.
- After the cron
-- [True] fix: Refuse every status except pending_context, and write the context and claim the lab in one conditional update, in both the route and the cron. Then make the page leave on 409. Tested in a scratch copy: diff in fix.diff in the scratch folder.

1. src/app/api/lab-results/[id]/context/route.ts
- Drop snapshotToLab and the separate unconditional update to "processing".
- After the version check, if lab.status !== "pending_context", return 409 {error, code:"not_pending"} and write nothing.
- Otherwise, write the context and claim the lab in one update:
  `const {data: claimed, error} = await supabase.from("lab_results").update({patient_context_version_id: contextVersionId, transient_context: transientContext, status: "processing"}).eq("id", labResultId).eq("user_id", user.id).eq("status", "pending_context").select("id");`
- On a database error return 500. When no row comes back (the cron or another tab got there first), return 409.
- Keep the rest as it is: summary, ready, recomputeLabMetrics, cycle, email.
- Rewrite the header comment: the upload flow never calls this route, since /confirm writes its own context.

2. src/app/[locale]/(dashboard)/labs/[id]/context/lab-context-client.tsx
- On res.status === 409, call router.replace(`/${locale}/labs`) and return.
- The context just saved still applies to the next lab.

3. src/lib/lab-results/auto-resolve.ts:70-78
- Use the same condition: `.eq("status", "pending_context").select("id")`.
- When no row comes back, return {biomarkerCount: 0, cyclesClosed: [], skipped: true} without throwing. A throw would make the cron route's catch (cron route.ts:81-85) put the client's lab, then in processing, back to pending_context.

4. Tests
- Replace context-route.test.ts:171-177 (which asserts that a non-pending lab is only stamped) with: 

## [confirmed] (medium) [flow] A failed confirmation leaves the lab in 'error', which nothing recovers, and the client's retry is answered ok (existed before this range)
verdicts: [True, True]
-- [True] fix: Changes to src/app/api/lab-results/[id]/context/route.ts. I tested them in scratch: repo/src/verify/route-fixed.ts, with repo/src/verify/context-fixed.test.ts and the repo's context-route.test.ts, all passing; tsc is clean.

1. **Catch block (lines 213-218): stop writing 'error'.**
   - Revert only if the lab is still ours: `update({status:"pending_context"}).eq("id",labResultId).eq("status","processing")`.
   - Raise `opsAlert("lab.context.POST","interpretation failed on confirmation - lab back in pending_context",{labId,error})`.
   - Return a retryable 503 with a localized message the patient can read.
   - With this, the form's retry runs the pipeline again, the context page and the dashboard notice show the lab, and the 72-hour cron resolves it if the client leaves.

2. **Lines 171-172: treat a failed 'ready' write as a failure.** Throw instead of logging, as auto-resolve.ts:121 does. Today the route returns ok and emails results-ready while the lab stays in 'processing' forever.

3. **Lines 88-102: refuse labs that are not waiting for context.**
   - Check the status before snapshotToLab. Answer 409, with no re-stamp, for any lab not in pending_context. The only caller is labs/[id]/context; the upload flow sends its context to /confirm (upload-client.tsx:668-675).
   - Claim the lab atomically: `update({status:"processing"}).eq("id",…).eq("status","pending_context").select("id")`, and answer 409 when no row comes back (a double submit).
   - Update the route's docblock.
   - Update the third case in src/lib/lab-results/context-route.test.ts: expect 409 and no re-stamp. Its fake database must honour the status filter and return the row on `.select`.

4. **Add `export const maxDuration = 120` (audit F37).** A platform timeout skips the catch and leaves the lab in 'p
-- [True] fix: This is a pre-existing bug (F38), already planned as B9 in the September decisions doc. Fix it before real patients and before the lab bridge goes live (ECH_BRIDGE_ENABLED). It does not need to block this range. A tested version of points 1 to 3 is in my scratch folder at .../verify-intent-flow-a-failed-confirmation-leaves-the-lab-in-/fixed/context-route.ts.

1. In src/app/api/lab-results/[id]/context/route.ts:
   a. Add `export const maxDuration = 120`, as the cron has.
   b. Right after loading the lab, and before reading the version and calling snapshotToLab, return 409 {error:"not_pending", status} for any status other than pending_context. Nothing is written for a refused request. The upload flow sends its context to /confirm, so no caller loses anything.
   c. Claim the lab with `.update({status:"processing"}).eq("id", id).eq("status","pending_context").select("id")`. If no row comes back, return 409.
   d. When the update to 'ready' fails, throw instead of logging. This stops the route from sending results-ready and answering ok while the lab stays in 'processing'.
   e. In the catch, do two things instead of setting 'error':
      - opsAlert("lab.context", ..., {labId, error}).
      - `.update({status:"pending_context"}).eq("id", id).eq("status","processing")`.
      Then return 503 {error:"interpretation_failed", retryable:true}. The page and the dashboard notice then offer a retry, and the 72-hour cron resolves the lab if the client never retries.
   f. Change the alerts for a failed recompute and a failed cycle close to opsAlert as well.

2. In src/lib/lab-results/context-route.test.ts, replace the case "a lab outside pending_context is only stamped" with: 409 and nothing stamped. Add three cases:
   - generateSummary fails once: 503 with pending_context, th

## [confirmed] (low) [flow] Deleting a lab, or editing its collection date, never refreshes the dashboard cache (existed before this range)
verdicts: [True, True]
-- [True] fix: In src/app/api/lab-results/[id]/route.ts:
1. Import recomputeAndCacheUserBA from "@/lib/biomarkers/rolling-average-ba".
2. DELETE: once the stillThere check confirms the row is gone, just before `return NextResponse.json({ success: true })`, add:
   `await recomputeAndCacheUserBA(user.id, writer).catch((err) => console.error("[lab-results DELETE] recomputeAndCacheUserBA failed:", err));`
3. PATCH: after a successful collection_date update, before returning 200, add:
   `await recomputeAndCacheUserBA(user.id, supabase).catch((err) => console.error("[lab-results PATCH] recomputeAndCacheUserBA failed:", err));`
   This handler has no `writer`; the session client is what confirm/route.ts uses, and RLS allows those reads and the profile write.
4. Optional: add `status` to the ownership select and refresh only when the lab was 'ready', since other labs are not in the average.
5. Add route tests like src/lib/lab-results/ready-routes.test.ts: after DELETE the cache equals the remaining labs' figure, and after deleting the last lab it is null.

Related path outside this finding: src/lib/lab-bridge/store.ts:471-477 (replaceResults) rewrites collection_date after processLabResults has already refreshed the cache. Write the date first, or refresh after the update.
-- [True] fix: The suggested fix is right in substance; four completions.

1. DELETE in src/app/api/lab-results/[id]/route.ts:
   - Import `recomputeAndCacheUserBA` from "@/lib/biomarkers/rolling-average-ba".
   - Place the refresh after the stillThere check, so it runs only once the row is confirmed gone, and catch its errors. Otherwise a failed read is caught by the outer try and returns 500 "Delete failed" for a lab that is already gone.
   ```
   await recomputeAndCacheUserBA(user.id, writer).catch((err) =>
     console.error("[lab-results DELETE] recomputeAndCacheUserBA failed:", err));
   ```

2. PATCH in the same file:
   - PATCH has no `writer` variable. After a successful update, call:
   ```
   await recomputeAndCacheUserBA(user.id, createAdminClient() ?? supabase).catch((err) =>
     console.error("[lab-results PATCH] recomputeAndCacheUserBA failed:", err));
   ```
   - The client's own login also works, because RLS lets a user update their own profile.
   - recomputeLabMetrics is not needed. The lab's own figures use today's age (process-results.ts:714), not collection_date, and the context is chosen by created_at.

3. Tests: add wiring tests next to ready-routes.test.ts. They should check that DELETE and PATCH refresh the cache after success, and do not refresh on 401, 403, 404, a failed update, or a delete the database silently rejected.

4. Data already stale, at deploy: the CEO-approved backfill (scripts/backfill_rolling_average_ba.ts:24-28) visits only users with a ready lab. If it is run, also visit profiles where current_ba is not null; recomputeAndCacheUserBA then writes null for them. Otherwise clients who already deleted every lab keep a figure with no lab.

Optional: update the documents that say the cache is refreshed "on every successful lab upload" (rolling-a

## [confirmed] (low) [flow] recomputeLabFigures ignores an error reading the profile: figures silently not recomputed, v3 record overwritten, callers told it succeeded
verdicts: [True, True]
-- [True] fix: 1. In src/lib/biomarkers/process-results.ts, recomputeLabFigures (:675-679), read the error and throw on it. Use `.maybeSingle()` so a missing row still gives null with no error; this is the finder's PGRST116 exception, written the way rolling-average-ba.ts:274-279 does it:
   `const { data: profile, error: profileError } = await supabase.from("profiles").select("date_of_birth, sex").eq("id", userId).maybeSingle();`
   `if (profileError) throw new Error(`recomputeLabMetrics: failed to load the profile: ${profileError.message}`);`
   The throw happens before the zone-count UPDATE and before bioAgeV3Shadow. So the stored figures and the v3 record are left as they were, which makes the :640 docstring true. The dashboard refresh in recomputeLabMetrics' finally block still runs.

2. In src/app/api/lab-results/[id]/context/route.ts:180-182, replace the console.error in the catch with:
   `opsAlert("lab.context.POST", "lab ready but its metrics could not be recomputed", { labResultId, error: err instanceof Error ? err.message : String(err) })` (import from "@/lib/ops-alert").
   This matches auto-resolve.ts:127-129, so ops sees the alert and re-runs POST /api/admin/recalc-metrics {labResultId}.

3. Optionally, add a case to src/lib/lab-results/context-route.test.ts where only the 'date_of_birth, sex' read fails. It should expect the opsAlert, no lab UPDATE after that read, and the v3 record unchanged.
-- [True] fix: 1) src/lib/biomarkers/process-results.ts:675-679 (recomputeLabFigures): read `const { data: profile, error: profileError } = await supabase.from("profiles").select("date_of_birth, sex").eq("id", userId).maybeSingle(); if (profileError) throw new Error(`recomputeLabMetrics: failed to load the profile: ${profileError.message}`);`. maybeSingle returns null with no error for a missing row, matching rolling-average-ba.ts:274-279. Keeping .single() and exempting only PGRST116 is equivalent. Update the step-1 comment: a database error is not a missing profile, and the stored figures and v3 record stay as they were. The throw happens before any write, so the lab keeps its figures, the v3 record is not overwritten with sex_unknown, and the finally block still refreshes profiles.current_ba. Callers then see the failure: the route logs it, the cron raises its opsAlert, recalc-metrics reports ok:false, and the value-edit PATCH returns regenerated:false as it already does for other read errors. 2) Recommended, not strictly required: in src/app/api/lab-results/[id]/context/route.ts:180-182 replace console.error with `opsAlert("lab.context.POST", "lab ready but its metrics could not be recomputed under the confirmed context", { labResultId, error: err instanceof Error ? err.message : String(err) })`, as the cron does. Monitoring greps for the [ALERT] format, so the lab can be repaired with recalc-metrics {labResultId}; until then the lab page's creatine note misstates which context the figure used. 3) Add regression tests: a profile read error makes recomputeLabMetrics reject, with no lab_results update and no bio_age_v3_shadow upsert, while the profiles cache update still runs; the context route emits the [ALERT] line; a missing profile row keeps the zone-counts-only / sex_unknown be

## [confirmed] (low) [flow] processLabResults reads the lab's context after inserting biomarker_values, so a read error leaves values without figures and a retry duplicates them
verdicts: [True, True]
-- [True] fix: 1. Fix for this range: in processLabResults (src/lib/biomarkers/process-results.ts), read the context before anything is written. Right after `const sex = profile.sex as string;` (line 168), add `const labSupplements = await loadLabSupplements(supabase, userId, labResultId);`. At step 6b (lines 525-527) use `const kdmContext: KdmPatientContext = { supplements: labSupplements };`. The read returns the same data either way: confirm's snapshotToLab has already stamped patient_context_version_id, and nothing in processLabResults writes lab_results before step 7. A read error now aborts with no rows written. I checked this in a scratch copy: 500 with 0 rows, then the retry gives 12 rows. All 938 tests pass and tsc is clean.

2. Defence in depth, for the older triggers this move does not cover (a Gemini failure in generateSummary, or the step-7 lab_results update failing):
- Make /confirm idempotent by deleting the lab's biomarker_values before calling processLabResults, as reprocess does. The DELETE policy from migration 20260410000000 allows it with the user client. Re-count afterwards, as reprocess does, because a DELETE blocked by RLS fails silently.
- In the webhook route, delete the lab_results row it just inserted when processLabResults throws, as lab-bridge/store.ts:434-441 does. A sender retry then does not leave an orphan pending_context lab.
-- [True] fix: Leave loadLabSupplements where it is (process-results.ts:526). Moving it before the insert loses data in /api/lab-results/reprocess, which deletes the lab's values before calling processLabResults.

Make /confirm safe to retry instead. In src/app/api/lab-results/confirm/route.ts, after the context snapshot and before processLabResults (line 195), add:

  const { error: clearError } = await supabase
    .from("biomarker_values")
    .delete()
    .eq("lab_result_id", labResultId);
  if (clearError) throw new Error(`Failed to clear biomarker_values: ${clearError.message}`);

The owner's DELETE policy is in 20260410000000_add_delete_policies.sql. Optionally recount the rows afterwards, as reprocess/route.ts:187-202 does, because Supabase does not report an error when RLS blocks a delete. This fixes the new context-read trigger and the two older ones: a generateSummary failure and a failed lab_results update. Optionally, also accept /confirm only for uploaded labs with status 'processing' or 'error'.

Add a route test: one failure, then a retry; expect one row per marker and the same zone counts after recomputeLabMetrics.

Optional, older than this range: in webhook/route.ts, wrap processLabResults (line 145) in try/catch and delete the lab_results row created at :115-127 when it fails (the values cascade), as lab-bridge/store.ts:433-441 does. A provider retry then no longer leaves a second lab for the same draw.

## [confirmed] (medium) [tests] The context reads' column lists are unpinned: the dashboard and the lab page can lose the creatine adjustment while every test passes
verdicts: [True, True]
-- [True] fix: 1. In src/lib/testing/fake-supabase.ts, add an opt-in projection that mimics PostgREST:

`fakeSupabase(respond, options: { project?: boolean } = {})`, and in `then` resolve with `options.project ? { ...response, data: projectToSelect(call, response.data) } : response`.

`projectToSelect` keeps only the comma-separated columns of the call's `select`, for an object or an array of rows. A select of "*", none, or one that embeds another table is returned as scripted.

2. Turn it on in the existing wiring fakes: `processing()`, `dashboard()` and `dashboardOf()` in biological-age-kdm.creatinine.test.ts, and `database()` in context-route.test.ts. All four still pass on a9310cc. They then kill R06, R14, R16, R09 and PR03, and R08/R15 die on behaviour instead of the string collision.

3. Add a database-backed dashboard case with projection, which is the only thing that kills R07 and a version_number drop:
   - a ready lab whose patient_context_version_id is null;
   - an older version without creatine and a 5 g version, both created before the lab;
   - the versions returned oldest-first with no order clause, since fetchContextVersions has none;
   - expect the 5 g figure.

4. Make the realistic case explicit at dashboard level: a recorded version created after the lab's created_at, as the only lab (most-recent path) and alongside an older lab without creatine (window path).

5. Pin the exact select strings:
   - computeRollingAverageBA's patient_context_versions read: "id, version_number, created_at, supplements";
   - both lab_results reads: "id, collection_date, created_at, patient_context_version_id";
   - the version read in loadLabSupplements: "supplements", in the test at :214.

No production code change is needed.
-- [True] fix: 1. In src/lib/testing/fake-supabase.ts, return only the selected columns by default, not as an opt-in. After `respond(call)`, trim `data` (one row or each row) to the keys the call's `select` string names. Parse top-level tokens, splitting on commas outside parentheses:
   - any "*" token keeps the whole row;
   - "alias:col" gives the key alias;
   - "col::type" gives col;
   - "embed!hint(...)" gives embed;
   - a call with no string select is left alone.
   This is about 25 lines (diff at /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-tests-the-context-reads-column-lists-are-unpin/fake-supabase.projection.diff). The current suite passes unchanged (938/938). Every existing and future fakeSupabase test then sees only the selected columns, as PostgREST returns them; an opt-in would leave the next wiring test with the same blind spot. With this alone, the existing tests in biological-age-kdm.creatinine.test.ts and context-route.test.ts (whose context version is created after the lab arrived) catch R06, R14, R16, R09, R08 and PR03. The reviewer's `projecting` helper splits on commas and only special-cases a bare "*". That is fine inside one test file, but as a shared helper it would remove every column for "*, embed(...)" selects.

2. Add one case to the "wiring" describe in biological-age-kdm.creatinine.test.ts, so a lab with no recorded context goes through computeRollingAverageBA (this catches R07):
   - one ready lab with patient_context_version_id null, created on day -19, creatinine 1.13;
   - versions ctx-1 (day -200, no supplements), ctx-5 (day -100, creatine 5 g) and ctx-6 (day -5, no supplements);
   - expect `ba` equal to computeComprehensiveBA at creatinine 1.0.
   Optionally, also add a lab recorded u

## [confirmed] (medium) [tests] Upload confirm: no test checks that the context is recorded before processing, and the lab-page creatine adjustment now depends on that order
verdicts: [True, True]
-- [True] fix: 1. In src/lib/lab-results/ready-routes.test.ts, in the "upload confirm: after the lab is ready" test, import snapshotToLab (from @/lib/patient-context) and processLabResults (from @/lib/biomarkers/process-results). Then assert:
   expect(snapshotToLab).toHaveBeenCalledWith(LAB, VERSION, {});
   expect(vi.mocked(snapshotToLab).mock.invocationCallOrder.at(-1)!).toBeLessThan(vi.mocked(processLabResults).mock.invocationCallOrder.at(-1)!);
   This passes on a9310cc and fails when the snapshot is moved after processing.

2. Preferably, also add a confirm-route test modelled on context-route.test.ts. It should run the real snapshotToLab, processLabResults and recomputeAndCacheUserBA on a scripted database that keeps the lab's recorded context.
   - Setup: lab created at 08:00 with no context; the gate version, with creatine "5 g", saved at 08:05; the typical man of 45 with creatinine 1.13.
   - Assert that the stored lab_results.biological_age equals computeReferenceBA(panel, "male", age, {supplements: [{key: "creatine", dose: "5 g"}]}).BA (51.29).
   - Assert that profiles.current_ba equals the Comprehensive figure under the same dose (47.2).

3. Extend the comment at confirm/route.ts:161-165. processLabResults also reads the creatine dose from the version recorded on the lab (loadLabSupplements / loadLabContext). A version saved at the gate is newer than this lab row. Without the snapshot, the fallback (the latest version created on or before the lab) would ignore the dose declared at the gate. The lab-page figure, the response's biologicalAge and the email would then use the old context, while the dashboard refresh after "ready" would use the new one.
-- [True] fix: Add these to the existing tests; the route code needs no change.

1. In src/lib/lab-results/ready-routes.test.ts, add a /confirm test that checks the snapshot has finished before processing starts, not merely that it was called first. Use mockImplementationOnce and a local steps array so the other tests' ["ready","cache:..."] expectations stay as they are:
- the snapshotToLab mock does `await new Promise(r => setTimeout(r, 0)); steps.push("context recorded")`
- the processLabResults mock does `steps.push("processing started")` and returns the usual result
- assert `snapshotToLab` was called with (LAB, VERSION, {})
- assert `steps` equals ["context recorded", "processing started"]
This catches a snapshot moved after processing and one run in parallel (Promise.all). The invocation-order assertion suggested as the minimum catches only the first.

2. Recommended in addition: a real-pipeline /confirm test in the style of context-route.test.ts. It runs the route with the real snapshotToLab, processLabResults and recomputeAndCacheUserBA on a scripted database that keeps state.
- The gate's version (creatine 5 g) must be created after the lab row's created_at. Otherwise the fallback picks it anyway and the test cannot tell the order.
- Assert that the stored biological_age and biological_age_comprehensive equal computeReferenceBA and computeComprehensiveBA with creatine 5 g, that the version 3 shadow record has creatine_g_per_day 5 and divisor 1.13, and that the cached current_ba equals the lab's Comprehensive figure.
- This test alone does not catch the parallel case, so keep step 1.

3. Rewrite the comment at confirm/route.ts:161-165. The snapshot must finish before processLabResults starts, neither in parallel nor after, because:
- both KDM figures and version 3 (supplements

## [confirmed] (medium) [tests] The cron's real recompute wiring is never run by a test: auto-resolve.test.ts always injects recomputeLabMetrics
verdicts: [True, True]
-- [True] fix: Add a test that runs the cron's default wiring. The better option is a route test (src/app/api/cron/auto-resolve-pending-context/route.test.ts) built the way src/lib/lab-results/context-route.test.ts is:
- Set CRON_SECRET and call GET.
- Mock createAdminClient to return a scripted fake-supabase with a pending_context lab older than 72 hours, its biomarker_values, the profile and two context versions.
- Stub generateSummary, sendEmail, completeCycleForLabResult, getUserProfile/getWearableData and opsAlert.
- Mock "@/lib/supabase/server" to throw.
- Leave recomputeLabMetrics and recomputeAndCacheUserBA real.
- Assert that after the lab_results update setting status "ready", a lab_results update writes biological_age under the stamped version and a profiles update writes current_ba with current_ba_n_labs_averaged 1, with no "metrics could not be recomputed" alert.

The minimum alternative: in a test file that mocks "@/lib/biomarkers/process-results" at module level, call `resolvePendingLab(client, "lab-1", "u1")` with no deps argument. Assert that recomputeLabMetrics is called exactly once with ("u1", "lab-1", client), after the status:"ready" update, and that opsAlert is not called.

Either option fails on A01, A03, A05, A06 and the cookie-client change.

Optional hardening: drop the `client as never` cast at auto-resolve.ts:44 by widening recomputeLabMetrics's client parameter to `SupabaseClient | ServerClient`, as loadLabSupplements already does. A wrong client would then be a type error.
-- [True] fix: 1. REQUIRED: add a test that runs what route.ts:74 runs, `resolvePendingLab(client, "lab-1", "u1")` with no deps argument. It goes through the real defaultDeps and the real recomputeLabMetrics. Next to auto-resolve.test.ts.
   Mocks (vi.mock):
   - @/lib/supabase/server: throws.
   - @/lib/patient-context, @/lib/queries, @/lib/ai/generate-summary, @/lib/email/send, @/lib/ops-alert: stubs.
   - @/lib/cycles/close-cycle: pushes "cycle".
   - @/lib/biomarkers/rolling-average-ba: recomputeAndCacheUserBA pushes `cache:${userId}`.
   - process-results stays real.
   Fake-supabase script:
   - Push "ready" on the lab_results update that sets status ready.
   - The AI's biomarker_values select returns the lab's rows.
   - recomputeLabMetrics' own select ("biomarker_key, value, zone") records which lab_result_id it read and returns [].
   Assertions:
   - recomputeAndCacheUserBA was called once, with ("u1", client).
   - The events equal ["ready", "recompute-read:lab-1", "cache:u1", "cycle"]: after ready, and awaited before the cycle closes.
   - opsAlert was not called.
   A second case: that recompute read returns an error. The lab still turns ready, the cache is still refreshed, and opsAlert is called with "cron.auto-resolve" and "lab ready but its metrics could not be recomputed".
   A working version is at /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-tests-the-cron-s-real-recompute-wiring-is-neve/repo/src/lib/__verify__/cron-default-wiring.test.ts. It fails on all five changes (A01, A03, A05, A06, A07).
   The reviewer's assertion alone (called with ("u1", "lab-1", admin) after ready) is incomplete: it never checks that the recompute finished, so an un-awaited wrapper (A07) passes it.

2. RECOMMENDED: bind the rea

## [confirmed] (low) [tests] Rolling average: the two lab_results read-error checks cover for each other, so removing either still passes the read-error test
verdicts: [True, True]
-- [True] fix: Add a test that fails one lab_results read at a time. Put it in the "wiring" describe block of src/lib/biomarkers/biological-age-kdm.creatinine.test.ts, before the it.each at :394. Keep the existing per-table test for profiles, biomarker_values and patient_context_versions.

The client has one ready lab, so neither window finds two labs and all three lab_results reads run. A window read is identified by its gte (the first is the 6-month read, the second the 12-month read); the most-recent read is the other one, the one ending in maybeSingle.

```ts
it.each(["six-month window", "twelve-month window", "most recent"] as const)(
  "the %s lab read fails alone: it throws, and the cached figure is not overwritten",
  async (failing) => {
    const lab = { id: "lab-0", collection_date: daysAgo(20), created_at: `${daysAgo(19)}T10:00:00Z`, patient_context_version_id: "ctx-9" };
    let windowReads = 0;
    const { client, calls } = fakeSupabase((c: FakeCall): FakeResponse => {
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { sex: "male", date_of_birth: DOB } };
      if (c.table === "lab_results") {
        const read = argsOf(c, "gte") ? (windowReads++ === 0 ? "six-month window" : "twelve-month window") : "most recent";
        if (read === failing) return { error: { message: "connection reset" } };
        return { data: ops(c).endsWith("maybeSingle") ? lab : [lab] };
      }
      if (c.table === "biomarker_values") return { data: Object.entries(BASE).map(([biomarker_key, value]) => ({ lab_result_id: lab.id, biomarker_key, value })) };
      if (c.table === "patient_context_versions") return { data: VERSIONS };
      return { data: null };
    });
    await expect(recomputeAndCacheUserBA("u1", client)).rejects.toThrow(/connection reset/);
    
-- [True] fix: In src/lib/biomarkers/biological-age-kdm.creatinine.test.ts, keep the existing `it.each` that fails every read of a table. In the same describe block, add a fixture that fails exactly one lab_results read and answers the window reads filtered by their `gte`, as the database does. Add two cases:

1. Window read: ready labs 20, 50 and 250 days old. Only the first (six-month) window read fails; the twelve-month read answers.
2. Most-recent read: a client with one ready lab. Both window reads then find fewer than two labs, so the code reaches the maybeSingle read, and that read fails.

Both cases expect the call to reject with /connection reset/ and expect no profiles update. Do not reuse `dashboard()` for case 2: with two labs in six months the maybeSingle read is never made, so the case would fail on correct code. Guard each case first: with every read answering, the same labs must give window_months 6 and null respectively, which shows the case reaches the read it makes fail.

Verified code (it passes on a9310cc, R17 fails only case 1, R18 fails only case 2):
```ts
  function oneLabReadFails(fail: "window" | "latest" | null, n: number) {
    const labs = [20, 50, 250].slice(0, n).map((d, i) => ({
      id: `lab-${i}`, collection_date: daysAgo(d), created_at: `${daysAgo(d - 1)}T10:00:00Z`, patient_context_version_id: "ctx-9",
    }));
    const rows = labs.flatMap((l) => Object.entries(BASE).map(([biomarker_key, value]) => ({ lab_result_id: l.id, biomarker_key, value })));
    let windowReads = 0;
    return fakeSupabase((c) => {
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { sex: "male", date_of_birth: DOB } };
      if (c.table === "lab_results" && ops(c).endsWith("maybeSingle")) {
        return fail === "latest" ? { error: { message:

## [confirmed] (low) [tests] The test "a read error throws: no figure is stored" checks only loadLabSupplements, so processLabResults could swallow the error unnoticed
verdicts: [True, True]
-- [True] fix: At a9310cc: add a processLabResults case to the "wiring" describe in src/lib/biomarkers/biological-age-kdm.creatinine.test.ts. Make the lab_results read whose select is "patient_context_version_id, created_at" return { error: { message: "connection reset" } }. Answer profiles with the DOB and sex, biomarker_references with REFERENCE_ROWS, and everything else with { data: null }. Then:

  await expect(processLabResults("u1", "lab-1", raw({ ...BASE, creatinine: 1.13 }), client)).rejects.toThrow(/connection reset/);
  expect(calls.some((c) => c.table === "lab_results" && "biological_age" in ((argsOf(c, "update")?.[0] as object) ?? {}))).toBe(false);

Optionally also assert no profiles update and no bio_age_v3_shadow upsert, and run the case for the recorded-version and in-force-version reads too.

At a9310cc, do not assert "no writes at all": biomarker_values are inserted before the read. That assertion only becomes valid once the read moves ahead of the insert. 432441f moves it to step 1b and already contains an equivalent test, which catches the mutation. No further change is needed at HEAD.
-- [True] fix: For a9310cc the suggested fix is right. Add a processLabResults case where the "patient_context_version_id, created_at" read returns an error. Assert that processing rejects with /connection reset/ and makes no lab_results update carrying biological_age. A test of this shape passes on a9310cc and kills PR09 for each of the 3 reads.

The stronger form pairs it with reading the context before anything is written. Move the loadLabSupplements call to just after the profile checks, ahead of the biomarker_values insert, and assert no insert, update, upsert or delete at all. This pins both the error propagation and the read order. 432441f already does exactly this (process-results.ts:170-178; biological-age-kdm.creatinine.test.ts:337-366), and that test kills both mutants. Nothing more is needed on HEAD.

One optional change: retitle the loader-only it.each (HEAD :252-258) to "a read error (%s) throws". The "no figure is stored" half is now covered by the processing test.

## [confirmed] (low) [tests] The unit-less dose rule (grams below 100, milligrams from 100) appears in a test title but is checked only at 5 and 5000
verdicts: [True, True]
-- [True] fix: In src/lib/biomarkers/supplements.test.ts, test "reads a dose without a unit as grams below 100, else as milligrams", add the values on both sides of the boundary and some in between, so that the test pins the threshold to 100 and the `>=`:

```ts
const dose = (d: string) => creatineDoseGramsPerDay([{ key: "creatine", dose: d }]);
expect(dose("5")).toBe(5);
expect(dose("99")).toBe(99);
expect(dose("100")).toBeCloseTo(0.1, 10);
expect(dose("500")).toBeCloseTo(0.5, 10);
expect(dose("750")).toBeCloseTo(0.75, 10);
expect(dose("5000")).toBe(5);
```

"99" and "100" together fix the threshold to 100 and also catch `>=` becoming `>`. "500" and "750" cover the 750 mg capsule case. This is already in commit 432441f (HEAD); I checked that it kills thresholds 1000, 10, 101 and 99 and the `>` change. Nothing more is needed beyond keeping that commit.
-- [True] fix: The suggested fix is correct and complete; no change to it is needed. In src/lib/biomarkers/supplements.test.ts, the test "reads a dose without a unit as grams below 100, else as milligrams" (lines 145-148 at a9310cc) should assert:
- dose("5") -> 5
- dose("99") -> 99
- dose("100") -> 0.1 (toBeCloseTo)
- dose("500") -> 0.5
- dose("750") -> 0.75
- dose("5000") -> 5

What each part protects:
- "99" and "100" fix the threshold at 100 and catch a change from `>=` to `>`.
- "500" and "750" check the division by 1000 for common capsule sizes.

This exact block is already in HEAD 432441f at src/lib/biomarkers/supplements.test.ts:145-153, and it kills all the threshold and operator mutants there, so nothing remains to do.

## [confirmed] (medium) [clinical] Creatine added with an empty dose gets no adjustment and no prompt, yet the copy says declaring creatine avoids the higher reading
verdicts: [True, True]
-- [True] fix: The suggested fix is correct, and 432441f (after the reviewed range) applies all of it:
- In the context form, when the creatine dose is blank (`!dose.trim()`, null passed as ""), show "Sin la dosis no ajustamos tu creatinina: escríbela en gramos al día, p. ej. 5 g." / "Without the dose we cannot adjust your creatinine: write it in grams a day, e.g. 5 g." with role=alert, before calling readCreatineDose.
- In the notes on the form, dashboard and lab page: "Si la tomas y no indicas tu dosis diaria, la cifra sale más alta" / "If you take it and do not give your daily dose, the figure reads higher".
- Align metodologia/page.tsx:101 and 167, completa/page.tsx:172 ("Si no indica su dosis diaria") and :288, PHYSICIAN-SIGNOFF item 12, the PROPOSAL row and the counsel note's quotes.

Two additions I would make:
1. Show the same message in the form's summary view. When a saved creatine entry's dose is empty or cannot be read, show the chip as "Creatina · sin dosis" / "Creatine · no dose" in the warning colour, with the missing-dose sentence under the supplements card. Otherwise "Sigue siendo correcto" carries a creatine entry with no dose to every later lab without a word: contexts saved before deploy, or after the client ignored the message.
2. Move the creatine dose check into a pure exported function, for example `creatineDoseFeedback(dose: string | null)`. Unit-test it with null, "", "   ", "cinco" and "5 g": vitest only runs .test.ts files and no component test covers this.
-- [True] fix: Apply the reviewer's fix, as 432441f already does, and add a prompt in the summary view.

1. Editing view (ItemPicker). For creatine, show a message whatever the dose text, including empty:
   - Empty: "Sin la dosis no ajustamos tu creatinina: escríbela en gramos al día, p. ej. 5 g." / "Without the dose we cannot adjust your creatinine: write it in grams a day, e.g. 5 g."
   - Unreadable: keep "No podemos leer esta dosis…".

2. Summary view (missing from the suggestion and from 432441f). In PatientContextGate summary mode, check each item in snapshot.supplements with key "creatine" and readCreatineDose(dose) === null.
   - Label the chip "Creatina · sin dosis" / "Creatine · no dose", or "dosis no legible" / "dose not readable" when there is text the reader cannot read.
   - Under the Supplements card, show the same message with role="alert", adding "Pulsa «Actualizar» para añadirla." / "Press Update to add it."
   - Keep it a prompt, not a block, so "Sigue siendo correcto" still works.
   - Add a render test for both views with creatine and an empty dose.

3. Client notes: "Si la tomas y no indicas tu dosis diaria, la cifra sale más alta" / "If you take it and do not give your daily dose, the figure reads higher". Apply this in:
   - PatientContextGate creatineNote
   - dashboard-client.tsx kdmCreatine
   - labs-client.tsx creatineNote
   - metodologia/page.tsx:101 and :167
   - completa/page.tsx:172 ("Si no indica su dosis diaria"), to match :288.

4. Documents. In PHYSICIAN-SIGNOFF item 12 and the PROPOSAL row, say:
   - without a dose the form can read, nothing changes;
   - the form asks for the dose in both the editing and the summary view;
   - the notes say the figure reads higher without the daily dose;
   - labs resolved by the 72-hour cron carry only the notes

## [confirmed] (medium) [clinical] The 1.65 caveat names only eGFR and cystatin C, but the validated Comprehensive also used 17+ routine NHANES markers EVA never supplies
verdicts: [True, True]
-- [True] fix: Apply the suggested rewording in both languages, with these refinements.

1. Pages: `completa/page.tsx` `:78`/`:194`, `:140`/`:256` and `:154`/`:270`, and `metodologia/page.tsx` `:52`/`:126`.
   - State that the HR 1.65 and C 0.775 were obtained in NHANES with every trained marker each person had, up to 80.
   - Name some markers EVA never receives: the white-cell differential, sodium, potassium, chloride, MCH, MCHC and MPV. Also mention eGFR and, where measured, cystatin C.
   - State that the dashboard figure uses at most 46 markers (12 with the Base Panel) and has not been tested against mortality.
   - Delete "No se ha vuelto a evaluar sin ellos" / "It has not been re-tested without them".

2. `METHODOLOGY-CLAIMS-FOR-COUNSEL.md:86`: stop calling it "the dashboard figure's 1.65" and match the page wording.

3. `CYSTATIN-C-FIX-OPTIONS.md:10-12`: replace the pending "without eGFR and cystatin C" rerun with a test of the figure as deployed:
   - limit NHANES inputs to the 46 trained markers EVA can supply;
   - use the same gate;
   - resolve parameters the way the app does (library, Spanish q, Path B), as `kdm_panel_revalidation.py` already does;
   - use the deployed s_CA;
   - report the 12-marker Base Panel separately.
   The simplest way is to add this as an extra panel in `scripts/kdm_panel_revalidation.py`.

4. If HEAD 432441f's text is kept: its memo header says "about 17 markers EVA's calculation never receives". The exact count is 32 trained markers in the NHANES frame, 17 of them measured in most participants.
-- [True] fix: Apply the reviewer's fix, with three changes.

1. Wording on both pages, ES and EN: completa :78/:140/:154 and :194/:256/:270; metodologia :52/:126.
   - Write "que el cálculo de EVA no usa (aunque aparezcan en tu analítica)" or "no recibe", not "que EVA no mide". EVA's catalogue and upload matcher take these results and show them; only kdm-adapter.ts skips them.
   - Do not list "fórmula leucocitaria" / "white-cell differential" as a whole: lymphocyte % enters (kdm-adapter.ts:201). Write "neutrófilos, monocitos, eosinófilos y basófilos" instead.
   - Add "plomo en sangre": it carries more weight than the other listed markers combined.
   - On the full page keep "el filtrado glomerular estimado y, cuando existía, la cistatina C".
   - Model text for :154: "Se evaluó en NHANES con todos los marcadores entrenados que tenía cada persona, entre ellos varios que el cálculo de EVA no usa (neutrófilos, monocitos, eosinófilos, basófilos, sodio, potasio, cloruro, HCM, CHCM, VPM, plomo en sangre), el filtrado glomerular estimado y, cuando existía, la cistatina C: HR por desviación estándar 1,65, C-statistic 0,775. La cifra del dashboard, calculada con los marcadores de EVA, no se ha evaluado frente a la mortalidad."
   - At :78/:140 say the 1.65 is "calculada en NHANES con marcadores que la cifra del dashboard no recibe", not eGFR alone.

2. Same correction in METHODOLOGY-CLAIMS-FOR-COUNSEL.md:86 and CYSTATIN-C-FIX-OPTIONS.md:10-12.

3. Write the pending run's spec in the memo header, merged with base-panel/ASSESSMENT.md item 7:
   - Score the Comprehensive the way the app does: parameters and the deployed Comprehensive s_CA resolved as biological-age-kdm.ts does it. scripts/kdm_panel_revalidation.py already does this. Use the same gate, single draw, no creatine adjustment.
   - 

## [confirmed] (low) [clinical] 'Of the kidney filtration markers, only creatinine enters' leaves out BUN (urea nitrogen), which enters both figures with the largest weight
verdicts: [True, True]
-- [True] fix: Use the finder's wording at metodologia/page.tsx:80 and :152 and completa/page.tsx:129 and :245.
- ES: "Del riñón entran la creatinina y la urea (BUN); la cistatina C y el filtrado glomerular estimado que imprimen algunos laboratorios se muestran como resultados, pero no entran en el cálculo."
- EN: "Of the kidney markers, creatinine and urea (BUN) enter; cystatin C, and the estimated GFR some laboratories print, are shown as results but do not enter the calculation."

Make the same change in:
- METHODOLOGY-CLAIMS-FOR-COUNSEL.md:79, CALIBRATION-AND-CREATINE.md:3 and CYSTATIN-C-FIX-OPTIONS.md:3.
- The bio_age_method column comment (20261030090000_bio_age_method_r2.sql:3). It should name only what never enters: cystatin C and a laboratory eGFR.
- bio-age-method.ts:7.
- biological-age-kdm.ts:603-604, :761 and :838.
- The test texts: biological-age-kdm.creatinine.test.ts:2 and :49, and biological-age-explain.test.ts:188.

HEAD 432441f already does all of this except biological-age-kdm.ts:844 (":838" at a9310cc), creatinine.test.ts:49 and explain.test.ts:188. Those three still say "only kidney marker"; reword them to something like "cystatin C and a laboratory eGFR never enter; creatinine (creatine-adjusted) and BUN do".

Optional: say on the pages that, with the Base Panel, BUN carries the most weight, and that dehydration or a high-protein diet raises urea and the figure. Clients could then connect a high figure to their urea.
-- [True] fix: Name urea (BUN) as entering, but keep the "filtration" scope, which the suggested fix drops.

1. Pages: metodologia/page.tsx:80 (ES) and :152 (EN); metodologia/completa/page.tsx:129 (ES) and :245 (EN).
   - ES: "De los marcadores de filtración renal entran la creatinina y la urea (BUN); la cistatina C y el filtrado glomerular estimado que imprimen algunos laboratorios se muestran como resultados, pero no entran en el cálculo."
   - EN: "Of the kidney filtration markers, creatinine and urea (BUN) enter; cystatin C, and the estimated GFR some laboratories print, are shown as results but do not enter the calculation."
   - Do not use the reviewer's "Del riñón" / "Of the kidney markers". EVA files serum calcium under Riñones/Kidneys, and calcium enters the dashboard figure, so the sentence would again leave out a marker that enters. Calcium is not a filtration marker, so "filtration" keeps the sentence accurate.

2. Documents:
   - METHODOLOGY-CLAIMS-FOR-COUNSEL.md:79: "Of the kidney filtration markers, creatinine and urea (BUN) enter. Cystatin C and a laboratory's eGFR are shown as results and never enter either figure; ..."
   - CALIBRATION-AND-CREATINE.md:3: "of the kidney filtration markers, creatinine and urea (BUN) enter the biological age, and cystatin C and a laboratory's eGFR never do; ..."
   - CYSTATIN-C-FIX-OPTIONS.md:3: "Of the kidney filtration markers, creatinine and urea (BUN) enter both figures; ..."

3. Column comment: supabase/migrations/20261030090000_bio_age_method_r2.sql:3 is not deployed, so edit it in place: "of the kidney filtration markers creatinine and urea (BUN) enter and cystatin C and a laboratory eGFR never do, ..."

4. Internal text with the same error, added in this range:
   - biological-age-kdm.ts:603-604: "creatinine and BUN (urea is con

## [confirmed] (low) [clinical] The provenance-tag documentation misdescribes the earlier rules behind stored Reference figures
verdicts: [True, True]
-- [True] fix: Both texts at a9310cc need the same correction.

Migration line 3, old-tag part:

'"KDM_v2.2_ReferenceBA" on rows written from 26 May to 30 October 2026 under the earlier rules: a cystatin C result removed creatinine from the figure and nothing took its place (cystatin C only stood in for creatinine at the gate, so a lab with cystatin C and no creatinine still got a figure, which a recompute now clears); otherwise a declared creatine dose subtracted min(0.05 + 0.025 x g/day, 0.40) mg/dL from creatinine; the client''s latest context. A laboratory eGFR never entered this figure. eGFR and cystatin C entered only the Comprehensive figures (the dashboard''s, and biological_age_comprehensive on the same row). NULL on legacy rows.'

bio-age-method.ts:13-16: use the same wording, and add "so those figures had no creatinine, cystatin C or eGFR (urea still entered)".

HEAD 432441f already uses the finding's suggested wording in both files. Only two additions would be worth making there: the gate clause, and the mention of the biological_age_comprehensive column.
-- [True] fix: The suggested wording is right in substance and is already in 432441f. Change these places:

(1) supabase/migrations/20261030090000_bio_age_method_r2.sql:3, the part about the old tag:
'"KDM_v2.2_ReferenceBA" on rows written from 26 May 2026 until the _r2 rules were deployed, under the earlier rules: a laboratory eGFR never entered this figure; a cystatin C result removed creatinine, and with it the creatine correction, and nothing took its place in the estimate (cystatin C itself never entered; urea (BUN) stayed). Cystatin C still stood in for creatinine at the gate, so a lab with cystatin C and no creatinine got a figure, which the _r2 rules withhold. The dose formula subtracted min(0.05 + 0.025 x g/day, 0.40) mg/dL from creatinine, using the client''s latest context. A laboratory eGFR, and cystatin C in creatinine''s place, entered only the Comprehensive figure: biological_age_comprehensive on these same rows, and the dashboard''s cached rolling average (profiles.current_ba), which carries no tag.'

(2) src/lib/biomarkers/bio-age-method.ts:13-18: use the same text, and delete "so those figures had no kidney filtration marker". BUN stayed in those figures and still moved them by years.

(3) src/lib/biomarkers/biological-age-kdm.ts:606-607: replace "Until 30 October 2026 it replaced creatinine, which left the Reference version with no kidney marker at all" with "Under the earlier rules it removed creatinine from both versions: the Comprehensive used it in creatinine's place; the Reference did not use it, which left urea (BUN) as that figure's only kidney marker."

Optional, in the same sentence: the old tag covers two sets of rules. Rows written before 25 September 2026 also come before that day's three input fixes: measured fructosamine set aside, the log-scale Spanis

## [confirmed] (low) [clinical] The reason given for the 3 g cap is overstated on the full page, and sign-off item 12(b) contradicts itself
verdicts: [True, True]
-- [True] fix: Apply on top of HEAD 432441f, which already holds the finder's version. Keep the Hultman reason. Replace the "not studied" clause, which is wrong because two small trials did compare doses.

**completa/page.tsx:172 (ES):**
"EVA la aplica entera desde 3 g al día porque con 3 g al día el músculo acaba tan cargado de creatina como con dosis mayores (Hultman 1996), y en proporción por debajo. No se sabe si una dosis mayor sube más la creatinina: los metaanálisis no analizaron la dosis, y los dos ensayos pequeños que compararon dosis no encontraron diferencias en la creatinina, ni siquiera frente a placebo. Es una estimación de EVA."

**completa/page.tsx:288 (EN):**
"EVA applies it in full from 3 g a day because at 3 g a day muscle ends up as loaded with creatine as at higher doses (Hultman 1996), and in proportion below that. Whether a higher dose raises creatinine more is not known: the meta-analyses did not analyse dose, and the two small trials that compared doses found no difference in creatinine, not even against placebo. This is EVA&apos;s estimate."

**PHYSICIAN-SIGNOFF.md:33, item 12(b)** (use the same wording in the supplements.ts comment above CREATINE_SATURATING_DOSE_G):
"(b) It applies in full from 3 g/day, because 3 g/day fills muscle creatine as much as higher doses, only more slowly (Hultman 1996). Whether a higher dose raises creatinine more is not known: no meta-analysis analysed dose, and the two small trials that compared doses found no difference in serum creatinine between any arms, placebo included (Vilar Neto 2020, PMID 32670557: 3 vs 5 g/day, 12 men per arm, 35 days; Kondo 2016, PMID 26907087: 2, 4 or 10 g/day, 8 weeks), so neither informs a gradient."

**supplements.ts, Naeini sentence (optional):** add "and significant again beyond 12 weeks" after 
-- [True] fix: Apply on HEAD (432441f). Keep the Hultman reason that is already there; replace the clauses that say "not studied". If fixing from a9310cc instead, first replace "porque los ensayos no han mostrado una subida mayor con dosis más altas" and "because trials have not shown a larger rise at higher doses" with the Hultman reason quoted in items 1 and 2.

1. **completa/page.tsx:172 (ES).** Replace "y en proporción por debajo; ningún ensayo ha estudiado si una dosis mayor sube más la creatinina, así que es una estimación de EVA." with: "y en proporción por debajo. Es una estimación de EVA: no se sabe si una dosis mayor sube más la creatinina, porque los pocos ensayos que compararon dosis eran demasiado pequeños para saberlo." The full sentence then begins "EVA la aplica entera desde 3 g al día porque con 3 g al día el músculo acaba tan cargado de creatina como con dosis mayores (Hultman 1996)".

2. **completa/page.tsx:288 (EN).** Replace "and in proportion below that; no trial has studied whether a higher dose raises creatinine more, so this is EVA&apos;s estimate." with: "and in proportion below that. This is EVA&apos;s estimate: whether a higher dose raises creatinine more is not known, because the few trials that compared doses were too small to tell." The sentence before it keeps "because at 3 g a day muscle ends up as loaded with creatine as at higher doses (Hultman 1996)".

3. **PHYSICIAN-SIGNOFF.md:33, item 12(b).** Replace with: "(b) It applies in full from 3 g/day, because 3 g/day fills muscle creatine as much as higher doses, only more slowly (Hultman 1996). Whether a higher dose raises creatinine more is not known: Tsiaras 2026 and Naeini 2025 analysed duration, not dose, and the trials that compared doses were too small to tell; the one comparing 3 and 5 g/day (Vil

## [confirmed] (medium) [dose-fuzz] Serving counts silently dropped (gummies, capsules, tablets) or fused into a thousands number
verdicts: [True, True]
-- [True] fix: Changes to src/lib/biomarkers/supplements.ts at a9310cc:

1. Widen SERVING (:238): add gominolas?, gomitas?, gumm(?:y|ies), sticks?, servicios? and c[áa]ps\.?. In SERVINGS_OF (:332-334), allow an optional "masticables", "de creatina" or "of creatine" between the serving word and de/of.

2. Read a product only when the mass is clearly per serving:
   - after de/of or x/*;
   - after "cada un[oa]", "each", "c/u", "por/per cápsula" or "/<serving word>";
   - "N de M unit" with no serving word, which also covers "4 diarias de 750mg" once "diarias" is removed;
   - "N per day, M each".

3. Turn ½, ¼, ¾, "un cuarto de", "tres cuartos de" and "half a" into numbers before reading.

4. Do not read "d{1,3} ddd" as thousands when a serving word follows the unit: "2 500mg capsules" is 2 × 0.5 g. Keep "2 500 mg" = 2.5.

5. Before the single-mass fallback at :387, return null when a count other than 1 stands before a serving word and none of the forms in step 2 read it. This covers masses written right after the serving word and masses in brackets.
   - A label-style total ("2 cápsulas 1,5 g", meaning 2 × 750 mg) and a per-unit size ("4 capsulas 750mg") are written the same way, so the form should ask, as the house rule does for other ambiguous doses.
   - The finder's suggestion to read a mass written right after the serving word as a product would turn "2 cápsulas 1,5 g" into 3 g, a +0.065 divisor over-read.
   - Its prototype also gives a factor-of-2 difference between the bracketed and unbracketed forms of the same dose.
   - Whichever rule is chosen, the bracketed and unbracketed forms must behave the same.

6. In src/components/dashboard/PatientContextGate.tsx, show the value read under the input ("Leemos X g al día"), so any remaining misread is visible to the client.

7. Add 
-- [True] fix: Keep the finding's fix; HEAD 432441f already has most of it. That covers:
- the extra serving words, with a trailing "." and "masticables" / "de creatina";
- the "each" markers;
- a count written right before the serving word's mass ("4 capsulas 750mg");
- "N de M" and "N per day, M each";
- ½, ¼, ¾ and "un cuarto de";
- a count, a mass and a serving word read as a product, not as thousands;
- "Leemos N g al día" shown under the input.

On top of it:

1. **Never cut a count out of another number.** In COUNT_THEN_EACH (HEAD supplements.ts:438), require a real separator:
   `(?<![\d.,])(COUNT)(?:\s*[,;]\s*|\s+)(NUMBER)\s*(WORD)\s*EACH`
   Also put `(?<![\d.,])` before the leading COUNT of COUNT_TIMES and COUNT_MASS_SERVING.

2. **Zero only when the client wrote zero.** In readCreatineDose, before returning, add `if (g === 0 && /[1-9]/.test(text)) return null`.

3. **Don't rely on the closed word list for the guard.** In the single-mass fallback, also return null when any count other than 1 (a number, or a count word) stands before the mass and no form read it, whatever word follows it.
   - Skip a total stated with "=" ("2 scoops = 10 g").
   - Skip a number followed by "%" or "mesh".
   - Keep HEAD's UNREAD_SERVINGS for counts after the mass, outside brackets.
   - This makes "4 comp. de 1 g", "4 grageas de 1 g", "2 chews of 1.5 g" and "4 softgels 750 mg" ask instead of reading 1, 1, 1.5 and 0.75.

4. **Form.** Mark a 0 reading of a non-empty dose as a problem, not as "Leemos 0 g al día" in the neutral colour.

5. **Tests.** Add these:
   - "2 x 750 mg cada una" → 1.5
   - "2 x 1000 mg each" → 2
   - "2x750mg each" → 1.5
   - "2 tomas al día de 2500 mg cada una" → 5
   - "4 cápsulas de 750 mg cada una" → 3
   - "1500 mg each" → 1.5 or null, never 0
   - "4 comp. de 1 g" 

## [confirmed] (medium) [dose-fuzz] Schedules less often than daily read as every day (cada 3 días, x semana, /sem, weekday names, día sí día no)
verdicts: [True, True]
-- [True] fix: The suggested fix is correct and is already in HEAD 432441f, outside the reviewed range:
- EVERY_N_DAYS and EVERY_N_HOURS are read before DURATION (supplements.ts:313, :322-325, :383-395).
- "x" is in the prefix lists, "de" is in DAYS_PER_WEEK, and sem/wk are in WEEK (:314-318, :327-330).
- EVERY_OTHER_DAY has the "día sí día no" forms (:319-321).
- UNCOUNTED_SCHEDULE returns null when no count a week was read (:263-271, :547).
- The form now shows what it read (PatientContextGate creatineDoseRead).

All of the finding's inputs now read the careful value or ask. To close the same mechanism at HEAD:
1. Read "(cada|every|c/) N (semanas?|sem|weeks?|wks?|mes(es)?|months?)" before DURATION, as every 7N or 30N days. The existing everyNDays <= 7 bound (:552) then makes the form ask for N >= 2 weeks.
2. Alternatively, give DURATION a lookbehind so it never strips a count preceded by cada/every/c/.
3. Add these to UNCOUNTED_SCHEDULE: "(cada|every) (mes|month)", "quincenal(es|mente)?", "biweekly", "fortnightly", "every other week", "(d[ií]as )?laborables", "cuando entren[oe]", "when i (train|work out)", and the Spanish weekday abbreviations "lun|mi[eé]|jue|vie|s[aá]b|dom" with the existing letter guards.
4. Add "d[ií]a (por|de) medio" and "interdiari[oa]s?" to EVERY_OTHER_DAY.
5. Add test rows for these cases to supplements.test.ts.
-- [True] fix: The suggested fix is right and is already in 432441f, but it is incomplete. Add the following to the current supplements.ts.

Prototype: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-dose-fuzz-schedules-less-often-than-daily-read-as-/proto/supplements.ts
Diff against HEAD: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-dose-fuzz-schedules-less-often-than-daily-read-as-/proto.vs.head.diff

(1) Intervals of weeks or months
- Make DURATION skip a count after cada/every/c/ for every unit, not only days:
  `(?<!(?:cada|every|c\/)\s*)(?<![\d.,])(COUNT)\s*DURATION_UNIT(?![letters])`
- Return null (the form asks) for:
  - '(cada|every|c/) (COUNT|otra|other|second|2nd) (semanas|weeks|sem|wks|meses|months)';
  - 'cada mes', 'every month', 'mensualmente';
  - 'quincenal(es|mente)', 'quincena(s)', 'fortnight(ly)', 'bi-weekly', 'bi-monthly'.
  Alternatively, read these as every 7N or 30N days; the existing 1-7 day check then returns null.
- Add quince/fifteen = 15 to COUNT_WORDS, so 'cada quince días' reaches that check.

(2) Weekly words and counts
- Accept 'semanal(es|mente)' in WEEKLY_AMOUNT and in DAYS_PER_WEEK's second branch.
- In DAYS_PER_WEEK, accept 'v.?' as a times word and 'de cada' as a connector.
- Add thrice = 3 to COUNT_WORDS.

(3) EVERY_OTHER_DAY
- Accept '1' wherever it accepts 'un' or 'otro' ('1 día sí 1 no').
- Add 'alternando días', 'días intercalados', 'día por/de medio', 'interdiario'.

(4) Schedules with no count a week: return null
- Add to UNCOUNTED_SCHEDULE:
  - Spanish day abbreviations: lun|mar|mi[eé]|jue|vie|s[aá]b|dom (as whole words);
  - training-day wording:
    - 'días (de|que|en que) (gimnasio|voy|hago|deporte|pesas)';
    - 'cuand

## [confirmed] (medium) [dose-fuzz] A singular week or an abbreviated duration is read as a frequency or a multiplier ('5 g desde hace una semana' → 0.71 g/day)
verdicts: [True, True]
-- [True] fix: The finder's fix is right in substance, and 432441f already implements an equivalent. Apply this to a9310cc's supplements.ts:

(a) Remove led durations before any frequency is read, with LED_DURATION. It covers `(?:durante|desde\s+hace|hace|llevo|lleva|for|during|since|over)\s+(?:(?:COUNT|an?|un[oa]?)\s*)?UNIT(?![letter])(?:\s+ago)?` and `(?:COUNT|an?)\s*UNIT\s+ago`. This handles "for a week", "a week ago" and "desde hace una semana" more robustly than skipping WEEKLY_AMOUNT depending on the words around it.

(b) DAYS_PER_WEEK must require something between the count and semana/week/wk/sem. Either a days/times word (d[ií]as?, d, veces, vez, days?, times, x) or a prefix (/, a, al, por, per, each, cada, en, x). A bare "1 semana" or "one week" is then left to DURATION.

(c) Change DURATION's units to `d[ií]as?|semanas?|sem|mes(?:es)?|años?|days?|weeks?|wks?|months?|years?|d`. This strips "x 30d" and "x 3 sem" before TIMES_COUNT can read them.

(d) Add the 14 singular and abbreviated cases to supplements.test.ts.

Optional hardening for the 3 phrasings 432441f still misreads:
- Add month abbreviations (mo, mos, mth, mths, and m after "x N") to the duration units. Alternatively, have TIMES_COUNT reject a count followed by a word: `(${COUNT})(?!\s*[letter])`.
- Treat "a week now", "a week in" and "a week so far" as a duration.
-- [True] fix: Do not apply the reviewer's changes again: 432441f already contains an equivalent fix (LED_DURATION, DURATION_UNIT with sem, wks? and d, DAYS_PER_WEEK needing a days/times word or a prefix, and tests at supplements.test.ts:206-208). That fix, however, reads a days-a-week schedule that follows a duration word as a weekly amount. Correct that, and accept hedge words, by replacing LED_DURATION in src/lib/biomarkers/supplements.ts at HEAD:

/** A duration's words followed by a per-week phrase ("durante 3 días a la semana") are a frequency, not a duration. */
const NOT_PER_WEEK = `(?!\\s*(?:(?:\\/|a|al|por|per|each|cada|en|x)\\s*)?(?:la\\s+)?(?:semana|week|wk|sem)(?![${LETTER}]))`;
/** An approximation between the lead word and the count ("for about a week", "desde hace casi un mes"). */
const HEDGE = `(?:(?:about|almost|nearly|around|roughly|approximately|more\\s+than|casi|unos|unas|aprox\\.?|aproximadamente|m[aá]s\\s+de)\\s+)?`;
const LED_DURATION = new RegExp(
  `(?<![${LETTER}])(?:durante|desde\\s+hace|hace|llevo|lleva|for|during|since|over)\\s+${HEDGE}(?:(?:${COUNT}|an?|un[oa]?)\\s*)?${DURATION_UNIT}(?![${LETTER}])${NOT_PER_WEEK}(?:\\s+ago)?|(?<![${LETTER}])(?:${COUNT}|an?)\\s*${DURATION_UNIT}\\s+ago(?![${LETTER}])`,
  "g",
);

Add these to the readCreatineDose cases in supplements.test.ts:
- Regression cases: "5 g durante 3 días a la semana" 15/7, "5 g for 3 days a week" 15/7, "5g for 4 days/week" 20/7, "5 g durante 3 días por semana" 15/7, "2 g durante 3 días a la semana" 6/7.
- Hedge words: "5g for about a week" 5, "3 g for nearly a week" 3, "5 g desde hace casi un mes" 5.
- The finding's inputs not yet tested: "5 g (llevo 1 semana)" 5, "5 g, empecé hace 1 semana" 5, "5 g x una semana" 5, "3 g desde hace 1 semana" 3, "5g, taking it for a week" 5, "5 g, 1 week in" 5, 

## [confirmed] (medium) [dose-fuzz] Spanish informal decimal marks misread: '2'5 g' → 5 g, '0'75 g' → 75 g; 'y medio' dropped
verdicts: [True, True]
-- [True] fix: In src/lib/biomarkers/supplements.ts, add a pass that applies to creatine only, so parseSupplementDose for other supplements is unchanged:

```ts
function normalizeCreatineText(text: string): string {
  return text
    .replace(/[⁄∕]/g, "/")  // fraction or division slash: SLASH_BETWEEN_NUMBERS then asks
    .replace(/(\d)\s*['´’‘`′ʼ＇]\s*(\d)/g, "$1,$2")  // 2'5, 2´5, 2’5, 2′5 -> 2,5; "5'000 mg" -> "5,000 mg" = 5 g via readNumber
    .replace(new RegExp(`(?<![\\d.,])(\\d+)\\s*(g|gr|grs|gramos?|grams?)\\s+y\\s+medi[oa](?![${LETTER}])`, "g"), "$1,5 $2");  // whole N only
}
const LEFTOVER_Y_MEDIO = new RegExp(`(?<![${LETTER}])y\\s+medio(?![${LETTER}])`);
```

In readCreatineDose:

```ts
const text = normalizeCreatineText(normalizeDose(dose));
if (!text || PER_KG.test(text) || SLASH_BETWEEN_NUMBERS.test(text) || LEFTOVER_Y_MEDIO.test(text)) return null;
```

Add tests for the 13 inputs, plus: `5'000 mg` → 5, `2′5 g` → 2.5, `1∕2 g` → null, `2,5 g y medio` → null, `5 g a las 7 y media` → 5.

On HEAD 432441f, which already has the core of this fix:
- widen the mark class at :353 with ′ (U+2032), ʼ (U+02BC) and ＇ (U+FF07);
- add the `(?<![\d.,])` lookbehind and `medi[oa]` to the "y medio" rewrite at :356, which removes the `2,5 g y medio` → 255 regression;
- add the leftover-"y medio" null guard.
-- [True] fix: Keep HEAD 432441f's normalizeCreatineText. It is the suggested fix and is correct for all 13 inputs. Complete it in src/lib/biomarkers/supplements.ts as follows:

(1) Read three more apostrophe-like characters: use /(\d)\s*['´’‘`′ʼ＇]\s*(\d)/g → "$1,$2" (adds U+2032, U+02BC, U+FF07). Keep the mapping of ⁄ and ∕ to "/".

(2) Fix the root cause instead of listing characters. In gramsPerIntake, in the single-amount branch, add this right after `const at = mass?.index ?? 0;`:
`if (new RegExp(`\\d[^\\d${LETTER}()%]{0,3}$`).test(text.slice(0, at))) return null;`
A digit right before the amount, joined only by spaces or marks the reader does not know ("0 5 g", "2:5 g", "2''5 g", "2, 5 g"), then makes the form ask instead of dropping the integer part.

(3) Handle "y medio" / "y media" safely:
- Rewrite it to ",5" only after a whole number with no decimal of its own, followed by a gram word: `(?<![\d.,])(\d+)\s*(g|gr|grs|gramos?|grams?)\s+y\s+medi[oa](?![LETTER])`.
- Only rewrite when it is followed by the end of the text, punctuation, or a word about how often or when: al, a, por, per, x, cada, diari[oa]s?, todos, en, con, antes, después, tras, daily, "de creatina".
- Add HALF_LEFT = /(?:g|gr|grs|gramos?|grams?)\s+y\s+medi[oa](?![LETTER])/ to readCreatineDose's list of patterns that return null. Any "y medio/media" still left after grams ("2,5 g y medio", "2 g y medio vaso de agua") then asks.

(4) Add test cases to supplements.test.ts:
- Read as a number: "2′5 g" → 2.5, "2 g y media" → 2.5.
- Must ask (null): "0 5 g", "2:5 g", "2''5 g", "2, 5 g", "2,5 g y medio", "2 g y medio vaso de agua".
- Must not change: "5 g a las 8'30" → 5, "5'000 mg" → 5, "2 500 mg" → 2.5.

## [confirmed] (low) [dose-fuzz] Several intakes a day: frequency or second amount dropped, or a split total multiplied
verdicts: [True, True]
-- [True] fix: For the reviewed range, the finder's fix is correct. It is already applied in 432441f, so keep it. That commit matches literal phrases, though, so I would generalise it. I prototyped this in scratch (proto/supplements.ts; the diff is in proto.diff in my scratch folder):

1. Drop "mañana y noche | morning and night/evening | am y pm" from the third TIMES_PER_DAY alternative, keeping bid/tid. Add a list of times of day:
   - TIME_OF_DAY = mañana | mediodía | tarde | noche | morning | noon | afternoon | evening | night | am | pm | al levantarme | al despertar(me) | al acostarme | antes de dormir | before bed.
   - Each may follow an optional "por/en/a/de la", "in the" or "at".
   - Entries are joined by `, + & / - – y and`.
   - Regex: TIMES_OF_DAY_LIST = `(?<!letter)PREFIX TIME (JOIN PREFIX TIME)+(?!letter)`.
   - In readFrequency, after the times-a-day take: if timesPerDay is still null and SPLIT_BEFORE does not match the text before the list, set timesPerDay to the number of distinct TIME_OF_DAY words in the match. A number between two times ("1 g mañana y 1 g noche") breaks the list, so the two-amount rules still apply.
2. EVERY_N_HOURS: also accept "each", "q" and a bare "/" before the number, and hour words (cuatro/four 4, seis/six 6, ocho/eight 8, doce/twelve 12).
3. "cada comida", "con/en las comidas", "with (each/every) meal(s)" with no counted meal list: return null so the form asks.
4. Add these inputs to supplements.test.ts next to lines 212-215 and 225-226.

Checks on the prototype:
- HEAD's own supplements.test.ts passes (181/181).
- All 17 finding inputs and all 17 HEAD near-variants read the careful value or ask.
- The 20 must-not-change inputs are unchanged, including "5 g por la noche", "5 g/24h", "5 g cada 48 horas", "2 g repartidos en mañana y noche" (2
-- [True] fix: This applies on top of HEAD 432441f, in src/lib/biomarkers/supplements.ts. The full patch is in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-dose-fuzz-several-intakes-a-day-frequency-or-secon/corrected-fix.patch and the patched file is fix/supplements.ts in the same folder.

(a) Times of day and meals: one list reader.
- Remove the fixed phrase "mañana y noche" / "morning and night" / "am y pm" from TIMES_PER_DAY, keeping bid and tid there. Remove the MEAL set count.
- Add SLOT_LIST: two or more times of day or meals in one list. The words are mañana, mediodía, tarde, noche, morning, noon, afternoon, evening, night, am, pm, pre, post, desayuno, almuerzo, comida, merienda, cena, breakfast, lunch, dinner and supper.
- Each word may follow "por la", "a la", "en la", "de", "con el", "in the", "at" or "with".
- The words may be joined only by ",", ";", "&", "+", or a whole-word "y", "e" or "and". The count is the number of distinct words.
- Joined by "o" or "or", or negated ("no con la cena"), the words are not a list: one intake.
- "am/pm" and "desayuno/cena" ask. "con cada comida", "con las comidas", "with every meal" and "with meals" ask when no count is given.

(b) A split total always wins.
- If "en N tomas/dosis", "repartid[oa]s", "dividid[oa]s", "split", "divided" or "en total" appears anywhere, or "entre", "between" or "across" comes right before the list, the amount is the day's total.
- Apply this after every count is read (times a day, hours, list), not only when the phrase comes right after "en".

(c) Compare counts that name the same intakes; never multiply them. This covers a times-a-day phrase, every N hours, a list, and a count of "tomas/dosis" in the amount. If they are equal, use the count once; i

## [confirmed] (low) [dose-fuzz] Texts that should be refused get a number: per-kg doses ('x kg', '/kilo'), doses the client stopped, mg written for g
verdicts: [True, True]
-- [True] fix: Keep what HEAD 432441f already applies, and correct its stop-word list.

Already in HEAD:
- PER_KG = `\/\s*k(?:g|ilo)|(?<![LETTER])(?:por|per|cada|each|x)\s*k(?:g|ilo)|(?<![LETTER])kg\s*-\s*1(?![0-9])`
- Return null when one intake is above 0 and below SMALLEST_CREATINE_INTAKE_G = 0.1 g.
- The '5 mgs' test expects null.

Changes to make in src/lib/biomarkers/supplements.ts:

1. Replace STOPPED with:

`(?<![LETTER])(?:` + [`ya\s+no(?!\s+(?:hago|cargo)(?![LETTER]))`, `no\s+(?:la\s+|lo\s+)?tomo`, `(?<!nunca\s+(?:la\s+|lo\s+)?)dej[eé]`, `dejad[oa]s?`, `tomaba`, `suspend[LETTER]*`, `interrump[LETTER]*`, `abandon[LETTER]*`, `parad[oa]`, `pausad[oa]`, `en\s+pausa`, `antes(?!\s+(?:de|del|o|u|y|e)(?![LETTER]))`, `stopped`, `no\s+longer`, `not\s+any\s*more`, `not\s+taking`, `used\s+to`, `quit`, `was\s+taking`, `discontinu[LETTER]*`, `paused`, `on\s+hold`, `previously`, `formerly`].join('|') + `)(?![LETTER])`

Here LETTER is the module's letter class, written as `[${LETTER}]` in the template string. The dead `lo\s+dej` and `la\s+dej` alternatives are dropped.

2. In normalizeCreatineText, add `.replace(/⁻/g, '-').replace(/¹/g, '1')` so that 'kg⁻¹' reaches PER_KG as 'kg-1'.

3. Add test cases:
- Expect null for: 'tomaba 5 g', '5 g (la he dejado)', 'suspendida (5 g)', 'was taking 5 g', '5 g, not anymore', '5 g (discontinued)', '0,1 g·kg⁻¹·día⁻¹'.
- Expect 5 for: '5 g al día, antes o después de entrenar', '5 g antes o después del entreno', '5 g, ya no hago fase de carga', '5 g, nunca la dejé'.

Checked in scratch (repo-head-fixed/, probe-fixed.out.txt):
- HEAD's supplements.test.ts passes 181/181 against the patched copy.
- All 12 finding inputs and all the gap inputs above return null.
- The four normal current doses return 5.

Because a word list can never be complete, the form's r
-- [True] fix: The suggested fix is correct as far as it goes, and 432441f has applied it: PER_KG with x, /kilo and kg-1; a STOPPED check; a 0.1 g floor per intake; the test now expecting "5 mgs" to give null; and the read-back in the form. Complete it in src/lib/biomarkers/supplements.ts as follows.

(1) PER_KG: also accept "*" as the times sign:
`new RegExp(`\\/\\s*k(?:g|ilo)|(?:(?<![${LETTER}])(?:por|per|cada|each|x)|\\*)\\s*k(?:g|ilo)|(?<![${LETTER}])kg\\s*-\\s*1(?![0-9])`)`

(2) STOPPED:
- Replace the dead `lo\\s+dej|la\\s+dej` with `(?:lo|la)\\s+(?:he\\s+)?dej[${LETTER}]*`.
- Replace `no\\s+tomo|no\\s+la\\s+tomo` with `no\\s+(?:la\\s+|lo\\s+)?(?:estoy\\s+)?tom(?:o|ando)`.
- Add these Spanish forms: `dejad[oa]`, `tomaba`, `tom[ée]\\s+hasta`, `sol[ií]a`, `suspend[${LETTER}]*`, `par[eé]`, `ahora\\s+no`, `actualmente\\s+no`, `sin\\s+tomar(?:la|lo)?`, `hasta\\s+(?:${MONTH}|hace|el\\s+mes|la\\s+semana)`.
- Add these English forms: `stopping`, `not\\s+(?:currently\\s+)?taking`, `was\\s+taking`, `took`, `discontinu[${LETTER}]*`, `paused?`, `previously`, `formerly`, `until\\s+(?:${MONTH}|last)`.
- MONTH is the Spanish and English month names. "hasta" and "until" count only before a month or "hace", so "hasta 5 g" (up to 5 g) still reads.

(3) Tests in supplements.test.ts:
- These give null: the 19 phrasings listed in the evidence, "0,1g*kg" and "0,1 g * kg".
- These still read: "5 g antes de entrenar", "5 g antes del entreno", "5 g para el entreno", "2*2,5 g", "5 g desde mayo".

(4) Keep the form's read-back ("Leemos X g al día"). No word list is complete, and the read-back is what shows the client any misread that remains.

A working version that passes all of HEAD's tests is at /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/review5/verify-intent-dos

## [split] (medium) [flow] The 72-hour cron recomputes a lab under the client's current context, so a context saved after the draw changes the draw's figure
verdicts: [True, False]
-- [True] fix: In src/lib/lab-results/auto-resolve.ts, have resolvePendingLab stamp the version the lab-context rule gives this lab, instead of the client's latest version. Replace lines 55-67 and the stamp update with:

```ts
const { data: labRef, error: labRefError } = await admin
  .from("lab_results").select("patient_context_version_id, created_at")
  .eq("id", labId).eq("user_id", userId).maybeSingle();
if (labRefError) throw new Error(`load lab: ${labRefError.message}`);
if (!labRef) throw new Error("lab not found");
// The version the lab is read under (lab-context.ts): the one its figures were computed under on arrival.
const inForce = await loadLabContext<{ id: string }>(admin, userId, labRef as LabContextRef, "id");
let versionId: string | null = inForce?.id ?? null;
if (!versionId) {
  // No version was in force when the lab arrived. A client with no version at all gets an empty one, as now.
  // A client whose versions are all later than the lab gets none stamped, so the lab keeps reading none, as on arrival.
  const current = await deps.getCurrentVersion(userId, admin);
  if (!current) versionId = (await deps.createNewVersion(userId, emptySnapshot(), admin)).id;
}
// stamp: { ...(versionId ? { patient_context_version_id: versionId } : {}), transient_context: { skipped: true, auto_resolved: true }, status: "processing" }
```

When only later versions exist, do not stamp the current version, because that still moves the figure. Do not mint an empty version either, because it would become the client's current context in the next gate.

Keep the recomputeLabMetrics call. It then changes nothing unless the values changed, and it still puts the now-ready lab on the dashboard.

Then update:
- the header (line 3), the comments at 55-59 and 123-126, and the header of src/app/api/c