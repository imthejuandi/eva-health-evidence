// Builds round 3 of docs/signoff/work/decisions/f04_inflammation.json from the round-2 file.
const fs = require("fs");
const crypto = require("crypto");
const REPO = "/home/user/eva-health";
const decFile = `${REPO}/docs/signoff/work/decisions/f04_inflammation.json`;
const verFile = `${REPO}/docs/signoff/work/verify/f04_inflammation.json`;
const d = JSON.parse(fs.readFileSync(decFile, "utf8"));
const sha = crypto.createHash("sha256").update(fs.readFileSync(verFile)).digest("hex");

const CRP = "hs_crp|both|All Adults|none";
const FIB = "fibrinogen|both|All Adults|none";
const crp = d.final_rows.find((r) => r.marker_key === "hs_crp");
const fib = d.final_rows.find((r) => r.marker_key === "fibrinogen");
const I = {
  C3: "f04_inflammation--C3--fibrinogen.both.All_Adults.none--none",
  Q1: "f04_inflammation--Q1--hs_crp.both.All_Adults.none--none",
  M2fib: "f04_inflammation--M2--fibrinogen.both.All_Adults.none--high",
  D3min: "f04_inflammation--D3--hs_crp.both.All_Adults.none--high",
  N1preg: "f04_inflammation--N1--hs_crp.female.All_Adults.pregnancy--high",
};
const changes = [];
function set(row, key, path, value, direction, reason, ev, issues) {
  const parts = path.split(".");
  let o = row;
  for (const p of parts.slice(0, -1)) o = o[p];
  const last = parts[parts.length - 1];
  const from = o[last];
  if (from === value) throw new Error(`no change at ${key} ${path}`);
  o[last] = value;
  changes.push({ row_key: key, field: path, from, to: value, direction, reason, evidence_ids: ev, issue_ids: issues });
}
function replaceIn(row, key, path, oldStr, newStr, reason, ev, issues) {
  const parts = path.split(".");
  let o = row;
  for (const p of parts.slice(0, -1)) o = o[p];
  const cur = o[parts[parts.length - 1]];
  if (!cur.includes(oldStr)) throw new Error(`'${oldStr.slice(0, 50)}' not in ${key} ${path}`);
  set(row, key, path, cur.replace(oldStr, newStr), "neutral", reason, ev, issues);
}

// ---------- hs-CRP ----------
set(crp, CRP, "reference_source",
  "f04-E01 (CDC/AHA 2003 scientific statement, Pearson TA et al., 'Markers of inflammation and cardiovascular disease: application to clinical and public health practice', Circulation 2003;107(3):499-511, PMID 12551878, DOI 10.1161/01.cir.0000052939.59093.45; the PubMed record has no abstract and the article is not in PMC, so the quote in f04-E01 was taken from the full-text PDF mirror the research file cites: high relative-risk category >3.0 mg/L, copied exactly), relayed by f04-E02; identical to Echevarne B0851 '<3.01' mg/L (catalogue line 308, dated 01/06/2020).",
  "neutral",
  "Traceability (J1 minor D3): names the CDC/AHA statement by PMID and DOI, read from its PubMed record in this task, beside the mirror URL that f04-E01 carries. The bound does not change.",
  ["f04-E01"], [I.D3min]);

const medEn = crp.pre_analytical.find((p) => p.rule === "medication");
const iMed = crp.pre_analytical.indexOf(medEn);
set(crp, CRP, `pre_analytical.${iMed}.text_en`,
  "Oral oestrogen (hormone therapy) more than doubled CRP in a randomised trial, while transdermal estradiol did not change it; oral contraceptive users more often have values above 3.0 mg/L. Proposed rule, not live: state-rules.md section 4.2 would show the value against the laboratory interval with the fixed state note, with no optimal category and no contribution to the score while oral oestrogen continues; transdermal oestrogen would not change the classification. EVA does not record hormone therapy or contraception today (reference-row.ts reads sex and age only), so until that input is built the value is classified on this row with its optimal band and counted in the score, and the messages name oral oestrogen and the contraceptive pill as causes of a raised value (launch condition F04-DQ-1). The repeat rule above 10 mg/L applies in every case. Excess body weight, smoking and chronic infection or inflammation also raise hs-CRP; weight loss and lipid-lowering medicines (statins, fibrates, niacin) lower it, so a value on treatment describes the treated state.",
  "neutral",
  "Q1 (J2, confirmed): the round-2 text described the oral-oestrogen rule in the present tense as if the app applied it. The app reads no hormone-therapy or contraception input (reference-row.ts, zone-classifier.ts and longevity-score.ts have none), so the text now says the rule is proposed and not live, says what happens today, and points to the launch condition. The evidence for the effect itself is unchanged.",
  ["f04-E15", "f04-E16", "f04-V01"], [I.Q1]);
set(crp, CRP, `pre_analytical.${iMed}.text_es`,
  "Los estrógenos orales (terapia hormonal) duplicaron con creces la PCR en un ensayo aleatorizado, mientras que el estradiol transdérmico no la cambió; las usuarias de anticonceptivos orales tienen con más frecuencia valores por encima de 3,0 mg/L. Regla propuesta, todavía no activa: la sección 4.2 de state-rules.md mostraría el valor frente al intervalo del laboratorio con la nota fija, sin categoría óptima y sin contar para la puntuación mientras dure el estrógeno oral; el estrógeno transdérmico no cambiaría la clasificación. EVA no registra hoy la terapia hormonal ni la anticoncepción (reference-row.ts solo lee el sexo y la edad), así que, hasta que exista ese dato, el valor se clasifica con esta fila y su banda óptima y cuenta para la puntuación, y los mensajes nombran los estrógenos orales y la píldora anticonceptiva como causas de un valor alto (condición de lanzamiento F04-DQ-1). La regla de repetición por encima de 10 mg/L se aplica siempre. El exceso de peso, el tabaco y una infección o inflamación crónicas también suben la PCR ultrasensible; la pérdida de peso y los medicamentos para bajar los lípidos (estatinas, fibratos, niacina) la bajan, así que un valor en tratamiento describe el estado en tratamiento.",
  "neutral",
  "Q1 (J2, confirmed): Spanish text aligned with the English one; the oral-oestrogen rule is described as proposed and not live.",
  ["f04-E15", "f04-E16", "f04-V01"], [I.Q1]);

replaceIn(crp, CRP, "method_note",
  "Declared pregnancy or lactation: no separate rows (removed in round 2); state-rules.md section 2.1 applies one app rule (laboratory interval only, no category, score or biological age, one fixed note). hs-CRP rises normally in pregnancy (third-trimester median 4.12 mg/L, f04-E12; pregnancy-specific upper reference limit 19 mg/L, f04-E13), so the general row's categories must not be shown in pregnancy; breastfeeding itself did not raise CRP in a population survey (f04-E14). Until reference-row.ts reads the declared state, a pregnant or breastfeeding client is classified on this row (F04-DQ-1).",
  "Declared pregnancy or lactation: no separate rows (removed in round 2). The intended handling is the single app rule of state-rules.md section 2.1 (laboratory interval only, no category, no score, no biological age, one fixed note), but it is not live: reference-row.ts picks the row by sex and age only and reads no declared state, so today a pregnant or breastfeeding client is classified on this row, shown the optimal category and scored (check Q1: the third-trimester persona at 4 mg/L reads above range). hs-CRP rises normally in pregnancy (third-trimester median 4.12 mg/L, first 2.39, second 2.44, f04-E12; pregnancy-specific upper reference limit 19 mg/L, f04-E13), so the general row's categories must not be shown in pregnancy; breastfeeding itself did not raise CRP in a population survey (f04-E14). Until the state rule is built, the above-optimal and above-range messages name pregnancy as a cause of a raised value; building it is launch condition F04-DQ-1.",
  "Q1 (J2, confirmed): the method note now states plainly that the pregnancy rule is not live and what a pregnant client sees today, adds the first- and second-trimester medians from the same abstract, and records the interim message change.",
  ["f04-E12", "f04-E13", "f04-E14"], [I.Q1, I.N1preg]);

replaceIn(crp, CRP, "messages.en.above_optimal",
  "excess body weight, smoking, oral oestrogen and the contraceptive pill can all raise it.",
  "excess body weight, smoking, pregnancy, oral oestrogen and the contraceptive pill can all raise it.",
  "Q1 (J2, confirmed): until the app reads declared pregnancy, a pregnant client is classified on this row; healthy pregnancies run first- and second-trimester medians of 2.39 and 2.44 mg/L (f04-E12), above the 0.5 mg/L optimal ceiling, so the message names pregnancy as a cause.",
  ["f04-E12"], [I.Q1]);
replaceIn(crp, CRP, "messages.es.above_optimal",
  "el exceso de peso, el tabaco, los estrógenos orales y la píldora anticonceptiva pueden subirla.",
  "el exceso de peso, el tabaco, el embarazo, los estrógenos orales y la píldora anticonceptiva pueden subirla.",
  "Q1 (J2, confirmed): Spanish text aligned with the English one (pregnancy named as a cause).",
  ["f04-E12"], [I.Q1]);
replaceIn(crp, CRP, "messages.en.above_range",
  "excess body weight, smoking, oral oestrogen and the contraceptive pill also raise it.",
  "excess body weight, smoking, pregnancy, oral oestrogen and the contraceptive pill also raise it.",
  "Q1 (J2, confirmed): the third-trimester median in healthy pregnancies is 4.12 mg/L (f04-E12), above the 3 mg/L limit, so a normal late pregnancy reads above range until the state rule is built; the message now names pregnancy as a cause.",
  ["f04-E12"], [I.Q1, I.N1preg]);
replaceIn(crp, CRP, "messages.es.above_range",
  "el exceso de peso, el tabaco, los estrógenos orales y la píldora anticonceptiva también la suben.",
  "el exceso de peso, el tabaco, el embarazo, los estrógenos orales y la píldora anticonceptiva también la suben.",
  "Q1 (J2, confirmed): Spanish text aligned with the English one (pregnancy named as a cause).",
  ["f04-E12"], [I.Q1, I.N1preg]);

set(crp, CRP, "notes",
  crp.notes + " Explicit age pass (check C3; same row for every adult age, no age split): ages 18-19 use this adult row, because Echevarne B0851 prints '<3.01' mg/L for ages 0-999 with no adult partition and the CDC/AHA categories apply to all adults (f04-E01); the optimal band comes from middle-aged cohorts (Women's Health Study mean age 54.7, f04-E07; UK Biobank median 57, f04-E09), so at 18-19 it is extrapolated, and no opened source gives a different limit for young adults. Ages 70-84: same row and band; the gradient was reported to attained ages 72 (ischaemic stroke) and 80 (all-cause death) in the Copenhagen cohorts (f04-E11); NHANES 2015-2018 healthy adults aged 70-79 are 90.0% (men) and 90.4% (women) non-optimal, so the band carries the 'reached by a minority' label and the physician decides it in F04-DQ-2. Ages 85 and over: same row and band, extrapolated; NHANES healthy-adult data stop at 79, and the one opened cohort of the oldest old (F04-F03: 2,206 adults aged 80 and over, median age 93.0, median follow-up 3.1 years) found a graded association of higher hs-CRP with all-cause death (fully adjusted HR 1.49 for the fourth against the first quartile) but reports no cut-point, so it supports the direction of the band, not the 0.5 mg/L value; F04-DQ-2 asks the physician to keep or drop the band at 70-84 and 85 and over. Version 3 is not computed above 84 (signed age range).",
  "neutral",
  "C3 (J5, confirmed): the row states its policy for ages 18-19, 70-84 and 85 and over explicitly, as PLAN.md section 4 requires, instead of leaving 18-19 and 85 and over unstated; the 85-and-over statement rests on a cohort of the oldest old opened in this task (F04-F03).",
  ["f04-E01", "f04-E07", "f04-E09", "f04-E11", "F04-F03"], [I.C3]);

// ---------- fibrinogen ----------
replaceIn(fib, FIB, "messages.en.above_range",
  "it also runs higher with age, excess body weight and smoking.",
  "it also runs higher with age, in pregnancy, with excess body weight and with smoking.",
  "Q1 (J2, confirmed) and M2 (J5, minor): the app reads no declared pregnancy today, so a pregnant client is classified on this row; fibrinogen in parturient women is often above the non-pregnant 2-4 g/L interval (F04-F01; interval 1.98 to 5.82 g/L in 10,472 parturient women), so the message names pregnancy as a cause.",
  ["F04-F01"], [I.Q1, I.M2fib]);
replaceIn(fib, FIB, "messages.es.above_range",
  "también es más alto con la edad, el exceso de peso y el tabaco.",
  "también es más alto con la edad, durante el embarazo, con el exceso de peso y con el tabaco.",
  "Q1 (J2, confirmed) and M2 (J5, minor): Spanish text aligned with the English one (pregnancy named as a cause).",
  ["F04-F01"], [I.Q1, I.M2fib]);

set(fib, FIB, "notes",
  "Explicit age pass (check C3; one row for every adult age, no age split): ages 18-19 use the adult row, because Echevarne H0028 prints 200-400 mg/dL for ages 0-999 with no adult partition. Ages 70-84 and 85 and over keep the same interval: Echevarne prints no older-adult band; the association of fibrinogen with vascular and non-vascular outcomes was approximately log-linear with no threshold within each age group, 70 and over included (f04-E20); a 2023 review states that fibrinogen is higher in people aged 60 and over (F04-F02) and that 'reference intervals to guide diagnosis and management are based on only two life stages, paediatric, and adult ranges. There are no specific diagnostic guidelines based on reference intervals for an older population.' The row is class e (reference only, no optimal band, not scored), so age changes no category except above 400 mg/dL, where an older adult sees the above-range message, which names age as a cause. No opened source gives the share of healthy adults aged 70-84 or 85 and over above 400 mg/dL, and NHANES 2015-2018 has no fibrinogen; physician question F04-DQ-6. Pregnancy and lactation: no separate state row; the intended handling is state-rules.md section 2.1 (laboratory interval only, fixed note), which is not live because the app reads no declared state (F04-DQ-1). Fibrinogen rises in pregnancy above the non-pregnant interval (F04-F01: interval 1.98 to 5.82 g/L in 10,472 parturient women, against 2-4 g/L outside pregnancy), so the above-range message names pregnancy as a cause. Medication and causes in the messages: age, body weight and smoking from f04-E26; pregnancy from F04-F01; the low-value causes (sample handling, medicines, liver conditions, inherited deficiency) rest on clinical knowledge, not on a source opened in this task (f04-VQ-3).",
  "neutral",
  "C3 (J5, confirmed): the row states its policy for ages 18-19, 70-84 and 85 and over explicitly, with the evidence for keeping one interval and the open question on the share of older adults above 400 mg/dL (F04-DQ-6). The round-2 pregnancy sentence said the fixed state note applies, which the app does not do today (Q1); it now says so.",
  ["f04-E20", "f04-E26", "F04-F01", "F04-F02"], [I.C3, I.Q1]);

// ---------- evidence ----------
const ev = [
  {
    id: "F04-F01",
    supports: [{ row_key: FIB, bound: "state_split" }],
    identifier: { type: "pmid", value: "30934105" },
    citation: "Zhang GM, Zhang W, Zhang GM. Age-Specific Reference Intervals for PT, aPTT, Fibrinogen and Thrombin Time for Parturient Women. Thromb Haemost 2019;119(6):894-898. DOI 10.1055/s-0039-1683932.",
    year: 2019,
    quote: "Parturient women are considered to be in a hyper-coagulable state. For example, the fibrinogen (FIB) levels are often higher than the upper limit of normal reference intervals (RIs) in parturient women than in non-parturient healthy individuals (2-4 g/L).",
    location: "abstract, background",
    design: "cross-sectional reference-interval study, Tukey outlier exclusion, intervals by CLSI C28-A3",
    n: 10472,
    follow_up_years: 0,
    outcome: "reference interval of plasma fibrinogen in parturient women (no clinical outcome); the results give 1.98 to 5.82 g/L",
    population_age: "parturient women, age groups from 16-20 to 41 years",
    population_sex: "female",
    assay: "ACL TOP 700 automatic coagulation analyser, plasma",
    band_rule: "none",
    basis_class: "laboratory_interval",
    proposed_grade: "C",
    age_stratified_statement: "The abstract gives age-specific intervals for PT only; fibrinogen is reported as one interval (1.98 to 5.82 g/L) for all parturient women.",
    notes: "Supports naming pregnancy as a cause in the fibrinogen above-range message and the pregnancy statement in the row notes. Parturient means at delivery, so it describes late pregnancy; the judge's Szecsi 2010 abstract (PMID 20174768, opened in this task) says fibrinogen 'increased markedly' in normal pregnancy but its abstract gives no number.",
  },
  {
    id: "F04-F02",
    supports: [{ row_key: FIB, bound: "age_split" }],
    identifier: { type: "pmid", value: "36600138" },
    citation: "Donkin R, Fung YL, Singh I. Fibrinogen, Coagulation, and Ageing. Subcell Biochem 2023;102:313-342.",
    year: 2023,
    quote: "increased disease burden in older people, hereafter defined as people aged 60 years or more. An older population will have a greater incidence of cardiovascular disease partly due to higher levels of blood fibrinogen, increased levels of some coagulation factors, and increased platelet activity.",
    location: "abstract",
    design: "narrative review (book chapter)",
    n: null,
    follow_up_years: null,
    outcome: "none (review of haemostasis and ageing)",
    population_age: "older people, defined as 60 and over",
    population_sex: "both",
    assay: "not applicable (review)",
    band_rule: "none",
    basis_class: "expert_opinion",
    proposed_grade: "C",
    age_stratified_statement: "Reports that fibrinogen is higher in people aged 60 and over and that reference intervals exist only for paediatric and adult life stages, with none for an older population; gives no age-specific interval.",
    notes: "Supports the fibrinogen age pass (one adult interval at every adult age, no older-adult band to adopt). The same abstract states, without a number: 'reference intervals to guide diagnosis and management are based on only two life stages, paediatric, and adult ranges. There are no specific diagnostic guidelines based on reference intervals for an older population.'",
  },
  {
    id: "F04-F03",
    supports: [{ row_key: CRP, bound: "age_split" }],
    identifier: { type: "pmid", value: "35211447" },
    citation: "Chen PL, Li ZH, Yang HL, et al. Associations Between High-Sensitivity C-Reactive Protein and All-Cause Mortality Among Oldest-Old in Chinese Longevity Areas: A Community-Based Cohort Study. Front Public Health 2022;10:824783. PMCID PMC8861080.",
    year: 2022,
    quote: "Compared with the lowest quartile, the fully adjusted HRs of the second, third, and fourth quartiles were 1.17 (95% CI: 0.94, 1.46), 1.28 (95% CI: 1.01, 1.61), and 1.49 (95% CI: 1.20, 1.87), respectively.",
    location: "abstract, results",
    design: "prospective community-based cohort (Healthy Aging and Biomarkers Cohort Study), Cox regression by hsCRP quartile and by the <1.0, 1.0-3.0 and >3.0 mg/L categories",
    n: 2206,
    follow_up_years: 3.1,
    outcome: "all-cause mortality (1,106 deaths)",
    population_age: "80 and over, median 93.0 years",
    population_sex: "not_reported",
    assay: "hsCRP (assay not given in the abstract)",
    band_rule: "none",
    basis_class: "outcome_nadir",
    proposed_grade: "C",
    age_stratified_statement: "The whole cohort is aged 80 and over (median 93.0); the abstract reports effect modification by smoking (P for interaction 0.011) but no age interaction and no quartile cut-points.",
    notes: "Context for the hs-CRP 85-and-over pass: the direction (lower is better) holds in the oldest old, but the cohort is below 10,000 people and 5 years of follow-up and gives no cut-point, so it cannot set or confirm the 0.5 mg/L ceiling at that age.",
  },
];
d.evidence = ev;

// ---------- physician questions ----------
const pq = (id) => d.physician_questions.find((q) => q.id === id);
const vq1 = pq("f04-VQ-1");
vq1.question = "hs-CRP with declared oral oestrogen (hormone therapy) or oral contraception: confirm the proposed rule of state-rules.md section 4.2 (value shown against the laboratory interval with the fixed note, no optimal category and no contribution to the score while oral oestrogen continues; transdermal oestrogen classified normally; repeat rule above 10 mg/L kept). The rule is not live: EVA records no hormone therapy or contraception today, so these clients are classified on the general row and scored, and the messages name oral oestrogen and the pill as causes. Is building that input a launch condition (F04-DQ-1)?";
vq1.why = "Oral oestrogen raised CRP in a randomised trial (f04-E15) and oral contraceptive users more often exceed 3.0 mg/L (f04-E16); the round-2 row described the rule as if the app applied it, which judge J2 and both refuters showed it does not (ledger Q1).";
const dq1 = pq("F04-DQ-1");
dq1.question = "Declared pregnancy, lactation, oral hormone therapy and oral contraception are not read by the row picker or the score today (reference-row.ts picks by sex and age only), so the state rule of state-rules.md sections 2.1 and 4.2 is not live and check Q1 fails (the third-trimester persona at hs-CRP 4 mg/L reads above range and is scored). Which do you sign: (a) the declared-state read is built and passes the C2 and Q1 fixtures before launch, so these states get the laboratory interval only, with the fixed note and no optimal category or score; or (b) a written launch condition that, until it is built, these clients are classified on the general hs-CRP and fibrinogen rows, whose messages name pregnancy, oral oestrogen and the pill as causes of a raised value? The separate pregnancy and lactation rows stay removed in both options.";
dq1.why = "hs-CRP rises in normal pregnancy (medians 2.39, 2.44 and 4.12 mg/L by trimester, f04-E12; pregnancy upper reference limit 19 mg/L, f04-E13) and fibrinogen in parturient women is often above the 2-4 g/L interval (F04-F01); breastfeeding itself did not raise CRP (f04-E14). PLAN.md section 4 gives declared pregnancy or lactation the laboratory interval only, with no optimal category, no score and no biological age. Ledger Q1 (J2, confirmed): a question does not close the check; only option (a) does.";
dq1.evidence_ids = ["f04-E12", "f04-E13", "f04-E14", "f04-E15", "f04-E16", "F04-F01"];
dq1.options = [
  "(a) Build the declared-state read before launch; Q1 and C2 must pass",
  "(b) Written launch condition: general rows with pregnancy and oral oestrogen named in the messages until the read is built",
];
const dq2 = pq("F04-DQ-2");
dq2.question = "hs-CRP age pass: keep the 0.5 mg/L optimal ceiling, labelled 'reached by a minority', at every adult age? At 18-19 it is extrapolated from middle-aged cohorts; at 70-79 about 90% of healthy NHANES adults are above it (90.0% men, 90.4% women); at 85 and over no outcome study gives a cut-point (the one oldest-old cohort opened, median age 93, shows only that higher quartiles carry more deaths). Options: keep the band at all ages; keep it to 84 and show 85 and over as in range or out of range only; or keep it to 69 and show 70 and over as in range or out of range only.";
dq2.why = "PLAN.md section 4 requires an explicit pass for ages 70-84 and 85 and over and a split only where outcome or reference evidence differs by age; the band rests on the Women's Health Study (f04-E06, f04-E07), with log-linear gradients in mixed-sex cohorts (f04-E08, f04-E09) reported to attained ages 72 and 80 (f04-E11), and an oldest-old cohort (F04-F03) that supports the direction but not the value.";
dq2.evidence_ids = ["f04-E06", "f04-E07", "f04-E08", "f04-E09", "f04-E11", "F04-F03"];
dq2.options = [
  "Keep 0.5 mg/L at every adult age with the minority label",
  "Keep to 84; 85 and over in range or out of range only",
  "Keep to 69; 70 and over in range or out of range only",
];
d.physician_questions.push({
  id: "F04-DQ-6",
  row_key: FIB,
  question: "Fibrinogen in older adults: keep one reference interval, 200-400 mg/dL (Echevarne H0028, ages 0-999), for ages 70-84 and 85 and over, knowing that fibrinogen runs higher with age and that no opened source gives the share of healthy older adults above 400 mg/dL? Or ask Echevarne for its distribution of fibrinogen results by age before the row is signed?",
  why: "C3 (J5, confirmed) asks for an explicit older-age policy. The outcome association has no threshold at 70 and over (f04-E20) and no older-adult reference interval exists (F04-F02), so there is no evidence-based band to adopt; the row is class e (not scored), so the only effect is how many older clients see the above-range message. NHANES 2015-2018 has no fibrinogen.",
  evidence_ids: ["f04-E20", "F04-F02"],
  options: [
    "Keep 200-400 mg/dL at every adult age",
    "Ask Echevarne for its fibrinogen distribution by age first",
  ],
});

// ---------- header ----------
d.round = 3;
d.decided_at = "2026-11-07";
d.verify_sha256 = sha;
d.changes = [...d.changes, ...changes];
const stillOpen = new Set([
  "f04_inflammation--D5--fibrinogen.both.All_Adults.bounds--none",
  "f04_inflammation--D5--hs_crp.both.All_Adults.bounds--none",
  "f04_inflammation--N1--hs_crp.female.60-69.optimal_minority--none",
  "f04_inflammation--N1--hs_crp.female.70-79.non_optimal_70_79--none",
  "f04_inflammation--N1--hs_crp.female.70-79.optimal_minority--none",
  "f04_inflammation--N1--hs_crp.male.70-79.non_optimal_70_79--none",
]);
d.issues_addressed = [...d.issues_addressed.filter((x) => !stillOpen.has(x)), I.C3, I.M2fib].sort();
d.notes = fs.readFileSync(process.argv[2], "utf8").trim();
fs.writeFileSync(decFile, JSON.stringify(d, null, 2) + "\n");
console.log("changes added", changes.length, "sha", sha);
