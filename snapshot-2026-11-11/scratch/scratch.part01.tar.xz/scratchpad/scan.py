import json,re,sys,collections,glob
doc=open('docs/signoff/work/governance/wording-rules.md',encoding='utf-8').read()
m=re.search(r'```json banned_terms\n(.*?)\n```',doc,re.S)
bt=json.loads(m.group(1))
print("JSON OK; es any regex",len(bt['es']['any']['regex']),"en any regex",len(bt['en']['any']['regex']),file=sys.stderr)
def compile_all(lang):
    out={}
    for tier in ('any','non_critical'):
        out[tier]=[(p,re.compile(p,re.I|re.M)) for p in bt[lang][tier]['regex']]
    return out
def strip_allow(text,lang):
    t=text
    for tier in ('any','non_critical'):
        for a in bt[lang][tier]['allow']:
            t=re.sub(re.escape(a),' ',t,flags=re.I)
    return t
# corpora
en=json.load(open('supabase/seed-data/biomarker-ranges-en.json'))
es=json.load(open('supabase/seed-data/rangos-biomarcadores-es.json'))
def seed_items(d,rowkey,namekey,msgpref,notekey):
    items=[]
    for r in d[rowkey]+d.get('calculated_metrics',d.get('metricas_calculadas',[])):
        for k,v in r.items():
            if isinstance(v,str) and (k.startswith(msgpref) or k==notekey):
                items.append((f"seed:{r.get(namekey)}:{k}",v))
    return items
corp={'en':[],'es':[]}
corp['en']+=seed_items(en,'biomarker_ranges','Biomarker','Msg_','Clinical_Notes')
corp['es']+=seed_items(es,'rangos_biomarcadores','Biomarcador','Msg_','Notas_Clínicas')
# code strings: extract quoted strings from the files
def strings_from(path,lang_guess=None):
    src=open(path,encoding='utf-8').read()
    out=[]
    for m in re.finditer(r'(?:"((?:[^"\\]|\\.){6,})"|\'((?:[^\'\\]|\\.){6,})\'|`((?:[^`\\]|\\.){6,})`)',src):
        s=m.group(1) or m.group(2) or m.group(3)
        if re.search(r'[A-Za-zÁÉÍÓÚáéíóúñ]{4,}\s+[A-Za-zÁÉÍÓÚáéíóúñ]{3,}',s) and not re.search(r'(className|rgba\(|^#|px|\$\{|import|/|=>)',s):
            out.append((path,s))
    return out
code_files=['src/lib/biomarkers/zone-config.ts','src/components/dashboard/MedicalDisclaimer.tsx','src/app/[locale]/(dashboard)/biomarker/[key]/detail-client.tsx']+sorted(glob.glob('src/lib/email/templates/*.ts'))
for f in code_files:
    for path,s in strings_from(f):
        lang='es' if re.search(r'[áéíóúñ¿¡]|\b(tu|tus|con|para|del|los|las|una)\b',s,re.I) else 'en'
        corp[lang].append((path,s))
# manual: zone labels (label/label_es) and detail-client italic labels are inside objects; add explicitly
corp['en'].append(('src/lib/biomarkers/zone-config.ts:labels','Below Range / Below Optimal / Optimal / Above Optimal / Above Range / Unclassified'))
corp['es'].append(('src/lib/biomarkers/zone-config.ts:labels','Por Debajo del Rango / Por Debajo del Optimo / Optimo / Por Encima del Optimo / Por Encima del Rango / Sin Clasificar'))
corp['en'].append(('detail-client.tsx:94,101','trending low / trending high'))
corp['es'].append(('detail-client.tsx:94,101','tendiendo bajo / tendiendo alto'))
# trend regexes are in section 6 not in banned_terms any; add an extra scan for trend words
trend={'en':re.compile(r'\b(trending|improving|worsening|trend|velocity)\b',re.I),'es':re.compile(r'\b(tendiendo|mejorando|empeorando|tendencia|velocidad)\b',re.I)}
rows=[]
examples=[]
for lang in ('es','en'):
    rx=compile_all(lang)
    for tier in ('any','non_critical'):
        for p,c in rx[tier]:
            hits=[]
            for src,text in corp[lang]:
                t=strip_allow(text,lang)
                if c.search(t): hits.append((src,text,c.search(t)))
            if hits:
                bysrc=collections.Counter(('seed' if s.startswith('seed:') else s.split(':')[0]) for s,_,_ in hits)
                markers=len(set(s.split(':')[1] for s,_,_ in hits if s.startswith('seed:')))
                rows.append((lang,tier,p,len(hits),markers,dict(bysrc)))
                ex=hits[0]; mm=ex[2]; s=max(0,mm.start()-40)
                examples.append((lang,tier,p,ex[0],ex[1][s:mm.end()+40].replace('\n',' ')))
    # trend
    hits=[(src,text) for src,text in corp[lang] if trend[lang].search(text)]
    rows.append((lang,'trend (section 6)',trend[lang].pattern,len(hits),len(set(s.split(':')[1] for s,_ in hits if s.startswith('seed:'))),dict(collections.Counter(('seed' if s.startswith('seed:') else s.split(':')[0]) for s,_ in hits))))
# closers coverage
def closer_cov(lang,d,rowkey,pref,req):
    tot=0;ok=0
    for r in d[rowkey]:
        for k,v in r.items():
            if isinstance(v,str) and k.startswith(pref): 
                tot+=1; ok+= (req in v)
    return ok,tot
cl_es=closer_cov('es',es,'rangos_biomarcadores','Msg_Crítico',bt['es']['required']['out_of_range_closer'])
cl_en=closer_cov('en',en,'biomarker_ranges','Msg_Critical',bt['en']['required']['out_of_range_closer'])
# output markdown
out=[]
out.append(f"Método: el bloque `banned_terms` de este archivo se aplicó con un script (`python3 -I`, expresiones regulares sin distinción de mayúsculas, lista `allow` eliminada antes de comparar) a: {len(corp['es'])} textos en español y {len(corp['en'])} en inglés, que son todos los campos `Msg_*` y las notas clínicas de los dos archivos semilla (180 filas cada uno, 726 mensajes y 180 notas por idioma), las etiquetas de `zone-config.ts`, las cadenas de `MedicalDisclaimer.tsx`, las etiquetas de tendencia de `detail-client.tsx` y las cadenas de las 8 plantillas de correo. Un \"hit\" es un texto (mensaje, nota o cadena) con al menos una coincidencia. / Method: the `banned_terms` block of this file was run by script over the same corpus; a hit is one text with at least one match.")
out.append("")
out.append("| Idioma / Language | Nivel / Tier | Regla (regex) | Textos con coincidencia / Hits | Marcadores (semilla) / Markers | Por fuente / By source |")
out.append("|---|---|---|---|---|---|")
for lang,tier,p,n,mk,bysrc in sorted(rows,key=lambda r:(r[0],-r[3])):
    pe=p.replace('|','\\|'); bs=', '.join(f'{k} {v}' for k,v in bysrc.items())
    out.append(f"| {lang} | {tier} | `{pe}` | {n} | {mk} | {bs} |")
out.append("")
out.append(f"Frase de red de seguridad estándar presente hoy: español {cl_es[0]} de {cl_es[1]} mensajes fuera de rango; inglés {cl_en[0]} de {cl_en[1]}. (Hoy 212 de 290 mensajes fuera de rango en cada idioma cierran con \"Coméntalo con tu médico\" / \"Discuss it with your doctor\", que no es la frase estándar.) / Standard safety-net sentence present today: Spanish {cl_es[0]} of {cl_es[1]} out-of-range messages; English {cl_en[0]} of {cl_en[1]}.")
out.append("")
out.append("Ejemplos (un texto por regla) / Examples (one text per rule):")
out.append("")
for lang,tier,p,src,snip in examples:
    pe=p[:50].replace('|','\\|')
    out.append(f"- `{lang}` `{tier}` `{pe}` … {src}: \"…{snip}…\"")
print("\n".join(out))
