const fs = require("fs");
const { matchQuote, statusForMatch, wordCount } = require("/home/user/eva-health/docs/signoff/tools/lib/text-normalise.js");
const SRC = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/f11src/";
const doc = JSON.parse(fs.readFileSync("/home/user/eva-health/docs/signoff/work/research/f11_platelets.json", "utf8"));
const fileFor = (idf) => {
  if (idf.type === "pmid") return SRC + `pmid-${idf.value}.txt`;
  if (idf.type === "pmcid") return { PMC11899349: SRC + "cache-PMC11899349.txt", PMC6178782: SRC + "cache-PMC6178782.txt", PMC6294153: SRC + "eutils-pmc6294153.txt" }[idf.value];
  if (idf.type === "url") return { "https://pmc.ncbi.nlm.nih.gov/articles/PMC4592279/": SRC + "url-pmc4592279.txt", "https://pmc.ncbi.nlm.nih.gov/articles/PMC9479031/": SRC + "url-pmc9479031.txt" }[idf.value];
};
console.log("== quotes");
for (const e of doc.evidence) {
  const f = fileFor(e.identifier);
  const m = matchQuote(e.quote, fs.readFileSync(f, "utf8"));
  console.log(e.id, statusForMatch(m), m.score, m.exact ? "exact" : "", "words", wordCount(e.quote), /\d/.test(e.quote) ? "" : "NO-DIGIT");
}
// also confirm the two cached PMC quotes in the NCBI eutils full texts
for (const e of doc.evidence.filter((x) => x.identifier.type === "pmcid" && x.identifier.value !== "PMC6294153")) {
  const alt = SRC + (e.identifier.value === "PMC11899349" ? "eutils-pmc11899349.txt" : "eutils-pmc6178782.txt");
  const m = matchQuote(e.quote, fs.readFileSync(alt, "utf8"));
  console.log("  eutils cross-check", e.id, statusForMatch(m), m.score);
}
// ---- M3 lexicon
const md = fs.readFileSync("/home/user/eva-health/docs/signoff/work/governance/wording-rules.md", "utf8");
const lex = JSON.parse(md.match(/```json[^\n]*\n([\s\S]*?)\n```/)[1]);
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function hits(text, lang, tiers) {
  let t = text; const out = new Set();
  const rules = tiers.map((x) => lex[lang][x]);
  for (const a of rules.flatMap((r) => r.allow || [])) t = t.replace(new RegExp(esc(a), "giu"), " ");
  for (const term of rules.flatMap((r) => r.terms || [])) if (new RegExp(`(?<![\\p{L}])${esc(term)}(?![\\p{L}])`, "iu").test(t)) out.add(term);
  for (const p of rules.flatMap((r) => r.regex || [])) { const mm = t.match(new RegExp(p, "i")); if (mm) out.add(mm[0]); }
  return [...out];
}
// ---- M4 numbers
function extractNumbers(text, lang) {
  const out = []; const re = lang === "es" ? /(?<![\p{L}\d,.-])(\d+(?:\.\d{3})*(?:,\d+)?)(?![\p{L}\d])/gu : /(?<![\p{L}\d,.-])(\d+(?:,\d{3})*(?:\.\d+)?)(?![\p{L}\d])/gu;
  for (const m of text.matchAll(re)) { const raw = m[1]; if (/^(19|20)\d\d$/.test(raw)) continue; const n = Number(lang === "es" ? raw.replace(/\./g, "").replace(",", ".") : raw.replace(/,/g, "")); if (Number.isFinite(n)) out.push(n); }
  return out;
}
// ---- M2 elements (copied regexes)
const EL = {
  en: [/\b(may|can|could|might|reflect|suggest|indicat|mean|linked|associated|sign of|is consistent)/i, /\b(infection|dehydrat|exercise|workout|training|fasting|non-fasting|supplement|medication|pregnan|sample|haemolys|hemolys|spurious|benign|harmless|temporar|transient|recent meal|alcohol|stress|time of day|morning|creatine|common|many (healthy )?(adults|people))/i, /\b(repeat|confirm|re-?test|recheck|second (test|sample|result)|another (test|sample|result)|persist|stays|remains|on two|follow-up test|next test)/i, /\b(doctor|physician|GP|clinician|specialist|medical attention|medical contact|same day|within (a )?(day|days|week|weeks|month|months)|soon|promptly|without delay|today|at your next)/i],
  es: [/\b(puede|podría|refleja|sugiere|indica|significa|asociad|relacionad|vinculad|señal de|es compatible)/i, /\b(infecci|deshidrat|ejercicio|entrenamiento|ayuno|sin ayuno|suplemento|medicamento|medicación|embaraz|muestra|hemóli|hemoli|espuri|benign|inofensiv|temporal|transitori|comida reciente|alcohol|estrés|hora del día|mañana|creatina|frecuente|muchas personas|muchos adultos)/i, /\b(repet|repít|confirm|segunda (prueba|muestra|analítica)|otra (prueba|muestra|analítica)|persist|se mantiene|sigue|en dos|próxima (prueba|analítica)|nuevo análisis)/i, /\b(médico|medica|profesional sanitario|especialista|atención médica|contacto médico|el mismo día|en (un |una )?(día|días|semana|semanas|mes|meses)|pronto|sin demora|hoy|en tu próxima)/i],
};
const closer = { en: lex.en.required.out_of_range_closer, es: lex.es.required.out_of_range_closer };
const crit = { en: lex.en.required.critical_closer, es: lex.es.required.critical_closer };
console.log("== messages");
for (const r of doc.rows) {
  const key = `${r.marker_key}|${r.sex}|${r.physiological_state}`;
  const bounds = [r.reference_low, r.reference_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high, ...r.explanatory_numbers].filter((b) => b != null);
  for (const lang of ["en", "es"]) {
    for (const [z, text] of Object.entries(r.messages[lang])) {
      const tiers = (z === "critical_low" || z === "critical_high") ? ["any"] : ["any", "non_critical"];
      const h = hits(text, lang, tiers);
      const bad = extractNumbers(text, lang).filter((n) => !bounds.some((b) => Math.abs(b - n) < 1e-9));
      const miss = (z === "below_range" || z === "above_range") ? EL[lang].map((re, i) => re.test(text) ? null : ["meaning", "benign", "repeat", "who"][i]).filter(Boolean) : [];
      const cl = (z === "below_range" || z === "above_range") ? text.endsWith(closer[lang]) : (z.startsWith("critical") ? text.endsWith(crit[lang]) : true);
      if (h.length || bad.length || miss.length || !cl) console.log(key, lang, z, "M3:", h, "M4:", bad, "M2:", miss, "closer:", cl);
    }
    const note = lang === "en" ? r.clinical_notes_en : r.clinical_notes_es;
    const hn = hits(note, lang, ["any", "non_critical"]); if (hn.length) console.log(key, lang, "note M3:", hn);
    for (const a of r.action_limits) { const t = lang === "en" ? a.follow_up_en : a.follow_up_es; const ha = hits(t, lang, ["any", "non_critical"]); if (ha.length) console.log(key, lang, "action M3:", ha); }
    for (const p of r.pre_analytical) { const t = lang === "en" ? p.text_en : p.text_es; const hp = hits(t, lang, ["any", "non_critical"]); if (hp.length) console.log(key, lang, "pre M3 (not client text):", hp); }
  }
}
console.log("done");
