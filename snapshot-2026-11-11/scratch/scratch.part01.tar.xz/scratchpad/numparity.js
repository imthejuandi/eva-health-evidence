const fams=["f01_albumin_proteins","f03_kidney","f04_inflammation"];
function nums(s,lang){ if(!s) return []; let t=s;
  if(lang==="es"){ t=t.replace(/(\d)\.(\d{3})(?!\d)/g,"$1$2"); t=t.replace(/(\d),(\d)/g,"$1.$2"); }
  else { t=t.replace(/(\d),(\d{3})(?!\d)/g,"$1$2"); }
  const m=t.match(/\d+(?:\.\d+)?/g)||[]; return m.map(Number).sort((a,b)=>a-b); }
function diff(a,b){ const A=[...a],B=[...b]; const onlyA=[],onlyB=[]; for(const x of A){const i=B.indexOf(x); if(i>=0)B.splice(i,1); else onlyA.push(x);} return {onlyEN:onlyA,onlyES:B}; }
for(const f of fams){ const d=require("/home/user/eva-health/docs/signoff/work/decisions/"+f+".json");
 for(const r of d.final_rows){ const key=[r.marker_key,r.sex,r.age_group,r.physiological_state].join("|");
  const pairs=[];
  for(const z of Object.keys(r.messages.en)) pairs.push(["msg."+z, r.messages.en[z], r.messages.es[z]]);
  pairs.push(["clinical_notes", r.clinical_notes_en, r.clinical_notes_es]);
  pairs.push(["method_note", r.method_note, r.method_note_es]);
  pairs.push(["reference_source", r.reference_source, r.reference_source_es]);
  pairs.push(["critical_none_reason", r.critical_none_reason, r.critical_none_reason_es]);
  (r.pre_analytical||[]).forEach((p,i)=>pairs.push(["pre["+i+"]."+p.rule, p.text_en, p.text_es]));
  (r.action_limits||[]).forEach((a,i)=>pairs.push(["action["+i+"]", a.follow_up_en, a.follow_up_es]));
  let n=0; for(const [k,en,es] of pairs){ n++; if(en==null&&es==null) continue; if(en==null||es==null){ console.log(key,k,"MISSING one side", en==null?"EN":"ES"); continue;}
   const dd=diff(nums(en,"en"),nums(es,"es")); if(dd.onlyEN.length||dd.onlyES.length) console.log(key, k, JSON.stringify(dd)); }
 console.log("checked",key,pairs.length); } }
