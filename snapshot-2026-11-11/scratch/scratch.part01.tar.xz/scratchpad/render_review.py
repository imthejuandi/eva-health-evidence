#!/usr/bin/env python3
"""Render Fable 5.2's approval synthesis verbatim into the governance record.

Usage: python3 render_review.py <synthesis.json> <repo> <run_id> <date>
Writes <repo>/docs/signoff/work/governance/fable-approval-review.json (the result as returned, plus where it came from)
and fable-approval-review.md (the same content as tables). No text is reworded: every rationale, rule and finding is
copied from the synthesis.
"""
import json
import sys
from pathlib import Path

syn_path, repo, run_id, date = sys.argv[1], Path(sys.argv[2]), sys.argv[3], sys.argv[4]
syn = json.loads(Path(syn_path).read_text())
gov = repo / "docs/signoff/work/governance"
pending = json.loads((gov / "pending-approvals.json").read_text())

record = {
    "_doc": "Fable 5.2's recommendation on the 22 frozen-file changes of pending-approvals.json and on decisions CEO-1 to CEO-8, "
    "which the CEO adopted as the approval decision (instruction of 9 November 2026: Fable 5.2 recommends on the decisions "
    "and its recommendations serve as the approval). AI work product: a licensed physician reviews and signs; nothing here is "
    "a medical sign-off. The text below is the synthesis as returned, unedited.",
    "recommended_by": "Fable 5.2 (claude-fable-5-2, effort max)",
    "adopted_by": "CEO",
    "date": date,
    "workflow_run": run_id,
    "inputs": {
        "pending_approvals": "docs/signoff/work/governance/pending-approvals.json",
        "prepared_at_commit": pending.get("prepared_at_commit"),
        "reviews": ["docs/signoff/work/central/fable-approval-runner.json", "docs/signoff/work/central/fable-approval-tools.json"],
        "decisions": "docs/signoff/work/governance/central-fix-decisions.md",
    },
    "result": syn,
}
(gov / "fable-approval-review.json").write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n")


def cell(t):
    return str(t if t is not None else "").replace("|", "\\|").replace("\n", " ").strip()


lines = [
    "# Fable 5.2 approval review",
    "",
    "AI work product of the sign-off programme. A licensed physician reviews and signs; nothing here is a medical sign-off.",
    "",
    f"On 9 November 2026 the CEO instructed that Fable 5.2 recommends on the 22 frozen-file changes and on decisions CEO-1 to "
    f"CEO-8, and that its recommendations serve as the approval. Reviewers and adversarial challengers per area "
    f"(`docs/signoff/work/central/fable-approval-runner.json`, `fable-approval-tools.json`) and a synthesizer (workflow run "
    f"{run_id}), all Fable 5.2 at maximum effort, produced the recommendation below. The text is theirs, unedited; the full "
    f"record is `fable-approval-review.json`.",
    "",
    "## Summary",
    "",
    syn.get("summary", ""),
    "",
    "## Files",
    "",
    "| File | Verdict | Action | Why | Required change |",
    "|---|---|---|---|---|",
]
for f in syn["files"]:
    lines.append(f"| `{cell(f['file'])}` | {cell(f['verdict'])} | {cell(f['action'])} | {cell(f['plain_rationale'])} | {cell(f['required_change']) or 'none'} |")
lines += ["", "Findings that stand, per file:", ""]
for f in syn["files"]:
    for x in f.get("standing_findings", []):
        lines.append(f"- `{f['file']}`: {cell(x['summary'])} Evidence: {cell(x['evidence'])} Fix: {cell(x['smallest_fix'])}")
fu = [(f["file"], u) for f in syn["files"] for u in f.get("followups", [])]
if fu:
    lines += ["", "Follow-ups (not conditions of approval):", ""]
    lines += [f"- `{file}`: {cell(u)}" for file, u in fu]
lines += ["", "## Decisions", "", "| Id | Recommendation | Rule | Why | Code change |", "|---|---|---|---|---|"]
for d in syn["decisions"]:
    lines.append(f"| {cell(d['id'])} | {cell(d['recommendation'])} | {cell(d['rule'])} | {cell(d['plain_rationale'])} | {cell(d['code_change']) if d.get('code_change_needed') else 'none'} |")
corr = [d for d in syn["decisions"] if cell(d.get("table_correction"))]
if corr:
    lines += ["", "Corrections to the decision table:", ""]
    lines += [f"- {d['id']}: {cell(d['table_correction'])}" for d in corr]
if syn.get("new_decisions"):
    lines += ["", "New decisions:", "", "| Id | Question | Recommendation | Rule | Why | Code change |", "|---|---|---|---|---|---|"]
    for d in syn["new_decisions"]:
        lines.append(f"| {cell(d['id'])} | {cell(d['question'])} | {cell(d['recommendation'])} | {cell(d['rule'])} | {cell(d['plain_rationale'])} | {cell(d['code_change']) if d.get('code_change_needed') else 'none'} |")
if syn.get("known_issue_updates"):
    lines += ["", "Known-issue updates:", ""]
    lines += [f"- {cell(k['id'])}: {cell(k['update'])}" for k in syn["known_issue_updates"]]
(gov / "fable-approval-review.md").write_text("\n".join(lines) + "\n")
print(json.dumps({"files": len(syn["files"]), "decisions": len(syn["decisions"]), "new_decisions": len(syn.get("new_decisions", []))}))
