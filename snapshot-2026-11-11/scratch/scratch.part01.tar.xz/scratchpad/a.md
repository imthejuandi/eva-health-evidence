# Scorecard: batch B01

AI work product of the sign-off loop (docs/signoff/LOOP-PROMPT.md). A licensed physician reviews and signs; nothing here is a sign-off. Verdicts are AI pre-review.

Run: batch B01, started 2026-11-06T10:00:00Z, round limit 3, agents 5 of a cap of 120, retries 1, nulls 1.

## Families

| Family | Stop | Rounds | Failing checks (latest) | Failures | Confirmed blocking | Disputed | Physician questions | Closed or refuted | Searches (author/verifier) |
|---|---|---|---|---|---|---|---|---|---|
| f01_albumin_proteins | incomplete (round limit) | 1 | D3 1, M2 16, M3 3, N1 1, P3 4, X1 4 | 29 | 29 | 0 | 0 | 0 | 12/9 |
| f03_kidney | not recorded | - | no checks file | - | 0 | 0 | 0 | 0 | not recorded |
| f04_inflammation | not recorded | - | no checks file | - | 0 | 0 | 0 | 0 | not recorded |

## Failing checks by family

### f01_albumin_proteins: Albumin and serum proteins

Trend of attributable failures by round: r1 29.

Round 1 (../../../tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/w/checks/f01_albumin_proteins-r1.json):

- D3: 1 failures, e.g. `albumin\|both\|All Adults\|bounds`
- M2: 16 failures, e.g. `albumin_globulin_ratio\|both\|All Adults\|critical_high\|en`, `albumin_globulin_ratio\|both\|All Adults\|critical_high\|es`, `albumin_globulin_ratio\|both\|All Adults\|critical_low\|en`, `albumin_globulin_ratio\|both\|All Adults\|critical_low\|es`, `albumin\|both\|All Adults\|critical_high\|en`, and 11 more
- M3: 3 failures, e.g. `row\|albumin\|both\|All Adults\|critical_high\|en`, `row\|albumin\|both\|All Adults\|critical_low\|en`, `row\|albumin\|both\|All Adults\|critical_low\|es`
- N1: 1 failures, e.g. `albumin\|male\|70-79\|reference_outside`
- P3: 4 failures, e.g. `bounded\|albumin_globulin_ratio\|both\|All Adults`, `bounded\|albumin\|both\|All Adults`, `bounded\|globulin\|both\|All Adults`, `bounded\|total_protein\|both\|All Adults`
- X1: 4 failures, e.g. `albumin\|female\|base\|high\|lower_than_bound`, `albumin\|female\|plus_hba1c\|high\|lower_than_bound`, `albumin\|male\|base\|high\|lower_than_bound`, `albumin\|male\|plus_hba1c\|high\|lower_than_bound`

Blocked checks (not passes): B4, B5, B6, C2, C3, E1, E2, E3, E4, E5, G1, G2, G4, G5, G6, G7, G8, L2, M5, P2, S4, S6, X2.

### f03_kidney: Kidney filtration: creatinine, eGFR, cystatin C, BUN, urea

No checks file yet.

### f04_inflammation: Inflammation: hs-CRP and fibrinogen

No checks file yet.

## Issues

| Family | Open | Confirmed | Disputed | Unreviewed | Physician question | Refuted | Fixed | Closed |
|---|---|---|---|---|---|---|---|---|
| f01_albumin_proteins | 29 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| f03_kidney | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| f04_inflammation | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

## Physician questions and disputed items

None recorded.

## Agents

| Role | Agents | Retries | Nulls | Model asked -> reported |
|---|---|---|---|---|
| author | 2 | 1 | 1 | fable -> not reported; fable -> x |

The reported model is the agent's own statement in its structured result; the workflow has no meta file to read it from.

## Left undone

- f03_kidney: judges round 2
