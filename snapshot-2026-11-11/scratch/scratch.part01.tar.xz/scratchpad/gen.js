const fs=require("fs"),crypto=require("crypto"),path=require("path");
const F="/home/user/eva-health/docs/signoff/tools/test/fixtures/work";
const sha=(f)=>crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex");
const w=(f,o)=>fs.writeFileSync(f,JSON.stringify(o,null,2)+"\n");
const R=JSON.parse(fs.readFileSync(`${F}/research/f04_inflammation.json`,"utf8"));
const key=r=>`${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
const grades={"hs_crp|both|All Adults|none":"B","hs_crp|female|All Adults|pregnancy":"D","fibrinogen|both|All Adults|none":"D"};
const final_rows=R.rows.map(r=>({...r,grade:grades[key(r)]}));
const verify={schema_version:"1",family:"f04_inflammation",verified_at:"2026-11-05",research_sha256:sha(`${F}/research/f04_inflammation.json`),verifier_role:"test fixture",
 row_verdicts:R.rows.map(r=>({row_key:key(r),verdict:"confirmed",grade:grades[key(r)],note:"Fixture: bounds and class confirmed."})),
 evidence_verdicts:[{evidence_id:"E1",verdict:"confirmed",grade:"B",quote_found:true,note:"Quote found in the abstract."},{evidence_id:"E2",verdict:"confirmed",grade:"C",quote_found:true,note:"Quote found on the guideline page."}],
 final_rows,corrections:[],evidence:[],physician_questions:[],searches_used:1,fetches_used:2,notes:"Test fixture."};
w(`${F}/verify/f04_inflammation.json`,verify);
const dec_rows=final_rows.map(r=>key(r)==="hs_crp|both|All Adults|none"?{...r,optimal_high:0.8,messages:{en:{...r.messages.en,optimal:"Your hs-CRP is in the optimal band, below 0.8 mg/L."},es:{...r.messages.es,optimal:"Tu PCR-us está en la banda óptima, por debajo de 0,8 mg/L."}}}:r);
const decision={schema_version:"1",family:"f04_inflammation",round:1,decided_at:"2026-11-05",verify_sha256:sha(`${F}/verify/f04_inflammation.json`),fixer_role:"test fixture",final_rows:dec_rows,
 changes:[{row_key:"hs_crp|both|All Adults|none",field:"optimal_high",from:1,to:0.8,direction:"tighten",reason:"Fixture: the judge disputed the rounding of the nadir.",evidence_ids:["E1"],issue_ids:["iss_0001"]}],
 issues_addressed:["iss_0001"],evidence:[],physician_questions:[],notes:"Test fixture."};
w(`${F}/decisions/f04_inflammation.json`,decision);
const judge={schema_version:"1",round:1,lens:"J2",shard:"B01",families_reviewed:["f01_albumin_proteins","f03_kidney","f04_inflammation"],sample_file:null,
 blocking:[{id:"iss_0001",family:"f04_inflammation",row_key:"hs_crp|both|All Adults|none",side:"high",check_id:"E3",value_disputed:"optimal_high 1 mg/L",evidence:{kind:"file_line",file:"docs/signoff/work/research/f04_inflammation.json",line:25},resolution:"Use the nadir reported in the source, 0.8 mg/L, or justify the rounding."}],
 minor:[{family:"f04_inflammation",row_key:null,side:null,check_id:"definition:critical limit",value_disputed:"critical_none_reason wording",evidence:{kind:"source_quote",identifier:{type:"url",value:"https://example.org/fixture-guideline"},quote:"A level above 10 mg/L should be discarded"},resolution:"Cite the repeat rule in critical_none_reason."}],
 model:"fixture",notes:null};
w(`${F}/judges/round-1/J2-B01.json`,judge);
w(`${F}/refutations/round-1/iss_0001-a.json`,{schema_version:"1",issue_id:"iss_0001",round:1,refuter:"a",family:"f04_inflammation",verdict:"confirmed",reason:"Reproduced: the research quote gives 1.0 mg/L as the lowest category, not a nadir.",evidence:[{kind:"file_line",file:"docs/signoff/work/research/f04_inflammation.json",line:25}],model:"fixture",notes:null});
w(`${F}/refutations/round-1/iss_0001-b.json`,{schema_version:"1",issue_id:"iss_0001",round:1,refuter:"b",family:"f04_inflammation",verdict:"confirmed",reason:"PLAN.md section 5 requires the nadir or lowest-risk category as reported, not a rounded value.",evidence:[{kind:"definition",text:"the band rule: nadir with confidence interval, risk within 10% of the minimum, or the lowest-risk category"}],model:"fixture",notes:null});
w(`${F}/ledger/f04_inflammation.json`,{schema_version:"1",family:"f04_inflammation",issues:[{id:"iss_0001",source:{judge_file:"docs/signoff/work/judges/round-1/J2-B01.json",lens:"J2",round:1},family:"f04_inflammation",check_id:"E3",row_key:"hs_crp|both|All Adults|none",side:"high",severity:"blocking",status:"confirmed",rounds:{opened:1,closed:null},evidence_paths:["docs/signoff/work/research/f04_inflammation.json:25"],refutation_paths:["docs/signoff/work/refutations/round-1/iss_0001-a.json","docs/signoff/work/refutations/round-1/iss_0001-b.json"],summary:"optimal_high rounded away from the reported nadir",resolution:null,closed_by:null,question_id:null}]});
