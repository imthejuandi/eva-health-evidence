// Apply the DSRT's own message checks (M2 heuristics, M3 lexicon, M4 numbers) to the rows of a research or verify file,
// plus the wording-rules closer and urgency phrases. Usage: tsx msgcheck.ts <file.json> <rows|final_rows>
import fs from "node:fs";
import { missingElements, parseLexicon, lexiconHits } from "/home/user/eva-health/scripts/signoff/checks/messages";
import { extractNumbers } from "/home/user/eva-health/scripts/signoff/lib/format";

const [file, key] = process.argv.slice(2);
const doc = JSON.parse(fs.readFileSync(file, "utf8"));
const rows = doc[key];
const lex = parseLexicon(fs.readFileSync("/home/user/eva-health/docs/signoff/work/governance/wording-rules.md", "utf8"))!;
const tiers = (lang: "en" | "es") => ["any", "non_critical"].map((t) => lex.langs[lang]?.[t]).filter(Boolean) as any[];
const CLOSER = {
  en: "This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.",
  es: "Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.",
};
const URG = {
  en: { routine: /discuss it with your doctor at your next check-up/i, soon: /book an appointment with your doctor in the next few weeks/i },
  es: { routine: /coméntalo con tu médico en tu próxima revisión/i, soon: /pide cita con tu médico en las próximas semanas/i },
};
let problems = 0;
const out = (s: string) => { problems++; console.log("  PROBLEM " + s); };
for (const r of rows) {
  const k = `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
  console.log(`== ${k} ref ${r.reference_low}-${r.reference_high} opt ${r.optimal_low}-${r.optimal_high} class ${r.marker_class} expl [${r.explanatory_numbers}]`);
  const bounds = [r.reference_low, r.reference_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high, ...r.explanatory_numbers].filter((b: any) => b != null);
  const texts: [string, "en" | "es", string][] = [];
  for (const lang of ["en", "es"] as const) {
    for (const [z, t] of Object.entries(r.messages[lang] || {})) texts.push([`msg.${z}`, lang, t as string]);
    const cn = r[`clinical_notes_${lang}`];
    if (cn) texts.push(["clinical_note", lang, cn]);
    (r.action_limits || []).forEach((a: any, i: number) => texts.push([`action[${i}]`, lang, a[`follow_up_${lang}`]]));
    (r.pre_analytical || []).forEach((p: any, i: number) => texts.push([`pre[${i}].${p.rule}`, lang, p[`text_${lang}`]]));
  }
  for (const [where, lang, t] of texts) {
    const hits = lexiconHits(t, tiers(lang), lex.flags);
    if (hits.length) out(`M3 ${where} ${lang}: ${hits.join(", ")}`);
    const allowed = new Set<number>(bounds);
    if (where.startsWith("action")) for (const a of r.action_limits) allowed.add(a.value);
    const nums = extractNumbers(t, lang).filter((n) => ![...allowed].some((b) => Math.abs(b - n) < 1e-9));
    if (nums.length) {
      if (where.startsWith("msg") || where === "clinical_note") out(`M4 ${where} ${lang}: numbers ${[...new Set(nums)].join(", ")}`);
      else console.log(`  info numbers in ${where} ${lang}: ${[...new Set(nums)].join(", ")}`);
    }
    if (where === "msg.below_range" || where === "msg.above_range") {
      const miss = missingElements(t, lang);
      if (miss.length) out(`M2 ${where} ${lang}: lacks ${miss.join(", ")}`);
      if (!t.trim().endsWith(CLOSER[lang])) out(`closer missing or not last in ${where} ${lang}`);
      const u = URG[lang];
      const has = [u.routine.test(t) ? "routine" : "", u.soon.test(t) ? "soon" : ""].filter(Boolean);
      console.log(`  urgency ${where} ${lang}: ${has.join("+") || "NONE"}`);
      if (!has.length) out(`no urgency phrase in ${where} ${lang}`);
    }
  }
}
console.log(`TOTAL PROBLEMS ${problems}`);
