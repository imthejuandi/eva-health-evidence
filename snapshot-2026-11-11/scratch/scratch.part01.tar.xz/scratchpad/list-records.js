// List evidence records of a file: id, identifier, first supports, grade, quote (truncated).
// Usage: node list-records.js <file> [width]
"use strict";
const fs = require("fs");
const [file, w] = process.argv.slice(2);
const width = Number(w || 160);
const d = JSON.parse(fs.readFileSync(file, "utf8"));
for (const ev of d.evidence || []) {
  const sup = (ev.supports || []).map((s) => `${s.row_key.split("|")[0]}:${s.bound}`).join(",");
  console.log(`${ev.id} | ${ev.identifier?.type}:${String(ev.identifier?.value).slice(0, 40)} | ${sup.slice(0, 80)} | ${ev.proposed_grade} | ${String(ev.quote).slice(0, width)}`);
}
