// Evidence repair for the B01 families: edits only `quote`, `identifier` and `notes` of named evidence records.
// Run from the worktree root: node apply-repair.js [--dry-run]
// Every new quote is cut by script from the opened source text (the repository source cache, or a fresh PubMed efetch
// saved in the scratchpad) and checked as a normalised substring of it before anything is written.
"use strict";
const fs = require("fs");
const path = require("path");
const { normaliseText, wordCount } = require(path.resolve("docs/signoff/tools/lib/text-normalise"));
const { canonicalIdentifier, cachePaths } = require(path.resolve("docs/signoff/tools/lib/sources"));

const DRY = process.argv.includes("--dry-run");
const SCRATCH = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad";
const DATE = "8 November 2026";
const MIRROR = "https://eclass.uoa.gr/modules/document/file.php/DIAT101/%CE%9A%CE%A1%CE%9F%CE%A5%CE%A0%CE%97%CE%A3%20%CE%94%CE%99%CE%91%CE%9B%CE%95%CE%9E%CE%95%CE%99%CE%A3/CARDIAC%20Markers/CARDIAC%20Markers%20papers/CRP/Pearson%20CRP%20guidelines.pdf";

const squash = (s) => s.replace(/\s+/g, " ").trim();
function cachedText(type, value) {
  const p = cachePaths(canonicalIdentifier({ type, value }).key);
  if (!fs.existsSync(p.txt)) throw new Error(`not in cache: ${type}:${value}`);
  return fs.readFileSync(p.txt, "utf8");
}
/** Cut the span from `start` to the end of `end` out of `text` (whitespace collapsed), exactly once. */
function cut(text, start, end) {
  const t = squash(text);
  const i = t.indexOf(start);
  if (i < 0 || t.indexOf(start, i + 1) >= 0) throw new Error(`start not found exactly once: ${start}`);
  const j = t.indexOf(end, i);
  if (j < 0) throw new Error(`end not found: ${end}`);
  return t.slice(i, j + end.length);
}
function mustContain(text, quote, label) {
  if (!normaliseText(text).includes(normaliseText(quote))) throw new Error(`${label}: quote is not a normalised substring of its source`);
  const w = wordCount(quote);
  if (w > 60) throw new Error(`${label}: ${w} words`);
  if (!/\d/.test(quote)) console.log(`  note: ${label} quote holds no digit (${w} words)`);
  else console.log(`  ok: ${label} quote holds a digit (${w} words)`);
}

// ---- opened texts ----
const park = cachedText("pmid", "32877465"); // PubMed abstract, Park 2020 (F01-E44)
const jmicc = cachedText("pmcid", "PMC12622803"); // Europe PMC full text, J-MICC (F01-V01)
const pearson = fs.readFileSync(path.join(SCRATCH, "fetch/pm-12551878/abstract.txt"), "utf8"); // PubMed record, PMID 12551878

const E44_QUOTE = cut(park, "The predictive value of serum AG ratio", "serum albumin (g/L)].");
const V01_QUOTE = cut(jmicc, "Serum total protein and albumin levels comprised three groups", "and >5.1 g/dL for albumin");
const PEARSON_TITLE = cut(pearson, "Markers of inflammation and cardiovascular disease", "and the American Heart Association.");
mustContain(park, E44_QUOTE, "F01-E44");
mustContain(jmicc, V01_QUOTE, "F01-V01");
mustContain(pearson, PEARSON_TITLE, "PMID 12551878 title");

const pearsonNote = (old, page, confirmedBy) =>
  `Evidence repair, ${DATE}: identifier changed from the PDF copy at ${MIRROR} (the source cache holds its raw PDF bytes, not its text) ` +
  `to the statement's PubMed record, PMID 12551878, matched through Europe PMC by its DOI. That record has no abstract and Europe PMC holds no full text, ` +
  (/\d/.test(old)
    ? `so the quote is its title and the number is not in the opened text. `
    : `so the quote is its title; no number is in the opened text, and the sentence quoted before holds none either. `) +
  `Quoted before, from the PDF copy (printed page ${page}, ${confirmedBy}; the location field describes it): '${old}'`;

// ---- edits: file -> id -> { expectQuote, expectIdentifier, quote?, identifier?, note(oldRecord) } ----
const EDITS = {
  "docs/signoff/work/research/f01_albumin_proteins.json": {
    "F01-E16": { note: () => `Evidence repair, ${DATE}: the number is not in the opened text. Europe PMC holds no full text of this article, and the PubMed abstract gives no figure for the fall in albumin or total protein; its only figures are the sample sizes (13,656 pregnant and 2634 non-pregnant women), which F01-E15 quotes. Quote kept.` },
    "F01-E19": { note: () => `Evidence repair, ${DATE}: the number is not in the opened text. Europe PMC holds no full text of this article, and the PubMed abstract gives no figure for the fall in albumin; its only figures are the 391 women without complications, the 36 tests and the sampling times ('gestational weeks 13-20, 21-28, 29-34, 35-42, at labor, and 1 and 2 days postpartum'). Quote kept.` },
    "F01-E24": { note: () => `Evidence repair, ${DATE}: the number is not in the opened text. Europe PMC holds no full text of this article, and the PubMed abstract names the bias criterion each analyte met without giving the bias; its only figures are the 120 participants and the 113 of 120 self-collections (94 %) that yielded a sample for at least one analyte, on which this record does not rest. Quote kept.` },
    "F01-E44": {
      quote: E44_QUOTE,
      note: () => `Evidence repair, ${DATE}: the formula holds no number, so the quote now starts one sentence earlier in the same abstract (Methods), which states the cohort and size this record gives (8,057 non-CKD participants); the formula sentence is unchanged. The PMC full text (PMC7467286) could not be opened: the Europe PMC full-text service answered HTTP 500.`,
    },
  },
  "docs/signoff/work/verify/f01_albumin_proteins.json": {
    "F01-V01": {
      quote: V01_QUOTE,
      note: (old) => `Evidence repair, ${DATE}: the quote is now the sentence of the same full text that holds the number this record is cited for, the 4.1 g/dL albumin boundary (Methods, Statistical analyses; F01-E03 quotes the same sentence). The dye statement quoted before, in Methods, Clinical characteristics (the location field describes it): '${old.quote}'`,
    },
  },
  "docs/signoff/work/research/f03_kidney.json": {
    "f03-E36": { note: () => `Evidence repair, ${DATE}: the number is not in the opened text. Europe PMC holds no full text of this article, and the PubMed abstract names these determinants without effect sizes; its figures are the sample (8058 inhabitants aged 28 to 75), the two 24-hour urine collections, and the correlations and R2 values of the models for creatinine clearance. Quote kept.` },
  },
  "docs/signoff/work/research/f04_inflammation.json": {
    "f04-E01": { identifier: { type: "pmid", value: "12551878" }, quote: PEARSON_TITLE, note: (old) => pearsonNote(old.quote, 506, "confirmed word for word by the verifier") },
    "f04-E03": { identifier: { type: "pmid", value: "12551878" }, quote: PEARSON_TITLE, note: (old) => pearsonNote(old.quote, 506, "confirmed word for word by the verifier") },
    "f04-E04": { identifier: { type: "pmid", value: "12551878" }, quote: PEARSON_TITLE, note: (old) => pearsonNote(old.quote, 506, "confirmed word for word by the verifier") },
  },
  "docs/signoff/work/verify/f04_inflammation.json": {
    "f04-V01": { identifier: { type: "pmid", value: "12551878" }, quote: PEARSON_TITLE, note: (old) => pearsonNote(old.quote, 503, "read by the verifier") },
  },
};

for (const [file, edits] of Object.entries(EDITS)) {
  const raw = fs.readFileSync(file, "utf8");
  const nl = raw.endsWith("\n") ? "\n" : "";
  const indent = [2, 1].find((ind) => JSON.stringify(JSON.parse(raw), null, ind) + nl === raw);
  if (!indent) throw new Error(`${file}: does not round-trip; refusing to edit`);
  const doc = JSON.parse(raw);
  console.log(`${file} (indent ${indent})`);
  for (const [id, e] of Object.entries(edits)) {
    const recs = doc.evidence.filter((r) => r.id === id);
    if (recs.length !== 1) throw new Error(`${file}: ${recs.length} records with id ${id}`);
    const rec = recs[0];
    const old = JSON.parse(JSON.stringify(rec));
    if (e.identifier) {
      if (old.identifier?.type !== "url" || old.identifier?.value !== MIRROR) throw new Error(`${id}: identifier is not the mirror URL`);
      rec.identifier = e.identifier;
    }
    if (e.quote) {
      if (e.quote === old.quote) throw new Error(`${id}: new quote equals the old one`);
      rec.quote = e.quote;
    }
    const add = e.note(old);
    rec.notes = old.notes ? `${old.notes} ${add}` : add;
    console.log(`  ${id}: ${e.identifier ? "identifier, " : ""}${e.quote ? "quote, " : ""}notes (+${wordCount(add)} words)`);
  }
  const out = JSON.stringify(doc, null, indent) + nl;
  if (!DRY) fs.writeFileSync(file, out);
}
console.log(DRY ? "dry run: nothing written" : "written");
