// Builds the J2 round-4 judge file for shard B01.f01_albumin_proteins.f03_kidney.f04_inflammation.
// AI pre-review; writes one file only.
const fs = require("fs");
const path = require("path");

const OUT = "/home/user/eva-health/docs/signoff/work/judges/round-4/J2-B01.f01_albumin_proteins.f03_kidney.f04_inflammation.json";
const PEARSON_URL = "https://eclass.uoa.gr/modules/document/file.php/DIAT101/%CE%9A%CE%A1%CE%9F%CE%A5%CE%A0%CE%97%CE%A3%20%CE%94%CE%99%CE%91%CE%9B%CE%95%CE%9E%CE%95%CE%99%CE%A3/CARDIAC%20Markers/CARDIAC%20Markers%20papers/CRP/Pearson%20CRP%20guidelines.pdf";

const blocking = [
  {
    family: "f03_kidney",
    row_key: "urea|both|All Adults|none",
    side: "both",
    check_id: "definition:reference interval",
    value_disputed:
      "Urea 21-54 mg/dL is presented to clients as 'the laboratory's reference interval' and its floor as 'the laboratory's lower limit of 21' in all four urea messages (EN and ES), and the row is labelled reference_basis echevarne_interval, but no laboratory prints it: Echevarne prints no urea interval and urea reaches EVA only from other laboratories' reports, whose own printed interval the client holds (B7).",
    evidence: {
      kind: "file_line",
      file: "docs/signoff/work/decisions/f03_kidney.json",
      line: 904,
      quote: "Your urea is below the laboratory's reference interval (21 to 54 mg/dL)."
    },
    resolution:
      "Name the interval as EVA's in the urea messages (EN lines 904-907, ES lines 911-914), as the row's own clinical note already does (line 932: 'EVA's urea interval, 21 to 54 mg/dL, is the laboratory's BUN interval (10 to 25 mg/dL) multiplied by 2.14'), for example 'below EVA's reference interval for urea (21 to 54 mg/dL), worked out from the laboratory's BUN interval' and 'from EVA's lower limit of 21'. Stop labelling the row echevarne_interval (line 856; its reference_source, line 857, says 'Echevarne prints no urea interval'), which needs a basis value for limits derived from printed intervals in common.schema.json. f03-Q08 (using the uploading laboratory's own interval) stays open."
  },
  {
    family: "f03_kidney",
    row_key: "cystatin_c|both|All Adults|none",
    side: "high",
    check_id: "N1",
    value_disputed:
      "Optimal band up to 0.72 mg/L carries no 'reached by a minority' label in the optimal or above-optimal message (EN and ES), although the row's own data show fewer than 10% of healthy adults reach it at 60-79: 2.5th percentile 0.74 mg/L in women and 0.78 mg/L in men aged 70-79; in the same validation split, women 60-69 p5 0.70 and p10 0.73 mg/L, men 60-69 p2.5 0.72 mg/L (B5). Check N1 cannot flag it because NHANES 2015-2018 has no cystatin C, so this is outside the scope of C-14.",
    evidence: {
      kind: "file_line",
      file: "docs/signoff/work/decisions/f03_kidney.json",
      line: 751,
      quote: "the 2.5th percentile at 70-79 is 0.74 mg/L in women and 0.78 mg/L in men and the median at 20-39 is 0.78 mg/L in women, so the band is reached by a minority of adults and by almost no healthy adult aged 70-79"
    },
    resolution:
      "Add the 'reached by a minority' label, as the hs-CRP row does, to the optimal and above-optimal messages (EN lines 734-735, ES lines 740-741), saying that few adults over 60 reach the band (docs/signoff/work/nhanes/distributions.json, validation split, cystatin_c cells female|60-69 lines 12331-12338, female|70-79 lines 12348-12355, male|60-69 lines 12416-12423, male|70-79 lines 12433-12440). f03-DQ06 stays for the choice of band."
  },
  {
    family: "f03_kidney",
    row_key: "creatinine|female|All Adults|none",
    side: "both",
    check_id: "N1",
    value_disputed:
      "The row notes and physician question f03-DQ02 state 'In check N1, 21.1% of healthy NHANES women aged 70-79 sit outside' the 0.55-1.02 mg/dL interval; check N1 of this round reports 23.8% for creatinine|female|70-79 (B7). 21.1% is the distributions-file share (21.09%, non-outcome split), not the N1 result.",
    evidence: {
      kind: "file_line",
      file: "docs/signoff/work/checks/B01-r4.json",
      line: 2668,
      quote: "\"detail\": \"23.8% outside the reference limits (rule 2% to 15%)\","
    },
    resolution:
      "Restate the share as 23.8% (check N1, round 4) in f03-DQ02 (docs/signoff/work/decisions/f03_kidney.json line 2615) and in the row notes (line 238), or attribute 21.1% to the distributions file and say why N1 differs. The options put to the physician do not change."
  }
];

const minor = [
  {
    family: "f03_kidney",
    row_key: "bun|both|All Adults|none",
    side: "high",
    check_id: "definition:optimal band",
    value_disputed:
      "Optimal ceiling 16 mg/dL is inclusive (src/lib/biomarkers/zone-classifier.ts line 89: above optimal only when value > 16), while the band rule excludes Hong 2023 Q4, which starts at 5.71 mmol/L = 16.0 mg/dL by the row's own factor (line 837); f03-DQ05 itself writes 'Q4 (≥16 mg/dL)'. A BUN of 16.0 mg/dL therefore reads optimal although the source places it in Q4 (Model 4 HR 1.48).",
    evidence: {
      kind: "source_quote",
      identifier: { type: "pmcid", value: "PMC9865447" },
      quote: "The results of the study showed that BUN levels in the Q4 group (≥5.71 mmol/L) were positively associated with all-cause and CVD mortality"
    },
    resolution:
      "Set optimal_high to 15 at whole-number precision (or 15.9 with one decimal), or state the edge convention in the row and f03-DQ08 as the cystatin C row does for 0.72. The urea ceiling 34 mg/dL (5.66 mmol/L) already sits in Q3."
  },
  {
    family: "f03_kidney",
    row_key: "bun_creatinine_ratio|both|All Adults|none",
    side: "both",
    check_id: "definition:reference interval",
    value_disputed:
      "reference_basis echevarne_interval for 7.6-45.5, which no laboratory prints: Echevarne reports no BUN-to-creatinine ratio and the row derives the limits from the BUN and creatinine intervals; the compiled summary repeats '(basis: Echevarne interval)'. The messages describe the limits correctly as derived.",
    evidence: {
      kind: "file_line",
      file: "docs/signoff/work/decisions/f03_kidney.json",
      line: 946,
      quote: "\"reference_basis\": \"echevarne_interval\","
    },
    resolution:
      "Use a basis value for limits derived from printed intervals (central change to common.schema.json, shared with the urea and albumin/globulin ratio rows); the limits and messages need no change."
  },
  {
    family: "f03_kidney",
    row_key: "egfr_creatinine_based|both|85+|none",
    side: null,
    check_id: "P1",
    value_disputed:
      "The messages state 'eGFR, CKD-EPI 2021 equation' and the row's pre-analytical rule shows laboratory-reported eGFR as a value only, but the app computes no eGFR and has no code for that values-only rule (no values_only handling anywhere in src), so every eGFR EVA holds today, all laboratory-reported with unknown equation, is classified on this row under a CKD-EPI 2021 label.",
    evidence: {
      kind: "file_line",
      file: "src/lib/biomarkers/biological-age-v3-adapter.ts",
      line: 57,
      quote: "`egfr_creatinine_based`, lab-reported and assumed CKD-EPI 2021; the app computes no eGFR, so this is checked"
    },
    resolution:
      "Make the in-app CKD-EPI 2021 computation, or the values-only display of laboratory eGFR, a written launch condition for the eGFR rows (as F04-DQ-1 does for the state rules), or drop the equation name from the messages until it is built; f03-VQ01 can carry it."
  },
  {
    family: "f03_kidney",
    row_key: "creatinine|female|All Adults|none",
    side: "high",
    check_id: "L1",
    value_disputed:
      "The row's critical_high message (4.0 mg/dL) tells the client 'Contact a doctor today; if you cannot, go to an emergency department', while the critical-limits table gives creatinine the action class 'urgencias' ('Go to an emergency department today', critical-limits.json action_class 'emergency'); BUN keeps 'hoy'. The pack gives two different instructions for a creatinine of 4.0 mg/dL or more.",
    evidence: {
      kind: "file_line",
      file: "docs/signoff/work/governance/critical-limits.md",
      line: 43,
      quote: "| Creatinina | mg/dL | ninguno | **4,0** | urgencias |"
    },
    resolution:
      "Align the row's critical_high message (docs/signoff/work/decisions/f03_kidney.json line 219 and its Spanish text) with the action class the physician picks in critical-limits.md, or drop it, since C-20 puts the critical wording in the table. The wording-rules closing sentence for the critical tier and the table's 'urgencias' class need one answer (central)."
  },
  {
    family: "f03_kidney",
    row_key: "creatinine|female|All Adults|none",
    side: null,
    check_id: "P1",
    value_disputed:
      "Exercise rule says 'most non-collapsed runners had a value above the reference range'; the source reports that 55.4% met the criteria for acute kidney injury, a rise from baseline, not a value above the reference range (the 68.9% above range applies to collapsed runners).",
    evidence: {
      kind: "source_quote",
      identifier: { type: "pmid", value: "32976313" },
      quote: "In the control group, mean creatinine was significantly raised in both the collapse and control groups, with 55.4% meeting the criteria for acute kidney injury, but had resolved to baseline after 24 h."
    },
    resolution:
      "Reword in EN and ES (docs/signoff/work/decisions/f03_kidney.json line 162 and the Spanish text) to 'and over half of non-collapsed runners met the criteria for acute kidney injury', or drop the clause."
  },
  {
    family: "f01_albumin_proteins",
    row_key: "globulin|both|All Adults|none",
    side: "both",
    check_id: "definition:reference interval",
    value_disputed:
      "Calculated globulin from other laboratories' reports is classified against Echevarne's electrophoretic total-globulin interval 1.9-4.0 g/dL (B0278, catalogue line 335) and screened with one action limit, 1.8 g/dL, but the opened sources are method-specific: calculated globulin on Roche bromocresol green and biuret 23-35 g/L (PMID 40728856, direct method), and an antibody-deficiency cut-off of 18 g/L with bromocresol green but 23 g/L with bromocresol purple (PMID 24784320). The row states the mismatch, but no physician question asks which interval and cut-off to sign.",
    evidence: {
      kind: "source_quote",
      identifier: { type: "pmid", value: "24784320" },
      quote: "Using bromocresol purple, 74% of samples had an IgG of < 6 g/l using a cut-off of < 23 g/l."
    },
    resolution:
      "Add a physician question: keep 1.9-4.0 g/dL or adopt a calculated-globulin interval (for example 2.3-3.5 g/dL on a bromocresol green method), and use 2.3 g/dL as the action limit when the uploading report's albumin dye is purple or unknown. The action limit's condition (docs/signoff/work/decisions/f01_albumin_proteins.json line 257) is free text the app cannot apply."
  },
  {
    family: "f01_albumin_proteins",
    row_key: "albumin_globulin_ratio|both|All Adults|none",
    side: "high",
    check_id: "definition:reference interval",
    value_disputed:
      "reference_basis echevarne_interval for a ceiling, 2.53, that Echevarne does not print (B0288 prints .99-1.81 for the electrophoretic ratio); the compiled summary repeats 'reference interval 0.99–2.53 ratio (basis: Echevarne interval)'. The messages are worded correctly ('the interval', not 'the laboratory interval', for 2.53).",
    evidence: {
      kind: "file_line",
      file: "docs/vendor/echevarne/catalogo-2026-08-25.tsv",
      line: 345
    },
    resolution:
      "Use a basis value for limits derived from printed intervals (central change to common.schema.json) for the 2.53 ceiling, or state the per-bound basis in the summary; F01-DQ-4 already asks the physician to sign the derived ceiling."
  },
  {
    family: "f01_albumin_proteins",
    row_key: "albumin|both|All Adults|none",
    side: "low",
    check_id: "definition:action limit",
    value_disputed:
      "The 35 g/L action limit (repeat, and see a doctor within weeks, for values inside Echevarne's 32-48 g/L interval) applies whatever the albumin dye, although a bromocresol purple method reads about 6 g/L below bromocresol green and changes how many people fall under a fixed cut-off; F01-VQ-1 puts the dye question for the 41 g/L floor only.",
    evidence: {
      kind: "source_quote",
      identifier: { type: "pmid", value: "26195486" },
      quote: "Following the change in method there was a large increase in the number of patients classified as hypoalbuminaemic using Pathology Harmony references intervals (32%) but not when retrospectively compared to locally derived reference intervals (16%) compared with the previous year (12%)."
    },
    resolution:
      "Extend F01-VQ-1 and the methods letter (L4) to the 35 g/L action limit: confirm it for a green method and restate it for a purple method before it is signed as final."
  },
  {
    family: "f04_inflammation",
    row_key: "hs_crp|both|All Adults|none",
    side: "high",
    check_id: "definition:optimal band",
    value_disputed:
      "Optimal 'up to 0.5 mg/L' includes 0.50 (classifier inclusive at the ceiling, row decimals 2), while the Women's Health Study's lowest-risk category is '<0.5' and 0.5 opens the next category (crude RR 2.2, FRS-adjusted 1.6); the EPIC-Norfolk reference is also '<0.5 mg/l'.",
    evidence: {
      kind: "source_quote",
      identifier: { type: "pmid", value: "15051634" },
      quote: "Crude RRs for those with baseline hsCRP levels of <0.5, 0.5 to <1.0, 1.0 to <2.0, 2.0 to <3.0, 3.0 to <4.0, 4.0 to <5.0, 5.0 to <10.0, 10.0 to <20.0, and > or =20.0 mg/L were 1.0, 2.2, 2.5, 3.1, 3.7, 4.2, 4.9, 6.3, and 7.6, respectively"
    },
    resolution:
      "Set optimal_high to 0.49 at two decimals, or state in the row that 0.50 is counted as optimal by rounding."
  },
  {
    family: "f04_inflammation",
    row_key: "hs_crp|both|All Adults|none",
    side: "high",
    check_id: "E2",
    value_disputed:
      "E2 reports quotes f04-E01, f04-E03, f04-E04 and f04-V01 (decision limit 3.0 mg/L, repeat above 10 mg/L, fasting rule, factors that move hs-CRP) as not found, but the cause is the cache, not the source: docs/signoff/work/sources-cache/39b4bcd1105bbc45f75e13c018de67998ab12347.txt holds the PDF with its binary bytes replaced by UTF-8 replacement characters (229,314 bytes, no extractable text), whereas the PDF at the same URL (136,255 bytes) contains these statements, including its table of factors (weight loss, oestrogen/progestogen use, statins, fibrates, niacin). The C-17 cache fix is wrong for PDF sources.",
    evidence: {
      kind: "source_quote",
      identifier: { type: "url", value: PEARSON_URL },
      quote: "The cutpoints of low risk (<1.0 mg/L), average risk (1.0 to 3.0 mg/L), and high risk (>3.0 mg/L) correspond to approximate tertiles of hs-CRP in the adult population."
    },
    resolution:
      "Store fetched PDFs as binary and cache their extracted text (central, source cache). The PDF renders < and > as symbol glyphs, so the quote check must normalise them. If the four quotes then match, E2 reads 151 of 152. The row's bounds need no change, and F04-DQ-7 can keep the decision-limit basis."
  },
  {
    family: "f04_inflammation",
    row_key: "hs_crp|both|All Adults|none",
    side: "high",
    check_id: "P3",
    value_disputed:
      "The name matcher sends 'pcr', 'proteina c reactiva', 'crp' and 'c-reactive protein' to hs_crp, so a conventional CRP on an uploaded report is classified against the 0.5 mg/L optimal ceiling and its messages say 'Your hs-CRP'; the row, its method note and P3 assume Echevarne's high-sensitivity assay B0851, whose lowest reportable value must sit at or below 0.5 mg/L.",
    evidence: {
      kind: "file_line",
      file: "src/lib/biomarkers/name-matcher.ts",
      line: 151,
      quote: "\"c-reactive protein\": \"hs_crp\", \"crp\": \"hs_crp\","
    },
    resolution:
      "Show a CRP not labelled high-sensitivity as a value only (or under its own key) until its assay is known, and list the case with F04-DQ-4 (bounded results)."
  },
  {
    family: "f04_inflammation",
    row_key: "fibrinogen|both|All Adults|none",
    side: null,
    check_id: "D4",
    value_disputed:
      "Fibrinogen reaches EVA only from uploaded reports, but the name matcher has no fibrinogen key or alias (a 'Fibrinógeno' line is unmatched unless the client picks the key by hand) and convertBiomarker has no g/L to mg/dL factor, so a result in g/L, the unit of the row's own pregnancy source (PMID 30934105: '2-4 g/L'), is refused as unit_mismatch.",
    evidence: {
      kind: "file_line",
      file: "src/lib/biomarkers/unit-conversions.ts",
      line: 889,
      quote: "// No conversion needed or not recognized — return as-is"
    },
    resolution:
      "Add fibrinogen with Spanish and English aliases to src/lib/biomarkers/name-matcher.ts and the exact factor g/L x 100 = mg/dL to unit-conversions.ts with a unit test (D4), or state in the row that fibrinogen is not received until then."
  }
];

const notes = [
  "AI pre-review, lens J2 (clinical biochemist), round 4, shard B01.f01_albumin_proteins.f03_kidney.f04_inflammation. All 15 rows read; the 12 sampled rows inspected closely.",
  "Checked: every reference bound against docs/vendor/echevarne/catalogo-2026-08-25.tsv at printed precision (albumin line 55, total protein 366, globulins 335, albumin/globulin 345, creatinine 114-115, BUN 97, cystatin C 107, hs-CRP 308, fibrinogen 145): all equal, except the disclosed derived limits (urea, the albumin/globulin ceiling, the BUN/creatinine ratio) and the hs-CRP decision limit, whose >3.0 mg/L cut point the CDC/AHA text confirms. Echevarne prints no age bands for these codes.",
  "Unit conversions in src/lib/biomarkers/unit-conversions.ts are correct for urea (x6.006), BUN (x2.801), creatinine (x0.0113), albumin and total protein (x10), globulin (x0.1) and hs-CRP (x10); fibrinogen has none (minor). The classifier is inclusive at the optimal ceiling (zone-classifier.ts line 89).",
  "Numbers agree between EN and ES in all 186 text-field pairs of the 15 rows; the compiled B01-r4 rows equal the decision rows (the critical_high texts are not compiled, C-20). Critical limits are their own fields (creatinine 4.0, BUN 100, urea 214 mg/dL), not renamed reference limits.",
  "Sources opened in this task (PubMed efetch, Europe PMC full text, guideline PDF): PMIDs 24784320, 28735065, 25437911, 30767593, 26195486, 31053386, 26561925, 17270090, 24062331, 32976313, 4005491, 42035842, 29483105, 28720681, 19929276, 12675875, 11601685, 15086483, 39485740, 15051634, 16053959, 11238292, 12706932, 35206975, 40728856, 23821244, 30934105; PMC9865447; PMC12456039; the Pearson 2003 PDF. The pre-analytical, biological-variation and method numbers they carry match the rows, except the marathon paraphrase (minor).",
  "Not re-raised (known issues or already physician questions): C-04, C-08, C-13 (total-protein, eGFR and BUN/creatinine K1 patterns: F01-DQ-3, f03-DQ04, f03-DQ07), C-14 (N1 for albumin, BUN, creatinine, hs-CRP), C-15 (albumin X1), C-20; the albumin dye (F01-VQ-1) and cystatin C calibration (f03-DQ06). Family pages docs/signoff/work/families/*.md do not exist (C3 blocked).",
  "Not opened: research, verify, ledger, refutations and other judge files, and the decisions files' issues_addressed and top-level notes fields. WebSearch calls: 0."
].join(" ");

const doc = {
  schema_version: "1",
  round: 4,
  lens: "J2",
  shard: "B01.f01_albumin_proteins.f03_kidney.f04_inflammation",
  families_reviewed: ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"],
  sample_file: "docs/signoff/work/judges/round-4/sample-B01.f01_albumin_proteins.f03_kidney.f04_inflammation.json",
  blocking,
  minor,
  model: "claude-opus-5-5",
  notes
};

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(doc, null, 1) + "\n", "utf8");
console.log("wrote", OUT, "blocking", blocking.length, "minor", minor.length);
