import sys, re, html
for p in sys.argv[1:]:
    raw = open(p, encoding='utf-8', errors='replace').read()
    raw2 = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', raw)
    title = re.search(r'(?is)<title>(.*?)</title>', raw2)
    txt = html.unescape(re.sub(r'(?s)<[^>]+>', '\n', raw2))
    lines = [l.strip() for l in txt.splitlines() if l.strip()]
    print('=====', p, '|', html.unescape(title.group(1)).strip() if title else '')
    # counts like "Artículos de revistas (2)"
    for l in lines:
        if re.match(r'^(Artículos de revistas|Artículos en obras colectivas|Libros|Tesis|Coordinador|Colaboraciones|Tesis dirigidas)', l):
            print('  COUNT:', l)
    # titles: Dialnet lists titles in <span class="titulo"> ... ; fall back to anchor text to /servlet/articulo, /servlet/libro, /servlet/tesis
    items = re.findall(r'(?is)<a[^>]+href="(/servlet/(?:articulo|libro|tesis|extart)\?codigo=\d+)"[^>]*>(.*?)</a>', raw)
    seen=set()
    for href, t in items:
        t = html.unescape(re.sub(r'(?s)<[^>]+>', '', t)).strip()
        if not t or (href,t) in seen: continue
        seen.add((href,t))
        flag = bool(re.search(r'(?i)biogram|edad biol|edad psicobiol|envejec|longev|anciano|vejez|geriatr|mayores|edad', t))
        print('  ', '*' if flag else ' ', href, '|', t[:160])
