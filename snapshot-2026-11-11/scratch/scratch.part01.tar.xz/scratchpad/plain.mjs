const meta = {
  name: 'ws1-batch',
  description: 'EVA sign-off workstream 1: run the author, verify, check, judge, refute and fix loop for one batch of biomarker families',
  whenToUse: 'A batch session of workstream 1 (docs/signoff/LOOP-PROMPT.md section 3), with args {batch, started_at}',
  phases: [
    { title: 'Setup', detail: 'read the batch families and the issues already in their ledgers' },
    { title: 'Author', detail: 'family auditor writes research/<family>.json; one repair pass' },
    { title: 'Verify', detail: 'independent verifier writes verify/<family>.json; one repair pass' },
    { title: 'Fix', detail: 'one fixer per family with confirmed issues writes decisions/<family>.json' },
    { title: 'Check', detail: 'validate, ownership, compile into a scratch copy, run the DSRT for the family' },
    { title: 'Judge', detail: 'six lenses J1-J6 over shards of at most 3 families' },
    { title: 'Refute', detail: 'two refuters per new blocking issue, default refuted' },
    { title: 'Ledger', detail: 'record outcomes with ledger.js; stop rules in code; scorecard each round' },
    { title: 'Scorecard', detail: 'finalize the ledgers and render scorecard-<batch>.md' },
  ],
}

// docs/signoff/workflows/ws1-batch.js implements docs/signoff/LOOP-PROMPT.md sections 1 to 4 for one batch.
// The script orchestrates only: agents do every file read and write and run the tools in docs/signoff/tools/.
// Round-varying content lives in files the agents read (inputs, checks, ledgers, judge files); prompts are the
// role prompts of LOOP-PROMPT.md section 2 with the placeholders filled. See docs/signoff/workflows/README.md.

// ─── arguments ───

const A = args || {}
if (!A.batch || typeof A.batch !== 'string') throw new Error('args.batch is required, e.g. {"batch": "B01", "started_at": "2026-11-06T09:00:00Z"}')
if (!A.started_at || typeof A.started_at !== 'string') throw new Error('args.started_at is required (an ISO time; the script has no clock)')
const BATCH = A.batch
const STARTED_AT = A.started_at
const TODAY = STARTED_AT.slice(0, 10)
const MAX_ROUNDS = Number.isInteger(A.max_rounds) && A.max_rounds > 0 ? A.max_rounds : 3
const START_ROUND = Number.isInteger(A.start_round) && A.start_round > 0 ? A.start_round : 1
const AGENT_CAP = Number.isInteger(A.agent_cap) && A.agent_cap > 0 ? A.agent_cap : 120
const CAP_AUTHOR = Number.isInteger(A.search_cap_author) ? A.search_cap_author : 22
const CAP_VERIFIER = Number.isInteger(A.search_cap_verifier) ? A.search_cap_verifier : 16
const CAP_FIXER = Number.isInteger(A.search_cap_fixer) ? A.search_cap_fixer : CAP_VERIFIER
const CAP_JUDGE = Number.isInteger(A.search_cap_judge) ? A.search_cap_judge : 6
const CAP_REFUTER = Number.isInteger(A.search_cap_refuter) ? A.search_cap_refuter : 4
const OVERRIDE = Array.isArray(A.families) ? A.families.filter((f) => typeof f === 'string').sort() : null
const SHARD_MAX = 3
const LENSES = ['J1', 'J2', 'J3', 'J4', 'J5', 'J6']
const MODEL = 'fable'
const RESERVE = 2 // agents kept back for the final ledger and scorecard

const W = 'docs/signoff/work'
const T = 'docs/signoff/tools'

// ─── issue ids: identical to idPart/issueId in docs/signoff/tools/ledger.js (a test compares them) ───

function idPart(s) {
  if (s === null || s === undefined || s === '') return 'none'
  return String(s).trim().replace(/\|/g, '.').replace(/\+/g, 'plus').replace(/\s+/g, '_').replace(/[^A-Za-z0-9_.:-]/g, '_')
}
function issueId(family, checkOrLens, rowKey, side) {
  return [family, checkOrLens, rowKey, side].map(idPart).join('--')
}

// ─── schemas ───

const STR_LIST = { type: 'array', items: { type: 'string' } }
const MODEL_PROP = { type: 'string', description: 'The model id you are running on, as you know it; "unknown" if you do not know.' }

const SETUP_SCHEMA = {
  type: 'object',
  required: ['batch', 'families', 'existing_issues', 'inputs_missing'],
  properties: {
    batch: { type: 'string' },
    families: {
      type: 'array',
      items: {
        type: 'object',
        required: ['family', 'title', 'keys', 'v3_keys', 'base_panel_keys'],
        properties: { family: { type: 'string' }, title: { type: 'string' }, keys: STR_LIST, v3_keys: STR_LIST, base_panel_keys: STR_LIST },
      },
    },
    existing_issues: {
      type: 'array',
      items: {
        type: 'object',
        required: ['id', 'family', 'lens', 'opened', 'status'],
        properties: { id: { type: 'string' }, family: { type: 'string' }, lens: { type: 'string' }, opened: { type: 'integer' }, status: { type: 'string' } },
      },
    },
    inputs_missing: STR_LIST,
    model: MODEL_PROP,
  },
}

const FILE_SCHEMA = {
  type: 'object',
  required: ['file', 'valid', 'errors', 'searches_used', 'files_written'],
  properties: {
    file: { type: 'string' },
    valid: { type: 'boolean', description: 'true only when the validator printed VALID for the file as it is on disk now' },
    errors: { ...STR_LIST, description: 'the validator error lines, verbatim; empty when valid' },
    searches_used: { type: 'integer', minimum: 0 },
    files_written: { ...STR_LIST, description: 'every path you wrote, repo-relative' },
    model: MODEL_PROP,
  },
}

const CHECK_SCHEMA = {
  type: 'object',
  required: ['family', 'round', 'valid', 'validation_errors', 'ownership_ok', 'outside_paths', 'compile_ok', 'checks_file', 'failing_count', 'failing', 'blocked_checks', 'errors'],
  properties: {
    family: { type: 'string' },
    round: { type: 'integer' },
    valid: {
      type: 'object',
      required: ['research', 'verify', 'decision'],
      properties: { research: { type: ['boolean', 'null'] }, verify: { type: ['boolean', 'null'] }, decision: { type: ['boolean', 'null'] } },
    },
    validation_errors: STR_LIST,
    ownership_ok: { type: 'boolean' },
    outside_paths: STR_LIST,
    compile_ok: { type: 'boolean' },
    checks_file: { type: 'string' },
    failing_count: { type: 'integer', minimum: 0, description: 'failing_count from the ledger.js checks output, verbatim' },
    failing: {
      type: 'array',
      items: { type: 'object', required: ['check', 'count'], properties: { check: { type: 'string' }, count: { type: 'integer' }, keys: STR_LIST } },
    },
    blocked_checks: STR_LIST,
    errors: { ...STR_LIST, description: 'any command that failed, with its last error line' },
    model: MODEL_PROP,
  },
}

const PREP_SCHEMA = {
  type: 'object',
  required: ['round', 'compile_ok', 'checks_file', 'samples', 'errors'],
  properties: {
    round: { type: 'integer' },
    compile_ok: { type: 'boolean' },
    checks_file: { type: 'string' },
    samples: { type: 'array', items: { type: 'object', required: ['shard', 'file'], properties: { shard: { type: 'string' }, file: { type: 'string' } } } },
    errors: STR_LIST,
    model: MODEL_PROP,
  },
}

const ISSUE_ITEM = {
  type: 'object',
  required: ['id', 'family', 'check_id', 'row_key', 'side', 'summary'],
  properties: {
    id: { type: 'string' }, family: { type: 'string' }, check_id: { type: 'string' },
    row_key: { type: ['string', 'null'] }, side: { type: ['string', 'null'] }, summary: { type: 'string' },
  },
}
const JUDGE_SCHEMA = {
  type: 'object',
  required: ['file', 'valid', 'errors', 'lens', 'families_reviewed', 'blocking', 'minor', 'searches_used'],
  properties: {
    file: { type: 'string' },
    valid: { type: 'boolean' },
    errors: STR_LIST,
    lens: { type: 'string' },
    families_reviewed: STR_LIST,
    blocking: { type: 'array', items: ISSUE_ITEM, description: 'the "blocking" array printed by ledger.js extract, copied exactly' },
    minor: { type: 'array', items: ISSUE_ITEM, description: 'the "minor" array printed by ledger.js extract, copied exactly' },
    searches_used: { type: 'integer', minimum: 0 },
    model: MODEL_PROP,
  },
}

const REFUTE_SCHEMA = {
  type: 'object',
  required: ['file', 'valid', 'errors', 'verdict'],
  properties: {
    file: { type: 'string' },
    valid: { type: 'boolean' },
    errors: STR_LIST,
    verdict: { type: 'string', enum: ['confirmed', 'refuted'], description: 'the verdict field of the file you wrote' },
    model: MODEL_PROP,
  },
}

const LEDGER_SCHEMA = {
  type: 'object',
  required: ['ok', 'written', 'errors', 'counts', 'scorecard_file'],
  properties: {
    ok: { type: 'boolean' },
    written: STR_LIST,
    errors: STR_LIST,
    counts: {
      type: 'array',
      items: {
        type: 'object',
        required: ['family', 'blocking_open', 'confirmed', 'disputed', 'unreviewed', 'script_open'],
        properties: {
          family: { type: 'string' }, blocking_open: { type: 'integer' }, confirmed: { type: 'integer' },
          disputed: { type: 'integer' }, unreviewed: { type: 'integer' }, script_open: { type: 'integer' },
        },
      },
      description: 'one entry per family from the "counts" object that ledger.js apply printed, copied exactly',
    },
    scorecard_file: { type: 'string' },
    model: MODEL_PROP,
  },
}

const FINAL_SCHEMA = {
  type: 'object',
  required: ['scorecard_file', 'finalized', 'errors'],
  properties: {
    scorecard_file: { type: 'string' },
    finalized: { type: 'array', items: { type: 'object', required: ['family', 'converted'], properties: { family: { type: 'string' }, converted: { type: 'integer' } } } },
    errors: STR_LIST,
    model: MODEL_PROP,
  },
}

// ─── prompts (LOOP-PROMPT.md section 2, placeholders filled) ───

function shared(searchCap) {
  return [
    'You are one agent in the EVA physician sign-off programme. Your output is AI work product that a licensed',
    'physician will review; write it so he can check every claim. Read `docs/signoff/PLAN.md` sections 2, 4 and 5.',
    '',
    'Rules:',
    '- Write only the file named below. Write it before you reply, and write partial results if you run short of time.',
    '- Do not edit any other file.',
    '- Do not query any database, send any message or call any API of the app.',
    '- Every number comes from a source you opened in this task: a PubMed or Europe PMC abstract, a PMC full text,',
    '  or a guideline page. Nothing comes from memory.',
    `- Search with at most ${searchCap} WebSearch calls. Fetch abstracts directly from these endpoints, which do`,
    '  not use the search budget:',
    '  - `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=...&resultType=core&format=json`',
    '  - `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=<PMID>&rettype=abstract&retmode=text`',
    '- When you reach a cap, stop searching. Mark the remaining sources unverified.',
    '',
    `Workflow notes: batch ${BATCH}; the run started ${STARTED_AT}, use ${TODAY} as today's date wherever a file needs`,
    'one. Do not commit or push. Count your WebSearch calls and report them as searches_used.',
  ].join('\n')
}

function halfNote(text) {
  return `\n\nRETRY AT HALF SCOPE: a previous agent for this task returned nothing. ${text} Write your file early and update it as you go.`
}

function authorPrompt(f, half) {
  const cap = half ? Math.floor(CAP_AUTHOR / 2) : CAP_AUTHOR
  return [
    shared(cap),
    '',
    `Role: a physician specialised in preventive and longevity medicine, auditing EVA's rows for the family`,
    `\`${f.family}\` (biomarker keys \`${f.keys.join(', ')}\`).`,
    '',
    `Input: \`${W}/inputs/${f.family}.json\`. It holds:`,
    '- the current rows in both languages, and the production snapshot rows;',
    "- Echevarne's catalogue interval, method and age bands for each mapped code;",
    '- the September research and verify files, and the current sources;',
    '- NHANES distributions by sex and age band, where they exist;',
    "- the version 3 clamps and today's consistency failures, for version 3 markers;",
    '- the locked decisions.',
    '',
    'For every row, decide and record:',
    '1. The marker class, a to e.',
    "2. The reference basis and bounds: Echevarne's interval, or a named guideline decision limit copied exactly.",
    '3. The optimal band and its band rule, from outcome evidence only.',
    '4. Age, sex and state splits. Include a pass for ages 70 to 84 and 85 and over, pregnancy and lactation,',
    '   menopause, and hormone therapy or oral contraception.',
    '5. Critical and action limits, or "none, because".',
    '6. Pre-analytical rules: fasting, time of day, haemolysis, capillary samples.',
    '7. The reference change value inputs.',
    '8. The client messages, in Spanish and English, for reachable zones only, following',
    `   \`${W}/governance/wording-rules.md\`.`,
    '9. For a version 3 marker, the consistency resolution: a row change, or an accepted exception with its reason.',
    '   The model itself never changes.' + (f.v3_keys.length ? ` Version 3 markers in this family: ${f.v3_keys.join(', ')}.` : ' This family has no version 3 marker.'),
    '',
    'For every bound, give one evidence record as in PLAN.md section 5, with a verbatim quote that contains the',
    'number. Propose a grade; the verifier decides it. A locked decision stays as it is: if the evidence contradicts',
    'it, write a CEO question with the evidence.',
    '',
    `Output: \`${W}/research/${f.family}.json\`, valid against \`${T}/schema/research.schema.json\`.`,
    `Check it with \`node ${T}/validate.js research ${f.family}\` and fix every error.`,
    '',
    `Reply with the structured result: file, valid (from the validator's last run), errors (its error lines), searches_used, files_written.`,
  ].join('\n') + (half ? halfNote(`Use at most ${cap} searches. Cover every row's class, basis, reference bounds and their evidence first, then optimal bands, then messages; list what you could not reach in unverified_sources and physician_questions.`) : '')
}

function verifierPrompt(f, half) {
  const cap = half ? Math.floor(CAP_VERIFIER / 2) : CAP_VERIFIER
  return [
    shared(cap),
    '',
    'Role: an independent physician-verifier. You did not write the file you check.',
    '',
    `Input: \`${W}/research/${f.family}.json\` and \`${W}/inputs/${f.family}.json\`.`,
    '',
    'Try to refute every claim:',
    '- Open each load-bearing source and confirm that the quote is in it, word for word.',
    '- Confirm that the number, unit and population fit the row.',
    '- Re-derive the band rule, and assign the grade yourself.',
    '- Check the class, the basis, the splits, the limits and the messages against PLAN.md and the wording rules.',
    '',
    'Where you disagree, give the corrected row with your evidence. Where you cannot decide, raise a physician',
    'question.',
    '',
    `Output: \`${W}/verify/${f.family}.json\`, valid against \`verify.schema.json\`, including \`final_rows\` and`,
    `a verdict per source. Check it with \`node ${T}/validate.js verify ${f.family}\`.`,
    '',
    `Reply with the structured result: file, valid (from the validator's last run), errors (its error lines), searches_used, files_written.`,
  ].join('\n') + (half ? halfNote(`Use at most ${cap} searches. Verify the sources behind optimal bands and bounds that differ from Echevarne's interval first; mark the rest unverified with a physician question.`) : '')
}

function fixerPrompt(f, n, half) {
  const cap = half ? Math.floor(CAP_FIXER / 2) : CAP_FIXER
  return [
    shared(cap),
    '',
    `Role: a physician fixing the family \`${f.family}\`. Here are the confirmed blocking issues from the ledger, with`,
    `their evidence: \`${W}/ledger/${f.family}.json\`. The definitions and the evidence standard decide what`,
    'the right fix is; the judges do not. A fix that only satisfies a check without meeting the definitions is',
    'wrong.',
    '',
    'Every loosening needs a grade A or B quote: a wider optimal band, a removed bound, or a bound moved toward the',
    'reference limit. Record each change with its reason and source.',
    '',
    `Output: \`${W}/decisions/${f.family}.json\`, the only file you may write, valid against`,
    '`decision.schema.json`.',
    '',
    'Workflow notes for this round:',
    `- Fix the ledger issues with status "confirmed" and the open script issues (source.lens "script"). Leave "disputed" issues as they are.`,
    `- The failing check details are in \`${W}/checks/${f.family}-r${n - 1}.json\` (only failures whose key names one of the family keys ${f.keys.join(', ')} are yours).`,
    `- Start from \`${W}/decisions/${f.family}.json\` if it exists, else from final_rows of \`${W}/verify/${f.family}.json\`. Set round to ${n}, decided_at to ${TODAY},`,
    `  verify_sha256 to the sha256 of the verify file (\`sha256sum ${W}/verify/${f.family}.json\`), and list every ledger id you resolve in issues_addressed.`,
    `- Validate with \`node ${T}/validate.js decision ${f.family}\` and fix every error.`,
    '',
    `Reply with the structured result: file, valid (from the validator's last run), errors (its error lines), searches_used, files_written.`,
  ].join('\n') + (half ? halfNote(`Use at most ${cap} searches. Fix only the first half of the confirmed and script issues in id order; the rest stay open for the physician.`) : '')
}

function repairPrompt(kind, f, file, errors, cap) {
  return [
    shared(Math.max(2, Math.floor(cap / 4))),
    '',
    `Role: the repair pass for \`${file}\` (the ${kind} file of family \`${f.family}\`), which failed validation.`,
    `Run \`node ${T}/validate.js ${kind} ${f.family}\` and fix every error it prints, changing only what the errors require.`,
    'Do not change any number, quote or source that is not named in an error. Write only that file.',
    '',
    'The errors reported by the previous agent were (they may be stale; trust the validator):',
    ...errors.slice(0, 40).map((e) => `- ${e}`),
    errors.length > 40 ? `- and ${errors.length - 40} more` : '',
    '',
    `Reply with the structured result: file, valid (from the validator's last run), errors (its error lines), searches_used, files_written.`,
  ].join('\n')
}

function checkPrompt(f, n, half) {
  const dir = `${W}/compiled/${BATCH}-r${n}/${f.family}`
  const checks = `${W}/checks/${f.family}-r${n}.json`
  return [
    `You are the mechanical runner of EVA's sign-off loop, batch ${BATCH}, family ${f.family}, round ${n}. Run these`,
    'commands from the repository root, in order, and report their results exactly. Do not edit any file by hand,',
    'do not fix anything, do not commit. Every number you report comes from command output.',
    '',
    `1. Validate: \`node ${T}/validate.js research ${f.family}\`, \`node ${T}/validate.js verify ${f.family}\`, and, if`,
    `   \`${W}/decisions/${f.family}.json\` exists, \`node ${T}/validate.js decision ${f.family}\`. valid.<kind> is true for`,
    '   VALID, false for INVALID, null when the file does not exist. Put the error lines in validation_errors.',
    `2. Ownership of the batch: \`git status --porcelain -uall | node ${T}/ownership.js --batch ${BATCH} --loop-outputs --json\`.`,
    `   Then the family's own files: \`git status --porcelain -uall | grep -F '${f.family}' | grep -v -F '${W}/checks/' | grep -v -F '${W}/compiled/' | node ${T}/ownership.js --family ${f.family} --json --record ${W}/checks/${BATCH}-r${n}-changes.json --agent ${f.family}\`.`,
    '   ownership_ok is true only when both print "ok": true; outside_paths is the union of their "outside" lists.',
    `3. Compile into a scratch copy: \`node ${T}/compile.js --out-dir ${dir} --families ${f.family}\`. compile_ok is its exit status 0.`,
    `4. Run the checks: \`npm run dsrt -- --families ${f.family} --seed-dir ${dir} --round ${n} --out ${checks}\`.`,
    `5. Sync the ledger: \`node ${T}/ledger.js checks --family ${f.family} --round ${n} --checks ${checks}\`. Copy from its`,
    '   JSON output: failing_count; failing as [{check, count, keys: the first 5 failure keys}]; blocked_checks.',
    '',
    `If step 3 fails, skip step 4 and 5, set checks_file to "" and failing_count to 0, and put the error in errors.`,
    `Reply with the structured result; checks_file is \`${checks}\`.`,
  ].join('\n') + (half ? '\n\nThis is a retry: a previous runner returned nothing. Run the same commands; keep output short.' : '')
}

function shardName(families) {
  return `${BATCH}.${families.join('.')}`
}

function prepPrompt(n, shards, families) {
  const dir = `${W}/compiled/${BATCH}-r${n}`
  const checks = `${W}/checks/${BATCH}-r${n}.json`
  return [
    `You are the mechanical runner of EVA's sign-off loop, batch ${BATCH}, round ${n}: prepare the judges' material.`,
    'Run these commands from the repository root, in order, and report their results exactly. Do not edit files by',
    'hand, do not fix anything, do not commit.',
    '',
    `1. Compile the batch into a scratch copy: \`node ${T}/compile.js --out-dir ${dir} --families ${families.join(',')}\`. compile_ok is exit status 0.`,
    `2. Run the checks: \`npm run dsrt -- --families ${families.join(',')} --seed-dir ${dir} --round ${n} --out ${checks}\`.`,
    '3. Write the seeded sample for each shard:',
    ...shards.map((s) => `   \`node ${T}/ledger.js sample --round ${n} --shard ${s.name} --families ${s.families.join(',')}\``),
    '',
    `Reply with the structured result: checks_file is \`${checks}\`; samples lists each shard and the "file" the sample command printed.`,
  ].join('\n')
}

function judgePrompt(lens, n, shard, families, half) {
  const sample = `${W}/judges/round-${n}/sample-${shard}.json`
  const out = `${W}/judges/round-${n}/${lens}-${shard}.json`
  return [
    shared(CAP_JUDGE),
    '',
    `Role: \`the lens ${lens} of ${W}/judges/lenses.json: read lenses.${lens}.role_text and adopt it, under its shared_rules (verdict label, blocking criteria B1-B7, what a judge never does)\`. You are reviewing this material for the physician before he sees it. Your job is to find`,
    'what would stop him signing. Assume nothing is right until you have checked it.',
    '',
    `Input: the compiled rows, family pages and decisions for \`${shard}\`; the check results file for this round; and a`,
    `seeded sample of rows to inspect closely, \`${sample}\`. You do not`,
    "see the authors' reasoning or earlier verdicts. Read all of the material you clear; do not sample beyond the",
    'list.',
    '',
    'Report blocking issues only where the physician could not sign as written. For each one, give:',
    '- the family, the row, the check id or definition it breaks, and the exact value disputed;',
    '- the evidence: a file and line, or a source with a quote;',
    '- what would resolve it.',
    '',
    'Minor issues go in a separate list.',
    '',
    `Output: \`${out}\`, valid against \`judge.schema.json\`.`,
    '',
    'Where the material is, for this shard:',
    `- families: ${families.join(', ')};`,
    `- compiled rows: \`${W}/compiled/${BATCH}-r${n}/biomarker-ranges-en.json\`, \`rangos-biomarcadores-es.json\`, \`biomarker-sources.json\`, \`CHANGES.md\` in the same directory; rows of other families there are not yours;`,
    `- decisions: \`${W}/decisions/<family>.json\` where it exists; family pages \`${W}/families/<family>.md\` where they exist;`,
    `- check results: \`${W}/checks/${BATCH}-r${n}.json\`;`,
    `- do not open \`${W}/research/\`, \`${W}/verify/\`, \`${W}/ledger/\`, \`${W}/refutations/\` or any other judge file.`,
    '',
    `Set schema_version "1", round ${n}, lens "${lens}", shard "${shard}", families_reviewed, sample_file "${sample}".`,
    'Give every issue a side ("low", "high", "both") when it concerns one bound, else null.',
    `Then run \`node ${T}/validate.js judge ${out}\` and fix every error, and run \`node ${T}/ledger.js extract ${out}\`.`,
    'Reply with the structured result: file, valid, errors, lens, families_reviewed, and the blocking and minor arrays the extract command printed, copied exactly.',
  ].join('\n') + (half ? halfNote(`First write the sample with \`node ${T}/ledger.js sample --round ${n} --shard ${shard} --families ${families.join(',')}\` (it prints the file). This shard is half of the original one.`) : '')
}

function refuterPrompt(side, issue, n, half) {
  const out = `${W}/refutations/round-${n}/${issue.id}-${side}.json`
  const desc = `issue \`${issue.id}\` in \`${issue.judge_file}\` (family ${issue.family}, check ${issue.check_id}, row ${issue.row_key || 'none'}, side ${issue.side || 'none'}; read its value_disputed, evidence and resolution there)`
  return [
    shared(CAP_REFUTER),
    '',
    `Role: a skeptical reviewer. Here is one blocking issue raised by a judge: ${desc}. Try to show it is not`,
    'real.',
    side === 'a' ? '- You are Refuter A: you reproduce it from the artefacts.' : "- You are Refuter B: you test it against PLAN.md's definitions and the acceptance test.",
    '',
    'Default to "refuted" if you cannot reproduce it, or if the definitions allow what the judge objects to.',
    '',
    `Output: \`${out}\`, with your verdict, confirmed or`,
    'refuted, your reason, and the evidence.',
    '',
    `The file is valid against \`${T}/schema/refutation.schema.json\`: schema_version "1", issue_id "${issue.id}", round ${n}, refuter "${side}",`,
    `family "${issue.family}". The artefacts are the compiled copy \`${W}/compiled/${BATCH}-r${n}/\`, \`${W}/decisions/\`, \`${W}/verify/\` and \`${W}/checks/${BATCH}-r${n}.json\`;`,
    `the definitions are \`docs/signoff/PLAN.md\` section 4 and 5 and \`docs/signoff/ACCEPTANCE-TEST.md\`. Do not read the other refuter's file.`,
    `Run \`node ${T}/validate.js refutation ${out}\` and fix every error. Reply with the structured result.`,
  ].join('\n') + (half ? halfNote('Test only the exact value disputed against the single piece of evidence the judge cites.') : '')
}

function ledgerPrompt(n, payload, run, half) {
  return [
    `You are the mechanical ledger runner of EVA's sign-off loop, batch ${BATCH}, round ${n}. Do not edit files by hand,`,
    'do not judge anything, do not commit. Run from the repository root:',
    '',
    `1. Write the JSON payload below to a temporary file outside the repository (for example with mktemp) and run`,
    `   \`node ${T}/ledger.js apply --payload <that file>\`. Its exit status is 0 when every ledger validates.`,
    `2. Write the run summary JSON below, exactly, to \`${W}/checks/${BATCH}-run.json\`, then run`,
    `   \`node ${T}/scorecard.js --batch ${BATCH} --run ${W}/checks/${BATCH}-run.json\` (it prints the scorecard path).`,
    '',
    'Reply with the structured result: ok (step 1 exit status 0), written and errors from the apply output, counts as one',
    'entry per family of the apply output\'s "counts" object (copied exactly), scorecard_file.',
    '',
    'Payload:',
    '```json',
    JSON.stringify(payload),
    '```',
    '',
    'Run summary:',
    '```json',
    JSON.stringify(run),
    '```',
  ].join('\n') + (half ? '\n\nThis is a retry: a previous runner returned nothing. Run the same commands.' : '')
}

function finalPrompt(stops, run, half) {
  return [
    `You are the mechanical runner that closes EVA's sign-off loop for batch ${BATCH}. Do not edit files by hand, do not`,
    'judge anything, do not commit. Run from the repository root, in order:',
    '',
    '1. Finalize each family\'s ledger (what is still open becomes a physician question; disputed items stay disputed):',
    ...stops.map((s) => `   \`node ${T}/ledger.js finalize --family ${s.family} --round ${s.round} --reason "${s.reason}"\``),
    `2. Validate each ledger: \`node ${T}/validate.js ledger <family>\` for ${stops.map((s) => s.family).join(', ')}.`,
    `3. Write the run summary JSON below, exactly, to \`${W}/checks/${BATCH}-run.json\`, then run`,
    `   \`node ${T}/scorecard.js --batch ${BATCH} --run ${W}/checks/${BATCH}-run.json\`.`,
    '',
    'Reply with the structured result: scorecard_file (the path scorecard.js printed); finalized as one entry per family with',
    'the number of ids in "converted" from the finalize output; errors (any failing command or INVALID line).',
    '',
    'Run summary:',
    '```json',
    JSON.stringify(run),
    '```',
  ].join('\n') + (half ? '\n\nThis is a retry: a previous runner returned nothing. Run the same commands.' : '')
}

function setupPrompt(half) {
  return [
    `You are the mechanical runner of EVA's sign-off loop, batch ${BATCH}. Read-only: do not edit any file, do not commit.`,
    '',
    OVERRIDE
      ? `1. From \`${W}/families.json\`, take the families ${OVERRIDE.join(', ')} (an override of the batch list).`
      : `1. From \`${W}/families.json\`, take the families listed in batches.${BATCH}.`,
    '   For each, return family (its name), title, keys, v3_keys and base_panel_keys exactly as in the file, sorted by family name.',
    `2. For each family, check that \`${W}/inputs/<family>.json\` exists; list the missing ones in inputs_missing.`,
    `3. Run \`node ${T}/ledger.js ids --judges-only --family <the families, comma-separated>\` and return every entry`,
    '   as existing_issues [{id, family, lens, opened, status}], copied exactly (an empty list if it prints {}).',
    '',
    'Reply with the structured result.',
  ].join('\n') + (half ? '\n\nThis is a retry: a previous runner returned nothing.' : '')
}

// ─── agent accounting ───

const runLog = { agents: [], nulls: 0, retries: 0, capped: false, left: [] }

async function call(prompt, opts, info) {
  const limit = info.final ? AGENT_CAP : AGENT_CAP - RESERVE
  if (runLog.agents.length >= limit) {
    runLog.capped = true
    return { __capped: true }
  }
  const entry = { label: opts.label, role: info.role, family: info.family || null, round: info.round ?? null, retry: !!info.retry, ok: false, model_requested: MODEL, model_reported: null }
  runLog.agents.push(entry)
  if (info.retry) runLog.retries++
  const res = await agent(prompt, { label: opts.label, phase: opts.phase, schema: opts.schema, model: MODEL, effort: opts.effort })
  if (res === null || res === undefined) {
    runLog.nulls++
    return null
  }
  entry.ok = true
  entry.model_reported = typeof res.model === 'string' ? res.model : null
  return res
}

/** Run once; on null retry once at half scope. Returns the result, null after two nulls, or {__capped}. */
async function withRetry(makePrompt, opts, info) {
  const first = await call(makePrompt(false), opts, info)
  if (first !== null) return first
  log(`${opts.label}: returned nothing; retrying once at half scope`)
  return call(makePrompt(true), { ...opts, label: `${opts.label} retry` }, { ...info, retry: true })
}
const capped = (r) => !!(r && r.__capped)

// ─── state ───

const fam = {} // family -> state
const seen = new Map() // judge issue id -> {family, lens, opened, status}
const pending = { issues: [], updates: [] } // ledger items not yet recorded
let lastRound = START_ROUND - 1

function unreviewed(f, part, n, summary) {
  const st = fam[f]
  st.unreviewed.push(part)
  pending.issues.push({
    family: f, check_id: `definition:unreviewed ${part}`, row_key: null, side: null, lens: 'orchestrator',
    judge_file: '(none)', round: n, severity: 'blocking', status: 'unreviewed', summary,
  })
}
function stop(f, status, reason, n) {
  const st = fam[f]
  if (st.status !== 'active') return
  st.status = status
  st.stop_reason = reason
  st.stop_round = n
  log(`${f}: stopped at round ${n}: ${status} (${reason})`)
}
function runSummary() {
  const families = {}
  for (const f of Object.keys(fam).sort()) {
    const s = fam[f]
    families[f] = {
      status: s.status, stop_reason: s.stop_reason, rounds: s.rounds, searches: { ...s.searches },
      blocking_open: s.end, unreviewed: [...s.unreviewed].sort(),
    }
  }
  return {
    batch: BATCH, started_at: STARTED_AT, max_rounds: MAX_ROUNDS, agent_cap: AGENT_CAP,
    agents_run: runLog.agents.length, retries: runLog.retries, nulls: runLog.nulls, capped: runLog.capped,
    families, agents: runLog.agents.map((a) => ({ ...a })), left: [...runLog.left].sort(),
  }
}

// ─── setup ───

phase('Setup')
const setup = await withRetry(setupPrompt, { label: `setup ${BATCH}`, phase: 'Setup', schema: SETUP_SCHEMA, effort: 'medium' }, { role: 'runner' })
if (!setup || capped(setup)) {
  log(`setup for ${BATCH} returned nothing twice; nothing was run`)
  return { batch: BATCH, error: 'setup failed', agents_run: runLog.agents.length }
}
const FAMILIES = [...setup.families].sort((a, b) => (a.family < b.family ? -1 : 1))
if (!FAMILIES.length) return { batch: BATCH, error: 'no families for this batch', agents_run: runLog.agents.length }
const byName = Object.fromEntries(FAMILIES.map((f) => [f.family, f]))
for (const f of FAMILIES) {
  fam[f.family] = { status: 'active', stop_reason: null, stop_round: null, rounds: 0, start: null, end: null, failing: null, searches: { author: 0, verifier: 0, fixer: 0, judges: 0 }, unreviewed: [], checkOk: false }
}
for (const x of setup.existing_issues || []) {
  if (!byName[x.family]) continue
  seen.set(x.id, { family: x.family, lens: x.lens, opened: x.opened, status: x.status })
}
for (const f of [...(setup.inputs_missing || [])].sort()) {
  if (!fam[f]) continue
  unreviewed(f, 'inputs', START_ROUND, `docs/signoff/work/inputs/${f}.json is missing; the family could not be authored`)
  stop(f, 'blocked', 'inputs missing', START_ROUND)
  runLog.left.push(`${f}: whole loop (inputs file missing)`)
}
log(`${BATCH}: ${FAMILIES.length} families (${FAMILIES.map((f) => f.family).join(', ')}); ${seen.size} judge issues already in the ledgers; round limit ${MAX_ROUNDS}; agent cap ${AGENT_CAP}`)

// ─── per-family stages ───

/** Author or verifier with validation and one repair pass. Returns true when the file is valid. */
async function authorLike(kind, f, n) {
  const st = fam[f.family]
  const isAuthor = kind === 'research'
  const role = isAuthor ? 'author' : 'verifier'
  const ph = isAuthor ? 'Author' : 'Verify'
  const cap = isAuthor ? CAP_AUTHOR : CAP_VERIFIER
  const file = `${W}/${kind}/${f.family}.json`
  const r = await withRetry((half) => (isAuthor ? authorPrompt(f, half) : verifierPrompt(f, half)), { label: `${role} ${f.family} r${n}`, phase: ph, schema: FILE_SCHEMA, effort: 'max' }, { role, family: f.family, round: n })
  if (capped(r)) { runLog.left.push(`${f.family}: ${role} round ${n} (agent cap)`); stop(f.family, 'stopped', 'agent cap', n); return false }
  if (!r) {
    unreviewed(f.family, role, n, `the ${role} returned nothing twice in round ${n}; ${file} is unreviewed`)
    stop(f.family, 'unreviewed', `${role} returned nothing twice`, n)
    return false
  }
  st.searches[role] += r.searches_used || 0
  if (r.valid) return true
  const fix = await call(repairPrompt(kind, f, file, r.errors || [], cap), { label: `${role}-repair ${f.family} r${n}`, phase: ph, schema: FILE_SCHEMA, effort: 'max' }, { role: `${role}-repair`, family: f.family, round: n })
  if (capped(fix)) { runLog.left.push(`${f.family}: ${role} repair round ${n} (agent cap)`); stop(f.family, 'stopped', 'agent cap', n); return false }
  if (fix) st.searches[role] += fix.searches_used || 0
  if (fix && fix.valid) return true
  unreviewed(f.family, `${role} rejected`, n, `${file} failed validation after one repair pass in round ${n}: ${((fix && fix.errors) || r.errors || []).slice(0, 5).join('; ')}`)
  stop(f.family, 'rejected', `${kind} file invalid after one repair pass`, n)
  return false
}

async function fixStage(f, n) {
  const st = fam[f.family]
  if (st.end === 0) return true // nothing confirmed or failing: no fixer this round (null = unknown, e.g. start_round > 1: run it)
  const file = `${W}/decisions/${f.family}.json`
  const r = await withRetry((half) => fixerPrompt(f, n, half), { label: `fixer ${f.family} r${n}`, phase: 'Fix', schema: FILE_SCHEMA, effort: 'max' }, { role: 'fixer', family: f.family, round: n })
  if (capped(r)) { runLog.left.push(`${f.family}: fixer round ${n} (agent cap)`); stop(f.family, 'stopped', 'agent cap', n); return false }
  if (!r) {
    unreviewed(f.family, `fixer r${n}`, n, `the fixer returned nothing twice in round ${n}; the confirmed issues stay open`)
    stop(f.family, 'unreviewed', 'fixer returned nothing twice', n)
    return false
  }
  st.searches.fixer += r.searches_used || 0
  if (r.valid) return true
  const fix = await call(repairPrompt('decision', f, file, r.errors || [], CAP_FIXER), { label: `fixer-repair ${f.family} r${n}`, phase: 'Fix', schema: FILE_SCHEMA, effort: 'max' }, { role: 'fixer-repair', family: f.family, round: n })
  if (capped(fix)) { runLog.left.push(`${f.family}: fixer repair round ${n} (agent cap)`); stop(f.family, 'stopped', 'agent cap', n); return false }
  if (fix) st.searches.fixer += fix.searches_used || 0
  if (fix && fix.valid) return true
  unreviewed(f.family, `fixer rejected r${n}`, n, `${file} failed validation after one repair pass in round ${n}; it must not be compiled until fixed`)
  stop(f.family, 'rejected', 'decision file invalid after one repair pass', n)
  return false
}

async function checkStage(f, n) {
  const st = fam[f.family]
  const r = await withRetry((half) => checkPrompt(f, n, half), { label: `check ${f.family} r${n}`, phase: 'Check', schema: CHECK_SCHEMA, effort: 'medium' }, { role: 'runner', family: f.family, round: n })
  if (capped(r)) { runLog.left.push(`${f.family}: checks round ${n} (agent cap)`); stop(f.family, 'stopped', 'agent cap', n); return false }
  if (!r) {
    unreviewed(f.family, `checks r${n}`, n, `the check runner returned nothing twice in round ${n}`)
    stop(f.family, 'unreviewed', 'check runner returned nothing twice', n)
    return false
  }
  if (!r.ownership_ok) {
    const outside = [...(r.outside_paths || [])].sort()
    log(`${f.family} r${n}: paths outside the ownership map: ${outside.slice(0, 10).join(', ')}${outside.length > 10 ? ` and ${outside.length - 10} more` : ''}`)
    pending.issues.push({
      family: f.family, check_id: 'G1', row_key: null, side: null, lens: 'orchestrator', judge_file: `${W}/checks/${BATCH}-r${n}-changes.json`,
      round: n, severity: 'blocking', summary: `round ${n}: ${outside.length} changed paths outside the ownership map: ${outside.slice(0, 5).join(', ')}`,
    })
  }
  if (!r.compile_ok || !r.checks_file) {
    unreviewed(f.family, `compile r${n}`, n, `the compile or the checks failed in round ${n}: ${(r.errors || []).slice(0, 3).join('; ')}`)
    stop(f.family, 'unreviewed', 'compile or checks failed', n)
    return false
  }
  st.failing = r.failing_count
  st.checkOk = true
  log(`${f.family} r${n}: ${r.failing_count} attributable check failures (${(r.failing || []).map((c) => `${c.check} ${c.count}`).join(', ') || 'none'}); blocked ${(r.blocked_checks || []).length}`)
  return true
}

// ─── rounds ───

for (let n = START_ROUND; n <= MAX_ROUNDS; n++) {
  const active = FAMILIES.filter((f) => fam[f.family].status === 'active')
  if (!active.length) break
  if (runLog.capped) break
  lastRound = n
  for (const f of active) { fam[f.family].rounds = n - START_ROUND + 1; fam[f.family].checkOk = false; fam[f.family].start = fam[f.family].end }
  log(`round ${n}: ${active.length} active families`)

  // 1-4: author or fix, validate, verify, compile and check, per family as a pipeline
  await pipeline(
    active,
    async (f) => (n === START_ROUND && START_ROUND === 1 ? authorLike('research', f, n) : fixStage(f, n)),
    async (ok, f) => (ok && n === START_ROUND && START_ROUND === 1 ? authorLike('verify', f, n) : ok),
    async (ok, f) => (ok ? checkStage(f, n) : false),
  )

  // 5: judges over the families that checked cleanly (barrier: the judges read the batch compile)
  const judgeable = FAMILIES.filter((f) => fam[f.family].status === 'active' && fam[f.family].checkOk).map((f) => f.family)
  const fresh = []
  const minors = []
  const raised = new Set()
  const judgedOk = {} // family -> Set(lens)
  for (const f of judgeable) judgedOk[f] = new Set()
  if (judgeable.length) {
    const shards = []
    for (let i = 0; i < judgeable.length; i += SHARD_MAX) {
      const part = judgeable.slice(i, i + SHARD_MAX)
      shards.push({ name: shardName(part), families: part })
    }
    const prep = await withRetry(() => prepPrompt(n, shards, judgeable), { label: `judge-prep ${BATCH} r${n}`, phase: 'Judge', schema: PREP_SCHEMA, effort: 'medium' }, { role: 'runner', round: n })
    if (!prep || capped(prep) || !prep.compile_ok) {
      for (const f of judgeable) {
        if (capped(prep)) runLog.left.push(`${f}: judges round ${n} (agent cap)`)
        else unreviewed(f, `judges r${n}`, n, `the batch compile for the judges failed in round ${n}`)
      }
      log(`round ${n}: judge preparation failed; no judges ran`)
    } else {
      const jobs = []
      for (const s of shards) for (const lens of LENSES) jobs.push({ shard: s, lens })
      const results = await parallel(jobs.map((j) => async () => {
        const first = await call(judgePrompt(j.lens, n, j.shard.name, j.shard.families, false), { label: `judge ${j.lens} ${j.shard.name} r${n}`, phase: 'Judge', schema: JUDGE_SCHEMA, effort: 'max' }, { role: 'judge', family: j.shard.families.join('+'), round: n })
        if (first !== null) return { job: j, families: j.shard.families, res: first }
        const halfFams = j.shard.families.slice(0, Math.ceil(j.shard.families.length / 2))
        const dropped = j.shard.families.slice(halfFams.length)
        log(`judge ${j.lens} ${j.shard.name} r${n}: returned nothing; retrying over ${halfFams.join(', ')}${dropped.length ? `; ${dropped.join(', ')} unreviewed by ${j.lens}` : ''}`)
        const second = await call(judgePrompt(j.lens, n, shardName(halfFams), halfFams, true), { label: `judge ${j.lens} ${shardName(halfFams)} r${n} retry`, phase: 'Judge', schema: JUDGE_SCHEMA, effort: 'max' }, { role: 'judge', family: halfFams.join('+'), round: n, retry: true })
        return { job: j, families: halfFams, dropped, res: second }
      }))
      for (const out of results.filter(Boolean).sort((a, b) => (a.job.lens + a.job.shard.name < b.job.lens + b.job.shard.name ? -1 : 1))) {
        const { job, families, res } = out
        const lost = res === null || capped(res) || !res.valid
        const notCovered = lost ? job.shard.families : (out.dropped || [])
        for (const f of notCovered) {
          if (capped(res)) runLog.left.push(`${f}: judge ${job.lens} round ${n} (agent cap)`)
          else unreviewed(f, `${job.lens.toLowerCase()} r${n}`, n, `judge ${job.lens} ${res && !capped(res) && !res.valid ? 'wrote an invalid file' : 'returned nothing twice'} in round ${n}; the family is unreviewed by this lens`)
        }
        if (lost) continue
        for (const f of families) if (judgedOk[f]) judgedOk[f].add(job.lens)
        fam[families[0]].searches.judges += res.searches_used || 0
        const take = (list, severity) => {
          for (const it of list || []) {
            if (!families.includes(it.family)) { log(`judge ${job.lens} r${n}: issue on ${it.family} outside its shard ignored`); continue }
            const id = issueId(it.family, it.check_id, it.row_key, it.side)
            if (severity === 'blocking') raised.add(id)
            if (seen.has(id)) continue // deduplicated against every issue seen, not only confirmed ones
            seen.set(id, { family: it.family, lens: job.lens, opened: n, status: 'open' })
            const item = { id, family: it.family, check_id: it.check_id, row_key: it.row_key, side: it.side, lens: job.lens, judge_file: res.file, round: n, severity, summary: it.summary, evidence_paths: [res.file] }
            if (severity === 'blocking') fresh.push(item)
            else minors.push(item)
          }
        }
        take(res.blocking, 'blocking')
        take(res.minor, 'minor')
      }
    }
  }
  log(`round ${n}: ${fresh.length} new blocking issues, ${minors.length} new minor issues, ${raised.size} blocking raised in all`)

  // 6: two refuters per new blocking issue, default refuted; outcome decided in code
  fresh.sort((a, b) => (a.id < b.id ? -1 : 1))
  const outcomes = await pipeline(fresh, async (issue) => {
    const verdicts = await parallel(['a', 'b'].map((side) => async () => {
      const r = await withRetry((half) => refuterPrompt(side, issue, n, half), { label: `refuter-${side} ${issue.id} r${n}`, phase: 'Refute', schema: REFUTE_SCHEMA, effort: 'max' }, { role: 'refuter', family: issue.family, round: n })
      if (capped(r)) return 'capped'
      return r && r.valid ? r.verdict : null
    }))
    const [va, vb] = verdicts
    let status
    if (va === 'capped' || vb === 'capped') status = 'capped'
    else if (va !== 'confirmed' && va !== 'refuted') status = 'unreviewed'
    else if (vb !== 'confirmed' && vb !== 'refuted') status = 'unreviewed'
    else if (va === 'confirmed' && vb === 'confirmed') status = 'confirmed'
    else if (va === 'refuted' && vb === 'refuted') status = 'refuted'
    else status = 'disputed'
    return { issue, status }
  })
  for (const o of outcomes.filter(Boolean)) {
    const { issue, status } = o
    pending.issues.push(issue)
    if (status === 'capped') {
      runLog.left.push(`${issue.family}: refutation of ${issue.id} round ${n} (agent cap)`)
      pending.updates.push({ id: issue.id, family: issue.family, status: 'unreviewed', round: n, resolution: 'not refuted: agent cap reached' })
      seen.get(issue.id).status = 'unreviewed'
      continue
    }
    // the ledger tool reads the two refutation files and sets the state they give
    pending.updates.push({ id: issue.id, family: issue.family, from_refutations: n, round: n })
    seen.get(issue.id).status = status
  }
  for (const m of minors) pending.issues.push(m)

  // closing: a confirmed issue the raising lens did not raise again after a fix round is closed by that lens
  for (const [id, x] of [...seen.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1))) {
    if (x.status !== 'confirmed' || !judgedOk[x.family] || x.opened >= n) continue
    if (!judgedOk[x.family].has(x.lens) || raised.has(id)) continue
    x.status = 'closed'
    pending.updates.push({ id, family: x.family, status: 'closed', round: n, closed_by: `${x.lens} round ${n}`, resolution: `not raised again by ${x.lens} in round ${n}, after the fix of round ${n}` })
  }

  // 7: the ledger, written by ledger.js; the stop rules use its counts
  const payload = { round: n, issues: pending.issues.map((x) => ({ ...x })), updates: pending.updates.map((x) => ({ ...x })), count_families: FAMILIES.map((f) => f.family) }
  phase('Ledger')
  const led = await withRetry((half) => ledgerPrompt(n, payload, runSummary(), half), { label: `ledger ${BATCH} r${n}`, phase: 'Ledger', schema: LEDGER_SCHEMA, effort: 'medium' }, { role: 'runner', round: n })
  const counts = {}
  if (led && !capped(led) && (led.errors || []).length) log(`ledger round ${n}: ${led.errors.length} errors: ${led.errors.slice(0, 5).join('; ')}`)
  if (led && !capped(led) && led.ok) {
    pending.issues = []
    pending.updates = []
    for (const c of led.counts || []) counts[c.family] = c
  } else {
    log(`ledger round ${n}: ${capped(led) ? 'agent cap' : 'not recorded'}; its items are carried to the next ledger run; stop rules use the in-script counts`)
    if (capped(led)) runLog.left.push(`ledger round ${n} (agent cap)`)
  }

  // stop rules, per family (LOOP-PROMPT.md section 1)
  for (const f of FAMILIES.map((x) => x.family)) {
    const st = fam[f]
    if (st.status !== 'active') continue
    const confirmedHere = [...seen.values()].filter((x) => x.family === f && x.status === 'confirmed').length
    st.end = counts[f] ? counts[f].blocking_open : confirmedHere + (st.failing || 0)
    if (runLog.capped) { stop(f, 'stopped', 'agent cap', n); runLog.left.push(`${f}: rounds after ${n} (agent cap)`); continue }
    if (st.end === 0) {
      if (st.unreviewed.length) stop(f, 'incomplete', `checks green and no confirmed issue, but unreviewed: ${[...st.unreviewed].sort().join(', ')}`, n)
      else stop(f, 'pass', 'checks green or blocked, no confirmed blocking issue', n)
      continue
    }
    if (n >= MAX_ROUNDS) { stop(f, 'open', `round limit ${MAX_ROUNDS}`, n); continue }
    if (st.start !== null && st.end >= st.start) { stop(f, 'open', `no net progress: ${st.start} blocking at the start of round ${n}, ${st.end} at its end`, n); continue }
    log(`${f}: round ${n} ends with ${st.end} blocking (started with ${st.start === null ? 'none known' : st.start})`)
  }
}

for (const f of FAMILIES.map((x) => x.family)) {
  if (fam[f].status === 'active') stop(f, 'open', runLog.capped ? 'agent cap' : `round limit ${MAX_ROUNDS}`, lastRound)
}
if (runLog.capped) log(`agent cap ${AGENT_CAP} reached; left undone: ${[...runLog.left].sort().join('; ')}`)

// 8: finalize the ledgers and write the scorecard
phase('Scorecard')
const stops = FAMILIES.map((x) => x.family).map((f) => ({ family: f, round: fam[f].stop_round ?? lastRound, reason: `${fam[f].status}: ${fam[f].stop_reason}`.replace(/"/g, "'") }))
let finalPayloadNote = null
if (pending.issues.length || pending.updates.length) {
  // a ledger run failed earlier: record its items before finalizing
  const payload = { round: lastRound, issues: pending.issues, updates: pending.updates, count_families: FAMILIES.map((f) => f.family) }
  const led = await call(ledgerPrompt(lastRound, payload, runSummary(), false), { label: `ledger ${BATCH} final`, phase: 'Scorecard', schema: LEDGER_SCHEMA, effort: 'medium' }, { role: 'runner', round: lastRound, final: true })
  if (led && !capped(led) && led.ok) { pending.issues = []; pending.updates = [] } else finalPayloadNote = 'ledger items of the last round were not recorded'
}
const fin = await withRetry((half) => finalPrompt(stops, runSummary(), half), { label: `scorecard ${BATCH}`, phase: 'Scorecard', schema: FINAL_SCHEMA, effort: 'medium' }, { role: 'runner', round: lastRound, final: true })
if (!fin || capped(fin)) log(`the final runner returned nothing; run the finalize and scorecard commands by hand (README)`)

const summary = runSummary()
return {
  batch: BATCH,
  started_at: STARTED_AT,
  rounds_run: lastRound - START_ROUND + 1,
  families: summary.families,
  agents_run: summary.agents_run,
  retries: summary.retries,
  nulls: summary.nulls,
  capped: summary.capped,
  left: summary.left,
  unrecorded_ledger_items: pending.issues.length + pending.updates.length,
  note: finalPayloadNote,
  scorecard: fin && !capped(fin) ? fin.scorecard_file : null,
  scorecard_errors: fin && !capped(fin) ? fin.errors : ['final runner returned nothing'],
}
