import sys, re
import xml.etree.ElementTree as ET
src = sys.argv[1]
out = sys.argv[2]
data = open(src, 'rb').read()
try:
    root = ET.fromstring(data)
    def walk(el, depth=0):
        parts = []
        tag = el.tag if isinstance(el.tag, str) else ''
        block = tag in ('p','title','article-title','label','caption','td','th','tr','sec','abstract','fn','ref','table-wrap','fig','kwd','aff','contrib','notes','ack','list-item')
        if el.text:
            parts.append(el.text)
        for ch in el:
            parts.append(walk(ch, depth+1))
            if ch.tail:
                parts.append(ch.tail)
        s = ''.join(parts)
        if tag in ('td','th'):
            s = s + ' | '
        elif block:
            s = '\n' + s + '\n'
        return s
    txt = walk(root)
except Exception as e:
    txt = re.sub(r'<[^>]+>', ' ', data.decode('utf-8', 'replace'))
txt = re.sub(r'[ \t]+', ' ', txt)
txt = re.sub(r'\n\s*\n+', '\n\n', txt)
open(out, 'w').write(txt)
print(len(txt))
