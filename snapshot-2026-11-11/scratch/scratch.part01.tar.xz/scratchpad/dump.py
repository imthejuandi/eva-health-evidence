import json, re, sys
REPO='/home/user/eva-health/'
KEYS={'f12_white_cells_core':["white_blood_cell_count","neutrophils_absolute","lymphocytes_absolute","nlr","neutrophils","lymphocytes"],
'f13_white_cells_other':["monocytes_absolute","eosinophils_absolute","basophils_absolute","monocytes","eosinophils","basophils"],
'f14_iron':["ferritin","iron_serum","iron_saturation_tsat","iron_binding_capacity_tibc"]}
fam_of={k:f for f,v in KEYS.items() for k in v}
def slug(n):
    n=n.lower(); n=re.sub(r'[()]','',n); n=re.sub(r'[^a-z0-9]+','_',n); return n.strip('_')
def rows_with_lines(fn, arrkey):
    p=REPO+'docs/signoff/work/compiled/B05-r1/'+fn
    lines=open(p).read().split('\n')
    d=json.load(open(p))
    rows=d[arrkey]
    # find start lines of row objects: lines exactly '    {' after the array key
    starts=[]
    in_arr=False
    for i,l in enumerate(lines):
        if l.startswith('  "%s"'%arrkey): in_arr=True; continue
        if in_arr and l=='    {': starts.append(i+1)
        if in_arr and l.startswith('  ]'): break
    assert len(starts)==len(rows), (len(starts),len(rows))
    out=[]
    for r,s in zip(rows,starts):
        # field line numbers
        fl={}
        j=s
        while j<len(lines) and lines[j-1]!='    }' and lines[j-1]!='    },':
            m=re.match(r'\s+"([^"]+)":',lines[j-1])
            if m: fl.setdefault(m.group(1),j)
            j+=1
        out.append((r,s,fl))
    return out
en=rows_with_lines('biomarker-ranges-en.json','biomarker_ranges')
es=rows_with_lines('rangos-biomarcadores-es.json','rangos_biomarcadores')
which=sys.argv[1] if len(sys.argv)>1 else None
for idx,((r,s,fl),(re_,se,fle)) in enumerate(zip(en,es)):
    k=slug(r['Biomarker'])
    if k not in fam_of: continue
    if which and fam_of[k]!=which: continue
    state=(r.get('State') or 'none')
    rk='%s|%s|%s|%s'%(k,r['Sex'].lower(),r['Age_Group'],state.lower() if state else 'none')
    print('='*100)
    print('IDX',idx,'ROWKEY',rk,'EN line',s,'ES line',se)
    for f,v in r.items():
        print('  EN %-22s L%-6s %s'%(f,fl.get(f),json.dumps(v,ensure_ascii=False)))
    for f,v in re_.items():
        print('  ES %-22s L%-6s %s'%(f,fle.get(f),json.dumps(v,ensure_ascii=False)))
