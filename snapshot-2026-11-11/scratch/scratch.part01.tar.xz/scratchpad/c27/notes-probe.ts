import { loadSeed } from "/home/user/eva-health/scripts/signoff/lib/seed";
import { extractNumbers } from "/home/user/eva-health/scripts/signoff/lib/format";
function main() {
  const seed = loadSeed(process.argv[2])!;
  let notes = 0, withNums = 0, bad = 0;
  const ex: string[] = [];
  for (const r of seed.rows) {
    const bounds = new Set([r.normal_low, r.normal_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high, ...r.explanatory_numbers].filter((b): b is number => b != null));
    for (const [lang, t] of [["en", r.clinical_notes_en], ["es", r.clinical_notes_es]] as const) {
      if (!t) continue;
      notes++;
      const nums = extractNumbers(t, lang);
      if (nums.length) withNums++;
      const b = nums.filter((n) => ![...bounds].some((x) => Math.abs(x - n) < 1e-9));
      if (b.length) { bad++; if (ex.length < 12) ex.push(`${r.biomarker_key}|${r.sex}|${r.age_group_en}|${lang}: [${[...new Set(b)].join(", ")}] in "${t.slice(0, 110)}"`); }
    }
  }
  console.log(JSON.stringify({ rows: seed.rows.length, notes, withNums, notesWithNonBoundNumbers: bad }));
  for (const e of ex) console.log(e);
}
main();
