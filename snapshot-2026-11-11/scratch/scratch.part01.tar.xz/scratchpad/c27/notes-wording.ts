import fs from "node:fs";
import { loadSeed } from "/home/user/eva-health/scripts/signoff/lib/seed";
import { parseLexicon, lexiconHits } from "/home/user/eva-health/scripts/signoff/checks/messages";
function main() {
  const seed = loadSeed(process.argv[2])!;
  const lex = parseLexicon(fs.readFileSync("/home/user/eva-health/docs/signoff/work/governance/wording-rules.md", "utf8"))!;
  let hits = 0;
  for (const r of seed.rows) for (const [lang, t] of [["en", r.clinical_notes_en], ["es", r.clinical_notes_es]] as const) {
    if (!t) continue;
    const rules = ["any", "non_critical"].map((x) => lex.langs[lang]?.[x]).filter((x): x is NonNullable<typeof x> => !!x);
    const h = lexiconHits(t, rules, lex.flags);
    if (h.length) { hits++; console.log(`${r.biomarker_key}|${r.sex}|${r.age_group_en}|${lang}: ${h.join(", ")}`); }
  }
  console.log("notes with hits:", hits);
}
main();
