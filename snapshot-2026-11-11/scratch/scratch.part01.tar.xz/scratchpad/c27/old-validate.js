#!/usr/bin/env node
// Validate a sign-off loop file against its schema and the semantic rules.
// Usage: node docs/signoff/tools/validate.js <research|verify|decision|judge|refutation|ledger> <family-or-path> [--families <families.json>] [--work-dir <dir>] [--quiet]
// A family name resolves to docs/signoff/work/<research|verify|decisions|ledger>/<family>.json (or under --work-dir
// for a scratch copy); the sibling research, verify and ledger files of the same family are read for cross-checks.
// Exit 0 when valid; errors are printed one per line to stdout, warnings prefixed "warn:".
"use strict";
const fs = require("fs");
const path = require("path");
const { validateAgainst } = require("./lib/schema-validator");
const checks = require("./lib/row-checks");

const KINDS = ["research", "verify", "decision", "judge", "refutation", "ledger"];
const WORK = path.join(__dirname, "..", "work");
const DIRS = { research: "research", verify: "verify", decision: "decisions", judge: "judges", refutation: "refutations", ledger: "ledger" };

function resolveTarget(kind, arg, workDir = WORK) {
  if (fs.existsSync(arg)) return path.resolve(arg);
  return path.join(workDir, DIRS[kind], arg.endsWith(".json") ? arg : `${arg}.json`);
}

function sha256File(file) {
  return require("crypto").createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function familyOf(doc, file) {
  if (doc && typeof doc.family === "string") return doc.family;
  const m = path.basename(file).match(/(f\d{2}_[a-z0-9_]+)/);
  return m ? m[1] : null;
}

/** Validate one file. Returns { errors, warnings }. */
function validateFile(kind, file, opts = {}) {
  const errors = [], warnings = [];
  if (!KINDS.includes(kind)) return { errors: [`unknown kind '${kind}'; expected ${KINDS.join("|")}`], warnings };
  if (!fs.existsSync(file)) return { errors: [`file not found: ${file}`], warnings };
  let doc;
  try { doc = JSON.parse(fs.readFileSync(file, "utf8")); } catch (e) { return { errors: [`invalid JSON: ${e.message}`], warnings }; }
  const schemaErrors = validateAgainst(kind, doc);
  errors.push(...schemaErrors.map((e) => `schema ${e}`));
  if (schemaErrors.length) return { errors, warnings, doc }; // semantic checks assume the shape
  const families = opts.families === null ? null : checks.loadFamilies(opts.families);
  const family = familyOf(doc, file);
  const workDir = opts.workDir || WORK;
  if (kind === "research") semanticResearch(doc, family, families, errors, warnings);
  else if (kind === "verify") semanticVerify(doc, family, families, errors, warnings, workDir);
  else if (kind === "decision") semanticDecision(doc, family, families, errors, warnings, workDir);
  else if (kind === "judge") semanticJudge(doc, errors, warnings);
  else if (kind === "ledger") semanticLedger(doc, errors, warnings);
  return { errors: [...new Set(errors)], warnings: [...new Set(warnings)], doc };
}

// The optional Spanish counterparts and clinical notes of a row (common.schema.json row): a Spanish text needs the
// English text it translates; the two clinical notes come together, both with text or both null; and a note follows
// the rule row-checks.js applies to the messages, that critical-tier wording appears only in the critical tier.
const ES_COUNTERPARTS = [["unit", "unit_es"], ["reference_source", "reference_source_es"], ["critical_none_reason", "critical_none_reason_es"], ["method_note", "method_note_es"]];
const CRITICAL_WORDING = /prompt medical attention|atenci[oó]n m[eé]dica (inmediata|urgente)|\bemergenc|\bimmediate\b|\binmediat|\bcritical\b|\bcr[ií]tic/i;
const hasText = (v) => typeof v === "string" && v.trim() !== "";
function checkSpanishText(rows, p, errors) {
  rows.forEach((r, i) => {
    const e = (m) => errors.push(`${p}[${i}] (${checks.rowKey(r)}): ${m}`);
    for (const [en, es] of ES_COUNTERPARTS) if (hasText(r[es]) && !hasText(r[en])) e(`${es} is given but ${en} is empty`);
    const [ne, ns] = [r.clinical_notes_en, r.clinical_notes_es];
    if ((ne === undefined) !== (ns === undefined)) e(`clinical_notes_en and clinical_notes_es go together; ${ne === undefined ? "clinical_notes_en" : "clinical_notes_es"} is missing`);
    else if (hasText(ne) !== hasText(ns)) e(`clinical note in one language only (${hasText(ne) ? "clinical_notes_es" : "clinical_notes_en"} is empty)`);
    for (const f of ["clinical_notes_en", "clinical_notes_es"]) if (hasText(r[f]) && CRITICAL_WORDING.test(r[f])) e(`${f} uses critical-tier wording`);
  });
}

function semanticResearch(doc, family, families, errors, warnings) {
  const rowKeys = checks.checkRowSet(doc.rows, "rows", errors, warnings);
  checkSpanishText(doc.rows, "rows", errors);
  checks.checkFamilyKeys(family, doc.rows, "rows", errors, families);
  const ids = checks.checkEvidence(doc.evidence, rowKeys, "evidence", errors, warnings);
  checks.checkBoundCoverage(doc.rows, doc.evidence, "rows", errors);
  checks.checkProposedGrades(doc.rows, doc.evidence, "rows", errors);
  checks.checkAgeSplits(doc.rows, doc.age_splits, "age_splits", errors);
  checks.checkV3(family, doc.rows, doc.v3_consistency, "v3_consistency", errors, families);
  doc.age_splits.forEach((s, i) => checks.checkIdRefs(s.evidence_ids, ids, `age_splits[${i}]`, errors));
  doc.v3_consistency.forEach((s, i) => checks.checkIdRefs(s.evidence_ids, ids, `v3_consistency[${i}]`, errors));
  doc.locked_decision_questions.forEach((q, i) => { checks.checkIdRefs(q.evidence_ids, ids, `locked_decision_questions[${i}]`, errors); if (!q.evidence_ids.length) errors.push(`locked_decision_questions[${i}]: a locked-decision question needs evidence ids`); });
  doc.physician_questions.forEach((q, i) => { checks.checkIdRefs(q.evidence_ids, ids, `physician_questions[${i}]`, errors); if (q.row_key && !rowKeys.has(q.row_key)) errors.push(`physician_questions[${i}]: unknown row ${q.row_key}`); });
  doc.rows.forEach((r, i) => { for (const a of r.action_limits) checks.checkIdRefs(a.evidence_ids, ids, `rows[${i}].action_limits`, errors); for (const pr of r.pre_analytical) checks.checkIdRefs(pr.evidence_ids, ids, `rows[${i}].pre_analytical`, errors); });
  for (const id of doc.unverified_sources || []) if (!ids.has(id)) errors.push(`unverified_sources: unknown evidence id '${id}'`);
  doc.rows.forEach((r, i) => { if (r.grade !== undefined) errors.push(`rows[${i}]: research rows carry no grade; the verifier assigns it`); });
}

function loadSibling(workDir, dir, family) {
  const file = path.join(workDir, dir, `${family}.json`);
  if (!family || !fs.existsSync(file)) return null;
  try { return { doc: JSON.parse(fs.readFileSync(file, "utf8")), file }; } catch { return null; }
}

function semanticVerify(doc, family, families, errors, warnings, workDir) {
  const rowKeys = checks.checkRowSet(doc.final_rows, "final_rows", errors, warnings);
  checkSpanishText(doc.final_rows, "final_rows", errors);
  checks.checkFamilyKeys(family, doc.final_rows, "final_rows", errors, families);
  const research = loadSibling(workDir, "research", family);
  const researchIds = new Set((research?.doc?.evidence || []).map((e) => e.id));
  const ownIds = checks.checkEvidence(doc.evidence, rowKeys, "evidence", errors, warnings);
  const all = new Set([...researchIds, ...ownIds]);
  for (const id of ownIds) if (researchIds.has(id)) errors.push(`evidence: id '${id}' already exists in the research file`);
  const allRecords = [...(research?.doc?.evidence || []), ...doc.evidence];
  checks.checkBoundCoverage(doc.final_rows, allRecords, "final_rows", errors);
  checks.checkV3(family, doc.final_rows, research?.doc?.v3_consistency || [], "research.v3_consistency", research ? errors : [], families);
  // Verdicts cover every research row and record, and name only known ones
  if (research) {
    if (doc.research_sha256 !== sha256File(research.file)) warnings.push(`research_sha256 does not match ${path.relative(process.cwd(), research.file)} (file changed after verification?)`);
    const rkeys = new Set((research.doc.rows || []).map(checks.rowKey));
    const verdictKeys = new Set(doc.row_verdicts.map((v) => v.row_key));
    for (const k of [...rkeys].sort()) if (!verdictKeys.has(k)) errors.push(`row_verdicts: no verdict for research row ${k}`);
    for (const k of [...verdictKeys].sort()) if (!rkeys.has(k)) errors.push(`row_verdicts: verdict for unknown research row ${k}`);
    const evKeys = new Set(doc.evidence_verdicts.map((v) => v.evidence_id));
    for (const id of [...researchIds].sort()) if (!evKeys.has(id)) errors.push(`evidence_verdicts: no verdict for evidence ${id}`);
    for (const id of [...evKeys].sort()) if (!researchIds.has(id)) errors.push(`evidence_verdicts: verdict for unknown evidence ${id}`);
    const byRow = new Map(doc.row_verdicts.map((v) => [v.row_key, v]));
    const researchRows = new Map((research.doc.rows || []).map((r) => [checks.rowKey(r), r]));
    doc.final_rows.forEach((r, i) => {
      const k = checks.rowKey(r);
      const v = byRow.get(k);
      if (v && v.grade !== r.grade) errors.push(`final_rows[${i}] (${k}): grade ${r.grade} differs from row_verdicts grade ${v.grade}`);
      const orig = researchRows.get(k);
      if (orig && v && v.verdict === "confirmed") {
        for (const f of ["reference_low", "reference_high", "optimal_low", "optimal_high", "critical_low", "critical_high"]) if ((orig[f] ?? null) !== (r[f] ?? null)) errors.push(`final_rows[${i}] (${k}): ${f} differs from research but the row verdict is 'confirmed'`);
      }
      if (orig && v && v.verdict === "refuted" && (r.optimal_low != null || r.optimal_high != null)) warnings.push(`final_rows[${i}] (${k}): row refuted but final row keeps an optimal band`);
    });
    for (const k of [...rkeys].sort()) if (!rowKeys.has(k) && byRow.get(k)?.verdict !== "refuted") errors.push(`final_rows: research row ${k} missing and not refuted`);
  } else {
    warnings.push(`research file for ${family} not found; cross-checks against research skipped`);
  }
  // Grade A/B bands need a confirmed record on the bound; unverifiable sources give grade D
  const evVerdict = new Map(doc.evidence_verdicts.map((v) => [v.evidence_id, v]));
  const support = new Map();
  for (const ev of allRecords) for (const s of ev.supports || []) (support.get(`${s.row_key}#${s.bound}`) || support.set(`${s.row_key}#${s.bound}`, []).get(`${s.row_key}#${s.bound}`)).push(ev.id);
  doc.final_rows.forEach((r, i) => {
    const k = checks.rowKey(r);
    if (!["A", "B"].includes(r.grade)) return;
    for (const b of ["optimal_low", "optimal_high"]) {
      if (r[b] == null) continue;
      const recs = support.get(`${k}#${b}`) || [];
      const ok = recs.some((id) => ownIds.has(id) || evVerdict.get(id)?.verdict === "confirmed" || evVerdict.get(id)?.verdict === "corrected");
      if (recs.length && !ok) errors.push(`final_rows[${i}] (${k}): grade ${r.grade} ${b} has no confirmed or corrected evidence record`);
    }
  });
  doc.evidence_verdicts.forEach((v, i) => { if (v.verdict === "unverifiable" && v.grade !== "D") errors.push(`evidence_verdicts[${i}] (${v.evidence_id}): an unverifiable source is grade D`); });
  doc.corrections.forEach((c, i) => { if (!rowKeys.has(c.row_key)) errors.push(`corrections[${i}]: unknown row ${c.row_key}`); checks.checkIdRefs(c.evidence_ids, all, `corrections[${i}]`, errors); });
  doc.physician_questions.forEach((q, i) => checks.checkIdRefs(q.evidence_ids, all, `physician_questions[${i}]`, errors));
}

function semanticDecision(doc, family, families, errors, warnings, workDir) {
  const rowKeys = checks.checkRowSet(doc.final_rows, "final_rows", errors, warnings);
  checkSpanishText(doc.final_rows, "final_rows", errors);
  checks.checkFamilyKeys(family, doc.final_rows, "final_rows", errors, families);
  const research = loadSibling(workDir, "research", family);
  const verify = loadSibling(workDir, "verify", family);
  const prior = [...(research?.doc?.evidence || []), ...(verify?.doc?.evidence || [])];
  const priorIds = new Set(prior.map((e) => e.id));
  const ownIds = checks.checkEvidence(doc.evidence, rowKeys, "evidence", errors, warnings);
  for (const id of ownIds) if (priorIds.has(id)) errors.push(`evidence: id '${id}' already exists in the research or verify file`);
  const all = new Set([...priorIds, ...ownIds]);
  checks.checkBoundCoverage(doc.final_rows, [...prior, ...doc.evidence], "final_rows", errors);
  if (verify) {
    if (doc.verify_sha256 !== sha256File(verify.file)) warnings.push(`verify_sha256 does not match ${path.relative(process.cwd(), verify.file)}`);
    const vrows = new Map((verify.doc.final_rows || []).map((r) => [checks.rowKey(r), r]));
    const changed = new Set(doc.changes.map((c) => `${c.row_key}#${c.field}`));
    doc.final_rows.forEach((r, i) => {
      const k = checks.rowKey(r);
      const v = vrows.get(k);
      if (!v) { if (!doc.changes.some((c) => c.row_key === k)) errors.push(`final_rows[${i}] (${k}): new row without a change record`); return; }
      for (const f of ["reference_low", "reference_high", "optimal_low", "optimal_high", "critical_low", "critical_high", "grade", "marker_class", "band_rule"]) {
        if ((v[f] ?? null) !== (r[f] ?? null) && !changed.has(`${k}#${f}`)) errors.push(`final_rows[${i}] (${k}): ${f} differs from the verify file (${JSON.stringify(v[f] ?? null)} -> ${JSON.stringify(r[f] ?? null)}) without a change record`);
      }
    });
    for (const k of [...vrows.keys()].sort()) if (!rowKeys.has(k) && !doc.changes.some((c) => c.row_key === k)) errors.push(`final_rows: verify row ${k} removed without a change record`);
  } else {
    warnings.push(`verify file for ${family} not found; cross-checks against verify skipped`);
  }
  doc.changes.forEach((c, i) => {
    checks.checkIdRefs(c.evidence_ids, all, `changes[${i}]`, errors);
    if (c.direction === "loosen" && !c.evidence_ids.length) errors.push(`changes[${i}] (${c.row_key} ${c.field}): a loosening needs a grade A or B quote (evidence_ids empty)`);
    if (c.direction === "loosen" && verify) {
      const grades = new Map((verify.doc.evidence_verdicts || []).map((v) => [v.evidence_id, v.grade]));
      const ok = c.evidence_ids.some((id) => ownIds.has(id) || ["A", "B"].includes(grades.get(id)));
      if (!ok) errors.push(`changes[${i}] (${c.row_key} ${c.field}): no cited evidence is grade A or B in the verify file`);
    }
  });
  doc.physician_questions.forEach((q, i) => checks.checkIdRefs(q.evidence_ids, all, `physician_questions[${i}]`, errors));
  const ledger = loadSibling(workDir, "ledger", family);
  if (ledger) {
    const known = new Set((ledger.doc.issues || []).map((x) => x.id));
    for (const id of doc.issues_addressed) if (!known.has(id)) errors.push(`issues_addressed: '${id}' is not in the ledger`);
  }
}

function semanticJudge(doc, errors, warnings) {
  for (const list of ["blocking", "minor"]) {
    const seen = new Set();
    doc[list].forEach((x, i) => {
      if (!doc.families_reviewed.includes(x.family)) errors.push(`${list}[${i}]: family ${x.family} is not in families_reviewed`);
      const sig = `${x.family}|${x.check_id}|${x.row_key}|${x.side ?? ""}`;
      if (seen.has(sig)) warnings.push(`${list}[${i}]: duplicate issue ${sig}`);
      seen.add(sig);
    });
  }
}

function semanticLedger(doc, errors, warnings) {
  const seen = new Set();
  doc.issues.forEach((x, i) => {
    if (seen.has(x.id)) errors.push(`issues[${i}]: duplicate issue id ${x.id}`);
    seen.add(x.id);
    if (x.family !== doc.family) errors.push(`issues[${i}]: family ${x.family} differs from ledger family ${doc.family}`);
    const closedStates = ["refuted", "fixed", "closed"];
    if (closedStates.includes(x.status) && x.rounds.closed == null) errors.push(`issues[${i}] (${x.id}): status ${x.status} but rounds.closed is null`);
    if (!closedStates.includes(x.status) && x.rounds.closed != null) errors.push(`issues[${i}] (${x.id}): rounds.closed set but status is ${x.status}`);
    if (x.rounds.closed != null && x.rounds.closed < x.rounds.opened) errors.push(`issues[${i}] (${x.id}): closed round before opened round`);
    if (x.status === "physician_question" && !x.question_id) errors.push(`issues[${i}] (${x.id}): physician_question needs question_id`);
    if (x.status === "fixed" && !x.resolution) errors.push(`issues[${i}] (${x.id}): fixed needs a resolution`);
    if (["confirmed", "disputed", "refuted"].includes(x.status) && x.refutation_paths.length < 2) errors.push(`issues[${i}] (${x.id}): ${x.status} needs two refutation paths`);
  });
  const ids = doc.issues.map((x) => x.id);
  if (ids.join() !== [...ids].sort().join()) warnings.push("issues are not sorted by id");
}

function main(argv) {
  const args = argv.filter((a) => !a.startsWith("--"));
  const quiet = argv.includes("--quiet");
  const famIdx = argv.indexOf("--families");
  const families = famIdx >= 0 ? argv[famIdx + 1] : undefined;
  const wdIdx = argv.indexOf("--work-dir");
  const workDir = wdIdx >= 0 ? path.resolve(argv[wdIdx + 1]) : undefined;
  const flagValues = new Set([families, workDir && argv[wdIdx + 1]].filter(Boolean));
  const [kind, target] = args.filter((a) => !flagValues.has(a));
  if (!kind || !target || !KINDS.includes(kind)) {
    console.log(`usage: node docs/signoff/tools/validate.js <${KINDS.join("|")}> <family-or-path> [--families <families.json>] [--work-dir <dir>] [--quiet]`);
    return 2;
  }
  const file = resolveTarget(kind, target, workDir);
  const { errors, warnings } = validateFile(kind, file, { families, workDir });
  for (const e of errors) console.log(e);
  if (!quiet) for (const w of warnings) console.log(`warn: ${w}`);
  console.log(`${errors.length ? "INVALID" : "VALID"} ${kind} ${path.relative(process.cwd(), file)}: ${errors.length} errors, ${warnings.length} warnings`);
  return errors.length ? 1 : 0;
}

if (require.main === module) process.exit(main(process.argv.slice(2)));

module.exports = { validateFile, resolveTarget, KINDS };
