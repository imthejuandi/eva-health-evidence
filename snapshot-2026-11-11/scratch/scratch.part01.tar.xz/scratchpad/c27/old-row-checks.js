// Semantic checks shared by validate.js for research, verify and decision files:
// bound ordering, quote length, evidence per bound, grade rules, reachable-zone messages,
// version 3 consistency blocks. Each check returns "path: message" strings.
"use strict";
const fs = require("fs");
const path = require("path");
const { wordCount } = require("./text-normalise");

const MAX_QUOTE_WORDS = 60;
const FAMILIES_FILE = path.join(__dirname, "..", "..", "work", "families.json");

function loadFamilies(file = FAMILIES_FILE) {
  if (!fs.existsSync(file)) return null;
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function rowKey(r) {
  return `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
}

const AGE_RE = /^(\d{1,3})-(\d{1,3})$|^(\d{1,3})\+$/;
function parseAge(a) {
  if (a === "All Adults") return [18, 200];
  const m = String(a).match(AGE_RE);
  if (!m) return null;
  if (m[3]) return [Number(m[3]), 200];
  return [Number(m[1]), Number(m[2])];
}

/** Zones the classifier can return for a row, given its bounds (check M1). */
function reachableZones(r) {
  const z = new Set();
  const hasOptimal = r.optimal_low != null || r.optimal_high != null;
  const lowLimit = r.reference_low != null && r.reference_low > 0;
  const highLimit = r.reference_high != null;
  if (r.critical_low != null) z.add("critical_low");
  if (r.critical_high != null) z.add("critical_high");
  if (lowLimit) z.add("below_range");
  if (highLimit) z.add("above_range");
  if (hasOptimal) {
    z.add("optimal");
    if (r.optimal_low != null && (!lowLimit || r.reference_low < r.optimal_low)) z.add("below_optimal");
    if (r.optimal_high != null && (!highLimit || r.optimal_high < r.reference_high)) z.add("above_optimal");
  } else {
    z.add("in_range");
  }
  return [...z].sort();
}

function checkRow(r, p, errs, warns) {
  const k = rowKey(r);
  const e = (m) => errs.push(`${p} (${k}): ${m}`);
  const w = (m) => warns.push(`${p} (${k}): ${m}`);
  const { reference_low: nl, reference_high: nh, optimal_low: ol, optimal_high: oh, critical_low: cl, critical_high: ch } = r;
  // Ordering: critical_low < reference_low <= optimal_low <= optimal_high <= reference_high < critical_high
  if (cl != null && nl != null && !(cl < nl)) e(`critical_low ${cl} must be < reference_low ${nl}`);
  if (cl != null && ol != null && !(cl < ol)) e(`critical_low ${cl} must be < optimal_low ${ol}`);
  if (nl != null && ol != null && !(nl <= ol)) e(`reference_low ${nl} must be <= optimal_low ${ol}`);
  if (ol != null && oh != null && !(ol <= oh)) e(`optimal_low ${ol} must be <= optimal_high ${oh}`);
  if (nl != null && nh != null && !(nl <= nh)) e(`reference_low ${nl} must be <= reference_high ${nh}`);
  if (oh != null && nh != null && !(oh <= nh)) e(`optimal_high ${oh} must be <= reference_high ${nh}`);
  if (nh != null && ch != null && !(nh < ch)) e(`reference_high ${nh} must be < critical_high ${ch}`);
  if (oh != null && ch != null && !(oh < ch)) e(`optimal_high ${oh} must be < critical_high ${ch}`);
  if (cl != null && ch != null && !(cl < ch)) e(`critical_low ${cl} must be < critical_high ${ch}`);
  if (nl == null && nh == null) e("a row needs at least one reference bound");
  // Class rules: only class a carries an optimal band
  const hasOptimal = ol != null || oh != null;
  if (hasOptimal && r.marker_class !== "a") e(`marker_class ${r.marker_class} may not carry an optimal band (only class a)`);
  if (hasOptimal && r.band_rule === "none") e("optimal band present but band_rule is 'none'");
  if (!hasOptimal && r.band_rule !== "none") e(`no optimal band but band_rule is '${r.band_rule}'`);
  if (r.physiological_state === "pregnancy" || r.physiological_state === "lactation") {
    if (hasOptimal) e(`${r.physiological_state} rows carry the laboratory interval only, no optimal band`);
    if (r.reference_basis !== "echevarne_interval") w(`${r.physiological_state} row with non-laboratory reference basis`);
  }
  // Critical limits: a value or "none, because"
  if (cl == null && ch == null && !(typeof r.critical_none_reason === "string" && r.critical_none_reason.trim())) e("no critical bound and no critical_none_reason");
  if ((cl != null || ch != null) && r.critical_none_reason) w("critical bound present and critical_none_reason also given");
  // Grade rules (verify and decision rows carry a grade)
  if (r.grade) {
    if (r.grade === "D" && hasOptimal) e("grade D means no optimal band");
    if (r.grade === "C" && hasOptimal) {
      const narrower = (ol != null && nl != null && ol > nl) || (oh != null && nh != null && oh < nh) || (ol != null && nl == null) || (oh != null && nh == null);
      if (narrower && r.grade_c_table_entry !== true) e("grade C band narrower than the reference interval must equal the interval or be a grade C decision table entry (grade_c_table_entry: true)");
    }
    if (r.grade_c_table_entry === true && r.grade !== "C") e("grade_c_table_entry only applies to grade C rows");
  }
  // Messages for every reachable zone, both languages
  const zones = reachableZones(r);
  for (const lang of ["en", "es"]) {
    const msgs = (r.messages && r.messages[lang]) || {};
    for (const z of zones) if (!msgs[z]) e(`missing ${lang} message for reachable zone '${z}'`);
    for (const z of Object.keys(msgs)) if (!zones.includes(z)) w(`${lang} message on unreachable zone '${z}' (listed for deletion)`);
  }
  // Critical wording appears only in the critical tier
  for (const lang of ["en", "es"]) {
    const msgs = (r.messages && r.messages[lang]) || {};
    for (const [z, text] of Object.entries(msgs)) {
      if (z === "critical_low" || z === "critical_high") continue;
      if (/prompt medical attention|atenci[oó]n m[eé]dica (inmediata|urgente)|\bemergenc|\bimmediate\b|\binmediat|\bcritical\b|\bcr[ií]tic/i.test(text)) e(`${lang} message for '${z}' uses critical-tier wording`);
    }
  }
  // RCV narrow-band rule (check P2)
  if (hasOptimal && r.rcv && r.rcv.rcv_pct != null && ol != null && oh != null && oh > 0) {
    const widthPct = ((oh - ol) / oh) * 100;
    if (widthPct < r.rcv.rcv_pct && !r.rcv.narrow_band_justification) e(`optimal band width ${widthPct.toFixed(1)}% is narrower than rcv_pct ${r.rcv.rcv_pct} without narrow_band_justification`);
  }
  if (!parseAge(r.age_group)) e(`unparseable age_group '${r.age_group}'`);
}

/** Row set checks: unique keys, age coverage per marker/sex/state. */
function checkRowSet(rows, p, errs, warns) {
  const seen = new Set();
  const groups = {};
  rows.forEach((r, i) => {
    const k = rowKey(r);
    if (seen.has(k)) errs.push(`${p}[${i}]: duplicate row key ${k}`);
    seen.add(k);
    checkRow(r, `${p}[${i}]`, errs, warns);
    const g = `${r.marker_key}|${r.sex}|${r.physiological_state}`;
    (groups[g] ??= []).push(parseAge(r.age_group));
  });
  for (const [g, ivs] of Object.entries(groups).sort()) {
    const iv = ivs.filter(Boolean).sort((a, b) => a[0] - b[0]);
    for (let i = 0; i < iv.length; i++) {
      if (i === 0 && iv[i][0] > 18) errs.push(`${p}: ${g} age coverage starts at ${iv[i][0]}, not 18`);
      if (i > 0 && iv[i][0] !== iv[i - 1][1] + 1) errs.push(`${p}: ${g} age bands gap or overlap between ${iv[i - 1].join("-")} and ${iv[i].join("-")}`);
    }
    if (iv.length && iv[iv.length - 1][1] < 200) errs.push(`${p}: ${g} has no open-ended top age band`);
  }
  // both rows must not overlap sex-specific rows for the same marker and state
  const byMarker = {};
  for (const r of rows) (byMarker[`${r.marker_key}|${r.physiological_state}`] ??= new Set()).add(r.sex);
  for (const [m, sexes] of Object.entries(byMarker).sort()) if (sexes.has("both") && (sexes.has("male") || sexes.has("female"))) errs.push(`${p}: ${m} mixes 'both' rows with sex-specific rows`);
  return seen;
}

/** Evidence records: ids unique, quotes at most 60 words, supports point at known rows and non-null bounds. */
function checkEvidence(records, rowKeys, p, errs, warns) {
  const ids = new Set();
  records.forEach((ev, i) => {
    const q = `${p}[${i}] (${ev.id})`;
    if (ids.has(ev.id)) errs.push(`${q}: duplicate evidence id`);
    ids.add(ev.id);
    const n = wordCount(ev.quote);
    if (n > MAX_QUOTE_WORDS) errs.push(`${q}: quote has ${n} words, at most ${MAX_QUOTE_WORDS} allowed`);
    if (!/\d/.test(ev.quote || "") && !["class", "method", "pre_analytical"].includes(ev.supports?.[0]?.bound)) warns.push(`${q}: quote contains no number`);
    for (const s of ev.supports || []) if (rowKeys && !rowKeys.has(s.row_key)) errs.push(`${q}: supports unknown row ${s.row_key}`);
    if (ev.basis_class === "laboratory_interval" || ev.basis_class === "treatment_tier") {
      for (const s of ev.supports || []) if (s.bound === "optimal_low" || s.bound === "optimal_high") errs.push(`${q}: an optimal bound may not rest on basis_class ${ev.basis_class}`);
    }
  });
  return ids;
}

/** Every bound that needs a record has one (check E1). Class e rows need records only for non-laboratory reference bounds. */
function checkBoundCoverage(rows, records, p, errs) {
  const support = new Map();
  for (const ev of records) for (const s of ev.supports || []) {
    const key = `${s.row_key}#${s.bound}`;
    (support.get(key) || support.set(key, []).get(key)).push(ev.id);
  }
  const has = (k, b) => support.has(`${k}#${b}`);
  rows.forEach((r, i) => {
    const k = rowKey(r);
    const e = (m) => errs.push(`${p}[${i}] (${k}): ${m}`);
    if (r.optimal_low != null && !has(k, "optimal_low")) e("optimal_low has no evidence record");
    if (r.optimal_high != null && !has(k, "optimal_high")) e("optimal_high has no evidence record");
    if (r.reference_basis !== "echevarne_interval") {
      if (r.reference_low != null && !has(k, "reference_low")) e(`reference_low with basis ${r.reference_basis} has no evidence record`);
      if (r.reference_high != null && !has(k, "reference_high")) e(`reference_high with basis ${r.reference_basis} has no evidence record`);
    }
    if (r.marker_class === "e") return;
    if (r.critical_low != null && !has(k, "critical_low")) e("critical_low has no evidence record");
    if (r.critical_high != null && !has(k, "critical_high")) e("critical_high has no evidence record");
    for (const a of r.action_limits || []) if (!(a.evidence_ids || []).length && !has(k, "action_limit")) e(`action limit '${a.name}' has no evidence`);
  });
}

/** Research rows carry no grade yet: an optimal bound whose every supporting record proposes grade D is an error (grade D means no optimal band). */
function checkProposedGrades(rows, records, p, errs) {
  const grades = new Map();
  for (const ev of records) for (const s of ev.supports || []) {
    const key = `${s.row_key}#${s.bound}`;
    (grades.get(key) || grades.set(key, []).get(key)).push(ev.proposed_grade);
  }
  rows.forEach((r, i) => {
    const k = rowKey(r);
    for (const b of ["optimal_low", "optimal_high"]) {
      const g = grades.get(`${k}#${b}`) || [];
      if (r[b] != null && g.length && g.every((x) => x === "D")) errs.push(`${p}[${i}] (${k}): ${b} rests only on proposed grade D evidence; grade D means no optimal band`);
    }
  });
}

/** Age splits: every age band boundary (other than 18) in a marker/sex/state group has a justification (check E4). */
function checkAgeSplits(rows, splits, p, errs) {
  const have = new Set((splits || []).map((s) => `${s.marker_key}|${s.sex}|${s.physiological_state}|${s.split_at}`));
  const groups = {};
  for (const r of rows) (groups[`${r.marker_key}|${r.sex}|${r.physiological_state}`] ??= []).push(parseAge(r.age_group));
  for (const [g, ivs] of Object.entries(groups).sort()) {
    const starts = [...new Set(ivs.filter(Boolean).map((iv) => iv[0]).filter((a) => a > 18))].sort((a, b) => a - b);
    for (const s of starts) if (!have.has(`${g}|${s}`)) errs.push(`${p}: age split at ${s} for ${g} has no age_splits justification`);
  }
  (splits || []).forEach((s, i) => {
    if (s.nadir_shift_pct != null && Math.abs(s.nadir_shift_pct) > 20 && !s.justification) errs.push(`${p}[${i}]: nadir shift above 20% needs a justification`);
  });
}

/** Version 3 markers in the family carry a v3_consistency entry. */
function checkV3(family, rows, v3, p, errs, families) {
  const fam = families?.families?.[family];
  const v3keys = fam ? fam.v3_keys || [] : Object.entries(families?.v3_markers || {}).filter(([, f]) => f === family).map(([k]) => k);
  const have = new Set((v3 || []).map((x) => x.marker_key));
  for (const k of [...v3keys].sort()) if (!have.has(k)) errs.push(`${p}: version 3 marker '${k}' has no v3_consistency entry`);
  for (const k of [...have].sort()) if (fam && !(fam.keys || []).includes(k)) errs.push(`${p}: v3_consistency entry for '${k}', which is not in family ${family}`);
}

/** Rows belong to the family's keys. */
function checkFamilyKeys(family, rows, p, errs, families) {
  const fam = families?.families?.[family];
  if (!fam) return;
  const keys = new Set(fam.keys || []);
  const seen = new Set(rows.map((r) => r.marker_key));
  for (const k of [...seen].sort()) if (!keys.has(k)) errs.push(`${p}: marker '${k}' is not in family ${family} (${[...keys].sort().join(", ")})`);
  for (const k of [...keys].sort()) if (!seen.has(k)) errs.push(`${p}: family key '${k}' has no row`);
}

function checkIdRefs(ids, known, p, errs) {
  for (const id of ids || []) if (!known.has(id)) errs.push(`${p}: unknown evidence id '${id}'`);
}

module.exports = { MAX_QUOTE_WORDS, loadFamilies, rowKey, parseAge, reachableZones, checkRow, checkRowSet, checkEvidence, checkBoundCoverage, checkProposedGrades, checkAgeSplits, checkV3, checkFamilyKeys, checkIdRefs };
