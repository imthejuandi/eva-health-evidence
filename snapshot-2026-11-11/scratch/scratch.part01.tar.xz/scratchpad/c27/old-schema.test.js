// node --test docs/signoff/tools/test/schema.test.js
// Schemas and validate.js on a valid fixture family and on invalid mutations. No network.
"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { validateFile, KINDS } = require("../validate");
const { validateAgainst, validate } = require("../lib/schema-validator");
const { reachableZones } = require("../lib/row-checks");

const FIX = path.join(__dirname, "fixtures", "work");
const FAM = "f04_inflammation";
const FILES = {
  research: path.join(FIX, "research", `${FAM}.json`),
  verify: path.join(FIX, "verify", `${FAM}.json`),
  decision: path.join(FIX, "decisions", `${FAM}.json`),
  judge: path.join(FIX, "judges", "round-1", "J2-B01.json"),
  refutation: path.join(FIX, "refutations", "round-1", "iss_0001-a.json"),
  ledger: path.join(FIX, "ledger", `${FAM}.json`),
};
const load = (kind) => JSON.parse(fs.readFileSync(FILES[kind], "utf8"));

/** Validate a mutated document the way the CLI would, with the fixture work tree for cross-file checks. */
function run(kind, mutate) {
  const doc = load(kind);
  mutate(doc);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "signoff-schema-"));
  const file = path.join(dir, kind === "judge" ? "J2-B01.json" : `${FAM}.json`);
  fs.writeFileSync(file, JSON.stringify(doc));
  const r = validateFile(kind, file, { workDir: FIX });
  fs.rmSync(dir, { recursive: true, force: true });
  return r;
}
const hasError = (r, re) => r.errors.some((e) => re.test(e));

test("every schema file parses and declares draft 2020-12", () => {
  for (const name of ["common", ...KINDS]) {
    const s = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "schema", `${name}.schema.json`), "utf8"));
    assert.equal(s.$schema, "https://json-schema.org/draft/2020-12/schema", name);
  }
});

test("the valid fixtures pass schema and semantic checks", () => {
  for (const kind of KINDS) {
    const r = validateFile(kind, FILES[kind], { workDir: FIX });
    assert.deepEqual(r.errors, [], `${kind}: ${r.errors.join("\n")}`);
  }
});

test("the mini validator reports type, enum, required, additionalProperties, pattern and oneOf", () => {
  const schema = {
    type: "object", required: ["a"], additionalProperties: false,
    properties: { a: { type: "integer", minimum: 1 }, b: { enum: ["x", "y"] }, c: { type: "string", pattern: "^f\\d{2}$" }, d: { oneOf: [{ type: "null" }, { type: "number" }] } },
  };
  assert.deepEqual(validate({ a: 2, b: "x", c: "f01", d: null }, schema), []);
  const errs = validate({ a: 0.5, b: "z", c: "nope", d: "s", e: 1 }, schema);
  assert.ok(errs.some((e) => e.includes("$.a")));
  assert.ok(errs.some((e) => e.includes("$.b")));
  assert.ok(errs.some((e) => e.includes("$.c")));
  assert.ok(errs.some((e) => e.includes("$.d")));
  assert.ok(errs.some((e) => e.includes("unexpected property 'e'")));
  assert.ok(validate({}, schema).some((e) => e.includes("missing required property 'a'")));
});

test("research: schema violations are reported with their path", () => {
  const r = run("research", (d) => { d.rows[0].marker_class = "z"; d.rows[0].reference_basis = "guess"; delete d.searches_used; });
  assert.ok(hasError(r, /rows\[0\]\.marker_class/));
  assert.ok(hasError(r, /rows\[0\]\.reference_basis/));
  assert.ok(hasError(r, /missing required property 'searches_used'/));
});

test("research: bound ordering is enforced", () => {
  const r = run("research", (d) => { d.rows[0].optimal_high = 6; });
  assert.ok(hasError(r, /optimal_high 6 must be <= reference_high 5/), r.errors.join("\n"));
  const r2 = run("research", (d) => { d.rows[2].critical_low = 250; });
  assert.ok(hasError(r2, /critical_low 250 must be < reference_low 200/));
});

test("research: a quote longer than 60 words is rejected", () => {
  const r = run("research", (d) => { d.evidence[0].quote = Array.from({ length: 61 }, (_, i) => `w${i}`).join(" "); });
  assert.ok(hasError(r, /quote has 61 words/));
  const ok = run("research", (d) => { d.evidence[0].quote = Array.from({ length: 59 }, (_, i) => `w${i}`).join(" ") + " 1.0"; });
  assert.ok(!hasError(ok, /quote has/));
});

test("research: every optimal bound needs an evidence record unless the row is class e", () => {
  const r = run("research", (d) => { d.evidence[0].supports = [{ row_key: "hs_crp|both|All Adults|none", bound: "reference_high" }]; });
  assert.ok(hasError(r, /optimal_high has no evidence record/), r.errors.join("\n"));
  const r2 = run("research", (d) => { d.rows[2].reference_basis = "decision_limit"; });
  assert.ok(hasError(r2, /reference_low with basis decision_limit has no evidence record/));
  const r3 = run("research", (d) => { d.rows[2].critical_low = 90; });
  assert.ok(!hasError(r3, /critical_low has no evidence record/), "class e critical bound needs no record");
});

test("research: an optimal bound resting only on proposed grade D evidence is rejected", () => {
  const r = run("research", (d) => { d.evidence[0].proposed_grade = "D"; });
  assert.ok(hasError(r, /optimal_high rests only on proposed grade D evidence; grade D means no optimal band/), r.errors.join("\n"));
  const ok = run("research", (d) => { d.evidence[0].proposed_grade = "C"; });
  assert.ok(!hasError(ok, /proposed grade D/));
});

test("research: only class a rows carry an optimal band; pregnancy rows carry none", () => {
  const r = run("research", (d) => { d.rows[2].optimal_high = 350; d.rows[2].band_rule = "nadir_ci"; });
  assert.ok(hasError(r, /marker_class e may not carry an optimal band/));
  const r2 = run("research", (d) => { d.rows[1].optimal_high = 1; d.rows[1].band_rule = "nadir_ci"; });
  assert.ok(hasError(r2, /pregnancy rows carry the laboratory interval only/));
});

test("research: version 3 markers must carry a v3_consistency block", () => {
  const r = run("research", (d) => { d.v3_consistency = []; });
  assert.ok(hasError(r, /version 3 marker 'hs_crp' has no v3_consistency entry/));
});

test("research: messages are required for every reachable zone", () => {
  const r = run("research", (d) => { delete d.rows[0].messages.es.above_optimal; });
  assert.ok(hasError(r, /missing es message for reachable zone 'above_optimal'/));
  const r2 = run("research", (d) => { d.rows[0].messages.en.optimal = "This is critical, seek prompt medical attention."; });
  assert.ok(hasError(r2, /uses critical-tier wording/));
});

test("research: critical limit needs a value or a reason; evidence ids must exist", () => {
  const r = run("research", (d) => { d.rows[0].critical_none_reason = null; });
  assert.ok(hasError(r, /no critical bound and no critical_none_reason/));
  const r2 = run("research", (d) => { d.physician_questions[0].evidence_ids = ["E9"]; });
  assert.ok(hasError(r2, /unknown evidence id 'E9'/));
});

test("research: age split without justification; duplicate keys; family keys", () => {
  const r = run("research", (d) => {
    const a = { ...d.rows[2], age_group: "18-59" }, b = { ...d.rows[2], age_group: "60+" };
    d.rows.splice(2, 1, a, b);
  });
  assert.ok(hasError(r, /age split at 60 for fibrinogen\|both\|none has no age_splits justification/), r.errors.join("\n"));
  const r2 = run("research", (d) => { d.rows.push({ ...d.rows[2] }); });
  assert.ok(hasError(r2, /duplicate row key/));
  const r3 = run("research", (d) => { d.rows[2].marker_key = "albumin"; });
  assert.ok(hasError(r3, /marker 'albumin' is not in family f04_inflammation/));
  assert.ok(hasError(r3, /family key 'fibrinogen' has no row/));
});

test("verify: grade D means no optimal band; grade C narrower band needs the table entry", () => {
  const r = run("verify", (d) => { d.final_rows[0].grade = "D"; d.row_verdicts[0].grade = "D"; });
  assert.ok(hasError(r, /grade D means no optimal band/));
  const r2 = run("verify", (d) => { d.final_rows[0].grade = "C"; d.row_verdicts[0].grade = "C"; });
  assert.ok(hasError(r2, /grade C band narrower than the reference interval/));
  const ok = run("verify", (d) => { d.final_rows[0].grade = "C"; d.row_verdicts[0].grade = "C"; d.final_rows[0].grade_c_table_entry = true; });
  assert.ok(!hasError(ok, /grade C band narrower/), ok.errors.join("\n"));
});

test("verify: verdict coverage and consistency with the research file", () => {
  const r = run("verify", (d) => { d.row_verdicts.pop(); });
  assert.ok(hasError(r, /no verdict for research row fibrinogen/));
  const r2 = run("verify", (d) => { d.final_rows[0].optimal_high = 0.5; });
  assert.ok(hasError(r2, /optimal_high differs from research but the row verdict is 'confirmed'/));
  const r3 = run("verify", (d) => { d.evidence_verdicts[0].verdict = "unverifiable"; });
  assert.ok(hasError(r3, /an unverifiable source is grade D/));
  const r4 = run("verify", (d) => { d.final_rows[0].grade = "A"; d.row_verdicts[0].grade = "A"; d.evidence_verdicts[0].verdict = "refuted"; });
  assert.ok(hasError(r4, /grade A optimal_high has no confirmed or corrected evidence record/));
  const r5 = run("verify", (d) => { delete d.final_rows[0].grade; });
  assert.ok(hasError(r5, /final_rows\[0\]: missing required property 'grade'/));
});

test("decision: changes must be recorded and a loosening needs grade A or B evidence", () => {
  const r = run("decision", (d) => { d.final_rows[0].optimal_high = 0.9; d.changes = []; d.issues_addressed = []; });
  assert.ok(hasError(r, /optimal_high differs from the verify file .* without a change record/));
  const r2 = run("decision", (d) => { d.changes[0].direction = "loosen"; d.changes[0].evidence_ids = []; });
  assert.ok(hasError(r2, /a loosening needs a grade A or B quote/));
  const r3 = run("decision", (d) => { d.changes[0].direction = "loosen"; d.changes[0].evidence_ids = ["E2"]; });
  assert.ok(hasError(r3, /no cited evidence is grade A or B/));
  const r4 = run("decision", (d) => { d.issues_addressed = ["iss_9999"]; });
  assert.ok(hasError(r4, /'iss_9999' is not in the ledger/));
});

test("judge: evidence shape depends on kind; families must be in the shard", () => {
  const r = run("judge", (d) => { d.blocking[0].evidence = { kind: "file_line", file: "x.json" }; });
  assert.ok(hasError(r, /blocking\[0\]\.evidence: missing required property 'line'/));
  const r2 = run("judge", (d) => { d.blocking[0].family = "f09_red_cells"; });
  assert.ok(hasError(r2, /family f09_red_cells is not in families_reviewed/));
  const r3 = run("judge", (d) => { d.blocking[0].check_id = "Z99"; });
  assert.ok(hasError(r3, /check_id/));
});

test("refutation and ledger: enums and state rules", () => {
  const r = run("refutation", (d) => { d.verdict = "maybe"; d.evidence = []; });
  assert.ok(hasError(r, /\$\.verdict/));
  assert.ok(hasError(r, /\$\.evidence: fewer than 1 items/));
  const l = run("ledger", (d) => { d.issues[0].status = "fixed"; });
  assert.ok(hasError(l, /status fixed but rounds.closed is null/));
  const l2 = run("ledger", (d) => { d.issues[0].status = "physician_question"; });
  assert.ok(hasError(l2, /physician_question needs question_id/));
  const l3 = run("ledger", (d) => { d.issues[0].status = "wontfix"; });
  assert.ok(hasError(l3, /issues\[0\]\.status/));
});

test("reachable zones follow the bounds", () => {
  assert.deepEqual(reachableZones({ reference_low: 0, reference_high: 5, optimal_low: null, optimal_high: 1, critical_low: null, critical_high: null }), ["above_optimal", "above_range", "optimal"]);
  assert.deepEqual(reachableZones({ reference_low: 200, reference_high: 400, optimal_low: null, optimal_high: null, critical_low: 100, critical_high: null }), ["above_range", "below_range", "critical_low", "in_range"]);
  assert.deepEqual(reachableZones({ reference_low: 3.5, reference_high: 5.1, optimal_low: 4, optimal_high: 5.1, critical_low: 2.5, critical_high: 6.5 }), ["above_range", "below_optimal", "below_range", "critical_high", "critical_low", "optimal"]);
});

test("validateAgainst resolves cross-file $ref to common.schema.json", () => {
  const errs = validateAgainst("research", { schema_version: "1" });
  assert.ok(errs.some((e) => e.includes("missing required property 'rows'")));
});

test("rows: the optional Spanish counterparts and clinical notes validate in every file kind", () => {
  const add = (r) => Object.assign(r, {
    unit_es: "mg/L", reference_source_es: "Echevarne PCR-US, catálogo 2026-08-25", critical_none_reason_es: "ninguno, porque no hay un umbral de contacto el mismo día",
    method_note_es: "Inmunoturbidimetría de alta sensibilidad.", clinical_notes_en: "A marker of inflammation.", clinical_notes_es: "Un marcador de inflamación.",
  });
  for (const kind of ["research", "verify", "decision"]) {
    const r = run(kind, (d) => add((d.rows || d.final_rows)[0]));
    assert.deepEqual(r.errors, [], `${kind}: ${r.errors.join("\n")}`);
  }
  const none = run("research", (d) => Object.assign(d.rows[0], { clinical_notes_en: null, clinical_notes_es: null }));
  assert.deepEqual(none.errors, [], "null notes in both languages: no note");
});

test("rows: a Spanish text needs its English text, the notes come in pairs, and notes keep critical wording out", () => {
  const r = run("research", (d) => { d.rows[0].clinical_notes_en = "A marker of inflammation."; });
  assert.ok(hasError(r, /rows\[0\] \(hs_crp\|both\|All Adults\|none\): clinical_notes_en and clinical_notes_es go together; clinical_notes_es is missing/), r.errors.join("\n"));
  const r2 = run("research", (d) => Object.assign(d.rows[0], { clinical_notes_en: "A marker of inflammation.", clinical_notes_es: null }));
  assert.ok(hasError(r2, /clinical note in one language only \(clinical_notes_es is empty\)/), r2.errors.join("\n"));
  const r3 = run("research", (d) => { d.rows[1].method_note_es = "Solo en español."; });
  assert.ok(hasError(r3, /rows\[1\] .*: method_note_es is given but method_note is empty/), r3.errors.join("\n"));
  const r4 = run("decision", (d) => Object.assign(d.final_rows[0], { clinical_notes_en: "A critical marker.", clinical_notes_es: "Un marcador." }));
  assert.ok(hasError(r4, /final_rows\[0\] .*: clinical_notes_en uses critical-tier wording/), r4.errors.join("\n"));
  const r5 = run("verify", (d) => Object.assign(d.final_rows[0], { clinical_notes_en: "x", clinical_notes_es: 5 }));
  assert.ok(hasError(r5, /final_rows\[0\]\.clinical_notes_es: expected string\|null/), r5.errors.join("\n"));
  const r6 = run("research", (d) => { d.rows[0].clinical_note_es = "x"; });
  assert.ok(hasError(r6, /unexpected property 'clinical_note_es'/), "the row still refuses fields it does not define");
});
