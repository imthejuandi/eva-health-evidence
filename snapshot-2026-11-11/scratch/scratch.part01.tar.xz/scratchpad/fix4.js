const fs = require("fs");
const f = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/f11gen.js";
let s = fs.readFileSync(f, "utf8");
function rep(o, n, k = 1) { const c = s.split(o).length - 1; if (c !== k) throw new Error(`count ${c} != ${k}: ${o.slice(0, 80)}`); s = s.split(o).join(n); }
rep("the IFCC list of limits for urgent notification asks", "the IFCC list of laboratory alert limits asks");
rep("la lista de la IFCC de límites para aviso urgente pide", "la lista de la IFCC de límites de aviso del laboratorio pide");
fs.writeFileSync(f, s); console.log("ok");
