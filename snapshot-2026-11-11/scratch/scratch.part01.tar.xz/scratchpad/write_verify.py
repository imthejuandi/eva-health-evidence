import json, hashlib, copy

REPO = "/home/user/eva-health"
research_path = f"{REPO}/docs/signoff/work/research/f11_platelets.json"
out_path = f"{REPO}/docs/signoff/work/verify/f11_platelets.json"

raw = open(research_path, "rb").read()
sha = hashlib.sha256(raw).hexdigest()
research = json.loads(raw)

ROW_NONE = "platelet_count|both|All Adults|none"
ROW_PREG = "platelet_count|female|All Adults|pregnancy"
ROW_MPV = "mpv|both|All Adults|none"

row_verdicts = [
    {
        "row_key": ROW_NONE,
        "verdict": "confirmed",
        "grade": "D",
        "note": (
            "Reference 130,000-450,000/µL confirmed: Echevarne H0008 PLAQUETAS, General, ages '14-999', 130000-450000 /µL, dated 31/05/2010, "
            "'Sangre total', 'TUBO EDTA', 'Contaje y Fórmula Electrónico', re-read at line 199 of docs/vendor/echevarne/catalogo-2026-08-25.tsv "
            "(line 198 is the under-14 band, 130000-600000), and OBX-7 '130000,000-450000,000' with LOINC 777-3 on OBX segment 8 of "
            "docs/context/training/EVA2026T1_X68800189.ORU (test value 200000,000, flag N). Taking the printed 130,000 instead of the 150,000 of a "
            "clinical review (f11-E12, a definition, not a named guideline decision limit) is what PLAN section 4 requires; the alternative stays in "
            "PQ-f11-02, whose percentiles (Spanish donors 123,000 men and 137,000 women; Italians over 64: 122,000 men and 140,000 women) are confirmed "
            "in f11-E10 and in Table 2 of the f11-E11 full text. Class c confirmed: the outcome evidence is observational and U-shaped (f11-E01 GESUS, "
            "mortality raised below 175 and above 300 ×10^9/L; f11-E02 Taiwan, lowest at 200-<300 with adjusted HRs 1.93, 1.08, 1.18 and 1.67 re-read "
            "in the letter's Table 1; f11-E04 WHI deciles; f11-E05 CHS, non-cardiovascular only), the two Mendelian-randomisation studies disagree on "
            "stroke (f11-E06 OR 1.07 per SD for ischaemic stroke; f11-E07 OR 1.037, 0.979-1.098, for stroke), f11-E09 finds no causal effect on cancer "
            "survival, high-normal counts mark cancers present within a year (f11-E08), and no opened source moves the count within the interval; "
            "marker-classes.json proposes class c; PQ-f11-01 keeps class a as the alternative, and if the physician chooses it the 175,000-300,000/µL "
            "band is grade C on the opened text (f11-VQ-01). Grade D: the row carries no optimal band, and under PLAN section 5 and the verify schema D "
            "is the grade of a row without a band; it does not mean the sources failed. Critical limits 30,000 and 1,000,000/µL confirmed against "
            "critical-limits.json entries[6] (recommendation; the alternative 20,000/1,000,000 stays there for the physician) and against the sources: "
            "Table 3 of Shah 2025 (f11-E18, f11-E20) reads 'Platelets 96 45 10⁹/L 37 (21) 25 (11) 30 (10–100) 20 ** (10–50) 894 (206) 984 (73) "
            "1000 (100–1000) 1000 (600–1000)', its columns being listing frequency 2024 and 1990, low mean 1990 and 2024, low median 1990 and 2024, high "
            "mean 1990 and 2024, high median 1990 and 2024, so the 1990 low median is 30, the 2024 low median 20 and the high median 1000 ×10^9/L in both "
            "years; Thomas 2003 <20,000 and >1 million (f11-E21); Kost 1990 means 37 and 910 (f11-E22); Bellvitge <30 with no high limit (f11-E23, read in "
            "the NCBI copy of the full text). The 2026 correction to Shah et al. (PMID 42449917, PMC13360011, opened through NCBI) changes only Table 8, "
            "the point-of-care limits, as the author states. Action limits confirmed: 100,000/µL (f11-E19, Shah's '100 × 10^9/L' threshold 'associated "
            "with thrombocytopenia', their reference 26; f11-E12; f11-E13) and 450,000/µL on a repeat count (f11-E14, ICC Table 4 major criterion 1 "
            "'Platelet count ≥ 450 × 10 9 /L', read on the PMC page; f11-E15, secondary causes 32.2%, 17.1%, 11.7%, 11.1%). Note for the fixer, no change "
            "made: the classifier's above_range zone starts above 450,000, while the action limit's name and the ICC criterion say 'at or above', so a "
            "count of exactly 450,000 reads 'in range' in the app; the follow-up text ('stays above 450,000/µL') agrees with the app. Splits: none, "
            "confirmed (Echevarne prints one band for both sexes from age 14; the sex and age differences quoted in the notes are in the sources: men "
            "195 ± 42 against women 213 ± 47 ×10^9/L, f11-E10; Italy 15-64 against over 64, 252 against 233, women 264 and 245 against men 238 and 220 "
            "×10^9/L, text and Table 2 of PMC3561305 opened through NCBI efetch). Ages 70-84 and 85 and over: the sources the scope names (f11-E02, "
            "f11-E05, f11-E11, PMID 15195993 with 16 centenarians aged 100-105 against controls aged 65-85, PMID 23518452 with 135 volunteers over 80) "
            "were opened and say what the scope says. Pre-analytical rules confirmed (f11-E13 heparin or sodium citrate tube and repeat; f11-E21 'Exclude "
            "EDTA-induced thrombocytopenia'; f11-E24 463 paired samples from 428 adults, platelets -1 ×10^9/L; f11-E25 CV up to 4 times higher in "
            "fingerprick drops). RCV placeholder confirmed; 1.96 × 1.414 × 5 = 13.9% and × 15 = 41.6% re-computed. Messages: scanned by script against "
            "the banned-terms block of docs/signoff/work/governance/wording-rules.md (both languages, 'any' and 'non_critical' scopes, allow list removed "
            "first) over every zone message, clinical note, pre-analytical text and action follow-up: 0 hits; the critical closer is present word for "
            "word in both critical messages and the out-of-range closer in both out-of-range messages; the four M2 elements are matched by the regexes of "
            "scripts/signoff/checks/messages.ts in both languages; every number in a message equals a bound or an explanatory number (130,000, "
            "450,000, 2, 4); the 'soon' urgency phrase and the class c sentence 'This marker does not count toward the score' are present. Production "
            "diff confirmed: snapshot row 150,000-450,000 with optimal 175,000-300,000; src/lib/biomarkers/longevity-score.ts line 243 "
            "add(\"Platelets\", \"PLT\", ..., 4, ...); hazard H13 lists 'platelets 150,000 vs 130,000'."
        ),
    },
    {
        "row_key": ROW_PREG,
        "verdict": "confirmed",
        "grade": "D",
        "note": (
            "Reference confirmed as for the 'none' row (Echevarne H0008, catalogue line 199; no pregnancy band is printed, as the reference_source "
            "says). State split confirmed on f11-E16 and f11-E17 (NEJM 2018, PubMed abstract: 15,723 deliveries, 7,351 analysed, 4,568 uncomplicated; "
            "mean first-trimester count 251,000 at a mean gestation of 8.7 weeks against 273,000/µL in 8,885 NHANES non-pregnant women; 9.9% below "
            "150,000 at delivery; 45 women, 1.0%, below 100,000; below 100,000 'a cause other than pregnancy or its complications should be "
            "considered'), so the row's 'about 1 in 10' and 'about 1 in 100' are the source's 9.9% and 1.0%. Class c, no optimal band, critical limits "
            "30,000 and 1,000,000/µL carried over, as PLAN section 4 and state-rules.md section 2.1 require (the critical tier stays active in "
            "pregnancy); the pregnancy-only action limit below 100,000/µL rests on f11-E17. Out-of-range messages stay on the row as every family with "
            "a pregnancy row has done (f01, f02, f04, f05, f08); the display rule of state-rules.md 2.1 is the app's, not the row's. No lactation row: "
            "the author's reason (the 'none' row already shows the laboratory interval only) is accepted because the class c display is the same, "
            "although f01, f02, f04 and f08 wrote lactation rows; the picker falls back to the 'none' row (check C1). Grade D: no optimal band. "
            "Messages: 0 banned-term hits in either language; the critical and out-of-range closers are present word for word; the four M2 elements "
            "are matched; the numbers 130,000, 450,000, 150,000, 100,000, 1 and 10 are bounds or explanatory numbers; the obstetric route "
            "('obstetrician or midwife' / 'obstetra o matrona') is named. Production diff confirmed: production has no pregnancy row for the platelet "
            "count, so a pregnant client gets the 'both' row today."
        ),
    },
    {
        "row_key": ROW_MPV,
        "verdict": "confirmed",
        "grade": "D",
        "note": (
            "Reference 6-11 fL confirmed: Echevarne H0042 VPM, General, ages '0-999', dated 14/11/2007, unit fL, 'Sangre total', 'TUBO EDTA', "
            "'Contaje y Fórmula Electrónico', re-read at line 221 of docs/vendor/echevarne/catalogo-2026-08-25.tsv, and OBX-7 '6,000-11,000' fL with "
            "LOINC 32623-1 on OBX segment 9 of the training ORU (test value 6,000, flag N); same bounds as the production snapshot row. Class e "
            "confirmed, as PLAN section 4 names MPV and marker-classes.json proposes: the general-population association with myocardial infarction is "
            "flat from the third quintile (f11-E29: +35%, +31%, +29%), the meta-analytic evidence comes from patient populations with causality left "
            "open (f11-E30), the Mendelian-randomisation estimate for stroke is null (f11-E07: OR 0.990, 95% CI 0.945-1.038, p = 0.675, present in the "
            "PubMed abstract), and the value depends on anticoagulant, time to analysis and analyser (f11-E26, f11-E27, f11-E31). Removing the "
            "September optimal band of 6-11 fL, equal to the interval, changes no classification. Grade D: no optimal band. No critical limit, reason "
            "confirmed: MPV is not in the L1 list of ACCEPTANCE-TEST.md, critical-limits.json has no entry for it, and the four opened lists carry no "
            "MPV row (0 mentions of 'MPV' or 'platelet volume' in the opened texts of Thomas 2003, Shah 2025 and Arbiol-Roca 2019, none in the Kost 1990 "
            "abstract). No action limit, consistent with class e. Splits: none (no sex difference, f11-E28; no difference among age groups, f11-E31). "
            "Pre-analytical rule and method note confirmed: 7.8-11 fL in citrate on a Technicon H*1 (f11-E28) and 7.2-11.7 fL on a CELL-DYN 3700 SL "
            "(f11-E31) against Echevarne's 6-11 fL on EDTA. RCV placeholder confirmed (f11-E32 leaves MPV out of the 5-15% range; f11-E33 gives ranges "
            "across six parameters, not per parameter). Messages: 0 banned-term hits; the out-of-range closer is present in both out-of-range messages; "
            "the four M2 elements are matched ('Repítelo' matches 'repít'); the numbers 6, 11, 2 and 4 are bounds or explanatory numbers; the 'routine' "
            "urgency phrase and the class e sentence are present; the above-range statement on heart attacks is population-level with 'is not known to "
            "cause them', as wording-rules.md section 3 requires. Production diff confirmed: optimal 6-11 removed; MPV is not in score 2.0 "
            "(no entry in src/lib/biomarkers/longevity-score.ts)."
        ),
    },
]

EV = {}
def ev(id_, verdict, grade, found, note):
    EV[id_] = {"evidence_id": id_, "verdict": verdict, "grade": grade, "quote_found": found, "note": note}

ev("f11-E01", "confirmed", "C", True,
   "Found word for word in the PubMed abstract opened by eutils efetch (quote-check: exact normalised substring). Numbers confirmed: 21,252 adults aged 20 and over of the Danish General Suburban Population Study, register linkage, Cox models adjusted for age, sex, smoking, haemoglobin, leukocyte count, CRP and Charlson index; U-shape with mortality raised below 175 and above 300 ×10^9/L; HR 1.42 (1.06-1.90) for mortality and 1.32 (1.03-1.69) for cardiovascular disease at 301-450 against 201-250; HR 1.28 (1.05-1.57) for future cancer at 100-200. Grade C, agreeing with the author: the size meets tier 2, but the abstract gives no follow-up length and shows no handling of reverse causation beyond adjustment for comorbidity; the paper is not open access (Europe PMC: inEPMC N, isOpenAccess N), so the full text was not opened; the band is a threshold statement, not a nadir with a confidence interval. Supports class only; if the physician keeps class a (PQ-f11-01 option B) this is the band's only record and it carries grade C (f11-VQ-01).")
ev("f11-E02", "confirmed", "C", True,
   "Found word for word on the PMC article page (quote-check: exact normalised substring; the identifier is the page because PubMed carries no abstract for this letter and neither Europe PMC nor NCBI returns body XML). Letter re-read: 131,308 people aged 65 and over, mean age 72.6 ± 6.3 years, mean follow-up 5.8 ± 2.9 years, 17,759 deaths (13.5%); Table 1 adjusted HRs 1.93 (1.77-2.11), 1.08 (1.05-1.12), 1.18 (1.11-1.25) and 1.67 (1.49-1.87) as quoted, adjusted for 20 covariates; participants with cardiovascular disease were excluded only from the cardiovascular-death analysis; the discussion says 'it is altogether unlikely that platelet count would have a causal effect on noncardiovascular mortality'. Grade C, agreeing: tier-2 size and follow-up, but reverse causation is not handled for all-cause mortality (no lag or exclusion of early deaths), Han Chinese adults aged 65 and over only, and the lowest-risk stratum (200-<300 ×10^9/L) is a category, not a nadir. It is the scope's evidence above age 70.")
ev("f11-E03", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 21,563 adults, mean age 55.6 ± 11.8 years, median follow-up 8.2 years (IQR 7.3-9.2; 175,972 person-years), 1,130 deaths (415 cardiovascular, 439 cancer, 276 non-vascular/non-cancer); HRs as quoted; 'Higher platelet count was not associated with any death risk'; the age-sex cut-offs are those of f11-E11 (extreme values 122 to 405 ×10^9/L). Grade C, agreeing: tier-2 size and follow-up, but no handling of reverse causation is shown in the abstract; supports class only and argues against an upper optimal bound.")
ev("f11-E04", "confirmed", "B", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 159,746 postmenopausal women with a baseline count, 75,339 with a year-3 count, median follow-up 15.9 years; Cox models by deciles of baseline and of mean count; the association was robust to adjustment, to exclusion of women with comorbidity and to 'allowance for reverse causality', and held in never, former and current smokers. Grade B, agreeing: tier-2 cohort with reverse causation addressed in the opened text; it gives no band (the decile cut-points are not in the abstract and the full text was not opened) and no evidence that moving the count changes outcomes, so it supports the class decision only.")
ev("f11-E05", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 5,766 community-dwelling adults aged 65 and over (mean 73), counts at baseline 1989-1990 and at 3 years or at baseline 1992-1993, 12-15 years of follow-up, 821 myocardial infarctions, 807 ischaemic and 161 haemorrhagic strokes, 159 venous thrombotic events, 3,413 deaths; no association with vascular outcomes or cardiovascular mortality; non-cardiovascular mortality rates 1.89, 1.08, 1.20 and 1.47 as quoted. Grade C, agreeing: below the tier-2 size (5,766 is under 10,000).")
ev("f11-E06", "confirmed", "B", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: instruments from a genome-wide association study of 166,066 subjects; 60,801 CAD cases and 123,504 controls; 60,341 ischaemic stroke cases and 454,450 controls; inverse-variance weighted estimates; OR 1.01 (0.98-1.04, P = 0.60) for CAD and 1.07 (1.04-1.11, P < 1×10^-5) for ischaemic stroke, 'including all major ischemic stroke subtypes', with sensitivity analyses robust to pleiotropy. Grade B, agreeing with the author: a tier-1 design with a hard outcome, graded B rather than A because it is a two-sample analysis of summary statistics that gives no bound and whose stroke finding f11-E07 did not reproduce, as two-sample Mendelian randomisation without a bound was graded in f02-E27, f03-E11 and f27-E35. Supports class only.")
ev("f11-E07", "confirmed", "B", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: instruments from UK Biobank (n = 350,474); PCT OR 1.113 (1.047-1.183), p < 0.001; PLT OR 1.037 (0.979-1.098), p = 0.221; PDW OR 0.973 (0.923-1.024), p = 0.294; MPV OR 0.990 (0.945-1.038), p = 0.675; mediation by systolic blood pressure 23.71% and diastolic 28.09%. The record's note that the PubMed text cuts the MPV estimate is not borne out by the efetch text opened today, which carries it in full, so the MPV null has its number. Grade B, agreeing: two-sample Mendelian randomisation of summary statistics with a hard outcome and no bound; supports class c for the count and class e for MPV.")
ev("f11-E08", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Confirmed: three primary-care cohorts (England, Canada, Australia) of patients aged 40 and over with a full blood count, stratified by 10-year age band, sex and platelet-count group; cancer incidence within one year from linked registries; a clear upward trend in every age group and both sexes; lung and colorectal the most common sites; cohort sizes not in the abstract. Grade C, agreeing: one-year incidence after the test (the cancers were present when the count was taken), no sizes, no band; supports the class decision and the above-range follow-up.")
ev("f11-E09", "confirmed", "B", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 65,471 cancer patients of UK Biobank with pre-diagnostic counts; HR 1.07 (1.04-1.10, p < .001) per 100 ×10^9/L for inferior overall survival; U-shaped relationship (p < .001); 34 genetic variants; MR HR 1.000 (0.998-1.001), p = .678; 'PLT is less likely to be a promising therapeutic target'. Grade B, agreeing: tier-2 cohort with pre-diagnostic measurement at several lag times plus two-sample Mendelian randomisation with a hard outcome and no bound; a patient population, so it bears on class only.")
ev("f11-E10", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 1,430 prospective healthy platelet donors (Hospital Clínic, Barcelona), Bayer-Technicon H*1; men 195 (SD 42), n = 1,053; women 213 (47), n = 377; 95% reference ranges 123-295, 137-319 and 125-300 ×10^9/L; conclusion 'seems to be lower than in other populations of North European origin'. The share of men below 175,000/µL under a normal distribution was re-derived: z = (175 - 195)/42 = -0.48, about 32%. Grade C, agreeing: a reference-interval study (laboratory basis) on a 1998 analyser, donor ages not stated.")
ev("f11-E11", "confirmed", "C", True,
   "Found word for word in the PubMed abstract; the full text (PMC3561305) was opened through NCBI efetch (Europe PMC answered HTTP 500): Table 2 gives, for 15-64 years, men n = 13,789 mean 238 (SD 57.9) 141-362 and women n = 16,358 mean 264 (65.3) 156-405, and for over 64 years men n = 4,303 mean 220 (59.5) 122-350 and women n = 4,835 mean 245 (61.2) 140-379 ×10^9/L; the text gives 252 against 233 ×10^9/L for 15-64 against over 64, which confirms the row notes and the scope's older-adult pass. 40,987 subjects, non-parametric 2.5th and 97.5th percentiles after excluding malignancy, liver disease and inherited thrombocytopenia, as the record says. Grade C rather than the author's B: a reference-interval study carries the laboratory basis class and is grade C by the convention applied in f02 and f10 whatever its size; it supports no optimal bound. Echevarne's single band for both sexes from age 14 is the row's basis, so no split follows from it.")
ev("f11-E12", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Abstract re-read: thrombocytopenia is a count below 150 ×10^3/µL; counts above 50 are generally asymptomatic; 20-50 may give petechiae, purpura or ecchymosis; below 10 a high risk of serious bleeding; common non-emergency causes are drug-induced and immune thrombocytopenia and hepatic disease. Grade C, agreeing: a clinical review (expert opinion); it is the source of today's 150,000/µL and not a named guideline decision limit, so PLAN section 4 gives Echevarne's 130,000/µL (PQ-f11-02).")
ev("f11-E13", "confirmed", "C", True,
   "Found word for word in the same PubMed abstract as f11-E12. It grounds the repeat in a heparin or sodium citrate tube and the comparison with earlier counts in the below-range message and the 100,000/µL action limit. Grade C: review.")
ev("f11-E14", "confirmed", "B", True,
   "Found word for word on the PMC article page (quote-check: exact normalised substring): Table 4, 'Diagnostic criteria for essential thromocythemia (ET) and post-ET myelofibrosis (post-ET MF)', major criterion 1 'Platelet count ≥ 450 × 10 9 /L' (the source's misspelling kept). Blood 2022;140(11):1200-1228, PMID 35767897, PMCID PMC9479031 confirmed in PubMed. Grade B, agreeing: a named international consensus classification used as a decision limit, graded as guideline decision limits were in f02, f05 and f06; it is one of four major criteria and diagnoses nothing alone, as the note says, and Echevarne's upper limit is the same 450,000/µL.")
ev("f11-E15", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 1,202 outpatients and inpatients aged 20 and over with counts above 450 ×10^9/L over half a year at one institute (Juntendo); 150 (12.5%) primary and 999 (83.1%) secondary; 129 (86%) of the primary cases with an MPN marker; tissue injury 32.2%, infection 17.1%, chronic inflammatory disorders 11.7%, iron deficiency anaemia 11.1%. Grade C, agreeing: single-centre retrospective hospital series (expert-opinion basis for naming reactive causes first).")
ev("f11-E16", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 15,723 deliveries, 7,351 women analysed, 4,568 uncomplicated, 2,586 with complications, 197 with pre-existing disorders; first-trimester mean 251,000 (mean gestation 8.7 weeks) against 273,000 per cubic millimetre in 8,885 NHANES non-pregnant women (P < 0.001); 9.9% below 150,000 at delivery; 45 women (1.0%) below 100,000; 12 below 80,000, of whom 5 (0.1%) had no alternative cause. Grade C rather than the author's B: a descriptive distribution study (laboratory-interval basis) with no outcome; by the convention applied to reference and distribution studies it is C. This does not weaken the state split: a pregnancy row carries no band, and the fall in the count from the first trimester, which the split rests on, is confirmed.")
ev("f11-E17", "confirmed", "C", True,
   "Found word for word in the Conclusions of the same PubMed abstract. Grade C: the authors' recommendation (expert opinion) drawn from their cohort; it is the basis of the pregnancy row's action limit below 100,000/µL.")
ev("f11-E18", "confirmed", "C", True,
   "Found word for word in the Europe PMC full text of PMC11899349 (quote-check: exact normalised substring; also present in the NCBI copy). Section 3.3 text on Figure 6 and Table 3 re-read: 'Platelets 96 45 10⁹/L 37 (21) 25 (11) 30 (10–100) 20 ** (10–50) 894 (206) 984 (73) 1000 (100–1000) 1000 (600–1000)', the columns being listing frequency (2024, 1990), low mean (1990, 2024), low median (1990, 2024), high mean (1990, 2024) and high median (1990, 2024): 1990 low median 30, 2024 low median 20, high median 1000 ×10^9/L in both years; 50 lists from university hospitals, Level 1 trauma centres, centres of excellence and high-performing hospitals. The 2026 correction (PMID 42449917, PMC13360011, opened through NCBI) changes only Table 8, the point-of-care limits, and states that the conclusions are unaffected, as the record says. Grade C, agreeing: a survey of institutional lists (expert opinion).")
ev("f11-E19", "confirmed", "C", True,
   "Found word for word in the same full text (the sentence after f11-E18). The 50 and 100 ×10^9/L thresholds are the authors' citation of their reference 26, which was not opened. Grade C: expert opinion; basis of the 100,000/µL action limit together with f11-E12 and f11-E13.")
ev("f11-E20", "confirmed", "C", True,
   "Found word for word in the same paragraph of the full text. High median 1000 ×10^9/L in 1990 and 2024, range narrowed from 100-1000 to 600-1000; 450 ×10^9/L cited as the thrombocytosis threshold (their reference 27). Grade C: survey of institutional lists.")
ev("f11-E21", "confirmed", "C", True,
   "Found word for word in the Europe PMC full text of PMC6178782 (quote-check: exact normalised substring): Table 1, 'Adult and paediatric limits of laboratory results which, after confirmation through repeat measurement in the same sample, need urgent notification', row 'Platelet count | < 20,000/ml > 1 million/ml | Risk of haemorrhage. Exclude EDTA-induced thrombocytopenia. Risk of thrombosis.' EJIFCC 2003;14(1):11-18, PMID 30323722 confirmed (publisher: International Federation of Clinical Chemistry and Laboratory Medicine). The table prints '/ml' for per-microlitre counts, as the note says; the record's location should read Table 1 (adult and paediatric limits), a wording point only. Grade C: expert list.")
ev("f11-E22", "confirmed", "C", True,
   "Found word for word in the PubMed abstract (JAMA 1990;263(5):704-7): mean low and high critical limits for platelets 37 and 910 ×10^9/L in a national survey of US trauma and medical centres. Grade C: survey of institutional lists.")
ev("f11-E23", "corrected", "C", True,
   "The quote 'B-Thrombocytes, x10 9 /L < 30 -' is in the full text as served by NCBI efetch (db=pmc, PMC6294153), in the laboratory's critical-value table between 'P-Sodium ion, mmol/L < 120 > 160' and the footnote 'B - blood' (no high limit), and on the PMC article page; the paper is Biochem Med (Zagreb) 2019;29(1):010704, Laboratori Clínic, Hospital Universitari de Bellvitge, 5,723 critical values over six months, as the record says. The programme's tool could not open it: Europe PMC's fullTextXML endpoint answered HTTP 500 three times in this task for this open-access article (search metadata: inEPMC Y, isOpenAccess Y), and the abstract fallback has no table, so quote-check reports the record 'not found' and the family stands at 32 of 33 quotes (97.0%), below the 98% of check E2. Corrected: identifier type 'url', value 'https://pmc.ncbi.nlm.nih.gov/articles/PMC6294153/', the form f11-E02 and f11-E14 already use; a test record with that identifier was found by quote-check as an exact normalised substring (see corrections). Grade C: institutional list (expert opinion).")
ev("f11-E24", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 463 paired capillary and venous samples from 428 adults (71% haematology patients, 29% potential donors), Advia 120 (Bayer); no difference in platelets (-1 ×10^9/L); no significant differences in severe thrombocytopenia. Grade C: method comparison (laboratory basis).")
ev("f11-E25", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Six successive drops from one fingerprick in each of 11 donors on a haematology analyser; CV up to 4 times higher for platelets than venous controls; fluctuations within instrument variability from 60 to 100 µL; 'caution when using measurements from a single drop'. Grade C: method study with 11 donors.")
ev("f11-E26", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. 170 healthy adults analysed in duplicate within 30 minutes and after 4 hours; 20 subjects re-analysed up to 24 hours at room temperature and 4 °C with K2-EDTA or Na-citrate; Sysmex XE-5000; MPV stability depends on anticoagulant, storage temperature and time; inverse non-linear correlation with the platelet count. Grade C: method study.")
ev("f11-E27", "confirmed", "C", True,
   "Found word for word in the Subjects and methods of the f11-E10 abstract: MPV measured in 93 donors in citrate (1:4 v/v) 'to avoid the platelet swelling induced by EDTA'. Grade C: method choice in a reference-interval study.")
ev("f11-E28", "confirmed", "C", True,
   "Found word for word in the Results of the same abstract: MPV 9.6 (0.7) fL with no significant sex difference, reference range 7.8-11 fL; inverse relation with the count, r = -0.282 (p = 0.006, n = 93) in citrate and r = -0.364 (p <= 0.0005, n = 1,430) in EDTA. Grade C: reference-interval study; supports no sex split and the inverse relation named in the MPV messages.")
ev("f11-E29", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. Numbers confirmed: 39,531 men and women of the Copenhagen General Population Study, 1,300 myocardial infarctions; tertiles +37% (18-59%) and +30% (12-52%); quintiles +13, +35, +31 and +29%; octiles as listed; MPV at or above 7.4 against below 7.4 fL +38% (8-75%); antiplatelet therapy did not modify the estimates. Grade C, agreeing: tier-2 size, but the follow-up length and the handling of reverse causation are not in the abstract, and the excess is flat from the third quintile; supports class e.")
ev("f11-E30", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. 16 cross-sectional studies (2,809 patients): MPV 0.92 fL (0.67-1.16) higher in acute myocardial infarction; 3 cohorts (3,184 patients): death after infarction OR 1.65 (1.12-2.52); 5 cohorts (430 patients): restenosis, MPV 0.98 fL higher; causality and clinical use 'remains unknown'. Grade C: meta-analysis of patient studies.")
ev("f11-E31", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. 2,298 Turkish adults aged 18 to 92 screened by stepwise exclusion; 326 healthy (204 women, 122 men, mean age 41 ± 16); CELL-DYN 3700 SL within 6 hours; mean MPV 8.9 ± 1.4 fL; no significant difference among age groups; 95% between 7.2 and 11.7 fL. Grade C: reference study on one analyser.")
ev("f11-E32", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. 32 studies appraised with BIVAC (4 A, 2 B, 20 C, 6 D); platelet (except MPV and PDW) and leukocyte CVI estimates 5-15%, erythrocyte parameters below 3%. Grade C rather than the author's B: a biological-variation meta-analysis is a laboratory-basis source and is graded C by the convention applied in f10 (f10-E17, f10-E18); the per-analyte values in the EFLM database were not opened, so the RCV stays a placeholder.")
ev("f11-E33", "confirmed", "C", True,
   "Found word for word in the PubMed abstract. 43 healthy subjects (21 sampled weekly for 5 weeks, 22 daily for 5 days, 8 in both), Sysmex XN, CV-ANOVA after outlier analysis; medium-term CVI 2.3-7.0% and short-term 1.1-8.6%; CVG 7.1-20.7% and 6.8-48.6%; each laboratory should estimate local RCVs. Grade C: biological-variation study.")

evidence_verdicts = [EV[e["id"]] for e in research["evidence"]]
assert len(evidence_verdicts) == 33

final_rows = []
for r in research["rows"]:
    row = copy.deepcopy(r)
    row["grade"] = "D"
    final_rows.append(row)

corrections = [
    {
        "row_key": ROW_NONE,
        "field": "evidence[f11-E23].identifier",
        "from": {"type": "pmcid", "value": "PMC6294153"},
        "to": {"type": "url", "value": "https://pmc.ncbi.nlm.nih.gov/articles/PMC6294153/"},
        "reason": (
            "Correction to the research file's evidence record f11-E23 (Arbiol-Roca 2019, Bellvitge critical-value list), for the fixer: the quote "
            "is verbatim in the article's critical-value table, but the programme's quote-check tool resolves a 'pmcid' identifier through Europe "
            "PMC's fullTextXML endpoint, which answered HTTP 500 three times in this task for PMC6294153 although the article is open access and in "
            "Europe PMC (search metadata inEPMC Y, isOpenAccess Y), and its fallback, the Europe PMC abstract, carries no table. The tool therefore "
            "reports f11-E23 'not found' and the family stands at 32 of 33 quotes (97.0%), below the 98% threshold of check E2. With the PMC article "
            "page as a 'url' identifier, the form f11-E02 and f11-E14 already use, a test record carrying the same quote was found by quote-check as "
            "an exact normalised substring (score 1). The quote, the source and the value (low limit 30 ×10^9/L, no high limit) do not change; the "
            "critical_low bound also rests on f11-E18, f11-E21 and f11-E22, all found."
        ),
        "evidence_ids": ["f11-E23"],
    }
]

physician_questions = [
    {
        "id": "f11-VQ-01",
        "row_key": ROW_NONE,
        "question": (
            "If you choose option B of PQ-f11-01 (keep the platelet count in class a with an optimal band of 175,000-300,000/µL), the verifier's "
            "grade for that band is C, so under PLAN section 5 it can be shown only as an entry in the grade C decision table (at most 20 entries), "
            "and a grade C band is not scored. Do you want it listed there, or do you confirm option A (class c, no optimal band, the verified row)?"
        ),
        "why": (
            "The band rests on one source, GESUS (f11-E01): 21,252 adults, but the abstract gives no follow-up length and shows no handling of reverse "
            "causation beyond adjustment for the Charlson index and C-reactive protein, and the paper is not open access, so tier 2 of the evidence "
            "standard is not demonstrated on the opened text; the band is a threshold statement ('<175 or >300 ×10^9/L'), not a nadir with a "
            "confidence interval. The other cohorts give no band EVA could copy: the Women's Health Initiative (f11-E04, grade B) reports deciles "
            "whose cut-points are not in the abstract; the Taiwanese cohort (f11-E02) is restricted to ages 65 and over and its lowest-risk stratum "
            "is 200-<300 ×10^9/L; Moli-sani (f11-E03) found no excess mortality with higher counts. A lower bound of 175,000/µL would read about a "
            "third of healthy Spanish men as 'below optimal' (mean 195,000, SD 42,000/µL in 1,053 donors, f11-E10; z = -0.48, computed by the "
            "verifier). Scoring: marker-classes.json scores a class a marker only when its band is grade A or B, so option B keeps the marker out of "
            "the score either way."
        ),
        "evidence_ids": ["f11-E01", "f11-E04", "f11-E02", "f11-E03", "f11-E10"],
        "options": [
            "A. Confirm class c, no optimal band, not scored; critical limits 30,000 and 1,000,000/µL and the two action limits as verified (verifier's recommendation).",
            "B. Class a with an optimal band of 175,000-300,000/µL recorded as a grade C decision-table entry resting on f11-E01, signed by you; not scored while the grade is C.",
        ],
    }
]

notes = (
    "Method. 0 WebSearch calls; 50 fetches: one eutils efetch call returning the 32 PubMed abstracts behind the records and the sources named in the "
    "scope and notes (22 PMIDs of the records plus 26265696, 35767897, 40075851, 30323722, 30591814, 15195993, 23518452, 8937589, 25552150 and 42449917); "
    "the quote-check tool (docs/signoff/tools/quote-check.js) run on the research file with --cache-dir in the verifier's scratch directory so that "
    "docs/signoff/work/sources-cache was not written (30 requests; 32 of 33 quotes found as exact normalised substrings, 0 weak, 1 not found, 0 "
    "unopenable; the one not found is f11-E23, see below); Europe PMC fullTextXML for PMC11899349 and PMC6178782 (served), PMC6294153, PMC4592279, "
    "PMC9479031, PMC13360011 and PMC3561305 (HTTP 500 each) and NCBI efetch db=pmc for the same seven (all served; PMC4592279 and PMC9479031 front "
    "matter only, so their quotes were checked on the PMC article pages the tool fetched); two Europe PMC searches (metadata of PMC6294153 and of the "
    "GESUS paper, DOI 10.1016/j.thromres.2016.08.012: not open access, no PMCID); one retry of PMC6294153; a two-record test file through quote-check "
    "(PMID 30591814 abstract, PMC6294153 page). Every number in every record (n, follow-up, ages, analysers, hazard ratios, intervals, percentages) "
    "was compared with the opened text; the only discrepancy is in a note, f11-E07, whose claim that the PubMed text cuts the MPV estimate is not "
    "true of the text opened today (MPV OR 0.990, 0.945-1.038). Repository facts re-read: docs/vendor/echevarne/catalogo-2026-08-25.tsv lines 198, 199 "
    "and 221; OBX segments 8 and 9 of docs/context/training/EVA2026T1_X68800189.ORU (CR-separated); src/lib/biomarkers/longevity-score.ts line 243; "
    "the production snapshot rows in the input file (platelet_count 150,000-450,000 with optimal 175,000-300,000; mpv 6-11 with optimal 6-11); "
    "marker-classes.json (draft c and e); critical-limits.json entries[6] and critical-limits.md (platelets 30,000 / 1,000,000, alternative 20,000); "
    "hazard-log.md H13; state-rules.md sections 2.1 and 2.4; the banned-terms block of wording-rules.md; the M2, M3 and M4 code of "
    "scripts/signoff/checks/messages.ts (M3 scans zone messages and app strings, not method notes or critical_none_reason, so the word 'critical' in "
    "the pregnancy method note and in MPV's critical_none_reason is not a hit, as in 54 of 60 such reasons in earlier families). Grading rule applied "
    "(PLAN section 5, as the f04 and f10 verifiers applied it): A for Mendelian randomisation or randomised trials that give the bound or an "
    "individual-data causal estimate; B for prospective cohorts of at least 10,000 adults with at least 5 years of follow-up, or pooled consortia, with "
    "reverse causation addressed in the opened text, for two-sample Mendelian randomisation of summary statistics with a hard outcome and no bound, and "
    "for named guideline or consensus decision limits; C for every other confirmed source, including reference-interval, distribution, method, "
    "pre-analytical and biological-variation studies, reviews, institutional lists, cohorts below the tier-2 size or whose follow-up or reverse-causation "
    "handling the opened text does not show; D for a source that cannot be opened or a quote not found (none here). Grades changed from the author's "
    "proposals: f11-E11, f11-E16 and f11-E32 from B to C (laboratory-basis sources, by convention); all others kept. Row grades: D on all three rows "
    "because none carries an optimal band (PLAN section 5; verify schema), not because any source failed. Rows: no bound, class, limit or message "
    "changed; final_rows equal the research rows plus the grade. Decisions confirmed: platelet count class c (PQ-f11-01, with f11-VQ-01 on the grade of "
    "the alternative), reference 130,000-450,000/µL from Echevarne (PQ-f11-02), critical limits from the draft table, action limits at 100,000/µL and at "
    "450,000/µL on repeat, a pregnancy row with the fixed note and a pregnancy action limit at 100,000/µL, no lactation row (the 'none' row applies, "
    "C1), MPV class e with no limits. Items for the fixer: (1) f11-E23 identifier to the PMC page URL (corrections[0]); (2) f11-E07 note on the MPV "
    "estimate; (3) f11-E21 location wording (Table 1 is 'Adult and paediatric limits'); (4) the 'at or above 450,000' wording of the second action limit "
    "against the classifier's 'above 450,000' zone, if the app's action-limit rule is 'at or above'. Not verified in this task and resting on no bound: "
    "the GESUS follow-up length (full text not open access), the WHI decile cut-points (full text not opened), the per-analyte CVI of the platelet count "
    "and MPV in the EFLM Biological Variation Database (not opened), and Shah et al.'s reference 26 behind the 100 and 50 ×10^9/L thresholds. The "
    "programme's NHANES distributions carry no platelet count or MPV, so check N1 is blocked on data for this family, as the author says. AI work "
    "product: an independent AI verifier that did not write the research file; a licensed physician reviews and signs."
)

doc = {
    "schema_version": "1",
    "family": "f11_platelets",
    "verified_at": "2026-11-09",
    "research_sha256": sha,
    "verifier_role": "independent physician-verifier (AI agent that did not write the research file), batch B04, round 1; AI work product for review by a licensed physician",
    "row_verdicts": row_verdicts,
    "evidence_verdicts": evidence_verdicts,
    "final_rows": final_rows,
    "corrections": corrections,
    "evidence": [],
    "physician_questions": physician_questions,
    "searches_used": 0,
    "fetches_used": 50,
    "notes": notes,
}

with open(out_path, "w", encoding="utf-8") as f:
    json.dump(doc, f, ensure_ascii=False, indent=1)
    f.write("\n")
print("written", out_path, "research sha", sha)
