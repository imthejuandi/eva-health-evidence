// strip tags like the repo's sources.js stripTags (approximation for reading)
const fs=require("fs");
const s=fs.readFileSync(process.argv[2],"utf8");
const named={amp:"&",lt:"<",gt:">",quot:'"',apos:"'",nbsp:" ",ndash:"–",mdash:"—",le:"≤",ge:"≥",micro:"µ",deg:"°",plusmn:"±",times:"×"};
const dec=(x)=>x.replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCodePoint(parseInt(h,16))).replace(/&#(\d+);/g,(_,d)=>String.fromCodePoint(Number(d))).replace(/&([a-z]+);/gi,(m,n)=>(n.toLowerCase() in named?named[n.toLowerCase()]:m));
const t=dec(s.replace(/<script[\s\S]*?<\/script>/gi," ").replace(/<style[\s\S]*?<\/style>/gi," ").replace(/<!--[\s\S]*?-->/g," ").replace(/<\/?(p|div|br|li|tr|td|th|h[1-6]|sec|title|abstract|table|caption|label|section|article)\b[^>]*>/gi,"\n").replace(/<[^>]+>/g," ")).replace(/[ \t]+/g," ").replace(/\n\s*\n+/g,"\n").trim();
fs.writeFileSync(process.argv[3],t);
console.log(process.argv[3], t.length);
