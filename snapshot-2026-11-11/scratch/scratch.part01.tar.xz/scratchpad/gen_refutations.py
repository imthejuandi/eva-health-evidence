import json, os, sys

ROOT = "/home/user/eva-health"
OUT = os.path.join(ROOT, "docs/signoff/work/refutations/round-1")
EN = "docs/signoff/work/compiled/B01-r1/biomarker-ranges-en.json"
ES = "docs/signoff/work/compiled/B01-r1/rangos-biomarcadores-es.json"
SRC = "docs/signoff/work/compiled/B01-r1/biomarker-sources.json"
CH = "docs/signoff/work/compiled/B01-r1/CHANGES.md"
CR = "docs/signoff/work/compiled/B01-r1/compile-report.json"
CK = "docs/signoff/work/checks/B01-r1.json"
AT = "docs/signoff/ACCEPTANCE-TEST.md"
PLAN = "docs/signoff/PLAN.md"
RES = "docs/signoff/work/research/f03_kidney.json"
VER = "docs/signoff/work/verify/f03_kidney.json"
WR = "docs/signoff/work/governance/wording-rules.md"
SR = "docs/signoff/work/governance/state-rules.md"
CL = "docs/signoff/work/governance/critical-limits.json"
DIST = "docs/signoff/work/nhanes/distributions.json"
ZC = "src/lib/biomarkers/zone-classifier.ts"
MSG = "scripts/signoff/checks/messages.ts"
LIM = "scripts/signoff/checks/limits.ts"
DET = "src/app/[locale]/(dashboard)/biomarker/[key]/detail-client.tsx"
PERS = "scripts/signoff/fixtures/personas.json"
MODEL = "claude-opus-5-5"


def fl(file, line=None, quote=None, text=None):
    e = {"kind": "file_line", "file": file}
    if line is not None:
        e["line"] = line
    if quote is not None:
        e["quote"] = quote
    if text is not None:
        e["text"] = text
    return e


def cr(file, line=None, text=None, quote=None):
    e = {"kind": "check_result", "file": file}
    if line is not None:
        e["line"] = line
    if text is not None:
        e["text"] = text
    if quote is not None:
        e["quote"] = quote
    return e


def df(file, text, line=None):
    e = {"kind": "definition", "file": file, "text": text}
    if line is not None:
        e["line"] = line
    return e


def sq(idtype, value, quote, text=None):
    e = {"kind": "source_quote", "identifier": {"type": idtype, "value": value}, "quote": quote}
    if text:
        e["text"] = text
    return e


# ---- shared evidence snippets ----
HONG_Q = sq("pmcid", "PMC9865447",
            "Blood Urea Nitrogen (mmol/L) P for Trend Q1 <3.57 Q2 3.57–4.59 Q3 4.60–5.70 Q4 ≥5.71 ... Model 4 1 [Reference] 1.06 (0.92,1.21) 1.05 (0.91,1.22) 1.48 (1.28,1.72)",
            "Opened in this task: Europe PMC fullTextXML of PMC9865447, table 2, all-cause mortality rows. 5.70 mmol/L x 2.801 = 16.0 mg/dL. The number is in the full-text table, not in the abstract.")
YUAN_ABS = sq("pmid", "40983592",
              "Compared to the first quintile, the hazard ratios (HR) [95% confidence intervals (CI)] for all-cause mortality were as follows: second quintile, 1.05 (0.82-1.34); third quintile, 1.29 (1.03-1.60)",
              "Opened in this task (PubMed efetch). The abstract gives quintile hazards but no quintile cut-offs in mg/L.")
YUAN_FT = sq("pmcid", "PMC12456039",
             "quintile 1 (<0.640 mg/L), quintile 2 (0.640–0.717 mg/L), quintile 3 (0.718–0.799 mg/L), quintile 4 (0.800–0.932 mg/L), and quintile 5 (>0.932 mg/L)",
             "Opened in this task: Europe PMC fullTextXML of PMC12456039, results section; the same full text states a Siemens cystatin C immunoassay on the Dimension Vista 1500. The 0.717 edge is in the full text, not the abstract.")
HUSS_T3 = sq("pmcid", "PMC10286512",
             "80-90 mL/min/1.73m 2 (reference for 50-65 years) ... Adjusted HR 1.15 (1.08 to 1.22) 1.02 (0.98 to 1.05) 1.00 (reference) 90-100 mL/min/1.73m 2 (reference for 40-50 years) ... Adjusted HR 1.05 (1.00 to 1.10) 1.00 (reference) 1.11 (1.09 to 1.12)",
             "Opened in this task: Europe PMC fullTextXML of PMC10286512, table 3 (all-cause mortality), columns 18-39, 40-49, 50-65. At 18-39, 90-100 is within 10% of the 100-110 referent and 80-90 is not.")
E2_FAIL = cr(CK, 1163, "E2 status fail: '0 of 131 quotes found (0.0%, need 98%); 131 unopenable'. Every f03 record (lines 834-1046) reads 'not in the cache or not openable (not in cache (offline)); verifier grade is B, must be D' where the verifier grade is B.")
E2_DEF = df(AT, "E2: 'Quotes are confirmed against the cached source text ... at least 98% of quotes found ... unopenable sources graded D'. PLAN section 5 (line 113): 'A script checks every quote against the source text, fetched ... and cached in the repo. A source that cannot be opened is grade D.' The grade table (lines 116-119) allows a narrower optimal band at grade A or B only 'with a confirmed quote'.", 40)
CACHE_NOTE = fl("docs/signoff/work/sources-cache", None, None, "The cache directory holds one source (2 files: ff41623e...json and .txt); none of the f03 identifiers is cached, which is why E2 ran with every f03 source 'not in cache (offline)'.")

issues = []

# 1 C2
issues.append(dict(
    id="f03_kidney--C2--egfr_creatinine_based.both.18-39.none--none",
    verdict="confirmed",
    reason=("Reproduced in substance. PLAN section 4 says declared pregnancy or lactation gives the laboratory interval only and no optimal category. "
            "The governance rule that would do this exists (state-rules.md 2.1, for every marker, and 2.2 cites the same kidney evidence the judge quotes), "
            "so the judge's sub-claim that no state rule is recorded does not reproduce. But the rule is not in force: the app's picker ignores the declared state "
            "(C1: 12 states ignored by the picker), C2 has no fixtures (blocked), and Q1 shows every pregnancy and lactation persona receiving optimal categories and a score. "
            "Those personas carry eGFR 105 (personas.json), which falls in the optimal band (90 or more) of the 18-39 eGFR row. "
            "So a pregnant client does get an optimal eGFR category from this row, which the definitions forbid. "
            "The fix is app-level, plus C2 fixtures for the f03 markers; no f03 pregnancy row is needed, because the governance rule already says it."),
    evidence=[
        cr(CK, 4504, "Q1: 'pregnancy persona sees 31 optimal categories, score 100' (pregnancy_t1); line 4472: 'lactation persona sees 36 optimal categories, score 100'."),
        fl(PERS, 2293, None, "Persona pregnancy_t1 (id at line 2238) carries egfr_creatinine_based 105 (also pregnancy_t2 line 2361, pregnancy_t3 line 2429); pregnancy and lactation personas, with creatinine 0.5-0.75 and BUN 8-14; personas.json gives physiological_state 'pregnancy' or 'lactation'."),
        cr(CK, 576, "C1 metric states_ignored_by_picker: 12 (of 13 recorded states); C2 status blocked at line 588: state-fixtures-result.json missing."),
        fl(EN, 4698, None, "egfr_creatinine_based|both|18-39|none: Optimal_Low 90, Optimal_High null; the row carries no state handling."),
        fl(SR, 285, "With `pregnancy_current` or `lactating` declared, the app shows for **every** marker:"),
        df(PLAN, "'declared pregnancy or lactation: the laboratory interval only, no optimal category, no score, no biological age, one fixed note'.", 84),
    ],
    notes="The judge's claim that f03 has no recorded state rule is not reproduced: state-rules.md 2.1 and 2.2 cover all markers and cite the kidney evidence. The defect confirmed is that the rule is not applied."
))

# 2 C3
issues.append(dict(
    id="f03_kidney--C3--none--none",
    verdict="confirmed",
    reason=("Reproduced. docs/signoff/work/families/ does not exist, so there is no f03_kidney family page and C3 is blocked. "
            "PLAN section 4 requires each family page to state its scope and an explicit pass for ages 70-84 and 85 and over, and C3 requires an explicit policy for 18-19 and 85+. "
            "In the compiled rows only eGFR carries age groups (18-39, 40-84, 85+) and its Method_Note states the 18-19 policy; BUN, urea, creatinine, cystatin C and the ratio carry one 'All Adults' row with no written 70-84 or 85+ pass. "
            "The BUN Method_Note itself cites 14-23 mg/dL in adults over 70 against the 16 mg/dL ceiling (Aono 1994 abstract, opened in this task). "
            "A blocked check is never a pass, and the missing artefact is internal to the programme, not external data."),
    evidence=[
        cr(CK, 595, "C3 status blocked: 'docs/signoff/work/families/*.md (family pages) is missing'."),
        fl("docs/signoff/work/families", None, None, "Directory absent (ls: cannot access 'families': No such file or directory)."),
        fl(EN, 4504, None, "BUN Method_Note: 'community-dwelling adults over 70 run 14-23 mg/dL, f03-E21 ... so one adult band is kept' with Optimal_High 16; no 70-84 or 85+ statement."),
        sq("pmid", "8207875", "The estimated normal range of BUN was 14-23 mg/dl both in male and female elderly subjects", "Opened in this task (PubMed efetch): 332 apparently healthy subjects aged 70 or over."),
        df(PLAN, "'Every family gets an explicit pass for ages 70 to 84 and 85 and over' (line 90); 'Each family page says who its ranges are for' (line 91).", 90),
        df(AT, "C3: 'Every family page states its scope ... Ages 18 to 19 and 85 and over have an explicit policy'; pass 100% of family pages. 'A blocked check is never a pass.'", 33),
    ],
))

# 3 D5
issues.append(dict(
    id="f03_kidney--D5--none--none",
    verdict="confirmed",
    reason=("Reproduced. The compiled biomarker-sources.json is a seed artefact (compile-sources.js: supabase/seed-data/biomarker-sources.json). "
            "Its summary_en and summary_es texts for the f03 markers still state the September bounds while the 'ranges' blocks of the same entries carry the compiled rows: "
            "BUN 'up to 18 mg/dL' against 16; urea 'optimal 21-39 ... reference 15-54' against 21-34 and 21-54; ratio 'optimal 11-18' against no optimal band; "
            "cystatin C 'up to 0.85 mg/L' against 0.72; eGFR '75 or above at 40-59 and 65-105 at 60 and over; reference starts at 75 at 18-39' against 75-105 at 40-84, none at 85+, floor 60. "
            "One seed artefact therefore states two sets of bounds for the same rows. The D5 script compares bounds, not prose, so it does not flag the summaries, "
            "but it independently fails on the same f03 bound changes (BUN 16 vs 18, cystatin C 0.72 vs 0.85, urea, eGFR rows) as unexplained, and the definition 'one source of truth' does not allow the contradiction."),
    evidence=[
        fl(SRC, 12588, "EVA's optimal BUN runs from the lower reference limit up to 18 mg/dL for all adults, within a reference range of 10–25 mg/dL"),
        fl(SRC, 15064, "EVA's optimal urea is 21–39 mg/dL for all adults, within a reference range of 15–54 mg/dL"),
        fl(SRC, 12819, "EVA's optimal BUN/creatinine ratio is 11–18 for all adults, within a reference range of 10–20."),
        fl(SRC, 13536, "it runs from the lower reference limit up to 0.85 mg/L, within a reference range of 0.62–1.11 mg/L"),
        fl(SRC, 13807, "EVA's optimal eGFR is 90 mL/min/1.73m² or above at ages 18–39, 75 or above at 40–59 and 65–105 mL/min/1.73m² at 60 and over; the reference range starts at 75 at ages 18–39"),
        fl(SRC, None, None, "Read with a JSON parser in this task: the same entries' 'ranges' blocks hold bun 10-25 optimal 10-16; urea 21-54 optimal 21-34; ratio 10-20 no optimal; cystatin_c 0.62-1.11 optimal to 0.72; eGFR 18-39 floor 60 optimal 90+, 40-84 optimal 75-105, 85+ no optimal."),
        fl("docs/signoff/tools/lib/compile-sources.js", 1, "compile-sources.js — supabase/seed-data/biomarker-sources.json, updated per family"),
        cr(CK, 508, "D5 fail, '42 unexplained differences'; f03 entries include 'optimal_high seed 16 vs production 18' (line 357) and 'optimal_high seed 0.72 vs production 0.85' (line 365)."),
        df(AT, "D5: 'One source of truth. Seed English = seed Spanish = migration files = latest production snapshot plus the documented pack changes.'", 24),
    ],
    notes="Scope caveat: the D5 runner reads bounds only. The verdict rests on the definition, which the prose contradicts, and on D5's own f03 failures."
))

# 4 E2 bun high
issues.append(dict(
    id="f03_kidney--E2--bun.both.All_Adults.none--high",
    verdict="confirmed",
    reason=("Reproduced. E2 fails with 0 of 131 quotes found and marks f03-E41, E41b, E42, E43 and E45 (the records CHANGES.md lists for this bound) as not in the cache, 'verifier grade is B, must be D'. "
            "Under PLAN section 5 a narrower optimal band at grade A or B needs a confirmed quote, and none is confirmed by the script. CHANGES.md line 166 records optimal_high 18 to 16 as '**unexplained**'. "
            "Correction to the judge: the 16 mg/dL edge does exist in the source. I opened PMC9865447 full text: table 2 gives Q3 4.60-5.70 and Q4 >=5.71 mmol/L with all-cause Model 4 HRs 1.06, 1.05 and 1.48, "
            "so 5.70 mmol/L x 2.801 = 16.0 mg/dL is the edge of the lowest-risk quartiles. The defect is the missing cache and the missing change reason, not a missing number; until both are fixed the definitions do not allow the band."),
    evidence=[
        fl(CH, 166, "| bun|both|All Adults | optimal_high | 18 | 16 | tighten | f03-E41, f03-E41b, f03-E42, f03-E43, f03-E45 | **unexplained** |"),
        cr(CK, 1006, "'source pmcid:PMC9865447 not in the cache or not openable (not in cache (offline)); verifier grade is B, must be D' (key f03_kidney|f03-E41|unopenable; also E41b line 1002, E42 line 1010)."),
        E2_FAIL,
        HONG_Q,
        fl(VER, None, None, "evidence_verdicts f03-E41b: 'PMC full text opened; table 1 quartile labels verbatim ... (3.57 = 10.0, 5.70 = 16.0 mg/dL)' - the verifier's confirmation is manual, not by the E2 script."),
        E2_DEF,
    ],
))

# 5 E2 cystatin high
issues.append(dict(
    id="f03_kidney--E2--cystatin_c.both.All_Adults.none--high",
    verdict="confirmed",
    reason=("Reproduced. CHANGES.md line 216 records optimal_high 0.85 to 0.72 as '**unexplained**', and E2 marks f03-E18, E18b, E38, E39 and E40 not in the cache with 'verifier grade is B, must be D'. "
            "The judge is right that the opened abstract (PMID 40983592) carries no cut-off: I opened it, it gives quintile HRs only. "
            "The 0.717 mg/L edge is in the PMC12456039 full text (quintile 2 0.640-0.717 mg/L; quintile 2 HR 1.05, quintile 3 HR 1.29), which I also opened, so the number exists but is not script-confirmed. "
            "The row's own Method_Note says the cut-off comes from a pre-standardisation assay, 'so 0.72 is approximate; standardised healthy medians are 0.78-0.79 mg/L', which is what the judge reports. "
            "Under PLAN section 5 the narrowed ceiling is not allowed without a confirmed quote; the change reason is also missing."),
    evidence=[
        fl(CH, 216, "| cystatin_c|both|All Adults | optimal_high | 0.85 | 0.72 | tighten | f03-E18, f03-E18b, f03-E38, f03-E39, f03-E40 | **unexplained** |"),
        cr(CK, 910, "'not in the cache or not openable (not in cache (offline)); verifier grade is B, must be D' for f03-E18 (line 910) and f03-E18b (line 906)."),
        YUAN_ABS,
        YUAN_FT,
        fl(EN, 4864, "The outcome cut-offs come from NHANES 1999-2004 (Siemens Dade Behring assay, before ERM-DA471/IFCC standardisation), so 0.72 is approximate; standardised healthy medians are 0.78-0.79 mg/L (f03-E20)."),
        E2_DEF,
    ],
))

# 6 E2 egfr 18-39 low
issues.append(dict(
    id="f03_kidney--E2--egfr_creatinine_based.both.18-39.none--low",
    verdict="confirmed",
    reason=("Reproduced. E2 marks f03-E03b (PMC10286512) and f03-E03 (PMID 37353230) not in the cache with 'verifier grade is B, must be D'. "
            "The opened abstract gives the design and the 100-110 referent at 18-39 but not the 90-100 hazard. I opened the PMC10286512 full text: "
            "table 3 gives HR 1.05 (1.00 to 1.10) at 90-100 and 1.15 (1.08 to 1.22) at 80-90 for ages 18-39, so 90 is the within-10% edge and the number exists. "
            "It is not script-confirmed, and PLAN section 5 allows a grade B narrowed band only with a confirmed quote; E2 fails. The defect is the uncached source."),
    evidence=[
        cr(CK, 842, "'source pmcid:PMC10286512 not in the cache or not openable (not in cache (offline)); verifier grade is B, must be D' (f03-E03b); line 846 the same for pmid 37353230 (f03-E03)."),
        sq("pmid", "37353230", "relative to age specific eGFR referents (100-110 mL/min/1.73m2) for ages 18-39 years, 90-100 for 40-49 years, 80-90 for 50-65 years)", "Opened in this task (PubMed efetch); 8 703 871 adults, median follow-up 9.2 years."),
        HUSS_T3,
        fl(EN, 4698, None, "egfr_creatinine_based|both|18-39|none: Optimal_Low 90; Method_Note cites 'f03-E03, f03-E03b: within 10% of the lowest-risk referent'."),
        E2_FAIL,
        E2_DEF,
    ],
))

# 7 E2 none
issues.append(dict(
    id="f03_kidney--E2--none--none",
    verdict="confirmed",
    reason=("Reproduced. E2 fails: 0 of 131 quotes found, 131 unopenable, and every f03 record (f03-E01 to f03-V03) is 'not in cache (offline)'; where the verifier grade is B the script says 'must be D'. "
            "The sources cache holds one source, none of them f03. The pass rule (98% found) is not met, and under PLAN section 5 the narrowed f03 bands (BUN 16, urea 34, cystatin C 0.72, eGFR 90 at 18-39, eGFR 75-105 at 40-84) have no script-confirmed quote. "
            "I agree with the judge's own spot check that the numbers exist: I opened PMC9865447 (5.70/5.71 mmol/L), PMC12456039 (0.717 mg/L) and PMC10286512 (table 3, 90-100 and 100-110). "
            "So the failure is the missing cache. It is still a failure of E2 as defined."),
    evidence=[
        E2_FAIL,
        CACHE_NOTE,
        HONG_Q,
        YUAN_FT,
        HUSS_T3,
        E2_DEF,
    ],
))

# 8 E3 female
issues.append(dict(
    id="f03_kidney--E3--creatinine.female.All_Adults.none--both",
    verdict="confirmed",
    reason=("Reproduced. The female creatinine row carries an optimal band 0.6-0.9 mg/dL inside the 0.55-1.02 interval at verifier grade C (biomarker-sources grades; verify note 'grade C'). "
            "PLAN section 5: at grade C optimal equals the reference interval unless the band is in the grade C decision table; docs/signoff/work/grade-c-table.json does not exist, E3 lists this row as a violation and reports 0 table entries. "
            "Physician question f03-Q01 asks whether to keep the bands as grade C table entries, but a question is not a table entry. "
            "Correction to the judge's side point: a question on the 70-79 female share does exist (f03-Q11 in the research file), though the row's Method_Note gives no id and quotes 18% where N1 computes 21.1%. That side point does not change this verdict."),
    evidence=[
        cr(CK, 1170, "E3 failure key creatinine|female|All Adults|none|grade_c: 'grade C narrowed low+high bound not in the grade C decision table'; grade_c_table_entries 0 (line 1182); status blocked on grade-c-table.json (line 1186)."),
        fl(EN, 4660, None, "creatinine|female|All Adults|none: Normal 0.55-1.02, Optimal 0.6-0.9."),
        fl(SRC, None, None, "signoff.grades for creatinine: creatinine|female|All Adults|none grade C; creatinine|male|All Adults|none grade C (read with a JSON parser)."),
        fl(RES, 2998, None, "f03-Q01: 'Creatinine optimal bands (men 0.8-1.1, women 0.6-0.9 mg/dL): keep them as grade C decision-table entries, or show creatinine as in range / out of range only?'"),
        fl(RES, 3164, None, "f03-Q11 exists: female creatinine interval has no age bands and 18% of healthy NHANES women aged 70-79 sit above 1.02 mg/dL."),
        df(PLAN, "Grade C: 'Optimal equals the reference interval, unless the band is listed in the grade C decision table for the physician, at most 20 entries'.", 118),
    ],
))

# 9 E3 male
issues.append(dict(
    id="f03_kidney--E3--creatinine.male.All_Adults.none--both",
    verdict="confirmed",
    reason=("Reproduced. The male creatinine row carries optimal 0.8-1.1 mg/dL inside the 0.7-1.3 interval at verifier grade C. "
            "No grade C decision table exists (grade-c-table.json missing; E3 lists this row as a violation, 0 table entries), so PLAN section 5 requires optimal to equal the reference interval. "
            "The verifier's own notes support the judge on the sources: f03-E15 (in-hospital mortality, men 0.9-1.0 mg/dL) and f03-E16 (Japanese men 40-55, 4 years) are graded C, "
            "and f03-E14 (NHANES, n = 9,894) gives fully adjusted HRs 0.87, 0.74, 0.83 with the last CI crossing 1. Physician question f03-Q01 exists but is not a table entry."),
    evidence=[
        cr(CK, 1174, "E3 failure key creatinine|male|All Adults|none|grade_c: 'grade C narrowed low+high bound not in the grade C decision table'."),
        fl(EN, 4628, None, "creatinine|male|All Adults|none: Normal 0.7-1.3, Optimal 0.8-1.1, Marker_Class a."),
        fl(VER, None, None, "evidence_verdicts: f03-E15 'in-hospital mortality, reference 0.7-0.8 (all and women) and 0.9-1.0 (men) confirmed. Inpatient cohort: grade C'; f03-E14 'Model 3 all-cause hazards for creatinine are 0.87 (0.75-1.01), 0.74 (0.62-0.89), 0.83 (0.67-1.02) ... grade C'; f03-E16 grade C."),
        fl(RES, 2998, None, "f03-Q01 asks whether to keep the creatinine bands as grade C decision-table entries; no table exists."),
        df(PLAN, "Grade C: 'Optimal equals the reference interval, unless the band is listed in the grade C decision table for the physician, at most 20 entries'.", 118),
        df(AT, "E3: 'A grade C band appears only in the grade C decision table, at most 20 entries'; pass 0 violations.", 41),
    ],
))

# 10 E4 egfr 40-84 low  -> refuted
issues.append(dict(
    id="f03_kidney--E4--egfr_creatinine_based.both.40-84.none--low",
    verdict="refuted",
    reason=("The judge's numbers reproduce, but the definitions allow the row as it stands. I opened the sources: Hussain 2023 enrolled ages 18-65; Hallan 2012 gives HR 3.50 at 18-54 falling to 1.35 at 75 and over for eGFR 45 vs 80; "
            "Astley 2025 gives EKFC medians of 66 (men) and 63 (women) at age 80. E4's rules are: an 'All Adults' optimum must say whether its source is age-stratified; a nadir shift above 20% of band width means a split or a physician question; "
            "bounds with no evidence above 70 are flagged. This row is already an age split (from 40), its split record states evidence_above_70 false, and E4 counts it as the one flagged split and passes. "
            "The floor 75 rests on the pooled CKD-PC lowest-risk band 75-105 (f03-E02, all ages). The physician question the judge asks for already exists: f03-Q04 asks whether the 40-84 floor should be 75, 80, or an age-adapted 70 or 65 for 65-84, "
            "and f03-Q02 covers the EKFC versus CKD-EPI 2021 offset. The defect alleged is a clinical choice routed to the physician as the definitions prescribe, not a rule violation."),
    evidence=[
        cr(CK, 1198, "E4 status pass: '0 age-split problems; 47 statements; 1 splits flagged with no evidence above 70'."),
        fl(RES, 2947, None, "age_splits entry egfr_creatinine_based split_at 40 (line 2938): evidence f03-E03, f03-E03b, f03-E02, f03-E05; 'evidence_above_70': false."),
        fl(RES, 3045, None, "f03-Q04: 'eGFR optimal floor for ages 40-84: 75 (as written), 80, or an age-adapted lower value for 65-84 (70 or 65)?'"),
        sq("pmid", "23111824", "adjusted HRs at an eGFR of 45 mL/min/1.73 m2 vs 80 mL/min/1.73 m2 were 3.50 (95% CI, 2.55-4.81), 2.21 (95% CI, 2.02-2.41), 1.59 (95% CI, 1.42-1.77), and 1.35 (95% CI, 1.23-1.48) in age categories 18-54, 55-64, 65-74, and ≥75 years", "Opened in this task (PubMed efetch)."),
        sq("pmid", "40122341", "in men aged 80 years old, the 5th, 50th and 95th eGFR percentiles were 49 ml/min per 1.73 m2, 66 ml/min per 1.73 m2, and 84 ml/min per 1.73 m2. In 80 year old women this was 46 ml/min per 1.73 m2, 63 ml/min per 1.73 m2, and 81 ml/min per 1.73 m2.", "Opened in this task (PubMed efetch); EKFC equation, not CKD-EPI 2021."),
        df(AT, "E4: 'Every outcome-derived \"All Adults\" optimum says whether its source reports age-stratified estimates ... A nadir shift of more than 20% of the band width between under 60 and 60 and over means a split or a physician question. Bounds with no evidence above age 70 are flagged.'", 42),
    ],
    notes="Refuted on the definitions, not on the clinical point: the share of healthy 70-84-year-olds below 75 is probably large, and f03-Q04 should carry the Astley and Hallan figures when it goes to the physician."
))

# 11 G6 bun low
issues.append(dict(
    id="f03_kidney--G6--bun.both.All_Adults.none--low",
    verdict="confirmed",
    reason=("Reproduced. The BUN Clinical_Notes (EN line 4491, ES line 4491) say 'a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range'. "
            "The compiled urea row is the BUN interval x 2.14, Normal_Low 21 mg/dL, which is BUN 9.81 mg/dL. BUN 7 is urea 14.98, below the urea range, so for BUN 7 to 9.8 the sentence is false; "
            "it describes the replaced production urea floor of 15 (CHANGES.md line 254: normal_low 15 to 21). A rounding sliver (BUN 9.82-9.99) still fits the sentence, so the judge's 'no such blood exists' is slightly too strong, "
            "but the note states a range the compiled rows contradict. The note is client-facing (detail-client.tsx shows clinical_notes), and G6 forbids two statements giving different values for the same quantity."),
    evidence=[
        fl(EN, 4491, "Their reference intervals come from different sources, so a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range."),
        fl(ES, 4491, "un BUN entre 7 y 10 mg/dL queda por debajo del intervalo del BUN aunque la misma sangre esté dentro del intervalo de la urea."),
        fl(EN, 4517, None, "urea|both|All Adults|none Normal_Low 21, Normal_High 54; Reference_Source: 'the Echevarne BUN interval 10-25 mg/dL multiplied by 2.14 ... rounded to 21-54 mg/dL'."),
        fl(CH, 254, "| urea|both|All Adults | normal_low | 15 | 21 | tighten | – | **unexplained** |"),
        fl(DET, 1014, None, "clinicalParas = paragraphsOf(locale === 'es' ? reference?.clinical_notes_es : reference?.clinical_notes_en): the note is shown to the client."),
        df(AT, "G6: 'Every number in the pack that exists in a result file matches it, and no two statements give different values for the same quantity'. G6 itself is blocked (pack missing), so this rests on the definition.", 127),
    ],
))

# 12 G6 bun none
issues.append(dict(
    id="f03_kidney--G6--bun.both.All_Adults.none--none",
    verdict="confirmed",
    reason=("Reproduced. The compiled biomarker-sources.json summaries for f03 state the September bounds while the same file's 'ranges' blocks and the compiled rows carry the new ones: "
            "BUN 'up to 18 mg/dL' (row 16); urea 'optimal 21-39 ... reference 15-54' (row 21-34, 21-54); ratio 'optimal 11-18' (row: none); cystatin C 'up to 0.85' (row 0.72); "
            "eGFR '75 at 18-39' reference and '65-105 at 60 and over' (rows: floor 60; 75-105 at 40-84; none at 85+). "
            "The eGFR entry also gives evidence_grade 'D' at line 13837 while signoff.grades give B, B, D for the three rows. Two statements in one artefact give different values for the same quantity, which G6 forbids."),
    evidence=[
        fl(SRC, 12588, "EVA's optimal BUN runs from the lower reference limit up to 18 mg/dL for all adults"),
        fl(SRC, 15064, "EVA's optimal urea is 21–39 mg/dL for all adults, within a reference range of 15–54 mg/dL"),
        fl(SRC, 12819, "EVA's optimal BUN/creatinine ratio is 11–18 for all adults"),
        fl(SRC, 13536, "up to 0.85 mg/L, within a reference range of 0.62–1.11 mg/L"),
        fl(SRC, 13807, "65–105 mL/min/1.73m² at 60 and over; the reference range starts at 75 at ages 18–39"),
        fl(SRC, 13837, "\"evidence_grade\": \"D\","),
        fl(SRC, None, None, "Same entries' 'ranges' (JSON parser): bun optimal 10-16; urea 21-54 optimal 21-34; ratio no optimal; cystatin_c optimal to 0.72; eGFR rows 18-39 (60, 90+), 40-84 (60, 75-105), 85+ (60, none); grades B, B, D."),
        df(AT, "G6: 'no two statements give different values for the same quantity'.", 127),
    ],
))

# 13 G6 urea low
issues.append(dict(
    id="f03_kidney--G6--urea.both.All_Adults.none--low",
    verdict="confirmed",
    reason=("Reproduced. The urea Clinical_Notes say 'Its reference interval starts at 15 mg/dL ... so urea between 15 and 21 mg/dL is within range here but would read low as BUN', "
            "while the same row's Normal_Low is 21 mg/dL; 15 is the production value the compile replaced (CHANGES.md line 254). The Spanish note repeats 15. "
            "The note is shown to the client on the marker page. Two statements in the same row give different reference floors, which G6 forbids."),
    evidence=[
        fl(EN, 4522, "Its reference interval starts at 15 mg/dL, while the BUN interval starts at 10 mg/dL, which equals urea 21 mg/dL; so urea between 15 and 21 mg/dL is within range here but would read low as BUN."),
        fl(EN, 4517, "\"Normal_Low\": 21,"),
        fl(ES, 4522, "Su intervalo de referencia empieza en 15 mg/dL, mientras que el del BUN empieza en 10 mg/dL"),
        fl(CH, 254, "| urea|both|All Adults | normal_low | 15 | 21 | tighten | – | **unexplained** |"),
        fl(DET, 1014, None, "The marker page renders clinical_notes_es / clinical_notes_en to the client."),
        df(AT, "G6: 'no two statements give different values for the same quantity'.", 127),
    ],
))

# 14 K1 ratio
issues.append(dict(
    id="f03_kidney--K1--bun_creatinine_ratio.both.All_Adults.none--both",
    verdict="confirmed",
    reason=("Reproduced. K1 reports two opposite-category patterns on the ratio at 83 ages from 18 to 100: BUN 13 and creatinine 0.618 (both optimal, woman) give 21.04, above the 10-20 interval; "
            "BUN 10.3 and creatinine 1.067 (both optimal, man) give 9.653, below it. K1 records 0 accepted reasons. The K1 pass rule is 0 opposite-category pairs. "
            "The row's own Reference_Source calls the lower limit 'convention only', and the only outcome source (Shen 2022, opened) puts lowest mortality at 11.43-14.64, defining neither 10 nor 20. "
            "Physician question f03-Q09 (keep or retire the ratio) exists but is not an accepted K1 reason."),
    evidence=[
        cr(CK, 1314, "opposite|bun_creatinine|female|bun:optimal,creatinine:optimal->bun_creatinine_ratio:critical_high: 'seen at 83 ages from 18 to 100; e.g. bun 13, creatinine 0.618 gives bun_creatinine_ratio 21.04'."),
        cr(CK, 1318, "opposite|bun_creatinine|male|bun:optimal,creatinine:optimal->bun_creatinine_ratio:critical_low: 'bun 10.3, creatinine 1.067 gives bun_creatinine_ratio 9.653'."),
        cr(CK, 1348, "K1 one_step_accepted 0; summary line 1356 '8 opposite-category patterns ... (0 with an accepted reason)'."),
        sq("pmid", "35166184", "BUN/Cre ratio between 11.43 and 14.64 was associated with the lowest all-cause mortality compared with the participants with the lowest quartile (HR 0.83 [0.76, 0.91]; p < 0.001).", "Opened in this task (PubMed efetch)."),
        fl(RES, 3130, None, "f03-Q09: keep the ratio as a reference-only index with 10-20, or retire it from the client view."),
        df(AT, "K1 pass: '0 opposite-category pairs; every one-step disagreement listed with an accepted reason'.", 50),
    ],
))

# 15 K1 egfr 18-39 both
issues.append(dict(
    id="f03_kidney--K1--egfr_creatinine_based.both.18-39.none--both",
    verdict="confirmed",
    reason=("Reproduced. K1 lists three opposite-category patterns on eGFR: creatinine below its interval (0.4125 mg/dL women, 0.525 mg/dL men) gives eGFR 145.9 and 149.4, 'optimal' on the 18-39 row, which has no optimal ceiling (62 and 60 ages); "
            "and creatinine 0.873 mg/dL (optimal, woman aged 98-100) gives eGFR 59.93, below range on the 85+ row. No accepted reason is recorded. The K1 pass rule is 0 opposite-category pairs, so the row as compiled fails it."),
    evidence=[
        cr(CK, 1322, "opposite|egfr_ckd_epi_2021|female|creatinine:critical_low->egfr_creatinine_based:optimal: 'seen at 62 ages from 18 to 100; e.g. creatinine 0.4125 gives egfr_creatinine_based 145.9 (... derived row 18-39 optimal [90, ], reference [60, ])'."),
        cr(CK, 1330, "opposite|egfr_ckd_epi_2021|male|creatinine:critical_low->egfr_creatinine_based:optimal: 'seen at 60 ages ... creatinine 0.525 gives egfr_creatinine_based 149.4'."),
        cr(CK, 1326, "opposite|egfr_ckd_epi_2021|female|creatinine:optimal->egfr_creatinine_based:critical_low: 'seen at 3 ages from 98 to 100; e.g. creatinine 0.873 gives egfr_creatinine_based 59.93 (... derived row 85+)'."),
        fl(EN, 4698, None, "egfr_creatinine_based|both|18-39|none: Optimal_Low 90, Optimal_High null."),
        cr(CK, 1356, "K1 status fail: '8 opposite-category patterns and 23 one-step patterns (0 with an accepted reason)'."),
        df(AT, "K1 pass: '0 opposite-category pairs; every one-step disagreement listed with an accepted reason'.", 50),
    ],
))

# 16 K1 egfr 18-39 high
issues.append(dict(
    id="f03_kidney--K1--egfr_creatinine_based.both.18-39.none--high",
    verdict="confirmed",
    reason=("Reproduced. With Optimal_High null on the 18-39 eGFR row, a creatinine below its interval (0.4125 mg/dL woman, 0.525 mg/dL man) yields eGFR 145.9 or 149.4, classified optimal, at 62 and 60 ages; "
            "K1 records no accepted reason, and its pass rule allows 0 opposite pairs. The judge's remedy is also supported by the source the row cites: I opened PMC10286512 table 3, where at 18-39 the 110-120 category carries HR 1.12 (1.08 to 1.16) "
            "and above 120 HR 1.18 (1.14 to 1.23) against the 100-110 referent, so the row's stated within-10% rule would close the band near 110; this is physician question f03-VQ02."),
    evidence=[
        cr(CK, 1322, "'seen at 62 ages from 18 to 100; e.g. creatinine 0.4125 gives egfr_creatinine_based 145.9 (eGFR by CKD-EPI 2021; derived row 18-39 optimal [90, ], reference [60, ])'."),
        cr(CK, 1330, "'seen at 60 ages from 18 to 100; e.g. creatinine 0.525 gives egfr_creatinine_based 149.4'."),
        fl(EN, 4714, "no optimal ceiling because hyperfiltration is a percentile concept whose absolute value ranges 94.7 to 146.7 across studies (f03-E10)"),
        sq("pmcid", "PMC10286512", "110-120 mL/min/1.73m 2 Event frequency 8697/1 061 965 16 991/621 341 11 052/91 549 Crude incidence rate 1.06 2.98 13.4 Adjusted HR 1.12 (1.08 to 1.16) 1.28 (1.25 to 1.32) 1.60 (1.57 to 1.63) >120 mL/min/1.73m 2 ... Adjusted HR 1.18 (1.14 to 1.23)", "Opened in this task: table 3, all-cause mortality; first column is ages 18-39."),
        fl(VER, 1661, None, "Physician question f03-VQ02 (eGFR 18-39: keep no ceiling or set 110) follows f03-VQ01 in the verify file."),
        df(AT, "K1 pass: '0 opposite-category pairs; every one-step disagreement listed with an accepted reason'.", 50),
    ],
))

# 17 K1 egfr 40-84 low
issues.append(dict(
    id="f03_kidney--K1--egfr_creatinine_based.both.40-84.none--low",
    verdict="confirmed",
    reason=("Reproduced. K1 lists, as one-step patterns with no accepted reason, creatinine 0.9894 mg/dL (woman, above_optimal but inside 0.55-1.02) giving eGFR 59.88 on the 40-84 row (below range) at 27 ages from 74 to 100, "
            "and creatinine 1.261 mg/dL (man, inside 0.7-1.3) giving 59.79 at 27 ages from 74 to 100. These are one-step, not opposite, disagreements, but K1's pass rule requires every one-step disagreement to carry an accepted reason, and 0 do. "
            "The cause the judge names is visible in the rows: Echevarne's creatinine interval has no age bands while CKD-EPI 2021 falls with age."),
    evidence=[
        cr(CK, 1234, "one_step|egfr_ckd_epi_2021|female|creatinine:above_optimal->egfr_creatinine_based:critical_low: 'seen at 27 ages from 74 to 100; e.g. creatinine 0.9894 gives egfr_creatinine_based 59.88 (... derived row 40-84 optimal [75, 105], reference [60, ]); no accepted reason'."),
        cr(CK, 1262, "one_step|egfr_ckd_epi_2021|male|creatinine:above_optimal->egfr_creatinine_based:critical_low: 'creatinine 1.261 gives egfr_creatinine_based 59.79'."),
        cr(CK, 1348, "K1 metric one_step_accepted: 0."),
        fl(EN, 4660, None, "creatinine female Reference_Source: 'Mujeres 0-999 y: 0.55-1.02 mg/dL' (no age bands); male row 4628: 'Hombre 0-999 y: 0.7-1.3 mg/dL'."),
        df(AT, "K1 pass: '0 opposite-category pairs; every one-step disagreement listed with an accepted reason'.", 50),
    ],
))

# 18 K1 egfr 85+ low
issues.append(dict(
    id="f03_kidney--K1--egfr_creatinine_based.both.85plus.none--low",
    verdict="confirmed",
    reason=("Reproduced. K1 lists an opposite-category pattern: a woman aged 98-100 with creatinine 0.873 mg/dL (optimal, inside 0.6-0.9) gets eGFR 59.93, below the 60 floor of the 85+ row. No accepted reason is recorded; K1 allows 0 opposite pairs. "
            "The 85+ row's own message says values near 60 are common after 85, and the EKFC reference values I opened give a 5th percentile of 46-49 at age 80. "
            "Physician question f03-Q05 asks to confirm the 85+ policy and f03-Q03 the 18-39 floor, but neither is an accepted K1 reason."),
    evidence=[
        cr(CK, 1326, "opposite|egfr_ckd_epi_2021|female|creatinine:optimal->egfr_creatinine_based:critical_low: 'seen at 3 ages from 98 to 100; e.g. creatinine 0.873 gives egfr_creatinine_based 59.93 (eGFR by CKD-EPI 2021; derived row 85+ optimal [, ], reference [60, ])'."),
        fl(EN, 4756, None, "egfr_creatinine_based|both|85+|none: Normal_Low 60, no optimal band."),
        sq("pmid", "40122341", "in men aged 80 years old, the 5th, 50th and 95th eGFR percentiles were 49 ml/min per 1.73 m2, 66 ml/min per 1.73 m2, and 84 ml/min per 1.73 m2. In 80 year old women this was 46 ml/min per 1.73 m2, 63 ml/min per 1.73 m2, and 81 ml/min per 1.73 m2.", "Opened in this task (PubMed efetch)."),
        cr(CK, 1356, "K1 status fail, 0 accepted reasons."),
        df(AT, "K1 pass: '0 opposite-category pairs'.", 50),
    ],
))

# 19 L1 bun high
issues.append(dict(
    id="f03_kidney--L1--bun.both.All_Adults.none--high",
    verdict="confirmed",
    reason=("Reproduced. The BUN row has Critical_High 100, but the compile did not carry a critical-tier message ('critical-tier messages (critical_high) have no seed column; not carried into the seed'), "
            "and the only above-range message ends 'Book an appointment with your doctor in the next few weeks'. The app classifier takes no critical-limit field and returns 'critical_high' from the reference limit (zone-classifier.ts lines 86-87), "
            "so BUN 120 mg/dL gets the same zone and message as BUN 26. PLAN section 4 requires a critical limit to have its own field, its own zone and its own message; only the field exists. "
            "Correction: critical-limits.json does have a BUN entry (line 399, critical_high 100); L1's 'no entry' failure comes from the script looking up 'marker_key' while the table uses 'key'. That does not change the verdict."),
    evidence=[
        fl(EN, 4498, "\"Critical_High\": 100,"),
        fl(EN, 4496, "Book an appointment with your doctor in the next few weeks."),
        fl(CR, 48, "bun|both|All Adults|none: critical-tier messages (critical_high) have no seed column; not carried into the seed"),
        fl(ZC, 87, "if (normalHigh != null && value > normalHigh) return \"critical_high\";"),
        cr(CK, 1615, "L1: 'classifyZone takes no critical-limit fields: 'critical' is not its own zone fed by the critical limits'; line 1607: critical code derived from a reference limit at zone-classifier.ts:86."),
        fl(CL, 399, None, "critical-limits.json entry key 'bun', critical_high 100; limits.ts line 121 indexes entries by marker_key, so the entry is not found by L1."),
        df(PLAN, "Critical limit: 'Its own field, its own zone and its own message. Never derived from the reference interval.'", 70),
    ],
))

# 20 L1 creatinine male high
issues.append(dict(
    id="f03_kidney--L1--creatinine.male.All_Adults.none--high",
    verdict="confirmed",
    reason=("Reproduced. The male creatinine row has Critical_High 4, the compile report says its critical-tier message is not carried into the seed, the classifier derives 'critical_high' from the reference limit, "
            "and the only above-range message ends 'next few weeks'. S5 shows panels with creatinine 6 still reaching score 95, grade Elite. PLAN section 4 forbids a critical label derived from the reference interval and requires its own zone and message. "
            "Correction: the judge's sub-claim that creatinine has no critical-limits.json entry does not reproduce; the entry exists (line 374, critical_high 4.0). L1 reports 'no entry' because limits.ts indexes by 'marker_key' and the table uses 'key'."),
    evidence=[
        fl(EN, 4644, "\"Critical_High\": 4,"),
        fl(EN, 4642, "Book an appointment with your doctor in the next few weeks."),
        fl(CR, 50, "creatinine|male|All Adults|none: critical-tier messages (critical_high) have no seed column; not carried into the seed"),
        fl(ZC, 87, "if (normalHigh != null && value > normalHigh) return \"critical_high\";"),
        cr(CK, 2814, "S5: 'male 46: creatinine 6 critical, score 95 grade Elite' (also lines 2794, 2870, 2918)."),
        fl(CL, 374, None, "critical-limits.json has key 'creatinine' with critical_high 4.0; L1's 'no entry' failure is a key-name mismatch."),
        df(PLAN, "Critical limit: 'Its own field, its own zone and its own message. Never derived from the reference interval.'", 70),
    ],
))

# 21 M3 cystatin
issues.append(dict(
    id="f03_kidney--M3--cystatin_c.both.All_Adults.none--none",
    verdict="confirmed",
    reason=("Reproduced. The cystatin C Clinical_Notes say 'Cystatin-C-based eGFR predicts mortality better than the creatinine-only version' and the Spanish 'predice mortalidad mejor'. "
            "wording-rules.md section 3.1 bans 'predicts'/'predice' and 'mortality'/'mortalidad' in any client text, and section 1 names Clinical_Notes / Notas_Clínicas as in scope. "
            "The note is shown to the client on the marker page. M3 missed it because its row scan reads only the Msg_* zone texts (messages.ts line 236); M3's 6 hits are all app files."),
    evidence=[
        fl(EN, 4851, "Cystatin-C-based eGFR predicts mortality better than the creatinine-only version."),
        fl(ES, 4851, "La eGFR basada en cistatina C predice mortalidad mejor que la basada solo en creatinina."),
        fl(WR, 248, "| No mortality | \"mortality\", \"death\", \"risk of death\", \"survival\", \"dying\" | No substitute: omit |"),
        fl(WR, 212, None, "Scope (section 1, English): '(`supabase/seed-data/biomarker-ranges-en.json`, fields `Msg_*` and `Clinical_Notes`)'; line 247 bans 'predicts'."),
        fl(MSG, 236, "const text = r.msg[z][lang];"),
        cr(CK, 1584, "M3 fail: '6 banned-wording hits over 238 texts'; none is a cystatin C row."),
        df(AT, "M3: 'no mortality wording' across rows, app notices, trend labels, emails; pass 0 hits.", 58),
    ],
))

# 22 M3 urea
issues.append(dict(
    id="f03_kidney--M3--urea.both.All_Adults.none--none",
    verdict="confirmed",
    reason=("Reproduced. The urea Clinical_Notes say 'lower steady-state Urea within the healthy band associates with better kidney trajectory and lower all-cause mortality' and the Spanish 'menor mortalidad por todas las causas'. "
            "wording-rules.md 3.1 bans 'mortality'/'mortalidad' in any client text with no substitute, and section 1 places Clinical_Notes / Notas_Clínicas in scope; the note is shown to the client. "
            "M3 did not flag it because the row scan reads only Msg_* fields."),
    evidence=[
        fl(EN, 4522, "lower steady-state Urea within the healthy band associates with better kidney trajectory and lower all-cause mortality."),
        fl(ES, 4522, "una urea estable en la parte baja del rango sano se asocia a mejor trayectoria renal y menor mortalidad por todas las causas."),
        fl(WR, 60, "| Sin mortalidad | \"mortalidad\", \"muerte\", \"riesgo de muerte\", \"supervivencia\", \"fallecimiento\" | No hay sustituto: se omite |"),
        fl(WR, 24, None, "Section 1 scope: 'cada biomarcador (`supabase/seed-data/rangos-biomarcadores-es.json`, campos `Msg_*` y `Notas_Clínicas`)'."),
        fl(MSG, 236, "const text = r.msg[z][lang];"),
        df(AT, "M3: 'no mortality wording'; pass 0 hits.", 58),
    ],
))

# 23 M4 bun low
issues.append(dict(
    id="f03_kidney--M4--bun.both.All_Adults.none--low",
    verdict="confirmed",
    reason=("Reproduced. The BUN Clinical_Notes give '7' as a BUN bound ('a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range'); 7 is neither a bound of the row (10, 25, 10, 16, 100) "
            "nor in its explanatory numbers [2, 4, 60], and with the compiled urea floor of 21 mg/dL (BUN 9.81) BUN 7 (urea 14.98) is below range on both rows. The Spanish note repeats it. "
            "Scope caveat: the M4 script reads only Msg_* fields (messages.ts line 269), which is why M4 passes. The note is client text shown with the row (detail-client.tsx), "
            "the wording rules group Clinical_Notes with the per-zone messages, and G6 forbids the contradiction regardless, so the definitions do not allow it."),
    evidence=[
        fl(EN, 4491, "so a BUN between 7 and 10 mg/dL reads below the BUN range while the same blood is within the urea range."),
        fl(ES, 4491, "un BUN entre 7 y 10 mg/dL queda por debajo del intervalo del BUN aunque la misma sangre esté dentro del intervalo de la urea."),
        fl(EN, 4505, None, "BUN Explanatory_Numbers [2, 4, 60]; bounds Normal 10-25, Optimal 10-16, Critical_High 100; urea row line 4517 Normal_Low 21."),
        fl(MSG, 269, "const text = r.msg[z][lang];"),
        cr(CK, 1594, "M4 pass: '0 messages quote numbers that are not the row's bounds' - Clinical_Notes not read."),
        fl(DET, 1014, None, "Clinical notes rendered on the client's marker page."),
        df(AT, "M4: 'Numbers in messages equal the row's bounds in that language's decimal format, or appear in the row's explanatory-numbers list'.", 59),
    ],
))

# 24 M4 urea low
issues.append(dict(
    id="f03_kidney--M4--urea.both.All_Adults.none--low",
    verdict="confirmed",
    reason=("Reproduced. The urea Clinical_Notes state 'Its reference interval starts at 15 mg/dL ... urea between 15 and 21 mg/dL is within range here', but Normal_Low is 21; 15 is not a bound (21, 54, 21, 34, 214) "
            "and not in the explanatory numbers [2, 4, 60]. It is the replaced production value (CHANGES.md line 254). The Spanish note repeats 15. "
            "Scope caveat as for BUN: M4's script reads Msg_* only, but the note is client text and the wording rules treat Notas_Clínicas with the zone messages; the number contradicts the row, which the definitions do not allow."),
    evidence=[
        fl(EN, 4522, "Its reference interval starts at 15 mg/dL, while the BUN interval starts at 10 mg/dL, which equals urea 21 mg/dL; so urea between 15 and 21 mg/dL is within range here but would read low as BUN."),
        fl(EN, 4517, "\"Normal_Low\": 21,"),
        fl(ES, 4522, "Su intervalo de referencia empieza en 15 mg/dL"),
        fl(CH, 254, "| urea|both|All Adults | normal_low | 15 | 21 | tighten | – | **unexplained** |"),
        fl(MSG, 269, "const text = r.msg[z][lang];"),
        df(AT, "M4: 'Numbers in messages equal the row's bounds ... or appear in the row's explanatory-numbers list'.", 59),
    ],
))

N1_DEF = df(AT, "N1: 'Laboratory reference limits leave 2% to 15% outside ... More than 60% non-optimal at 70 to 79 is a physician question'; pass 'all rules hold or are justified'. Runner: resolutions are read from docs/signoff/work/nhanes/n1-resolutions.json (population.ts line 16).", 110)
N1_RES0 = cr(CK, 4361, "N1 metric resolutions: 0; summary line 4366 '68 unresolved population rules'. docs/signoff/work/nhanes/n1-resolutions.json does not exist.")

# 25 N1 bun both
issues.append(dict(
    id="f03_kidney--N1--bun.both.All_Adults.none--both",
    verdict="confirmed",
    reason=("Reproduced. N1 reports BUN 25.0% outside the reference limits for women 20-39, 17.5% for women 40-59 and 17.5% for men 20-39 (rule 2-15%), and 63.3% non-optimal for men 70-79 'must be a physician question', with 0 resolutions recorded. "
            "Physician question f03-Q07 covers the ceiling choice (16, 17 or 18) and the low share in women, but not the 70-79 non-optimal share, and no N1 resolution exists. "
            "Two corrections that do not change the verdict: the generator's exact share for men 20-39 is 10.85% outside (inside the rule), so that one failure is an interpolation artefact; "
            "and 63.3% is interpolated on integer data: the percentiles (p50 17 mg/dL, 4.42% below 10) put the true share between about 54% and 79%. The female shares are exact (24.17% and 16.44%) and breach the rule."),
    evidence=[
        cr(CK, 4101, "bun|female|20-39|reference_outside 25.0%; line 4105 bun|female|40-59 17.5%; line 4109 bun|male|20-39 17.5%; line 4113 bun|male|70-79 '63.3% non-optimal at 70-79: must be a physician question'."),
        N1_RES0,
        fl(DIST, None, None, "splits.nonoutcome (waves 9-10) bun cells, reference 10-25 as compiled: female|20-39 outside_reference 24.17; female|40-59 16.44; male|20-39 10.85; male|70-79 p50 17.0, critical_low 4.42 (read with a JSON parser; optimal shares there use the old ceiling 18)."),
        fl(RES, 3097, None, "f03-Q07: 'BUN optimal ceiling 16 mg/dL ... or 17 ... or keep 18; and accept that 16-38% of healthy women aged 20-59 read below range under Echevarne's lower limit 10?'"),
        sq("pmid", "8207875", "The estimated normal range of BUN was 14-23 mg/dl both in male and female elderly subjects", "Opened in this task: the row's own age source (f03-E21)."),
        N1_DEF,
    ],
))

# 26 N1 bun high
issues.append(dict(
    id="f03_kidney--N1--bun.both.All_Adults.none--high",
    verdict="confirmed",
    reason=("Reproduced. N1 reports 63.3% of healthy men aged 70-79 non-optimal under the 16 mg/dL ceiling and requires a physician question; N1 has 0 resolutions, and no f03 physician question addresses the 70-79 share "
            "(f03-Q07 asks about the ceiling value and the low share in young women). The row's own message says values above 16 'are common after 60'. "
            "The 63.3% is interpolated; the NHANES percentiles (p50 17 mg/dL, 4.42% below 10) bound the share between about 54% and 79%, so the exact share may sit either side of 60%. "
            "The runner's method is the fixed N1 definition and its result fails, so the issue stands; an exact recount would settle the size."),
    evidence=[
        cr(CK, 4113, "bun|male|70-79|non_optimal_70_79: '63.3% non-optimal at 70-79: must be a physician question'."),
        N1_RES0,
        fl(DIST, None, None, "splits.nonoutcome.markers.bun.cells male|70-79: n 325, percentiles p25 14, p50 17, p75 20; critical_low 4.42%."),
        fl(EN, 4495, "it rises gradually with age, so values in this zone are common after 60."),
        fl(RES, 3097, None, "f03-Q07 covers ceiling 16/17/18 and the young-women low share, not the 70-79 non-optimal share."),
        N1_DEF,
    ],
))

# 27 N1 bun low
issues.append(dict(
    id="f03_kidney--N1--bun.both.All_Adults.none--low",
    verdict="confirmed",
    reason=("Reproduced for women. N1 reports 25.0% (women 20-39) and 17.5% (women 40-59) below Echevarne's 10 mg/dL, outside the 2-15% rule, with 0 resolutions; the generator's exact shares are 24.17% and 16.44%, still outside. "
            "PLAN section 4 makes Echevarne's interval binding, and the row's Method_Note gives that reason and points to f03-Q07, but N1 counts only resolutions in n1-resolutions.json, which does not exist, "
            "and the note's '16-38% of women aged 20-59' does not match N1's figures. Correction: the men 20-39 failure (17.5%) does not reproduce exactly; the generator's exact share is 10.85%, inside the rule."),
    evidence=[
        cr(CK, 4101, "bun|female|20-39|reference_outside '25.0% outside the reference limits (rule 2% to 15%)'; line 4105 female|40-59 17.5%; line 4109 male|20-39 17.5%."),
        N1_RES0,
        fl(DIST, None, None, "splits.nonoutcome bun: female|20-39 outside_reference 24.17 (critical_low 24.01); female|40-59 16.44; male|20-39 10.85."),
        fl(EN, 4504, "NHANES healthy adults: 16-38% of women aged 20-59 sit below 10 mg/dL (input bundle), outside the 2-15% rule of check N1; that follows from Echevarne's printed lower limit, which the plan makes binding (physician question f03-Q07)."),
        df(PLAN, "Reference interval: 'Echevarne's printed interval for the method EVA uses'.", 62),
        N1_DEF,
    ],
))

# 28 N1 creatinine female high
issues.append(dict(
    id="f03_kidney--N1--creatinine.female.All_Adults.none--high",
    verdict="confirmed",
    reason=("Reproduced. N1 reports 21.1% of healthy women aged 70-79 outside the female creatinine interval 0.55-1.02 mg/dL (rule 2-15%), with 0 resolutions. "
            "The row's Method_Note calls it 'a physician question, not a row change' but gives no id, and quotes 18% where N1 computes 21.1%. "
            "A matching question does exist in the research file (f03-Q11), so the gap is narrower than the judge says: the question is not linked from the row, not carried into N1, and the two figures disagree. "
            "N1 still fails on this cell under its own definition."),
    evidence=[
        cr(CK, 4117, "creatinine|female|70-79|reference_outside: '21.1% outside the reference limits (rule 2% to 15%)'."),
        N1_RES0,
        fl(EN, 4682, "in NHANES 18% of healthy women aged 70-79 sit above 1.02 mg/dL (input bundle), which is a physician question, not a row change."),
        fl(RES, 3164, None, "f03-Q11: 'Echevarne's female creatinine interval has no age bands and 18% of healthy NHANES women aged 70-79 sit above 1.02 mg/dL (input bundle). Accept the above range reading for older women, or ask Echevarne for age-partitioned intervals?'"),
        N1_DEF,
    ],
    notes="Partly refuted detail: a question id (f03-Q11) exists in research/f03_kidney.json; the row does not cite it."
))

# 29 Q1
issues.append(dict(
    id="f03_kidney--Q1--egfr_creatinine_based.both.18-39.none--low",
    verdict="confirmed",
    reason=("Reproduced. Every eGFR message names 'the CKD-EPI 2021 equation', and the Method_Note opens with 'the app computes eGFR from Echevarne's creatinine with the race-free CKD-EPI 2021 creatinine equation', "
            "then says in its verifier note that 'today the app computes no eGFR' and that laboratory-reported eGFR of unknown equation is shown 'as values only'. The same row therefore states two contradictory facts. "
            "The values-only rule is not carried into the compiled seed (no pre-analytical field) and the app maps uploaded 'egfr' to this marker (key-aliases.ts line 53) and scores EGFR, so an uploaded eGFR of any equation is classified against these rows with CKD-EPI 2021 messages. "
            "Q1 classifies a healthy persona's eGFR 55 as critical_low. The cited persona is 95, so on the 85+ row, but the messages and Method_Note are the same on the 18-39 row. Physician question f03-VQ01 asks this but does not resolve the contradiction."),
    evidence=[
        fl(EN, 4702, "Your estimated kidney filtration (eGFR, CKD-EPI 2021 equation) is below 60 mL/min/1.73 m²"),
        fl(EN, 4714, "Derived marker: the app computes eGFR from Echevarne's creatinine with the race-free CKD-EPI 2021 creatinine equation (K1; f03-E08)"),
        fl(EN, 4714, "Verifier note (7 November 2026): today the app computes no eGFR."),
        fl("src/lib/biomarkers/key-aliases.ts", 53, "egfr: \"egfr_creatinine_based\","),
        cr(CK, 4427, "Q1: 'healthy persona sees 5 critical messages: ... egfr_creatinine_based=55 (critical_low) ...' (healthy_female_95)."),
        fl(VER, 1661, None, "f03-VQ01: until the computation exists, should a laboratory-reported eGFR be shown as a value only or classified against the KDIGO floor only?"),
        df(AT, "Q1 pass: '0 healthy personas see a critical message'. G6: 'no two statements give different values for the same quantity'.", 116),
    ],
))


def main():
    os.makedirs(OUT, exist_ok=True)
    written = []
    for it in issues:
        doc = {
            "schema_version": "1",
            "issue_id": it["id"],
            "round": 1,
            "refuter": "a",
            "family": "f03_kidney",
            "verdict": it["verdict"],
            "reason": it["reason"],
            "evidence": it["evidence"],
            "model": MODEL,
            "notes": it.get("notes"),
        }
        path = os.path.join(OUT, it["id"] + "-a.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)
            f.write("\n")
        written.append(path)
    print(len(written))
    for p in written:
        print(p)


if __name__ == "__main__":
    main()
