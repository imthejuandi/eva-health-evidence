// Scan every client text in the research rows against the banned_terms block of wording-rules.md.
const fs = require("fs");
const md = fs.readFileSync("/home/user/eva-health/docs/signoff/work/governance/wording-rules.md", "utf8");
const m = md.match(/```json banned_terms\n([\s\S]*?)\n```/);
const bt = JSON.parse(m[1]);
const doc = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const rows = doc.final_rows || doc.rows;
function scan(lang, text, where) {
  const out = [];
  let t = text;
  for (const a of bt[lang].any.allow) t = t.split(a).join(" ");
  for (const scope of ["any", "non_critical"]) {
    for (const re of bt[lang][scope].regex) {
      const r = new RegExp(re, bt.flags);
      const hit = t.match(r);
      if (hit) out.push(`${where} [${lang}/${scope}] /${re}/ -> "${hit[0]}"`);
    }
  }
  // required closer on out-of-range messages
  return out;
}
const hits = [];
for (const r of rows) {
  const k = `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
  for (const lang of ["en", "es"]) {
    for (const [zone, text] of Object.entries(r.messages[lang] || {})) {
      hits.push(...scan(lang, text, `${k} msg.${lang}.${zone}`));
      if (["below_range", "above_range", "critical_low", "critical_high"].includes(zone)) {
        const closer = bt[lang].required.out_of_range_closer;
        if (!text.endsWith(closer)) hits.push(`${k} msg.${lang}.${zone}: does not end with the standard safety-net sentence`);
        const soon = lang === "en" ? "Book an appointment with your doctor in the next few weeks" : "Pide cita con tu médico en las próximas semanas";
        const routine = lang === "en" ? "Discuss it with your doctor at your next check-up" : "Coméntalo con tu médico en tu próxima revisión";
        if (!text.includes(soon) && !text.includes(routine)) hits.push(`${k} msg.${lang}.${zone}: no urgency phrase (soon/routine)`);
        if (!/2 (to|a) 4 (weeks|semanas)|repeat|repite|repita|repeats|repetir/i.test(text)) hits.push(`${k} msg.${lang}.${zone}: no repeat rule found`);
      }
      if (["below_optimal", "above_optimal"].includes(zone)) {
        const routine = lang === "en" ? "at your next check-up" : "en tu próxima revisión";
        if (!text.includes(routine)) hits.push(`${k} msg.${lang}.${zone}: in-range-not-optimal message without the routine phrase`);
      }
      if (zone === "in_range" || (zone === "optimal" && r.marker_class !== "a")) {
        const sc = lang === "en" ? "This marker does not count toward the score." : "Este marcador no entra en la puntuación.";
        if (r.marker_class !== "a" && !text.includes(sc)) hits.push(`${k} msg.${lang}.${zone}: class ${r.marker_class} message lacks '${sc}'`);
      }
    }
    for (const a of r.action_limits || []) hits.push(...scan(lang, a[`follow_up_${lang}`], `${k} action '${a.name}' ${lang}`));
    for (const [i, p] of (r.pre_analytical || []).entries()) hits.push(...scan(lang, p[`text_${lang}`], `${k} pre_analytical[${i}] ${lang}`));
  }
  // M4: numbers in messages vs bounds + explanatory numbers
  const bounds = new Set([r.reference_low, r.reference_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high, ...(r.explanatory_numbers || [])].filter((b) => b != null).map(Number));
  for (const a of r.action_limits || []) bounds.add(a.value);
  for (const lang of ["en", "es"]) for (const [zone, text] of Object.entries(r.messages[lang] || {})) {
    const nums = (text.match(/\d+(?:[.,]\d+)?/g) || []).map((s) => Number(s.replace(",", ".")));
    for (const n of nums) if (!bounds.has(n)) hits.push(`${k} msg.${lang}.${zone}: number ${n} is not a bound or explanatory number`);
  }
}
console.log(hits.length ? hits.join("\n") : "no hits");
