import { classifyZone } from "/home/user/eva-health/src/lib/biomarkers/zone-classifier";
import { ckdEpi2021, judge } from "/home/user/eva-health/scripts/signoff/checks/coherence";
for (const [cr, age] of [[0.9894, 85], [0.9894, 88], [0.9894, 100], [0.5335, 85], [0.5335, 88], [0.50, 88], [0.5335, 100]] as [number, number][]) {
  const e = ckdEpi2021(cr, age, "female");
  const zc = classifyZone(cr, null, null, 0.55, 1.02) as any;
  const ze = classifyZone(e, null, null, 60, null) as any;
  console.log(`female age ${age} creatinine ${cr} -> ${zc}; eGFR ${e.toFixed(2)} (85+ row) -> ${ze}; K1 verdict ${judge([zc], [-1], ze)}`);
}
let a = 0; for (a = 18; a <= 100; a++) if (ckdEpi2021(0.9894, a, "female") < 60) break; console.log("first age eGFR<60 at cr 0.9894:", a, ckdEpi2021(0.9894, 74, "female").toFixed(2));
