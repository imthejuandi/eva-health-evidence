import fs from "node:fs"; import os from "node:os"; import path from "node:path";
import { makeCtx } from "/home/user/eva-health/.claude/worktrees/approval-fixes/scripts/signoff/lib/runner";
import { checks as dataChecks } from "/home/user/eva-health/.claude/worktrees/approval-fixes/scripts/signoff/checks/data";
const ROOT = "/home/user/eva-health/.claude/worktrees/approval-fixes";
for (const c of ["B01-r3", "B01-r4"]) {
  const ctx = makeCtx({ root: ROOT, seedDir: path.join(ROOT, "docs/signoff/work/compiled", c), workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
  const r = await dataChecks.find((x) => x.id === "D5")!.run(ctx);
  console.log(c, JSON.stringify({ explained: r.metrics!.explained_by_documented_changes, failures: r.failures.length, other: r.failures.filter((f) => !f.key.endsWith("|only_in_production")).map((f) => f.key), m: r.metrics }));
}
