import fs from 'node:fs'
const src = fs.readFileSync('/home/user/eva-health/docs/signoff/workflows/ws1-batch.js', 'utf8').replace(/^export const meta = /, 'const meta = ')
const scenario = process.argv[2] || 'progress'
const calls = []
let judgeRound = 0
const agent = async (prompt, opts) => {
  calls.push(opts.label)
  const L = opts.label
  if (scenario === 'nulls' && /^author f03/.test(L)) return null
  if (L.startsWith('setup')) return { batch: 'B01', families: [
    { family: 'f01_albumin_proteins', title: 't', keys: ['albumin'], v3_keys: ['albumin'], base_panel_keys: [] },
    { family: 'f03_kidney', title: 't', keys: ['creatinine'], v3_keys: [], base_panel_keys: [] },
    { family: 'f04_inflammation', title: 't', keys: ['hs_crp'], v3_keys: [], base_panel_keys: [] }], existing_issues: [], inputs_missing: scenario === 'missing' ? ['f04_inflammation'] : [] }
  if (/^(author|verifier|fixer)/.test(L)) return { file: 'x', valid: !/^author f01.*r1$/.test(L), errors: ['e1'], searches_used: 3, files_written: [] }
  if (L.startsWith('check')) { const n = +L.match(/r(\d+)$/)[1]; const f = L.split(' ')[1]; const fc = f === 'f04_inflammation' ? 0 : Math.max(0, 4 - 2 * n); return { family: f, round: n, valid: { research: true, verify: true, decision: null }, validation_errors: [], ownership_ok: true, outside_paths: [], compile_ok: true, checks_file: 'c', failing_count: fc, failing: [], blocked_checks: [], errors: [] } }
  if (L.startsWith('judge-prep')) return { round: 1, compile_ok: true, checks_file: 'c', samples: [], errors: [] }
  if (L.startsWith('judge')) {
    const n = +L.match(/r(\d+)( retry)?$/)[1]
    const lens = L.split(' ')[1]
    const blocking = lens === 'J2' && n === 1 ? [{ id: 'x', family: 'f01_albumin_proteins', check_id: 'E3', row_key: 'albumin|both|All Adults|none', side: 'low', summary: 's' }, { id: 'y', family: 'f03_kidney', check_id: 'M3', row_key: null, side: null, summary: 's' }] : []
    if (scenario === 'nulls' && lens === 'J5') return null
    return { file: `judges/round-${n}/${lens}.json`, valid: true, errors: [], lens, families_reviewed: [], blocking, minor: [], searches_used: 1 }
  }
  if (L.startsWith('refuter')) return { file: 'r', valid: true, errors: [], verdict: L.includes('f03') && L.startsWith('refuter-b') ? 'refuted' : 'confirmed' }
  if (L.startsWith('ledger')) return { ok: true, written: [], errors: [], counts: [], scorecard_file: 's' }
  if (L.startsWith('scorecard')) return { scorecard_file: 'docs/signoff/work/scorecard-B01.md', finalized: [], errors: [] }
  throw new Error('unexpected ' + L)
}
const parallel = async (ts) => Promise.all(ts.map(async (t) => { try { return await t() } catch (e) { console.error('thunk threw', e); return null } }))
const pipeline = async (items, ...stages) => Promise.all(items.map(async (it, i) => { let v = it; try { for (let s = 0; s < stages.length; s++) v = await stages[s](s === 0 ? it : v, it, i); return v } catch (e) { console.error('stage threw', e); return null } }))
const logs = []
const fn = new (Object.getPrototypeOf(async function () {}).constructor)('agent', 'parallel', 'pipeline', 'phase', 'log', 'args', 'budget', src)
const out = await fn(agent, parallel, pipeline, () => {}, (m) => logs.push(m), { batch: 'B01', started_at: '2026-11-06T09:00:00Z', agent_cap: scenario === 'cap' ? 20 : 120 }, { total: null })
console.log(logs.join('\n'))
console.log(JSON.stringify({ ...out, families: Object.fromEntries(Object.entries(out.families).map(([k, v]) => [k, `${v.status} | ${v.stop_reason} | rounds ${v.rounds} | end ${v.blocking_open}`])) }, null, 1))
console.log('agents', calls.length)
