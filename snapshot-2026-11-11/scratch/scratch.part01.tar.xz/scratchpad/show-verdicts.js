// Print the verifier's evidence verdicts for the given ids, and any other field in the verify file that names them.
// Usage: node show-verdicts.js <verify-file> id1,id2
"use strict";
const fs = require("fs");
const [file, idsArg] = process.argv.slice(2);
const ids = new Set(idsArg.split(","));
const d = JSON.parse(fs.readFileSync(file, "utf8"));
for (const v of d.evidence_verdicts || []) if (ids.has(v.evidence_id)) console.log(JSON.stringify(v, null, 2));
