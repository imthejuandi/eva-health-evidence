import fs from "node:fs";
import path from "node:path";
import { parseForwardMigration } from "/home/user/eva-health/scripts/signoff/checks/data";
const roots = ["/home/user/eva-health/docs/signoff/work/compiled"];
let files = 0, bad = 0;
const walk = (d: string) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else if (/^(migration|forward)\.sql$/.test(e.name)) { files++; const m = parseForwardMigration(fs.readFileSync(p, "utf8"), p); if (m.unreadable.length) { bad++; console.log(p, m.unreadable.slice(0, 2)); } } } };
roots.forEach(walk);
console.log(`files ${files}, unreadable ${bad}`);
