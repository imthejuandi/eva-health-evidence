// Builds docs/signoff/work/decisions/f04_inflammation.json (round 2 fixer) from the verify file's final_rows.
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = "/home/user/eva-health";
const verifyPath = path.join(ROOT, "docs/signoff/work/verify/f04_inflammation.json");
const outPath = path.join(ROOT, "docs/signoff/work/decisions/f04_inflammation.json");
const verifyBuf = fs.readFileSync(verifyPath);
const verify = JSON.parse(verifyBuf);
const sha = crypto.createHash("sha256").update(verifyBuf).digest("hex");

const clone = (x) => JSON.parse(JSON.stringify(x));
const rk = (r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
const rows = clone(verify.final_rows);
const crp = rows.find((r) => rk(r) === "hs_crp|both|All Adults|none");
const preg = rows.find((r) => rk(r) === "hs_crp|female|All Adults|pregnancy");
const lact = rows.find((r) => rk(r) === "hs_crp|female|All Adults|lactation");
const fib = rows.find((r) => rk(r) === "fibrinogen|both|All Adults|none");
if (!crp || !preg || !lact || !fib) throw new Error("verify rows not found");

const changes = [];
const L = "f04_inflammation--";
function replaceIn(row, lang, zone, from, to, reason, issueIds, evidenceIds = []) {
  const before = row.messages[lang][zone];
  if (!before.includes(from)) throw new Error(`${rk(row)} ${lang}.${zone}: text not found: ${from}`);
  const after = before.replace(from, to);
  row.messages[lang][zone] = after;
  changes.push({ row_key: rk(row), field: `messages.${lang}.${zone}`, from: before, to: after, direction: "neutral", reason, evidence_ids: evidenceIds, issue_ids: issueIds });
}

// ── 1. Pregnancy and lactation rows removed (state-rules.md section 2.2: one app rule, not pregnancy rows). ──
const stateReason = (state) =>
  `Removed. PLAN.md section 4 gives declared ${state} the laboratory interval only, with no optimal category, score or biological age, and docs/signoff/work/governance/state-rules.md section 2.1 implements that as one app rule for every marker ('Why one rule and not pregnancy rows', section 2.2), with no colour and no out-of-range message. This row only repeated the general row's reference interval (Echevarne B0851 '<3.01' mg/L, no ${state}-specific interval in the catalogue) and could never be picked: src/lib/biomarkers/reference-row.ts referenceRowFor takes sex and age only, and ageGroupContains does not recognise the label '${state === "pregnancy" ? "Pregnancy" : "Lactation"}' (check C1, file index ${state === "pregnancy" ? 5 : 6}). Keeping it satisfied nothing in the definitions; the definition is met only when the app reads the declared state, which is outside this file (physician question F04-DQ-1). Its grade D also pulled the compiled hs-CRP evidence_grade to D (judge J3, G6). The clinical content it carried (hs-CRP rises normally in pregnancy) moves to the general row's method note.`;
changes.push({
  row_key: "hs_crp|female|All Adults|pregnancy", field: "row",
  from: "present (Echevarne '<3.01' read as 0-3 mg/L, no optimal band, grade D, label 'Pregnancy' / 'Embarazo')", to: null,
  direction: "neutral", reason: stateReason("pregnancy"), evidence_ids: ["f04-E12", "f04-E13"],
  issue_ids: [L + "C1--hs_crp.female.Pregnancy.unreachable--none", L + "D2--hs_crp.female.Pregnancy.age_group--none", L + "D3--hs_crp.female.Pregnancy.no_catalogue_band--none", L + "D5--hs_crp.female.Pregnancy.row_only_in_seed--none"],
});
changes.push({
  row_key: "hs_crp|female|All Adults|lactation", field: "row",
  from: "present (Echevarne '<3.01' read as 0-3 mg/L, no optimal band, grade D, label 'Lactation' / 'Lactancia')", to: null,
  direction: "neutral", reason: stateReason("lactation"), evidence_ids: ["f04-E14"],
  issue_ids: [L + "C1--hs_crp.female.Lactation.unreachable--none", L + "D2--hs_crp.female.Lactation.age_group--none", L + "D3--hs_crp.female.Lactation.no_catalogue_band--none", L + "D5--hs_crp.female.Lactation.row_only_in_seed--none"],
});
const finalRows = rows.filter((r) => r !== preg && r !== lact);

// ── 2. hs-CRP reference_low: production 0 -> null (kept from the verify file), recorded against production. ──
changes.push({
  row_key: "hs_crp|both|All Adults|none", field: "reference_low", from: 0, to: null, direction: "neutral",
  reason: "Against production (the verify file already has null; recorded here because no earlier file carries the change, and check D5 lists it). The row's basis is the CDC/AHA decision limit, which defines only the upper cut-point ('high risk (>3.0 mg/L)', f04-E01), and Echevarne B0851 prints '<3.01' mg/L with no lower limit (catalogue line 308). A floor of 0 has no source under either basis (the validator refuses a decision-limit bound without an evidence record), and null and 0 classify every non-negative value the same way (zone-classifier.ts: below range only for value < normal_low). No client sees a difference. D5 compares the seed with production only, so it lists this documented difference until the migration is applied.",
  evidence_ids: ["f04-E01"], issue_ids: [L + "D5--hs_crp.both.All_Adults.bounds--none"],
});

// ── 3. Fibrinogen optimal ceiling 300 mg/dL (production) -> none, recorded against production. ──
changes.push({
  row_key: "fibrinogen|both|All Adults|none", field: "optimal_high", from: 300, to: null, direction: "loosen",
  reason: "Against production (the verify file already has null; recorded here because no earlier file carries the change, and check D5 lists it). The production ceiling of 300 mg/dL has no outcome basis: the Fibrinogen Studies Collaboration (154,211 participants, 31 prospective cohorts, individual participant data; grade B) found 'no evidence of a threshold within the range of usual fibrinogen level studied at any age', and Mendelian randomisation found 'fibrinogen genotype was not significantly associated with MI incidence' (risk ratio 1.00, 95% CI 0.95-1.04, per allele in the meta-analysis; grade A). PLAN.md section 4 allows an optimal band only on outcome evidence for the band, and section 5 gives no optimal band without it, so fibrinogen is class e (in range or out of range only). Effect: a value of 300-400 mg/dL moves from 'above optimal' to 'in range'. Physician question f04-Q04 (research file) stays open for confirmation.",
  evidence_ids: ["f04-E20", "f04-E21"], issue_ids: [L + "D5--fibrinogen.both.All_Adults.bounds--none"],
});

// ── 4. M2: four elements in the out-of-range messages. ──
replaceIn(crp, "en", "above_range",
  "It shows inflammation somewhere in the body and does not point to any one organ; in population studies, values above 3 mg/L go with more cardiovascular events than values below 1 mg/L.",
  "It suggests inflammation somewhere in the body and does not point to any one organ; in population studies, values above 3 mg/L are linked with more cardiovascular events than values below 1 mg/L.",
  "M2 'meaning': a single value suggests, it does not show, inflammation; 'are linked with' states the population association without implying cause (Mendelian randomisation f04-E10: genetically raised CRP did not change coronary risk). No number changed.",
  [L + "M2--hs_crp.both.All_Adults.critical_high.en--none"], ["f04-E01", "f04-E10"]);
replaceIn(crp, "es", "above_range",
  "Indica inflamación en algún lugar del cuerpo",
  "Sugiere inflamación en algún lugar del cuerpo",
  "Parity with the English change (M2 'meaning'): 'sugiere' matches 'suggests'; no number changed.",
  [], ["f04-E01", "f04-E10"]);
replaceIn(fib, "en", "above_range",
  "Fibrinogen is a clotting protein that rises with inflammation.",
  "Fibrinogen is a clotting protein that rises with inflammation, so a raised value can reflect inflammation somewhere in the body; it does not point to any one organ.",
  "M2 'meaning': the message named the protein and its causes but did not say what a raised value may mean for the client. Inflammation as the meaning follows the message's own causes; no cardiovascular claim is added, because Mendelian randomisation does not support a causal role (f04-E21).",
  [L + "M2--fibrinogen.both.All_Adults.critical_high.en--none"], ["f04-E21", "f04-E26"]);
replaceIn(fib, "es", "above_range",
  "El fibrinógeno es una proteína de la coagulación que sube con la inflamación.",
  "El fibrinógeno es una proteína de la coagulación que sube con la inflamación, así que un valor alto puede reflejar inflamación en algún lugar del cuerpo; no señala ningún órgano concreto.",
  "M2 'meaning', Spanish: same sentence as the English change.",
  [L + "M2--fibrinogen.both.All_Adults.critical_high.es--none"], ["f04-E21", "f04-E26"]);
replaceIn(fib, "es", "below_range",
  "Repite el análisis en 2 a 4 semanas con una muestra nueva.",
  "Repite el análisis en 2 a 4 semanas con una muestra nueva para confirmar el resultado.",
  "M2 'confirm_repeat', Spanish: the imperative 'Repite' required by wording-rules.md is kept; 'para confirmar el resultado' states the purpose of the repeat. (The check's Spanish pattern lists 'repít', with an accent, so it does not match 'Repite'; see notes.)",
  [L + "M2--fibrinogen.both.All_Adults.critical_low.es--none"]);
replaceIn(fib, "en", "below_range",
  "Repeat the test in 2 to 4 weeks with a fresh sample.",
  "Repeat the test in 2 to 4 weeks with a fresh sample to confirm the result.",
  "Parity with the Spanish change; no number changed.", []);

// ── 5. N1: 'reached by a minority' label in the optimal and above-optimal messages. ──
const nhanesSrc = "NHANES 2015-2018 healthy adults 20-79 (docs/signoff/work/nhanes/distributions.json, non-outcome split, via the brief markers.hs_crp.nhanes): optimal share (0.5 mg/L or lower) 23.82% in men 20-39 (the highest cell) down to 9.26% in women 60-69 and 9.98% in women 70-79; the check's interpolation gives 9.5% and 9.6%. In the Women's Health Study cohort of 27,939 healthy women, '15.1% had hsCRP <0.50 mg/L' (PMID 15051634 abstract, opened in this task).";
replaceIn(crp, "en", "optimal",
  "In large population studies, people with the lowest hs-CRP had the fewest cardiovascular events.",
  "In large population studies, people with the lowest hs-CRP had the fewest cardiovascular events. Only a minority of adults reach this band: in a US survey of healthy adults, fewer than 1 in 4 at any age, and fewer than 1 in 10 women aged 60 to 79.",
  `N1 'reached by a minority' label (check N1, judge J1). ${nhanesSrc} 'Fewer than 1 in 4' covers every sex and age cell; 'fewer than 1 in 10 women aged 60 to 79' covers the two cells below the 10% rule.`,
  [L + "N1--hs_crp.both.All_Adults.none--high", L + "N1--hs_crp.female.60-69.optimal_minority--none", L + "N1--hs_crp.female.70-79.optimal_minority--none"], ["f04-E06"]);
replaceIn(crp, "es", "optimal",
  "En grandes estudios de población, las personas con la PCR ultrasensible más baja tuvieron menos episodios cardiovasculares.",
  "En grandes estudios de población, las personas con la PCR ultrasensible más baja tuvieron menos episodios cardiovasculares. Solo una minoría de adultos alcanza esta banda: en una encuesta de adultos sanos de Estados Unidos, menos de 1 de cada 4 a cualquier edad y menos de 1 de cada 10 mujeres de 60 a 79 años.",
  "N1 label, Spanish: same sentence and numbers as the English change.",
  [L + "N1--hs_crp.both.All_Adults.none--high", L + "N1--hs_crp.female.60-69.optimal_minority--none", L + "N1--hs_crp.female.70-79.optimal_minority--none"], ["f04-E06"]);
replaceIn(crp, "en", "above_optimal",
  "Many adults are in this zone.",
  "Many adults are in this zone: the optimal band is reached by only a minority, fewer than 1 in 4 adults at any age and fewer than 1 in 10 women aged 60 to 79 in a US survey of healthy adults.",
  `N1 label on the above-optimal message too, so a client above 0.5 mg/L reads that most people are above the band. ${nhanesSrc}`,
  [L + "N1--hs_crp.both.All_Adults.none--high"], ["f04-E06"]);
replaceIn(crp, "es", "above_optimal",
  "Muchos adultos están en esta zona.",
  "Muchos adultos están en esta zona: la banda óptima solo la alcanza una minoría, menos de 1 de cada 4 adultos a cualquier edad y menos de 1 de cada 10 mujeres de 60 a 79 años en una encuesta de adultos sanos de Estados Unidos.",
  "N1 label, Spanish: same sentence and numbers as the English change.",
  [L + "N1--hs_crp.both.All_Adults.none--high"], ["f04-E06"]);
const expBefore = crp.explanatory_numbers.slice();
crp.explanatory_numbers = [...new Set([...crp.explanatory_numbers, 1, 4, 10, 60, 79])].sort((a, b) => a - b);
changes.push({
  row_key: "hs_crp|both|All Adults|none", field: "explanatory_numbers", from: expBefore, to: crp.explanatory_numbers, direction: "neutral",
  reason: "The minority label quotes '1 in 4', '1 in 10' and 'aged 60 to 79'; these are shares and ages, not bounds (check M4).",
  evidence_ids: [], issue_ids: [L + "N1--hs_crp.both.All_Adults.none--high"],
});

// ── 6. Method note and notes of the general hs-CRP row. ──
const mnBefore = crp.method_note;
crp.method_note = mnBefore +
  " Declared pregnancy or lactation: no separate rows (removed in round 2); state-rules.md section 2.1 applies one app rule (laboratory interval only, no category, score or biological age, one fixed note). hs-CRP rises normally in pregnancy (third-trimester median 4.12 mg/L, f04-E12; pregnancy-specific upper reference limit 19 mg/L, f04-E13), so the general row's categories must not be shown in pregnancy; breastfeeding itself did not raise CRP in a population survey (f04-E14). Until reference-row.ts reads the declared state, a pregnant or breastfeeding client is classified on this row (F04-DQ-1)." +
  " Bounded results: a '<x' result with x above 0.5 mg/L cannot be placed inside or above the optimal band; it must be shown as in range with no optimal category, never as above optimal (check P3; process-results.ts classifies the bound itself today; F04-DQ-4).";
changes.push({ row_key: "hs_crp|both|All Adults|none", field: "method_note", from: mnBefore, to: crp.method_note, direction: "neutral",
  reason: "Carries the pregnancy and lactation facts from the removed state rows and states the bounded-result rule the app must follow (P3).", evidence_ids: ["f04-E12", "f04-E13", "f04-E14"], issue_ids: [] });
const notesBefore = crp.notes;
crp.notes = notesBefore.replace(
  "so the band carries the 'reached by a minority' label there (f04-Q01).",
  "so the band carries the 'reached by a minority' label (f04-Q01); round 2 wrote the label into the optimal and above-optimal messages in both languages, and the 70-79 non-optimal share (90.0% men, 90.4% women in check N1) is physician question F04-DQ-2."
);
if (crp.notes === notesBefore) throw new Error("notes not updated");
changes.push({ row_key: "hs_crp|both|All Adults|none", field: "notes", from: notesBefore, to: crp.notes, direction: "neutral",
  reason: "Records where the N1 label now sits and the physician question for ages 70-79.", evidence_ids: ["f04-E06"], issue_ids: [] });

// ── Physician questions. ──
const vq = (id) => { const q = verify.physician_questions.find((x) => x.id === id); if (!q) throw new Error(id); return clone(q); };
const physician_questions = [
  vq("f04-VQ-1"),
  vq("f04-VQ-3"),
  {
    id: "F04-DQ-1", row_key: null,
    question: "Declared pregnancy or lactation and hs-CRP: confirm that the separate pregnancy and lactation rows stay removed and that the single app rule of state-rules.md section 2.1 (laboratory interval only, no category, no score, no biological age, one fixed note) is the only way these states are handled, and that it must be in the app before launch?",
    why: "Judge J1 found, and both refuters confirmed (ledger f04_inflammation--C1--hs_crp.female.All_Adults.pregnancy--none and ...lactation--none), that a client who declares pregnancy or breastfeeding is classified on hs_crp|both|All Adults|none with the 0.5 mg/L optimal band and is scored, because src/lib/biomarkers/reference-row.ts referenceRowFor takes sex and age only. Removing the state rows does not fix this; only the app rule does, and it lies outside the family file. hs-CRP rises normally in pregnancy: third-trimester median 4.12 mg/L (f04-E12) and a pregnancy-specific upper reference limit of 19 mg/L (f04-E13), so many healthy pregnant women would read 'above the reference interval'. Until the rule exists, the PLAN.md section 4 definition is not met for any marker.",
    evidence_ids: ["f04-E12", "f04-E13", "f04-E14"],
    options: [
      "Keep the rows removed; the app implements state-rules.md 2.1 before launch (recommended)",
      "Restore pregnancy and lactation rows once the picker reads the declared state, with pregnancy-specific intervals by trimester (state-rules.md 2.3)",
      "Hide hs-CRP entirely for declared pregnancy or lactation",
    ],
  },
  {
    id: "F04-DQ-2", row_key: "hs_crp|both|All Adults|none",
    question: "hs-CRP at ages 70-79 (and the 70-84 and 85+ pass): keep the 0.5 mg/L optimal ceiling for older adults, now labelled 'reached by a minority', knowing that about 90% of healthy NHANES adults aged 70-79 are above it?",
    why: "Check N1 (judge J1, confirmed): 90.0% of healthy men and 90.4% of healthy women aged 70-79 are non-optimal under the 0.5 mg/L ceiling; women reach the band in 9.5% at 60-69 and 9.6% at 70-79 (check interpolation; distributions.json non-outcome split gives 9.26% and 9.98%). The ceiling is the lowest-risk category in the Women's Health Study: crude relative risk 1.0 below 0.5 mg/L against 2.2 at 0.5 to <1.0, and 'Of the total cohort, 15.1% had hsCRP <0.50 mg/L' (f04-E06, PMID 15051634, abstract opened in this task); the gradient is log-linear without a threshold (f04-E08, f04-E09). No opened source gives a separate older-adult band. Round 2 adds the minority label to the optimal and above-optimal messages; the age split itself is the physician's decision (f04-Q01 sets out the 1.0 mg/L alternative). For the harness, the resolution text for docs/signoff/work/nhanes/n1-resolutions.json is this question (kind physician_question for hs_crp|male|70-79 and hs_crp|female|70-79) and the label sentence of the optimal message (kind label for hs_crp|female|60-69 and hs_crp|female|70-79).",
    evidence_ids: ["f04-E06", "f04-E07", "f04-E08", "f04-E09"],
    options: [
      "Keep 0.5 mg/L at every age with the minority label (recommended: no opened source supports a different older-adult nadir)",
      "Use below 1.0 mg/L (CDC/AHA low-risk category) from age 70, as a grade C decision-table entry",
      "Show hs-CRP from age 70 as in range or out of range only, with no optimal band",
    ],
  },
  {
    id: "F04-DQ-3", row_key: "hs_crp|both|All Adults|none",
    question: "Confirm that an hs-CRP above 3 mg/L, which has no critical limit, must never trigger the app notice 'may need prompt medical attention' / 'podría necesitar atención médica pronta', and that the notice is removed or tied to signed critical limits before launch?",
    why: "Judge J1 (M3, confirmed by both refuters): the app classifies every value above Normal_High as zone critical_high, and the labs and dashboard pages show CriticalValueNotice (MedicalDisclaimer.tsx lines 189-193) whenever any marker is in that zone. A client with hs-CRP 3.5 mg/L after a cold is told it may need prompt medical attention, against PLAN.md section 4 ('Prompt medical attention' appears only with a critical limit) and wording-rules.md section 3.2, which already records the breach. The row's own messages comply; the defect is app-wide copy outside this file and affects every marker, fibrinogen included.",
    evidence_ids: ["f04-E03"],
    options: ["Remove the notice in safe mode and rebuild it on signed critical limits only (recommended)", "Keep the notice with non-critical wording for any out-of-range value"],
  },
  {
    id: "F04-DQ-4", row_key: "hs_crp|both|All Adults|none",
    question: "Bounded hs-CRP results ('<x' mg/L): show them as in range with no optimal category whenever x is above 0.5 mg/L, until Echevarne gives the assay's lowest reportable value?",
    why: "Check P3: a result reported as '<1.75' mg/L is classified above optimal today, because process-results.ts classifies the bound itself and ignores the '<' comparator. The true value may be inside the optimal band. The assay's lowest reportable value is unknown (methods letter). The fix is in the app; the row's method note now states the rule.",
    evidence_ids: [],
    options: ["In range with no optimal category (recommended)", "Not classified, value only"],
  },
  {
    id: "F04-DQ-5", row_key: "fibrinogen|both|All Adults|none",
    question: "Approve the corrected published summary for fibrinogen, which today still says 'Optimal is up to 300 mg/dL': EN 'Reference interval 200-400 mg/dL (Echevarne H0028, citrated plasma, clotting method). Reference only: no optimal band and not scored, because no outcome study shows a threshold.' ES 'Intervalo de referencia 200-400 mg/dL (Echevarne H0028, plasma citratado, método coagulativo). Solo referencia: sin banda óptima y sin puntuación, porque ningún estudio de resultados muestra un umbral.'?",
    why: "Judges J2 and J3 (G6, confirmed): the compiled biomarker-sources.json keeps the production summary 'Optimal is up to 300 mg/dL' while the row is class e with no optimal band. docs/signoff/tools/lib/compile-sources.js copies summary_en, summary_es, caveats_en and caveats_es from the existing entry, so a decision file cannot change them; the compile or the pack must use this text. The removal rests on the Fibrinogen Studies Collaboration ('no evidence of a threshold ... at any age', f04-E20, grade B) and Mendelian randomisation (f04-E21, grade A). The hs-CRP half of J3's G6 finding (evidence_grade D) came from the grade D pregnancy and lactation rows, now removed; the remaining hs-CRP row is grade B.",
    evidence_ids: ["f04-E20", "f04-E21"],
    options: ["Approve the text", "Amend the text"],
  },
];

const issues_addressed = [
  L + "C1--hs_crp.female.Lactation.unreachable--none",
  L + "C1--hs_crp.female.Pregnancy.unreachable--none",
  L + "D2--hs_crp.female.Lactation.age_group--none",
  L + "D2--hs_crp.female.Pregnancy.age_group--none",
  L + "D3--hs_crp.female.Lactation.no_catalogue_band--none",
  L + "D3--hs_crp.female.Pregnancy.no_catalogue_band--none",
  L + "D5--fibrinogen.both.All_Adults.bounds--none",
  L + "D5--hs_crp.both.All_Adults.bounds--none",
  L + "D5--hs_crp.female.Lactation.row_only_in_seed--none",
  L + "D5--hs_crp.female.Pregnancy.row_only_in_seed--none",
  L + "M2--fibrinogen.both.All_Adults.critical_high.en--none",
  L + "M2--fibrinogen.both.All_Adults.critical_high.es--none",
  L + "M2--fibrinogen.both.All_Adults.critical_low.es--none",
  L + "M2--hs_crp.both.All_Adults.critical_high.en--none",
  L + "N1--hs_crp.both.All_Adults.none--high",
  L + "N1--hs_crp.female.60-69.optimal_minority--none",
  L + "N1--hs_crp.female.70-79.non_optimal_70_79--none",
  L + "N1--hs_crp.female.70-79.optimal_minority--none",
  L + "N1--hs_crp.male.70-79.non_optimal_70_79--none",
];

const notes = `Round 2 fixer decision for f04_inflammation, written 2026-11-07 from verify file sha256 ${sha}. AI work product for review by a licensed physician; AI pre-review, not a sign-off.

Resolved here: (1) the hs-CRP pregnancy and lactation rows are removed, because state-rules.md sections 2.1-2.2 handle both states with one app rule and the rows only repeated the general interval (C1, D2, D3 no_catalogue_band and D5 row_only_in_seed script issues); their pregnancy facts move to the general row's method note. (2) hs-CRP normal_low: production 0 against the verify file's null is recorded as a documented neutral difference (D5; the decision limit and Echevarne give no lower limit, and no value classifies differently). (3) The fibrinogen optimal ceiling 300 mg/dL removed against production is recorded as a loosening with grade B (f04-E20) and grade A (f04-E21) quotes (D5). D5 compares the seed with production only, so it will keep listing (2) and (3) as differences until the migration is applied; both now carry a reason and a source. (4) M2: the hs-CRP and fibrinogen above-range messages now say what a raised value may mean, and the Spanish fibrinogen below-range repeat sentence states that it confirms the result. (5) N1: the 'reached by a minority' label is in the hs-CRP optimal and above-optimal messages in both languages, and ages 70-79 are physician question F04-DQ-2.

Confirmed issues not resolvable in this file, each with a physician question: C1 (J1) pregnancy and lactation behaviour needs the app state rule (F04-DQ-1); M3 (J1) the CriticalValueNotice is app copy (F04-DQ-3); G6 (J2, J3) the fibrinogen summary text in biomarker-sources.json is copied by the compile from the production entry (F04-DQ-5 gives the replacement text; the hs-CRP grade D half is fixed by removing the grade D rows). Open script issues not resolved, with the reason: D3 hs_crp bounds is a harness reading, not a row error: the row's basis is the CDC/AHA decision limit '>3.0 mg/L', copied exactly (f04-E01), with reference_source filled, but scripts/signoff/lib/seed.ts reads a 'Source' column while compile-rows.js writes 'Reference_Source', so the D3 exemption never applies; and Echevarne's '<3.01' with values to two decimals is 3.00 as the highest value inside, which EVA's inclusive normal_high 3 reproduces exactly, while 3.01 would put a value the laboratory flags inside the range. L1 'table|hs_crp: no entry' is the reader mismatch already reported by f01: docs/signoff/work/governance/critical-limits.json has the hs-CRP entry (entries[17]) under 'key', while scripts/signoff/checks/limits.ts indexes entries by 'marker_key'. P3 is app behaviour (process-results.ts ignores the '<' comparator) and fails for every row with an optimal ceiling; the rule is in the method note and F04-DQ-4.

Harness notes: N1 reads resolutions only from docs/signoff/work/nhanes/n1-resolutions.json, which this fixer may not write; suggested entries: 'hs_crp|female|60-69|optimal_minority' and 'hs_crp|female|70-79|optimal_minority' kind label, text the label sentence of the optimal message; 'hs_crp|male|70-79|non_optimal_70_79' and 'hs_crp|female|70-79|non_optimal_70_79' kind physician_question, text F04-DQ-2. The M2 Spanish confirm_repeat pattern lists 'repít' with an accent, which does not match the imperative 'Repite' that wording-rules.md prescribes. Verify question f04-VQ-2 (lactation message) is dropped with the lactation row. Disputed issues (C2, C3, D5 J1, E2 J3) are left as they are. Searches: 0 WebSearch calls; PubMed efetch for PMIDs 15051634, 16219884 and 16870675 (quotes for f04-E06, f04-E20 and f04-E21 confirmed in the abstracts).`;

const doc = {
  schema_version: "1",
  family: "f04_inflammation",
  round: 2,
  decided_at: "2026-11-07",
  verify_sha256: sha,
  fixer_role: "physician fixer, round 2 (AI work product for physician review)",
  final_rows: finalRows,
  changes,
  issues_addressed,
  evidence: [],
  physician_questions,
  notes,
};
fs.writeFileSync(outPath, JSON.stringify(doc, null, 2) + "\n");
console.log("wrote", outPath, finalRows.length, "rows,", changes.length, "changes");
