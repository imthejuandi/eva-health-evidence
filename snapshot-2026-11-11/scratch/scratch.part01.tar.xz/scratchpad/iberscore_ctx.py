import sys, re
import xml.etree.ElementTree as ET
path = sys.argv[1]
pats = sys.argv[2:]
t = ET.parse(path)
root = t.getroot()
# collect references: find the ref id(s) that cite IberScore paper
refids = []
for ref in root.iter('ref'):
    txt = ' '.join(ref.itertext())
    if re.search(r'IberScore|Fern[aá]ndez-Labandera|2047487319894880|33838039', txt, re.I):
        refids.append(ref.get('id'))
        print('REF', ref.get('id'), '::', re.sub(r'\s+',' ',txt)[:400])
# find paragraphs mentioning the ref ids or patterns
for p in root.iter('p'):
    xr = [x.get('rid') for x in p.iter('xref')]
    rids = set()
    for r in xr:
        if r: rids.update(r.split())
    txt = re.sub(r'\s+',' ',' '.join(p.itertext()))
    hit = any(r in rids for r in refids) or any(re.search(pp, txt, re.I) for pp in pats)
    if hit:
        print('PARA ::', txt[:2500])
        print('---')
