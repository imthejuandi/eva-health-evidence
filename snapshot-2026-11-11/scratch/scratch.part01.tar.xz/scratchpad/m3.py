import re,io
p="/home/user/eva-health/scripts/signoff/checks/messages.ts"
s=open(p,encoding="utf8").read()
start=s.index("export interface Lexicon {")
end=s.index("/** String literals in a TS/TSX source")
new='''export interface TierRules {
  terms: string[];
  regex: string[];
  allow: string[];
}
export interface Lexicon {
  flags: string;
  /** language → tier ("any" applies to every text, "non_critical" to every text outside the critical tier) → rules */
  langs: Record<string, Record<string, TierRules>>;
}

const strings = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);

/**
 * The banned-term lexicon: the first fenced json block of wording-rules.md (the fence may carry a label, as in
 * "```json banned_terms"). Per language and tier it holds `terms` (whole-word phrases), `regex` (patterns compiled
 * with the document's `flags`) and `allow` (phrases removed from the text before matching). A tier given as a
 * plain list of strings is read as terms. The `required` block is not a tier.
 */
export function parseLexicon(markdown: string): Lexicon | null {
  const m = markdown.match(/```json[^\\n]*\\n([\\s\\S]*?)\\n```/);
  if (!m) return null;
  let doc: Record<string, unknown>;
  try {
    doc = JSON.parse(m[1]) as Record<string, unknown>;
  } catch {
    return null;
  }
  const src = (doc.banned && typeof doc.banned === "object" ? doc.banned : doc) as Record<string, unknown>;
  const langs: Record<string, Record<string, TierRules>> = {};
  for (const lang of ["en", "es"]) {
    const tiers = src[lang];
    if (!tiers || typeof tiers !== "object") continue;
    for (const [tier, v] of Object.entries(tiers as Record<string, unknown>)) {
      if (tier === "required") continue;
      let rules: TierRules | null = null;
      if (Array.isArray(v)) rules = { terms: strings(v), regex: [], allow: [] };
      else if (v && typeof v === "object") {
        const o = v as Record<string, unknown>;
        if (Array.isArray(o.terms) || Array.isArray(o.regex)) rules = { terms: strings(o.terms), regex: strings(o.regex), allow: strings(o.allow) };
      }
      if (rules) (langs[lang] ??= {})[tier === "all" ? "any" : tier] = rules;
    }
  }
  if (!Object.keys(langs).length) return null;
  return { flags: typeof doc.flags === "string" ? doc.flags : "i", langs };
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\\\$&");

/** The banned phrases a text contains under the given rules, lower-cased, de-duplicated and sorted. */
export function lexiconHits(text: string, rules: TierRules[], flags = "i"): string[] {
  let t = text;
  for (const a of rules.flatMap((r) => r.allow)) t = t.replace(new RegExp(escapeRe(a), "giu"), " ");
  const hits = new Set<string>();
  for (const term of rules.flatMap((r) => r.terms)) {
    if (new RegExp(`(?<![\\\\p{L}])${escapeRe(term)}(?![\\\\p{L}])`, "iu").test(t)) hits.add(term.toLowerCase());
  }
  for (const pattern of rules.flatMap((r) => r.regex)) {
    let re: RegExp;
    try {
      re = new RegExp(pattern, flags.replace(/g/g, ""));
    } catch {
      continue;
    }
    const mm = t.match(re);
    if (mm) hits.add(mm[0].trim().toLowerCase());
  }
  return [...hits].filter(Boolean).sort();
}

'''
s=s[:start]+new+s[end:]
old_terms='const termsFor = (lang: string, tiers: string[]) => tiers.flatMap((t) => lex[lang]?.[t] ?? []);'
assert old_terms in s
s=s.replace(old_terms,'const rulesFor = (lang: string, tiers: string[]): TierRules[] => tiers.map((t) => lex.langs[lang]?.[t]).filter((r): r is TierRules => !!r);\n    const nonCritical = ["any", "non_critical"];')
s=s.replace('const hits = lexiconHits(text, termsFor(lang, ["all", "non_critical"]));','const hits = lexiconHits(text, rulesFor(lang, nonCritical), lex.flags);')
s=s.replace('const hits = [...new Set([...lexiconHits(lit, termsFor("en", ["all", "non_critical"])), ...lexiconHits(lit, termsFor("es", ["all", "non_critical"]))])];','const hits = [...new Set([...lexiconHits(lit, rulesFor("en", nonCritical), lex.flags), ...lexiconHits(lit, rulesFor("es", nonCritical), lex.flags)])].sort();')
assert "termsFor" not in s
open(p,"w",encoding="utf8").write(s)
