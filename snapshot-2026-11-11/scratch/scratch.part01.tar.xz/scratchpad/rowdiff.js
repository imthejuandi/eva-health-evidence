const d=require("/home/user/eva-health/docs/signoff/work/research/f14_iron.json");
const bi=Number(process.argv[2]); const i=Number(process.argv[3]);
const base=d.rows[bi]; const r=d.rows[i];
console.log("=== ROW",i, r.marker_key, r.sex, r.physiological_state, "vs base", bi);
for (const k of Object.keys(r)) {
  const a=JSON.stringify(base[k]), b=JSON.stringify(r[k]);
  if (a!==b) {
    if (k==="action_limits"||k==="pre_analytical") {
      r[k].forEach((x,j)=>{ const m=base[k].findIndex(y=>JSON.stringify(y)===JSON.stringify(x)); if (m<0) console.log(k+"["+j+"]:",JSON.stringify(x,null,1)); else console.log(k+"["+j+"]: same as base["+m+"]"); });
    } else if (k==="messages") {
      for (const lang of ["en","es"]) for (const z of Object.keys(r.messages[lang])) { if ((base.messages[lang]||{})[z]!==r.messages[lang][z]) console.log("messages."+lang+"."+z+":",r.messages[lang][z]); else console.log("messages."+lang+"."+z+": same as base"); }
    } else console.log(k+":",JSON.stringify(r[k],null,1));
  }
}
