import { __test } from "@/lib/biomarkers/kdm-adapter";
import { resolveKdmParams, KIDNEY_MARKERS_NOT_USED } from "@/lib/biomarkers/biological-age-kdm";
import lib from "@/lib/biomarkers/data/marker_library_v2_2.json";
const map = __test.CODE_TO_KDM as Record<string, unknown>;
const keys = new Set<string>();
for (const v of Object.values(map)) {
  const k = typeof v === "string" ? v : (v as { kdm?: string; key?: string; marker?: string }).kdm ?? (v as { key?: string }).key ?? (v as { marker?: string }).marker;
  if (k) keys.add(k);
}
console.log("CODE_TO_KDM sample:", JSON.stringify(Object.entries(map).slice(0, 2)));
console.log("distinct mapped KDM keys:", keys.size);
const libMarkers = Object.keys((lib as { markers: Record<string, unknown> }).markers ?? {});
console.log("library markers:", libMarkers.length);
for (const sex of ["male", "female"] as const) {
  const all: Record<string, number> = Object.fromEntries(libMarkers.filter((m) => !KIDNEY_MARKERS_NOT_USED.includes(m)).map((m) => [m, 1]));
  const reach: Record<string, number> = Object.fromEntries([...keys].filter((m) => !KIDNEY_MARKERS_NOT_USED.includes(m)).map((m) => [m, 1]));
  const pAll = Object.keys(resolveKdmParams(all, sex, false).params).length;
  const pReach = Object.keys(resolveKdmParams(reach, sex, false).params).length;
  console.log(sex, "library with params (no kidney exclusions):", pAll, "reachable through CODE_TO_KDM:", pReach);
}
