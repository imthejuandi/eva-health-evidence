// Round-4 fixer edits for f01_albumin_proteins. Reads the round-3 decision file, writes the round-4 one.
const fs = require("fs");
const P = "/home/user/eva-health/docs/signoff/work/decisions/f01_albumin_proteins.json";
const d = JSON.parse(fs.readFileSync(P, "utf8"));
const LP = "f01_albumin_proteins--";

d.round = 4;
d.decided_at = "2026-11-08";
d.verify_sha256 = "bcd7bc56db70eab21f4dda7ff6c7309364f88375271b79f1f07652574371c6e1";

const row = (k) => d.final_rows.find((r) => r.marker_key === k);
const rk = (k) => `${k}|both|All Adults|none`;
const A = row("albumin"), TP = row("total_protein"), G = row("globulin"), R = row("albumin_globulin_ratio");
const changes = [];
function set(r, field, to, direction, reason, ev, issues) {
  const parts = field.split(".");
  let o = r;
  for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
  const last = parts[parts.length - 1];
  const from = o[last] === undefined ? null : o[last];
  o[last] = to;
  changes.push({ row_key: rk(r.marker_key), field, from, to, direction, reason, evidence_ids: ev, issue_ids: issues });
}

// ---------- Issue ids resolved this round ----------
const I = {
  ocTP: LP + "C2--total_protein.both.All_Adults.none--none",
  d2Preg: LP + "D2--albumin.female.All_Adults.pregnancy--none",
  e1Lact: LP + "E1--albumin.female.All_Adults.lactation--none",
  m2Preg: LP + "M2--albumin.female.All_Adults.pregnancy--none",
  m2Ratio: LP + "M2--albumin_globulin_ratio.both.All_Adults.none--high",
  m5: LP + "M5--none--none",
  basis: LP + "definition:basis_of_each_bound--albumin.both.All_Adults.none--low",
};

// ---------- 1. Albumin optimal message: no claim the band holds "at every age studied" ----------
set(A, "messages.en.optimal",
  "Your albumin is in the optimal band, from 41 g/L up to the top of the laboratory interval at 48 g/L. In large population studies of adults aged 35 and over, this is the band linked to the best long-term health, in both sexes. No action is needed.",
  "neutral",
  "Wording only, bounds unchanged. The round-3 text said the band holds 'at every age studied'. Moli-sani found the hypoalbuminaemia association only at 65 and over (HR 1.83, 1.33-2.50) and not below 65 (HR 1.03, 0.53-2.00; F01-E11), and no outcome source opened covers ages 18 to 34; J-MICC, aged 35-69 (F01-F06), shows the excess below 4.1 g/dL in a mostly younger cohort. The message now names the ages the studies cover (35 and over) and drops the claim (judge J1, definition: basis of each bound).",
  ["F01-E11", "F01-F06", "F01-E04"], [I.basis]);
set(A, "messages.es.optimal",
  "Tu albúmina está en la banda óptima, desde 41 g/L hasta el límite superior del intervalo del laboratorio, 48 g/L. En grandes estudios de población en adultos de 35 años o más, es la banda que se asocia a la mejor salud a largo plazo, en ambos sexos. No necesitas hacer nada.",
  "neutral",
  "Spanish mirror of the English change: 'en todas las edades estudiadas' removed; the studies cover adults aged 35 and over (F01-E11, F01-F06).",
  ["F01-E11", "F01-F06"], [I.basis]);

// ---------- 2. Albumin notes: basis of the 41 g/L floor stated correctly; OC flag ----------
set(A, "notes",
  "Class a confirmed (marker-classes.json draft): modifiable through nutrition and inflammation, with prospective mortality evidence in general populations. Version 3 marker and Base Panel marker; priority member of the albumin_proteins redundancy group. Basis of the 41 g/L floor (band rule lowest_risk_category, basis outcome categories): it is the first whole g/L inside the lowest-risk category of both tier-2 cohorts. J-MICC (35,746 adults aged 35-69, 11.8 years; F01-F06, F01-E03, F01-E04): reference category 4.1-5.1 g/dL; below 4.1 g/dL HR 1.69 (1.50-1.91, fully adjusted); above 5.1 g/dL HR 1.13 (0.47-2.72, 5 deaths). Moli-sani (17,930 adults aged 35 and over, CRP below 10 mg/L; F01-F07, F01-E01): reference category above 40 g/L; 35.1-40.0 g/L HR 1.23 (1.10-1.37). With the row's whole-g/L resolution (decimals 0) 'above 40 g/L' starts at 41, and 41 is J-MICC's category edge (4.1 g/dL); where the two cohorts differ (a value between 40.1 and 40.9 g/L) the row takes the higher edge. 41 g/L is not taken from the Moli-sani spline, whose reference is the cohort median (also 41 g/L) on a linear curve (P for non-linearity 0.97, F01-E02). The J-MICC edge was chosen by the authors from the Japanese laboratory standard, but the hazard ratios are outcome estimates for those categories, so the bound does not rest on a laboratory interval alone; whether such a category edge, on a curve with no plateau, is the right convention is F01-VQ-1 (judge J2). No sex split: the cohorts adjust for sex without reporting a different lowest-risk category. Age: Moli-sani found the association with albumin of 35 g/L or less only at 65 and over (HR 1.83 against 1.03 below 65; F01-E11), J-MICC finds it at 35-69, and evidence above 70 exists (EPESE 71 and over; Leiden 85-plus; Nomura at 85); no outcome source opened covers ages 18 to 34, so the band is extrapolated there (F01-DQ-8, with the 35 g/L action limit). Oral contraception: one small 1992 study (11 women aged 18-26, desogestrel 0.15 mg with ethinylestradiol 0.03 mg) found albumin 5.1 g/L lower after six months (F01-E20, proposed grade D); PLAN section 4 flags oral contraception on the rows it moves, so the clinical note now says so without a number; adding albumin to the app rule of state-rules.md 4.2 is F01-DQ-7. Menopause and hormone therapy: no separate rows, no source opened. Ages 18 to 19: same row. Ages 85 and over: same row, see PQ-3. NHANES (bromocresol purple) medians in the input: healthy women 70-79 41 g/L, men 70-79 42 g/L, so about half of healthy adults over 70 read below optimal; the share is lower if Echevarne uses bromocresol green.",
  "neutral",
  "Physician-facing note. Corrects the stated basis of optimal_low 41 g/L (judge J1: it is not the Moli-sani spline median but the first whole g/L of the lowest-risk category in both cohorts, opened in their full texts), states the Moli-sani age interaction and the 18-34 gap (F01-DQ-8), and replaces the reference to 'PQ-6', which was not among this file's questions (judge J5), with the oral-contraception flag and F01-DQ-7.",
  ["F01-F06", "F01-F07", "F01-E01", "F01-E02", "F01-E04", "F01-E11", "F01-E20"], [I.basis, I.ocTP]);

// ---------- 3. Clinical notes EN/ES (C-10) with the oral-contraception flag (PLAN section 4) ----------
function notesChange(r, en, es, reason, ev, issues) {
  set(r, "clinical_notes_en", en, "neutral", reason, ev, issues);
  set(r, "clinical_notes_es", es, "neutral", "Spanish version of clinical_notes_en, same content.", ev, issues);
}
notesChange(A,
  "The most abundant protein in your blood, made by the liver. It keeps fluid inside the blood vessels and carries hormones, medicines and nutrients. It falls with inflammation, with a diet very low in protein and when blood is drawn lying down. If you take a combined oral contraceptive pill, albumin can read a little lower; the interval shown does not take this into account.",
  "La proteína más abundante de tu sangre, producida por el hígado. Mantiene el líquido dentro de los vasos sanguíneos y transporta hormonas, medicamentos y nutrientes. Baja con la inflamación, con una dieta muy pobre en proteínas y cuando la sangre se extrae tumbado. Si tomas una píldora anticonceptiva combinada, la albúmina puede leerse algo más baja; el intervalo mostrado no lo tiene en cuenta.",
  "Clinical note written for this row's bounds (known central issue C-10: the family supplies clinical_notes_en and clinical_notes_es). The September note's 'broad marker of nutrition and healthy aging' is dropped as an unsourced claim. Oral contraception is flagged on the row it moves, as PLAN section 4 requires ('hormone therapy and oral contraception flagged on the rows they move'), with the state-rules.md wording 'the interval shown does not take it into account'; no number, because the only source is a small study (F01-E20, 11 women, albumin 5.1 g/L lower after six months). Posture and inflammation follow the pre-analytical records (F01-E21).",
  ["F01-E20", "F01-E21"], [I.ocTP]);
notesChange(TP,
  "The total amount of protein in your blood: albumin plus globulin. Read it together with those two results, which say more than the total. If you take a combined oral contraceptive pill, total protein can read a little lower; the interval shown does not take this into account.",
  "La cantidad total de proteína en tu sangre: la albúmina más la globulina. Interprétala junto con esos dos resultados, que dicen más que el total. Si tomas una píldora anticonceptiva combinada, las proteínas totales pueden leerse algo más bajas; el intervalo mostrado no lo tiene en cuenta.",
  "Clinical note written for this class e row (C-10). Flags oral contraception on the row it moves (PLAN section 4; judge J5 found no such note on the row): total protein 2.8 g/L lower after six months of a combined pill in one small study (F01-E20). The September note's 'overview of nutrition, liver function and immune status' is replaced by the component rule the row's messages already state.",
  ["F01-E20"], [I.ocTP]);
notesChange(G,
  "Globulin is calculated as total protein minus albumin. It is mostly antibodies, with some transport proteins, and rises with long-standing inflammation or infection. Because it is calculated, it also depends on the laboratory's albumin method: a method that reads albumin high makes globulin read low.",
  "La globulina se calcula como proteínas totales menos albúmina. Está formada sobre todo por anticuerpos, con algunas proteínas de transporte, y sube con la inflamación o la infección prolongadas. Como es un valor calculado, también depende del método de albúmina del laboratorio: un método que lee la albúmina alta hace que la globulina se lea baja.",
  "Clinical note written for this class e row (C-10). States that globulin is calculated and inherits the albumin dye bias (bromocresol green about 6 g/L above bromocresol purple, F01-E26, F01-E27), as the row's method note and messages already say.",
  ["F01-E26", "F01-E27"], []);
notesChange(R,
  "The albumin/globulin ratio is albumin divided by globulin. It adds nothing beyond your albumin and globulin results, so read it together with them. Because globulin is calculated from albumin, a laboratory method that reads albumin high raises the ratio.",
  "El cociente albúmina/globulina es la albúmina dividida por la globulina. No añade nada a tus resultados de albúmina y globulina, así que interprétalo junto con ellos. Como la globulina se calcula a partir de la albúmina, un método de laboratorio que lee la albúmina alta sube el cociente.",
  "Clinical note written for this class e row (C-10); replaces the September note's 'clues about liver function, inflammation and immune activity' with the redundancy statement the row's messages already make, and the dye effect (F01-E26, F01-E27, formula as in F01-E44).",
  ["F01-E26", "F01-E27", "F01-E44"], []);

// ---------- 4. Ratio above-range message: concentration does not change a ratio (judge J2, M2) ----------
set(R, "messages.en.above_range",
  "Your albumin/globulin ratio is above the interval, which ends at 2.53. A ratio this high can only occur when albumin is above its own interval or globulin is below its own, so read those two results first. Concentrated blood, for example from not drinking enough before the draw, raises albumin and globulin by the same proportion, so it does not change the ratio. The usual cause is a globulin on the low side, and a common, harmless technical cause is a laboratory albumin method that reads high, which makes the calculated globulin read low and the ratio read high. Repeat the test in 2 to 4 weeks together with albumin and total protein. Discuss it with your doctor at your next check-up; if your globulin is low, your doctor may suggest measuring your immunoglobulins. This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.",
  "neutral",
  "Judge J2 (M2): the round-3 text named concentrated blood as 'the usual cause' of a ratio above 2.53. Haemoconcentration raises albumin and globulin by the same factor and leaves their quotient unchanged, as the total-protein row's own posture note implies, so it cannot raise the ratio. The benign cause is now the albumin method: bromocresol green reads albumin about 6 g/L higher than bromocresol purple (F01-E26, F01-E27), and calculated globulin (total protein minus albumin, F01-E44) then reads low, so the ratio reads high. Bounds, urgency and the four required elements are unchanged.",
  ["F01-E26", "F01-E27", "F01-E44"], [I.m2Ratio]);
set(R, "messages.es.above_range",
  "Tu cociente albúmina/globulina está por encima del intervalo, que termina en 2,53. Un cociente tan alto solo puede darse cuando la albúmina está por encima de su propio intervalo o la globulina por debajo del suyo, así que mira primero esos dos resultados. La sangre concentrada, por ejemplo por beber poco antes de la extracción, sube la albúmina y la globulina en la misma proporción, así que no cambia el cociente. La causa habitual es una globulina algo baja, y una causa técnica frecuente e inofensiva es un método de albúmina del laboratorio que lee alto: la globulina calculada se lee baja y el cociente, alto. Confirma el resultado con un nuevo análisis en 2 a 4 semanas junto con la albúmina y las proteínas totales. Coméntalo con tu médico en tu próxima revisión; si la globulina está baja, tu médico puede proponerte medir las inmunoglobulinas. Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.",
  "neutral",
  "Spanish mirror of the English change (judge J2, M2): concentrated blood no longer named as the cause; the albumin-method cause named instead (F01-E26, F01-E27).",
  ["F01-E26", "F01-E27", "F01-E44"], [I.m2Ratio]);

// ---------- 5. Spanish physician-facing fields (C-11, judge J1 M5) ----------
const ES = {
  albumin: {
    method_note_es: "Echevarne indica solo 'Espectrofotometría Ultravioleta-Visible', sin el colorante. Un método de púrpura de bromocresol lee unos 6 g/L menos que el de verde de bromocresol (intervalo de referencia con púrpura 31-45 g/L frente a los 35-50 g/L de Pathology Harmony y de los fabricantes; sesgo del verde de 6,2 g/L frente a un inmunoensayo en sueros nefróticos). El intervalo de Echevarne, 32-48 g/L, queda entre un intervalo de tipo púrpura y uno de tipo verde. De las dos cohortes en las que se apoya el límite óptimo de 41 g/L, Moli-sani no indica el colorante (ensayo colorimétrico en un analizador ILab ARIES) y J-MICC midió la albúmina con verde de bromocresol o con púrpura de bromocresol modificado según la región del estudio, así que su límite de categoría de 4,1 g/dL es una cifra de métodos mezclados; NHANES, usado en la comprobación poblacional, es púrpura de bromocresol. La carta de métodos (línea de lanzamiento L4) debe aclarar el colorante antes de firmar la banda como definitiva, y el estudio de alineación puede desplazar el límite unos pocos g/L.",
    reference_source_es: "Echevarne B0020 Albúmina / suero (prueba B0200, sinónimo ALBS), catálogo docs/vendor/echevarne/catalogo-2026-08-25.tsv línea 55: 32-48 g/L, General (ambos sexos), edades 0-999, muestra suero, método 'Espectrofotometría Ultravioleta-Visible' (colorante no indicado), fechado el 01/06/2020",
    critical_none_reason_es: "ninguno, porque ninguna lista institucional o de consenso de valores críticos consultada incluye un límite de albúmina salvo una lista de atención primaria del NHS con 10 g/L o menos, que está en el suelo del intervalo de plausibilidad de la versión 3 (10 a 60 g/L en la comprobación B2; los límites de Tietz recogidos en la entrada son 15 a 60 g/L) y que en un cliente ambulatorio es casi siempre un error de muestra o de transcripción (docs/signoff/work/governance/critical-limits.json, entrada 'albumin', borrador del 2026-11-06); los valores por debajo de 32 g/L pasan al nivel fuera de rango con la urgencia 'pronto', los valores por debajo de 35 g/L llevan el límite de acción y una albúmina por debajo de 30 g/L bloquea la edad biológica (comprobación B2). Ese borrador ofrece 20 g/L como límite 'hoy' de opinión de experto (grado D) para que el médico lo acepte o lo rechace.",
  },
  total_protein: {
    method_note_es: "Echevarne: 'Espectrofotometría Ultravioleta-Visible' (reacción colorimétrica de tipo biuret). Las proteínas totales son la suma de la albúmina y la globulina, así que se aplica la regla de coherencia proteínas totales = albúmina + globulina (comprobación K1); las filas de globulina y del cociente de EVA proceden solo de informes subidos.",
    reference_source_es: "Echevarne B0024 Proteínas totales / suero (prueba B0240, sinónimo PTO), catálogo docs/vendor/echevarne/catalogo-2026-08-25.tsv línea 366: 57-82 g/L, General (ambos sexos), edades 0-999, muestra suero, método 'Espectrofotometría Ultravioleta-Visible', fechado el 01/06/2020",
    critical_none_reason_es: "ninguno, porque ninguna lista institucional o de consenso de valores críticos consultada incluye un límite de proteínas totales (docs/signoff/work/governance/critical-limits.json no tiene entrada; las proteínas totales no están en la lista L1); los valores fuera de rango llevan la urgencia 'pronto'.",
  },
  globulin: {
    method_note_es: "Globulina calculada (proteínas totales menos albúmina) en informes subidos de otros laboratorios; hereda el sesgo del colorante de la albúmina (el verde de bromocresol lee la albúmina unos 6 g/L más alta que la púrpura de bromocresol, así que la globulina calculada se lee más baja en la misma medida). El B0278 de Echevarne es la fracción de globulinas totales por electroforesis, otro mensurando, y se usa aquí solo porque es el único intervalo impreso de Echevarne para la globulina (nota del CMO de septiembre, referencia 1,9-4,0 g/dL). Unidad: producción guarda g/dL y convierte los valores subidos en g/L multiplicando por 0,1 (src/lib/biomarkers/unit-conversions.ts, líneas 496-502); el cambio a g/L aprobado en principio y aplazado (DR-2026-09-25-12) es la PQ-5 y exige invertir esa conversión en la misma versión.",
    reference_source_es: "Echevarne B0278 GLOBULINAS TOTALES (PROTEINOGRAMA B2060, electroforesis capilar), catálogo docs/vendor/echevarne/catalogo-2026-08-25.tsv línea 335: 19-40 g/L, General, edades 0-999, fechado el 01/12/2009; se lleva como 1,9-4,0 g/dL en la unidad de producción; el código no está mapeado en src/lib/lab-provider/echevarne.ts (solo candidato) y EVA recibe la globulina solo de informes subidos",
    critical_none_reason_es: "ninguno, porque ninguna lista de valores críticos consultada incluye un límite de globulina (la globulina no está en la lista L1 y docs/signoff/work/governance/critical-limits.json no tiene entrada); los valores fuera de rango llevan la urgencia 'pronto' y nombran la prueba de seguimiento.",
  },
  albumin_globulin_ratio: {
    method_note_es: "En los informes subidos el cociente suele ser la albúmina dividida por la globulina calculada (albúmina/(proteínas totales menos albúmina); fórmula como en F01-E44), así que cualquier cálculo dentro de la app debe llevar la albúmina (g/L) y la globulina (g/dL) a la misma unidad (globulina x 10) antes de dividir. El cociente calculado hereda el sesgo del colorante de la albúmina (el verde de bromocresol sube la albúmina unos 6 g/L, F01-E26, F01-E27, y con ello el cociente). El B0288 de Echevarne (0,99-1,81) es el cociente de su proteinograma por electroforesis capilar, otro mensurando. Los intervalos de adultos sanos sitúan el percentil 97,5 cerca de 1,8 para ambos mensurandos: electroforesis capilar (297 adultos, Adís Abeba) 1,16-1,8 en hombres y 1,09-1,74 en mujeres (F01-F02); cociente calculado por química seca, adultos de la provincia de Gandaki, 1,1-1,8 (F01-F01). Los valores de 1,81 a 2,53 son por tanto poco frecuentes en adultos sanos, pero cada uno exige una albúmina cerca de su límite superior o una globulina cerca de su límite inferior, y ambas se clasifican en sus propias filas; por encima de 2,53 una de ellas está fuera de su intervalo. Ninguna cohorte consultada muestra exceso de riesgo con cocientes altos (UK Biobank, 284.012 participantes, 16,48 años: cociente más alto HR 0,61, F01-F04; 26.974 adultos coreanos, menor riesgo en el grupo abierto de 1,5 o más, F01-F05). El cociente es redundante con sus componentes y no puntúa; la F01-DQ-4 pide al médico que firme este intervalo o una regla de la app que muestre el cociente solo como valor.",
    reference_source_es: "Límite inferior 0,99: Echevarne B0288 ALBÚMINA/GLOBULINAS TOTALES (PROTEINOGRAMA / SUERO, perfil B2060, sinónimo PROTE), catálogo docs/vendor/echevarne/catalogo-2026-08-25.tsv línea 345, impreso .99-1.81 (sin unidad), General, edades 0-999, muestra suero, método 'Electroforesis Capilar'. Límite superior 2,53: no es un límite impreso. Es 48/19 = 2,526, redondeado hacia arriba a dos decimales: el cociente más alto posible con la albúmina y la globulina dentro de los intervalos que EVA muestra para ellas (Echevarne B0020 albúmina 32-48 g/L, línea 55; B0278 globulinas totales 19-40 g/L, línea 335). Echevarne no imprime intervalo para el cociente calculado (albúmina/(proteínas totales - albúmina)) que EVA recibe de los informes subidos; el B0288 es el cociente electroforético, otro mensurando, y su límite superior impreso 1,81 contradice las filas de los componentes (albúmina 42,2 g/L con globulina 19,6 g/L da 2,16; K1, juez J1, confirmado por ambos refutadores). Se mantiene el límite inferior impreso: una albúmina dentro de su banda óptima (41 g/L o más) con una globulina dentro de su intervalo (40 g/L o menos) da al menos 41/40 = 1,025, así que el límite inferior nunca contradice a los componentes, y la evidencia de resultados de grado B sitúa el exceso de riesgo por debajo de 1,0-1,1 (F01-F05).",
    critical_none_reason_es: "ninguno, porque ninguna lista de valores críticos consultada incluye un límite para el cociente (no está en la lista L1; no hay entrada en docs/signoff/work/governance/critical-limits.json); los valores fuera de rango llevan la urgencia 'pronto' o la de rutina indicada en el mensaje.",
  },
};
for (const [k, fields] of Object.entries(ES)) {
  const r = row(k);
  for (const [f, v] of Object.entries(fields)) {
    set(r, f, v, "neutral",
      `Spanish text of ${f.replace(/_es$/, "")} for the Spanish file, the version the physician signs (known central issue C-11: the family supplies it; judge J1, M5, found these fields in English). Translation only; same content and numbers as the English field.`,
      [], [I.m5]);
  }
}

// ---------- 6. Total protein notes: PQ-6 reference replaced ----------
set(TP, "notes",
  TP.notes.replace("Oral contraception lowered total protein by 2.8 g/L in one small study (PQ-6).",
    "Oral contraception lowered total protein by 2.8 g/L after six months in one small study (11 women, F01-E20, proposed grade D); the row's clinical note flags it as PLAN section 4 requires, and adding total protein to the app rule of state-rules.md 4.2 is F01-DQ-7."),
  "neutral",
  "Judge J5 (C2): the note sent oral contraception to 'PQ-6', which is not among this file's physician questions, and no note sat on the row. The flag is now in the clinical note and the app-rule question is F01-DQ-7.",
  ["F01-E20"], [I.ocTP]);
if (!TP.notes.includes("F01-DQ-7")) throw new Error("TP notes replace failed");

// ---------- 7. New evidence records (opened in this task) ----------
d.evidence.push({
  id: "F01-F06",
  supports: [
    { row_key: rk("albumin"), bound: "optimal_low" },
    { row_key: rk("albumin"), bound: "age_split" },
  ],
  identifier: { type: "pmid", value: "41248155" },
  citation: "Serum albumin and gamma gap levels, and combined effect for risk of mortality in a Japanese population from the J-MICC study. PLoS One 2025. PMCID PMC12622803; DOI 10.1371/journal.pone.0336926.",
  year: 2025,
  quote: "The participants totaled 35,746 (17,160 men and 18,586 women) aged 35-69 years from the Japan Multi-Institutional Collaborative Cohort (J-MICC) Study. The mean follow-up period was 11.8 years, with 1,529 deaths and 1,907 censoring.",
  location: "abstract (PubMed record, fetched through Europe PMC on 2026-11-08)",
  design: "prospective cohort; Cox proportional hazards with adjustment for age, sex, BMI, activity, education, diet, comorbidity",
  n: 35746,
  follow_up_years: 11.8,
  outcome: "all-cause and cause-specific mortality",
  population_age: "35-69 years at enrolment",
  population_sex: "both",
  assay: "albumin by bromocresol green or modified bromocresol purple depending on study region; total protein by biuret (full text, Methods)",
  band_rule: "lowest_risk_category",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "Ages 35-69 only; the full text gives no albumin hazard ratio by age band. Full-text Table 2 (all causes, model 3): albumin below 4.1 g/dL HR 1.69 (1.50-1.91), 4.1-5.1 g/dL reference, above 5.1 g/dL HR 1.13 (0.47-2.72). The abstract calls the albumin dose relationship 'dose-dependent'. It covers the under-65 adults in whom Moli-sani found no association, and nobody under 35.",
  notes: "Same cohort as the verify records F01-E03, F01-E04 and F01-V01, which cite the PMC full text; this record cites the PubMed abstract for the age range and follow-up used in the albumin optimal message ('adults aged 35 and over').",
});
d.evidence.push({
  id: "F01-F07",
  supports: [{ row_key: rk("albumin"), bound: "optimal_low" }],
  identifier: { type: "pmcid", value: "PMC11247150" },
  citation: "Di Castelnuovo A et al. The association between hypoalbuminemia and risk of death due to cancer and vascular disease in individuals aged 65 years and older: findings from the prospective Moli-sani cohort study. eClinicalMedicine 2024. PMID 39010980; DOI 10.1016/j.eclinm.2024.102627.",
  year: 2024,
  quote: "Multivariable-adjusted HRs were calculated for three categories of serum albumin levels: ≤35 g/L, 35.1–40.0 g/L, and >40 g/L, with the latter group serving as the reference.",
  location: "full text (PMC), Methods, statistical analysis",
  design: "prospective cohort (Moli-sani), multivariable Cox models, competing-risk analysis",
  n: 17930,
  follow_up_years: null,
  outcome: "all-cause, vascular and cancer mortality",
  population_age: "35 years and over (mean 54, SD 11); 18.4% over 65",
  population_sex: "both",
  assay: "colorimetric assay on an ILab ARIES analyser; dye not stated",
  band_rule: "lowest_risk_category",
  basis_class: "outcome_nadir",
  proposed_grade: "B",
  age_stratified_statement: "Yes: the association of albumin 35 g/L or less with total mortality was seen at 65 and over (HR 1.83, 1.33-2.50) and not below 65 (HR 1.03, 0.53-2.00; P < 0.0001 for difference), F01-E11.",
  notes: "Defines the lowest-risk (reference) category as above 40 g/L; the 35.1-40.0 g/L hazard ratio 1.23 (1.10-1.37) is F01-E01. Follow-up length is not in the passages opened in this task, so it is left null.",
});

// ---------- 8. Physician questions ----------
d.physician_questions.push({
  id: "F01-DQ-7",
  row_key: rk("albumin"),
  question: "Oral contraception lowers albumin and total protein in the one study opened (11 women aged 18-26 on desogestrel 0.15 mg with ethinylestradiol 0.03 mg: albumin 5.1 g/L and total protein 2.8 g/L lower after six months). The rows now flag it in their clinical notes. Do you also add albumin and total protein to the app rule of state-rules.md section 4.2, so that with contraception = oral the fixed note shows on these rows and albumin is classified against the laboratory interval only, with no optimal category? Or is the clinical-note flag enough, given a single small study (proposed grade D)?",
  why: "PLAN section 4 says hormone therapy and oral contraception are 'flagged on the rows they move'. A 5.1 g/L fall would move a client from about 44 to 39 g/L, across the 41 g/L optimal floor. The app rule in state-rules.md 4.2 covers SHBG, estradiol, TSH, free T4, hs-CRP and triglycerides only, and is a governance file this decision cannot edit. The research file's PQ-6 raised this; judge J5 found it missing from the decision.",
  evidence_ids: ["F01-E20"],
  options: [
    "Add albumin and total protein to the state-rules.md 4.2 list (fixed note; albumin without optimal category while oral oestrogen continues)",
    "Keep the clinical-note flag only",
  ],
});
d.physician_questions.push({
  id: "F01-DQ-8",
  row_key: rk("albumin"),
  question: "No outcome cohort opened covers ages 18 to 34 (J-MICC 35-69, Moli-sani 35 and over, EPESE 71 and over), and Moli-sani found no association with low albumin below 65 (HR 1.03, 0.53-2.00). Do you sign the 41 g/L optimal floor and the 35 g/L action limit for all adults from 18, or do you show albumin as in range or out of range only (no optimal category, no score) at 18 to 34, keeping the 35 g/L action limit as a diagnostic follow-up at every age?",
  why: "PLAN section 4 defines the optimal band by prospective outcome data 'for that sex, age group' and allows an age split only where the evidence differs by age. Removing the band at 18-34 would be a loosening, which needs a grade A or B quote; no source opened supplies one, and none shows harm from the band either, so this is a clinical judgement, not a fix the evidence settles. Judges J3 (E4) and J1 (L2) raised it.",
  evidence_ids: ["F01-F06", "F01-F07", "F01-E11"],
  options: [
    "One row for all adults from 18 (current)",
    "Ages 18-34: in range / out of range only; 35 and over: optimal from 41 g/L; action limit 35 g/L at every age",
  ],
});

// ---------- 9. Bookkeeping ----------
d.changes = d.changes.concat(changes);
for (const id of Object.values(I)) if (!d.issues_addressed.includes(id)) d.issues_addressed.push(id);
// The three removed-row issues: record why they are resolved.
d.changes.push({
  row_key: "albumin|female|All Adults|pregnancy",
  field: "row",
  from: null,
  to: null,
  direction: "neutral",
  reason: "No new change: records that three judge issues on the pregnancy and lactation rows are resolved by the round-3 removal of those rows (changes above). D2 (Spanish 'Embarazo'/'Lactancia' labels, J2), E1 (the lactation rows reusing the pregnancy method note, J5) and M2 (the pregnancy critical-low message naming pre-eclampsia symptoms without a time frame, J5) all concerned texts of rows that no longer exist; D2 passes on the B01-r3 compile. Pregnancy and lactation are handled by the app-level rule of state-rules.md 2.1 (F01-DQ-5, central issue C-08).",
  evidence_ids: ["F01-E15"],
  issue_ids: [I.d2Preg, I.e1Lact, I.m2Preg],
});

d.notes = [
  "Round 4 fixer decision for f01_albumin_proteins, written 2026-11-08 from verify file sha256 bcd7bc56db70eab21f4dda7ff6c7309364f88375271b79f1f07652574371c6e1, starting from the round-3 decision file. AI work product for physician review. No bound changes in this round; no loosening.",
  "",
  "Resolved in round 4 (physician_question items whose check is not central and which the definitions settle):",
  "- definition: basis of each bound, albumin (J1): the basis of optimal_low 41 g/L is restated after opening both full texts. It is the first whole g/L inside the lowest-risk category of J-MICC (4.1-5.1 g/dL; below 4.1 HR 1.69, 1.50-1.91) and of Moli-sani (above 40 g/L; 35.1-40.0 HR 1.23, 1.10-1.37), not the Moli-sani spline median. The optimal message no longer says the band holds 'at every age studied'; it names adults aged 35 and over (F01-F06, F01-F07, F01-E11).",
  "- C2 total protein (J5): oral contraception is flagged in the clinical notes of albumin and total protein (PLAN section 4); the dangling 'PQ-6' reference is replaced by F01-DQ-7, which asks whether the app rule of state-rules.md 4.2 should also cover these rows.",
  "- M2 albumin/globulin ratio above range (J2): the message no longer names concentrated blood as the cause (a ratio is unchanged by concentration); it names the albumin-method cause instead (F01-E26, F01-E27).",
  "- M5 (J1): method_note_es, reference_source_es and critical_none_reason_es written for all four rows (central issue C-11, family part). clinical_notes_en and clinical_notes_es written for all four rows (C-10, family part).",
  "- D2, E1 and M2 on the pregnancy and lactation rows (J2, J5): resolved by the round-3 row removal; recorded in a change entry.",
  "",
  "Left as physician questions, with the reason:",
  "- E4 (J3) and L2 albumin (J1): ages 18-34 have no outcome source and Moli-sani shows no association below 65. Removing the band or the action limit for young adults would be a loosening without a grade A or B quote, and keeping them is an extrapolation; that is a clinical judgement, now F01-DQ-8.",
  "- definition: optimal band, albumin (J2), and P3 and D3 albumin dye (J1, J2): whether a laboratory-chosen category edge on a curve without plateau is the right floor, and the dye, are F01-VQ-1 and the Echevarne methods letter (central issue C-07).",
  "- L2 and definition: action limit, globulin (J1, J3): the 1.8 g/dL cut-off is the bromocresol-green one (F01-E36) and 2.3 g/dL the bromocresol-purple one (F01-E37); EVA does not record the dye of uploaded reports. Choosing between more false alarms and later detection is a clinical trade-off for the physician, not settled by the definitions.",
  "- D3 and definition: reference interval, albumin/globulin ratio (J1): the reference_basis enum has no value for a derived ceiling; F01-DQ-4 asks the physician to sign 0.99-2.53, a value-only rule or the printed 0.99-1.81.",
  "- D3, D4 and definition: reference interval, globulin (J1, J2): unit and measurand change is DR-2026-09-25-12 (PQ-5) and needs the app conversion flipped in the same release (D4, central C-18).",
  "- E1 'quote contains no number' (J1 and script; F01-E16, F01-E19, F01-E24, F01-E44, F01-V01): those records live in the research and verify files, which this fixer may not edit. This file cites them only for context (state rows, capillary note, ratio formula); the new records F01-F06 and F01-F07 carry numbers.",
  "",
  "Central items not addressed here (known-issues.md): C2 pregnancy (C-08, F01-DQ-5); D5 and D6 change reasons (C-02, C-21: every changed bound already carries a reason and source in changes); E2 cache (C-17; the new quotes are copied from the PubMed abstract of PMID 41248155 and the PMC full text of PMC11247150, both fetched in this task); G2 traceability (C-01); G6 summaries (C-09; proposed replacement texts are in the round-3 notes and still apply); K1 (C-13, F01-DQ-3); L1 and M3 critical zone (C-04, C-05; albumin's row carries critical none, matching critical-limits.json); N1 (C-14, F01-DQ-2); X1 (C-15, F01-DQ-1); definition: marker classes (C-16).",
  "",
  "Searches: 0 WebSearch calls. Fetched in this task: Europe PMC full text of PMC11247150 (Moli-sani) and PMC12622803 (J-MICC), the Europe PMC record of PMC12622803 (PMID 41248155), and the PubMed abstract of PMID 1385569 (oral contraception).",
].join("\n");

fs.writeFileSync(P, JSON.stringify(d, null, 2) + "\n");
console.log("changes added", changes.length + 1, "issues_addressed", d.issues_addressed.length);
