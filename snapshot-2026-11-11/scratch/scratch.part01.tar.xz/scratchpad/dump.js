const fs=require('fs');
const dir='docs/signoff/work/compiled/B01-r1/';
const en=JSON.parse(fs.readFileSync(dir+'biomarker-ranges-en.json'));
const es=JSON.parse(fs.readFileSync(dir+'rangos-biomarcadores-es.json'));
const want=/albumin|globulin|protein|bun|urea|creatinin|cystatin|egfr|fibrinogen|crp|proteína|albúmina|urea|creatinina|cistatina|fibrinógeno|pcr/i;
const enLines=fs.readFileSync(dir+'biomarker-ranges-en.json','utf8').split('\n');
function lineOf(text, lines){ // find line index of first line containing text
  const i=lines.findIndex(l=>l.includes(text)); return i+1;}
const which=process.argv[2];
const data = which==='es'?es:en;
const lines = which==='es'? fs.readFileSync(dir+'rangos-biomarcadores-es.json','utf8').split('\n') : enLines;
const key = which==='es' ? (Object.keys(data)[0]) : 'biomarker_ranges';
console.log('top keys', Object.keys(data));
const rows = data[key];
rows.forEach((r,idx)=>{
  const name = r.Biomarker||r.Biomarcador||JSON.stringify(r).slice(0,40);
  if(!want.test(name)) return;
  // find line number: search for the Biomarker line then the nth occurrence
  console.log('\n######## idx', idx, name);
  for (const [k,v] of Object.entries(r)) {
    const vs = typeof v==='string'? JSON.stringify(v): JSON.stringify(v);
    const needle = `"${k}": ${vs}`;
    let ln = lines.findIndex(l=>l.trim()===needle+',' || l.trim()===needle);
    console.log(`  [L${ln+1}] ${k}: ${vs}`);
  }
});
