// Builds docs/signoff/work/decisions/f01_albumin_proteins.json (round 2) from the verify file.
"use strict";
const fs = require("fs");
const path = require("path");
const REPO = "/home/user/eva-health";
const W = path.join(REPO, "docs/signoff/work");
const verify = JSON.parse(fs.readFileSync(path.join(W, "verify/f01_albumin_proteins.json"), "utf8"));
const VSHA = process.argv[2];
const clone = (x) => JSON.parse(JSON.stringify(x));
const rk = (r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;

const rows = clone(verify.final_rows).filter((r) => r.physiological_state === "none");
const get = (k) => rows.find((r) => r.marker_key === k);
const alb = get("albumin"), tp = get("total_protein"), glob = get("globulin"), agr = get("albumin_globulin_ratio");
const changes = [];
const ch = (row_key, field, from, to, direction, reason, evidence_ids, issue_ids) => changes.push({ row_key, field, from, to, direction, reason, evidence_ids, issue_ids });
const rep = (s, a, b) => { if (!s.includes(a)) throw new Error(`not found: ${a.slice(0, 60)}`); return s.replace(a, b); };

const ALB = "albumin|both|All Adults|none", TP = "total_protein|both|All Adults|none", GL = "globulin|both|All Adults|none", AG = "albumin_globulin_ratio|both|All Adults|none";
const L = (s) => `f01_albumin_proteins--${s}`;

// ── 1. Pregnancy and lactation rows removed (C1, D2, D3, D5, M2 script issues) ──
const stateIssues = {
  "albumin|female|All Adults|pregnancy": ["C1--albumin.female.Pregnancy.unreachable--none", "D2--albumin.female.Pregnancy.age_group--none", "D3--albumin.female.Pregnancy.no_catalogue_band--none", "D5--albumin.female.Pregnancy.row_only_in_seed--none", "M2--albumin.female.Pregnancy.critical_high.es--none"],
  "albumin|female|All Adults|lactation": ["C1--albumin.female.Lactation.unreachable--none", "D2--albumin.female.Lactation.age_group--none", "D3--albumin.female.Lactation.no_catalogue_band--none", "D5--albumin.female.Lactation.row_only_in_seed--none", "M2--albumin.female.Lactation.critical_high.en--none", "M2--albumin.female.Lactation.critical_high.es--none", "M2--albumin.female.Lactation.critical_low.es--none"],
  "total_protein|female|All Adults|pregnancy": ["C1--total_protein.female.Pregnancy.unreachable--none", "D2--total_protein.female.Pregnancy.age_group--none", "D3--total_protein.female.Pregnancy.no_catalogue_band--none", "D5--total_protein.female.Pregnancy.row_only_in_seed--none", "M2--total_protein.female.Pregnancy.critical_high.es--none"],
  "total_protein|female|All Adults|lactation": ["C1--total_protein.female.Lactation.unreachable--none", "D2--total_protein.female.Lactation.age_group--none", "D3--total_protein.female.Lactation.no_catalogue_band--none", "D5--total_protein.female.Lactation.row_only_in_seed--none", "M2--total_protein.female.Lactation.critical_high.es--none", "M2--total_protein.female.Lactation.critical_low.es--none"],
};
for (const [k, ids] of Object.entries(stateIssues)) {
  ch(k, "row", "present (laboratory interval 32-48 or 57-82 g/L, no optimal band, grade D)", null, "neutral",
    "Row removed. It duplicated the laboratory interval of the general row with no optimal band, and the app's picker (src/lib/biomarkers/reference-row.ts) has no pregnancy or lactation input, so the row was never picked (C1) and, compiled under the age-group label 'Pregnancy'/'Lactation', it broke EN/ES parity (D2), had no Echevarne band (D3) and no production counterpart (D5). Echevarne prints no pregnancy or lactation interval (catalogue lines 55 and 366), so the row added nothing beyond the general interval. PLAN section 4 ('declared pregnancy or lactation: the laboratory interval only, no optimal category, no score, no biological age, one fixed note') is delivered by the single app-level rule of docs/signoff/work/governance/state-rules.md sections 2.1 and 2.2 ('Por qué una sola regla y no filas de embarazo'), which applies to every marker, not by state rows. Until that rule is implemented in the app, pregnant and lactating clients are classified on the general row: physician question F01-DQ-5 and the open C2 issue.",
    ["F01-E15", "F01-E19"], ids.map(L));
}

// ── 2. Messages: M2 elements on the general rows ──
const ES_REPEAT = "Repite el análisis en 2 a 4 semanas";
const ES_CONFIRM = "Confirma el resultado con un nuevo análisis en 2 a 4 semanas";
function esRepeat(row, zone, issue) {
  const from = row.messages.es[zone];
  const to = rep(from, ES_REPEAT, ES_CONFIRM);
  row.messages.es[zone] = to;
  ch(rk(row), `messages.es.${zone}`, from, to, "neutral",
    "Wording only. The repeat rule was already present ('Repite el análisis en 2 a 4 semanas'), but the M2 pattern for the confirmation element does not recognise the imperative 'Repite'; the sentence now reads 'Confirma el resultado con un nuevo análisis en 2 a 4 semanas', same timing and meaning, so the four required elements are explicit. The M2 regular expression (scripts/signoff/checks/messages.ts line 98, 'repet|repít') misses 'Repite' in every family; reported in the decision notes.",
    [], [L(issue)]);
}
esRepeat(alb, "below_range", "M2--albumin.both.All_Adults.critical_low.es--none");
esRepeat(alb, "above_range", "M2--albumin.both.All_Adults.critical_high.es--none");
esRepeat(tp, "below_range", "M2--total_protein.both.All_Adults.critical_low.es--none");
esRepeat(tp, "above_range", "M2--total_protein.both.All_Adults.critical_high.es--none");
esRepeat(glob, "above_range", "M2--globulin.both.All_Adults.critical_high.es--none");

// Globulin below range: benign / spurious cause made explicit (EN and ES) and the Spanish repeat rule.
{
  const fromEn = glob.messages.en.below_range;
  const toEn = rep(fromEn, "Globulin is mostly antibodies, so a low value can mean fewer antibodies are being made or that protein is being lost; it also reads low when the laboratory's albumin method reads high.",
    "Globulin is mostly antibodies, so a low value can mean fewer antibodies are being made or that protein is being lost. A common, spurious cause is technical: globulin is calculated as total protein minus albumin, so it reads low whenever the laboratory's albumin method reads high.");
  glob.messages.en.below_range = toEn;
  ch(GL, "messages.en.below_range", fromEn, toEn, "neutral",
    "M2: the benign or spurious cause was present ('it also reads low when the laboratory's albumin method reads high') but not named as such; it is now stated as a common spurious, technical cause. Basis: the bromocresol green albumin assay reads about 6 g/L higher than bromocresol purple (F01-E26, F01-E27), and calculated globulin inherits that bias.",
    ["F01-E26", "F01-E27"], [L("M2--globulin.both.All_Adults.critical_low.en--none")]);
  const fromEs = glob.messages.es.below_range;
  let toEs = rep(fromEs, "La globulina está formada sobre todo por anticuerpos, así que un valor bajo puede significar que se fabrican menos anticuerpos o que se pierde proteína; también se lee baja cuando el método de albúmina del laboratorio lee alto.",
    "La globulina está formada sobre todo por anticuerpos, así que un valor bajo puede significar que se fabrican menos anticuerpos o que se pierde proteína. Una causa frecuente y espuria es técnica: la globulina se calcula como proteínas totales menos albúmina, así que se lee baja siempre que el método de albúmina del laboratorio lee alto.");
  toEs = rep(toEs, ES_REPEAT, ES_CONFIRM);
  glob.messages.es.below_range = toEs;
  ch(GL, "messages.es.below_range", fromEs, toEs, "neutral",
    "M2: Spanish mirror of the English change (frequent spurious technical cause named) and the repeat sentence reworded to 'Confirma el resultado con un nuevo análisis en 2 a 4 semanas'.",
    ["F01-E26", "F01-E27"], [L("M2--globulin.both.All_Adults.critical_low.es--none")]);
}

// ── 3. Albumin/globulin ratio: Echevarne's printed interval B0288 (K1, J2 confirmed) ──
{
  const prodLow = 1, prodHigh = 2.5;
  agr.reference_low = 0.99;
  agr.reference_high = 1.81;
  const oldSource = agr.reference_source;
  agr.reference_source = "Echevarne B0288 ALBÚMINA/GLOBULINAS TOTALES (PROTEINOGRAMA / SUERO, profile B2060, synonym PROTE), catalogue docs/vendor/echevarne/catalogo-2026-08-25.tsv line 345: .99-1.81 (no unit), General (both sexes), ages 0-999, specimen serum, method 'Electroforesis Capilar', dated 14/11/2003. It is the only albumin/globulin ratio interval Echevarne prints. Measurand caveat: Echevarne's ratio is electrophoretic, while EVA receives the ratio only from uploaded reports, usually calculated as albumin/(total protein - albumin); the code is not mapped in src/lib/lab-provider/echevarne.ts. Two healthy-adult reference studies give a similar interval for both measurands: capillary electrophoresis 1.16-1.8 (men) and 1.09-1.74 (women) (F01-F02) and dry-chemistry calculated ratio 1.1-1.8 (F01-F01).";
  const L1 = agr.messages.en, S1 = agr.messages.es;
  const old = clone(agr.messages);
  L1.in_range = "Your albumin/globulin ratio is within the laboratory interval (0.99 to 1.81). It summarises the balance between albumin and the other blood proteins; read it together with your albumin and globulin results. This marker does not count toward the score.";
  L1.below_range = rep(L1.below_range, "is below the interval, which starts at 0.8.", "is below the laboratory interval, which starts at 0.99.");
  L1.above_range = "Your albumin/globulin ratio is above the laboratory interval, which ends at 1.81. A high ratio usually means globulin is on the low side or the blood was concentrated (not drinking enough before the draw, a long tourniquet time); this is a common and usually harmless finding when albumin and globulin are each within their own intervals. Repeat the test in 2 to 4 weeks together with albumin and total protein. Discuss it with your doctor at your next check-up. This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.";
  S1.in_range = "Tu cociente albúmina/globulina está dentro del intervalo del laboratorio (0,99 a 1,81). Resume el equilibrio entre la albúmina y el resto de proteínas de la sangre; interprétalo junto con tus resultados de albúmina y globulina. Este marcador no entra en la puntuación.";
  S1.below_range = rep(rep(S1.below_range, "está por debajo del intervalo, que empieza en 0,8.", "está por debajo del intervalo del laboratorio, que empieza en 0,99."), ES_REPEAT, ES_CONFIRM);
  S1.above_range = "Tu cociente albúmina/globulina está por encima del intervalo del laboratorio, que termina en 1,81. Un cociente alto suele significar que la globulina está algo baja o que la sangre estaba concentrada (beber poco antes de la extracción, un torniquete prolongado); es un hallazgo frecuente y casi siempre benigno cuando la albúmina y la globulina están cada una dentro de su intervalo. Confirma el resultado con un nuevo análisis en 2 a 4 semanas junto con la albúmina y las proteínas totales. Coméntalo con tu médico en tu próxima revisión. Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita.";
  agr.method_note = "Echevarne's B0288 (0.99-1.81) is the ratio from its capillary-electrophoresis proteinogram. On uploaded reports the ratio is usually albumin divided by calculated globulin (albumin/(total protein minus albumin); formula as in F01-E44), so any in-app calculation must bring albumin (g/L) and globulin (g/dL) to the same unit (globulin x 10) before dividing. The calculated ratio inherits the albumin dye bias (bromocresol green raises albumin by about 6 g/L, F01-E26, F01-E27, and so raises the ratio). Independent healthy-adult intervals agree with Echevarne's to within about 0.1: capillary electrophoresis (Capillarys 2, 297 adults, Addis Ababa) 1.16-1.8 in men and 1.09-1.74 in women (F01-F02); dry-chemistry calculated ratio, adults of Gandaki Province, 1.1-1.8 (F01-F01); Korean community cohort median 1.38, IQR 1.28-1.52 (F01-E43). The interval of the uploading laboratory may differ; PQ-4 and F01-DQ-4 ask the physician.";
  agr.notes = "Class e kept (marker-classes.json draft 'e'): albumin, the priority member of the albumin_proteins redundancy group, carries the modifiable signal. Outcome evidence on the ratio itself is substantial and points to higher risk at low ratios (26,974 healthy Korean adults: AGR below 1.0 aHR 6.71 and 1.0-1.1 aHR 2.69 against 1.5 or more, F01-E39; UK Biobank 284,012 participants over 16.48 years, F01-E42; NHANES CKM inflection 1.26, F01-E41), so the class is a physician decision (PQ-4, F01-DQ-6). Population median in a Korean community cohort 1.38 (IQR 1.28-1.52, F01-E43). No sex or age split: Echevarne prints one General interval; the Ethiopian study partitions by sex with a difference of under 0.1 (F01-F02). Pregnancy and lactation: app-level rule of state-rules.md 2.1, no separate rows. Coherence (K1): with 0.99-1.81, albumin inside its optimal band and globulin in the lower part of its interval give a ratio above 1.81 (for example 42.2 g/L over 19.6 g/L = 2.16), because three separately printed percentile intervals are not arithmetically consistent; F01-DQ-4.";
  agr.change_vs_production = "Reference 1.0-2.5 -> 0.99-1.81: Echevarne's printed ratio interval B0288 (catalogue line 345), replacing the production interval, which had no source, and the round-1 interval 0.8-2.5, which was the quotient of the extremes of two other intervals and was wrongly labelled as an Echevarne interval (K1 issue, judge J2). optimal 1.4-2.5 removed: class e (marker-classes.json draft). Messages rewritten to the new bounds and the wording rules.";
  ch(AG, "reference_low", prodLow, 0.99, "loosen",
    `Reference track (PLAN section 5: 'Reference limits: Echevarne's interval'). Echevarne prints 0.99-1.81 for the ratio (B0288, catalogue line 345); production had 1.0 with no source and the round-1 verify file had 0.8 (from ${JSON.stringify(oldSource.slice(0, 60))}...), the quotient 32/40 of two other intervals, mislabelled echevarne_interval (judge J2, confirmed). Against the verify file this is a tightening (0.8 -> 0.99); against production the floor moves 0.01 lower, the printed value. The grade A/B rule for loosening applies to optimal bands; this is a laboratory limit copied exactly. Two independent healthy-adult studies give lower limits of 1.09-1.16 (F01-F02) and 1.1 (F01-F01), so 0.99 is not looser than the published populations.`,
    ["F01-F01", "F01-F02"], [L("K1--albumin_globulin_ratio.both.All_Adults.none--both"), L("D5--albumin_globulin_ratio.both.All_Adults.bounds--none")]);
  ch(AG, "reference_high", prodHigh, 1.81, "tighten",
    "Echevarne's printed ratio interval B0288 (catalogue line 345) ends at 1.81; production and round 1 had 2.5 (round 1 derived it as 48/19 = 2.53). Healthy-adult upper limits of 1.74-1.8 (F01-F02) and 1.8 (F01-F01) agree with 1.81. The K1 example of judge J2 (albumin 39.77 g/L, globulin 4.12 g/dL, ratio 0.97 'in range' while globulin is out of range) now reads below range.",
    ["F01-F01", "F01-F02"], [L("K1--albumin_globulin_ratio.both.All_Adults.none--both"), L("D5--albumin_globulin_ratio.both.All_Adults.bounds--none")]);
  ch(AG, "reference_source", oldSource, agr.reference_source, "neutral",
    "Source of the new interval: Echevarne B0288 printed interval, with the measurand caveat and the two corroborating healthy-adult studies.",
    ["F01-F01", "F01-F02"], [L("K1--albumin_globulin_ratio.both.All_Adults.none--both")]);
  ch(AG, "optimal_low", 1.4, null, "loosen",
    "Production optimal floor 1.4 removed (already absent in the round-1 verify file): the ratio is class e in the marker-classes.json draft, and a class e marker carries no optimal band (PLAN section 4). This removal rests on the class definition, not on outcome evidence: the grade B cohort F01-E39 (26,974 healthy Korean adults) found higher mortality below 1.1 against 1.5 or more, which argues for a floor, so the class is put to the physician (F01-DQ-6, PQ-4). Recorded here so the production difference is documented (D5).",
    ["F01-E39", "F01-E42"], [L("D5--albumin_globulin_ratio.both.All_Adults.bounds--none")]);
  ch(AG, "optimal_high", 2.5, null, "loosen",
    "Production optimal ceiling 2.5 removed with the class e band (PLAN section 4). No cohort opened shows harm at high ratios (F01-E39 reference group: 1.5 or more; F01-E42 HR 0.61 per unit increase), and the new reference ceiling 1.81 now bounds the in-range zone below the old optimal ceiling.",
    ["F01-E39", "F01-E42"], [L("D5--albumin_globulin_ratio.both.All_Adults.bounds--none")]);
  for (const z of ["in_range", "below_range", "above_range"]) {
    ch(AG, `messages.en.${z}`, old.en[z], L1[z], "neutral", "Messages follow the new interval 0.99-1.81; above_range names the common benign causes (M2 benign_causes was missing).", [], z === "above_range" ? [L("M2--albumin_globulin_ratio.both.All_Adults.critical_high.en--none")] : []);
    ch(AG, `messages.es.${z}`, old.es[z], S1[z], "neutral", "Spanish mirror; the repeat sentence reads 'Confirma el resultado con un nuevo análisis en 2 a 4 semanas' (M2 confirm_repeat) and above_range names the frequent benign causes.", [], z === "above_range" ? [L("M2--albumin_globulin_ratio.both.All_Adults.critical_high.es--none")] : z === "below_range" ? [L("M2--albumin_globulin_ratio.both.All_Adults.critical_low.es--none")] : []);
  }
}

// ── 4. Documented differences against production (D5) ──
ch(ALB, "reference_low", 35, 32, "loosen",
  "Reference track: Echevarne prints 32-48 g/L for B0020 (catalogue line 55), and PLAN section 4 makes Echevarne's printed interval the reference interval. The production floor 35 g/L is the cohort definition of hypoalbuminaemia and is kept as an action limit (repeat in 2 to 4 weeks with CRP, doctor in the next few weeks), supported by grade B records from the same cohort: F01-E10 defines hypoalbuminaemia as serum albumin of 35 g/L or less, and F01-E11 reports it associated with total mortality at ages 65 and over (HR 1.83, 1.33-2.50). Physician question PQ-2.",
  ["F01-E10", "F01-E11"], [L("D5--albumin.both.All_Adults.bounds--none")]);
ch(ALB, "optimal_low", 42, 41, "loosen",
  "Optimal floor 42 -> 41 g/L. 42 had no source (September rounding). Grade B quotes: Moli-sani (F01-E01, F01-E02: linear rise in mortality below the reference value of 41 g/L) and J-MICC (F01-E03, F01-E04: below 4.1 g/dL HR 1.69, 1.50-1.91, against 4.1-5.1 g/dL). Band rule: lowest-risk category. Physician question PQ-1 and F01-VQ-1.",
  ["F01-E01", "F01-E02", "F01-E03", "F01-E04"], [L("D5--albumin.both.All_Adults.bounds--none")]);
ch(ALB, "optimal_high", 48, null, "loosen",
  "Optimal ceiling 48 g/L removed. It equalled the reference ceiling, so the reference top still caps the band and no value changes zone. Grade B quotes show no upper optimum inside the interval: the J-MICC lowest-risk category runs to 5.1 g/dL (F01-E03, F01-E04), above the 48 g/L ceiling. Values above 48 g/L stay out of range (above_range).",
  ["F01-E03", "F01-E04"], [L("D5--albumin.both.All_Adults.bounds--none")]);
ch(TP, "optimal_low", 65, null, "loosen",
  "Production optimal floor 65 g/L removed: total protein is class e (marker-classes.json draft; PLAN section 4) and the band was derived from the component bands, not from total-protein outcome evidence. Grade B quote F01-E31 (J-MICC, 35,746 adults, 11.8 years): total protein below 6.6 g/dL had no significant excess after full adjustment (HR 1.12, 0.94-1.36) against 6.6-8.1 g/dL, so no evidence that 57-65 g/L carries more risk.",
  ["F01-E31"], [L("D5--total_protein.both.All_Adults.bounds--none")]);
ch(TP, "optimal_high", 80, null, "loosen",
  "Production optimal ceiling 80 g/L removed with the class e band. Grade B quote F01-E31 (J-MICC): excess mortality only above 8.1 g/dL (HR 1.39, 1.10-1.76, in the first model; 1.33, 1.05-1.68, in the fully adjusted model), which sits at Echevarne's reference ceiling of 82 g/L, so the in-range zone up to 82 g/L is within 1 g/L of the outcome threshold.",
  ["F01-E31"], [L("D5--total_protein.both.All_Adults.bounds--none")]);
ch(GL, "optimal_low", 2.2, null, "loosen",
  "Production optimal floor 2.2 g/dL removed: PLAN section 4 names globulin as class e (reference only, no optimal band). No cohort opened shows excess risk between 1.9 and 2.2 g/dL. Grade B record F01-E38 (J-MICC) concerns the upper side only.",
  ["F01-E38", "F01-E35"], [L("D5--globulin.both.All_Adults.bounds--none")]);
ch(GL, "optimal_high", 3.0, null, "loosen",
  "Production optimal ceiling 3.0 g/dL removed because PLAN section 4 names globulin as class e. This removal follows the definition, not the outcome evidence: the grade B record F01-E38 (J-MICC) reports a threshold-type rise in mortality above the gamma-gap standard of 3.0, and F01-E35 a gradual rise above 3.2 g/dL with roughly double risk above 4.0. The above-range message keeps the electrophoresis follow-up at 4.0 g/dL. Whether globulin should be class a with an upper optimal bound is put to the physician (F01-DQ-6).",
  ["F01-E38", "F01-E35"], [L("D5--globulin.both.All_Adults.bounds--none")]);

// ── 5. Evidence records (new) ──
const evidence = [
  {
    id: "F01-F01",
    supports: [{ row_key: AG, bound: "reference_low" }, { row_key: AG, bound: "reference_high" }],
    identifier: { type: "pmid", value: "38722987" },
    citation: "Establishment of dry-chemistry-based reference intervals of routine liver function tests for the adult population of Gandaki Province, Nepal. 2024. PMCID PMC11081272.",
    year: 2024,
    quote: "albumin: 39.0-52.0g/L; globulin: 27.0-42.0g/L; A/G ratio: 1.1-1.8",
    location: "abstract",
    design: "cross-sectional reference-interval study, direct a priori selection, non-parametric 95% double-sided intervals",
    n: null,
    follow_up_years: 0,
    outcome: "reference interval (2.5th to 97.5th percentile) of the calculated albumin/globulin ratio in apparently healthy adults",
    population_age: "adults (age range not stated in the abstract)",
    population_sex: "both",
    assay: "dry chemistry (platform not named in the abstract); globulin and A/G ratio calculated from total protein and albumin",
    band_rule: "none",
    basis_class: "laboratory_interval",
    proposed_grade: "C",
    age_stratified_statement: "No age-stratified intervals in the abstract; the abstract reports sex differences for albumin, globulin and the A/G ratio without giving the sex-specific limits.",
    notes: "Corroborates the width of Echevarne's printed ratio interval (0.99-1.81) for the calculated measurand that EVA receives from uploaded reports. Not used as the reference interval itself (PLAN section 5: reference limits are Echevarne's interval). Sample size not in the abstract.",
  },
  {
    id: "F01-F02",
    supports: [{ row_key: AG, bound: "reference_low" }, { row_key: AG, bound: "reference_high" }, { row_key: AG, bound: "method" }],
    identifier: { type: "pmid", value: "36039308" },
    citation: "Bikila D, Lejisa T, Tolcha Y, et al. Establishment of Reference Intervals for Serum Protein Electrophoresis of Apparently Healthy Adults in Addis Ababa, Ethiopia. Int J Gen Med 2022. PMCID PMC9419900.",
    year: 2022,
    quote: "Moreover, the albumin to globulin ratios were 1.16-1.8 and 1.09-1.74 for males and females, respectively.",
    location: "abstract, results",
    design: "cross-sectional reference-interval study, CLSI EP28-A3c non-parametric method",
    n: 297,
    follow_up_years: 0,
    outcome: "reference interval of the electrophoretic albumin/globulin ratio in apparently healthy adults",
    population_age: "apparently healthy adults (age range not stated in the abstract)",
    population_sex: "both",
    assay: "capillary zone electrophoresis, Capillarys 2 Flex Piercing analyser (the same technique as Echevarne's B2060 proteinogram, 'Electroforesis Capilar')",
    band_rule: "none",
    basis_class: "laboratory_interval",
    proposed_grade: "C",
    age_stratified_statement: "No age-stratified intervals; partitioned by sex (men 1.16-1.8, women 1.09-1.74), a difference under 0.1.",
    notes: "Same measurand and technique as Echevarne's B0288; supports that 0.99-1.81 is a plausible healthy-adult interval and that 2.5 is far above it.",
  },
];

// ── 6. Physician questions ──
const physician_questions = [
  ...clone(verify.physician_questions),
  {
    id: "F01-DQ-1",
    row_key: ALB,
    question: "Albumin above the reference ceiling (48 g/L) lowers the version 3 biological age: X1 finds the age up to 1.4866 years lower (base tier) and 1.4117 years lower (plus-HbA1c tier) between 48.05 and 60 g/L than at 48 g/L, in both sexes, while the zone classifier calls these values out of range. Version 3 is frozen. Which resolution do you sign? (a) recommended: a refusal or provisional rule in the version 3 adapter that withholds the biological age when albumin is above the Echevarne ceiling, as check B2 already does for creatinine above its interval, with the copy 'Your albumin is above the laboratory interval, usually because the blood was concentrated; repeat it well hydrated before we calculate your biological age'; (b) accept this segment as one of the at most two X1 exceptions, with the magnitude stated in the pack.",
    why: "Confirmed blocking issue X1 (judges J1, J2, J3, J5). The fix is not in the range rows: removing the 48 g/L ceiling would contradict Echevarne's printed interval (PLAN section 4) and would be a loosening without outcome evidence. Share of healthy adults affected (NHANES 2015-2018 healthy adults, bromocresol purple, docs/signoff/work/nhanes/distributions.json, non-outcome split): above 48 g/L in 10.47% of men 20-39, 3.02% of men 40-59, 0.34% of men 70-79, 2.39% of women 20-39; with the bromocresol green offset of +3.54 g/L used in that file (its source, PMID 29790973, was not opened in this task) the share in men 20-39 becomes 51.39%. So the size of the problem depends on Echevarne's dye (methods letter L4). Exceptions live in docs/signoff/work/v3/consistency-exceptions.json and are accepted by judge J3; this decision file cannot write them.",
    evidence_ids: ["F01-E26", "F01-E27"],
    options: ["Refusal or provisional biological age when albumin is above 48 g/L (recommended)", "Accept as one of the two X1 exceptions, with the magnitude and the share stated", "Defer until Echevarne states its albumin dye"],
  },
  {
    id: "F01-DQ-2",
    row_key: ALB,
    question: "N1 population check on Echevarne's albumin interval 32-48 g/L (one General band, ages 0-999): healthy NHANES men aged 20-39 fall outside it in 17.5% (rule 2% to 15%), women aged 70-79 in 1.8% and men aged 70-79 in 0.0% (rule at least 2%). Do you accept the interval with this justification: 'Echevarne's printed interval is binding under PLAN section 4; NHANES measures albumin by bromocresol purple, which reads about 6 g/L lower than bromocresol green, and with the offset of +3.54 g/L used in EVA's NHANES distributions file the share above 48 g/L in men aged 20-39 rises from 10.47% to 51.39%, so the shares cannot be judged until Echevarne states its dye'? Or do you ask Echevarne for a sex-partitioned interval through the methods letter?",
    why: "Open N1 script issues for albumin male 20-39, female 70-79 and male 70-79. N1 accepts a written justification in docs/signoff/work/nhanes/n1-resolutions.json (kind 'justification'), which this decision file cannot write; the text above is offered for the keys 'albumin|male|20-39|reference_outside', 'albumin|female|70-79|reference_outside' and 'albumin|male|70-79|reference_outside'. Shares from the N1 failures in docs/signoff/work/checks/f01_albumin_proteins-r1.json and from docs/signoff/work/nhanes/distributions.json.",
    evidence_ids: ["F01-E26", "F01-E27"],
    options: ["Accept the interval with the justification (recommended until the dye is known)", "Ask Echevarne for its dye and a sex-partitioned interval before signing"],
  },
  {
    id: "F01-DQ-3",
    row_key: TP,
    question: "Total protein = albumin + globulin. With Echevarne's three printed intervals (albumin 32-48 g/L, globulin 19-40 g/L, total protein 57-82 g/L), a person with albumin in its optimal band and globulin inside its interval can have total protein above 82 g/L (for example 46.6 + 38.8 = 85.4 g/L), and albumin below optimal with globulin below range can sum to an in-range total protein. Which rule do you sign? (a) recommended: when an uploaded report carries albumin and globulin, total protein is shown as a value with the laboratory interval but without its own out-of-range zone or message unless albumin or globulin is also out of range, and the client reads the components; (b) keep the three zones independent and record the disagreement as an accepted reason; (c) narrow the globulin ceiling to 34 g/L (82 minus 48), which no laboratory prints and which this decision does not propose.",
    why: "Confirmed blocking issue K1 (judge J1) and the open K1 script patterns for total protein. Percentile reference intervals of a sum are not the sum of the components' intervals; Echevarne's own proteinogram is equally inconsistent (electrophoretic albumin 36-54 g/L plus globulins 19-40 g/L, catalogue lines 334-335, against total protein 57-82 g/L). K1 allows no opposite-category pair, so option (b) cannot pass K1, and option (c) would invent a reference interval (PLAN section 4). Option (a) is an app rule outside this file.",
    evidence_ids: ["F01-E31", "F01-F02"],
    options: ["Total protein without its own zone when the components are reported (recommended)", "Independent zones with an accepted reason", "Globulin ceiling 34 g/L (not recommended: not a printed interval)"],
  },
  {
    id: "F01-DQ-4",
    row_key: AG,
    question: "The albumin/globulin ratio now uses Echevarne's printed interval 0.99-1.81 (B0288). Because it is a ratio of two separately printed intervals, a person with albumin inside its optimal band and globulin in the lower part of its interval reads above range (for example 42.2 g/L over 19.6 g/L = 2.16), and K1 will report this as an opposite pair. Do you sign (a) recommended: the ratio is shown as a value with the laboratory interval but without its own zone or message when albumin and globulin are on the same report, since it adds no information beyond them; (b) the uploading laboratory's own printed interval replaces Echevarne's for uploaded ratios; or (c) independent zones with an accepted reason?",
    why: "Resolves the mislabelled interval of the confirmed K1 issue (judge J2: 0.8-2.5 was a quotient of extremes labelled as Echevarne's), and states the coherence cost of the printed interval openly. Healthy-adult studies give 1.09-1.8 (F01-F02, capillary electrophoresis) and 1.1-1.8 (F01-F01, calculated ratio), so 0.99-1.81 is not an outlier interval.",
    evidence_ids: ["F01-F01", "F01-F02", "F01-E43"],
    options: ["Ratio as a value only when the components are reported (recommended)", "Uploading laboratory's interval", "Independent zones with an accepted reason"],
  },
  {
    id: "F01-DQ-5",
    row_key: null,
    question: "The albumin and total-protein pregnancy and lactation rows are removed: they copied the laboratory interval and were unreachable because the app's picker reads no pregnancy or lactation field. Do you confirm that pregnancy and lactation are handled by the single app-level rule of state-rules.md 2.1 for every marker (laboratory interval only, no optimal category, no score, no biological age, the fixed note, critical limits still active), and that the range pages are not released for pregnant or lactating clients until that rule passes the C2 fixtures and the Q1 pregnancy personas?",
    why: "Confirmed blocking issues C1 (judge J2) and C2 (judge J5) remain open at app level: until the rule is implemented, a pregnant client is classified on the general albumin row (optimal floor 41 g/L, scored) and the third-trimester persona's albumin of 31 g/L reads below range. Albumin falls in normal pregnancy (F01-E19, F01-E15), so the optimal category must not be shown then. The fix is in src/lib/biomarkers/reference-row.ts or an app-level gate, outside this decision file.",
    evidence_ids: ["F01-E15", "F01-E19"],
    options: ["Confirm the single app-level rule and the release block (recommended)", "Ask for trimester-specific rows, which needs a gestational-week field the app does not record"],
  },
  {
    id: "F01-DQ-6",
    row_key: GL,
    question: "Globulin and the albumin/globulin ratio carry no optimal band because the plan classes them as reference-only (class e). Grade B cohort evidence points the other way: J-MICC reports a threshold-type rise in mortality with globulin (gamma gap) above 3.0 g/dL (F01-E38), an insurance cohort a gradual rise above 3.2 g/dL with roughly double risk above 4.0 (F01-E35), and 26,974 healthy Korean adults higher mortality with a ratio below 1.1 against 1.5 or more (F01-E39). Do you keep both as class e (recommended by the plan's redundancy rule, since albumin carries the modifiable signal), or reclassify one of them as class a with an outcome bound?",
    why: "The production optimal bands (globulin 2.2-3.0 g/dL, ratio 1.4-2.5) are removed in this decision by the class definition, not because the evidence shows no risk. The physician should sign that trade-off knowingly.",
    evidence_ids: ["F01-E38", "F01-E35", "F01-E39", "F01-E42"],
    options: ["Keep class e for both (recommended)", "Globulin class a with an upper optimal bound near 3.0-3.2 g/dL", "Ratio class a with a floor near 1.4"],
  },
];

const issues_addressed = [...new Set(changes.flatMap((c) => c.issue_ids || []))].sort();

const notes = [
  "Round 2 fixer decision for f01_albumin_proteins, written 2026-11-07 from verify file sha256 " + VSHA + ". AI work product for physician review.",
  "Resolved here: the four pregnancy and lactation rows are removed (C1, D2, D3, D5 row_only_in_seed and their M2 message issues); the Spanish repeat sentences and the missing benign causes are fixed on the general rows (M2); the albumin/globulin ratio now carries Echevarne's printed interval 0.99-1.81 instead of the mislabelled quotient 0.8-2.5 (K1, judge J2); every bound that differs from production is recorded as a change with its reason and evidence (D5 bounds issues for albumin, total protein, globulin and the ratio). D5's script compares the seed with production only, so it will keep listing these documented differences until the migration is applied.",
  "Not resolvable in this file, left open with physician questions: X1 albumin above 48 g/L (refusal rule in the version 3 adapter or a J3-accepted exception; F01-DQ-1); K1 total protein = albumin + globulin opposite pair (app rule; F01-DQ-3); K1 ratio coherence under the printed interval, which now shows albumin optimal plus low-normal globulin as ratio above range (F01-DQ-4); C1 (J2) and C2 (J5) pregnancy behaviour, which needs the app-level state rule (F01-DQ-5); N1 albumin shares, whose justification text is in F01-DQ-2 for docs/signoff/work/nhanes/n1-resolutions.json.",
  "Harness findings for the orchestrator: (1) L1 'table|albumin: no entry in critical-limits.json' is a reader mismatch, not a missing entry: docs/signoff/work/governance/critical-limits.json has an albumin entry (line 543) under the field 'key', while scripts/signoff/checks/limits.ts line 121 indexes entries by 'marker_key'. (2) The M2 Spanish confirm_repeat pattern (scripts/signoff/checks/messages.ts line 98) does not match the imperative 'Repite', which the wording rules use in every family. (3) D5 confirmed (J1) and G6 confirmed (J2, J3): docs/signoff/tools/lib/compile-sources.js line 53 copies summary_en, summary_es, caveats_en and caveats_es from the production entry, so the compiled biomarker-sources.json keeps the old numbers (albumin 42 and 35-48 g/L, ratio 1.4 and 1.0-2.5, globulin 2.2-3.0 g/dL, total protein 65-80 g/L). A decision file cannot set those fields. Proposed replacements for the compile to use or for the pack: albumin EN 'Reference interval 32-48 g/L (Echevarne). Optimal 41 g/L and above, up to the reference ceiling; below 35 g/L carries a repeat-and-review action limit.' ES 'Intervalo de referencia 32-48 g/L (Echevarne). Óptimo desde 41 g/L hasta el límite superior del intervalo; por debajo de 35 g/L, límite de acción con repetición y revisión.' Total protein EN 'Reference interval 57-82 g/L (Echevarne); reference only, no optimal band.' ES 'Intervalo de referencia 57-82 g/L (Echevarne); solo referencia, sin banda óptima.' Globulin EN 'Reference interval 1.9-4.0 g/dL (Echevarne B0278, 19-40 g/L); reference only, no optimal band; below 1.8 g/dL carries an immunoglobulin follow-up.' ES 'Intervalo de referencia 1,9-4,0 g/dL (Echevarne B0278, 19-40 g/L); solo referencia, sin banda óptima; por debajo de 1,8 g/dL, seguimiento con inmunoglobulinas.' Ratio EN 'Reference interval 0.99-1.81 (Echevarne B0288); reference only, no optimal band.' ES 'Intervalo de referencia 0,99-1,81 (Echevarne B0288); solo referencia, sin banda óptima.' (4) E2 marks every f01 source 'not in cache (offline)'; the two new records (PMID 38722987, PMID 36039308) also need caching.",
  "Disputed issues (C3, N1 J1) are left as they are. Searches: 0 WebSearch calls; two Europe PMC REST queries.",
].join("\n\n");

const doc = {
  schema_version: "1",
  family: "f01_albumin_proteins",
  round: 2,
  decided_at: "2026-11-07",
  verify_sha256: VSHA,
  fixer_role: "physician fixer (AI work product for physician review)",
  final_rows: rows,
  changes,
  issues_addressed,
  evidence,
  physician_questions,
  notes,
};
const out = path.join(W, "decisions/f01_albumin_proteins.json");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(doc, null, 2) + "\n");
console.log(out, rows.length, "rows", changes.length, "changes", issues_addressed.length, "issues");
