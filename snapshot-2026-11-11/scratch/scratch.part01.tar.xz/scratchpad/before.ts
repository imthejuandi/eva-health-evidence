import fs from "node:fs";
import { probe } from "/home/user/eva-health/scripts/signoff/checks/bioage";
const dir = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad";
const fx = JSON.parse(fs.readFileSync(`${dir}/fixtures.json`, "utf8"));
for (const f of fx) {
  const r = probe(f.input);
  f.before = r.ba == null ? `no result (${r.reason})` : `ba ${r.ba.toFixed(2)}${r.provisional ? " provisional" : ""}`;
  console.log(f.id.padEnd(40), f.before);
}
fs.writeFileSync(`${dir}/fixtures-before.json`, JSON.stringify(fx, null, 2));
