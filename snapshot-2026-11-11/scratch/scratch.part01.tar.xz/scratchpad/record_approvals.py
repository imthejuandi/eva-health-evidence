#!/usr/bin/env python3
"""Record the CEO's approvals of frozen-file changes exactly as Fable 5.2 recommended them.

Usage:
  python3 record_approvals.py <repo> <date> synthesis
      every file the synthesis (governance/fable-approval-review.json) rules approve with action approve_current, at its
      listed sha256, which must equal the file's current sha256 and that of the commit recorded;
  python3 record_approvals.py <repo> <date> rereview <rereview.json> <review_file>
      every file the re-review's final verdict approves, at the sha256 it reviewed.
Entries already present for the same file and sha256 are kept; an entry of a file at another sha256 is kept too (G1
matches the current sha256 only). Prints what it recorded and what it refused.
"""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

repo, date, mode = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
gov = repo / "docs/signoff/work/governance"
out_file = gov / "approved-changes.json"
approved = json.loads(out_file.read_text()) if out_file.exists() else []
pending = {p["file"]: p for p in json.loads((gov / "pending-approvals.json").read_text())["files"]}


def sha(path):
    return hashlib.sha256((repo / path).read_bytes()).hexdigest()


def commit_holding(path, digest):
    """The latest commit on HEAD whose version of path has this sha256."""
    log = subprocess.run(["git", "-C", str(repo), "log", "--format=%H", "--", path], capture_output=True, text=True, check=True).stdout.split()
    for c in log:
        body = subprocess.run(["git", "-C", str(repo), "show", f"{c}:{path}"], capture_output=True).stdout
        if hashlib.sha256(body).hexdigest() == digest:
            return c
    return None


wanted = []
if mode == "synthesis":
    syn = json.loads((gov / "fable-approval-review.json").read_text())["result"]
    for f in syn["files"]:
        if f["verdict"] == "approve" and f["action"] == "approve_current":
            wanted.append({"file": f["file"], "sha256": f["sha256"], "basis": "synthesis", "review_file": "docs/signoff/work/governance/fable-approval-review.json"})
elif mode == "rereview":
    rr, review_file = json.loads(Path(sys.argv[4]).read_text()), sys.argv[5]
    for f in rr["files"]:
        if f["verdict"] == "approve":
            wanted.append({"file": f["file"], "sha256": f["sha256"], "basis": "rereview", "review_file": review_file})
else:
    sys.exit(f"unknown mode {mode}")

recorded, refused = [], []
for w in wanted:
    cur = sha(w["file"]) if (repo / w["file"]).exists() else None
    if cur != w["sha256"]:
        refused.append(f"{w['file']}: recommended at {w['sha256'][:12]}, current {str(cur)[:12]}")
        continue
    c = commit_holding(w["file"], w["sha256"])
    if not c:
        refused.append(f"{w['file']}: no commit holds sha256 {w['sha256'][:12]} (commit the file first)")
        continue
    if any(a["file"] == w["file"] and a["sha256"] == w["sha256"] for a in approved):
        continue
    p = pending.get(w["file"], {})
    approved.append({
        "file": w["file"],
        "sha256": w["sha256"],
        "commit": c,
        "approved_by": "CEO",
        "approved_on": date,
        "basis": "Fable 5.2's recommendation, adopted by the CEO as the approval (instruction of 9 November 2026)",
        "review_file": w["review_file"],
        "area": p.get("area"),
        "kind": p.get("kind"),
    })
    recorded.append(w["file"])

approved.sort(key=lambda a: (a["file"], a["approved_on"], a["sha256"]))
out_file.write_text(json.dumps(approved, indent=2) + "\n")
print(json.dumps({"recorded": recorded, "refused": refused, "total_entries": len(approved)}, indent=1))
