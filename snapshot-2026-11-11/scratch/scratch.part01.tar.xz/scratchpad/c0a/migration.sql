-- ============================================================================
-- Sign-off ranges: forward migration (signoff_ranges)
-- Built by docs/signoff/tools/compile.js from the sign-off decisions (docs/signoff/work/decisions/, else the
-- verify final_rows, else the research rows, else today's seed rows; per family in compile-report.json).
-- Baseline: docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json (200 rows) plus the changes applied after it (20260925010000_gate1_thresholds_1, 20260925010100_gate1_thresholds_2; 20260925011000_ai_prompt_zone_guard; 20260925012000_nlr_row; 20260925012100_nlr_name_en; 20260925013000_in_range_messages_1, 20260925013100_in_range_messages_2, 20260925013200_in_range_messages_3): 203 rows.
-- NOT APPLIED. Not a file in supabase/migrations. Apply only after the physician has signed and the CEO approves.
-- Rows upserted: 1 (new 0) · rows deleted: 0 · field changes: 1
-- ============================================================================

-- 1. Sign-off columns
alter table public.biomarker_references
  add column if not exists critical_low numeric,
  add column if not exists critical_high numeric,
  add column if not exists critical_none_reason text,
  add column if not exists marker_class text,
  add column if not exists reference_basis text,
  add column if not exists reference_source text,
  add column if not exists physiological_state text,
  add column if not exists method_note text,
  add column if not exists explanatory_numbers numeric[];

-- 2. Changed and new rows (every column, keyed by biomarker_key, sex, age_group_en)
-- upsert: 1 row(s)
insert into public.biomarker_references (biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category, is_base_panel, is_genetic, clinical_notes_en, clinical_notes_es, msg_critical_low_en, msg_critical_low_es, msg_below_optimal_en, msg_below_optimal_es, msg_optimal_en, msg_optimal_es, msg_above_optimal_en, msg_above_optimal_es, msg_critical_high_en, msg_critical_high_es, critical_low, critical_high, critical_none_reason, marker_class, reference_basis, reference_source, physiological_state, method_note, explanatory_numbers)
values
  ('vitamin_b12', 'Vitamin B12', 'Vitamina B12', 'pg/mL', 'pg/mL', 'both', 'All Adults', 'Todos los Adultos', 211, 911, 400, 800, false, 'nutrients', false, false, 'A vitamin essential for nerve function, DNA synthesis and red blood cell formation. Because the body stores it, deficiency develops slowly but can cause lasting nerve damage if missed.', 'Una vitamina esencial para la función nerviosa, la síntesis de ADN y la formación de glóbulos rojos. Como el cuerpo la almacena, el déficit se desarrolla despacio, pero puede causar daño nervioso duradero si pasa inadvertido.', 'Vitamin B12 is below the reference range. Low B12 can cause megaloblastic anemia, neuropathy, fatigue and cognitive problems; discuss it with your doctor, who can look for a cause such as diet, malabsorption or pernicious anemia. A value far outside the range needs prompt medical attention.', 'La vitamina B12 está por debajo del intervalo de referencia. Una B12 baja puede causar anemia megaloblástica, neuropatía, fatiga y problemas cognitivos; coméntalo con tu médico, que puede buscar la causa, como la dieta, la malabsorción o la anemia perniciosa. Un valor muy alejado del intervalo requiere atención médica sin demora.', 'Vitamin B12 is below optimal. Even within the standard ''normal'' range, levels under 400 pg/mL are associated with subtle neurological symptoms and elevated homocysteine. Consider methylated B12 supplementation and confirm functional status with MMA.', 'La vitamina B12 está por debajo del óptimo. Incluso dentro del rango ''normal'' estándar, niveles bajo 400 pg/mL se asocian con síntomas neurológicos sutiles y homocisteína elevada. Considerar suplementación con B12 metilada y confirmar el estado funcional con MMA.', 'Vitamin B12 is in the optimal range, supporting nerve health, DNA synthesis, and red blood cell production. Homocysteine should track in the optimal range as well.', 'La vitamina B12 está en el rango óptimo, apoyando la salud nerviosa, la síntesis de ADN y la producción de glóbulos rojos. La homocisteína debería estar también en rango óptimo.', 'Vitamin B12 is above optimal. If you supplement, this is usually benign — methylcobalamin has no documented toxicity ceiling. If you don''t supplement, evaluate liver function and rule out hematologic conditions.', 'La vitamina B12 está por encima del óptimo. Si suplementas, esto suele ser benigno — la metilcobalamina no tiene techo de toxicidad documentado. Si no suplementas, evaluar función hepática y descartar condiciones hematológicas.', 'Vitamin B12 is above the reference range. It can reflect supplement use; without supplements, a high level can be associated with liver disease, kidney impairment or myeloproliferative (blood) disorders. Discuss it with your doctor.', 'La vitamina B12 está por encima del intervalo de referencia. Puede deberse a suplementos; si no los tomas, un nivel alto puede asociarse con enfermedad hepática, insuficiencia renal o trastornos mieloproliferativos (de la sangre). Coméntalo con tu médico.', null, null, null, null, null, null, null, null, null)
on conflict (biomarker_key, sex, age_group_en) do update set
  name_en = excluded.name_en,
  name_es = excluded.name_es,
  unit_en = excluded.unit_en,
  unit_es = excluded.unit_es,
  age_group_es = excluded.age_group_es,
  normal_low = excluded.normal_low,
  normal_high = excluded.normal_high,
  optimal_low = excluded.optimal_low,
  optimal_high = excluded.optimal_high,
  tested_2x_year = excluded.tested_2x_year,
  panel_category = excluded.panel_category,
  is_base_panel = excluded.is_base_panel,
  is_genetic = excluded.is_genetic,
  clinical_notes_en = excluded.clinical_notes_en,
  clinical_notes_es = excluded.clinical_notes_es,
  msg_critical_low_en = excluded.msg_critical_low_en,
  msg_critical_low_es = excluded.msg_critical_low_es,
  msg_below_optimal_en = excluded.msg_below_optimal_en,
  msg_below_optimal_es = excluded.msg_below_optimal_es,
  msg_optimal_en = excluded.msg_optimal_en,
  msg_optimal_es = excluded.msg_optimal_es,
  msg_above_optimal_en = excluded.msg_above_optimal_en,
  msg_above_optimal_es = excluded.msg_above_optimal_es,
  msg_critical_high_en = excluded.msg_critical_high_en,
  msg_critical_high_es = excluded.msg_critical_high_es,
  critical_low = excluded.critical_low,
  critical_high = excluded.critical_high,
  critical_none_reason = excluded.critical_none_reason,
  marker_class = excluded.marker_class,
  reference_basis = excluded.reference_basis,
  reference_source = excluded.reference_source,
  physiological_state = excluded.physiological_state,
  method_note = excluded.method_note,
  explanatory_numbers = excluded.explanatory_numbers;

-- 3. Rows retired by a decision
-- delete: none
