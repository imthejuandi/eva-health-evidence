# Sign-off compile: changes against production

Baseline: `docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json` (200 rows) plus the changes applied after it, 203 rows:

- 20260925010000_gate1_thresholds_1, 20260925010100_gate1_thresholds_2: docs/biomarker-evidence/longevity/gate1/changes.json, 71 field changes
- 20260925011000_ai_prompt_zone_guard: nothing to apply (ai_prompts only), 0 field changes
- 20260925012000_nlr_row: docs/biomarker-evidence/longevity/gate1/changes-nlr.json, 2 field changes
- 20260925012100_nlr_name_en: parsed supabase/migrations/20260925012100_nlr_name_en.sql, 2 field changes
- 20260925013000_in_range_messages_1, 20260925013100_in_range_messages_2, 20260925013200_in_range_messages_3: docs/biomarker-evidence/longevity/gate1/changes-inrange.json, 66 field changes

Seed rows 173 → 173. Field changes 1 on 1 rows (added 0, removed 0); tighten 0, loosen 0, neutral 1; without a reason 1. Production rows kept that are not in the compiled seed: 34.

## Families

| Family | Source | Rows compiled | Rows changed | Warnings |
|---|---|---|---|---|
| f01_albumin_proteins | seed | 4 | 0 | 0 |
| f02_liver_enzymes | seed | 8 | 0 | 0 |
| f03_kidney | seed | 8 | 0 | 1 |
| f04_inflammation | seed | 2 | 0 | 1 |
| f05_glycaemia | seed | 5 | 0 | 0 |
| f06_lipids_core | seed | 7 | 0 | 0 |
| f07_apolipoproteins | seed | 2 | 0 | 2 |
| f08_uric_acid_metabolic | seed | 4 | 0 | 1 |
| f09_red_cells | seed | 6 | 0 | 0 |
| f10_red_cell_indices | seed | 4 | 0 | 0 |
| f11_platelets | seed | 2 | 0 | 0 |
| f12_white_cells_core | seed | 9 | 0 | 0 |
| f13_white_cells_other | seed | 6 | 0 | 0 |
| f14_iron | seed | 7 | 0 | 0 |
| f15_thyroid | seed | 7 | 0 | 0 |
| f16_bone_mineral | seed | 3 | 0 | 1 |
| f17_b_vitamins | seed | 3 | 1 | 2 |
| f18_electrolytes | seed | 4 | 0 | 0 |
| f19_male_hormones | seed | 13 | 0 | 0 |
| f20_female_hormones | seed | 23 | 0 | 1 |
| f21_adrenal_growth | seed | 11 | 0 | 1 |
| f22_prostate | seed | 5 | 0 | 0 |
| f23_omega3 | seed | 4 | 0 | 0 |
| f24_omega6_ratios | seed | 5 | 0 | 0 |
| f25_trace_minerals | seed | 1 | 0 | 3 |
| f26_other_vitamins | seed | 0 | 0 | 6 |
| f27_lipoprotein_subfractions | seed | 6 | 0 | 0 |
| f28_autoimmunity | seed | 4 | 0 | 0 |
| f29_cardiac_toxins | seed | 2 | 0 | 1 |
| f30_urine_pancreas_bilirubin | seed | 6 | 0 | 0 |

## f17_b_vitamins

| Row | Field | From | To | Direction | Evidence | Reason |
|---|---|---|---|---|---|---|
| vitamin_b12|both|All Adults | name_es | Vitamina B12 (Cobalamina) | Vitamina B12 | neutral | – | **unexplained** |

## Production rows not in the compiled seed (kept; not touched by the migration)

- adiponectin|female|All Adults (f08_uric_acid_metabolic): production-only marker; not in the seed and not retired by a decision
- adiponectin|male|All Adults (f08_uric_acid_metabolic): production-only marker; not in the seed and not retired by a decision
- apoe_genotype|both|All Adults (f07_apolipoproteins): production-only marker; not in the seed and not retired by a decision
- apolipoprotein_a1_apoa1|female|All Adults (f07_apolipoproteins): production-only marker; not in the seed and not retired by a decision
- apolipoprotein_a1_apoa1|male|All Adults (f07_apolipoproteins): production-only marker; not in the seed and not retired by a decision
- copper_serum|female|All Adults (f25_trace_minerals): production-only marker; not in the seed and not retired by a decision
- copper_serum|male|All Adults (f25_trace_minerals): production-only marker; not in the seed and not retired by a decision
- cystatin_c|both|All Adults (f03_kidney): production-only marker; not in the seed and not retired by a decision
- fibrinogen|both|All Adults (f04_inflammation): production-only marker; not in the seed and not retired by a decision
- folate_vitamin_b9|both|All Adults (f17_b_vitamins): production-only marker; not in the seed and not retired by a decision
- holo_transcobalamin_active_b12|both|All Adults (f17_b_vitamins): production-only marker; not in the seed and not retired by a decision
- igf_1_insulin_like_growth_factor_1|both|18-29 (f21_adrenal_growth): production-only marker; not in the seed and not retired by a decision
- igf_1_insulin_like_growth_factor_1|both|30-39 (f21_adrenal_growth): production-only marker; not in the seed and not retired by a decision
- igf_1_insulin_like_growth_factor_1|both|40-49 (f21_adrenal_growth): production-only marker; not in the seed and not retired by a decision
- igf_1_insulin_like_growth_factor_1|both|50-59 (f21_adrenal_growth): production-only marker; not in the seed and not retired by a decision
- igf_1_insulin_like_growth_factor_1|both|60+ (f21_adrenal_growth): production-only marker; not in the seed and not retired by a decision
- iodine_urine|both|All Adults (f25_trace_minerals): production-only marker; not in the seed and not retired by a decision
- nt_probnp|both|18-49 (f29_cardiac_toxins): production-only marker; not in the seed and not retired by a decision
- nt_probnp|both|50-74 (f29_cardiac_toxins): production-only marker; not in the seed and not retired by a decision
- nt_probnp|both|75+ (f29_cardiac_toxins): production-only marker; not in the seed and not retired by a decision
- progesterone|female|On Hormone Therapy (f20_female_hormones): production-only marker; not in the seed and not retired by a decision
- progesterone|female|Postmenopausal (f20_female_hormones): production-only marker; not in the seed and not retired by a decision
- progesterone|female|Premenopausal (follicular) (f20_female_hormones): production-only marker; not in the seed and not retired by a decision
- progesterone|female|Premenopausal (luteal) (f20_female_hormones): production-only marker; not in the seed and not retired by a decision
- progesterone|female|Premenopausal (ovulatory) (f20_female_hormones): production-only marker; not in the seed and not retired by a decision
- progesterone|male|All Adults (f20_female_hormones): production-only marker; not in the seed and not retired by a decision
- pth_intact_parathyroid_hormone|both|All Adults (f16_bone_mineral): production-only marker; not in the seed and not retired by a decision
- selenium_serum|both|All Adults (f25_trace_minerals): production-only marker; not in the seed and not retired by a decision
- vitamin_a_retinol|both|All Adults (f26_other_vitamins): production-only marker; not in the seed and not retired by a decision
- vitamin_b1_thiamine|both|All Adults (f26_other_vitamins): production-only marker; not in the seed and not retired by a decision
- vitamin_b6_pyridoxal_5_phosphate|both|All Adults (f26_other_vitamins): production-only marker; not in the seed and not retired by a decision
- vitamin_c_ascorbic_acid|both|All Adults (f26_other_vitamins): production-only marker; not in the seed and not retired by a decision
- vitamin_e_alpha_tocopherol|both|All Adults (f26_other_vitamins): production-only marker; not in the seed and not retired by a decision
- vitamin_k1_phylloquinone|both|All Adults (f26_other_vitamins): production-only marker; not in the seed and not retired by a decision
