import json, sys
for path in sys.argv[1:]:
    d = json.load(open(path, encoding='utf-8'))
    bad = 0
    for i, e in enumerate(d['evidence']):
        if 'quote' in e and 'file' in e and 'line' in e:
            try:
                L = open('/home/user/eva-health/' + e['file'], encoding='utf-8').read().split('\n')[e['line'] - 1]
            except Exception as ex:
                print('  ERR', i, e['file'], ex); bad += 1; continue
            if e['quote'] not in L:
                print('  MISS', i, e['file'], e['line'], repr(e['quote'][:80])); bad += 1
        elif 'file' in e and 'line' in e:
            n = len(open('/home/user/eva-health/' + e['file'], encoding='utf-8').read().split('\n'))
            if e['line'] > n: print('  LINE OUT OF RANGE', i, e['file'], e['line']); bad += 1
    print(path.split('/')[-1], 'quote misses:', bad)
