import { classifyZone } from "/home/user/eva-health/src/lib/biomarkers/zone-classifier";
import { convertBiomarker } from "/home/user/eva-health/src/lib/biomarkers/unit-conversions";
import { ZONE_CONFIG } from "/home/user/eva-health/src/lib/biomarkers/zone-config";
// HbA1c compiled row: reference 4.3-5.6, optimal 4.5-5.4 (biomarker-ranges-en.json lines 2420-2423)
for (const mmol of [23, 24, 38, 39, 43]) {
  const c = convertBiomarker("hba1c", mmol, "mmol/mol", { normalHigh: 5.6, trustUnit: true });
  const z = classifyZone(c.value, 4.5, 5.4, 4.3, 5.6);
  console.log(`hba1c ${mmol} mmol/mol -> ${c.value.toFixed(4)} ${c.unit} -> zone ${z} (${ZONE_CONFIG[z].label})`);
}
for (const pct of [5.6, 5.65, 5.7, 4.3]) {
  const z = classifyZone(pct, 4.5, 5.4, 4.3, 5.6);
  console.log(`hba1c ${pct}% -> zone ${z} (${ZONE_CONFIG[z].label})`);
}
// Insulin compiled row: reference null-29.1, no optimal band (lines 2485-2488)
for (const ins of [15.6, 21.82, 28.2, 29.1, 29.2]) {
  const z = classifyZone(ins, null, null, null, 29.1);
  console.log(`insulin ${ins} -> zone ${z} (${ZONE_CONFIG[z].label} / ${ZONE_CONFIG[z].label_es}, tone ${ZONE_CONFIG[z].tone})`);
}
// HOMA-IR compiled row: reference 0-3.46, optimal up to 1.8 (lines 2516-2519); glucose 74-99, optimal 74-90 (lines 2385-2388)
for (const [g, i] of [[76.22, 21.82], [90, 15.6], [74, 18.9], [90, 15.5], [74, 18.94]] as [number, number][]) {
  const h = (g * i) / 405;
  console.log(`glucose ${g} (${classifyZone(g, 74, 90, 74, 99)}), insulin ${i} (${classifyZone(i, null, null, null, 29.1)}) -> HOMA-IR ${h.toFixed(4)} (${classifyZone(h, null, 1.8, 0, 3.46)})`);
}
console.log("3.46*405/90 =", (3.46 * 405 / 90).toFixed(3), "; 3.46*405/74 =", (3.46 * 405 / 74).toFixed(3));
