import { classifyZone, ZONE_CONFIG } from "/home/user/eva-health/src/lib/biomarkers/zone-classifier";
const cases: [string, number, number | null, number | null, number | null, number | null][] = [
  ["AST both All Adults (opt null/null, ref null-34), value 20", 20, null, null, null, 34],
  ["AST both All Adults, value 34", 34, null, null, null, 34],
  ["AST both All Adults, value 35", 35, null, null, null, 34],
  ["ALP male 18-18 (opt null/null, ref 55-149), value 100", 100, null, null, 55, 149],
  ["ALT female All Adults (opt 10-25, ref 10-49), value 12", 12, 10, 25, 10, 49],
];
for (const [label, v, oL, oH, nL, nH] of cases) {
  const z = classifyZone(v, oL, oH, nL, nH);
  console.log(`${label} -> zone=${z} label=${ZONE_CONFIG[z].label}/${ZONE_CONFIG[z].label_es} tone=${ZONE_CONFIG[z].tone}`);
}
