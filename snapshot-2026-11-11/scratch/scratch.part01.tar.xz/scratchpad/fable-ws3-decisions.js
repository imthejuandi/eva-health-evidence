export const meta = {
  name: 'fable-ws3-decisions',
  description: 'Fable 5.2 rules on workstream 3 decisions D-01 to D-27: three decision lenses, then one ruling recorded as the CEO decision',
  phases: [
    { title: 'Lenses', detail: 'three Fable 5.2 lenses (clinical safety, evidence and governance, product and release) each take every decision' },
    { title: 'Ruling', detail: 'one Fable 5.2 agent reconciles the lenses into one ruling per decision, checking disputed points in the repository' },
  ],
}

// args: { repo, scratch }
const A = args
const MODEL = 'claude-fable-5-2'
const EFFORT = 'max'
const REPO = A.repo
const SCR = A.scratch

const LENS = {
  type: 'object',
  properties: {
    lens: { type: 'string' },
    decisions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          choice: { type: 'string', description: 'the option number from ws3-decisions.md, or "amended" with the amendment in rule' },
          rule: { type: 'string', description: 'the exact rule the app and the files must follow, in one or two sentences' },
          rationale: { type: 'string' },
          evidence: { type: 'string', description: 'file:line references you checked' },
          physician_question: { type: 'string', description: 'what the physician must still confirm, or empty' },
          confidence: { type: 'string', enum: ['high', 'medium', 'low'] },
        },
        required: ['id', 'choice', 'rule', 'rationale', 'evidence', 'physician_question', 'confidence'],
      },
    },
    conflicts: { type: 'array', items: { type: 'string' }, description: 'pairs of decisions or packages that contradict each other under your choices' },
    missing_decisions: { type: 'array', items: { type: 'string' } },
  },
  required: ['lens', 'decisions', 'conflicts', 'missing_decisions'],
}
const RULING = {
  type: 'object',
  properties: {
    decisions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          choice: { type: 'string' },
          rule: { type: 'string' },
          plain_rationale: { type: 'string', description: 'two to four sentences a CEO without a coding background can follow' },
          package_changes: { type: 'string', description: 'what the affected work packages must do differently from the design, or "none"' },
          physician_question: { type: 'string' },
          lenses_agreed: { type: 'boolean' },
        },
        required: ['id', 'choice', 'rule', 'plain_rationale', 'package_changes', 'physician_question', 'lenses_agreed'],
      },
    },
    new_decisions: {
      type: 'array',
      items: { type: 'object', properties: { id: { type: 'string' }, question: { type: 'string' }, ruling: { type: 'string' }, plain_rationale: { type: 'string' } }, required: ['id', 'question', 'ruling', 'plain_rationale'] },
    },
    summary: { type: 'string' },
  },
  required: ['decisions', 'new_decisions', 'summary'],
}

const BACKGROUND = [
  'Background.',
  '- EVA is a preventive-health app. Before launch, a licensed physician will review and sign its optimal biomarker ranges, its biological age model (version 3) and its EVA score. The acceptance test is docs/signoff/ACCEPTANCE-TEST.md; the plan is docs/signoff/PLAN.md (section 4 definitions, section 5 evidence standard, section 10 decisions).',
  '- Workstream 3 makes the score consistent with the ranges and the biological age. Its read-only map and design are docs/signoff/work/ws3/design.json (README.md beside it lists work packages WS3-01 to WS3-26). Its 27 open decisions, each with options, a recommendation and the reasons, are docs/signoff/work/governance/ws3-decisions.md.',
  '- Governance drafts the decisions must agree with: docs/signoff/work/governance/state-rules.md, critical-limits.json and critical-limits.md, wording-rules.md, marker-classes.json, action-limits.json, base-panel.md, decision-register.md, hazard-log.md, change-control.md; earlier CEO decisions CEO-1 to CEO-17 in central-fix-decisions.md; known issues in docs/signoff/work/central/known-issues.md.',
  '- The CEO instructed that Fable 5.2 recommends on these decisions and that its recommendations serve as the approval. Your output therefore carries the CEO\'s authority on how the app and the files are built; the physician still signs every clinical number and text. The CEO\'s standing constraints: nothing is reprocessed, recalculated or backfilled and no migration is applied until the material is final; staging before production; no patient data is read.',
  `- Work in ${REPO}, read-only: do not modify, create or delete any file there and run no git command that changes state. Scratch files only under ${SCR}/ (mkdir -p). You may run the runner on the latest batch compile (\`npx tsx scripts/signoff/dsrt.ts --round 9 --only <ids> --seed-dir docs/signoff/work/compiled/B05-r2 --out ${SCR}/<file>.json\`) and the app's tests.`,
].join('\n')

const LENSES = [
  { key: 'clinical', text: 'Your lens: clinical safety and longevity medicine. Judge each decision by what a client sees and does: false reassurance, needless alarm, a missed critical value, a pregnant or breastfeeding client, an athlete or a creatine user, a client on hormone therapy, a capillary kit result. Prefer the option a careful longevity physician would sign; say what the physician must still confirm.' },
  { key: 'evidence', text: 'Your lens: evidence and governance. Judge each decision against the evidence standard (PLAN.md section 5), the acceptance test (no check may pass more easily than its specification allows), the governance drafts and the earlier CEO decisions. Flag any option that contradicts a governance text, invents a clinical number in code, or would let a check pass on a placeholder.' },
  { key: 'product', text: 'Your lens: product, engineering and release. Judge each decision by feasibility, release coupling (code that needs a migration not yet applied), reversibility, the CEO\'s no-reprocess constraint, English and Spanish parity, and what it costs to operate. Flag options that cannot ship safely in the order the design gives.' },
]

phase('Lenses')
const lenses = await parallel(LENSES.map((l) => () => agent([
  `You are a Fable 5.2 decision reviewer for EVA's workstream 3, lens "${l.key}".`, BACKGROUND, l.text,
  'For each decision D-01 to D-27 in ws3-decisions.md: choose an option (or amend one), state the exact rule, give your rationale and the file:line evidence you checked, the physician question if any, and your confidence. Check the design\'s claims in the repository before relying on them. Then list conflicts between decisions under your choices and decisions the design missed.',
  'Reply with the structured result.',
].join('\n\n'), { label: `lens ${l.key}`, phase: 'Lenses', schema: LENS, model: MODEL, effort: EFFORT })))
const got = lenses.filter(Boolean)
log(`lenses returned: ${got.map((x) => x.lens).join(', ')}${got.length < LENSES.length ? ` (missing ${LENSES.length - got.length})` : ''}`)

phase('Ruling')
const ruling = got.length ? await agent([
  'You are Fable 5.2, giving one ruling per workstream 3 decision for EVA\'s CEO. Three lenses reviewed the decisions; their results are below. Where they agree, adopt the choice unless your own check of the repository shows it is wrong. Where they disagree, check the disputed point yourself and rule. Your ruling is recorded verbatim as the CEO\'s decision on each D-xx.',
  BACKGROUND,
  `The lenses:\n${JSON.stringify(got, null, 1)}`,
  'Reply with the structured result: every decision D-01 to D-27 once, in order, plus any new decision the lenses found that the packages need.',
].join('\n\n'), { label: 'ruling', phase: 'Ruling', schema: RULING, model: MODEL, effort: EFFORT }) : null

return { lenses: got, ruling }
