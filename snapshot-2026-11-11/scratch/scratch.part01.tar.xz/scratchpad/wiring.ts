import { boundedWiring } from "/home/user/eva-health/.claude/worktrees/approval-fixes/scripts/signoff/checks/preanalytical";
for (const root of ["/home/user/eva-health/.claude/worktrees/approval-fixes", "/home/user/eva-health"]) console.log(root, JSON.stringify(boundedWiring(root).map((w) => `${w.file} ${w.rule}`), null, 1));
