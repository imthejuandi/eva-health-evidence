// Builds docs/signoff/work/checks/round-0-summary.md from round-0.json (deterministic).
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const root = process.argv[2];
const round = Number(process.argv[3] || 0);
const file = path.join(root, `docs/signoff/work/checks/round-${round}.json`);
const buf = fs.readFileSync(file);
const out = JSON.parse(buf.toString("utf8"));
const md = fs.readFileSync(path.join(root, "docs/signoff/ACCEPTANCE-TEST.md"), "utf8");

const meta = {};
let group = "";
let letter = "";
for (const line of md.split(/\r?\n/)) {
  const h = line.match(/^## ([A-Z])\. (.+)$/);
  if (h) { letter = h[1]; group = h[2].trim(); }
  const m = line.match(/^\| ([A-Z]\d+) \| (.+?) \| (.+?) \| (.+?) \|$/);
  if (m) meta[m[1]] = { letter, group, how: m[3].trim(), title: m[2].trim() };
}
const esc = (s) => String(s).replace(/\|/g, "\\|").replace(/\s*\n\s*/g, " ");
const cut = (s, n) => (s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s);
const shortTitle = (t) => cut(t.split(/\. /)[0], 70);

const L = [];
L.push(`# DSRT round ${round}: baseline`);
L.push("");
L.push(`The Doctor Sign-off Readiness Test (\`docs/signoff/ACCEPTANCE-TEST.md\`) run on today's data, before any workstream has changed a row. This is the baseline the physician programme starts from. A check that fails here fails because today's data or app fails it; no check was weakened to pass.`);
L.push("");
L.push(`- Results file: \`docs/signoff/work/checks/round-${round}.json\` (sha256 \`${crypto.createHash("sha256").update(buf).digest("hex")}\`), byte-identical across two runs (G3).`);
L.push(`- Commit: \`${out.git_commit}\`; ${Object.keys(out.inputs).length} input files hashed in the results file (\`inputs\`).`);
L.push(`- Seed: \`supabase/seed-data\`; work dir: \`docs/signoff/work\`. Compiled copy of today's seed: \`docs/signoff/work/compiled/round-${round}/\` (byte-identical across two runs).`);
L.push(`- Reproduce: \`npm run dsrt -- --round ${round}\` and \`node docs/signoff/tools/compile.js --out-dir docs/signoff/work/compiled/round-${round}\`.`);
L.push(`- Totals: **${out.counts.pass} pass, ${out.counts.fail} fail, ${out.counts.blocked} blocked** of ${out.results.length} checks. Blocked is never pass.`);
L.push("");
L.push("## Reading this baseline");
L.push("");
L.push("- The evidence checks (E1 to E4), traceability (G2) and the pack checks (G4 to G7) are blocked because workstream 1 has not yet written research, verify or decision files and the pack does not exist. They become pass or fail as the loop writes them.");
L.push("- Judge and audit checks (M5, E5, G7, G8) read the loop's result files and stay blocked until a round writes them.");
L.push("- D6 fails on the missing reconciliation set. `node docs/signoff/tools/compile.js --out-dir <dir> --reconciliation-dir docs/signoff/work/reconciliation` writes `diff.json`, `forward.sql` and `rollback.sql`; on today's seed the diff holds one unexplained change (`vitamin_b12|both|All Adults` `name_es`: production \"Vitamina B12 (Cobalamina)\", seed \"Vitamina B12\"). The reader-test result file has no producer yet.");
L.push("- L2 reads `docs/signoff/work/governance/action-limits.json`, which the governance work added while this baseline was being built; its entries are not complete yet, so L2 fails rather than blocks.");
L.push("- The critical-message findings in Q1 and S5 follow from L1: the app derives `critical_low`/`critical_high` from the reference limits (`src/lib/biomarkers/zone-classifier.ts` lines 86 and 87), so an LDL of 113 mg/dL shows as critical.");
L.push("- P3: `src/lib/biomarkers/process-results.ts` keeps a result's comparator (`<`, `>`) but classifies the bare number, so every bounded fixture is classified as if it were exact.");
L.push("");
L.push("## Every check");
L.push("");
L.push("| Id | Group | Check | How | Status | Failures | Summary |");
L.push("|---|---|---|---|---|---|---|");
for (const r of out.results) {
  const m = meta[r.id] || { group: "", how: "", title: "" };
  const summary = r.status === "blocked" && r.blocked_on && !r.summary.includes(r.blocked_on) ? `${r.summary} (blocked on ${r.blocked_on})` : r.summary;
  L.push(`| ${r.id} | ${esc(m.group)} | ${esc(shortTitle(m.title))} | ${esc(m.how)} | ${r.status} | ${r.status === "fail" ? r.failures.length : ""} | ${esc(summary)} |`);
}
L.push("");
L.push("## Counts by group");
L.push("");
L.push("| Group | Checks | Pass | Fail | Blocked | Failure records |");
L.push("|---|---|---|---|---|---|");
const groups = new Map();
for (const r of out.results) {
  const m = meta[r.id] || { letter: "?", group: "?" };
  const g = r.id === "G8" ? `${m.letter}. ${m.group}` : `${m.letter}. ${m.group}`;
  if (!groups.has(g)) groups.set(g, { checks: 0, pass: 0, fail: 0, blocked: 0, failures: 0 });
  const e = groups.get(g);
  e.checks++; e[r.status]++; if (r.status === "fail") e.failures += r.failures.length;
}
const tot = { checks: 0, pass: 0, fail: 0, blocked: 0, failures: 0 };
for (const [g, e] of groups) {
  L.push(`| ${esc(g)} | ${e.checks} | ${e.pass} | ${e.fail} | ${e.blocked} | ${e.failures} |`);
  for (const k of Object.keys(tot)) tot[k] += e[k];
}
L.push(`| **Total** | ${tot.checks} | ${tot.pass} | ${tot.fail} | ${tot.blocked} | ${tot.failures} |`);
L.push("");
L.push("## What blocks the blocked checks");
L.push("");
L.push("| Id | Missing input |");
L.push("|---|---|");
for (const r of out.results.filter((x) => x.status === "blocked")) L.push(`| ${r.id} | ${esc(r.blocked_on || r.summary)} |`);
L.push("");
L.push("## Top failures");
L.push("");
L.push("Failing checks, most failure records first (ties by id); up to five failure keys each, in key order as the results file lists them. The full lists are in the results file.");
L.push("");
const fails = out.results.filter((x) => x.status === "fail").map((r, i) => ({ r, i })).sort((a, b) => b.r.failures.length - a.r.failures.length || a.i - b.i);
for (const { r } of fails) {
  const m = meta[r.id] || { title: "" };
  L.push(`### ${r.id} ${esc(shortTitle(m.title))}: ${r.failures.length} failures`);
  L.push("");
  L.push(esc(r.summary));
  L.push("");
  L.push("| Key | Detail |");
  L.push("|---|---|");
  for (const f of r.failures.slice(0, 5)) L.push(`| \`${esc(f.key)}\` | ${esc(cut(f.detail, 220))} |`);
  if (r.failures.length > 5) L.push(`| … | ${r.failures.length - 5} more |`);
  L.push("");
}
process.stdout.write(L.join("\n").replace(/\n+$/, "") + "\n");
