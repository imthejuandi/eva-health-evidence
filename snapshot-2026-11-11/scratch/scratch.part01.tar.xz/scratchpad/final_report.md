# Decision memo: which biological age model EVA should use

**Date:** 29 October 2026. **For:** the CEO.

**Basis:** three expert reviews, reconciled here:
- an epidemiologist and journal reviewer;
- EVA's head of product and laboratory operations;
- a clinical and regulatory adviser.

I re-checked the key facts today against the sources in section 7. Codes in brackets point there: [I] for EVA's own files, [S] for external sources.

> **How this memo was made.** A research workflow of 83 agents ran six searches, checked 42 candidate models against
> their original papers, sent a second checker against every claim of Spanish training, filled four gaps found by a
> completeness review, and had three independent judges score the options. A synthesis agent wrote this memo. The
> orchestrator, acting as CMO, then reviewed it. It re-opened four key sources: the 2026 systematic review, the
> Moli-sani table, the National Death Index access page, and the UK Biobank showcase and access paper. All four
> matched. It also made three corrections: the third judge's full scores, recovered after its sheet was cut off
> (section 2.2); the wording on KDM v2.2's public figures (section 2 and 5.1); and this note. The evidence behind
> every model is in `evidence.json` beside this file.

## 1. The answer

Choose EVA version 3 (v3). It is EVA's re-estimate of the Levine 2018 PhenoAge method on six Base Panel tests: the Base tier for everyone, plus Base + HbA1c when a reliable HbA1c exists. It is the closest option to your checklist that EVA can actually run. It meets item 4, partly meets items 1, 3 and 5, and does not meet item 2. No option meets item 2 today, because no published blood-chemistry biological age has been trained or validated on Spanish data.

The path from there:
- Treat v3 as stage one: validate it once in UK Biobank, then in Spanish data with linked deaths, then publish. Finished, this path scores 17 of 25 with all three reviewers, the best of any option.
- Retire KDM v2.2 and correct its public claims now.
- Release v3 only after the laboratory and capillary checks pass.
- Keep the original PhenoAge as the comparator, not as the product.

## 2. Each option against the checklist

**How to read the table.** Each cell gives Met, Partly or Not met, with the main reason. "Future" options are judged as if completed. Neither of them exists today.

| Option | 1 Validated | 2 Spanish trained | 3 Most respected | 4 Base Panel | 5 Expandable |
|---|---|---|---|---|---|
| **O2. EVA v3 as it is (choose now)** | Partly. Pre-registered sealed US test: HR 1.52 per SD, C gain 0.022. Not external, not published [I1, I2]. | Not met. US NHANES data only [I2]. | Partly. Uses the benchmark PhenoAge method. The model itself is unpublished [I1]. | Met. Six of the 13 tests, one serum tube, no blood count or glucose. Lab and capillary checks pending [I2, I3]. | Partly. Tiers and add-on rules exist. All five add-ons tested failed [I6]. |
| **O3. v3 validated in UK Biobank and Spain, then published (future)** | Met when done. | Partly. "Validated in Spanish data", probably ages 65+ first [S23, S24]. | Partly. Published and externally validated, but still a re-estimate. | Met. Same as v3. | Partly. UK Biobank can test new modules such as cystatin C [S44]. |
| O1. Keep KDM v2.2 | Not met. Fails 7 of EVA's pre-registered tests. Its public figures are either in-sample or held-out with no stored record [I3, I8]. | Not met. Only applied in Spain. Spanish summary means shift 9 of 14 markers [I8, I9]. | Not met. The method is well cited. This build is unpublished and flagged "NEEDS REVIEW" [I9]. | Partly. Runs on 10 of 13 tests, but the stored result is 60% chronological age [I7]. | Partly. Easy to add markers, but the result moves with which tests were done [I5]. |
| O4. Original Levine PhenoAge, adding a blood count and glucose | Met for ranking risk [S3, S6, S7]. Reads about 4 years young in EVA's tests [I5]. | Not met. US-trained. No Spanish validation found. | Met. The de facto benchmark [S5, S9]. | Not met. Needs an EDTA blood count and glucose [S8, I7, I11]. | Not met. One fixed formula. |
| O5. New EVA model trained on a Spanish cohort with deaths (future) | Partly. One cohort allows internal validation only. | Partly. The only confirmed candidate covers ages 65+ in one province [S23, S24]. | Not met. A new, small re-fit starts with no standing. | Met if the cohort has all six markers. | Partly. New markers need Spanish data with deaths. |
| Homeostatic dysregulation (HD) on Base Panel markers | Not met. Published versions use other marker sets, so EVA's version would be new [S13]. | Not met. | Partly. 226 citations. The consortium review excluded the HD study it considered [S5, S9]. | Partly. Computable, but gives a distance, not years. | Partly. Recompute the reference, but the scale changes. |
| Laboratory frailty index (FI-Lab), adapted | Not met for EVA. The evidence is mainly in people 65+ [S15]. | Not met. | Partly. 247 citations. A 38-study meta-analysis exists [S9, S15]. | Partly. Computable, but gives a 0 to 1 score, not years. | Partly. Any test with a reference range can be added. |
| TSHA frailty equations (Spanish) | Not met. Predicts a frailty score, not death or age. Preprint [S23]. | Partly. Trained on Spanish adults 65+ in Toledo [S23]. | Not met. 0 citations [S9]. | Not met. Every equation needs a blood-count value [S23]. | Not met. |
| Bortz UK Biobank blood age | Partly. Tested only on a Scottish hold-out of the same cohort [S6]. | Not met. | Partly. 79 citations [S9]. | Not met. Most of its 25 inputs are missing, including cystatin C [S6]. | Not met. Fixed set of 25 markers. |
| GOLD Light BioAge | Partly. In an independent Chinese cohort: C 0.742, and it read 5.19 years young [S17]. | Not met. | Not met. 30 citations [S9]. | Not met. Needs glucose [S18]. | Not met. |
| Keyoniq SevenAge | Not met. Trained to predict age, with a 9.06-year error [S19]. | Not met. Thai hospital data. | Not met. 2 citations [S9]. | Not met. Needs HbA1c from an EDTA tube [S19, I11]. | Not met. |

### 2.2 How the three reviewers scored the options

Scores are out of 25: five criteria, scored 0 to 5 each.
- **Where all three scored an option:** the reconciled total is the median of the three on each criterion.
- **Where fewer scored:** I decided, as explained in 2.3.

| Option | Epidemiologist | Product and lab | Clinical and regulatory | Reconciled |
|---|---|---|---|---|
| O3. v3 validated in UK Biobank and Spain (future) | 17 | 17 | 17 | 17 |
| O5. New Spanish-trained model (future) | 12 | 13 | 16 | 13 |
| O2. EVA v3 as it is | 12 | 12 | 11 | 12 |
| O4. Original PhenoAge plus blood count and glucose | 10 | 11 | 12 | 11 |
| Homeostatic dysregulation | 9 | 10 | 9 | 9 |
| FI-Lab, adapted | 9 | not scored | 10 | 9 |
| O1. KDM v2.2 | 8 | 8 | 8 | 8 |
| TSHA frailty equations | 8 | 7 | 7 | 7 |
| Bortz UK Biobank | 5 | 8 | 7 | 5 |
| GOLD Light BioAge | 5 | not scored | 6 | 5 |
| Keyoniq SevenAge | not scored | 5 | 6 | 5 |

The third reviewer's sheet reached the synthesis cut off after its O5 scores. The orchestrator recovered the full sheet afterwards and added its scores above; the reconciled column was set before that and no ranking changes. Its recommendation is the same as the other two: v3 now, released only through the proposal's conditions, with O3 as the target. It scored the original PhenoAge above v3 on paper, 12 to 11, and still chose v3, because the Base Panel is a hard constraint for the decision now. It also scored three options not shown here: IberScore 10, the BioAge 12-marker PhenoAge 8, and the Rotterdam re-fit 7.

O5 totals more than O2 only on paper. It needs a Spanish dataset that is not confirmed, and it would take years. So the choice now is O2, and the target is O3.

### 2.3 Where the reviewers disagreed, and what I decided

| Issue | Epidemiologist | Product and lab | Clinical and regulatory | Decision and why |
|---|---|---|---|---|
| Credit for v3's validation (O2, item 1) | 3 | 3 | 2: internal, unpublished work is capped | **Partly.** The design is unusually strict. But it is internal, US-only and unpublished, and the sealed test was used twice [I1, I2]. For public claims the stricter view governs: no "validated" claim until external validation and publication. |
| Original PhenoAge against v3 | v3 ahead, 12 to 10 | v3 ahead, 12 to 11 | PhenoAge ahead, 12 to 11, but the Base Panel is a hard constraint | **v3 now.** PhenoAge needs an EDTA blood count and glucose, which the one-tube kit cannot give [I7, I11]. On US validation it reads 4.13 years young and fails calibration even after an intercept [I5]. An ALP-free version read Italians 9.9 years young [S8]. Keep it as the comparator. |
| Build a Spanish model now (O5) or validate v3 first (O3) | O3, 17 to 12 | O3, 17 to 13 | Nearly tied, 17 to 16 | **Validate v3 first.** Only O5 can make EVA "Spanish trained", but no representative Spanish adult cohort with all six markers and deaths is confirmed [S23, S24, S37]. A 2026 review of 81 routine-chemistry clocks advises validating promising clocks in target populations rather than building new ones [S1]. The same partner and data serve both, so O3 first loses nothing. Move to O5 only if v3 ranks risk poorly in Spanish data, or a representative cohort becomes available. |
| Value of a Spanish validation (O3, item 2) | 3 | 3 | 4 | **Partly.** It is the "next best thing" on your list. If only TSHA is used, the honest claim is "validated in Spanish adults aged 65 and over". |
| KDM v2.2 in the meantime | Show none if v3's gate fails | Keep it, labelled as an estimate, until v3 is released | A physician would not countersign it | **Both.** Keep it only as a labelled estimate until v3 clears its gates, and fix its claims now. If v3 cannot clear the gates, show no biological age. |
| What "recalibration" means | Only with Spanish outcome data | Only with Spanish outcome data [I4] | Harmonise the cohort's lab methods first | **Two different things.** Laboratory alignment of Echevarne to the model's scale is required before release [I3]. A change of level for Spanish people needs Spanish death data and a pre-registered rule [I4]. Do not re-centre the number on EVA's own clients. |
| How much of KDM v2.2 is chronological age | 60% | 60% | 78% | **Both are right.** 60% is the stored Reference tier and 78% the dashboard's Comprehensive tier, for a typical man of 45 [I7]. |
| Small differences (HD 9 or 10; Bortz 5 or 8; TSHA 8 or 7) | | | | **Lower score taken.** The higher scores credit things EVA cannot use: method-level validation for HD, imputation that needs a 25-marker reference set for Bortz, and a preprint with no citations for TSHA. None of these choices changes the ranking. |

## 3. "Spanish trained": what exists and what does not

**Plain answer.** In everything I could search, no biological age built from routine blood chemistry meets all three of these conditions:
- trained on Spanish population data;
- validated against mortality;
- able to run on a serum panel.

None of the established models has been validated in a Spanish cohort either: PhenoAge, KDM, homeostatic dysregulation and FI-Lab. So item 2 cannot be met by adopting a published model. It can be partly met by validating v3 in Spanish data, and fully met only by training a new model on a suitable Spanish cohort.

### 3.1 What exists, and what role Spanish data played

| Item | Spanish role | What it is | Why it does not serve EVA |
|---|---|---|---|
| TSHA frailty equations (Zamudio and colleagues, 2024 preprint) | **Trained** on Spanish data: TSHA, Toledo, ages 65+, fasting blood 2006 to 2009 [S23] | Four regression equations that predict a frailty score | Not death and not years. Every equation needs a blood-count value. 0 citations [S9, S23] |
| TSHA latent phenotypes (2026) | **Trained** on 1,491 TSHA participants [S24] | Three groups built from 39 blood tests | A category, not an age |
| EXERNET clusters (2025) | **Trained** on 536 active Spaniards over 65 [S26] | Three groups | A category, not an age |
| Immunity Clock (2021) | Built by a Madrid group on 214 healthy people. The abstract does not state the sample's country, so Spanish training is **unverified** [S27] | Five live-cell immune tests, trained to predict age | Needs specialised cell assays, not routine chemistry |
| IberScore (2021) | **Trained** on workers examined by Ibermutuamur, a Spanish mutual [S28] | A 10-year heart-risk calculator that uses a "cardiovascular biological age" | Predicts heart events. Not a blood-chemistry age |
| CORDIOPREV senescence score (2020) | **Trained** on 353 coronary patients in Córdoba [S29] | Predicts short telomeres | Not an age. Specialised assays |
| SHARE Klemera-Doubal age (2026 preprint) | **Fitted on pooled data** from 12 countries [S35]. Spain is one of SHARE's 12 blood-spot countries, 5.6% of one analysis sample [S36] | KDM on nine indicators from finger-prick dried blood spots | Not Spain-specific. A preprint |
| EVA's KDM v2.2 | **Applied only.** Published Spanish means, mostly from the PESA study, shift 9 of 14 markers. No Spanish outcome data [I8, I9] | EVA's production model | Fails EVA's own tests |

**Out of scope, noted briefly:**
- a mostly Spanish NMR metabolomic clock from CIC bioGUNE [S30];
- the PREDIMED 38-metabolite mortality signature [S31];
- a Flemish-trained NMR clock, **validated** in the Spanish Hortega cohort [S32];
- a three-gene blood expression clock from Zaragoza [S33];
- EPIC-Granada allostatic load scores, tested against cancer, not age [S34].

Spanish "biological age" papers in PubMed are mostly something else: DNA methylation (for example a Barcelona stroke cohort [S47]), bioimpedance "metabolic age", or immune and redox assays.

### 3.2 What was not found

- A Spanish-trained, mortality-validated blood-chemistry age that runs on a serum panel.
- Any validation of clinical PhenoAge, KDM, homeostatic dysregulation or FI-Lab in a Spanish cohort.

### 3.3 Searches I ran in this task

| Database | Query, in short | Hits | Result |
|---|---|---|---|
| PubMed | biological, phenotypic or PhenoAge age, Klemera, dysregulation or aging clock, with a Spanish affiliation | 370 | None in scope |
| PubMed | the same core terms, Spanish affiliation, and blood or biomarker terms | 91 | None |
| PubMed | "edad biológica" or "envejecimiento biológico" | 4 | None |
| PubMed | core terms and Spanish cohort names (TSHA, ENRICA, Di@bet.es, PREDIMED, EPIC-Spain, REGICOR, Hortega, AEGIS, CORDELIA, SUN, SIDIAP) | 11 | None |
| PubMed | Spain or Spanish, core terms, and mortality or validation | 8 | None |
| Europe PMC full text | PhenoAge, phenotypic age or Klemera, with a Spanish affiliation | 81 | None |
| Europe PMC full text | the same terms with Spanish cohort names | 45 | None |
| Europe PMC full text | biological or phenotypic age, Spanish population, albumin and creatinine | 35 | None |
| Europe PMC full text | "edad biológica" with albúmina or creatinina | 5 | Congress books only |
| Europe PMC preprints | 2024 to 2026, biological age with Spain or Spanish | 21 | None |
| Europe PMC preprints | SHARE dried blood spots with KDM | 3 | None (the SHARE preprint was found through Crossref) |

**Screening:**
- I screened 378 unique PubMed records by title.
- I read 16 borderline abstracts.

**Not searched:** Spanish thesis and congress databases (TESEO, TDX, IBECS, SciELO). The research team's earlier sweeps reported them blocked, and I did not reach them either. A Spanish thesis or congress abstract could therefore have been missed.

## 4. "Most respected": the evidence

### 4.1 Citations (Crossref, read 29 October 2026) [S9]

| Paper | What it is | Citations |
|---|---|---|
| Levine 2018 | PhenoAge (the paper is mainly about the DNA methylation version) | 3,594 |
| Levine 2013 | KDM reference implementation | 869 |
| Klemera and Doubal 2006 | KDM method | 802 |
| Liu 2018 | Clinical PhenoAge validated in NHANES IV | 738 |
| Kwon and Belsky 2021 | BioAge toolkit (KDM, PhenoAge, HD) | 415 |
| Moqri 2024 | Biomarkers of Aging Consortium review | 345 |
| Howlett 2014 | FI-Lab | 247 |
| Cohen 2013 | Homeostatic dysregulation | 226 |
| Wu 2021 | Rotterdam PhenoAge re-fit | 93 |
| Fong 2024 | LinAge | 88 |
| Bortz 2023 | UK Biobank blood age | 79 |
| Immunity Clock 2021 | Madrid immune clock | 36 |
| Hao 2025 | GOLD BioAge | 30 |
| Wang 2025 | Kailuan, a Chinese PhenoAge re-fit | 12 |
| IberScore 2021 | Spanish heart-risk score | 10 |
| Meyer 2025 | Keyoniq SevenAge | 2 |
| Zamudio 2024 | TSHA frailty equations (preprint) | 0 |
| EVA v3 | Unpublished | none |

### 4.2 Consensus

- **The Biomarkers of Aging Consortium (Nature Medicine 2024).**
  - It lists "Phenotypic aging" among blood-based biomarkers validated across populations.
  - KDM is not in that table.
  - It excluded the homeostatic dysregulation study it reviewed, for follow-up under 10 years [S5].
  - It also says no consensus exists on how such biomarkers should be validated before clinical use [S5].
- **No endorsement.** None of the sources I opened shows a guideline or regulatory endorsement of any blood-chemistry biological age.
- **A 2026 systematic review** appraised 81 routine-chemistry clocks with PROBAST+AI [S1].
  - 38.3% had no validation at all.
  - Most were at high risk of bias.
  - It advised validating promising clocks rather than building new ones.

### 4.3 Validations of the original PhenoAge

| Population | Result | Source |
|---|---|---|
| US NHANES IV (developers) | HR 1.09 per year. 10-year AUC 0.88, against 0.86 for age | [S3] |
| UK Biobank | HR 1.100 per year. KDM fell to HR 1.000 once PhenoAge was in the model | [S7] |
| UK Biobank, Scotland hold-out | C 0.750, against 0.726 for age and sex | [S6] |
| Moli-sani, southern Italy (version without ALP) | Read 9.9 years younger than age on average. Still predicted cancer death, HR 1.04 per year | [S8] |
| EVA's US validation (BioAge implementation) | Reads 4.13 years young. Band gaps of -1.20 to +2.56 years even after an intercept | [I5] |

### 4.4 Head-to-head comparisons

- **Five cohorts in four countries, on the same markers:** "no single metric consistently outperformed the others" [S4].
- **KDM in Europe:** KDM predicts death in Europe (Dutch Lifelines: HR 1.07 per year of acceleration) [S22]. But it carried no extra information once PhenoAge was modelled in UK Biobank [S7].
- **EVA's sealed 2007 to 2014 test,** each model paired with v3 on overlapping subjects [I2]:

| Model | HR per SD | C gain over age and sex |
|---|---|---|
| Original PhenoAge (needs a blood count and glucose) | 1.583 | 0.0313 |
| EVA v3, Base tier | 1.516 | 0.0217 |
| BioAge KDM (Levine 2013) | 1.301 | 0.0064 |
| EVA KDM v2.2, Base Panel | 1.296 | 0.0087 |

On the same people, v3's C gain is 0.0096 lower than PhenoAge's, a significant difference. The HR difference is not significant [I2].

### 4.5 What this means for EVA

- The original PhenoAge is the most respected blood-chemistry biological age. No blood-chemistry model has a guideline endorsement.
- v3 borrows PhenoAge's method and its conversion to years, not its reputation.
- EVA earns respect by publishing v3 with external validation, and by always reporting the original PhenoAge beside it.

## 5. The recommended path

### 5.1 Decisions for you now

1. **Adopt v3 to replace KDM v2.2.**
   - Use the Base tier for everyone.
   - Use Base + HbA1c only when a reliable HbA1c is under 90 days old [I3]. It gives almost the same number: C 0.7952 against 0.7955 [I2].
   - v3 adds no test and no tube to the €99 Base Panel [I13].
   - The app already computes v3 in shadow mode [I12].
2. **Gate client release on the proposal's seven conditions** [I3]:
   - laboratory alignment;
   - the capillary study;
   - integration fixes;
   - a shadow period;
   - client copy;
   - labelled past results;
   - a physician's countersignature.

   Add counsel's view on medical-device software [I15].
3. **Correct KDM v2.2's public pages now.** The methodology page says "validated in 18,570 people", "Out-of-sample (5-fold CV); 95% CI [1.20, 1.40]" and "Recalibrated for Spain on 11 of 14 base-panel markers" [I10]. EVA's own files do not support these as written [I8]:
   - The held-out figure, 1.29, is recorded only in a commit message, and the interval [1.20, 1.40] is recorded nowhere.
   - The figures stored in the code, 1.39 and 1.65, are in-sample.
   - The marker library holds Spanish values for 9 of the 14 markers, not 11.

   Replacement text for each claim is ready in `docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md`, waiting for counsel.
4. **Fund the validation program:** a UK Biobank application now, and a Spanish public research partner.
5. **Set the interim rule.** Keep KDM v2.2 only as a labelled estimate until v3 is released. If v3 cannot pass its gates, show no biological age.

### 5.2 Steps to close each gap

The times below are planning estimates, not verified facts, except where a source is cited.

| Checklist item | Gap today | Step | Pass rule, fixed in advance | Time |
|---|---|---|---|---|
| 1 Validated | Internal, US-only, unpublished | **(a) External validation in UK Biobank.** Validate the frozen v3 once, under a public pre-registration. UK Biobank has 12 of the 13 Base Panel tests, 56,961 participants with a recorded death, and companies are treated the same as academics [S44, S45]. The application text is drafted [I14]. | The charter's thresholds: HR lower bound at least 1.20; C gain above zero; every sex and age band within 1.5 years [I4] | About 6 to 9 months. UK Biobank reported 24 weeks from application to data at the end of 2018 [S45] |
| 1 Validated | Unpublished | **(b) Peer-reviewed publication** under TRIPOD+AI. Disclose the reused sealed test, the amended plan and EVA's commercial interest. Share the coefficients and the code. | | Review takes about 6 to 12 months after submission |
| 2 Spanish | No Spanish data | **(a) Validate in TSHA** with the frozen v3 (section 5.3). Check ranking (HR, C gain) and level (observed against expected deaths, by sex and age band). **(b) Recalibrate only if needed.** Only if ranking passes and level fails, re-set the two per-sex intercepts by a pre-registered rule, then check on data not used to set them [I2, I4]. **(c) Representative adults next:** Di@bet.es, after re-assay. | No "validated in Spain" claim if the pre-registered thresholds are missed | TSHA: about 6 to 12 months from first contact. Di@bet.es: about 12 to 24 months |
| 3 Respected | Unpublished | Publish (step 1b). Report the original PhenoAge as the comparator in every validation. Register validation protocols publicly before data access. | | With step 1b |
| 4 Base Panel | Transfer to Echevarne and to Tasso samples unproven | **(a) Echevarne method alignment** for albumin, ALP, creatinine, BUN, GGT and hs-CRP. Confirm the albumin and creatinine methods: the catalogue lists only "Espectrofotometría Ultravioleta-Visible" [I11]. Add a change-control clause. **(b) Tasso capillary against venous study:** a pilot of 20 to 30 kits, then about 100 pairs, at least 40 of them shipped in July and August [I3]. | Residual lab offset within 0.5 years. Capillary mean difference within 0.5 years [I3] | Alignment: about 2 to 3 months. Capillary: the summer arm runs July to August 2027, so results come in autumn 2027 |
| 5 Expandable | All five add-ons failed in NHANES [I6] | Test new modules in UK Biobank under pre-registration, cystatin C first: in UK Biobank, one SD of cystatin C raised mortality hazard by 31% [S6]. Keep other laboratories' results out of the age until each is aligned [I3]. Bring back the blood count only after analyzer harmonisation [I1]. | Composition test T4 must pass [I4] | With step 1a |

### 5.3 Which Spanish data to use, and how to get it

| Dataset | Who and when | The six v3 inputs | Deaths | Access | Use |
|---|---|---|---|---|---|
| **TSHA, Toledo** | 2,488 people 65+, a random census sample [S24]. Fasting blood 2006 to 2009 [S23] | All six appear in the baseline blood tables of a 2024 preprint. CRP was available for 679 of 847 women [S23] | National Death Index, followed 2006 to 2019 [S24]. The number of deaths was not in the sources I opened | Not public [S24]. Work with the TSHA team: Toledo geriatrics, the UCLM-SESCAM group and CIBERFES [S24] | **First Spanish validation (older adults)** |
| **Di@bet.es** | 5,072 adults 18+, a national random sample [S37]. Serum frozen at minus 80 °C [S38] | Creatinine and hs-CRP are listed [S38]. Albumin, ALP and urea were not seen in the papers I opened | Death certificates to the end of 2023, median 14.5 years. 337 deaths in a subsample of 2,918 [S37] | Through the study's investigators. Stored serum would need re-assay, ideally at Echevarne | Representative validation, or training for O5 |
| ENRICA | 11,090 adults 18+, representative of Spain [S39] | hs-CRP measured. Others not checked | 330 deaths to 2017 [S39] | Through the investigators | Secondary |
| CORDELIA | 196,632 people pooled from Spanish cohorts. Plasma for 99,019 [S40] | Of the six, only creatinine (Jaffe method) is harmonised [S40] | Cohort-linked outcomes | Open application from 2027 [S40] | A possible re-assay route later |
| SIDIAP and BIFAP | Health records | n/a | n/a | SIDIAP does not give data to for-profit entities [S42]. BIFAP serves independent researchers doing drug-safety studies [S43] | Not a route for EVA |
| UK Biobank (not Spanish) | About 500,000 adults | 12 of the 13 Base Panel tests | 56,961 with a recorded death [S44] | Companies on the same terms as academics [S45] | First external validation, and new modules |

**Why EVA needs a public partner.** Spain's National Death Index releases data only to four kinds of body [S41]:
- health centres;
- health administrations;
- public research centres;
- life or accident insurers.

EVA cannot link deaths itself.

**Two cautions about TSHA:**
- Its 2006 to 2009 assays did not use Echevarne's methods, so a level check there mixes laboratory and population differences. Ask whether stored TSHA serum exists for re-assay; that is unverified.
- TSHA has no one under 65, so it cannot show how v3 performs in EVA's younger clients.

### 5.4 A faster route for clinic draws (needs the physician's agreement)

The capillary study cannot finish before late summer 2027 [I3]. If clinic draws are venous, they do not depend on that study. Consider a staged release:
- **First, clinic venous samples,** once laboratory alignment, the shadow period, client copy and the countersignature are done.
- **Then home kits,** only after the capillary study passes.

This changes the order of the proposal's conditions, so the countersigning physician must agree.

### 5.5 What not to do

- **Do not switch to the original PhenoAge.** It breaks the one-tube kit and fails EVA's calibration test [I5, I7].
- **Do not build a new Spanish model before validating v3 in Spain** [S1].
- **Do not re-centre v3 on EVA's own clients** without outcome data [I4].
- **Do not present homeostatic dysregulation or FI-Lab as a biological age.** Neither is in years.
- **Do not call v3 "validated" in public copy** until external validation and publication.

## 6. Risks, and what would change the recommendation

### 6.1 Risks

| Risk | Evidence | What to do |
|---|---|---|
| The level may not hold in Spain | A PhenoAge computed without ALP read southern Italians 9.9 years young [S8]. Part of this may be PhenoAge's own bias: 4.13 years young on US validation [I5]. Weighted to the US population, v3 reads 0.43 years young [I2] | Monitor monthly in shadow mode, by sex and age band. Change the level only with Spanish death data [I3, I4] |
| Laboratory and sample handling rival the biology | Shifts measured: see the first table below [I2, I3] | Alignment, the capillary study, and change control with Echevarne |
| Small signal for one person | See the second table below [I1, I2] | Honest display: a range, the average of two draws, no claims about small moves |
| Credibility | Unpublished. Sealed test used twice. Plan amended after the 2015 to 2018 check. EVA has a commercial interest [I1, I2] | Pre-register, publish, share the code |
| The Spanish route stalls, or covers only people 65+ | Access rules for INDEF, SIDIAP and BIFAP [S41, S42, S43]. TSHA is 65+ only [S24] | Run the TSHA and Di@bet.es tracks in parallel, with UK Biobank meanwhile |
| Clients' numbers move at the switch | KDM and PhenoAge accelerations correlate only at r = 0.23 in UK Biobank [S7] | Keep past results labelled with their method. Explain the change |
| Regulation | v3 is more explicitly mortality-trained, which adds pressure toward "medical device" [I15] | Counsel before release. No risk or prediction claims. Never show the internal mortality probability [I15] |
| Interim exposure | KDM v2.2 reads 3.52 years old on US validation. Its repeat-draw SD is 3.7 to 4.3 years [I3, I5] | Labelled estimate only. Stop if v3 fails its gates |
| Search gaps | Spanish theses and congress abstracts were not searched | Ask Spanish ageing research groups directly |

How laboratory and sample handling move v3's number:

| Shift | Change in v3's result |
|---|---|
| NHANES analyzer change between two survey cycles | 2.6 years [I2] |
| Albumin 0.2 g/dL lower | +1.44 years [I2] |
| Typical between-laboratory differences | 1.2 to 3.8 years [I3] |
| Unspun Tasso+ serum samples that were usable | 23.1% [I3] |

How small the signal is for one person:

| Measure | Value |
|---|---|
| C gain over age and sex | 0.022 [I2] |
| 95% range at a typical profile | ±3.1 years [I1] |
| Change needed to count as real | about 4.3 years [I1] |
| Share at the hs-CRP floor of 2.1 mg/L, women / men | 42.5% / 56.6% [I2] |

### 6.2 What would change the recommendation

| If this happens | Then |
|---|---|
| UK Biobank validation misses the pre-registered thresholds | Do not release v3 as validated. Review the model under a new pre-registration before release |
| Spanish data show poor ranking (HR interval includes 1, or no C gain) | Move to O5, a Spanish re-fit, or stop showing a biological age |
| Spanish ranking passes but the level is off | Pre-registered intercept recalibration, as planned in O3 |
| The capillary study fails | Clinic draws only, or change the tube, re-aligned first [I3] |
| A representative Spanish adult cohort with all six markers and deaths becomes accessible: Di@bet.es after re-assay, CORDELIA by application from 2027 [S40], or EU Health Data Space secondary-use rules from March 2029 [S46] | O5 becomes realistic and could meet item 2 fully |
| A Spanish-trained serum biological age is published, or found in Spanish theses | Re-assess it against this checklist |
| EVA adds a venous blood count and glucose | The original PhenoAge becomes runnable as a secondary comparator. Its calibration and incentive failures remain |
| Counsel classifies the number as medical-device software | The timeline and claims change. v3's evidence package becomes the starting file |

## 7. Sources

**Inputs to this memo:** three reviewer score sheets supplied with this task. The third, from the clinical and regulatory adviser, was cut off in the synthesis input after its O5 scores; the orchestrator recovered the full sheet afterwards (section 2.2).

### EVA's internal files (opened read-only)

- **I1.** `ml/biological-age/REPORT.md`.
  - "The main scientific gap is external validation."
  - "Not tested on a European or Spanish population, or on EVA's clients."
  - "Laboratory methods matter as much as the model."
- **I2.** `ml/biological-age/MODEL-CARD.md`.
  - "There is no validation outside the US, in Spain, or in EVA's clients."
  - Sealed test, Base tier: "1.516 (1.412 to 1.629)".
  - "42.5% of women and 56.6% of men in validation".
  - Weighted level: "−0.43 (−0.67 to −0.18)".
  - "should use EVA's own paired or method-comparison data after lab alignment".
- **I3.** `ml/biological-age/PROPOSAL.md`.
  - "it fails T2, T3, T4, T5, T6, T7 and T9".
  - "only 23.1% of serum samples shipped unspun had enough volume".
  - "At least 40 pairs are collected and shipped in July and August".
- **I4.** `ml/biological-age/CHARTER.md`.
  - "None. It returns only if Spanish outcome data validate it."
  - "HR per SD lower bound ≥ 1.20".
- **I5.** `ml/biological-age/REPORT-baselines.md`, section 6.
  - EVA KDM v2.2: "fail (+3.52 y; 0.952; none)".
  - PhenoAge: "fail (−4.13 y; 1.046; 0.795)".
  - "its sex-by-age band gaps range from −1.20 to +2.56 years".
  - "Base Panel reads 1.68 y older than every marker".
- **I6.** `ml/biological-age/addons/REPORT.md`.
  - "No add-on enters the biological age."
- **I7.** `docs/biomarker-evidence/longevity/base-panel/ASSESSMENT.md`.
  - F1 table: "Reference (stored with the result)", weight on chronological age "0.60". Comprehensive tier "0.78".
  - "the laboratory runs HbA1c on EDTA whole blood".
  - "Glucose and insulin fall in blood that travels uncentrifuged for a day". The file marks this as snippet-level.
- **I8.** `docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md`.
  - "1.39, 1.65 and 0.77 are in-sample".
  - "The marker library holds Spanish values for 9 of the 14".
- **I9.** `src/lib/biomarkers/data/marker_library_v2_2.json`.
  - "deployment_recommendation": "NEEDS REVIEW".
  - "PESA (Fernández-Friera et al. Circulation 2015)".
- **I10.** `src/app/[locale]/(marketing)/metodologia/page.tsx`, lines 112 and 122.
  - "Out-of-sample (5-fold CV); 95% CI [1.20, 1.40]."
  - "Recalibrated for Spain on 11 of 14 base-panel markers."
- **I11.** `docs/vendor/echevarne/catalogo-2026-08-25.tsv`.
  - "ALBÚMINA / SUERO" with "TUBO SUERO GEL" and "Espectrofotometría Ultravioleta-Visible".
  - "HEMOGLOBINA A1 C" with "Sangre total" and "TUBO EDTA".
  - "HEMOGRAMA" with "TUBO EDTA".
- **I12.** `src/lib/biomarkers/process-results.ts`, lines 605 to 607.
  - "upserted into bio_age_v3_shadow with the service-role client".
- **I13.** `docs/market/rythm-health.md`.
  - "€396 for 4 tests, €99 each".
- **I14.** `docs/ukbiobank/APPLICATION-DRAFT.md`.
  - "External validation and extension of a mortality-trained blood-chemistry biological age."
- **I15.** `docs/audit/drafts/mdsw-memo-addendum-ba-v3.md`.
  - "Version 3 is more explicitly mortality-trained than KDM v2.2".

### External sources (opened today)

**Reviews, benchmark papers and comparisons**
- **S1.** Zhang 2026, J Gerontol A. PMID 41678247, DOI 10.1093/gerona/glag032.
  - "31 aging clocks (38.3%) were developed with neither internal nor external validation".
  - "Future research should prioritize validating the promising aging clocks in target populations rather than developing new ones".
- **S2.** Levine 2018, Aging. PMID 29676998, PMC5940111, DOI 10.18632/aging.101414.
  - "our analytical sample included 9,926 adults with complete biomarker data".
- **S3.** Liu 2018, PLoS Med. PMID 30596641, PMC6312200, DOI 10.1371/journal.pmed.1002718.
  - "increased the risk of mortality by 9%".
  - "Phenotypic Age, with an area under the curve (AUC) of 0.88".
  - "Nevertheless, further evaluation in other cohorts is needed."
- **S4.** Provost 2025, J Gerontol A. PMID 40796170, PMC12501105, DOI 10.1093/gerona/glaf179.
  - "no single metric consistently outperformed the others".
- **S5.** Moqri 2024, Nat Med. PMID 38355974, PMC11090477, DOI 10.1038/s41591-023-02784-9.
  - "biomarkers of aging validated in cross-population studies", listing "Phenotypic aging".
  - "Exclusion was primarily due to follow-up times below 10 years (Mahalanobis distance".
  - "no consensus exists on how biomarkers of aging should be validated before their translation to the clinic".
- **S6.** Bortz 2023, Commun Biol. PMID 37884697, PMC10603148, DOI 10.1038/s42003-023-05456-z.
  - "the test set was made up of participants in Scotland only".
  - "the PhenoAge model with C-Index of 0.750".
  - "in cystatin C (0.14 mg/L) increases mortality hazard by 31%".
- **S7.** Kuo 2021, Aging Cell. PMC8208797, DOI 10.1111/acel.13376.
  - "weakly correlated ( r = 0.23)".
  - "(HR = 1.000, 95% CI: 0.992 to 1.008) was reduced toward the null".
- **S8.** Morelli 2025, Aging Dis. PMID 40540717, PMC13061564, DOI 10.14336/AD.2025.0204.
  - "∆PhenoAge (y) -9.9 (5.3)".
  - "except ALP, which was not available in the Moli-sani cohort".
  - "1.04 [1.03-1.05] per unit increase".
- **S9.** Crossref API (`api.crossref.org/works/<DOI>`), 29 October 2026, field "is-referenced-by-count":

| DOI | Count |
|---|---|
| 10.18632/aging.101414 | 3594 |
| 10.1093/gerona/gls233 | 869 |
| 10.1016/j.mad.2005.10.004 | 802 |
| 10.1371/journal.pmed.1002718 | 738 |
| 10.1007/s11357-021-00480-5 | 415 |
| 10.1038/s41591-023-02784-9 | 345 |
| 10.1186/s12916-014-0171-9 | 247 |
| 10.1016/j.mad.2013.01.004 | 226 |
| 10.1038/s41598-021-95425-5 | 93 |
| 10.1038/s43587-024-00646-8 | 88 |
| 10.1038/s42003-023-05456-z | 79 |
| 10.1093/gerona/glab136 | 36 |
| 10.1002/advs.202501765 | 30 |
| 10.1007/s11357-025-01612-x | 12 |
| 10.1177/2047487319894880 | 10 |
| 10.1111/eci.13305 | 7 |
| 10.1038/s41598-025-14580-1 | 4 |
| 10.1093/gerona/glaf179 | 4 |
| 10.1093/gerona/glag032 | 2 |
| 10.1038/s41598-025-27478-9 | 2 |
| 10.21203/rs.3.rs-4110049/v1 | 0 |
| 10.2196/76500 | 0 |
| 10.1038/s41514-026-00415-4 | 0 |

- **S10.** Klemera and Doubal 2006. PMID 16318865.
  - "A new approach to the concept and computation of biological age."
- **S11.** Levine 2013. PMID 23213031, PMC3660119.
  - "Modeling the rate of senescence".
- **S12.** Kwon and Belsky 2021. PMID 34725754, PMC8602613.
  - "A toolkit for quantification of biological age from blood chemistry and organ function test data: BioAge."

**Other models**
- **S13.** Cohen 2013. PMID 23376244, PMC3971434.
  - "we selected a 14-marker subset from 63 blood measures".
- **S14.** Howlett 2014. PMID 25288274, PMC4190374.
  - "The areas under the ROC curves were 0.72 for FI-LAB".
- **S15.** Sapp 2023, Age Ageing. PMID 36626319, PMC9831271.
  - "FI-Lab scores per 0.01 unit increase predicted mortality overall (HR = 1.04".
  - "these conclusions were most relevant to older (65+ years old) individuals".
- **S16.** Hao 2025, GOLD BioAge. PMID 40600465, PMC12407260.
  - "a simplified version called Light BioAge is created, which uses three biomarkers".
- **S17.** CHERRY cohort, Light BioAge. PMID 42287049, PMC13268843.
  - "C-index: 0.742".
  - "The median Light BioAge and AgeDiff were 49.31 and -5.19 years".
- **S18.** Light BioAge inputs. PMID 42300733.
  - "serum creatinine, fasting glucose, and high-sensitivity C-reactive protein".
- **S19.** Meyer 2025, Keyoniq. PMID 41372266, PMC12695998.
  - "trained on seven features: creatinine, HbA1c, albumin, ALT, HDL, triglycerides, and sex".
  - "MAE: 9.06 years".
- **S20.** Wang 2025, Kailuan. PMID 40148729, PMC12397035.
  - "the Kailuan Study I (n = 83,571) for developing BA".
- **S21.** Wu 2021, Rotterdam. PMID 34354164, PMC8342513.
  - "(HR 1.11; 95%CI 1.08-1.14) of mortality".
- **S22.** Zuo 2026, Lifelines. PMID 41981354.
  - "HR per 1-year increase = 1.07".

**Spanish-trained items and Spanish cohorts**
- **S23.** Zamudio 2024, TSHA frailty preprint. DOI 10.21203/rs.3.rs-4110049/v1, Europe PMC PPR830886.
  - "Baseline data were collected from June 2006 until September 2009."
  - "Participants in the TSHA study also provided 12-hour fasting blood samples."
  - Table rows: "Albumin (g/dL) 4.27 0.25 843" and "C-Reactive protein (nmol/L) 4.50 3.90 679".
  - "Albumin was present in all functions of risk factors selected by the modeling."
- **S24.** González-Martos 2026, npj Aging. PMID 42215477, PMC13503819.
  - "2488 people aged over 65 years residing in the province of Toledo, Spain".
  - "mortality data were retrieved from the Spanish National Death Index".
  - "Participants were followed from 2006 to 2019".
  - "The datasets analysed during the current study are not publicly available".
- **S25.** TSHA preprocessing paper. PMC6483150.
  - "High-sensitivity C-reactive protein (hs-CRP) [mg/L] 14.98" (percent missing).
- **S26.** EXERNET clusters. PMID 40835865.
  - "536 physically active Spanish participants aged over 65 years".
- **S27.** Immunity Clock. PMID 33979432, DOI 10.1093/gerona/glab136.
  - "A set of 14 immune function variables were measured in 214 healthy individuals".
  - Affiliation: Complutense University of Madrid.
- **S28.** IberScore. PMID 33838039.
  - "We built a new risk calculator using an estimation of cardiovascular biological age as a predictor".
- **S29.** CORDIOPREV score. PMID 32506428.
  - "defined by the lower quintile of relative telomere length".

**Out of scope, noted for completeness**
- **S30.** CIC bioGUNE NMR clocks. PMID 40903544.
  - "NMR-based metabolomic clocks provide a non-invasive, high-throughput platform".
- **S31.** PREDIMED metabolomic signature. PMID 40107652.
  - "38 plasma metabolites were identified as predictors of all-cause mortality".
- **S32.** pMTB-age. PMID 42325222.
  - "external replication Spanish Hortega cohort (N = 811 [2001])".
- **S33.** GamC. PMID 40728816.
  - "GamC is calculated from the expression levels of three genes".
- **S34.** EPIC-Granada allostatic load. PMID 42801852.
  - "including 955 incident cancer cases and 955 matched controls".

**SHARE**
- **S35.** Guo 2026, medRxiv preprint. DOI 10.64898/2026.09.11.26361838, via Crossref.
  - "Cross-sectional analyses used 2015 data from the Survey of Health, Ageing and Retirement in Europe (SHARE)".
  - "combined nine physiological indicators".
- **S36.** SHARE blood-spot countries. PMC12520349.
  - "SHARE collected dried blood spot (DBS) data from ~27,000 individuals in 12 participating countries".
  - "Spain 1,256 (5.61%)".

**Spanish datasets**
- **S37.** Di@bet.es. PMC13341360.
  - "a representative random sample of the Spanish adult population".
  - "The final baseline sample included 5072 non‐pregnant adults".
  - "as of December 31, 2023".
  - "a total of 337 participants (11.5%) had died from any cause".
- **S38.** Di@bet.es. PMC12892829.
  - "serum was frozen at −80°C until analysis".
  - "creatinine and hs‐CRP".
- **S39.** ENRICA. PMC7786987.
  - "11,090 individuals aged 18+ years, representative of the population of Spain".
  - "330 total deaths".
- **S40.** CORDELIA. PMC12170779.
  - "harmonized data on risk factors (body mass index, waist circumference, lipid profile, blood pressure, glucose, creatinine)".
  - "creatinine using the Jaffe method".
  - "Thereafter, any researcher may request access by submitting a standardized application form".

**Data access rules**
- **S41.** National Death Index access rules. https://www.sanidad.gob.es/estadEstudios/estadisticas/estadisticas/estMinisterio/IND_TipoDifusion.htm
  - "Los datos únicamente podrán ser cedidos a:"
  - "Centros de investigación de carácter público."
  - "Entidades aseguradoras autorizadas para operar en España en los ramos de vida o accidentes."
- **S42.** SIDIAP. https://www.sidiap.org/index.php/en/solicituds-en
  - "SIDIAP does not cede data to for-profit entities".
- **S43.** BIFAP, AEMPS. https://www.aemps.gob.es/medicamentos-de-uso-humano/farmacovigilancia-de-medicamentos-de-uso-humano/bifap/
  - "Estos datos están disponibles para proyectos de investigadores independientes que quieran realizar estudios farmacoepidemiológicos."
- **S44.** UK Biobank Showcase. https://biobank.ndph.ox.ac.uk/showcase/label.cgi?id=17518 and field.cgi?id=40000
  - Field list includes "Albumin", "Apolipoprotein B", "C-reactive protein", "Cystatin C" and "Urea".
  - "covering 56,961 participants".
- **S45.** "The advantages of UK Biobank's open-access strategy for health research", 2019. PMC6790705.
  - "access to the resource is available to commercial companies for use for health‐related research on the same basis as academic researchers".
  - "reduced from 69 weeks in 2013 to 24 weeks by the end of 2018".
- **S46.** European Health Data Space. https://health.ec.europa.eu/ehealth-digital-health-and-care/european-health-data-space-regulation-ehds_en
  - "Rules on secondary use will also start to apply for most data categories (e.g. data from electronic health records)" (March 2029).

**Spanish "biological age" that is out of scope**
- **S47.** Barcelona stroke cohort. PMID 29515201, PMC5841388.
  - "Biological age was estimated with an algorithm based on DNA methylation in 71 CpGs."

**Downloaded files.** Copies of every external source above are in `/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/bioage-research/`, in the folders named `final-synth-*`.