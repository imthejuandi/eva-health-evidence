// Print the full evidence records with the given ids from a research, verify or decision file.
// Usage: node show-records.js <file> id1,id2,...
const fs = require("fs");
const [file, idsArg] = process.argv.slice(2);
const d = JSON.parse(fs.readFileSync(file, "utf8"));
const ids = new Set(String(idsArg || "").split(",").filter(Boolean));
for (const ev of d.evidence || []) {
  if (!ids.size || ids.has(ev.id)) console.log(JSON.stringify(ev, null, 2));
}
