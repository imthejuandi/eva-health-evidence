import json
base = '/home/user/eva-health/docs/signoff/work/compiled/B04-r1/'
en = json.load(open(base+'biomarker-ranges-en.json'))['biomarker_ranges']
es = json.load(open(base+'rangos-biomarcadores-es.json'))['rangos_biomarcadores']
NAMES_EN = {"Hemoglobin","Hematocrit","Red Blood Cell Count","MCV","MCH","MCHC","RDW","Platelet Count","MPV"}
def match(name):
    n=name.lower()
    return any(x in n for x in ("hemoglobin","hematocrit","red blood cell","mcv","mch","rdw","platelet","mpv","hemoglobina","hematocrito","recuento de glóbulos rojos","recuento de hematíes","eritrocitos","plaquetas","vpm"))
out=[]
out.append("######## EN ROWS ########")
for i,r in enumerate(en):
    if match(r['Biomarker']):
        out.append(f"\n=== EN[{i}] {r['Biomarker']} | {r['Sex']} | {r['Age_Group']} | State={r.get('State')} ===")
        for k,v in r.items():
            out.append(f"{k}: {json.dumps(v,ensure_ascii=False)}")
out.append("\n\n######## ES ROWS ########")
for i,r in enumerate(es):
    if match(r['Biomarcador']):
        out.append(f"\n=== ES[{i}] {r['Biomarcador']} | {r['Sexo']} | {r['Grupo_Edad']} | Estado={r.get('Estado')} ===")
        for k,v in r.items():
            out.append(f"{k}: {json.dumps(v,ensure_ascii=False)}")
open('/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/rows_dump.txt','w').write("\n".join(out))
print(len(out))
