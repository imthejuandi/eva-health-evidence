import json, re, sys
exec(open('/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/dump.py').read().split("which=sys.argv")[0])
pairs=[('Clinical_Notes','Notas_Clínicas'),('Msg_Critical_Low','Msg_Crítico_Bajo'),('Msg_Below_Optimal','Msg_Debajo_Óptimo'),('Msg_Optimal','Msg_Óptimo'),('Msg_Above_Optimal','Msg_Encima_Óptimo'),('Msg_Critical_High','Msg_Crítico_Alto'),('Critical_None_Reason','Motivo_Sin_Crítico'),('Reference_Source','Fuente_Referencia'),('Method_Note','Nota_Método')]
numpairs=[('Normal_Low','Normal_Bajo'),('Normal_High','Normal_Alto'),('Optimal_Low','Óptimo_Bajo'),('Optimal_High','Óptimo_Alto'),('Critical_Low','Crítico_Bajo'),('Critical_High','Crítico_Alto'),('Marker_Class','Clase_Marcador'),('Reference_Basis','Base_Referencia'),('State','Estado'),('Explanatory_Numbers','Números_Explicativos'),('Unit','Unidad')]
def nums_en(s):
    if not s: return []
    s=re.sub(r'(?<=\d),(?=\d{3}\b)','',s)  # 1,000 -> 1000
    return sorted(float(x) for x in re.findall(r'\d+(?:\.\d+)?',s))
def nums_es(s):
    if not s: return []
    s=re.sub(r'(?<=\d)\.(?=\d{3}\b)','',s)  # 1.000 -> 1000
    s=re.sub(r'(?<=\d),(?=\d)','.',s)      # 2,0 -> 2.0
    return sorted(float(x) for x in re.findall(r'\d+(?:\.\d+)?',s))
for idx,((r,s,fl),(re_,se,fle)) in enumerate(zip(en,es)):
    k=slug(r['Biomarker'])
    if k not in fam_of: continue
    rk='%s|%s|%s|%s'%(k,r['Sex'].lower(),r['Age_Group'],r.get('State'))
    for a,b in numpairs:
        if json.dumps(r.get(a))!=json.dumps(re_.get(b)):
            print('FIELD DIFF',rk,a,r.get(a),'|',b,re_.get(b))
    for a,b in pairs:
        ne=nums_en(r.get(a)); ns=nums_es(re_.get(b))
        if ne!=ns:
            print('NUM DIFF',rk,a,'L%s'%fl.get(a),'EN',ne,'ES',ns)
