import { isStated } from "/home/user/eva-health/.claude/worktrees/approval-fixes/scripts/signoff/checks/data";
for (const t of ["not in the family's decision final_rows", "Not in the family’s decision final_rows.", "not in the family's decision final rows", "Merged into ast|both: one interval (f02-E45).", "decision"]) console.log(JSON.stringify(t), isStated(t));
