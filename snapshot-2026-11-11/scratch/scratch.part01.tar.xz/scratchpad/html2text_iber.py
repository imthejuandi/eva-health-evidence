import sys, re, html
from html.parser import HTMLParser
class P(HTMLParser):
    def __init__(self):
        super().__init__(); self.out=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style','noscript'): self.skip+=1
        if tag in ('p','div','br','li','h1','h2','h3','h4','tr','td','th','section'): self.out.append('\n')
    def handle_endtag(self, tag):
        if tag in ('script','style','noscript') and self.skip: self.skip-=1
    def handle_data(self, data):
        if not self.skip: self.out.append(data)
p=P(); p.feed(open(sys.argv[1],encoding='utf-8',errors='replace').read())
txt=''.join(p.out)
txt=re.sub(r'[ \t\r\f\v]+',' ',txt)
txt=re.sub(r'\n\s*\n+','\n',txt)
open(sys.argv[2],'w').write(txt)
print(len(txt))
