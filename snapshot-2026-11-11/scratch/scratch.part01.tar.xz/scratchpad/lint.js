const fs=require("fs");
const d=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
const md=fs.readFileSync(process.argv[3],"utf8");
const lex=JSON.parse(md.match(/```json[^\n]*\n([\s\S]*?)\n```/)[1]);
const EL={en:[["meaning",/\b(may|can|could|might|reflect|suggest|indicat|mean|linked|associated|sign of|is consistent)/i],["benign",/\b(infection|dehydrat|exercise|workout|training|fasting|non-fasting|supplement|medication|pregnan|sample|haemolys|hemolys|spurious|benign|harmless|temporar|transient|recent meal|alcohol|stress|time of day|morning|creatine|common|many (healthy )?(adults|people))/i],["repeat",/\b(repeat|confirm|re-?test|recheck|second (test|sample|result)|another (test|sample|result)|persist|stays|remains|on two|follow-up test|next test)/i],["who",/\b(doctor|physician|GP|clinician|specialist|medical attention|medical contact|same day|within (a )?(day|days|week|weeks|month|months)|soon|promptly|without delay|today|at your next)/i]],
es:[["meaning",/\b(puede|podría|refleja|sugiere|indica|significa|asociad|relacionad|vinculad|señal de|es compatible)/i],["benign",/\b(infecci|deshidrat|ejercicio|entrenamiento|ayuno|sin ayuno|suplemento|medicamento|medicación|embaraz|muestra|hemóli|hemoli|espuri|benign|inofensiv|temporal|transitori|comida reciente|alcohol|estrés|hora del día|mañana|creatina|frecuente|muchas personas|muchos adultos)/i],["repeat",/\b(repet|repít|confirm|segunda (prueba|muestra|analítica)|otra (prueba|muestra|analítica)|persist|se mantiene|sigue|en dos|próxima (prueba|analítica)|nuevo análisis)/i],["who",/\b(médico|medica|profesional sanitario|especialista|atención médica|contacto médico|el mismo día|en (un |una )?(día|días|semana|semanas|mes|meses)|pronto|sin demora|hoy|en tu próxima)/i]]};
const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
function hits(t,lang,tiers){let out=[];for(const tier of tiers){const r=lex[lang][tier];if(!r)continue;let x=t;for(const a of r.allow||[])x=x.replace(new RegExp(esc(a),"giu")," ");for(const term of r.terms||[])if(new RegExp(`(?<![\\p{L}])${esc(term)}(?![\\p{L}])`,"iu").test(x))out.push(term);for(const p of r.regex||[]){try{if(new RegExp(p,"i").test(x))out.push("re:"+p)}catch{}}}return out;}
for(const r of d.final_rows){const k=[r.marker_key,r.sex,r.age_group].join("|");
 for(const lang of ["en","es"]){
  for(const z of ["below_range","above_range"]) if(r.messages[lang][z]){const miss=EL[lang].filter(([n,re])=>!re.test(r.messages[lang][z])).map(x=>x[0]); if(miss.length) console.log("M2",k,z,lang,miss);}
  for(const [z,t] of Object.entries(r.messages[lang])){const tiers=z.startsWith("critical")?["any"]:["any","non_critical"]; const h=hits(t,lang,tiers); if(h.length) console.log("M3",k,z,lang,h);}
  const cn=r["clinical_notes_"+lang]; if(cn){const h=hits(cn,lang,["any","non_critical"]); if(h.length) console.log("M3 note",k,lang,h);}
 }}
console.log("done");
