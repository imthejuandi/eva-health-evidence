const fs = require("fs");
const f = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/f11gen.js";
let s = fs.readFileSync(f, "utf8");
function rep(o, n, k = 1) { const c = s.split(o).length - 1; if (c !== k) throw new Error(`count ${c} != ${k}: ${o.slice(0, 80)}`); s = s.split(o).join(n); }
// 1. SHAH_LOW: first sentence only; supports critical_low only
rep(`  supports: [...sup(["plt", "pltPreg"], "critical_low"), ...sup(["plt"], "action_limit")],
  identifier: { type: "pmcid", value: "PMC11899349" },`, `  supports: sup(["plt", "pltPreg"], "critical_low"),
  identifier: { type: "pmcid", value: "PMC11899349" },`);
rep(`quote: cut("cache-PMC11899349.txt", "The low median critical limit changed significantly", "thresholds associated with severe thrombocytopenia and thrombocytopenia, respectively."),`,
    `quote: cut("cache-PMC11899349.txt", "The low median critical limit changed significantly", "between 1990 and 2024."),`);
rep(`The authors place 100 ×10^9/L as the threshold associated with thrombocytopenia, the basis of the row's 100,000/µL action limit. A 2026 correction`,
    `The next sentence of the source is {{SHAH_THRESH}}. A 2026 correction`);
// 2. New record SHAH_THRESH right after SHAH_LOW
rep(`const SHAH_HIGH = ev({`, `const SHAH_THRESH = ev({
  supports: sup(["plt"], "action_limit"),
  identifier: { type: "pmcid", value: "PMC11899349" },
  citation: "Shah A, Dohner J, Cheng K, Garcia M, Kost GJ. Diagnostics (Basel) 2025;15(5):604 (as {{SHAH_LOW}}).",
  year: 2025,
  quote: cut("cache-PMC11899349.txt", "This shifted the low median critical limit further away", "thresholds associated with severe thrombocytopenia and thrombocytopenia, respectively."),
  location: "Results, section 3.3 (Hematology and Coagulation Tests), text on Figure 6 (sentence after {{SHAH_LOW}})",
  design: "survey of 50 US critical-limit lists (2024) compared with 1990; the thresholds are cited by the authors (their reference 26)",
  n: 50,
  follow_up_years: null,
  outcome: "clinical thresholds set beside the critical limits",
  population_age: "adults (hospital critical-limit lists)",
  population_sex: "not_reported",
  assay: "platelet count ×10^9/L",
  band_rule: "none",
  basis_class: "expert_opinion",
  proposed_grade: "C",
  age_stratified_statement: "Not applicable (institutional lists and cited clinical thresholds).",
  notes: "100 ×10^9/L (100,000/µL) is the threshold the authors associate with thrombocytopenia and 50 ×10^9/L with severe thrombocytopenia; their source (reference 26) was not opened. Basis of the 'none' row's action limit below 100,000/µL; the critical limit (30,000/µL) sits below both.",
});

const SHAH_HIGH = ev({`);
rep(`evidence_ids: [SHAH_LOW, GAUER_DEF, GAUER_PSEUDO],`, `evidence_ids: [SHAH_THRESH, GAUER_DEF, GAUER_PSEUDO],`);
rep(`is 100,000/µL ({{SHAH_LOW}})`, `is 100,000/µL ({{SHAH_THRESH}})`);
rep(`evidence_ids: [GAUER_DEF, LOZANO_PLT, BIINO, REESE_STATE, SHAH_LOW],`, `evidence_ids: [GAUER_DEF, LOZANO_PLT, BIINO, REESE_STATE, SHAH_THRESH],`);
rep(`SHAH_LOW, SHAH_HIGH, THOMAS,`, `SHAH_LOW, SHAH_THRESH, SHAH_HIGH, THOMAS,`);
// 3. Lozano MPV quote shorter
rep(`"and in EDTA (r = -0.364, p < or = 0.0005, n = 1,430)"),`, `"(r = -0.282, p = 0.006, n = 93)"),`);
rep(`notes: "No sex difference in MPV, so no sex split;`, `notes: "The sentence continues: 'and in EDTA (r = -0.364, p < or = 0.0005, n = 1,430)'. No sex difference in MPV, so no sex split;`);
fs.writeFileSync(f, s);
console.log("ok");
