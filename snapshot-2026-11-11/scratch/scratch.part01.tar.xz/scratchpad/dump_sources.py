import json
base = '/home/user/eva-health/docs/signoff/work/compiled/B04-r1/'
d = json.load(open(base+'biomarker-sources.json'))['biomarkers']
out=[]
for k in ('hemoglobin','hematocrit','red_blood_cell_count','mcv','mch','mchc','rdw','platelet_count','mpv'):
    out.append(f"\n################ {k} ################")
    out.append(json.dumps(d[k], ensure_ascii=False, indent=1))
open('/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/sources_dump.txt','w').write("\n".join(out))
print(sum(len(x) for x in out))
