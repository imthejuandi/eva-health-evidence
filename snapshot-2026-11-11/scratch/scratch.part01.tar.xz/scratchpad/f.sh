#!/bin/bash
# usage: f.sh <outfile> <url>   -- fetch with logging
S=/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad
echo "$2" >> $S/fetch.log
curl -sS -m 90 -A "eva-health-signoff-research/1.0" "$2" -o "$1" -w "%{http_code} %{size_download}\n"
