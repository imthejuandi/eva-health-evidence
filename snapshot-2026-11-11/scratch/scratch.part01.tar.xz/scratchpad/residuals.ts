import fs from "node:fs";
import { computeReferenceBA } from "@/lib/biomarkers/biological-age-kdm";
import { bioAgeV3Record } from "@/lib/biomarkers/biological-age-v3-adapter";
import { getCanonicalUnit } from "@/lib/biomarkers/canonical-units";
const { panels } = JSON.parse(fs.readFileSync("docs/biomarker-evidence/longevity/base-panel/panels.json", "utf8"));
const NOW = new Date("2026-10-30T12:00:00Z");
for (const label of ["Typical man, 45", "Typical woman, 45"]) {
  const p = panels.find((x: { label: string }) => x.label === label);
  const sex = p.sex, age = p.age; const v = p.values as Record<string, number>;
  const c0 = v.creatinine;
  const ref = (c: number, dose: string | null) => computeReferenceBA(Object.entries({ ...v, creatinine: c }).map(([code, value]) => ({ code, value })), sex, age, { supplements: dose ? [{ key: "creatine", dose }] : null })!.BA;
  const v3 = (c: number, dose: string | null) => bioAgeV3Record({ values: Object.entries({ ...v, creatinine: c }).map(([k, x]) => ({ biomarker_key: k, value: x, unit: getCanonicalUnit(k) })), drawDate: "2026-10-01", otherResults: [], dateOfBirth: `${2026 - age}-01-01`, sex, conditionKeys: [], now: NOW, supplements: dose ? [{ key: "creatine", dose }] : null }).ba!;
  const r0 = ref(c0, null), w0 = v3(c0, null);
  const rows: [string, number, number][] = [
    ["13% rise, undeclared", ref(c0 * 1.13, null) - r0, v3(c0 * 1.13, null) - w0],
    ["+0.13 mg/dL, undeclared", ref(c0 + 0.13, null) - r0, v3(c0 + 0.13, null) - w0],
    ["+0.13 mg/dL, 5 g declared", ref(c0 + 0.13, "5 g") - r0, v3(c0 + 0.13, "5 g") - w0],
    ["13% rise, 2 g declared (loaded)", ref(c0 * 1.13, "2 g") - r0, v3(c0 * 1.13, "2 g") - w0],
    ["no rise yet, 5 g declared", ref(c0, "5 g") - r0, v3(c0, "5 g") - w0],
  ];
  console.log(`${label}: creatinine ${c0}, Reference ${r0.toFixed(2)}, v3 ${w0.toFixed(2)}`);
  for (const [k, a, b] of rows) console.log(`  ${k.padEnd(34)} lab page ${a >= 0 ? "+" : ""}${a.toFixed(2)}  v3 ${b >= 0 ? "+" : ""}${b.toFixed(2)}`);
}
