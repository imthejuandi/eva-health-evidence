#!/bin/bash
# usage: s.sh "<europe pmc query>" [pageSize] [abstract chars]
S=/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad
Q="$1"; N="${2:-10}"; A="${3:-600}"
echo "epmc search: $Q" >> $S/fetch.log
curl -sS -m 90 -G "https://www.ebi.ac.uk/europepmc/webservices/rest/search" --data-urlencode "query=$Q" --data-urlencode "resultType=core" --data-urlencode "format=json" --data-urlencode "pageSize=$N" -o $S/src/last_search.json
jq -r --argjson a "$A" '"hits=\(.hitCount)", (.resultList.result[] | "\n# PMID \(.pmid // "-") | \(.pmcid // "-") | OA=\(.isOpenAccess) | \(.pubYear) | \(.journalInfo.journal.isoabbreviation // .bookOrReportDetails.publisher // "-") | \(.authorString // "" | .[0:80])\n  T: \(.title)\n  DOI: \(.doi // "-")\n  A: \((.abstractText // "") | gsub("<[^>]+>";" ") | .[0:$a])")' $S/src/last_search.json
