// Generates the fixture list (without "before"); run once.
const V = "venous";
const f = [];
const add = (id, rule, input, expect_reason, ref) => f.push({ id, rule, ref, input, expect_reason });
const v = (values, more = {}) => ({ values, collection_method: V, ...more });
// Plausibility
add("plausibility_albumin_0", "plausibility: albumin 10 to 60 g/L", v({ albumin: 0 }), "implausible_value", "plausibility.markers.albumin");
add("plausibility_albumin_4_3", "plausibility: albumin 10 to 60 g/L (4.3 is a g/dL value typed in a g/L field)", v({ albumin: 4.3 }), "implausible_value", "plausibility.markers.albumin");
add("plausibility_albumin_61", "plausibility: albumin 10 to 60 g/L", v({ albumin: 61 }), "implausible_value", "plausibility.markers.albumin");
add("plausibility_alp_9", "plausibility: ALP 10 to 1500 U/L", v({ alp: 9 }), "implausible_value", "plausibility.markers.alp");
add("plausibility_alp_1501", "plausibility: ALP 10 to 1500 U/L", v({ alp: 1501 }), "implausible_value", "plausibility.markers.alp");
add("plausibility_hs_crp_0_04", "plausibility: hs-CRP 0.05 to 100 mg/L", v({ hs_crp: 0.04 }), "implausible_value", "plausibility.markers.hs_crp");
add("plausibility_hs_crp_101", "plausibility: hs-CRP 0.05 to 100 mg/L", v({ hs_crp: 101 }), "implausible_value", "plausibility.markers.hs_crp");
add("plausibility_creatinine_0_19", "plausibility: creatinine 0.2 to 15 mg/dL", v({ creatinine: 0.19 }), "implausible_value", "plausibility.markers.creatinine");
add("plausibility_creatinine_88_4", "plausibility: creatinine 0.2 to 15 mg/dL (88.4 is a µmol/L value stored as mg/dL)", v({ creatinine: 88.4 }), "implausible_value", "plausibility.markers.creatinine");
add("plausibility_bun_1_9", "plausibility: BUN 2 to 150 mg/dL", v({ bun: 1.9 }), "implausible_value", "plausibility.markers.bun");
add("plausibility_bun_151", "plausibility: BUN 2 to 150 mg/dL", v({ bun: 151 }), "implausible_value", "plausibility.markers.bun");
add("plausibility_ggt_2", "plausibility: GGT 3 to 1000 U/L", v({ ggt: 2 }), "implausible_value", "plausibility.markers.ggt");
add("plausibility_ggt_1001", "plausibility: GGT 3 to 1000 U/L", v({ ggt: 1001 }), "implausible_value", "plausibility.markers.ggt");
add("plausibility_hba1c_2_9", "plausibility: HbA1c 3 to 18 %", v({ hba1c: 2.9 }), "implausible_value", "plausibility.markers.hba1c");
add("plausibility_hba1c_18_1", "plausibility: HbA1c 3 to 18 %", v({ hba1c: 18.1 }), "implausible_value", "plausibility.markers.hba1c");
// Kidney
add("kidney_creatinine_2_0_man", "kidney: creatinine above the upper reference limit (man, fallback 1.3 mg/dL)", v({ creatinine: 2.0 }), "kidney", "kidney.creatinine_above_reference_upper_limit");
add("kidney_creatinine_1_31_man", "kidney: creatinine above the upper reference limit (man, 1.31 > 1.3 mg/dL)", v({ creatinine: 1.31 }), "kidney", "kidney.creatinine_above_reference_upper_limit");
add("kidney_creatinine_1_1_woman", "kidney: creatinine above the upper reference limit (woman, fallback 1.02 mg/dL)", v({ creatinine: 1.1 }, { sex: "female" }), "kidney", "kidney.creatinine_above_reference_upper_limit");
add("kidney_creatinine_bound_above_limit", "kidney: a '>' bound at the limit counts as above it", { ...v({ creatinine: 1.3 }), comparators: { creatinine: ">" } }, "kidney", "kidney.creatinine_above_reference_upper_limit");
add("kidney_ckd_declared", "kidney: chronic kidney disease declared in the patient context", v({}, { conditionKeys: ["ckd"] }), "kidney", "kidney.declared_kidney_disease");
// Albumin low
add("albumin_low_29", "albumin below 30 g/L gives no result", v({ albumin: 29 }), "albumin_low", "albumin_low");
add("albumin_low_bound_30", "albumin below 30 g/L: a '<' bound at 30 counts as below", { ...v({ albumin: 30 }), comparators: { albumin: "<" } }, "albumin_low", "albumin_low");
// hs-CRP
add("crp_above_limit_60", "hs-CRP above 50 mg/L gives no result", v({ hs_crp: 60 }), "crp_above_limit", "hs_crp.refuse_above");
add("crp_above_limit_bound_50", "hs-CRP above 50 mg/L: a '>' bound at 50 counts as above", { ...v({ hs_crp: 50 }), comparators: { hs_crp: ">" } }, "crp_above_limit", "hs_crp.refuse_above");
// Liver enzymes
add("alp_above_limit_400_man", "ALP above 3 x the upper reference limit (man: 3 x 129 = 387 U/L)", v({ alp: 400 }), "alp_above_limit", "liver_enzymes.alp");
add("alp_above_limit_320_woman", "ALP above 3 x the upper reference limit (woman: 3 x 104 = 312 U/L)", v({ alp: 320 }, { sex: "female" }), "alp_above_limit", "liver_enzymes.alp");
add("ggt_above_limit_220_man", "GGT above 3 x the upper reference limit (man: 3 x 73 = 219 U/L)", v({ ggt: 220 }), "ggt_above_limit", "liver_enzymes.ggt");
add("ggt_above_limit_115_woman", "GGT above 3 x the upper reference limit (woman: 3 x 38 = 114 U/L)", v({ ggt: 115 }, { sex: "female" }), "ggt_above_limit", "liver_enzymes.ggt");
// States
add("state_pregnancy", "declared pregnancy gives no result", v({}, { sex: "female", age: 32, conditionKeys: ["pregnancy_current"] }), "pregnancy", "states.pregnancy");
add("state_lactation", "declared lactation gives no result", v({}, { sex: "female", age: 32, conditionKeys: ["lactating"] }), "lactation", "states.lactation");
// Age
add("age_82", "ages outside the signed range 20 to 79", v({}, { age: 82 }), "age_outside_signed_range", "age");
add("age_80", "ages outside the signed range 20 to 79 (80 to 84: never in the sealed test)", v({}, { age: 80 }), "age_outside_signed_range", "age");
add("age_19", "ages outside the signed range 20 to 79", v({}, { age: 19 }), "age_outside_signed_range", "age");
// Sex
add("sex_missing", "missing sex: no result, no default", v({}, { sex: null }), "sex_unknown", "sex");
add("sex_other", "sex other than male or female: no result, no default", v({}, { sex: "other" }), "sex_unknown", "sex");
// Unit mismatch (the model's own refusal)
add("unit_mismatch_albumin_g_dl", "unit mismatch: albumin in g/dL is not converted by guess", { ...v({ albumin: 4.4 }), units: { albumin: "g/dL" } }, "unit_mismatch", "meta.units");
// Collection method
add("collection_method_unknown", "collection method unknown counts as not venous", {}, "collection_method", "collection_method");
add("collection_method_capillary_home_kit", "collection method capillary, home kit", { collection_method: "capillary", labSource: "home_kit" }, "collection_method", "collection_method");
add("collection_method_capillary_echevarne", "collection method capillary, analysed at EVA's laboratory", { collection_method: "capillary" }, "collection_method", "collection_method");
add("collection_method_venous_upload", "venous draw from another laboratory (client's upload)", { collection_method: "venous", labSource: "user_upload" }, "collection_method", "collection_method");
// Passing controls
const ok = (id, rule, input, ref) => add(id, rule, input, null, ref);
ok("control_healthy_man_50", "control: healthy man, 50, venous at EVA's laboratory", v({}), "all");
ok("control_healthy_woman_45", "control: healthy woman, 45, venous at EVA's laboratory", v({}, { sex: "female", age: 45 }), "all");
ok("control_plus_hba1c", "control: Base Panel with HbA1c 5.4 %", v({ hba1c: 5.4 }), "plausibility.markers.hba1c");
ok("control_age_20", "control: age 20, lower end of the signed range", v({}, { age: 20 }), "age");
ok("control_age_79", "control: age 79, upper end of the signed range", v({}, { age: 79 }), "age");
ok("control_albumin_30", "control: albumin at 30 g/L is not below 30", v({ albumin: 30 }), "albumin_low");
ok("control_albumin_60", "control: albumin at the plausibility ceiling 60 g/L", v({ albumin: 60 }), "plausibility.markers.albumin");
ok("control_creatinine_1_3_man", "control: creatinine at the man's upper limit 1.3 mg/dL is not above it", v({ creatinine: 1.3 }), "kidney.creatinine_above_reference_upper_limit");
ok("control_crp_30_provisional", "control: hs-CRP 30 mg/L gives a provisional result (capped at 10)", v({ hs_crp: 30 }), "hs_crp.provisional_above");
ok("control_crp_50", "control: hs-CRP at 50 mg/L is not above 50 (provisional)", v({ hs_crp: 50 }), "hs_crp.refuse_above");
ok("control_alp_387_man", "control: ALP at 3 x the man's upper limit is not above it", v({ alp: 387 }), "liver_enzymes.alp");
ok("control_ggt_219_man", "control: GGT at 3 x the man's upper limit is not above it", v({ ggt: 219 }), "liver_enzymes.ggt");
ok("bounded_ggt_lt5", "a bounded result '<5' resolves to 5, never to half of it", v({ ggt: "<5" }), "meta.bounded_results");
ok("bounded_ggt_lt5_comparator", "a bounded result stored as value 5 with comparator '<' resolves to 5", { ...v({ ggt: 5 }), comparators: { ggt: "<" } }, "meta.bounded_results");
ok("bounded_crp_lt0_3", "a bounded hs-CRP '<0.3' resolves to 0.3", { ...v({ hs_crp: 0.3 }), comparators: { hs_crp: "<" } }, "meta.bounded_results");
console.log(JSON.stringify(f));
