// Builds docs/signoff/work/decisions/f08_uric_acid_metabolic.json from the verify file's final_rows.
// Run from the repository root: node <this file>
"use strict";
const fs = require("fs");
const crypto = require("crypto");
const path = require("path");

const ROOT = "/home/user/eva-health";
const FAM = "f08_uric_acid_metabolic";
const verifyFile = path.join(ROOT, "docs/signoff/work/verify", `${FAM}.json`);
const ledgerFile = path.join(ROOT, "docs/signoff/work/ledger", `${FAM}.json`);
const researchFile = path.join(ROOT, "docs/signoff/work/research", `${FAM}.json`);
const outFile = path.join(ROOT, "docs/signoff/work/decisions", `${FAM}.json`);

const verify = JSON.parse(fs.readFileSync(verifyFile, "utf8"));
const ledger = JSON.parse(fs.readFileSync(ledgerFile, "utf8"));
const research = JSON.parse(fs.readFileSync(researchFile, "utf8"));
const verifySha = crypto.createHash("sha256").update(fs.readFileSync(verifyFile)).digest("hex");

const key = (r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
const clone = (x) => JSON.parse(JSON.stringify(x));
const vrows = new Map(verify.final_rows.map((r) => [key(r), r]));
const ids = new Set(ledger.issues.map((i) => i.id));
const L = (suffix) => {
  const id = `${FAM}--${suffix}`;
  if (!ids.has(id)) throw new Error(`not in ledger: ${id}`);
  return id;
};

// ─── Ledger ids ───
const I = {
  c1Lact: L("C1--uric_acid.female.Lactation.unreachable--none"),
  c1Preg: L("C1--uric_acid.female.Pregnancy.unreachable--none"),
  d2Lact: L("D2--uric_acid.female.Lactation.age_group--none"),
  d2Preg: L("D2--uric_acid.female.Pregnancy.age_group--none"),
  d3Lact: L("D3--uric_acid.female.Lactation.no_catalogue_band--none"),
  d3Preg: L("D3--uric_acid.female.Pregnancy.no_catalogue_band--none"),
  d5AdipoF: L("D5--adiponectin.female.All_Adults.bounds--none"),
  d5AdipoM: L("D5--adiponectin.male.All_Adults.bounds--none"),
  d5LepF: L("D5--leptin.female.All_Adults.bounds--none"),
  d5LepM: L("D5--leptin.male.All_Adults.bounds--none"),
  d5UaF: L("D5--uric_acid.female.All_Adults.bounds--none"),
  d5Lact: L("D5--uric_acid.female.Lactation.row_only_in_seed--none"),
  d5Preg: L("D5--uric_acid.female.Pregnancy.row_only_in_seed--none"),
  d5UaM: L("D5--uric_acid.male.All_Adults.bounds--none"),
  g2AdipoF: L("G2--row.adiponectin.female.All_Adults.none--none"),
  g2AdipoM: L("G2--row.adiponectin.male.All_Adults.none--none"),
  g2LepF: L("G2--row.leptin.female.All_Adults.none--none"),
  g2LepM: L("G2--row.leptin.male.All_Adults.none--none"),
  g2Lact: L("G2--row.uric_acid.female.All_Adults.lactation--none"),
  g2UaF: L("G2--row.uric_acid.female.All_Adults.none--none"),
  g2Preg: L("G2--row.uric_acid.female.All_Adults.pregnancy--none"),
  g2UaM: L("G2--row.uric_acid.male.All_Adults.none--none"),
  n1Script: L("N1--uric_acid.male.60-69.reference_outside--none"),
  confClass: L("definition:marker_classes--leptin.female.All_Adults.none--none"),
  confBand: L("definition:optimal_band--leptin.male.All_Adults.none--none"),
  g6AgeDep: L("G6--uric_acid.male.All_Adults.none--none"),
  n1J5: L("N1--uric_acid.male.All_Adults.none--both"),
  n1LepM: L("N1--leptin.male.All_Adults.none--high"),
  bandUaM: L("definition:optimal_band--uric_acid.male.All_Adults.none--high"),
  ageUaM: L("definition:age_groups--uric_acid.male.All_Adults.none--low"),
};

// ─── Row keys ───
const K = {
  uaM: "uric_acid|male|All Adults|none",
  uaF: "uric_acid|female|All Adults|none",
  uaPreg: "uric_acid|female|All Adults|pregnancy",
  uaLact: "uric_acid|female|All Adults|lactation",
  lepM: "leptin|male|All Adults|none",
  lepF: "leptin|female|All Adults|none",
  adM: "adiponectin|male|All Adults|none",
  adF: "adiponectin|female|All Adults|none",
};

// ─── Texts ───
const T = {};

T.uaMethodM_en =
  "Echevarne B0025 (synonym AU1, test B0250 ÁCIDO ÚRICO / SUERO), UV-visible spectrophotometry (enzyme principle not stated: methods letter), serum in a gel tube; catalogue lines 88 (men 3.7-9.2 mg/dL) and 89 (women 3.1-7.8 mg/dL), ages 0-999, dated 01/06/2020 (line 87 'General' 3.1-9.2). EVA follows the printed interval (PLAN section 4). The named guideline threshold, 6.8 mg/dL (ACR 2020, f08-E13), is carried as an action limit, not as the ceiling (physician question F08-DQ-2). Men's optimal band: the ceiling of 6 mg/dL is the lowest-risk category for incident gout (adjusted HR 2.7 at 6.0-6.9 mg/dL against below 6 mg/dL, f08-E01). Men's all-cause mortality rose significantly only from 7 mg/dL (f08-E02; adjusted HR 1.18, 1.04-1.35, at 7.0-7.9 against 4.0-4.9 mg/dL, f08-E03), and a health-system cohort placed men's lowest mortality at 5.1-7.6 mg/dL (f08-E31), so the ceiling rests on gout and the mortality records are context. The floor is Echevarne's 3.7 mg/dL: men's excess mortality was significant only below 3.0 mg/dL (f08-E03) or 3.5 mg/dL (f08-E04), and in adults aged 65 and over the excess below 4 mg/dL was confined to malnourished participants (f08-E05); physician question F08-DQ-4. Urate is causal for gout (f08-E07) and, modestly, for coronary disease (f08-E08), but lowering it with a medicine did not reduce cardiovascular events in people aged 60 and over with heart disease (f08-E09), so the band is not a drug target. Critical limit 13 mg/dL (critical-limits.json entries[11]; f08-E11, f08-E12). Uric acid is the priority member of its own redundancy group (marker-classes.json). NHANES 2017-2018 measured urate on a Roche Cobas 6000 (CDC bridging difference 2.37%).";

T.uaMethodM_es =
  "Echevarne B0025 (sinónimo AU1, prueba B0250 ÁCIDO ÚRICO / SUERO), espectrofotometría ultravioleta-visible (principio enzimático no indicado: carta de métodos), suero en tubo con gel; líneas 88 (hombres 3,7-9,2 mg/dL) y 89 (mujeres 3,1-7,8 mg/dL) del catálogo, edades 0-999, fecha 01/06/2020 (línea 87 'General' 3,1-9,2). EVA sigue el intervalo impreso (PLAN, sección 4). El umbral con nombre de una guía, 6,8 mg/dL (ACR 2020, f08-E13), se aplica como límite de acción y no como techo (pregunta al médico F08-DQ-2). Banda óptima de los hombres: el techo de 6 mg/dL es la categoría de menor riesgo de gota incidente (HR ajustado 2,7 con 6,0-6,9 mg/dL frente a menos de 6 mg/dL, f08-E01). La mortalidad por cualquier causa de los hombres solo aumentó de forma significativa a partir de 7 mg/dL (f08-E02; HR ajustado 1,18, 1,04-1,35, con 7,0-7,9 frente a 4,0-4,9 mg/dL, f08-E03), y una cohorte del sistema sanitario situó la menor mortalidad de los hombres en 5,1-7,6 mg/dL (f08-E31), así que el techo se basa en la gota y los registros de mortalidad son contexto. El suelo es el 3,7 mg/dL de Echevarne: el exceso de mortalidad de los hombres solo fue significativo por debajo de 3,0 mg/dL (f08-E03) o de 3,5 mg/dL (f08-E04), y en adultos de 65 años o más el exceso por debajo de 4 mg/dL se limitó a los participantes malnutridos (f08-E05); pregunta al médico F08-DQ-4. El urato es causal de la gota (f08-E07) y, de forma modesta, de la enfermedad coronaria (f08-E08), pero bajarlo con un medicamento no redujo los episodios cardiovasculares en personas de 60 años o más con cardiopatía (f08-E09), así que la banda no es un objetivo farmacológico. Límite crítico 13 mg/dL (critical-limits.json entries[11]; f08-E11, f08-E12). El ácido úrico es el miembro prioritario de su propio grupo de redundancia (marker-classes.json). NHANES 2017-2018 midió el urato en un Roche Cobas 6000 (diferencia de puente de los CDC 2,37 %).";

T.uaMethodF_en =
  "Echevarne B0025 (synonym AU1, test B0250 ÁCIDO ÚRICO / SUERO), UV-visible spectrophotometry (enzyme principle not stated: methods letter), serum in a gel tube; catalogue lines 88 (men 3.7-9.2 mg/dL) and 89 (women 3.1-7.8 mg/dL), ages 0-999, dated 01/06/2020 (line 87 'General' 3.1-9.2). EVA follows the printed interval (PLAN section 4). The named guideline threshold, 6.8 mg/dL (ACR 2020, f08-E13), is carried as an action limit, not as the ceiling (physician question F08-DQ-2). Women's optimal band: the ceiling of 5 mg/dL is the upper edge of the categories within 10% of the lowest all-cause mortality (adjusted HR 1.05 at 3.0-3.9 mg/dL and 1.20, 1.06-1.37, at 5.0-5.9 mg/dL, against 4.0-4.9 mg/dL; f08-E02, f08-E03), below the lowest-risk gout category (below 6 mg/dL, f08-E01); the floor is Echevarne's 3.1 mg/dL (women's excess mortality only below 3.0 mg/dL, f08-E03, or 2.5 mg/dL, f08-E04). Urate is causal for gout (f08-E07) and, modestly, for coronary disease (f08-E08), but lowering it with a medicine did not reduce cardiovascular events in people aged 60 and over with heart disease (f08-E09), so the band is not a drug target. Critical limit 13 mg/dL (critical-limits.json entries[11]; f08-E11, f08-E12). Uric acid is the priority member of its own redundancy group (marker-classes.json). NHANES 2017-2018 measured urate on a Roche Cobas 6000 (CDC bridging difference 2.37%). Pregnancy and lactation: uric acid has no pregnancy or lactation row (removed in round 2); state-rules.md sections 2.1 and 2.4 apply one app rule to every marker, the laboratory interval and the fixed note with no optimal category, score or biological age, and the critical limit stays on. In 120 healthy pregnant women uric acid fell to about three quarters of its pre-pregnancy level at 8-12 weeks (median 201 against 278 µmol/L, about 3.4 against 4.7 mg/dL) and was back at that level at 36-40 weeks (281 µmol/L), when the upper reference limit was 464 µmol/L, about 7.8 mg/dL (f08-F01, full text Tables 2 and 3; 59.48 µmol/L per mg/dL, f08-E31). A higher uric acid measured before 20 weeks went with pre-eclampsia (pooled OR 1.46, 1.22-1.75, top against bottom quartile; f08-F02). Whether a value above the interval should still be flagged in pregnancy is physician question F08-DQ-1. No opened source gives uric acid after birth: the postpartum reference study names five other analytes still changed at six months and does not say whether uric acid was measured (f08-F03, the source of f08-E17).";

T.uaMethodF_es =
  "Echevarne B0025 (sinónimo AU1, prueba B0250 ÁCIDO ÚRICO / SUERO), espectrofotometría ultravioleta-visible (principio enzimático no indicado: carta de métodos), suero en tubo con gel; líneas 88 (hombres 3,7-9,2 mg/dL) y 89 (mujeres 3,1-7,8 mg/dL) del catálogo, edades 0-999, fecha 01/06/2020 (línea 87 'General' 3,1-9,2). EVA sigue el intervalo impreso (PLAN, sección 4). El umbral con nombre de una guía, 6,8 mg/dL (ACR 2020, f08-E13), se aplica como límite de acción y no como techo (pregunta al médico F08-DQ-2). Banda óptima de las mujeres: el techo de 5 mg/dL es el borde superior de las categorías a menos de un 10 % de la menor mortalidad por cualquier causa (HR ajustado 1,05 con 3,0-3,9 mg/dL y 1,20, 1,06-1,37, con 5,0-5,9 mg/dL, frente a 4,0-4,9 mg/dL; f08-E02, f08-E03), por debajo de la categoría de menor riesgo de gota (menos de 6 mg/dL, f08-E01); el suelo es el 3,1 mg/dL de Echevarne (exceso de mortalidad de las mujeres solo por debajo de 3,0 mg/dL, f08-E03, o de 2,5 mg/dL, f08-E04). El urato es causal de la gota (f08-E07) y, de forma modesta, de la enfermedad coronaria (f08-E08), pero bajarlo con un medicamento no redujo los episodios cardiovasculares en personas de 60 años o más con cardiopatía (f08-E09), así que la banda no es un objetivo farmacológico. Límite crítico 13 mg/dL (critical-limits.json entries[11]; f08-E11, f08-E12). El ácido úrico es el miembro prioritario de su propio grupo de redundancia (marker-classes.json). NHANES 2017-2018 midió el urato en un Roche Cobas 6000 (diferencia de puente de los CDC 2,37 %). Embarazo y lactancia: el ácido úrico no tiene fila de embarazo ni de lactancia (retiradas en la ronda 2); las secciones 2.1 y 2.4 de state-rules.md aplican una sola regla de la app a todos los marcadores, el intervalo del laboratorio y la nota fija sin categoría óptima, puntuación ni edad biológica, y el límite crítico sigue activo. En 120 embarazadas sanas el ácido úrico bajó a unas tres cuartas partes de su nivel previo al embarazo entre las semanas 8 y 12 (mediana 201 frente a 278 µmol/L, unos 3,4 frente a 4,7 mg/dL) y volvió a ese nivel entre las semanas 36 y 40 (281 µmol/L), cuando el límite superior de referencia era 464 µmol/L, unos 7,8 mg/dL (f08-F01, texto completo, tablas 2 y 3; 59,48 µmol/L por mg/dL, f08-E31). Un ácido úrico más alto medido antes de la semana 20 se asoció a la preeclampsia (OR combinada 1,46, 1,22-1,75, cuartil superior frente al inferior; f08-F02). Si un valor por encima del intervalo debe seguir señalándose en el embarazo es la pregunta al médico F08-DQ-1. Ninguna fuente abierta da el ácido úrico después del parto: el estudio de referencia del posparto nombra otros cinco analitos que siguen alterados a los seis meses y no dice si se midió el ácido úrico (f08-F03, la fuente de f08-E17).";

T.lepMethod_en =
  "Echevarne D0547 (synonym LEPTIA, test D0920 LEPTINA), ELISA (kit not named: methods letter), serum in a gel tube; catalogue line 283: one interval for both sexes ('General'), ages 14-999, 0.7-8.3 ng/mL, dated 22/06/2023 (line 282: ages 0-13.999, 0.7-7 ng/mL). Women have about three times the leptin of men (f08-E20, f08-E24) and a leptin interval needs sex and BMI (f08-E22), so most women in a representative Spanish population sample read above this printed interval (median 24.5 ng/mL, lower quartile 14.1 ng/mL, f08-E20), and so do between a quarter and a half of the men (median 7.2 ng/mL, upper quartile 14.3 ng/mL, f08-E20); a healthy-volunteer study found leptin the only one of its measurands with reference limits that differ by sex (f08-V01): physician question F08-DQ-3. Class d: no optimal band, not scored; leptin has no outcome band (all-cause mortality meta-analysis null overall, HR 1.028, 0.908-1.165, with higher risk in men, HR 1.162, and at 60 and over, HR 1.129, in subgroups and no level of lowest risk; f08-E21). No NHANES distribution exists for check N1.";

T.lepMethod_es =
  "Echevarne D0547 (sinónimo LEPTIA, prueba D0920 LEPTINA), ELISA (kit no indicado: carta de métodos), suero en tubo con gel; línea 283 del catálogo: un solo intervalo para ambos sexos ('General'), edades 14-999, 0,7-8,3 ng/mL, fecha 22/06/2023 (línea 282: edades 0-13,999, 0,7-7 ng/mL). Las mujeres tienen unas tres veces más leptina que los hombres (f08-E20, f08-E24) y un intervalo de leptina necesita sexo e IMC (f08-E22), así que la mayoría de las mujeres de una muestra representativa de la población española quedan por encima de este intervalo impreso (mediana 24,5 ng/mL, cuartil inferior 14,1 ng/mL, f08-E20), y también entre una cuarta parte y la mitad de los hombres (mediana 7,2 ng/mL, cuartil superior 14,3 ng/mL, f08-E20); un estudio en voluntarios sanos encontró que la leptina era la única de sus magnitudes con límites de referencia distintos por sexo (f08-V01): pregunta al médico F08-DQ-3. Clase d: sin banda óptima, no puntúa; la leptina no tiene banda basada en desenlaces (metaanálisis de mortalidad por cualquier causa nulo en conjunto, HR 1,028, 0,908-1,165, con más riesgo en hombres, HR 1,162, y a partir de los 60 años, HR 1,129, en subgrupos y sin un nivel de menor riesgo; f08-E21). No hay distribución de NHANES para la comprobación N1.";

// Row notes (bookkeeping fields)
T.uaNotesM =
  "Round 2 (fixer, 2026-11-08): bounds, grade and messages as verified; the method note now states the band's basis (ceiling from gout, mortality as context) and the age pass is stated below. Optimal ceiling 6 mg/dL: lowest-risk gout category (<6 mg/dL; gout HR 2.7 at 6.0-6.9 and 6.6 at 7.0-7.9 mg/dL, f08-E01). Men's all-cause mortality rose significantly only from 7 mg/dL (f08-E02; Konta 2020 Table 3, f08-E03: 5.0-5.9 mg/dL HR 1.06, 0.95-1.19; 6.0-6.9 HR 1.06, 0.95-1.19; 7.0-7.9 HR 1.18, 1.04-1.35), and the Irish health-system cohort placed the male optimum at 304-454 µmol/L, 5.1-7.6 mg/dL (f08-E31, contrary record): the ceiling rests on gout, not on mortality (judge J3, round 1). Floor 3.7 mg/dL: Echevarne's lower limit, supported by f08-E03, f08-E04 and f08-E05; against it, the within-10% rule that sets the female band puts the male floor at 4.0 on the same Japanese table (men 3.0-3.9 mg/dL adjusted HR 1.15, 0.97-1.36), and the Irish cohort found men below 238 µmol/L (4.0 mg/dL) at HR 2.35 (1.65-3.14): physician question F08-DQ-4, which replaces f08-Q02 and f08-VQ01. Sex split: Echevarne's sex-specific interval and a male mortality threshold 2 mg/dL above the female one (f08-E02, f08-E10). Age pass (checks C3 and E4): 18-19: Echevarne prints the interval for ages 0-999, so the adult row applies; the mortality cohorts behind the band edges cover ages 40-74 (f08-E02, f08-E03) and 65 and over (f08-E05), and no opened source gives an estimate for 18-19. 70-84: no split; in 127,771 adults aged 65 and over the lowest-risk stratum was 4 to <5 mg/dL, as at 40-74, and the excess below 4 mg/dL (HR 1.16, 1.07-1.25) was confined to malnourished participants (f08-E05, f08-E06), so 3.7-3.9 mg/dL reads optimal at every age; F08-DQ-4 offers 4.0 mg/dL from 65. ALL-HEART (mean age 72.0 years) found no cardiovascular benefit from lowering urate with a medicine (f08-E09). 85 and over: no opened source gives a separate estimate; the adult row applies. NHANES 2015-2018 healthy men (input bundle and check file): 1.0% of men aged 60-69 fall outside 3.7-9.2 mg/dL (1st and 99th percentiles 3.7 and 9.1 mg/dL, n 609), below N1's 2%; physician question F08-DQ-2 (replaces f08-Q01) carries the justification for n1-resolutions.json, and N1 flags no other uric acid cell. About 1-3% of healthy men are between 3.7 and 4.0 mg/dL (linear interpolation of the age-band percentiles). The 6.8 mg/dL action limit fires for about a quarter of healthy men (75th percentile 6.7-6.9 mg/dL by age band); physician question f08-VQ05 on its wording above the reference ceiling. Score v2 still uses URIC_ACID r(3, 6.0, null, 9) for men (longevity-score.ts line 232); WS3 aligns it with the signed row. Critical limit 13 mg/dL from the governance draft (critical-limits.json entries[11]); alternative 'none' (physician question f08-Q03).";

T.uaNotesF =
  "Round 2 (fixer, 2026-11-08): bounds, grade and messages as verified; the pregnancy and lactation rows are removed and their facts move to the method note (f08-F01, f08-F02, f08-F03); the method note states the band's basis per sex; the age pass is stated below. Optimal ceiling 5 mg/dL: within 10% of the lowest all-cause HR (women 3.0-3.9 mg/dL HR 1.05, 0.91-1.21; 4.0-4.9 reference; 5.0-5.9 HR 1.20, 1.06-1.37; f08-E02, f08-E03), consistent with the stronger association in women in the 2025 meta-analysis (RR 1.91 against 1.16 in men, f08-E10); gout risk is already low below 6 mg/dL (f08-E01). The source category 5.0-5.9 starts at 5.0 while EVA's classifier counts 5.0 as optimal (one reporting step); 4.9 would match the category exactly. Floor 3.1 mg/dL: Echevarne's lower limit; excess risk only below 3.0 mg/dL (f08-E03; below 2.9 mg/dL HR 1.52, 1.22-1.90) or 2.5 mg/dL (f08-E04). Menopause pass: menopause went with uric acid 0.34 to 0.36 mg/dL higher after adjustment (f08-E18), and the band comes from women aged 40-74 with a mean age of 62.4 years (f08-E03, Table 1), so no postmenopausal row. Hormone therapy and oral contraception: no row or flag (f08-E19: current postmenopausal hormone use went with uric acid 0.24 mg/dL lower, cross-sectional; state-rules.md section 4.2 does not list uric acid). Pregnancy and lactation pass: no state rows; state-rules.md sections 2.1 and 2.4 govern both (method note; physician question F08-DQ-1, which replaces f08-VQ02); the removed rows' messages remain in the verify file if the physician decides to classify in pregnancy or lactation. Age pass (checks C3 and E4): 18-19: Echevarne prints the interval for ages 0-999 and the adult row applies; no opened source gives an estimate for 18-19. 70-84: no split; the lowest-risk stratum at 65 and over was 4 to <5 mg/dL, sexes pooled (f08-E05, f08-E06). 85 and over: no opened estimate; the adult row applies. NHANES 2015-2018 healthy women (input bundle): optimal share 63.8% at 20-39 down to 44.2% at 70-79, so non-optimal at 70-79 is 55.8%, under N1's 60% trigger; N1 flags no female uric acid cell on 3.1-7.8 mg/dL. The 6.8 mg/dL action limit: physician question f08-VQ05. Wording for a mortality-derived band: physician question f08-VQ04. Score v2 still uses URIC_ACID r(2.5, 5, null, 8) for women (longevity-score.ts line 232); WS3 aligns it with the signed row. Critical limit 13 mg/dL from the governance draft (critical-limits.json entries[11]); alternative 'none' (physician question f08-Q03).";

T.lepNotesM =
  "Round 2 (fixer, 2026-11-08): row as verified; the method note now gives the male share and points to F08-DQ-3, which replaces f08-Q04. Male median 7.2 ng/mL (IQR 3.3-14.3) in 11,540 Spanish adults (f08-E20), so between a quarter and a half of that representative sample (not a healthy-reference sample) read above 8.3 ng/mL; the Spanish cut-off for cardiometabolic abnormality in men is 6.45 ng/mL (f08-E20, outcome-free cross-sectional). Age pass (check C3): Echevarne prints one interval from age 14 (line 283), which applies at 18-19, 70-84 and 85 and over; leptin was inversely associated with age in the Spanish sample (f08-E20), the European reference curves cover ages 0-75 and are specific to sex and BMI (f08-E22), and no opened source gives an adult age-specific limit or an estimate at 85 and over. Pregnancy and hormone states do not apply to this row. Display (confirmed ledger issue definition:optimal band, round 1): the row carries no optimal band and its in-range text names only the laboratory interval, but the app today labels every in-range value of a row without a band 'Optimal' / 'Optimo' and draws the whole interval as the optimal band (zone-classifier.ts line 90; zone-config.ts line 18; dashboard-client.tsx lines 1894-1895 and 1948; process-results.ts line 505), so men at 5-8.3 ng/mL, above optimal in production, read optimal until the in_range zone exists; that app change is proposed as a central item in the decision notes.";

T.lepNotesF =
  "Round 2 (fixer, 2026-11-08): row as verified; the method note points to F08-DQ-3, which replaces f08-Q04. Female median 24.5 ng/mL (IQR 14.1-37.0) in 11,540 Spanish adults (f08-E20): the 25th percentile is above Echevarne's ceiling, so most women in this representative sample (not a healthy-reference sample) would get the above-range message; physician question F08-DQ-3 (false-alarm hazard). Pregnancy pass: leptin rises through pregnancy (f08-E23); no pregnancy row, because state-rules.md section 2.1 shows the laboratory interval only in declared pregnancy; the above-range message names pregnancy as a cause. Menopause, hormone therapy and oral contraception: no row or flag; no opened source quantifies their effect on leptin. Age pass as for men: one Echevarne interval from age 14 applies at 18-19, 70-84 and 85 and over; no age-specific adult limit was opened. Display (confirmed ledger issue definition:marker classes, round 1): the row has no band, but the app labels in-range values 'Optimal' / 'Optimo' until the in_range zone exists (central item proposed in the decision notes).";

T.adNotesM =
  "Round 2 (fixer, 2026-11-08): row as verified. Sex split follows Echevarne's sex-specific intervals; women run higher (7.4 against 5.4 µg/mL, f08-E24). Age pass (check C3): Echevarne prints one interval for ages 0-999 (line 18), which applies at 18-19, 70-84 and 85 and over; adiponectin was positively correlated with age (r = 0.227, f08-E24), and no opened source gives an adult age-specific limit or an estimate at 85 and over. States: no pregnancy, lactation, menopause or hormone-therapy row; state-rules.md section 2.1 governs declared pregnancy and lactation, and no opened source quantifies the other effects. Display: the row has no band, but the app labels in-range values 'Optimal' / 'Optimo' until the in_range zone exists (central item proposed in the decision notes). Code D0412 is not mapped: physician question f08-Q05.";

T.adNotesF =
  "Round 2 (fixer, 2026-11-08): row as verified. Sex split follows Echevarne's sex-specific intervals (f08-E24). Age, state and display passes as for men: one Echevarne interval for ages 0-999 (line 19) applies at 18-19, 70-84 and 85 and over; no adult age-specific limit or estimate at 85 and over was opened. Code D0412 is not mapped: physician question f08-Q05.";

T.uaCvpM =
  "reference_high 7 -> 9.2 mg/dL: Echevarne's printed ceiling (PLAN section 4). Production's 7.0 was an epidemiological hyperuricaemia convention, not a named guideline limit; the named guideline threshold (ACR 2020, 6.8 mg/dL, f08-E13) is carried as a new action limit, and the alternatives are physician question F08-DQ-2. optimal_low 4 -> 3.7 (Echevarne's floor; no below-optimal band): the excess risk below 4 mg/dL was confined to malnourished older adults (f08-E05) and was significant only below 3.0 or 3.5 mg/dL in the two largest cohorts (f08-E03, f08-E04); physician question F08-DQ-4. Unchanged: reference_low 3.7, optimal_high 6. New: critical_high 13 mg/dL (critical-limits.json entries[11]), action limit above 6.8 mg/dL, pre-analytical rules, RCV inputs, messages rewritten (four elements, safety-net sentence; the production below-optimal text of 25 September falls away with the zone). Each bound change has a record in the decision file's changes.";

T.uaCvpF =
  "reference_high 6 -> 7.8 mg/dL: Echevarne's printed ceiling (PLAN section 4). Production's 6.0 was, in the September review's own caveat, 'a widely used epidemiological convention, not a formal guideline definition'; the named guideline threshold (ACR 2020, 6.8 mg/dL, f08-E13) is carried as a new action limit, and the alternatives are physician question F08-DQ-2. Unchanged: reference_low 3.1, optimal 3.1-5. New: critical_high 13 mg/dL (critical-limits.json entries[11]), action limit above 6.8 mg/dL, pre-analytical rules, RCV inputs, messages rewritten (four elements, safety-net sentence). No pregnancy or lactation row (state-rules.md sections 2.1 and 2.4). Each bound change has a record in the decision file's changes.";

// ─── Final rows ───
const order = [K.uaM, K.uaF, K.lepM, K.lepF, K.adM, K.adF];
const rows = order.map((k) => {
  const v = vrows.get(k);
  if (!v) throw new Error(`verify row missing: ${k}`);
  return clone(v);
});
const byKey = new Map(rows.map((r) => [key(r), r]));
Object.assign(byKey.get(K.uaM), { method_note: T.uaMethodM_en, method_note_es: T.uaMethodM_es, change_vs_production: T.uaCvpM, notes: T.uaNotesM });
Object.assign(byKey.get(K.uaF), { method_note: T.uaMethodF_en, method_note_es: T.uaMethodF_es, change_vs_production: T.uaCvpF, notes: T.uaNotesF });
Object.assign(byKey.get(K.lepM), { method_note: T.lepMethod_en, method_note_es: T.lepMethod_es, notes: T.lepNotesM });
Object.assign(byKey.get(K.lepF), { method_note: T.lepMethod_en, method_note_es: T.lepMethod_es, notes: T.lepNotesF });
Object.assign(byKey.get(K.adM), { notes: T.adNotesM });
Object.assign(byKey.get(K.adF), { notes: T.adNotesF });

// ─── Changes ───
const vr = (k, f) => vrows.get(k)[f];
const changes = [];
const ch = (row_key, field, from, to, direction, reason, evidence_ids, issue_ids) =>
  changes.push({ row_key, field, from, to, direction, reason, evidence_ids, issue_ids });

// Removed state rows
ch(K.uaPreg, "row",
  "present in the verify file: Echevarne female interval 3.1-7.8 mg/dL (B0025, catalogue line 89, ages 0-999), no optimal band, critical high 13 mg/dL, grade D, labels 'Pregnancy' / 'Embarazo'",
  null, "neutral",
  "Removed. PLAN.md section 4 gives declared pregnancy the laboratory interval only, with no optimal category, score or biological age, and docs/signoff/work/governance/state-rules.md section 2.1 makes that one app rule for every marker, with the fixed note and the critical tier on (section 2.2, 'Por qué una sola regla y no filas de embarazo'; trimester rows only once a gestational week is recorded, section 2.3). This row repeated the non-pregnant female interval because Echevarne prints no pregnancy band (B0025, catalogue lines 87-89), so check D3 found no catalogue band for it; it could never be picked, because src/lib/biomarkers/reference-row.ts (referenceRowFor) chooses rows by sex and age and 'Pregnancy' is not an age band (check C1; the app's reading of the declared state is central item C-08); it is not in production (check D5); and its Spanish label 'Embarazo' failed check D2. Families f01, f02 and f04 removed their state rows for the same reasons. Its pregnancy facts move to the method note of the female row, with their sources filed again on that row (f08-F01 and f08-F02, the sources and quotes of f08-E15 and f08-E16): in normal pregnancy uric acid falls to about three quarters of its pre-pregnancy level at 8-12 weeks, and a higher uric acid before 20 weeks goes with pre-eclampsia (pooled OR 1.46, 1.22-1.75). Whether a value above the interval should still be flagged in pregnancy, which this row's above-range message did, is physician question F08-DQ-1 (replaces f08-VQ02). The critical limit of 13 mg/dL stays on in pregnancy through rule 2.1. No client sees a difference today: the row was unreachable, and its messages remain in the verify file.",
  ["f08-F01", "f08-F02"],
  [I.c1Preg, I.d2Preg, I.d3Preg, I.d5Preg, I.g2Preg]);

ch(K.uaLact, "row",
  "present in the verify file: Echevarne female interval 3.1-7.8 mg/dL (B0025, catalogue line 89, ages 0-999), no optimal band, critical high 13 mg/dL, grade D, labels 'Lactation' / 'Lactancia'",
  null, "neutral",
  "Removed. docs/signoff/work/governance/state-rules.md section 2.4 applies the pregnancy rule of section 2.1 to declared lactation (laboratory interval and fixed note only, no optimal category, score or biological age, critical tier on) and leaves to the physician whether lactating women may be classified against the laboratory interval (draft recommendation: no). This row classified a breastfeeding woman against the non-lactating interval (Echevarne prints no lactation band), could never be picked (check C1; central item C-08), is not in production (check D5) and failed checks D2 ('Lactancia') and D3, like the pregnancy row. No opened source gives uric acid after birth: the postpartum reference study of 139 women followed to six months names alkaline phosphatase, chloride, GGT, sodium and urea as still changed at six months and does not say whether uric acid was measured (f08-F03, the source and quote of f08-E17, filed again on the female row). If the physician decides to classify in lactation, the general female row already carries Echevarne's interval and this row's messages remain in the verify file. No client sees a difference today: the row was unreachable.",
  ["f08-F03", "f08-E17"],
  [I.c1Lact, I.d2Lact, I.d3Lact, I.d5Lact, I.g2Lact]);

// Bounds against production (check D5)
ch(K.uaM, "reference_high", 7, vr(K.uaM, "reference_high"), "loosen",
  "Against production (the verify file already has 9.2; check D5 listed the difference without a reason). PLAN.md section 4 makes Echevarne's printed interval the reference interval and lets a guideline decision limit replace it only where a named guideline defines the threshold, copied exactly. Echevarne prints 3.7-9.2 mg/dL for men (B0025, catalogue line 88, ages 0-999). Production's 7.0 mg/dL is the epidemiological definition of hyperuricaemia, not a named guideline limit. The only named guideline threshold opened, the ACR 2020 definition of asymptomatic hyperuricaemia, 'an SU concentration of ≥6.8 mg/dl with no prior gout flares or subcutaneous tophi' (f08-E13, grade B), is carried as an action limit, with the same guideline's conditional recommendation against starting urate-lowering medicine at that level. What the wider interval changes for a man at 7.0-9.2 mg/dL: he reads above optimal, above the 6 mg/dL ceiling that rests on gout (adjusted HR 2.7 at 6.0-6.9 and 6.6 at 7.0-7.9 mg/dL against below 6 mg/dL, f08-E01, grade B), with the action-limit text above 6.8 mg/dL, instead of out of range. On production's ceiling 18.3% to 21.1% of healthy NHANES 2015-2018 men in each age band were above 7.0 mg/dL (input bundle shares on the production rows); on Echevarne's interval 1.0% of men aged 60-69 fall outside 3.7-9.2 mg/dL (check N1). The alternatives, 6.8 or 7.0 mg/dL as the ceiling, are physician question F08-DQ-2.",
  ["f08-E13", "f08-E01"], [I.d5UaM]);

ch(K.uaM, "optimal_low", 4, vr(K.uaM, "optimal_low"), "loosen",
  "Against production (the verify file already has 3.7; check D5 listed it and the compile flagged it as a loosening with no change record). The floor moves to Echevarne's lower limit, so men have no below-optimal band. Grade B quotes: in 500,511 Japanese adults aged 40-74 followed for 7 years, 'A significant increase in adjusted HR for all-cause mortality was observed with uric acid levels ≥7.0 mg/dL and <3.0 mg/dL in men' (f08-E03; Table 3: 3.0-3.9 mg/dL adjusted HR 1.15, 0.97-1.36, against 4.0-4.9 mg/dL); in 127,771 adults aged 65 and over, 'among the low SUA (<4 mg/dL) strata, only malnourished participants had greater all-cause and CVD-related mortality' (f08-E05), the only cohort here that handled reverse causation at the low end (PLAN section 5). The Korean cohort put the men's excess below 3.5 mg/dL (HR 1.58, 1.18-2.10; f08-E04, grade C). Against the change: by the within-10% rule that sets the women's band, the HR of 1.15 at 3.0-3.9 mg/dL keeps the floor at 4.0, and the Irish health-system cohort found men below 238 µmol/L (4.0 mg/dL) at HR 2.35 (1.65-3.14; f08-E31, grade C). About 1-3% of healthy NHANES 2015-2018 men are between 3.7 and 4.0 mg/dL (input bundle percentiles). Physician question F08-DQ-4 (replaces f08-Q02 and f08-VQ01) offers 4.0 mg/dL for all men or from age 65.",
  ["f08-E05", "f08-E03", "f08-E04", "f08-E31"], [I.d5UaM]);

const critReason =
  "Against production, which had no critical limit (the verify file already has 13 mg/dL; check D5 listed it without a reason). A critical limit is its own field and zone and is never derived from the reference interval (PLAN.md section 4). 13 mg/dL is the value of the governance draft docs/signoff/work/governance/critical-limits.json (entries[11], critical_high 13, recommendation 'High 13 mg/dL. Three sources agree'), which check L1 asks the row to equal (central item C-04). Opened sources: the eJIFCC critical-limits list, 'Uric acid > 13 mg/dl (773 mmol/l) Acute urate nephropathy with tubular blockade and renal failure' (f08-E11, PMC6178782 full text), and the 2024 survey of 50 US hospital lists, in which uric acid was on 8% of 2024 lists with a 2024 median of 13 mg/dL, range 10-13 (f08-E12, PMC11899349 full text, Table 1). The alternative, none, is physician question f08-Q03. The critical tier reaches the client only after the signed table and the contracted call path (central items C-04 and C-20).";
ch(K.uaM, "critical_high", null, vr(K.uaM, "critical_high"), "tighten", critReason, ["f08-E11", "f08-E12"], [I.d5UaM]);

ch(K.uaF, "reference_high", 6, vr(K.uaF, "reference_high"), "loosen",
  "Against production (the verify file already has 7.8; check D5 listed it without a reason). Echevarne prints 3.1-7.8 mg/dL for women (B0025, catalogue line 89, ages 0-999), and PLAN.md section 4 makes the printed interval the reference interval. Production's 6.0 mg/dL was, in the September review's own caveat, 'a widely used epidemiological convention, not a formal guideline definition' (input bundle). The only named guideline threshold opened, ACR 2020's 6.8 mg/dL for both sexes ('an SU concentration of ≥6.8 mg/dl', f08-E13, grade B), is carried as an action limit. What the wider interval changes for a woman at 6.0-7.8 mg/dL: she reads above optimal, above the 5 mg/dL ceiling (women's adjusted all-cause HR 1.20, 1.06-1.37, at 5.0-5.9 and 1.50, 1.26-1.78, at 6.0-6.9 mg/dL against 4.0-4.9 mg/dL, f08-E03, grade B; gout HR 2.7 at 6.0-6.9 mg/dL against below 6 mg/dL, f08-E01, grade B), with the action-limit text above 6.8 mg/dL, instead of out of range. On production's ceiling 21.0% and 25.2% of healthy NHANES 2015-2018 women aged 60-69 and 70-79 were above 6.0 mg/dL (input bundle shares on the production rows); on Echevarne's interval check N1 flags no female cell. The alternatives are physician question F08-DQ-2.",
  ["f08-E13", "f08-E03", "f08-E01"], [I.d5UaF]);

ch(K.uaF, "critical_high", null, vr(K.uaF, "critical_high"), "tighten", critReason, ["f08-E11", "f08-E12"], [I.d5UaF]);

const lepBand =
  "Leptin is class d (descriptive, not scored; docs/signoff/work/governance/marker-classes.json draft), and PLAN.md section 4 gives an optimal band only to class a markers with outcome evidence. No opened source gives a level of lowest risk: in a meta-analysis of 19 prospective studies with 16,208 people, 'no significant association was found between leptin and all-cause mortality (HR=1.028; 95% CI: 0.908-1.165; p=0.659)' (f08-E21, grade B); its subgroup associations (men HR 1.162, 1.036-1.302; age 60 and over HR 1.129, 1.030-1.238) compare higher with lower leptin and give no threshold.";
ch(K.lepM, "optimal_high", 5, vr(K.lepM, "optimal_high"), "loosen",
  `Against production (the verify file already has no band; check D5 listed the difference without a reason). ${lepBand} Production's 5 ng/mL ceiling had no opened source (September grade C, confidence low). The band is removed, not moved: leptin shows the laboratory interval only (Echevarne D0547, catalogue line 283, 0.7-8.3 ng/mL). Until the app has an in_range zone, an in-range value of a row with no band is labelled 'Optimal' (zone-classifier.ts line 90), so men at 5-8.3 ng/mL, above optimal in production, read optimal: that is the confirmed issue definition:optimal band, whose remaining part is the app change proposed in the decision notes.`,
  ["f08-E21"], [I.d5LepM, I.confBand]);
ch(K.lepM, "optimal_low", 0.7, vr(K.lepM, "optimal_low"), "loosen",
  `Against production (check D5). ${lepBand} The removed floor equalled Echevarne's lower limit (0.7 ng/mL, catalogue line 283), so values below it read below range as before and no value changes zone on this side.`,
  ["f08-E21"], [I.d5LepM, I.confBand]);
ch(K.lepF, "optimal_high", 8.3, vr(K.lepF, "optimal_high"), "loosen",
  `Against production (check D5). ${lepBand} Production's female band, 0.7-8.3 ng/mL, was Echevarne's interval (D0547, catalogue line 283) relabelled as optimal, and PLAN.md section 4 forbids an optimal bound that rests only on a laboratory interval. The removed bounds equalled the reference limits, so no value changes zone; the app's 'Optimal' label for in-range values of a row without a band is the confirmed issue definition:marker classes, whose remaining part is the app change proposed in the decision notes.`,
  ["f08-E21"], [I.d5LepF, I.confClass]);
ch(K.lepF, "optimal_low", 0.7, vr(K.lepF, "optimal_low"), "loosen",
  `Against production (check D5). ${lepBand} The removed floor equalled Echevarne's lower limit (0.7 ng/mL), so no value changes zone on this side.`,
  ["f08-E21"], [I.d5LepF, I.confClass]);

const adBand =
  "Adiponectin is class d (docs/signoff/work/governance/marker-classes.json draft) and has no outcome band: higher adiponectin goes with higher, not lower, mortality (pooled HR per standard deviation 1.24, 1.17-1.31, for all-cause mortality in 55 studies with 61,676 people; f08-E25, grade B), and Mendelian randomisation did not support a causal effect on heart failure, atrial fibrillation, aortic valve stenosis or myocardial infarction (two-sample risk ratios 0.99, 1.00, 1.01 and 0.99 in up to 1,030,836 people; f08-E26, grade A) and found no evidence of a causal effect on fasting insulin or type 2 diabetes (f08-E27, grade B).";
ch(K.adM, "optimal_high", 16.5, vr(K.adM, "optimal_high"), "loosen",
  `Against production (the verify file already has no band; check D5 listed it without a reason; the production-only marker enters the seed). ${adBand} Production's optimal ceiling of 16.5 µg/mL equalled Echevarne's upper limit (D0412, catalogue line 18), an optimal bound resting only on a laboratory interval, which PLAN.md section 4 does not allow. No value changes zone: above 16.5 µg/mL reads above range as before.`,
  ["f08-E26", "f08-E25", "f08-E27"], [I.d5AdipoM]);
ch(K.adF, "optimal_high", 23.35, vr(K.adF, "optimal_high"), "loosen",
  `Against production (the verify file already has no band; check D5 listed it without a reason; the production-only marker enters the seed). ${adBand} Production's optimal ceiling of 23.35 µg/mL equalled Echevarne's upper limit (D0412, catalogue line 19), an optimal bound resting only on a laboratory interval, which PLAN.md section 4 does not allow. No value changes zone: above 23.35 µg/mL reads above range as before.`,
  ["f08-E26", "f08-E25", "f08-E27"], [I.d5AdipoF]);

// Method notes (against the verify file)
ch(K.uaM, "method_note", vr(K.uaM, "method_note"), T.uaMethodM_en, "neutral",
  "Judge J3 (round 1, minor, definition:optimal band): the verified note called the 3.7-6 mg/dL band the lowest-risk range for gout and mortality, but men's mortality rose significantly only from 7 mg/dL (f08-E02, f08-E03) and the Irish health-system cohort put men's lowest mortality at 304-454 µmol/L, 5.1-7.6 mg/dL at 59.48 µmol/L per mg/dL (f08-E31); 6 mg/dL is the lowest-risk gout category (f08-E01). The note now states the ceiling's basis as gout, keeps the mortality records as context, states the floor's basis with the older-adult finding (f08-E05; judge J1, definition:age groups) and renames the questions (F08-DQ-2 replaces f08-Q01; F08-DQ-4 replaces f08-Q02 and f08-VQ01). Physician-facing text; no bound changes.",
  ["f08-E01", "f08-E02", "f08-E03", "f08-E31", "f08-E05"], [I.bandUaM, I.ageUaM]);
ch(K.uaM, "method_note_es", vr(K.uaM, "method_note_es"), T.uaMethodM_es, "neutral",
  "Spanish text of the method-note change above, with the same content and numbers in Spanish format.",
  ["f08-E01", "f08-E02", "f08-E03", "f08-E31", "f08-E05"], [I.bandUaM, I.ageUaM]);
ch(K.uaF, "method_note", vr(K.uaF, "method_note"), T.uaMethodF_en, "neutral",
  "Two changes. (1) The pregnancy and lactation rows are removed (records above), so their facts move here, with their sources filed again on this row (f08-F01, f08-F02 and f08-F03, the sources and quotes of f08-E15, f08-E16 and f08-E17, whose only rows are gone): in 120 healthy pregnant women uric acid fell to about three quarters of its pre-pregnancy level at 8-12 weeks (median 201 against 278 µmol/L) and was back at it by 36-40 weeks (281 µmol/L), when the upper reference limit was 464 µmol/L, about 7.8 mg/dL (full text Tables 2 and 3), and a higher uric acid before 20 weeks went with pre-eclampsia (pooled OR 1.46, 1.22-1.75). (2) The band's basis is stated per sex, as for men (judge J3, round 1): the women's ceiling of 5 mg/dL is the within-10% mortality edge (f08-E02, f08-E03), below the lowest-risk gout category (f08-E01). The questions are renamed (F08-DQ-1, F08-DQ-2). Physician-facing text; no bound changes.",
  ["f08-F01", "f08-F02", "f08-F03", "f08-E02", "f08-E03", "f08-E01", "f08-E31"], [I.g6AgeDep]);
ch(K.uaF, "method_note_es", vr(K.uaF, "method_note_es"), T.uaMethodF_es, "neutral",
  "Spanish text of the method-note change above, with the same content and numbers in Spanish format.",
  ["f08-F01", "f08-F02", "f08-F03", "f08-E02", "f08-E03", "f08-E01", "f08-E31"], [I.g6AgeDep]);
for (const k of [K.lepM, K.lepF]) {
  ch(k, "method_note", vr(k, "method_note"), T.lepMethod_en, "neutral",
    "Judge J1 (round 1, minor, N1 on the male row; J3 and J5 asked the same) asked for the male share: the note now says that between a quarter and a half of the men in the representative Spanish sample were above 8.3 ng/mL (median 7.2, upper quartile 14.3 ng/mL; f08-E20), and points to physician question F08-DQ-3, which replaces f08-Q04 and covers both sexes. The note is the same on both leptin rows. Physician-facing text; no bound changes.",
    ["f08-E20"], [I.n1LepM]);
  ch(k, "method_note_es", vr(k, "method_note_es"), T.lepMethod_es, "neutral",
    "Spanish text of the method-note change above, with the same content and numbers in Spanish format.",
    ["f08-E20"], [I.n1LepM]);
}

// ─── New evidence records ───
const rE = new Map(research.evidence.map((e) => [e.id, e]));
const e15 = rE.get("f08-E15"), e16 = rE.get("f08-E16"), e17 = rE.get("f08-E17");
const evidence = [
  {
    id: "f08-F01",
    supports: [{ row_key: K.uaF, bound: "state_split" }],
    identifier: clone(e15.identifier),
    citation: "Wu L, Wu Q, Li Q, et al. Consecutive reference intervals for biochemical indices related to serum lipid levels and renal function during normal pregnancy. BMC Pregnancy Childbirth 2022;22(1):642. PMID 35971117, PMCID PMC9377122 (state-rules.md source S2); full text opened through NCBI efetch on 2026-11-08 (the Europe PMC fullTextXML endpoint returned HTTP 500).",
    year: 2022,
    quote: e15.quote,
    location: "full text, results, uric acid paragraph; Table 2 (median uric acid 278 µmol/L before pregnancy, 201 at 8+1 to 12 weeks, 281 at 36+1 to 40 weeks) and Table 3 (upper reference limit 464 µmol/L at 36+1 to 40 weeks)",
    design: "longitudinal reference-interval study in normal pregnancy, ten time points from pre-pregnancy to 40 weeks",
    n: 120,
    follow_up_years: null,
    outcome: "serum uric acid through normal pregnancy (medians and reference limits by gestational age)",
    population_age: "healthy pregnant women aged 18 and over (China)",
    population_sex: "female",
    assay: "uricase colorimetry on an Abbott Architect C16000 analyser (full text, Table 1 and methods)",
    band_rule: "none",
    basis_class: "laboratory_interval",
    proposed_grade: "C",
    age_stratified_statement: "Not age-stratified; stratified by gestational week.",
    notes: "Same source and quote as f08-E15 (verifier: confirmed, grade C), filed again on the female row in round 2 because the pregnancy row it supported was removed (state-rules.md section 2.1). It supports the pregnancy facts in the female row's method note and physician question F08-DQ-1, not a bound: in declared pregnancy the app shows the laboratory interval only. 464 µmol/L is about 7.8 mg/dL at 59.48 µmol/L per mg/dL (f08-E31).",
  },
  {
    id: "f08-F02",
    supports: [{ row_key: K.uaF, bound: "state_split" }],
    identifier: clone(e16.identifier),
    citation: e16.citation,
    year: e16.year,
    quote: e16.quote,
    location: "abstract",
    design: "case-control study (1,365 cases, 1,886 normotensive controls) and meta-analysis of three prospective cohorts with uric acid measured before 20 weeks",
    n: 3251,
    follow_up_years: null,
    outcome: "pre-eclampsia",
    population_age: "primigravid women",
    population_sex: "female",
    assay: "serum uric acid (method not given in the abstract)",
    band_rule: "none",
    basis_class: e16.basis_class,
    proposed_grade: "C",
    age_stratified_statement: "Not age-stratified; early and late pre-eclampsia showed the same association.",
    notes: "Same source and quote as f08-E16 (verifier: confirmed, grade C), filed again on the female row in round 2 because the pregnancy row it supported was removed. The abstract also gives an adjusted OR of 1.21 (1.11-1.33) per standard deviation of uric acid in the case-control part. It supports the pregnancy facts in the female row's method note and physician question F08-DQ-1, not a bound.",
  },
  {
    id: "f08-F03",
    supports: [{ row_key: K.uaF, bound: "state_split" }],
    identifier: clone(e17.identifier),
    citation: e17.citation,
    year: e17.year,
    quote: e17.quote,
    location: "abstract",
    design: "longitudinal reference-interval study, pregnancy weeks 18, 28 and 36 and 6 weeks, 4 months and 6 months postpartum, with never-pregnant controls",
    n: 198,
    follow_up_years: 0.5,
    outcome: "biochemical reference values in pregnancy and the first six postpartum months",
    population_age: "healthy pregnant and never-pregnant women (Norway)",
    population_sex: "female",
    assay: "routine serum chemistry (not detailed in the abstract)",
    band_rule: "none",
    basis_class: "laboratory_interval",
    proposed_grade: "C",
    age_stratified_statement: "Not age-stratified.",
    notes: "Same source and quote as f08-E17 (verifier: confirmed, grade C), filed again on the female row in round 2 because the lactation row it supported was removed. 139 healthy women and 59 never-pregnant controls. The abstract names alkaline phosphatase, chloride, GGT, sodium and urea as still changed at six months postpartum and does not say whether uric acid was among the 23 parameters, so no uric-acid-specific lactation source was opened; it supports the lactation sentence of the female row's method note, not a bound.",
  },
];

// ─── Physician questions ───
const physician_questions = [
  {
    id: "F08-DQ-1",
    row_key: K.uaF,
    question: "Uric acid in pregnancy: the pregnancy and lactation rows are removed in round 2, so a declared pregnancy follows docs/signoff/work/governance/state-rules.md section 2.1 for uric acid as for every marker: the laboratory interval and the fixed note only, with no out-of-range message, while the critical limit of 13 mg/dL stays on. Keep the rule as written for uric acid, or amend section 2.1 so that in pregnancy a uric acid above the reference interval (7.8 mg/dL) still shows an above-range message, with a signed line asking for same-day contact with the maternity unit if there are symptoms such as headache, changes in vision, pain under the ribs or new swelling? Decide it together with F02-DQ-1 (ALT and AST), so that one rule holds across families.",
    why: "In 120 healthy pregnant women uric acid fell to about three quarters of its pre-pregnancy level at 8-12 weeks (median 201 against 278 µmol/L) and was back at that level at 36-40 weeks (281 µmol/L), when the upper reference limit was 464 µmol/L, about 7.8 mg/dL, Echevarne's female ceiling (f08-F01, full text Tables 2 and 3; 59.48 µmol/L per mg/dL, f08-E31). A value above 7.8 mg/dL is therefore above that study's upper reference limit at every stage of pregnancy (299 to 464 µmol/L, about 5.0 to 7.8 mg/dL, by gestational period). A higher uric acid goes with pre-eclampsia: adjusted OR 1.21 (1.11-1.33) per standard deviation in 1,365 cases and 1,886 controls, and a pooled OR of 1.46 (1.22-1.75) for the top against the bottom quartile in three cohorts that measured it before 20 weeks (f08-F02, grade C). Under rule 2.1 such a value below 13 mg/dL gets only the fixed note, which sends the results to the obstetrician or midwife. The wording rules keep same-day language for the critical tier, so a same-day symptom line outside it needs your signature. Low values are common early in pregnancy: at 8-12 weeks the lower quartile was 174 µmol/L, about 2.9 mg/dL, below Echevarne's floor of 3.1 mg/dL (f08-F01), and rule 2.1 keeps them from being flagged. The app reads no declared state today (central item C-08), so either answer is implemented in the app, not in these rows. Replaces f08-VQ02, whose premise (the pregnancy row's 'next few weeks' message) no longer exists.",
    evidence_ids: ["f08-F01", "f08-F02", "f08-E31"],
    options: [
      "Keep state-rules.md 2.1 as written for uric acid: no classification in pregnancy; the fixed note sends the results to the obstetrician or midwife; the critical limit of 13 mg/dL stays on",
      "Amend 2.1 for uric acid: above 7.8 mg/dL, show the above-range message in pregnancy too, with the signed same-day symptom line",
      "Decide together with F02-DQ-1 one rule for every marker whose raised value pregnancy does not explain",
    ],
  },
  {
    id: "F08-DQ-2",
    row_key: K.uaM,
    question: "Uric acid reference ceiling, now with check N1 (replaces f08-Q01): keep Echevarne's printed ceilings, 9.2 mg/dL for men and 7.8 mg/dL for women, with the ACR 2020 hyperuricaemia threshold of 6.8 mg/dL as an action limit, and accept that 1.0% of healthy men aged 60-69 fall outside 3.7-9.2 mg/dL where N1 asks for 2% to 15%; or make 6.8 mg/dL the ceiling for both sexes as a guideline decision limit; or keep production's 7.0 mg/dL (men) and 6.0 mg/dL (women)?",
    why: "PLAN section 4 makes Echevarne's printed interval the reference interval unless a named guideline defines the threshold, copied exactly. The only named guideline threshold opened is the ACR 2020 definition of asymptomatic hyperuricaemia, 'an SU concentration of ≥6.8 mg/dl with no prior gout flares or subcutaneous tophi', and the same guideline conditionally recommends against starting urate-lowering medicine at that level (f08-E13, full text). Production's 7.0 and 6.0 mg/dL have no opened guideline source. Check N1 (docs/signoff/work/checks/f08_uric_acid_metabolic-r1.json) flags one uric acid cell on Echevarne's interval: healthy men aged 60-69 in NHANES 2015-2018, 1.0% outside 3.7-9.2 mg/dL (n 609; 1st and 99th percentiles 3.7 and 9.1 mg/dL, input bundle); it flags no other uric acid cell. The alternatives miss N1 the other way: on production's rows the share outside the interval was 18.9% to 22.4% in every male age band and 15.9%, 15.0%, 26.0% and 29.2% in women aged 20-39, 40-59, 60-69 and 70-79 (input bundle shares on the production rows), and about a quarter of healthy men are above 6.8 mg/dL (75th percentile 6.7-6.9 mg/dL by age band). Whatever the ceiling, men above 6 mg/dL and women above 5 mg/dL read above optimal, and above 6.8 mg/dL the ACR action-limit text applies. Justification offered for docs/signoff/work/nhanes/n1-resolutions.json, which this file cannot write (central item C-14): 'Echevarne's printed interval is binding under PLAN section 4 (B0025, catalogue line 88: men 3.7-9.2 mg/dL, ages 0-999). In NHANES 2015-2018 healthy men aged 60-69 the 99th percentile is 9.1 mg/dL, so 1.0% fall outside the interval. Values from 6 mg/dL up to the ceiling are still flagged as above optimal, and from 6.8 mg/dL they get the ACR 2020 action-limit text. NHANES 2017-2018 measured urate on a Roche Cobas 6000, with a CDC bridging difference of 2.37%.'",
    evidence_ids: ["f08-E13", "f08-E01", "f08-E03"],
    options: [
      "Echevarne 3.7-9.2 mg/dL (men) and 3.1-7.8 mg/dL (women), action limit above 6.8 mg/dL, with the N1 justification above (author, verifier and this fixer)",
      "ACR 2020 decision limit 6.8 mg/dL as the ceiling for both sexes, lower limits from Echevarne (about a quarter of healthy men out of range)",
      "Production 7.0 mg/dL (men) and 6.0 mg/dL (women), recorded as an exception to PLAN section 4 (more than 15% outside in every male age band and in women aged 20-39, 60-69 and 70-79)",
    ],
  },
  {
    id: "F08-DQ-3",
    row_key: K.lepF,
    question: "Leptin, for women and men (replaces f08-Q04 and extends it to men): Echevarne prints one interval for both sexes, 0.7-8.3 ng/mL from age 14. Keep it for both sexes, with messages that explain the sex difference, and ask Echevarne for its ELISA kit's sex- and BMI-specific intervals; or show leptin as a value only, with no in-range or out-of-range label, in women or in both sexes, until Echevarne answers; or use a sex-specific population interval?",
    why: "In 11,540 adults representing the Spanish population aged 18 and over, measured by ELISA in a central laboratory, the median was 24.5 ng/mL (interquartile range 14.1-37.0) in women and 7.2 ng/mL (3.3-14.3) in men (f08-E20). So more than three quarters of the women and between a quarter and a half of the men in that sample were above 8.3 ng/mL; the sample is the general population, not a healthy-reference sample, so the healthy-adult share is not known, and NHANES has no leptin for check N1. Women had higher leptin than men in every adult BMI category in 12,629 people from 16 European cohorts aged 0-75 (f08-E22), and a healthy-volunteer biological-variation study found leptin the only one of its measurands whose reference limits differed between sexes (f08-V01). Leptin has no outcome band: in a meta-analysis of 19 prospective studies (16,208 people) all-cause mortality was not associated overall (HR 1.028, 0.908-1.165), with higher risk in men (HR 1.162, 1.036-1.302) and at 60 and over (HR 1.129, 1.030-1.238) in subgroups and no level of lowest risk (f08-E21). Leptin is class d and not scored, so a label only describes body fat; an above-range label on most women and on many men is a false-alarm hazard. A population interval would need reference_basis population_study and sex- and BMI-specific limits (f08-E22), against PLAN section 4's rule that the reference interval is the laboratory's. Round-1 AI judges J2 and J5 proposed the value-only display for women until Echevarne answers; J1 and J3 offered it, with a sex-specific population interval as the alternative.",
    evidence_ids: ["f08-E20", "f08-E22", "f08-V01", "f08-E21", "f08-E24"],
    options: [
      "Keep Echevarne 0.7-8.3 ng/mL for both sexes with the explanatory messages, and request the kit's sex-specific intervals in the methods letter (research proposal)",
      "Value only, no in-range or out-of-range label, for women until Echevarne answers; men keep the interval (interim proposal of the round-1 AI judges)",
      "Value only for both sexes until Echevarne answers",
      "A sex-specific population interval (reference_basis population_study), against PLAN section 4",
    ],
  },
  {
    id: "F08-DQ-4",
    row_key: K.uaM,
    question: "Men's uric acid optimal floor, at every age and from 65 (replaces f08-Q02 and f08-VQ01): keep 3.7 mg/dL, Echevarne's lower limit, so men have no below-optimal band and 3.7-3.9 mg/dL reads optimal at every age; restore production's 4.0 mg/dL for all men; or keep 3.7 mg/dL under 65 and use 4.0 mg/dL from 65?",
    why: "In 500,511 Japanese adults aged 40-74 followed for 7 years, men at 3.0-3.9 mg/dL had an adjusted all-cause HR of 1.15 (0.97-1.36) against 4.0-4.9 mg/dL, not significant but 15% above the reference, and men below 2.9 mg/dL 1.49 (1.12-1.98) (f08-E03, full text Table 3); by the within-10% rule that sets the women's band, the men's floor would be 4.0 mg/dL. In 375,163 Korean adults the men's excess began below 3.5 mg/dL (HR 1.58, 1.18-2.10; f08-E04, grade C). In 127,771 adults aged 65 and over, all-cause mortality was higher below 4 mg/dL than at 4 to <5 mg/dL (HR 1.16, 1.07-1.25), but 'among the low SUA (<4 mg/dL) strata, only malnourished participants had greater all-cause and CVD-related mortality' (f08-E05, f08-E06); it is the only cohort here that handled reverse causation at the low end, which PLAN section 5 asks for. A health-system cohort found men below 238 µmol/L (4.0 mg/dL) at HR 2.35 (1.65-3.14), in patients whose illness can itself lower urate (f08-E31, grade C). So a low uric acid in older men marks poor nutrition rather than a level to raise; the below-range message names poor nutrition, but 3.7-3.9 mg/dL reads optimal. The change from production's 4.0 to 3.7 is a loosening resting on the grade B records f08-E03 and f08-E05. In NHANES 2015-2018 about 1% to 3% of healthy men are between 3.7 and 4.0 mg/dL, by linear interpolation of the age-band percentiles (input bundle).",
    evidence_ids: ["f08-E03", "f08-E04", "f08-E05", "f08-E06", "f08-E31"],
    options: [
      "3.7 mg/dL at every adult age, no below-optimal band for men (author, verifier and this fixer)",
      "4.0 mg/dL at every adult age, as in production, by the within-10% rule, as a grade C decision-table entry",
      "3.7 mg/dL under 65 and 4.0 mg/dL from 65 (an age split resting on f08-E05 and f08-E06), with a below-optimal message that names poor nutrition and weight loss",
    ],
  },
];

// ─── Issues addressed ───
const issues_addressed = [
  I.c1Lact, I.c1Preg, I.d2Lact, I.d2Preg, I.d3Lact, I.d3Preg,
  I.d5AdipoF, I.d5AdipoM, I.d5LepF, I.d5LepM, I.d5UaF, I.d5Lact, I.d5Preg, I.d5UaM,
  I.g2AdipoF, I.g2AdipoM, I.g2LepF, I.g2LepM, I.g2Lact, I.g2UaF, I.g2Preg, I.g2UaM,
  I.n1Script, I.confClass, I.confBand,
  I.g6AgeDep, I.n1J5, I.n1LepM, I.bandUaM, I.ageUaM,
].sort();

// Rows traced by final rows (G2): record nothing extra; the ids sit in issues_addressed.

const notes = fs.readFileSync(path.join(__dirname, "notes.txt"), "utf8").trim().replace(/\{VERIFY_SHA\}/g, verifySha);

const doc = {
  schema_version: "1",
  family: FAM,
  round: 2,
  decided_at: "2026-11-08",
  verify_sha256: verifySha,
  fixer_role: "physician fixer, round 2, batch B02 (AI work product for review by a licensed physician)",
  final_rows: rows,
  changes,
  issues_addressed,
  evidence,
  physician_questions,
  notes,
};

fs.writeFileSync(outFile, JSON.stringify(doc, null, 2) + "\n");
console.log(`wrote ${outFile}: ${rows.length} rows, ${changes.length} changes, ${issues_addressed.length} issues, ${evidence.length} evidence, ${physician_questions.length} questions`);
