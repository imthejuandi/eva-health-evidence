// Evidence repair, round 2, f07_apolipoproteins: re-copy the four Echevarne catalogue quotes exactly from the
// vendored file (tabs kept) and append the repair note. Touches only quote and notes of f07-E15, E20, E21, E33.
"use strict";
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = "/home/user/eva-health";
const FILE = path.join(ROOT, "docs/signoff/work/research/f07_apolipoproteins.json");
const TSV = path.join(ROOT, "docs/vendor/echevarne/catalogo-2026-08-25.tsv");
const TSV_SHA = "0539eedaa44caf2a85c700c6d4fa37ceb3c5c2ee76f96820471c784783f856e0";

const tsvBuf = fs.readFileSync(TSV);
const sha = crypto.createHash("sha256").update(tsvBuf).digest("hex");
if (sha !== TSV_SHA) throw new Error(`vendored catalogue hash ${sha} differs from the cited ${TSV_SHA}`);
const lines = tsvBuf.toString("utf8").split("\n");

const OLD_PAREN = "(tab-separated; the quote collapses the tabs and empty fields to single spaces)";
const NEW_PAREN = "(tab-separated; the quote is the line copied exactly, tabs included)";

const COMMON_HEAD = "Evidence repair, round 2, 8 November 2026:";
const GRADE_TAIL = "The identifier is unchanged. Under PLAN section 5 a source that cannot be opened is grade D; this pass changes no grade, which is the verifier's to set.";

const SEARCH_URL = "https://wwws.echevarne.com/csp/web/CLNSUBBuscaCataleg2ESP04.csp?term=LIPOPROTE&idLang=CAS&familia=0&subfamilia=0&clinica=checked";
const plan = {
  "f07-E15": {
    line: 84,
    note: `${COMMON_HEAD} check E2 counts this source unopenable, and it still is: the URL returned HTTP 404 to quote-check.js in this pass. A laboratory catalogue has no PubMed or Europe PMC record to switch to. Two web searches in this pass looked for a public Echevarne page that prints the interval. The first found no Echevarne page. The second found Echevarne's public online test catalogue (https://wwws.echevarne.com/csp/web/ESP04CatalegInternet.csp?idLang=CAS, whose page script sends browsers to laboratorioechevarne.com/pages/catalogo-analisis-clinicos). Its search (${SEARCH_URL}) lists test B3110 'APOLIPOPROTEÍNA B / SUERO', but the catalogue opens a test's details only in a session-bound view with no stable address, so it cannot be an identifier the script opens; those details were not read in this pass. The quote is now line 84 copied exactly, tabs included. The earlier quote wrote the tabs as single spaces, and the repository's normaliser reads a space between a digit and three final digits as a thousands separator, so '46 142' became the one number 46142: against line 84 the earlier quote scored 0.963 with 46142 missing, which would be a weak match if the source were readable. The new quote matches line 84 exactly with the repository's normaliser (file sha256 ${TSV_SHA}). ${GRADE_TAIL}`,
  },
  "f07-E20": {
    line: 81,
    note: `${COMMON_HEAD} as f07-E15. Check E2 counts this source unopenable, and it still is (HTTP 404 to quote-check.js in this pass); a laboratory catalogue has no PubMed or Europe PMC record to switch to; Echevarne's public online catalogue lists test B3100 'APOLIPOPROTEÍNA A / SUERO' but has no stable per-test address (see f07-E15). The quote is now line 81 copied exactly, tabs included. With the tabs written as spaces, the earlier quote read '79 169' as the one number 79169 under the repository's normaliser (score 0.96 against line 81, 79169 missing). The new quote matches line 81 exactly with the repository's normaliser (file sha256 ${TSV_SHA}). ${GRADE_TAIL}`,
  },
  "f07-E21": {
    line: 82,
    note: `${COMMON_HEAD} as f07-E15. Check E2 counts this source unopenable, and it still is (HTTP 404 to quote-check.js in this pass); a laboratory catalogue has no PubMed or Europe PMC record to switch to; Echevarne's public online catalogue lists test B3100 'APOLIPOPROTEÍNA A / SUERO' but has no stable per-test address (see f07-E15). The quote is now line 82 copied exactly, tabs included. With the tabs written as spaces, the earlier quote read '76 214' as the one number 76214 under the repository's normaliser (score 0.96 against line 82, 76214 missing). The new quote matches line 82 exactly with the repository's normaliser (file sha256 ${TSV_SHA}). ${GRADE_TAIL}`,
  },
  "f07-E33": {
    line: 304,
    note: `${COMMON_HEAD} as f07-E15. Check E2 counts this source unopenable, and it still is (HTTP 404 to quote-check.js in this pass); a laboratory catalogue has no PubMed or Europe PMC record to switch to; Echevarne's public online catalogue lists test B7700 'LIPOPROTEÍNA A / SUERO' but has no stable per-test address (see f07-E15). The earlier quote already matched line 304 exactly with the repository's normaliser (the field after '<50' is the date, which the normaliser does not fuse with it); it is re-copied with its tabs so that the four catalogue quotes are all literal copies of their lines. The new quote matches line 304 exactly with the repository's normaliser (file sha256 ${TSV_SHA}). ${GRADE_TAIL}`,
  },
};

const text = fs.readFileSync(FILE, "utf8");
const doc = JSON.parse(text);
if (JSON.stringify(doc, null, 1) + "\n" !== text) throw new Error("research file does not round-trip with indent 1");

for (const [id, p] of Object.entries(plan)) {
  const ev = doc.evidence.find((e) => e.id === id);
  if (!ev) throw new Error(`missing ${id}`);
  const lineText = lines[p.line - 1];
  if (!lineText) throw new Error(`no line ${p.line}`);
  if (ev.location !== `catalogue line ${p.line}`) throw new Error(`${id}: location ${ev.location} is not line ${p.line}`);
  if (!ev.notes.includes(OLD_PAREN)) throw new Error(`${id}: parenthetical not found in notes`);
  if (ev.notes.includes(COMMON_HEAD)) throw new Error(`${id}: already repaired`);
  ev.quote = lineText;
  ev.notes = `${ev.notes.replace(OLD_PAREN, NEW_PAREN)} ${p.note}`;
}

fs.writeFileSync(FILE, JSON.stringify(doc, null, 1) + "\n");
console.log("written", FILE);
