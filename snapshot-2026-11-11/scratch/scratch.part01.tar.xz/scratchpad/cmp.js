const en=require("/home/user/eva-health/docs/signoff/work/compiled/B02-r1/biomarker-ranges-en.json").biomarker_ranges;
const es=require("/home/user/eva-health/docs/signoff/work/compiled/B02-r1/rangos-biomarcadores-es.json").rangos_biomarcadores;
const idx=[88,89,91,92,183,93,94,95,184,185,132,142,145,149];
const pairs=[["Clinical_Notes","Notas_Clínicas"],["Msg_Critical_Low","Msg_Crítico_Bajo"],["Msg_Below_Optimal","Msg_Debajo_Óptimo"],["Msg_Optimal","Msg_Óptimo"],["Msg_Above_Optimal","Msg_Encima_Óptimo"],["Msg_Critical_High","Msg_Crítico_Alto"],["Critical_None_Reason","Motivo_Sin_Crítico"],["Reference_Source","Fuente_Referencia"],["Method_Note","Nota_Método"]];
function nums(s,lang){ if(!s) return []; let t=String(s); if(lang==="es"){ t=t.replace(/(\d)\.(\d{3})(?!\d)/g,"$1$2").replace(/(\d),(\d)/g,"$1.$2"); } else { t=t.replace(/(\d),(\d{3})(?!\d)/g,"$1$2"); } return (t.match(/\d+(\.\d+)?/g)||[]).map(Number); }
for (const i of idx){ const a=en[i], b=es[i];
  const keyEn=[a.Biomarker,a.Sex,a.Age_Group,a.State].join("|"), keyEs=[b.Biomarcador,b.Sexo,b.Grupo_Edad,b.Estado].join("|");
  const bnd=["Normal_Low","Normal_High","Optimal_Low","Optimal_High","Critical_Low","Critical_High"].map(k=>a[k]).join(",");
  const bndEs=["Normal_Bajo","Normal_Alto","Óptimo_Bajo","Óptimo_Alto","Crítico_Bajo","Crítico_Alto"].map(k=>b[k]).join(",");
  console.log("#",i,keyEn," <> ",keyEs, bnd===bndEs?"bounds ok":"BOUNDS DIFFER "+bnd+" vs "+bndEs, "class",a.Marker_Class,b.Clase_Marcador, "basis",a.Reference_Basis,b.Base_Referencia, "expl", JSON.stringify(a.Explanatory_Numbers), JSON.stringify(b.Números_Explicativos));
  for (const [ke,ks] of pairs){ const ne=nums(a[ke],"en").sort((x,y)=>x-y), ns=nums(b[ks],"es").sort((x,y)=>x-y); const se=JSON.stringify(ne), ss=JSON.stringify(ns); if (se!==ss) console.log("   ",ke,"EN",se," ES",ss); }
}
