import sys, os, re, ssl, time, urllib.request, urllib.parse, json
import xml.etree.ElementTree as ET
DATA = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/bioage-research/ml-recent-clocks"
CTX = ssl.create_default_context(cafile="/root/.ccr/ca-bundle.crt")
def get(url, tries=4):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 research-script"})
            with urllib.request.urlopen(req, context=CTX, timeout=90) as r:
                return r.read()
        except Exception as e:
            sys.stderr.write(f"retry {i} {e}\n"); time.sleep(2 + 3 * i)
    raise RuntimeError("failed " + url)

def fulltext(pmcid):
    p = os.path.join(DATA, f"{pmcid}.xml")
    if not os.path.exists(p):
        raw = None
        try:
            raw = get(f"https://www.ebi.ac.uk/europepmc/webservices/rest/{pmcid}/fullTextXML")
        except Exception as e:
            sys.stderr.write(f"EPMC failed {e}; trying NCBI efetch pmc\n")
            raw = get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?" + urllib.parse.urlencode({"db": "pmc", "id": pmcid.replace("PMC", ""), "retmode": "xml"}))
        open(p, "wb").write(raw)
    raw = open(p, "rb").read()
    root = ET.fromstring(raw)
    # paragraphs, titles, table cells
    out = []
    for el in root.iter():
        tag = el.tag
        if tag in ("title", "p", "td", "th", "caption", "label", "aff", "kwd"):
            t = " ".join("".join(el.itertext()).split())
            if t:
                out.append(f"<{tag}> {t}")
    txt = "\n".join(out)
    open(os.path.join(DATA, f"{pmcid}.txt"), "w").write(txt)
    return txt

if __name__ == "__main__":
    pmcid = sys.argv[1]
    txt = fulltext(pmcid)
    if len(sys.argv) > 2:
        pat = re.compile(sys.argv[2], re.I)
        ctx = int(sys.argv[3]) if len(sys.argv) > 3 else 0
        lines = txt.split("\n")
        for i, l in enumerate(lines):
            if pat.search(l):
                print(f"[{i}] " + l[:1500])
    else:
        print(txt[:3000])
        print(f"... total chars {len(txt)}")
