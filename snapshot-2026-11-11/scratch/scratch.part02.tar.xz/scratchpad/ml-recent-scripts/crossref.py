import sys, json, time, ssl, urllib.request, urllib.parse, os
D = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/bioage-research/ml-recent-clocks"
CTX = ssl.create_default_context(cafile="/root/.ccr/ca-bundle.crt")
out = {}
for doi in sys.argv[1:]:
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi)
    for i in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "research-script (mailto:none)"})
            with urllib.request.urlopen(req, context=CTX, timeout=60) as r:
                d = json.load(r)["message"]
            break
        except Exception as e:
            d = None; time.sleep(2)
    if d:
        out[doi] = {"count": d.get("is-referenced-by-count"), "title": (d.get("title") or [""])[0][:90], "container": (d.get("container-title") or [""])[0][:40]}
        print(f"{doi} | cited-by {d.get('is-referenced-by-count')} | {(d.get('container-title') or [''])[0][:40]} | {(d.get('title') or [''])[0][:90]}")
    else:
        print(f"{doi} | FAILED")
    time.sleep(0.5)
json.dump(out, open(os.path.join(D, "crossref_counts.json"), "w"), indent=1)
