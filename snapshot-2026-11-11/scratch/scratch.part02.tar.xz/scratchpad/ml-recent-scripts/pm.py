import sys, os, json, time, ssl, urllib.request, urllib.parse, hashlib
import xml.etree.ElementTree as ET

DATA = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/bioage-research/ml-recent-clocks"
CTX = ssl.create_default_context(cafile="/root/.ccr/ca-bundle.crt")
BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

def get(url, tries=4):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 research-script"})
            with urllib.request.urlopen(req, context=CTX, timeout=60) as r:
                return r.read()
        except Exception as e:
            sys.stderr.write(f"retry {i} {e}\n")
            time.sleep(2 + 3 * i)
    raise RuntimeError("failed " + url)

def save(name, data):
    p = os.path.join(DATA, name)
    with open(p, "wb") as f:
        f.write(data)
    return p

def search(term, retmax=40):
    q = urllib.parse.urlencode({"db": "pubmed", "term": term, "retmax": retmax, "retmode": "json", "sort": "relevance"})
    raw = get(BASE + "esearch.fcgi?" + q)
    h = hashlib.md5(term.encode()).hexdigest()[:10]
    save(f"esearch_{h}.json", raw)
    d = json.loads(raw)
    ids = d["esearchresult"]["idlist"]
    cnt = d["esearchresult"]["count"]
    print(f"QUERY: {term}\nCOUNT: {cnt}")
    if not ids:
        return
    time.sleep(0.4)
    q2 = urllib.parse.urlencode({"db": "pubmed", "id": ",".join(ids), "retmode": "json"})
    raw2 = get(BASE + "esummary.fcgi?" + q2)
    save(f"esummary_{h}.json", raw2)
    s = json.loads(raw2)["result"]
    for i in ids:
        r = s.get(i, {})
        print(f"{i} | {r.get('pubdate','')[:4]} | {r.get('source','')} | {r.get('title','')[:160]} | {r.get('sortfirstauthor','')}")

def text(el):
    return "".join(el.itertext()).strip() if el is not None else ""

def fetch(pmids, show_abs=True, maxabs=4000):
    q = urllib.parse.urlencode({"db": "pubmed", "id": ",".join(pmids), "retmode": "xml"})
    raw = get(BASE + "efetch.fcgi?" + q)
    save(f"efetch_{'_'.join(pmids)[:80]}.xml", raw)
    root = ET.fromstring(raw)
    for art in root.findall(".//PubmedArticle"):
        pmid = text(art.find(".//MedlineCitation/PMID"))
        title = text(art.find(".//ArticleTitle"))
        journal = text(art.find(".//Journal/Title"))
        year = text(art.find(".//JournalIssue/PubDate/Year")) or text(art.find(".//JournalIssue/PubDate/MedlineDate"))
        doi = ""; pmc = ""
        for aid in art.findall(".//PubmedData/ArticleIdList/ArticleId"):
            if aid.get("IdType") == "doi": doi = aid.text
            if aid.get("IdType") == "pmc": pmc = aid.text
        print("=" * 100)
        print(f"PMID {pmid} | {year} | {journal}\nTITLE: {title}\nDOI: {doi} | PMC: {pmc}")
        auths = []
        affs_all = []
        for a in art.findall(".//AuthorList/Author"):
            nm = (text(a.find("LastName")) + " " + text(a.find("Initials"))).strip() or text(a.find("CollectiveName"))
            affs = [text(x) for x in a.findall(".//AffiliationInfo/Affiliation")]
            auths.append(nm)
            for af in affs:
                affs_all.append((nm, af))
        print("AUTHORS: " + ", ".join(auths[:40]) + (" ..." if len(auths) > 40 else ""))
        spain = [f"{n}: {af}" for n, af in affs_all if any(k in af for k in ["Spain", "España", "Madrid", "Barcelona", "Valencia", "Sevilla", "Seville", "Navarra", "Granada", "Bilbao", "Zaragoza", "Salamanca", "Murcia", "Málaga", "Malaga", "Santiago de Compostela", "Oviedo", "Toledo", "CIBER"])]
        print("SPANISH AFFILIATIONS: " + (" || ".join(spain) if spain else "none"))
        countries = sorted(set(af.split(",")[-1].strip().rstrip(".") for _, af in affs_all))
        print("AFFIL LAST TOKENS: " + "; ".join(countries[:40]))
        if show_abs:
            ab = " ".join((("[" + x.get("Label") + "] ") if x.get("Label") else "") + text(x) for x in art.findall(".//Abstract/AbstractText"))
            print("ABSTRACT: " + ab[:maxabs])

if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "search":
        search(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 40)
    elif cmd == "fetch":
        fetch(sys.argv[2].split(","))
    elif cmd == "fetchnoabs":
        fetch(sys.argv[2].split(","), show_abs=False)
