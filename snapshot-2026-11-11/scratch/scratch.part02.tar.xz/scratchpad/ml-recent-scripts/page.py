import sys, re, html, os, subprocess
D = "/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/bioage-research/ml-recent-clocks"
url, name = sys.argv[1], sys.argv[2]
pat = sys.argv[3] if len(sys.argv) > 3 else None
width = int(sys.argv[4]) if len(sys.argv) > 4 else 350
p = os.path.join(D, name + ".html")
r = subprocess.run(["curl", "-sS", "-L", "-m", "60", "-A", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36", "-o", p, "-w", "%{http_code} %{size_download} %{url_effective}", url], capture_output=True, text=True)
print("HTTP:", r.stdout, r.stderr[:200])
t = open(p, encoding="utf-8", errors="ignore").read()
t = re.sub(r"<script.*?</script>|<style.*?</style>|<noscript.*?</noscript>", " ", t, flags=re.S | re.I)
t = html.unescape(re.sub(r"<[^>]+>", " ", t))
t = re.sub(r"\s+", " ", t)
open(os.path.join(D, name + ".txt"), "w").write(t)
print("TEXT CHARS:", len(t))
if pat:
    seen = 0
    for m in re.finditer(pat, t, flags=re.I):
        print("...", t[max(0, m.start() - width): m.end() + width], "\n")
        seen += 1
        if seen > 12: break
else:
    print(t[:2500])
