// Independent read-only check of origin/main's KDM v2.2 on synthetic values. No database.
import { computeReferenceBA, computeComprehensiveBA } from "./src/lib/biomarkers/biological-age-kdm";
type In = { code: string; value: number };
const man45: In[] = [
  { code: "albumin", value: 45 }, { code: "alp", value: 75 }, { code: "hs_crp", value: 1.0 },
  { code: "creatinine", value: 1.0 }, { code: "bun", value: 14 }, { code: "uric_acid", value: 5.5 },
  { code: "total_cholesterol", value: 195 }, { code: "hdl_cholesterol", value: 50 }, { code: "triglycerides", value: 110 },
  { code: "apolipoprotein_b_apob", value: 95 }, { code: "alt", value: 24 }, { code: "ggt", value: 24 },
];
const fmt = (r: { BA: number; n_markers_used?: number } | null) => (r ? `${r.BA.toFixed(1)} (n=${r.n_markers_used ?? "?"})` : "null");
for (const [label, extra] of [
  ["no glycation marker", [] as In[]],
  ["HbA1c 5.4 %", [{ code: "hba1c", value: 5.4 }]],
  ["fructosamine 150", [{ code: "fructosamine", value: 150 }]],
  ["fructosamine 200", [{ code: "fructosamine", value: 200 }]],
  ["fructosamine 230", [{ code: "fructosamine", value: 230 }]],
] as const) {
  const panel = [...man45, ...extra];
  console.log(label.padEnd(22), "lab page", fmt(computeReferenceBA(panel, "male", 45, null) as never), " dashboard", fmt(computeComprehensiveBA(panel, "male", 45, null) as never));
}
