/**
 * Server/edge observability bootstrap (OPS-001).
 *
 * Env-gated: without SENTRY_DSN (or NEXT_PUBLIC_SENTRY_DSN) this registers
 * nothing and the app behaves exactly as before — safe to ship ahead of the
 * Sentry account existing.
 *
 * IMPORTANT: NEVER send health data (biomarker values, lab results, wearable
 * metrics, chat messages) to Sentry. Only errors + user id / subscription
 * status for debugging. beforeSend strips known health keys defensively.
 */
import * as Sentry from "@sentry/nextjs";

const dsn = process.env.SENTRY_DSN ?? process.env.NEXT_PUBLIC_SENTRY_DSN;

export function register() {
  if (!dsn) return;
  Sentry.init({
    dsn,
    tracesSampleRate: 0.1,
    beforeSend(event) {
      if (event.extra) {
        delete event.extra.biomarkers;
        delete event.extra.labResults;
        delete event.extra.wearableData;
        delete event.extra.chatMessages;
        delete event.extra.healthData;
      }
      return event;
    },
  });
}

export const onRequestError = dsn ? Sentry.captureRequestError : undefined;
