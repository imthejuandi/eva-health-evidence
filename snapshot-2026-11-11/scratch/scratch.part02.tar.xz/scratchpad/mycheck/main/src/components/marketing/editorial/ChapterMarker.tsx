import { cn } from "@/lib/utils";

/**
 * ChapterMarker — the `§ 01 — The dispatch` mono label that opens
 * every section on the landing page.
 *
 * The label sits above section headlines as a typographic
 * "preface", establishing the magazine chapter rhythm that the
 * .impeccable.md design doctrine calls for ("Editorial rhythm
 * over grid rigour. Sections are chapters, not feature cards.").
 *
 * Usage:
 *   <ChapterMarker>{t.chapter01}</ChapterMarker>
 *   <ChapterMarker align="center" color="jade">{t.chapter05}</ChapterMarker>
 *
 * The component renders a plain `<p>` — wrap it in a
 * framer-motion element (e.g. motion.div) if you want a
 * fade-up on scroll reveal.
 */
interface ChapterMarkerProps {
  /** The label text, e.g. "§ 01 — The dispatch" */
  children: React.ReactNode;
  /** Text alignment. Default "left". */
  align?: "left" | "center";
  /**
   * Accent color. Default "terra" (for cream backgrounds).
   * Use "terra-light" on dark sections (Reckoning § 03,
   * FinalCall § 07) where plain terra loses too much contrast.
   */
  color?: "terra" | "terra-light" | "jade" | "muted";
  /** Additional Tailwind classes merged at the end. */
  className?: string;
}

export function ChapterMarker({
  children,
  align = "left",
  color = "terra",
  className,
}: ChapterMarkerProps) {
  return (
    <p
      className={cn(
        // Font + size — DM Mono 10px uppercase, tight tracking.
        // Unchanged from the landing's existing marker style.
        "font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px]",
        // Color
        color === "terra" && "text-[#97472c]",
        color === "terra-light" && "text-[#d97b5c]",
        color === "jade" && "text-[#3a665e]",
        color === "muted" && "text-[#8a7f76]",
        // Alignment
        align === "center" && "text-center",
        className,
      )}
    >
      {children}
    </p>
  );
}
