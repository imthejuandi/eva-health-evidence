/**
 * Editorial primitives — the reusable typographic + layout
 * building blocks for the marketing surface.
 *
 * These were extracted from the landing page after the bold
 * redesign so that `/about`, `/how-it-works`, `/pricing`,
 * `/science`, `/contact`, and `/blog` can inherit the same
 * voice without duplicating class-string spaghetti across
 * six files. See `.impeccable.md` for the design doctrine
 * these primitives embody.
 *
 * All of them are framework-light: plain `<p>` / `<h2>` /
 * `<section>` wrappers with carefully-tuned Tailwind class
 * lists, plus variant props where the landing uses more than
 * one shape of the same pattern. Framer-motion is only pulled
 * into HandDrawnUnderline because it needs scroll-linked
 * pathLength animation; every other primitive is
 * render-static so consumers can layer motion (or not) at
 * the call site.
 */

export { ChapterMarker } from "./ChapterMarker";
export {
  HeroHeadline,
  SectionHeadline,
  SubHeadline,
} from "./DisplayHeading";
export { LedeItalic } from "./LedeItalic";
export { BodyProse } from "./BodyProse";
export { SectionShell } from "./SectionShell";
export { HandDrawnUnderline } from "./HandDrawnUnderline";
export { BiomarkerSpecimen, ZoneLegendTrack } from "./BiomarkerSpecimen";
export type { Zone } from "./BiomarkerSpecimen";
