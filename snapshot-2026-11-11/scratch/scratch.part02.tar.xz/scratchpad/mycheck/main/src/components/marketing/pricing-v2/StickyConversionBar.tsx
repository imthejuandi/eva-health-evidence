"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

interface StickyConversionBarProps {
  heroSelector?: string;
  label: string;
  price: string;
  priceSuffix?: string;
  ctaLabel: string;
  onCta: () => void;
  loading?: boolean;
  dismissLabel: string;
}

const EASE_EXPO: [number, number, number, number] = [0.16, 1, 0.3, 1];

export function StickyConversionBar({
  heroSelector = "[data-pricing-hero]",
  label,
  price,
  priceSuffix,
  ctaLabel,
  onCta,
  loading = false,
  dismissLabel,
}: StickyConversionBarProps) {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (dismissed) return;
    const hero = document.querySelector(heroSelector);
    if (!hero) return;

    const observer = new IntersectionObserver(
      ([entry]) => setVisible(!entry.isIntersecting),
      { threshold: 0, rootMargin: "-100px 0px 0px 0px" },
    );
    observer.observe(hero);
    return () => observer.disconnect();
  }, [heroSelector, dismissed]);

  return (
    <AnimatePresence>
      {visible && !dismissed && (
        <motion.div
          initial={reduce ? { opacity: 0 } : { y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={reduce ? { opacity: 0 } : { y: 80, opacity: 0 }}
          transition={{ duration: 0.42, ease: EASE_EXPO }}
          className="fixed inset-x-0 bottom-[var(--space-lg)] z-50 flex justify-center px-[var(--space-lg)]"
        >
          <div className="flex w-full max-w-[720px] items-center gap-[var(--space-md)] bg-[var(--color-eva-ink)] py-[var(--space-sm)] pl-[var(--space-lg)] pr-[var(--space-sm)] text-white md:gap-[var(--space-xl)] md:pl-[var(--space-xl)]">
            <div className="min-w-0 flex-1">
              <div
                className={cn(
                  "font-[family-name:var(--font-dm-mono)] text-[9.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-mint)]",
                )}
              >
                {label}
              </div>
              <div className="mt-[2px] flex items-baseline gap-[var(--space-xs)]">
                <span
                  className="truncate font-[family-name:var(--font-sentient)] text-[24px] font-medium leading-none tracking-[-0.02em] text-white md:text-[28px]"
                  style={{ fontVariantNumeric: "tabular-nums" }}
                >
                  {price}
                </span>
                {priceSuffix && (
                  <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.18em] text-white/55">
                    {priceSuffix}
                  </span>
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={onCta}
              disabled={loading}
              className={cn(
                "group/bar inline-flex items-center gap-[var(--space-sm)] bg-[var(--color-eva-terra)] px-[var(--space-lg)] py-[var(--space-md)] font-[family-name:var(--font-manrope)] text-[13px] font-semibold tracking-[0.01em] text-white transition-colors hover:bg-[var(--color-eva-terra-deep)] disabled:opacity-60",
              )}
            >
              {loading ? "· · ·" : ctaLabel}
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden className="transition-transform duration-[220ms] group-hover/bar:translate-x-0.5">
                <path d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <button
              type="button"
              onClick={() => setDismissed(true)}
              aria-label={dismissLabel}
              className="flex h-8 w-8 shrink-0 items-center justify-center text-white/50 transition-colors hover:text-white"
            >
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
                <path d="M3 3L9 9M9 3L3 9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
