import Link from "next/link";

interface MarketingFooterProps {
  locale: string;
}

export function MarketingFooter({ locale }: MarketingFooterProps) {
  const t =
    locale === "es"
      ? { tagline: "Salud preventiva de precision, impulsada por la ciencia.", howItWorks: "Como Funciona", science: "Ciencia", pricing: "Precios", about: "Nosotros", privacy: "Politica de Privacidad", terms: "Terminos del Servicio", cookies: "Politica de Cookies", followUs: "Siguenos" }
      : { tagline: "Precision preventative health, powered by science.", howItWorks: "How It Works", science: "Science", pricing: "Pricing", about: "About", privacy: "Privacy Policy", terms: "Terms of Service", cookies: "Cookie Policy", followUs: "Follow our journey" };

  const navLinks = [
    { label: t.howItWorks, href: `/${locale}/how-it-works` },
    { label: t.science, href: `/${locale}/science` },
    { label: t.pricing, href: `/${locale}/pricing` },
    { label: t.about, href: `/${locale}/about` },
  ];

  const legalLinks = [
    { label: t.privacy, href: `/${locale}/legal/privacy` },
    { label: t.terms, href: `/${locale}/legal/terms` },
    { label: t.cookies, href: `/${locale}/legal/cookies` },
  ];

  return (
    <footer className="w-full bg-eva-surface">
      <div className="mx-auto max-w-7xl px-6 py-20 sm:px-10 md:px-16 md:py-28 lg:px-20">
        {/* Top divider */}
        <div className="mb-16 h-px w-full bg-eva-on-surface/[0.06]" />

        <div className="grid gap-14 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link href={`/${locale}`} className="flex items-baseline gap-1.5">
              <span className="font-[family-name:var(--font-logo)] text-2xl font-light lowercase tracking-[-0.5px] text-eva-on-surface">eva</span>
              <span className="font-heading text-lg font-bold uppercase tracking-[0.06em] text-eva-terra">Health</span>
            </Link>
            <p className="mt-4 max-w-[260px] text-[14px] leading-[1.7] text-eva-on-surface-dim">
              {t.tagline}
            </p>
          </div>
          <div className="flex flex-col gap-3.5">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-[14px] font-medium text-eva-on-surface-muted transition-colors duration-500 hover:text-eva-terra"
                style={{ transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)" }}
              >
                {link.label}
              </Link>
            ))}
          </div>
          <div className="flex flex-col gap-3.5">
            {legalLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-[14px] text-eva-on-surface-dim transition-colors duration-500 hover:text-eva-terra"
                style={{ transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)" }}
              >
                {link.label}
              </Link>
            ))}
            <a
              href="mailto:hello@evahealth.es"
              className="mt-3 font-mono text-[11px] tracking-[0.05em] text-eva-on-surface-dim transition-colors duration-500 hover:text-eva-terra"
              style={{ transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)" }}
            >
              hello@evahealth.es
            </a>
          </div>
          <div>
            <p className="font-heading text-[13px] font-semibold uppercase tracking-[0.12em] text-eva-on-surface-muted">{t.followUs}</p>
            <div className="mt-5 flex gap-3">
              {[
                { label: "Email", href: "mailto:hello@evahealth.es", icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                )},
                { label: "Blog", href: `/${locale}/blog`, icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"><path d="M7 7h10v10"/><path d="M7 17 17 7"/></svg>
                )},
              ].map(({ label, href, icon }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full text-eva-on-surface-dim ring-1 ring-eva-on-surface/[0.06] transition-all duration-500 hover:text-eva-terra hover:ring-eva-terra/20"
                  style={{ transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)" }}
                >
                  {icon}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 flex items-center justify-between border-t border-eva-on-surface/[0.06] pt-7">
          <p className="font-mono text-[11px] tracking-[0.05em] text-eva-on-surface-dim">&copy; {new Date().getFullYear()} EVA Health &middot; Madrid</p>
        </div>
      </div>
    </footer>
  );
}
