"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { useParams } from "next/navigation";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const params = useParams();
  const locale = (params.locale as string) ?? "es";

  const t =
    locale === "es"
      ? {
          message: "Usamos cookies para mejorar tu experiencia.",
          accept: "Aceptar",
          manage: "Gestionar",
          policy: "Politica de Cookies",
        }
      : {
          message: "We use cookies to improve your experience.",
          accept: "Accept",
          manage: "Manage",
          policy: "Cookie Policy",
        };

  useEffect(() => {
    const consent = localStorage.getItem("eva-cookie-consent");
    if (!consent) {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  function accept() {
    localStorage.setItem("eva-cookie-consent", "accepted");
    setVisible(false);
  }

  function manage() {
    localStorage.setItem("eva-cookie-consent", "managed");
    setVisible(false);
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="fixed bottom-0 left-0 right-0 z-[9998] px-4 pb-4 md:px-8 md:pb-6"
        >
          <div className="mx-auto flex max-w-4xl flex-col items-center gap-4 rounded-2xl bg-white/95 px-6 py-5 shadow-[0_-8px_40px_rgba(29,27,24,0.08)] backdrop-blur-xl sm:flex-row sm:justify-between">
            <p className="text-center font-[family-name:var(--font-inter)] text-[13px] text-[#4c463f] sm:text-left">
              {t.message}{" "}
              <Link
                href={`/${locale}/legal/cookies`}
                className="font-medium text-[#97472c] underline underline-offset-2"
              >
                {t.policy}
              </Link>
            </p>
            <div className="flex shrink-0 gap-3">
              <button
                onClick={manage}
                className="rounded-full border border-[#e7e2dc] px-5 py-2 font-[family-name:var(--font-inter)] text-[13px] font-medium text-[#4c463f] transition-colors hover:bg-[#f8f3ed]"
              >
                {t.manage}
              </button>
              <button
                onClick={accept}
                className="rounded-full bg-gradient-to-br from-[#97472c] to-[#d97b5c] px-5 py-2 font-[family-name:var(--font-inter)] text-[13px] font-semibold text-white shadow-[0_4px_16px_rgba(151,71,44,0.2)]"
              >
                {t.accept}
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
