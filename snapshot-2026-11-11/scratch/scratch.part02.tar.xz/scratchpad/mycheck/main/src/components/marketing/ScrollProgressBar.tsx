"use client";

import { motion, useReducedMotion, useScroll, useSpring } from "framer-motion";

/**
 * Thin fixed scroll-progress bar pinned to the top of the viewport.
 * Uses a spring to smooth the progress value so it glides rather than
 * tracking scroll 1:1. Respects prefers-reduced-motion by rendering a
 * static invisible state.
 */
export function ScrollProgressBar() {
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, {
    stiffness: 140,
    damping: 28,
    restDelta: 0.001,
  });

  if (reduce) return null;

  return (
    <motion.div
      aria-hidden
      className="pointer-events-none fixed inset-x-0 top-0 z-30 h-[2px] origin-left"
      style={{
        scaleX: progress,
        background:
          "linear-gradient(90deg, rgba(151,71,44,0.85) 0%, rgba(196,147,50,0.85) 50%, rgba(58,102,94,0.85) 100%)",
        transformOrigin: "0%",
      }}
    />
  );
}
