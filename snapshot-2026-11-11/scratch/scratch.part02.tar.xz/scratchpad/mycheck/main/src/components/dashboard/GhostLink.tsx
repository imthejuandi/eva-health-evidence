"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

type Intent = "default" | "danger";

interface GhostLinkProps {
  children: ReactNode;
  onClick?: () => void;
  href?: string;
  intent?: Intent;
}

/**
 * GhostLink — secondary text link used alongside the dark
 * `PrimaryPill`. Manrope semibold, underlined with a 6px offset,
 * decoration warmth varies by intent (default → ink, danger →
 * terra-red).
 */
export function GhostLink({ children, onClick, href, intent = "default" }: GhostLinkProps) {
  const colour = intent === "danger" ? "text-[#b04040]" : "text-[#4c463f]";
  const decoration =
    intent === "danger"
      ? "decoration-[#b04040]/30"
      : "decoration-[#1d1b18]/20";
  const hoverColour =
    intent === "danger"
      ? "hover:text-[#8a2020] hover:decoration-[#b04040]/60"
      : "hover:text-[#1d1b18] hover:decoration-[#1d1b18]/60";
  const cls = `${FONT_CLASS.manrope} text-[13px] font-medium ${colour} underline ${decoration} underline-offset-[6px] transition-colors ${hoverColour} focus-visible:outline-none focus-visible:rounded-sm focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-[#fef8f2] focus-visible:ring-[#97472c]/60`;
  if (href) {
    return (
      <Link href={href} className={cls}>
        {children}
      </Link>
    );
  }
  return (
    <button type="button" onClick={onClick} className={cls}>
      {children}
    </button>
  );
}
