"use client";

import {
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";

/**
 * Generic scroll-snap carousel — a horizontally scrolling row where
 * each child snaps to the container's start. Native browser scrolling
 * (no JS pointer capture, no fight with vertical page scroll), with
 * dot indicators and prev/next arrows wired to scrollTo for
 * non-touch users.
 *
 * The active index is read FROM the scroll position via
 * IntersectionObserver, never driven into it — the source of truth
 * stays in the browser's scroll engine. Dots and counter always
 * reflect what the user actually sees, including mid-swipe.
 *
 * The native scrollbar is hidden via globals.css
 * (.scroll-snap-carousel::-webkit-scrollbar { display: none }).
 *
 * Usage:
 *   <ScrollSnapCarousel
 *     count={items.length}
 *     renderItem={(i) => <Card item={items[i]} />}
 *     renderCounter={(active, total) => `${active+1}/${total}`}
 *   />
 */
export function ScrollSnapCarousel({
  count,
  renderItem,
  className = "",
  itemClassName = "",
  itemWidthClass = "w-full",
  gapClass = "gap-4 md:gap-6",
  showDots = true,
  showArrows = true,
  showCounter = false,
  arial,
  onIndexChange,
}: {
  count: number;
  renderItem: (index: number) => ReactNode;
  className?: string;
  itemClassName?: string;
  /** Width class for each item. Default `"w-full"` (one card per view).
   *  Pass a responsive class like `"w-[88%] md:w-[44%]"` to show
   *  partial peek of the next card. */
  itemWidthClass?: string;
  /** Tailwind gap utility for between cards. */
  gapClass?: string;
  showDots?: boolean;
  showArrows?: boolean;
  showCounter?: boolean;
  /** Override aria-label on each dot button. */
  arial?: (i: number) => string;
  onIndexChange?: (i: number) => void;
}) {
  const [index, setIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || count === 0) return;
    const observer = new IntersectionObserver(
      (entries) => {
        let bestIdx = -1;
        let bestRatio = 0;
        for (const entry of entries) {
          if (entry.isIntersecting && entry.intersectionRatio > bestRatio) {
            const idx = cardRefs.current.indexOf(entry.target as HTMLElement);
            if (idx !== -1) {
              bestRatio = entry.intersectionRatio;
              bestIdx = idx;
            }
          }
        }
        if (bestIdx !== -1) {
          setIndex(bestIdx);
          onIndexChange?.(bestIdx);
        }
      },
      { root: container, threshold: [0.5, 0.75, 0.95] },
    );
    cardRefs.current.forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, [count, onIndexChange]);

  const scrollToIndex = (i: number) => {
    const card = cardRefs.current[i];
    const container = containerRef.current;
    if (!card || !container) return;
    container.scrollTo({ left: card.offsetLeft, behavior: "smooth" });
  };

  if (count === 0) return null;

  return (
    <>
      {showCounter && (
        <p
          className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] md:text-[11px]"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {String(index + 1).padStart(2, "0")} /{" "}
          {String(count).padStart(2, "0")}
        </p>
      )}

      <div
        ref={containerRef}
        className={`scroll-snap-carousel flex snap-x snap-mandatory overflow-x-auto pb-3 ${gapClass} ${className}`}
        style={{
          scrollPadding: "0 4px",
          scrollbarWidth: "none",
          WebkitOverflowScrolling: "touch",
        }}
      >
        {Array.from({ length: count }).map((_, i) => (
          <div
            key={i}
            ref={(el) => {
              cardRefs.current[i] = el;
            }}
            className={`${itemWidthClass} shrink-0 snap-start ${itemClassName}`}
          >
            {renderItem(i)}
          </div>
        ))}
      </div>

      {(showDots || showArrows) && (
        <div className="mt-6 flex items-center justify-between gap-6 md:mt-8">
          {showDots ? (
            <div className="flex items-center gap-2">
              {Array.from({ length: count }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  aria-label={arial?.(i) ?? `Go to ${i + 1}`}
                  onClick={() => scrollToIndex(i)}
                  className="group p-1"
                >
                  <span
                    aria-hidden
                    className="block h-[3px] rounded-full transition-[width,background-color] duration-300"
                    style={{
                      width: i === index ? 32 : 16,
                      backgroundColor:
                        i === index ? "#1d1b18" : "rgba(29,27,24,0.2)",
                    }}
                  />
                </button>
              ))}
            </div>
          ) : (
            <span />
          )}

          {showArrows && (
            <div className="flex items-center gap-2">
              <CarouselArrow
                direction="prev"
                onClick={() => scrollToIndex(Math.max(0, index - 1))}
                disabled={index === 0}
              />
              <CarouselArrow
                direction="next"
                onClick={() =>
                  scrollToIndex(Math.min(count - 1, index + 1))
                }
                disabled={index === count - 1}
              />
            </div>
          )}
        </div>
      )}
    </>
  );
}

function CarouselArrow({
  direction,
  onClick,
  disabled,
}: {
  direction: "prev" | "next";
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={direction === "prev" ? "Previous" : "Next"}
      className="group flex h-11 w-11 items-center justify-center rounded-full border border-[#1d1b18]/15 bg-white/60 backdrop-blur transition-[transform,background,border-color] duration-200 hover:-translate-y-[1px] hover:border-[#1d1b18]/35 hover:bg-white active:scale-[0.95] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0"
    >
      <svg
        className={`h-4 w-4 text-[#1d1b18] transition-transform duration-300 ${
          direction === "prev"
            ? "group-hover:-translate-x-0.5"
            : "group-hover:translate-x-0.5"
        }`}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {direction === "prev" ? (
          <path d="M19 12H5M12 19l-7-7 7-7" />
        ) : (
          <path d="M5 12h14M13 5l7 7-7 7" />
        )}
      </svg>
    </button>
  );
}
