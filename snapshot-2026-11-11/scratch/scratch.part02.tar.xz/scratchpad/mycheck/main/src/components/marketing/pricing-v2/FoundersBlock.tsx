"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";

interface FoundersBlockProps {
  eyebrow: string;
  quote: string;
  attribution: string;
  role: string;
  aboutLabel: string;
  aboutHref: string;
  cmoName: string;
  cmoRole: string;
  cmoNote: string;
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function FoundersBlock({
  eyebrow,
  quote,
  attribution,
  role,
  aboutLabel,
  aboutHref,
  cmoName,
  cmoRole,
  cmoNote,
}: FoundersBlockProps) {
  const reduce = useReducedMotion();
  // Only render the CMO card once a real Chief Medical Officer is appointed.
  const hasCmo = Boolean(cmoName);

  return (
    <section className="bg-[var(--color-eva-surface)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
        </header>

        <div
          className={`mt-[clamp(3rem,5vw,4rem)] grid grid-cols-1 gap-[clamp(2rem,5vw,4rem)]${
            hasCmo ? " lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]" : ""
          }`}
        >
          {/* Founder quote */}
          <motion.figure
            initial={reduce ? false : { opacity: 0, y: 14 }}
            whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, ease: EASE_QUART }}
          >
            <blockquote className="font-[family-name:var(--font-sentient)] text-[clamp(1.75rem,3.3vw,2.5rem)] font-medium leading-[1.22] tracking-[-0.02em] text-[var(--color-eva-on-surface)]">
              &ldquo;{quote}&rdquo;
            </blockquote>
            <figcaption className="mt-[var(--space-2xl)] flex items-baseline gap-[var(--space-md)]">
              <span
                aria-hidden
                className="inline-block h-[1px] w-[28px] translate-y-[-4px] bg-[var(--color-eva-on-surface)]/45"
              />
              <div>
                <span className="block font-[family-name:var(--font-manrope)] text-[15px] font-semibold text-[var(--color-eva-on-surface)]">
                  {attribution}
                </span>
                <span className="mt-[var(--space-xs)] block font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
                  {role}
                </span>
              </div>
            </figcaption>
            <div className="mt-[var(--space-xl)]">
              <Link
                href={aboutHref}
                className="group/link inline-flex items-center gap-[var(--space-sm)] font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-on-surface)]/70 transition-colors hover:text-[var(--color-eva-terra)]"
              >
                <span className="relative after:absolute after:-bottom-[2px] after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-current after:transition-transform after:duration-[260ms] group-hover/link:after:scale-x-100">
                  {aboutLabel}
                </span>
                <svg width="10" height="10" viewBox="0 0 12 12" fill="none" aria-hidden>
                  <path
                    d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5"
                    stroke="currentColor"
                    strokeWidth="1.3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </Link>
            </div>
          </motion.figure>

          {/* CMO specimen card — only when a real CMO has been appointed */}
          {hasCmo && (
            <motion.aside
              initial={reduce ? false : { opacity: 0, y: 14 }}
              whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.8, delay: 0.1, ease: EASE_QUART }}
              className="border border-[var(--color-eva-on-surface)]/12 bg-[var(--color-eva-surface-lowest)] p-[var(--space-xl)] md:p-[var(--space-2xl)]"
            >
              <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-jade)]">
                § CMO · Medical lead
              </span>
              <h3 className="mt-[var(--space-md)] font-[family-name:var(--font-sentient)] text-[clamp(1.5rem,2.5vw,2rem)] font-medium leading-[1.1] tracking-[-0.02em] text-[var(--color-eva-on-surface)]">
                {cmoName}
              </h3>
              <span className="mt-[var(--space-xs)] block font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-on-surface)]/55">
                {cmoRole}
              </span>
              <p className="mt-[var(--space-lg)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] font-[family-name:var(--font-manrope)] text-[14.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/75">
                {cmoNote}
              </p>
            </motion.aside>
          )}
        </div>
      </div>
    </section>
  );
}
