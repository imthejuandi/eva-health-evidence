"use client";

import type { CSSProperties } from "react";

/**
 * Section header used at the top of every editorial section in the
 * dashboard. Adapted from the investors deck's chapter-marker pattern:
 * a short hairline rule, a mono kicker (e.g. "§ 03 — By category"),
 * an optional Cormorant headline with an italic terra accent, and an
 * optional subtitle.
 *
 * Usage:
 *   <EditorialSectionHeader
 *     kicker={t.biomarkers}               // "§ 03 — By category"
 *     title="A reading by"
 *     accent="stratum."                   // italic terra fragment of title
 *     subtitle="One category at a time"   // optional small print
 *   />
 *
 * Layout variants:
 *   - layout="stacked" (default): everything stacks vertically.
 *   - layout="split":   kicker+subtitle on the left, title on the right.
 *     Used by FindingsBand-style sections where the kicker rail sits in
 *     a 3-col rail next to a 9-col body.
 */
export function EditorialSectionHeader({
  kicker,
  title,
  accent,
  subtitle,
  rule = true,
  layout = "stacked",
  className,
  style,
}: {
  kicker: string;
  title?: string;
  accent?: string;
  subtitle?: string;
  rule?: boolean;
  layout?: "stacked" | "split";
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <header
      className={`flex flex-col gap-3 ${
        layout === "split"
          ? "md:flex-row md:items-end md:justify-between md:gap-10"
          : ""
      } ${className ?? ""}`}
      style={style}
    >
      <div className="flex items-center gap-3">
        {rule && (
          <span
            aria-hidden
            className="inline-block h-px w-8 bg-[#1d1b18]/25 md:w-12"
          />
        )}
        <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]">
          {kicker}
        </p>
      </div>

      {title && (
        <h2 className="max-w-[16ch] font-[family-name:var(--font-cormorant)] text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[64px] md:tracking-[-1px]">
          {title}
          {accent && (
            <>
              {" "}
              <span className="italic text-[#97472c]">{accent}</span>
            </>
          )}
        </h2>
      )}

      {subtitle && (
        <p className="font-[family-name:var(--font-jakarta)] text-[12px] uppercase tracking-[1.2px] text-[#8a7f76]">
          {subtitle}
        </p>
      )}
    </header>
  );
}
