import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

/**
 * DisplayHeading family — Sentient display-serif headlines for
 * the marketing surface.
 *
 * Three size tiers, each a separate component so call sites are
 * semantic and discoverable:
 *
 *   <HeroHeadline>   — 60 / 148 / 192px — hero only
 *   <SectionHeadline>— 52 / 120–140 / 148px — chapter openers
 *   <SubHeadline>    — 28 / 44 / 56px — row / card titles
 *
 * Why three components instead of one with a `size` prop: the
 * three tiers have different leading + max-width + tracking
 * curves, so forcing them through a single component means
 * either duplicating logic in consumers or a fat props surface.
 * Three small components is the happier path.
 *
 * All three render a plain heading element (no framer-motion
 * wrapper) — wrap in motion.h1 / motion.h2 on the call site if
 * you want a reveal animation.
 *
 * Font face: Sentient (Fontshare). Weight: 500 (medium).
 * Color: #1d1b18 ink by default; `color` prop accepts
 * "ink" | "terra" | "jade" | "inverse".
 * `balance` applies `text-wrap: balance` for nicer line breaks
 * on multi-word headlines.
 */

const DISPLAY = "font-[family-name:var(--font-sentient)]";

type HeadingColor = "ink" | "terra" | "jade" | "inverse";

const colorClass: Record<HeadingColor, string> = {
  ink: "text-[#1d1b18]",
  terra: "text-[#97472c]",
  jade: "text-[#3a665e]",
  inverse: "text-[#fef8f2]",
};

/* ──────────────────────────────────────────────────────────────
 * HeroHeadline
 * 60 / 148 / 192px — for the one hero on a page. Do not use
 * elsewhere; smaller chapters should use SectionHeadline.
 * ────────────────────────────────────────────────────────────── */
interface HeroHeadlineProps {
  children: React.ReactNode;
  color?: HeadingColor;
  balance?: boolean;
  className?: string;
}

export function HeroHeadline({
  children,
  color = "ink",
  balance = true,
  className,
}: HeroHeadlineProps) {
  return (
    <h1
      className={cn(
        DISPLAY,
        "max-w-[14ch] text-[60px] font-medium leading-[0.9] tracking-[-1.2px] md:text-[148px] md:tracking-[-5px] lg:text-[192px] lg:tracking-[-7px]",
        colorClass[color],
        className,
      )}
      style={
        balance ? ({ textWrap: "balance" } as CSSProperties) : undefined
      }
    >
      {children}
    </h1>
  );
}

/* ──────────────────────────────────────────────────────────────
 * SectionHeadline
 * Chapter openers. Three size variants (see `scale` prop):
 *
 *   "monumental" — 52 / 140 md tracking -1 / -4.5
 *                  (Shortfall § 02, Reckoning § 03)
 *   "grand"      — 52 / 120 / 148 lg tracking -1 / -4 / -5.5
 *                  (Reveal § 05 — has an lg step)
 *   "standard"   — 52 / 112 md tracking -1 / -3.5
 *                  (Method § 04 — smaller chapter heading)
 *
 * Default: "monumental" — the most common variant on the landing.
 * ────────────────────────────────────────────────────────────── */
type SectionScale = "monumental" | "grand" | "standard";

const scaleClass: Record<SectionScale, string> = {
  monumental:
    "text-[52px] leading-[0.92] tracking-[-1px] md:text-[140px] md:tracking-[-4.5px]",
  grand:
    "text-[52px] leading-[0.95] tracking-[-1px] md:text-[120px] md:tracking-[-4px] lg:text-[148px] lg:tracking-[-5.5px]",
  standard:
    "text-[52px] leading-[0.92] tracking-[-1px] md:text-[112px] md:tracking-[-3.5px]",
};

interface SectionHeadlineProps {
  children: React.ReactNode;
  scale?: SectionScale;
  color?: HeadingColor;
  /** `max-w-[Nch]` clamp. Default 16ch. */
  maxCh?: number;
  balance?: boolean;
  /** Heading level element. Default "h2". */
  as?: "h1" | "h2";
  className?: string;
}

export function SectionHeadline({
  children,
  scale = "monumental",
  color = "ink",
  maxCh = 16,
  balance = true,
  as = "h2",
  className,
}: SectionHeadlineProps) {
  const Tag = as;
  return (
    <Tag
      className={cn(
        DISPLAY,
        "font-medium",
        scaleClass[scale],
        colorClass[color],
        className,
      )}
      style={{
        maxWidth: `${maxCh}ch`,
        ...(balance ? { textWrap: "balance" as const } : {}),
      }}
    >
      {children}
    </Tag>
  );
}

/* ──────────────────────────────────────────────────────────────
 * SubHeadline
 * 28 / 44 / 56px — row titles, card titles, sub-section
 * headlines. Tighter tracking and leading than SectionHeadline
 * because the sizes are smaller.
 *
 * Quarterly Ledger step titles use this size.
 * ────────────────────────────────────────────────────────────── */
interface SubHeadlineProps {
  children: React.ReactNode;
  color?: HeadingColor;
  balance?: boolean;
  /** Heading level element. Default "h3". */
  as?: "h2" | "h3" | "h4";
  className?: string;
}

export function SubHeadline({
  children,
  color = "ink",
  balance = true,
  as = "h3",
  className,
}: SubHeadlineProps) {
  const Tag = as;
  return (
    <Tag
      className={cn(
        DISPLAY,
        "text-[28px] font-medium leading-[1.08] tracking-[-0.4px] md:text-[44px] md:tracking-[-1.2px] lg:text-[56px] lg:tracking-[-1.8px]",
        colorClass[color],
        className,
      )}
      style={
        balance ? ({ textWrap: "balance" } as CSSProperties) : undefined
      }
    >
      {children}
    </Tag>
  );
}
