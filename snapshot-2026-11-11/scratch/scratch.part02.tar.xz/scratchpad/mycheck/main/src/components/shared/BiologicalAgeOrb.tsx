"use client";

import { motion } from "framer-motion";

interface BiologicalAgeOrbProps {
  bioAge: number;
  realAge: number;
  size?: "large" | "hero" | "dashboard" | "small";
  /**
   * Optional KDM provenance: number of markers that contributed to the BA
   * computation. When supplied, renders a "{markersUsed}/14 marcadores" line
   * below the delta. Defaults preserve the existing layout when omitted.
   */
  markersUsed?: number;
  /**
   * Optional confidence/qualitative tag (e.g., "alta", "media"). Reserved
   * for future use — accepted now to keep API additions non-breaking.
   */
  confidence?: string;
}

export function BiologicalAgeOrb({
  bioAge,
  realAge,
  size = "large",
  markersUsed,
  confidence,
}: BiologicalAgeOrbProps) {
  const sizeMap = {
    large: { outer: 400, inner: 360, fontSize: 96, labelSize: 13, deltaSize: 15, letterSpacing: -4, pad: 20 },
    hero: { outer: 320, inner: 280, fontSize: 72, labelSize: 11, deltaSize: 13, letterSpacing: -3, pad: 20 },
    dashboard: { outer: 160, inner: 140, fontSize: 38, labelSize: 9, deltaSize: 11, letterSpacing: -2, pad: 10 },
    small: { outer: 116, inner: 100, fontSize: 28, labelSize: 8, deltaSize: 9, letterSpacing: -1.5, pad: 8 },
  };

  const s = sizeMap[size];
  const diff = Math.round((realAge - bioAge) * 10) / 10;
  const positive = diff > 0;
  const deltaText = positive
    ? `${diff}yr younger`
    : `${Math.abs(diff)}yr older`;

  // Calculate inner radius for concentric curves
  const outerRadius = s.outer / 2;
  const innerRadius = outerRadius - s.pad / 2;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.88 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.85, ease: [0.32, 0.72, 0, 1] }}
      className="relative flex shrink-0 items-center justify-center"
    >
      {/* ─── Outer Shell (Double-Bezel) ─── */}
      <div
        className="flex items-center justify-center"
        style={{
          width: s.outer,
          height: s.outer,
          borderRadius: outerRadius,
          padding: s.pad,
          background: "rgba(188,236,225,0.08)",
          boxShadow: "inset 0 0 0 1px rgba(58,102,94,0.08)",
        }}
      >
        {/* ─── Inner Core ─── */}
        <div
          className="flex items-center justify-center"
          style={{
            width: s.inner,
            height: s.inner,
            borderRadius: innerRadius,
            background:
              "radial-gradient(circle at 40% 30%, rgba(188,236,225,0.55), rgba(188,236,225,0.15) 65%, rgba(254,248,242,0.6) 100%)",
            boxShadow:
              "0 20px 60px rgba(58,102,94,0.1), 0 4px 16px rgba(58,102,94,0.06), inset 0 1px 2px rgba(255,255,255,0.6), inset 0 -1px 2px rgba(58,102,94,0.06)",
          }}
        >
          <div className="text-center">
            <div
              className="font-heading font-extrabold leading-none text-[#3a665e]"
              style={{ fontSize: s.fontSize, letterSpacing: s.letterSpacing }}
            >
              {bioAge}
            </div>
            <div
              className="mt-1 font-sans font-semibold uppercase tracking-[1.4px] text-[#4c463f]"
              style={{ fontSize: s.labelSize }}
            >
              Bio Age
            </div>
            <div
              className="mt-1.5 font-sans font-bold"
              style={{
                fontSize: s.deltaSize,
                color: positive ? "#3a665e" : "#97472c",
              }}
            >
              {deltaText}
            </div>
            {typeof markersUsed === "number" && (
              <div
                className="mt-1 font-sans font-medium tracking-wide text-[#4c463f]/70"
                style={{ fontSize: Math.max(s.labelSize - 1, 8) }}
              >
                {markersUsed}/14 marcadores
              </div>
            )}
            {confidence && (
              <div
                className="mt-0.5 font-sans uppercase tracking-[1px] text-[#4c463f]/60"
                style={{ fontSize: Math.max(s.labelSize - 2, 7) }}
              >
                {confidence}
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
