"use client";

import { motion, useReducedMotion } from "framer-motion";

export type TraceKind = "hrv" | "sleep" | "heart" | "recovery";

export interface TraceEntry {
  kind: TraceKind;
  label: string;
  descriptor: string;
  color: string;
}

interface SeismographStripProps {
  traces: TraceEntry[];
}

const W = 600;
const H = 52;
const STEPS = 80;

function seededNoise(i: number): number {
  // Deterministic pseudo-random noise from integer seed
  const x = Math.sin(i * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

function makePath(kind: TraceKind): string {
  const pts: string[] = [];

  if (kind === "hrv") {
    // Spiky, irregular — RR-interval style
    for (let i = 0; i <= STEPS; i++) {
      const x = (i / STEPS) * W;
      const noise = seededNoise(i * 3 + 1) * 2 - 1;
      const base = Math.sin(i * 0.5) * 0.5 + Math.cos(i * 1.3) * 0.4;
      const y = H / 2 + H * 0.38 * (base + noise * 0.5);
      pts.push(`${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${Math.max(3, Math.min(H - 3, y)).toFixed(1)}`);
    }
  } else if (kind === "sleep") {
    // Gentle sinusoidal — sleep cycles
    for (let i = 0; i <= STEPS; i++) {
      const x = (i / STEPS) * W;
      const y =
        H / 2 +
        H * 0.25 * Math.sin(i * 0.16) +
        H * 0.08 * Math.sin(i * 0.42);
      pts.push(`${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
  } else if (kind === "heart") {
    // EKG-like: baseline with periodic QRS complexes
    pts.push(`M 0 ${H / 2}`);
    const beats = 8;
    const spacing = W / beats;
    for (let i = 0; i < beats; i++) {
      const x0 = i * spacing;
      pts.push(
        `L ${(x0 + spacing * 0.28).toFixed(1)} ${H / 2}`,
        `L ${(x0 + spacing * 0.34).toFixed(1)} ${(H / 2 - H * 0.05).toFixed(1)}`, // P wave
        `L ${(x0 + spacing * 0.40).toFixed(1)} ${H / 2}`,
        `L ${(x0 + spacing * 0.44).toFixed(1)} ${(H / 2 + H * 0.06).toFixed(1)}`, // Q
        `L ${(x0 + spacing * 0.48).toFixed(1)} ${(H * 0.1).toFixed(1)}`, // R peak
        `L ${(x0 + spacing * 0.52).toFixed(1)} ${(H * 0.9).toFixed(1)}`, // S trough
        `L ${(x0 + spacing * 0.58).toFixed(1)} ${H / 2}`,
        `L ${(x0 + spacing * 0.70).toFixed(1)} ${(H / 2 - H * 0.08).toFixed(1)}`, // T wave
        `L ${(x0 + spacing * 0.80).toFixed(1)} ${H / 2}`,
        `L ${(x0 + spacing).toFixed(1)} ${H / 2}`
      );
    }
  } else {
    // recovery — slow gentle arc
    for (let i = 0; i <= STEPS; i++) {
      const x = (i / STEPS) * W;
      const t = i / STEPS;
      const y =
        H / 2 -
        H * 0.28 * Math.sin(t * Math.PI) +
        H * 0.06 * Math.sin(i * 0.3);
      pts.push(`${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
  }

  return pts.join(" ");
}

/**
 * Four stacked waveform traces styled like a medical-monitor printout or
 * seismograph strip. Each trace has its own shape profile to suggest its
 * signal type (HRV is spiky, sleep is wavy, heart is an EKG, recovery is
 * a slow arc). Paths draw in with staggered pathLength animation on
 * scroll-into-view. Respects prefers-reduced-motion.
 */
export function SeismographStrip({ traces }: SeismographStripProps) {
  const reduce = useReducedMotion();

  return (
    <div className="border-y border-[#1d1b18]/15">
      {traces.map((trace, i) => {
        const path = makePath(trace.kind);
        const gridTicks = 24;
        return (
          <div
            key={i}
            className="grid grid-cols-[110px_1fr_auto] items-center gap-4 border-t border-[#1d1b18]/10 py-5 first:border-t-0 md:grid-cols-[140px_1fr_200px] md:gap-8 md:py-6"
          >
            {/* Label */}
            <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#1d1b18] [font-feature-settings:'tnum']">
              {trace.label}
            </span>

            {/* Trace */}
            <svg
              viewBox={`0 0 ${W} ${H}`}
              className="h-[46px] w-full md:h-[52px]"
              preserveAspectRatio="none"
              aria-hidden
            >
              {/* Dotted baseline */}
              <line
                x1="0"
                y1={H / 2}
                x2={W}
                y2={H / 2}
                stroke="rgba(29,27,24,0.08)"
                strokeWidth="0.8"
                strokeDasharray="2,4"
              />
              {/* Faint vertical grid ticks */}
              {Array.from({ length: gridTicks }).map((_, g) => {
                const x = (g / (gridTicks - 1)) * W;
                return (
                  <line
                    key={g}
                    x1={x}
                    y1={H / 2 - 3}
                    x2={x}
                    y2={H / 2 + 3}
                    stroke="rgba(29,27,24,0.09)"
                    strokeWidth="0.6"
                  />
                );
              })}
              {/* The waveform */}
              <motion.path
                d={path}
                fill="none"
                stroke={trace.color}
                strokeWidth="1.3"
                strokeLinecap="round"
                strokeLinejoin="round"
                initial={reduce ? { pathLength: 1 } : { pathLength: 0 }}
                whileInView={{ pathLength: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={
                  reduce
                    ? { duration: 0 }
                    : {
                        duration: 1.6 + i * 0.15,
                        delay: i * 0.12,
                        ease: [0.22, 1, 0.36, 1],
                      }
                }
              />

              {/* Live-signal spark: short bright segment that traces the
                  waveform in a loop — reinforces "continuous signal". */}
              {!reduce && (
                <motion.path
                  d={path}
                  fill="none"
                  stroke={trace.color}
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray="42 2000"
                  initial={{ strokeDashoffset: 0, opacity: 0 }}
                  whileInView={{
                    strokeDashoffset: [0, -2042],
                    opacity: [0, 0.85, 0.85, 0],
                  }}
                  viewport={{ once: false, amount: 0.2 }}
                  transition={{
                    duration: 5.5 + i * 0.3,
                    repeat: Infinity,
                    delay: 2.4 + i * 0.5,
                    ease: "linear",
                    times: [0, 0.04, 0.96, 1],
                  }}
                  style={{ filter: "drop-shadow(0 0 2px currentColor)" }}
                />
              )}
            </svg>

            {/* Descriptor — hidden on narrow, shown on md+ */}
            <span className="hidden font-[family-name:var(--font-sentient)] italic leading-[1.4] text-[#4c463f] md:block" style={{ fontSize: "13px" }}>
              {trace.descriptor}
            </span>

            {/* Mobile descriptor — shown below trace on small screens */}
            <span className="col-start-2 font-[family-name:var(--font-sentient)] italic leading-[1.4] text-[#4c463f] md:hidden" style={{ fontSize: "12px" }}>
              {trace.descriptor}
            </span>
          </div>
        );
      })}
    </div>
  );
}
