"use client";

import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { PanelDefinition } from "@/config/panels";
import { PanelPriceSlot } from "./PanelPriceSlot";
import { QuoteRequestForm } from "./QuoteRequestForm";

interface SpecialtyPanelsSectionProps {
  eyebrow: string;
  headline: string;
  kicker: string;
  locale: string;
  panels: PanelDefinition[];
  includedLabel: string;
  quoteLabel: string;
  addonSuffix: string;
  biomarkersLabel: string;
  formEmailLabel: string;
  formEmailPlaceholder: string;
  formSubmitLabel: string;
  formSuccess: string;
  formError: string;
  onQuoteSubmit?: (data: { panelId: string; email: string }) => Promise<void> | void;
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function SpecialtyPanelsSection({
  eyebrow,
  headline,
  kicker,
  locale,
  panels,
  includedLabel,
  quoteLabel,
  addonSuffix,
  biomarkersLabel,
  formEmailLabel,
  formEmailPlaceholder,
  formSubmitLabel,
  formSuccess,
  formError,
  onQuoteSubmit,
}: SpecialtyPanelsSectionProps) {
  const [openQuoteId, setOpenQuoteId] = useState<string | null>(null);
  const reduce = useReducedMotion();

  return (
    <section className="bg-[var(--color-eva-surface)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <div>
            <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
              {headline}
            </h2>
            <p className="mt-[var(--space-md)] max-w-[56ch] font-[family-name:var(--font-manrope)] text-[15.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/70">
              {kicker}
            </p>
          </div>
        </header>

        {/* Hairline rows */}
        <ul className="mt-[clamp(3rem,5vw,4rem)] border-t border-[var(--color-eva-on-surface)]/15">
          {panels.map((panel, idx) => {
            const mode = panel.pricingMode ?? "quote";
            const name = locale === "es" ? panel.name_es : panel.name;
            const desc = locale === "es" ? panel.description_es : panel.description;
            const isOpen = openQuoteId === panel.id;

            return (
              <motion.li
                key={panel.id}
                initial={reduce ? false : { opacity: 0, y: 8 }}
                whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{
                  duration: 0.5,
                  delay: idx * 0.04,
                  ease: EASE_QUART,
                }}
                className="border-b border-[var(--color-eva-on-surface)]/15"
              >
                <div className="grid grid-cols-1 gap-[var(--space-md)] py-[var(--space-xl)] md:grid-cols-[80px_minmax(0,1.2fr)_minmax(0,1.6fr)_auto] md:items-baseline md:gap-[var(--space-2xl)]">
                  <span
                    className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    § {String(idx + 1).padStart(2, "0")}
                  </span>
                  <div>
                    <h3 className="font-[family-name:var(--font-sentient)] text-[clamp(1.5rem,2.5vw,2rem)] font-medium leading-[1.1] tracking-[-0.02em] text-[var(--color-eva-on-surface)]">
                      {name}
                    </h3>
                    {panel.biomarker_count && (
                      <span
                        className="mt-[var(--space-xs)] inline-block font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-on-surface)]/50"
                        style={{ fontVariantNumeric: "tabular-nums" }}
                      >
                        {panel.biomarker_count} {biomarkersLabel}
                      </span>
                    )}
                  </div>
                  <p className="max-w-[60ch] font-[family-name:var(--font-manrope)] text-[14.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/75">
                    {desc}
                  </p>
                  <div className={cn("flex md:justify-end", "items-baseline")}>
                    <PanelPriceSlot
                      mode={mode}
                      addonPriceEur={panel.addonPriceEur}
                      includedLabel={includedLabel}
                      quoteLabel={quoteLabel}
                      addonSuffix={addonSuffix}
                      onQuoteClick={() => setOpenQuoteId(isOpen ? null : panel.id)}
                    />
                  </div>
                </div>

                <AnimatePresence initial={false}>
                  {isOpen && mode === "quote" && (
                    <motion.div
                      key="form"
                      initial={{ gridTemplateRows: "0fr", opacity: 0 }}
                      animate={{ gridTemplateRows: "1fr", opacity: 1 }}
                      exit={{ gridTemplateRows: "0fr", opacity: 0 }}
                      transition={{ duration: 0.36, ease: EASE_QUART }}
                      className="grid overflow-hidden"
                      style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                    >
                      <div className="min-h-0">
                        <div className="border-t border-[var(--color-eva-on-surface)]/10 bg-[var(--color-eva-cream-warm)]/50 px-[var(--space-md)] py-[var(--space-lg)] md:px-[var(--space-xl)]">
                          <QuoteRequestForm
                            panelId={panel.id}
                            emailLabel={formEmailLabel}
                            emailPlaceholder={formEmailPlaceholder}
                            submitLabel={formSubmitLabel}
                            successMessage={formSuccess}
                            errorMessage={formError}
                            onSubmit={onQuoteSubmit}
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
