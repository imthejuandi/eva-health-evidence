"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";

const E: [number, number, number, number] = [0.32, 0.72, 0, 1];

interface Props {
  stdLabel: string;
  optLabel: string;
  stdVerdict: string;
  optVerdict: string;
  className?: string;
}

/**
 * NormalVsOptimalFlip — the "aha" moment of the how-it-works page.
 *
 * Shows Ferritin 38 ng/mL evaluated twice:
 *   Phase 1: Standard lab view — wide band (12-300), pin inside → "Normal"
 *   Phase 2: EVA optimal view — narrow band (50-150), pin OUTSIDE → "Below Optimal"
 *
 * The band width, pin color, and verdict text all animate in sequence
 * so the visitor watches the SAME number get reclassified in real time.
 */
export function NormalVsOptimalFlip({ stdLabel, optLabel, stdVerdict, optVerdict, className }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-12%" });
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const ts = [
      setTimeout(() => setPhase(1), 400),
      setTimeout(() => setPhase(2), 2000),
      setTimeout(() => setPhase(3), 3600),
    ];
    return () => ts.forEach(clearTimeout);
  }, [inView]);

  const trackH = "h-[18px] md:h-[22px]";
  const pinH = "h-[18px] md:h-[22px]";

  return (
    <div ref={ref} className={`w-full space-y-4 md:space-y-6 ${className ?? ""}`}>
      {/* Standard Lab View */}
      <div className="rounded-lg bg-[#f8f3ed] p-4 md:rounded-xl md:p-6">
        <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
          <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#8a7f76] md:text-[10px]">{stdLabel}</span>
          <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#1d1b18] md:text-[15px]">
            Ferritin · <span className="font-[family-name:var(--font-dm-mono)] [font-feature-settings:'tnum']">38 ng/mL</span>
          </span>
        </div>
        <div className={`relative mt-3 w-full md:mt-4 ${trackH}`}>
          <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#1d1b18]/8" />
          {/* Wide "normal" band: 5%-90% of track */}
          {phase >= 1 && (
            <motion.div
              className={`absolute top-1/2 -translate-y-1/2 rounded-full ${trackH}`}
              style={{ left: "4%", background: "rgba(138,127,118,0.1)" }}
              initial={{ width: "0%" }}
              animate={{ width: "88%" }}
              transition={{ duration: 0.9, ease: E }}
            />
          )}
          {/* Pin at ferritin position (~14% of range 12-300) */}
          {phase >= 1 && (
            <motion.div
              className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{ left: "13%" }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.4, ease: E }}
            >
              <span className={`block w-[3px] rounded-full bg-[#3a665e] ${pinH}`} style={{ boxShadow: "0 0 8px rgba(58,102,94,0.4)" }} />
            </motion.div>
          )}
        </div>
        {phase >= 1 && (
          <motion.p
            className="mt-2.5 font-[family-name:var(--font-dm-mono)] text-[10px] font-bold uppercase tracking-[2px] text-[#3a665e] md:mt-3 md:text-[11px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9, duration: 0.4 }}
          >
            {stdVerdict}
          </motion.p>
        )}
      </div>

      {/* EVA Optimal View */}
      <div className="rounded-lg bg-[#f8f3ed] p-4 md:rounded-xl md:p-6">
        <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
          <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[10px]">{optLabel}</span>
          <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#1d1b18] md:text-[15px]">
            Ferritin · <span className="font-[family-name:var(--font-dm-mono)] [font-feature-settings:'tnum']">38 ng/mL</span>
          </span>
        </div>
        <div className={`relative mt-3 w-full md:mt-4 ${trackH}`}>
          <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#1d1b18]/8" />
          {/* Narrow optimal band: 21%-74% */}
          {phase >= 2 && (
            <motion.div
              className={`absolute top-1/2 -translate-y-1/2 rounded-full ${trackH}`}
              style={{ left: "21%", background: "linear-gradient(90deg, rgba(58,102,94,0.22), rgba(58,102,94,0.36))" }}
              initial={{ width: "0%" }}
              animate={{ width: "53%" }}
              transition={{ duration: 0.9, ease: E }}
            />
          )}
          {/* Same pin position — now OUTSIDE the optimal band */}
          {phase >= 2 && (
            <motion.div
              className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{ left: "13%" }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.4, ease: E }}
            >
              <span className={`block w-[3px] rounded-full bg-[#c49332] ${pinH}`} style={{ boxShadow: "0 0 8px rgba(196,147,50,0.5)" }} />
            </motion.div>
          )}
          {/* Continuous glow after phase 3 */}
          {phase >= 3 && (
            <motion.div
              className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{ left: "13%" }}
              animate={{ opacity: [0.15, 0.4, 0.15] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <span className="block h-[26px] w-[7px] rounded-full bg-[#c49332]/20 md:h-[30px]" />
            </motion.div>
          )}
        </div>
        {phase >= 2 && (
          <motion.p
            className="mt-2.5 font-[family-name:var(--font-dm-mono)] text-[10px] font-bold uppercase tracking-[2px] text-[#c49332] md:mt-3 md:text-[11px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9, duration: 0.4 }}
          >
            {optVerdict}
          </motion.p>
        )}
      </div>
    </div>
  );
}
