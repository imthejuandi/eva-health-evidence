import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

/**
 * BiomarkerSpecimen — marketing-grade biomarker track.
 *
 * A read-only editorial replica of the dashboard's
 * `BiomarkerTrack` visualization (see
 * `src/app/[locale]/(dashboard)/dashboard/dashboard-client.tsx`).
 * The dashboard version is interactive — hover, tap-to-pin,
 * tooltip with full ranges — because the dashboard shows real
 * user data and the tooltip is the disclosure surface. On
 * marketing surfaces we drop all of that and keep only the
 * static visual, so /how-it-works can show a faithful "this is
 * what a reading looks like in the product" specimen without
 * dragging in the dashboard's state and data dependencies.
 *
 * Visual tokens are kept **exactly** in sync with the dashboard
 * implementation so the marketing surface and the product share
 * the same visual vocabulary. If the dashboard version of the
 * track changes (height, stroke, colour, radius), this file
 * must be updated to match.
 *
 *   · 22px relative track height
 *   · 1px hairline base rule at rgba(29,27,24,0.15)
 *   · 10px vertical tick marks at the bounds
 *   · 12px rounded-full optimal band with jade linear-gradient
 *     from rgba(58,102,94,0.22) → rgba(58,102,94,0.36)
 *   · 3px value pin, coloured by zone, with a 0 0 10px glow
 *   · Manrope 14px bold for the biomarker name
 *   · DM Mono 13px bold tabular-nums for the value
 *   · 10px muted unit suffix
 *
 * Two named exports:
 *
 *   <BiomarkerSpecimen>  — a single reading, with an optional
 *                          mono eyebrow above the row
 *   <ZoneLegendTrack>    — a teaching track showing all 5 zones
 *                          as continuous tinted regions, no value
 *                          pin, for the "here is the system"
 *                          explainer on /how-it-works
 *
 * Both components render plain divs — wrap in ScrollReveal at
 * the call site if you want a fade-up.
 */

/* ──────────────────────────────────────────────────────────────
 * Zone tokens — mirrors ZONE_COLOR_M from dashboard-client.tsx.
 * Keep the two in lockstep.
 * ────────────────────────────────────────────────────────────── */
export type Zone =
  | "critical_low"
  | "below_optimal"
  | "optimal"
  | "above_optimal"
  | "critical_high";

const ZONE_COLOR: Record<Zone, string> = {
  critical_low: "#b04040",
  below_optimal: "#c49332",
  optimal: "#3a665e",
  above_optimal: "#c49332",
  critical_high: "#b04040",
};

/* ──────────────────────────────────────────────────────────────
 * BiomarkerSpecimen
 * ────────────────────────────────────────────────────────────── */
interface BiomarkerSpecimenProps {
  /** Biomarker name, e.g. "Ferritin". */
  name: string;
  /** Numeric reading, e.g. 38. */
  value: number;
  /** Unit suffix, e.g. "ng/mL". */
  unit?: string;
  /** Lower bound of the visible range (left edge of the track). */
  rangeLo: number;
  /** Upper bound of the visible range (right edge of the track). */
  rangeHi: number;
  /** Lower bound of the optimal band (jade gradient pill). */
  optimalLo: number;
  /** Upper bound of the optimal band. */
  optimalHi: number;
  /** Classified zone — drives the value pin colour. */
  zone: Zone;
  /**
   * Optional DM Mono eyebrow printed above the row, e.g.
   * "Example reading · Ferritin". Gives the specimen its
   * editorial caption without requiring a wrapper element.
   */
  eyebrow?: string;
  /** Eyebrow colour — defaults to terra. */
  eyebrowColor?: string;
  className?: string;
}

export function BiomarkerSpecimen({
  name,
  value,
  unit,
  rangeLo,
  rangeHi,
  optimalLo,
  optimalHi,
  zone,
  eyebrow,
  eyebrowColor = "#97472c",
  className,
}: BiomarkerSpecimenProps) {
  const color = ZONE_COLOR[zone];

  // Clamp the value inside the visible range so an out-of-range
  // reading doesn't pin into the negative or off the right edge.
  // Same guard the dashboard uses.
  const span = rangeHi - rangeLo || 1;
  const clamped = Math.max(rangeLo, Math.min(rangeHi, value));
  const valuePct = ((clamped - rangeLo) / span) * 100;
  const optLoPct = ((optimalLo - rangeLo) / span) * 100;
  const optHiPct = ((optimalHi - rangeLo) / span) * 100;
  const optWidth = Math.max(2, optHiPct - optLoPct);

  return (
    <div className={cn("w-full", className)}>
      {eyebrow && (
        <p
          className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] [font-feature-settings:'tnum','calt','kern']"
          style={{ color: eyebrowColor }}
        >
          {eyebrow}
        </p>
      )}
      <div
        className={cn(
          "grid grid-cols-12 items-center gap-4",
          eyebrow && "mt-4",
        )}
      >
        {/* Name — Manrope 14px bold, left column */}
        <div className="col-span-12 md:col-span-4">
          <p className="font-[family-name:var(--font-manrope)] text-[14px] font-bold text-[#1d1b18] md:text-[15px]">
            {name}
          </p>
        </div>

        {/* Track — 22px tall relative container with base rule,
            tick marks, jade optimal band, and a glowing value pin.
            The math matches the dashboard implementation exactly. */}
        <div className="col-span-9 md:col-span-6">
          <div className="relative h-[22px] w-full">
            {/* Base rule */}
            <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#1d1b18]/15" />
            {/* Tick marks at the bounds */}
            <div className="absolute left-0 top-1/2 h-[10px] w-[1px] -translate-y-1/2 bg-[#1d1b18]/25" />
            <div className="absolute right-0 top-1/2 h-[10px] w-[1px] -translate-y-1/2 bg-[#1d1b18]/25" />
            {/* Optimal band — 12px rounded pill with a subtle jade
                gradient. Identical to the dashboard. */}
            <div
              className="absolute top-1/2 h-[12px] -translate-y-1/2 rounded-full"
              style={
                {
                  left: `${optLoPct}%`,
                  width: `${optWidth}%`,
                  background:
                    "linear-gradient(90deg, rgba(58,102,94,0.22), rgba(58,102,94,0.36))",
                } as CSSProperties
              }
            />
            {/* Value pin — 3px wide vertical line, zone-coloured,
                with a soft glow. Positioned at valuePct. */}
            <div
              className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${valuePct}%` }}
            >
              <span
                className="block h-[22px] w-[3px] rounded-full"
                style={{
                  backgroundColor: color,
                  boxShadow: `0 0 10px ${color}`,
                }}
              />
            </div>
          </div>
        </div>

        {/* Value — DM Mono tabular nums, zone-coloured, with unit
            suffix in muted 10px. */}
        <div className="col-span-3 md:col-span-2 text-right">
          <p
            className="font-[family-name:var(--font-dm-mono)] text-[13px] font-bold [font-feature-settings:'tnum']"
            style={{
              color,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {fmt(value)}
            {unit && (
              <span className="ml-1 text-[10px] font-semibold text-[#8a7f76]">
                {unit}
              </span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * ZoneLegendTrack
 *
 * A teaching track showing all 5 zones as a continuous 22px
 * rounded pill divided into tinted regions. No value pin — this
 * isn't a reading, it's the explanation. Rhymes with
 * BiomarkerSpecimen: same track height, same base rule, same tick
 * marks, same 12px pill, same gradient stops.
 *
 * Zone widths follow the dashboard's visual weighting: the
 * optimal band occupies the widest slice (2), the "below/above
 * optimal" bands each get 1.5, and the "critical low/high" bands
 * each get 1. Total 7.
 * ────────────────────────────────────────────────────────────── */
interface ZoneLegendTrackProps {
  className?: string;
}

export function ZoneLegendTrack({ className }: ZoneLegendTrackProps) {
  return (
    <div
      aria-hidden
      className={cn("relative h-[22px] w-full", className)}
    >
      {/* Base rule */}
      <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#1d1b18]/15" />
      {/* Tick marks at the bounds */}
      <div className="absolute left-0 top-1/2 h-[10px] w-[1px] -translate-y-1/2 bg-[#1d1b18]/25" />
      <div className="absolute right-0 top-1/2 h-[10px] w-[1px] -translate-y-1/2 bg-[#1d1b18]/25" />
      {/* 5-zone gradient pill — continuous flex row inside a
          rounded-full overflow-hidden strip so the five bands
          share the same radius without gaps. Gradients fade toward
          the edges so adjacent bands visually blend rather than
          clicking off at a hard seam. */}
      <div className="absolute inset-x-0 top-1/2 flex h-[12px] -translate-y-1/2 overflow-hidden rounded-full">
        <div
          className="flex-[1]"
          style={{
            background:
              "linear-gradient(90deg, rgba(176,64,64,0.18), rgba(176,64,64,0.28))",
          }}
        />
        <div
          className="flex-[1.5]"
          style={{
            background:
              "linear-gradient(90deg, rgba(196,147,50,0.14), rgba(196,147,50,0.26))",
          }}
        />
        <div
          className="flex-[2]"
          style={{
            background:
              "linear-gradient(90deg, rgba(58,102,94,0.22), rgba(58,102,94,0.36))",
          }}
        />
        <div
          className="flex-[1.5]"
          style={{
            background:
              "linear-gradient(90deg, rgba(196,147,50,0.26), rgba(196,147,50,0.14))",
          }}
        />
        <div
          className="flex-[1]"
          style={{
            background:
              "linear-gradient(90deg, rgba(176,64,64,0.28), rgba(176,64,64,0.18))",
          }}
        />
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
 * fmt — tiny number formatter. The dashboard has its own `fmt`
 * helper that's locale-aware and handles nullish inputs; on the
 * marketing surface we only ever pass hard-coded example readings
 * so a two-decimal toFixed with a strip of trailing zeros is
 * enough. Integers stay integers, halves like "2.5" stay as
 * "2.5", long decimals collapse to two places.
 * ────────────────────────────────────────────────────────────── */
function fmt(n: number): string {
  if (Number.isInteger(n)) return n.toString();
  return n.toFixed(2).replace(/\.?0+$/, "");
}
