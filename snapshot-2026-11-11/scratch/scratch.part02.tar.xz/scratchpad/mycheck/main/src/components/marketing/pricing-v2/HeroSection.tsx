"use client";

import { motion, useReducedMotion } from "framer-motion";
import { PlanCardGrid } from "./PlanCardGrid";
import { TrustStrip } from "./TrustStrip";
import type { PlanCardProps } from "./PlanCard";

interface HeroSectionProps {
  eyebrow: string;
  /** Full headline with no inline markup. */
  headline: string;
  /** Optional word in headline to underline (last match wins). */
  highlightWord?: string;
  subhead: string;
  plans: PlanCardProps[];
  trustItems: { icon: "shield" | "lock" | "beaker"; label: string }[];
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

function renderHeadline(headline: string, highlightWord?: string) {
  if (!highlightWord) return headline;
  const lower = headline.toLowerCase();
  const idx = lower.lastIndexOf(highlightWord.toLowerCase());
  if (idx === -1) return headline;
  return (
    <>
      {headline.slice(0, idx)}
      <span className="relative inline-block whitespace-nowrap">
        {headline.slice(idx, idx + highlightWord.length)}
        <svg
          aria-hidden
          viewBox="0 0 220 14"
          preserveAspectRatio="none"
          className="absolute inset-x-0 -bottom-[6px] h-[10px] w-full text-[var(--color-eva-terra)]"
        >
          <path
            d="M2 10 C 55 2, 165 2, 218 10"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />
        </svg>
      </span>
      {headline.slice(idx + highlightWord.length)}
    </>
  );
}

export function HeroSection({
  eyebrow,
  headline,
  highlightWord,
  subhead,
  plans,
  trustItems,
}: HeroSectionProps) {
  const reduce = useReducedMotion();

  return (
    <section className="relative bg-[var(--color-eva-surface)] px-[var(--space-xl)] pt-[clamp(4rem,8vw,6rem)] pb-[clamp(4rem,8vw,6.5rem)] md:px-[var(--space-3xl)]">
      {/* Top meta rule — like a journal masthead */}
      <div className="mx-auto mb-[clamp(3rem,6vw,5rem)] flex max-w-[1240px] items-baseline justify-between border-b border-[var(--color-eva-on-surface)]/15 pb-[var(--space-md)]">
        <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
          {eyebrow}
        </span>
        <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/40">
          Vol. 01 · Madrid
        </span>
      </div>

      <div className="mx-auto grid max-w-[1240px] grid-cols-1 items-start gap-[clamp(2.5rem,5vw,4.5rem)] lg:grid-cols-[minmax(0,1fr)_minmax(0,1.25fr)]">
        {/* Left: headline + subhead + trust (natural flow, no stretch) */}
        <div className="flex flex-col">
          <div>
            <motion.h1
              initial={reduce ? false : { opacity: 0, y: 16 }}
              animate={reduce ? undefined : { opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: EASE_QUART }}
              className="font-[family-name:var(--font-sentient)] text-[clamp(2.75rem,6.5vw,5.5rem)] font-medium leading-[0.96] tracking-[-0.035em] text-[var(--color-eva-on-surface)]"
            >
              {renderHeadline(headline, highlightWord)}
            </motion.h1>

            <motion.p
              initial={reduce ? false : { opacity: 0, y: 12 }}
              animate={reduce ? undefined : { opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.12, ease: EASE_QUART }}
              className="mt-[var(--space-xl)] max-w-[44ch] font-[family-name:var(--font-manrope)] text-[16.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/75 md:text-[18px]"
            >
              {subhead}
            </motion.p>
          </div>

          <motion.div
            initial={reduce ? false : { opacity: 0 }}
            animate={reduce ? undefined : { opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.28, ease: EASE_QUART }}
            className="mt-[clamp(2rem,4vw,3rem)]"
          >
            <TrustStrip items={trustItems} />
          </motion.div>
        </div>

        {/* Right: plan cards */}
        <div>
          <PlanCardGrid plans={plans} priceScale="hero" />
        </div>
      </div>
    </section>
  );
}
