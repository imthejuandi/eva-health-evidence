"use client";

import { useState, type ReactNode } from "react";

/**
 * Editorial disclosure — a click-to-expand section with a mono label,
 * an optional count badge, and a `+ → ×` rotating glyph (the same
 * pattern used in the investors deck's source-detail cards).
 *
 * The trigger row is fully button-styled; the body is rendered only
 * when open so accessible tools like screen readers don't see hidden
 * content. The `accentColor` prop tints the label, the count badge
 * dot, and the trigger row's hover state — pass the section's own
 * accent (terra, jade, gold).
 *
 * Usage:
 *   <Disclosure
 *     label="Strengths"
 *     count={12}
 *     accentColor="#3a665e"
 *   >
 *     ... children rendered when open ...
 *   </Disclosure>
 */
export function Disclosure({
  label,
  count,
  accentColor,
  defaultOpen = false,
  children,
}: {
  label: string;
  count?: number;
  accentColor: string;
  defaultOpen?: boolean;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="rounded-2xl border border-[#1d1b18]/10 bg-white/55">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="group flex w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left transition-colors hover:bg-white/80"
      >
        <span className="flex items-baseline gap-2.5">
          <span
            aria-hidden
            className="h-1.5 w-1.5 shrink-0 rounded-full"
            style={{
              backgroundColor: accentColor,
              boxShadow: `0 0 6px ${accentColor}`,
            }}
          />
          <span
            className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px]"
            style={{ color: accentColor }}
          >
            {label}
          </span>
          {typeof count === "number" && (
            <span
              className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold text-[#8a7f76]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {String(count).padStart(2, "0")}
            </span>
          )}
        </span>
        <span
          aria-hidden
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[#1d1b18]/15 text-[#4c463f] transition-transform duration-200 group-hover:border-[#1d1b18]/35"
          style={{ transform: open ? "rotate(45deg)" : "rotate(0deg)" }}
        >
          <svg
            viewBox="0 0 12 12"
            className="h-3 w-3"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          >
            <path d="M6 1.5v9M1.5 6h9" />
          </svg>
        </span>
      </button>
      {open && (
        <div className="border-t border-[#1d1b18]/8 px-4 py-3">{children}</div>
      )}
    </div>
  );
}
