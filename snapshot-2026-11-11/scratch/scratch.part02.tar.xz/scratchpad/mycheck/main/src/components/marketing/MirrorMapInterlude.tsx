"use client";

import { motion, useReducedMotion } from "framer-motion";

interface MirrorMapInterludeProps {
  setupLine1: string;
  setupLine2: string;
  landingLine: string;
  leftWord: string;
  rightWord: string;
  eyebrowLabel: string;
  nextChapterLabel: string;
}

const EASE = [0.22, 1, 0.36, 1] as const;

/**
 * Interlude between § 03 and § 04 — a cinematic dark chapter break.
 *
 * This is the page's palate cleanser: the reader has just finished
 * the biological-age chapter and is about to enter the longevity-
 * score chapter. The interlude lands like the black spread page
 * between two essays in a print magazine — full-bleed ink, quiet
 * setup lines, a hairline caesura, and a display-scale thesis
 * that sets the reader up for what's next.
 *
 * Composition (top → bottom):
 *   1. Thin terra rule + small eyebrow label (BETWEEN CHAPTERS · § III ½)
 *   2. Two muted setup sentences at body scale, stacked and centered
 *   3. A narrow centered divider rule
 *   4. The punchline as two display-scale italic lines with the two
 *      concept words (mirror / map) in accent colors — terra-light
 *      for mirror (ties back to § 03) and gold for map (ties forward
 *      to § 04)
 *   5. Small forward-pointer footer + bottom rule
 *
 * Motion: everything fades in on scroll with a staggered cascade,
 * rules draw in via scaleX. Full sequence ~2.5s. The punchline lines
 * rise from below at the highest scale + Y delta to feel like the
 * moment the interlude resolves. Respects prefers-reduced-motion.
 */
export function MirrorMapInterlude({
  setupLine1,
  setupLine2,
  landingLine,
  leftWord,
  rightWord,
  eyebrowLabel,
  nextChapterLabel,
}: MirrorMapInterludeProps) {
  const reduce = useReducedMotion();

  // Split the landing line ("The first is a mirror. The second is a map.")
  // into two sentences so each can stand at display scale.
  const [sentence1 = "", sentence2 = ""] = landingLine
    .split(/\.\s*/)
    .map((s) => s.trim())
    .filter(Boolean);

  const enter = (delay: number, y = 22) =>
    reduce
      ? { initial: false, animate: { opacity: 1, y: 0 } }
      : ({
          initial: { opacity: 0, y },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, amount: 0.2 },
          transition: { duration: 0.9, delay, ease: EASE },
        } as const);

  const drawRule = (delay: number, duration = 1.3) =>
    reduce
      ? { initial: false, animate: { scaleX: 1 } }
      : ({
          initial: { scaleX: 0 },
          whileInView: { scaleX: 1 },
          viewport: { once: true },
          transition: { duration, delay, ease: EASE },
        } as const);

  return (
    <div className="relative">
      {/* ─── Top: rule + eyebrow ─────────────────────────────── */}
      <div className="flex flex-col items-center">
        <motion.span
          aria-hidden
          className="block h-px origin-center bg-[#d97b5c]/70"
          style={{ width: "72px" }}
          {...drawRule(0)}
        />
        <motion.span
          className="mt-5 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[3.5px] text-[#d97b5c]"
          {...enter(0.3, 8)}
        >
          {eyebrowLabel}
        </motion.span>
      </div>

      {/* ─── Quiet setup lines (stacked, centered, muted cream) ─── */}
      <div className="mx-auto mt-20 max-w-[820px] text-center md:mt-28">
        <motion.p
          {...enter(0.45)}
          className="font-[family-name:var(--font-sentient)] italic leading-[1.4] text-[#fef8f2]/65"
          style={{ fontSize: "clamp(19px, 2.6vw, 28px)" }}
        >
          {setupLine1}
        </motion.p>
        <motion.p
          {...enter(0.65)}
          className="mt-5 font-[family-name:var(--font-sentient)] italic leading-[1.4] text-[#fef8f2]/65 md:mt-7"
          style={{ fontSize: "clamp(19px, 2.6vw, 28px)" }}
        >
          {setupLine2}
        </motion.p>
      </div>

      {/* ─── Thin centered divider — marks the pivot ─── */}
      <motion.span
        aria-hidden
        className="mx-auto mt-20 block h-px origin-center bg-[#fef8f2]/25 md:mt-28"
        style={{ width: "clamp(140px, 22vw, 280px)" }}
        {...drawRule(0.85, 1.2)}
      />

      {/* ─── Punchline — two display-scale italic lines with accents ─── */}
      <div className="mx-auto mt-14 text-center md:mt-20">
        <motion.p
          {...enter(1.0, 44)}
          className="font-[family-name:var(--font-sentient)] italic leading-[1.05] text-[#fef8f2]"
          style={{ fontSize: "clamp(44px, 8.5vw, 108px)", letterSpacing: "-0.02em" }}
        >
          {accentize(sentence1, leftWord, "#e89470")}
        </motion.p>
        <motion.p
          {...enter(1.25, 44)}
          className="mt-2 font-[family-name:var(--font-sentient)] italic leading-[1.05] text-[#fef8f2] md:mt-4"
          style={{ fontSize: "clamp(44px, 8.5vw, 108px)", letterSpacing: "-0.02em" }}
        >
          {accentize(sentence2, rightWord, "#e8c068")}
        </motion.p>
      </div>

      {/* ─── Bottom: forward pointer to § 04 ─────────────────── */}
      <div className="mt-24 flex flex-col items-center md:mt-32">
        <motion.span
          className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[3.5px] text-[#e8c068]"
          {...enter(1.55, 10)}
        >
          {nextChapterLabel}
        </motion.span>
        <motion.span
          aria-hidden
          className="mt-5 block h-px origin-center bg-[#e8c068]/55"
          style={{ width: "72px" }}
          {...drawRule(1.7)}
        />
      </div>
    </div>
  );
}

/**
 * Find the accent word in a sentence (case-insensitive, last occurrence)
 * and wrap it in a colored span. Handles trailing period.
 */
function accentize(sentence: string, word: string, color: string) {
  if (!sentence) return null;
  const idx = sentence.toLowerCase().lastIndexOf(word.toLowerCase());
  if (idx === -1) return <>{sentence}.</>;
  return (
    <>
      {sentence.slice(0, idx)}
      <span style={{ color }}>
        {sentence.slice(idx, idx + word.length)}
      </span>
      {sentence.slice(idx + word.length)}.
    </>
  );
}
