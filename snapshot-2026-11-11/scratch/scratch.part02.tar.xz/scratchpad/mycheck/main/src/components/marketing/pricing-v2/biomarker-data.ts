import type { Biomarker } from "./BiomarkerGrid";

export interface BiomarkerBilingual extends Omit<Biomarker, "name" | "short" | "detects" | "matters"> {
  name: { en: string; es: string };
  /** Short label for the compact tile — must fit ~10 chars. */
  short: { en: string; es: string };
  detects: { en: string; es: string };
  matters: { en: string; es: string };
}

export const BIOMARKERS: BiomarkerBilingual[] = [
  {
    code: "ApoB",
    category: "cardio",
    range: "< 80 mg/dL",
    name: { en: "Apolipoprotein B", es: "Apolipoproteína B" },
    short: { en: "Apo B", es: "Apo B" },
    detects: {
      en: "The count of atherogenic particles that actually cause cardiovascular disease.",
      es: "El recuento de partículas aterogénicas que realmente causan enfermedad cardiovascular.",
    },
    matters: {
      en: "A stronger predictor of heart disease than LDL cholesterol. A true causal marker for cardiovascular risk.",
      es: "Un predictor más fuerte de enfermedad cardíaca que el colesterol LDL. Un marcador causal real del riesgo cardiovascular.",
    },
  },
  {
    code: "hsCRP",
    category: "cardio",
    range: "< 1.0 mg/L",
    name: { en: "hs-CRP", es: "PCR Ultrasensible" },
    short: { en: "hs-CRP", es: "hs-CRP" },
    detects: {
      en: "Low-grade systemic inflammation hiding behind 'normal' lab ranges.",
      es: "Inflamación sistémica de bajo grado que se esconde detrás de rangos 'normales'.",
    },
    matters: {
      en: "Silent inflammation drives accelerated aging, heart disease, and metabolic decline.",
      es: "La inflamación silenciosa acelera el envejecimiento, la enfermedad cardíaca y el declive metabólico.",
    },
  },
  {
    code: "HbA1c",
    category: "metabolic",
    range: "< 5.4 %",
    name: { en: "Hemoglobin A1c", es: "Hemoglobina A1c" },
    short: { en: "HbA1c", es: "HbA1c" },
    detects: {
      en: "Your average blood sugar over the last three months.",
      es: "Tu promedio de azúcar en sangre durante los últimos tres meses.",
    },
    matters: {
      en: "Picks up metabolic dysfunction years before a diabetes diagnosis.",
      es: "Detecta disfunción metabólica años antes de un diagnóstico de diabetes.",
    },
  },
  {
    code: "Ins",
    category: "metabolic",
    range: "< 7 µIU/mL",
    name: { en: "Fasting Insulin", es: "Insulina en Ayunas" },
    short: { en: "Insulin", es: "Insulina" },
    detects: {
      en: "Early insulin resistance before blood sugar ever rises.",
      es: "Resistencia a la insulina temprana, antes de que suba el azúcar en sangre.",
    },
    matters: {
      en: "The earliest warning sign of metabolic dysfunction.",
      es: "La primera señal de alerta de disfunción metabólica.",
    },
  },
  {
    code: "Trig",
    category: "metabolic",
    range: "< 100 mg/dL",
    name: { en: "Triglycerides", es: "Triglicéridos" },
    short: { en: "Triglyc.", es: "Triglic." },
    detects: {
      en: "Fat circulating in the blood after meals.",
      es: "Grasa circulando en la sangre después de las comidas.",
    },
    matters: {
      en: "Strong indicator of metabolic health and cardiovascular risk.",
      es: "Fuerte indicador de salud metabólica y riesgo cardiovascular.",
    },
  },
  {
    code: "HDL",
    category: "cardio",
    range: "> 55 mg/dL",
    name: { en: "HDL Cholesterol", es: "Colesterol HDL" },
    short: { en: "HDL", es: "HDL" },
    detects: {
      en: "Protective cholesterol that clears arteries.",
      es: "Colesterol protector que limpia las arterias.",
    },
    matters: {
      en: "Higher HDL correlates with longer lifespan and lower heart disease risk.",
      es: "Un HDL más alto se correlaciona con mayor longevidad y menor riesgo cardíaco.",
    },
  },
  {
    code: "LDL",
    category: "cardio",
    range: "< 100 mg/dL",
    name: { en: "LDL Cholesterol", es: "Colesterol LDL" },
    short: { en: "LDL", es: "LDL" },
    detects: {
      en: "Cholesterol that can deposit in artery walls.",
      es: "Colesterol que puede depositarse en las paredes arteriales.",
    },
    matters: {
      en: "Chronic elevation is a leading cause of heart disease.",
      es: "Su elevación crónica es una causa principal de enfermedad cardíaca.",
    },
  },
  {
    code: "Ferr",
    category: "nutrient",
    range: "30 – 150 ng/mL",
    name: { en: "Ferritin", es: "Ferritina" },
    short: { en: "Ferritin", es: "Ferritina" },
    detects: {
      en: "Iron storage in the body.",
      es: "Reserva de hierro en el cuerpo.",
    },
    matters: {
      en: "Too low: fatigue and hair loss. Too high: inflammation and organ stress.",
      es: "Muy bajo: fatiga y caída de cabello. Muy alto: inflamación y estrés orgánico.",
    },
  },
  {
    code: "VitD",
    category: "nutrient",
    range: "40 – 60 ng/mL",
    name: { en: "Vitamin D", es: "Vitamina D" },
    short: { en: "Vit. D", es: "Vit. D" },
    detects: {
      en: "Your body's vitamin D status.",
      es: "El estado de vitamina D de tu cuerpo.",
    },
    matters: {
      en: "Affects immunity, hormones, mood, and bone density. Widely deficient in modern life.",
      es: "Afecta inmunidad, hormonas, estado de ánimo y densidad ósea. Ampliamente deficiente en la vida moderna.",
    },
  },
  {
    code: "B12",
    category: "nutrient",
    range: "400 – 900 pg/mL",
    name: { en: "Vitamin B12", es: "Vitamina B12" },
    short: { en: "Vit. B12", es: "Vit. B12" },
    detects: {
      en: "A key B-vitamin for energy and nervous system function.",
      es: "Una vitamina B clave para la energía y función del sistema nervioso.",
    },
    matters: {
      en: "Low levels drive fatigue, brain fog, and nerve damage if sustained.",
      es: "Niveles bajos causan fatiga, niebla mental y daño nervioso si se mantienen.",
    },
  },
  {
    code: "TSH",
    category: "metabolic",
    range: "0.5 – 2.5 mIU/L",
    name: { en: "Thyroid-Stimulating Hormone", es: "Hormona Estimulante de la Tiroides" },
    short: { en: "TSH", es: "TSH" },
    detects: {
      en: "Signals from the brain to the thyroid gland.",
      es: "Señales del cerebro a la glándula tiroides.",
    },
    matters: {
      en: "Drives metabolism, energy, mood, and body temperature regulation.",
      es: "Regula el metabolismo, la energía, el estado de ánimo y la temperatura corporal.",
    },
  },
  {
    code: "ALT",
    category: "metabolic",
    range: "< 25 U/L",
    name: { en: "Alanine Aminotransferase", es: "Alanina Aminotransferasa" },
    short: { en: "ALT", es: "ALT" },
    detects: {
      en: "Liver cell stress or damage.",
      es: "Estrés o daño en células del hígado.",
    },
    matters: {
      en: "Detects early fatty liver, one of the most reversible metabolic conditions.",
      es: "Detecta hígado graso temprano, una de las condiciones metabólicas más reversibles.",
    },
  },
  {
    code: "Creat",
    category: "metabolic",
    range: "0.7 – 1.2 mg/dL",
    name: { en: "Creatinine", es: "Creatinina" },
    short: { en: "Creatinine", es: "Creatinina" },
    detects: {
      en: "Kidney filtration function.",
      es: "Función de filtración renal.",
    },
    matters: {
      en: "Kidneys fail silently; creatinine catches declining function early.",
      es: "Los riñones fallan silenciosamente; la creatinina detecta su declive temprano.",
    },
  },
  {
    code: "UA",
    category: "metabolic",
    range: "3.5 – 6.0 mg/dL",
    name: { en: "Uric Acid", es: "Ácido Úrico" },
    short: { en: "Uric Acid", es: "Ác. Úrico" },
    detects: {
      en: "A byproduct of purine metabolism.",
      es: "Un producto del metabolismo de las purinas.",
    },
    matters: {
      en: "Linked to gout, high blood pressure, and metabolic syndrome.",
      es: "Vinculado a gota, hipertensión y síndrome metabólico.",
    },
  },
  {
    code: "GGT",
    category: "metabolic",
    range: "< 30 U/L",
    name: { en: "Gamma-GT", es: "Gamma-GT" },
    short: { en: "Gamma-GT", es: "Gamma-GT" },
    detects: {
      en: "Liver and bile duct stress.",
      es: "Estrés del hígado y las vías biliares.",
    },
    matters: {
      en: "A sensitive early marker of oxidative stress and toxin load.",
      es: "Un marcador temprano sensible de estrés oxidativo y carga tóxica.",
    },
  },
];

export function getBiomarkersForLocale(locale: "en" | "es"): Biomarker[] {
  return BIOMARKERS.map((m) => ({
    code: m.code,
    category: m.category,
    range: m.range,
    name: m.name[locale],
    short: m.short[locale],
    detects: m.detects[locale],
    matters: m.matters[locale],
  }));
}
