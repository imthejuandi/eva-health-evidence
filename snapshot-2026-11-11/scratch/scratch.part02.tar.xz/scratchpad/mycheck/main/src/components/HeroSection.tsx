"use client";

import { motion } from "framer-motion";
import dynamic from "next/dynamic";

const GradientBackground = dynamic(() => import("./GradientBackground"), {
  ssr: false,
});

const trustItems = [
  {
    label: "Needle-free at home",
    icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
  },
  {
    label: "15 core biomarkers",
    icon: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z",
  },
  {
    label: "Biological Age included",
    icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
  },
  {
    label: "From \u20AC99/quarter",
    icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
  },
];

export default function HeroSection() {
  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-[#0a0e1a] flex items-center justify-center">
      {/* 3D Animated Gradient Background */}
      <GradientBackground />

      {/* Overlay for text readability */}
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-[#0a0e1a]/50 via-[#0a0e1a]/20 to-[#0a0e1a]/80" />

      {/* Hero Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-6 sm:px-8 lg:px-12 text-center flex flex-col items-center">
        {/* Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/15 bg-cyan-950/40 px-4 py-1.5 text-[13px] font-medium tracking-wide text-cyan-300/90 backdrop-blur-sm uppercase">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cyan-400" />
            </span>
            Precision Preventative Health
          </span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="mt-8 text-[2.5rem] font-bold leading-[1.08] tracking-[-0.02em] text-white sm:text-5xl md:text-6xl lg:text-[4.25rem]"
        >
          Your labs say you&apos;re fine.
          <br />
          <span className="bg-gradient-to-r from-cyan-300 via-cyan-400 to-teal-400 bg-clip-text text-transparent">
            Your body knows different.
          </span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.6 }}
          className="mt-7 max-w-xl text-base leading-relaxed text-slate-400 sm:text-[1.125rem] sm:leading-[1.7]"
        >
          EVA reinterprets your biomarkers against longevity-optimised ranges,
          revealing what &ldquo;normal&rdquo; results actually mean for your energy,
          aging, and long-term health.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
          className="mt-12 flex flex-col items-center gap-3.5 sm:flex-row"
        >
          <button className="group relative inline-flex h-[52px] items-center justify-center gap-2.5 overflow-hidden rounded-full bg-gradient-to-r from-cyan-500 to-teal-500 px-8 text-[15px] font-semibold text-white shadow-lg shadow-cyan-500/20 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/25 hover:scale-[1.02] active:scale-[0.98]">
            <span className="relative z-10">Start Your Health Journey</span>
            <svg
              className="relative z-10 h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-teal-400 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
          </button>

          <button className="group inline-flex h-[52px] items-center justify-center gap-2.5 rounded-full border border-white/10 bg-white/[0.03] px-8 text-[15px] font-medium text-slate-300 backdrop-blur-sm transition-all duration-300 hover:border-cyan-400/25 hover:bg-white/[0.06] hover:text-white">
            <svg className="h-4 w-4 text-cyan-400/70" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Upload Your Labs Free
          </button>
        </motion.div>

        {/* Trust indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="mt-16 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4 sm:gap-x-10"
        >
          {trustItems.map((item) => (
            <div key={item.label} className="flex flex-col items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-cyan-500/10">
                <svg className="h-4 w-4 text-cyan-400/80" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={item.icon} />
                </svg>
              </div>
              <span className="text-[13px] font-medium text-slate-400/90">{item.label}</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 z-[2] h-40 bg-gradient-to-t from-[#0a0e1a] to-transparent" />
    </section>
  );
}
