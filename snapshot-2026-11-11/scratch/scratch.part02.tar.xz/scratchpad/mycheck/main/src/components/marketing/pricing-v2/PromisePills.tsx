"use client";

import { motion, useReducedMotion } from "framer-motion";

interface Promise {
  /** Retained for source compat; no longer rendered as an icon. */
  icon?: "cancel" | "lock" | "sparkles";
  title: string;
  body: string;
}

interface PromisePillsProps {
  items: Promise[];
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function PromisePills({ items }: PromisePillsProps) {
  const reduce = useReducedMotion();

  return (
    <ul className="grid grid-cols-1 border-t border-white/15 md:grid-cols-3 md:border-t-0">
      {items.map((item, idx) => (
        <motion.li
          key={item.title}
          initial={reduce ? false : { opacity: 0, y: 8 }}
          whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{
            duration: 0.55,
            delay: idx * 0.1,
            ease: EASE_QUART,
          }}
          className="relative flex flex-col gap-[var(--space-sm)] py-[var(--space-xl)] md:border-t md:border-white/15 md:pr-[var(--space-2xl)] md:pt-[var(--space-lg)]"
        >
          <span
            aria-hidden
            className="inline-block h-[1px] w-[24px] bg-[var(--color-eva-mint)]"
          />
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-mint)]">
            § {String(idx + 1).padStart(2, "0")}
          </span>
          <span className="font-[family-name:var(--font-sentient)] text-[clamp(1.25rem,2vw,1.625rem)] font-medium leading-[1.2] tracking-[-0.015em] text-white">
            {item.title}
          </span>
          <p className="max-w-[30ch] font-[family-name:var(--font-manrope)] text-[14px] leading-[1.55] text-white/65">
            {item.body}
          </p>
        </motion.li>
      ))}
    </ul>
  );
}
