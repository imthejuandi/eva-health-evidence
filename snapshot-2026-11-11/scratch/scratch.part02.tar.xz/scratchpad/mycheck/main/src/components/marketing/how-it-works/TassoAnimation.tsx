"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence, useInView } from "framer-motion";

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

interface Props {
  labels: { stick: string; click: string; wait: string; done: string };
  descriptions: { stick: string; click: string; wait: string; done: string };
  tapContinue: string;
  tapRestart: string;
  className?: string;
}

export function TassoAnimation({ labels, descriptions, tapContinue, tapRestart, className }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-5%" });
  const [step, setStep] = useState(0);
  
  // Track animation phase within step 3
  const [step3Phase, setStep3Phase] = useState(0);

  const steps = [
    { num: "01", label: labels.stick, color: "#97472c" },
    { num: "02", label: labels.click, color: "#97472c" },
    { num: "03", label: labels.wait, color: "#c49332" },
    { num: "04", label: labels.done, color: "#3a665e" },
  ];

  const handleNext = () => {
    if (step === 3) {
      setStep(0);
      setStep3Phase(0);
    } else {
      setStep((s) => s + 1);
    }
  };

  // Auto-advance from step 2 to step 3 after blood fill animation completes
  useEffect(() => {
    if (step === 2) {
      const timer = setTimeout(() => {
        setStep(3);
        setStep3Phase(0);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [step]);
  
  // Step 3 phases: 0=blood fill, 1=disconnect, 2=cap, 3=envelope, 4=done
  useEffect(() => {
    if (step === 3) {
      // Blood finishes filling (1.5s)
      const t1 = setTimeout(() => setStep3Phase(1), 1500);
      // Device fades, tube disconnects (3s)
      const t2 = setTimeout(() => setStep3Phase(2), 3000);
      // Cap twists on (5s)
      const t3 = setTimeout(() => setStep3Phase(3), 5000);
      // Into envelope (7s)
      const t4 = setTimeout(() => setStep3Phase(4), 7000);
      
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
        clearTimeout(t3);
        clearTimeout(t4);
      };
    }
  }, [step]);

  // Blood fill: tube is 90px tall (y: 182 to 272)
  const tubeHeight = 90;
  const bloodHeight = step === 2 ? tubeHeight * 0.6 : step >= 3 ? tubeHeight : 0;
  const bloodY = 272 - bloodHeight;

  return (
    <div ref={ref} className={`flex flex-col items-center ${className ?? ""}`}>
      <motion.div
        className="relative cursor-pointer select-none"
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
        transition={{ duration: 0.6, ease: EASE }}
        onClick={handleNext}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && handleNext()}
        aria-label="Advance animation step"
      >
        <svg viewBox="0 0 200 340" className="w-[200px] md:w-[240px]" aria-hidden>
          <defs>
            {/* Device body gradient - white/cream */}
            <linearGradient id="device-body" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#f5f2ed" />
            </linearGradient>
            
            {/* Button gradient - coral/orange */}
            <radialGradient id="button-grad" cx="0.35" cy="0.3" r="0.65">
              <stop offset="0%" stopColor="#f28060" />
              <stop offset="100%" stopColor="#e86550" />
            </radialGradient>
            
            {/* Blood gradient - bright red */}
            <linearGradient id="blood-grad" x1="0" y1="1" x2="0" y2="0">
              <stop offset="0%" stopColor="#8B0000" />
              <stop offset="50%" stopColor="#CC0000" />
              <stop offset="100%" stopColor="#E32636" />
            </linearGradient>
            
            {/* Shadow */}
            <filter id="device-shadow" x="-40%" y="-40%" width="180%" height="180%">
              <feDropShadow dx="0" dy="4" stdDeviation="8" floodColor="#000" floodOpacity="0.12" />
            </filter>

            {/* Clip for blood inside tube */}
            <clipPath id="blood-clip">
              <rect x="88" y="182" width="24" height="90" rx="4" />
            </clipPath>
            
            {/* Skin contact radial gradient - fades outward */}
            <radialGradient id="skin-contact" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0%" stopColor="#e8c4b0" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#e8c4b0" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#e8c4b0" stopOpacity="0" />
            </radialGradient>
          </defs>
          
          {/* ==================== SKIN PATCH ==================== */}
          <motion.g
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ 
              scale: step === 0 ? 0.75 : 1.15,
              opacity: inView && (step < 3 || step3Phase < 1) ? 1 : 0
            }}
            transition={{ duration: 0.6, ease: EASE, delay: 0.15 }}
            style={{ transformOrigin: "100px 120px" }}
          >
            <motion.circle cx="100" cy="120" fill="url(#skin-contact)" initial={{ r: 85 }} animate={{ r: step >= 1 ? 105 : 85 }} transition={{ duration: 0.5, ease: EASE }} />
            <motion.circle cx="100" cy="120" fill="#e8c4b0" initial={{ r: 68, opacity: 0 }} animate={{ r: step >= 1 ? 88 : 68, opacity: inView ? 0.85 : 0 }} transition={{ duration: 0.5, ease: EASE }} />
            <motion.circle cx="100" cy="120" fill="#ddb8a0" initial={{ r: 50, opacity: 0 }} animate={{ r: step >= 1 ? 72 : 50, opacity: inView ? 1 : 0 }} transition={{ duration: 0.4, ease: EASE, delay: 0.05 }} />
            <motion.circle cx="100" cy="120" r="50" fill="none" stroke="#c9a080" strokeWidth="2.5" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: step >= 1 ? 0.6 : 0, scale: step >= 1 ? 1 : 0.8 }} transition={{ duration: 0.35 }} style={{ transformOrigin: "100px 120px" }} />
            <motion.path d="M 55 95 Q 100 70 145 95" fill="none" stroke="#f5e0d0" strokeWidth="4" strokeLinecap="round" initial={{ opacity: 0, pathLength: 0 }} animate={{ opacity: step >= 0 ? 0.6 : 0, pathLength: step >= 0 ? 1 : 0 }} transition={{ duration: 0.5, delay: 0.2 }} />
          </motion.g>

          {/* ==================== TASSO+ DEVICE (visible steps 0-2, fades in step 3 phase 1) ==================== */}
          <motion.g
            filter="url(#device-shadow)"
            initial={{ y: -40, opacity: 0 }}
            animate={{ 
              y: step === 3 && step3Phase >= 1 ? -20 : 0,
              opacity: inView && (step < 3 || step3Phase < 1) ? 1 : 0
            }}
            transition={{ duration: 0.5, ease: EASE, delay: step === 3 ? 0 : 0.5 }}
          >
            {/* Device body - teardrop shape */}
            <path
              d="M 100 30 C 55 30 35 65 35 105 C 35 145 55 165 80 175 L 80 180 L 120 180 L 120 175 C 145 165 165 145 165 105 C 165 65 145 30 100 30 Z"
              fill="url(#device-body)"
              stroke="#e8e4de"
              strokeWidth="1.5"
            />
            
            {/* Inner ring */}
            <circle cx="100" cy="100" r="38" fill="#faf9f7" stroke="#eae6e0" strokeWidth="1" />
            
            {/* Coral button */}
            <motion.circle
              cx="100" cy="100" r="30"
              fill="url(#button-grad)"
              animate={step === 1 ? { scale: [1, 0.88, 1] } : { scale: 1 }}
              transition={{ duration: 0.2 }}
              style={{ transformOrigin: "100px 100px" }}
            />
            
            {/* Cross indent */}
            <motion.g animate={step === 1 ? { scale: [1, 0.88, 1] } : { scale: 1 }} transition={{ duration: 0.2 }} style={{ transformOrigin: "100px 100px" }}>
              <rect x="96" y="78" width="8" height="44" rx="2" fill="#c75545" fillOpacity="0.4" />
              <rect x="78" y="96" width="44" height="8" rx="2" fill="#c75545" fillOpacity="0.4" />
            </motion.g>
            
            {/* Button highlight */}
            <ellipse cx="90" cy="88" rx="8" ry="4" fill="#fff" fillOpacity="0.45" />

            {/* Tube connector */}
            <rect x="90" y="175" width="20" height="10" rx="2" fill="#e8e4de" />
            
            {/* Tube body */}
            <rect x="86" y="180" width="28" height="95" rx="5" fill="#fafafa" stroke="#d0d0d0" strokeWidth="1" />
            <rect x="88" y="182" width="24" height="90" rx="4" fill="#ffffff" />
            
            {/* Graduation marks */}
            <line x1="88" y1="200" x2="94" y2="200" stroke="#ccc" strokeWidth="0.75" />
            <line x1="88" y1="220" x2="94" y2="220" stroke="#ccc" strokeWidth="0.75" />
            <line x1="88" y1="240" x2="94" y2="240" stroke="#ccc" strokeWidth="0.75" />
            <line x1="88" y1="260" x2="94" y2="260" stroke="#ccc" strokeWidth="0.75" />
            
            {/* Blood fill */}
            <g clipPath="url(#blood-clip)">
              <motion.rect
                x="88"
                width="24"
                rx="3"
                fill="url(#blood-grad)"
                animate={{ height: bloodHeight, y: bloodY }}
                transition={{ duration: step === 2 ? 2.5 : step === 3 ? 1.2 : 0.3, ease: "easeOut" }}
              />
            </g>
            
            {/* Tube bottom cap */}
            <rect x="86" y="272" width="28" height="6" rx="2" fill="#e0e0e0" stroke="#c8c8c8" strokeWidth="0.5" />
          </motion.g>

          {/* ==================== LANCET FLASH (step 1) ==================== */}
          <AnimatePresence>
            {step === 1 && (
              <motion.circle
                cx="100" cy="175" r="0"
                fill="#97472c"
                initial={{ r: 0, opacity: 0.6 }}
                animate={{ r: [0, 15, 25], opacity: [0.6, 0.3, 0] }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35 }}
              />
            )}
          </AnimatePresence>

          {/* ==================== VACUUM RIPPLES (step 2) ==================== */}
          <AnimatePresence>
            {step === 2 && (
              <>
                <motion.circle cx="100" cy="100" r="40" fill="none" stroke="#c49332" strokeWidth="1.5" initial={{ scale: 1, opacity: 0 }} animate={{ scale: [1, 1.6], opacity: [0.5, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut" }} style={{ transformOrigin: "100px 100px" }} />
                <motion.circle cx="100" cy="100" r="40" fill="none" stroke="#c49332" strokeWidth="1.5" initial={{ scale: 1, opacity: 0 }} animate={{ scale: [1, 1.6], opacity: [0.5, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: "easeOut", delay: 0.6 }} style={{ transformOrigin: "100px 100px" }} />
              </>
            )}
          </AnimatePresence>

          {/* ==================== STEP 3: DISCONNECTED TUBE + CAP + ENVELOPE ==================== */}
          <AnimatePresence>
            {step === 3 && step3Phase >= 1 && (
              <motion.g initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
                
                {/* Detached tube - moves from device position to center then into envelope */}
                <motion.g
                  initial={{ y: 0, scale: 1 }}
                  animate={{ 
                    y: step3Phase >= 4 ? 100 : step3Phase >= 3 ? -40 : 0,
                    scale: step3Phase >= 4 ? 0.3 : step3Phase >= 3 ? 0.5 : 1,
                    opacity: step3Phase >= 4 ? 0 : 1
                  }}
                  transition={{ duration: 1.5, ease: EASE }}
                >
                  {/* Tube body */}
                  <rect x="86" y="100" width="28" height="95" rx="5" fill="#fafafa" stroke="#d0d0d0" strokeWidth="1" />
                  <rect x="88" y="102" width="24" height="90" rx="4" fill="#ffffff" />
                  
                  {/* Blood - full */}
                  <rect x="88" y="102" width="24" height="90" rx="4" fill="url(#blood-grad)" />
                  
                  {/* Graduation marks */}
                  <line x1="88" y1="120" x2="94" y2="120" stroke="#ccc" strokeWidth="0.75" />
                  <line x1="88" y1="140" x2="94" y2="140" stroke="#ccc" strokeWidth="0.75" />
                  <line x1="88" y1="160" x2="94" y2="160" stroke="#ccc" strokeWidth="0.75" />
                  <line x1="88" y1="180" x2="94" y2="180" stroke="#ccc" strokeWidth="0.75" />
                  
                  {/* Bottom cap */}
                  <rect x="86" y="192" width="28" height="6" rx="2" fill="#e0e0e0" stroke="#c8c8c8" strokeWidth="0.5" />
                  
                  {/* Top cap - twists on starting at phase 2 */}
                  <motion.g
                    initial={{ y: -50, rotate: -360, opacity: 0 }}
                    animate={{ 
                      y: step3Phase >= 2 ? 0 : -50,
                      rotate: step3Phase >= 2 ? 0 : -360,
                      opacity: step3Phase >= 2 ? 1 : 0
                    }}
                    transition={{ duration: 1.8, ease: EASE }}
                    style={{ transformOrigin: "100px 100px" }}
                  >
                    <rect x="82" y="88" width="36" height="16" rx="4" fill="#e86550" />
                    <rect x="84" y="90" width="32" height="4" rx="2" fill="#c75545" fillOpacity="0.35" />
                    <line x1="86" y1="96" x2="86" y2="102" stroke="#c75545" strokeWidth="1.5" strokeOpacity="0.5" />
                    <line x1="91" y1="96" x2="91" y2="102" stroke="#c75545" strokeWidth="1.5" strokeOpacity="0.5" />
                    <line x1="96" y1="96" x2="96" y2="102" stroke="#c75545" strokeWidth="1.5" strokeOpacity="0.5" />
                    <line x1="101" y1="96" x2="101" y2="102" stroke="#c75545" strokeWidth="1.5" strokeOpacity="0.5" />
                    <line x1="106" y1="96" x2="106" y2="102" stroke="#c75545" strokeWidth="1.5" strokeOpacity="0.5" />
                    <line x1="111" y1="96" x2="111" y2="102" stroke="#c75545" strokeWidth="1.5" strokeOpacity="0.5" />
                    <ellipse cx="92" cy="92" rx="6" ry="2" fill="#fff" fillOpacity="0.3" />
                  </motion.g>
                </motion.g>
                
                {/* Envelope - centered */}
                <motion.g
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ 
                    opacity: step3Phase >= 3 ? 1 : 0,
                    y: step3Phase >= 3 ? 0 : 40
                  }}
                  transition={{ duration: 0.8, ease: EASE }}
                >
                  <rect x="25" y="200" width="150" height="100" rx="6" fill="#f5f2ed" stroke="#d4cfc5" strokeWidth="2" />
                  <rect x="33" y="208" width="134" height="84" rx="3" fill="#ebe7e0" fillOpacity="0.5" />
                  
                  {/* Flap */}
                  <motion.path
                    d="M 25 206 L 100 260 L 175 206 L 175 200 L 25 200 Z"
                    fill="#e8e4de"
                    stroke="#d4cfc5"
                    strokeWidth="1.5"
                    initial={{ scaleY: -1 }}
                    animate={{ scaleY: step3Phase >= 4 ? 1 : -1 }}
                    transition={{ duration: 0.8, ease: EASE }}
                    style={{ transformOrigin: "100px 203px" }}
                  />
                  
                  {/* Seal line */}
                  <motion.line
                    x1="25" y1="206" x2="175" y2="206"
                    stroke="#d4cfc5" strokeWidth="1.5"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: step3Phase >= 4 ? 1 : 0 }}
                    transition={{ duration: 0.3, delay: 0.5 }}
                  />
                  
                  {/* Medical cross */}
                  <motion.g
                    initial={{ opacity: 0 }}
                    animate={{ opacity: step3Phase >= 4 ? 1 : 0 }}
                    transition={{ duration: 0.4, delay: 0.7 }}
                  >
                    <rect x="93" y="245" width="14" height="5" rx="1.5" fill="#3a665e" fillOpacity="0.7" />
                    <rect x="97.5" y="240" width="5" height="15" rx="1.5" fill="#3a665e" fillOpacity="0.7" />
                  </motion.g>
                </motion.g>
                
                {/* Checkmark - centered above envelope */}
                <motion.g
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: step3Phase >= 4 ? 1 : 0, scale: step3Phase >= 4 ? 1 : 0.5 }}
                  transition={{ duration: 0.4, delay: 1 }}
                >
                  <circle cx="100" cy="160" r="18" fill="#3a665e" fillOpacity="0.15" />
                  <motion.path
                    d="M 89 160 L 96 168 L 112 150"
                    fill="none"
                    stroke="#3a665e"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: step3Phase >= 4 ? 1 : 0 }}
                    transition={{ duration: 0.4, delay: 1.2 }}
                  />
                </motion.g>
              </motion.g>
            )}
          </AnimatePresence>

          {/* Tap hint */}
          <motion.text
            x="100"
            y="325"
            textAnchor="middle"
            className="fill-muted-foreground text-[10px] uppercase tracking-widest"
            initial={{ opacity: 0 }}
            animate={{ opacity: inView ? 0.5 : 0 }}
            transition={{ delay: 0.7 }}
          >
            {step === 3 && step3Phase >= 4 ? tapRestart : tapContinue}
          </motion.text>
        </svg>
      </motion.div>

      {/* Step Label */}
      <motion.div
        className="mt-6 flex items-center gap-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: inView ? 1 : 0 }}
        transition={{ duration: 0.3, delay: 0.4 }}
      >
        <span
          className="flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold transition-colors duration-300"
          style={{ backgroundColor: `${steps[step].color}18`, color: steps[step].color }}
        >
          {step === 3 ? "\u2713" : steps[step].num}
        </span>
        <AnimatePresence mode="wait">
          <motion.p
            key={step}
            className="text-lg font-semibold text-foreground md:text-xl"
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
          >
            {steps[step].label}
          </motion.p>
        </AnimatePresence>
      </motion.div>

      {/* Step Indicators */}
      <div className="mt-5 flex gap-2">
        {steps.map((s, i) => (
          <button
            key={i}
            onClick={(e) => { e.stopPropagation(); setStep(i); setStep3Phase(0); }}
            className="h-2.5 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2"
            style={{
              width: step === i ? 28 : 10,
              backgroundColor: step >= i ? steps[i].color : "rgba(29,27,24,0.12)",
            }}
            aria-label={`Step ${i + 1}: ${s.label}`}
          />
        ))}
      </div>

      {/* Step Description */}
      <AnimatePresence mode="wait">
        <motion.p
          key={step}
          className="mt-3 max-w-[260px] text-center text-sm text-muted-foreground"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.25 }}
        >
          {step === 0 && descriptions.stick}
          {step === 1 && descriptions.click}
          {step === 2 && descriptions.wait}
          {step === 3 && descriptions.done}
        </motion.p>
      </AnimatePresence>
    </div>
  );
}
