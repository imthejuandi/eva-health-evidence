"use client";

interface SourceTagProps {
  source: string;
}

export function SourceTag({ source }: SourceTagProps) {
  const isEva = source.toLowerCase() === "eva" || source.toLowerCase() === "eva_kit";

  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1px] ${
        isEva
          ? "bg-[rgba(151,71,44,0.08)] text-[#97472c]"
          : "bg-[rgba(58,102,94,0.08)] text-[#3a665e]"
      }`}
    >
      {isEva ? "EVA" : "Uploaded"}
    </span>
  );
}
