"use client";

import { useEffect, type ReactNode } from "react";
import { motion } from "framer-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

interface EditorialModalProps {
  open: boolean;
  onClose: () => void;
  /** Mono kicker shown above the title (e.g. "§ Confirm removal"). */
  kicker: string;
  /** Cormorant title body. */
  title: string;
  /** Italic-terra accent fragment of the title (renders as a span). */
  accent?: string;
  /** When true, Escape and backdrop clicks are blocked while a save /
   *  delete is in flight. */
  busy?: boolean;
  children: ReactNode;
}

/**
 * EditorialModal — bottom-sheet on mobile, centred card on desktop.
 * Cream surface, terra kicker, Cormorant title with optional italic
 * accent. Closes on Escape and on backdrop click (suppressed while
 * `busy`). Animates in with a soft ease-out-expo lift.
 *
 * Used by the delete-account confirm and the Apple Health import
 * sheet. The body is left to the caller via `children`.
 */
export function EditorialModal({
  open,
  onClose,
  kicker,
  title,
  accent,
  busy,
  children,
}: EditorialModalProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !busy) onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, busy, onClose]);

  if (!open) return null;
  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-end justify-center bg-[#1d1b18]/55 px-4 py-6 backdrop-blur-sm md:items-center md:py-0"
      onClick={(e) => {
        if (e.target === e.currentTarget && !busy) onClose();
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-[520px] rounded-t-[28px] bg-[#fef8f2] p-7 shadow-[0_30px_80px_-20px_rgba(151,71,44,0.4)] md:rounded-[28px] md:p-9"
      >
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
        >
          {kicker}
        </p>
        <h3
          className={`mt-4 ${FONT_CLASS.cormorant} text-[34px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[40px] md:tracking-[-0.8px]`}
          style={{ textWrap: "balance" } as React.CSSProperties}
        >
          {title}{" "}
          {accent && <span className="italic text-[#97472c]">{accent}</span>}
        </h3>
        <div className="mt-5">{children}</div>
      </motion.div>
    </div>
  );
}
