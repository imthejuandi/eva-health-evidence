"use client";

import { ZONE_CONFIG, type Zone } from "@/lib/biomarkers/zone-config";

interface StatusPillProps {
  zone: Zone;
  size?: "sm" | "md";
  locale?: string;
}

export function StatusPill({ zone, size = "md", locale = "en" }: StatusPillProps) {
  const config = ZONE_CONFIG[zone] ?? ZONE_CONFIG.unclassified;
  const label = locale === "es" ? config.label_es : config.label;

  const sizeClasses = size === "sm"
    ? "px-2 py-0.5 text-[9px] gap-1"
    : "px-2.5 py-1 text-[10px] gap-1.5";

  return (
    <span
      className={`inline-flex items-center rounded-full font-[family-name:var(--font-dm-mono)] font-semibold uppercase tracking-[0.5px] ${sizeClasses}`}
      style={{ backgroundColor: config.bg, color: config.color }}
    >
      <span
        className={`rounded-full ${size === "sm" ? "h-1.5 w-1.5" : "h-2 w-2"}`}
        style={{ backgroundColor: config.color }}
      />
      {label}
    </span>
  );
}
