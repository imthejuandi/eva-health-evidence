"use client";

import { StatusPill } from "./StatusPill";
import { SourceTag } from "./SourceTag";
import type { Zone } from "@/lib/biomarkers/zone-config";

interface BiomarkerRowProps {
  name: string;
  value: number;
  unit: string;
  zone: Zone;
  source?: string;
  onClick?: () => void;
  index?: number;
  locale?: string;
}

export function BiomarkerRow({
  name,
  value,
  unit,
  zone,
  source = "uploaded",
  onClick,
  index = 0,
  locale = "en",
}: BiomarkerRowProps) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-[16px] border border-[#e7e2dc] bg-white px-4 py-3.5 text-left transition-all hover:border-[#8a7f76] hover:shadow-[0_4px_16px_rgba(29,27,24,0.04)]"
      style={{
        animationDelay: `${index * 50}ms`,
        animation: "fadeSlideIn 0.3s ease-out both",
      }}
    >
      {/* Name + source */}
      <div className="min-w-0 flex-1">
        <p className="truncate font-[family-name:var(--font-manrope)] text-[14px] font-bold text-[#1d1b18]">
          {name}
        </p>
        <div className="mt-1">
          <SourceTag source={source} />
        </div>
      </div>

      {/* Value */}
      <div className="shrink-0 text-right">
        <span className="font-[family-name:var(--font-manrope)] text-[16px] font-extrabold text-[#1d1b18]">
          {Number.isInteger(value) ? value : value.toFixed(1)}
        </span>
        <span className="ml-1 font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">
          {unit}
        </span>
      </div>

      {/* Zone pill */}
      <div className="shrink-0">
        <StatusPill zone={zone} size="sm" locale={locale} />
      </div>

      {/* Chevron */}
      {onClick && (
        <svg
          className="h-4 w-4 shrink-0 text-[#8a7f76]"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
        </svg>
      )}

      <style jsx>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </button>
  );
}
