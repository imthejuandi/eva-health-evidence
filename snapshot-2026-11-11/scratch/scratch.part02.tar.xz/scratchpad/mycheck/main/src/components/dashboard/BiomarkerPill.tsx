"use client";

import type { BiomarkerValue } from "@/lib/queries/types";
import { groupThousands } from "@/lib/dashboard-format";

/** Format a number to at most 2 decimal places. Mirrors the `fmt`
 * helper in dashboard-client.tsx; duplicated here to keep this
 * component self-contained. */
function fmt(n: number | null | undefined, max = 2): string {
  if (n == null || !Number.isFinite(n)) return "—";
  if (Number.isInteger(n)) return groupThousands(String(n));
  return groupThousands(parseFloat(n.toFixed(max)).toString());
}

const ZONE_TONE: Record<BiomarkerValue["zone"], string> = {
  optimal: "#3a665e",
  below_optimal: "#c49332",
  above_optimal: "#c49332",
  critical_low: "#b04040",
  critical_high: "#b04040",
  unclassified: "#8a7f76",
};

/**
 * A single biomarker rendered as a pill — zone-coloured glow dot,
 * biomarker name (Manrope bold), value + unit (DM Mono). Used inside
 * action cards' "Targets" emphasis, EVA AI inline citations, and
 * anywhere else a single biomarker needs to be name-checked.
 *
 * Set `as="a"` and pass `href` to render a link instead of a div —
 * useful for citations that should jump to the biomarker detail page.
 */
export function BiomarkerPill({
  biomarker,
  href,
  className = "",
}: {
  biomarker: BiomarkerValue;
  href?: string;
  className?: string;
}) {
  const tone = ZONE_TONE[biomarker.zone] ?? "#8a7f76";
  const Tag = href ? "a" : "div";
  return (
    <Tag
      href={href}
      className={`inline-flex items-center gap-1.5 rounded-full border border-[#1d1b18]/12 bg-white px-2.5 py-1 transition-colors ${
        href ? "hover:border-[#1d1b18]/35 hover:bg-white/95" : ""
      } ${className}`}
    >
      <span
        aria-hidden
        className="h-1.5 w-1.5 rounded-full"
        style={{
          backgroundColor: tone,
          boxShadow: `0 0 6px ${tone}`,
        }}
      />
      <span className="font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#1d1b18]">
        {biomarker.biomarker_name}
      </span>
      <span
        className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold text-[#8a7f76]"
        style={{ fontVariantNumeric: "tabular-nums" }}
      >
        {biomarker.comparator === "<" || biomarker.comparator === ">" ? `${biomarker.comparator} ` : ""}
        {fmt(biomarker.value)}
        {biomarker.unit ? ` ${biomarker.unit}` : ""}
      </span>
    </Tag>
  );
}
