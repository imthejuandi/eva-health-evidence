"use client";

import { ACTION_CATEGORY_COLORS } from "@/lib/dashboard-tokens";

interface ActionStepCardProps {
  priority: number;
  category: string;
  title: string;
  description: string;
  relatedBiomarkers?: string[];
  status: "pending" | "in_progress" | "completed" | "dismissed";
  onStatusChange?: (status: "pending" | "in_progress" | "completed" | "dismissed") => void;
  locale?: string;
}

export function ActionStepCard({
  priority,
  category,
  title,
  description,
  relatedBiomarkers = [],
  status,
  onStatusChange,
}: ActionStepCardProps) {
  const catColor = ACTION_CATEGORY_COLORS[category] ?? "#8a7f76";
  const isCompleted = status === "completed";

  return (
    <div
      className={`flex items-start gap-4 rounded-[20px] border p-5 transition-all ${
        isCompleted
          ? "border-[rgba(58,102,94,0.2)] bg-[rgba(58,102,94,0.03)] opacity-70"
          : "border-[#e7e2dc] bg-white shadow-[0_8px_24px_rgba(29,27,24,0.03)]"
      }`}
    >
      {/* Priority number */}
      <span
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-[family-name:var(--font-manrope)] text-[13px] font-bold text-white"
        style={{ backgroundColor: catColor }}
      >
        {priority}
      </span>

      {/* Content */}
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className={`font-[family-name:var(--font-manrope)] text-[14px] font-bold ${isCompleted ? "line-through text-[#8a7f76]" : "text-[#1d1b18]"}`}>
              {title}
            </p>
            <span
              className="mt-1 inline-block rounded-full px-2 py-0.5 font-[family-name:var(--font-dm-mono)] text-[8px] font-semibold uppercase tracking-[1px]"
              style={{ backgroundColor: `${catColor}15`, color: catColor }}
            >
              {category}
            </span>
          </div>

          {/* Status toggle */}
          {onStatusChange && (
            <button
              onClick={() =>
                onStatusChange(isCompleted ? "pending" : "completed")
              }
              className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition-all ${
                isCompleted
                  ? "border-[#3a665e] bg-[#3a665e]"
                  : "border-[#e7e2dc] hover:border-[#8a7f76]"
              }`}
            >
              {isCompleted && (
                <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                </svg>
              )}
            </button>
          )}
        </div>

        <p className={`mt-2 font-[family-name:var(--font-inter)] text-[13px] leading-relaxed ${isCompleted ? "text-[#8a7f76]" : "text-[#4c463f]"}`}>
          {description}
        </p>

        {relatedBiomarkers.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            {relatedBiomarkers.map((key) => (
              <span
                key={key}
                className="rounded-full bg-[rgba(138,127,118,0.08)] px-2 py-0.5 font-[family-name:var(--font-dm-mono)] text-[8px] font-medium uppercase tracking-[0.5px] text-[#8a7f76]"
              >
                {key.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
