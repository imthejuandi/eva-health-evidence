"use client";

import { cn } from "@/lib/utils";

type Cell = boolean | string;

export interface MatrixColumn {
  id: "free" | "quarterly" | "full";
  name: string;
  price: string;
  priceSuffix?: string;
  highlight?: boolean;
}

export interface MatrixRow {
  label: string;
  cells: [Cell, Cell, Cell];
}

export interface MatrixGroup {
  title: string;
  rows: MatrixRow[];
}

interface ComparisonMatrixProps {
  eyebrow: string;
  headline: string;
  columns: [MatrixColumn, MatrixColumn, MatrixColumn];
  groups: MatrixGroup[];
  mostPopularLabel: string;
}

function Check() {
  return (
    <svg
      aria-hidden
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
      className="text-[var(--color-eva-jade)]"
    >
      <path
        d="M3 7.5L5.5 10L11 4"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function CellView({ value }: { value: Cell }) {
  if (value === true) return <Check />;
  if (value === false)
    return (
      <span className="font-[family-name:var(--font-dm-mono)] text-[13px] text-[var(--color-eva-on-surface)]/30" aria-label="Not included">
        —
      </span>
    );
  return (
    <span
      className="font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-on-surface)]/75"
      style={{ fontVariantNumeric: "tabular-nums" }}
    >
      {value}
    </span>
  );
}

export function ComparisonMatrix({
  eyebrow,
  headline,
  columns,
  groups,
  mostPopularLabel,
}: ComparisonMatrixProps) {
  return (
    <section className="bg-[var(--color-eva-surface)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        {/* Masthead */}
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
            {headline}
          </h2>
        </header>

        {/* Desktop table */}
        <div className="mt-[clamp(3rem,5vw,4rem)] hidden md:block">
          <div className="grid grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)] items-end border-b border-[var(--color-eva-on-surface)]/25 pb-[var(--space-lg)]">
            <span />
            {columns.map((col) => (
              <div
                key={col.id}
                className={cn(
                  "flex flex-col gap-[var(--space-sm)] pl-[var(--space-lg)]",
                  col.highlight && "relative",
                )}
              >
                {col.highlight && (
                  <span
                    aria-hidden
                    className="absolute -left-px -top-[var(--space-md)] h-[1px] w-full bg-[var(--color-eva-terra)]"
                  />
                )}
                <span
                  className={cn(
                    "font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.22em]",
                    col.highlight
                      ? "text-[var(--color-eva-terra)]"
                      : "text-[var(--color-eva-on-surface)]/50",
                  )}
                >
                  {col.highlight ? mostPopularLabel : col.name}
                </span>
                {col.highlight && (
                  <span className="font-[family-name:var(--font-manrope)] text-[14px] font-semibold text-[var(--color-eva-on-surface)]">
                    {col.name}
                  </span>
                )}
                <span className="flex items-baseline gap-[var(--space-xs)]">
                  <span
                    className="font-[family-name:var(--font-sentient)] text-[26px] font-medium leading-none tracking-[-0.02em] text-[var(--color-eva-on-surface)]"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    {col.price}
                  </span>
                  {col.priceSuffix && (
                    <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.16em] text-[var(--color-eva-on-surface)]/50">
                      {col.priceSuffix}
                    </span>
                  )}
                </span>
              </div>
            ))}
          </div>

          {groups.map((group) => (
            <div key={group.title}>
              <div className="grid grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)] border-b border-[var(--color-eva-on-surface)]/12 py-[var(--space-md)]">
                <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/45">
                  § {group.title}
                </span>
              </div>
              {group.rows.map((row) => (
                <div
                  key={row.label}
                  className="group/row grid grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)] items-center border-b border-[var(--color-eva-on-surface)]/8 py-[var(--space-md)] transition-colors hover:bg-[var(--color-eva-cream-warm)]/40"
                >
                  <span className="pr-[var(--space-lg)] font-[family-name:var(--font-manrope)] text-[14px] text-[var(--color-eva-on-surface)]/85">
                    {row.label}
                  </span>
                  {row.cells.map((cell, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "flex items-center justify-start pl-[var(--space-lg)]",
                        columns[idx]?.highlight && "relative",
                      )}
                    >
                      {columns[idx]?.highlight && (
                        <span
                          aria-hidden
                          className="pointer-events-none absolute inset-y-0 left-0 w-px bg-[var(--color-eva-terra)]/25"
                        />
                      )}
                      <CellView value={cell} />
                    </div>
                  ))}
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Mobile: stacked per plan */}
        <div className="mt-[var(--space-3xl)] flex flex-col gap-[var(--space-3xl)] md:hidden">
          {columns.map((col, colIdx) => (
            <div key={col.id} className="border-t border-[var(--color-eva-on-surface)]/20 pt-[var(--space-lg)]">
              {col.highlight && (
                <span className="inline-block font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-terra)]">
                  {mostPopularLabel}
                </span>
              )}
              <div className="mt-[var(--space-xs)] flex items-baseline justify-between gap-[var(--space-md)]">
                <span className="font-[family-name:var(--font-manrope)] text-[16px] font-semibold text-[var(--color-eva-on-surface)]">
                  {col.name}
                </span>
                <span
                  className="font-[family-name:var(--font-sentient)] text-[22px] font-medium leading-none tracking-[-0.02em] text-[var(--color-eva-on-surface)]"
                  style={{ fontVariantNumeric: "tabular-nums" }}
                >
                  {col.price}
                  {col.priceSuffix && (
                    <span className="ml-[var(--space-xs)] font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.14em] text-[var(--color-eva-on-surface)]/50">
                      {col.priceSuffix}
                    </span>
                  )}
                </span>
              </div>

              <div className="mt-[var(--space-md)] flex flex-col gap-[var(--space-md)]">
                {groups.map((group) => (
                  <div key={group.title}>
                    <div className="mb-[var(--space-xs)] font-[family-name:var(--font-dm-mono)] text-[9.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/45">
                      § {group.title}
                    </div>
                    <ul className="divide-y divide-[var(--color-eva-on-surface)]/10">
                      {group.rows.map((row) => (
                        <li
                          key={row.label}
                          className="flex items-baseline justify-between gap-[var(--space-md)] py-[var(--space-sm)]"
                        >
                          <span className="font-[family-name:var(--font-manrope)] text-[13.5px] text-[var(--color-eva-on-surface)]/80">
                            {row.label}
                          </span>
                          <span className="shrink-0"><CellView value={row.cells[colIdx]} /></span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
