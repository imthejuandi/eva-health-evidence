"use client";

import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { stagger } from "@/lib/dashboard-motion";

export function AmbientMesh() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 z-[1]"
      style={{
        background:
          "radial-gradient(circle at 20% 20%, rgba(217,123,92,0.14), transparent 50%), radial-gradient(circle at 80% 30%, rgba(188,236,225,0.22), transparent 55%), radial-gradient(circle at 50% 85%, rgba(196,147,50,0.12), transparent 60%)",
      }}
    />
  );
}

export function GrainOverlay() {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 z-[2] opacity-[0.05]"
      style={{
        backgroundImage:
          "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        backgroundRepeat: "repeat",
        backgroundSize: "256px 256px",
      }}
    />
  );
}

interface DashboardChromeProps {
  children: ReactNode;
  animate?: boolean;
  className?: string;
}

export function DashboardChrome({
  children,
  animate = true,
  className,
}: DashboardChromeProps) {
  return (
    <div className="relative min-h-screen overflow-x-clip bg-[#fef8f2] text-[#1d1b18]">
      <AmbientMesh />
      <GrainOverlay />
      {animate ? (
        <motion.div
          variants={stagger}
          initial="hidden"
          animate="show"
          className={`relative z-[2] ${className ?? ""}`}
        >
          {children}
        </motion.div>
      ) : (
        <div className={`relative z-[2] ${className ?? ""}`}>{children}</div>
      )}
    </div>
  );
}
