"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQAccordionProps {
  items: FAQItem[];
}

export function FAQAccordion({ items }: FAQAccordionProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="flex flex-col gap-3">
      {items.map((item, idx) => (
        <div
          key={idx}
          className="overflow-hidden rounded-2xl bg-white shadow-[0_20px_60px_rgba(29,27,24,0.04)]"
        >
          <button
            type="button"
            id={`faq-trigger-${idx}`}
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            aria-expanded={openIndex === idx}
            aria-controls={`faq-panel-${idx}`}
            className="flex w-full items-center justify-between px-7 py-5 text-left transition-colors hover:bg-[#fef8f2]"
          >
            <span className="font-[family-name:var(--font-dm-mono)] text-[14px] font-medium text-[#1d1b18]">
              {item.question}
            </span>
            <motion.span
              animate={{ rotate: openIndex === idx ? 45 : 0 }}
              transition={{ duration: 0.2 }}
              className="ml-4 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#f8f3ed] text-[14px] text-[#8a7f76]"
            >
              +
            </motion.span>
          </button>
          <AnimatePresence initial={false}>
            {openIndex === idx && (
              <motion.div
                id={`faq-panel-${idx}`}
                role="region"
                aria-labelledby={`faq-trigger-${idx}`}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                <div className="px-7 pb-6 font-[family-name:var(--font-manrope)] text-[14px] leading-relaxed text-[#4c463f]">
                  {item.answer}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}
