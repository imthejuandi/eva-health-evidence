"use client";

import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

function GradientMesh() {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uColor1: { value: new THREE.Color("#0f172a") },
      uColor2: { value: new THREE.Color("#0e7490") },
      uColor3: { value: new THREE.Color("#06b6d4") },
      uColor4: { value: new THREE.Color("#164e63") },
      uColor5: { value: new THREE.Color("#0891b2") },
    }),
    []
  );

  const vertexShader = `
    varying vec2 vUv;
    varying float vElevation;
    uniform float uTime;

    //	Simplex 3D Noise
    vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}
    vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}

    float snoise(vec3 v){
      const vec2 C = vec2(1.0/6.0, 1.0/3.0);
      const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
      vec3 i  = floor(v + dot(v, C.yyy));
      vec3 x0 = v - i + dot(i, C.xxx);
      vec3 g = step(x0.yzx, x0.xyz);
      vec3 l = 1.0 - g;
      vec3 i1 = min(g.xyz, l.zxy);
      vec3 i2 = max(g.xyz, l.zxy);
      vec3 x1 = x0 - i1 + C.xxx;
      vec3 x2 = x0 - i2 + C.yyy;
      vec3 x3 = x0 - D.yyy;
      i = mod(i, 289.0);
      vec4 p = permute(permute(permute(
                i.z + vec4(0.0, i1.z, i2.z, 1.0))
              + i.y + vec4(0.0, i1.y, i2.y, 1.0))
              + i.x + vec4(0.0, i1.x, i2.x, 1.0));
      float n_ = 1.0/7.0;
      vec3 ns = n_ * D.wyz - D.xzx;
      vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
      vec4 x_ = floor(j * ns.z);
      vec4 y_ = floor(j - 7.0 * x_);
      vec4 x = x_ * ns.x + ns.yyyy;
      vec4 y = y_ * ns.x + ns.yyyy;
      vec4 h = 1.0 - abs(x) - abs(y);
      vec4 b0 = vec4(x.xy, y.xy);
      vec4 b1 = vec4(x.zw, y.zw);
      vec4 s0 = floor(b0)*2.0 + 1.0;
      vec4 s1 = floor(b1)*2.0 + 1.0;
      vec4 sh = -step(h, vec4(0.0));
      vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
      vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
      vec3 p0 = vec3(a0.xy, h.x);
      vec3 p1 = vec3(a0.zw, h.y);
      vec3 p2 = vec3(a1.xy, h.z);
      vec3 p3 = vec3(a1.zw, h.w);
      vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
      p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
      vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
      m = m * m;
      return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
    }

    void main() {
      vUv = uv;
      vec3 pos = position;

      float noiseFreq = 1.5;
      float noiseAmp = 0.45;
      vec3 noisePos = vec3(pos.x * noiseFreq + uTime * 0.15, pos.y * noiseFreq + uTime * 0.1, uTime * 0.08);
      float elevation = snoise(noisePos) * noiseAmp;

      pos.z += elevation;
      vElevation = elevation;

      gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    }
  `;

  const fragmentShader = `
    varying vec2 vUv;
    varying float vElevation;
    uniform float uTime;
    uniform vec3 uColor1;
    uniform vec3 uColor2;
    uniform vec3 uColor3;
    uniform vec3 uColor4;
    uniform vec3 uColor5;

    void main() {
      float t = uTime * 0.05;

      // Create flowing gradient zones
      float zone1 = smoothstep(-0.1, 0.3, vUv.x + sin(vUv.y * 2.0 + t) * 0.15);
      float zone2 = smoothstep(0.2, 0.5, vUv.x + cos(vUv.y * 1.5 + t * 1.3) * 0.1);
      float zone3 = smoothstep(0.4, 0.7, vUv.x + sin(vUv.y * 2.5 + t * 0.7) * 0.12);
      float zone4 = smoothstep(0.6, 0.9, vUv.x + cos(vUv.y * 1.8 + t * 1.1) * 0.08);

      vec3 color = uColor1;
      color = mix(color, uColor2, zone1);
      color = mix(color, uColor3, zone2);
      color = mix(color, uColor4, zone3);
      color = mix(color, uColor5, zone4);

      // Add elevation-based brightness
      float brightness = 1.0 + vElevation * 0.3;
      color *= brightness;

      // Subtle vignette
      float vignette = 1.0 - distance(vUv, vec2(0.5)) * 0.5;
      color *= vignette;

      gl_FragColor = vec4(color, 1.0);
    }
  `;

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
    }
  });

  return (
    <mesh ref={meshRef} rotation={[-Math.PI / 3, 0, 0]} position={[0, 0, -1]}>
      <planeGeometry args={[8, 8, 128, 128]} />
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function FloatingOrbs() {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    }
  });

  const orbs = useMemo(
    () =>
      Array.from({ length: 6 }, (_, i) => ({
        position: [
          Math.sin((i / 6) * Math.PI * 2) * 2.5,
          Math.cos((i / 6) * Math.PI * 2) * 1.5 + 0.5,
          Math.sin((i / 6) * Math.PI * 2 + 1) * 1.5 - 1,
        ] as [number, number, number],
        scale: 0.08 + Math.random() * 0.12,
        speed: 0.5 + Math.random() * 0.5,
        offset: i * 1.2,
      })),
    []
  );

  return (
    <group ref={groupRef}>
      {orbs.map((orb, i) => (
        <FloatingOrb key={i} {...orb} />
      ))}
    </group>
  );
}

function FloatingOrb({
  position,
  scale,
  speed,
  offset,
}: {
  position: [number, number, number];
  scale: number;
  speed: number;
  offset: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      const t = state.clock.elapsedTime * speed + offset;
      meshRef.current.position.y = position[1] + Math.sin(t) * 0.3;
      meshRef.current.position.x = position[0] + Math.cos(t * 0.7) * 0.15;
    }
  });

  return (
    <mesh ref={meshRef} position={position} scale={scale}>
      <sphereGeometry args={[1, 32, 32]} />
      <meshStandardMaterial
        color="#06b6d4"
        emissive="#0891b2"
        emissiveIntensity={2}
        transparent
        opacity={0.6}
        roughness={0.1}
        metalness={0.8}
      />
    </mesh>
  );
}

export default function GradientBackground() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 0, 3], fov: 60 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.3} />
        <pointLight position={[5, 5, 5]} intensity={0.5} color="#06b6d4" />
        <pointLight position={[-5, 3, 2]} intensity={0.3} color="#0e7490" />
        <GradientMesh />
        <FloatingOrbs />
      </Canvas>
    </div>
  );
}
