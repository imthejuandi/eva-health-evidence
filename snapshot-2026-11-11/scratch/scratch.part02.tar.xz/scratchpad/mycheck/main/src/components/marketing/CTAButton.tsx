"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

interface CTAButtonProps {
  variant?: "primary" | "secondary" | "ghost";
  href?: string;
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
}

const EASE_CSS = "cubic-bezier(0.32, 0.72, 0, 1)";

function ArrowIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-current">
      <path d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function CTAButton({
  variant = "primary",
  href,
  children,
  onClick,
  className = "",
  type = "button",
  disabled = false,
}: CTAButtonProps) {
  /* ─── Primary: Dark pill with nested trailing icon circle ─── */
  if (variant === "primary") {
    const cls = cn(
      "group relative inline-flex items-center gap-2.5 overflow-hidden rounded-full",
      "bg-eva-on-surface py-3.5 pl-7 pr-3.5",
      "font-heading text-[15px] font-bold tracking-[0.2px] text-white",
      "shadow-[0_16px_48px_rgba(29,27,24,0.12),0_2px_6px_rgba(29,27,24,0.06)]",
      "transition-all duration-700 active:scale-[0.97]",
      "hover:shadow-[0_24px_64px_rgba(29,27,24,0.18),0_4px_10px_rgba(29,27,24,0.08)]",
      disabled && "opacity-50 pointer-events-none",
      className,
    );

    const inner = (
      <>
        <span>{children}</span>
        {/* Button-in-Button trailing icon */}
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/[0.12] transition-all duration-700 group-hover:translate-x-0.5 group-hover:-translate-y-px group-hover:scale-110 group-hover:bg-white/[0.22]"
          style={{ transitionTimingFunction: EASE_CSS }}
        >
          <ArrowIcon />
        </span>
      </>
    );

    if (href) {
      return (
        <Link href={href} className={cls} style={{ transitionTimingFunction: EASE_CSS }}>
          {inner}
        </Link>
      );
    }
    return (
      <button type={type} onClick={onClick} disabled={disabled} className={cls} style={{ transitionTimingFunction: EASE_CSS }}>
        {inner}
      </button>
    );
  }

  /* ─── Secondary: Hairline border pill with nested trailing icon ─── */
  if (variant === "secondary") {
    const cls = cn(
      "group relative inline-flex items-center gap-2.5 overflow-hidden rounded-full",
      "border border-eva-on-surface/[0.12] bg-transparent py-3.5 pl-7 pr-3.5",
      "font-heading text-[15px] font-bold tracking-[0.2px] text-eva-on-surface",
      "transition-all duration-700 active:scale-[0.97]",
      "hover:border-eva-on-surface/[0.25] hover:bg-eva-on-surface/[0.03]",
      disabled && "opacity-50 pointer-events-none",
      className,
    );

    const inner = (
      <>
        <span>{children}</span>
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-eva-on-surface/[0.05] transition-all duration-700 group-hover:translate-x-0.5 group-hover:-translate-y-px group-hover:scale-110 group-hover:bg-eva-on-surface/[0.1]"
          style={{ transitionTimingFunction: EASE_CSS }}
        >
          <ArrowIcon />
        </span>
      </>
    );

    if (href) {
      return (
        <Link href={href} className={cls} style={{ transitionTimingFunction: EASE_CSS }}>
          {inner}
        </Link>
      );
    }
    return (
      <button type={type} onClick={onClick} disabled={disabled} className={cls} style={{ transitionTimingFunction: EASE_CSS }}>
        {inner}
      </button>
    );
  }

  /* ─── Ghost: Subtle underline reveal ─── */
  const cls = cn(
    "group relative inline-flex items-center gap-1.5 font-heading text-[14px] font-bold tracking-[0.2px] text-eva-on-surface-muted",
    "transition-all duration-500 active:scale-[0.98]",
    "hover:text-eva-terra",
    disabled && "opacity-50 pointer-events-none",
    className,
  );

  const inner = (
    <>
      <span
        className="relative after:absolute after:-bottom-0.5 after:left-0 after:h-[1.5px] after:w-full after:origin-left after:scale-x-0 after:rounded-full after:bg-current after:transition-transform after:duration-500 group-hover:after:scale-x-100"
        style={{ transitionTimingFunction: EASE_CSS }}
      >
        {children}
      </span>
    </>
  );

  if (href) {
    return (
      <Link href={href} className={cls} style={{ transitionTimingFunction: EASE_CSS }}>
        {inner}
      </Link>
    );
  }
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={cls} style={{ transitionTimingFunction: EASE_CSS }}>
      {inner}
    </button>
  );
}
