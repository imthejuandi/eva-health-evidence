"use client";

import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

interface QuoteRequestFormProps {
  panelId: string;
  emailLabel: string;
  emailPlaceholder: string;
  submitLabel: string;
  successMessage: string;
  errorMessage: string;
  onSubmit?: (data: { panelId: string; email: string }) => Promise<void> | void;
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function QuoteRequestForm({
  panelId,
  emailLabel,
  emailPlaceholder,
  submitLabel,
  successMessage,
  errorMessage,
  onSubmit,
}: QuoteRequestFormProps) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const reduce = useReducedMotion();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) {
      setStatus("error");
      return;
    }
    setStatus("loading");
    try {
      await onSubmit?.({ panelId, email });
      setStatus("ok");
      setEmail("");
    } catch {
      setStatus("error");
    }
  };

  return (
    <AnimatePresence mode="wait">
      {status === "ok" ? (
        <motion.p
          key="ok"
          initial={reduce ? false : { opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3, ease: EASE_QUART }}
          className="flex items-center gap-[var(--space-sm)] font-[family-name:var(--font-manrope)] text-[13px] text-[var(--color-eva-jade)]"
        >
          <span
            aria-hidden
            className="inline-block h-[1px] w-[16px] bg-[var(--color-eva-jade)]"
          />
          {successMessage}
        </motion.p>
      ) : (
        <motion.form
          key="form"
          initial={reduce ? false : { opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3, ease: EASE_QUART }}
          onSubmit={handleSubmit}
          className="flex flex-col gap-[var(--space-sm)] sm:flex-row sm:items-stretch"
        >
          <label className="sr-only" htmlFor={`quote-email-${panelId}`}>
            {emailLabel}
          </label>
          <input
            id={`quote-email-${panelId}`}
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (status === "error") setStatus("idle");
            }}
            placeholder={emailPlaceholder}
            required
            className={cn(
              "flex-1 bg-transparent px-[var(--space-md)] py-[var(--space-sm)]",
              "font-[family-name:var(--font-manrope)] text-[14px] text-[var(--color-eva-on-surface)]",
              "border-b border-[var(--color-eva-on-surface)]/25 transition-colors placeholder:text-[var(--color-eva-on-surface)]/40",
              "focus:border-[var(--color-eva-terra)] focus:outline-none",
              status === "error" && "border-[var(--color-eva-danger)]",
            )}
          />
          <button
            type="submit"
            disabled={status === "loading"}
            className="group/send inline-flex items-center justify-between gap-[var(--space-sm)] bg-[var(--color-eva-on-surface)] px-[var(--space-lg)] py-[var(--space-sm)] font-[family-name:var(--font-manrope)] text-[13px] font-semibold tracking-[0.01em] text-white transition-colors hover:bg-[var(--color-eva-ink)] disabled:opacity-60"
          >
            {status === "loading" ? "· · · · ·" : submitLabel}
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden className="transition-transform duration-[220ms] group-hover/send:translate-x-0.5">
              <path d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </motion.form>
      )}
      {status === "error" && (
        <motion.p
          key="err"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="mt-[var(--space-sm)] font-[family-name:var(--font-manrope)] text-[12.5px] text-[var(--color-eva-danger)]"
        >
          {errorMessage}
        </motion.p>
      )}
    </AnimatePresence>
  );
}
