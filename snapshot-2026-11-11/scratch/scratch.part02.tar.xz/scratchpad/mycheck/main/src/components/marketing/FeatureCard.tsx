"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  accent?: "terra" | "jade" | "gold";
}

const accentConfig = {
  terra: {
    iconBg: "bg-gradient-to-br from-eva-terra to-eva-terra-light",
    iconGlow: "rgba(151,71,44,0.10)",
    shellBg: "rgba(151,71,44,0.03)",
    shellRing: "rgba(151,71,44,0.05)",
  },
  jade: {
    iconBg: "bg-gradient-to-br from-eva-jade to-eva-jade-light",
    iconGlow: "rgba(58,102,94,0.10)",
    shellBg: "rgba(58,102,94,0.03)",
    shellRing: "rgba(58,102,94,0.05)",
  },
  gold: {
    iconBg: "bg-gradient-to-br from-[#c49332] to-[#e8c76a]",
    iconGlow: "rgba(196,147,50,0.10)",
    shellBg: "rgba(196,147,50,0.03)",
    shellRing: "rgba(196,147,50,0.05)",
  },
};

export function FeatureCard({
  icon: Icon,
  title,
  description,
  accent = "terra",
}: FeatureCardProps) {
  const cfg = accentConfig[accent];

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
      /* ─── Outer Shell (Double-Bezel) ─── */
      className="group rounded-[2rem] p-1.5"
      style={{
        background: cfg.shellBg,
        boxShadow: `inset 0 0 0 1px ${cfg.shellRing}`,
      }}
    >
      {/* ─── Inner Core ─── */}
      <div
        className="rounded-[calc(2rem-0.375rem)] bg-white p-8 transition-shadow duration-700"
        style={{
          boxShadow: "inset 0 1px 1px rgba(255,255,255,0.5), 0 16px 48px rgba(29,27,24,0.03)",
          transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)",
        }}
      >
        {/* Icon circle */}
        <div
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-[14px] transition-transform duration-700 group-hover:scale-110",
            cfg.iconBg,
          )}
          style={{
            boxShadow: `0 8px 24px ${cfg.iconGlow}`,
            transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)",
          }}
        >
          <Icon className="h-5 w-5 text-white" strokeWidth={1.5} />
        </div>

        <h3 className="mt-6 font-heading text-[17px] font-bold text-eva-on-surface">
          {title}
        </h3>
        <p className="mt-3 text-[14px] leading-relaxed text-eva-on-surface-muted">
          {description}
        </p>
      </div>
    </motion.div>
  );
}
