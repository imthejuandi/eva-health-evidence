"use client";

import { motion } from "framer-motion";
import type { BookedTest } from "@/lib/queries/types";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import { formatDayMonth } from "@/lib/dashboard-format";

type KitStatus = BookedTest["status"];
type LiveStatus = Exclude<KitStatus, "cancelled">;

const STATUS_ORDER: LiveStatus[] = [
  "scheduled",
  "kit_sent",
  "sample_received",
  "processing",
  "completed",
];

/**
 * KitTimeline — editorial visualisation of a single booking's lifecycle.
 * Renders the five-step pipeline (scheduled → kit_sent → sample_received
 * → processing → completed) with the current step highlighted in terra
 * and prior steps in jade. Cancelled bookings render a single muted row
 * instead of the full timeline.
 *
 * Used both inside the dashboard "next test" section and on the /book
 * page once redesigned.
 */
export function KitTimeline({
  booking,
  locale,
}: {
  booking: BookedTest;
  locale: string;
}) {
  if (booking.status === "cancelled") {
    return (
      <div className="border-t border-[#1d1b18]/15 pt-4">
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
        >
          {locale === "es" ? "Cancelada" : "Cancelled"}
        </p>
      </div>
    );
  }

  const t =
    locale === "es"
      ? {
          scheduled: { label: "Programado", body: "Tu kit esta en cola para envio." },
          kit_sent: { label: "Kit enviado", body: "Tu kit va camino a casa." },
          track: "Seguir el envío",
          sample_received: { label: "Muestra recibida", body: "El laboratorio tiene tu muestra." },
          processing: { label: "Procesando", body: "El laboratorio analiza tus marcadores." },
          completed: { label: "Resultados listos", body: "Tu lectura esta disponible en Analisis." },
          eta: "Llegada estimada",
          drawn: "Programada",
        }
      : {
          scheduled: { label: "Scheduled", body: "Your kit is queued for shipment." },
          kit_sent: { label: "Kit shipped", body: "Your kit is on its way." },
          track: "Track shipment",
          sample_received: { label: "Sample received", body: "The lab has your sample." },
          processing: { label: "Processing", body: "The lab is analysing your markers." },
          completed: { label: "Results ready", body: "Your reading is available in Labs." },
          eta: "Estimated arrival",
          drawn: "Scheduled",
        };

  const currentIndex = STATUS_ORDER.indexOf(booking.status);

  // Per-step accent colour: jade for completed steps, terra for the
  // active one, dim for upcoming. Mirrors the brand zone language.
  function colourFor(stepIndex: number) {
    if (stepIndex < currentIndex) return "#3a665e";
    if (stepIndex === currentIndex) return "#97472c";
    return "#8a7f76";
  }

  const scheduled = booking.scheduled_date
    ? formatDayMonth(booking.scheduled_date, locale)
    : null;

  return (
    <motion.div
      variants={staggerTight}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-15%" }}
      className="border-t border-[#1d1b18]/15 pt-5"
    >
      {scheduled && (
        <div className="mb-4 flex items-baseline gap-3">
          <p
            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
          >
            {t.drawn}
          </p>
          <p
            className={`${FONT_CLASS.cormorant} text-[20px] font-medium tabular-nums text-[#1d1b18]`}
          >
            {scheduled.day} {scheduled.month} {scheduled.year}
          </p>
        </div>
      )}

      <ol className="space-y-3">
        {STATUS_ORDER.map((step, i) => {
          const stepCopy = t[step];
          const colour = colourFor(i);
          const isCurrent = i === currentIndex;
          const isDone = i < currentIndex;
          return (
            <motion.li key={step} variants={fadeUp} className="flex items-start gap-3">
              <span
                aria-hidden
                className={`mt-1 inline-flex h-3 w-3 shrink-0 items-center justify-center rounded-full ${
                  isCurrent ? "ring-2 ring-offset-2 ring-offset-[#fef8f2]" : ""
                }`}
                style={{
                  backgroundColor: isDone || isCurrent ? colour : "transparent",
                  boxShadow: isDone || isCurrent ? "none" : `inset 0 0 0 1px ${colour}`,
                  ...(isCurrent ? { ["--tw-ring-color" as string]: `${colour}40` } : {}),
                }}
              />
              <div className="min-w-0 flex-1">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px]`}
                  style={{ color: colour }}
                >
                  {stepCopy.label}
                </p>
                <p
                  className={`mt-0.5 ${FONT_CLASS.manrope} text-[13px] leading-[1.55] ${
                    isCurrent
                      ? "text-[#1d1b18]"
                      : isDone
                        ? "text-[#4c463f]"
                        : "text-[#8a7f76]"
                  }`}
                >
                  {stepCopy.body}
                </p>
                {/* DHL tracking (F5): cycles carry the real tracking number. */}
                {step === "kit_sent" && isCurrent && booking.dhl_tracking_out && (
                  <a
                    href={`https://www.dhl.com/${locale === "es" ? "es-es" : "en"}/home/tracking.html?tracking-id=${encodeURIComponent(booking.dhl_tracking_out)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${FONT_CLASS.dmMono} mt-1 inline-block text-[11px] font-semibold uppercase tracking-[1.2px] text-[#97472c] underline underline-offset-4`}
                  >
                    {t.track} · {booking.dhl_tracking_out}
                  </a>
                )}
              </div>
            </motion.li>
          );
        })}
      </ol>
    </motion.div>
  );
}
