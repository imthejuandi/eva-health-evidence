"use client";

interface RangeBarProps {
  value: number;
  optimalLow?: number | null;
  optimalHigh?: number | null;
  criticalLow?: number | null;
  criticalHigh?: number | null;
  zone: string;
  unit?: string;
  standardRangeLabel?: string;
  optimalRangeLabel?: string;
}

export function RangeBar({
  value,
  optimalLow,
  optimalHigh,
  criticalLow,
  criticalHigh,
  zone,
  unit = "",
  standardRangeLabel,
  optimalRangeLabel,
}: RangeBarProps) {
  // Compute the full display range
  const allVals = [value];
  if (optimalLow != null) allVals.push(optimalLow);
  if (optimalHigh != null) allVals.push(optimalHigh);
  if (criticalLow != null) allVals.push(criticalLow);
  if (criticalHigh != null) allVals.push(criticalHigh);

  const dataMin = Math.min(...allVals);
  const dataMax = Math.max(...allVals);
  const padding = (dataMax - dataMin) * 0.15 || dataMax * 0.2 || 10;
  const rangeMin = dataMin - padding;
  const rangeMax = dataMax + padding;
  const span = rangeMax - rangeMin || 1;

  function pct(v: number): number {
    return Math.max(0, Math.min(100, ((v - rangeMin) / span) * 100));
  }

  // Zone sections for the bar
  const oLow = optimalLow ?? rangeMin;
  const oHigh = optimalHigh ?? rangeMax;
  const cLow = criticalLow ?? rangeMin;
  const cHigh = criticalHigh ?? rangeMax;

  const sections = [
    { left: pct(rangeMin), width: pct(cLow) - pct(rangeMin), color: "rgba(176,64,64,0.25)" },
    { left: pct(cLow), width: pct(oLow) - pct(cLow), color: "rgba(196,147,50,0.25)" },
    { left: pct(oLow), width: pct(oHigh) - pct(oLow), color: "rgba(58,102,94,0.30)" },
    { left: pct(oHigh), width: pct(cHigh) - pct(oHigh), color: "rgba(196,147,50,0.25)" },
    { left: pct(cHigh), width: 100 - pct(cHigh), color: "rgba(176,64,64,0.25)" },
  ].filter((s) => s.width > 0);

  // Dot color based on zone
  const dotColors: Record<string, string> = {
    critical_low: "#b04040",
    below_optimal: "#c49332",
    optimal: "#3a665e",
    above_optimal: "#c49332",
    critical_high: "#b04040",
    unclassified: "#8a7f76",
  };
  const dotColor = dotColors[zone] ?? "#8a7f76";
  const dotPct = pct(value);

  return (
    <div className="w-full">
      {/* Bar */}
      <div className="relative h-3 overflow-hidden rounded-full bg-[#e7e2dc]">
        {sections.map((s, i) => (
          <div
            key={i}
            className="absolute inset-y-0"
            style={{ left: `${s.left}%`, width: `${s.width}%`, backgroundColor: s.color }}
          />
        ))}
        {/* Value dot */}
        <div
          className="absolute top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white"
          style={{
            left: `${dotPct}%`,
            backgroundColor: dotColor,
            boxShadow: `0 0 8px ${dotColor}40`,
          }}
        />
      </div>

      {/* Labels */}
      <div className="mt-2 flex items-baseline justify-between">
        {standardRangeLabel && (
          <span className="font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">
            {standardRangeLabel}
          </span>
        )}
        {optimalRangeLabel && (
          <span className="font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#3a665e]">
            {optimalRangeLabel}
          </span>
        )}
      </div>

      {/* Value display */}
      <div className="mt-1 text-right">
        <span className="font-[family-name:var(--font-manrope)] text-[14px] font-extrabold" style={{ color: dotColor }}>
          {value}
        </span>
        {unit && (
          <span className="ml-1 font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">{unit}</span>
        )}
      </div>
    </div>
  );
}
