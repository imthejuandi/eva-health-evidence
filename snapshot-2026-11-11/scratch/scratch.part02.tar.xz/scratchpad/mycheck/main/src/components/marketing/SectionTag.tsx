import { cn } from "@/lib/utils";

interface SectionTagProps {
  text: string;
  color?: "terra" | "jade";
}

export function SectionTag({ text, color = "terra" }: SectionTagProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-3.5 py-1 font-mono text-[10px] font-medium uppercase tracking-[0.2em]",
        color === "terra"
          ? "bg-eva-terra/[0.04] text-eva-terra ring-1 ring-eva-terra/[0.08]"
          : "bg-eva-jade/[0.04] text-eva-jade ring-1 ring-eva-jade/[0.08]",
      )}
    >
      <span className="relative flex h-1.5 w-1.5">
        <span
          className={cn(
            "absolute inline-flex h-full w-full rounded-full opacity-50",
            color === "terra" ? "bg-eva-terra animate-[breathe_3s_ease-in-out_infinite]" : "bg-eva-jade animate-[breathe_3s_ease-in-out_infinite]",
          )}
        />
        <span
          className={cn(
            "relative inline-flex h-1.5 w-1.5 rounded-full",
            color === "terra" ? "bg-eva-terra" : "bg-eva-jade",
          )}
        />
      </span>
      {text}
    </span>
  );
}
