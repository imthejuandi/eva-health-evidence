"use client";

import { motion, useReducedMotion } from "framer-motion";

interface Step {
  number: string;
  title: string;
  body: string;
  duration: string;
}

interface HowItWorksProps {
  eyebrow: string;
  headline: string;
  steps: Step[];
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function HowItWorks({ eyebrow, headline, steps }: HowItWorksProps) {
  const reduce = useReducedMotion();

  return (
    <section className="bg-[var(--color-eva-surface-lowest)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        {/* Section masthead */}
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
            {headline}
          </h2>
        </header>

        {/* Steps — typographic numerals, no icons */}
        <ol className="mt-[clamp(3rem,6vw,5rem)] grid grid-cols-1 gap-x-[var(--space-2xl)] gap-y-[var(--space-4xl)] md:grid-cols-3">
          {steps.map((step, idx) => (
            <motion.li
              key={step.number}
              initial={reduce ? false : { opacity: 0, y: 14 }}
              whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{
                duration: 0.7,
                delay: idx * 0.1,
                ease: EASE_QUART,
              }}
              className="relative pt-[var(--space-lg)]"
            >
              {/* Hairline rule at top of each step, connecting across the row on desktop */}
              <span
                aria-hidden
                className="absolute inset-x-0 top-0 h-px bg-[var(--color-eva-on-surface)]/15"
              />

              <span
                aria-hidden
                className="font-[family-name:var(--font-sentient)] text-[clamp(4rem,8vw,6.5rem)] font-medium leading-[0.85] tracking-[-0.035em] text-[var(--color-eva-terra)]"
                style={{ fontVariantNumeric: "tabular-nums" }}
              >
                {step.number}
              </span>

              <div className="mt-[var(--space-xl)] flex items-baseline gap-[var(--space-sm)]">
                <span
                  aria-hidden
                  className="inline-block h-[1px] w-[12px] translate-y-[-3px] bg-[var(--color-eva-on-surface)]/40"
                />
                <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-on-surface)]/55">
                  {step.duration}
                </span>
              </div>

              <h3 className="mt-[var(--space-md)] font-[family-name:var(--font-manrope)] text-[20px] font-semibold leading-[1.2] tracking-[-0.01em] text-[var(--color-eva-on-surface)] md:text-[22px]">
                {step.title}
              </h3>

              <p className="mt-[var(--space-md)] max-w-[32ch] font-[family-name:var(--font-manrope)] text-[15px] leading-[1.55] text-[var(--color-eva-on-surface)]/70">
                {step.body}
              </p>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  );
}
