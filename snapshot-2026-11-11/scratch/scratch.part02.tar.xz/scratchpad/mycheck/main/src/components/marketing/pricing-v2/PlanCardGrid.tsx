"use client";

import { motion, useReducedMotion } from "framer-motion";
import { PlanCard, type PlanCardProps } from "./PlanCard";

interface PlanCardGridProps {
  plans: PlanCardProps[];
  /** "hero" = larger price scale; "compact" = final-CTA scale. */
  priceScale?: "hero" | "compact";
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function PlanCardGrid({ plans, priceScale = "hero" }: PlanCardGridProps) {
  const reduce = useReducedMotion();

  return (
    <div className="grid grid-cols-1 gap-0 md:grid-cols-3">
      {plans.map((plan, idx) => (
        <motion.div
          key={plan.id}
          initial={reduce ? false : { opacity: 0, y: 16 }}
          whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, delay: idx * 0.08, ease: EASE_QUART }}
          className="flex h-full"
        >
          <PlanCard {...plan} priceScale={priceScale} />
        </motion.div>
      ))}
    </div>
  );
}
