"use client";

import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

interface FAQItem {
  question: string;
  answer: string;
}

export interface FAQCategory {
  id: string;
  label: string;
  items: FAQItem[];
}

interface FAQTabsProps {
  eyebrow: string;
  headline: string;
  categories: FAQCategory[];
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

function FAQRow({ item, idx }: { item: FAQItem; idx: number }) {
  const [open, setOpen] = useState(false);
  const reduce = useReducedMotion();

  return (
    <div className="border-b border-[var(--color-eva-on-surface)]/15">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="group/q grid w-full grid-cols-[48px_1fr_auto] items-baseline gap-[var(--space-lg)] py-[var(--space-xl)] text-left"
      >
        <span
          className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/45"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          § {String(idx + 1).padStart(2, "0")}
        </span>
        <span className="font-[family-name:var(--font-sentient)] text-[clamp(1.125rem,2vw,1.375rem)] font-medium leading-[1.25] tracking-[-0.012em] text-[var(--color-eva-on-surface)]">
          {item.question}
        </span>
        <span
          aria-hidden
          className={cn(
            "relative block h-[14px] w-[14px] shrink-0 transition-transform duration-[280ms]",
            open && "rotate-45",
          )}
          style={{ transitionTimingFunction: "cubic-bezier(0.25, 1, 0.5, 1)" }}
        >
          <span className="absolute inset-x-0 top-1/2 h-[1.5px] w-full -translate-y-1/2 bg-[var(--color-eva-on-surface)]" />
          <span className="absolute left-1/2 inset-y-0 w-[1.5px] h-full -translate-x-1/2 bg-[var(--color-eva-on-surface)]" />
        </span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="ans"
            initial={
              reduce
                ? { opacity: 0 }
                : { gridTemplateRows: "0fr", opacity: 0 }
            }
            animate={
              reduce
                ? { opacity: 1 }
                : { gridTemplateRows: "1fr", opacity: 1 }
            }
            exit={
              reduce
                ? { opacity: 0 }
                : { gridTemplateRows: "0fr", opacity: 0 }
            }
            transition={{ duration: 0.36, ease: EASE_QUART }}
            className="grid overflow-hidden"
          >
            <div className="min-h-0">
              <p className="ml-[calc(48px+var(--space-lg))] max-w-[68ch] pb-[var(--space-xl)] font-[family-name:var(--font-manrope)] text-[15px] leading-[1.6] text-[var(--color-eva-on-surface)]/75">
                {item.answer}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function FAQTabs({ eyebrow, headline, categories }: FAQTabsProps) {
  const [activeId, setActiveId] = useState(categories[0]?.id ?? "");
  const active = categories.find((c) => c.id === activeId) ?? categories[0];

  return (
    <section className="bg-[var(--color-eva-surface-lowest)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1000px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
            {headline}
          </h2>
        </header>

        {/* Tab bar — typographic underline, no card */}
        <div
          role="tablist"
          aria-label={headline}
          className="mt-[clamp(2.5rem,4vw,3.5rem)] flex flex-wrap gap-x-[var(--space-xl)] gap-y-[var(--space-sm)] border-b border-[var(--color-eva-on-surface)]/15 pb-[var(--space-sm)]"
        >
          {categories.map((cat) => {
            const isActive = cat.id === activeId;
            return (
              <button
                key={cat.id}
                role="tab"
                aria-selected={isActive}
                aria-controls={`faq-panel-${cat.id}`}
                id={`faq-tab-${cat.id}`}
                onClick={() => setActiveId(cat.id)}
                className="relative font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[0.22em] transition-colors"
                style={{
                  color: isActive
                    ? "var(--color-eva-on-surface)"
                    : "rgba(29,27,24,0.5)",
                }}
              >
                {cat.label}
                {isActive && (
                  <motion.span
                    layoutId="faq-tab-underline"
                    className="absolute -bottom-[9px] left-0 h-[2px] w-full bg-[var(--color-eva-terra)]"
                    transition={{ duration: 0.32, ease: EASE_QUART }}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Panel */}
        <div
          id={`faq-panel-${activeId}`}
          role="tabpanel"
          aria-labelledby={`faq-tab-${activeId}`}
          className="mt-[var(--space-lg)]"
        >
          {active?.items.map((item, i) => (
            <FAQRow key={item.question} item={item} idx={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
