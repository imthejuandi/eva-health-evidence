"use client";

import type { ReactNode } from "react";

/**
 * A numbered list with leading mono-tabular numerals (01, 02, ...) in
 * the section's accent colour. Used wherever ordered editorial copy
 * needs the magazine-numbered look — booking next-steps, findings
 * lists, profile data-rights actions.
 */
export function NumberedList({
  items,
  accentColor,
  className,
}: {
  items: Array<ReactNode>;
  accentColor: string;
  className?: string;
}) {
  return (
    <ol className={`space-y-1.5 ${className ?? ""}`}>
      {items.map((item, i) => (
        <li
          key={i}
          className="flex items-baseline gap-3 font-[family-name:var(--font-jakarta)] text-[13px] leading-[1.55] text-[#1d1b18]"
        >
          <span
            className="shrink-0 font-[family-name:var(--font-dm-mono)] text-[9px]"
            style={{ color: accentColor, fontVariantNumeric: "tabular-nums" }}
          >
            {String(i + 1).padStart(2, "0")}
          </span>
          <span className="min-w-0 flex-1">{item}</span>
        </li>
      ))}
    </ol>
  );
}
