"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

type Intent = "default" | "danger";

interface PrimaryPillProps {
  children: ReactNode;
  /** Click handler. Mutually exclusive with `href`. */
  onClick?: () => void;
  /** Render as a Next.js `<Link>` instead of a `<button>`. */
  href?: string;
  /** Show a spinning refresh glyph in the trailing chip. */
  loading?: boolean;
  disabled?: boolean;
  /** Visual intent. `danger` swaps the dark-ink fill for terra-red
   *  and tints the warm shadow accordingly. */
  intent?: Intent;
  /** Form button type — only used when rendered as `<button>`. */
  type?: "button" | "submit";
  /** Optional accessible label for icon-only states. */
  ariaLabel?: string;
}

/**
 * PrimaryPill — the dark editorial CTA used across the dashboard.
 * Cream text on a dark/intent fill, with a circular trailing chip
 * holding either an arrow (default) or a spinning refresh glyph
 * (loading). Lifts on hover, settles on press.
 *
 * Renders as a `<Link>` when `href` is provided, otherwise a
 * `<button>`. Accepts a `type="submit"` variant for forms.
 */
export function PrimaryPill({
  children,
  onClick,
  href,
  loading,
  disabled,
  intent = "default",
  type = "button",
  ariaLabel,
}: PrimaryPillProps) {
  const bg = intent === "danger" ? "#b04040" : "#1d1b18";
  const shadow =
    intent === "danger"
      ? "0 18px 50px -12px rgba(176,64,64,0.55)"
      : "0 18px 50px -12px rgba(151,71,44,0.45)";
  const cls = `group inline-flex items-center gap-3 rounded-full px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] transition-transform hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-[#fef8f2] focus-visible:ring-[#97472c]`;
  const inner = (
    <>
      {children}
      <span
        aria-hidden
        className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
      >
        <svg
          className={`h-3 w-3 ${loading ? "animate-spin" : ""}`}
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
        >
          {loading ? (
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"
            />
          ) : (
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
            />
          )}
        </svg>
      </span>
    </>
  );

  if (href) {
    return (
      <Link
        href={href}
        className={cls}
        style={{ backgroundColor: bg, boxShadow: shadow }}
        aria-label={ariaLabel}
      >
        {inner}
      </Link>
    );
  }
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      className={cls}
      style={{ backgroundColor: bg, boxShadow: shadow }}
      aria-label={ariaLabel}
    >
      {inner}
    </button>
  );
}
