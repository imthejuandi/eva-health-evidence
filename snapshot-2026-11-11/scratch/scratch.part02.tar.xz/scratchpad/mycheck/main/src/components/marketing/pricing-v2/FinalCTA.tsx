"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { PlanCardGrid } from "./PlanCardGrid";
import type { PlanCardProps } from "./PlanCard";

interface FinalCTAProps {
  eyebrow: string;
  headline: string;
  subhead: string;
  plans: PlanCardProps[];
  escapeHatchLabel: string;
  escapeHatchHref: string;
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function FinalCTA({
  eyebrow,
  headline,
  subhead,
  plans,
  escapeHatchLabel,
  escapeHatchHref,
}: FinalCTAProps) {
  const reduce = useReducedMotion();

  return (
    <section className="bg-[var(--color-eva-surface)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <div>
            <motion.h2
              initial={reduce ? false : { opacity: 0, y: 14 }}
              whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease: EASE_QUART }}
              className="max-w-[22ch] font-[family-name:var(--font-sentient)] text-[clamp(2.25rem,5vw,3.75rem)] font-medium leading-[1.05] tracking-[-0.03em] text-[var(--color-eva-on-surface)]"
            >
              {headline}
            </motion.h2>
            <motion.p
              initial={reduce ? false : { opacity: 0, y: 12 }}
              whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="mt-[var(--space-md)] max-w-[52ch] font-[family-name:var(--font-manrope)] text-[15.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/70 md:text-[17px]"
            >
              {subhead}
            </motion.p>
          </div>
        </header>

        <div className="mt-[clamp(3rem,5vw,4rem)]">
          <PlanCardGrid plans={plans} priceScale="compact" />
        </div>

        <div className="mt-[clamp(2.5rem,4vw,3.5rem)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)]">
          <Link
            href={escapeHatchHref}
            className="group/esc inline-flex items-center gap-[var(--space-sm)] font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-on-surface)]/65 transition-colors hover:text-[var(--color-eva-terra)]"
          >
            <span className="relative after:absolute after:-bottom-[2px] after:left-0 after:h-px after:w-full after:origin-left after:scale-x-0 after:bg-current after:transition-transform after:duration-[260ms] group-hover/esc:after:scale-x-100">
              {escapeHatchLabel}
            </span>
            <svg width="10" height="10" viewBox="0 0 12 12" fill="none" aria-hidden>
              <path
                d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5"
                stroke="currentColor"
                strokeWidth="1.3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
}
