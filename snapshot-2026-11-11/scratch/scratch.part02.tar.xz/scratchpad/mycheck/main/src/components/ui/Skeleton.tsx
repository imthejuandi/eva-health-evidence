"use client";

interface SkeletonProps {
  variant?: "line" | "circle" | "card" | "row";
  width?: string;
  height?: string;
  className?: string;
}

const base = "animate-pulse rounded-[12px] bg-[#e7e2dc]";

export function Skeleton({ variant = "line", width, height, className = "" }: SkeletonProps) {
  switch (variant) {
    case "circle":
      return <div className={`${base} rounded-full ${className}`} style={{ width: width ?? "48px", height: height ?? "48px" }} />;
    case "card":
      return (
        <div className={`${base} rounded-[24px] ${className}`} style={{ width: width ?? "100%", height: height ?? "160px" }} />
      );
    case "row":
      return (
        <div className={`flex items-center gap-3 rounded-[16px] border border-[#e7e2dc] px-4 py-3.5 ${className}`}>
          <div className={`${base} h-4 flex-1`} />
          <div className={`${base} h-4 w-16`} />
          <div className={`${base} h-5 w-20 rounded-full`} />
        </div>
      );
    default:
      return <div className={`${base} ${className}`} style={{ width: width ?? "100%", height: height ?? "16px" }} />;
  }
}

export function SkeletonDashboard() {
  return (
    <div className="px-5 py-8 md:px-8 md:py-12">
      <div className="mx-auto max-w-4xl">
        <Skeleton width="200px" height="32px" />
        <div className="mt-8 flex items-center gap-6">
          <div className="flex-1 space-y-3">
            <Skeleton width="60%" height="20px" />
            <Skeleton width="90%" height="14px" />
            <Skeleton width="75%" height="14px" />
          </div>
          <Skeleton variant="circle" width="140px" height="140px" />
        </div>
        <div className="mt-6 grid grid-cols-3 gap-4">
          <Skeleton variant="card" height="100px" />
          <Skeleton variant="card" height="100px" />
          <Skeleton variant="card" height="100px" />
        </div>
        <div className="mt-6 space-y-3">
          <Skeleton variant="card" height="80px" />
          <Skeleton variant="card" height="80px" />
        </div>
      </div>
    </div>
  );
}

export function SkeletonLabs() {
  return (
    <div className="px-5 py-8 md:px-8 md:py-12">
      <div className="mx-auto max-w-4xl">
        <Skeleton width="160px" height="32px" />
        <Skeleton variant="card" height="120px" className="mt-6" />
        <div className="mt-6 grid grid-cols-3 gap-4">
          <Skeleton variant="card" height="90px" />
          <Skeleton variant="card" height="90px" />
          <Skeleton variant="card" height="90px" />
        </div>
        <div className="mt-8 space-y-2">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton variant="row" key={i} />)}
        </div>
      </div>
    </div>
  );
}

export function SkeletonBiomarkerDetail() {
  return (
    <div className="px-5 py-8 md:px-8 md:py-12">
      <div className="mx-auto max-w-3xl">
        <Skeleton width="100px" height="14px" />
        <Skeleton width="250px" height="28px" className="mt-6" />
        <Skeleton width="180px" height="14px" className="mt-2" />
        <div className="mt-4 flex items-baseline gap-3">
          <Skeleton width="80px" height="36px" />
          <Skeleton width="60px" height="20px" className="rounded-full" />
        </div>
        <Skeleton variant="card" height="100px" className="mt-6" />
        <Skeleton variant="card" height="48px" className="mt-8" />
        <Skeleton variant="card" height="220px" className="mt-8" />
      </div>
    </div>
  );
}
