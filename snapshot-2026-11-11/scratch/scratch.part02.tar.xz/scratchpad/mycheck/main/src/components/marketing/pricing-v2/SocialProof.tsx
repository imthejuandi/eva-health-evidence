"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface Testimonial {
  quote: string;
  name: string;
  role: string;
  rating?: number;
}

interface SocialProofProps {
  eyebrow: string;
  headline: string;
  stat: { value: string; label: string };
  testimonials: Testimonial[];
  pressLabel: string;
  pressLogos: string[];
  navLabel?: string;
}

const EASE_EXPO: [number, number, number, number] = [0.16, 1, 0.3, 1];
const EASE_IN: [number, number, number, number] = [0.7, 0, 0.84, 0];

export function SocialProof({
  eyebrow,
  headline,
  stat,
  testimonials,
  pressLabel,
  pressLogos,
  navLabel = "Testimonial",
}: SocialProofProps) {
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (paused || reduce || testimonials.length <= 1) return;
    const id = window.setInterval(() => {
      setIdx((i) => (i + 1) % testimonials.length);
    }, 6500);
    return () => window.clearInterval(id);
  }, [paused, reduce, testimonials.length]);

  const active = testimonials[idx];
  const count = testimonials.length;

  const hasStat = Boolean(stat.value);
  const hasTestimonials = count > 0;
  const hasPress = pressLogos.length > 0;

  // Nothing real to show yet (no rating, testimonials, or press): render
  // nothing rather than an empty "Proof" section full of placeholder
  // scaffolding. Each block reappears automatically once real copy exists.
  if (!hasStat && !hasTestimonials && !hasPress) return null;

  return (
    <section className="bg-[var(--color-eva-surface-lowest)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
            {headline}
          </h2>
        </header>

        {(hasStat || hasTestimonials) && (
          <div className="mt-[clamp(3rem,5vw,4rem)] grid grid-cols-1 gap-[var(--space-4xl)] lg:grid-cols-[minmax(0,1fr)_minmax(0,1.8fr)]">
            {/* Stat block */}
            {hasStat && (
              <div className="flex flex-col gap-[var(--space-md)]">
                <span
                  className="font-[family-name:var(--font-sentient)] text-[clamp(3.5rem,8vw,5.5rem)] font-medium leading-[0.85] tracking-[-0.04em] text-[var(--color-eva-terra)]"
                  style={{ fontVariantNumeric: "tabular-nums" }}
                >
                  {stat.value}
                </span>
                <p className="max-w-[26ch] font-[family-name:var(--font-manrope)] text-[14.5px] leading-[1.5] text-[var(--color-eva-on-surface)]/70">
                  {stat.label}
                </p>
              </div>
            )}

            {/* Pull quote */}
            {hasTestimonials && (
              <div
                onMouseEnter={() => setPaused(true)}
                onMouseLeave={() => setPaused(false)}
                className="flex flex-col justify-between gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)]"
              >
                <AnimatePresence mode="wait">
                  {active && (
                    <motion.figure
                      key={idx}
                      initial={reduce ? false : { opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={reduce ? { opacity: 0 } : { opacity: 0, y: -6 }}
                      transition={{ duration: 0.5, ease: EASE_EXPO }}
                    >
                      <svg
                        aria-hidden
                        width="32"
                        height="24"
                        viewBox="0 0 32 24"
                        className="mb-[var(--space-md)] text-[var(--color-eva-terra)]"
                      >
                        <path
                          d="M6 0C2 0 0 4 0 8v16h12V8H4c0-2 1-4 4-4V0H6zm18 0c-4 0-6 4-6 8v16h12V8h-8c0-2 1-4 4-4V0h-2z"
                          fill="currentColor"
                          opacity="0.18"
                        />
                      </svg>
                      <blockquote className="font-[family-name:var(--font-sentient)] text-[clamp(1.5rem,2.6vw,2rem)] font-medium leading-[1.28] tracking-[-0.015em] text-[var(--color-eva-on-surface)]">
                        {active.quote}
                      </blockquote>
                      <figcaption className="mt-[var(--space-xl)] flex items-center gap-[var(--space-md)]">
                        <span
                          aria-hidden
                          className="inline-block h-[1px] w-[24px] bg-[var(--color-eva-on-surface)]/45"
                        />
                        <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/75">
                          {active.name} · {active.role}
                        </span>
                      </figcaption>
                    </motion.figure>
                  )}
                </AnimatePresence>

                {count > 1 && (
                  <div className="flex items-center justify-between gap-[var(--space-md)]">
                    <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/45">
                      {navLabel} {String(idx + 1).padStart(2, "0")} / {String(count).padStart(2, "0")}
                    </span>
                    <div className="flex items-center gap-[var(--space-sm)]">
                      {testimonials.map((_, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setIdx(i)}
                          aria-label={`${navLabel} ${i + 1}`}
                          className="relative h-[24px] w-[24px]"
                        >
                          <span
                            aria-hidden
                            className={cn(
                              "absolute left-0 top-[50%] h-[1px] w-full transition-[background-color,width] duration-[320ms]",
                              i === idx
                                ? "bg-[var(--color-eva-terra)]"
                                : "bg-[var(--color-eva-on-surface)]/25",
                            )}
                            style={{ transitionTimingFunction: "cubic-bezier(0.25, 1, 0.5, 1)" }}
                          />
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() =>
                          setIdx((i) => (i - 1 + count) % count)
                        }
                        aria-label="Previous"
                        className="ml-[var(--space-md)] flex h-7 w-7 items-center justify-center border border-[var(--color-eva-on-surface)]/15 transition-colors hover:bg-[var(--color-eva-cream-warm)]"
                      >
                        <svg width="10" height="10" viewBox="0 0 12 12" fill="none" aria-hidden>
                          <path d="M7.5 2.5L3 6.5L7.5 10.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </button>
                      <button
                        type="button"
                        onClick={() => setIdx((i) => (i + 1) % count)}
                        aria-label="Next"
                        className="flex h-7 w-7 items-center justify-center border border-[var(--color-eva-on-surface)]/15 transition-colors hover:bg-[var(--color-eva-cream-warm)]"
                      >
                        <svg width="10" height="10" viewBox="0 0 12 12" fill="none" aria-hidden>
                          <path d="M4.5 2.5L9 6.5L4.5 10.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Press strip */}
        {hasPress && (
          <div className="mt-[clamp(3rem,6vw,5rem)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)]">
            <div className="flex flex-col gap-[var(--space-lg)] md:flex-row md:items-center md:justify-between md:gap-[var(--space-2xl)]">
              <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
                {pressLabel}
              </span>
              <div className="flex flex-wrap items-baseline gap-x-[var(--space-2xl)] gap-y-[var(--space-md)]">
                {pressLogos.map((logo) => (
                  <span
                    key={logo}
                    className="font-[family-name:var(--font-sentient)] text-[clamp(1rem,1.6vw,1.3rem)] font-medium text-[var(--color-eva-on-surface)]/55"
                  >
                    {logo}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
