import { cn } from "@/lib/utils";

/**
 * SectionShell — standard marketing section wrapper.
 *
 * Every chapter on the landing page (and, going forward, every
 * chapter on the sub-pages) uses the same outer layout:
 *   · a full-width `<section>` with a background tone
 *   · an inner `<div>` clamped to max-w-[1480px] with px-6/md:px-12
 *   · vertical padding sized to the section's rhythm
 *
 * SectionShell absorbs those three concerns so call sites only
 * need to pass their content. Tone variants:
 *
 *   "cream"     — #fef8f2, the default warm page background
 *   "cream-alt" — #f8f3ed, the slightly deeper cream used to
 *                 visually separate adjacent cream sections
 *                 (Shortfall §02, Reveal §05)
 *   "dark"      — #1d1b18 ink, inverse sections with
 *                 #fef8f2 text (Reckoning §03, FinalCall §07)
 *
 * Size variants (vertical padding):
 *
 *   "standard" — py-24 md:py-36 — default
 *   "large"    — py-24 md:py-40 — FounderCinematic
 *   "xlarge"   — py-24 md:py-44 — Shortfall
 *   "xxlarge"  — py-28 md:py-48 — FinalCall
 *
 * Adds `relative overflow-hidden` by default so ambient gradient
 * washes and absolutely-positioned decorations can sit inside
 * without escaping the chapter.
 */
type SectionTone = "cream" | "cream-alt" | "dark";
type SectionSize = "standard" | "large" | "xlarge" | "xxlarge";

const toneClass: Record<SectionTone, string> = {
  cream: "bg-[#fef8f2]",
  "cream-alt": "bg-[#f8f3ed]",
  dark: "bg-[#1d1b18] text-[#fef8f2]",
};

const sizeClass: Record<SectionSize, string> = {
  standard: "py-24 md:py-36",
  large: "py-24 md:py-40",
  xlarge: "py-24 md:py-44",
  xxlarge: "py-28 md:py-48",
};

interface SectionShellProps {
  children: React.ReactNode;
  tone?: SectionTone;
  size?: SectionSize;
  /** Drop the overflow-hidden if a section needs to bleed content. */
  overflow?: "hidden" | "visible";
  /** Additional classes merged on the outer <section>. */
  className?: string;
  /** Additional classes merged on the inner max-width container. */
  innerClassName?: string;
  id?: string;
}

export function SectionShell({
  children,
  tone = "cream",
  size = "standard",
  overflow = "hidden",
  className,
  innerClassName,
  id,
}: SectionShellProps) {
  return (
    <section
      id={id}
      className={cn(
        "relative",
        overflow === "hidden" && "overflow-hidden",
        toneClass[tone],
        sizeClass[size],
        className,
      )}
    >
      <div
        className={cn(
          "mx-auto max-w-[1480px] px-6 md:px-12",
          innerClassName,
        )}
      >
        {children}
      </div>
    </section>
  );
}
