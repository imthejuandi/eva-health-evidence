"use client";

import { useParams } from "next/navigation";

// A11Y-002: keyboard-only "skip to content" link. Visually hidden until it
// receives focus (first Tab on the page), then it surfaces in the top-left
// corner and jumps focus past the persistent nav/chrome to <main id="main">.
export function SkipLink() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const label = locale === "es" ? "Saltar al contenido" : "Skip to content";

  return (
    <a
      href="#main"
      className="sr-only focus:not-sr-only focus:absolute focus:z-[100] focus:left-4 focus:top-4 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-black focus:shadow"
    >
      {label}
    </a>
  );
}
