"use client";

import { MiniSparkline } from "./MiniSparkline";

interface MetricData {
  current: number | null;
  history: (number | null)[];
}

interface WearableSnapshotGridProps {
  hrv?: MetricData;
  restingHr?: MetricData;
  sleep?: MetricData;
  respiratoryRate?: MetricData;
  locale?: string;
  onConnect?: () => void;
}

interface TileProps {
  label: string;
  value: number | null;
  unit: string;
  data: (number | null)[];
  color: string;
}

function WearableTile({ label, value, unit, data, color }: TileProps) {
  return (
    <div className="rounded-[16px] bg-[#f8f3ed] p-4">
      <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1px] text-[#8a7f76]">
        {label}
      </p>
      <div className="mt-2 flex items-end justify-between gap-2">
        <p className="font-[family-name:var(--font-manrope)] text-[22px] font-extrabold text-[#1d1b18]">
          {value != null ? (Number.isInteger(value) ? value : value.toFixed(1)) : "—"}
          <span className="ml-1 text-[11px] font-medium text-[#8a7f76]">{unit}</span>
        </p>
        <MiniSparkline data={data} color={color} />
      </div>
    </div>
  );
}

export function WearableSnapshotGrid({
  hrv,
  restingHr,
  sleep,
  respiratoryRate,
  locale = "en",
  onConnect,
}: WearableSnapshotGridProps) {
  const hasData = [hrv, restingHr, sleep, respiratoryRate].some(
    (m) => m && m.current != null,
  );

  const t = locale === "es"
    ? { hrv: "VFC", hr: "FC Reposo", sleep: "Sueno", resp: "Frec. Resp.", ms: "ms", bpm: "lpm", h: "h", brpm: "rpm", connect: "Conectar Apple Health", noData: "Conecta tu wearable para ver biometricas junto a tus biomarcadores." }
    : { hrv: "HRV", hr: "Resting HR", sleep: "Sleep", resp: "Resp. Rate", ms: "ms", bpm: "bpm", h: "h", brpm: "brpm", connect: "Connect Apple Health", noData: "Connect your wearable to see biometrics alongside your biomarkers." };

  if (!hasData) {
    return (
      <div className="rounded-[24px] bg-white p-7 shadow-[0_20px_60px_rgba(29,27,24,0.04)]">
        <h3 className="font-[family-name:var(--font-manrope)] text-[18px] font-extrabold text-[#1d1b18]">
          {locale === "es" ? "Datos de Wearable" : "Wearable Data"}
        </h3>
        <p className="mt-3 font-[family-name:var(--font-inter)] text-[13px] text-[#4c463f]">
          {t.noData}
        </p>
        <button
          onClick={onConnect}
          className="mt-3 rounded-[100px] border-[1.5px] border-[#3a665e] px-5 py-2.5 font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#3a665e] transition-colors hover:bg-[rgba(58,102,94,0.05)]"
        >
          {t.connect}
        </button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      <WearableTile
        label={t.hrv}
        value={hrv?.current ?? null}
        unit={t.ms}
        data={hrv?.history ?? []}
        color="#3a665e"
      />
      <WearableTile
        label={t.hr}
        value={restingHr?.current ?? null}
        unit={t.bpm}
        data={restingHr?.history ?? []}
        color="#97472c"
      />
      <WearableTile
        label={t.sleep}
        value={sleep?.current ?? null}
        unit={t.h}
        data={sleep?.history ?? []}
        color="#c49332"
      />
      <WearableTile
        label={t.resp}
        value={respiratoryRate?.current ?? null}
        unit={t.brpm}
        data={respiratoryRate?.history ?? []}
        color="#3a665e"
      />
    </div>
  );
}
