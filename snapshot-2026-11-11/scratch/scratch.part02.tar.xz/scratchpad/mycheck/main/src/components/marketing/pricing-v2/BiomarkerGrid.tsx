"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

export type BiomarkerCategory = "metabolic" | "cardio" | "nutrient";

export interface Biomarker {
  code: string;
  name: string;
  /** Short label shown on the compact grid tile. */
  short: string;
  detects: string;
  range: string;
  matters: string;
  category: BiomarkerCategory;
}

interface BiomarkerGridProps {
  eyebrow: string;
  headline: string;
  kicker: string;
  markers: Biomarker[];
  closeLabel: string;
  detectsLabel: string;
  rangeLabel: string;
  mattersLabel: string;
  categories: Record<BiomarkerCategory, string>;
}

const CATEGORY_COLOR: Record<BiomarkerCategory, string> = {
  metabolic: "var(--color-eva-terra)",
  cardio: "var(--color-eva-jade)",
  nutrient: "var(--color-eva-gold)",
};

const EASE_EXPO: [number, number, number, number] = [0.16, 1, 0.3, 1];

/** True on ≥ 768px. Tracks resize. */
function useIsDesktop() {
  const [isDesktop, setIsDesktop] = useState<boolean>(false);
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return isDesktop;
}

export function BiomarkerGrid({
  eyebrow,
  headline,
  kicker,
  markers,
  closeLabel,
  detectsLabel,
  rangeLabel,
  mattersLabel,
  categories,
}: BiomarkerGridProps) {
  const [active, setActive] = useState<Biomarker | null>(null);
  const reduce = useReducedMotion();
  const isDesktop = useIsDesktop();

  useEffect(() => {
    if (!active) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [active]);

  const panelInitial = reduce
    ? { opacity: 0 }
    : isDesktop
      ? { x: "100%", y: 0, opacity: 1 }
      : { y: "100%", x: 0, opacity: 1 };
  const panelAnimate = reduce
    ? { opacity: 1 }
    : { x: 0, y: 0, opacity: 1 };
  const panelExit = reduce
    ? { opacity: 0 }
    : isDesktop
      ? { x: "100%", y: 0, opacity: 1 }
      : { y: "100%", x: 0, opacity: 1 };

  return (
    <section className="bg-[var(--color-eva-surface-lowest)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <div>
            <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
              {headline}
            </h2>
            <p className="mt-[var(--space-md)] max-w-[56ch] font-[family-name:var(--font-manrope)] text-[15.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/70">
              {kicker}
            </p>
          </div>
        </header>

        <ul className="mt-[clamp(3rem,5vw,4rem)] grid grid-cols-[repeat(auto-fit,minmax(140px,1fr))] border-l border-t border-[var(--color-eva-on-surface)]/12">
          {markers.map((marker) => (
            <li key={marker.code}>
              <button
                type="button"
                onClick={() => setActive(marker)}
                className="group relative flex h-full w-full flex-col items-start justify-between gap-[var(--space-md)] border-b border-r border-[var(--color-eva-on-surface)]/12 px-[var(--space-lg)] py-[var(--space-lg)] text-left transition-colors duration-[220ms] hover:bg-[var(--color-eva-cream-warm)]"
                style={{ transitionTimingFunction: "cubic-bezier(0.25, 1, 0.5, 1)" }}
              >
                <span
                  aria-hidden
                  className="absolute top-0 left-0 h-[2px] w-[16px]"
                  style={{ backgroundColor: CATEGORY_COLOR[marker.category] }}
                />
                <span
                  className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em]"
                  style={{ color: CATEGORY_COLOR[marker.category] }}
                >
                  {marker.code}
                </span>
                <div className="min-w-0 self-stretch">
                  <span className="block break-words font-[family-name:var(--font-sentient)] text-[clamp(16px,1.6vw,20px)] font-medium leading-[1.1] tracking-[-0.015em] text-[var(--color-eva-on-surface)]">
                    {marker.short}
                  </span>
                  <span className="mt-[var(--space-xs)] block font-[family-name:var(--font-dm-mono)] text-[9.5px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-on-surface)]/55">
                    {categories[marker.category]}
                  </span>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.24 }}
            onClick={() => setActive(null)}
            className="fixed inset-0 z-40 bg-[var(--color-eva-ink)]/45"
            aria-hidden
          />
        )}
        {active && (
          <motion.aside
            key="panel"
            role="dialog"
            aria-modal="true"
            aria-label={active.name}
            initial={panelInitial}
            animate={panelAnimate}
            exit={panelExit}
            transition={{ duration: 0.42, ease: EASE_EXPO }}
            className={cn(
              "fixed z-50 bg-[var(--color-eva-surface-lowest)]",
              "bottom-0 left-0 right-0 max-h-[85vh] overflow-y-auto",
              "md:left-auto md:top-0 md:bottom-0 md:right-0 md:w-[clamp(380px,36vw,520px)] md:max-h-none md:border-l md:border-[var(--color-eva-on-surface)]/12",
            )}
          >
            <div className="flex h-full flex-col">
              <div className="flex items-center justify-between border-b border-[var(--color-eva-on-surface)]/12 px-[var(--space-xl)] py-[var(--space-lg)]">
                <span
                  className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em]"
                  style={{ color: CATEGORY_COLOR[active.category] }}
                >
                  § {active.code} · {categories[active.category]}
                </span>
                <button
                  type="button"
                  onClick={() => setActive(null)}
                  className="group/close flex items-center gap-[var(--space-xs)] font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-on-surface)]/55 transition-colors hover:text-[var(--color-eva-on-surface)]"
                >
                  <span>{closeLabel}</span>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
                    <path
                      d="M3 3L9 9M9 3L3 9"
                      stroke="currentColor"
                      strokeWidth="1.2"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>
              </div>

              <div className="flex-1 px-[var(--space-xl)] py-[var(--space-2xl)]">
                <h3 className="font-[family-name:var(--font-sentient)] text-[clamp(1.75rem,3vw,2.5rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
                  {active.name}
                </h3>

                <dl className="mt-[var(--space-2xl)] flex flex-col gap-[var(--space-xl)]">
                  <Field label={detectsLabel} body={active.detects} />
                  <Field
                    label={rangeLabel}
                    body={
                      <span
                        className="font-[family-name:var(--font-sentient)] text-[22px] font-medium leading-none tracking-[-0.015em] text-[var(--color-eva-on-surface)]"
                        style={{ fontVariantNumeric: "tabular-nums" }}
                      >
                        {active.range}
                      </span>
                    }
                  />
                  <Field label={mattersLabel} body={active.matters} />
                </dl>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </section>
  );
}

function Field({ label, body }: { label: string; body: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-[var(--space-sm)] border-t border-[var(--color-eva-on-surface)]/12 pt-[var(--space-md)]">
      <dt className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
        {label}
      </dt>
      <dd className="font-[family-name:var(--font-manrope)] text-[15px] leading-[1.55] text-[var(--color-eva-on-surface)]/85">
        {body}
      </dd>
    </div>
  );
}
