"use client";

import { motion, useReducedMotion } from "framer-motion";

interface AnimatedGradientBgProps {
  variant?: "hero" | "dark" | "subtle";
}

/* Soft Structuralism: ultra-diffused, airy floating orbs with minimal color */
const ORB_CONFIGS = {
  hero: [
    { color: "rgba(188,236,225,0.10)", size: 600, x: "15%", y: "15%", delay: 0 },
    { color: "rgba(217,123,92,0.05)", size: 500, x: "75%", y: "25%", delay: 3 },
    { color: "rgba(196,147,50,0.03)", size: 450, x: "50%", y: "75%", delay: 6 },
    { color: "rgba(188,236,225,0.06)", size: 380, x: "85%", y: "70%", delay: 9 },
  ],
  dark: [
    { color: "rgba(58,102,94,0.08)", size: 600, x: "20%", y: "20%", delay: 0 },
    { color: "rgba(151,71,44,0.05)", size: 500, x: "75%", y: "50%", delay: 4 },
    { color: "rgba(188,236,225,0.04)", size: 400, x: "50%", y: "80%", delay: 8 },
  ],
  subtle: [
    { color: "rgba(188,236,225,0.06)", size: 500, x: "30%", y: "30%", delay: 0 },
    { color: "rgba(217,123,92,0.03)", size: 400, x: "65%", y: "60%", delay: 3 },
  ],
};

export function AnimatedGradientBg({ variant = "hero" }: AnimatedGradientBgProps) {
  const orbs = ORB_CONFIGS[variant];
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {orbs.map((orb, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: orb.size,
            height: orb.size,
            left: orb.x,
            top: orb.y,
            background: `radial-gradient(circle, ${orb.color} 0%, transparent 65%)`,
            filter: "blur(120px)",
            transform: "translate(-50%, -50%)",
            mixBlendMode: "normal",
          }}
          animate={
            prefersReducedMotion
              ? {}
              : {
                  x: [0, 20, -15, 10, 0],
                  y: [0, -15, 12, 18, 0],
                  scale: [1, 1.04, 0.96, 1.02, 1],
                }
          }
          transition={{
            duration: 35,
            delay: orb.delay,
            repeat: Infinity,
            repeatType: "loop",
            ease: [0.32, 0.72, 0, 1],
          }}
        />
      ))}
    </div>
  );
}
