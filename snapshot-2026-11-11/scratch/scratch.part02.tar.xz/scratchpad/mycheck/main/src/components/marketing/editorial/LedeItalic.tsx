import { cn } from "@/lib/utils";

/**
 * LedeItalic — the editorial italic lede pattern.
 *
 * A Sentient medium italic paragraph that sits between a
 * section headline and body copy, carrying the "opening
 * claim" of a chapter. Matches the landing hero's sub
 * treatment (the "95% of 'normal' lab results hide a
 * deficiency." line) and the §02 Shortfall closing line.
 *
 * Typography:
 *   Sentient medium italic
 *   22 / 28 / 32px (mobile / md / lg)
 *   leading 1.3 / 1.28 / 1.25
 *   max-width 40ch (clamped so it reads as a quoted claim,
 *     not a long paragraph)
 *   color default ink #1d1b18
 *
 * Why italic Sentient: it's the single typographic move that
 * says "this is a pulled claim" without requiring a layout
 * break or a pull-quote column. Classic late-NYT-Magazine
 * / Aesop / Bloomberg Work Shift editorial pattern.
 */
type LedeColor = "ink" | "terra" | "jade" | "inverse";

const colorClass: Record<LedeColor, string> = {
  ink: "text-[#1d1b18]",
  terra: "text-[#97472c]",
  jade: "text-[#3a665e]",
  inverse: "text-[#fef8f2]",
};

interface LedeItalicProps {
  children: React.ReactNode;
  color?: LedeColor;
  /** `max-w-[Nch]` clamp. Default 40ch. */
  maxCh?: number;
  balance?: boolean;
  className?: string;
}

export function LedeItalic({
  children,
  color = "ink",
  maxCh = 40,
  balance = true,
  className,
}: LedeItalicProps) {
  return (
    <p
      className={cn(
        "font-[family-name:var(--font-sentient)] text-[22px] font-medium italic leading-[1.3] md:text-[28px] md:leading-[1.28] lg:text-[32px] lg:leading-[1.25]",
        colorClass[color],
        className,
      )}
      style={{
        maxWidth: `${maxCh}ch`,
        ...(balance ? { textWrap: "balance" as const } : {}),
      }}
    >
      {children}
    </p>
  );
}
