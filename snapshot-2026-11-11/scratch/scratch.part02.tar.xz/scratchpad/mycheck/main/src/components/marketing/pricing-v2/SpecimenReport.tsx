"use client";

import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface SpecimenRow {
  code: string;
  name: string;
  value: string;
  unit: string;
  /** Position of the value inside the range as a 0–100 percent. */
  position: number;
  /** Width of the "optimal zone" band as a 0–100 percent, centered on `zoneMid`. */
  zoneMid: number;
  zoneWidth: number;
  status: "optimal" | "watch";
}

interface SpecimenReportProps {
  eyebrow: string;
  headline: string;
  kicker: string;
  /** Document metadata — appears as a hairline masthead. */
  meta: {
    subject: string;
    cycle: string;
    specimen: string;
    received: string;
  };
  rows: SpecimenRow[];
  pullQuote: {
    kicker: string;
    body: string;
    attribution: string;
  };
  /** Signature line text at the bottom of the plate. */
  signature: string;
}

const EASE_EXPO: [number, number, number, number] = [0.16, 1, 0.3, 1];

function RangeBar({
  position,
  zoneMid,
  zoneWidth,
  status,
  animate,
}: {
  position: number;
  zoneMid: number;
  zoneWidth: number;
  status: "optimal" | "watch";
  animate: boolean;
}) {
  const zoneLeft = Math.max(0, zoneMid - zoneWidth / 2);
  const zoneRight = Math.min(100, zoneMid + zoneWidth / 2);
  const dotColor =
    status === "optimal"
      ? "var(--color-eva-jade)"
      : "var(--color-eva-gold)";

  return (
    <div className="relative h-[2px] w-full">
      {/* Base rule */}
      <span
        aria-hidden
        className="absolute inset-0 bg-[var(--color-eva-on-surface)]/15"
      />
      {/* Optimal zone */}
      <motion.span
        aria-hidden
        className="absolute top-0 h-full bg-[var(--color-eva-mint)]/60"
        initial={animate ? { scaleX: 0 } : undefined}
        whileInView={animate ? { scaleX: 1 } : undefined}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.8, ease: EASE_EXPO, delay: 0.1 }}
        style={{
          left: `${zoneLeft}%`,
          width: `${zoneRight - zoneLeft}%`,
          transformOrigin: "left center",
        }}
      />
      {/* Reading marker */}
      <motion.span
        aria-hidden
        className="absolute top-1/2 h-[10px] w-[10px] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{ left: `${position}%`, backgroundColor: dotColor }}
        initial={animate ? { opacity: 0, scale: 0.4 } : undefined}
        whileInView={animate ? { opacity: 1, scale: 1 } : undefined}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.5, ease: EASE_EXPO, delay: 0.5 }}
      />
    </div>
  );
}

export function SpecimenReport({
  eyebrow,
  headline,
  kicker,
  meta,
  rows,
  pullQuote,
  signature,
}: SpecimenReportProps) {
  const reduce = useReducedMotion();
  const animate = !reduce;

  return (
    <section className="relative bg-[var(--color-eva-surface)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] md:px-[var(--space-3xl)]">
      <div className="mx-auto max-w-[1240px]">
        {/* Section masthead */}
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] border-t border-[var(--color-eva-on-surface)]/15 pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            {eyebrow}
          </span>
          <div>
            <h2 className="font-[family-name:var(--font-sentient)] text-[clamp(2rem,4vw,3.25rem)] font-medium leading-[1.05] tracking-[-0.025em] text-[var(--color-eva-on-surface)]">
              {headline}
            </h2>
            <p className="mt-[var(--space-md)] max-w-[52ch] font-[family-name:var(--font-manrope)] text-[15.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/70">
              {kicker}
            </p>
          </div>
        </header>

        {/* The specimen plate */}
        <motion.div
          initial={animate ? { opacity: 0, y: 24 } : undefined}
          whileInView={animate ? { opacity: 1, y: 0 } : undefined}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.9, ease: EASE_EXPO }}
          className="relative mt-[clamp(3rem,5vw,4rem)] overflow-hidden bg-[var(--color-eva-surface-lowest)]"
        >
          <span
            aria-hidden
            className="absolute inset-0 border border-[var(--color-eva-on-surface)]/12"
          />
          {/* Subtle paper grain — scoped to this plate only */}
          <span
            aria-hidden
            className="pointer-events-none absolute inset-0 opacity-[0.04] mix-blend-multiply"
            style={{
              backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='g'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23g)'/></svg>")`,
              backgroundSize: "200px 200px",
            }}
          />

          {/* Plate masthead */}
          <div className="relative grid grid-cols-2 gap-[var(--space-xl)] border-b border-[var(--color-eva-on-surface)]/12 px-[clamp(1.5rem,4vw,3rem)] py-[var(--space-xl)] md:grid-cols-4">
            <MetaCell label="Subject" value={meta.subject} />
            <MetaCell label="Cycle" value={meta.cycle} />
            <MetaCell label="Specimen" value={meta.specimen} />
            <MetaCell label="Received" value={meta.received} />
          </div>

          {/* Biomarker table */}
          <div className="relative px-[clamp(1.5rem,4vw,3rem)] py-[clamp(1.5rem,4vw,2.5rem)]">
            {/* Column headers */}
            <div className="hidden grid-cols-[72px_minmax(0,1.5fr)_minmax(0,1fr)_minmax(0,1.2fr)_72px] gap-[var(--space-lg)] border-b border-[var(--color-eva-on-surface)]/15 pb-[var(--space-sm)] font-[family-name:var(--font-dm-mono)] text-[9.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/45 md:grid">
              <span>Code</span>
              <span>Marker</span>
              <span className="text-right">Reading</span>
              <span>Range</span>
              <span className="text-right">Zone</span>
            </div>

            <ul>
              {rows.map((row, idx) => (
                <motion.li
                  key={row.code}
                  initial={animate ? { opacity: 0, y: 8 } : undefined}
                  whileInView={animate ? { opacity: 1, y: 0 } : undefined}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{
                    duration: 0.5,
                    delay: idx * 0.04,
                    ease: EASE_EXPO,
                  }}
                  className={cn(
                    "grid grid-cols-[1fr_auto] items-start gap-x-[var(--space-lg)] gap-y-[var(--space-sm)] border-b border-[var(--color-eva-on-surface)]/8 py-[var(--space-lg)] last:border-b-0",
                    "md:grid-cols-[72px_minmax(0,1.5fr)_minmax(0,1fr)_minmax(0,1.2fr)_72px]",
                  )}
                >
                  <span className="col-span-1 font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-on-surface)]/60 md:col-span-1">
                    {row.code}
                  </span>
                  <span className="col-start-1 font-[family-name:var(--font-manrope)] text-[14px] font-medium text-[var(--color-eva-on-surface)] md:col-start-auto md:col-span-1">
                    {row.name}
                  </span>
                  <span
                    className="col-start-2 row-start-1 text-right font-[family-name:var(--font-sentient)] text-[22px] font-medium leading-none text-[var(--color-eva-on-surface)] md:col-start-auto md:row-start-auto md:text-[26px]"
                    style={{ fontVariantNumeric: "tabular-nums" }}
                  >
                    {row.value}
                    <span className="ml-[var(--space-xs)] font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.14em] text-[var(--color-eva-on-surface)]/50">
                      {row.unit}
                    </span>
                  </span>
                  <span className="col-span-2 flex items-center md:col-span-1">
                    <RangeBar
                      position={row.position}
                      zoneMid={row.zoneMid}
                      zoneWidth={row.zoneWidth}
                      status={row.status}
                      animate={animate}
                    />
                  </span>
                  <span
                    className={cn(
                      "col-start-2 row-start-2 text-right font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.16em]",
                      "md:col-start-auto md:row-start-auto",
                      row.status === "optimal"
                        ? "text-[var(--color-eva-jade)]"
                        : "text-[var(--color-eva-gold)]",
                    )}
                  >
                    {row.status}
                  </span>
                </motion.li>
              ))}
            </ul>
          </div>

          {/* Pull quote */}
          <div className="relative grid grid-cols-1 gap-[var(--space-xl)] border-t border-[var(--color-eva-on-surface)]/12 bg-[var(--color-eva-cream-warm)] px-[clamp(1.5rem,4vw,3rem)] py-[clamp(2rem,4vw,3rem)] md:grid-cols-[140px_minmax(0,1fr)]">
            <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
              {pullQuote.kicker}
            </span>
            <blockquote className="max-w-[60ch] font-[family-name:var(--font-sentient)] text-[clamp(1.25rem,2.2vw,1.625rem)] font-medium leading-[1.35] tracking-[-0.012em] text-[var(--color-eva-on-surface)]">
              &ldquo;{pullQuote.body}&rdquo;
              <footer className="mt-[var(--space-md)] font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-on-surface)]/55">
                · {pullQuote.attribution}
              </footer>
            </blockquote>
          </div>

          {/* Signature */}
          <div className="relative flex items-baseline justify-between border-t border-[var(--color-eva-on-surface)]/12 px-[clamp(1.5rem,4vw,3rem)] py-[var(--space-lg)] font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/55">
            <span>{signature}</span>
            <span aria-hidden>§</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function MetaCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-[var(--space-xs)]">
      <span className="font-[family-name:var(--font-dm-mono)] text-[9.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-on-surface)]/45">
        {label}
      </span>
      <span className="font-[family-name:var(--font-manrope)] text-[13.5px] font-medium text-[var(--color-eva-on-surface)]">
        {value}
      </span>
    </div>
  );
}
