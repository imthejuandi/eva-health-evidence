"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

interface RangeComparisonBarProps {
  biomarkerName: string;
  value: number;
  unit?: string;
  standardRange: { low: number; high: number };
  optimalRange: { low: number; high: number };
  standardVerdict: string;
  optimalVerdict: string;
}

function getValuePosition(value: number, min: number, max: number): number {
  const clamped = Math.max(min, Math.min(max, value));
  return ((clamped - min) / (max - min)) * 100;
}

export function RangeComparisonBar({
  biomarkerName,
  value,
  unit,
  standardRange,
  optimalRange,
  standardVerdict,
  optimalVerdict,
}: RangeComparisonBarProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const absMin = Math.min(standardRange.low, optimalRange.low) * 0.8;
  const absMax = Math.max(standardRange.high, optimalRange.high) * 1.2;
  const valuePos = getValuePosition(value, absMin, absMax);

  const stdLeft = getValuePosition(standardRange.low, absMin, absMax);
  const stdWidth = getValuePosition(standardRange.high, absMin, absMax) - stdLeft;

  const optLeft = getValuePosition(optimalRange.low, absMin, absMax);
  const optWidth = getValuePosition(optimalRange.high, absMin, absMax) - optLeft;

  const isStdOk = value >= standardRange.low && value <= standardRange.high;
  const isOptOk = value >= optimalRange.low && value <= optimalRange.high;

  return (
    <div
      ref={ref}
      /* ─── Outer Shell (Double-Bezel) ─── */
      className="rounded-[2rem] p-1.5"
      style={{
        background: "rgba(255,255,255,0.06)",
        boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.08)",
      }}
    >
      {/* ─── Inner Core ─── */}
      <div
        className="rounded-[calc(2rem-0.375rem)] p-7"
        style={{
          background: "rgba(255,255,255,0.05)",
          boxShadow: "inset 0 1px 1px rgba(255,255,255,0.08)",
        }}
      >
        <div className="mb-1 flex items-baseline justify-between">
          <h4 className="font-heading text-[15px] font-bold text-white">
            {biomarkerName}
          </h4>
          <span className="font-heading text-[18px] font-extrabold text-white">
            {value}
            {unit && (
              <span className="ml-1 text-[12px] font-medium text-white/50">
                {unit}
              </span>
            )}
          </span>
        </div>

        {/* Standard Lab Range */}
        <div className="mt-5">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="font-mono text-[10px] font-medium uppercase tracking-[1.4px] text-white/40">
              Standard Lab Range
            </span>
            <span
              className={`rounded-full px-2.5 py-0.5 text-[10px] font-semibold ${
                isStdOk
                  ? "bg-eva-jade/15 text-eva-jade-light"
                  : "bg-eva-terra/12 text-eva-terra-light"
              }`}
            >
              {standardVerdict}
            </span>
          </div>
          <div className="relative h-2.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
            <motion.div
              className="absolute top-0 h-full rounded-full bg-white/[0.08]"
              initial={{ width: 0 }}
              animate={isInView ? { width: `${stdWidth}%` } : {}}
              transition={{ duration: 0.7, ease: [0.32, 0.72, 0, 1] }}
              style={{ left: `${stdLeft}%` }}
            />
            <motion.div
              className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/20 bg-white shadow-[0_2px_8px_rgba(0,0,0,0.3)]"
              initial={{ left: "0%" }}
              animate={isInView ? { left: `${valuePos}%` } : {}}
              transition={{ duration: 0.85, ease: [0.32, 0.72, 0, 1], delay: 0.2 }}
            />
          </div>
          <div className="mt-1 flex justify-between font-mono text-[9px] text-white/30">
            <span>{standardRange.low}</span>
            <span>{standardRange.high}</span>
          </div>
        </div>

        {/* EVA Optimal Range */}
        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="font-mono text-[10px] font-medium uppercase tracking-[1.4px] text-eva-terra-light/70">
              EVA Optimal Range
            </span>
            <span
              className={`rounded-full px-2.5 py-0.5 text-[10px] font-semibold ${
                isOptOk
                  ? "bg-eva-jade/15 text-eva-jade-light"
                  : "bg-eva-gold/15 text-[#e8c76a]"
              }`}
            >
              {optimalVerdict}
            </span>
          </div>
          <div className="relative h-2.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
            <motion.div
              className="absolute top-0 h-full rounded-full bg-gradient-to-r from-eva-terra/15 to-eva-terra-light/20"
              initial={{ width: 0 }}
              animate={isInView ? { width: `${optWidth}%` } : {}}
              transition={{ duration: 0.7, ease: [0.32, 0.72, 0, 1], delay: 0.3 }}
              style={{ left: `${optLeft}%` }}
            />
            <motion.div
              className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white/20 shadow-[0_2px_8px_rgba(0,0,0,0.3)]"
              initial={{ left: "0%" }}
              animate={isInView ? { left: `${valuePos}%` } : {}}
              transition={{ duration: 0.85, ease: [0.32, 0.72, 0, 1], delay: 0.5 }}
              style={{ background: isOptOk ? "#3a665e" : "#c49332" }}
            />
          </div>
          <div className="mt-1 flex justify-between font-mono text-[9px] text-white/30">
            <span>{optimalRange.low}</span>
            <span>{optimalRange.high}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
