"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";

const E: [number, number, number, number] = [0.32, 0.72, 0, 1];

export type AIPart = { t: string } | { v: string; c: string };

function Prose({ parts, className }: { parts: AIPart[]; className?: string }) {
  return (
    <p className={`font-[family-name:var(--font-manrope)] text-[14px] leading-[1.7] text-[#2a2319] md:text-[16px] ${className ?? ""}`}>
      {parts.map((p, i) => "v" in p
        ? <span key={i} className="font-[family-name:var(--font-dm-mono)] text-[13px] font-bold [font-feature-settings:'tnum'] md:text-[14px]" style={{ color: p.c }}>{p.v}</span>
        : <span key={i}>{p.t}</span>
      )}
    </p>
  );
}

function MiniTrack({ name, val, unit, bandL, bandW, pinL, pinC, optR }: {
  name: string; val: string; unit: string; bandL: string; bandW: string; pinL: string; pinC: string; optR: string;
}) {
  return (
    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} transition={{ duration: 0.5, delay: 0.3, ease: E }}
      className="mt-3 overflow-hidden rounded-lg bg-[#f0ebe5] p-3 md:mt-4 md:rounded-xl md:p-4">
      <div className="flex items-center justify-between text-[11px] md:text-[12px]">
        <span className="font-[family-name:var(--font-manrope)] font-bold text-[#1d1b18]">{name}</span>
        <span className="font-[family-name:var(--font-dm-mono)] font-bold [font-feature-settings:'tnum']" style={{ color: pinC }}>{val} <span className="text-[9px] text-[#8a7f76] md:text-[10px]">{unit}</span></span>
      </div>
      <div className="relative mt-2 h-[12px] w-full md:mt-2.5 md:h-[14px]">
        <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#1d1b18]/8" />
        <div className="absolute top-1/2 h-[8px] -translate-y-1/2 rounded-full md:h-[9px]" style={{ left: bandL, width: bandW, background: "linear-gradient(90deg, rgba(58,102,94,0.2), rgba(58,102,94,0.35))" }} />
        <motion.div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2" style={{ left: pinL }} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.6, duration: 0.4, ease: E }}>
          <span className="block h-[12px] w-[2.5px] rounded-full md:h-[14px] md:w-[3px]" style={{ backgroundColor: pinC, boxShadow: `0 0 6px ${pinC}60` }} />
        </motion.div>
      </div>
      <p className="mt-1.5 font-[family-name:var(--font-dm-mono)] text-[8px] text-[#3a665e] [font-feature-settings:'tnum'] md:text-[9px]">Optimal: {optR}</p>
    </motion.div>
  );
}

function Dots() {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-1 py-1.5">
      {[0, 1, 2].map((i) => <motion.span key={i} className="h-[5px] w-[5px] rounded-full bg-[#8a7f76]/35 md:h-[6px] md:w-[6px]" animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2, ease: "easeInOut" }} />)}
    </motion.div>
  );
}

interface ChatProps {
  premium: string;
  q1: string; a1: AIPart[];
  q2: string; a2: AIPart[];
  placeholder: string;
  className?: string;
}

export function AIChat({ premium, q1, a1, q2, a2, placeholder, className }: ChatProps) {
  const ref = useRef<HTMLDivElement>(null);
  const iv = useInView(ref, { once: true, margin: "-12%" });
  const [s, setS] = useState(0);

  useEffect(() => {
    if (!iv) return;
    const d = [500, 1800, 3500, 5500, 6800, 8500];
    const ts = d.map((ms, i) => setTimeout(() => setS(i + 1), ms));
    return () => ts.forEach(clearTimeout);
  }, [iv]);

  const m = { initial: { opacity: 0, y: 14, filter: "blur(5px)" }, animate: { opacity: 1, y: 0, filter: "blur(0px)" }, transition: { duration: 0.6, ease: E } };

  return (
    <div ref={ref} className={`relative mx-auto max-w-[860px] ${className ?? ""}`}>
      <div aria-hidden className="pointer-events-none absolute -inset-6 -z-10 rounded-[2.5rem] opacity-50 blur-3xl md:-inset-10" style={{ background: "radial-gradient(ellipse at 50% 40%, rgba(151,71,44,0.07), rgba(58,102,94,0.03) 60%, transparent 80%)" }} />
      <div className="overflow-hidden rounded-xl border border-[#1d1b18]/8 bg-[#fef8f2] md:rounded-2xl">
        {/* Header */}
        <div className="flex items-center gap-2.5 border-b border-[#1d1b18]/6 px-4 py-3 md:px-6 md:py-4">
          <span className="h-2 w-2 rounded-full bg-[#3a665e] shadow-[0_0_5px_rgba(58,102,94,0.35)]" />
          <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#1d1b18] md:text-[14px]">EVA AI</span>
          <span className="ml-auto font-[family-name:var(--font-dm-mono)] text-[8px] uppercase tracking-[1.5px] text-[#c49332] md:text-[9px]">{premium}</span>
        </div>
        {/* Messages */}
        <div className="flex min-h-[260px] flex-col gap-4 p-4 md:min-h-[380px] md:gap-6 md:p-6">
          {s >= 1 && <motion.div {...m} className="flex justify-end"><div className="max-w-[85%] rounded-xl rounded-br-sm bg-[#f0ebe5] px-3.5 py-2.5 md:max-w-[75%] md:rounded-2xl md:rounded-br-md md:px-5 md:py-3.5"><p className="font-[family-name:var(--font-manrope)] text-[13px] leading-[1.6] text-[#1d1b18] md:text-[15px]">{q1}</p></div></motion.div>}
          {s === 2 && <Dots />}
          {s >= 3 && <motion.div {...m} className="max-w-[92%] md:max-w-[85%]"><Prose parts={a1} /><MiniTrack name="Ferritin" val="38" unit="ng/mL" bandL="21%" bandW="53%" pinL="15%" pinC="#c49332" optR="50–150" /></motion.div>}
          {s >= 4 && <motion.div {...m} className="flex justify-end"><div className="max-w-[85%] rounded-xl rounded-br-sm bg-[#f0ebe5] px-3.5 py-2.5 md:max-w-[75%] md:rounded-2xl md:rounded-br-md md:px-5 md:py-3.5"><p className="font-[family-name:var(--font-manrope)] text-[13px] leading-[1.6] text-[#1d1b18] md:text-[15px]">{q2}</p></div></motion.div>}
          {s === 5 && <Dots />}
          {s >= 6 && <motion.div {...m} className="max-w-[92%] md:max-w-[85%]"><Prose parts={a2} /><MiniTrack name="ApoB" val="95" unit="mg/dL" bandL="9%" bandW="36%" pinL="59%" pinC="#c49332" optR="40–80" /></motion.div>}
        </div>
        {/* Input placeholder */}
        <div className="border-t border-[#1d1b18]/6 px-4 py-3 md:px-6 md:py-4">
          <div className="rounded-lg bg-[#f0ebe5] px-3.5 py-2.5 md:rounded-xl md:px-4 md:py-3">
            <span className="font-[family-name:var(--font-manrope)] text-[13px] text-[#8a7f76] md:text-[14px]">{placeholder}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
