import type { ReactNode } from "react";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import { yearRoman, quarterRoman } from "@/lib/dashboard-format";

interface EditorialMastheadProps {
  /** The publication-context label that sits in the centre of the
   *  stripe. Examples: "The almanac", "Submission", "Specimen file",
   *  "Quarterly readings", "Consultation". */
  issue: string;
  /** Optional right-most caption. When omitted, defaults to
   *  "Vol. {Roman year}". Pass a string OR JSX — JSX lets call sites
   *  highlight specific words inline (e.g. an ink-bold counter or a
   *  month name). */
  volSuffix?: ReactNode;
  /** Convenience flag — when `volSuffix` is omitted, append the
   *  current quarter to the default volume caption
   *  ("Vol. MMXXVI · Q II"). */
  withQuarter?: boolean;
  /** ISO date string used to derive the year + quarter on the
   *  default captions. Defaults to `new Date()`. */
  date?: string;
}

/**
 * EditorialMasthead — the magazine-cap stripe at the top of every
 * editorial dashboard page. Three text columns separated by hairlines:
 * "EVA · {issue} · Vol. MMXXVI [· QII]".
 *
 * The right-most caption is composed as React children so call sites
 * can drop in their own bespoke highlights — the biomarker monograph
 * passes "Chapter <ink>Cardiovascular</ink>", the manage archive
 * passes "<ink>03</ink> readings", the consultation passes a
 * month-led "MAY <ink>MMXXVI</ink> · QII".
 */
export function EditorialMasthead({
  issue,
  volSuffix,
  withQuarter = false,
  date,
}: EditorialMastheadProps) {
  const d = date ? new Date(date) : new Date();
  const yr = yearRoman(d.getFullYear());
  const q = quarterRoman(d);

  const right: ReactNode =
    volSuffix !== undefined ? (
      volSuffix
    ) : withQuarter ? (
      <>
        Vol. <span className="text-[#1d1b18]">{yr}</span>{" "}
        <span className="text-[#1d1b18]/40">·</span> Q{q}
      </>
    ) : (
      <>
        Vol. <span className="text-[#1d1b18]">{yr}</span>
      </>
    );

  return (
    <div className="flex items-center gap-4 border-b border-[#1d1b18]/15 pb-3 md:gap-6">
      <p
        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2.4px] text-[#1d1b18]`}
      >
        EVA
      </p>
      <span aria-hidden className="h-px flex-1 bg-[#1d1b18]/15" />
      <p
        className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[2px] text-[#8a7f76]`}
      >
        {issue}
      </p>
      <span aria-hidden className="hidden h-px w-6 bg-[#1d1b18]/15 md:block" />
      <p
        className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[2px] text-[#8a7f76]`}
      >
        {right}
      </p>
    </div>
  );
}
