"use client";

interface MiniSparklineProps {
  data: (number | null)[];
  color?: string;
  width?: number;
  height?: number;
}

export function MiniSparkline({
  data,
  color = "#3a665e",
  width = 64,
  height = 26,
}: MiniSparklineProps) {
  const valid = data.filter((v): v is number => v != null);
  if (valid.length < 2) return <div style={{ width, height }} />;

  const min = Math.min(...valid);
  const max = Math.max(...valid);
  const range = max - min || 1;
  const pad = 2;

  const points = valid
    .map((v, i) => {
      const x = (i / (valid.length - 1)) * (width - pad * 2) + pad;
      const y = height - pad - ((v - min) / range) * (height - pad * 2);
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <svg width={width} height={height} className="shrink-0">
      <polyline
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
      />
    </svg>
  );
}
