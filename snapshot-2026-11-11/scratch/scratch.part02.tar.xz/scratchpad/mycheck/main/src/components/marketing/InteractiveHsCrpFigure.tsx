"use client";

import { useCallback, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";

interface InteractiveHsCrpFigureProps {
  clinicLabel: string;
  optimalLabel: string;
  biomarkerName: string;
  unit: string;
  dragHint: string;
  statusOptimal: string;
  statusAboveOpt: string;
  statusElevated: string;
  interpOptimal: string;
  interpAboveOpt: string;
  interpElevated: string;
  valueLabel: string;
  statusLabel: string;
}

/* ─── canvas geometry ─── */
const W = 800;
const H = 460;
const BASE_Y = 320;
const PEAK_Y = 60;
const TRACK_LEFT = 40;
const TRACK_RIGHT = 760;
const TRACK_W = TRACK_RIGHT - TRACK_LEFT;

/* ─── hs-CRP scale ─── */
const MIN_VALUE = 0;
const MAX_VALUE = 6;
const OPTIMAL_MAX = 1.0;
const CLINIC_MAX = 3.0;
const INITIAL_VALUE = 2.1;

/* ─── bell curve: population distribution peaked near 2 mg/L ─── */
const BELL_CENTER_X = 280; // peak x (~2 mg/L on the scale)
const BELL_SIGMA = 140;
const BELL_AMPLITUDE = BASE_Y - PEAK_Y;

function clampValue(v: number): number {
  return Math.max(MIN_VALUE, Math.min(MAX_VALUE, v));
}

function valueToX(value: number): number {
  return TRACK_LEFT + (clampValue(value) / MAX_VALUE) * TRACK_W;
}

function xToValue(x: number): number {
  const clampedX = Math.max(TRACK_LEFT, Math.min(TRACK_RIGHT, x));
  return clampValue(((clampedX - TRACK_LEFT) / TRACK_W) * MAX_VALUE);
}

function bellY(x: number): number {
  const norm = (x - BELL_CENTER_X) / BELL_SIGMA;
  return BASE_Y - BELL_AMPLITUDE * Math.exp(-(norm * norm) / 2);
}

type Status = "optimal" | "aboveOpt" | "elevated";

function classify(v: number): Status {
  if (v <= OPTIMAL_MAX) return "optimal";
  if (v <= CLINIC_MAX) return "aboveOpt";
  return "elevated";
}

/**
 * Interactive figure for § 02. A hs-CRP value the reader can drag,
 * mousewheel, or keyboard-adjust. As the value moves, the marker
 * crosses bands (optimal / above-optimal / elevated) and a status
 * panel below updates with a colour-coded label + one-sentence
 * interpretation.
 *
 * Scale: 0–6 mg/L.
 *   ≤ 1.0      → Optimal            (jade)
 *   1.0 – 3.0  → Above optimal       (muted)
 *   >  3.0     → Elevated            (terra)
 *
 * Interactions:
 *   - pointer drag (mouse + touch via Pointer Events)
 *   - mousewheel over the figure
 *   - keyboard arrows when the figure is focused (shift = larger step)
 */
export function InteractiveHsCrpFigure({
  clinicLabel,
  optimalLabel,
  biomarkerName,
  unit,
  dragHint,
  statusOptimal,
  statusAboveOpt,
  statusElevated,
  interpOptimal,
  interpAboveOpt,
  interpElevated,
  valueLabel,
  statusLabel,
}: InteractiveHsCrpFigureProps) {
  const reduce = useReducedMotion();
  const svgRef = useRef<SVGSVGElement>(null);
  const [value, setValue] = useState(INITIAL_VALUE);
  const [isDragging, setIsDragging] = useState(false);

  const status = classify(value);
  const userX = valueToX(value);
  const userY = bellY(userX);

  /* ─── bands ─── */
  const clinicX = valueToX(0);
  const clinicRight = valueToX(CLINIC_MAX);
  const optimalRight = valueToX(OPTIMAL_MAX);

  /* ─── bell path ─── */
  const bellPath = `M ${TRACK_LEFT} ${BASE_Y} C ${TRACK_LEFT + 140} ${BASE_Y}, ${BELL_CENTER_X - 60} ${PEAK_Y}, ${BELL_CENTER_X} ${PEAK_Y} C ${BELL_CENTER_X + 60} ${PEAK_Y}, ${BELL_CENTER_X + 180} ${BASE_Y}, ${TRACK_RIGHT} ${BASE_Y}`;
  const bellFillPath = `${bellPath} L ${TRACK_RIGHT} ${BASE_Y} L ${TRACK_LEFT} ${BASE_Y} Z`;

  /* ─── status palette ─── */
  const statusMeta = {
    optimal: { label: statusOptimal, interp: interpOptimal, color: "#3a665e", bg: "rgba(58,102,94,0.12)" },
    aboveOpt: { label: statusAboveOpt, interp: interpAboveOpt, color: "#8a7f76", bg: "rgba(138,127,118,0.14)" },
    elevated: { label: statusElevated, interp: interpElevated, color: "#97472c", bg: "rgba(151,71,44,0.12)" },
  }[status];

  /* ─── pointer handling ─── */
  const updateFromClientX = useCallback((clientX: number) => {
    const svg = svgRef.current;
    if (!svg) return;
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = 0;
    const ctm = svg.getScreenCTM();
    if (!ctm) return;
    const localX = pt.matrixTransform(ctm.inverse()).x;
    setValue(xToValue(localX));
  }, []);

  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsDragging(true);
    updateFromClientX(e.clientX);
  };
  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!isDragging) return;
    updateFromClientX(e.clientX);
  };
  const handlePointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    e.currentTarget.releasePointerCapture(e.pointerId);
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.15 : -0.15;
    setValue((v) => clampValue(v + delta));
  };

  const handleKeyDown = (e: React.KeyboardEvent<SVGSVGElement>) => {
    const step = e.shiftKey ? 0.5 : 0.1;
    if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
      e.preventDefault();
      setValue((v) => clampValue(v - step));
    } else if (e.key === "ArrowRight" || e.key === "ArrowUp") {
      e.preventDefault();
      setValue((v) => clampValue(v + step));
    } else if (e.key === "Home") {
      e.preventDefault();
      setValue(MIN_VALUE);
    } else if (e.key === "End") {
      e.preventDefault();
      setValue(MAX_VALUE);
    }
  };

  const entrance = (delay: number) =>
    reduce
      ? { duration: 0 }
      : { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] };

  return (
    <div className="relative">
      <div className="mx-auto w-full max-w-[800px]">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${W} ${H}`}
          preserveAspectRatio="xMidYMid meet"
          className="h-auto w-full select-none"
          role="slider"
          tabIndex={0}
          aria-valuemin={MIN_VALUE}
          aria-valuemax={MAX_VALUE}
          aria-valuenow={Math.round(value * 10) / 10}
          aria-valuetext={`${value.toFixed(1)} ${unit}, ${statusMeta.label}`}
          aria-label={`${biomarkerName} explorer`}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onWheel={handleWheel}
          onKeyDown={handleKeyDown}
          style={{
            cursor: isDragging ? "grabbing" : "grab",
            touchAction: "none",
            outline: "none",
          }}
        >
          <defs>
            <linearGradient id="hscrp-bell-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(29,27,24,0.08)" />
              <stop offset="100%" stopColor="rgba(29,27,24,0.01)" />
            </linearGradient>
            <linearGradient id="hscrp-optimal-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(58,102,94,0.32)" />
              <stop offset="100%" stopColor="rgba(58,102,94,0.1)" />
            </linearGradient>
          </defs>

          {/* Baseline + tick marks */}
          <motion.g
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={entrance(0.5)}
          >
            <line
              x1="0"
              y1={BASE_Y}
              x2={W}
              y2={BASE_Y}
              stroke="rgba(29,27,24,0.18)"
              strokeWidth="1"
            />
            {[0, 1, 2, 3, 4, 5, 6].map((v) => {
              const x = valueToX(v);
              return (
                <g key={v}>
                  <line
                    x1={x}
                    y1={BASE_Y}
                    x2={x}
                    y2={BASE_Y + 6}
                    stroke="rgba(29,27,24,0.3)"
                    strokeWidth="1"
                  />
                  <text
                    x={x}
                    y={BASE_Y + 20}
                    textAnchor="middle"
                    fontSize="10"
                    fontFamily="var(--font-dm-mono), monospace"
                    fill="#8a7f76"
                    style={{ fontFeatureSettings: "'tnum'" }}
                  >
                    {v}
                  </text>
                </g>
              );
            })}
            <text
              x={TRACK_RIGHT + 12}
              y={BASE_Y + 20}
              textAnchor="start"
              fontSize="9"
              fontFamily="var(--font-dm-mono), monospace"
              fill="#8a7f76"
              fontWeight="600"
              letterSpacing="1.4"
              style={{ textTransform: "uppercase" }}
            >
              {unit}
            </text>
          </motion.g>

          {/* Clinic-normal band (wide, muted) */}
          <motion.rect
            x={clinicX}
            y={PEAK_Y - 10}
            width={clinicRight - clinicX}
            height={BASE_Y - PEAK_Y + 10}
            fill="rgba(138,127,118,0.13)"
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={entrance(0.7)}
          />
          {/* Optimal band (narrow, jade) — sits atop clinic on its left edge */}
          <motion.rect
            x={clinicX}
            y={PEAK_Y - 10}
            width={optimalRight - clinicX}
            height={BASE_Y - PEAK_Y + 10}
            fill="url(#hscrp-optimal-fill)"
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={entrance(0.85)}
          />

          {/* Band edge marks */}
          <motion.g
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={entrance(1.0)}
          >
            <line
              x1={optimalRight}
              y1={BASE_Y}
              x2={optimalRight}
              y2={BASE_Y + 14}
              stroke="#3a665e"
              strokeWidth="1.5"
            />
            <line
              x1={clinicRight}
              y1={BASE_Y}
              x2={clinicRight}
              y2={BASE_Y + 14}
              stroke="#8a7f76"
              strokeWidth="1"
            />
          </motion.g>

          {/* Bell curve fill */}
          <motion.path
            d={bellFillPath}
            fill="url(#hscrp-bell-fill)"
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={entrance(0.35)}
          />
          {/* Bell curve stroke */}
          <motion.path
            d={bellPath}
            fill="none"
            stroke="#1d1b18"
            strokeWidth="1.4"
            strokeLinecap="round"
            initial={reduce ? { pathLength: 1 } : { pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={
              reduce
                ? { duration: 0 }
                : { duration: 1.6, delay: 0.1, ease: [0.22, 1, 0.36, 1] }
            }
          />

          {/* Band labels below the axis numbers */}
          <motion.g
            initial={reduce ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={entrance(1.15)}
          >
            <text
              x={(clinicX + optimalRight) / 2}
              y={BASE_Y + 44}
              textAnchor="middle"
              fontSize="10"
              fontFamily="var(--font-dm-mono), monospace"
              fontWeight="700"
              fill="#3a665e"
              letterSpacing="2.2"
              style={{ textTransform: "uppercase" }}
            >
              {optimalLabel}
            </text>
            <text
              x={(optimalRight + clinicRight) / 2}
              y={BASE_Y + 44}
              textAnchor="middle"
              fontSize="10"
              fontFamily="var(--font-dm-mono), monospace"
              fontWeight="600"
              fill="#8a7f76"
              letterSpacing="2.2"
              style={{ textTransform: "uppercase" }}
            >
              {clinicLabel}
            </text>
          </motion.g>

          {/* User value marker (draggable) */}
          <motion.g
            animate={reduce ? undefined : isDragging ? undefined : { scale: [1, 1, 1] }}
            transition={{ duration: 1, repeat: Infinity, repeatDelay: 2 }}
          >
            {/* Drop line */}
            <line
              x1={userX}
              y1={userY + 7}
              x2={userX}
              y2={BASE_Y}
              stroke={statusMeta.color}
              strokeWidth="1"
              strokeDasharray="3,4"
              opacity="0.7"
            />
            {/* Halo circle (signals draggability) */}
            <motion.circle
              cx={userX}
              cy={userY}
              r={isDragging ? 18 : 14}
              fill="none"
              stroke={statusMeta.color}
              strokeWidth="1"
              opacity="0.35"
              animate={
                reduce || isDragging
                  ? undefined
                  : { r: [13, 18, 13], opacity: [0.4, 0.15, 0.4] }
              }
              transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
            />
            {/* The dot */}
            <circle
              cx={userX}
              cy={userY}
              r="6"
              fill={statusMeta.color}
            />
            {/* Value chip above */}
            <rect
              x={userX - 32}
              y={userY - 38}
              width="64"
              height="22"
              rx="11"
              fill="#fef8f2"
              stroke={statusMeta.color}
              strokeWidth="1"
            />
            <text
              x={userX}
              y={userY - 22}
              textAnchor="middle"
              fontSize="11"
              fontFamily="var(--font-dm-mono), monospace"
              fontWeight="700"
              fill={statusMeta.color}
              style={{ fontFeatureSettings: "'tnum'" }}
            >
              {value.toFixed(1)}
            </text>
          </motion.g>
        </svg>

        {/* Drag hint — mono caps, muted */}
        <p className="mt-3 text-center font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.2px] text-[#8a7f76]">
          {dragHint}
        </p>
      </div>

      {/* ─── Status panel ─── */}
      <div className="mx-auto mt-10 max-w-[640px] md:mt-12">
        <div className="border-t border-[#1d1b18]/15 pt-6 md:pt-7">
          <div className="flex items-end justify-between gap-6">
            {/* Value block */}
            <div>
              <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
                {valueLabel} · {biomarkerName}
              </p>
              <p className="mt-2 flex items-baseline gap-2">
                <motion.span
                  key={value.toFixed(1)}
                  className="font-[family-name:var(--font-dm-mono)] font-bold leading-none [font-feature-settings:'tnum']"
                  style={{ fontSize: "clamp(36px, 5vw, 56px)", color: statusMeta.color }}
                  initial={reduce ? false : { opacity: 0.6, y: 2 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  {value.toFixed(1)}
                </motion.span>
                <span className="font-[family-name:var(--font-dm-mono)] text-[13px] font-semibold text-[#8a7f76]">
                  {unit}
                </span>
              </p>
            </div>

            {/* Status pill */}
            <div className="text-right">
              <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
                {statusLabel}
              </p>
              <AnimatePresence mode="wait">
                <motion.span
                  key={status}
                  className="mt-2 inline-flex items-center rounded-full px-3 py-1 font-[family-name:var(--font-dm-mono)] text-[10px] font-bold uppercase tracking-[2px]"
                  style={{ backgroundColor: statusMeta.bg, color: statusMeta.color }}
                  initial={reduce ? false : { opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={reduce ? undefined : { opacity: 0, y: 4, transition: { duration: 0.18 } }}
                  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                >
                  {statusMeta.label}
                </motion.span>
              </AnimatePresence>
            </div>
          </div>

          {/* Interpretation */}
          <div className="mt-6 min-h-[60px] md:min-h-[48px]">
            <AnimatePresence mode="wait">
              <motion.p
                key={status}
                className="font-[family-name:var(--font-sentient)] italic leading-[1.55] text-[#2a2319]"
                style={{ fontSize: "clamp(14.5px, 1.5vw, 16.5px)" }}
                initial={reduce ? false : { opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduce ? undefined : { opacity: 0, y: -4, transition: { duration: 0.2 } }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              >
                {statusMeta.interp}
              </motion.p>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
