"use client";

import Link from "next/link";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

export interface PendingLab {
  id: string;
  collection_date: string | null;
  created_at: string;
}

/**
 * Results that arrived from the lab but are still waiting for the patient's
 * per-draw context. /labs and the dashboard only list "ready" results, so
 * without this a result that came through the bridge was invisible in the
 * app until the email link was opened or the 72-hour cron resolved it.
 */
export function PendingResultsNotice({ locale, pending }: { locale: string; pending: PendingLab[] }) {
  if (!pending.length) return null;
  const es = locale === "es";
  const fmt = (d: string | null, fallback: string) =>
    new Date(d ?? fallback).toLocaleDateString(es ? "es-ES" : "en-GB", { day: "numeric", month: "long" });
  return (
    <div className="mt-8 space-y-3">
      {pending.map((lab) => (
        <Link
          key={lab.id}
          href={`/${locale}/labs/${lab.id}/context`}
          className="flex flex-wrap items-center justify-between gap-4 rounded-[16px] border border-[#97472c]/30 bg-[#97472c]/[0.06] px-5 py-4 transition-colors hover:bg-[#97472c]/[0.10]"
        >
          <div className="min-w-0">
            <p className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}>
              {es ? "Resultados nuevos" : "New results"}
            </p>
            <p className={`mt-1 ${FONT_CLASS.manrope} text-[14px] leading-[1.5] text-[#1d1b18]`}>
              {es
                ? `Tus resultados del ${fmt(lab.collection_date, lab.created_at)} han llegado. Confirma el contexto de la extracción para ver tu interpretación.`
                : `Your results from ${fmt(lab.collection_date, lab.created_at)} are in. Confirm the context of the draw to see your interpretation.`}
            </p>
          </div>
          <span className={`${FONT_CLASS.manrope} shrink-0 text-[13px] font-bold text-[#97472c]`}>
            {es ? "Completar contexto →" : "Complete context →"}
          </span>
        </Link>
      ))}
    </div>
  );
}
