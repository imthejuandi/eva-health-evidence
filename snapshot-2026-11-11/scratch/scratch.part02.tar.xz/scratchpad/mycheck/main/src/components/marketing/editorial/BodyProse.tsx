import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

/**
 * BodyProse — standard body paragraph for the marketing
 * surface. Manrope sans, comfortable reading size and leading,
 * tone-aware colour.
 *
 * Three `tone` variants map to the three backgrounds the
 * marketing pages use:
 *
 *   "body"    — #2a2319 on cream, default, "this is the main
 *               thing you're reading"
 *   "muted"   — #4c463f on cream, for supporting text next to
 *               a louder headline or stat
 *   "inverse" — #fef8f2/65 on dark (Reckoning §03, FinalCall §07)
 *
 * `size` prop: "default" (17/19px) or "compact" (16/17px).
 * Default handles the 99% case; "compact" is for places that
 * already have a louder typographic moment above them.
 *
 * Renders a plain `<p>`. Wrap in motion.p on the call site if
 * you want fade-in.
 */
type BodyTone = "body" | "muted" | "inverse";
type BodySize = "default" | "compact";

const toneClass: Record<BodyTone, string> = {
  body: "text-[#2a2319]",
  muted: "text-[#4c463f]",
  inverse: "text-[#fef8f2]/65",
};

const sizeClass: Record<BodySize, string> = {
  default:
    "text-[17px] leading-[1.7] md:text-[19px] md:leading-[1.75]",
  compact:
    "text-[16px] leading-[1.7] md:text-[17px] md:leading-[1.75]",
};

interface BodyProseProps {
  children: React.ReactNode;
  tone?: BodyTone;
  size?: BodySize;
  /** `max-w-[Nch]` clamp. Default 52ch (comfortable magazine measure). */
  maxCh?: number;
  /** Use font-weight: 500 (medium) instead of the Manrope default. */
  medium?: boolean;
  className?: string;
}

export function BodyProse({
  children,
  tone = "body",
  size = "default",
  maxCh = 52,
  medium = false,
  className,
}: BodyProseProps) {
  return (
    <p
      className={cn(
        "font-[family-name:var(--font-manrope)]",
        sizeClass[size],
        toneClass[tone],
        medium && "font-medium",
        className,
      )}
      style={
        {
          maxWidth: `${maxCh}ch`,
          textWrap: "pretty",
        } as CSSProperties
      }
    >
      {children}
    </p>
  );
}
