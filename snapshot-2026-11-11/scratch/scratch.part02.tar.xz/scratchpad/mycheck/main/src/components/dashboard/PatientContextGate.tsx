"use client";

/**
 * Context gate UI.
 *
 * Renders the patient-context check that every new lab passes through
 * before AI interpretation runs. Two visual states:
 *
 *   "summary"  — read-only chip cards of the user's last-saved durable
 *                context plus the per-draw transient strip. Two CTAs:
 *                "Still accurate" (snapshot existing version + transient
 *                onto the lab) and "Update" (expand into edit mode).
 *
 *   "editing"  — per-section accordions with chip selectors and a few
 *                small numeric inputs. Saving creates a new version
 *                (POST /api/patient-context) and then snapshots that
 *                new version onto the lab.
 *
 * This component is shared between the upload flow (rendered inline as
 * chapter "§ Context") and the standalone /labs/[id]/context route
 * webhook-arrived labs deep-link into.
 *
 * Spanish strings are the primary line of authoring; chip widths are
 * sized so the Spanish copy never truncates.
 */

import { useEffect, useMemo, useState } from "react";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import {
  CARDIO_INTENSITIES,
  CONDITION_KEYS,
  CONTRACEPTION_OPTIONS,
  DIET_PATTERNS,
  DRAW_TIME_OPTIONS,
  FASTED_OPTIONS,
  HRT_OPTIONS,
  LAST_WORKOUT_OPTIONS,
  MEDICATION_KEYS,
  MENOPAUSE_STATUSES,
  MENSTRUAL_REGULARITIES,
  SMOKING_STATUSES,
  SUPPLEMENT_KEYS,
  THREE_POINT_OPTIONS,
  TRT_OPTIONS,
  emptySnapshot,
  labelFor,
  type DurableContextSnapshot,
  type MedicationItem,
  type SupplementItem,
  type TransientContext,
} from "@/lib/patient-context/options";

type Lang = "en" | "es";
type Sex = "male" | "female" | null;

interface VersionPayload {
  id: string;
  version_number: number;
  is_empty: boolean;
  created_at: string;
  snapshot: DurableContextSnapshot;
}

export interface PatientContextGateProps {
  profileLocale: Lang;
  userSex: Sex;
  /** Called with a context version id + transient block once the user
   *  confirms the gate. The parent decides what to do with them (e.g.
   *  POST /api/lab-results/[id]/context, or just close a modal). */
  onConfirm: (versionId: string, transient: TransientContext) => Promise<void>;
  submitting?: boolean;
  /** Pre-loaded current version, if the parent already fetched it. */
  initialVersion?: VersionPayload | null;
}

const T = (lang: Lang) =>
  lang === "es"
    ? {
        kicker: "§ Contexto",
        title: "Confirma tu",
        accent: "contexto.",
        lede:
          "Tu interpretacion cambia si tomas creatina, si entrenaste fuerte la vispera, o si llevas un tratamiento cronico. Confirma lo que sigue siendo cierto antes de leer tus marcadores.",
        durableHeading: "Tu contexto duradero",
        durableSavedAgo: (days: number) =>
          days === 0 ? "Guardado hoy" : `Guardado hace ${days} dia${days === 1 ? "" : "s"}`,
        durableNeverSaved: "Aun no nos has contado tu contexto",
        staleWarning:
          "Hace mas de tres meses que no actualizas esto. Vale la pena revisarlo: medicacion, suplementos y rutina cambian con frecuencia.",
        ctaStill: "Sigue siendo correcto",
        ctaUpdate: "Actualizar",
        ctaCancel: "Cancelar",
        ctaSave: "Guardar contexto",
        savingLabel: "Guardando...",
        emptyChip: "Sin registros",
        addItem: "Añadir",
        remove: "Quitar",
        dose: "Dosis",
        editNotice:
          "Estas actualizando tu perfil para todos los analisis futuros. Los analisis pasados conservan el contexto que tenian cuando se interpretaron.",
        // Transient strip
        transientHeading: "Sobre este analisis en concreto",
        transientLede:
          "Detalles del dia de la extraccion. Saltalos si no estas seguro.",
        skipAll: "Saltar todo",
        fastedLabel: "Ayuno antes de la extraccion",
        workoutLabel: "Ultimo entrenamiento",
        illLabel: "¿Te sentiste enferma/o esa semana?",
        illYes: "Si",
        illNo: "No",
        cycleLabel: "Dia del ciclo",
        cyclePlaceholder: "Ej. 14",
        drawTimeLabel: "Hora de la extraccion",
        sleepLabel: "Sueño la noche anterior",
        hydrationLabel: "Hidratacion ese dia",
        // Section labels
        sectionMeds: "Medicamentos",
        sectionSupps: "Suplementos",
        sectionConds: "Condiciones",
        sectionLife: "Estilo de vida",
        sectionSex: "Salud hormonal",
        // Lifestyle field labels
        smokingLabel: "Tabaco",
        alcoholLabel: "Bebidas alcoholicas / semana",
        cardioFreqLabel: "Sesiones de cardio / semana",
        cardioIntensityLabel: "Intensidad dominante",
        resistanceLabel: "Sesiones de fuerza / semana",
        dietLabel: "Patron alimentario",
        // Sex-specific labels
        menstrualLabel: "Ciclo menstrual",
        contraceptionLabel: "Anticonceptivo",
        menopauseLabel: "Estado menopausico",
        hrtLabel: "Terapia hormonal (THS)",
        trtLabel: "Terapia con testosterona",
        errorPrefix: "No pudimos guardar:",
      }
    : {
        kicker: "§ Context",
        title: "Confirm your",
        accent: "context.",
        lede:
          "Your interpretation changes if you take creatine, if you trained hard yesterday, or if you're on chronic therapy. Confirm what's still true before we read your markers.",
        durableHeading: "Your durable context",
        durableSavedAgo: (days: number) =>
          days === 0 ? "Saved today" : `Saved ${days} day${days === 1 ? "" : "s"} ago`,
        durableNeverSaved: "We haven't asked you these yet",
        staleWarning:
          "You haven't updated this in over three months. Worth a look — medications, supplements, and routines drift over time.",
        ctaStill: "Still accurate",
        ctaUpdate: "Update",
        ctaCancel: "Cancel",
        ctaSave: "Save context",
        savingLabel: "Saving...",
        emptyChip: "None on file",
        addItem: "Add",
        remove: "Remove",
        dose: "Dose",
        editNotice:
          "You're updating your profile for every future lab. Past labs keep the context they were interpreted under.",
        transientHeading: "About this specific draw",
        transientLede:
          "Day-of-draw details. Skip anything you're not sure about.",
        skipAll: "Skip all",
        fastedLabel: "Fasted before the draw",
        workoutLabel: "Last workout",
        illLabel: "Were you ill that week?",
        illYes: "Yes",
        illNo: "No",
        cycleLabel: "Cycle day",
        cyclePlaceholder: "e.g. 14",
        drawTimeLabel: "Draw time",
        sleepLabel: "Sleep the night before",
        hydrationLabel: "Hydration that day",
        sectionMeds: "Medications",
        sectionSupps: "Supplements",
        sectionConds: "Conditions",
        sectionLife: "Lifestyle",
        sectionSex: "Hormonal health",
        smokingLabel: "Smoking",
        alcoholLabel: "Alcoholic drinks / week",
        cardioFreqLabel: "Cardio sessions / week",
        cardioIntensityLabel: "Dominant intensity",
        resistanceLabel: "Resistance sessions / week",
        dietLabel: "Diet pattern",
        menstrualLabel: "Menstrual cycle",
        contraceptionLabel: "Contraception",
        menopauseLabel: "Menopausal status",
        hrtLabel: "Hormone therapy (HRT)",
        trtLabel: "Testosterone therapy",
        errorPrefix: "Couldn't save:",
      };

function daysAgo(iso: string): number {
  const ms = Date.now() - new Date(iso).getTime();
  return Math.max(0, Math.floor(ms / 86_400_000));
}

export function PatientContextGate({
  profileLocale,
  userSex,
  onConfirm,
  submitting = false,
  initialVersion = null,
}: PatientContextGateProps) {
  const t = useMemo(() => T(profileLocale), [profileLocale]);
  const [version, setVersion] = useState<VersionPayload | null>(initialVersion);
  const [loading, setLoading] = useState(initialVersion === null);
  const [mode, setMode] = useState<"summary" | "editing">("summary");
  const [snapshot, setSnapshot] = useState<DurableContextSnapshot>(
    initialVersion?.snapshot ?? emptySnapshot(),
  );
  const [transient, setTransient] = useState<TransientContext>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load the current version on mount when the parent didn't provide one.
  useEffect(() => {
    if (initialVersion !== null) return;
    let cancelled = false;
    fetch("/api/patient-context", { credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((data) => {
        if (cancelled) return;
        if (data.version) {
          setVersion(data.version);
          setSnapshot(data.version.snapshot ?? emptySnapshot());
        }
      })
      .catch((err) => console.error("[ContextGate] load failed:", err))
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [initialVersion]);

  async function handleStillAccurate() {
    if (!version) {
      // Edge case: user has no version yet but tries to confirm without
      // editing. Create an empty version on their behalf.
      try {
        setSaving(true);
        const r = await fetch("/api/patient-context", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "same-origin",
          body: JSON.stringify({ snapshot: emptySnapshot() }),
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();
        await onConfirm(data.version.id, transient);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Save failed");
      } finally {
        setSaving(false);
      }
      return;
    }
    try {
      setSaving(true);
      await onConfirm(version.id, transient);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function handleSave() {
    try {
      setSaving(true);
      setError(null);
      const r = await fetch("/api/patient-context", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ snapshot }),
      });
      if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        throw new Error(e.error || `HTTP ${r.status}`);
      }
      const data = await r.json();
      await onConfirm(data.version.id, transient);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const updateLifestyle = (patch: Partial<DurableContextSnapshot["lifestyle"]>) =>
    setSnapshot((s) => ({ ...s, lifestyle: { ...s.lifestyle, ...patch } }));
  const updateSexSpecific = (patch: Partial<DurableContextSnapshot["sex_specific"]>) =>
    setSnapshot((s) => ({ ...s, sex_specific: { ...s.sex_specific, ...patch } }));
  const toggleCondition = (key: string) =>
    setSnapshot((s) => {
      const set = new Set(s.conditions.keys);
      if (set.has(key as never)) set.delete(key as never);
      else set.add(key as never);
      return { ...s, conditions: { keys: Array.from(set) as never } };
    });

  function addItem(kind: "medications" | "supplements", key: string) {
    setSnapshot((s) => {
      const list = s[kind];
      if (list.some((it) => it.key === key)) return s;
      const next = [...list, { key, dose: null } as MedicationItem | SupplementItem];
      return { ...s, [kind]: next };
    });
  }
  function removeItem(kind: "medications" | "supplements", key: string) {
    setSnapshot((s) => ({
      ...s,
      [kind]: s[kind].filter((it) => it.key !== key),
    }));
  }
  function setItemDose(
    kind: "medications" | "supplements",
    key: string,
    dose: string,
  ) {
    setSnapshot((s) => ({
      ...s,
      [kind]: s[kind].map((it) =>
        it.key === key ? { ...it, dose: dose || null } : it,
      ),
    }));
  }

  return (
    <section className={`${FONT_CLASS.manrope} text-[#1d1b18]`}>
      <header className="mb-6">
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
        >
          {t.kicker}
        </p>
        <h2
          className={`mt-3 ${FONT_CLASS.cormorant} text-[40px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[56px] md:tracking-[-2px]`}
        >
          {t.title} <span className="italic">{t.accent}</span>
        </h2>
        <p className="mt-3 max-w-[60ch] text-[14px] leading-[1.55] text-[#5b554f]">
          {t.lede}
        </p>
      </header>

      {/* Stale-context nudge. Memory drift on meds/supps/routine is
          one of the most common ways "still accurate" silently lies
          in consumer-health flows — a quiet amber prompt at >90 days
          materially reduces that risk without forcing the user to
          edit. */}
      {version && !loading && daysAgo(version.created_at) >= 90 && (
        <div
          className={`mb-3 rounded-md border border-[#c49332]/35 bg-[rgba(196,147,50,0.08)] px-3 py-2 ${FONT_CLASS.manrope} text-[12px] leading-[1.45] text-[#7a5a1a]`}
        >
          {t.staleWarning}
        </div>
      )}

      <div className="rounded-[16px] border border-[#1d1b18]/15 bg-[#fbf6ee] p-5 md:p-7">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <div>
            <p
              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
            >
              {t.durableHeading}
            </p>
            <p className="mt-1 text-[12px] italic text-[#8a7f76]">
              {loading
                ? "…"
                : version
                  ? t.durableSavedAgo(daysAgo(version.created_at))
                  : t.durableNeverSaved}
            </p>
          </div>
          {mode === "summary" ? (
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setMode("editing")}
                className={`${FONT_CLASS.dmMono} rounded-full border border-[#1d1b18]/20 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[1.4px] text-[#1d1b18] transition-colors hover:border-[#97472c] hover:text-[#97472c]`}
              >
                {t.ctaUpdate}
              </button>
              <button
                type="button"
                onClick={handleStillAccurate}
                disabled={saving || submitting}
                className={`${FONT_CLASS.dmMono} rounded-full bg-[#3a665e] px-4 py-1.5 text-[10px] font-semibold uppercase tracking-[1.4px] text-[#f7f1e8] transition-colors hover:bg-[#2e524b] disabled:opacity-50`}
              >
                {saving || submitting ? t.savingLabel : t.ctaStill}
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                setMode("summary");
                if (version) setSnapshot(version.snapshot);
              }}
              className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.4px] text-[#8a7f76] hover:text-[#1d1b18]`}
            >
              {t.ctaCancel}
            </button>
          )}
        </div>

        {mode === "editing" && (
          <p className="mt-3 rounded-md bg-[rgba(151,71,44,0.06)] px-3 py-2 text-[12px] italic text-[#97472c]">
            {t.editNotice}
          </p>
        )}

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {/* Medications */}
          <SectionCard
            title={t.sectionMeds}
            mode={mode}
            chips={snapshot.medications.map((m) => ({
              key: m.key,
              label: `${labelFor(m.key, profileLocale)}${m.dose ? ` · ${m.dose}` : ""}`,
            }))}
            emptyLabel={t.emptyChip}
          >
            <ItemPicker
              kind="medications"
              keys={MEDICATION_KEYS as readonly string[]}
              selected={snapshot.medications}
              onAdd={(k) => addItem("medications", k)}
              onRemove={(k) => removeItem("medications", k)}
              onDose={(k, d) => setItemDose("medications", k, d)}
              labels={{ add: t.addItem, remove: t.remove, dose: t.dose }}
              lang={profileLocale}
            />
          </SectionCard>

          {/* Supplements */}
          <SectionCard
            title={t.sectionSupps}
            mode={mode}
            chips={snapshot.supplements.map((s) => ({
              key: s.key,
              label: `${labelFor(s.key, profileLocale)}${s.dose ? ` · ${s.dose}` : ""}`,
            }))}
            emptyLabel={t.emptyChip}
          >
            <ItemPicker
              kind="supplements"
              keys={SUPPLEMENT_KEYS as readonly string[]}
              selected={snapshot.supplements}
              onAdd={(k) => addItem("supplements", k)}
              onRemove={(k) => removeItem("supplements", k)}
              onDose={(k, d) => setItemDose("supplements", k, d)}
              labels={{ add: t.addItem, remove: t.remove, dose: t.dose }}
              lang={profileLocale}
            />
          </SectionCard>

          {/* Conditions */}
          <SectionCard
            title={t.sectionConds}
            mode={mode}
            chips={snapshot.conditions.keys.map((k) => ({
              key: k,
              label: labelFor(k, profileLocale),
            }))}
            emptyLabel={t.emptyChip}
          >
            <ToggleChipRow
              keys={CONDITION_KEYS as readonly string[]}
              selected={snapshot.conditions.keys as readonly string[]}
              onToggle={toggleCondition}
              lang={profileLocale}
            />
          </SectionCard>

          {/* Lifestyle */}
          <SectionCard
            title={t.sectionLife}
            mode={mode}
            chips={summarizeLifestyle(snapshot.lifestyle, profileLocale, t)}
            emptyLabel={t.emptyChip}
          >
            <div className="grid gap-3">
              <RadioRow
                label={t.smokingLabel}
                keys={SMOKING_STATUSES as readonly string[]}
                value={snapshot.lifestyle.smoking_status}
                onChange={(v) => updateLifestyle({ smoking_status: v as never })}
                lang={profileLocale}
              />
              <NumberRow
                label={t.alcoholLabel}
                value={snapshot.lifestyle.alcohol_drinks_per_week}
                onChange={(v) => updateLifestyle({ alcohol_drinks_per_week: v })}
                min={0}
                max={50}
              />
              <NumberRow
                label={t.cardioFreqLabel}
                value={snapshot.lifestyle.cardio_sessions_per_week}
                onChange={(v) => updateLifestyle({ cardio_sessions_per_week: v })}
                min={0}
                max={14}
              />
              <RadioRow
                label={t.cardioIntensityLabel}
                keys={CARDIO_INTENSITIES as readonly string[]}
                value={snapshot.lifestyle.cardio_dominant_intensity}
                onChange={(v) =>
                  updateLifestyle({ cardio_dominant_intensity: v as never })
                }
                lang={profileLocale}
              />
              <NumberRow
                label={t.resistanceLabel}
                value={snapshot.lifestyle.resistance_sessions_per_week}
                onChange={(v) =>
                  updateLifestyle({ resistance_sessions_per_week: v })
                }
                min={0}
                max={14}
              />
              <RadioRow
                label={t.dietLabel}
                keys={DIET_PATTERNS as readonly string[]}
                value={snapshot.lifestyle.diet_pattern}
                onChange={(v) => updateLifestyle({ diet_pattern: v as never })}
                lang={profileLocale}
              />
            </div>
          </SectionCard>

          {/* Sex-specific (female + male variants) */}
          {userSex && (
            <SectionCard
              title={t.sectionSex}
              mode={mode}
              chips={summarizeSexSpecific(snapshot.sex_specific, profileLocale)}
              emptyLabel={t.emptyChip}
              className="md:col-span-2"
            >
              {userSex === "female" ? (
                <div className="grid gap-3">
                  <RadioRow
                    label={t.menstrualLabel}
                    keys={MENSTRUAL_REGULARITIES as readonly string[]}
                    value={snapshot.sex_specific.menstrual_regularity}
                    onChange={(v) =>
                      updateSexSpecific({ menstrual_regularity: v as never })
                    }
                    lang={profileLocale}
                  />
                  <RadioRow
                    label={t.contraceptionLabel}
                    keys={CONTRACEPTION_OPTIONS as readonly string[]}
                    value={snapshot.sex_specific.contraception}
                    onChange={(v) =>
                      updateSexSpecific({ contraception: v as never })
                    }
                    lang={profileLocale}
                  />
                  <RadioRow
                    label={t.menopauseLabel}
                    keys={MENOPAUSE_STATUSES as readonly string[]}
                    value={snapshot.sex_specific.menopause_status}
                    onChange={(v) =>
                      updateSexSpecific({ menopause_status: v as never })
                    }
                    lang={profileLocale}
                  />
                  <RadioRow
                    label={t.hrtLabel}
                    keys={HRT_OPTIONS as readonly string[]}
                    value={snapshot.sex_specific.hrt}
                    onChange={(v) => updateSexSpecific({ hrt: v as never })}
                    lang={profileLocale}
                  />
                </div>
              ) : (
                <RadioRow
                  label={t.trtLabel}
                  keys={TRT_OPTIONS as readonly string[]}
                  value={snapshot.sex_specific.trt}
                  onChange={(v) => updateSexSpecific({ trt: v as never })}
                  lang={profileLocale}
                />
              )}
            </SectionCard>
          )}
        </div>

        {mode === "editing" && (
          <div className="mt-6 flex flex-wrap items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => {
                setMode("summary");
                if (version) setSnapshot(version.snapshot);
              }}
              className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.4px] text-[#8a7f76] hover:text-[#1d1b18]`}
            >
              {t.ctaCancel}
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={saving || submitting}
              className={`${FONT_CLASS.dmMono} rounded-full bg-[#3a665e] px-5 py-2 text-[10px] font-semibold uppercase tracking-[1.4px] text-[#f7f1e8] transition-colors hover:bg-[#2e524b] disabled:opacity-50`}
            >
              {saving || submitting ? t.savingLabel : t.ctaSave}
            </button>
          </div>
        )}
      </div>

      {/* Transient context strip — always visible. */}
      <div className="mt-8 rounded-[16px] border border-[#1d1b18]/15 bg-[#fbf6ee] p-5 md:p-7">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <div>
            <p
              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
            >
              {t.transientHeading}
            </p>
            <p className="mt-1 max-w-[55ch] text-[12px] italic text-[#8a7f76]">
              {t.transientLede}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setTransient({ skipped: true })}
            className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.4px] text-[#8a7f76] hover:text-[#1d1b18]`}
          >
            {t.skipAll}
          </button>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <RadioRow
            label={t.fastedLabel}
            keys={FASTED_OPTIONS as readonly string[]}
            value={transient.fasted}
            onChange={(v) => setTransient((tr) => ({ ...tr, fasted: v as never, skipped: false }))}
            lang={profileLocale}
          />
          <RadioRow
            label={t.workoutLabel}
            keys={LAST_WORKOUT_OPTIONS as readonly string[]}
            value={transient.last_workout}
            onChange={(v) =>
              setTransient((tr) => ({ ...tr, last_workout: v as never, skipped: false }))
            }
            lang={profileLocale}
          />
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[12px] uppercase tracking-[1.2px] text-[#8a7f76]">
              {t.illLabel}
            </span>
            <button
              type="button"
              onClick={() =>
                setTransient((tr) => ({ ...tr, currently_ill: true, skipped: false }))
              }
              className={`${FONT_CLASS.dmMono} rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-[1.3px] transition-colors ${
                transient.currently_ill === true
                  ? "bg-[#97472c] text-[#f7f1e8]"
                  : "border border-[#1d1b18]/20 text-[#1d1b18] hover:border-[#97472c]"
              }`}
            >
              {t.illYes}
            </button>
            <button
              type="button"
              onClick={() =>
                setTransient((tr) => ({ ...tr, currently_ill: false, skipped: false }))
              }
              className={`${FONT_CLASS.dmMono} rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-[1.3px] transition-colors ${
                transient.currently_ill === false
                  ? "bg-[#3a665e] text-[#f7f1e8]"
                  : "border border-[#1d1b18]/20 text-[#1d1b18] hover:border-[#3a665e]"
              }`}
            >
              {t.illNo}
            </button>
          </div>
          {userSex === "female" && (
            <div className="flex flex-wrap items-center gap-3">
              <label
                htmlFor="cycle-day"
                className="text-[12px] uppercase tracking-[1.2px] text-[#8a7f76]"
              >
                {t.cycleLabel}
              </label>
              <input
                id="cycle-day"
                type="number"
                min={1}
                max={45}
                placeholder={t.cyclePlaceholder}
                value={transient.cycle_day ?? ""}
                onChange={(e) => {
                  const n = parseInt(e.target.value, 10);
                  setTransient((tr) => ({
                    ...tr,
                    cycle_day: Number.isFinite(n) ? n : null,
                    skipped: false,
                  }));
                }}
                className={`w-24 border-b border-[#1d1b18]/30 bg-transparent py-1 ${FONT_CLASS.dmMono} text-[14px] tabular-nums text-[#1d1b18] outline-none focus:border-[#97472c]`}
              />
            </div>
          )}
          <RadioRow
            label={t.drawTimeLabel}
            keys={DRAW_TIME_OPTIONS as readonly string[]}
            value={transient.draw_time}
            onChange={(v) =>
              setTransient((tr) => ({ ...tr, draw_time: v as never, skipped: false }))
            }
            lang={profileLocale}
          />
          <RadioRow
            label={t.sleepLabel}
            keys={THREE_POINT_OPTIONS as readonly string[]}
            value={transient.sleep_quality}
            onChange={(v) =>
              setTransient((tr) => ({ ...tr, sleep_quality: v as never, skipped: false }))
            }
            lang={profileLocale}
          />
          <RadioRow
            label={t.hydrationLabel}
            keys={THREE_POINT_OPTIONS as readonly string[]}
            value={transient.hydration}
            onChange={(v) =>
              setTransient((tr) => ({ ...tr, hydration: v as never, skipped: false }))
            }
            lang={profileLocale}
          />
        </div>
      </div>

      {error && (
        <p
          role="alert"
          className={`mt-4 rounded-md border border-[#b04040]/30 bg-[#fef8f2] p-3 text-[12px] text-[#b04040]`}
        >
          {t.errorPrefix} {error}
        </p>
      )}
    </section>
  );
}

// ─── Sub-components ──────────────────────────────────────────────────

function SectionCard({
  title,
  mode,
  chips,
  emptyLabel,
  className,
  children,
}: {
  title: string;
  mode: "summary" | "editing";
  chips: Array<{ key: string; label: string }>;
  emptyLabel: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className={`rounded-[12px] border border-[#1d1b18]/10 bg-[#fffbf3] p-4 ${className ?? ""}`}
    >
      <p
        className={`${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.4px] text-[#8a7f76]`}
      >
        {title}
      </p>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {chips.length === 0 ? (
          <span className="text-[12px] italic text-[#8a7f76]">{emptyLabel}</span>
        ) : (
          chips.map((c) => (
            <span
              key={c.key}
              className="rounded-full border border-[#1d1b18]/15 bg-white px-2.5 py-1 text-[11px] text-[#1d1b18]"
            >
              {c.label}
            </span>
          ))
        )}
      </div>
      {mode === "editing" && <div className="mt-4">{children}</div>}
    </div>
  );
}

function ItemPicker({
  keys,
  selected,
  onAdd,
  onRemove,
  onDose,
  labels,
  lang,
}: {
  kind: "medications" | "supplements";
  keys: readonly string[];
  selected: Array<{ key: string; dose?: string | null }>;
  onAdd: (k: string) => void;
  onRemove: (k: string) => void;
  onDose: (k: string, d: string) => void;
  labels: { add: string; remove: string; dose: string };
  lang: Lang;
}) {
  const [query, setQuery] = useState("");
  const lowerQ = query.trim().toLowerCase();
  const selectedSet = new Set(selected.map((s) => s.key));
  const filtered = keys.filter((k) => {
    if (selectedSet.has(k)) return false;
    if (!lowerQ) return true;
    return (
      k.includes(lowerQ) || labelFor(k, lang).toLowerCase().includes(lowerQ)
    );
  });
  return (
    <div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={labels.add}
        className={`w-full border-b border-[#1d1b18]/25 bg-transparent py-1 ${FONT_CLASS.manrope} text-[13px] outline-none focus:border-[#97472c]`}
      />
      <ul className="mt-2 max-h-32 overflow-y-auto">
        {filtered.slice(0, 20).map((k) => (
          <li key={k}>
            <button
              type="button"
              onClick={() => {
                onAdd(k);
                setQuery("");
              }}
              className="w-full rounded px-2 py-1 text-left text-[12px] text-[#1d1b18] hover:bg-[rgba(151,71,44,0.08)]"
            >
              + {labelFor(k, lang)}
            </button>
          </li>
        ))}
      </ul>
      {selected.length > 0 && (
        <ul className="mt-3 flex flex-col gap-1.5">
          {selected.map((it) => (
            <li key={it.key} className="flex flex-wrap items-center gap-2">
              <span className="text-[12px] text-[#1d1b18]">
                {labelFor(it.key, lang)}
              </span>
              <input
                type="text"
                value={it.dose ?? ""}
                onChange={(e) => onDose(it.key, e.target.value)}
                placeholder={labels.dose}
                className={`flex-1 border-b border-[#1d1b18]/20 bg-transparent py-0.5 text-[12px] outline-none focus:border-[#97472c]`}
              />
              <button
                type="button"
                onClick={() => onRemove(it.key)}
                className={`${FONT_CLASS.dmMono} text-[9px] uppercase tracking-[1.2px] text-[#8a7f76] hover:text-[#b04040]`}
              >
                {labels.remove}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function ToggleChipRow({
  keys,
  selected,
  onToggle,
  lang,
}: {
  keys: readonly string[];
  selected: readonly string[];
  onToggle: (k: string) => void;
  lang: Lang;
}) {
  const set = new Set(selected);
  return (
    <div className="flex flex-wrap gap-1.5">
      {keys.map((k) => {
        const active = set.has(k);
        return (
          <button
            key={k}
            type="button"
            onClick={() => onToggle(k)}
            className={`rounded-full px-2.5 py-1 text-[11px] transition-colors ${
              active
                ? "bg-[#97472c] text-[#f7f1e8]"
                : "border border-[#1d1b18]/15 bg-white text-[#1d1b18] hover:border-[#97472c]"
            }`}
          >
            {labelFor(k, lang)}
          </button>
        );
      })}
    </div>
  );
}

function RadioRow({
  label,
  keys,
  value,
  onChange,
  lang,
}: {
  label: string;
  keys: readonly string[];
  value: string | undefined;
  onChange: (v: string) => void;
  lang: Lang;
}) {
  return (
    <div>
      <span className="text-[11px] uppercase tracking-[1.2px] text-[#8a7f76]">
        {label}
      </span>
      <div className="mt-1.5 flex flex-wrap gap-1.5">
        {keys.map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => onChange(k)}
            className={`rounded-full px-2.5 py-1 text-[11px] transition-colors ${
              value === k
                ? "bg-[#3a665e] text-[#f7f1e8]"
                : "border border-[#1d1b18]/15 bg-white text-[#1d1b18] hover:border-[#3a665e]"
            }`}
          >
            {labelFor(k, lang)}
          </button>
        ))}
      </div>
    </div>
  );
}

function NumberRow({
  label,
  value,
  onChange,
  min,
  max,
}: {
  label: string;
  value: number | undefined;
  onChange: (v: number | undefined) => void;
  min: number;
  max: number;
}) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <span className="text-[11px] uppercase tracking-[1.2px] text-[#8a7f76]">
        {label}
      </span>
      <input
        type="number"
        min={min}
        max={max}
        value={value ?? ""}
        onChange={(e) => {
          const v = e.target.value;
          if (v === "") return onChange(undefined);
          const n = parseInt(v, 10);
          if (Number.isFinite(n)) onChange(n);
        }}
        className={`w-20 border-b border-[#1d1b18]/30 bg-transparent py-1 ${FONT_CLASS.dmMono} text-[13px] tabular-nums text-[#1d1b18] outline-none focus:border-[#97472c]`}
      />
    </div>
  );
}

// ─── Summary helpers ─────────────────────────────────────────────────

function summarizeLifestyle(
  l: DurableContextSnapshot["lifestyle"],
  lang: Lang,
  t: ReturnType<typeof T>,
): Array<{ key: string; label: string }> {
  const out: Array<{ key: string; label: string }> = [];
  if (l.smoking_status) {
    out.push({
      key: `smoke:${l.smoking_status}`,
      label: `${t.smokingLabel}: ${labelFor(l.smoking_status, lang)}`,
    });
  }
  if (typeof l.alcohol_drinks_per_week === "number") {
    out.push({
      key: "alc",
      label: `${t.alcoholLabel}: ${l.alcohol_drinks_per_week}`,
    });
  }
  if (typeof l.cardio_sessions_per_week === "number") {
    out.push({
      key: "cardio",
      label: `${t.cardioFreqLabel}: ${l.cardio_sessions_per_week}`,
    });
  }
  if (l.cardio_dominant_intensity) {
    out.push({
      key: "cardioInt",
      label: labelFor(l.cardio_dominant_intensity, lang),
    });
  }
  if (typeof l.resistance_sessions_per_week === "number") {
    out.push({
      key: "resist",
      label: `${t.resistanceLabel}: ${l.resistance_sessions_per_week}`,
    });
  }
  if (l.diet_pattern) {
    out.push({ key: "diet", label: labelFor(l.diet_pattern, lang) });
  }
  return out;
}

function summarizeSexSpecific(
  s: DurableContextSnapshot["sex_specific"],
  lang: Lang,
): Array<{ key: string; label: string }> {
  const out: Array<{ key: string; label: string }> = [];
  for (const [k, v] of Object.entries(s)) {
    if (!v) continue;
    out.push({ key: k, label: labelFor(String(v), lang) });
  }
  return out;
}
