"use client";

import { motion, useReducedMotion } from "framer-motion";
import { PromisePills } from "./PromisePills";

interface Promise {
  icon?: "cancel" | "lock" | "sparkles";
  title: string;
  body: string;
}

interface CancelAnytimeBannerProps {
  eyebrow: string;
  headline: string;
  promises: Promise[];
  ctaLabel: string;
  onCta: () => void;
  loading?: boolean;
}

const EASE_QUART: [number, number, number, number] = [0.25, 1, 0.5, 1];

export function CancelAnytimeBanner({
  eyebrow,
  headline,
  promises,
  ctaLabel,
  onCta,
  loading = false,
}: CancelAnytimeBannerProps) {
  const reduce = useReducedMotion();

  return (
    <section className="relative bg-[var(--color-eva-ink)] px-[var(--space-xl)] py-[clamp(4rem,9vw,7rem)] text-white md:px-[var(--space-3xl)]">
      {/* A single faint warm glow, not the usual blurry orbs */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-[2px]"
        style={{
          background:
            "linear-gradient(90deg, transparent 0%, rgba(151,71,44,0.55) 48%, rgba(143,212,184,0.25) 72%, transparent 100%)",
        }}
      />

      <div className="relative mx-auto max-w-[1240px]">
        <header className="grid grid-cols-1 gap-[var(--space-2xl)] pt-[var(--space-lg)] md:grid-cols-[minmax(0,1fr)_minmax(0,1.6fr)]">
          <span className="font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.22em] text-[var(--color-eva-mint)]">
            {eyebrow}
          </span>
          <motion.h2
            initial={reduce ? false : { opacity: 0, y: 14 }}
            whileInView={reduce ? undefined : { opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.8, ease: EASE_QUART }}
            className="max-w-[20ch] font-[family-name:var(--font-sentient)] text-[clamp(2.25rem,4.5vw,3.75rem)] font-medium leading-[1.05] tracking-[-0.03em] text-white"
          >
            {headline}
          </motion.h2>
        </header>

        <div className="mt-[clamp(3rem,5vw,4rem)]">
          <PromisePills items={promises} />
        </div>

        <div className="mt-[clamp(3rem,5vw,4rem)] flex items-center gap-[var(--space-xl)] border-t border-white/15 pt-[var(--space-xl)]">
          <button
            type="button"
            onClick={onCta}
            disabled={loading}
            className="group/cta inline-flex items-center gap-[var(--space-md)] bg-white px-[var(--space-xl)] py-[var(--space-md)] font-[family-name:var(--font-manrope)] text-[14.5px] font-semibold tracking-[0.01em] text-[var(--color-eva-on-surface)] transition-[background-color] duration-[260ms] hover:bg-[var(--color-eva-mint)] disabled:opacity-60"
            style={{ transitionTimingFunction: EASE_QUART.toString() }}
          >
            <span>{loading ? "· · · · ·" : ctaLabel}</span>
            <svg
              width="14"
              height="14"
              viewBox="0 0 14 14"
              fill="none"
              aria-hidden
              className="transition-transform duration-[260ms] group-hover/cta:translate-x-0.5"
            >
              <path
                d="M3 11L11 3M11 3H5.5M11 3V8.5"
                stroke="currentColor"
                strokeWidth="1.3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
}
