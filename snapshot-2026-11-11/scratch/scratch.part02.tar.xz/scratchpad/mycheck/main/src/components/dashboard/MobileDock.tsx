"use client";

import Link from "next/link";

/**
 * Floating pill-shaped mobile dock — replaces the old full-width
 * bottom tab bar. Lifted from the investors deck's mobile dock
 * pattern (./public/investors/mobile.css L105-147): centred at the
 * bottom of the viewport, rounded into a pill, soft warm shadow.
 *
 * Notes:
 *   - No backdrop-filter blur. We deliberately use a near-opaque
 *     warm background instead. Even 12px backdrop blur on a fixed
 *     element re-runs every scroll frame; the dashboard's heavy
 *     content can't afford it (this was a confirmed cause of the
 *     "stuck mobile scroll" we just fixed).
 *   - Each item is a 44×44 touch target with a round terra fill
 *     behind the icon when active. Labels read below the icon at
 *     8px DM Mono; on phones smaller than 640px (sm) the labels
 *     hide and only the icons remain so the dock stays comfortably
 *     inside the viewport on tight screens.
 *   - The caller decides which item is active. The dock doesn't
 *     parse the path itself because each section has different
 *     subpath semantics (e.g. /labs/manage should keep labs lit).
 *
 * The desktop sidebar lives separately in the dashboard layout —
 * this component is only mounted at < lg.
 */

type DockItem = {
  key: string;
  href: string;
  label: string;
  iconD: string;
  active: boolean;
};

export function MobileDock({
  items,
  className = "",
}: {
  items: DockItem[];
  className?: string;
}) {
  return (
    <nav
      aria-label="Primary"
      className={`fixed inset-x-0 bottom-0 z-40 flex justify-center px-4 pb-[max(env(safe-area-inset-bottom),18px)] lg:hidden ${className}`}
    >
      <div
        className="flex items-center gap-0.5 rounded-full border border-[#1d1b18]/8 px-1.5 py-1.5"
        style={{
          background: "rgba(254,248,242,0.96)",
          boxShadow:
            "0 1px 0 rgba(255,255,255,0.9) inset, 0 14px 36px -16px rgba(151,71,44,0.32), 0 6px 14px -8px rgba(29,27,24,0.18)",
        }}
      >
        {items.map((item) => (
          <Link
            key={item.key}
            href={item.href}
            aria-label={item.label}
            aria-current={item.active ? "page" : undefined}
            className={`group relative flex h-11 min-w-[44px] flex-col items-center justify-center gap-0.5 rounded-full px-2.5 transition-colors duration-200 ${
              item.active
                ? "text-[#fef8f2]"
                : "text-[#8a7f76] hover:text-[#1d1b18]"
            }`}
            style={
              item.active
                ? {
                    background: "linear-gradient(180deg, #97472c, #7a3a23)",
                    boxShadow:
                      "0 1px 0 rgba(255,220,200,0.25) inset, 0 4px 10px -2px rgba(151,71,44,0.5)",
                  }
                : undefined
            }
          >
            <svg
              aria-hidden
              className="h-[18px] w-[18px]"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={item.active ? 2 : 1.6}
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d={item.iconD}
              />
            </svg>
            <span
              className={`hidden font-[family-name:var(--font-dm-mono)] text-[8px] font-semibold uppercase tracking-[0.6px] sm:inline ${
                item.active ? "text-[#fef8f2]" : "text-[#8a7f76]"
              }`}
            >
              {item.label}
            </span>
          </Link>
        ))}
      </div>
    </nav>
  );
}
