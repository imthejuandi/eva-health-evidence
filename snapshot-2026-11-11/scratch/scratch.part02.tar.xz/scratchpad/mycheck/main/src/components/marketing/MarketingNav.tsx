"use client";

/**
 * MarketingNav — floating Dynamic-Island-style nav.
 *
 * Two-state floating pill anchored at the top-center of the viewport:
 *
 *  1. AT THE TOP of the page, the pill opens as a full horizontal bar
 *     showing the EVA wordmark + nav links + language toggle + CTA.
 *     This is the landing-page entry state — everything visible, no
 *     hover required.
 *
 *  2. AS THE USER SCROLLS past the hero (scrollY > 24px), the pill
 *     collapses via a spring-driven layout animation back to just the
 *     italic "EVA" wordmark.
 *
 * Once collapsed, hovering (desktop) or tapping (mobile) re-expands
 * it using the exact same layout morph — same spring physics, same
 * content, same iOS-drawer easing. The only difference is the
 * trigger surface.
 *
 * Mobile behaviour
 *  - At the top of the page the pill opens as a wide two-row banner
 *    anchored near the top of the viewport: row 1 carries the EVA
 *    wordmark on the left and the language toggle + CTA on the
 *    right, row 2 centers the four nav links beneath them. The
 *    banner spans most of the viewport width so it reads as the
 *    "ceiling" of the page rather than a floating island.
 *  - As the user scrolls past the threshold the banner collapses via
 *    the same spring layout morph into the compact centered "EVA"
 *    pill.
 *  - Tapping the collapsed pill re-expands it into the same two-row
 *    banner — same spring, same content — so touch users get the
 *    full navigation menu without a separate overlay screen.
 *  - `rounded-3xl md:rounded-full` keeps the corners sane when the
 *    mobile pill grows into a two-row rectangle; desktop stays a
 *    true capsule.
 *
 * Animation engine
 *  - motion.div with `layout` prop on the pill container handles the
 *    width/height morph automatically as inner content appears or
 *    disappears.
 *  - AnimatePresence(mode="popLayout") removes exiting children from
 *    layout immediately so the parent shrinks without waiting.
 *  - Spring physics (stiffness 280, damping 30) for natural settle
 *    without bounce.
 *  - All hover/active states share the iOS-drawer cubic-bezier so the
 *    micro-interactions feel like one system.
 *
 * Touch + scroll detection
 *  - Both are read via useSyncExternalStore — the React-19-sanctioned
 *    pattern for subscribing to browser state without the
 *    setState-in-effect lint rule. Touch uses matchMedia, scroll
 *    uses a passive scroll listener on window. Snapshots return
 *    primitive booleans so React bails out of re-renders unless the
 *    value actually flips.
 */

import { useState, useSyncExternalStore } from "react";
import Link from "next/link";
import { useParams, usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

const EASE_PREMIUM = [0.32, 0.72, 0, 1] as const;
const PILL_SPRING = { type: "spring" as const, stiffness: 280, damping: 30 };
// Scroll distance (px) past which the pill collapses to its compact
// state. 24px keeps the expanded bar visible while the user is still
// on the hero and collapses the moment they commit to scrolling.
const SCROLL_THRESHOLD = 24;

// ── External store: touch-device detection ──────────────────────────
// Module-scope so the snapshot functions keep stable identity across
// renders (useSyncExternalStore requirement).
const TOUCH_QUERY = "(hover: none) and (pointer: coarse)";
const subscribeTouch = (callback: () => void) => {
  if (typeof window === "undefined" || !window.matchMedia) return () => {};
  const mq = window.matchMedia(TOUCH_QUERY);
  mq.addEventListener("change", callback);
  return () => mq.removeEventListener("change", callback);
};
const getTouchSnapshot = () => {
  if (typeof window === "undefined" || !window.matchMedia) return false;
  return window.matchMedia(TOUCH_QUERY).matches;
};
const getTouchServerSnapshot = () => false;

// ── External store: at-top-of-page detection ─────────────────────────
// Passive scroll listener + boolean snapshot. Because the snapshot
// returns the same value between threshold crossings, React only
// re-renders when `atTop` actually flips — cheap enough for a scroll
// listener.
const subscribeScroll = (callback: () => void) => {
  if (typeof window === "undefined") return () => {};
  window.addEventListener("scroll", callback, { passive: true });
  return () => window.removeEventListener("scroll", callback);
};
const getAtTopSnapshot = () => {
  if (typeof window === "undefined") return true;
  return window.scrollY < SCROLL_THRESHOLD;
};
// Server snapshot: assume we start at the top of the page. Any
// hydration mismatch resolves with a single layout-morph frame.
const getAtTopServerSnapshot = () => true;

export function MarketingNav() {
  // Hover expansion is only ever set on desktop via mouse events;
  // touch expansion is toggled by tapping the logo. We keep them
  // separate so that scroll-driven expansion (atTop) doesn't clobber
  // the other's intent.
  const [hoverExpanded, setHoverExpanded] = useState(false);
  const [touchOpen, setTouchOpen] = useState(false);
  const isTouch = useSyncExternalStore(
    subscribeTouch,
    getTouchSnapshot,
    getTouchServerSnapshot,
  );
  const atTop = useSyncExternalStore(
    subscribeScroll,
    getAtTopSnapshot,
    getAtTopServerSnapshot,
  );

  const params = useParams();
  const pathname = usePathname();
  const locale = (params.locale as string) ?? "es";
  const otherLocale = locale === "es" ? "en" : "es";

  const t =
    locale === "es"
      ? {
          howItWorks: "Cómo Funciona",
          science: "Ciencia",
          pricing: "Precios",
          about: "Nosotros",
          getStarted: "Empezar",
          lang: "EN",
          langSwitch: "Cambiar idioma a English",
          menu: "Abrir menú",
        }
      : {
          howItWorks: "How It Works",
          science: "Science",
          pricing: "Pricing",
          about: "About",
          getStarted: "Get Started",
          lang: "ES",
          langSwitch: "Switch language to Español",
          menu: "Open menu",
        };

  // Collapse both interactive states on route change. React 19 forbids
  // setState-in-useEffect for values that are directly derived from
  // props; the sanctioned pattern is to track the previous value with
  // a state variable and reset during render. React bails out of the
  // second render automatically because the state identity is stable.
  const [prevPathname, setPrevPathname] = useState(pathname);
  if (pathname !== prevPathname) {
    setPrevPathname(pathname);
    setHoverExpanded(false);
    setTouchOpen(false);
  }

  const switchedPath = pathname.replace(`/${locale}`, `/${otherLocale}`);
  const navLinks = [
    { label: t.howItWorks, href: `/${locale}/how-it-works` },
    { label: t.science, href: `/${locale}/science` },
    { label: t.pricing, href: `/${locale}/pricing` },
    { label: t.about, href: `/${locale}/about` },
  ];
  const isActive = (href: string) => pathname === href;

  // The single source of truth for whether the pill shows its
  // expanded content. atTop always wins — the landing state is the
  // bar. Once collapsed, hover (desktop) or tap (touch) re-expands.
  const expanded = atTop || (isTouch ? touchOpen : hoverExpanded);

  const handleMouseEnter = () => {
    if (!isTouch) setHoverExpanded(true);
  };
  const handleMouseLeave = () => {
    if (!isTouch) setHoverExpanded(false);
  };
  const handleLogoClick = (e: React.MouseEvent) => {
    // At the top of the page the pill is already expanded and the
    // logo should navigate home. Once the user has scrolled past the
    // threshold, touch users tap the logo to toggle the inline
    // morph — preventDefault blocks the navigation so the gesture
    // reads as "open the menu", not "go home".
    if (isTouch && !atTop) {
      e.preventDefault();
      setTouchOpen((v) => !v);
    }
  };

  // CTA arrow icon — reused in both the mobile row-1 CTA and the
  // desktop inline CTA so styling stays consistent.
  const ctaArrow = (
    <span
      className="flex h-6 w-6 items-center justify-center rounded-full bg-white/15 transition-all duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-px group-hover:scale-110 group-hover:bg-white/25"
      style={{ transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)" }}
    >
      <svg
        width="11"
        height="11"
        viewBox="0 0 12 12"
        fill="none"
        className="text-white"
      >
        <path
          d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  );
  const ctaClass =
    "group relative inline-flex items-center gap-2 rounded-full bg-[#1d1b18] py-2 pl-4 pr-2 font-[family-name:var(--font-manrope)] text-[12px] font-bold uppercase tracking-[1px] text-[#fef8f2] transition-[transform,background-color] duration-500 hover:bg-[#2a2522] active:scale-[0.97]";
  const ctaStyle = {
    transitionTimingFunction: "cubic-bezier(0.32, 0.72, 0, 1)",
  } as const;
  const langClass =
    "font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.4px] text-[#8a7f76] transition-colors duration-300 hover:text-[#97472c]";
  const navLinkClass = (active: boolean) =>
    cn(
      "group relative font-[family-name:var(--font-manrope)] text-[13px] font-medium transition-colors duration-300",
      active ? "text-[#97472c]" : "text-[#4c463f] hover:text-[#1d1b18]",
    );

  return (
    <motion.div
      className="fixed left-1/2 top-4 z-[101] -translate-x-1/2 md:top-5"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <motion.div
        layout
        transition={PILL_SPRING}
        className="flex flex-col items-stretch rounded-3xl border border-[#1d1b18]/12 bg-[#fef8f2]/96 md:flex-row md:items-center md:rounded-full"
        style={{
          // Warm tinted shadow rather than a generic drop shadow.
          // Two layers: a tight close-in shadow for the rim and a
          // wider diffusion shadow for floating depth.
          boxShadow:
            "0 1px 0 rgba(255,255,255,0.85) inset, 0 12px 36px -14px rgba(151,71,44,0.25), 0 2px 8px -4px rgba(29,27,24,0.10)",
        }}
      >
        {/* ─── Row 1 ───────────────────────────────────────────────
            Mobile: EVA on the left, lang toggle + CTA on the right,
            spread with justify-between so the banner feels balanced.
            Desktop: just the logo — the desktop inline row below
            carries the rest of the content. */}
        <div className="flex w-full items-center justify-between md:w-auto md:justify-start">
          <Link
            href={`/${locale}`}
            onClick={handleLogoClick}
            aria-label={t.menu}
            aria-expanded={expanded}
            className="font-[family-name:var(--font-logo)] text-[24px] font-light lowercase leading-none tracking-[-0.5px] text-[#1d1b18] transition-colors duration-300 hover:text-[#97472c]"
          >
            <span className="block px-6 py-3.5">eva</span>
          </Link>

          {/* Mobile-only inline CTA cluster (right side of row 1).
              Hidden on desktop; desktop carries its own CTA further
              down inside the inline expanded block. popLayout keeps
              the parent shrinking immediately on collapse. */}
          <AnimatePresence mode="popLayout">
            {expanded && (
              <motion.div
                key="mobile-cta"
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 12 }}
                transition={{
                  duration: 0.35,
                  ease: EASE_PREMIUM,
                  delay: 0.05,
                }}
                className="flex items-center gap-3 whitespace-nowrap pr-4 md:hidden"
              >
                <Link
                  href={switchedPath}
                  onClick={() => setTouchOpen(false)}
                  aria-label={t.langSwitch}
                  hrefLang={otherLocale}
                  lang={otherLocale}
                  className={langClass}
                >
                  {t.lang}
                </Link>
                <Link
                  href={`/${locale}/signup`}
                  onClick={() => setTouchOpen(false)}
                  className={ctaClass}
                  style={ctaStyle}
                >
                  <span>{t.getStarted}</span>
                  {ctaArrow}
                </Link>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ─── Row 2 (mobile only) ─────────────────────────────────
            The four nav links, centered below the logo row. Hidden
            on desktop so the desktop inline block stays a single
            horizontal row. */}
        <AnimatePresence mode="popLayout">
          {expanded && (
            <motion.nav
              key="mobile-nav"
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{
                duration: 0.35,
                ease: EASE_PREMIUM,
                delay: 0.08,
              }}
              className="flex items-center justify-center gap-x-5 whitespace-nowrap border-t border-[#1d1b18]/10 px-4 py-3 md:hidden"
            >
              {navLinks.map((link) => {
                const active = isActive(link.href);
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setTouchOpen(false)}
                    className={cn(
                      navLinkClass(active),
                      "text-[12px]",
                    )}
                  >
                    {link.label}
                    <span
                      aria-hidden
                      className={cn(
                        "absolute -bottom-1 left-0 h-[1.5px] w-full origin-left bg-current transition-transform duration-500",
                        active
                          ? "scale-x-100"
                          : "scale-x-0 group-hover:scale-x-100",
                      )}
                      style={{
                        transitionTimingFunction:
                          "cubic-bezier(0.32, 0.72, 0, 1)",
                      }}
                    />
                  </Link>
                );
              })}
            </motion.nav>
          )}
        </AnimatePresence>

        {/* ─── Desktop inline expanded row ─────────────────────────
            Hidden on mobile; on desktop this is the classic inline
            row with hairline + nav links + lang toggle + CTA. */}
        <AnimatePresence mode="popLayout">
          {expanded && (
            <motion.div
              key="desktop-inline"
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{
                duration: 0.35,
                ease: EASE_PREMIUM,
                delay: 0.05,
              }}
              className="hidden items-center gap-6 whitespace-nowrap pr-2 md:flex"
            >
              <span
                aria-hidden
                className="h-5 w-[1px] bg-[#1d1b18]/12"
              />

              <nav className="flex items-center gap-6">
                {navLinks.map((link) => {
                  const active = isActive(link.href);
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setTouchOpen(false)}
                      className={navLinkClass(active)}
                    >
                      {link.label}
                      <span
                        aria-hidden
                        className={cn(
                          "absolute -bottom-1 left-0 h-[1.5px] w-full origin-left bg-current transition-transform duration-500",
                          active
                            ? "scale-x-100"
                            : "scale-x-0 group-hover:scale-x-100",
                        )}
                        style={{
                          transitionTimingFunction:
                            "cubic-bezier(0.32, 0.72, 0, 1)",
                        }}
                      />
                    </Link>
                  );
                })}
              </nav>

              <Link
                href={switchedPath}
                onClick={() => setTouchOpen(false)}
                aria-label={t.langSwitch}
                hrefLang={otherLocale}
                lang={otherLocale}
                className={langClass}
              >
                {t.lang}
              </Link>

              <Link
                href={`/${locale}/signup`}
                onClick={() => setTouchOpen(false)}
                className={ctaClass}
                style={ctaStyle}
              >
                <span>{t.getStarted}</span>
                {ctaArrow}
              </Link>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}
