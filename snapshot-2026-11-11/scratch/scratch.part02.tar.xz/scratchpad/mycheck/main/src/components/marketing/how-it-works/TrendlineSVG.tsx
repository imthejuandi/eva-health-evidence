"use client";

import { motion } from "framer-motion";

const E: [number, number, number, number] = [0.32, 0.72, 0, 1];

interface Props {
  labels: { q1: string; q2: string; q3: string; q4: string; optimal: string };
  className?: string;
}

/**
 * TrendlineSVG — quarterly ferritin trend drawing itself on scroll.
 *
 * Shows Ferritin rising from 38 → 42 → 49 → 52 across four quarters,
 * crossing the optimal threshold (50) at Q3. The line draws via
 * pathLength animation. The optimal band is a subtle jade fill.
 * DM Mono labels at each quarter mark.
 */
export function TrendlineSVG({ labels, className }: Props) {
  return (
    <svg viewBox="0 0 400 160" className={`w-full ${className ?? ""}`} aria-hidden>
      {/* Grid lines */}
      <line x1="60" y1="20" x2="380" y2="20" stroke="#1d1b18" strokeOpacity="0.04" />
      <line x1="60" y1="60" x2="380" y2="60" stroke="#1d1b18" strokeOpacity="0.04" />
      <line x1="60" y1="100" x2="380" y2="100" stroke="#1d1b18" strokeOpacity="0.04" />

      {/* Optimal threshold band (50-150 mapped to y: ~58 to ~20) */}
      <rect x="60" y="20" width="320" height="42" fill="#3a665e" fillOpacity="0.06" rx="4" />
      <text x="55" y="44" textAnchor="end" fontSize="8" fill="#3a665e" fontWeight="600" fontFamily="var(--font-dm-mono)">{labels.optimal}</text>

      {/* Quarter markers */}
      {[{ x: 100, l: labels.q1 }, { x: 193, l: labels.q2 }, { x: 286, l: labels.q3 }, { x: 380, l: labels.q4 }].map((q) => (
        <g key={q.l}>
          <line x1={q.x} y1="15" x2={q.x} y2="110" stroke="#1d1b18" strokeOpacity="0.06" />
          <text x={q.x} y="128" textAnchor="middle" fontSize="10" fill="#8a7f76" fontWeight="600" fontFamily="var(--font-dm-mono)">{q.l}</text>
        </g>
      ))}

      {/* Trendline: 38 → 42 → 49 → 52 (y inverted: higher value = lower y)
          Range: 30-60, so 38→y=73, 42→y=60, 49→y=37, 52→y=27 */}
      <motion.path
        d="M100,73 C140,68 160,63 193,60 C220,54 255,42 286,37 C310,32 350,28 380,27"
        fill="none" stroke="#97472c" strokeWidth="2.5" strokeLinecap="round"
        initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }}
        viewport={{ once: true, margin: "-10%" }}
        transition={{ duration: 1.8, ease: E }}
      />

      {/* Value dots + labels */}
      {[
        { x: 100, y: 73, v: "38" },
        { x: 193, y: 60, v: "42" },
        { x: 286, y: 37, v: "49" },
        { x: 380, y: 27, v: "52" },
      ].map((pt, i) => (
        <motion.g key={pt.v}
          initial={{ opacity: 0, scale: 0 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-10%" }}
          transition={{ delay: 0.4 + i * 0.3, duration: 0.4, ease: E }}
        >
          <circle cx={pt.x} cy={pt.y} r="4" fill="#97472c" />
          <text x={pt.x} y={pt.y - 10} textAnchor="middle" fontSize="10" fill="#97472c" fontWeight="700" fontFamily="var(--font-dm-mono)">{pt.v}</text>
        </motion.g>
      ))}
    </svg>
  );
}
