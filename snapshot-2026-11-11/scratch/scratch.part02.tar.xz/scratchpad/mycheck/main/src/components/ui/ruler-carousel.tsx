"use client";

/**
 * RulerCarousel — a horizontally-stepping carousel whose active item
 * sits between two ruler rails, centred on the rails' long centre tick.
 *
 * Behaviour notes (these differ from the reference implementation this
 * was adapted from, and each difference is deliberate):
 *
 *  1. **Truly infinite, no reset dance.** The reference triplicated the
 *     item array and jumped `activeIndex` back to the middle copy via a
 *     `setTimeout(…, 0)` + `isResetting` flag. That reads a stale
 *     `targetX` on the flag render, so the spring gets cut short and
 *     then slides a full set-width — a visible glitch on every wrap.
 *     Here `active` is a free-running integer over a *virtual* track:
 *     slot `k` always renders `items[mod(k, items.length)]`, and only a
 *     window of slots around `active` is mounted. There is no boundary
 *     to reset at, so there is nothing to glitch.
 *
 *  2. **Measured pitch instead of a hardcoded 500px.** The reference
 *     assumed 9 items at a fixed 400px width + 100px gap, so the
 *     transform maths broke for any other item count or label length.
 *     We measure the widest label off-screen and step every slot at
 *     that constant pitch — which is also the right metaphor, since a
 *     ruler's ticks are evenly spaced.
 *
 *  3. **Fit-to-viewport scaling.** Long labels (`165+ available as full
 *     panel`) overflow a phone at display sizes. The track is scaled
 *     about its centre so the widest label always fits. Scaling about
 *     the centre leaves the active slot centred, so the centre tick
 *     still lines up with it.
 *
 *  4. **Scoped keyboard nav.** The reference bound `keydown` to
 *     `window` and `preventDefault()`-ed the arrow keys for the whole
 *     document. On the landing page that would hijack arrow keys from
 *     the biomarker rail (A11Y-011, an arrow-key-pannable scroll
 *     region) and from every text input. Arrow handling lives on this
 *     component's own focusable group instead.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent } from "react";
import { motion, useReducedMotion, type Transition } from "framer-motion";
import { FastForward, Rewind } from "lucide-react";

import { cn } from "@/lib/utils";

export interface CarouselItem {
  id: number;
  title: string;
  /**
   * Per-item type override, merged over `itemClassName`. Used for the
   * brand wordmark that rests at the ruler's zero position, so it reads
   * as the mark rather than as one more claim.
   */
  className?: string;
}

export interface RulerCarouselProps {
  originalItems: CarouselItem[];
  /** Gutter between adjacent slots, in unscaled px. */
  gap?: number;
  /** Ruler ticks per rail. Odd values put a tick exactly at the centre. */
  totalLines?: number;
  /**
   * ms each item is held during the one-shot intro sweep.
   *
   * The sweep starts when the band scrolls properly into frame, steps
   * once through every item — so it departs from item 0 and lands back
   * on it — and then hands the track to the reader for good. It pauses
   * on hover/focus and while off-screen, is cancelled the moment the
   * reader touches the controls, and never runs under
   * `prefers-reduced-motion`. Omit (or pass 0) to skip it entirely.
   */
  introHoldMs?: number;
  /** Typography for the item labels — pass the caller's display face. */
  itemClassName?: string;
  /** Typography for the `n / total` counter — usually a mono face. */
  counterClassName?: string;
  className?: string;
  labels?: {
    region?: string;
    previous?: string;
    next?: string;
  };
}

/** Horizontal breathing room kept clear at both viewport edges, in px. */
const EDGE_PADDING = 48;

/** Share of the band that must be in frame before the intro sweep arms. */
const INTRO_VISIBILITY = 0.6;

/** Fades the peek labels out at both ends of the track. */
const TRACK_EDGE_MASK =
  "linear-gradient(to right, transparent 0%, #000 14%, #000 86%, transparent 100%)";

const mod = (value: number, length: number) =>
  ((value % length) + length) % length;

function RulerLines({
  top = true,
  totalLines = 101,
}: {
  top?: boolean;
  totalLines?: number;
}) {
  const lines = [];
  const lineSpacing = 100 / (totalLines - 1);
  const centerIndex = Math.floor((totalLines - 1) / 2);

  for (let i = 0; i < totalLines; i++) {
    const isCenter = i === centerIndex;
    const isFifth = i % 5 === 0;

    let height = "h-2 md:h-3";
    let color = "bg-foreground/20";

    if (isCenter) {
      height = "h-6 md:h-8";
      color = "bg-primary";
    } else if (isFifth) {
      height = "h-3 md:h-4";
      color = "bg-primary/40";
    }

    lines.push(
      <div
        key={i}
        className={cn(
          "absolute w-px -translate-x-1/2 md:w-0.5",
          height,
          color,
          top ? "top-0" : "bottom-0",
        )}
        style={{ left: `${i * lineSpacing}%` }}
      />,
    );
  }

  return (
    <div aria-hidden className="relative h-6 w-full shrink-0 md:h-8">
      {lines}
    </div>
  );
}

export function RulerCarousel({
  originalItems,
  gap = 96,
  totalLines = 101,
  introHoldMs = 0,
  itemClassName,
  counterClassName,
  className,
  labels,
}: RulerCarouselProps) {
  const itemCount = originalItems.length;
  const reduced = useReducedMotion();

  const viewportRef = useRef<HTMLDivElement>(null);
  const measureRef = useRef<HTMLDivElement>(null);

  // `active` indexes a virtual, unbounded track — it is free to run
  // negative or past the array length. See note 1 in the file header.
  const [active, setActive] = useState(0);
  const [itemWidth, setItemWidth] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(0);
  const [tookOver, setTookOver] = useState(false);
  // Latches once the band has been properly in frame; the intro sweep
  // waits on it so the reader is actually looking when it plays.
  const [enteredView, setEnteredView] = useState(false);
  const [sweepFinished, setSweepFinished] = useState(false);

  // The sweep's hold conditions live in refs, not state: the loop below
  // reads them every frame, and making them dependencies would tear the
  // loop down and rebuild it — resetting its schedule — on every hover.
  const pausedRef = useRef(false);
  const onScreenRef = useRef(true);
  const tookOverRef = useRef(false);

  // Measure the widest label. The measuring row carries the same
  // typography as the real slots but sits off-screen; `visibility:
  // hidden` (not `display: none`) is required so it still generates
  // boxes to measure. Observing each child means the webfont swap and
  // the responsive type-scale jump at `md` both retrigger measurement.
  useEffect(() => {
    const el = measureRef.current;
    if (!el) return;

    const children = Array.from(el.children);
    const measure = () => {
      let widest = 0;
      for (const child of children) {
        widest = Math.max(widest, child.getBoundingClientRect().width);
      }
      if (widest > 0) setItemWidth(Math.ceil(widest));
    };

    measure();
    const observer = new ResizeObserver(measure);
    for (const child of children) observer.observe(child);
    return () => observer.disconnect();
  }, [originalItems]);

  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;

    const measure = () => setViewportWidth(el.getBoundingClientRect().width);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Don't spring a track nobody is looking at — this page also runs an
  // R3F canvas, so idle off-screen animation is worth reclaiming. The
  // second threshold arms the intro sweep: the band sits directly under
  // a 100dvh hero, so it enters from the bottom edge, and firing while
  // it's still a sliver would spend the sweep off-screen.
  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        onScreenRef.current = entry.isIntersecting;
        if (entry.intersectionRatio >= INTRO_VISIBILITY) setEnteredView(true);
      },
      { threshold: [0, INTRO_VISIBILITY] },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const measured = itemWidth > 0 && viewportWidth > 0;
  const fit = measured
    ? Math.min(1, (viewportWidth - EDGE_PADDING) / itemWidth)
    : 1;
  // Cap the gutter at a fraction of the viewport so narrow screens
  // still show a sliver of the neighbouring labels. At the full 96px
  // gap a phone pushes them entirely off-screen, which loses the only
  // cue that the track continues in both directions.
  const effectiveGap = measured
    ? Math.min(gap, (viewportWidth / fit) * 0.1)
    : gap;
  const pitch = itemWidth + effectiveGap;

  // Mount just enough slots to cover the visible width on both sides,
  // plus one for the slot sliding in. Clamped so a pathological pitch
  // can't mount thousands of nodes.
  const halfWindow = useMemo(() => {
    if (!measured) return 1;
    return Math.min(12, Math.ceil(viewportWidth / fit / 2 / pitch) + 1);
  }, [measured, viewportWidth, fit, pitch]);

  const slots = useMemo(() => {
    const out: number[] = [];
    for (let k = active - halfWindow; k <= active + halfWindow; k++) {
      out.push(k);
    }
    return out;
  }, [active, halfWindow]);

  // The ref is what actually stops the sweep loop mid-frame; the state
  // is only there to re-render the live region. Setting state alone
  // would let the loop take one more step before React commits.
  const step = useCallback((delta: number) => {
    tookOverRef.current = true;
    setTookOver(true);
    setActive((prev) => prev + delta);
  }, []);

  const selectSlot = useCallback((slot: number) => {
    tookOverRef.current = true;
    setTookOver(true);
    setActive(slot);
  }, []);

  // One step per item, so the sweep departs from item 0 and lands back
  // on it.
  //
  // This is a rAF loop against a wall-clock deadline rather than the
  // obvious chain of `setTimeout`s, because the obvious version drifts
  // badly here. The landing page runs an R3F shader canvas, so the main
  // thread is busy enough that a 950ms timer lands ~1300ms late; and
  // re-arming the next timer from inside an effect means React's
  // passive-effect latency (~500ms under that load) is added on top.
  // Measured end to end, a 950ms hold was pacing at ~1750ms. A single
  // long-lived loop that owns its own schedule is immune to both: it
  // never waits on a commit, and each deadline is derived from the
  // previous one rather than from when the last step happened to land.
  const sweepEnabled =
    introHoldMs > 0 && !reduced && measured && enteredView && !tookOver;

  useEffect(() => {
    if (!sweepEnabled) return;

    let frame = 0;
    let remaining = itemCount;
    let deadline = performance.now() + introHoldMs;

    const tick = (now: number) => {
      frame = requestAnimationFrame(tick);

      if (tookOverRef.current) {
        cancelAnimationFrame(frame);
        return;
      }

      // Hovering, or scrolling the band back out of frame, holds the
      // current item: push the deadline out instead of banking the
      // elapsed time, so the reader gets a full hold when they let go.
      if (pausedRef.current || !onScreenRef.current) {
        deadline = now + introHoldMs;
        return;
      }

      if (now < deadline) return;

      setActive((prev) => prev + 1);
      remaining -= 1;
      // Advance the deadline rather than restarting it from `now`, so a
      // late frame doesn't push the rest of the sweep back with it.
      deadline += introHoldMs;
      // ...but never let it fall behind the clock. rAF is suspended
      // outright while the tab is hidden, so on return `now` can be far
      // past the deadline, and a pure `+=` would then fire the backlog
      // on consecutive frames — the sweep visibly bursting through two
      // or three claims at once. After any such stall, resume with a
      // full hold instead of replaying the debt.
      if (deadline < now) deadline = now + introHoldMs;

      if (remaining <= 0) {
        cancelAnimationFrame(frame);
        setSweepFinished(true);
      }
    };

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [sweepEnabled, introHoldMs, itemCount]);

  const introDone = introHoldMs === 0 || tookOver || sweepFinished;

  const handleKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      step(-1);
    } else if (event.key === "ArrowRight") {
      event.preventDefault();
      step(1);
    }
  };

  // Damping is deliberately well under critical (2·√stiffness) so the
  // track overshoots and settles back — that recoil is the whole point
  // of stepping between detents. At damping 30 against stiffness 260
  // the ratio is 0.93, effectively critically damped, which slides
  // rather than snaps. These sit near 0.55, and the scale pop on the
  // label is looser still so it lands a beat after the track.
  const trackTransition: Transition = reduced
    ? { duration: 0 }
    : { type: "spring", stiffness: 300, damping: 19, mass: 1 };

  const itemTransition: Transition = reduced
    ? { duration: 0 }
    : { type: "spring", stiffness: 420, damping: 20 };

  const trackX = viewportWidth / 2 - (active * pitch + itemWidth / 2);
  const activeItem = originalItems[mod(active, itemCount)];

  return (
    <div className={cn("relative w-full", className)}>
      {/* Off-screen measuring row — see the effect above. */}
      <div
        ref={measureRef}
        aria-hidden
        className="pointer-events-none invisible absolute -left-[9999px] top-0 flex"
      >
        {originalItems.map((item) => (
          <span
            key={item.id}
            className={cn(
              "shrink-0 whitespace-nowrap",
              itemClassName,
              item.className,
            )}
          >
            {item.title}
          </span>
        ))}
      </div>

      <div
        ref={viewportRef}
        role="group"
        aria-roledescription="carousel"
        aria-label={labels?.region ?? "Highlights"}
        tabIndex={0}
        onKeyDown={handleKeyDown}
        onMouseEnter={() => {
          pausedRef.current = true;
        }}
        onMouseLeave={() => {
          pausedRef.current = false;
        }}
        // React's synthetic focus events bubble, so these fire for the
        // slot buttons too — i.e. focus-within pausing, without needing
        // a second listener.
        onFocus={() => {
          pausedRef.current = true;
        }}
        onBlur={() => {
          pausedRef.current = false;
        }}
        className="relative w-full overflow-hidden rounded-sm outline-none focus-visible:ring-2 focus-visible:ring-primary/40 focus-visible:ring-offset-4 focus-visible:ring-offset-background"
      >
        <div className="flex h-[112px] flex-col justify-between md:h-[152px]">
          <RulerLines top totalLines={totalLines} />

          {/* The rails run full-bleed, but the labels dissolve at both
              edges — a peek label sliced off mid-glyph by the section
              boundary reads as a layout accident rather than a track
              that continues. Masking (rather than a gradient overlay)
              keeps this background-agnostic. */}
          <div
            className="relative min-h-0 flex-1"
            style={{
              WebkitMaskImage: TRACK_EDGE_MASK,
              maskImage: TRACK_EDGE_MASK,
            }}
          >
            <div
              className="absolute inset-0"
              style={{
                transform: `scale(${fit})`,
                opacity: measured ? 1 : 0,
                transition: "opacity 240ms ease",
              }}
            >
              {/* Mounted only once the pitch is known. Combined with
                  `initial={false}`, the track's first frame lands
                  directly on `trackX` instead of springing in from
                  x=0 — no first-paint slide, and no "have I positioned
                  yet" flag to carry. */}
              {measured && (
              <motion.div
                className="absolute inset-0"
                initial={false}
                animate={{ x: trackX }}
                transition={trackTransition}
              >
                {slots.map((slot) => {
                  const item = originalItems[mod(slot, itemCount)];
                  const isActive = slot === active;

                  return (
                    <motion.button
                      key={slot}
                      type="button"
                      // Only the active label is a tab stop; the peek
                      // labels stay clickable but keyboard users move
                      // with the arrow keys and the controls below,
                      // rather than tabbing through every slot.
                      tabIndex={isActive ? 0 : -1}
                      aria-current={isActive ? "true" : undefined}
                      onClick={() => selectSlot(slot)}
                      initial={false}
                      animate={{
                        scale: isActive ? 1 : 0.75,
                        opacity: isActive ? 1 : 0.65,
                      }}
                      transition={itemTransition}
                      style={{ left: slot * pitch, width: itemWidth }}
                      className={cn(
                        "absolute inset-y-0 flex cursor-pointer items-center justify-center whitespace-nowrap outline-none",
                        isActive
                          ? "text-foreground"
                          : "text-muted-foreground hover:text-foreground",
                        itemClassName,
                        item.className,
                      )}
                    >
                      {item.title}
                    </motion.button>
                  );
                })}
              </motion.div>
              )}
            </div>
          </div>

          <RulerLines top={false} totalLines={totalLines} />
        </div>
      </div>

      <div className="mt-5 flex items-center justify-center gap-4 md:mt-6">
        <button
          type="button"
          onClick={() => step(-1)}
          aria-label={labels?.previous ?? "Previous item"}
          className="flex cursor-pointer items-center justify-center rounded-full p-1 text-primary/70 transition-colors hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary/50"
        >
          <Rewind className="h-5 w-5" />
        </button>

        <div
          className={cn(
            "flex items-center gap-2 text-sm font-medium text-muted-foreground",
            counterClassName,
          )}
          style={{ fontVariantNumeric: "tabular-nums" }}
          // Announcing every step of the intro sweep is noise; once the
          // reader is driving, the change is worth announcing.
          aria-live={introDone ? "polite" : "off"}
        >
          <span className="sr-only">{activeItem?.title}</span>
          <span aria-hidden>{mod(active, itemCount) + 1}</span>
          <span aria-hidden className="opacity-60">
            /
          </span>
          <span aria-hidden>{itemCount}</span>
        </div>

        <button
          type="button"
          onClick={() => step(1)}
          aria-label={labels?.next ?? "Next item"}
          className="flex cursor-pointer items-center justify-center rounded-full p-1 text-primary/70 transition-colors hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary/50"
        >
          <FastForward className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
