"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useInView, useReducedMotion } from "framer-motion";

interface EvaChatDemoProps {
  title: string;
  subtitle: string;
  userLabel: string;
  evaLabel: string;
  userMessage: string;
  evaMessage: string;
  referencedLabel: string;
  ref1: string;
  ref2: string;
  inputPlaceholder: string;
  sendLabel: string;
}

type Phase = "idle" | "user" | "typing" | "response" | "sources";

/**
 * Mini product demo of the EVA AI chat. Renders as a chat UI and runs
 * a scripted choreography on scroll-into-view:
 *   t=0.3s   user message slides in
 *   t=1.2s   typing indicator appears
 *   t=2.6s   typing fades, EVA response fades in
 *   t=3.4s   referenced source tags pop in, staggered
 *
 * Respects prefers-reduced-motion: everything appears at once, no
 * typing indicator.
 */
export function EvaChatDemo({
  title,
  subtitle,
  userLabel,
  evaLabel,
  userMessage,
  evaMessage,
  referencedLabel,
  ref1,
  ref2,
  inputPlaceholder,
  sendLabel,
}: EvaChatDemoProps) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: 0.3 });
  const reduce = useReducedMotion();
  const [phase, setPhase] = useState<Phase>(reduce ? "sources" : "idle");

  useEffect(() => {
    if (!inView || reduce) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    timers.push(setTimeout(() => setPhase("user"), 300));
    timers.push(setTimeout(() => setPhase("typing"), 1200));
    timers.push(setTimeout(() => setPhase("response"), 2600));
    timers.push(setTimeout(() => setPhase("sources"), 3400));
    return () => {
      timers.forEach((t) => clearTimeout(t));
    };
  }, [inView, reduce]);

  const ease = [0.22, 1, 0.36, 1] as const;

  return (
    <motion.div
      ref={ref}
      className="relative mx-auto max-w-[640px] overflow-hidden"
      style={{
        border: "1px solid rgba(29,27,24,0.14)",
        borderRadius: "18px",
        backgroundColor: "rgba(254,248,242,0.9)",
        boxShadow: "0 1px 2px rgba(29,27,24,0.04), 0 24px 48px -24px rgba(29,27,24,0.14)",
      }}
      initial={reduce ? false : { opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={reduce ? { duration: 0 } : { duration: 0.8, ease }}
    >
      {/* Chat header */}
      <div className="flex items-center justify-between gap-3 border-b border-[#1d1b18]/10 px-5 py-4 md:px-6">
        <div className="flex items-center gap-3">
          <span
            className="flex h-7 w-7 items-center justify-center rounded-full font-[family-name:var(--font-sentient)] italic text-[#fef8f2]"
            style={{
              background: "linear-gradient(135deg,#3a665e,#1d4b43)",
              fontSize: "13px",
              lineHeight: 1,
            }}
          >
            E
          </span>
          <div className="flex flex-col">
            <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold leading-none text-[#1d1b18]">
              {title}
            </span>
            <span className="mt-1 flex items-center gap-1.5 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
              <motion.span
                className="block h-[6px] w-[6px] rounded-full bg-[#3a665e]"
                aria-hidden
                animate={reduce ? undefined : { opacity: [0.5, 1, 0.5] }}
                transition={reduce ? undefined : { duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
              />
              {subtitle}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1.5" aria-hidden>
          <span className="block h-[6px] w-[6px] rounded-full bg-[#1d1b18]/15" />
          <span className="block h-[6px] w-[6px] rounded-full bg-[#1d1b18]/15" />
          <span className="block h-[6px] w-[6px] rounded-full bg-[#1d1b18]/15" />
        </div>
      </div>

      {/* Messages */}
      <div className="flex flex-col gap-5 px-5 py-6 md:min-h-[340px] md:px-6 md:py-7">
        {/* User message — appears first */}
        <AnimatePresence initial={false}>
          {(phase === "user" || phase === "typing" || phase === "response" || phase === "sources") && (
            <motion.div
              key="user"
              className="flex flex-col items-end"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease }}
            >
              <span className="mb-1.5 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
                {userLabel}
              </span>
              <div
                className="max-w-[78%] px-4 py-3"
                style={{
                  backgroundColor: "rgba(196,147,50,0.14)",
                  borderRadius: "14px 14px 4px 14px",
                }}
              >
                <p className="font-[family-name:var(--font-manrope)] text-[14px] leading-[1.55] text-[#1d1b18]">
                  {userMessage}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Typing indicator — shows while EVA "composes" */}
        <AnimatePresence mode="wait">
          {phase === "typing" && (
            <motion.div
              key="typing"
              className="flex flex-col items-start"
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4, transition: { duration: 0.25 } }}
              transition={{ duration: 0.35, ease }}
            >
              <span className="mb-1.5 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#3a665e]">
                {evaLabel}
              </span>
              <div
                className="flex items-center gap-1.5 border border-[#1d1b18]/10 px-4 py-3.5"
                style={{
                  backgroundColor: "#ffffff",
                  borderRadius: "14px 14px 14px 4px",
                }}
              >
                <TypingDot delay={0} />
                <TypingDot delay={0.18} />
                <TypingDot delay={0.36} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* EVA response */}
        <AnimatePresence initial={false}>
          {(phase === "response" || phase === "sources") && (
            <motion.div
              key="response"
              className="flex flex-col items-start"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease }}
            >
              <span className="mb-1.5 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#3a665e]">
                {evaLabel}
              </span>
              <div
                className="max-w-[88%] border border-[#1d1b18]/10 px-4 py-3"
                style={{
                  backgroundColor: "#ffffff",
                  borderRadius: "14px 14px 14px 4px",
                }}
              >
                <p className="font-[family-name:var(--font-manrope)] text-[14px] leading-[1.65] text-[#2a2319]">
                  {evaMessage}
                </p>

                {/* Referenced sources — pop in after response lands */}
                <AnimatePresence initial={false}>
                  {phase === "sources" && (
                    <motion.div
                      key="sources"
                      className="mt-4 border-t border-[#1d1b18]/10 pt-3"
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.35, ease }}
                    >
                      <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
                        {referencedLabel}
                      </p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <motion.span
                          className="inline-flex items-center rounded-full px-2.5 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-semibold text-[#97472c]"
                          style={{ backgroundColor: "rgba(151,71,44,0.08)" }}
                          initial={{ opacity: 0, scale: 0.9, y: 4 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: 0.1, ease }}
                        >
                          {ref1}
                        </motion.span>
                        <motion.span
                          className="inline-flex items-center rounded-full px-2.5 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-semibold text-[#3a665e]"
                          style={{ backgroundColor: "rgba(58,102,94,0.10)" }}
                          initial={{ opacity: 0, scale: 0.9, y: 4 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: 0.25, ease }}
                        >
                          {ref2}
                        </motion.span>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input bar */}
      <div className="border-t border-[#1d1b18]/10 px-5 py-3 md:px-6">
        <div
          className="group flex items-center gap-3 rounded-full border border-[#1d1b18]/10 px-4 py-2.5 transition-[border-color,box-shadow] duration-300"
          style={{ backgroundColor: "#ffffff" }}
        >
          <span className="flex-1 font-[family-name:var(--font-manrope)] text-[13px] italic text-[#8a7f76]">
            {inputPlaceholder}
            <motion.span
              className="ml-0.5 inline-block h-[12px] w-[1px] -translate-y-[1px] bg-[#3a665e] align-middle"
              aria-hidden
              animate={reduce ? undefined : { opacity: [0, 1, 1, 0] }}
              transition={
                reduce
                  ? undefined
                  : { duration: 1.1, repeat: Infinity, ease: "easeInOut", times: [0, 0.1, 0.5, 1] }
              }
            />
          </span>
          <motion.button
            type="button"
            tabIndex={-1}
            aria-label={sendLabel}
            whileHover={reduce ? undefined : { scale: 1.08 }}
            whileTap={reduce ? undefined : { scale: 0.92 }}
            transition={{ duration: 0.18, ease }}
            className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full"
            style={{ backgroundColor: "#1d1b18" }}
          >
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
              <path
                d="M1.5 6h9m0 0L7 2.5M10.5 6L7 9.5"
                stroke="#fef8f2"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}

function TypingDot({ delay }: { delay: number }) {
  return (
    <motion.span
      className="block h-[6px] w-[6px] rounded-full bg-[#3a665e]"
      animate={{ opacity: [0.25, 1, 0.25], y: [0, -2, 0] }}
      transition={{
        duration: 1.0,
        repeat: Infinity,
        ease: "easeInOut",
        delay,
      }}
    />
  );
}
