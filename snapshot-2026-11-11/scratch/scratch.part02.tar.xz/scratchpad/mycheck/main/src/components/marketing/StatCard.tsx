"use client";

import { motion, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  number: string;
  suffix?: string;
  label: string;
  source?: string;
  color?: "terra" | "jade" | "gold";
}

const colorMap = {
  terra: { text: "text-eva-terra", accent: "rgba(151,71,44,0.06)", ring: "rgba(151,71,44,0.06)" },
  jade: { text: "text-eva-jade", accent: "rgba(58,102,94,0.06)", ring: "rgba(58,102,94,0.06)" },
  gold: { text: "text-eva-gold", accent: "rgba(196,147,50,0.06)", ring: "rgba(196,147,50,0.06)" },
};

function AnimatedNumber({ value, suffix }: { value: string; suffix?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [display, setDisplay] = useState("0");

  useEffect(() => {
    if (!isInView) return;
    const numericPart = parseFloat(value.replace(/[^0-9.]/g, ""));
    const prefix = value.replace(/[0-9.]/g, "");
    if (isNaN(numericPart)) {
      setDisplay(value);
      return;
    }
    const duration = 1200;
    const start = performance.now();
    const step = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = numericPart * eased;
      setDisplay(
        prefix +
          (Number.isInteger(numericPart)
            ? Math.round(current).toString()
            : current.toFixed(1)),
      );
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [isInView, value]);

  return (
    <div ref={ref} className="font-display text-[52px] font-bold leading-none tracking-tight">
      {display}
      {suffix && <span className="text-[32px]">{suffix}</span>}
    </div>
  );
}

export function StatCard({
  number,
  suffix,
  label,
  source,
  color = "terra",
}: StatCardProps) {
  const cfg = colorMap[color];

  return (
    <motion.div
      whileHover={{ y: -3 }}
      transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
      /* ─── Outer Shell (Double-Bezel) ─── */
      className="rounded-[2rem] p-1.5"
      style={{
        background: cfg.accent,
        boxShadow: `inset 0 0 0 1px ${cfg.ring}`,
      }}
    >
      {/* ─── Inner Core ─── */}
      <div
        className={cn(
          "rounded-[calc(2rem-0.375rem)] bg-white p-8",
        )}
        style={{
          boxShadow: "inset 0 1px 1px rgba(255,255,255,0.6), 0 20px 60px rgba(29,27,24,0.03)",
        }}
      >
        <div className={cfg.text}>
          <AnimatedNumber value={number} suffix={suffix} />
        </div>
        <p className="mt-3 font-heading text-[15px] font-medium leading-relaxed text-eva-on-surface-muted">
          {label}
        </p>
        {source && (
          <p className="mt-2 font-mono text-[9px] font-medium uppercase tracking-[1px] text-eva-on-surface-dim">
            {source}
          </p>
        )}
      </div>
    </motion.div>
  );
}
