"use client";

import type { PanelPricingMode } from "@/config/panels";

interface PanelPriceSlotProps {
  mode: PanelPricingMode;
  addonPriceEur?: number;
  includedLabel: string;
  quoteLabel: string;
  addonSuffix: string;
  onQuoteClick?: () => void;
}

export function PanelPriceSlot({
  mode,
  addonPriceEur,
  includedLabel,
  quoteLabel,
  addonSuffix,
  onQuoteClick,
}: PanelPriceSlotProps) {
  if (mode === "included") {
    return (
      <span className="inline-flex items-center gap-[var(--space-sm)] font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-jade)]">
        <span
          aria-hidden
          className="inline-block h-[1px] w-[14px] bg-[var(--color-eva-jade)]"
        />
        {includedLabel}
      </span>
    );
  }

  if (mode === "addon" && typeof addonPriceEur === "number") {
    return (
      <span className="inline-flex items-baseline gap-[var(--space-xs)]">
        <span
          className="font-[family-name:var(--font-sentient)] text-[18px] font-medium leading-none tracking-[-0.015em] text-[var(--color-eva-terra)]"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          +€{addonPriceEur}
        </span>
        <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-terra)]/80">
          {addonSuffix}
        </span>
      </span>
    );
  }

  return (
    <button
      type="button"
      onClick={onQuoteClick}
      className="group/quote inline-flex items-center gap-[var(--space-sm)] font-[family-name:var(--font-dm-mono)] text-[10.5px] font-semibold uppercase tracking-[0.2em] text-[var(--color-eva-on-surface)]/70 transition-colors hover:text-[var(--color-eva-on-surface)]"
    >
      <span>{quoteLabel}</span>
      <svg
        width="10"
        height="10"
        viewBox="0 0 12 12"
        fill="none"
        aria-hidden
        className="transition-transform duration-[220ms] group-hover/quote:translate-x-0.5"
      >
        <path
          d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5"
          stroke="currentColor"
          strokeWidth="1.3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </button>
  );
}
