"use client";

import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface StepCardProps {
  number: number;
  icon: LucideIcon;
  title: string;
  description: string;
  isLast?: boolean;
}

export function StepCard({ number, icon: Icon, title, description, isLast = false }: StepCardProps) {
  return (
    <div className={cn("relative flex flex-col items-center text-center")}>
      {/* Connector line (desktop only, not on last) */}
      {!isLast && (
        <div className="pointer-events-none absolute top-7 left-[calc(50%+36px)] hidden h-[1.5px] w-[calc(100%-72px)] bg-gradient-to-r from-eva-terra/20 to-eva-jade/20 md:block" />
      )}

      {/* ─── Outer Shell (Double-Bezel) ─── */}
      <div
        className="w-full rounded-[2rem] p-1.5"
        style={{
          background: "rgba(29,27,24,0.02)",
          boxShadow: "inset 0 0 0 1px rgba(29,27,24,0.04)",
        }}
      >
        {/* ─── Inner Core ─── */}
        <div
          className="flex flex-col items-center rounded-[calc(2rem-0.375rem)] bg-white px-6 py-10"
          style={{
            boxShadow: "inset 0 1px 1px rgba(255,255,255,0.5), 0 12px 40px rgba(29,27,24,0.02)",
          }}
        >
          {/* Number badge */}
          <div
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full font-heading text-[17px] font-bold text-white"
            style={{
              background: "linear-gradient(135deg, #1d1b18 0%, #4c463f 100%)",
              boxShadow: "0 8px 24px rgba(29,27,24,0.12)",
            }}
          >
            {number}
          </div>

          {/* Icon */}
          <div className="mt-5 flex h-11 w-11 items-center justify-center rounded-xl bg-eva-terra/[0.05]">
            <Icon className="h-5 w-5 text-eva-terra" strokeWidth={1.5} />
          </div>

          {/* Content */}
          <h3 className="mt-5 font-heading text-[16px] font-bold text-eva-on-surface">
            {title}
          </h3>
          <p className="mt-2.5 text-[14px] leading-relaxed text-eva-on-surface-muted">
            {description}
          </p>
        </div>
      </div>
    </div>
  );
}
