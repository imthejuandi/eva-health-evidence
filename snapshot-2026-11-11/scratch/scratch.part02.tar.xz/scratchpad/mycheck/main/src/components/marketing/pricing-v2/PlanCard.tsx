"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

const EASE_QUART = "cubic-bezier(0.25, 1, 0.5, 1)";

export type PlanAccent = "terra" | "jade" | "gold";

export interface PlanCardProps {
  id: "free" | "quarterly" | "full";
  /** Specimen-plate code, e.g. "Rx-01 · QT". */
  eyebrow: string;
  name: string;
  price: string;
  priceSuffix?: string;
  tagline: string;
  features: string[];
  ctaLabel: string;
  ctaHref?: string;
  ctaOnClick?: () => void;
  mostPopular?: boolean;
  mostPopularLabel?: string;
  accent?: PlanAccent;
  loading?: boolean;
  onSelect?: (id: "free" | "quarterly" | "full") => void;
  footnote?: string;
  /**
   * Optional secondary offer under the main CTA (e.g. the annual-billing
   * variant of the quarterly plan). Text-link styling on purpose — it must
   * not compete with the primary CTA.
   */
  secondaryCta?: { label: string; onClick: () => void; loading?: boolean };
  /** Visual scale of the price. "hero" = fluid clamp; "compact" = fixed. */
  priceScale?: "hero" | "compact";
}

const ACCENT_COLOR: Record<PlanAccent, string> = {
  terra: "var(--color-eva-terra)",
  jade: "var(--color-eva-jade)",
  gold: "var(--color-eva-gold)",
};

export function PlanCard({
  id,
  eyebrow,
  name,
  price,
  priceSuffix,
  tagline,
  features,
  ctaLabel,
  ctaHref,
  ctaOnClick,
  mostPopular = false,
  mostPopularLabel = "Most signed up",
  accent = "terra",
  loading = false,
  onSelect,
  footnote,
  secondaryCta,
  priceScale = "hero",
}: PlanCardProps) {
  const accentColor = ACCENT_COLOR[accent];

  const wrapperCls = cn(
    "group relative flex h-full w-full flex-col",
    "transition-[transform,background-color] duration-[420ms]",
    mostPopular
      ? "bg-[var(--color-eva-cream-warm)]"
      : "bg-[var(--color-eva-surface-lowest)]",
    "hover:-translate-y-1",
  );

  const handleClick = () => {
    onSelect?.(id);
    ctaOnClick?.();
  };

  const priceClass = cn(
    "block font-[family-name:var(--font-sentient)] font-medium leading-[0.85] text-[var(--color-eva-on-surface)]",
    priceScale === "hero"
      ? "text-[clamp(2.75rem,5.5vw,4.5rem)] tracking-[-0.04em]"
      : "text-[clamp(2.25rem,4vw,3rem)] tracking-[-0.03em]",
  );

  const ctaClass = cn(
    "group/btn relative flex h-[48px] w-full items-center justify-center gap-[var(--space-sm)]",
    "px-[var(--space-md)]",
    "font-[family-name:var(--font-manrope)] text-[13px] font-semibold tracking-[0.01em]",
    "transition-colors duration-[220ms]",
    loading && "pointer-events-none opacity-60",
    mostPopular
      ? "bg-[var(--color-eva-terra-deep)] text-white hover:bg-[var(--color-eva-terra)]"
      : id === "free"
        ? "bg-transparent text-[var(--color-eva-on-surface)] ring-1 ring-inset ring-[var(--color-eva-on-surface)]/25 hover:bg-[var(--color-eva-on-surface)] hover:text-white hover:ring-[var(--color-eva-on-surface)]"
        : "bg-[var(--color-eva-on-surface)] text-white hover:bg-[var(--color-eva-ink)]",
  );

  const ctaContent = (
    <>
      <span className="whitespace-nowrap">{loading ? "· · · · ·" : ctaLabel}</span>
      <svg
        aria-hidden
        width="14"
        height="14"
        viewBox="0 0 14 14"
        fill="none"
        className="shrink-0 transition-transform duration-[220ms] group-hover/btn:translate-x-0.5"
        style={{ transitionTimingFunction: EASE_QUART }}
      >
        <path
          d="M3 11L11 3M11 3H5.5M11 3V8.5"
          stroke="currentColor"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </>
  );

  return (
    <article
      className={wrapperCls}
      style={{ transitionTimingFunction: EASE_QUART }}
    >
      {/* Specimen-plate top rule: terra on most-popular, jade on selected state. */}
      <span
        aria-hidden
        className={cn(
          "absolute inset-x-0 top-0 h-px",
          mostPopular
            ? "bg-[var(--color-eva-terra)]"
            : "bg-[var(--color-eva-on-surface)]/15",
        )}
      />
      {/* Hairline vertical/bottom border */}
      <span
        aria-hidden
        className="absolute inset-0 border border-[var(--color-eva-on-surface)]/10 border-t-0"
      />

      {mostPopular && (
        <span
          className={cn(
            "absolute -top-[11px] left-[var(--space-xl)]",
            "bg-[var(--color-eva-terra)] text-[var(--color-eva-surface)]",
            "px-[var(--space-md)] py-[var(--space-xs)]",
            "font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[0.18em]",
          )}
        >
          {mostPopularLabel}
        </span>
      )}

      <div className="flex flex-1 flex-col p-[var(--space-xl)] md:p-[var(--space-2xl)]">
        {/* Specimen code eyebrow — reserve 2 lines so prices align across cards */}
        <div className="flex min-h-[2.25rem] items-start gap-[var(--space-sm)] pt-[4px]">
          <span
            aria-hidden
            className="mt-[8px] inline-block h-[1px] w-[var(--space-xl)] shrink-0"
            style={{ backgroundColor: accentColor }}
          />
          <span
            className="font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase leading-[1.35] tracking-[0.22em]"
            style={{ color: accentColor }}
          >
            {eyebrow}
          </span>
        </div>

        {/* Plan name — reserve 2 lines so prices align across cards */}
        <h3 className="mt-[var(--space-md)] min-h-[3rem] font-[family-name:var(--font-manrope)] text-[18px] font-semibold leading-[1.25] tracking-[-0.01em] text-[var(--color-eva-on-surface)] md:min-h-[3.25rem] md:text-[20px]">
          {name}
        </h3>

        {/* Price — hero typographic moment */}
        <div className="mt-[var(--space-xl)]">
          <span
            className={priceClass}
            style={{ fontVariantNumeric: "tabular-nums" }}
          >
            {price}
          </span>
          {priceSuffix && (
            <span className="mt-[var(--space-xs)] block font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[0.18em] text-[var(--color-eva-on-surface)]/55">
              {priceSuffix}
            </span>
          )}
        </div>

        {/* Tagline — min-h aligns the divider across cards regardless of copy length */}
        <p className="mt-[var(--space-lg)] min-h-[5lh] max-w-[34ch] font-[family-name:var(--font-manrope)] text-[14.5px] leading-[1.55] text-[var(--color-eva-on-surface)]/75">
          {tagline}
        </p>

        {/* Feature list — typographic, no icon circles */}
        <ul className="mt-[var(--space-xl)] flex flex-col gap-[var(--space-md)] border-t border-[var(--color-eva-on-surface)]/10 pt-[var(--space-lg)]">
          {features.map((feat) => (
            <li
              key={feat}
              className="grid grid-cols-[14px_1fr] gap-[var(--space-md)] font-[family-name:var(--font-manrope)] text-[13.5px] leading-[1.5] text-[var(--color-eva-on-surface)]/85"
            >
              <svg
                aria-hidden
                width="14"
                height="14"
                viewBox="0 0 14 14"
                fill="none"
                className="mt-[3px] shrink-0 text-[var(--color-eva-jade)]"
              >
                <path
                  d="M3 7.5L5.5 10L11 4"
                  stroke="currentColor"
                  strokeWidth="1.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span>{feat}</span>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <div className="mt-auto pt-[var(--space-2xl)]">
          {ctaHref ? (
            <Link
              href={ctaHref}
              onClick={() => onSelect?.(id)}
              className={ctaClass}
              style={{ transitionTimingFunction: EASE_QUART }}
            >
              {ctaContent}
            </Link>
          ) : (
            <button
              type="button"
              onClick={handleClick}
              disabled={loading}
              className={ctaClass}
              style={{ transitionTimingFunction: EASE_QUART }}
            >
              {ctaContent}
            </button>
          )}
          {secondaryCta && (
            <button
              type="button"
              onClick={secondaryCta.onClick}
              disabled={secondaryCta.loading}
              className="mt-[var(--space-sm)] self-center font-[family-name:var(--font-manrope)] text-[12.5px] font-semibold text-[var(--color-eva-on-surface)]/70 underline underline-offset-4 transition-colors hover:text-[var(--color-eva-on-surface)] disabled:opacity-50"
            >
              {secondaryCta.loading ? "…" : secondaryCta.label}
            </button>
          )}
          {/* Footnote — min-h reserves 2 lines so all CTA containers match height and buttons land at the same y across cards */}
          <p className="mt-[var(--space-md)] min-h-[2lh] font-[family-name:var(--font-dm-mono)] text-[10.5px] leading-[1.4] uppercase tracking-[0.14em] text-[var(--color-eva-on-surface)]/50">
            {footnote ?? ""}
          </p>
        </div>
      </div>
    </article>
  );
}
