"use client";

import { useParams } from "next/navigation";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceArea,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface DataPoint {
  date: string;
  value: number;
  source: string;
}

interface TrendChartProps {
  dataPoints: DataPoint[];
  optimalLow?: number | null;
  optimalHigh?: number | null;
  unit?: string;
}

export function TrendChart({ dataPoints, optimalLow, optimalHigh, unit = "" }: TrendChartProps) {
  const locale = (useParams().locale as string) ?? "es";
  const dateLocale = locale === "es" ? "es-ES" : "en-GB";

  if (dataPoints.length === 0) return null;

  const chartData = dataPoints.map((d) => ({
    date: new Date(d.date).toLocaleDateString(dateLocale, { day: "numeric", month: "short" }),
    value: d.value,
    source: d.source,
  }));

  const allValues = dataPoints.map((d) => d.value);
  if (optimalLow != null) allValues.push(optimalLow);
  if (optimalHigh != null) allValues.push(optimalHigh);
  const yMin = Math.min(...allValues) * 0.9;
  const yMax = Math.max(...allValues) * 1.1;

  return (
    <div className="h-[220px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e7e2dc" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 11, fill: "#8a7f76", fontFamily: "var(--font-inter)" }}
            axisLine={{ stroke: "#e7e2dc" }}
            tickLine={false}
          />
          <YAxis
            domain={[yMin, yMax]}
            tick={{ fontSize: 11, fill: "#8a7f76", fontFamily: "var(--font-inter)" }}
            axisLine={false}
            tickLine={false}
            width={40}
            unit={unit ? ` ${unit}` : ""}
          />
          <Tooltip
            contentStyle={{
              borderRadius: 16,
              border: "1px solid #e7e2dc",
              boxShadow: "0 8px 24px rgba(29,27,24,0.06)",
              fontFamily: "var(--font-inter)",
              fontSize: 13,
            }}
            formatter={(val) => [`${val} ${unit}`, "Value"]}
          />
          <Legend
            wrapperStyle={{ fontSize: 11, fontFamily: "var(--font-dm-mono)" }}
          />

          {/* Optimal range band */}
          {optimalLow != null && optimalHigh != null && (
            <ReferenceArea
              y1={optimalLow}
              y2={optimalHigh}
              fill="rgba(58,102,94,0.08)"
              stroke="none"
              label={{ value: "Optimal", position: "insideTopRight", fill: "#3a665e", fontSize: 10 }}
            />
          )}

          <Line
            type="monotone"
            dataKey="value"
            stroke="#97472c"
            strokeWidth={2.5}
            dot={(props: Record<string, unknown>) => {
              const { cx, cy, payload } = props as { cx: number; cy: number; payload: { source: string } };
              const isEva = payload.source === "eva" || payload.source === "eva_kit";
              return (
                <circle
                  key={`dot-${cx}-${cy}`}
                  cx={cx}
                  cy={cy}
                  r={5}
                  fill={isEva ? "#97472c" : "#3a665e"}
                  stroke="#fff"
                  strokeWidth={2}
                />
              );
            }}
            activeDot={{ r: 7, stroke: "#97472c", strokeWidth: 2 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
