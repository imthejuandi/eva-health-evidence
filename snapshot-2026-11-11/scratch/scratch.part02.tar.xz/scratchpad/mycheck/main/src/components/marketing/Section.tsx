import { cn } from "@/lib/utils";

interface SectionProps {
  children: React.ReactNode;
  bg?: "default" | "muted" | "dark";
  maxWidth?: "sm" | "md" | "lg";
  id?: string;
  center?: boolean;
  className?: string;
}

const bgMap = {
  default: "bg-eva-surface",
  muted: "bg-eva-surface-low",
  dark: "bg-eva-on-surface text-white",
};

const maxWidthMap = {
  sm: "max-w-3xl",
  md: "max-w-4xl",
  lg: "max-w-5xl",
};

export function Section({
  children,
  bg = "default",
  maxWidth = "lg",
  id,
  center = false,
  className,
}: SectionProps) {
  return (
    <section id={id} className={cn("px-5 py-20 md:px-8 md:py-28", bgMap[bg], className)}>
      <div className={cn("mx-auto", maxWidthMap[maxWidth], center && "text-center")}>
        {children}
      </div>
    </section>
  );
}
