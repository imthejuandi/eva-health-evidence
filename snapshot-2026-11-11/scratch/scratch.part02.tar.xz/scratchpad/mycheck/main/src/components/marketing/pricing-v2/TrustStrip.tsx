"use client";

interface TrustStripItem {
  /** Retained for source compatibility; no longer rendered as an icon. */
  icon?: "shield" | "lock" | "beaker";
  label: string;
}

interface TrustStripProps {
  items: TrustStripItem[];
}

export function TrustStrip({ items }: TrustStripProps) {
  return (
    <ul className="flex flex-col gap-[var(--space-sm)] md:flex-row md:flex-wrap md:items-center md:gap-x-[var(--space-2xl)] md:gap-y-[var(--space-sm)]">
      {items.map((item) => (
        <li
          key={item.label}
          className="flex items-center gap-[var(--space-md)] font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--color-eva-on-surface)]/65"
        >
          <span
            aria-hidden
            className="inline-block h-[1px] w-[12px] bg-[var(--color-eva-jade)]"
          />
          <span>{item.label}</span>
        </li>
      ))}
    </ul>
  );
}
