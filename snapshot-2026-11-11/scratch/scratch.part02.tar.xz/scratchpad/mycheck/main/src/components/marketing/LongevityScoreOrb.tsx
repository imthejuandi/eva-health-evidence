"use client";

import { useEffect, useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import { BiologicalAgeOrb } from "@/components/shared/BiologicalAgeOrb";

interface LongevityScoreOrbProps {
  score: number; // 0–100
  bioAge: number;
  realAge: number;
  size?: "large" | "hero" | "dashboard" | "small";
  scoreLabel?: string;
}

const sizeConfig = {
  large:     { orbOuter: 400, svgSize: 480, arcRadius: 228, stroke: 4,   labelFont: 22, subFont: 9,  labelOffset: 34 },
  hero:      { orbOuter: 320, svgSize: 384, arcRadius: 184, stroke: 3,   labelFont: 18, subFont: 8,  labelOffset: 27 },
  dashboard: { orbOuter: 160, svgSize: 192, arcRadius: 92,  stroke: 2.5, labelFont: 11, subFont: 7,  labelOffset: 15 },
  small:     { orbOuter: 116, svgSize: 140, arcRadius: 66,  stroke: 2,   labelFont: 9,  subFont: 6,  labelOffset: 11 },
};

export function LongevityScoreOrb({
  score,
  bioAge,
  realAge,
  size = "large",
  scoreLabel = "LONGEVITY SCORE",
}: LongevityScoreOrbProps) {
  const cfg = sizeConfig[size];
  const circumference = 2 * Math.PI * cfg.arcRadius;
  const targetOffset = circumference * (1 - score / 100);

  // Spring-driven dash offset: starts at full (hidden) → target
  const rawProgress = useMotionValue(0);
  const springProgress = useSpring(rawProgress, {
    stiffness: 60,
    damping: 20,
    mass: 1,
  });
  const dashOffset = useTransform(springProgress, (p) =>
    circumference * (1 - p / 100)
  );

  const hasAnimated = useRef(false);

  function triggerAnimation() {
    if (hasAnimated.current) return;
    hasAnimated.current = true;
    // Slight delay so the inner orb's own entrance animation leads
    setTimeout(() => rawProgress.set(score), 400);
  }

  // Label coordinates: score callout at top of arc (12 o'clock + slight gap)
  const cx = cfg.svgSize / 2;
  const cy = cfg.svgSize / 2;
  const labelY = cy - cfg.arcRadius - cfg.labelOffset;

  return (
    <motion.div
      className="relative shrink-0"
      style={{ width: cfg.orbOuter, height: cfg.orbOuter }}
      // Trigger arc animation when this element enters the viewport
      onViewportEnter={triggerAnimation}
      viewport={{ once: true, amount: 0.4 }}
    >
      {/* Centered BiologicalAgeOrb — unchanged */}
      <div className="absolute inset-0 flex items-center justify-center">
        <BiologicalAgeOrb bioAge={bioAge} realAge={realAge} size={size} />
      </div>

      {/* SVG ring overlay — extends beyond orb bounding box via overflow:visible */}
      <svg
        aria-hidden
        className="pointer-events-none absolute"
        style={{
          top: "50%",
          left: "50%",
          transform: `translate(-50%, -50%)`,
          overflow: "visible",
          width: cfg.svgSize,
          height: cfg.svgSize,
        }}
        viewBox={`0 0 ${cfg.svgSize} ${cfg.svgSize}`}
      >
        {/* Track ring — full circle, very faint gold */}
        <circle
          cx={cx}
          cy={cy}
          r={cfg.arcRadius}
          fill="none"
          stroke="rgba(196,147,50,0.14)"
          strokeWidth={cfg.stroke}
        />

        {/* Score arc — gold, starts at 12 o'clock (−90° rotation) */}
        <motion.circle
          cx={cx}
          cy={cy}
          r={cfg.arcRadius}
          fill="none"
          stroke="#c49332"
          strokeWidth={cfg.stroke}
          strokeLinecap="round"
          style={{
            rotate: "-90deg",
            transformOrigin: `${cx}px ${cy}px`,
            strokeDasharray: circumference,
            strokeDashoffset: dashOffset,
          }}
        />

        {/* Score label at top of arc */}
        <g>
          {/* Score number */}
          <text
            x={cx}
            y={labelY}
            textAnchor="middle"
            dominantBaseline="central"
            fontFamily="var(--font-dm-mono), monospace"
            fontSize={cfg.labelFont}
            fontWeight="700"
            fill="#c49332"
            style={{ fontFeatureSettings: "'tnum'" }}
          >
            {score}/100
          </text>
          {/* Sub-label */}
          <text
            x={cx}
            y={labelY + cfg.labelFont * 0.9}
            textAnchor="middle"
            dominantBaseline="central"
            fontFamily="var(--font-dm-mono), monospace"
            fontSize={cfg.subFont}
            fontWeight="600"
            fill="rgba(151,71,44,0.65)"
            letterSpacing="1.8"
            style={{ textTransform: "uppercase" }}
          >
            {scoreLabel}
          </text>
        </g>
      </svg>
    </motion.div>
  );
}
