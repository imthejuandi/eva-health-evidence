"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * HandDrawnUnderline — the terra pen-stroke underline that
 * draws itself in underneath an emphasised word.
 *
 * First used on the `really?` italic word in §05 The reveal on
 * the landing page. Extracted as a primitive so other pages
 * can reach for the same motion when they want to land a
 * single word with extra weight.
 *
 * Usage:
 *   <span className="relative inline-block italic text-[#97472c]">
 *     really?
 *     <HandDrawnUnderline />
 *   </span>
 *
 * Animation details:
 *   · viewBox 0 0 300 14, preserveAspectRatio none — the SVG
 *     stretches to fill its parent's width, so the underline
 *     adapts to any font size / word length
 *   · d="M4 9 Q 70 2, 150 7 T 296 5" — quadratic bezier with a
 *     slight wobble so it reads as a pen stroke rather than a
 *     ruler line
 *   · pathLength animates 0 → 1 over `drawDuration`, starting
 *     after `delay` (default 0.6s) — `whileInView` fires once
 *     per scroll pass, matching the reveal animations elsewhere
 *     on the marketing surface
 *
 * The parent element must be `relative` and have a
 * `display: inline-block` (or similar) so the absolute SVG
 * positions correctly against the word's bounding box.
 */
const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

interface HandDrawnUnderlineProps {
  /** Stroke color. Default terra. */
  color?: string;
  /** Stroke width in px. Default 3. */
  strokeWidth?: number;
  /** How long the path draws itself in (seconds). Default 1.1. */
  drawDuration?: number;
  /** Delay before the draw starts (seconds). Default 0.6. */
  delay?: number;
  /** Offset from the word's bottom. Default "sm" (-bottom-[6px]/md:-bottom-[10px]). */
  offset?: "sm" | "md";
  className?: string;
}

export function HandDrawnUnderline({
  color = "#97472c",
  strokeWidth = 3,
  drawDuration = 1.1,
  delay = 0.6,
  offset = "sm",
  className,
}: HandDrawnUnderlineProps) {
  return (
    <motion.svg
      aria-hidden
      viewBox="0 0 300 14"
      preserveAspectRatio="none"
      className={cn(
        "pointer-events-none absolute left-0 w-full",
        offset === "sm" &&
          "-bottom-[6px] h-[10px] md:-bottom-[10px] md:h-[14px]",
        offset === "md" &&
          "-bottom-[8px] h-[12px] md:-bottom-[14px] md:h-[18px]",
        className,
      )}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 0.3, delay, ease: EASE }}
    >
      <motion.path
        d="M4 9 Q 70 2, 150 7 T 296 5"
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true, margin: "-10%" }}
        transition={{ duration: drawDuration, delay, ease: EASE }}
      />
    </motion.svg>
  );
}
