"use client";

import { useState } from "react";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

/**
 * "Registrar extracción" — the patient tells us WHEN the blood was drawn.
 * Hybrid timing with Echevarne: the order already left with the kit
 * (estimated date); this re-sends it with the real date/time so the lab
 * processes with real data. Shown on the kit timeline while the kit is out.
 */
export function ActivateKitForm({
  cycleId,
  locale,
  extractionConfirmedAt,
}: {
  cycleId: string;
  locale: string;
  extractionConfirmedAt: string | null;
}) {
  const es = locale === "es";
  const [value, setValue] = useState(() => {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16); // yyyy-MM-ddTHH:mm for datetime-local
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(extractionConfirmedAt);

  const t = es
    ? {
        title: "Registra tu extracción",
        help: "Indica el día y la hora en que te sacaron la sangre. Se lo comunicamos al laboratorio para que procese tu muestra con los datos reales.",
        label: "Fecha y hora de la extracción",
        cta: "Registrar",
        saving: "Guardando…",
        done: "Extracción registrada el",
        edit: "Corregir",
        err: "No se pudo registrar. Inténtalo de nuevo.",
      }
    : {
        title: "Register your blood draw",
        help: "Tell us the day and time your blood was drawn. We pass it to the lab so your sample is processed with real data.",
        label: "Date and time of the draw",
        cta: "Register",
        saving: "Saving…",
        done: "Draw registered on",
        edit: "Correct",
        err: "Could not register. Please try again.",
      };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const iso = new Date(value).toISOString();
      const res = await fetch("/api/cycles/activate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cycleId, extractionAt: iso }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? t.err);
        return;
      }
      setDone(iso);
    } catch {
      setError(t.err);
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="mt-5 rounded-[14px] border border-[#3a665e]/30 bg-[rgba(58,102,94,0.06)] px-4 py-3">
        <p className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#3a665e]`}>
          {t.done}{" "}
          {new Date(done).toLocaleString(es ? "es-ES" : "en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
        </p>
        <button type="button" onClick={() => setDone(null)} className={`mt-1 ${FONT_CLASS.manrope} text-[12px] text-[#8a7f76] underline underline-offset-2`}>
          {t.edit}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="mt-5 rounded-[14px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-4">
      <p className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#1d1b18]`}>{t.title}</p>
      <p className={`mt-1 ${FONT_CLASS.manrope} text-[12px] leading-[1.5] text-[#8a7f76]`}>{t.help}</p>
      <label className={`mt-3 block ${FONT_CLASS.manrope} text-[12px] text-[#4c463f]`}>
        {t.label}
        <input
          type="datetime-local"
          required
          value={value}
          max={new Date().toISOString().slice(0, 16)}
          onChange={(e) => setValue(e.target.value)}
          className="mt-1 block w-full rounded-[10px] border border-[#e7e2dc] bg-white px-3 py-2 text-[13px] text-[#1d1b18]"
        />
      </label>
      {error && <p className={`mt-2 ${FONT_CLASS.manrope} text-[12px] text-[#b04040]`}>{error}</p>}
      <button
        type="submit"
        disabled={busy}
        className={`mt-3 rounded-full bg-[#1d1b18] px-5 py-2 ${FONT_CLASS.manrope} text-[12px] font-semibold text-[#fef8f2] disabled:opacity-50`}
      >
        {busy ? t.saving : t.cta}
      </button>
    </form>
  );
}
