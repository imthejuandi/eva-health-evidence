import { type NextRequest, NextResponse } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";
import createMiddleware from "next-intl/middleware";
import { routing } from "@/i18n/routing";
import { checkRateLimit, type RateLimitRule } from "@/lib/rate-limit";

const locales = ["es", "en"] as const;
const defaultLocale = "es";

const intlMiddleware = createMiddleware(routing);

function getLocaleFromPath(pathname: string): string {
  const segments = pathname.split("/");
  const maybeLocale = segments[1];
  if (locales.includes(maybeLocale as (typeof locales)[number])) {
    return maybeLocale;
  }
  return defaultLocale;
}

// ── Rate limiting (SEC-002) ─────────────────────────────────────────
// Per-IP caps on the sensitive public endpoints. Enforced only when Upstash
// is configured (checkRateLimit fails open otherwise), so an unprovisioned
// deploy is never broken.
const RATE_LIMIT_RULES: { match: (p: string) => boolean; rule: RateLimitRule }[] = [
  { match: (p) => p === "/api/emails/contact", rule: { key: "contact", limit: 5, window: "1 m" } },
  { match: (p) => p === "/api/beta-access", rule: { key: "beta-access", limit: 10, window: "1 m" } },
  { match: (p) => p === "/api/beta-subscribe", rule: { key: "beta-subscribe", limit: 20, window: "1 h" } },
  { match: (p) => p === "/api/ai/chat", rule: { key: "ai-chat", limit: 30, window: "1 m" } },
];

function rateLimitRuleFor(pathname: string): RateLimitRule | null {
  for (const { match, rule } of RATE_LIMIT_RULES) {
    if (match(pathname)) return rule;
  }
  return null;
}

function clientIp(request: NextRequest): string {
  const fwd = request.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]?.trim() || "anonymous";
  return request.headers.get("x-real-ip") ?? "anonymous";
}

// SEC-006 — security headers stamped on every proxied response (pages, API,
// redirects).
const PERMISSIONS_POLICY =
  "camera=(), microphone=(), geolocation=(), browsing-topics=()";

// The CSP ships in Report-Only mode so it surfaces violations without breaking
// the app; flip to the enforcing `Content-Security-Policy` header after
// validating against the live site. 'unsafe-inline' is required because the
// marketing pages render statically (no per-request nonce); a nonce-based CSP
// would force all-dynamic rendering (see Next CSP guide).
const CSP_REPORT_ONLY = [
  "default-src 'self'",
  "base-uri 'self'",
  "object-src 'none'",
  "frame-ancestors 'none'",
  "form-action 'self'",
  "script-src 'self' 'unsafe-inline' https://js.stripe.com https://va.vercel-scripts.com https://plausible.io",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  "connect-src 'self' https://*.supabase.co wss://*.supabase.co https://api.stripe.com https://va.vercel-scripts.com https://plausible.io",
  "frame-src https://js.stripe.com https://hooks.stripe.com",
  "upgrade-insecure-requests",
].join("; ");

function applySecurityHeaders(response: NextResponse): NextResponse {
  const h = response.headers;
  h.set(
    "Strict-Transport-Security",
    "max-age=63072000; includeSubDomains; preload",
  );
  h.set("X-Frame-Options", "DENY");
  h.set("X-Content-Type-Options", "nosniff");
  h.set("Referrer-Policy", "strict-origin-when-cross-origin");
  h.set("Permissions-Policy", PERMISSIONS_POLICY);
  h.set("Content-Security-Policy-Report-Only", CSP_REPORT_ONLY);
  return response;
}

// Run the routing/auth logic, then stamp security headers on whatever response
// it produces (redirect, rewrite, or pass-through).
export async function proxy(request: NextRequest): Promise<NextResponse> {
  return applySecurityHeaders(await handleRequest(request));
}

async function handleRequest(request: NextRequest): Promise<NextResponse> {
  const { pathname } = request.nextUrl;

  // API routes: rate-limit the sensitive public endpoints (SEC-002), then
  // pass through — route handlers own their own auth and logic.
  if (pathname.startsWith("/api")) {
    const rule = rateLimitRuleFor(pathname);
    if (rule) {
      const { success, reset } = await checkRateLimit(rule, clientIp(request));
      if (!success) {
        const retryAfter = Math.max(1, Math.ceil((reset - Date.now()) / 1000));
        return NextResponse.json(
          { error: "Too many requests. Please slow down and try again." },
          { status: 429, headers: { "Retry-After": String(retryAfter) } },
        );
      }
    }
    return NextResponse.next();
  }

  // Skip static assets.
  if (pathname.startsWith("/_next") || pathname.includes(".")) {
    return NextResponse.next();
  }

  // Skip the investors pitch route - served as static HTML from /public/investors
  if (pathname === "/investors" || pathname.startsWith("/investors/")) {
    return NextResponse.next();
  }

  // ── Beta gate ──────────────────────────────────────────────────────
  // Until launch, the entire site lives behind a password / waitlist
  // landing at /{locale}/beta. Visitors without the eva_beta_access
  // cookie are bounced there, regardless of whether they have a
  // Supabase auth session. The gate runs BEFORE the Supabase call so
  // anonymous traffic is blocked without hitting the auth backend.
  //
  // The password unlock API and the waitlist subscribe API both live
  // under /api/* which is already exempted above; the gate page
  // itself is exempted by path here.
  //
  // Launch flip: the whole block runs only when BETA_GATE_ENABLED is
  // anything other than the string "false". Default = enabled, so a
  // missing or misspelled env var keeps the gate on. Set
  // BETA_GATE_ENABLED=false in Vercel on launch day to disable; no
  // code deploy needed and reverting is the same one-line change.
  const betaGateEnabled = process.env.BETA_GATE_ENABLED !== "false";
  if (betaGateEnabled) {
    const betaLocale = getLocaleFromPath(pathname);
    const betaPathWithoutLocale = pathname.replace(`/${betaLocale}`, "") || "/";
    const isBetaPage = betaPathWithoutLocale === "/beta";
    const hasBetaCookie = request.cookies.get("eva_beta_access")?.value === "1";

    if (!hasBetaCookie && !isBetaPage) {
      const gateUrl = new URL(`/${betaLocale}/beta`, request.url);
      // Preserve the deep link so we can redirect post-unlock. Skip
      // for the bare locale root (no value in echoing "/" back as
      // ?next=).
      if (pathname !== `/${betaLocale}` && pathname !== `/${betaLocale}/`) {
        gateUrl.searchParams.set("next", pathname);
      }
      return NextResponse.redirect(gateUrl);
    }
    // If the user is already past the gate and visits /beta, send
    // them to the marketing landing instead of showing the gate
    // again.
    if (hasBetaCookie && isBetaPage) {
      return NextResponse.redirect(new URL(`/${betaLocale}`, request.url));
    }
  }

  // 1. Refresh Supabase auth session
  const { supabaseResponse, user, supabase } = await updateSession(request);

  const locale = getLocaleFromPath(pathname);
  const pathWithoutLocale = pathname.replace(`/${locale}`, "") || "/";

  // 2. Protected routes (all dashboard-group routes)
  const protectedPrefixes = ["/dashboard", "/labs", "/eva-ai", "/book", "/profile", "/upload", "/onboarding"];
  const isProtected = protectedPrefixes.some((p) => pathWithoutLocale.startsWith(p));

  if (isProtected) {
    if (!user) {
      const loginUrl = new URL(`/${locale}/login`, request.url);
      loginUrl.searchParams.set("redirect", pathname);
      return NextResponse.redirect(loginUrl);
    }

    // Check onboarding status (skip if already on /onboarding)
    if (pathWithoutLocale !== "/onboarding" && supabase) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("onboarding_completed")
        .eq("id", user.id)
        .single();

      if (profile && !profile.onboarding_completed) {
        return NextResponse.redirect(
          new URL(`/${locale}/onboarding`, request.url)
        );
      }
    }
  }

  // 3. Protected routes: /[locale]/admin/*
  if (pathWithoutLocale.startsWith("/admin")) {
    // Edge pre-check = defense-in-depth + bootstrap. ADMIN_EMAILS is the fast
    // allow-list at the edge; the AUTHORITATIVE gate is requireAdmin() in the
    // (admin) layout + admin API routes, which additionally enforces
    // profiles.is_admin AND MFA assurance (AAL2). Consequence: an admin must
    // also be present in ADMIN_EMAILS to reach the admin UI — keep ADMIN_EMAILS
    // in sync with the is_admin flag for anyone who needs dashboard access.
    if (!user) {
      const loginUrl = new URL(`/${locale}/login`, request.url);
      loginUrl.searchParams.set("redirect", pathname);
      return NextResponse.redirect(loginUrl);
    }

    const adminEmails = (process.env.ADMIN_EMAILS ?? "")
      .split(",")
      .map((e) => e.trim().toLowerCase());

    if (!adminEmails.includes(user.email?.toLowerCase() ?? "")) {
      return NextResponse.redirect(
        new URL(`/${locale}/dashboard`, request.url)
      );
    }
  }

  // 4. Redirect authenticated users on auth pages to dashboard
  if (
    user &&
    (pathWithoutLocale === "/login" || pathWithoutLocale === "/signup")
  ) {
    return NextResponse.redirect(
      new URL(`/${locale}/dashboard`, request.url)
    );
  }

  // 5. Apply next-intl locale routing
  const intlResponse = intlMiddleware(request);

  // Merge Supabase cookies into the intl response
  supabaseResponse.cookies.getAll().forEach((cookie) => {
    intlResponse.cookies.set(cookie.name, cookie.value, cookie);
  });

  return intlResponse;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
