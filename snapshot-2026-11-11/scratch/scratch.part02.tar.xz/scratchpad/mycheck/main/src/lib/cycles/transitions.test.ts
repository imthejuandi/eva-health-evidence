import { describe, it, expect } from "vitest";
import { validateAdminAction, systemTransitionAllowed } from "./transitions";

describe("validateAdminAction — the fulfillment desk cannot be driven any→any", () => {
  it("assign_kit: only from awaiting_fulfillment, and only with a label", () => {
    expect(validateAdminAction("assign_kit", "awaiting_fulfillment", { kitLabelCode: "Z0001" }))
      .toEqual({ ok: true, to: "kit_assigned" });
    expect(validateAdminAction("assign_kit", "awaiting_fulfillment", {}).ok).toBe(false);
    expect(validateAdminAction("assign_kit", "shipped", { kitLabelCode: "Z0001" }).ok).toBe(false);
  });

  it("ship: only from kit_assigned, and only with a tracking number", () => {
    expect(validateAdminAction("ship", "kit_assigned", { trackingNumber: "JD014600003SE" }))
      .toEqual({ ok: true, to: "shipped" });
    expect(validateAdminAction("ship", "kit_assigned", {}).ok).toBe(false);
    expect(validateAdminAction("ship", "awaiting_fulfillment", { trackingNumber: "X" }).ok).toBe(false);
  });

  it("reopen: recovery path from kit_assigned or error only", () => {
    expect(validateAdminAction("reopen", "kit_assigned", {})).toEqual({ ok: true, to: "awaiting_fulfillment" });
    expect(validateAdminAction("reopen", "error", {}).ok).toBe(true);
    expect(validateAdminAction("reopen", "shipped", {}).ok).toBe(false);
  });

  it("cancel: allowed pre-lab only — never on lab-side statuses", () => {
    for (const from of ["awaiting_fulfillment", "kit_assigned", "shipped", "error"]) {
      expect(validateAdminAction("cancel", from, {}).ok).toBe(true);
    }
    for (const from of ["activated", "order_sent", "order_accepted", "results_partial", "results_final", "completed", "cancelled"]) {
      expect(validateAdminAction("cancel", from, {}).ok).toBe(false);
    }
  });

  it("patient/bridge-owned statuses reject every admin action", () => {
    for (const action of ["assign_kit", "ship", "reopen"] as const) {
      expect(validateAdminAction(action, "activated", { kitLabelCode: "x", trackingNumber: "y" }).ok).toBe(false);
      expect(validateAdminAction(action, "order_accepted", { kitLabelCode: "x", trackingNumber: "y" }).ok).toBe(false);
    }
  });
});

describe("validateAdminAction — complete (results_final → completed, 2026-09-22)", () => {
  it("closes a cycle whose results are in, from results_final only", () => {
    expect(validateAdminAction("complete", "results_final", {})).toEqual({ ok: true, to: "completed" });
    for (const from of ["awaiting_fulfillment", "kit_assigned", "shipped", "order_sent", "order_accepted", "results_partial", "completed", "cancelled", "error"]) {
      expect(validateAdminAction("complete", from, {}).ok).toBe(false);
    }
  });

  it("the system transition agrees: completed is reachable from results_final alone", () => {
    expect(systemTransitionAllowed("completed", "results_final")).toBe(true);
    expect(systemTransitionAllowed("completed", "results_partial")).toBe(false);
  });
});
