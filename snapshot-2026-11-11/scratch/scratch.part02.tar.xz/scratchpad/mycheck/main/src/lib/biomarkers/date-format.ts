/**
 * Shared helpers for European DD/MM/YYYY date display + ISO storage.
 */

/** Convert ISO "1990-03-15" (what the DB stores) → "15/03/1990" (what we display). */
export function isoToEuropean(iso: string | null | undefined): string {
  if (!iso) return "";
  // Already European or user-entered format
  const eu = iso.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (eu) return iso;
  const isoMatch = iso.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (!isoMatch) return iso;
  const [, y, m, d] = isoMatch;
  return `${d.padStart(2, "0")}/${m.padStart(2, "0")}/${y}`;
}

/** Convert European "15/03/1990" → ISO "1990-03-15" for DB storage. Returns null if invalid. */
export function europeanToIso(european: string | null | undefined): string | null {
  if (!european) return null;
  // Accept ISO already
  const alreadyIso = european.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (alreadyIso) {
    const [, y, m, d] = alreadyIso;
    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  const match = european.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return null;
  const [, d, m, y] = match;
  const day = Number(d);
  const month = Number(m);
  const year = Number(y);
  if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1900 || year > 2100) {
    return null;
  }
  // Validate the date actually exists (e.g. not Feb 30)
  const date = new Date(year, month - 1, day);
  if (
    date.getFullYear() !== year ||
    date.getMonth() !== month - 1 ||
    date.getDate() !== day
  ) {
    return null;
  }
  return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
}

/**
 * Auto-insert slashes as the user types a DD/MM/YYYY date.
 * Strips non-digits, inserts "/" after positions 2 and 5, caps at 10 chars.
 */
export function formatEuropeanInput(raw: string): string {
  const digits = raw.replace(/\D/g, "").slice(0, 8);
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}
