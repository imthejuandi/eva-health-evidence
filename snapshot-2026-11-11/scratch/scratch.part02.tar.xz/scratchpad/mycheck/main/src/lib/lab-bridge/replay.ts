/**
 * Replay an ORU from its archived copy in lab_messages.raw.
 *
 * Every inbound message is archived before it is processed and the file is
 * moved to resultados/procesados, where Echevarne purges it weekly. Until
 * 2026-09-22 nothing could read that archive back (audit finding G6-2): a
 * result whose recording failed after the ACK went out, or that was deleted
 * later, had no way back except asking the lab to re-send.
 *
 * This is the desk's way back. It touches no SFTP and sends no ACK (the
 * message was acknowledged when it arrived — an unacknowledged file is still
 * in /resultados and the normal pass handles it); it re-runs the match and the
 * recording exactly as the pass does, on the archived row, and closes it.
 */
import { EchevarneProvider } from "@/lib/lab-provider/echevarne";
import type { BridgeStore } from "./store";

export interface InboundMessageRow {
  id: string;
  msgType: string;
  messageControlId: string;
  raw: string;
  status: string;
  cycleId: string | null;
}

export interface ReplayDeps {
  store: BridgeStore;
  loadInbound(id: string): Promise<InboundMessageRow | null>;
  now: Date;
}

export type ReplayResult =
  | { ok: true; labMessageId: string; messageControlId: string; cycleId: string; labResultId: string; processed: number; unmatched: number }
  | {
      ok: false;
      code: "NOT_FOUND" | "NOT_AN_ORU" | "UNMATCHED_ORDER" | "LABEL_MISMATCH" | "CYCLE_CLOSED" | "ALREADY_RECORDED";
      message: string;
    };

export async function replayInboundOru(
  deps: ReplayDeps,
  labMessageId: string,
  opts: { force?: boolean } = {},
): Promise<ReplayResult> {
  const row = await deps.loadInbound(labMessageId);
  if (!row) return { ok: false, code: "NOT_FOUND", message: `No inbound message ${labMessageId}` };
  if (row.msgType !== "ORU") return { ok: false, code: "NOT_AN_ORU", message: `Message ${labMessageId} is a ${row.msgType}, only ORUs can be replayed` };

  const parsed = EchevarneProvider.parseResults(row.raw);
  const cycle = parsed.placerOrderNumber ? await deps.store.findCycleByPlacer(parsed.placerOrderNumber) : null;
  if (!cycle) {
    return { ok: false, code: "UNMATCHED_ORDER", message: `No cycle with placer ${parsed.placerOrderNumber ?? "(none)"}` };
  }
  if (cycle.kitLabelCode && parsed.providerReference && cycle.kitLabelCode !== parsed.providerReference) {
    return { ok: false, code: "LABEL_MISMATCH", message: `Cycle ${cycle.id} expects petition ${cycle.kitLabelCode}, ORU carries ${parsed.providerReference}` };
  }
  if (cycle.status === "cancelled" || cycle.status === "completed") {
    return { ok: false, code: "CYCLE_CLOSED", message: `Cycle ${cycle.id} is ${cycle.status}; nothing can be recorded on it` };
  }
  if (cycle.labResultId && !opts.force) {
    return {
      ok: false,
      code: "ALREADY_RECORDED",
      message: `Cycle ${cycle.id} already has lab result ${cycle.labResultId}; replay with force to replace its values with this report's`,
    };
  }

  const recorded = await deps.store.recordResults(cycle, parsed, deps.now);
  const nextStatus = parsed.orderStatus === "partial" ? "results_partial" : "results_final";
  await deps.store.setCycleStatus(cycle.id, nextStatus, { lab_result_id: recorded.labResultId });
  await deps.store.markInboundProcessed(row.id, undefined, cycle.id);

  return {
    ok: true,
    labMessageId: row.id,
    messageControlId: row.messageControlId,
    cycleId: cycle.id,
    labResultId: recorded.labResultId,
    processed: recorded.processed,
    unmatched: recorded.unmatched,
  };
}
