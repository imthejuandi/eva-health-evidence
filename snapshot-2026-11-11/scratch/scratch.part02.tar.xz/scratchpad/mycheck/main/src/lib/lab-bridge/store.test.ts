import { describe, it, expect, vi, beforeEach } from "vitest";
import type { LabProviderResult } from "@/lib/lab-provider/types";
import { fakeSupabase, ops } from "@/lib/testing/fake-supabase";

vi.mock("@/lib/biomarkers/process-results", () => ({ processLabResults: vi.fn() }));
import { processLabResults } from "@/lib/biomarkers/process-results";
import { SupabaseBridgeStore } from "./store";

// SupabaseBridgeStore is the only store that touches real tables; the
// scripted client keeps it under test without a database.

describe("SupabaseBridgeStore.archiveInbound", () => {
  it("on a duplicate MSH-10 returns the existing row's id and status, so the pass can tell finished from unfinished", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "lab_messages" && ops(c).startsWith("insert")) return { data: null, error: { code: "23505", message: "duplicate key" } };
      if (c.table === "lab_messages" && ops(c).startsWith("select")) return { data: { id: "in-9", status: "error", cycle_id: null } };
      throw new Error(`unexpected call ${c.table}.${ops(c)}`);
    });
    const store = new SupabaseBridgeStore(client);
    const r = await store.archiveInbound({ msgType: "ORU", messageControlId: "X68800189-261", raw: "MSH|…" });
    expect(r).toEqual({ id: "in-9", duplicate: true, status: "error", cycleId: null });
    const lookup = calls.find((c) => ops(c).startsWith("select"))!;
    expect(lookup.ops.find((o) => o.op === "eq" && o.args[0] === "direction")?.args[1]).toBe("in");
    expect(lookup.ops.find((o) => o.op === "eq" && o.args[0] === "message_control_id")?.args[1]).toBe("X68800189-261");
  });

  it("a fresh message is archived as 'received' with its id", async () => {
    const { client } = fakeSupabase(() => ({ data: { id: "in-1" } }));
    const store = new SupabaseBridgeStore(client);
    expect(await store.archiveInbound({ msgType: "ACK", messageControlId: "EVA1M1", raw: "MSH|…" })).toEqual({ id: "in-1", duplicate: false });
  });

  it("any other insert error is thrown, never swallowed as a duplicate", async () => {
    const { client } = fakeSupabase(() => ({ data: null, error: { code: "57P01", message: "terminating connection" } }));
    const store = new SupabaseBridgeStore(client);
    await expect(store.archiveInbound({ msgType: "ORU", messageControlId: "X", raw: "MSH|…" })).rejects.toMatchObject({ code: "57P01" });
  });
});

describe("SupabaseBridgeStore.findCycleByPlacer / findOutboundByControlId", () => {
  it("a database error is thrown — it must never read as 'no such cycle' (that answer goes to the lab)", async () => {
    const { client } = fakeSupabase(() => ({ data: null, error: { code: "08006", message: "connection failure" } }));
    const store = new SupabaseBridgeStore(client);
    await expect(store.findCycleByPlacer("EVA000001001")).rejects.toMatchObject({ code: "08006" });
    await expect(store.findOutboundByControlId("EVA000001001M1")).rejects.toMatchObject({ code: "08006" });
  });

  it("returns the cycle with its lab_result_id, or null when there is none", async () => {
    const { client } = fakeSupabase((c) =>
      c.table === "test_cycles" ? { data: { id: "c1", user_id: "u1", status: "results_final", seq: 4, kit_label_code: "X68800193", placer_order_number: "EVA000001004", lab_result_id: "lab-1" } } : { data: null },
    );
    const store = new SupabaseBridgeStore(client);
    expect(await store.findCycleByPlacer("EVA000001004")).toEqual({
      id: "c1", userId: "u1", status: "results_final", seq: 4, kitLabelCode: "X68800193", placerOrderNumber: "EVA000001004", labResultId: "lab-1",
    });
    const { client: empty } = fakeSupabase(() => ({ data: null }));
    expect(await new SupabaseBridgeStore(empty).findCycleByPlacer("EVA000009999")).toBeNull();
  });
});

describe("SupabaseBridgeStore.recordResults", () => {
  const cycle = { id: "c1", userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1", labResultId: null };
  const parsed = {
    providerReference: "X68800189",
    placerOrderNumber: "EVA2026T1",
    biomarkers: [{ biomarker_key: "B0000", value: 90, unit: "mg/dL", loincCode: "2345-7", status: "final" }],
    collectionDate: "2026-09-22",
    rawPayload: null,
  } as unknown as LabProviderResult;

  beforeEach(() => {
    vi.mocked(processLabResults).mockReset();
  });

  it("deletes the lab_results row it inserted when the pipeline throws, then rethrows (no orphans)", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-1" } };
      if (c.table === "profiles") return { data: { locale: "es" } };
      if (c.table === "biomarker_references") return { data: [{ biomarker_key: "glucose_fasting", name_en: "Glucose", name_es: "Glucosa" }] };
      return { data: null };
    });
    vi.mocked(processLabResults).mockRejectedValueOnce(new Error("Profile missing date_of_birth"));
    const store = new SupabaseBridgeStore(client);

    await expect(store.recordResults(cycle, parsed, new Date("2026-09-22T08:00:00Z"))).rejects.toThrow(/date_of_birth/);

    const del = calls.find((c) => c.table === "lab_results" && ops(c).startsWith("delete"));
    expect(del).toBeDefined();
    expect(del!.ops.find((o) => o.op === "eq")?.args).toEqual(["id", "lab-1"]);
    // The cycle was never pointed at the dead row.
    expect(calls.some((c) => c.table === "test_cycles" && ops(c).startsWith("update"))).toBe(false);
  });

  it("on success links the cycle to the new lab_results row and passes trustUnits to the pipeline", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-2" } };
      if (c.table === "profiles") return { data: { locale: "es", email: "" } };
      if (c.table === "biomarker_references") return { data: [] };
      return { data: null };
    });
    vi.mocked(processLabResults).mockResolvedValueOnce({ processed: [{}, {}], unmatched: [] } as unknown as Awaited<ReturnType<typeof processLabResults>>);
    const store = new SupabaseBridgeStore(client);

    const r = await store.recordResults(cycle, parsed, new Date("2026-09-22T08:00:00Z"));
    expect(r).toEqual({ labResultId: "lab-2", processed: 2, unmatched: 0, replaced: false });
    expect(vi.mocked(processLabResults).mock.calls[0][4]).toEqual({ trustUnits: true });
    const link = calls.find((c) => c.table === "test_cycles" && ops(c).startsWith("update"))!;
    expect(link.ops[0].args[0]).toMatchObject({ lab_result_id: "lab-2" });
    expect(calls.some((c) => c.table === "lab_results" && ops(c).startsWith("delete"))).toBe(false);
  });

  it("stores the lab's TX observations on the result row, as the lab wrote them", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-3" } };
      if (c.table === "profiles") return { data: { locale: "es", email: "" } };
      if (c.table === "biomarker_references") return { data: [] };
      return { data: null };
    });
    vi.mocked(processLabResults).mockResolvedValueOnce({ processed: [{}], unmatched: [] } as unknown as Awaited<ReturnType<typeof processLabResults>>);
    const notes = [{ code: "B0101", text: "Suero lipémico.\nRepetir en ayunas." }];
    await new SupabaseBridgeStore(client).recordResults(cycle, { ...parsed, textNotes: notes }, new Date("2026-09-22T08:00:00Z"));
    const insert = calls.find((c) => c.table === "lab_results" && ops(c).startsWith("insert"))!;
    expect(insert.ops[0].args[0]).toMatchObject({ lab_notes: notes, status: "pending_context", source: "echevarne" });
  });
});

describe("SupabaseBridgeStore.recordResults — a cycle that already has a result (decision 2026-09-22)", () => {
  const cycle = { id: "c1", userId: "u1", status: "results_final", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1", labResultId: "lab-1" };
  const parsed = {
    providerReference: "X68800189",
    placerOrderNumber: "EVA2026T1",
    biomarkers: [{ biomarker_key: "B0000", value: 95, unit: "mg/dL", loincCode: "2345-7", status: "corrected" }],
    collectionDate: "2026-09-23",
    textNotes: [{ code: "B0101", text: "Resultado corregido." }],
    rawPayload: null,
  } as unknown as LabProviderResult;

  beforeEach(() => {
    vi.mocked(processLabResults).mockReset();
  });

  it("replaces the values of the same lab_results row: old values deleted, pipeline re-run on the same id, row stamped corrected_at — no insert, no email", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("select")) return { data: { id: "lab-1", status: "pending_context" } };
      if (c.table === "biomarker_references") return { data: [] };
      return { data: null };
    });
    vi.mocked(processLabResults).mockResolvedValueOnce({ processed: [{}], unmatched: [] } as unknown as Awaited<ReturnType<typeof processLabResults>>);
    const store = new SupabaseBridgeStore(client);

    const r = await store.recordResults(cycle, parsed, new Date("2026-09-23T08:00:00Z"));
    expect(r).toEqual({ labResultId: "lab-1", processed: 1, unmatched: 0, replaced: true });

    const wipe = calls.find((c) => c.table === "biomarker_values" && ops(c).startsWith("delete"))!;
    expect(wipe.ops.find((o) => o.op === "eq")?.args).toEqual(["lab_result_id", "lab-1"]);
    expect(vi.mocked(processLabResults).mock.calls[0].slice(0, 2)).toEqual(["u1", "lab-1"]);
    expect(vi.mocked(processLabResults).mock.calls[0][4]).toEqual({ trustUnits: true });
    const stamp = calls.find((c) => c.table === "lab_results" && ops(c).startsWith("update"))!;
    expect(stamp.ops[0].args[0]).toEqual({ collection_date: "2026-09-23", lab_notes: parsed.textNotes, corrected_at: "2026-09-23T08:00:00.000Z" });
    expect(stamp.ops.find((o) => o.op === "eq")?.args).toEqual(["id", "lab-1"]);
    expect(calls.some((c) => c.table === "lab_results" && ops(c).startsWith("insert"))).toBe(false);
    // No "your results are in" email for a correction: the only profile read is the mapper's locale lookup.
    expect(calls.filter((c) => c.table === "profiles").map((c) => c.ops[0].args[0])).toEqual(["locale"]);
    // The interpretation was not generated yet (pending_context): nothing to regenerate.
    const statusUpdates = calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update") && (c.ops[0].args[0] as { status?: string }).status);
    expect(statusUpdates).toEqual([]);
  });

  it("falls through to a fresh result only when the cycle's result no longer exists", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("select")) return { data: null };
      if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-9" } };
      if (c.table === "profiles") return { data: { locale: "es", email: "" } };
      if (c.table === "biomarker_references") return { data: [] };
      return { data: null };
    });
    vi.mocked(processLabResults).mockResolvedValueOnce({ processed: [{}], unmatched: [] } as unknown as Awaited<ReturnType<typeof processLabResults>>);
    const r = await new SupabaseBridgeStore(client).recordResults(cycle, parsed, new Date("2026-09-23T08:00:00Z"));
    expect(r).toEqual({ labResultId: "lab-9", processed: 1, unmatched: 0, replaced: false });
    expect(calls.some((c) => c.table === "biomarker_values" && ops(c).startsWith("delete"))).toBe(false);
    const link = calls.find((c) => c.table === "test_cycles" && ops(c).startsWith("update"))!;
    expect(link.ops[0].args[0]).toMatchObject({ lab_result_id: "lab-9" });
  });

  it("a database error while looking the result up is thrown, never read as 'no result'", async () => {
    const { client } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("select")) return { data: null, error: { code: "08006", message: "connection failure" } };
      return { data: null };
    });
    await expect(new SupabaseBridgeStore(client).recordResults(cycle, parsed, new Date())).rejects.toMatchObject({ code: "08006" });
    expect(vi.mocked(processLabResults)).not.toHaveBeenCalled();
  });
});
