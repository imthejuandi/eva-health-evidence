import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { readFileSync } from "node:fs";
import { decodeHl7Bytes } from "@/lib/lab-provider/hl7";
import { InMemoryBridgeStore } from "./store";
import { replayInboundOru, type ReplayDeps } from "./replay";

beforeAll(() => {
  process.env.ECH_MSH_SENDING_APP = "EVAHEALTH";
  process.env.ECH_MSH_SENDING_FACILITY = "EVAHEALTH";
});
afterAll(() => {
  delete process.env.ECH_MSH_SENDING_APP;
  delete process.env.ECH_MSH_SENDING_FACILITY;
});

const NOW = new Date("2026-09-22T09:00:00Z");
const REAL_ORU = decodeHl7Bytes(new Uint8Array(readFileSync("docs/context/training/EVA2026T1_X68800189.ORU")));

/** An archived ORU whose recording never finished: the row is there, in 'error', the file long gone. */
async function archivedButUnfinished(store: InMemoryBridgeStore) {
  const archived = await store.archiveInbound({ msgType: "ORU", messageControlId: "X68800189-261", raw: REAL_ORU });
  await store.markInboundProcessed(archived.id!, "processing failed: profile has no date of birth");
  return archived.id!;
}

function deps(store: InMemoryBridgeStore): ReplayDeps {
  return {
    store,
    now: NOW,
    loadInbound: async (id) => {
      const r = store.inbound.find((i) => i.id === id);
      return r ? { id: r.id, msgType: r.msgType, messageControlId: r.messageControlId, raw: r.raw, status: r.status, cycleId: r.cycleId ?? null } : null;
    },
  };
}

describe("replayInboundOru — a result comes back from lab_messages.raw, no SFTP involved", () => {
  it("records the results, moves the cycle to results_final and closes the archived row", async () => {
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const id = await archivedButUnfinished(store);

    const r = await replayInboundOru(deps(store), id);
    expect(r).toMatchObject({ ok: true, labMessageId: id, messageControlId: "X68800189-261", cycleId: c.id, processed: 22 });
    expect(store.results).toHaveLength(1);
    expect(c.status).toBe("results_final");
    expect(c.patch.lab_result_id).toBe(store.results[0].labResultId);
    expect(store.inbound[0]).toMatchObject({ status: "processed", cycleId: c.id, error: undefined });
  });

  it("refuses to record twice unless forced; forced, it replaces the existing result's values (same result id)", async () => {
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "results_final", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1", labResultId: "lab-old" });
    const id = await archivedButUnfinished(store);

    const refused = await replayInboundOru(deps(store), id);
    expect(refused).toMatchObject({ ok: false, code: "ALREADY_RECORDED" });
    expect(store.results).toHaveLength(0);

    const forced = await replayInboundOru(deps(store), id, { force: true });
    expect(forced).toMatchObject({ ok: true, labResultId: "lab-old" });
    expect(store.results).toHaveLength(1);
    expect(store.replacements).toBe(1);
    expect(c.labResultId).toBe("lab-old"); // one result per cycle: corrected in place, never a second row
  });

  it("refuses an unknown id, a non-ORU, an unmatched or mislabelled order and a closed cycle", async () => {
    const store = new InMemoryBridgeStore();
    expect(await replayInboundOru(deps(store), "nope")).toMatchObject({ ok: false, code: "NOT_FOUND" });

    const ack = await store.archiveInbound({ msgType: "ACK", messageControlId: "EVA2026T1M1", raw: "MSH|^~\\&|LABTRAK|ECHEVARNE|EVAHEALTH|EVAHEALTH|20260909100000||ACK^O21|EVA2026T1M1|T|2.5\rMSA|CA|EVA2026T1M1" });
    expect(await replayInboundOru(deps(store), ack.id!)).toMatchObject({ ok: false, code: "NOT_AN_ORU" });

    const id = await archivedButUnfinished(store);
    expect(await replayInboundOru(deps(store), id)).toMatchObject({ ok: false, code: "UNMATCHED_ORDER" }); // no cycle yet

    const wrong = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800999", placerOrderNumber: "EVA2026T1" });
    expect(await replayInboundOru(deps(store), id)).toMatchObject({ ok: false, code: "LABEL_MISMATCH" });
    wrong.kitLabelCode = "X68800189";
    wrong.status = "cancelled";
    expect(await replayInboundOru(deps(store), id)).toMatchObject({ ok: false, code: "CYCLE_CLOSED" });
    expect(store.results).toHaveLength(0);
    expect(store.inbound.find((i) => i.id === id)?.status).toBe("error"); // untouched on every refusal
  });
});
