import { Resend } from "resend";
import { renderResultsReady, type ResultsReadyData } from "./templates/results-ready";
import { renderWelcome, type WelcomeData } from "./templates/welcome";
import { renderBookingConfirmed, type BookingConfirmedData } from "./templates/booking-confirmed";
import { renderPaymentFailed, type PaymentFailedData } from "./templates/payment-failed";
import { renderKitShipped, type KitShippedData } from "./templates/kit-shipped";
import { renderSampleReceived, type SampleReceivedData } from "./templates/sample-received";
import { renderContextNeeded, type ContextNeededData } from "./templates/context-needed";
import { renderBase } from "./templates/base";

function getResend() {
  return new Resend(process.env.RESEND_API_KEY);
}

type TemplateMap = {
  "results-ready": ResultsReadyData;
  "welcome": WelcomeData;
  "booking-confirmed": BookingConfirmedData;
  "payment-failed": PaymentFailedData;
  "kit-shipped": KitShippedData;
  "sample-received": SampleReceivedData;
  "context-needed": ContextNeededData;
};

type TemplateName = keyof TemplateMap;

const SUBJECTS: Record<TemplateName, Record<string, string>> = {
  "results-ready": { en: "Your EVA results are ready", es: "Tus resultados EVA estan listos" },
  "welcome": { en: "Welcome to EVA Health", es: "Bienvenido a EVA Health" },
  "booking-confirmed": { en: "Your test is booked", es: "Tu test esta reservado" },
  "payment-failed": { en: "Payment issue: action needed", es: "Problema de pago: accion requerida" },
  "kit-shipped": { en: "Your EVA kit is on its way", es: "Tu kit EVA esta en camino" },
  "sample-received": { en: "We've received your sample", es: "Hemos recibido tu muestra" },
  "context-needed": { en: "Your results arrived — confirm context to unlock", es: "Tus resultados llegaron — confirma tu contexto" },
};

function renderTemplate<T extends TemplateName>(template: T, data: TemplateMap[T], locale: string): string {
  let body: string;
  switch (template) {
    case "results-ready":
      body = renderResultsReady(data as ResultsReadyData, locale);
      break;
    case "welcome":
      body = renderWelcome(data as WelcomeData, locale);
      break;
    case "booking-confirmed":
      body = renderBookingConfirmed(data as BookingConfirmedData, locale);
      break;
    case "payment-failed":
      body = renderPaymentFailed(data as PaymentFailedData, locale);
      break;
    case "kit-shipped":
      body = renderKitShipped(data as KitShippedData, locale);
      break;
    case "sample-received":
      body = renderSampleReceived(data as SampleReceivedData, locale);
      break;
    case "context-needed":
      body = renderContextNeeded(data as ContextNeededData, locale);
      break;
    default:
      throw new Error(`Unknown template: ${template}`);
  }
  return renderBase(body, locale);
}

export async function sendEmail<T extends TemplateName>(
  to: string,
  template: T,
  data: TemplateMap[T],
  language: string = "en",
): Promise<void> {
  const locale = language === "es" ? "es" : "en";
  const subject = SUBJECTS[template][locale];
  const html = renderTemplate(template, data, locale);

  await getResend().emails.send({
    from: "EVA Health <noreply@evahealth.es>",
    to,
    subject,
    html,
  });
}
