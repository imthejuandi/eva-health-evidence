import { describe, it, expect } from "vitest";
import { bridgeEnabledFromEnv } from "./run";

describe("bridge enable switch", () => {
  it("only the literal \"true\" turns the bridge on — credentials alone never do", () => {
    expect(bridgeEnabledFromEnv({ ECH_BRIDGE_ENABLED: "true" } as unknown as NodeJS.ProcessEnv)).toBe(true);
    for (const v of [undefined, "", "false", "TRUE", "1", "yes"]) {
      expect(bridgeEnabledFromEnv({ ECH_BRIDGE_ENABLED: v, ECH_SFTP_HOST: "sftp.example" } as unknown as NodeJS.ProcessEnv)).toBe(false);
    }
  });
});
