/**
 * KDM v2.2 Biological Age module — mortality-validated joint estimator.
 *
 * This module produces a population-anchored biological age from the
 * Klemera-Doubal Method (KDM) joint estimator (Klemera & Doubal 2006;
 * Levine 2013; Kwon & Belsky 2021). The library data was trained on
 * NHANES Continuous 1999-2018 (n=18,570) with Spanish-cohort recalibration
 * via PESA / ENRICA / Di@bet.es / Hortega / PREDIMED / EPIRCE / La Rioja
 * (see `data/marker_library_v2_2.json::model_meta`).
 *
 * Validation (NHANES held-out follow-up through 2019):
 *   - Reference BA  : HR per SD = 1.373 [1.29, 1.46], C-stat 0.770
 *   - Calibration slope = 1.027
 *
 * --- Conceptual distinction from the longevity score ---
 * KDM is population-anchored: "how fast are you aging vs typical for your CA?"
 * The longevity-score (./longevity-score.ts) is optimal-range-anchored: "how
 * close are you to longevity-medicine optimal targets?" The two are intentionally
 * distinct metrics — both write to lab_results in parallel.
 *
 * --- Status ---
 * B.5 — core joint-estimator math (incl. natural-log transform when
 *       `log_transformed: true`; skip rule for value ≤ 0).
 * B.6 — sex-aware parameter resolution + s_ca lookup. Propagates
 *       `log_transformed` from the library entry into the resolved params.
 * B.7 — Spanish-recalibration q swap.
 * B.8 — covered by B.5/B.6 wire-up; verified end-to-end against the real
 *       hs-CRP library entry in `biological-age-kdm.test.ts`.
 * B.9 — Fructosamine = 19.97·HbA1c − 39.4 (Cohen 2010) derived when
 *       HbA1c is supplied and Fructosamine is missing.
 * B.10 — gating (≥ 8 of 14 base + Alb + Crea); `computeReferenceBA` and
 *        `computeComprehensiveBA` are now live. Numerical parity vs
 *        Python lands in B.12.
 *
 * --- Path B parameter corrections (2026-05-26 post-launch) ---
 *
 * v2.2.1 (initial Path B): BUN and derived Fructosamine were trained with
 * 1st-99th percentile winsorization applied before the OLS fit. This
 * tightened their residual SD `s`, inflating the joint-estimator weight
 * `(k/s)²` beyond what is statistically justified. The first Path B
 * (deployed in PR #32) overrode (k, q, s) for those two markers only.
 *
 * v2.2.2 (full Path B, this commit): the same issue applied to every
 * trained marker. The Comprehensive BA (full-panel joint estimator) was
 * systematically biased relative to the Reference BA by mean −1.59 years
 * across NHANES — caused by cumulative weight inflation across all
 * winsorized markers. Full Path B applies unwinsorized (k, q, s) to ALL
 * 80 trained markers via `data/path_b_overrides.json`.
 *
 * Mortality re-validation on n=18,570 NHANES subjects across configs:
 *
 *                          Reference HR/SD    Comprehensive HR/SD    Mean Δ (Comp − Ref)
 *   v2.2  (winsorized):    1.367              1.631                  −1.93 y
 *   v2.2.1 (BUN+Fruct):    1.406              1.658                  −1.59 y
 *   v2.2.2 (FULL Path B):  1.391              1.654                  +0.07 y  ← deployed
 *
 * Both tiers pass the spec thresholds (HR/SD ≥ 1.02, C-stat ≥ 0.75,
 * calibration slope ∈ [0.9, 1.1]). v2.2.2 essentially eliminates the
 * population-level Reference/Comprehensive discrepancy while preserving
 * mortality predictiveness.
 *
 * See `scripts/comprehensive_ba_mortality_validation.py` for the run that
 * justifies full Path B; see `generate_path_b_full_overrides.py` for the
 * refit pipeline. The Comprehensive BA carries the larger mortality
 * signal (HR/SD 1.65 vs 1.39) — it's the more discriminative model when
 * the user uploads an extended panel.
 *
 * See plan: /Users/jdl/.claude/plans/glowing-mixing-cray.md §B.3-B.12
 */

import type { BiomarkerInput } from "./longevity-score";
import { kdmInputsFromBiomarkerValues } from "./kdm-adapter";
import {
  creatinineOffsetFromSupplements,
  type SupplementEntry,
} from "./supplements";
import libraryData from "./data/marker_library_v2_2.json";
import sCaData from "./data/kdm_s_ca.json";
import pathBData from "./data/path_b_overrides.json";

// ─── Public types ───

export type Sex = "male" | "female";

/**
 * Result of a KDM joint-estimator computation.
 *
 * `null` is returned when the gating condition fails (see B.10):
 *   - fewer than 8 of 14 base-panel markers present, OR
 *   - Albumin missing, OR
 *   - Creatinine missing.
 *
 * When non-null:
 *   - `BA`        : final CA-anchored biological age (years). This is the
 *                   number written to `lab_results.biological_age`.
 *   - `BA_E`      : pre-anchoring biological age estimate (years). Internal
 *                   diagnostic — the joint estimator's raw output before
 *                   shrinkage toward CA via `s_CA`.
 *   - `s_BA`      : KDM-method s_BA estimate (years). Joint-estimator standard
 *                   deviation; smaller = tighter agreement across markers.
 *   - `n_markers_used`            : count of markers that contributed.
 *   - `used_markers`              : Spanish marker names that contributed
 *                                   (post-adapter — see kdm-adapter.ts in B.4).
 *   - `applied_spanish_recalibration_markers`
 *                                 : subset of `used_markers` where the Spanish
 *                                   recalibrated `q_spain` was applied instead
 *                                   of the NHANES `q_NHANES`. See B.7.
 */
export type KdmReferenceBAResult = {
  BA: number;
  BA_E: number;
  s_BA: number;
  n_markers_used: number;
  used_markers: string[];
  applied_spanish_recalibration_markers: string[];
} | null;

/**
 * Comprehensive BA result — uses the full trained panel rather than just the
 * 14-marker base panel. Same gating (≥8 base + Albumin + Creatinine) but the
 * joint estimator runs over every available marker for which the library has
 * trained KDM parameters. Typically wider standard error; treated as a
 * supplementary headline when sufficient data is uploaded.
 */
export type KdmComprehensiveBAResult = KdmReferenceBAResult;

// ─── Internal types ───

/**
 * Per-marker KDM parameters supplied to the joint estimator.
 *
 * `q` is the marker's mean value at age 50 in the training population.
 * `k` is the slope (units per year of CA). `s` is the residual SD.
 * `log_transformed` indicates the marker value must be natural-logged
 * before plugging into the estimator (applied in B.8).
 *
 * The caller is responsible for resolving sex-stratified vs pooled
 * parameters before calling `klemeraDoubalBa`; this struct represents
 * the already-resolved (k, q, s) tuple for one marker.
 */
export interface KdmMarkerParams {
  k: number;
  q: number;
  s: number;
  log_transformed?: boolean;
}

/**
 * Per-stratum s_ca lookup. `s_ca` is the residual SD of (BA_E − CA) in the
 * training population. The estimator uses it as the prior precision when
 * shrinking BA toward CA. Falls back to `pooled` then to a literal 10.0
 * when neither sex-specific nor pooled is available.
 */
export interface SCaPooled {
  male?: number;
  female?: number;
  pooled?: number;
}

/**
 * Raw return shape of the joint estimator before the outer wrappers
 * (`computeReferenceBA` / `computeComprehensiveBA`) add the
 * `applied_spanish_recalibration_markers` field. Internal — exported only
 * for testing and for the wrappers in B.10-B.11.
 */
export interface KdmJointEstimatorResult {
  BA: number;
  BA_E: number;
  s_BA: number;
  n_markers_used: number;
  used_markers: string[];
}

// ─── Core joint estimator ───

/**
 * Klemera-Doubal joint estimator. Direct TypeScript port of
 * `klemera_doubal_ba()` in
 * `/Users/jdl/Projects/KDM Final Training/training_package_v2_2/training_scripts/kdm_training.py`
 * lines 321-361.
 *
 * Math (Klemera & Doubal 2006, eqs. 35-39):
 *
 *   BA_E = Σᵢ (xᵢ − qᵢ) · (kᵢ / sᵢ²) / Σᵢ (kᵢ / sᵢ)²
 *   s_BA² = 1 / Σᵢ (kᵢ / sᵢ)²
 *
 * CA-anchored shrinkage (Klemera & Doubal 2006, eq. 39):
 *
 *   BA = (BA_E / s_BA² + CA / s_CA²) / (1 / s_BA² + 1 / s_CA²)
 *
 * For log-distributed markers the natural log of x is used before
 * plugging into the formula (set `log_transformed: true` on the param
 * struct; the caller is responsible for confirming x > 0). Markers with
 * non-finite values, missing/zero `s`, or value ≤ 0 (when log-transformed)
 * are silently skipped.
 *
 * Returns `null` when no marker contributed (denominator == 0).
 *
 * Status: B.5 — sex stratification is delegated to the caller via the
 * pre-resolved `params` argument; B.6 adds the sex-aware lookup at the
 * call site. Spanish recalibration is delegated similarly via the
 * caller's choice of `q` (B.7).
 */
export function klemeraDoubalBa(
  values: Record<string, number>,
  params: Record<string, KdmMarkerParams>,
  ca: number,
  useCaAnchor: boolean,
  sCaPooled: SCaPooled,
  sex: Sex,
): KdmJointEstimatorResult | null {
  let num = 0.0;
  let denom = 0.0;
  const used: string[] = [];

  for (const [marker, rawValue] of Object.entries(values)) {
    if (!Number.isFinite(rawValue)) continue;

    const p = params[marker];
    if (!p) continue;

    const { k, q, s, log_transformed } = p;
    if (!Number.isFinite(k) || !Number.isFinite(q)) continue;
    if (!Number.isFinite(s) || s <= 0) continue;

    let v = rawValue;
    if (log_transformed) {
      if (rawValue <= 0) continue;
      v = Math.log(rawValue);
    }
    if (!Number.isFinite(v)) continue;

    num += (v - q) * (k / (s * s));
    denom += (k / s) ** 2;
    used.push(marker);
  }

  if (denom === 0 || used.length === 0) return null;

  const BA_E = num / denom;
  const s_BA2 = 1.0 / denom;

  let BA: number;
  if (useCaAnchor) {
    const sCaCandidate = sex === "male" ? sCaPooled.male : sCaPooled.female;
    const sCa =
      typeof sCaCandidate === "number" && sCaCandidate > 0
        ? sCaCandidate
        : typeof sCaPooled.pooled === "number" && sCaPooled.pooled > 0
          ? sCaPooled.pooled
          : 10.0;
    const sCa2 = sCa * sCa;
    BA = (BA_E / s_BA2 + ca / sCa2) / (1.0 / s_BA2 + 1.0 / sCa2);
  } else {
    BA = BA_E;
  }

  return {
    BA,
    BA_E,
    s_BA: Math.sqrt(s_BA2),
    n_markers_used: used.length,
    used_markers: used,
  };
}

// ─── Sex-aware parameter resolution (B.6) ───

/**
 * Shape of one marker entry in `data/marker_library_v2_2.json::markers`.
 * Permissive (Record-typed) at the JSON boundary so we can resolve at
 * runtime; the strict `KdmMarkerParams` shape is what we hand to the
 * estimator.
 */
export interface KdmLibraryMarker {
  sex_stratified?: boolean;
  log_transformed?: boolean;
  kqs?: { k: number; q: number; s: number } | null;
  kqs_M?: { k: number; q: number; s: number } | null;
  kqs_F?: { k: number; q: number; s: number } | null;
  /**
   * Spanish recalibration block (B.7).
   *
   * Top-level `q_spain` is populated for pooled-fit markers (11 markers in
   * v2.2). For sex-stratified markers, the `per_sex.{M,F}.q_spain` block is
   * populated only when sex-specific Spanish reference means were supplied
   * (0 of 7 in v2.2 — all sex-stratified entries lack per_sex.q_spain). When
   * absent, the recalibration is a no-op for that marker and the NHANES q
   * from `kqs[_M|_F]` is used.
   */
  spanish_recalibration?: {
    calibration_status?: string;
    q_spain?: number | null;
    per_sex?: {
      M?: { q_spain?: number | null } | null;
      F?: { q_spain?: number | null } | null;
    } | null;
  } | null;
}

/**
 * Path B parameter overrides for ALL trained markers whose `s` was tightened
 * by winsorization in the original training pipeline. The JSON is generated
 * by `scripts/generate_path_b_full_overrides.py` from raw NHANES values
 * (1999-2018 cycles), re-fitting each marker's OLS without the 1st-99th
 * percentile clip step that the original training applied.
 *
 * The library JSON is preserved as the historical training record; these
 * overrides apply at lookup time inside `computeBa`.
 */
interface PathBFit {
  k: number;
  q: number;
  s: number;
  r2: number;
  n: number;
}
interface PathBEntry {
  log_transformed?: boolean;
  sex_stratified?: boolean;
  kqs?: PathBFit;
  kqs_M?: PathBFit;
  kqs_F?: PathBFit;
}
const PATH_B_OVERRIDES = (
  pathBData as unknown as { markers: Record<string, PathBEntry> }
).markers;

/**
 * Look up Path B (k, q, s) for a marker + sex. Returns null if the marker
 * has no Path B refit (skipped during generation due to n<100 or
 * missing parameters).
 */
function pathBLookup(
  markerKey: string,
  sex: Sex,
): { k: number; q: number; s: number } | null {
  const entry = PATH_B_OVERRIDES[markerKey];
  if (!entry) return null;
  if (entry.sex_stratified) {
    const block = sex === "male" ? entry.kqs_M : entry.kqs_F;
    if (!block) return null;
    return { k: block.k, q: block.q, s: block.s };
  }
  if (!entry.kqs) return null;
  return { k: entry.kqs.k, q: entry.kqs.q, s: entry.kqs.s };
}

/**
 * Pick the right (k, q, s) tuple for a marker given the subject's sex.
 *
 * Mirrors `kdm_training.py` lines 333-341:
 *   - If `sex_stratified: true` → use `kqs_M` (male) or `kqs_F` (female).
 *   - Otherwise → use pooled `kqs`.
 *
 * Returns `null` if the relevant block is missing, has a null `k`, or has
 * a non-positive `s` (matches the Python skip conditions). B.7 will layer
 * Spanish-recalibration q swap on top of this.
 */
export function resolveMarkerParams(
  entry: KdmLibraryMarker,
  sex: Sex,
): KdmMarkerParams | null {
  const block = entry.sex_stratified
    ? sex === "male"
      ? entry.kqs_M
      : entry.kqs_F
    : entry.kqs;

  if (!block) return null;
  const { k, q, s } = block;
  if (!Number.isFinite(k) || !Number.isFinite(q)) return null;
  if (!Number.isFinite(s) || s <= 0) return null;

  return { k, q, s, log_transformed: entry.log_transformed ?? false };
}

/**
 * Lookup the Spanish-recalibrated q for one marker (B.7).
 *
 * Mirrors `recalibrate.py` per-sex / pooled write paths:
 *   - pooled (non sex-stratified): `spanish_recalibration.q_spain`
 *   - sex-stratified: `spanish_recalibration.per_sex.{M,F}.q_spain`
 *
 * Returns `null` if no recalibrated q is available. The recalibration is
 * applied ONLY when `calibration_status` starts with `"recalibrated_"` — a
 * status like `"unrecalibrated"` or `"insufficient_source_data"` means
 * the NHANES q stays.
 */
export function resolveSpanishRecalibratedQ(
  entry: KdmLibraryMarker,
  sex: Sex,
): number | null {
  const sr = entry.spanish_recalibration;
  if (!sr) return null;
  if (!sr.calibration_status?.startsWith("recalibrated_")) return null;

  if (entry.sex_stratified) {
    const bucket = sex === "male" ? sr.per_sex?.M : sr.per_sex?.F;
    const q = bucket?.q_spain;
    return typeof q === "number" && Number.isFinite(q) ? q : null;
  }

  const q = sr.q_spain;
  return typeof q === "number" && Number.isFinite(q) ? q : null;
}

/**
 * Resolve marker params with Spanish recalibration applied where possible.
 *
 * Composition of `resolveMarkerParams` (B.6) + `resolveSpanishRecalibratedQ`
 * (B.7). Returns the params with `q` swapped to `q_spain` when available,
 * along with a flag indicating whether the swap happened.
 *
 * Returns `null` if the underlying (k, q, s) tuple is unavailable, matching
 * `resolveMarkerParams` semantics.
 */
export function resolveMarkerParamsWithRecalibration(
  entry: KdmLibraryMarker,
  sex: Sex,
): { params: KdmMarkerParams; spanishRecalibrationApplied: boolean } | null {
  const baseParams = resolveMarkerParams(entry, sex);
  if (!baseParams) return null;

  const qSpain = resolveSpanishRecalibratedQ(entry, sex);
  if (qSpain === null) {
    return { params: baseParams, spanishRecalibrationApplied: false };
  }

  return {
    params: { ...baseParams, q: qSpain },
    spanishRecalibrationApplied: true,
  };
}

// ─── Fructosamine derivation (B.9) ───

/**
 * Spanish marker key for Fructosamine in the KDM library.
 */
export const FRUCTOSAMINE_KDM_KEY = "Fructosamina";

/**
 * Spanish marker key for HbA1c in the KDM library.
 */
export const HBA1C_KDM_KEY = "HbA1c (Hemoglobina Glicosilada)";

/**
 * Derive Fructosamine from HbA1c via the locked Cohen 2010 formula:
 *
 *   Fructosamine (µmol/L) = 19.97 × HbA1c (%) − 39.4
 *
 * Spec rationale: Fructosamine measures the same underlying physiology as
 * HbA1c (mean glucose exposure over ~14-21 days vs ~3 months) on a
 * different timescale. The Cohen et al. 2010 mapping converts between
 * the two so that lab panels containing HbA1c but not Fructosamine still
 * contribute a Fructosamine value to the KDM estimator.
 *
 * If `inputs` already contains Fructosamine, this function returns the
 * map unchanged (caller's measured value wins). If HbA1c is missing, the
 * map is returned unchanged (nothing to derive from).
 *
 * Caller pattern (used in B.10/B.13):
 *   const adapted = kdmInputsFromBiomarkerValues(values);
 *   const filled = deriveFructosamineIfMissing(adapted.inputs);
 *   const ba = computeReferenceBA(filled, sex, age);
 */
export function deriveFructosamineIfMissing(
  inputs: Record<string, number>,
): Record<string, number> {
  if (FRUCTOSAMINE_KDM_KEY in inputs) return inputs;

  const hba1c = inputs[HBA1C_KDM_KEY];
  if (typeof hba1c !== "number" || !Number.isFinite(hba1c)) return inputs;

  const derived = 19.97 * hba1c - 39.4;
  if (!Number.isFinite(derived)) return inputs;

  return { ...inputs, [FRUCTOSAMINE_KDM_KEY]: derived };
}

/**
 * Which trained panel to use s_ca for: `"reference"` (14-marker base panel)
 * or `"comprehensive"` (full trained panel).
 */
export type SCaTier = "reference" | "comprehensive";

/**
 * Per-stratum s_ca lookup from `data/kdm_s_ca.json`.
 *
 * Returns the male/female/pooled `SCaPooled` block for the requested tier,
 * ready to hand to `klemeraDoubalBa`. Throws if the JSON shape is
 * unexpectedly missing the tier (configuration bug).
 */
export function resolveSCa(tier: SCaTier): SCaPooled {
  const block = (sCaData as Record<string, unknown>)[tier];
  if (!block || typeof block !== "object") {
    throw new Error(`kdm_s_ca.json: missing tier "${tier}"`);
  }
  const b = block as Record<string, unknown>;
  return {
    male: typeof b.male === "number" ? b.male : undefined,
    female: typeof b.female === "number" ? b.female : undefined,
    pooled: typeof b.pooled === "number" ? b.pooled : undefined,
  };
}

// ─── Library access ───

/** Typed view of the bundled marker library JSON. */
const library = libraryData as unknown as {
  meta: {
    base_panel: string[];
    sex_stratified_markers: string[];
  };
  markers: Record<string, KdmLibraryMarker>;
};

/** The 14-marker base panel (KDM v2.2). Sourced from `marker_library_v2_2.json::meta.base_panel`. */
export const BASE_PANEL: readonly string[] = library.meta.base_panel;

/** Albumin and Creatinine are MANDATORY for KDM gating (Klemera & Doubal 2006 anchoring requirement). */
export const MANDATORY_BASE_MARKERS = [
  "Albúmina",
  "Creatinina",
] as const;

/** Minimum count of base-panel markers required to compute a KDM result. */
export const MIN_BASE_PANEL_MARKERS = 8;

// ─── Gating helper (B.10) ───

/**
 * Apply KDM v2.2 gating to a KDM-keyed input map.
 *
 * Mirrors `kdm_training.py` lines 391-395 / 430-434:
 *   - At least 8 of the 14 base-panel markers present
 *   - Albúmina present
 *   - Creatinina present (or Cistatina C — see below)
 *
 * Returns `true` to proceed, `false` to abort with a null result.
 *
 * --- Cystatin C substitution (Path B / v2.2.1 addition) ---
 * When `applyLifestyleAdjustments` drops creatinine because Cystatin C
 * is available (Cystatin C is unaffected by muscle mass / creatine), we
 * accept Cystatin C as the kidney-function gate marker. The 8-of-14 base-
 * panel count is unaffected — Cystatin C is NOT a base-panel marker, so
 * it counts via the Creatinine slot only.
 */
export function passesKdmGate(inputs: Record<string, number>): boolean {
  // Mandatory Albumin
  const alb = inputs["Albúmina"];
  if (typeof alb !== "number" || !Number.isFinite(alb)) return false;

  // Mandatory kidney marker: Creatinine OR Cystatin C
  const creat = inputs["Creatinina"];
  const cysc = inputs["Cistatina C"];
  const hasKidneyMarker =
    (typeof creat === "number" && Number.isFinite(creat)) ||
    (typeof cysc === "number" && Number.isFinite(cysc));
  if (!hasKidneyMarker) return false;

  // ≥ 8 of 14 base-panel markers. When Creatinine was dropped because
  // Cystatin C is the kidney marker, count Cystatin C in its place so the
  // panel-size requirement still maps to "≥ 8 of 14 informative markers".
  let basePresent = BASE_PANEL.filter((m) => {
    const v = inputs[m];
    return typeof v === "number" && Number.isFinite(v);
  }).length;
  const creatPresent = typeof creat === "number" && Number.isFinite(creat);
  const cyscPresent = typeof cysc === "number" && Number.isFinite(cysc);
  if (!creatPresent && cyscPresent) {
    // Cystatin C substitutes for Creatinine in the count.
    basePresent += 1;
  }
  return basePresent >= MIN_BASE_PANEL_MARKERS;
}

// ─── Internal compute helper ───

/**
 * Common path for Reference / Comprehensive BA — runs gating, resolves
 * per-marker params (with sex stratification + Spanish recalibration),
 * and calls the joint estimator.
 *
 * `restrictToBasePanel`:
 *   - true  → only base-panel markers contribute (Reference BA)
 *   - false → every KDM-mapped marker contributes (Comprehensive BA)
 */
function computeBa(
  kdmInputs: Record<string, number>,
  sex: Sex,
  age: number,
  tier: SCaTier,
  restrictToBasePanel: boolean,
): KdmReferenceBAResult {
  if (!passesKdmGate(kdmInputs)) return null;

  const params: Record<string, KdmMarkerParams> = {};
  const applied: string[] = [];
  const considerSet = restrictToBasePanel ? new Set(BASE_PANEL) : null;

  for (const markerKey of Object.keys(kdmInputs)) {
    if (considerSet && !considerSet.has(markerKey)) continue;
    const entry = library.markers[markerKey];
    if (!entry) continue;
    const resolved = resolveMarkerParamsWithRecalibration(entry, sex);
    if (!resolved) continue;

    // Apply Path B parameter overrides for markers whose `s` was tightened
    // by Phase 1 winsorization. Spanish recalibration's q swap stays
    // applied; Path B replaces (k, s) and the NHANES q baseline only when
    // no Spanish q_spain was substituted (otherwise the recalibrated q
    // wins).
    const override = pathBLookup(markerKey, sex);
    if (override) {
      params[markerKey] = {
        k: override.k,
        // Spanish q wins if it was applied; otherwise use Path B's q.
        q: resolved.spanishRecalibrationApplied ? resolved.params.q : override.q,
        s: override.s,
        log_transformed: resolved.params.log_transformed,
      };
    } else {
      params[markerKey] = resolved.params;
    }
    if (resolved.spanishRecalibrationApplied) applied.push(markerKey);
  }

  if (Object.keys(params).length === 0) return null;

  const sCa = resolveSCa(tier);
  const ba = klemeraDoubalBa(kdmInputs, params, age, true, sCa, sex);
  if (!ba) return null;

  return {
    BA: ba.BA,
    BA_E: ba.BA_E,
    s_BA: ba.s_BA,
    n_markers_used: ba.n_markers_used,
    used_markers: ba.used_markers,
    applied_spanish_recalibration_markers: applied.filter((m) =>
      ba.used_markers.includes(m),
    ),
  };
}

// ─── Public API ───

/**
 * Optional patient context used by the KDM pipeline for lifestyle
 * adjustments (creatine supplementation, etc.) and for the Cystatin-C-
 * preferred kidney-marker selection.
 */
export interface KdmPatientContext {
  /** Patient supplements list from `patient_context_versions.supplements`. */
  supplements?: SupplementEntry[] | null;
}

/**
 * Adjust the KDM-keyed input map for lifestyle / measurement artifacts that
 * KDM cannot otherwise distinguish from biological aging:
 *
 *  - Creatine supplementation raises serum creatinine without affecting
 *    kidney function. Subtract a dose-dependent offset from creatinine
 *    before the joint estimator sees it.
 *  - When Cystatin C is present, drop creatinine entirely from the KDM
 *    input. Cystatin C is unaffected by muscle mass / creatine and is the
 *    strictly better kidney-aging biomarker.
 *
 * Returns a NEW object — does not mutate the input.
 */
export function applyLifestyleAdjustments(
  inputs: Record<string, number>,
  context: KdmPatientContext | null | undefined,
): Record<string, number> {
  const out = { ...inputs };

  // Cystatin-C-preferred: if Cystatin C present, drop creatinine entirely.
  if (
    typeof out["Cistatina C"] === "number" &&
    Number.isFinite(out["Cistatina C"])
  ) {
    delete out["Creatinina"];
    return out;
  }

  // Otherwise, apply creatine-dose-aware creatinine offset.
  if (typeof out["Creatinina"] === "number" && Number.isFinite(out["Creatinina"])) {
    const offset = creatinineOffsetFromSupplements(context?.supplements ?? null);
    if (offset > 0) {
      out["Creatinina"] = Math.max(0, out["Creatinina"] - offset);
    }
  }

  return out;
}

/**
 * Reference Biological Age — 14-marker base-panel joint estimator.
 *
 * Pipeline:
 *   1. `kdmInputsFromBiomarkerValues` — map engine codes / DB keys to KDM keys
 *   2. `deriveFructosamineIfMissing` — Cohen 2010 from HbA1c
 *   3. `applyLifestyleAdjustments` — creatine offset / Cystatin-C-preferred
 *   4. `passesKdmGate` — ≥ 8 of 14 base + Albúmina + Creatinina
 *   5. `resolveMarkerParamsWithRecalibration` (+ Path B override) per marker
 *   6. `klemeraDoubalBa` with Reference-tier s_ca
 *
 * Returns `null` when gating fails.
 */
export function computeReferenceBA(
  values: BiomarkerInput[],
  sex: Sex,
  age: number,
  context?: KdmPatientContext | null,
): KdmReferenceBAResult {
  if (!Number.isFinite(age) || age <= 0) return null;
  const adapted = kdmInputsFromBiomarkerValues(values);
  const filled = deriveFructosamineIfMissing(adapted.inputs);
  const adjusted = applyLifestyleAdjustments(filled, context);
  return computeBa(adjusted, sex, age, "reference", true);
}

/**
 * Comprehensive Biological Age — full-panel joint estimator.
 *
 * Same pipeline as `computeReferenceBA` but the joint estimator runs over
 * every KDM-mapped marker (not just the 14-marker base panel). Used as a
 * supplementary metric when the user has uploaded an extended panel.
 *
 * Returns `null` when gating fails.
 */
export function computeComprehensiveBA(
  values: BiomarkerInput[],
  sex: Sex,
  age: number,
  context?: KdmPatientContext | null,
): KdmComprehensiveBAResult {
  if (!Number.isFinite(age) || age <= 0) return null;
  const adapted = kdmInputsFromBiomarkerValues(values);
  const filled = deriveFructosamineIfMissing(adapted.inputs);
  const adjusted = applyLifestyleAdjustments(filled, context);
  return computeBa(adjusted, sex, age, "comprehensive", false);
}
