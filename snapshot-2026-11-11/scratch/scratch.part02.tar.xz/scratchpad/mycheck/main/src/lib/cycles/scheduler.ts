/**
 * Cycle-scheduler decision logic (F4) — THE only creator of test cycles.
 *
 * Golden rule 2 (docs/lab-integration-message-logistics.md): payments never
 * create kits; Stripe webhooks only maintain the entitlement columns
 * (plan / paid_until / subscription_status / full_panel_purchased_at) and the
 * daily cron asks one question per user: does the entitlement cover a cycle
 * that is due, with no cycle currently open?
 *
 * This module is PURE (no I/O, clock injected) so the cadence rules are unit
 * tested exhaustively; the cron route wires it to the service-role client.
 * Idempotency is structural: the one_open_cycle_per_user partial unique index
 * makes a double-insert impossible — the route treats 23505 as "already open".
 */

/** Days between draws on a subscription (quarterly cadence anchor). */
export const CYCLE_CADENCE_DAYS = 90;

export interface SchedulerProfile {
  id: string;
  /** Sequential identity (profiles.patient_number) → NHC + placer prefix. */
  patient_number: number;
  subscription_status: string | null;
  plan: string | null;
  /** YYYY-MM-DD — entitlement covered through this date (Stripe webhook). */
  paid_until: string | null;
  full_panel_purchased_at: string | null;
  next_panel_type: string | null;
}

export interface SchedulerCycle {
  seq: number;
  status: string;
  panel_type: string;
  extraction_confirmed_at: string | null;
  created_at: string;
}

export interface CycleToCreate {
  seq: number;
  panel_type: string;
  /** YYYY-MM-DD */
  due_date: string;
  placer_order_number: string;
}

const OPEN_STATUSES_EXCLUDED = new Set(["completed", "cancelled"]);

function isOpen(c: SchedulerCycle): boolean {
  return !OPEN_STATUSES_EXCLUDED.has(c.status);
}

function isoDate(d: Date): string {
  return d.toISOString().split("T")[0];
}

function addDays(iso: string, days: number): string {
  const d = new Date(`${iso.split("T")[0]}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return isoDate(d);
}

/**
 * eva's placer order number (OML ORC.2.1, echoed back in the ORU — the
 * matching key) lives in ./identifiers: short alphanumeric, derived from
 * profiles.patient_number + cycle seq, per ECH's format rules (2026-09-07).
 */
import { buildPlacerOrderNumber } from "./identifiers";
export { buildPlacerOrderNumber };

/**
 * Decide whether ONE new cycle is due for this user today. Returns the row to
 * insert, or null with a reason (for the cron's structured logs).
 */
export function decideNextCycle(
  profile: SchedulerProfile,
  cycles: SchedulerCycle[],
  today: string,
): { create: CycleToCreate | null; reason: string } {
  if (cycles.some(isOpen)) {
    return { create: null, reason: "open-cycle-exists" };
  }

  const nextSeq = cycles.reduce((m, c) => Math.max(m, c.seq), 0) + 1;

  // One-time Full Panel purchase → one full-panel cycle, independent of the
  // subscription entitlement. full_panel_purchased_at is never cleared, so the
  // "already served" marker is the existence of a full-panel cycle.
  const hasFullCycle = cycles.some((c) => c.panel_type === "full");
  if (profile.full_panel_purchased_at && !hasFullCycle) {
    return {
      create: {
        seq: nextSeq,
        panel_type: "full",
        due_date: today,
        placer_order_number: buildPlacerOrderNumber(profile.patient_number, nextSeq),
      },
      reason: "full-panel-purchase",
    };
  }

  // Subscription cadence. Entitlement must cover TODAY: active status and a
  // paid_until on/after today. past_due/cancelled never create cycles; a
  // paid_until in the past means a lost/lapsed entitlement — also no cycle.
  const entitled =
    profile.subscription_status === "active" &&
    (profile.plan === "quarterly" || profile.plan === "annual") &&
    !!profile.paid_until &&
    profile.paid_until >= today;
  if (!entitled) {
    return { create: null, reason: "not-entitled" };
  }

  // First cycle: due immediately after the first payment.
  // Subsequent cycles: 90 days after the previous draw (clinical anchor =
  // confirmed extraction; fallback = the previous cycle's creation).
  const last = cycles.reduce<SchedulerCycle | null>(
    (best, c) => (!best || c.seq > best.seq ? c : best),
    null,
  );
  const dueDate = last
    ? addDays(last.extraction_confirmed_at ?? last.created_at, CYCLE_CADENCE_DAYS)
    : today;
  if (dueDate > today) {
    return { create: null, reason: `next-due-${dueDate}` };
  }

  return {
    create: {
      seq: nextSeq,
      panel_type: profile.next_panel_type || "base",
      due_date: dueDate,
      placer_order_number: buildPlacerOrderNumber(profile.patient_number, nextSeq),
    },
    reason: last ? "cadence-due" : "first-cycle",
  };
}

/** Thresholds for the stuck-cycle alert sweep (days). */
export const STUCK_THRESHOLDS = {
  /** shipped but never activated */
  shippedNoActivation: 10,
  /** order_sent with no ACK (hours) */
  orderSentNoAckHours: 48,
  /** activated but no result yet */
  activatedNoResult: 21,
} as const;
