import { createClient } from "@/lib/supabase/server";
import { ZONE_CONFIG, type Zone } from "./zone-config";

// Re-export client-safe types and config
export { ZONE_CONFIG, type Zone };

// ─── Age group matching ───

const AGE_BRACKETS = [
  { label: "18-25", min: 18, max: 25 },
  { label: "26-35", min: 26, max: 35 },
  { label: "36-45", min: 36, max: 45 },
  { label: "46-55", min: 46, max: 55 },
  { label: "56-65", min: 56, max: 65 },
  { label: "66-75", min: 66, max: 75 },
  { label: "76-85", min: 76, max: 85 },
  { label: "86-95", min: 86, max: 95 },
  { label: "96-100+", min: 96, max: 200 },
] as const;

/**
 * Parse a date-of-birth string tolerantly. Handles:
 *   - ISO: "1990-03-15" or "1990-03-15T00:00:00Z"
 *   - European: "15/03/1990" or "15-03-1990"
 *   - US: "03/15/1990" (only when unambiguous — month > 12 on the EU side)
 *   - Reverse: "1990/03/15"
 * Returns a valid Date or null.
 */
export function parseDateOfBirth(dob: string): Date | null {
  if (!dob || typeof dob !== "string") return null;
  const trimmed = dob.trim();

  // 1. ISO date (YYYY-MM-DD, optionally with time)
  const isoMatch = trimmed.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (isoMatch) {
    const [, y, m, d] = isoMatch;
    const date = new Date(Number(y), Number(m) - 1, Number(d));
    return isNaN(date.getTime()) ? null : date;
  }

  // 2. YYYY/MM/DD
  const revSlash = trimmed.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (revSlash) {
    const [, y, m, d] = revSlash;
    const date = new Date(Number(y), Number(m) - 1, Number(d));
    return isNaN(date.getTime()) ? null : date;
  }

  // 3. DD/MM/YYYY or DD-MM-YYYY (European — our default in the UI)
  const euMatch = trimmed.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
  if (euMatch) {
    const [, aStr, bStr, yStr] = euMatch;
    const a = Number(aStr);
    const b = Number(bStr);
    const y = Number(yStr);
    // If "a" > 12 it can't be a month — it's DD/MM/YYYY
    // If "b" > 12 it can't be a month — must be MM/DD/YYYY
    // Otherwise default to European DD/MM/YYYY (placeholder hint matches)
    let day: number, month: number;
    if (a > 12) { day = a; month = b; }
    else if (b > 12) { day = b; month = a; }
    else { day = a; month = b; }
    const date = new Date(y, month - 1, day);
    return isNaN(date.getTime()) ? null : date;
  }

  // 4. Last resort: let Date parse it
  const fallback = new Date(trimmed);
  return isNaN(fallback.getTime()) ? null : fallback;
}

export function calculateAge(dob: string): number {
  const birth = parseDateOfBirth(dob);
  if (!birth) return NaN;
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

function getAgeGroupLabel(age: number): string {
  for (const bracket of AGE_BRACKETS) {
    if (age >= bracket.min && age <= bracket.max) return bracket.label;
  }
  return "18-25";
}

// ─── Reference range type ───

export interface BiomarkerReference {
  biomarker_key: string;
  sex: string;
  age_group_en: string;
  normal_low: number | null;
  normal_high: number | null;
  optimal_low: number | null;
  optimal_high: number | null;
  msg_critical_low_en: string | null;
  msg_critical_low_es: string | null;
  msg_below_optimal_en: string | null;
  msg_below_optimal_es: string | null;
  msg_optimal_en: string | null;
  msg_optimal_es: string | null;
  msg_above_optimal_en: string | null;
  msg_above_optimal_es: string | null;
  msg_critical_high_en: string | null;
  msg_critical_high_es: string | null;
}

// ─── Classification result ───

export interface ZoneResult {
  zone: Zone;
  biomarkerKey: string;
  value: number;
  optimalLow: number | null;
  optimalHigh: number | null;
  normalLow: number | null;
  normalHigh: number | null;
  message_en: string | null;
  message_es: string | null;
}

// ─── Core zone logic ───

export function classifyZone(
  value: number,
  optimalLow: number | null,
  optimalHigh: number | null,
  normalLow: number | null,
  normalHigh: number | null,
): Zone {
  // Check critical boundaries first (using normal range as critical proxy)
  // 1. Critical low
  if (normalLow != null && value < normalLow) {
    return "critical_low";
  }

  // 2. Below optimal (above or at critical low, below optimal low)
  if (optimalLow != null && value < optimalLow) {
    return "below_optimal";
  }

  // 3. Optimal
  const aboveLow = optimalLow == null || value >= optimalLow;
  const belowHigh = optimalHigh == null || value <= optimalHigh;
  if (aboveLow && belowHigh) {
    return "optimal";
  }

  // 4. Above optimal (below or at critical high)
  if (optimalHigh != null && value > optimalHigh) {
    if (normalHigh != null && value > normalHigh) {
      return "critical_high";
    }
    return "above_optimal";
  }

  return "optimal";
}

function getZoneMessage(
  zone: Zone,
  ref: BiomarkerReference,
): { en: string | null; es: string | null } {
  switch (zone) {
    case "critical_low":
      return { en: ref.msg_critical_low_en, es: ref.msg_critical_low_es };
    case "below_optimal":
      return { en: ref.msg_below_optimal_en, es: ref.msg_below_optimal_es };
    case "optimal":
      return { en: ref.msg_optimal_en, es: ref.msg_optimal_es };
    case "above_optimal":
      return { en: ref.msg_above_optimal_en, es: ref.msg_above_optimal_es };
    case "critical_high":
      return { en: ref.msg_critical_high_en, es: ref.msg_critical_high_es };
    default:
      return { en: null, es: null };
  }
}

// ─── Main classifier ───

export async function classifyBiomarker(
  biomarkerKey: string,
  value: number | null | undefined,
  sex: string,
  dateOfBirth: string,
): Promise<ZoneResult> {
  const empty: ZoneResult = {
    zone: "unclassified",
    biomarkerKey,
    value: value ?? 0,
    optimalLow: null,
    optimalHigh: null,
    normalLow: null,
    normalHigh: null,
    message_en: null,
    message_es: null,
  };

  if (value == null || !isFinite(value)) {
    return empty;
  }

  const age = calculateAge(dateOfBirth);
  const ageGroup = getAgeGroupLabel(age);
  const sexNorm = sex.toLowerCase();

  const supabase = await createClient();

  // Try exact sex match first, then 'both'
  const { data: refs } = await supabase
    .from("biomarker_references")
    .select("*")
    .eq("biomarker_key", biomarkerKey)
    .eq("age_group_en", ageGroup)
    .in("sex", [sexNorm, "both"]);

  if (!refs || refs.length === 0) {
    console.warn(
      `[zone-classifier] No reference found for ${biomarkerKey}, sex=${sexNorm}, age_group=${ageGroup}`,
    );
    return empty;
  }

  // Prefer exact sex match over 'both'
  const ref =
    (refs.find((r) => r.sex === sexNorm) as BiomarkerReference | undefined) ??
    (refs[0] as BiomarkerReference);

  const zone = classifyZone(
    value,
    ref.optimal_low,
    ref.optimal_high,
    ref.normal_low,
    ref.normal_high,
  );

  const msgs = getZoneMessage(zone, ref);

  return {
    zone,
    biomarkerKey,
    value,
    optimalLow: ref.optimal_low,
    optimalHigh: ref.optimal_high,
    normalLow: ref.normal_low,
    normalHigh: ref.normal_high,
    message_en: msgs.en,
    message_es: msgs.es,
  };
}

// ─── Batch classifier ───

export async function classifyBiomarkers(
  biomarkers: Array<{ biomarker_key: string; value: number }>,
  sex: string,
  dateOfBirth: string,
): Promise<ZoneResult[]> {
  return Promise.all(
    biomarkers.map((b) =>
      classifyBiomarker(b.biomarker_key, b.value, sex, dateOfBirth),
    ),
  );
}
