/**
 * Biomarker name fuzzy matcher.
 *
 * Labs report names inconsistently. This resolves raw names to canonical
 * biomarker_key values — the slugified keys that actually exist in
 * biomarker_references (see supabase/seed-data/*.json → seed-references.ts).
 *
 * IMPORTANT: every key this matcher can emit MUST be a real seed key.
 * The matcher used to emit "convenient" short keys ("fasting_insulin",
 * "apolipoprotein_b", "cortisol_am") that the seed never had — the
 * extract route then either guessed wrong via substring fallback or the
 * /confirm allow-list rejected the whole upload. Keys here are now the
 * verbatim seed slugs.
 *
 * Priority: 1) Exact, 2) Alias, 3) Fuzzy (guarded), 4) null
 */

// ─── Canonical biomarker keys (verbatim slugs from biomarker_references) ───

const ALL_KEYS = new Set([
  // CBC / Blood
  "white_blood_cell_count", "red_blood_cell_count", "hemoglobin", "hematocrit",
  "platelet_count", "mcv", "mch", "mchc", "rdw", "mpv",
  "neutrophils", "neutrophils_absolute", "lymphocytes", "lymphocytes_absolute",
  "monocytes", "monocytes_absolute", "eosinophils", "eosinophils_absolute",
  "basophils", "basophils_absolute", "abo_group_and_rh_factor",
  // Metabolic
  "glucose_fasting", "hba1c", "insulin_fasting", "leptin",
  // Lipids
  "total_cholesterol", "ldl_cholesterol", "hdl_cholesterol", "triglycerides",
  "non_hdl_cholesterol", "apolipoprotein_b_apob", "lipoproteina",
  "total_cholesterol_hdl_ratio", "ldl_particle_number", "ldl_pattern",
  "ldl_peak_size", "ldl_small", "ldl_medium", "hdl_large",
  // Inflammatory
  "hs_crp", "homocysteine",
  // Liver
  "alt", "ast", "ggt", "alp", "total_bilirubin", "albumin", "globulin",
  "total_protein", "albumin_globulin_ratio",
  // Kidney
  "creatinine", "uric_acid", "egfr_creatinine_based", "bun", "urea",
  "bun_creatinine_ratio", "microalbumin_urine",
  // Thyroid
  "tsh", "free_t4_thyroxine", "free_t3_triiodothyronine",
  "thyroid_peroxidase_antibodies_tpo", "thyroglobulin_antibodies_tgab",
  // Iron
  "ferritin", "iron_serum", "iron_binding_capacity_tibc", "iron_saturation_tsat",
  // Vitamins & minerals
  "vitamin_d_25_oh", "vitamin_b12", "magnesium_serum", "zinc_serum",
  "calcium_serum",
  // Omega
  "omega_3_total", "omega_3_epa", "omega_3_dha", "omega_3_dpa",
  "omega_6_total", "omega_6_linoleic_acid", "omega_6_arachidonic_acid",
  "omega_6_omega_3_ratio", "arachidonic_acid_epa_ratio",
  // Hormones
  "testosterone_total", "testosterone_free", "estradiol", "dhea_sulfate",
  "cortisol_morning_8am", "shbg", "fsh", "luteinizing_hormone_lh", "prolactin",
  "anti_mullerian_hormone_amh",
  // Autoimmune
  "ana_screen", "ana_titer", "ana_pattern", "rheumatoid_factor_rf",
  // Pancreas
  "amylase", "lipase",
  // Specialty / advanced
  "methylmalonic_acid_mma", "psa_total", "psa_free",
  // Environmental
  "lead_blood", "mercury_blood",
]);

// ─── Alias map (EN + ES + common lab variants → seed keys) ───
//
// Every value here is a real biomarker_references key. Keys (the left
// side) are stored in the SAME normalized form normalize() produces:
// lowercase, accents stripped, parentheses removed, no punctuation
// except spaces/hyphens.

const ALIASES: Record<string, string> = {
  // ── CBC ──
  "leucocitos": "white_blood_cell_count", "recuento de leucocitos": "white_blood_cell_count",
  "globulos blancos": "white_blood_cell_count", "recuento de globulos blancos": "white_blood_cell_count",
  "white blood cells": "white_blood_cell_count", "white blood cell count": "white_blood_cell_count",
  "wbc": "white_blood_cell_count", "leucocitos totales": "white_blood_cell_count",
  "hematies": "red_blood_cell_count", "eritrocitos": "red_blood_cell_count",
  "globulos rojos": "red_blood_cell_count", "recuento de globulos rojos": "red_blood_cell_count",
  "recuento de hematies": "red_blood_cell_count", "red blood cells": "red_blood_cell_count",
  "red blood cell count": "red_blood_cell_count", "rbc": "red_blood_cell_count", "hematie": "red_blood_cell_count",
  "hemoglobina": "hemoglobin", "hemoglobin": "hemoglobin", "hb": "hemoglobin", "hgb": "hemoglobin",
  "hematocrito": "hematocrit", "hematocrit": "hematocrit", "hto": "hematocrit", "hct": "hematocrit",
  "plaquetas": "platelet_count", "recuento de plaquetas": "platelet_count", "platelets": "platelet_count",
  "platelet count": "platelet_count", "plt": "platelet_count", "trombocitos": "platelet_count",
  "vcm": "mcv", "volumen corpuscular medio": "mcv", "mean corpuscular volume": "mcv",
  "hcm": "mch", "hemoglobina corpuscular media": "mch", "mean corpuscular hemoglobin": "mch",
  "chcm": "mchc", "cmhc": "mchc", "concentracion de hemoglobina corpuscular media": "mchc",
  "mean corpuscular hemoglobin concentration": "mchc",
  "ade": "rdw", "amplitud de distribucion eritrocitaria": "rdw",
  "red cell distribution width": "rdw", "ancho de distribucion eritrocitaria": "rdw",
  "vpm": "mpv", "volumen plaquetario medio": "mpv", "mean platelet volume": "mpv",
  "neutrofilos": "neutrophils", "neutrophils": "neutrophils", "segmentados": "neutrophils",
  "neutrofilos absolutos": "neutrophils", "neutrofilos totales": "neutrophils",
  "linfocitos": "lymphocytes", "lymphocytes": "lymphocytes", "linfocitos absolutos": "lymphocytes",
  "monocitos": "monocytes", "monocytes": "monocytes", "monocitos absolutos": "monocytes",
  "eosinofilos": "eosinophils", "eosinophils": "eosinophils", "eosinofilos absolutos": "eosinophils",
  "basofilos": "basophils", "basophils": "basophils", "basofilos absolutos": "basophils",
  "grupo sanguineo": "abo_group_and_rh_factor", "grupo abo y factor rh": "abo_group_and_rh_factor",

  // ── Metabolic ──
  "glucosa": "glucose_fasting", "glucosa basal": "glucose_fasting", "glucosa en ayunas": "glucose_fasting",
  "glucemia": "glucose_fasting", "glucemia basal": "glucose_fasting", "glucemia en ayunas": "glucose_fasting",
  "fasting glucose": "glucose_fasting", "blood glucose": "glucose_fasting", "glucose": "glucose_fasting",
  "glucosa serica": "glucose_fasting", "glucosa ayunas": "glucose_fasting",
  "hba1c": "hba1c", "hemoglobina glicosilada": "hba1c", "hemoglobina glicada": "hba1c",
  "hemoglobina a1c": "hba1c", "a1c": "hba1c", "hb a1c": "hba1c", "glycated hemoglobin": "hba1c",
  "glycosylated hemoglobin": "hba1c", "hemoglobin a1c": "hba1c", "hemoglobina glucosilada": "hba1c",
  "insulina": "insulin_fasting", "insulina basal": "insulin_fasting", "insulina en ayunas": "insulin_fasting",
  "fasting insulin": "insulin_fasting", "insulin": "insulin_fasting", "insulinemia": "insulin_fasting",
  "insulina ayunas": "insulin_fasting",
  "leptina": "leptin", "leptin": "leptin",

  // ── Lipids ──
  "colesterol total": "total_cholesterol", "colesterol": "total_cholesterol",
  "total cholesterol": "total_cholesterol", "cholesterol": "total_cholesterol",
  "colesterol serico": "total_cholesterol",
  "colesterol ldl": "ldl_cholesterol", "ldl colesterol": "ldl_cholesterol",
  "ldl-colesterol": "ldl_cholesterol", "ldl cholesterol": "ldl_cholesterol",
  "ldl-c": "ldl_cholesterol", "ldl": "ldl_cholesterol", "c-ldl": "ldl_cholesterol",
  "colesterol de baja densidad": "ldl_cholesterol", "ldl colesterol calculado": "ldl_cholesterol",
  "colesterol hdl": "hdl_cholesterol", "hdl colesterol": "hdl_cholesterol",
  "hdl-colesterol": "hdl_cholesterol", "hdl cholesterol": "hdl_cholesterol",
  "hdl-c": "hdl_cholesterol", "hdl": "hdl_cholesterol", "c-hdl": "hdl_cholesterol",
  "colesterol de alta densidad": "hdl_cholesterol",
  "colesterol no hdl": "non_hdl_cholesterol", "colesterol no-hdl": "non_hdl_cholesterol",
  "non hdl cholesterol": "non_hdl_cholesterol", "non-hdl cholesterol": "non_hdl_cholesterol",
  "no hdl": "non_hdl_cholesterol",
  "trigliceridos": "triglycerides", "triglycerides": "triglycerides", "tg": "triglycerides",
  "trigliceridemia": "triglycerides",
  "apolipoproteina b": "apolipoprotein_b_apob", "apolipoprotein b": "apolipoprotein_b_apob",
  "apo b": "apolipoprotein_b_apob", "apob": "apolipoprotein_b_apob", "apo-b": "apolipoprotein_b_apob",
  "apolipoproteina b apob": "apolipoprotein_b_apob",
  "lipoproteina a": "lipoproteina", "lipoprotein a": "lipoproteina", "lp a": "lipoproteina",
  "lpa": "lipoproteina", "lipoprotein": "lipoproteina", "lipoproteina": "lipoproteina",
  "indice aterogenico": "total_cholesterol_hdl_ratio",
  "ratio colesterol total hdl": "total_cholesterol_hdl_ratio",
  "cociente colesterol total hdl": "total_cholesterol_hdl_ratio",

  // ── Inflammatory ──
  "pcr": "hs_crp", "proteina c reactiva": "hs_crp", "pcr ultrasensible": "hs_crp",
  "proteina c reactiva ultrasensible": "hs_crp", "pcr-us": "hs_crp", "pcr us": "hs_crp",
  "hs-crp": "hs_crp", "hscrp": "hs_crp", "high sensitivity crp": "hs_crp",
  "c-reactive protein": "hs_crp", "crp": "hs_crp", "pcr alta sensibilidad": "hs_crp",
  "pcr de alta sensibilidad": "hs_crp", "proteina c reactiva alta sensibilidad": "hs_crp",
  "proteina c reactiva pcr ultrasensible": "hs_crp",
  "homocisteina": "homocysteine", "homocysteine": "homocysteine", "homocisteina total": "homocysteine",

  // ── Liver ──
  "alanina aminotransferasa": "alt", "gpt": "alt", "alat": "alt", "sgpt": "alt", "tgp": "alt",
  "alanine aminotransferase": "alt", "transaminasa gpt": "alt", "gpt alt": "alt",
  "aspartato aminotransferasa": "ast", "got": "ast", "asat": "ast", "sgot": "ast", "tgo": "ast",
  "aspartate aminotransferase": "ast", "transaminasa got": "ast", "got ast": "ast",
  "gamma gt": "ggt", "gamma glutamil transferasa": "ggt", "gamma-glutamil transferasa": "ggt",
  "gamma glutamyl transferase": "ggt", "gamma-glutamyl transferase": "ggt", "ggtp": "ggt",
  "fosfatasa alcalina": "alp", "fosfatasas alcalinas": "alp", "alkaline phosphatase": "alp",
  "bilirrubina total": "total_bilirubin", "bilirrubina": "total_bilirubin",
  "total bilirubin": "total_bilirubin", "bilirubin": "total_bilirubin",
  "bilirrubina serica": "total_bilirubin",
  "albumina": "albumin", "albumin": "albumin", "albumina serica": "albumin", "serum albumin": "albumin",
  "globulina": "globulin", "globulin": "globulin", "globulinas": "globulin",
  "proteinas totales": "total_protein", "proteina total": "total_protein",
  "total protein": "total_protein", "proteinas": "total_protein",
  "ratio albumina globulina": "albumin_globulin_ratio",

  // ── Kidney ──
  "creatinina": "creatinine", "creatinine": "creatinine", "creatinina serica": "creatinine",
  "acido urico": "uric_acid", "uric acid": "uric_acid", "urato": "uric_acid",
  "filtrado glomerular": "egfr_creatinine_based", "filtrado glomerular estimado": "egfr_creatinine_based",
  "tasa de filtracion glomerular": "egfr_creatinine_based", "egfr": "egfr_creatinine_based",
  "tfg": "egfr_creatinine_based", "tfge": "egfr_creatinine_based", "estimated gfr": "egfr_creatinine_based",
  "ckd-epi": "egfr_creatinine_based", "indice de filtrado glomerular": "egfr_creatinine_based",
  // Urea (the whole molecule) and BUN (its nitrogen fraction) are now
  // separate biomarkers — Urea is what European/Spanish labs report
  // directly, BUN is the U.S. convention. Each has its own seed entry,
  // its own reference ranges and its own detail page. The conversion
  // (Urea × 0.4665 = BUN) only happens inside the KDM joint estimator,
  // which is anchored on BUN.
  "urea": "urea", "urea en sangre": "urea", "urea serica": "urea",
  "urea en suero": "urea",
  "bun": "bun", "nitrogeno ureico": "bun", "nitrogeno ureico en sangre": "bun",
  "blood urea nitrogen": "bun", "nitrogeno ureico sanguineo": "bun",
  "microalbumina": "microalbumin_urine", "microalbuminuria": "microalbumin_urine",
  "microalbumina en orina": "microalbumin_urine", "microalbumin": "microalbumin_urine",
  "albumina en orina": "microalbumin_urine",

  // ── Thyroid ──
  "tirotropina": "tsh", "hormona estimulante del tiroides": "tsh", "hormona tirotropa": "tsh",
  "thyroid stimulating hormone": "tsh", "tirotrofina": "tsh",
  "t4 libre": "free_t4_thyroxine", "free t4": "free_t4_thyroxine", "ft4": "free_t4_thyroxine",
  "tiroxina libre": "free_t4_thyroxine", "t4l": "free_t4_thyroxine", "free thyroxine": "free_t4_thyroxine",
  "t3 libre": "free_t3_triiodothyronine", "free t3": "free_t3_triiodothyronine",
  "ft3": "free_t3_triiodothyronine", "triyodotironina libre": "free_t3_triiodothyronine",
  "t3l": "free_t3_triiodothyronine", "free triiodothyronine": "free_t3_triiodothyronine",
  "anti-tpo": "thyroid_peroxidase_antibodies_tpo", "anticuerpos anti-tpo": "thyroid_peroxidase_antibodies_tpo",
  "anti tpo": "thyroid_peroxidase_antibodies_tpo", "anti-peroxidasa": "thyroid_peroxidase_antibodies_tpo",
  "anticuerpos antiperoxidasa": "thyroid_peroxidase_antibodies_tpo",
  "anticuerpos antiperoxidasa tiroidea": "thyroid_peroxidase_antibodies_tpo",
  "antiperoxidasa tiroidea": "thyroid_peroxidase_antibodies_tpo",
  "anti-peroxidasa tiroidea": "thyroid_peroxidase_antibodies_tpo",
  "thyroid peroxidase antibodies": "thyroid_peroxidase_antibodies_tpo",
  "anti-tiroglobulina": "thyroglobulin_antibodies_tgab", "anti-tg": "thyroglobulin_antibodies_tgab",
  "anti tg": "thyroglobulin_antibodies_tgab", "anticuerpos antitiroglobulina": "thyroglobulin_antibodies_tgab",
  "anticuerpos anti-tiroglobulina": "thyroglobulin_antibodies_tgab",
  "antitiroglobulina": "thyroglobulin_antibodies_tgab",
  "thyroglobulin antibodies": "thyroglobulin_antibodies_tgab",

  // ── Iron ──
  "ferritina": "ferritin", "ferritin": "ferritin", "ferritina serica": "ferritin",
  "hierro": "iron_serum", "hierro serico": "iron_serum", "iron": "iron_serum",
  "serum iron": "iron_serum", "sideremia": "iron_serum", "hierro en suero": "iron_serum",
  "saturacion de transferrina": "iron_saturation_tsat",
  "indice de saturacion de transferrina": "iron_saturation_tsat",
  "indice de saturacion de la transferrina": "iron_saturation_tsat",
  "transferrin saturation": "iron_saturation_tsat", "saturacion de hierro": "iron_saturation_tsat",
  "tsat": "iron_saturation_tsat", "saturacion transferrina": "iron_saturation_tsat",
  "capacidad total de fijacion del hierro": "iron_binding_capacity_tibc",
  "capacidad de fijacion del hierro": "iron_binding_capacity_tibc",
  "capacidad de fijacion de hierro": "iron_binding_capacity_tibc",
  "tibc": "iron_binding_capacity_tibc", "iron binding capacity": "iron_binding_capacity_tibc",
  "total iron binding capacity": "iron_binding_capacity_tibc",

  // ── Vitamins & minerals ──
  "vitamina d": "vitamin_d_25_oh", "vit d": "vitamin_d_25_oh", "25-oh vitamin d": "vitamin_d_25_oh",
  "25-hydroxyvitamin d": "vitamin_d_25_oh", "vitamina d 25-oh": "vitamin_d_25_oh",
  "25 oh d3": "vitamin_d_25_oh", "cholecalciferol": "vitamin_d_25_oh", "calcidiol": "vitamin_d_25_oh",
  "calcifediol": "vitamin_d_25_oh", "vitamin d": "vitamin_d_25_oh", "vit d3": "vitamin_d_25_oh",
  "25-oh d": "vitamin_d_25_oh", "vitamina d3": "vitamin_d_25_oh", "vitamina d total": "vitamin_d_25_oh",
  "25-hidroxivitamina d": "vitamin_d_25_oh", "25 hidroxi vitamina d": "vitamin_d_25_oh",
  "hidroxivitamina d": "vitamin_d_25_oh", "vitamina d 25 hidroxi": "vitamin_d_25_oh",
  "vitamina d 25 oh": "vitamin_d_25_oh", "25-oh-vitamina d": "vitamin_d_25_oh",
  "vitamina b12": "vitamin_b12", "vitamin b12": "vitamin_b12", "cobalamina": "vitamin_b12",
  "cianocobalamina": "vitamin_b12", "vit b12": "vitamin_b12", "vitamina b-12": "vitamin_b12",
  "magnesio": "magnesium_serum", "magnesium": "magnesium_serum", "magnesio serico": "magnesium_serum",
  "zinc": "zinc_serum", "zn": "zinc_serum", "zinc serico": "zinc_serum", "cinc": "zinc_serum",
  "calcio": "calcium_serum", "calcium": "calcium_serum", "calcio serico": "calcium_serum",
  "calcio total": "calcium_serum", "calcio en sangre": "calcium_serum",

  // ── Omega ──
  "omega 3": "omega_3_total", "omega-3": "omega_3_total", "omega 3 total": "omega_3_total",
  "indice omega 3": "omega_3_total", "indice de omega 3": "omega_3_total",
  "acidos grasos omega 3": "omega_3_total",
  "epa": "omega_3_epa", "acido eicosapentaenoico": "omega_3_epa", "eicosapentaenoic acid": "omega_3_epa",
  "dha": "omega_3_dha", "acido docosahexaenoico": "omega_3_dha", "docosahexaenoic acid": "omega_3_dha",
  "omega 6": "omega_6_total", "omega-6": "omega_6_total", "omega 6 total": "omega_6_total",

  // ── Hormones ──
  "testosterona": "testosterone_total", "testosterona total": "testosterone_total",
  "total testosterone": "testosterone_total",
  "testosterona libre": "testosterone_free", "free testosterone": "testosterone_free",
  "17-beta estradiol": "estradiol", "17 beta estradiol": "estradiol", "e2": "estradiol",
  "estradiol e2": "estradiol", "17b-estradiol": "estradiol",
  "dhea-s": "dhea_sulfate", "dhea sulfato": "dhea_sulfate", "dhea-sulfato": "dhea_sulfate",
  "sulfato de dhea": "dhea_sulfate", "dehidroepiandrosterona": "dhea_sulfate",
  "dehidroepiandrosterona sulfato": "dhea_sulfate", "dhea-sulfate": "dhea_sulfate",
  "dhea s": "dhea_sulfate", "dheas": "dhea_sulfate", "s-dhea": "dhea_sulfate",
  "sulfato de dehidroepiandrosterona": "dhea_sulfate",
  "cortisol": "cortisol_morning_8am", "cortisol matutino": "cortisol_morning_8am",
  "cortisol am": "cortisol_morning_8am", "cortisol morning": "cortisol_morning_8am",
  "cortisol basal": "cortisol_morning_8am", "cortisol 8am": "cortisol_morning_8am",
  "cortisol matinal": "cortisol_morning_8am", "cortisol serico": "cortisol_morning_8am",
  "morning cortisol": "cortisol_morning_8am",
  "globulina fijadora de hormonas sexuales": "shbg",
  "globulina transportadora de hormonas sexuales": "shbg",
  "globulina ligadora de hormonas sexuales": "shbg",
  "sex hormone binding globulin": "shbg", "sex hormone-binding globulin": "shbg",
  "hormona foliculoestimulante": "fsh", "hormona folicoestimulante": "fsh",
  "foliculo estimulante": "fsh", "follicle stimulating hormone": "fsh",
  "lh": "luteinizing_hormone_lh", "hormona luteinizante": "luteinizing_hormone_lh",
  "luteinizing hormone": "luteinizing_hormone_lh",
  "prolactina": "prolactin", "prolactin": "prolactin", "prl": "prolactin",
  "amh": "anti_mullerian_hormone_amh", "hormona antimulleriana": "anti_mullerian_hormone_amh",
  "hormona anti-mulleriana": "anti_mullerian_hormone_amh",
  "hormona anti mulleriana": "anti_mullerian_hormone_amh",
  "anti-mullerian hormone": "anti_mullerian_hormone_amh",
  "antimullerian hormone": "anti_mullerian_hormone_amh",
  "anti mullerian hormone": "anti_mullerian_hormone_amh",

  // ── Autoimmune ──
  "ana": "ana_screen", "anticuerpos antinucleares": "ana_screen",
  "anticuerpos anti-nucleares": "ana_screen", "antinuclear antibodies": "ana_screen",
  "ana screen": "ana_screen", "cribado ana": "ana_screen",
  "titulo ana": "ana_titer", "ana titer": "ana_titer",
  "patron ana": "ana_pattern", "ana pattern": "ana_pattern",
  "factor reumatoide": "rheumatoid_factor_rf", "factor reumatoideo": "rheumatoid_factor_rf",
  "rheumatoid factor": "rheumatoid_factor_rf", "rf": "rheumatoid_factor_rf",

  // ── Pancreas ──
  "amilasa": "amylase", "amylase": "amylase", "amilasa serica": "amylase",
  "amilasemia": "amylase", "amilasa total": "amylase", "amilasa pancreatica": "amylase",
  "lipasa": "lipase", "lipase": "lipase", "lipasa serica": "lipase",

  // ── Electrolytes ──
  "sodio": "sodium", "sodium": "sodium", "na": "sodium", "natremia": "sodium",
  "potasio": "potassium", "potassium": "potassium", "kalemia": "potassium",
  "cloruro": "chloride", "cloruros": "chloride", "chloride": "chloride", "cloro": "chloride",

  // ── PSA ──
  "psa": "psa_total", "psa total": "psa_total", "antigeno prostatico especifico": "psa_total",
  "antigeno prostatico especifico total": "psa_total", "prostate specific antigen": "psa_total",
  "antigeno prostatico": "psa_total",
  "psa libre": "psa_free", "psa free": "psa_free", "free psa": "psa_free",
  "antigeno prostatico libre": "psa_free", "fraccion libre de psa": "psa_free",

  // ── Specialty ──
  "acido metilmalonico": "methylmalonic_acid_mma", "methylmalonic acid": "methylmalonic_acid_mma",
  "mma": "methylmalonic_acid_mma",
  "plomo": "lead_blood", "lead": "lead_blood", "plomo en sangre": "lead_blood",
  "mercurio": "mercury_blood", "mercury": "mercury_blood", "mercurio en sangre": "mercury_blood",
};

// ─── Levenshtein distance ───

function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;

  // Optimize: if length difference > 2, skip
  if (Math.abs(m - n) > 2) return 3;

  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + cost,
      );
    }
  }

  return dp[m][n];
}

// ─── Normalize input ───

function normalize(name: string): string {
  return name
    .toLowerCase()
    .trim()
    // Strip Spanish diacritics so "Neutrófilos" lowercases to the same
    // key the alias map stores ("neutrofilos"). The map stores
    // accent-free forms only.
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[()]/g, "")
    // Lab reports prefix CBC differential lines with "%" or "#" to
    // distinguish percentage vs absolute count ("% Neutrófilos" /
    // "# Neutrófilos"). The percent/hash itself is not part of the
    // biomarker name — drop it before alias lookup. The unit (which
    // arrives separately) is what disambiguates the two downstream via
    // resolveCbcDifferentialKey.
    .replace(/^[\s%#]+/, "")
    .replace(/[^a-z0-9ñ\s\-]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

/**
 * Concatenated digit run of a string. Used to veto fuzzy matches that
 * differ on a digit — "vitamina b6" vs "vitamina b9", "free t3" vs
 * "free t4", "omega-3" vs "omega-6". A single-character Levenshtein
 * edit treats those as near-identical, but the digit is the entire
 * clinical meaning, so a digit mismatch must block the fuzzy match.
 */
function digitSignature(s: string): string {
  return (s.match(/\d/g) ?? []).join("");
}

// Below this normalized length we never fuzzy-match. Short clinical
// abbreviations ("ph", "inr", "ade", "got", "gpt", "lh") are only 2-3
// chars, so a Levenshtein ≤ 2 threshold would match almost anything —
// that is exactly how "pH" was resolving to luteinizing_hormone_lh.
// Such abbreviations must resolve via exact/alias only, never fuzzy.
const MIN_FUZZY_LENGTH = 5;

// ─── Match result ───

export interface MatchResult {
  biomarkerKey: string | null;
  confidence: "exact" | "alias" | "fuzzy" | "none";
  originalName: string;
}

// ─── Main matcher ───

export function matchBiomarkerName(rawName: string): MatchResult {
  return matchInternal(rawName, false);
}

/**
 * Internal recursion entrypoint. `fromSplit` prevents the parenthesis
 * fallback from triggering on a piece we've already split out — so we
 * never end up in a degenerate recursion if a part itself contains
 * stray parens after normalisation.
 */
function matchInternal(rawName: string, fromSplit: boolean): MatchResult {
  const original = rawName;
  const normalized = normalize(rawName);
  const slugged = slugify(rawName);

  if (normalized.length < 2) {
    return { biomarkerKey: null, confidence: "none", originalName: original };
  }

  // 1. Exact match against canonical seed keys
  if (ALL_KEYS.has(slugged)) {
    return { biomarkerKey: slugged, confidence: "exact", originalName: original };
  }

  // 2. Alias match
  if (normalized in ALIASES) {
    return { biomarkerKey: ALIASES[normalized], confidence: "alias", originalName: original };
  }

  // Also try slugified form against aliases
  if (slugged in ALIASES) {
    return { biomarkerKey: ALIASES[slugged], confidence: "alias", originalName: original };
  }

  // 3. Fuzzy match (Levenshtein ≤ 2) against alias keys + canonical keys.
  //    Guarded: only for inputs of a meaningful length, and the digit
  //    signature of input and candidate must match exactly.
  if (normalized.length >= MIN_FUZZY_LENGTH) {
    const inputDigits = digitSignature(normalized);
    let bestKey: string | null = null;
    let bestDist = 3;

    for (const [aliasKey, biomarkerKey] of Object.entries(ALIASES)) {
      if (aliasKey.length < MIN_FUZZY_LENGTH) continue;
      if (digitSignature(aliasKey) !== inputDigits) continue;
      const dist = levenshtein(normalized, aliasKey);
      if (dist < bestDist) {
        bestDist = dist;
        bestKey = biomarkerKey;
      }
      if (dist === 0) break;
    }

    // Also fuzzy against canonical keys (slug form)
    const sluggedDigits = digitSignature(slugged);
    for (const key of ALL_KEYS) {
      if (key.length < MIN_FUZZY_LENGTH) continue;
      if (digitSignature(key) !== sluggedDigits) continue;
      const dist = levenshtein(slugged, key);
      if (dist < bestDist) {
        bestDist = dist;
        bestKey = key;
      }
    }

    if (bestKey && bestDist <= 2) {
      return { biomarkerKey: bestKey, confidence: "fuzzy", originalName: original };
    }
  }

  // 4. Parenthesis-splitting fallback. Many labs report
  //    "SHBG (Sex Hormone Binding Globulin)" or
  //    "Sex Hormone Binding Globulin (SHBG)" as a single field. Neither
  //    the combined string nor its alias-stripped form is in our map,
  //    so we'd fall through to "none" and force the user to pick
  //    manually. Splitting on the parens and trying each part lets the
  //    abbreviation OR the full name resolve on its own. We pick the
  //    higher-precedence match (exact > alias > fuzzy).
  if (!fromSplit) {
    const parts = splitOnParens(original);
    if (parts.length > 1) {
      const rank = { exact: 3, alias: 2, fuzzy: 1, none: 0 } as const;
      let best: MatchResult | null = null;
      for (const part of parts) {
        const r = matchInternal(part, true);
        if (r.confidence === "none") continue;
        if (!best || rank[r.confidence] > rank[best.confidence]) {
          best = r;
        }
        if (r.confidence === "exact") break;
      }
      if (best) {
        return { ...best, originalName: original };
      }
    }
  }

  // 5. No match
  return { biomarkerKey: null, confidence: "none", originalName: original };
}

/**
 * Split a lab-report biomarker name on its parentheses. Returns each
 * inside-and-outside piece as a separate string so the matcher can try
 * them independently. Pure helper; does not normalize.
 */
function splitOnParens(raw: string): string[] {
  const parts: string[] = [];
  const regex = /([^()]+)|\(([^()]+)\)/g;
  let m: RegExpExecArray | null;
  while ((m = regex.exec(raw)) !== null) {
    const piece = (m[1] ?? m[2] ?? "").trim();
    if (piece.length >= 2) parts.push(piece);
  }
  return parts;
}

// ─── Batch matcher ───

export function matchBiomarkerNames(rawNames: string[]): MatchResult[] {
  return rawNames.map(matchBiomarkerName);
}

// ─── DB key → Bio-age engine code mapping ───
// Maps biomarker_references keys to the uppercase codes used in
// biological-age.ts. Legacy short-form matcher keys are kept alongside
// the seed slugs so bio-age still resolves if an older key flows
// through the pipeline from cached data.

export const DB_KEY_TO_ENGINE_CODE: Record<string, string> = {
  // ── Lipids ──
  apolipoprotein_b: "APOB",
  apolipoprotein_b_apob: "APOB",
  ldl_cholesterol: "LDL_C",
  hdl_cholesterol: "HDL_C",
  triglycerides: "TG",
  lipoprotein_a: "LPA",
  lipoproteina: "LPA",

  // ── Metabolic ──
  hba1c: "HBA1C",
  glucose_fasting: "GLUCOSE",
  fasting_insulin: "INSULIN",
  insulin_fasting: "INSULIN",
  homa_ir: "HOMA_IR",
  fructosamine: "FRUCTOSAMINE",

  // ── Inflammatory ──
  hs_crp: "HSCRP",

  // ── Kidney ──
  egfr: "EGFR",
  egfr_creatinine_based: "EGFR",
  creatinine: "CREATININE",
  uric_acid: "URIC_ACID",

  // ── Liver ──
  alt: "ALT",
  ast: "AST",
  ggt: "GGT",
  albumin: "ALBUMIN",
  total_bilirubin: "BILIRUBIN",
  alkaline_phosphatase: "ALP",
  alp: "ALP",

  // ── CBC ──
  rdw: "RDW",
  mcv: "MCV",
  white_blood_cell_count: "WBC",
  lymphocytes: "LYMPH_PCT",
  hemoglobin: "HGB",
  platelet_count: "PLT",
  // NLR is a ratio the engine scores; it is computed from neutrophils and
  // lymphocytes by calculated-metrics (see engine-inputs.ts), never mapped
  // from the raw neutrophil percentage.

  // ── Iron ──
  ferritin: "FERRITIN",
  transferrin_saturation: "TSAT",
  iron_saturation_tsat: "TSAT",

  // ── Hormones ──
  testosterone: "TESTOSTERONE",
  testosterone_total: "TESTOSTERONE",
  estradiol: "ESTRADIOL",
  shbg: "SHBG",

  // ── Thyroid ──
  tsh: "TSH",
  free_t4: "FT4",
  free_t4_thyroxine: "FT4",
  free_t3: "FT3",
  free_t3_triiodothyronine: "FT3",

  // ── Nutrients ──
  vitamin_d_25_oh: "VITD",
  vitamin_b12: "B12",
  folate: "FOLATE",
  magnesium: "MAGNESIUM",
  magnesium_serum: "MAGNESIUM",
  zinc: "ZINC",
  zinc_serum: "ZINC",
};
