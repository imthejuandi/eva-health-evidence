export interface WearableDayData {
  date: string; // YYYY-MM-DD
  hrv_ms: number | null;
  resting_hr_bpm: number | null;
  sleep_hours: number | null;
  sleep_quality_score: number | null;
  respiratory_rate: number | null;
  steps: number | null;
  active_energy_kcal: number | null;
  vo2_max: number | null;
  blood_oxygen_pct: number | null;
  recovery_score: number | null;
}

export interface WearableImportResult {
  source: string;
  daysImported: number;
  dateRange: { start: string; end: string } | null;
  data: WearableDayData[];
}

export interface WearableAdapter {
  source: string;
  parseExport(fileBuffer: Buffer): Promise<WearableImportResult>;
}
