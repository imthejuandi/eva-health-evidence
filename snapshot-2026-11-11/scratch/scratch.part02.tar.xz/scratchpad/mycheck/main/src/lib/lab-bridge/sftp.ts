/**
 * Minimal SFTP surface the bridge needs, so the sync loop can be tested
 * against an in-memory mailbox and run against Echevarne's real one.
 *
 * Real mailbox (2026-09-08): sftp.laboratorioechevarne.com:218, user
 * evahealth, base /files, PURGED WEEKLY by ECH.
 */
import { timingSafeEqual } from "node:crypto";

export interface SftpEntry {
  name: string;
  type: "file" | "dir";
  size: number;
}

export interface SftpLike {
  list(dir: string): Promise<SftpEntry[]>;
  get(path: string): Promise<Uint8Array>;
  put(path: string, data: Uint8Array): Promise<void>;
  rename(from: string, to: string): Promise<void>;
  exists(path: string): Promise<boolean>;
}

function dirname(p: string): string {
  const i = p.lastIndexOf("/");
  return i <= 0 ? "/" : p.slice(0, i);
}
function basename(p: string): string {
  return p.slice(p.lastIndexOf("/") + 1);
}

/** In-memory mailbox for tests. Directories must be created explicitly (like the real one). */
export class InMemorySftp implements SftpLike {
  readonly files = new Map<string, Uint8Array>();
  readonly dirs = new Set<string>(["/"]);
  readonly log: string[] = [];

  mkdirp(dir: string): void {
    const parts = dir.split("/").filter(Boolean);
    let cur = "";
    for (const p of parts) {
      cur += `/${p}`;
      this.dirs.add(cur);
    }
  }

  async list(dir: string): Promise<SftpEntry[]> {
    if (!this.dirs.has(dir)) throw new Error(`No such directory: ${dir}`);
    const out: SftpEntry[] = [];
    for (const d of this.dirs) if (dirname(d) === dir && d !== dir) out.push({ name: basename(d), type: "dir", size: 0 });
    for (const [f, data] of this.files) if (dirname(f) === dir) out.push({ name: basename(f), type: "file", size: data.length });
    return out.sort((a, b) => a.name.localeCompare(b.name));
  }
  async get(path: string): Promise<Uint8Array> {
    const d = this.files.get(path);
    if (!d) throw new Error(`No such file: ${path}`);
    this.log.push(`get ${path}`);
    return d;
  }
  async put(path: string, data: Uint8Array): Promise<void> {
    if (!this.dirs.has(dirname(path))) throw new Error(`No such directory: ${dirname(path)}`);
    this.files.set(path, data);
    this.log.push(`put ${path}`);
  }
  async rename(from: string, to: string): Promise<void> {
    const d = this.files.get(from);
    if (!d) throw new Error(`No such file: ${from}`);
    if (!this.dirs.has(dirname(to))) throw new Error(`No such directory: ${dirname(to)}`);
    this.files.delete(from);
    this.files.set(to, d);
    this.log.push(`rename ${from} -> ${to}`);
  }
  async exists(path: string): Promise<boolean> {
    return this.files.has(path) || this.dirs.has(path);
  }
}

export interface SftpEnvConfig {
  host: string;
  port: number;
  username: string;
  password?: string;
  privateKey?: string;
  /**
   * SHA-256 fingerprint of Echevarne's SFTP host key, normalized to 64 hex
   * chars. When set, the connection is refused unless the server presents
   * exactly that key — without it, anyone on the network path could pose as
   * the lab and receive the credential and the orders (audit 2026-09-21,
   * F12). Set from ECH_SFTP_HOST_KEY_SHA256 (hex, colon-separated hex, or
   * OpenSSH's "SHA256:<base64>").
   */
  hostKeySha256?: string;
}

/**
 * Normalize a host-key fingerprint to lowercase hex (64 chars) or null when
 * it is not a SHA-256 fingerprint in any of the usual spellings:
 *   "ab12…" (hex) · "ab:12:…" (colon hex) · "SHA256:base64…" (OpenSSH).
 */
export function normalizeHostKeyFingerprint(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let s = raw.trim().replace(/^sha256:/i, "").trim();
  if (/^[0-9a-f]{2}(:[0-9a-f]{2}){31}$/i.test(s)) s = s.replace(/:/g, "");
  if (/^[0-9a-f]{64}$/i.test(s)) return s.toLowerCase();
  const b64 = s.replace(/=+$/, "");
  if (/^[A-Za-z0-9+/]{43}$/.test(b64)) {
    const bytes = Buffer.from(`${b64}=`, "base64");
    if (bytes.length === 32) return bytes.toString("hex");
  }
  return null;
}

export function readSftpConfigFromEnv(env: NodeJS.ProcessEnv = process.env): SftpEnvConfig | null {
  const host = env.ECH_SFTP_HOST;
  const username = env.ECH_SFTP_USER;
  const password = env.ECH_SFTP_PASSWORD;
  const privateKey = env.ECH_SFTP_PRIVATE_KEY;
  if (!host || !username || (!password && !privateKey)) return null;
  const hostKeySha256 = normalizeHostKeyFingerprint(env.ECH_SFTP_HOST_KEY_SHA256) ?? undefined;
  return { host, port: Number(env.ECH_SFTP_PORT ?? "22"), username, password, privateKey, hostKeySha256 };
}

/** ssh2 hands the verifier the hashed host key (hex when hostHash is set); compare in constant time. */
export function hostKeyMatches(presented: string | Buffer, expectedHex: string): boolean {
  const got = normalizeHostKeyFingerprint(typeof presented === "string" ? presented : presented.toString("hex"));
  if (!got || got.length !== expectedHex.length) return false;
  return timingSafeEqual(Buffer.from(got), Buffer.from(expectedHex));
}

/**
 * Real adapter over ssh2-sftp-client. Connects lazily on first use; call
 * close() when the run ends. Kept behind the SftpLike interface so the sync
 * loop never depends on the library.
 */
export async function connectRealSftp(cfg: SftpEnvConfig): Promise<{ sftp: SftpLike; close: () => Promise<void> }> {
  const { default: Client } = await import("ssh2-sftp-client");
  const client = new Client();
  const expected = cfg.hostKeySha256;
  await client.connect({
    host: cfg.host,
    port: cfg.port,
    username: cfg.username,
    password: cfg.password,
    privateKey: cfg.privateKey,
    readyTimeout: 20_000,
    // Pin the lab's host key when a fingerprint is configured: a server that
    // presents any other key is refused before the password is sent.
    ...(expected
      ? {
          hostHash: "sha256",
          hostVerifier: (hashedKey: string | Buffer) => hostKeyMatches(hashedKey, expected),
        }
      : {}),
  });
  const sftp: SftpLike = {
    async list(dir) {
      const rows = await client.list(dir);
      return rows.map((r) => ({ name: r.name, type: r.type === "d" ? "dir" : "file", size: r.size }));
    },
    async get(path) {
      const buf = (await client.get(path)) as Buffer;
      return new Uint8Array(buf);
    },
    async put(path, data) {
      await client.put(Buffer.from(data), path);
    },
    async rename(from, to) {
      await client.rename(from, to);
    },
    async exists(path) {
      return Boolean(await client.exists(path));
    },
  };
  return {
    sftp,
    close: async () => {
      await client.end();
    },
  };
}
