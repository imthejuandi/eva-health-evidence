export interface ResultsReadyData {
  firstName: string;
  biomarkerCount: number;
  biologicalAge: number | null;
  baDelta: number | null;
  longevityScore: number | null;
  locale: string;
}

export function renderResultsReady(data: ResultsReadyData, locale: string): string {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
  const dashboardUrl = `${appUrl}/${locale}/dashboard`;

  if (locale === "es") {
    return `
      <h1>Tus resultados estan listos, ${data.firstName}</h1>
      <p>Hemos analizado tus biomarcadores contra rangos optimizados para la longevidad. Aqui tienes un resumen:</p>

      <div style="margin: 20px 0;">
        <span class="stat">${data.biomarkerCount} biomarcadores analizados</span>
        ${data.longevityScore != null ? `<span class="stat">Longevity Score: ${data.longevityScore}/100</span>` : ""}
        ${data.biologicalAge != null ? `<span class="stat">Edad Biologica: ${data.biologicalAge} (${data.baDelta != null && data.baDelta < 0 ? `${Math.abs(data.baDelta)}a mas joven` : data.baDelta != null ? `${data.baDelta}a mayor` : ""})</span>` : ""}
      </div>

      <hr class="divider">

      <p>Entra en tu panel para ver la interpretacion completa de cada biomarcador, pasos de accion personalizados y como cada resultado impacta tu envejecimiento.</p>

      <a href="${dashboardUrl}" class="cta">Ver Tus Resultados</a>
    `;
  }

  return `
    <h1>Your results are ready, ${data.firstName}</h1>
    <p>We've analyzed your biomarkers against longevity-optimized ranges. Here's a quick snapshot:</p>

    <div style="margin: 20px 0;">
      <span class="stat">${data.biomarkerCount} biomarkers analyzed</span>
      ${data.longevityScore != null ? `<span class="stat">Longevity Score: ${data.longevityScore}/100</span>` : ""}
      ${data.biologicalAge != null ? `<span class="stat">Biological Age: ${data.biologicalAge} (${data.baDelta != null && data.baDelta < 0 ? `${Math.abs(data.baDelta)}y younger` : data.baDelta != null ? `${data.baDelta}y older` : ""})</span>` : ""}
    </div>

    <hr class="divider">

    <p>Head to your dashboard to see the full interpretation of every biomarker, personalized action steps, and how each result impacts your aging.</p>

    <a href="${dashboardUrl}" class="cta">View Your Results</a>
  `;
}
