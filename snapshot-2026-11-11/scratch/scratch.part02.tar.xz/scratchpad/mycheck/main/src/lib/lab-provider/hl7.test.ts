/**
 * Unit tests for the generic HL7 v2 reader + the Echevarne provider's
 * tolerance of legacy/synthetic messages. The v2.8-spec behaviour is locked
 * separately in echevarne-v28.test.ts against the OFFICIAL sample messages.
 */
import { describe, it, expect } from "vitest";
import {
  parseHl7,
  segmentsByName,
  getField,
  getMshField,
  getComponent,
  hl7DateToIso,
  hl7DateTimeToIso,
  parseHl7Number,
  parseHl7Value,
} from "./hl7";
import { EchevarneProvider } from "./echevarne";

// Synthetic legacy-shaped ORU (no ORC/SPM): exercises the parser's fallbacks.
const SAMPLE = [
  "MSH|^~\\&|ECHEVARNE|LAB|EVA|EVA|20260604120000||ORU^R01|MSG00001|P|2.5.1",
  "PID|1||EVA-USER-123^^^EVA^MR||DOE^JANE||19900101|F",
  "OBR|1|ORDER-789|FILLER-456|PANEL^EVA Quarterly^L|||20260603083000",
  "OBX|1|NM|2345-7^Glucose^LN||92|mg/dL^^UCUM|70-99|N|||F",
  "OBX|2|NM|4548-4^HbA1c^LN||5,4|%^^UCUM|4.0-5.6|N|||F",
  "OBX|3|NM|2571-8^Triglycerides^LN||110|mg/dL|<150|H|||P",
].join("\r");

describe("parseHl7", () => {
  it("reads delimiters from MSH and splits segments", () => {
    const m = parseHl7(SAMPLE);
    expect(m.delimiters.field).toBe("|");
    expect(m.delimiters.component).toBe("^");
    expect(m.delimiters.subcomponent).toBe("&");
    expect(segmentsByName(m, "OBX")).toHaveLength(3);
  });

  it("exposes 1-based field/component access for non-MSH segments", () => {
    const m = parseHl7(SAMPLE);
    const obx1 = segmentsByName(m, "OBX")[0];
    expect(getField(obx1, 5)).toBe("92"); // OBX-5 value
    expect(getComponent(getField(obx1, 3), 1, m.delimiters)).toBe("2345-7"); // OBX-3.1
  });

  it("reads MSH fields with the MSH-specific off-by-one accessor", () => {
    const m = parseHl7(SAMPLE);
    expect(getMshField(m, 10)).toBe("MSG00001"); // message control id
    expect(getMshField(m, 9)).toBe("ORU^R01");
    expect(getMshField(m, 1)).toBe("|");
  });

  it("throws on a non-HL7 payload", () => {
    expect(() => parseHl7('{"not":"hl7"}')).toThrow();
  });
});

describe("hl7 helpers", () => {
  it("parses HL7 timestamps to ISO calendar dates", () => {
    expect(hl7DateToIso("20260603083000")).toBe("2026-06-03");
    expect(hl7DateToIso("")).toBe("");
  });

  it("parses full HL7 timestamps to ISO datetimes", () => {
    expect(hl7DateTimeToIso("20260603083000")).toBe("2026-06-03T08:30:00");
    expect(hl7DateTimeToIso("20260603")).toBe("2026-06-03T00:00:00");
    expect(hl7DateTimeToIso("nope")).toBe("");
  });

  it("parses numbers including the European decimal comma", () => {
    expect(parseHl7Number("5,4")).toBe(5.4);
    expect(parseHl7Number("92")).toBe(92);
    expect(Number.isNaN(parseHl7Number("Positive"))).toBe(true);
  });

  it("parses bounded values with < / > comparators", () => {
    expect(parseHl7Value("<0,500")).toEqual({ value: 0.5, comparator: "<" });
    expect(parseHl7Value(">8,000")).toEqual({ value: 8, comparator: ">" });
    expect(parseHl7Value("92")).toEqual({ value: 92 });
    expect(parseHl7Value("Negativo")).toBeNull();
  });
});

describe("EchevarneProvider on legacy/synthetic messages", () => {
  it("falls back to OBR identifiers and OBR-7 when ORC/SPM are absent", () => {
    const r = EchevarneProvider.parseResults(SAMPLE);
    expect(r.userId).toBeUndefined(); // order-based: no user id in the message
    expect(r.placerOrderNumber).toBe("ORDER-789");
    expect(r.providerReference).toBe("FILLER-456");
    expect(r.collectionDate).toBe("2026-06-03");
    expect(r.messageControlId).toBe("MSG00001");
    // No F-only filter any more: all rows are kept, tagged with their status.
    expect(r.biomarkers).toHaveLength(3);
    expect(r.biomarkers[0]).toMatchObject({ biomarker_key: "2345-7", value: 92, unit: "mg/dL", status: "final" });
    expect(r.biomarkers[2].status).toBe("preliminary");
  });

  it("accepts a JSON envelope { hl7 } as well as a raw string", () => {
    const r = EchevarneProvider.parseResults({ hl7: SAMPLE });
    expect(r.biomarkers).toHaveLength(3);
  });

  it("maps via the ECH catalog first and LOINC as fallback; '' when unmapped", () => {
    // D0590 is not in the ECH catalog, so a bare code stays unmapped…
    expect(EchevarneProvider.mapBiomarkerName("D0590")).toBe("");
    // …but a LOINC passed alongside resolves through the fallback map.
    expect(EchevarneProvider.mapBiomarkerName("D0590", "2345-7")).toBe("glucose_fasting");
    expect(EchevarneProvider.mapBiomarkerName("D0590", "9999-9")).toBe("");
  });

  it("verifyWebhook fails closed when the secret is unset (inert by default)", () => {
    expect(EchevarneProvider.verifyWebhook({ authorization: "Bearer x" }, SAMPLE)).toBe(false);
  });
});
