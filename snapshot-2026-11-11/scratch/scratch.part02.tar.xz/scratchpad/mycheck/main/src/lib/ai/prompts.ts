import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Prompt loader. The dashboard's AI features fetch their system
 * prompts and model config from the `ai_prompts` table at runtime,
 * so prompts can be edited in Supabase Studio without a redeploy
 * and never ship to the browser bundle.
 *
 * Access is service-role only (the table has RLS on with no policies),
 * so this module must run on the server and uses createAdminClient.
 *
 * Cache: prompts are cached per-process for 60 seconds. That amortises
 * the DB hit across multiple AI calls in the same warm container but
 * lets Studio edits take effect within a minute.
 */

export interface AiPrompt {
  key: string;
  content: string;
  model: string;
  temperature: number | null;
  maxOutputTokens: number | null;
  thinkingBudget: number | null;
  responseMimeType: string | null;
}

const CACHE_TTL_MS = 60_000;
const cache = new Map<string, { value: AiPrompt; expiresAt: number }>();

export async function getPrompt(key: string): Promise<AiPrompt> {
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && hit.expiresAt > now) return hit.value;

  const admin = createAdminClient();
  if (!admin) {
    throw new Error(
      `Cannot load AI prompt "${key}": SUPABASE_SERVICE_ROLE_KEY is not configured.`,
    );
  }

  const { data, error } = await admin
    .from("ai_prompts")
    .select("key, content, model, temperature, max_output_tokens, thinking_budget, response_mime_type")
    .eq("key", key)
    .maybeSingle();

  if (error) {
    throw new Error(`Failed to load AI prompt "${key}": ${error.message}`);
  }
  if (!data) {
    throw new Error(`AI prompt "${key}" is missing from the ai_prompts table.`);
  }

  const prompt: AiPrompt = {
    key: data.key,
    content: data.content,
    model: data.model,
    temperature: data.temperature,
    maxOutputTokens: data.max_output_tokens,
    thinkingBudget: data.thinking_budget,
    responseMimeType: data.response_mime_type,
  };

  cache.set(key, { value: prompt, expiresAt: now + CACHE_TTL_MS });
  return prompt;
}
