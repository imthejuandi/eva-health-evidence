/**
 * The Longevity Score engine scores stored values, and stored values are in
 * eva's canonical units (Echevarne's since 2026-09-17). These tests pin the
 * engine registry to those units — the 2026-09-21 audit found four markers
 * still in the old units (every hemogram and albumin scored critical) and the
 * neutrophil percentage fed in as if it were the NLR ratio.
 */
import { describe, it, expect } from "vitest";
import { calculateLongevityScore } from "./longevity-score";
import { DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
import { getCanonicalUnit, unitsMatch } from "./canonical-units";
import { buildEngineInputs } from "./engine-inputs";
import { ECH_PANEL_ORDER_CODES } from "@/lib/lab-bridge/panel-codes";
import { EchevarneProvider } from "@/lib/lab-provider/echevarne";

/** Registry unit per engine code, read through a probe value's MarkerScore. */
function registryUnit(code: string): string | null {
  const probe = [
    { code: "APOB", value: 70 }, { code: "HBA1C", value: 5.2 }, { code: "GLUCOSE", value: 85 },
    { code: "HSCRP", value: 0.5 }, { code: "ALT", value: 20 }, { code: "RDW", value: 12 },
    { code: "HGB", value: 15 }, { code: "HDL_C", value: 55 }, { code: "TG", value: 80 },
    { code: "CREATININE", value: 0.9 }, { code: "ALBUMIN", value: 45 },
  ];
  if (!probe.some((p) => p.code === code)) probe.push({ code, value: 1 });
  const r = calculateLongevityScore(probe, "male", 40);
  const m = [...r.markerScores, ...r.suppressedMarkers].find((s) => s.code === code);
  return m?.unit ?? null;
}

describe("Longevity Score registry — every scored marker is in eva's canonical unit", () => {
  const cases = Object.entries(DB_KEY_TO_ENGINE_CODE)
    .map(([key, code]) => ({ key, code, canonical: getCanonicalUnit(key) }))
    .filter((c) => c.canonical !== null);

  it("covers the mapped keys that exist in the seed", () => {
    expect(cases.length).toBeGreaterThan(30);
  });

  for (const c of cases) {
    it(`${c.key} → ${c.code}: registry unit matches the seed's ${c.canonical}`, () => {
      const unit = registryUnit(c.code);
      if (unit === null) return; // age/sex-gated marker with no range for the probe: nothing to score
      if (unit === "" && c.canonical === "ratio") return; // unitless ratios
      expect(unitsMatch(unit, c.canonical), `${c.code} registry '${unit}' vs seed '${c.canonical}'`).toBe(true);
    });
  }
});

describe("Longevity Score — Echevarne-unit values score where the v4 ranges intended", () => {
  const healthy = [
    { biomarkerKey: "apolipoprotein_b_apob", value: 70 },
    { biomarkerKey: "hdl_cholesterol", value: 60 },
    { biomarkerKey: "triglycerides", value: 70 },
    { biomarkerKey: "hs_crp", value: 0.4 },
    { biomarkerKey: "alt", value: 18 },
    { biomarkerKey: "albumin", value: 45 }, // g/L
    { biomarkerKey: "creatinine", value: 0.9 },
    { biomarkerKey: "white_blood_cell_count", value: 5500 }, // raw cells/µL
    { biomarkerKey: "platelet_count", value: 250000 }, // raw cells/µL
    { biomarkerKey: "rdw", value: 12.5 },
    { biomarkerKey: "hemoglobin", value: 15 },
    { biomarkerKey: "hba1c", value: 5.0 },
    { biomarkerKey: "testosterone_total", value: 7.0 }, // ng/mL
    { biomarkerKey: "neutrophils", value: 58 }, // %
    { biomarkerKey: "lymphocytes", value: 32 }, // %
  ];

  it("a healthy panel in lab units is optimal on every one of those markers", () => {
    const inputs = buildEngineInputs(healthy, "male");
    const r = calculateLongevityScore(inputs, "male", 35);
    expect(r.validation.valid).toBe(true);
    const zones = Object.fromEntries(r.markerScores.map((m) => [m.code, m.zone]));
    for (const code of ["WBC", "PLT", "ALBUMIN", "TESTOSTERONE", "NLR"]) {
      expect(zones[code], code).toBe("optimal");
    }
    expect(r.longevityScore).toBeGreaterThanOrEqual(85);
  });

  it("NLR is the computed neutrophil/lymphocyte ratio, never the neutrophil percentage", () => {
    const inputs = buildEngineInputs(healthy, "male");
    const nlr = inputs.find((i) => i.code === "NLR");
    expect(nlr?.value).toBeCloseTo(58 / 32, 2);
    expect(inputs.filter((i) => i.code === "NLR")).toHaveLength(1);
  });

  it("HOMA-IR reaches the engine from insulin_fasting + glucose_fasting", () => {
    const inputs = buildEngineInputs([{ biomarkerKey: "insulin_fasting", value: 5 }, { biomarkerKey: "glucose_fasting", value: 90 }], "male");
    expect(inputs.find((i) => i.code === "HOMA_IR")?.value).toBeCloseTo(1.11, 1);
  });
});

describe("Longevity Score — the Base Panel (2026-09-22) is scorable on its own", () => {
  it("the 13 ordered tests map to engine markers covering 4 of the 5 domains", () => {
    // Order code → result code(s) → DB key → engine code, exactly as an ORU would arrive.
    const resultCodes: Record<string, string> = { ALBS: "B0020", FAL: "B0202", PCUL: "B0851", CR1: "B0003", BUN: "B0150", AU1: "B0025", COL: "B0001", HDLC: "B0017", TRIG: "B0004", APOB: "B0839", GPT: "B0005", GGT: "B0007", FRUC: "B0158" };
    const values: Record<string, number> = { albumin: 45, alp: 70, hs_crp: 0.5, creatinine: 0.9, bun: 14, uric_acid: 5, total_cholesterol: 180, hdl_cholesterol: 60, triglycerides: 70, apolipoprotein_b_apob: 70, alt: 18, ggt: 20, fructosamine: 190 };
    const rows = ECH_PANEL_ORDER_CODES.base.map((t) => {
      const key = EchevarneProvider.mapBiomarkerName(resultCodes[t.code]);
      expect(key, `${t.code} → ${resultCodes[t.code]} must map to a biomarker`).toBeTruthy();
      return { biomarkerKey: key!, value: values[key!] };
    });
    const inputs = buildEngineInputs(rows, "female");
    const r = calculateLongevityScore(inputs, "female", 42);
    expect(r.validation.valid).toBe(true);
    expect(r.validation.domainsCovered).toBe(4); // no CBC on the Base Panel → hematology uncovered
    expect(r.validation.missingDomains).toEqual(["hematology"]);
    expect(r.markerScores.map((m) => m.code)).toContain("FRUCTOSAMINE");
    expect(r.longevityScore).toBeGreaterThan(0);
  });
});
