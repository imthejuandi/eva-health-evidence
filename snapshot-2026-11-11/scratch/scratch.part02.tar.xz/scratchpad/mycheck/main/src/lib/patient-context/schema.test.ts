import { describe, expect, it } from "vitest";
import {
  DurableContextSnapshotSchema,
  TransientContextSchema,
} from "./schema";
import { emptySnapshot, isSnapshotEmpty } from "./options";

describe("Patient context — durable schema", () => {
  it("accepts a minimal empty snapshot", () => {
    const result = DurableContextSnapshotSchema.safeParse(emptySnapshot());
    expect(result.success).toBe(true);
  });

  it("accepts a populated snapshot", () => {
    const result = DurableContextSnapshotSchema.safeParse({
      medications: [
        { key: "statin_rosuvastatin", dose: "10mg" },
        { key: "metformin", dose: "1000mg BID" },
      ],
      supplements: [{ key: "creatine", dose: "10g daily" }],
      conditions: { keys: ["diabetes_t2"] },
      lifestyle: {
        smoking_status: "never",
        alcohol_drinks_per_week: 2,
        cardio_sessions_per_week: 4,
        cardio_dominant_intensity: "zone2",
        resistance_sessions_per_week: 3,
        diet_pattern: "mediterranean",
      },
      sex_specific: { trt: "none" },
    });
    expect(result.success).toBe(true);
  });

  it("rejects an unknown medication key", () => {
    const result = DurableContextSnapshotSchema.safeParse({
      ...emptySnapshot(),
      medications: [{ key: "kombucha_drops" }],
    });
    expect(result.success).toBe(false);
  });

  it("rejects an unknown condition key", () => {
    const result = DurableContextSnapshotSchema.safeParse({
      ...emptySnapshot(),
      conditions: { keys: ["definitely_not_a_real_dx"] },
    });
    expect(result.success).toBe(false);
  });

  it("rejects out-of-range numeric lifestyle fields", () => {
    const result = DurableContextSnapshotSchema.safeParse({
      ...emptySnapshot(),
      lifestyle: { alcohol_drinks_per_week: -3 },
    });
    expect(result.success).toBe(false);
  });

  it("isSnapshotEmpty returns true for the empty snapshot", () => {
    expect(isSnapshotEmpty(emptySnapshot())).toBe(true);
  });

  it("isSnapshotEmpty returns false when any section has content", () => {
    expect(
      isSnapshotEmpty({
        ...emptySnapshot(),
        supplements: [{ key: "creatine" }],
      }),
    ).toBe(false);
  });
});

describe("Patient context — transient schema", () => {
  it("accepts an empty transient block", () => {
    expect(TransientContextSchema.safeParse({}).success).toBe(true);
  });

  it("accepts a populated transient block", () => {
    const result = TransientContextSchema.safeParse({
      fasted: "twelve_plus",
      last_workout: "hard_24_to_48h",
      currently_ill: false,
      cycle_day: 14,
      draw_time: "morning",
      sleep_quality: "good",
      hydration: "ok",
      skipped: false,
    });
    expect(result.success).toBe(true);
  });

  it("rejects an out-of-range cycle day", () => {
    const result = TransientContextSchema.safeParse({ cycle_day: 99 });
    expect(result.success).toBe(false);
  });

  it("rejects an unknown fasted bucket", () => {
    const result = TransientContextSchema.safeParse({ fasted: "ish" });
    expect(result.success).toBe(false);
  });
});
