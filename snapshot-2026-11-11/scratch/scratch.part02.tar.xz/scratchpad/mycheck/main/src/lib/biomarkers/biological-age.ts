/**
 * @deprecated The legacy v4.0 penalty-engine `calculate()` exported below is
 * preserved here as a backward-compatibility shim. It now re-exports the
 * longevity-score engine (which is the rightful owner of the penalty math).
 *
 * For new code:
 *   - Use `calculateLongevityScore` from `./longevity-score` for the 1-100
 *     deviation-from-optimal-range longevity score.
 *   - Use `computeReferenceBA` / `computeComprehensiveBA` from
 *     `./biological-age-kdm` for mortality-validated biological age
 *     (KDM v2.2 joint estimator, HR/SD 1.37 in NHANES n=18,570).
 *
 * The legacy `FullResult.biologicalAge` field returned by `calculate()` is
 * the penalty-derived deviation heuristic — it remains numerically defined
 * for back-compat but should NOT be persisted to `lab_results.biological_age`.
 * Use the KDM module's output for that field. The orchestrator in
 * `process-results.ts` (see B.13 of plan kdm-v2-2-integration) is the source
 * of truth for which value lands in the DB.
 *
 * Split rationale: see audit/longevity_score_audit_report.md
 */

export * from "./longevity-score";
// Back-compat alias: existing import sites use `import { calculate } from "./biological-age"`.
export { calculateLongevityScore as calculate } from "./longevity-score";
