import { describe, it, expect } from "vitest";
import {
  ID_DOCUMENT_TYPES,
  isValidDni,
  isValidNie,
  normalizeDocumentNumber,
  validateIdDocument,
} from "./document";

describe("identity document — Echevarne PID.3.5 types", () => {
  it("exposes exactly the spec's type codes", () => {
    expect([...ID_DOCUMENT_TYPES].sort()).toEqual(
      ["CENSO", "CIF", "DNI", "DNI_TUTOR", "ID", "NIE", "NIE_TUTOR", "NIF", "NIF_TUTOR", "OTROS", "PASAPORTE"].sort(),
    );
  });

  it("normalizes case and separators", () => {
    expect(normalizeDocumentNumber(" 12.345.678-z ")).toBe("12345678Z");
  });

  it("validates the DNI mod-23 check letter", () => {
    expect(isValidDni("12345678Z")).toBe(true); // 12345678 % 23 = 14 → Z
    expect(isValidDni("12345678A")).toBe(false);
    expect(isValidDni("1234567Z")).toBe(false);
  });

  it("validates NIE with X/Y/Z prefix mapped to 0/1/2", () => {
    expect(isValidNie("X1234567L")).toBe(true); // 01234567 % 23 = 20 → L
    expect(isValidNie("Y1234567X")).toBe(true); // 11234567 % 23 = 16 → X
    expect(isValidNie("X1234567A")).toBe(false);
  });

  it("validateIdDocument returns the normalized number and rejects bad input", () => {
    expect(validateIdDocument("DNI", "12345678-z")).toEqual({ ok: true, type: "DNI", number: "12345678Z" });
    expect(validateIdDocument("NIE", "x1234567l")).toEqual({ ok: true, type: "NIE", number: "X1234567L" });
    expect(validateIdDocument("PASAPORTE", "PAB 123456")).toEqual({ ok: true, type: "PASAPORTE", number: "PAB123456" });
    expect(validateIdDocument("DNI", "12345678A").ok).toBe(false);
    expect(validateIdDocument("PASAPORTE", "ab").ok).toBe(false);
    expect(validateIdDocument("CARNET", "123").ok).toBe(false);
    expect(validateIdDocument("DNI", "").ok).toBe(false);
  });
});
