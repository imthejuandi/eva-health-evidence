/**
 * Rolling-average biological age — the dashboard's single user-facing BA.
 *
 * Rather than displaying the most recent lab's BA (which fluctuates with
 * single-lab measurement noise), this module computes a stable composite
 * by AVERAGING biomarkers across the user's labs in a recent time window,
 * then running the KDM joint estimator once on the averaged panel.
 *
 * --- Window selection ---
 *
 *   1. 6-month window (preferred): includes labs collected within the
 *      last 6 months. Used when ≥ 2 distinct labs fall in this window.
 *      Matches the product's quarterly-testing cadence.
 *
 *   2. 12-month fallback: when fewer than 2 labs in 6 months, expand to
 *      12 months. Covers less-frequent testers without forcing a
 *      single-lab BA.
 *
 *   3. Single-lab fallback: when < 2 labs even in 12 months, use the most
 *      recent lab's biomarkers directly. `window_months` returns null.
 *
 * --- Tier selection ---
 *
 *   - Comprehensive BA is preferred when the joint estimator computes —
 *     it uses every KDM-mapped marker and has higher mortality
 *     discrimination (HR/SD 1.49 vs Reference 1.29).
 *   - Reference BA is the fallback when Comprehensive returns null.
 *   - Both share the same gate (≥ 8 of 14 base panel + Albumin + Creatinine).
 *
 * --- Caching ---
 *
 * The output is written to `profiles.current_ba` by
 * `recomputeAndCacheUserBA()` on every successful lab upload. The
 * dashboard reads from the cached column, not recomputing per request.
 * See `supabase/migrations/20260527000000_rolling_average_ba.sql`.
 *
 * --- Outlier handling ---
 *
 * Current implementation does NAIVE averaging — every biomarker_value in
 * the window contributes equally. Known limitation: if a single lab has
 * extraction artifacts (urea-vs-BUN unit confusion, etc.), those values
 * will pollute the average. Outlier detection (IQR / per-user median
 * filter) is a planned fast-follow once we see this in production.
 *
 * --- Example (user 9d66d21b, 3 labs Jan/Mar/May 2026, 30yo male,
 *     creatine 10g/day) ---
 *
 *   - 6-month window from May 2026 includes all 3 labs.
 *   - Averaging 53 biomarkers across the 3 labs → KDM Comprehensive 25.5,
 *     Reference 23.8. Showing Comprehensive.
 *   - For context, the latest single lab (May) gives Reference 32.6;
 *     the previous lab (March) gave Reference 18.5. The rolling average
 *     of 25.5 smooths the inter-lab spread that's mathematically
 *     expected per KDM uncertainty.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import {
  computeComprehensiveBA,
  computeReferenceBA,
  type KdmPatientContext,
} from "./biological-age-kdm";
import type { BiomarkerInput } from "./longevity-score";
import type { SupplementEntry } from "./supplements";

// ─── Public types ───

export type RollingBAMethod = "Comprehensive" | "Reference";

export interface RollingAverageBAResult {
  ba: number;
  method: RollingBAMethod;
  n_labs_averaged: number;
  /** 6 or 12 when window-based; null when single-lab fallback. */
  window_months: number | null;
  n_markers_used: number;
  applied_spanish_recalibration_markers: string[];
  /** Reference age used for KDM (chronological age at most recent lab's collection date). */
  reference_age: number;
}

// ─── Helpers ───

interface LabRow {
  id: string;
  collection_date: string;
}

interface BiomarkerRow {
  biomarker_key: string;
  value: number;
}

function calculateAgeAt(dob: string, asOf: string): number {
  const d = new Date(dob);
  const a = new Date(asOf);
  let age = a.getFullYear() - d.getFullYear();
  const m = a.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && a.getDate() < d.getDate())) age--;
  return age;
}

function monthsAgoIso(monthsBack: number, ref: Date = new Date()): string {
  const d = new Date(ref);
  d.setMonth(d.getMonth() - monthsBack);
  return d.toISOString().slice(0, 10);
}

async function fetchLabsInWindow(
  supabase: SupabaseClient,
  userId: string,
  sinceDate: string,
): Promise<LabRow[]> {
  const { data } = await supabase
    .from("lab_results")
    .select("id, collection_date")
    .eq("user_id", userId)
    .eq("status", "ready")
    .gte("collection_date", sinceDate)
    .order("collection_date", { ascending: false });
  return ((data as LabRow[] | null) ?? []).filter(
    (l) => l.id && l.collection_date,
  );
}

async function fetchMostRecentLab(
  supabase: SupabaseClient,
  userId: string,
): Promise<LabRow | null> {
  const { data } = await supabase
    .from("lab_results")
    .select("id, collection_date")
    .eq("user_id", userId)
    .eq("status", "ready")
    .order("collection_date", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return data && (data as LabRow).id ? (data as LabRow) : null;
}

async function fetchBiomarkerValuesForLabs(
  supabase: SupabaseClient,
  labIds: string[],
): Promise<BiomarkerRow[]> {
  if (labIds.length === 0) return [];
  const { data } = await supabase
    .from("biomarker_values")
    .select("biomarker_key, value")
    .in("lab_result_id", labIds);
  return (data as BiomarkerRow[] | null) ?? [];
}

/**
 * Average biomarker values by biomarker_key. Non-finite values are skipped
 * silently. When multiple rows share the same biomarker_key (e.g., the
 * urea/BUN extraction case where one lab has two entries for the same
 * underlying analyte), they all contribute to the simple mean.
 */
export function averageBiomarkers(rows: BiomarkerRow[]): BiomarkerInput[] {
  const sums = new Map<string, { sum: number; n: number }>();
  for (const r of rows) {
    if (!r.biomarker_key) continue;
    if (typeof r.value !== "number" || !Number.isFinite(r.value)) continue;
    const slot = sums.get(r.biomarker_key);
    if (slot) {
      slot.sum += r.value;
      slot.n += 1;
    } else {
      sums.set(r.biomarker_key, { sum: r.value, n: 1 });
    }
  }
  const out: BiomarkerInput[] = [];
  for (const [code, { sum, n }] of sums.entries()) {
    out.push({ code, value: sum / n });
  }
  return out;
}

async function fetchSupplements(
  supabase: SupabaseClient,
  userId: string,
): Promise<SupplementEntry[]> {
  const { data } = await supabase
    .from("patient_context_versions")
    .select("supplements")
    .eq("user_id", userId)
    .order("version_number", { ascending: false })
    .limit(1)
    .maybeSingle();
  const raw = (data as { supplements?: unknown } | null)?.supplements;
  return Array.isArray(raw) ? (raw as SupplementEntry[]) : [];
}

// ─── Public API ───

/**
 * Compute the user's rolling-average biological age.
 *
 * Returns null when the user has no labs, or when no lab in any window
 * passes the KDM gate.
 */
export async function computeRollingAverageBA(
  userId: string,
  supabase: SupabaseClient,
): Promise<RollingAverageBAResult | null> {
  // 1. Profile (sex + DOB)
  const { data: profile } = await supabase
    .from("profiles")
    .select("sex, date_of_birth")
    .eq("id", userId)
    .maybeSingle();
  if (!profile) return null;
  const p = profile as { sex: string | null; date_of_birth: string | null };
  if (!p.sex || !p.date_of_birth) return null;
  const sex: "male" | "female" =
    p.sex.toLowerCase() === "female" ? "female" : "male";

  // 2. Try 6-month window first
  const since6m = monthsAgoIso(6);
  const labs6m = await fetchLabsInWindow(supabase, userId, since6m);

  let labs: LabRow[];
  let windowMonths: number | null;
  if (labs6m.length >= 2) {
    labs = labs6m;
    windowMonths = 6;
  } else {
    // 3. 12-month fallback
    const since12m = monthsAgoIso(12);
    const labs12m = await fetchLabsInWindow(supabase, userId, since12m);
    if (labs12m.length >= 2) {
      labs = labs12m;
      windowMonths = 12;
    } else {
      // 4. Single-lab fallback
      const latest = await fetchMostRecentLab(supabase, userId);
      if (!latest) return null;
      labs = [latest];
      windowMonths = null;
    }
  }

  // 5. Fetch all biomarker values across the selected labs
  const labIds = labs.map((l) => l.id);
  const rows = await fetchBiomarkerValuesForLabs(supabase, labIds);
  if (rows.length === 0) return null;

  // 6. Average biomarkers by key
  const averagedInputs = averageBiomarkers(rows);
  if (averagedInputs.length === 0) return null;

  // 7. Reference age = chronological age at the MOST RECENT lab in the window
  //    (the biomarkers are dominated by recent labs; pinning age to the
  //    most recent collection date avoids extrapolating BA forward).
  const mostRecentDate = labs[0].collection_date;
  const age = calculateAgeAt(p.date_of_birth, mostRecentDate);
  if (!Number.isFinite(age) || age <= 0) return null;

  // 8. Supplements context
  const supplements = await fetchSupplements(supabase, userId);
  const context: KdmPatientContext = { supplements };

  // 9. Compute Comprehensive first (preferred), fall back to Reference
  const comp = computeComprehensiveBA(averagedInputs, sex, age, context);
  if (comp) {
    return {
      ba: comp.BA,
      method: "Comprehensive",
      n_labs_averaged: labs.length,
      window_months: windowMonths,
      n_markers_used: comp.n_markers_used,
      applied_spanish_recalibration_markers:
        comp.applied_spanish_recalibration_markers,
      reference_age: age,
    };
  }

  const ref = computeReferenceBA(averagedInputs, sex, age, context);
  if (ref) {
    return {
      ba: ref.BA,
      method: "Reference",
      n_labs_averaged: labs.length,
      window_months: windowMonths,
      n_markers_used: ref.n_markers_used,
      applied_spanish_recalibration_markers:
        ref.applied_spanish_recalibration_markers,
      reference_age: age,
    };
  }

  return null;
}

/**
 * Compute the user's rolling-average BA and write it to
 * `profiles.current_ba*`. Call this after every successful lab upload.
 *
 * Always uses the admin client supplied by the caller — the lab-upload
 * pipeline already has one.
 */
export async function recomputeAndCacheUserBA(
  userId: string,
  supabase: SupabaseClient,
): Promise<RollingAverageBAResult | null> {
  const result = await computeRollingAverageBA(userId, supabase);

  const update: Record<string, number | string | null> = {
    current_ba: result ? Number(result.ba.toFixed(2)) : null,
    current_ba_method: result?.method ?? null,
    current_ba_n_labs_averaged: result?.n_labs_averaged ?? null,
    current_ba_window_months: result?.window_months ?? null,
    current_ba_n_markers_used: result?.n_markers_used ?? null,
    current_ba_computed_at: new Date().toISOString(),
  };

  await supabase.from("profiles").update(update).eq("id", userId);

  return result;
}
