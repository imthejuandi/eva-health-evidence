/**
 * The bridge — one pass over Echevarne's SFTP mailbox.
 *
 * Contract (Joan Fajardo, 2026-08-31 + folder tree verified 2026-09-08):
 *   /peticiones            ← we PUT numeroPeticionLab.OML (one order per file)
 *   /peticiones/ack        ← ECH leaves numeroPeticionLab.ACK for our OMLs
 *   /peticiones/ack/procesados  ← we move ACKs we have read (assumed; asked)
 *   /peticiones/procesadas ← ECH moves OMLs it has processed
 *   /resultados            ← ECH leaves numeroPeticionLab.ORU
 *   /resultados/ack        ← we PUT numeroPeticionLab.ACK for each ORU (mandatory)
 *   /resultados/procesados ← we move ORUs we have processed
 *
 * Golden rules honoured here: every inbound file is ARCHIVED (deduped by
 * MSH-10) before it is processed; every ORU gets an ACK (CA or CE) even when
 * we cannot match it; nothing is deleted — files are moved to procesados
 * (ECH purges the mailbox weekly anyway); a failure on one file never aborts
 * the pass. Encoding: ECH files are Latin-1 unless MSH-18 says otherwise.
 */
import { decodeHl7Bytes, parseHl7, getMshField } from "@/lib/lab-provider/hl7";
import { parseAck, buildOruAck } from "@/lib/lab-provider/ack";
import { EchevarneProvider } from "@/lib/lab-provider/echevarne";
import type { BridgeStore, BridgeCycle } from "./store";
import type { SftpLike } from "./sftp";
import { toHl7DateTime } from "./outbox";

export interface BridgeAlert {
  scope: string;
  message: string;
  meta?: Record<string, unknown>;
}

export interface BridgeSyncOptions {
  sftp: SftpLike;
  store: BridgeStore;
  now: Date;
  baseDir?: string;
  processingId?: "P" | "T";
  /** Hours an outbound OML may wait for its ACK before we alert. */
  ackTimeoutHours?: number;
  /**
   * Upload as `<name>.tmp` then rename, so ECH's poller can never read a
   * half-written order. OFF by default: their mailbox rejects the temp file
   * ("Permission denied /files/peticiones/X…OML.tmp", verified 2026-09-09),
   * so we write the final name directly.
   *
   * Why that is safe (Joan, 2026-09-17): their poller waits until the file's
   * size stops growing before reading it. Trouble would only come from a
   * writer that keeps the file open while it does other work. Ours never
   * does: the message is fully built in `lab_messages.raw` beforehand and
   * goes out as ONE `put` of a ~4 KB buffer — open, write, close, well under a
   * second. Do not turn the upload into a streamed or incremental write; that
   * invariant is what makes the plain put correct. A wrong read on their side
   * shows up as a CE in the ACK, which the pass already alerts on.
   */
  atomicUpload?: boolean;
  /**
   * Take only inbound files whose MSH-11 equals our own processing id and
   * leave the rest untouched for the other environment. Preview (T) and
   * Production (P) share ECH's single mailbox; MSH-11 is the HL7 field made
   * for exactly this split. OFF by default because today ECH stamps every
   * ORU "P", training ones included — asked them (2026-09-17) to echo the
   * OML's T/P; switch on (ECH_HONOUR_PROCESSING_ID=true) once they confirm.
   * Their ACKs already echo it.
   */
  honourProcessingId?: boolean;
  onAlert?: (a: BridgeAlert) => void;
}

export interface BridgeSyncReport {
  uploaded: string[];
  acksProcessed: string[];
  orusProcessed: string[];
  /** Re-delivered messages that had already been fully processed: re-ACKed, nothing else. */
  duplicates: string[];
  /** Re-delivered ORUs whose earlier pass never finished: processed now (also listed in orusProcessed). */
  retried: string[];
  /** Final/corrected reports that replaced the values of a cycle's existing result (MSH-10). */
  corrected: string[];
  /** Inbound files stamped with the other environment's MSH-11 — left in place, untouched. */
  otherEnvironment: string[];
  errors: { file: string; error: string }[];
  alerts: BridgeAlert[];
}

export const ACK_TIMEOUT_HOURS = 48;

export async function runBridgeSync(opts: BridgeSyncOptions): Promise<BridgeSyncReport> {
  const base = (opts.baseDir ?? "/files").replace(/\/$/, "");
  const processingId = opts.processingId ?? "T";
  const report: BridgeSyncReport = { uploaded: [], acksProcessed: [], orusProcessed: [], duplicates: [], retried: [], corrected: [], otherEnvironment: [], errors: [], alerts: [] };
  const alert = (a: BridgeAlert) => {
    report.alerts.push(a);
    opts.onAlert?.(a);
  };
  const dirs = {
    peticiones: `${base}/peticiones`,
    peticionesAck: `${base}/peticiones/ack`,
    peticionesAckProcesados: `${base}/peticiones/ack/procesados`,
    resultados: `${base}/resultados`,
    resultadosAck: `${base}/resultados/ack`,
    resultadosProcesados: `${base}/resultados/procesados`,
  };

  // ── 1. Outbound: upload queued OMLs.
  for (const msg of await opts.store.listQueuedOutbound()) {
    const finalPath = `${dirs.peticiones}/${msg.filename}`;
    try {
      if (opts.atomicUpload) {
        const tmpPath = `${finalPath}.tmp`;
        await opts.sftp.put(tmpPath, Buffer.from(msg.raw, "utf8"));
        await opts.sftp.rename(tmpPath, finalPath);
      } else {
        await opts.sftp.put(finalPath, Buffer.from(msg.raw, "utf8"));
      }
      await opts.store.markOutboundSent(msg.id, opts.now);
      report.uploaded.push(msg.filename);
    } catch (e) {
      report.errors.push({ file: msg.filename, error: errMsg(e) });
    }
  }

  // ── 2. Inbound ACKs for our OMLs.
  for (const entry of await safeList(opts.sftp, dirs.peticionesAck, report)) {
    if (entry.type !== "file" || !/\.ack$/i.test(entry.name)) continue;
    await ingestAck(opts, `${dirs.peticionesAck}/${entry.name}`, entry.name, report, alert, {
      moveTo: `${dirs.peticionesAckProcesados}/${entry.name}`,
    });
  }

  // ── 2b. ACKs that reached procesados before we read them. ECH's own
  // process moved 254889.ACK there on 2026-09-16 while this pass only looked
  // at /ack, so the order looked unacknowledged until its results arrived.
  // Read-only catch-up: MSH-10 dedupe makes re-reading free, nothing is
  // moved, and only a newly archived ACK shows up in the report.
  for (const entry of await safeList(opts.sftp, dirs.peticionesAckProcesados, report)) {
    if (entry.type !== "file" || !/\.ack$/i.test(entry.name)) continue;
    await ingestAck(opts, `${dirs.peticionesAckProcesados}/${entry.name}`, entry.name, report, alert, { catchUp: true });
  }

  // ── 3. Inbound ORUs (results). Always answered with an ACK, always archived, always moved.
  for (const entry of await safeList(opts.sftp, dirs.resultados, report)) {
    if (entry.type !== "file" || !/\.oru$/i.test(entry.name)) continue;
    const path = `${dirs.resultados}/${entry.name}`;
    // Set once the message is archived: a failure after that point is written
    // onto the row, so the next pass knows the work was never finished.
    let inboundId: string | null = null;
    let cycle: BridgeCycle | null = null;
    try {
      const text = decodeHl7Bytes(await opts.sftp.get(path));
      if (belongsToOtherEnvironment(opts, text)) {
        report.otherEnvironment.push(entry.name);
        continue;
      }
      const parsed = EchevarneProvider.parseResults(text);
      const controlId = parsed.messageControlId ?? entry.name;
      const petition = parsed.providerReference || entry.name.replace(/\.oru$/i, "");

      const archived = await opts.store.archiveInbound({ msgType: "ORU", messageControlId: controlId, raw: text });
      let ackOk = true;
      let errorCode: string | undefined;
      let errorText: string | undefined;

      if (archived.duplicate && archived.status === "processed") {
        // Re-delivery of a message we finished (ECH retries when it lacks our
        // ACK): re-ACK, don't re-process. Archived-but-unfinished is NOT this
        // case — a 'received' row means an earlier pass died between archiving
        // and recording, an 'error' row means it could not be matched then;
        // both are processed again below, with the row they already have, and
        // only a pass that completes answers the lab with CA.
        report.duplicates.push(entry.name);
      } else {
        inboundId = archived.id;
        if (!inboundId) throw new Error("archived message has no id");
        if (archived.duplicate) report.retried.push(entry.name);
        cycle = parsed.placerOrderNumber ? await opts.store.findCycleByPlacer(parsed.placerOrderNumber) : null;
        if (!cycle) {
          ackOk = false;
          errorCode = "UNMATCHED_ORDER";
          errorText = `No cycle with placer ${parsed.placerOrderNumber ?? "(none)"}`;
          alert({ scope: "bridge.oru", message: "ORU does not match any cycle", meta: { file: entry.name, placer: parsed.placerOrderNumber, filler: petition } });
          await opts.store.markInboundProcessed(inboundId, errorText);
        } else if (cycle.kitLabelCode && parsed.providerReference && cycle.kitLabelCode !== parsed.providerReference) {
          ackOk = false;
          errorCode = "LABEL_MISMATCH";
          errorText = `Cycle ${cycle.id} expects petition ${cycle.kitLabelCode}, ORU carries ${parsed.providerReference}`;
          alert({ scope: "bridge.oru", message: "ORU petition number does not match the cycle's sticker", meta: { file: entry.name, cycleId: cycle.id } });
          await opts.store.markInboundProcessed(inboundId, errorText, cycle.id);
        } else {
          await processResults(opts, cycle, parsed, inboundId, report, alert, { retry: archived.duplicate });
        }
      }

      const ackText = buildOruAck({
        messageControlId: ackControlId(petition, opts.now),
        messageDateTime: toHl7DateTime(opts.now),
        processingId,
        ackedMessageControlId: controlId,
        ok: ackOk,
        errorCode,
        errorText,
      });
      await opts.sftp.put(`${dirs.resultadosAck}/${petition}.ACK`, Buffer.from(ackText, "utf8"));
      report.orusProcessed.push(entry.name);
      // Our own ACK is traffic too: archive it. Failing to archive must not
      // undo a delivered ACK, so it is reported rather than thrown.
      try {
        await opts.store.archiveOutboundAck({ cycleId: cycle?.id ?? archived.cycleId ?? null, messageControlId: ackControlId(petition, opts.now), raw: ackText }, opts.now);
      } catch (e) {
        report.errors.push({ file: `${petition}.ACK`, error: `ACK delivered but not archived: ${errMsg(e)}` });
      }
      await fileConsumed(opts, path, `${dirs.resultadosProcesados}/${entry.name}`, entry.name, report, alert);
    } catch (e) {
      report.errors.push({ file: entry.name, error: errMsg(e) });
      alert({ scope: "bridge.oru", message: "ORU processing failed — file left in /resultados for the next pass", meta: { file: entry.name, error: errMsg(e), cycleId: cycle?.id } });
      // No ACK went out, the file stays: the next pass finds the archived row
      // in 'error' and processes it again instead of treating it as done.
      if (inboundId) {
        await opts.store.markInboundProcessed(inboundId, `processing failed: ${errMsg(e)}`, cycle?.id).catch(() => undefined);
      }
    }
  }

  // ── 4. Stale orders: sent but never acknowledged.
  const cutoff = new Date(opts.now.getTime() - (opts.ackTimeoutHours ?? ACK_TIMEOUT_HOURS) * 3_600_000);
  for (const stale of await opts.store.listSentWithoutAck(cutoff)) {
    alert({ scope: "bridge.ack", message: "OML sent without ACK past the timeout", meta: { file: stale.filename, messageControlId: stale.messageControlId, cycleId: stale.cycleId } });
  }

  return report;
}

/**
 * Move a file we have already consumed to its «procesados» folder.
 *
 * By the time this runs the message is archived, the order is updated and (for
 * an ORU) the ACK is written, so a failure here is NOT a processing failure and
 * must not read like one: the work stands, MSH-10 dedupe stops the next pass
 * from acting on it twice. What it does mean is that the file will keep coming
 * back every pass — which is exactly how ECH's write permissions bit us on
 * /peticiones (2026-09-09 → 09-15), so it gets its own alert.
 */
async function fileConsumed(
  opts: BridgeSyncOptions,
  from: string,
  to: string,
  name: string,
  report: BridgeSyncReport,
  alert: (a: BridgeAlert) => void,
): Promise<void> {
  try {
    await opts.sftp.rename(from, to);
  } catch (e) {
    report.errors.push({ file: name, error: `processed, but could not be moved: ${errMsg(e)}` });
    alert({
      scope: "bridge.mailbox",
      message: "File processed but could not be moved to procesados — check the mailbox permissions",
      meta: { file: name, to, error: errMsg(e) },
    });
  }
}

async function processResults(
  opts: BridgeSyncOptions,
  cycle: BridgeCycle,
  parsed: ReturnType<typeof EchevarneProvider.parseResults>,
  inboundId: string,
  report: BridgeSyncReport,
  alert: (a: BridgeAlert) => void,
  mode: { retry?: boolean } = {},
): Promise<void> {
  // A partial report (ORC-5 = A) is archived and acknowledged but never
  // recorded or announced: the patient sees one complete panel when the
  // final report comes (decision 2026-09-22). The cycle notes the wait.
  if (parsed.orderStatus === "partial") {
    await opts.store.setCycleStatus(cycle.id, "results_partial");
    await opts.store.markInboundProcessed(inboundId, undefined, cycle.id);
    return;
  }
  // A final or corrected report for a cycle that already has a result
  // replaces that result's values (store.recordResults) — one result, one
  // email. The same path makes a retry safe: a message whose earlier pass
  // recorded the values and died before closing the row, or died half-way
  // through a replacement, records them again over the same result instead
  // of leaving a second row or an empty one.
  const recorded = await opts.store.recordResults(cycle, parsed, opts.now);
  // Results for an order the lab never acknowledged (seen in training,
  // 2026-09-17: ORU without any ACK in /peticiones/ack). The ORU proves they
  // processed the OML, so it is closed as implicitly accepted — otherwise the
  // stale-order sweep would flag a completed order on every pass. Reported
  // once, because a missing ACK is still a gap in the lab's process.
  for (const unacked of await opts.store.listUnackedOutboundForCycle(cycle.id)) {
    await opts.store.markOutboundImpliedAck(unacked.id, opts.now);
    alert({
      scope: "bridge.ack",
      message: "Results arrived for an order the lab never acknowledged — closed as implicitly accepted",
      meta: { cycleId: cycle.id, messageControlId: unacked.messageControlId, oru: parsed.messageControlId },
    });
  }
  await opts.store.setCycleStatus(cycle.id, "results_final", { lab_result_id: recorded.labResultId });
  await opts.store.markInboundProcessed(inboundId, undefined, cycle.id);
  if (recorded.processed === 0) {
    alert({ scope: "bridge.oru", message: "ORU processed but no biomarker could be mapped", meta: { cycleId: cycle.id, labResultId: recorded.labResultId } });
  }
  // A retry re-recording the same message is not a correction.
  if (recorded.replaced && !mode.retry) report.corrected.push(parsed.messageControlId ?? cycle.id);
}

/**
 * One ACK from Echevarne for one of our OMLs. `moveTo` archives the file
 * into procesados once read; `catchUp` is the read-only sweep of procesados,
 * where an already-archived ACK is the normal case and stays silent.
 */
async function ingestAck(
  opts: BridgeSyncOptions,
  path: string,
  name: string,
  report: BridgeSyncReport,
  alert: (a: BridgeAlert) => void,
  mode: { moveTo?: string; catchUp?: boolean },
): Promise<void> {
  try {
    const text = decodeHl7Bytes(await opts.sftp.get(path));
    if (belongsToOtherEnvironment(opts, text)) {
      if (!mode.catchUp) report.otherEnvironment.push(name);
      return;
    }
    const ack = parseAck(text);
    const archived = await opts.store.archiveInbound({ msgType: "ACK", messageControlId: ack.messageControlId || name, raw: text });
    if (archived.duplicate) {
      if (!mode.catchUp) report.duplicates.push(name);
    } else {
      const outbound = await opts.store.findOutboundByControlId(ack.ackedMessageControlId);
      if (!outbound) {
        alert({ scope: "bridge.ack", message: "ACK for an unknown OML", meta: { file: name, msa2: ack.ackedMessageControlId } });
        await opts.store.markInboundProcessed(archived.id!, `no outbound message with MSH-10 ${ack.ackedMessageControlId}`);
      } else {
        await opts.store.markOutboundAcked(outbound.id, { ok: ack.ok, code: ack.code, text: ack.errorText ?? ack.errorCode }, opts.now);
        await opts.store.markInboundProcessed(archived.id!, undefined, outbound.cycleId);
        if (!ack.ok) {
          alert({ scope: "bridge.ack", message: "Echevarne REJECTED an order (CE)", meta: { file: name, code: ack.errorCode, text: ack.errorText, cycleId: outbound.cycleId } });
        }
      }
      report.acksProcessed.push(mode.catchUp ? `${name} (from procesados)` : name);
    }
    if (mode.moveTo) await fileConsumed(opts, path, mode.moveTo, name, report, alert);
  } catch (e) {
    report.errors.push({ file: name, error: errMsg(e) });
  }
}

/**
 * True when honourProcessingId is on and the message carries a non-empty
 * MSH-11 different from ours. An unreadable header never claims a file for
 * the other side: it falls through to normal processing and its error path.
 */
function belongsToOtherEnvironment(opts: BridgeSyncOptions, text: string): boolean {
  if (!opts.honourProcessingId) return false;
  let msh11 = "";
  try {
    msh11 = getMshField(parseHl7(text), 11).trim().toUpperCase();
  } catch {
    return false;
  }
  return msh11 !== "" && msh11 !== (opts.processingId ?? "T");
}

/** MSH-10 for our ACK: petition + 'A' + hhmmss (≤ 20 chars, unique per pass). */
function ackControlId(petition: string, now: Date): string {
  return `${petition}A${toHl7DateTime(now).slice(8)}`.slice(0, 20);
}

async function safeList(sftp: SftpLike, dir: string, report: BridgeSyncReport) {
  try {
    return await sftp.list(dir);
  } catch (e) {
    report.errors.push({ file: dir, error: errMsg(e) });
    return [];
  }
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}
