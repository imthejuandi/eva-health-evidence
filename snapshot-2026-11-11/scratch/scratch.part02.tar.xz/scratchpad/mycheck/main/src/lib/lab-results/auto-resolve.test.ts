import { describe, it, expect, vi } from "vitest";
import { fakeSupabase, ops, argsOf } from "@/lib/testing/fake-supabase";
import { resolvePendingLab, type AutoResolveDeps } from "./auto-resolve";

// Under the cron there is no session: every helper must receive the
// service-role client, and nothing may reach for the cookie-bound one.
vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("RLS client must not be created under the cron");
  },
}));

function deps(overrides: Partial<AutoResolveDeps> = {}): AutoResolveDeps {
  return {
    getCurrentVersion: vi.fn(async () => ({ id: "v7" })) as unknown as AutoResolveDeps["getCurrentVersion"],
    createNewVersion: vi.fn(async () => ({ id: "v-new" })) as unknown as AutoResolveDeps["createNewVersion"],
    getUserProfile: vi.fn(async () => ({ id: "u1", email: "p@example.test", full_name: "Ana Prueba", locale: "es" })) as unknown as AutoResolveDeps["getUserProfile"],
    getWearableData: vi.fn(async () => []) as unknown as AutoResolveDeps["getWearableData"],
    generateSummary: vi.fn(async () => undefined) as unknown as AutoResolveDeps["generateSummary"],
    sendEmail: vi.fn(async () => undefined) as unknown as AutoResolveDeps["sendEmail"],
    completeCycleForLabResult: vi.fn(async () => ["c4"]) as unknown as AutoResolveDeps["completeCycleForLabResult"],
    ...overrides,
  };
}

const bv = [{ biomarker_key: "glucose_fasting", biomarker_name: "Glucosa", value: 90, unit: "mg/dL", zone: "optimal", optimal_low: 70, optimal_high: 99 }];

describe("resolvePendingLab — the 72-hour fallback acts with the service-role client", () => {
  it("stamps the last context version, runs the pipeline with the admin client, marks ready, closes the cycle and emails", async () => {
    const { client, calls } = fakeSupabase((c) => (c.table === "biomarker_values" ? { data: bv } : { data: null }));
    const d = deps();
    const r = await resolvePendingLab(client, "lab-1", "u1", d);
    expect(r).toEqual({ biomarkerCount: 1, cyclesClosed: ["c4"] });

    expect(d.getCurrentVersion).toHaveBeenCalledWith("u1", client);
    expect(d.createNewVersion).not.toHaveBeenCalled();
    expect(d.getUserProfile).toHaveBeenCalledWith("u1", client);
    expect(d.getWearableData).toHaveBeenCalledWith("u1", 30, client);
    expect(vi.mocked(d.generateSummary).mock.calls[0][5]).toBe(client);
    expect(d.completeCycleForLabResult).toHaveBeenCalledWith(client, "lab-1");
    expect(vi.mocked(d.sendEmail).mock.calls[0].slice(0, 2)).toEqual(["p@example.test", "results-ready"]);

    const updates = calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update")).map((c) => argsOf(c, "update")?.[0]);
    expect(updates[0]).toMatchObject({ patient_context_version_id: "v7", status: "processing", transient_context: { skipped: true, auto_resolved: true } });
    expect(updates[1]).toEqual({ status: "ready" });
  });

  it("with no saved context it mints an empty version through the admin client", async () => {
    const { client } = fakeSupabase((c) => (c.table === "biomarker_values" ? { data: bv } : { data: null }));
    const d = deps({ getCurrentVersion: vi.fn(async () => null) as unknown as AutoResolveDeps["getCurrentVersion"] });
    await resolvePendingLab(client, "lab-1", "u1", d);
    expect(vi.mocked(d.createNewVersion).mock.calls[0][0]).toBe("u1");
    expect(vi.mocked(d.createNewVersion).mock.calls[0][2]).toBe(client);
  });

  it("a lab with no biomarker values is not marked ready and no email goes out", async () => {
    const { client, calls } = fakeSupabase((c) => (c.table === "biomarker_values" ? { data: [] } : { data: null }));
    const d = deps();
    await expect(resolvePendingLab(client, "lab-1", "u1", d)).rejects.toThrow(/no biomarker_values/);
    expect(calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update")).map((c) => argsOf(c, "update")?.[0])).not.toContainEqual({ status: "ready" });
    expect(d.sendEmail).not.toHaveBeenCalled();
  });

  it("a cycle that cannot be closed does not undo a ready lab", async () => {
    const { client } = fakeSupabase((c) => (c.table === "biomarker_values" ? { data: bv } : { data: null }));
    const d = deps({ completeCycleForLabResult: vi.fn(async () => { throw new Error("boom"); }) as unknown as AutoResolveDeps["completeCycleForLabResult"] });
    const r = await resolvePendingLab(client, "lab-1", "u1", d);
    expect(r.cyclesClosed).toEqual([]);
    expect(d.sendEmail).toHaveBeenCalled();
  });
});
