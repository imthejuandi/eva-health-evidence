import { describe, it, expect } from "vitest";
import { normalizeHostKeyFingerprint, hostKeyMatches, readSftpConfigFromEnv } from "./sftp";

// One key, three spellings of the same SHA-256 fingerprint.
const HEX = "a2b4c6d8e0f1a2b4c6d8e0f1a2b4c6d8e0f1a2b4c6d8e0f1a2b4c6d8e0f1a2b4";
const COLON = HEX.match(/.{2}/g)!.join(":");
const B64 = Buffer.from(HEX, "hex").toString("base64").replace(/=+$/, "");

describe("SFTP host-key pinning (audit 2026-09-21, F12)", () => {
  it("normalizes hex, colon-separated hex and OpenSSH's SHA256:base64 to the same 64 hex chars", () => {
    expect(normalizeHostKeyFingerprint(HEX.toUpperCase())).toBe(HEX);
    expect(normalizeHostKeyFingerprint(COLON)).toBe(HEX);
    expect(normalizeHostKeyFingerprint(`SHA256:${B64}`)).toBe(HEX);
    expect(normalizeHostKeyFingerprint(`  sha256:${B64}=  `)).toBe(HEX);
  });

  it("rejects anything that is not a SHA-256 fingerprint", () => {
    for (const bad of ["", "abc", "MD5:aa:bb", HEX.slice(0, 40), `SHA256:${B64.slice(0, 20)}`, undefined, null]) {
      expect(normalizeHostKeyFingerprint(bad)).toBeNull();
    }
  });

  it("matches the presented key only when it is exactly the pinned one", () => {
    expect(hostKeyMatches(HEX, HEX)).toBe(true);
    expect(hostKeyMatches(Buffer.from(HEX, "hex"), HEX)).toBe(true);
    expect(hostKeyMatches(HEX.replace(/b4$/, "b5"), HEX)).toBe(false); // one nibble off → refused
    expect(hostKeyMatches("not-a-key", HEX)).toBe(false);
  });

  it("readSftpConfigFromEnv carries the normalized fingerprint and ignores a malformed one", () => {
    const base = { ECH_SFTP_HOST: "sftp.example", ECH_SFTP_USER: "u", ECH_SFTP_PASSWORD: "p" } as unknown as NodeJS.ProcessEnv;
    expect(readSftpConfigFromEnv({ ...base, ECH_SFTP_HOST_KEY_SHA256: `SHA256:${B64}` } as NodeJS.ProcessEnv)?.hostKeySha256).toBe(HEX);
    expect(readSftpConfigFromEnv({ ...base, ECH_SFTP_HOST_KEY_SHA256: "garbage" } as NodeJS.ProcessEnv)?.hostKeySha256).toBeUndefined();
    expect(readSftpConfigFromEnv(base)?.hostKeySha256).toBeUndefined();
  });
});
