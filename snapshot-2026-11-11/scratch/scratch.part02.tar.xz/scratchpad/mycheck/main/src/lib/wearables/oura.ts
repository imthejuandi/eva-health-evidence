import type { WearableAdapter, WearableImportResult } from "./interface";

export class OuraAdapter implements WearableAdapter {
  source = "oura";
  async parseExport(_fileBuffer: Buffer): Promise<WearableImportResult> {
    throw new Error("Oura integration coming soon");
  }
}
