import type { WearableAdapter, WearableImportResult } from "./interface";

export class GarminAdapter implements WearableAdapter {
  source = "garmin";
  async parseExport(_fileBuffer: Buffer): Promise<WearableImportResult> {
    throw new Error("Garmin integration coming soon");
  }
}
