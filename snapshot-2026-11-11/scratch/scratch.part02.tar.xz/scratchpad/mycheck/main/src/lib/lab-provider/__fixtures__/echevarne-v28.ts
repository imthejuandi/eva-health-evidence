/**
 * The three ORU^R01 sample messages from the OFFICIAL Echevarne spec v2.8
 * (docs/vendor/echevarne/spec-v2.8-extracted.txt §1.3.3.1–1.3.3.3), plus the
 * OML example (§1.1.2.8) and both ACK examples (§1.2.1 / §1.4.1).
 *
 * Reconstruction notes:
 *  - The PDF wraps long segments across lines; each segment here is restored
 *    to a single line. Line breaks INSIDE result texts are the literal HL7
 *    escape `\.br\` exactly as the spec transmits them.
 *  - These are synthetic patients from the spec itself (APE1/APE2/NOMBRE,
 *    12345678T…), not real people.
 *  - String.raw keeps every backslash literal.
 *
 * Structural facts the tests assert:
 *  - EX1 (bioquímica/hormonas + alergia): ORC.5=CM (final), placer
 *    20253989090, filler W88800130, ORC.27=20251231000000, kit label
 *    Z000010X, NM values with EU comma, a TX conclusion, and the ED PDF.
 *  - EX2 (RAST + catecolaminas): ORC.5=A (PARTIAL), a `<0,500` bounded value,
 *    NTE comments, FT1 billing rows, ED PDF. LOINC present in OBX-3.4 of the
 *    first OBX (2345-7).
 *  - EX3 (microbiología): TX-only germs + antibiogram (sensitivity letters in
 *    OBX-6.2, MIC values like `>8,000` in OBX-5), CATALÁN accents, specimen
 *    OBX after SPM, ED PDF.
 */

export const ORU_EX1_BIOQUIMICA = String.raw`
MSH|^~\&|LABTRAK|ECHEVARNE|SOFT_HOSPITAL|ID_HOSPITAL|20250922162447||ORU^R01|W88800130-39|P|2.5|||AL||||||TCP
PID|1|17691009|1017876|W88800130|APE2^APE1|NOMBRE|19600101000000|M|||||^^^||8^SPANISH
PV1|1|O|^^^||||||||||||||||REFCLI|||||||||||||||||||||||||20250922000000||||||W88800130
ORC|RE|20253989090|W88800130|W88800130|CM||^^^^^URGENTE||20250922130600|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|1|20253989090|W88800130|ACTH^ACTH^1^B5000^ACTH^||20250922125700|20250922125800|20250922130200||||||||^^||||||20250922130200||LAB|F
OBX|1|NM|D0590^ACTH^^2141-0^^D0590||50,000|^pg/mL|0,000-46,000|H|||F|||20250922130200||^|
SPM|1|Z000010X^B5000||SVPCON^Pl/cong^^^|^||||||P||| - Pl/cong - ||||20250904000000
ORC|RE|20253989090|W88800130|W88800130|CM||^^^^^URGENTE||20250922130600|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|2|20253989090|W88800130|I1^Apis mellifera (ABEJA) ANTICUERPOS IgE / SUERO^1^P0743^I1^||20250922125700|20250922125900|20250922130300||||||||^^||||||20250922130300||LAB|F
OBX|1|NM|P0743^Apis mellifera (ABEJA) ANTICUERPOS IgE / SUERO^^6844-5^^P0743||0,110|^KU/L|0,000-0,200|N|||F|||20250922130300||^|
OBX|2|TX|P2082^Conclusion RAST^^^^P2082||No se detectan anticuerpos IgE Específicos.|^|||||F|||20250922130300||^|
SPM|1|Z000010Y^P0743||SVSUER^Suero^^^|^||||||P||| - Suero - ||||20250904000000
ORC|RE|20253989090|W88800130|W88800130|CM||^^^^^URGENTE||20250922130600|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|3|20253989090|W88800130|IGG4I1^ABEJA (VENENO) A mellifera ANTICUERPOS IgG4^1^P2030^IGG4I1^||20250922125700|20250922125900|20250922130300||||||||^^||||||20250922130300||LAB|F
OBX|1|NM|P2030^ABEJA (VENENO) A mellifera ANTICUERPOS IgG4^^56286-8^^P2030||0,010|^mgA/L|0,000-0,150|N|||F|||20250922130300||^|
SPM|1|Z000010Y^P2030||SVSUER^Suero^^^|^||||||P||| - Suero - ||||20250904000000
ORC|RE|20253989090|W88800130|W88800130|CM||^^^^^URGENTE||20250922130600|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|4|20253989090|W88800130|XXXX^Conclusión IgG4^1^P2083^XXXX^||20250922125700|20250922125900|20250922130600||||||||^^||||||20250922130600||LAB|F
OBX|1|TX|P2083^^^^^P2083||Un resultado alto de IgG4 específica no implica patología alérgica, sino una\.br\alta exposición al alérgeno.\.br\Útil en la monitorización de pacientes sometidos a terapia\.br\hiposensibilizante.|^|||||F|||20250922130600||^|
SPM|1|Z000010Y^P2083||^^^^|^||||||P||| -             - ||||20250904000000
ORC|RE|20253989090|W88800130|W88800130|CM||^^^^^URGENTE||20250922130600|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|5|20253989090|W88800130|INFORMEPDF^Documento adjunto INFORMEPDF^^^INFORMEPDF^||20250922130600|20250922130600|20250922130600||||||||^^||||||20250922130600||LAB|F
OBX|1|ED|INPDF^Documento adjunto INFORMEPDF^^LAB^^INPDF||PDF^AP^PDF^Base64^JVBERi0xLjQKJcfsj6I.......QolJUVPRgo=|^| ||||F|||20250922130600||^|
`.trim();

export const ORU_EX2_RAST_PARTIAL = String.raw`
MSH|^~\&|LABTRAK|ECHEVARNE|SOFT_HOSPITAL|ID_HOSPITAL|20180319200030||ORU^R01|N00946463-101151|P|2.5|||AL||||||SOAP
PID|1|11048242|12345678T|N00946463|GOMEZ^EVA|RODRIGUEZ|19650116000000|F|||||^^^||8^SPANISH
PV1|1|O|||||||||||||||||IDCLIENT0510101460|||||||||||||||||||||||||20180316000000||||||IDCLIENT12345
ORC|RE|0510101460|N00946463||A||^^^^^||20180401105425|^^||12584^LOPEZ&GUTIERREZ^LUIS^^^|||20251231000000||||||||||||20251231000000
OBR|1|0510101460|N00946463|ATRGL^TRANSGLUTAMINASA TISULAR ANTICUERPOS IgA^1^I2532^ATRGL^3130||20180316165500|20180319192500|20180319192500||||||||12345^LOPEZ GUTIERREZ^LORENZO||||||||LAB|F
NTE|1|P|Comment line 1 of OBR||
NTE|2|P|Comment line 2 of OBR||
OBX|1|NM|I1433^TRANSGLUTAMINASA TISULAR ANTICUERPOS IgA^^2345-7^^I1433||<0,500|^U/mL|0,000-15,000|N|||F|||20180319192500||^|
NTE|1|P|Comment line 1 of OBX 1||
NTE|2|P|Comment line 2 of OBX 1||
OBX|2|TX|I1434^Resultado Transglutaminasa IgA^^^^I1434||Negativo|^| ||||F|||20180319192500||^|
NTE|1|P|Comment line 1 of OBX 2||
NTE|2|P|Comment line 2 of OBX 2||
OBX|3|TX|I1435^Valoración I2532^^^^I1435||Valoración:\.br\ Negativo: Inferior a 15 U/mL\.br\ Positivo: Superior a 15 U/mL|^| ||||F|||20180319192500||^|
FT1|1|||||PY|ATRGL|TRANSGLUTAMINASA TISULAR ANTICUERPOS IgA||1||2,00
ORC|RE|0510101460|N00946463||A||^^^^^||20180401105425|^^||12584^LOPEZ&GUTIERREZ^LUIS^^^|||20251231000000||||||||||||20251231000000
OBR|2|0510101460|N00946463|CATF^CATECOLAMINAS FRACCIONADAS / ORINA^1^T3521^CATF^||20180309190600|20180319101500|20180319181600||||||||^^||||||||LAB|F
OBX|1|NM|B0313^DIURESIS^^^^B0313||1350,000|^mL| ||||F|||20180319181600||^|
NTE|1|P|Comment line 1 of OBX 1||
NTE|2|P|Comment line 2 of OBX 1||
OBX|2|NM|T1634^ADRENALINA^^^^T1634||13,500|^mg/24h|0,000-20,000|N|||F|||20180319181600||^|
OBX|3|NM|T1635^NOR-ADRENALINA^^^^T1635||69,500|^mg/24h|15,000-80,000|N|||F|||20180319181600||^|
OBX|4|NM|T1636^DOPAMINA^^^^T1636||340,100|^mg/24h|65,000-400,000|N|||F|||20180319181600||^|
NTE|1|P|Comment line 1 of OBX 4||
NTE|2|P|Comment line 2 of OBX 4||
NTE|3|P|Comment line 3 of OBX 4||
OBX|5|TX|T1690^Referencias T3521^^^^T1690||Si el resultado obtenido es inferior al límite de cuantificación del método no se informa del valor de concentración en 24 horas sino del valor en mg/L\.br\\.br\Valores de referencia según TIETZ Textbook of Clinical Chemistry and Molecular Diagnosis, 4th. edition, 2006.\.br\\.br\\.br\Valores de referencia:\.br\\.br\Adrenalina:     Inferior a 20 mg/24h\.br\\.br\Nor-Adrenalina: Entre 15 - 80 mg/24h\.br\\.br\Dopamina:       Entre 65 - 400 mg/24h|^| ||||F|||20180319181600||^|
ORC|RE|0510101460|N00946463|N00946463|A||^^^^^||20180401105425|^^||12584^LOPEZ&GUTIERREZ^LUIS^^^|||20251231000000||||||||||||20251231000000
OBR|3|0510101460|N00946463|INFORMEPDF^Documento adjunto INFORMEPDF^^||20180316165500|20180319192500|20180319192500||||||||^^||||||||LAB|F
OBX|1|ED|INPDF^Documento adjunto INFORMEPDF^^LAB^^INPDF||PDF^AP^PDF^Base64^JVBERi0xLjQKJcfsj6I.......QolJUVPRgo=|^| ||||F|||20180319192500||^|
FT1|1|||||PY|CATF|CATECOLAMINAS FRACCIONADAS / ORINA ||1||4,50|LAB|Laboratorio
`.trim();

export const ORU_EX3_MICRO = String.raw`
MSH|^~\&|LABTRAK|ECHEVARNE|SOFT_HOSPITAL|ID_HOSPITAL|20251030123254||ORU^R01|W88800151-80|P|2.5|||AL||||||TCP
PID|1|17691026|12345678T|W88800151|APE2^APE1|NOMBRE|19400101000000|M|||||^^^||9^CATALÁN
PV1|1|O|^^^||||||||||||||||REF-CLI|||||||||||||||||||||||||20251027000000||||||50201
ORC|RE|20253967069|W88800151|W88800151|CM||^^^^^||20250122101300|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|1|20253967069|W88800151|CUL^Cultivo muestra^1^M1100^CUL^||20250117133900|20250120074800|20250122101300||||||||^^||||||20250122101300||LAB|F
OBX|1|TX|M9998^UBICACION ANAT^^^^M9998||umbilical|^|||||F|||20250122101300||^|
OBX|2|TX|M9999^Mostra:^^^^M9999||Pus|^|||||F|||20250122101300||^|
OBX|3|TX|M0305^RESULTADO CULTIVO^^^^M0305||RESULTAT\.br\S'observa creixement de:|^|||||F|||20250122101300||^|
OBX|4|TX|M0100^RESULTADO 1^^^^M0100||Força|^||N|||F|||20250122101300||^|
OBX|5|TX|M9997^GERMEN 1^^^^M9997||Corynebacterium striatum|^||N|||F|||20250122101300||^|
OBX|6|TX|PEN^Penicilina^^^^M9997|||^R|||||F|||20250122101300||^|
OBX|7|TX|CLI^Clindamicina^^^^M9997|||^R|||||F|||20250122101300||^|
OBX|8|TX|CIP^Ciprofloxacino^^^^M9997|||^R|||||F|||20250122101300||^|
OBX|9|TX|MXF^Moxifloxacino^^^^M9997|||^R|||||F|||20250122101300||^|
OBX|10|TX|GEN^Gentamicina^^^^M9997|||^S|||||F|||20250122101300||^|
OBX|11|TX|VAN^Vancomicina^^^^M9997|||^S|||||F|||20250122101300||^|
OBX|12|TX|LNZ^Linezolid^^^^M9997|||^S|||||F|||20250122101300||^|
OBX|13|TX|CXM^Cefuroxima^^^^M9997|||^S|||||F|||20250122101300||^|
OBX|14|TX|RIF^Rifampicina^^^^M9997|||^S|||||F|||20250122101300||^|
OBX|15|TX|TMS^Trimetoprim+Sulfametoxazol^^^^M9997|||^S|||||F|||20250122101300||^|
OBX|16|TX|M0105^RESULTADO 2^^^^M0105||Escàs|^||N|||F|||20250122101300||^|
OBX|17|TX|M9996^GERMEN 2^^^^M9996||Citrobacter diversus|^||N|||F|||20250122101300||^|
OBX|18|TX|AMP^Ampicilina^^^^M9996||>8,000|^R|||||F|||20250122101300||^|
OBX|19|TX|AMC^Amoxicilina+Clavulánico^^^^M9996||<8,000|^S|||||F|||20250122101300||^|
OBX|20|TX|TZP^Piperacilina+Tazobactam^^^^M9996||<8,000|^S|||||F|||20250122101300||^|
OBX|21|TX|CXM^Cefuroxima^^^^M9996||<4,000|^S|||||F|||20250122101300||^|
OBX|22|TX|FOX^Cefoxitina^^^^M9996||<8,000|^S|||||F|||20250122101300||^|
OBX|23|TX|CTX^Cefotaxima^^^^M9996||<1,000|^S|||||F|||20250122101300||^|
OBX|24|TX|CAZ^Ceftazidima^^^^M9996||<1,000|^S|||||F|||20250122101300||^|
OBX|25|TX|FEP^Cefepime^^^^M9996||<0,500|^S|||||F|||20250122101300||^|
OBX|26|TX|CFM^Cefixima^^^^M9996||<1,000|^S|||||F|||20250122101300||^|
OBX|27|TX|IMP^Imipenem^^^^M9996||<1,000|^S|||||F|||20250122101300||^|
OBX|28|TX|MER^Meropenem^^^^M9996||<0,120|^S|||||F|||20250122101300||^|
OBX|29|TX|ETP^Ertapenem^^^^M9996||<0,120|^S|||||F|||20250122101300||^|
OBX|30|TX|ATM^Aztreonam^^^^M9996||<1,000|^S|||||F|||20250122101300||^|
OBX|31|TX|CIP^Ciprofloxacino^^^^M9996||<0,060|^S|||||F|||20250122101300||^|
OBX|32|TX|LVX^Levofloxacino^^^^M9996||<0,500|^S|||||F|||20250122101300||^|
OBX|33|TX|GEN^Gentamicina^^^^M9996||<2,000|^S|||||F|||20250122101300||^|
OBX|34|TX|TOB^Tobramicina^^^^M9996||<2,000|^S|||||F|||20250122101300||^|
OBX|35|TX|AMK^Amicacina^^^^M9996||<8,000|^S|||||F|||20250122101300||^|
OBX|36|TX|TGC^Tigeciclina^^^^M9996||<1,000|^R|||||F|||20250122101300||^|
OBX|37|TX|FOF^Fosfomicina^^^^M9996||<16,000|^S|||||F|||20250122101300||^|
OBX|38|TX|SXT^Cotrimoxazol^^^^M9996||<2/38|^S|||||F|||20250122101300||^|
OBX|39|TX|M0106^RESULTADO 3^^^^M0106||Abundant|^||N|||F|||20250122101300||^|
OBX|40|TX|M9995^GERMEN 3^^^^M9995||Anaerococcus vaginalis|^||N|||F|||20250122101300||^|
OBX|41|TX|PEN^Penicilina^^^^M9995||<0,016|^S|||||F|||20250122101300||^|
OBX|42|TX|AMC^Amoxicilina+Clavulánico^^^^M9995||<0,016|^S|||||F|||20250122101300||^|
OBX|43|TX|TZP^Piperacilina+Tazobactam^^^^M9995||<0,016|^S|||||F|||20250122101300||^|
OBX|44|TX|FOX^Cefoxitina^^^^M9995||0,094|^S|||||F|||20250122101300||^|
OBX|45|TX|IMP^Imipenem^^^^M9995||0,040|^S|||||F|||20250122101300||^|
OBX|46|TX|MTZ^Metronidazol^^^^M9995||0,380|^S|||||F|||20250122101300||^|
OBX|47|TX|CLI^Clindamicina^^^^M9995||0,047|^S|||||F|||20250122101300||^|
OBX|48|TX|MXF^Moxifloxacino^^^^M9995||0,064|^S|||||F|||20250122101300||^|
OBX|49|TX|M0498^SENSIBILIDADES^^^^M0498||S-Sensible, règim de dosificació estàndard: Un microorganisme es caracteritza com a Sensible, règim de dosificació estàndard*, quan hi ha una alta probabilitat d'èxit terapèutic usant un règim de dosificació estàndard de l'agent.\.br\I-Sensible, quan s'incrementa l'exposició: Un microorganisme es caracteritza com a Sensible, quan s'incrementa l'exposició*, quan hi ha una alta probabilitat d'èxit terapèutic perquè l'exposició a l'agent està incrementada per un ajustament del règim de dosificació o per concentració al lloc de la infecció.\.br\R-Resistent: Un microorganisme es caracteritza com a resistent quan hi ha una alta probabilitat de fracàs terapèutic fins i tot quan hi ha un increment de l'exposició*\.br\\.br\*L'exposició està en funció del mode d'administració, la dosi, l'interval entre dosis, el temps d'infusió, així com la distribució, el metabolisme i l'excreció de l'antimicrobià, que poden influir al microorganisme infectant al lloc de la infecció .|^|||||F|||20250122101300||^|
SPM|1|Z000011J^M1100||XXPUS^Pus^^PUS^Pus|UMBI^umbilical||||||P|||Pus - Pus - umbilical||||20251022000000
OBX|1|TX|M1100^[20/01/2025 07:48 JRAGUERA] 1.+atb cory\.br\[20/01/2025 11:34 JRAGUERA] 3.atb ana
ORC|RE|20253967069|W88800151|W88800151|CM||^^^^^||20250122101300|^^||^^^^^|||20251231000000||||||||||||20251231000000
OBR|2|20253967069|W88800151|INFORMEPDF^Documento adjunto INFORMEPDF^^^INFORMEPDF^||20250122101300|20250122101300|20250122101300||||||||^^||||||20250122101300||LAB|F
OBX|1|ED|INPDF^Documento adjunto INFORMEPDF^^LAB^^INPDF||PDF^AP^PDF^Base64^JVBERi0xLjcKJeTjz9IKNSAwIG9iago8PC9UeXBlL1hPY....QolJUVPRgo=|^| ||||F|||20250122101300||^|
`.trim();

/** OML^O21 example (§1.1.2.8) — the shape WE must emit. */
export const OML_EXAMPLE = String.raw`
MSH|^~\&|SOFT_HOSPITAL|HOSPITAL|LABTRAK|ECHEVARNE|20180313112000||OML^O21|N00894051-93876|P|2.5|||AL|||UTF-8
PID|1||1234^^^HIS^ID~12345678Z^^^^DNI~456789X^^^^PASAPORTE~043674985^^^^NHC||GARCIA^JOSEFA|RODRIGUEZ|19890127|F|65^10||||931478526~657123456~935689871||8
PV1|1|O|||||||||||||||||2018H002108^^^123456789~ABC123456^^123456~1234567890123456789|||||||||||||||||||||||||20180313000000
ORC|NW|45689JKN2018^REF-CLIENT|N00894051^^Z00001DQ||SC||^^^^^N||20180313050400|^^^^^^^^223&ASI&C12345678^A^^^^88888^^^^^^^^186019&&&X12345678^03||0812226^ROCA RIBAS SERDA^FRANCESC^^^^^^^^^^^^^&OBSERVACIONES DE LA PETICION|^125^2||20180313120550||||||||||||||A
OBR|1|45689JKN2018|N00894051^^Z00001DQ|H^^^||20180313050400
SPM|1|||^||||||||||||||20180312050505
BLG|||
`.trim();

/** ACK examples: ECH answering our OML (§1.2.1) and us answering their ORU (§1.4.1). */
export const ACK_OML_OK = String.raw`
MSH|^~\&|LABTRAK|ECHEVARNE|SOFT_HOSPITAL|ID_HOSPITAL|20180314112700||ACK^^ACK|251009|P|2.5|||AL|ER
MSA|CA|N00894051-93876
`.trim();

export const ACK_OML_ERROR = String.raw`
MSH|^~\&|LABTRAK|ECHEVARNE|SOFT_HOSPITAL|ID_HOSPITAL|201803141253||ACK^^ACK|251164|P|2.5|||AL|ER
MSA|CE|N00894051-93876
ERR||OML||E|CODIGO_ERROR^DESCRIPCIÓN_ERROR||||
`.trim();
