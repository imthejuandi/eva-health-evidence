/**
 * Calculated/derived metrics from raw biomarker values.
 * Each metric: check required biomarkers → calculate → classify → return.
 */

import type { Zone } from "./zone-classifier";

export interface CalculatedMetric {
  metricName: string;
  metricKey: string;
  value: number;
  unit: string;
  zone: Zone;
  interpretation: string;
  interpretation_es: string;
}

type BiomarkerMap = Record<string, number>;

function has(map: BiomarkerMap, ...keys: string[]): boolean {
  return keys.every((k) => k in map && map[k] != null && isFinite(map[k]));
}

// ─── 1. HOMA-IR ───

function calcHomaIR(map: BiomarkerMap): CalculatedMetric | null {
  // The seed (and Echevarne D0154) key insulin as `insulin_fasting`; the
  // legacy `fasting_insulin` spelling is still honoured.
  const insulinKey = has(map, "insulin_fasting") ? "insulin_fasting" : "fasting_insulin";
  if (!has(map, insulinKey, "glucose_fasting")) return null;
  const insulin = map[insulinKey];
  const glucose = map["glucose_fasting"];
  const value = (insulin * glucose) / 405;
  const rounded = Math.round(value * 100) / 100;

  let zone: Zone = "optimal";
  let interp = "Insulin sensitivity is optimal.";
  let interp_es = "La sensibilidad a la insulina es optima.";

  if (rounded < 0.5) {
    zone = "below_optimal";
    interp = "Unusually low HOMA-IR. May indicate hypoglycemia risk.";
    interp_es = "HOMA-IR inusualmente bajo. Puede indicar riesgo de hipoglucemia.";
  } else if (rounded > 1.5 && rounded <= 2.5) {
    zone = "above_optimal";
    interp = "Mild insulin resistance. Lifestyle changes recommended.";
    interp_es = "Resistencia a la insulina leve. Se recomiendan cambios de estilo de vida.";
  } else if (rounded > 2.5 && rounded <= 4.0) {
    zone = "above_optimal";
    interp = "Moderate insulin resistance. Action recommended.";
    interp_es = "Resistencia a la insulina moderada. Se recomienda accion.";
  } else if (rounded > 4.0) {
    zone = "critical_high";
    interp = "Significant insulin resistance. Medical attention advised.";
    interp_es = "Resistencia a la insulina significativa. Se aconseja atencion medica.";
  }

  return { metricName: "HOMA-IR", metricKey: "homa_ir", value: rounded, unit: "", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── 2. TG/HDL Ratio ───

function calcTgHdlRatio(map: BiomarkerMap): CalculatedMetric | null {
  if (!has(map, "triglycerides", "hdl_cholesterol")) return null;
  const value = Math.round((map["triglycerides"] / map["hdl_cholesterol"]) * 100) / 100;

  let zone: Zone = "optimal";
  let interp = "TG/HDL ratio is optimal: low atherogenic risk.";
  let interp_es = "Ratio TG/HDL optimo: bajo riesgo aterogenico.";

  if (value > 1.5 && value <= 3.0) {
    zone = "above_optimal";
    interp = "Elevated TG/HDL ratio. May indicate insulin resistance.";
    interp_es = "Ratio TG/HDL elevado. Puede indicar resistencia a la insulina.";
  } else if (value > 3.0) {
    zone = "critical_high";
    interp = "High TG/HDL ratio: significant metabolic and cardiovascular risk.";
    interp_es = "Ratio TG/HDL alto: riesgo metabolico y cardiovascular significativo.";
  }

  return { metricName: "TG/HDL Ratio", metricKey: "tg_hdl_ratio", value, unit: "", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── 3. De Ritis Ratio (AST/ALT) ───

function calcDeRitis(map: BiomarkerMap): CalculatedMetric | null {
  if (!has(map, "ast", "alt") || map["alt"] === 0) return null;
  const value = Math.round((map["ast"] / map["alt"]) * 100) / 100;

  let zone: Zone = "optimal";
  let interp = "De Ritis ratio is within the optimal range.";
  let interp_es = "El ratio De Ritis esta dentro del rango optimo.";

  if (value < 0.8) {
    zone = "below_optimal";
    interp = "Low De Ritis ratio may suggest non-alcoholic fatty liver. ALT predominance.";
    interp_es = "Ratio De Ritis bajo puede sugerir higado graso. Predominancia de ALT.";
  } else if (value > 1.2 && value <= 2.0) {
    zone = "above_optimal";
    interp = "Elevated De Ritis ratio. May indicate cardiac or muscle involvement.";
    interp_es = "Ratio De Ritis elevado. Puede indicar afectacion cardiaca o muscular.";
  } else if (value > 2.0) {
    zone = "critical_high";
    interp = "High De Ritis ratio. May suggest alcoholic liver disease or significant hepatic damage.";
    interp_es = "Ratio De Ritis alto. Puede sugerir enfermedad hepatica alcoholica o daño hepatico significativo.";
  }

  return { metricName: "De Ritis Ratio (AST/ALT)", metricKey: "de_ritis", value, unit: "", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── 4. Omega-3 Index ───

function calcOmega3Index(map: BiomarkerMap): CalculatedMetric | null {
  if (!has(map, "epa", "dha", "total_fatty_acids") || map["total_fatty_acids"] === 0) return null;
  const value = Math.round(((map["epa"] + map["dha"]) / map["total_fatty_acids"]) * 10000) / 100;

  let zone: Zone;
  let interp: string;
  let interp_es: string;

  if (value >= 8) {
    zone = "optimal";
    interp = "Omega-3 index is optimal: associated with lowest cardiovascular risk.";
    interp_es = "Indice Omega-3 optimo: asociado con el menor riesgo cardiovascular.";
  } else if (value >= 4) {
    zone = "below_optimal";
    interp = "Omega-3 index is suboptimal. Consider increasing fatty fish or supplementation.";
    interp_es = "Indice Omega-3 suboptimo. Considere aumentar pescado graso o suplementacion.";
  } else {
    zone = "critical_low";
    interp = "Low Omega-3 index: elevated cardiovascular risk.";
    interp_es = "Indice Omega-3 bajo: riesgo cardiovascular elevado.";
  }

  return { metricName: "Omega-3 Index", metricKey: "omega3_index", value, unit: "%", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── 5. NLR (Neutrophil-to-Lymphocyte Ratio) ───

function calcNLR(map: BiomarkerMap): CalculatedMetric | null {
  if (!has(map, "neutrophils", "lymphocytes") || map["lymphocytes"] === 0) return null;
  const value = Math.round((map["neutrophils"] / map["lymphocytes"]) * 100) / 100;

  let zone: Zone = "optimal";
  let interp = "NLR is optimal: balanced immune response.";
  let interp_es = "NLR optimo: respuesta inmune equilibrada.";

  if (value < 1.0) {
    zone = "below_optimal";
    interp = "Low NLR. May indicate viral infection or immune dysregulation.";
    interp_es = "NLR bajo. Puede indicar infeccion viral o desregulacion inmune.";
  } else if (value > 2.5 && value <= 6.0) {
    zone = "above_optimal";
    interp = "Elevated NLR. Suggests systemic inflammation or physiological stress.";
    interp_es = "NLR elevado. Sugiere inflamacion sistemica o estres fisiologico.";
  } else if (value > 6.0) {
    zone = "critical_high";
    interp = "High NLR: significant inflammation. Medical evaluation recommended.";
    interp_es = "NLR alto: inflamacion significativa. Se recomienda evaluacion medica.";
  }

  return { metricName: "Neutrophil-to-Lymphocyte Ratio", metricKey: "nlr", value, unit: "", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── 6. Free Androgen Index ───

function calcFAI(map: BiomarkerMap, sex: string): CalculatedMetric | null {
  // FAI = total testosterone (nmol/L) × 100 / SHBG (nmol/L). Testosterone is
  // stored in ng/mL (Echevarne's unit, canonical since 2026-09-17):
  // 1 ng/mL = 3.467 nmol/L. The legacy "testosterone" key is honoured too.
  const tKey = has(map, "testosterone_total") ? "testosterone_total" : "testosterone";
  if (!has(map, tKey, "shbg") || map["shbg"] === 0) return null;
  const testosteroneNmolL = map[tKey] * 3.467;
  const value = Math.round((testosteroneNmolL / map["shbg"]) * 10000) / 100;

  const isMale = sex.toLowerCase() === "male";
  const optLow = isMale ? 35 : 1;
  const optHigh = isMale ? 92 : 10;

  let zone: Zone = "optimal";
  let interp = "Free Androgen Index is within the optimal range.";
  let interp_es = "El Indice de Androgenos Libres esta dentro del rango optimo.";

  if (value < optLow) {
    zone = "below_optimal";
    interp = isMale
      ? "Low FAI may indicate hypogonadism or elevated SHBG."
      : "Low FAI. May indicate androgen deficiency.";
    interp_es = isMale
      ? "FAI bajo puede indicar hipogonadismo o SHBG elevada."
      : "FAI bajo. Puede indicar deficiencia androgenica.";
  } else if (value > optHigh) {
    zone = "above_optimal";
    interp = isMale
      ? "Elevated FAI. Consider evaluating androgen excess."
      : "Elevated FAI. May indicate PCOS or adrenal hyperactivity.";
    interp_es = isMale
      ? "FAI elevado. Considere evaluar exceso androgenico."
      : "FAI elevado. Puede indicar SOP o hiperactividad adrenal.";
  }

  return { metricName: "Free Androgen Index", metricKey: "fai", value, unit: "", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── 7. Non-HDL Cholesterol ───

function calcNonHDL(map: BiomarkerMap): CalculatedMetric | null {
  if (!has(map, "total_cholesterol", "hdl_cholesterol")) return null;
  const value = Math.round((map["total_cholesterol"] - map["hdl_cholesterol"]) * 10) / 10;

  let zone: Zone = "optimal";
  let interp = "Non-HDL cholesterol is optimal.";
  let interp_es = "Colesterol no-HDL optimo.";

  if (value >= 130 && value < 160) {
    zone = "above_optimal";
    interp = "Non-HDL slightly elevated. Monitor with lifestyle changes.";
    interp_es = "Colesterol no-HDL ligeramente elevado. Monitorizar con cambios de estilo de vida.";
  } else if (value >= 160) {
    zone = "critical_high";
    interp = "High non-HDL cholesterol: significant atherogenic risk.";
    interp_es = "Colesterol no-HDL alto: riesgo aterogenico significativo.";
  }

  return { metricName: "Non-HDL Cholesterol", metricKey: "non_hdl", value, unit: "mg/dL", zone, interpretation: interp, interpretation_es: interp_es };
}

// ─── Public API ───

export function calculateAllMetrics(
  biomarkers: Array<{ biomarker_key: string; value: number }>,
  sex: string,
): CalculatedMetric[] {
  const map: BiomarkerMap = {};
  for (const b of biomarkers) {
    map[b.biomarker_key] = b.value;
  }

  const results: CalculatedMetric[] = [];
  const fns = [
    () => calcHomaIR(map),
    () => calcTgHdlRatio(map),
    () => calcDeRitis(map),
    () => calcOmega3Index(map),
    () => calcNLR(map),
    () => calcFAI(map, sex),
    () => calcNonHDL(map),
  ];

  for (const fn of fns) {
    const result = fn();
    if (result) results.push(result);
  }

  return results;
}
