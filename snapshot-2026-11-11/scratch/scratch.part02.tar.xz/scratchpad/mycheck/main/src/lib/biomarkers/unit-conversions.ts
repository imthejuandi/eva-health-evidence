/**
 * Unit conversions for biomarkers where labs report different units
 * than the EVA reference ranges expect.
 *
 * Each conversion takes the raw extracted value + its unit, plus the
 * canonical biomarker_key, and returns a normalized value in the expected
 * EVA unit. If no conversion is needed, returns the value unchanged.
 *
 * Applied AFTER name matching (so we know the biomarkerKey) but BEFORE
 * zone classification (so zones are compared against the right scale).
 */

import { normalizeUnit } from "./canonical-units";

export interface ConversionResult {
  value: number;
  unit: string;
  converted: boolean;
  note?: string;
}

/**
 * Normalize a unit string for comparison: lowercase, strip whitespace,
 * normalize common variants. "mg/dL" → "mg/dl", "µmol/L" → "umol/l".
 */
function normUnit(unit: string): string {
  return (unit || "")
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/µ/g, "u")
    .replace(/[·•]/g, "")
    .replace(/\*/g, "")
    .replace(/\/dl\.?/, "/dl")
    .replace(/\/l\.?/, "/l")
    // Spanish "UI" ≡ "IU", and a bare "U" ≡ "IU" (µU/mL ≡ µIU/mL, U/L ≡ IU/L)
    // — see canonical-units.normalizeUnit.
    .replace(/ui(?=\/|$)/g, "iu")
    .replace(/(^|m|u|k)u(?=\/|$)/g, "$1iu");
}

/**
 * CBC cell-count biomarkers. Since 2026-09-17 the canonical unit is the
 * RAW number of cells per microlitre — Echevarne's convention and what its
 * PDF shows the patient ("5.000.000 /µL", "200.000 /µL") — so partner
 * results never rescale. Other labs and most US reports use the "thousands"
 * scale (×10³/µL ≡ ×10⁹/L ≡ K/µL) and, for red cells, the "millions" scale
 * (×10⁶/µL ≡ ×10¹²/L); those are multiplied back up — a pure decimal shift.
 */
const CELL_COUNT_KEYS = new Set([
  "white_blood_cell_count",
  "platelet_count",
  "lymphocytes_absolute",
  "monocytes_absolute",
  "neutrophils_absolute",
  "eosinophils_absolute",
  "basophils_absolute",
]);

/**
 * True when `unit` is a RAW per-volume cell count — the absolute number
 * of cells per microlitre (or per mm³, which is identical) — rather than
 * a ×10³/µL or ×10⁶/µL scaled notation.
 *
 * Uses the canonical normalizer so every power notation ("x10³/µL",
 * "10⁹/L", "K/µL", …) collapses to a "10^N" form we can exclude, while
 * a bare "/µL", "células/µL", "cells/µL", "/mm³" — or one of the
 * frequently OCR-mangled per-volume forms ("/mL", "/mi", "/mcL") — is
 * recognised as a raw count.
 */
function isRawPerVolumeCellCount(unit: string): boolean {
  const u = normalizeUnit(unit).replace(/³/g, "3");
  if (!u) return false;
  // Already a scaled notation (×10³ / ×10⁶ / ×10⁹) or a thousands prefix.
  if (u.includes("10^")) return false;
  if (u.startsWith("mil/") || u.startsWith("k/") || u.startsWith("m/")) return false;
  // Optional cell word ("cells", "células", "cel", …) then a per-volume
  // suffix. "ml"/"mi"/"mcl" are included because labs and OCR routinely
  // render a per-µL count that way; for these cell-count biomarkers the
  // intended scale is always cells/µL.
  return /^[^/]*\/(?:ul|ml|mi|mcl|cmm|mm3|nl)$/.test(u);
}

/** "×10³/µL", "10⁹/L", "K/µL", "mil/µL" … — the thousands scale. */
function isThousandsScaleUnit(unit: string): boolean {
  const u = normalizeUnit(unit);
  return u.includes("10^3") || u.startsWith("mil/") || u.startsWith("k/");
}

/** "×10⁶/µL", "10¹²/L", "M/µL" — the millions scale (red cells). */
function isMillionsScaleUnit(unit: string): boolean {
  const u = normalizeUnit(unit);
  return u.includes("10^6") || u.startsWith("m/");
}

/**
 * Eosinophils and basophils are legitimately reported as a handful of
 * cells per µL, so a small number under an explicit raw unit is real and
 * must never be read as a thousands-scale value. The other counts have a
 * physiological floor far above their thousands-scale range, which lets
 * the magnitude expose a mislabelled unit either way.
 */
const SMALL_COUNT_KEYS = new Set(["eosinophils_absolute", "basophils_absolute"]);

/**
 * Bring a cell count to the canonical raw cells/µL.
 *
 * The unit string cannot be trusted on its own — labs and OCR routinely
 * tag a raw count "10³/µL" or a thousands value "/µL" — so the value's
 * magnitude against the canonical normal-high (raw scale) arbitrates:
 *   · a scaled value is < normalHigh / 200 (WBC 4.5 vs 11 000; PLT 250 vs
 *     400 000; RBC 4.9 vs 5 650 000) — a raw count that low is impossible;
 *   · a raw value is ≥ normalHigh / 20 even in disease.
 * Without a normal-high, the unit decides.
 *
 * `trustUnit` switches the arbiter off: the label alone decides. That is
 * the mode for results that arrive as structured HL7 from a partner lab
 * (Echevarne's OBX-6 is the lab's own unit, never OCR'd, never retyped),
 * where "44 /µL" means exactly 44 cells — a dummy the lab typed, not a
 * mislabelled thousands value (decided 2026-09-21). A value with no unit
 * at all still falls back to the magnitude, since there is nothing to trust.
 */
function rescaleCellCount(
  biomarkerKey: string,
  value: number,
  unit: string,
  normalHigh: number | null,
  trustUnit = false,
): ConversionResult {
  const isRbc = biomarkerKey === "red_blood_cell_count";
  const factor = isRbc ? 1_000_000 : 1000;
  const scaledUnit = isRbc ? isMillionsScaleUnit(unit) : isThousandsScaleUnit(unit);
  const rawUnit = isRawPerVolumeCellCount(unit);
  const hasRange = normalHigh != null && normalHigh > 0;
  const looksScaled = hasRange && value > 0 && value < normalHigh / 200;
  const looksRaw = hasRange && value >= normalHigh / 20;

  let scaled: boolean;
  let why = "";
  if (trustUnit && (scaledUnit || rawUnit)) {
    scaled = scaledUnit;
    if (scaled) why = " (unit trusted as reported by the lab)";
  } else if (scaledUnit) {
    scaled = !looksRaw; // a value in the raw range under a scaled label is a mislabel
    if (!scaled) why = " (magnitude shows a raw count mislabelled as scaled)";
  } else if (rawUnit) {
    // Trust the raw label. Only total white cells and red cells have a floor
    // no living patient goes under (55 and 28 250 /µL), so only there can the
    // magnitude prove the label wrong ("4.5 /µL" is a thousands value). A
    // platelet or differential count can be genuinely tiny in the sickest
    // patients (agranulocytosis, severe thrombocytopenia); multiplying those
    // by 1000 would be the one mistake worse than a false alarm.
    scaled = (biomarkerKey === "white_blood_cell_count" || isRbc) && looksScaled;
    if (scaled) why = " (magnitude shows a scaled value mislabelled as raw)";
  } else {
    scaled = SMALL_COUNT_KEYS.has(biomarkerKey) ? value > 0 && value < 1 : looksScaled;
    if (scaled) why = " (no usable unit; magnitude indicated a scaled value)";
  }

  if (!scaled) return { value, unit: "/µL", converted: false };
  return {
    value: value * factor,
    unit: "/µL",
    converted: true,
    note: `${biomarkerKey} rescaled from ×10${isRbc ? "⁶" : "³"}/µL to raw cells/µL via ×${factor.toLocaleString("en-US")}${why}`,
  };
}

/**
 * Urea vs. BUN (Blood Urea Nitrogen):
 *
 * Urea is the whole molecule; BUN measures only its nitrogen fraction
 * (BUN = Urea × 0.4665). EVA treats them as two SEPARATE biomarkers
 * with two separate seed entries, two separate reference ranges, and
 * two separate detail pages — Urea is the European/Spanish reporting
 * convention, BUN is the U.S. one. The user opens a Urea-named lab and
 * gets the Urea page; opens a BUN-named lab and gets the BUN page.
 *
 * The unit conversions here only normalize between unit *systems* for
 * the SAME molecule (mmol/L → mg/dL). The cross-molecule conversion
 * (Urea ↔ BUN, ×0.4665) is applied separately by the KDM joint
 * estimator, which is anchored on BUN.
 */
export function convertBiomarker(
  biomarkerKey: string,
  value: number,
  unit: string,
  opts?: {
    normalHigh?: number | null;
    /** Take the reported unit at face value (structured lab feeds); see rescaleCellCount. */
    trustUnit?: boolean;
  },
): ConversionResult {
  const u = normUnit(unit);

  // ─── CBC cell counts: raw cells/µL → ×10³/µL (or ×10⁶/µL for RBC) ───
  // Spain and much of Europe report the leukocyte differential absolute
  // counts (and other CBC cell counts) as the RAW number of cells per
  // microlitre — e.g. "Linfocitos 2340 /µL", "Neutrófilos 4200 /µL",
  // "Basófilos 40 /µL". EVA's reference ranges use the "thousands" scale
  // (×10³/µL ≡ ×10⁹/L ≡ K/µL), so a raw /µL count is 1000× too large.
  // (1 µL = 1 mm³, so "/mm³" is the same raw scale.) Both reportings are
  // clinically standard — WBC differential intervals are published
  // interchangeably as e.g. "1.5–3.5 ×10³/µL" or "1500–3500 /µL".
  //
  // The reported unit can't be trusted on its own: labs and the OCR step
  // routinely mislabel a raw /µL count as "10³/µL" or "/mL". So we treat
  // the value as a raw count when EITHER the unit is an explicit raw
  // per-volume notation OR the magnitude is far above the canonical range
  // (>20× the normal high). 20× sits well below the 1000× gap between the
  // two scales, so an in-range or even pathologically high value is never
  // rescaled, while a mislabelled raw count always is.
  if (CELL_COUNT_KEYS.has(biomarkerKey) || biomarkerKey === "red_blood_cell_count") {
    return rescaleCellCount(biomarkerKey, value, unit, opts?.normalHigh ?? null, opts?.trustUnit === true);
  }

  // ─── Urea (mmol/L → mg/dL) ───
  // 1 mmol/L Urea = 60 g/mol ÷ 10 = 6.006 mg/dL
  if (biomarkerKey === "urea") {
    if (u === "mg/dl" || u === "") {
      return { value, unit: "mg/dL", converted: false };
    }
    if (u === "mmol/l") {
      return {
        value: value * 6.006,
        unit: "mg/dL",
        converted: true,
        note: "Urea converted from mmol/L to mg/dL via ×6.006",
      };
    }
    if (u === "g/l") {
      // 1 g/L = 100 mg/dL
      return {
        value: value * 100,
        unit: "mg/dL",
        converted: true,
        note: "Urea converted from g/L to mg/dL via ×100",
      };
    }
  }

  // ─── BUN (mmol/L → mg/dL) ───
  // BUN in mmol/L is rare but possible. 1 mmol/L BUN = 2.801 mg/dL.
  // g/L is exceedingly rare for BUN itself (it's mostly an EU Urea
  // reporting unit) but the pre-split code accepted it via the
  // urea-name branch — keep parity so a 'Blood Urea Nitrogen' lab
  // (which the matcher routes to the bun key) reported in g/L still
  // imports instead of being dropped as unit_mismatch.
  if (biomarkerKey === "bun") {
    if (u === "mg/dl" || u === "") {
      return { value, unit: "mg/dL", converted: false };
    }
    if (u === "mmol/l") {
      return {
        value: value * 2.801,
        unit: "mg/dL",
        converted: true,
        note: "BUN converted from mmol/L to mg/dL via ×2.801",
      };
    }
    if (u === "g/l") {
      // 1 g/L BUN = 100 mg/dL. (The lab reported the nitrogen
      // fraction directly in g/L, which is unusual but legitimate.)
      return {
        value: value * 100,
        unit: "mg/dL",
        converted: true,
        note: "BUN converted from g/L to mg/dL via ×100",
      };
    }
  }

  // ─── Glucose: mmol/L → mg/dL ───
  // Glucose (mg/dL) = Glucose (mmol/L) × 18.0182
  if (biomarkerKey === "glucose_fasting" && u === "mmol/l") {
    return {
      value: value * 18.0182,
      unit: "mg/dL",
      converted: true,
      note: "Glucose converted from mmol/L to mg/dL via ×18.0182",
    };
  }

  // ─── Cholesterol (total/LDL/HDL/non-HDL): mmol/L → mg/dL ───
  // Cholesterol (mg/dL) = Cholesterol (mmol/L) × 38.67
  if (
    ["total_cholesterol", "ldl_cholesterol", "hdl_cholesterol", "non_hdl_cholesterol"].includes(
      biomarkerKey,
    ) &&
    u === "mmol/l"
  ) {
    return {
      value: value * 38.67,
      unit: "mg/dL",
      converted: true,
      note: `${biomarkerKey} converted from mmol/L to mg/dL via ×38.67`,
    };
  }

  // ─── Triglycerides: mmol/L → mg/dL ───
  // TG (mg/dL) = TG (mmol/L) × 88.57
  if (biomarkerKey === "triglycerides" && u === "mmol/l") {
    return {
      value: value * 88.57,
      unit: "mg/dL",
      converted: true,
      note: "Triglycerides converted from mmol/L to mg/dL via ×88.57",
    };
  }

  // ─── Creatinine: umol/L → mg/dL ───
  // Creatinine (mg/dL) = Creatinine (umol/L) × 0.0113
  if (biomarkerKey === "creatinine" && (u === "umol/l" || u === "μmol/l")) {
    return {
      value: value * 0.0113,
      unit: "mg/dL",
      converted: true,
      note: "Creatinine converted from μmol/L to mg/dL via ×0.0113",
    };
  }

  // ─── Uric acid: umol/L → mg/dL ───
  // Uric acid (mg/dL) = Uric acid (umol/L) × 0.01681
  if (biomarkerKey === "uric_acid" && (u === "umol/l" || u === "μmol/l")) {
    return {
      value: value * 0.01681,
      unit: "mg/dL",
      converted: true,
      note: "Uric acid converted from μmol/L to mg/dL via ×0.01681",
    };
  }

  // ─── Bilirubin: umol/L → mg/dL ───
  if (
    (biomarkerKey === "total_bilirubin" || biomarkerKey === "direct_bilirubin") &&
    (u === "umol/l" || u === "μmol/l")
  ) {
    return {
      value: value * 0.0585,
      unit: "mg/dL",
      converted: true,
      note: `${biomarkerKey} converted from μmol/L to mg/dL via ×0.0585`,
    };
  }

  // ─── Vitamin D: nmol/L → ng/mL ───
  // Vitamin D (ng/mL) = Vitamin D (nmol/L) / 2.496
  if (biomarkerKey === "vitamin_d_25_oh" && u === "nmol/l") {
    return {
      value: value / 2.496,
      unit: "ng/mL",
      converted: true,
      note: "Vitamin D converted from nmol/L to ng/mL via ÷2.496",
    };
  }

  // ─── Vitamin D: µg/L ≡ ng/mL (notation only) ───
  // 1 µg/L = 1 ng/mL. Many European labs use µg/L.
  if (biomarkerKey === "vitamin_d_25_oh" && (u === "ug/l" || u === "μg/l")) {
    return {
      value,
      unit: "ng/mL",
      converted: true,
      note: "Vitamin D µg/L ≡ ng/mL (notation only)",
    };
  }

  // ─── Calcium: canonical mg/L (Echevarne B0010, adopted 2026-09-17) ───
  if (biomarkerKey === "calcium_serum") {
    if (u === "mg/l" || u === "") return { value, unit: "mg/L", converted: false };
    if (u === "mg/dl") {
      return { value: value * 10, unit: "mg/L", converted: true, note: "Calcium converted from mg/dL to mg/L via ×10" };
    }
  }

  // ─── Albumin / total protein: canonical g/L (Echevarne B0020, B0024) ───
  if (biomarkerKey === "albumin" || biomarkerKey === "total_protein") {
    if (u === "g/l" || u === "") return { value, unit: "g/L", converted: false };
    if (u === "g/dl") {
      return {
        value: value * 10,
        unit: "g/L",
        converted: true,
        note: `${biomarkerKey === "albumin" ? "Albumin" : "Total protein"} converted from g/dL to g/L via ×10`,
      };
    }
  }

  // ─── AMH: pmol/L → ng/mL ───
  // MW ≈ 140 kDa dimer; clinical convention: 1 ng/mL = 7.14 pmol/L.
  // Echevarne can report either (catalog D0694 pmol/L / D0695 ng/mL).
  if (biomarkerKey === "anti_mullerian_hormone_amh" && u === "pmol/l") {
    return {
      value: value / 7.14,
      unit: "ng/mL",
      converted: true,
      note: "AMH converted from pmol/L to ng/mL via ÷7.14",
    };
  }

  // ─── Vitamin B12: pmol/L → pg/mL ───
  if (biomarkerKey === "vitamin_b12" && u === "pmol/l") {
    return {
      value: value * 1.355,
      unit: "pg/mL",
      converted: true,
      note: "Vitamin B12 converted from pmol/L to pg/mL via ×1.355",
    };
  }

  // ─── Vitamin B12: ng/L ≡ pg/mL (notation only) ───
  if (biomarkerKey === "vitamin_b12" && u === "ng/l") {
    return {
      value,
      unit: "pg/mL",
      converted: true,
      note: "Vitamin B12 ng/L ≡ pg/mL (notation only)",
    };
  }

  // ─── Homocysteine: mg/L → µmol/L (rare reverse direction) ───
  if (biomarkerKey === "homocysteine" && u === "mg/l") {
    return {
      value: value * 7.397,
      unit: "umol/L",
      converted: true,
      note: "Homocysteine converted from mg/L to μmol/L via ×7.397",
    };
  }

  // ─── HbA1c: mmol/mol (IFCC) → % (DCCT/NGSP) ───
  // HbA1c (%) = (HbA1c mmol/mol + 23.5) / 10.929 ≈ mmol/mol × 0.0915 + 2.15
  if (biomarkerKey === "hba1c" && (u === "mmol/mol" || u === "mmolmol")) {
    return {
      value: value * 0.0915 + 2.15,
      unit: "%",
      converted: true,
      note: "HbA1c converted from mmol/mol (IFCC) to % (NGSP)",
    };
  }

  // ─── hs-CRP: mg/dL → mg/L ───
  // Seed expects mg/L. Some labs report mg/dL (×10 to get mg/L).
  if (biomarkerKey === "hs_crp" && u === "mg/dl") {
    return {
      value: value * 10,
      unit: "mg/L",
      converted: true,
      note: "hs-CRP converted from mg/dL to mg/L via ×10",
    };
  }

  // ─── Calcium (serum): mmol/L → mg/L ───
  // Ca (mg/L) = Ca (mmol/L) × 40.08
  if (biomarkerKey === "calcium_serum" && u === "mmol/l") {
    return {
      value: value * 40.08,
      unit: "mg/L",
      converted: true,
      note: "Calcium converted from mmol/L to mg/L via ×40.08",
    };
  }

  // ─── Hemoglobin: g/L → g/dL ───
  // Common in European labs. Same factor as albumin.
  if (biomarkerKey === "hemoglobin" && u === "g/l") {
    return {
      value: value * 0.1,
      unit: "g/dL",
      converted: true,
      note: "Hemoglobin converted from g/L to g/dL via ×0.1",
    };
  }

  // ─── MCHC: g/L → g/dL ───
  if (biomarkerKey === "mchc" && u === "g/l") {
    return {
      value: value * 0.1,
      unit: "g/dL",
      converted: true,
      note: "MCHC converted from g/L to g/dL via ×0.1",
    };
  }

  // ─── Hematocrit: decimal fraction → percent ───
  // Some European labs report HCT as 0.42 instead of 42%. If the value
  // is < 1 and the unit is empty or "L/L" / "ratio", scale up.
  if (biomarkerKey === "hematocrit" && (u === "" || u === "l/l" || u === "ratio") && value < 1) {
    return {
      value: value * 100,
      unit: "%",
      converted: true,
      note: "Hematocrit converted from fraction to percent (×100)",
    };
  }

  // ─── Globulin: g/L → g/dL (total protein moved to g/L above) ───
  if (biomarkerKey === "globulin" && u === "g/l") {
    return {
      value: value * 0.1,
      unit: "g/dL",
      converted: true,
      note: "globulin converted from g/L to g/dL via ×0.1",
    };
  }

  // ─── Iron (serum) & TIBC: µmol/L → µg/dL ───
  // Iron (µg/dL) = Iron (µmol/L) × 5.585
  if (
    (biomarkerKey === "iron_serum" || biomarkerKey === "iron_binding_capacity_tibc") &&
    (u === "umol/l" || u === "μmol/l")
  ) {
    return {
      value: value * 5.585,
      unit: "µg/dL",
      converted: true,
      note: `${biomarkerKey} converted from μmol/L to µg/dL via ×5.585`,
    };
  }

  // ─── Cortisol (morning): nmol/L → µg/dL ───
  // Cortisol (µg/dL) = Cortisol (nmol/L) × 0.03626
  if (biomarkerKey === "cortisol_morning_8am" && u === "nmol/l") {
    return {
      value: value * 0.03626,
      unit: "µg/dL",
      converted: true,
      note: "Cortisol converted from nmol/L to µg/dL via ×0.03626",
    };
  }

  // ─── Testosterone Total: canonical ng/mL (Echevarne D0014) ───
  // ng/mL = nmol/L × 0.2884; ng/mL = ng/dL ÷ 100
  if (biomarkerKey === "testosterone_total") {
    if (u === "ng/ml" || u === "") return { value, unit: "ng/mL", converted: false };
    if (u === "nmol/l") {
      return {
        value: value * 0.2884,
        unit: "ng/mL",
        converted: true,
        note: "Testosterone (total) converted from nmol/L to ng/mL via ×0.2884",
      };
    }
    if (u === "ng/dl") {
      return {
        value: value / 100,
        unit: "ng/mL",
        converted: true,
        note: "Testosterone (total) converted from ng/dL to ng/mL via ÷100",
      };
    }
  }

  // ─── Testosterone Free → ng/dL (canonical) ───
  // EVA's free-testosterone reference ranges are ng/dL (male ~5-21).
  // Labs report SI (pmol/L) or pg/mL; convert both to ng/dL.
  //   ng/dL = pmol/L × MW(288.4 g/mol) / 10000  →  ÷34.67
  //   ng/dL = pg/mL / 10  (1 ng/dL = 10 pg/mL)
  if (biomarkerKey === "testosterone_free") {
    if (u === "pmol/l") {
      return {
        value: value / 34.67,
        unit: "ng/dL",
        converted: true,
        note: "Testosterone (free) converted from pmol/L to ng/dL via ÷34.67",
      };
    }
    if (u === "pg/ml") {
      return {
        value: value / 10,
        unit: "ng/dL",
        converted: true,
        note: "Testosterone (free) converted from pg/mL to ng/dL via ÷10",
      };
    }
  }

  // ─── Estradiol: pmol/L → pg/mL ───
  // Estradiol (pg/mL) = Estradiol (pmol/L) / 3.671
  if (biomarkerKey === "estradiol" && u === "pmol/l") {
    return {
      value: value / 3.671,
      unit: "pg/mL",
      converted: true,
      note: "Estradiol converted from pmol/L to pg/mL via ÷3.671",
    };
  }

  // ─── DHEA-Sulfate: µmol/L → µg/dL ───
  // DHEA-S (µg/dL) = DHEA-S (µmol/L) × 36.848
  if (
    biomarkerKey === "dhea_sulfate" &&
    (u === "umol/l" || u === "μmol/l")
  ) {
    return {
      value: value * 36.848,
      unit: "µg/dL",
      converted: true,
      note: "DHEA-S converted from μmol/L to µg/dL via ×36.848",
    };
  }

  // ─── Insulin (fasting): pmol/L → µU/mL (Echevarne's label; ≡ µIU/mL) ───
  // Insulin (µU/mL) = Insulin (pmol/L) / 6.945
  if (biomarkerKey === "insulin_fasting" && u === "pmol/l") {
    return {
      value: value / 6.945,
      unit: "µU/mL",
      converted: true,
      note: "Insulin converted from pmol/L to µU/mL via ÷6.945",
    };
  }

  // ─── Prolactin: mIU/L → ng/mL ───
  // Prolactin (ng/mL) = Prolactin (mIU/L) / 21.2
  if (biomarkerKey === "prolactin" && u === "miu/l") {
    return {
      value: value / 21.2,
      unit: "ng/mL",
      converted: true,
      note: "Prolactin converted from mIU/L to ng/mL via ÷21.2",
    };
  }

  // ─── Ferritin: µg/L is equivalent to ng/mL (1:1 — just notation) ───
  if (biomarkerKey === "ferritin" && (u === "ug/l" || u === "μg/l")) {
    return {
      value,
      unit: "ng/mL",
      converted: true,
      note: "Ferritin µg/L ≡ ng/mL (notation only)",
    };
  }

  // ─── PSA Total: µg/L ≡ ng/mL (notation only) ───
  if (biomarkerKey === "psa_total" && (u === "ug/l" || u === "μg/l")) {
    return {
      value,
      unit: "ng/mL",
      converted: true,
      note: "PSA µg/L ≡ ng/mL (notation only)",
    };
  }

  // ─── Prolactin: µg/L ≡ ng/mL (notation only) ───
  if (biomarkerKey === "prolactin" && (u === "ug/l" || u === "μg/l")) {
    return {
      value,
      unit: "ng/mL",
      converted: true,
      note: "Prolactin µg/L ≡ ng/mL (notation only)",
    };
  }

  // ─── Lead (Blood): µg/dL ≡ µg/dL — already canonical. But nmol/L is
  //     sometimes used (1 µg/dL = 48.3 nmol/L for lead).
  if (biomarkerKey === "lead_blood" && u === "nmol/l") {
    return {
      value: value / 48.3,
      unit: "µg/dL",
      converted: true,
      note: "Lead converted from nmol/L to µg/dL via ÷48.3",
    };
  }

  // ─── Mercury (Blood): µg/L → same (canonical). nmol/L → ÷ 4.99
  if (biomarkerKey === "mercury_blood" && u === "nmol/l") {
    return {
      value: value / 4.99,
      unit: "µg/L",
      converted: true,
      note: "Mercury converted from nmol/L to µg/L via ÷4.99",
    };
  }

  // ─── Microalbumin (Urine): µg/mL ≡ mg/L (1000× smaller scale) ───
  if (biomarkerKey === "microalbumin_urine" && (u === "ug/ml" || u === "μg/ml")) {
    return {
      value,
      unit: "mg/L",
      converted: true,
      note: "Microalbumin µg/mL ≡ mg/L (notation only)",
    };
  }

  // ─── Cortisol: ng/mL → µg/dL (÷10) ───
  if (biomarkerKey === "cortisol_morning_8am" && u === "ng/ml") {
    return {
      value: value / 10,
      unit: "µg/dL",
      converted: true,
      note: "Cortisol converted from ng/mL to µg/dL via ÷10",
    };
  }

  // ─── TSH: mIU/L ≡ µIU/mL (notation only, 1:1) ───
  // Numerically identical because 1 µIU/mL × 1000 mL/L = 1 mIU/L. Canonical
  // is Echevarne's µUI/mL (seed label "µIU/mL"), adopted 2026-09-17.
  if (biomarkerKey === "tsh" && u === "miu/l") {
    return {
      value,
      unit: "µIU/mL",
      converted: true,
      note: "TSH mIU/L ≡ µIU/mL (notation only)",
    };
  }

  // ─── FSH: IU/L ≡ mIU/mL (notation only) ───
  // 1 IU/L = 1000 mIU/L = 1 mIU/mL. Seed canonical is mIU/mL.
  if (biomarkerKey === "fsh" && u === "iu/l") {
    return {
      value,
      unit: "mIU/mL",
      converted: true,
      note: "FSH IU/L ≡ mIU/mL (notation only)",
    };
  }
  // Also accept mIU/L (European), same passthrough
  if (biomarkerKey === "fsh" && u === "miu/l") {
    return {
      value: value / 1,
      unit: "mIU/mL",
      converted: true,
      note: "FSH mIU/L ≡ mIU/mL (numerically equivalent)",
    };
  }

  // ─── LH: IU/L ≡ mIU/mL (notation only) ───
  if (biomarkerKey === "luteinizing_hormone_lh" && (u === "iu/l" || u === "miu/l")) {
    return {
      value,
      unit: "mIU/mL",
      converted: true,
      note: "LH IU/L ≡ mIU/mL (notation only)",
    };
  }

  // ─── Free T3: pmol/L → pg/mL ───
  // FT3 (pg/mL) = FT3 (pmol/L) × 0.651
  if (biomarkerKey === "free_t3_triiodothyronine" && u === "pmol/l") {
    return {
      value: value * 0.651,
      unit: "pg/mL",
      converted: true,
      note: "Free T3 converted from pmol/L to pg/mL via ×0.651",
    };
  }

  // ─── Free T4: pmol/L → ng/dL ───
  // FT4 (ng/dL) = FT4 (pmol/L) × 0.0777
  if (biomarkerKey === "free_t4_thyroxine" && u === "pmol/l") {
    return {
      value: value * 0.0777,
      unit: "ng/dL",
      converted: true,
      note: "Free T4 converted from pmol/L to ng/dL via ×0.0777",
    };
  }
  // FT4 in pg/mL → ng/dL: ÷10 (1 ng/dL = 10 pg/mL). Several European
  // labs report free T4 in pg/mL (~10-18) rather than ng/dL (~0.8-1.8).
  if (biomarkerKey === "free_t4_thyroxine" && u === "pg/ml") {
    return {
      value: value / 10,
      unit: "ng/dL",
      converted: true,
      note: "Free T4 converted from pg/mL to ng/dL via ÷10",
    };
  }
  // FT4 in ng/mL → ng/dL: ×100 (1 ng/mL = 100 ng/dL). Rare, but the
  // factor must be ×100 — same as ng/mL→ng/dL for testosterone above.
  // (Was ×10, which is wrong: that would be a 10× under-read.)
  if (biomarkerKey === "free_t4_thyroxine" && u === "ng/ml") {
    return {
      value: value * 100,
      unit: "ng/dL",
      converted: true,
      note: "Free T4 converted from ng/mL to ng/dL via ×100",
    };
  }

  // ─── Magnesium (serum): mmol/L → mg/dL ───
  // Mg (mg/dL) = Mg (mmol/L) × 2.43
  if (biomarkerKey === "magnesium_serum" && u === "mmol/l") {
    return {
      value: value * 2.43,
      unit: "mg/dL",
      converted: true,
      note: "Magnesium converted from mmol/L to mg/dL via ×2.43",
    };
  }
  // Also accept mEq/L (1 mEq/L = 0.5 mmol/L for Mg²⁺ = 1.215 mg/dL)
  if (biomarkerKey === "magnesium_serum" && u === "meq/l") {
    return {
      value: value * 1.215,
      unit: "mg/dL",
      converted: true,
      note: "Magnesium converted from mEq/L to mg/dL via ×1.215",
    };
  }

  // ─── Zinc (serum): µmol/L → µg/dL ───
  // Zn (µg/dL) = Zn (µmol/L) × 6.538
  if (biomarkerKey === "zinc_serum" && (u === "umol/l" || u === "μmol/l")) {
    return {
      value: value * 6.538,
      unit: "µg/dL",
      converted: true,
      note: "Zinc converted from µmol/L to µg/dL via ×6.538",
    };
  }

  // ─── ApoB: g/L → mg/dL ───
  // ApoB (mg/dL) = ApoB (g/L) × 100 (since 1 g/L = 100 mg/dL)
  if (biomarkerKey === "apolipoprotein_b_apob" && u === "g/l") {
    return {
      value: value * 100,
      unit: "mg/dL",
      converted: true,
      note: "ApoB converted from g/L to mg/dL via ×100",
    };
  }

  // ─── hs-CRP: nmol/L → mg/L ───
  // hs-CRP (mg/L) = hs-CRP (nmol/L) × 0.1138
  if (biomarkerKey === "hs_crp" && u === "nmol/l") {
    return {
      value: value * 0.1138,
      unit: "mg/L",
      converted: true,
      note: "hs-CRP converted from nmol/L to mg/L via ×0.1138",
    };
  }

  // ─── Calcium: mEq/L → mg/L ───
  // Ca (mg/L) = Ca (mEq/L) × 20.04
  if (biomarkerKey === "calcium_serum" && u === "meq/l") {
    return {
      value: value * 20.04,
      unit: "mg/L",
      converted: true,
      note: "Calcium converted from mEq/L to mg/L via ×20.04",
    };
  }

  // ─── Homocysteine: mg/dL → µmol/L ───
  if (biomarkerKey === "homocysteine" && u === "mg/dl") {
    return {
      value: value * 73.97,
      unit: "µmol/L",
      converted: true,
      note: "Homocysteine converted from mg/dL to µmol/L via ×73.97",
    };
  }

  // ─── SHBG: nmol/L is the canonical — accept it as-is. Some labs
  //     report as µg/mL (1 nmol/L ≈ 0.0949 µg/mL for SHBG mw 95000).
  if (biomarkerKey === "shbg" && (u === "ug/ml" || u === "μg/ml")) {
    return {
      value: value / 0.0949,
      unit: "nmol/L",
      converted: true,
      note: "SHBG converted from µg/mL to nmol/L via ÷0.0949",
    };
  }

  // ─── Lp(a): mg/dL is canonical (aligned with the Echevarne catalog,
  //     2026-08-25 — LPA/B1381 reports mg/dL); also accept µg/mL
  //     (1 mg/dL = 10 µg/mL) and nmol/L (approximate ÷2.5).
  if (biomarkerKey === "lipoproteina" && (u === "ug/ml" || u === "μg/ml")) {
    return {
      value: value / 10,
      unit: "mg/dL",
      converted: true,
      note: "Lp(a) converted from µg/mL to mg/dL via ÷10",
    };
  }

  // Lp(a) mass↔molar conversion is NOT linear (depends on isoform), but the
  // clinical convention when a direct measure is unavailable is 2.5 nmol/L
  // per mg/dL.
  if (biomarkerKey === "lipoproteina" && u === "nmol/l") {
    return {
      value: value / 2.5,
      unit: "mg/dL",
      converted: true,
      note: "Lp(a) approximated from nmol/L to mg/dL via ÷2.5 (isoform-dependent)",
    };
  }

  // No conversion needed or not recognized — return as-is
  return { value, unit, converted: false };
}
