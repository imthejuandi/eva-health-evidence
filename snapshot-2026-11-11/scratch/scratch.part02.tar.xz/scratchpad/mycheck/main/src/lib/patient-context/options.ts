/**
 * Source of truth for every question the patient-context UI can ask.
 *
 * Keys are stable English enum strings. They never appear in the UI —
 * the UI looks up the localized label from the en/es maps below. Keys
 * are what the AI prompt sees, what the database stores, and what the
 * trend rules + ranges key off. Renaming a key is a data migration.
 *
 * Adding an option:
 *   1. Add the canonical key to the relevant array (drives ordering).
 *   2. Add an entry to LABELS.en and LABELS.es with the same key.
 *
 * Removing an option: leave the key in LABELS forever so historical
 * patient_context_versions rows still render correctly. Just drop it
 * from the array so it doesn't appear in the picker for new edits.
 */

// ─── Medications — items that meaningfully shift lab interpretation ───

export const MEDICATION_KEYS = [
  "statin_rosuvastatin",
  "statin_atorvastatin",
  "statin_simvastatin",
  "statin_other",
  "pcsk9_inhibitor",
  "ezetimibe",
  "bempedoic_acid",
  "metformin",
  "glp1_agonist",
  "sglt2_inhibitor",
  "insulin_therapy",
  "thyroid_levothyroxine",
  "thyroid_other",
  "trt_injectable",
  "trt_topical",
  "hrt_oral",
  "hrt_transdermal",
  "oral_contraceptive",
  "ssri",
  "snri",
  "ppi",
  "beta_blocker",
  "diuretic",
  "corticosteroid",
  "nsaid_chronic",
  "anticoagulant_warfarin",
  "anticoagulant_doac",
  "immunosuppressant",
  "other",
] as const;
export type MedicationKey = (typeof MEDICATION_KEYS)[number];

// ─── Supplements — items that materially confound common biomarkers ───

export const SUPPLEMENT_KEYS = [
  "creatine",          // ↑ creatinine
  "biotin",            // interferes with TSH / troponin / fT4 immunoassays
  "iron",              // ↑ ferritin, transferrin saturation
  "vitamin_d",         // ↑ 25-OH-D
  "b12",
  "folate",
  "omega3",            // ↓ TG, ↑ bleeding time
  "magnesium",
  "zinc",              // can ↓ copper
  "berberine",         // ↓ glucose, HbA1c
  "nac",
  "methylated_b",      // ↓ homocysteine
  "red_yeast_rice",    // ↓ LDL (statin-like)
  "niacin",            // ↑ HDL, can ↑ glucose
  "dhea",              // ↑ DHEA-S, downstream androgens
  "testosterone_booster",
  "protein_powder",
  "nmn_nr",
  "melatonin",
  "other",
] as const;
export type SupplementKey = (typeof SUPPLEMENT_KEYS)[number];

// ─── Conditions — chronic dx that flip the interpretive frame ───

export const CONDITION_KEYS = [
  "diabetes_t1",
  "diabetes_t2",
  "prediabetes",
  "hypothyroid_hashimoto",
  "hyperthyroid_graves",
  "autoimmune_other",
  "ckd",
  "nafld_mafld",
  "gout",
  "prior_cv_event",
  "prior_cancer",
  "pregnancy_current",
  "lactating",
] as const;
export type ConditionKey = (typeof CONDITION_KEYS)[number];

// ─── Lifestyle — fixed enum + numeric fields ───

export const SMOKING_STATUSES = [
  "never",
  "former_under_5_years",
  "former_over_5_years",
  "current",
] as const;
export type SmokingStatus = (typeof SMOKING_STATUSES)[number];

export const CARDIO_INTENSITIES = [
  "zone2",
  "hiit",
  "mixed",
  "running_pace",
  "other",
] as const;
export type CardioIntensity = (typeof CARDIO_INTENSITIES)[number];

export const DIET_PATTERNS = [
  "omnivore",
  "vegetarian",
  "vegan",
  "keto",
  "carnivore",
  "mediterranean",
  "other",
] as const;
export type DietPattern = (typeof DIET_PATTERNS)[number];

export interface Lifestyle {
  smoking_status?: SmokingStatus;
  alcohol_drinks_per_week?: number;
  cardio_sessions_per_week?: number;
  cardio_dominant_intensity?: CardioIntensity;
  resistance_sessions_per_week?: number;
  diet_pattern?: DietPattern;
}

// ─── Sex-specific — conditionally rendered ───

export const MENSTRUAL_REGULARITIES = ["regular", "irregular", "absent"] as const;
export type MenstrualRegularity = (typeof MENSTRUAL_REGULARITIES)[number];

export const CONTRACEPTION_OPTIONS = [
  "none",
  "oral",
  "iud_hormonal",
  "iud_copper",
  "implant",
] as const;
export type ContraceptionOption = (typeof CONTRACEPTION_OPTIONS)[number];

export const MENOPAUSE_STATUSES = ["peri", "post"] as const;
export type MenopauseStatus = (typeof MENOPAUSE_STATUSES)[number];

export const HRT_OPTIONS = ["none", "oral", "transdermal"] as const;
export type HrtOption = (typeof HRT_OPTIONS)[number];

export const TRT_OPTIONS = ["none", "injectable", "topical"] as const;
export type TrtOption = (typeof TRT_OPTIONS)[number];

export interface SexSpecific {
  menstrual_regularity?: MenstrualRegularity;
  contraception?: ContraceptionOption;
  menopause_status?: MenopauseStatus;
  hrt?: HrtOption;
  trt?: TrtOption;
}

// ─── Per-draw transient context ───

export const FASTED_OPTIONS = [
  "under_8h",
  "eight_to_twelve",
  "twelve_plus",
  "not_fasted",
] as const;
export type FastedOption = (typeof FASTED_OPTIONS)[number];

export const LAST_WORKOUT_OPTIONS = [
  "none",
  "light_under_24h",
  "hard_under_24h",
  "hard_24_to_48h",
] as const;
export type LastWorkoutOption = (typeof LAST_WORKOUT_OPTIONS)[number];

export const DRAW_TIME_OPTIONS = [
  "morning",
  "midday",
  "afternoon",
  "evening",
] as const;
export type DrawTimeOption = (typeof DRAW_TIME_OPTIONS)[number];

export const THREE_POINT_OPTIONS = ["poor", "ok", "good"] as const;
export type ThreePoint = (typeof THREE_POINT_OPTIONS)[number];

export interface TransientContext {
  fasted?: FastedOption;
  last_workout?: LastWorkoutOption;
  currently_ill?: boolean;
  cycle_day?: number | null;
  draw_time?: DrawTimeOption;
  sleep_quality?: ThreePoint;
  hydration?: ThreePoint;
  skipped?: boolean;
}

// ─── Item shapes for jsonb columns ───

export interface MedicationItem {
  key: MedicationKey;
  dose?: string | null;
  /** Free text only used when key === "other" */
  text?: string | null;
}

export interface SupplementItem {
  key: SupplementKey;
  dose?: string | null;
  text?: string | null;
}

export interface ConditionsBlock {
  keys: ConditionKey[];
}

export interface DurableContextSnapshot {
  medications: MedicationItem[];
  supplements: SupplementItem[];
  conditions: ConditionsBlock;
  lifestyle: Lifestyle;
  sex_specific: SexSpecific;
}

// ─── Locale-aware labels ───

type Lang = "en" | "es";

/**
 * Look up the user-facing label for any context key. Falls back to the
 * key itself so a forgotten translation never crashes the UI; an audit
 * test can sweep for keys that fall through.
 */
export function labelFor(key: string, lang: Lang): string {
  return LABELS[lang][key] ?? LABELS.en[key] ?? humanize(key);
}

function humanize(key: string): string {
  return key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// Spanish authored first (primary business language) — EN follows.
const LABELS_ES: Record<string, string> = {
  // Medications
  statin_rosuvastatin: "Rosuvastatina",
  statin_atorvastatin: "Atorvastatina",
  statin_simvastatin: "Simvastatina",
  statin_other: "Otra estatina",
  pcsk9_inhibitor: "Inhibidor PCSK9",
  ezetimibe: "Ezetimibe",
  bempedoic_acid: "Acido bempedoico",
  metformin: "Metformina",
  glp1_agonist: "Agonista GLP-1 (Ozempic, Mounjaro)",
  sglt2_inhibitor: "Inhibidor SGLT2",
  insulin_therapy: "Insulina",
  thyroid_levothyroxine: "Levotiroxina",
  thyroid_other: "Otra medicacion tiroidea",
  trt_injectable: "TRT inyectable",
  trt_topical: "TRT topica",
  hrt_oral: "THS oral",
  hrt_transdermal: "THS transdermica",
  oral_contraceptive: "Anticonceptivo oral",
  ssri: "ISRS (antidepresivo)",
  snri: "IRSN (antidepresivo)",
  ppi: "Inhibidor de bomba de protones",
  beta_blocker: "Betabloqueante",
  diuretic: "Diuretico",
  corticosteroid: "Corticoide",
  nsaid_chronic: "AINE de uso cronico",
  anticoagulant_warfarin: "Warfarina",
  anticoagulant_doac: "Anticoagulante directo (DOAC)",
  immunosuppressant: "Inmunosupresor",
  other: "Otro",

  // Supplements
  creatine: "Creatina",
  biotin: "Biotina",
  iron: "Hierro",
  vitamin_d: "Vitamina D",
  b12: "Vitamina B12",
  folate: "Folato",
  omega3: "Omega-3",
  magnesium: "Magnesio",
  zinc: "Zinc",
  berberine: "Berberina",
  nac: "NAC",
  methylated_b: "Vitaminas B metiladas",
  red_yeast_rice: "Levadura de arroz rojo",
  niacin: "Niacina",
  dhea: "DHEA",
  testosterone_booster: "Refuerzo de testosterona",
  protein_powder: "Proteina en polvo",
  nmn_nr: "NMN / NR",
  melatonin: "Melatonina",

  // Conditions
  diabetes_t1: "Diabetes tipo 1",
  diabetes_t2: "Diabetes tipo 2",
  prediabetes: "Prediabetes",
  hypothyroid_hashimoto: "Hipotiroidismo / Hashimoto",
  hyperthyroid_graves: "Hipertiroidismo / Graves",
  autoimmune_other: "Otra enfermedad autoinmune",
  ckd: "Enfermedad renal cronica",
  nafld_mafld: "Higado graso (NAFLD/MAFLD)",
  gout: "Gota",
  prior_cv_event: "Evento cardiovascular previo",
  prior_cancer: "Cancer (previo o actual)",
  pregnancy_current: "Embarazo actual",
  lactating: "Lactancia",

  // Smoking
  never: "Nunca",
  former_under_5_years: "Ex-fumador (<5 años)",
  former_over_5_years: "Ex-fumador (5+ años)",
  current: "Fumador actual",

  // Cardio intensity
  zone2: "Zona 2 (aerobico moderado)",
  hiit: "HIIT",
  mixed: "Mixto",
  running_pace: "Carrera a ritmo",

  // Diet pattern
  omnivore: "Omnivora",
  vegetarian: "Vegetariana",
  vegan: "Vegana",
  keto: "Cetogenica",
  carnivore: "Carnivora",
  mediterranean: "Mediterranea",

  // Menstrual / contraception / menopause / HRT / TRT
  regular: "Regulares",
  irregular: "Irregulares",
  absent: "Ausentes",
  oral: "Oral",
  iud_hormonal: "DIU hormonal",
  iud_copper: "DIU de cobre",
  implant: "Implante",
  peri: "Perimenopausia",
  post: "Postmenopausia",
  transdermal: "Transdermica",
  injectable: "Inyectable",
  topical: "Topica",
  none: "Ninguna",

  // Transient — fasted
  under_8h: "Menos de 8h",
  eight_to_twelve: "8 a 12h",
  twelve_plus: "Mas de 12h",
  not_fasted: "Sin ayuno",

  // Transient — last workout
  light_under_24h: "Ligero, ultimas 24h",
  hard_under_24h: "Intenso, ultimas 24h",
  hard_24_to_48h: "Intenso, 24-48h antes",

  // Transient — draw time
  morning: "Mañana",
  midday: "Mediodia",
  afternoon: "Tarde",
  evening: "Noche",

  // Transient — sleep/hydration 3-point
  poor: "Mal",
  ok: "Regular",
  good: "Bien",

  // Section headers used in summary cards
  section_medications: "Medicamentos",
  section_supplements: "Suplementos",
  section_conditions: "Condiciones",
  section_lifestyle: "Estilo de vida",
  section_sex_specific: "Salud hormonal",
};

const LABELS_EN: Record<string, string> = {
  statin_rosuvastatin: "Rosuvastatin",
  statin_atorvastatin: "Atorvastatin",
  statin_simvastatin: "Simvastatin",
  statin_other: "Other statin",
  pcsk9_inhibitor: "PCSK9 inhibitor",
  ezetimibe: "Ezetimibe",
  bempedoic_acid: "Bempedoic acid",
  metformin: "Metformin",
  glp1_agonist: "GLP-1 agonist (Ozempic, Mounjaro)",
  sglt2_inhibitor: "SGLT2 inhibitor",
  insulin_therapy: "Insulin",
  thyroid_levothyroxine: "Levothyroxine",
  thyroid_other: "Other thyroid medication",
  trt_injectable: "Injectable TRT",
  trt_topical: "Topical TRT",
  hrt_oral: "Oral HRT",
  hrt_transdermal: "Transdermal HRT",
  oral_contraceptive: "Oral contraceptive",
  ssri: "SSRI (antidepressant)",
  snri: "SNRI (antidepressant)",
  ppi: "Proton pump inhibitor",
  beta_blocker: "Beta blocker",
  diuretic: "Diuretic",
  corticosteroid: "Corticosteroid",
  nsaid_chronic: "Chronic NSAID use",
  anticoagulant_warfarin: "Warfarin",
  anticoagulant_doac: "Direct oral anticoagulant (DOAC)",
  immunosuppressant: "Immunosuppressant",
  other: "Other",

  creatine: "Creatine",
  biotin: "Biotin",
  iron: "Iron",
  vitamin_d: "Vitamin D",
  b12: "Vitamin B12",
  folate: "Folate",
  omega3: "Omega-3",
  magnesium: "Magnesium",
  zinc: "Zinc",
  berberine: "Berberine",
  nac: "NAC",
  methylated_b: "Methylated B vitamins",
  red_yeast_rice: "Red yeast rice",
  niacin: "Niacin",
  dhea: "DHEA",
  testosterone_booster: "Testosterone booster",
  protein_powder: "Protein powder",
  nmn_nr: "NMN / NR",
  melatonin: "Melatonin",

  diabetes_t1: "Type 1 diabetes",
  diabetes_t2: "Type 2 diabetes",
  prediabetes: "Prediabetes",
  hypothyroid_hashimoto: "Hypothyroidism / Hashimoto's",
  hyperthyroid_graves: "Hyperthyroidism / Graves",
  autoimmune_other: "Other autoimmune condition",
  ckd: "Chronic kidney disease",
  nafld_mafld: "Fatty liver (NAFLD/MAFLD)",
  gout: "Gout",
  prior_cv_event: "Prior cardiovascular event",
  prior_cancer: "Cancer (prior or current)",
  pregnancy_current: "Currently pregnant",
  lactating: "Lactating",

  never: "Never",
  former_under_5_years: "Former (<5 years)",
  former_over_5_years: "Former (5+ years)",
  current: "Current smoker",

  zone2: "Zone 2 (moderate aerobic)",
  hiit: "HIIT",
  mixed: "Mixed",
  running_pace: "Running pace",

  omnivore: "Omnivore",
  vegetarian: "Vegetarian",
  vegan: "Vegan",
  keto: "Ketogenic",
  carnivore: "Carnivore",
  mediterranean: "Mediterranean",

  regular: "Regular",
  irregular: "Irregular",
  absent: "Absent",
  oral: "Oral",
  iud_hormonal: "Hormonal IUD",
  iud_copper: "Copper IUD",
  implant: "Implant",
  peri: "Perimenopausal",
  post: "Postmenopausal",
  transdermal: "Transdermal",
  injectable: "Injectable",
  topical: "Topical",
  none: "None",

  under_8h: "Under 8h",
  eight_to_twelve: "8 to 12h",
  twelve_plus: "12h+",
  not_fasted: "Not fasted",

  light_under_24h: "Light, last 24h",
  hard_under_24h: "Hard, last 24h",
  hard_24_to_48h: "Hard, 24-48h ago",

  morning: "Morning",
  midday: "Midday",
  afternoon: "Afternoon",
  evening: "Evening",

  poor: "Poor",
  ok: "Okay",
  good: "Good",

  section_medications: "Medications",
  section_supplements: "Supplements",
  section_conditions: "Conditions",
  section_lifestyle: "Lifestyle",
  section_sex_specific: "Hormonal health",
};

const LABELS: Record<Lang, Record<string, string>> = {
  en: LABELS_EN,
  es: LABELS_ES,
};

// ─── Empty snapshot — used when a user skips onboarding context. ───

export function emptySnapshot(): DurableContextSnapshot {
  return {
    medications: [],
    supplements: [],
    conditions: { keys: [] },
    lifestyle: {},
    sex_specific: {},
  };
}

export function isSnapshotEmpty(s: DurableContextSnapshot): boolean {
  return (
    s.medications.length === 0 &&
    s.supplements.length === 0 &&
    s.conditions.keys.length === 0 &&
    Object.keys(s.lifestyle).length === 0 &&
    Object.keys(s.sex_specific).length === 0
  );
}
