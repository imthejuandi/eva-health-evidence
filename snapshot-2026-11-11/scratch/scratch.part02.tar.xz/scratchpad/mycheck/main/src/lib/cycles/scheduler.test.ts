import { describe, it, expect } from "vitest";
import {
  decideNextCycle,
  buildPlacerOrderNumber,
  CYCLE_CADENCE_DAYS,
  type SchedulerProfile,
  type SchedulerCycle,
} from "./scheduler";

const TODAY = "2026-08-26";
const USER = "a1b2c3d4-0000-0000-0000-000000000000";

function profile(over: Partial<SchedulerProfile> = {}): SchedulerProfile {
  return {
    id: USER,
    patient_number: 42,
    subscription_status: "active",
    plan: "quarterly",
    paid_until: "2026-11-26",
    full_panel_purchased_at: null,
    next_panel_type: "base",
    ...over,
  };
}

function cycle(over: Partial<SchedulerCycle> = {}): SchedulerCycle {
  return {
    seq: 1,
    status: "completed",
    panel_type: "base",
    extraction_confirmed_at: null,
    created_at: "2026-05-01T10:00:00Z",
    ...over,
  };
}

describe("decideNextCycle — entitlement gating", () => {
  it("creates the first cycle immediately for an entitled subscriber", () => {
    const d = decideNextCycle(profile(), [], TODAY);
    expect(d.create).toMatchObject({ seq: 1, panel_type: "base", due_date: TODAY });
    expect(d.reason).toBe("first-cycle");
  });

  it("annual plan behaves identically to quarterly (golden rule: plan-agnostic cron)", () => {
    const d = decideNextCycle(profile({ plan: "annual", paid_until: "2027-08-26" }), [], TODAY);
    expect(d.create).not.toBeNull();
  });

  it("creates nothing for past_due, cancelled, missing plan or lapsed paid_until", () => {
    for (const p of [
      profile({ subscription_status: "past_due" }),
      profile({ subscription_status: "cancelled" }),
      profile({ plan: null }),
      profile({ paid_until: null }),
      profile({ paid_until: "2026-08-25" }), // expired yesterday
    ]) {
      expect(decideNextCycle(p, [], TODAY).create).toBeNull();
    }
  });

  it("never creates while a cycle is open (any non-terminal status)", () => {
    for (const status of ["awaiting_fulfillment", "shipped", "activated", "order_sent", "results_partial", "error"]) {
      const d = decideNextCycle(profile(), [cycle({ status })], TODAY);
      expect(d.create).toBeNull();
      expect(d.reason).toBe("open-cycle-exists");
    }
  });
});

describe("decideNextCycle — cadence", () => {
  it("waits 90 days after the previous confirmed extraction", () => {
    const recent = cycle({ extraction_confirmed_at: "2026-07-01T08:00:00Z" });
    expect(decideNextCycle(profile(), [recent], TODAY).create).toBeNull();

    const old = cycle({ extraction_confirmed_at: "2026-05-01T08:00:00Z" }); // +90d = 2026-07-30
    const d = decideNextCycle(profile(), [old], TODAY);
    expect(d.create).toMatchObject({ seq: 2, due_date: "2026-07-30" });
    expect(d.reason).toBe("cadence-due");
  });

  it("falls back to created_at when the cycle never recorded an extraction", () => {
    const d = decideNextCycle(profile(), [cycle({ created_at: "2026-05-10T10:00:00Z" })], TODAY);
    expect(d.create?.due_date).toBe("2026-08-08");
  });

  it("freezes profiles.next_panel_type onto the new cycle", () => {
    const d = decideNextCycle(
      profile({ next_panel_type: "full" }),
      [cycle({ extraction_confirmed_at: "2026-01-01T08:00:00Z" })],
      TODAY,
    );
    expect(d.create?.panel_type).toBe("full");
  });

  it("increments seq past the highest existing cycle", () => {
    const cycles = [cycle({ seq: 1 }), cycle({ seq: 2, created_at: "2026-05-01T10:00:00Z" })];
    const d = decideNextCycle(profile(), cycles, TODAY);
    expect(d.create?.seq).toBe(3);
  });
});

describe("decideNextCycle — one-time Full Panel", () => {
  it("creates a full-panel cycle without subscription entitlement", () => {
    const p = profile({
      subscription_status: "free",
      plan: null,
      paid_until: null,
      full_panel_purchased_at: "2026-08-20T12:00:00Z",
    });
    const d = decideNextCycle(p, [], TODAY);
    expect(d.create).toMatchObject({ panel_type: "full", due_date: TODAY });
    expect(d.reason).toBe("full-panel-purchase");
  });

  it("serves the full panel only once (existing full cycle = already served)", () => {
    const p = profile({ full_panel_purchased_at: "2026-08-20T12:00:00Z", subscription_status: "free", plan: null, paid_until: null });
    const served = [cycle({ panel_type: "full", status: "completed" })];
    expect(decideNextCycle(p, served, TODAY).create).toBeNull();
  });
});

describe("buildPlacerOrderNumber", () => {
  it("is short, alphanumeric (ECH rule) and unique per patient+seq", () => {
    expect(buildPlacerOrderNumber(42, 3)).toBe("EVA000042003");
    expect(buildPlacerOrderNumber(42, 3)).toMatch(/^[A-Z0-9]{1,20}$/);
  });

  it("cadence constant stays quarterly", () => {
    expect(CYCLE_CADENCE_DAYS).toBe(90);
  });
});
