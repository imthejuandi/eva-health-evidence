const ROMAN_MAP: [number, string][] = [
  [1000, "M"],
  [900, "CM"],
  [500, "D"],
  [400, "CD"],
  [100, "C"],
  [90, "XC"],
  [50, "L"],
  [40, "XL"],
  [10, "X"],
  [9, "IX"],
  [5, "V"],
  [4, "IV"],
  [1, "I"],
];

const QUARTER_ROMAN = ["", "I", "II", "III", "IV"];

export function yearRoman(year: number): string {
  if (year <= 0) return String(year);
  let n = year;
  let out = "";
  for (const [v, s] of ROMAN_MAP) {
    while (n >= v) {
      out += s;
      n -= v;
    }
  }
  return out;
}

export function quarterRoman(date: Date): string {
  const q = Math.floor(date.getMonth() / 3) + 1;
  return QUARTER_ROMAN[q] ?? String(q);
}

export function formatDayMonth(
  date: string,
  locale: string,
): { day: string; month: string; year: number } {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, "0");
  const month = d
    .toLocaleDateString(locale === "es" ? "es-ES" : "en-GB", { month: "long" })
    .replace(/^\w/, (c) => c.toUpperCase());
  return { day, month, year: d.getFullYear() };
}

export function fmtValue(v: number): string {
  if (Number.isInteger(v)) return groupThousands(String(v));
  return groupThousands(parseFloat(v.toFixed(2)).toString());
}

/**
 * A measured value as the lab reported it: a bounded result ("<0,5 mg/L",
 * below the assay's detection limit) keeps its comparator in front of the
 * number, so the patient never reads the bound as a measurement.
 */
export function fmtMeasured(v: number, comparator?: string | null): string {
  const c = comparator === "<" || comparator === ">" ? `${comparator} ` : "";
  return `${c}${fmtValue(v)}`;
}

/**
 * Group the integer part of a numeric string in threes with a narrow
 * no-break space (SI style, reads the same in es and en) once it reaches
 * five digits — the raw cell counts adopted from Echevarne (2026-09-17)
 * render as "4 850 000 /µL", not "4850000". Small values stay untouched.
 */
export function groupThousands(s: string): string {
  const m = /^(-?)(\d+)(\.\d+)?$/.exec(s);
  if (!m || m[2].length < 5) return s;
  return m[1] + m[2].replace(/\B(?=(\d{3})+(?!\d))/g, "\u202F") + (m[3] ?? "");
}

/**
 * Locale-aware display label for a biomarker_values.category slug.
 *
 * Categories come from the seed-references panel_category column —
 * lowercase slugs like "cardiovascular", "blood", "immune". This map
 * keeps every Spanish dashboard surface (left rail, category tabs,
 * stratum header, 3D constellation perimeter labels) reading in the
 * right language. Unknown slugs fall back to a sentence-cased English
 * version so a future seed addition doesn't render as blank.
 */
const CATEGORY_LABELS: Record<string, { en: string; es: string }> = {
  cardiovascular: { en: "Cardiovascular", es: "Cardiovascular" },
  metabolic: { en: "Metabolic", es: "Metabólico" },
  hormonal: { en: "Hormonal", es: "Hormonal" },
  thyroid: { en: "Thyroid", es: "Tiroides" },
  inflammatory: { en: "Inflammatory", es: "Inflamatorio" },
  nutrition: { en: "Nutrition", es: "Nutrición" },
  nutrients: { en: "Nutrients", es: "Nutrientes" },
  liver: { en: "Liver", es: "Hígado" },
  kidney: { en: "Kidney", es: "Riñón" },
  kidneys: { en: "Kidneys", es: "Riñones" },
  immune: { en: "Immune", es: "Inmune" },
  blood: { en: "Blood", es: "Sangre" },
  autoimmunity: { en: "Autoimmunity", es: "Autoinmunidad" },
  environmental: { en: "Environmental", es: "Ambiental" },
  biological_age: { en: "Biological age", es: "Edad biológica" },
  stress_aging: { en: "Stress & aging", es: "Estrés y envejecimiento" },
  pancreas: { en: "Pancreas", es: "Páncreas" },
  uncategorized: { en: "Uncategorized", es: "Sin categoría" },
};

export function formatCategoryLabel(
  category: string | null | undefined,
  locale: string,
): string {
  if (!category) return locale === "es" ? "Sin categoría" : "Uncategorized";
  const entry = CATEGORY_LABELS[category];
  if (entry) return locale === "es" ? entry.es : entry.en;
  return (
    category.charAt(0).toUpperCase() + category.slice(1).replace(/_/g, " ")
  );
}
