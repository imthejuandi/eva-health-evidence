import { describe, it, expect } from "vitest";
import { formatBridgeSummary, ago } from "./summary";

describe("bridge pass summary line", () => {
  it("reads the same on the desk and in the run log", () => {
    const line = formatBridgeSummary({
      uploaded: [],
      acks: ["254899.ACK (from procesados)"],
      orus: ["EVA000001004_X68800193.ORU"],
      duplicates: [],
      otherEnvironment: [],
      errors: [{ file: "X.OML", error: "Permission denied" }],
      alerts: [{ scope: "bridge.ack", message: "OML sent without ACK past the timeout" }],
      ms: 2563,
      processingId: "T",
    });
    expect(line).toBe(
      "[T] uploaded 0 (—) · ACKs 1 (254899.ACK (from procesados)) · ORUs 1 (EVA000001004_X68800193.ORU) · duplicates 0 · other env 0 · errors 1: X.OML: Permission denied · alerts 1: OML sent without ACK past the timeout · 2563 ms",
    );
  });

  it("relative time", () => {
    const now = new Date("2026-09-21T10:00:00Z");
    expect(ago("2026-09-21T09:59:30Z", now)).toBe("30s ago");
    expect(ago("2026-09-21T09:48:00Z", now)).toBe("12 min ago");
    expect(ago("2026-09-21T07:00:00Z", now)).toBe("3 h ago");
    expect(ago("2026-09-18T07:57:00Z", now)).toBe("2026-09-18 07:57");
  });
});
