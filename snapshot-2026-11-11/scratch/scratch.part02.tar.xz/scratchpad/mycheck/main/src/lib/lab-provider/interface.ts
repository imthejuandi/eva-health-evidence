import { type LabProviderResult } from "./types";

export interface LabProvider {
  name: string;
  /**
   * How this provider's payload arrives on the wire. "json" payloads are
   * JSON.parse'd by the route before parseResults; "hl7" payloads are passed
   * through as the raw pipe-delimited string (JSON.parse would throw on them).
   * Defaults to "json" when omitted.
   */
  payloadFormat?: "json" | "hl7";
  parseResults(payload: unknown): LabProviderResult;
  /**
   * Resolve a provider analyte code/name to an eva biomarker_key ("" when
   * unmapped — downstream skips + logs). Providers that receive a LOINC
   * alongside their proprietary code (Echevarne OBX-3.4) get it as the
   * optional second argument for fallback mapping.
   */
  mapBiomarkerName(providerName: string, loincCode?: string): string;
  // SEC-008 — mandatory. Every provider must verify a request before any
  // write; the route rejects (401) when this returns false.
  verifyWebhook(headers: Record<string, string>, body: string): boolean;
}
