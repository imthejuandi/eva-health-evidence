/**
 * Unit tests for kdm-adapter.ts.
 *
 * Run: `npx vitest run src/lib/biomarkers/kdm-adapter.test.ts`
 */
import { describe, it, expect } from "vitest";
import {
  kdmInputsFromBiomarkerValues,
  __test,
} from "./kdm-adapter";

describe("kdmInputsFromBiomarkerValues", () => {
  it("maps engine codes (uppercase) to Spanish KDM keys", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "APOB", value: 75 },
      { code: "HBA1C", value: 5.3 },
      { code: "ALBUMIN", value: 44 },
      { code: "CREATININE", value: 0.9 },
    ]);

    expect(result.inputs["Apolipoproteína B (ApoB)"]).toBe(75);
    expect(result.inputs["HbA1c (Hemoglobina Glicosilada)"]).toBe(5.3);
    expect(result.inputs["Albúmina"]).toBeCloseTo(4.4, 9); // 44 g/L → 4.4 g/dL for the KDM library
    expect(result.inputs["Creatinina"]).toBe(0.9);
    expect(result.skipped).toEqual([]);
    expect(result.unconverted).toEqual([]);
  });

  it("maps DB keys (snake_case) to the same Spanish keys", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "apolipoprotein_b", value: 75 },
      { code: "vitamin_d_25_oh", value: 42 },
      { code: "hs_crp", value: 0.8 },
    ]);

    expect(result.inputs["Apolipoproteína B (ApoB)"]).toBe(75);
    expect(result.inputs["Vitamina D (25-OH)"]).toBe(42);
    expect(result.inputs["PCR de Alta Sensibilidad (hs-PCR)"]).toBe(0.8);
  });

  it("brings raw cells/µL CBC counts to the KDM library's ×10³/μL and ×10⁶/μL", () => {
    // Engine canonical is Echevarne's raw count per µL (2026-09-17); the KDM
    // library keeps the thousands/millions scale, so the adapter divides.
    const result = kdmInputsFromBiomarkerValues([
      { code: "WBC", value: 6800 },
      { code: "PLT", value: 250000 },
      { code: "red_blood_cell_count", value: 4900000 },
    ]);

    expect(result.inputs["Recuento de Glóbulos Blancos"]).toBeCloseTo(6.8, 9);
    expect(result.inputs["Recuento de Plaquetas"]).toBeCloseTo(250, 9);
    expect(result.inputs["Recuento de Glóbulos Rojos"]).toBeCloseTo(4.9, 9);
    expect(result.converted).toEqual(["Recuento de Glóbulos Blancos", "Recuento de Plaquetas", "Recuento de Glóbulos Rojos"]);
    expect(result.unconverted).toEqual([]);
  });

  it("bridges the other Echevarne units the KDM library does not use", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "ALBUMIN", value: 44 }, // g/L → 4.4 g/dL
      { code: "calcium", value: 95 }, // mg/L → 9.5 mg/dL
      { code: "TESTOSTERONE", value: 5.5 }, // ng/mL → 550 ng/dL
    ]);
    expect(result.inputs["Albúmina"]).toBeCloseTo(4.4, 9);
    expect(result.inputs["Calcio (Sérico)"]).toBeCloseTo(9.5, 9);
    expect(result.inputs["Testosterona Total"]).toBeCloseTo(550, 9);
    expect(result.unconverted).toEqual([]);
  });

  it("records unmapped codes under skipped", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "HOMA_IR", value: 1.5 }, // computed metric, no KDM equivalent
      { code: "NLR", value: 1.8 }, // computed ratio, no KDM equivalent
      { code: "UNKNOWN_CODE", value: 99 },
    ]);

    expect(Object.keys(result.inputs)).toHaveLength(0);
    expect(result.skipped).toEqual(["HOMA_IR", "NLR", "UNKNOWN_CODE"]);
  });

  it("drops non-finite values silently (NaN-safety for the joint estimator)", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "APOB", value: NaN },
      { code: "HBA1C", value: Infinity },
      { code: "ALBUMIN", value: -Infinity },
      { code: "GLUCOSE", value: 90 }, // valid; should land in inputs
    ]);

    expect(Object.keys(result.inputs)).toEqual(["Glucosa (Ayunas)"]);
    expect(result.inputs["Glucosa (Ayunas)"]).toBe(90);
  });

  it("emits unconverted when unit mismatch has no conversion factor", () => {
    // Direct test of convertUnit via internal __test surface
    expect(__test.convertUnit(40, "ng/mL", "nmol/L")).toBeNull();
    expect(__test.convertUnit(40, "mg/dL", "mg/dL")).toBe(40);
  });

  it("normalizeUnitString collapses micro and ×10 variants", () => {
    expect(__test.normalizeUnitString("10³/µL")).toBe(
      __test.normalizeUnitString("×10³/μL"),
    );
    expect(__test.normalizeUnitString("μg/dL")).toBe(
      __test.normalizeUnitString("µg/dL"),
    );
  });

  it("synthetic 14-marker base-panel input maps cleanly", () => {
    // Synthetic input simulating a user uploading the KDM 14-marker base panel
    // via engine codes that map to it. Note: 4 of the 14 base panel markers
    // (BUN, Total Cholesterol, Fructosamine, and Cystatin-not-base) are
    // ABSENT from the eva engine's 39-code list, so this input uses
    // engine codes for the 10 overlapping markers, plus DB keys for the
    // 4 KDM-base-only markers.
    const result = kdmInputsFromBiomarkerValues([
      { code: "ALBUMIN", value: 44 },
      { code: "CREATININE", value: 0.9 },
      { code: "blood_urea_nitrogen", value: 14 },
      { code: "URIC_ACID", value: 5.2 },
      { code: "ALP", value: 75 },
      { code: "GGT", value: 18 },
      { code: "total_cholesterol", value: 180 },
      { code: "HDL_C", value: 55 },
      { code: "TG", value: 90 },
      { code: "HSCRP", value: 0.7 },
      { code: "FERRITIN", value: 80 },
      { code: "VITD", value: 42 },
      { code: "TSH", value: 1.8 },
      // Fructosamine intentionally omitted — derived from HbA1c in B.9.
    ]);

    expect(Object.keys(result.inputs).length).toBeGreaterThanOrEqual(13);
    expect(result.unconverted).toEqual([]);
    expect(result.inputs["Albúmina"]).toBeCloseTo(4.4, 9); // 44 g/L → 4.4 g/dL for the KDM library
    expect(result.inputs["Creatinina"]).toBe(0.9);
    expect(result.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBe(14);
    expect(result.inputs["Colesterol Total"]).toBe(180);
  });

  it("last duplicate wins when same KDM key supplied via two synonyms", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "APOB", value: 70 },
      { code: "apolipoprotein_b", value: 75 }, // second one wins
    ]);
    expect(result.inputs["Apolipoproteína B (ApoB)"]).toBe(75);
  });

  describe("Urea cross-molecule scaling to BUN", () => {
    it("scales a urea-keyed value to BUN via ×0.4665", () => {
      const result = kdmInputsFromBiomarkerValues([
        // 30 mg/dL Urea ≈ 14 mg/dL BUN (the KDM library is anchored on BUN).
        { code: "urea", value: 30 },
      ]);
      // Allow for floating-point: 30 × 0.4665 = 13.995.
      expect(result.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBeCloseTo(
        13.995,
        3,
      );
      expect(result.converted).toContain("BUN (Nitrógeno Ureico en Sangre)");
      expect(result.unconverted).toEqual([]);
    });

    it("prefers same-molecule BUN over cross-molecule Urea when both are present", () => {
      // Lab reports BOTH a Urea row AND a BUN row for the same draw.
      // bun's value should win regardless of array order because it's
      // same-molecule (no cross-molecule scaling needed).
      const ureaFirst = kdmInputsFromBiomarkerValues([
        { code: "urea", value: 30 }, // → would scale to 13.995
        { code: "bun", value: 14 }, // same-molecule, wins
      ]);
      expect(ureaFirst.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBe(14);

      const bunFirst = kdmInputsFromBiomarkerValues([
        { code: "bun", value: 14 }, // same-molecule, wins
        { code: "urea", value: 30 }, // → would scale to 13.995, dropped
      ]);
      expect(bunFirst.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBe(14);
    });

    it("falls back to scaled Urea when no BUN row is present", () => {
      const result = kdmInputsFromBiomarkerValues([
        { code: "urea", value: 40 },
      ]);
      expect(result.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBeCloseTo(
        18.66,
        2,
      );
    });
  });
});
