import { describe, it, expect } from "vitest";
import { decodeHl7Bytes } from "./hl7";

// Byte-level shape of ECH's real training ORU (2026-09-07): Latin-1, MSH-18 empty.
const latin1Oru = Buffer.concat([
  Buffer.from("MSH|^~\\&|LABTRAK|ECHEVARNE|EVAHEALTH|EVAHEALTH|20260907152608||ORU^R01|X68800189-261|P|2.5|||AL||||||SFTP\r", "latin1"),
  Buffer.from("OBX|3|NM|H0005^HEMAT", "latin1"),
  Buffer.from([0xcd]), // Í
  Buffer.from("ES^^789-8^^H0005||5000000,000|^/", "latin1"),
  Buffer.from([0xb5]), // µ
  Buffer.from("L|3800000,000-5300000,000|N|||F\r", "latin1"),
]);

describe("decodeHl7Bytes — ECH files are Latin-1 unless MSH-18 says UTF-8", () => {
  it("decodes ECH's Latin-1 ORU so µ and accented letters survive", () => {
    const text = decodeHl7Bytes(latin1Oru);
    expect(text).toContain("HEMATÍES");
    expect(text).toContain("/µL");
    expect(text).not.toContain("�");
  });

  it("decodes as UTF-8 when MSH-18 declares it (our own OMLs)", () => {
    const utf8 = Buffer.from("MSH|^~\\&|EVAHEALTH|EVAHEALTH|LABTRAK|ECHEVARNE|20260908120000||OML^O21|X|T|2.5|||AL|||UTF-8\rPID|1||00000000T^^^^DNI||PÉREZ^JOSÉ|\r", "utf8");
    expect(decodeHl7Bytes(utf8)).toContain("PÉREZ^JOSÉ");
  });
});

describe("decodeHl7Bytes — real ECH files from training (both encodings seen in practice)", () => {
  it("2026-09-07 ORU: Latin-1 with empty MSH-18 → decoded as Latin-1", async () => {
    const { readFileSync } = await import("node:fs");
    const text = decodeHl7Bytes(new Uint8Array(readFileSync("docs/context/training/EVA2026T1_X68800189.ORU")));
    expect(text).toContain("HEMATÍES");
    expect(text).toContain("/µL");
  });
  it("2026-09-09 ORU: ECH now declares UTF-8 in MSH-18 and the bytes are UTF-8 → decoded as UTF-8", async () => {
    const { readFileSync } = await import("node:fs");
    const text = decodeHl7Bytes(new Uint8Array(readFileSync("docs/context/training/EVA000001001_X68800190.ORU")));
    expect(text.split("\r")[0].split("|")[17]).toBe("UTF-8");
    expect(text).toContain("HEMATÍES");
    expect(text).toContain("/µL");
    expect(text).not.toContain("Ã"); // classic double-decode symptom
  });
});
