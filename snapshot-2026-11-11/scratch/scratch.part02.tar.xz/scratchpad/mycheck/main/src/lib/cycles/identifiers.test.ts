import { describe, it, expect } from "vitest";
import { ALPHANUMERIC_ID, buildPlacerOrderNumber, nhcFor } from "./identifiers";

describe("identifiers — ECH format rules (short, alphanumeric)", () => {
  it("renders the NHC as EVA + 6 digits", () => {
    expect(nhcFor(1)).toBe("EVA000001");
    expect(nhcFor(42)).toBe("EVA000042");
    expect(nhcFor(123456)).toBe("EVA123456");
    expect(nhcFor(42)).toMatch(ALPHANUMERIC_ID);
  });

  it("placer = NHC + 3-digit seq, stable and unique per patient+seq", () => {
    expect(buildPlacerOrderNumber(42, 1)).toBe("EVA000042001");
    expect(buildPlacerOrderNumber(42, 12)).toBe("EVA000042012");
    expect(buildPlacerOrderNumber(7, 1)).not.toBe(buildPlacerOrderNumber(7, 2));
  });

  it("rejects nonsense inputs instead of emitting a bad id", () => {
    expect(() => nhcFor(0)).toThrow();
    expect(() => nhcFor(1.5)).toThrow();
    expect(() => buildPlacerOrderNumber(42, 0)).toThrow();
    expect(() => buildPlacerOrderNumber(42, 1000)).toThrow();
  });
});
