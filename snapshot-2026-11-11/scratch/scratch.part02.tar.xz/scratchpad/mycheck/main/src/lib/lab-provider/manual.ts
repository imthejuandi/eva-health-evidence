import { timingSafeEqual } from "node:crypto";
import { type LabProvider } from "./interface";
import { type LabProviderResult } from "./types";

// SEC-008 — the manual/internal webhook must present a shared secret as
// `Authorization: Bearer <LAB_WEBHOOK_SECRET>`. Fails closed when the secret
// is unset so an unconfigured deployment rejects rather than accepts.
function bearerMatches(headers: Record<string, string>): boolean {
  const secret = process.env.LAB_WEBHOOK_SECRET;
  if (!secret) return false;
  const auth = headers["authorization"] ?? "";
  const match = /^Bearer\s+(.+)$/i.exec(auth);
  if (!match) return false;
  const provided = Buffer.from(match[1]);
  const expected = Buffer.from(secret);
  return provided.length === expected.length && timingSafeEqual(provided, expected);
}

interface ManualFormEntry {
  biomarker_key: string;
  value: number;
  unit: string;
}

interface ManualFormPayload {
  userId: string;
  collectionDate: string;
  results: ManualFormEntry[];
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

export const ManualProvider: LabProvider = {
  name: "manual",

  parseResults(payload: unknown): LabProviderResult {
    const data = payload as ManualFormPayload;
    return {
      providerReference: `manual-${Date.now()}`,
      userId: data.userId,
      biomarkers: data.results.map((r) => ({
        biomarker_key: r.biomarker_key,
        value: r.value,
        unit: r.unit,
      })),
      collectionDate: data.collectionDate,
      rawPayload: payload,
    };
  },

  mapBiomarkerName(providerName: string): string {
    return slugify(providerName);
  },

  verifyWebhook(headers: Record<string, string>, _body: string): boolean {
    return bearerMatches(headers);
  },
};
