import { describe, it, expect, beforeEach, beforeAll, afterAll } from "vitest";

// The ACK builder identifies eva via env (fail-closed) — same values as production.
beforeAll(() => {
  process.env.ECH_MSH_SENDING_APP = "EVAHEALTH";
  process.env.ECH_MSH_SENDING_FACILITY = "EVAHEALTH";
});
afterAll(() => {
  delete process.env.ECH_MSH_SENDING_APP;
  delete process.env.ECH_MSH_SENDING_FACILITY;
});
import { readFileSync } from "node:fs";
import { InMemorySftp } from "./sftp";
import { InMemoryBridgeStore, type BridgeCycle } from "./store";
import { runBridgeSync } from "./sync";
import { parseAck } from "@/lib/lab-provider/ack";
import type { LabProviderResult } from "@/lib/lab-provider/types";

const BASE = "/files";
const NOW = new Date("2026-09-09T08:00:00Z");
// The REAL training result Echevarne sent us (Latin-1, MSH-18 empty, 38 OBX + PDF).
const REAL_ORU = new Uint8Array(readFileSync("docs/context/training/EVA2026T1_X68800189.ORU"));
const REAL_ACK = readFileSync("docs/context/training/254818.ACK", "latin1");

function mailbox(): InMemorySftp {
  const s = new InMemorySftp();
  for (const d of ["peticiones", "peticiones/ack", "peticiones/ack/procesados", "peticiones/procesadas", "resultados", "resultados/ack", "resultados/ack/procesados", "resultados/procesados"]) {
    s.mkdirp(`${BASE}/${d}`);
  }
  return s;
}

function text(sftp: InMemorySftp, path: string): string {
  return Buffer.from(sftp.files.get(path)!).toString("utf8");
}

describe("bridge sync — outbound OMLs", () => {
  let sftp: InMemorySftp;
  let store: InMemoryBridgeStore;
  beforeEach(() => {
    sftp = mailbox();
    store = new InMemoryBridgeStore();
  });

  it("writes the order under its final name (ECH's mailbox denies .tmp), marks it sent and moves the cycle to order_sent", async () => {
    const c = store.addCycle({ userId: "u1", status: "shipped", seq: 1, kitLabelCode: "X68800191", placerOrderNumber: "EVA000042001" });
    store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000042001M1", raw: "MSH|^~\\&|EVAHEALTH|…", filename: "X68800191.OML" });

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.uploaded).toEqual(["X68800191.OML"]);
    expect(r.errors).toEqual([]);
    expect(sftp.files.has(`${BASE}/peticiones/X68800191.OML`)).toBe(true);
    // No temp file is created at all — the server rejects that extension.
    expect(sftp.log.filter((l) => l.includes(".tmp"))).toEqual([]);
    expect(sftp.log.filter((l) => l.startsWith("put"))[0]).toBe(`put ${BASE}/peticiones/X68800191.OML`);
    expect(store.outbound[0].status).toBe("sent");
    expect(c.status).toBe("order_sent");
  });

  it("still supports the atomic tmp+rename upload if ECH ever allows it", async () => {
    const c = store.addCycle({ userId: "u1", status: "shipped", seq: 1, kitLabelCode: "X68800191", placerOrderNumber: "EVA000042001" });
    store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000042001M1", raw: "MSH|x", filename: "X68800191.OML" });

    const r = await runBridgeSync({ sftp, store, now: NOW, atomicUpload: true });
    expect(r.uploaded).toEqual(["X68800191.OML"]);
    expect(sftp.log.filter((l) => l.startsWith("put"))[0]).toBe(`put ${BASE}/peticiones/X68800191.OML.tmp`);
    expect(sftp.log.some((l) => l.startsWith(`rename ${BASE}/peticiones/X68800191.OML.tmp`))).toBe(true);
    expect(sftp.files.has(`${BASE}/peticiones/X68800191.OML.tmp`)).toBe(false);
    expect(sftp.files.has(`${BASE}/peticiones/X68800191.OML`)).toBe(true);
  });

  it("is idempotent: a second pass uploads nothing", async () => {
    const c = store.addCycle({ userId: "u1", status: "shipped", seq: 1, kitLabelCode: "X68800191", placerOrderNumber: "EVA000042001" });
    store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000042001M1", raw: "MSH|x", filename: "X68800191.OML" });
    await runBridgeSync({ sftp, store, now: NOW });
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.uploaded).toEqual([]);
    expect(sftp.log.filter((l) => l.startsWith("put")).length).toBe(1);
  });

  it("an upload failure on one file never stops the pass", async () => {
    const c = store.addCycle({ userId: "u1", status: "shipped", seq: 1, kitLabelCode: "X68800191", placerOrderNumber: "EVA000042001" });
    store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000042001M1", raw: "MSH|x", filename: "X68800191.OML", createdAt: "2026-01-01" });
    const c2 = store.addCycle({ userId: "u2", status: "shipped", seq: 1, kitLabelCode: "X68800192", placerOrderNumber: "EVA000043001" });
    store.queueOutbound({ cycleId: c2.id, messageControlId: "EVA000043001M1", raw: "MSH|y", filename: "X68800192.OML", createdAt: "2026-01-02" });
    const failing = sftp.put.bind(sftp);
    sftp.put = async (path, data) => {
      if (path.includes("X68800191")) throw new Error("boom");
      return failing(path, data);
    };
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.errors).toEqual([{ file: "X68800191.OML", error: "boom" }]);
    expect(r.uploaded).toEqual(["X68800192.OML"]);
    expect(store.outbound[0].status).toBe("queued"); // retried next pass
  });
});

describe("bridge sync — ACKs from Echevarne for our OMLs", () => {
  // ECH's ACK carries OUR OML's MSH-10 as its own (254818.ACK: MSH-10 =
  // EVA-TRAIN-20260903-0001 = MSA-2). Archiving it must never collide with
  // the outbound row — dedupe is per direction (migration 20260921000000).
  it("an ACK whose MSH-10 equals our OML's MSH-10 is archived, not mistaken for a duplicate", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA-TRAIN-20260903-0001", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "sent";
    m.sentAt = NOW.toISOString();
    sftp.files.set(`${BASE}/peticiones/ack/254818.ACK`, Buffer.from(REAL_ACK, "latin1"));
    expect(parseAck(REAL_ACK).messageControlId).toBe(parseAck(REAL_ACK).ackedMessageControlId); // the collision that bit us
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.duplicates).toEqual([]);
    expect(r.acksProcessed).toEqual(["254818.ACK"]);
    expect(c.status).toBe("order_accepted");
  });

  it("CA → outbound processed, cycle order_accepted, ACK archived and moved to ack/procesados", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA-TRAIN-20260903-0001", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "sent";
    m.sentAt = NOW.toISOString();
    // The real ACK Joan's system produced for our OML nº 1.
    sftp.files.set(`${BASE}/peticiones/ack/X68800189.ACK`, Buffer.from(REAL_ACK, "latin1"));

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.acksProcessed).toEqual(["X68800189.ACK"]);
    expect(r.errors).toEqual([]);
    expect(m.status).toBe("processed");
    expect(c.status).toBe("order_accepted");
    expect(c.patch.oml_ack).toBe("CA");
    expect(store.inbound[0]).toMatchObject({ msgType: "ACK", status: "processed", cycleId: c.id }); // tied to the customer's cycle
    expect(sftp.files.has(`${BASE}/peticiones/ack/procesados/X68800189.ACK`)).toBe(true);
    expect(sftp.files.has(`${BASE}/peticiones/ack/X68800189.ACK`)).toBe(false);
  });

  it("CE → cycle error with the reason, alert raised; unknown MSA-2 → alert, file still moved", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800191", placerOrderNumber: "EVA000042001" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000042001M1", raw: "MSH|x", filename: "X68800191.OML" });
    m.status = "sent";
    m.sentAt = NOW.toISOString();
    const ce = "MSH|^~\\&|LABTRAK|ECHEVARNE|EVAHEALTH|EVAHEALTH|20260909100000||ACK^O21^OML_O21|ACK1|T|2.5\rMSA|CE|EVA000042001M1|rechazado\rERR|||CODIGO_X^Paciente sin documento";
    sftp.files.set(`${BASE}/peticiones/ack/X68800191.ACK`, Buffer.from(ce, "latin1"));
    const unknown = "MSH|^~\\&|LABTRAK|ECHEVARNE|EVAHEALTH|EVAHEALTH|20260909100001||ACK^O21^OML_O21|ACK2|T|2.5\rMSA|CA|NOPE";
    sftp.files.set(`${BASE}/peticiones/ack/X99999999.ACK`, Buffer.from(unknown, "latin1"));

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(c.status).toBe("error");
    expect(String(c.patch.oml_ack)).toMatch(/^CE:/);
    expect(r.alerts.map((a) => a.message)).toEqual(expect.arrayContaining([expect.stringMatching(/REJECTED/), expect.stringMatching(/unknown OML/)]));
    expect(sftp.files.has(`${BASE}/peticiones/ack/procesados/X99999999.ACK`)).toBe(true);
  });

  it("an ACK we could not move is still processed, alerts about the mailbox, and is not processed twice", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA-TRAIN-20260903-0001", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "sent";
    m.sentAt = NOW.toISOString();
    sftp.files.set(`${BASE}/peticiones/ack/X68800189.ACK`, Buffer.from(REAL_ACK, "latin1"));
    sftp.rename = async () => {
      throw new Error("Permission denied");
    };

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.acksProcessed).toEqual(["X68800189.ACK"]); // the work stands…
    expect(c.status).toBe("order_accepted");
    expect(r.alerts[0].scope).toBe("bridge.mailbox"); // …and the stuck file is called out
    expect(r.errors[0].error).toMatch(/processed, but could not be moved/);

    // The file is still there; MSH-10 dedupe keeps the next pass from redoing it.
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.duplicates).toEqual(["X68800189.ACK"]);
    expect(store.inbound).toHaveLength(1);
  });
});

describe("bridge sync — results (the real Echevarne ORU)", () => {
  function seeded() {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    return { sftp, store, c };
  }

  it("decodes Latin-1, matches by placer, records results, ACKs with CA and moves the file", async () => {
    const { sftp, store, c } = seeded();
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.errors).toEqual([]);
    expect(r.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(c.status).toBe("results_final");
    expect(store.results[0]).toMatchObject({ cycleId: c.id, biomarkers: 22 });
    expect(store.inbound[0]).toMatchObject({ msgType: "ORU", messageControlId: "X68800189-261", status: "processed", cycleId: c.id });
    // Raw archive must have survived the Latin-1 decode (µ intact).
    expect(store.inbound[0].raw).toContain("/µL");
    const ack = text(sftp, `${BASE}/resultados/ack/X68800189.ACK`);
    const parsed = parseAck(ack);
    expect(parsed.ok).toBe(true);
    expect(parsed.ackedMessageControlId).toBe("X68800189-261");
    expect(ack.split("\r")[0]).toMatch(/^MSH\|\^~\\&\|EVAHEALTH\|EVAHEALTH\|LABTRAK\|ECHEVARNE\|20260909100000\|\|ACK\^R01\|X68800189A100000\|T\|2\.5/);
    expect(sftp.files.has(`${BASE}/resultados/procesados/X68800189.ORU`)).toBe(true);
    expect(sftp.files.has(`${BASE}/resultados/X68800189.ORU`)).toBe(false);
    expect(r.alerts).toEqual([]);
  });

  it("re-delivery of the same ORU is ACKed again but never processed twice", async () => {
    const { sftp, store, c } = seeded();
    await runBridgeSync({ sftp, store, now: NOW });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU); // ECH retries
    const r2 = await runBridgeSync({ sftp, store, now: new Date(NOW.getTime() + 60_000) });
    expect(r2.duplicates).toEqual(["X68800189.ORU"]);
    expect(store.results).toHaveLength(1);
    expect(c.status).toBe("results_final");
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).ok).toBe(true);
    expect(sftp.files.has(`${BASE}/resultados/X68800189.ORU`)).toBe(false);
  });

  it("an ORU with no matching cycle gets a CE ACK, is archived, moved, and raises an alert", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore(); // no cycles at all
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r = await runBridgeSync({ sftp, store, now: NOW });
    const parsed = parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`));
    expect(parsed.ok).toBe(false);
    expect(parsed.errorCode).toBe("UNMATCHED_ORDER");
    expect(store.inbound[0].status).toBe("error");
    expect(store.results).toHaveLength(0);
    expect(r.alerts.map((a) => a.message)).toContain("ORU does not match any cycle");
    expect(sftp.files.has(`${BASE}/resultados/procesados/X68800189.ORU`)).toBe(true);
  });

  it("a petition-number mismatch between ORU and cycle is refused (CE) and alerted", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800999", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).errorCode).toBe("LABEL_MISMATCH");
    expect(store.results).toHaveLength(0);
    expect(r.alerts[0].message).toMatch(/does not match the cycle's sticker/);
  });

  it("a corrupt ORU is left in place for the next pass and reported, other files still flow", async () => {
    const { sftp, store } = seeded();
    sftp.files.set(`${BASE}/resultados/BROKEN.ORU`, Buffer.from("not hl7 at all", "latin1"));
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(r.errors.map((e) => e.file)).toEqual(["BROKEN.ORU"]);
    expect(sftp.files.has(`${BASE}/resultados/BROKEN.ORU`)).toBe(true);
  });

  it("an ORU we could not move is still processed and ACKed, and is only re-ACKed on the next pass", async () => {
    const { sftp, store, c } = seeded();
    sftp.rename = async () => {
      throw new Error("Permission denied");
    };

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(c.status).toBe("results_final");
    expect(store.results).toHaveLength(1);
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).ok).toBe(true);
    expect(r.alerts.map((a) => a.scope)).toEqual(["bridge.mailbox"]);

    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.duplicates).toEqual(["X68800189.ORU"]);
    expect(store.results).toHaveLength(1); // results recorded once, ACK re-sent
  });

  it("results for an order the lab never ACKed close the OML as implicitly accepted, once", async () => {
    // Seen in training 2026-09-17: X68800192.ORU arrived with nothing in /peticiones/ack.
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA2026T1M1", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "sent";
    m.sentAt = new Date(NOW.getTime() - 10 * 24 * 3_600_000).toISOString(); // long past the ACK timeout
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(c.status).toBe("results_final");
    expect(m.status).toBe("processed");
    expect(c.patch.oml_ack).toBe("ORU"); // never a CA we did not receive
    expect(r.alerts.map((a) => a.message)).toEqual([expect.stringMatching(/never acknowledged/)]);
    // No stale-order alert on the same pass, nor on the next one.
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.alerts).toEqual([]);
  });

  it("archives the ACK it writes for every ORU — our own traffic included", async () => {
    const { sftp, store, c } = seeded();
    await runBridgeSync({ sftp, store, now: NOW });
    expect(store.outboundAcks).toHaveLength(1);
    expect(store.outboundAcks[0]).toMatchObject({ cycleId: c.id, messageControlId: "X68800189A100000" });
    expect(store.outboundAcks[0].raw).toBe(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`));
  });
});

describe("bridge sync — archived is not processed (audit 2026-09-21, F01)", () => {
  function seeded() {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    return { sftp, store, c };
  }

  it("a failure after archiving leaves no ACK and no result; the next pass processes the same message and only then answers CA", async () => {
    const { sftp, store, c } = seeded();
    const realRecord = store.recordResults.bind(store);
    let failOnce = true;
    store.recordResults = async (cycle: BridgeCycle, parsed: LabProviderResult) => {
      if (failOnce) {
        failOnce = false;
        throw new Error("profile has no date of birth");
      }
      return realRecord(cycle, parsed);
    };

    const r1 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r1.errors).toEqual([{ file: "X68800189.ORU", error: "profile has no date of birth" }]);
    expect(r1.orusProcessed).toEqual([]);
    expect(sftp.files.has(`${BASE}/resultados/ack/X68800189.ACK`)).toBe(false); // nothing told the lab "done"
    expect(sftp.files.has(`${BASE}/resultados/X68800189.ORU`)).toBe(true); // file stays for the next pass
    expect(store.results).toHaveLength(0);
    expect(store.inbound).toHaveLength(1);
    expect(store.inbound[0]).toMatchObject({ status: "error", cycleId: c.id });
    expect(store.inbound[0].error).toMatch(/processing failed: profile has no date of birth/);
    expect(c.status).toBe("order_accepted");

    const r2 = await runBridgeSync({ sftp, store, now: new Date(NOW.getTime() + 600_000) });
    expect(r2.errors).toEqual([]);
    expect(r2.duplicates).toEqual([]); // not "already handled"…
    expect(r2.retried).toEqual(["X68800189.ORU"]); // …but picked up where it died
    expect(r2.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(store.results).toHaveLength(1);
    expect(store.inbound).toHaveLength(1); // same archived row, now closed
    expect(store.inbound[0]).toMatchObject({ status: "processed", cycleId: c.id });
    expect(c.status).toBe("results_final");
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).ok).toBe(true);
    expect(sftp.files.has(`${BASE}/resultados/procesados/X68800189.ORU`)).toBe(true);
  });

  it("a retry whose earlier pass had already recorded the results does not record them twice", async () => {
    const { sftp, store, c } = seeded();
    // Die AFTER recordResults (results + lab_result_id written) but before the row is closed.
    const realSet = store.setCycleStatus.bind(store);
    let failOnce = true;
    store.setCycleStatus = async (cycleId, status, patch) => {
      if (failOnce) {
        failOnce = false;
        throw new Error("connection reset");
      }
      return realSet(cycleId, status, patch);
    };
    const r1 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r1.errors).toHaveLength(1);
    expect(store.results).toHaveLength(1);
    expect(c.labResultId).toBe(store.results[0].labResultId);
    expect(store.inbound[0].status).toBe("error");

    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.retried).toEqual(["X68800189.ORU"]);
    expect(store.results).toHaveLength(1); // reused, not duplicated
    expect(c.status).toBe("results_final");
    expect(c.patch.lab_result_id).toBe(store.results[0].labResultId);
    expect(store.inbound[0].status).toBe("processed");
    expect(r2.alerts).toEqual([]);
  });

  it("an unmatched ORU re-delivered with the same MSH-10 gets CE again, and CA once its cycle exists", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore(); // no cycle yet
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r1 = await runBridgeSync({ sftp, store, now: NOW });
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).errorCode).toBe("UNMATCHED_ORDER");
    expect(store.inbound[0].status).toBe("error");

    // ECH re-delivers; still no cycle → CE again, still not "done".
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.retried).toEqual(["X68800189.ORU"]);
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).errorCode).toBe("UNMATCHED_ORDER");
    expect(store.results).toHaveLength(0);
    expect(store.inbound).toHaveLength(1);

    // Ops creates the cycle; the next re-delivery is matched, recorded and answered CA.
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r3 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r3.retried).toEqual(["X68800189.ORU"]);
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).ok).toBe(true);
    expect(store.results).toHaveLength(1);
    expect(store.inbound[0]).toMatchObject({ status: "processed", cycleId: c.id });
    expect(c.status).toBe("results_final");
    void r1;
  });

  it("a fully processed ORU re-delivered is re-ACKed only (unchanged)", async () => {
    const { sftp, store } = seeded();
    await runBridgeSync({ sftp, store, now: NOW });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.duplicates).toEqual(["X68800189.ORU"]);
    expect(r2.retried).toEqual([]);
    expect(store.results).toHaveLength(1);
  });
});

describe("bridge sync — partial and corrected reports (decision 2026-09-22: one result per cycle)", () => {
  /** The real training ORU with another MSH-10 and, optionally, ORC-5 = A (partial). */
  function variant(controlId: string, opts: { partial?: boolean } = {}): Uint8Array {
    let s = Buffer.from(REAL_ORU).toString("latin1").replace("|X68800189-261|", `|${controlId}|`);
    if (opts.partial) s = s.replace(/^(ORC\|RE\|EVA2026T1\|X68800189\|X68800189\|)CM\|/gm, "$1A|");
    return new Uint8Array(Buffer.from(s, "latin1"));
  }

  it("a partial report is archived and ACKed but records nothing; the final one records once; a later corrected one replaces in place", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });

    // 1. Partial (ORC-5 = A): the lab is answered, the patient is not.
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, variant("X68800189-260", { partial: true }));
    const r1 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r1.errors).toEqual([]);
    expect(r1.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).ok).toBe(true);
    expect(sftp.files.has(`${BASE}/resultados/procesados/X68800189.ORU`)).toBe(true);
    expect(store.results).toHaveLength(0);
    expect(c.status).toBe("results_partial");
    expect(c.labResultId).toBeNull();
    expect(store.inbound[0]).toMatchObject({ messageControlId: "X68800189-260", status: "processed", cycleId: c.id });
    expect(r1.corrected).toEqual([]);

    // 2. Final (ORC-5 = CM, new MSH-10): the one result, the one email.
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.errors).toEqual([]);
    expect(r2.duplicates).toEqual([]);
    expect(r2.retried).toEqual([]);
    expect(store.results).toHaveLength(1);
    expect(store.replacements).toBe(0);
    expect(c.status).toBe("results_final");
    expect(c.patch.lab_result_id).toBe(store.results[0].labResultId);
    expect(r2.corrected).toEqual([]);

    // 3. Corrected (another MSH-10, same petition): same result id, new values, reported as corrected.
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, variant("X68800189-262"));
    const r3 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r3.errors).toEqual([]);
    expect(r3.duplicates).toEqual([]);
    expect(store.results).toHaveLength(1); // never a second lab_results row
    expect(store.replacements).toBe(1);
    expect(store.results[0].labResultId).toBe(c.labResultId);
    expect(c.status).toBe("results_final");
    expect(r3.corrected).toEqual(["X68800189-262"]);
    expect(store.inbound.map((i) => i.status)).toEqual(["processed", "processed", "processed"]);
    expect(parseAck(text(sftp, `${BASE}/resultados/ack/X68800189.ACK`)).ok).toBe(true);
  });

  it("a partial report re-delivered is re-ACKed only, and the partial never counts as the cycle's result", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, variant("X68800189-260", { partial: true }));
    await runBridgeSync({ sftp, store, now: NOW });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, variant("X68800189-260", { partial: true }));
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.duplicates).toEqual(["X68800189.ORU"]);
    expect(store.results).toHaveLength(0);
    expect(c.status).toBe("results_partial");
  });

  it("a retry that re-records over the same result is not reported as a correction", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const realSet = store.setCycleStatus.bind(store);
    let failOnce = true;
    store.setCycleStatus = async (cycleId, status, patch) => {
      if (failOnce) {
        failOnce = false;
        throw new Error("connection reset");
      }
      return realSet(cycleId, status, patch);
    };
    await runBridgeSync({ sftp, store, now: NOW });
    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.retried).toEqual(["X68800189.ORU"]);
    expect(r2.corrected).toEqual([]);
    expect(store.results).toHaveLength(1);
    expect(c.status).toBe("results_final");
  });
});

describe("bridge sync — stale orders", () => {
  it("alerts on OMLs sent past the ACK timeout, not on fresh ones", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X1", placerOrderNumber: "EVA000001001" });
    const old = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000001001M1", raw: "x", filename: "X1.OML" });
    old.status = "sent";
    old.sentAt = new Date(NOW.getTime() - 72 * 3_600_000).toISOString();
    const fresh = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000001001M2", raw: "x", filename: "X1.OML" });
    fresh.status = "sent";
    fresh.sentAt = new Date(NOW.getTime() - 1 * 3_600_000).toISOString();
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.alerts).toHaveLength(1);
    expect(r.alerts[0].meta?.messageControlId).toBe("EVA000001001M1");
  });

  it("a cancelled cycle's unacknowledged OML is not a stale order", async () => {
    // X68800191: sent, then ECH said the petition number was already used and
    // the cycle was cancelled and resent as X68800193.
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "cancelled", seq: 3, kitLabelCode: "X68800191", placerOrderNumber: "EVA000001003" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA000001003M1", raw: "x", filename: "X68800191.OML" });
    m.status = "sent";
    m.sentAt = new Date(NOW.getTime() - 72 * 3_600_000).toISOString();
    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.alerts).toEqual([]);
  });

  it("an order that waited days in the queue is not stale the pass that finally uploads it", async () => {
    // The real case: ECH's mailbox denied writes from 09-09 to 09-15, so the
    // OML sat queued for six days. The timeout counts from the upload, never
    // from the queueing.
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "shipped", seq: 1, kitLabelCode: "X68800192", placerOrderNumber: "EVA000001002" });
    store.queueOutbound({
      cycleId: c.id,
      messageControlId: "EVA000001002M1",
      raw: "MSH|x",
      filename: "X68800192.OML",
      createdAt: new Date(NOW.getTime() - 6 * 24 * 3_600_000).toISOString(),
    });

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.uploaded).toEqual(["X68800192.OML"]);
    expect(r.alerts).toEqual([]);
  });
});

describe("bridge sync — one mailbox, two environments (MSH-11)", () => {
  // ECH's real training ORU is stamped MSH-11 = P (they stamp everything P today).
  it("with honourProcessingId, a T environment leaves a P result untouched for production", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);

    const r = await runBridgeSync({ sftp, store, now: NOW, processingId: "T", honourProcessingId: true });
    expect(r.otherEnvironment).toEqual(["X68800189.ORU"]);
    expect(r.orusProcessed).toEqual([]);
    expect(store.inbound).toHaveLength(0); // not archived
    expect(sftp.files.has(`${BASE}/resultados/X68800189.ORU`)).toBe(true); // not moved
    expect(sftp.files.has(`${BASE}/resultados/ack/X68800189.ACK`)).toBe(false); // not ACKed
    expect(r.errors).toEqual([]);
  });

  it("the matching environment takes it; an ACK stamped T stays with T", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA-TRAIN-20260903-0001", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "sent";
    m.sentAt = NOW.toISOString();
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    sftp.files.set(`${BASE}/peticiones/ack/X68800189.ACK`, Buffer.from(REAL_ACK, "latin1")); // MSH-11 = T

    const asP = await runBridgeSync({ sftp, store, now: NOW, processingId: "P", honourProcessingId: true });
    expect(asP.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(asP.otherEnvironment).toEqual(["X68800189.ACK"]);
    expect(sftp.files.has(`${BASE}/peticiones/ack/X68800189.ACK`)).toBe(true);
  });

  it("is off by default: today ECH stamps every ORU P, so a T environment still processes it", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    store.addCycle({ userId: "u1", status: "order_accepted", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    sftp.files.set(`${BASE}/resultados/X68800189.ORU`, REAL_ORU);
    const r = await runBridgeSync({ sftp, store, now: NOW, processingId: "T" });
    expect(r.orusProcessed).toEqual(["X68800189.ORU"]);
    expect(r.otherEnvironment).toEqual([]);
  });
});

describe("bridge sync — ACKs that reached procesados before we read them", () => {
  // ECH's process moved 254889.ACK into /peticiones/ack/procesados on 2026-09-16
  // and our pass, which only listed /ack, never saw it.
  it("recovers the ACK read-only: order acknowledged, file left where it is, silent on the next pass", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "order_sent", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA-TRAIN-20260903-0001", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "sent";
    m.sentAt = NOW.toISOString();
    sftp.files.set(`${BASE}/peticiones/ack/procesados/254889.ACK`, Buffer.from(REAL_ACK, "latin1"));

    const r = await runBridgeSync({ sftp, store, now: NOW });
    expect(r.acksProcessed).toEqual(["254889.ACK (from procesados)"]);
    expect(m.status).toBe("processed");
    expect(c.status).toBe("order_accepted");
    expect(sftp.files.has(`${BASE}/peticiones/ack/procesados/254889.ACK`)).toBe(true);
    expect(sftp.log.filter((l) => l.startsWith("rename"))).toEqual([]);

    const r2 = await runBridgeSync({ sftp, store, now: NOW });
    expect(r2.acksProcessed).toEqual([]);
    expect(r2.duplicates).toEqual([]); // already archived is the normal case there
    expect(store.inbound).toHaveLength(1);
  });
});

describe("bridge sync — a CA that arrives after the results", () => {
  it("upgrades the implied ORU acknowledgement to the real CA without touching the cycle status", async () => {
    const sftp = mailbox();
    const store = new InMemoryBridgeStore();
    const c = store.addCycle({ userId: "u1", status: "results_final", seq: 1, kitLabelCode: "X68800189", placerOrderNumber: "EVA2026T1" });
    c.patch.oml_ack = "ORU";
    const m = store.queueOutbound({ cycleId: c.id, messageControlId: "EVA-TRAIN-20260903-0001", raw: "MSH|x", filename: "X68800189.OML" });
    m.status = "processed"; // closed implicitly when the ORU came
    sftp.files.set(`${BASE}/peticiones/ack/procesados/254889.ACK`, Buffer.from(REAL_ACK, "latin1"));

    await runBridgeSync({ sftp, store, now: NOW });
    expect(c.status).toBe("results_final");
    expect(c.patch.oml_ack).toBe("CA");
  });
});
