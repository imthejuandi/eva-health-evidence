import { type LabProvider } from "./interface";
import { ManualProvider } from "./manual";
import { EchevarneProvider } from "./echevarne";

const providers: Record<string, LabProvider> = {
  manual: ManualProvider,
  echevarne: EchevarneProvider,
};

export function getProvider(name: string): LabProvider {
  const provider = providers[name];
  if (!provider) {
    throw new Error(`Unknown lab provider: ${name}`);
  }
  return provider;
}

export type { LabProvider } from "./interface";
export type { LabProviderResult, BiomarkerResult } from "./types";
