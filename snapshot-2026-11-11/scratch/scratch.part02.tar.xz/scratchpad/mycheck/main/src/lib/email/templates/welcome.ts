export interface WelcomeData {
  firstName: string;
  locale: string;
}

export function renderWelcome(data: WelcomeData, locale: string): string {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
  const dashboardUrl = `${appUrl}/${locale}/dashboard`;

  if (locale === "es") {
    return `
      <h1>Bienvenido a EVA, ${data.firstName}</h1>
      <p>Gracias por unirte a EVA Health. Estas a punto de empezar un camino de salud preventiva basado en datos reales, no en promedios poblacionales.</p>
      <p>Tu suscripcion trimestral incluye:</p>
      <ul style="padding-left: 20px; margin: 16px 0;">
        <li style="margin-bottom: 8px;">15 biomarcadores base con interpretacion de rangos optimos</li>
        <li style="margin-bottom: 8px;">Calculo de Edad Biologica y Longevity Score</li>
        <li style="margin-bottom: 8px;">Asistente de salud EVA AI</li>
        <li style="margin-bottom: 8px;">Integracion con wearables</li>
        <li style="margin-bottom: 8px;">Flexibilidad trimestral: elige tu panel cada ciclo</li>
      </ul>
      <hr class="divider">
      <p>Tu primer paso: reserva tu kit de recogida o sube analisis existentes.</p>
      <a href="${dashboardUrl}" class="cta">Ir a Mi Panel</a>
    `;
  }

  return `
    <h1>Welcome to EVA, ${data.firstName}</h1>
    <p>Thanks for joining EVA Health. You're about to start a preventative health journey based on real data, not population averages.</p>
    <p>Your quarterly subscription includes:</p>
    <ul style="padding-left: 20px; margin: 16px 0;">
      <li style="margin-bottom: 8px;">15 base biomarkers with longevity-optimal range interpretation</li>
      <li style="margin-bottom: 8px;">Biological Age and Longevity Score calculation</li>
      <li style="margin-bottom: 8px;">EVA AI health assistant</li>
      <li style="margin-bottom: 8px;">Wearable integration</li>
      <li style="margin-bottom: 8px;">Quarterly flexibility: choose your panel each cycle</li>
    </ul>
    <hr class="divider">
    <p>Your first step: book your collection kit or upload existing lab results.</p>
    <a href="${dashboardUrl}" class="cta">Go to My Dashboard</a>
  `;
}
