/**
 * Patient + order identifiers as Echevarne wants them: SHORT and purely
 * ALPHANUMERIC (J. Fajardo, 2026-09-07). Both derive from
 * profiles.patient_number (sequential identity column) so they are stable,
 * human-readable on a support call, and never collide.
 *
 *   NHC    (PID-3, type NHC)  EVA000042
 *   Placer (ORC-2.1/OBR-2.1)  EVA000042001   = NHC + 3-digit cycle seq
 *
 * ORC-2.1 is ST-199 and ECH's own examples are ~9 chars, so 12 is fine.
 */

export const ALPHANUMERIC_ID = /^[A-Z0-9]{1,20}$/;

export function nhcFor(patientNumber: number): string {
  if (!Number.isInteger(patientNumber) || patientNumber <= 0) {
    throw new Error(`[identifiers] invalid patient_number: ${patientNumber}`);
  }
  return `EVA${String(patientNumber).padStart(6, "0")}`;
}

export function buildPlacerOrderNumber(patientNumber: number, seq: number): string {
  if (!Number.isInteger(seq) || seq <= 0 || seq > 999) {
    throw new Error(`[identifiers] invalid cycle seq: ${seq}`);
  }
  return `${nhcFor(patientNumber)}${String(seq).padStart(3, "0")}`;
}
