import { GoogleGenAI } from "@google/genai";
import { createClient } from "@/lib/supabase/server";
import { type SupabaseClient } from "@supabase/supabase-js";
import { getPrompt } from "@/lib/ai/prompts";

/**
 * Apply a literacy tier (beginner / familiar / optimizer) to a lab's
 * stored master interpretation. Reads the *_master columns, rephrases
 * them into the chosen tier, and writes the result to the active
 * columns the dashboard, /labs and /biomarker pages already read from.
 *
 * The clinical content of the master is preserved exactly: same
 * findings, same values, same priority order, same urgency, same
 * recommended actions. Only vocabulary, depth and the presence or
 * absence of mechanism / lay-implication wording change.
 *
 * Optimizer tier is a no-op rephrase: the master is copied verbatim
 * into the active columns. No Gemini call. The other two tiers each
 * cost one Gemini call regardless of how many biomarkers or actions
 * exist (everything is rephrased in a single batched JSON request).
 */

type Tier = "beginner" | "familiar" | "optimizer";

interface RephraseInput {
  summary: string;
  summary_es: string;
  interpretations: Array<{
    biomarker_key: string;
    text: string;
    text_es: string;
  }>;
  action_steps: Array<{
    id: string;
    title: string;
    title_es: string;
    description: string;
    description_es: string;
  }>;
}

interface RephraseOutput {
  summary: string;
  summary_es: string;
  interpretations: Array<{
    biomarker_key: string;
    text: string;
    text_es: string;
  }>;
  action_steps: Array<{
    id: string;
    title: string;
    title_es: string;
    description: string;
    description_es: string;
  }>;
}

async function rephraseWithGemini(
  tier: Tier,
  input: RephraseInput,
): Promise<RephraseOutput> {
  const geminiKey = process.env.GEMINI_API_KEY;
  if (!geminiKey) throw new Error("GEMINI_API_KEY not set");
  const genai = new GoogleGenAI({ apiKey: geminiKey });
  const rephrasePrompt = await getPrompt("tier_rephrase");

  const userPrompt = `TARGET TIER: ${tier}

MASTER INTERPRETATION (rephrase preserving every clinical finding, every value, every recommendation):
${JSON.stringify(input, null, 2)}

Return the rephrased JSON. Same shape, same biomarker_keys, same action_step ids, same ordering.`;

  const response = await genai.models.generateContent({
    model: rephrasePrompt.model,
    contents: [{ role: "user", parts: [{ text: userPrompt }] }],
    config: {
      systemInstruction: rephrasePrompt.content,
      ...(rephrasePrompt.temperature != null && { temperature: rephrasePrompt.temperature }),
      ...(rephrasePrompt.maxOutputTokens != null && { maxOutputTokens: rephrasePrompt.maxOutputTokens }),
      ...(rephrasePrompt.thinkingBudget != null && { thinkingConfig: { thinkingBudget: rephrasePrompt.thinkingBudget } }),
      ...(rephrasePrompt.responseMimeType && { responseMimeType: rephrasePrompt.responseMimeType }),
    },
  });

  const responseText = response.text ?? "";
  if (!responseText) throw new Error("Empty response from Gemini rephrase");

  let parsed: RephraseOutput;
  try {
    parsed = JSON.parse(responseText);
  } catch (err) {
    console.error("[apply-tier] Failed to parse rephrase JSON:", responseText.slice(0, 200));
    throw new Error(`Invalid JSON from Gemini rephrase: ${err instanceof Error ? err.message : "unknown"}`);
  }
  if (!parsed.summary || !Array.isArray(parsed.interpretations) || !Array.isArray(parsed.action_steps)) {
    throw new Error("Rephrase response missing required fields");
  }
  return parsed;
}

/**
 * Read the master interpretation for a lab and materialize it into the
 * active columns at the requested tier.
 *
 * Returns true if the active columns were updated. Returns false if
 * the master is missing (caller should generate it first via
 * generateMasterInterpretation, then call applyTier again).
 */
export async function applyTier(
  labResultId: string,
  tier: Tier,
  client?: SupabaseClient,
): Promise<boolean> {
  const supabase = client ?? (await createClient());

  const { data: lab } = await supabase
    .from("lab_results")
    .select("summary_narrative_master, summary_narrative_master_es")
    .eq("id", labResultId)
    .maybeSingle();

  if (!lab?.summary_narrative_master) {
    return false;
  }

  const { data: bvs, error: bvError } = await supabase
    .from("biomarker_values")
    .select("biomarker_key, interpretation_master, interpretation_master_es")
    .eq("lab_result_id", labResultId);
  if (bvError) throw new Error(`Failed to load master biomarker interpretations: ${bvError.message}`);

  const { data: steps, error: stepsError } = await supabase
    .from("action_steps")
    .select("id, title_master, title_master_es, description_master, description_master_es")
    .eq("lab_result_id", labResultId);
  if (stepsError) throw new Error(`Failed to load master action_steps: ${stepsError.message}`);

  // Optimizer tier: copy master verbatim into active columns. No AI call.
  if (tier === "optimizer") {
    await supabase
      .from("lab_results")
      .update({
        summary_narrative: lab.summary_narrative_master,
        summary_narrative_es: lab.summary_narrative_master_es,
      })
      .eq("id", labResultId);

    for (const bv of bvs ?? []) {
      if (!bv.interpretation_master) continue;
      await supabase
        .from("biomarker_values")
        .update({
          interpretation: bv.interpretation_master,
          interpretation_es: bv.interpretation_master_es,
        })
        .eq("lab_result_id", labResultId)
        .eq("biomarker_key", bv.biomarker_key);
    }

    for (const s of steps ?? []) {
      if (!s.title_master) continue;
      await supabase
        .from("action_steps")
        .update({
          title: s.title_master,
          title_es: s.title_master_es,
          description: s.description_master,
          description_es: s.description_master_es,
        })
        .eq("id", s.id);
    }
    return true;
  }

  // Beginner / familiar: send the master content to Gemini for a single
  // batched rephrase, then write the result back to the active columns.
  const input: RephraseInput = {
    summary: lab.summary_narrative_master ?? "",
    summary_es: lab.summary_narrative_master_es ?? "",
    interpretations: (bvs ?? [])
      .filter((b) => b.interpretation_master)
      .map((b) => ({
        biomarker_key: b.biomarker_key,
        text: b.interpretation_master ?? "",
        text_es: b.interpretation_master_es ?? "",
      })),
    action_steps: (steps ?? [])
      .filter((s) => s.title_master)
      .map((s) => ({
        id: s.id,
        title: s.title_master ?? "",
        title_es: s.title_master_es ?? "",
        description: s.description_master ?? "",
        description_es: s.description_master_es ?? "",
      })),
  };

  const rephrased = await rephraseWithGemini(tier, input);

  await supabase
    .from("lab_results")
    .update({
      summary_narrative: rephrased.summary,
      summary_narrative_es: rephrased.summary_es,
    })
    .eq("id", labResultId);

  const interpErrors: string[] = [];
  const interpMissed: string[] = [];
  for (const interp of rephrased.interpretations) {
    // count: "exact" so we can detect the silent-0-rows case below.
    // Supabase doesn't return a Postgres "not found" error when an
    // UPDATE matches no rows, so a hallucinated biomarker_key from
    // Gemini (e.g. "lipoprotein_a" instead of the seed slug
    // "lipoproteina") would otherwise leave the active interpretation
    // column stale with no visible failure.
    const { error, count } = await supabase
      .from("biomarker_values")
      .update(
        {
          interpretation: interp.text,
          interpretation_es: interp.text_es,
        },
        { count: "exact" },
      )
      .eq("lab_result_id", labResultId)
      .eq("biomarker_key", interp.biomarker_key);
    if (error) interpErrors.push(`${interp.biomarker_key}: ${error.message}`);
    else if (count === 0) interpMissed.push(interp.biomarker_key);
  }
  if (interpErrors.length > 0) {
    console.error("[apply-tier] Some rephrased interpretations failed to save:", interpErrors);
  }
  if (interpMissed.length > 0) {
    console.warn(
      "[apply-tier] Rephrase returned biomarker_keys that don't exist on this lab — " +
        "likely Gemini hallucinated a key. The active interpretation column for " +
        "these markers stays at the previous value:",
      interpMissed,
    );
  }

  for (const s of rephrased.action_steps) {
    await supabase
      .from("action_steps")
      .update({
        title: s.title,
        title_es: s.title_es,
        description: s.description,
        description_es: s.description_es,
      })
      .eq("id", s.id);
  }

  return true;
}
