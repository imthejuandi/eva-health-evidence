export interface BookingConfirmedData {
  firstName: string;
  panelName: string;
  scheduledDate: string;
  locale: string;
}

export function renderBookingConfirmed(data: BookingConfirmedData, locale: string): string {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
  const dashboardUrl = `${appUrl}/${locale}/dashboard`;

  if (locale === "es") {
    return `
      <h1>Tu test esta reservado, ${data.firstName}</h1>
      <div style="margin: 20px 0;">
        <span class="stat">${data.panelName}</span>
        <span class="stat">Fecha estimada: ${data.scheduledDate}</span>
      </div>
      <p>Tu kit de recogida llegara a tu domicilio en 3-5 dias habiles.</p>
      <hr class="divider">
      <p style="font-weight: 700; margin-bottom: 8px;">Proximos pasos:</p>
      <ol style="padding-left: 20px;">
        <li style="margin-bottom: 6px;">Recibe el kit en casa</li>
        <li style="margin-bottom: 6px;">Recoge la muestra siguiendo las instrucciones (500µL, sin aguja)</li>
        <li style="margin-bottom: 6px;">Envia la muestra con el sobre prepagado</li>
        <li style="margin-bottom: 6px;">Resultados listos en 5-7 dias habiles</li>
      </ol>
      <a href="${dashboardUrl}" class="cta">Ver Mi Panel</a>
    `;
  }

  return `
    <h1>Your test is booked, ${data.firstName}</h1>
    <div style="margin: 20px 0;">
      <span class="stat">${data.panelName}</span>
      <span class="stat">Estimated date: ${data.scheduledDate}</span>
    </div>
    <p>Your collection kit will arrive at your address in 3-5 business days.</p>
    <hr class="divider">
    <p style="font-weight: 700; margin-bottom: 8px;">Next steps:</p>
    <ol style="padding-left: 20px;">
      <li style="margin-bottom: 6px;">Receive kit at home</li>
      <li style="margin-bottom: 6px;">Collect sample following instructions (500µL, needle-free)</li>
      <li style="margin-bottom: 6px;">Send sample with prepaid envelope</li>
      <li style="margin-bottom: 6px;">Results ready in 5-7 business days</li>
    </ol>
    <a href="${dashboardUrl}" class="cta">View My Dashboard</a>
  `;
}
