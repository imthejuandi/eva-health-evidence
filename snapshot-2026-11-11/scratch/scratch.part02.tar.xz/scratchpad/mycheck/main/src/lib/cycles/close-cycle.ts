/**
 * The last transition of a cycle — results_final → completed — belongs to the
 * results pipeline: it fires when the lab result's interpretation is ready
 * (lab_results.status = 'ready'). Until 2026-09-22 nothing wrote it (audit
 * finding G1): the cycle stayed open forever, the scheduler counted it as
 * open and never created the next one, and /book kept saying "processing".
 *
 * Two entry points, both on the service-role client (the patient's session
 * cannot update test_cycles — RLS grants it SELECT only):
 *   - completeCycleForLabResult: right after a lab_results row turns 'ready'
 *     (context route, 72-hour fallback cron).
 *   - sweepCompletableCycles: idempotent catch-up run by the bridge pass and
 *     the daily scheduler, so a missed call never leaves a cycle open. Also
 *     reports results_final cycles whose lab_result_id is NULL (a deleted
 *     result) — those need a human.
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import { SYSTEM_TRANSITIONS } from "./transitions";

type Row = Record<string, unknown>;

/** Closes the cycle(s) pointing at this lab result. Returns the ids closed (0 for an upload-flow lab). */
export async function completeCycleForLabResult(admin: SupabaseClient, labResultId: string, at: Date = new Date()): Promise<string[]> {
  const { data, error } = await admin
    .from("test_cycles")
    .update({ status: "completed", updated_at: at.toISOString() })
    .eq("lab_result_id", labResultId)
    .in("status", [...SYSTEM_TRANSITIONS.completed])
    .select("id");
  if (error) throw error;
  return ((data ?? []) as Row[]).map((r) => String(r.id));
}

export interface CompletionSweep {
  /** Cycles closed by this sweep. */
  completed: string[];
  /** results_final cycles with no lab result to wait for — need Ops. */
  stuckWithoutResult: string[];
}

export async function sweepCompletableCycles(admin: SupabaseClient, at: Date = new Date()): Promise<CompletionSweep> {
  const { data, error } = await admin
    .from("test_cycles")
    .select("id, lab_results:lab_result_id!inner ( status )")
    .eq("status", "results_final")
    .eq("lab_results.status", "ready");
  if (error) throw error;
  const ids = ((data ?? []) as Row[]).map((r) => String(r.id));

  const completed: string[] = [];
  if (ids.length) {
    const { data: done, error: updateError } = await admin
      .from("test_cycles")
      .update({ status: "completed", updated_at: at.toISOString() })
      .in("id", ids)
      .eq("status", "results_final")
      .select("id");
    if (updateError) throw updateError;
    completed.push(...((done ?? []) as Row[]).map((r) => String(r.id)));
  }

  const { data: stuck, error: stuckError } = await admin
    .from("test_cycles")
    .select("id")
    .eq("status", "results_final")
    .is("lab_result_id", null);
  if (stuckError) throw stuckError;

  return { completed, stuckWithoutResult: ((stuck ?? []) as Row[]).map((r) => String(r.id)) };
}
