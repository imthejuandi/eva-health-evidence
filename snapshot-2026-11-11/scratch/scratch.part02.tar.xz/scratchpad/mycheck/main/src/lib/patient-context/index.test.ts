/**
 * The optional-client contract of the patient-context helpers: a service
 * caller (the 72-hour fallback cron) injects the service-role client and the
 * cookie-bound RLS client is never created — under cron there is no session,
 * so that client would see nothing.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const { createClientMock } = vi.hoisted(() => ({ createClientMock: vi.fn() }));
vi.mock("@/lib/supabase/server", () => ({ createClient: createClientMock }));

import { getCurrentVersion, createNewVersion, emptySnapshot } from "./index";
import { fakeSupabase, ops, argsOf } from "@/lib/testing/fake-supabase";

beforeEach(() => {
  createClientMock.mockReset();
  createClientMock.mockImplementation(async () => {
    throw new Error("RLS client must not be created in a service context");
  });
});

describe("patient-context helpers — optional client threading", () => {
  it("getCurrentVersion uses the injected client and never creates the RLS one", async () => {
    const { client, calls } = fakeSupabase(() => ({ data: { id: "v1", user_id: "u1", version_number: 1 } }));
    const row = await getCurrentVersion("u1", client);
    expect(row).toMatchObject({ id: "v1" });
    expect(createClientMock).not.toHaveBeenCalled();
    expect(calls[0].table).toBe("patient_context_versions");
    expect(argsOf(calls[0], "eq")).toEqual(["user_id", "u1"]);
  });

  it("createNewVersion threads the client into the version lookup and the insert", async () => {
    const { client, calls } = fakeSupabase((c) =>
      ops(c).startsWith("select") ? { data: { id: "v1", user_id: "u1", version_number: 3 } } : { data: { id: "v2", user_id: "u1", version_number: 4 } },
    );
    const row = await createNewVersion("u1", emptySnapshot(), client);
    expect(row).toMatchObject({ id: "v2", version_number: 4 });
    expect(createClientMock).not.toHaveBeenCalled();
    const insert = calls.find((c) => ops(c).startsWith("insert"))!;
    expect(argsOf(insert, "insert")?.[0]).toMatchObject({ user_id: "u1", version_number: 4, is_empty: true });
  });

  it("without a client, user flows still get the RLS server client", async () => {
    const { client } = fakeSupabase(() => ({ data: null }));
    createClientMock.mockResolvedValue(client);
    expect(await getCurrentVersion("u1")).toBeNull();
    expect(createClientMock).toHaveBeenCalledTimes(1);
  });
});
