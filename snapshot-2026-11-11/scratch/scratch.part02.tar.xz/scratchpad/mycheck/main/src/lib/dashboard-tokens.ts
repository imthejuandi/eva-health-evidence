export const ZONE_COLORS: Record<string, string> = {
  optimal: "#3a665e",
  below_optimal: "#c49332",
  above_optimal: "#c49332",
  critical_low: "#b04040",
  critical_high: "#b04040",
};

export const ZONE_TINTS: Record<string, string> = {
  optimal: "rgba(58,102,94,0.10)",
  below_optimal: "rgba(196,147,50,0.12)",
  above_optimal: "rgba(196,147,50,0.12)",
  critical_low: "rgba(176,64,64,0.10)",
  critical_high: "rgba(176,64,64,0.10)",
};

export const ACTION_CATEGORY_COLORS: Record<string, string> = {
  nutrition: "#3a665e",
  supplement: "#3a665e",
  exercise: "#c49332",
  lifestyle: "#c49332",
  medical: "#b04040",
  monitoring: "#8a7f76",
};

export const BIOMARKER_CATEGORY_COLORS: Record<string, string> = {
  nutrition: "#3a665e",
  cardiovascular: "#b04040",
  hormonal: "#c49332",
  inflammatory: "#97472c",
  metabolic: "#3a665e",
  thyroid: "#c49332",
};

export const BRAND = {
  terra: "#97472c",
  terraLight: "#d97b5c",
  terraDeep: "#5a2716",
  jade: "#3a665e",
  jadeLight: "#bcece1",
  gold: "#c49332",
  danger: "#b04040",
  ink: "#1d1b18",
  inkMuted: "#4c463f",
  inkDim: "#8a7f76",
  cream: "#fef8f2",
  creamLow: "#f8f3ed",
  creamHigh: "#e7e2dc",
  white: "#ffffff",
} as const;

export const FONTS = {
  cormorant: "var(--font-cormorant)",
  manrope: "var(--font-manrope)",
  dmMono: "var(--font-dm-mono)",
  logo: "var(--font-logo)",
} as const;

export const FONT_CLASS = {
  cormorant: "font-[family-name:var(--font-cormorant)]",
  manrope: "font-[family-name:var(--font-manrope)]",
  dmMono: "font-[family-name:var(--font-dm-mono)]",
  logo: "font-[family-name:var(--font-logo)]",
} as const;

export function fmt(n: number | null | undefined, max = 2): string {
  if (n == null || !Number.isFinite(n)) return "—";
  if (Number.isInteger(n)) return String(n);
  return parseFloat(n.toFixed(max)).toString();
}

export function zoneColor(zone: string | null | undefined): string {
  if (!zone) return BRAND.inkDim;
  return ZONE_COLORS[zone] ?? BRAND.inkDim;
}

export function zoneTint(zone: string | null | undefined): string {
  if (!zone) return "rgba(138,127,118,0.08)";
  return ZONE_TINTS[zone] ?? "rgba(138,127,118,0.08)";
}
