/**
 * Patient-context helpers.
 *
 * All access goes through the server-side Supabase client so RLS policies
 * on patient_context_versions and patient_context_drafts continue to do
 * their job (users can only ever read/write their own rows).
 *
 * Versioning rule: createNewVersion always inserts a new row. The
 * previous row is left in place so any lab_results that already
 * snapshotted to it keep rendering with the context they were
 * interpreted under.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import type { DurableContextSnapshot, TransientContext } from "./options";
import { emptySnapshot, isSnapshotEmpty } from "./options";

export type {
  DurableContextSnapshot,
  TransientContext,
  MedicationItem,
  SupplementItem,
  ConditionsBlock,
  Lifestyle,
  SexSpecific,
} from "./options";

export interface PatientContextVersionRow {
  id: string;
  user_id: string;
  version_number: number;
  medications: DurableContextSnapshot["medications"];
  supplements: DurableContextSnapshot["supplements"];
  conditions: DurableContextSnapshot["conditions"];
  lifestyle: DurableContextSnapshot["lifestyle"];
  sex_specific: DurableContextSnapshot["sex_specific"];
  is_empty: boolean;
  created_at: string;
}

/**
 * Fetch the most recent patient_context_versions row for a user.
 * Returns null when the user has never filled in their context (the
 * first context save creates version 1).
 *
 * `client` is for service contexts (the 72-hour fallback cron) that act on
 * the user's behalf with no session: the cookie-bound client has no
 * auth.uid() there, so RLS would return nothing and every row would end in
 * 'error' (audit 2026-09-21, F09). User flows pass nothing.
 */
export async function getCurrentVersion(
  userId: string,
  client?: SupabaseClient,
): Promise<PatientContextVersionRow | null> {
  const supabase = client ?? (await createClient());
  const { data, error } = await supabase
    .from("patient_context_versions")
    .select("*")
    .eq("user_id", userId)
    .order("version_number", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) {
    throw new Error(`Failed to load patient context: ${error.message}`);
  }
  return (data as PatientContextVersionRow | null) ?? null;
}

/**
 * Insert a new patient_context_versions row. Always creates — never
 * overwrites — so an edit can't retroactively rewrite the context
 * snapshotted to past lab_results. Returns the inserted row.
 */
export async function createNewVersion(
  userId: string,
  snapshot: DurableContextSnapshot,
  client?: SupabaseClient,
): Promise<PatientContextVersionRow> {
  const supabase = client ?? (await createClient());

  // Compute the next version number with a single round-trip. Two
  // simultaneous writes for the same user would race here; the unique
  // (user_id, version_number) index converts that race into a 23505
  // conflict the caller can retry.
  const current = await getCurrentVersion(userId, client);
  const nextVersion = (current?.version_number ?? 0) + 1;

  const { data, error } = await supabase
    .from("patient_context_versions")
    .insert({
      user_id: userId,
      version_number: nextVersion,
      medications: snapshot.medications,
      supplements: snapshot.supplements,
      conditions: snapshot.conditions,
      lifestyle: snapshot.lifestyle,
      sex_specific: snapshot.sex_specific,
      is_empty: isSnapshotEmpty(snapshot),
    })
    .select("*")
    .single();
  if (error) {
    throw new Error(`Failed to create patient context version: ${error.message}`);
  }
  return data as PatientContextVersionRow;
}

/**
 * Convert a patient_context_versions row to its plain snapshot shape.
 * Used when feeding the AI prompt — the prompt only needs the data,
 * not the version metadata.
 */
export function toSnapshot(row: PatientContextVersionRow): DurableContextSnapshot {
  return {
    medications: row.medications ?? [],
    supplements: row.supplements ?? [],
    conditions: row.conditions ?? { keys: [] },
    lifestyle: row.lifestyle ?? {},
    sex_specific: row.sex_specific ?? {},
  };
}

/**
 * Snapshot a context version + per-draw transient context onto a
 * lab_results row. Called at the moment the user confirms the context
 * gate for that lab. Does NOT change status — the caller (the context
 * POST route) handles the state transition once snapshotting succeeds.
 */
export async function snapshotToLab(
  labResultId: string,
  versionId: string,
  transient: TransientContext,
): Promise<void> {
  const supabase = await createClient();
  const { error } = await supabase
    .from("lab_results")
    .update({
      patient_context_version_id: versionId,
      transient_context: transient,
    })
    .eq("id", labResultId);
  if (error) {
    throw new Error(`Failed to snapshot context to lab: ${error.message}`);
  }
}

// ─── Draft autosave ─────────────────────────────────────────────────

export interface DraftPayload {
  durable: DurableContextSnapshot;
  transient?: TransientContext;
  /** ISO timestamp of the last save — purely informational, the DB row's
   *  updated_at is the authoritative one. */
  updated_at?: string;
}

export async function getDraft(userId: string): Promise<DraftPayload | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("patient_context_drafts")
    .select("draft, updated_at")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) {
    throw new Error(`Failed to load patient context draft: ${error.message}`);
  }
  if (!data) return null;
  return { ...(data.draft as DraftPayload), updated_at: data.updated_at };
}

export async function saveDraft(
  userId: string,
  draft: DraftPayload,
): Promise<void> {
  const supabase = await createClient();
  const { error } = await supabase
    .from("patient_context_drafts")
    .upsert(
      { user_id: userId, draft, updated_at: new Date().toISOString() },
      { onConflict: "user_id" },
    );
  if (error) {
    throw new Error(`Failed to save patient context draft: ${error.message}`);
  }
}

export async function clearDraft(userId: string): Promise<void> {
  const supabase = await createClient();
  const { error } = await supabase
    .from("patient_context_drafts")
    .delete()
    .eq("user_id", userId);
  if (error) {
    throw new Error(`Failed to clear patient context draft: ${error.message}`);
  }
}

// Re-export to keep call sites short.
export { emptySnapshot, isSnapshotEmpty };
