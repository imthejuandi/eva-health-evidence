const COLORS = {
  bg: "#fef8f2",
  surface: "#ffffff",
  terra: "#97472c",
  terraLight: "#d97b5c",
  jade: "#3a665e",
  text: "#1d1b18",
  textMuted: "#4c463f",
  textDim: "#8a7f76",
  border: "#e7e2dc",
};

export function renderBase(body: string, locale: string): string {
  const footer =
    locale === "es"
      ? "EVA Health S.L. · Madrid, España"
      : "EVA Health S.L. · Madrid, Spain";

  return `<!DOCTYPE html>
<html lang="${locale}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;700;800&family=Inter:wght@400;500&display=swap" rel="stylesheet">
  <style>
    body { margin: 0; padding: 0; background-color: ${COLORS.bg}; font-family: 'Inter', -apple-system, sans-serif; }
    .wrapper { max-width: 560px; margin: 0 auto; padding: 40px 20px; }
    .card { background: ${COLORS.surface}; border-radius: 24px; padding: 40px 32px; box-shadow: 0 8px 32px rgba(29,27,24,0.04); }
    .logo { font-family: 'Manrope', sans-serif; font-size: 22px; font-weight: 800; color: ${COLORS.text}; text-decoration: none; }
    .logo span { background: linear-gradient(135deg, ${COLORS.terra}, ${COLORS.terraLight}); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .footer { text-align: center; padding: 24px 0 0; color: ${COLORS.textDim}; font-size: 12px; }
    .footer a { color: ${COLORS.textDim}; }
    h1 { font-family: 'Manrope', sans-serif; font-size: 24px; font-weight: 800; color: ${COLORS.text}; margin: 24px 0 8px; }
    p { color: ${COLORS.textMuted}; font-size: 15px; line-height: 1.6; margin: 0 0 16px; }
    .cta { display: inline-block; background: linear-gradient(135deg, ${COLORS.terra}, ${COLORS.terraLight}); color: #ffffff !important; font-family: 'Manrope', sans-serif; font-weight: 700; font-size: 15px; padding: 14px 32px; border-radius: 100px; text-decoration: none; margin: 8px 0 0; }
    .stat { display: inline-block; background: rgba(58,102,94,0.10); color: ${COLORS.jade}; font-family: 'Manrope', sans-serif; font-weight: 700; font-size: 13px; padding: 6px 14px; border-radius: 100px; margin: 4px 4px 4px 0; }
    .divider { border: none; border-top: 1px solid ${COLORS.border}; margin: 24px 0; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <a href="${process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es"}" class="logo">EVA <span>Health</span></a>
      ${body}
    </div>
    <div class="footer">
      <p>${footer}</p>
    </div>
  </div>
</body>
</html>`;
}
