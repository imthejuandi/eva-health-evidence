/**
 * Minimal HL7 v2.x reader — just enough for ORU^R01 lab-result messages.
 *
 * This is NOT a full HL7 engine: no MLLP transport, no ACK generation, no
 * schema validation, no full escape-sequence unescaping. It turns a raw HL7 v2
 * message (pipe/hat-delimited text) into typed segments and lets callers pull
 * fields/components out of it.
 *
 * Delimiters are READ FROM the MSH segment (per the HL7 spec) and never
 * hardcoded — a sending system is free to choose them.
 *
 * Field-indexing gotcha (HL7 is 1-based): for a normal segment, splitting on
 * the field separator gives fields[0] = segment name, so `getField(seg, n)`
 * returns `fields[n]` (e.g. OBX-5 = fields[5]). MSH is the exception — MSH-1 is
 * itself the field separator — so do NOT use `getField` on MSH; read delimiters
 * via `parseHl7`.
 */

export interface Hl7Delimiters {
  field: string;
  component: string;
  repetition: string;
  escape: string;
  subcomponent: string;
}

export interface Hl7Segment {
  name: string;
  /** Raw, undivided field strings. fields[0] === name for non-MSH segments. */
  fields: string[];
}

export interface Hl7Message {
  delimiters: Hl7Delimiters;
  segments: Hl7Segment[];
}

const FALLBACK: Hl7Delimiters = {
  field: "|",
  component: "^",
  repetition: "~",
  escape: "\\",
  subcomponent: "&",
};

/** Split a raw HL7 v2 message into delimiters + segments. Throws if no MSH. */
export function parseHl7(raw: string): Hl7Message {
  const text = raw.replace(/^﻿/, "").trim();
  const lines = text
    .split(/\r\n|\r|\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0 || !lines[0].startsWith("MSH")) {
    throw new Error("Not an HL7 v2 message: missing MSH segment");
  }
  const msh = lines[0];
  const field = msh.charAt(3) || FALLBACK.field; // char immediately after "MSH"
  const enc = msh.split(field)[1] ?? ""; // MSH-2 encoding characters, e.g. "^~\&"
  const delimiters: Hl7Delimiters = {
    field,
    component: enc.charAt(0) || FALLBACK.component,
    repetition: enc.charAt(1) || FALLBACK.repetition,
    escape: enc.charAt(2) || FALLBACK.escape,
    subcomponent: enc.charAt(3) || FALLBACK.subcomponent,
  };
  const segments: Hl7Segment[] = lines.map((line) => ({
    name: line.substring(0, 3),
    fields: line.split(field),
  }));
  return { delimiters, segments };
}

/** All segments with the given 3-char name (e.g. "OBX"). */
export function segmentsByName(msg: Hl7Message, name: string): Hl7Segment[] {
  return msg.segments.filter((s) => s.name === name);
}

/**
 * 1-based field accessor for the MSH segment ONLY. MSH is special: MSH-1 is
 * the field separator itself, so after splitting on it MSH-n lives at
 * fields[n-1] (e.g. MSH-10 message control id = fields[9]). Using getField()
 * on MSH would be off by one — this is the correct accessor.
 */
export function getMshField(msg: Hl7Message, n: number): string {
  const msh = msg.segments[0];
  if (!msh || msh.name !== "MSH") return "";
  if (n === 1) return msg.delimiters.field;
  return msh.fields[n - 1] ?? "";
}

/** 1-based field accessor for NON-MSH segments (OBX-5 → getField(seg, 5)). */
export function getField(seg: Hl7Segment | undefined, n: number): string {
  return seg?.fields[n] ?? "";
}

/** 1-based component accessor within a field (OBX-3.1 → getComponent(field, 1, d)). */
export function getComponent(field: string, n: number, d: Hl7Delimiters): string {
  return field.split(d.component)[n - 1] ?? "";
}

/**
 * HL7 timestamp (YYYYMMDD[HHMMSS][.S][+/-ZZZZ]) → ISO calendar date (YYYY-MM-DD).
 * Returns "" if it cannot parse a date. We only need the calendar date for
 * `collectionDate`; time-of-day/timezone are dropped intentionally.
 */
export function hl7DateToIso(ts: string): string {
  const m = /^(\d{4})(\d{2})(\d{2})/.exec(ts.trim());
  if (!m) return "";
  return `${m[1]}-${m[2]}-${m[3]}`;
}

/**
 * HL7 timestamp (YYYYMMDD[HHMMSS]) → full ISO datetime (UTC-naive, no zone
 * suffix — Echevarne sends local wall-clock times with no offset). Falls back
 * to midnight when only the date part is present; "" when unparseable.
 * Use hl7DateToIso when only the calendar date matters.
 */
export function hl7DateTimeToIso(ts: string): string {
  const m = /^(\d{4})(\d{2})(\d{2})(?:(\d{2})(\d{2})(\d{2})?)?/.exec(ts.trim());
  if (!m) return "";
  const [, y, mo, d, h = "00", mi = "00", s = "00"] = m;
  return `${y}-${mo}-${d}T${h}:${mi}:${s ?? "00"}`;
}

/**
 * Parse an HL7 numeric value, tolerating a European decimal comma ("5,4" → 5.4)
 * and surrounding whitespace. Returns NaN for non-numeric values (e.g.
 * "Positive", "<0.01") — callers should skip those.
 */
export function parseHl7Number(value: string): number {
  const cleaned = value.trim().replace(/\s+/g, "").replace(",", ".");
  if (!/^[-+]?\d*\.?\d+$/.test(cleaned)) return NaN;
  return Number(cleaned);
}

export interface Hl7NumericValue {
  value: number;
  /** Set when the raw value carried a bound prefix: "<0,500" / ">8,000". */
  comparator?: "<" | ">";
}

/**
 * Parse an HL7 numeric value INCLUDING Echevarne's bounded results
 * ("<0,500", ">8,000" — routine for detection-limit values, spec v2.8
 * examples §1.3.3). Plain parseHl7Number drops those as NaN, which silently
 * discarded real results. Returns null for genuinely non-numeric values.
 */
export function parseHl7Value(raw: string): Hl7NumericValue | null {
  const trimmed = raw.trim();
  const m = /^([<>])\s*(.+)$/.exec(trimmed);
  const comparator = (m?.[1] as "<" | ">" | undefined) ?? undefined;
  const numericPart = m ? m[2] : trimmed;
  const value = parseHl7Number(numericPart);
  if (Number.isNaN(value)) return null;
  return comparator ? { value, comparator } : { value };
}

/**
 * Decode raw HL7 bytes from Echevarne into a string.
 *
 * Real-world finding (training ORU X68800189, 2026-09-07): ECH writes result
 * files in ISO-8859-1 (Latin-1) with MSH-18 EMPTY — the file is NOT valid
 * UTF-8 (0xF3 «ó», 0xB5 «µ»). Reading it as UTF-8 corrupts units such as
 * "/µL", which silently breaks the CBC ÷1000 rescaling. Rule: honour MSH-18
 * when present (UTF-8 / 8859-1 variants), otherwise default to Latin-1.
 * Our own OMLs declare UTF-8 in MSH-18, so the rule is asymmetric on purpose.
 */
/**
 * Undo the HL7 escape sequences a free-text field may carry (\F\ | · \S\ ^ ·
 * \R\ ~ · \T\ & · \E\ \ · \.br\ line break), so a lab observation reads as
 * the lab wrote it. Unknown sequences are left untouched.
 */
export function unescapeHl7Text(s: string): string {
  return s
    .replace(/\\\.br\\/gi, "\n")
    .replace(/\\F\\/g, "|")
    .replace(/\\S\\/g, "^")
    .replace(/\\R\\/g, "~")
    .replace(/\\T\\/g, "&")
    .replace(/\\E\\/g, "\\");
}

export function decodeHl7Bytes(bytes: Uint8Array): string {
  const head = Buffer.from(bytes.subarray(0, 512)).toString("latin1");
  const msh = head.split(/\r|\n/)[0] ?? "";
  const charset = (msh.split("|")[17] ?? "").trim().toUpperCase();
  const utf8 = charset === "UTF-8" || charset === "UTF8" || charset === "UNICODE UTF-8";
  return Buffer.from(bytes).toString(utf8 ? "utf8" : "latin1");
}
