import { describe, it, expect } from "vitest";
import { classifyZone } from "./zone-classifier";
import { calculate } from "./biological-age";
import { calculateAllMetrics } from "./calculated-metrics";
import { matchBiomarkerName } from "./name-matcher";

// ═══════════════════════════════════════════════════════════════════════════════
// Zone Classification
// ═══════════════════════════════════════════════════════════════════════════════

describe("Zone Classifier", () => {
  describe("standard ranges (Vitamin D: optimal 40-60, normal 10-100)", () => {
    it("classifies critical_low (below normal)", () => {
      expect(classifyZone(5, 40, 60, 10, 100)).toBe("critical_low");
    });
    it("classifies below_optimal (below optimal, above normal)", () => {
      expect(classifyZone(28, 40, 60, 10, 100)).toBe("below_optimal");
    });
    it("classifies optimal", () => {
      expect(classifyZone(55, 40, 60, 10, 100)).toBe("optimal");
    });
    it("classifies above_optimal (above optimal, below normal high)", () => {
      expect(classifyZone(85, 40, 60, 10, 100)).toBe("above_optimal");
    });
    it("classifies critical_high (above normal)", () => {
      expect(classifyZone(105, 40, 60, 10, 100)).toBe("critical_high");
    });
  });

  describe("boundary values", () => {
    it("optimal_low boundary is inclusive", () => {
      expect(classifyZone(40, 40, 60, 10, 100)).toBe("optimal");
    });
    it("optimal_high boundary is inclusive", () => {
      expect(classifyZone(60, 40, 60, 10, 100)).toBe("optimal");
    });
    it("normal_low boundary is below_optimal (< is critical, = is below_optimal)", () => {
      expect(classifyZone(10, 40, 60, 10, 100)).toBe("below_optimal");
      expect(classifyZone(9, 40, 60, 10, 100)).toBe("critical_low");
    });
  });

  describe("one-sided ranges", () => {
    // hs-CRP: optimal_low=null, optimal_high=1.0
    it("one-sided lower: value within optimal", () => {
      expect(classifyZone(0.3, null, 1.0, null, 10.0)).toBe("optimal");
    });
    it("one-sided lower: value above optimal", () => {
      expect(classifyZone(3.5, null, 1.0, null, 10.0)).toBe("above_optimal");
    });
    it("one-sided lower: value critical high", () => {
      expect(classifyZone(12, null, 1.0, null, 10.0)).toBe("critical_high");
    });

    // eGFR: optimal_low=90, optimal_high=null
    it("one-sided upper: value within optimal", () => {
      expect(classifyZone(105, 90, null, 60, null)).toBe("optimal");
    });
    it("one-sided upper: value below optimal", () => {
      expect(classifyZone(75, 90, null, 60, null)).toBe("below_optimal");
    });
    it("one-sided upper: value critical low", () => {
      expect(classifyZone(50, 90, null, 60, null)).toBe("critical_low");
    });
  });

  describe("missing reference (all nulls)", () => {
    it("returns optimal when all ranges are null", () => {
      expect(classifyZone(50, null, null, null, null)).toBe("optimal");
    });
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Age Group Matching (tested via biological-age engine internals)
// ═══════════════════════════════════════════════════════════════════════════════

describe("Age Group Matching (via bio-age validation)", () => {
  const minimalPanel = [
    { code: "APOB", value: 80 }, { code: "HBA1C", value: 5.2 },
    { code: "GLUCOSE", value: 85 }, { code: "HSCRP", value: 0.5 },
    { code: "ALT", value: 20 }, { code: "RDW", value: 12 },
    { code: "HGB", value: 15 }, { code: "HDL_C", value: 55 },
    { code: "TG", value: 80 }, { code: "WBC", value: 5500 },
    { code: "CREATININE", value: 0.9 },
  ];

  it("age 17 still calculates (uses 18-29 bracket)", () => {
    const r = calculate(minimalPanel, "male", 17);
    expect(r.validation.valid).toBe(true);
  });

  it("age 25 uses 18-29 bracket", () => {
    const r = calculate(minimalPanel, "male", 25);
    expect(r.validation.valid).toBe(true);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 30 calculates correctly", () => {
    const r = calculate(minimalPanel, "male", 30);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 55 calculates correctly", () => {
    const r = calculate(minimalPanel, "male", 55);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 96 calculates (80+ bracket)", () => {
    const r = calculate(minimalPanel, "male", 96);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 105 calculates (80+ bracket)", () => {
    const r = calculate(minimalPanel, "male", 105);
    expect(r.longevityScore).toBeGreaterThan(0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Biological Age (v4 engine)
// ═══════════════════════════════════════════════════════════════════════════════

describe("Biological Age v4", () => {
  const fullPanel = [
    { code: "APOB", value: 109.7 }, { code: "LDL_C", value: 118 },
    { code: "HBA1C", value: 5.2 }, { code: "GLUCOSE", value: 87 },
    { code: "INSULIN", value: 3.5 }, { code: "HOMA_IR", value: 0.71 },
    { code: "HSCRP", value: 0.59 }, { code: "EGFR", value: 78 },
    { code: "HDL_C", value: 45 }, { code: "TG", value: 67 },
    { code: "LPA", value: 14.7 }, { code: "ALT", value: 59 },
    { code: "RDW", value: 11.9 }, { code: "ALBUMIN", value: 42.7 },
    { code: "VITD", value: 11.6 }, { code: "TESTOSTERONE", value: 5.63 },
    { code: "WBC", value: 7870 }, { code: "LYMPH_PCT", value: 42.4 },
    { code: "FERRITIN", value: 217.56 }, { code: "TSAT", value: 71.88 },
    { code: "TSH", value: 1.23 }, { code: "SHBG", value: 22.6 },
    { code: "URIC_ACID", value: 5.9 }, { code: "GGT", value: 22 },
    { code: "AST", value: 39 }, { code: "HGB", value: 15.1 },
    { code: "MCV", value: 95.6 }, { code: "B12", value: 315 },
    { code: "FOLATE", value: 7.3 }, { code: "CREATININE", value: 1.17 },
    { code: "PLT", value: 299000 }, { code: "MAGNESIUM", value: 2.0 },
    { code: "ZINC", value: 65 }, { code: "FT4", value: 0.84 },
    { code: "FT3", value: 2.45 }, { code: "BILIRUBIN", value: 0.4 },
    { code: "ALP", value: 83 },
  ];

  it("full panel passes validation", () => {
    const r = calculate(fullPanel, "male", 30);
    expect(r.validation.valid).toBe(true);
    expect(r.confidence).not.toBe("insufficient");
  });

  it("produces valid longevity score (1-100)", () => {
    const r = calculate(fullPanel, "male", 30);
    expect(r.longevityScore).toBeGreaterThanOrEqual(1);
    expect(r.longevityScore).toBeLessThanOrEqual(100);
  });

  it("produces valid biological age (18-99)", () => {
    const r = calculate(fullPanel, "male", 30);
    expect(r.biologicalAge).toBeGreaterThanOrEqual(18);
    expect(r.biologicalAge).toBeLessThanOrEqual(99);
  });

  it("suppresses LDL_C when APOB present (redundancy)", () => {
    const r = calculate(fullPanel, "male", 30);
    expect(r.suppressedMarkers.some((s) => s.code === "LDL_C" && s.suppressedBy === "APOB")).toBe(true);
  });

  it("identifies top aging drivers", () => {
    const r = calculate(fullPanel, "male", 30);
    expect(r.topAgingDrivers.length).toBeGreaterThan(0);
    expect(r.topAgingDrivers[0].baYearsImpact).toBeGreaterThan(0);
  });

  it("identifies protective markers", () => {
    const r = calculate(fullPanel, "male", 30);
    expect(r.topProtective.length).toBeGreaterThan(0);
    expect(r.topProtective[0].baYearsImpact).toBeLessThan(0);
  });

  it("returns insufficient for too few markers", () => {
    const r = calculate([{ code: "HBA1C", value: 5.2 }], "male", 30);
    expect(r.validation.valid).toBe(false);
    expect(r.longevityScore).toBe(-1);
    expect(r.biologicalAge).toBe(-1);
  });

  it("returns insufficient when domains are missing", () => {
    // Only metabolic markers — missing cardiovascular, inflammatory, organ_function, hematology
    const r = calculate([
      { code: "HBA1C", value: 5.2 }, { code: "GLUCOSE", value: 87 },
      { code: "INSULIN", value: 3.5 }, { code: "HOMA_IR", value: 0.71 },
      { code: "URIC_ACID", value: 5.0 },
      { code: "B12", value: 500 }, { code: "FOLATE", value: 12 },
      { code: "MAGNESIUM", value: 2.2 }, { code: "ZINC", value: 90 },
    ], "male", 30);
    expect(r.validation.valid).toBe(false);
  });

  it("perfect panel produces high longevity score", () => {
    const perfectPanel = [
      { code: "APOB", value: 60 }, { code: "HBA1C", value: 5.0 },
      { code: "GLUCOSE", value: 82 }, { code: "INSULIN", value: 3.0 },
      { code: "HSCRP", value: 0.3 }, { code: "EGFR", value: 110 },
      { code: "HDL_C", value: 65 }, { code: "TG", value: 60 },
      { code: "ALT", value: 18 }, { code: "RDW", value: 12 },
      { code: "HGB", value: 15.5 }, { code: "WBC", value: 5000 },
      { code: "ALBUMIN", value: 46 }, { code: "VITD", value: 50 },
      { code: "CREATININE", value: 0.9 },
    ];
    const r = calculate(perfectPanel, "male", 30);
    expect(r.longevityScore).toBeGreaterThanOrEqual(85);
    expect(r.biologicalAge).toBeLessThan(30);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Calculated Metrics
// ═══════════════════════════════════════════════════════════════════════════════

describe("Calculated Metrics", () => {
  it("HOMA-IR: (5 * 90) / 405 ≈ 1.11", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "fasting_insulin", value: 5.0 },
      { biomarker_key: "glucose_fasting", value: 90 },
    ], "male");
    const homa = metrics.find((m) => m.metricKey === "homa_ir");
    expect(homa).toBeDefined();
    expect(homa!.value).toBeCloseTo(1.11, 1);
    expect(homa!.zone).toBe("optimal");
  });

  it("TG/HDL: 150/50 = 3.0 → above_optimal (> 3.0 is critical)", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "triglycerides", value: 150 },
      { biomarker_key: "hdl_cholesterol", value: 50 },
    ], "male");
    const ratio = metrics.find((m) => m.metricKey === "tg_hdl_ratio");
    expect(ratio).toBeDefined();
    expect(ratio!.value).toBe(3.0);
    expect(ratio!.zone).toBe("above_optimal");
  });

  it("TG/HDL: 200/50 = 4.0 → critical_high", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "triglycerides", value: 200 },
      { biomarker_key: "hdl_cholesterol", value: 50 },
    ], "male");
    const ratio = metrics.find((m) => m.metricKey === "tg_hdl_ratio");
    expect(ratio!.value).toBe(4.0);
    expect(ratio!.zone).toBe("critical_high");
  });

  it("De Ritis: 35/20 = 1.75 → above_optimal", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "ast", value: 35 },
      { biomarker_key: "alt", value: 20 },
    ], "male");
    const deRitis = metrics.find((m) => m.metricKey === "de_ritis");
    expect(deRitis).toBeDefined();
    expect(deRitis!.value).toBe(1.75);
    expect(deRitis!.zone).toBe("above_optimal");
  });

  it("NLR: 4.5/1.5 = 3.0 → above_optimal", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "neutrophils", value: 4.5 },
      { biomarker_key: "lymphocytes", value: 1.5 },
    ], "male");
    const nlr = metrics.find((m) => m.metricKey === "nlr");
    expect(nlr).toBeDefined();
    expect(nlr!.value).toBe(3.0);
    expect(nlr!.zone).toBe("above_optimal");
  });

  it("Non-HDL: 220 - 50 = 170 → critical_high", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "total_cholesterol", value: 220 },
      { biomarker_key: "hdl_cholesterol", value: 50 },
    ], "male");
    const nonHdl = metrics.find((m) => m.metricKey === "non_hdl");
    expect(nonHdl).toBeDefined();
    expect(nonHdl!.value).toBe(170);
    expect(nonHdl!.zone).toBe("critical_high");
  });

  it("FAI male optimal: (600/40)*100 = 1500 → above_optimal", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "testosterone", value: 600 },
      { biomarker_key: "shbg", value: 40 },
    ], "male");
    const fai = metrics.find((m) => m.metricKey === "fai");
    expect(fai).toBeDefined();
    expect(fai!.zone).toBe("above_optimal");
  });

  it("returns empty for missing biomarkers", () => {
    const metrics = calculateAllMetrics([], "male");
    expect(metrics.length).toBe(0);
  });

  it("skips metrics with missing inputs", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "ast", value: 25 },
      // alt is missing, so De Ritis can't compute
    ], "male");
    expect(metrics.find((m) => m.metricKey === "de_ritis")).toBeUndefined();
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Name Matcher
// ═══════════════════════════════════════════════════════════════════════════════

describe("Name Matcher", () => {
  describe("exact match", () => {
    it("matches canonical key directly", () => {
      const r = matchBiomarkerName("Hemoglobin");
      expect(r.biomarkerKey).toBe("hemoglobin");
      expect(r.confidence).toBe("exact");
    });

    it("matches with different casing", () => {
      const r = matchBiomarkerName("HBA1C");
      expect(r.biomarkerKey).toBe("hba1c");
      expect(r.confidence).toBe("exact");
    });
  });

  describe("alias match", () => {
    it("matches English alias", () => {
      const r = matchBiomarkerName("Vitamin D");
      expect(r.biomarkerKey).toBe("vitamin_d_25_oh");
      expect(r.confidence).toBe("alias");
    });

    it("matches Spanish alias", () => {
      const r = matchBiomarkerName("Glucosa en ayunas");
      expect(r.biomarkerKey).toBe("glucose_fasting");
      expect(r.confidence).toBe("alias");
    });

    it("matches common abbreviation", () => {
      const r = matchBiomarkerName("GPT");
      expect(r.biomarkerKey).toBe("alt");
      expect(r.confidence).toBe("alias");
    });

    it("matches lab variant name", () => {
      const r = matchBiomarkerName("Hemoglobina glicosilada");
      expect(r.biomarkerKey).toBe("hba1c");
      expect(r.confidence).toBe("alias");
    });

    it("matches hs-CRP Spanish", () => {
      const r = matchBiomarkerName("PCR ultrasensible");
      expect(r.biomarkerKey).toBe("hs_crp");
      expect(r.confidence).toBe("alias");
    });

    it("matches ApoB variants", () => {
      expect(matchBiomarkerName("Apo B").biomarkerKey).toBe("apolipoprotein_b_apob");
      expect(matchBiomarkerName("Apolipoproteina B").biomarkerKey).toBe(
        "apolipoprotein_b_apob",
      );
    });
  });

  describe("fuzzy match (Levenshtein ≤ 2)", () => {
    it("matches with 1 char typo", () => {
      const r = matchBiomarkerName("ferritni");
      expect(r.biomarkerKey).toBe("ferritin");
      expect(r.confidence).toBe("fuzzy");
    });

    it("matches with transposition", () => {
      const r = matchBiomarkerName("creatinien");
      expect(r.confidence).toBe("fuzzy");
      expect(r.biomarkerKey).toBe("creatinine");
    });
  });

  describe("no match", () => {
    it("returns null for unrecognizable name", () => {
      const r = matchBiomarkerName("xyzzy foobarbaz");
      expect(r.biomarkerKey).toBeNull();
      expect(r.confidence).toBe("none");
    });

    it("returns null for empty string", () => {
      const r = matchBiomarkerName("");
      expect(r.biomarkerKey).toBeNull();
      expect(r.confidence).toBe("none");
    });
  });

  describe("Spanish accents and CBC-prefix tolerance", () => {
    it("matches accented Spanish name (Neutrófilos → neutrophils)", () => {
      const r = matchBiomarkerName("Neutrófilos");
      expect(r.biomarkerKey).toBe("neutrophils");
      expect(r.confidence).toBe("alias");
    });

    it("strips '%' prefix used for CBC differential lines", () => {
      const r = matchBiomarkerName("% Neutrófilos");
      expect(r.biomarkerKey).toBe("neutrophils");
      expect(r.confidence).toBe("alias");
    });

    it("strips '#' prefix used for absolute CBC counts", () => {
      const r = matchBiomarkerName("# Eosinófilos");
      expect(r.biomarkerKey).toBe("eosinophils");
      expect(r.confidence).toBe("alias");
    });

    it("matches Basófilos with accent", () => {
      const r = matchBiomarkerName("Basófilos");
      expect(r.biomarkerKey).toBe("basophils");
      expect(r.confidence).toBe("alias");
    });
  });

  describe("parenthesis-splitting fallback", () => {
    it("matches when abbreviation is wrapped: 'SHBG (Sex hormone binding globulin)'", () => {
      const r = matchBiomarkerName("SHBG (Sex hormone binding globulin)");
      // SHBG resolves exact on the inner-or-outer split — exact beats alias.
      expect(r.biomarkerKey).toBe("shbg");
      expect(r.confidence).toBe("exact");
    });

    it("matches when full name leads and abbreviation is in parens", () => {
      const r = matchBiomarkerName("Sex Hormone Binding Globulin (SHBG)");
      expect(r.biomarkerKey).toBe("shbg");
      expect(r.confidence).toBe("exact");
    });

    it("matches Spanish AMH wrapped variant", () => {
      const r = matchBiomarkerName("Hormona Antimulleriana (AMH)");
      expect(r.biomarkerKey).toBe("anti_mullerian_hormone_amh");
      // Both the abbreviation and the full name resolve via alias to
      // the seed key — alias is the highest confidence available.
      expect(r.confidence).toBe("alias");
    });
  });

  describe("newly-added aliases", () => {
    it("matches AMH abbreviation", () => {
      const r = matchBiomarkerName("AMH");
      expect(r.biomarkerKey).toBe("anti_mullerian_hormone_amh");
      expect(r.confidence).toBe("alias");
    });

    it("matches Spanish lipasa", () => {
      const r = matchBiomarkerName("Lipasa");
      expect(r.biomarkerKey).toBe("lipase");
      expect(r.confidence).toBe("alias");
    });

    it("matches Spanish amilasa", () => {
      const r = matchBiomarkerName("Amilasa");
      expect(r.biomarkerKey).toBe("amylase");
      expect(r.confidence).toBe("alias");
    });

    it("matches PSA (Spanish full name)", () => {
      const r = matchBiomarkerName("Antigeno prostatico especifico");
      expect(r.biomarkerKey).toBe("psa_total");
      expect(r.confidence).toBe("alias");
    });
  });

  // Every key the matcher emits must be a real biomarker_references
  // slug, otherwise /confirm's allow-list 422s the whole upload.
  describe("emits real seed keys (no key drift)", () => {
    it("Insulina → insulin_fasting (not fasting_insulin)", () => {
      expect(matchBiomarkerName("Insulina").biomarkerKey).toBe("insulin_fasting");
      expect(matchBiomarkerName("Insulina basal").biomarkerKey).toBe(
        "insulin_fasting",
      );
    });

    it("Vitamina D variants → vitamin_d_25_oh", () => {
      expect(matchBiomarkerName("Vitamina D").biomarkerKey).toBe("vitamin_d_25_oh");
      expect(matchBiomarkerName("25-OH Vitamina D").biomarkerKey).toBe(
        "vitamin_d_25_oh",
      );
      expect(matchBiomarkerName("25-Hidroxivitamina D").biomarkerKey).toBe(
        "vitamin_d_25_oh",
      );
    });

    it("Hierro → iron_serum", () => {
      expect(matchBiomarkerName("Hierro").biomarkerKey).toBe("iron_serum");
    });

    it("T4 libre / T3 libre → thyroxine/triiodothyronine seed keys", () => {
      expect(matchBiomarkerName("T4 libre").biomarkerKey).toBe(
        "free_t4_thyroxine",
      );
      expect(matchBiomarkerName("T3 libre").biomarkerKey).toBe(
        "free_t3_triiodothyronine",
      );
    });

    it("Testosterona total / Cortisol → seed keys", () => {
      expect(matchBiomarkerName("Testosterona total").biomarkerKey).toBe(
        "testosterone_total",
      );
      expect(matchBiomarkerName("Cortisol").biomarkerKey).toBe(
        "cortisol_morning_8am",
      );
    });
  });

  // Fuzzy matching used to resolve short clinical abbreviations to
  // unrelated biomarkers (Levenshtein ≤ 2 on 2-3 char strings).
  describe("fuzzy false-positive guards", () => {
    it("'pH' does not match Luteinizing Hormone", () => {
      const r = matchBiomarkerName("pH");
      expect(r.biomarkerKey).toBeNull();
      expect(r.confidence).toBe("none");
    });

    it("'INR' does not fuzzy-match a biomarker", () => {
      expect(matchBiomarkerName("INR").biomarkerKey).toBeNull();
    });

    it("'ADE' resolves to rdw, not hba1c", () => {
      const r = matchBiomarkerName("ADE");
      expect(r.biomarkerKey).toBe("rdw");
    });

    it("'Vitamina B6' does not match B12 (digit guard)", () => {
      const r = matchBiomarkerName("Vitamina B6");
      expect(r.biomarkerKey).not.toBe("vitamin_b12");
    });
  });
});
