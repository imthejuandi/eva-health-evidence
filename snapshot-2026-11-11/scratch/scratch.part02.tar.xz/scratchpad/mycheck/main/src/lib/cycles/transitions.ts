/**
 * Admin-driven cycle transitions (F5 fulfillment flow).
 *
 * Each actor owns its slice of the test_cycles state machine; this module is
 * the ADMIN slice only — the fulfillment desk. Other transitions belong to:
 *   patient   shipped → activated                (/activate, F6)
 *   bridge    activated → order_sent → order_accepted → results_* (F7)
 *   pipeline  results_final → completed          (lab-results ready)
 *   scheduler creates awaiting_fulfillment rows  (F4)
 *
 * Explicit ACTIONS instead of raw target statuses so each carries its
 * required payload and the route can't be driven any→any (the defect the old
 * bookings panel had).
 */

export type AdminCycleAction = "assign_kit" | "ship" | "reopen" | "cancel" | "complete";

/**
 * Transitions driven by the SYSTEM (bridge + lab), documented here so the
 * whole lifecycle is readable in one place. Hybrid timing (ECH, 2026-09-03):
 * the initial OML goes out right after `shipped`, so `order_sent` follows
 * `shipped` directly; `activated` is no longer a step on the main path — the
 * patient's extraction is a timestamp (extraction_confirmed_at) that triggers
 * a re-send of the same order. Results can arrive while still `order_sent`
 * (an ACK may have been missed) — allowed on purpose.
 */
export const SYSTEM_TRANSITIONS: Record<string, readonly string[]> = {
  order_sent: ["shipped", "activated"],
  order_accepted: ["shipped", "activated", "order_sent"],
  error: ["shipped", "activated", "order_sent", "order_accepted"],
  results_partial: ["order_sent", "order_accepted", "results_partial"],
  results_final: ["order_sent", "order_accepted", "results_partial"],
  completed: ["results_final"],
};

export function systemTransitionAllowed(to: string, from: string): boolean {
  return (SYSTEM_TRANSITIONS[to] ?? []).includes(from);
}

interface ActionSpec {
  from: readonly string[];
  to: string;
  /** Payload fields that MUST be present for this action. */
  requires: readonly ("kitLabelCode" | "trackingNumber")[];
}

export const ADMIN_ACTIONS: Record<AdminCycleAction, ActionSpec> = {
  /** Ops scanned the Echevarne sticker onto the kit. */
  assign_kit: {
    from: ["awaiting_fulfillment"],
    to: "kit_assigned",
    requires: ["kitLabelCode"],
  },
  /** DHL label created; tracking pasted (MVP) — kit-shipped email fires here. */
  ship: {
    from: ["kit_assigned"],
    to: "shipped",
    requires: ["trackingNumber"],
  },
  /** Undo/recovery back to the fulfillment queue (wrong scan, error triage). */
  reopen: {
    from: ["kit_assigned", "error"],
    to: "awaiting_fulfillment",
    requires: [],
  },
  /** Terminal cancel — only before the sample is with the lab. */
  cancel: {
    from: ["awaiting_fulfillment", "kit_assigned", "shipped", "error"],
    to: "cancelled",
    requires: [],
  },
  /**
   * Manual close of a cycle whose results are in. The pipeline does this by
   * itself when the interpretation is ready (src/lib/cycles/close-cycle.ts);
   * the desk needs it for the exceptions — a result the patient will never
   * open, or one that was deleted — so the next cycle can be scheduled.
   */
  complete: {
    from: ["results_final"],
    to: "completed",
    requires: [],
  },
};

export function validateAdminAction(
  action: AdminCycleAction,
  currentStatus: string,
  payload: { kitLabelCode?: string | null; trackingNumber?: string | null },
): { ok: true; to: string } | { ok: false; error: string } {
  const spec = ADMIN_ACTIONS[action];
  if (!spec) return { ok: false, error: `Unknown action: ${action}` };
  if (!spec.from.includes(currentStatus)) {
    return {
      ok: false,
      error: `Action '${action}' is not allowed from status '${currentStatus}' (allowed from: ${spec.from.join(", ")})`,
    };
  }
  for (const field of spec.requires) {
    if (!payload[field] || !String(payload[field]).trim()) {
      return { ok: false, error: `Action '${action}' requires ${field}` };
    }
  }
  return { ok: true, to: spec.to };
}
