import { describe, it, expect } from "vitest";
import { fakeSupabase, ops, argsOf } from "@/lib/testing/fake-supabase";
import { completeCycleForLabResult, sweepCompletableCycles } from "./close-cycle";

const AT = new Date("2026-09-22T09:00:00Z");

describe("completeCycleForLabResult — results_final → completed when the interpretation is ready", () => {
  it("closes only the cycle(s) pointing at the lab result and only from results_final", async () => {
    const { client, calls } = fakeSupabase(() => ({ data: [{ id: "c4" }] }));
    expect(await completeCycleForLabResult(client, "lab-1", AT)).toEqual(["c4"]);
    const call = calls[0];
    expect(call.table).toBe("test_cycles");
    expect(ops(call)).toBe("update.eq.in.select");
    expect(argsOf(call, "update")?.[0]).toEqual({ status: "completed", updated_at: AT.toISOString() });
    expect(argsOf(call, "eq")).toEqual(["lab_result_id", "lab-1"]);
    expect(argsOf(call, "in")).toEqual(["status", ["results_final"]]);
  });

  it("an upload-flow lab has no cycle: nothing closed, no error", async () => {
    const { client } = fakeSupabase(() => ({ data: [] }));
    expect(await completeCycleForLabResult(client, "lab-upload", AT)).toEqual([]);
  });

  it("a database error is thrown, not swallowed", async () => {
    const { client } = fakeSupabase(() => ({ error: { code: "08006", message: "connection failure" } }));
    await expect(completeCycleForLabResult(client, "lab-1", AT)).rejects.toMatchObject({ code: "08006" });
  });
});

describe("sweepCompletableCycles — idempotent catch-up", () => {
  it("closes results_final cycles whose result is ready and reports those with no result at all", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "test_cycles" && ops(c).startsWith("select") && argsOf(c, "eq", "lab_results.status")) return { data: [{ id: "c1" }, { id: "c2" }] };
      if (c.table === "test_cycles" && ops(c).startsWith("update")) return { data: [{ id: "c1" }, { id: "c2" }] };
      if (c.table === "test_cycles" && ops(c).startsWith("select") && argsOf(c, "is", "lab_result_id")) return { data: [{ id: "c9" }] };
      throw new Error(`unexpected ${c.table}.${ops(c)}`);
    });
    const r = await sweepCompletableCycles(client, AT);
    expect(r).toEqual({ completed: ["c1", "c2"], stuckWithoutResult: ["c9"] });
    const update = calls.find((c) => ops(c).startsWith("update"))!;
    expect(argsOf(update, "in")).toEqual(["id", ["c1", "c2"]]);
    expect(argsOf(update, "eq")).toEqual(["status", "results_final"]); // never touches a cycle that moved meanwhile
  });

  it("with nothing to close it issues no update", async () => {
    const { client, calls } = fakeSupabase(() => ({ data: [] }));
    expect(await sweepCompletableCycles(client, AT)).toEqual({ completed: [], stuckWithoutResult: [] });
    expect(calls.some((c) => ops(c).startsWith("update"))).toBe(false);
  });
});
