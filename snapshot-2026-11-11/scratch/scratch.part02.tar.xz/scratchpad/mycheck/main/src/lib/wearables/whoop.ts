import type { WearableAdapter, WearableImportResult } from "./interface";

export class WhoopAdapter implements WearableAdapter {
  source = "whoop";
  async parseExport(_fileBuffer: Buffer): Promise<WearableImportResult> {
    throw new Error("Whoop integration coming soon");
  }
}
