/**
 * OML^O21 builder — eva → Echevarne petition messages, per the official spec
 * v2.8 (docs/vendor/echevarne/spec-v2.8-extracted.txt §1.1: structure §1.1.1,
 * segment tables §1.1.2, literal example §1.1.2.8).
 *
 * Message shape: MSH · PID · [PV1] · per test { ORC · OBR · [SPM] · BLG }.
 *
 * Identity/config comes from env — values are assigned by Echevarne and must
 * NEVER be invented (TODO(F0), see .env.example):
 *   ECH_MSH_SENDING_APP       MSH-3  "ID Software CLIENTE" (eva's software id)
 *   ECH_MSH_SENDING_FACILITY  MSH-4  "ID del CLIENTE" (eva's client code in ECH's LIS)
 * Receiving side is fixed by the spec: MSH-5 LABTRAK · MSH-6 ECHEVARNE.
 *
 * Determinism: every timestamp and the message control id are INPUTS — the
 * builder never reads the clock, so tests are exact and callers control ids.
 */

import type { IdDocumentType } from "@/lib/identity/document";
import { buildOrc10 } from "./echevarne-config";

/** Short alphanumeric references only (ECH, 2026-09-07). */
const ALPHANUMERIC_ID = /^[A-Z0-9]{1,20}$/;

/**
 * Prescribing physician → ORC-12 and OBR-16 (`colegiado^APELLIDOS^NOMBRE`).
 * ECH asked (2026-09-07) whether production orders will carry it; a lab
 * order legally needs a prescriber, so eva's medical director signs. All
 * three components are R when the field is present.
 */
export interface OmlPrescriber {
  /** Número de colegiado (ORC-12.1 / OBR-16.1). */
  collegiateNumber: string;
  /** Apellidos (12.2 / 16.2). */
  surnames: string;
  /** Nombre (12.3 / 16.3). */
  givenName: string;
}

export interface OmlPatient {
  /**
   * Identity document → PID-3 first repetition (`number^^^^TYPE`).
   * Type ∈ the spec's PID-3.5 codes (DNI | NIF | CIF | NIE | PASAPORTE |
   * CENSO | OTROS | ID | *_TUTOR). REQUIRED: ECH needs a categorized
   * identifier on every order (J. Fajardo, 2026-08-31). Validated upstream by
   * src/lib/identity/document.ts; the builder only refuses empties.
   */
  document: { type: IdDocumentType; number: string };
  /**
   * eva's own patient reference → PID-3 second repetition (`nhc^^^^NHC`).
   * ECH echoes it back in the ORU, which makes result matching robust even
   * if the document number is later corrected. Any stable short string.
   */
  nhc: string;
  firstName: string;
  /** Primer apellido (PID-5.1). */
  surname1: string;
  /**
   * Segundo apellido (PID-6.1). The spec marks it R, but ECH confirmed
   * (2026-09) it is not mandatory on their side: patients with a single
   * surname go out with it empty rather than with an invented value.
   */
  surname2: string;
  /** yyyyMMdd (PID-7). */
  birthDate: string;
  /** M | F (PID-8, sexo biológico). */
  sex: "M" | "F";
  /** Up to two phone numbers (PID-13, repeated with ~). */
  phones?: string[];
  /** ECH LIS language code (PID-15.1): 8 SPANISH · 9 CATALAN · 10 INGLÉS … */
  languageCode?: string;
}

export interface OmlTest {
  /** Código peticionario de la prueba de ECH (OBR-4.1) — from the F0 catalog. */
  code: string;
  /** Optional description (OBR-4.2). */
  description?: string;
}

export interface OmlOrderInput {
  /** MSH-10 — unique per message; also what ECH's ACK echoes in MSA-2. */
  messageControlId: string;
  /** MSH-7, yyyyMMddHHmmss. */
  messageDateTime: string;
  /** MSH-11: P production · T training. */
  processingId: "P" | "T";
  /** ORC-2.1 / OBR-2.1 — eva's petition number (the matching key). */
  placerOrderNumber: string;
  /** Optional client reference (ORC-2.2). */
  placerReference?: string;
  /** ORC-9, yyyyMMddHHmmss — fecha y hora de la petición. */
  requestDateTime: string;
  /** ORC-15 (REQUIRED) — fecha y hora de la extracción de las muestras. */
  extractionDateTime: string;
  /** ORC-7.6: N normal · U urgente. Default N. */
  priority?: "N" | "U";
  /** ORC-29.1 tipo de petición: I|U|A|C|E|D. Default A (ambulatorio). */
  orderType?: string;
  /**
   * ECH's petition number — the code printed on the sticker ECH sends us
   * (what Ops scans; also the OML/ORU file name). Goes in ORC-3.1 AND
   * OBR-3.1, nothing in ORC-3.3, nothing in SPM-2 (J. Fajardo, 2026-09-07:
   * petition number and sample label are different codes in their LIS).
   * REQUIRED: the initial OML goes out at ship, when the sticker is known.
   */
  labPetitionNumber: string;
  /** Prescribing physician (ORC-12 / OBR-16). Optional in training; production orders should carry it. */
  prescriber?: OmlPrescriber;
  patient: OmlPatient;
  tests: OmlTest[];
}

/** HL7 escape for field content (spec delimiters |^~\& → \F\ \S\ \R\ \E\ \T\). */
export function hl7Escape(value: string): string {
  return value
    .replace(/\\/g, "\\E\\")
    .replace(/\|/g, "\\F\\")
    .replace(/\^/g, "\\S\\")
    .replace(/~/g, "\\R\\")
    .replace(/&/g, "\\T\\")
    .replace(/\r\n|\r|\n/g, "\\.br\\");
}

function envOrThrow(name: string): string {
  const v = process.env[name];
  if (!v) {
    throw new Error(
      `[oml-builder] ${name} is not set. These identifiers are assigned by Echevarne (F0) — refusing to invent them.`,
    );
  }
  return v;
}

/**
 * Build a complete OML^O21 message (segments joined with \r, no trailing
 * newline). Throws when required identity env vars or required fields are
 * missing — an incomplete petition must never reach the lab.
 */
export function buildOml(input: OmlOrderInput): string {
  if (!input.tests.length) throw new Error("[oml-builder] At least one test is required");
  if (!input.extractionDateTime) throw new Error("[oml-builder] extractionDateTime (ORC-15) is required");

  const sendingApp = envOrThrow("ECH_MSH_SENDING_APP");
  const sendingFacility = envOrThrow("ECH_MSH_SENDING_FACILITY");
  const e = hl7Escape;
  const p = input.patient;

  const msh = [
    "MSH",
    "^~\\&",
    e(sendingApp),
    e(sendingFacility),
    "LABTRAK",
    "ECHEVARNE",
    input.messageDateTime,
    "",
    "OML^O21",
    e(input.messageControlId),
    input.processingId,
    "2.5",
    "",
    "",
    "AL",
    "",
    "",
    "UTF-8",
  ].join("|");

  if (!p.document?.type || !p.document?.number) {
    throw new Error("[oml-builder] patient.document (PID-3.1 + PID-3.5) is required — ECH rejects orders without a categorized identifier");
  }
  if (!p.nhc) throw new Error("[oml-builder] patient.nhc (PID-3, type NHC) is required");

  const pid = [
    "PID",
    "1",
    "",
    // Two repetitions, per ECH's example: document first, then eva's NHC.
    `${e(p.document.number)}^^^^${e(p.document.type)}~${e(p.nhc)}^^^^NHC`,
    "",
    `${e(p.surname1)}^${e(p.firstName)}`,
    e(p.surname2),
    p.birthDate,
    p.sex,
    "",
    "",
    "",
    "",
    (p.phones ?? []).slice(0, 2).map(e).join("~"),
    "",
    p.languageCode ?? "8",
  ].join("|");

  const pv1 = ["PV1", "1", "O"].join("|");

  const segments: string[] = [msh, pid, pv1];

  if (!ALPHANUMERIC_ID.test(input.placerOrderNumber)) {
    throw new Error(`[oml-builder] placerOrderNumber must be short alphanumeric (ECH), got '${input.placerOrderNumber}'`);
  }
  if (!ALPHANUMERIC_ID.test(p.nhc)) {
    throw new Error(`[oml-builder] patient.nhc must be short alphanumeric (ECH), got '${p.nhc}'`);
  }
  if (!input.labPetitionNumber || !ALPHANUMERIC_ID.test(input.labPetitionNumber)) {
    throw new Error("[oml-builder] labPetitionNumber (ECH petition number from the sticker) is required — ORC-3.1/OBR-3.1");
  }
  if (input.prescriber) {
    const { collegiateNumber, surnames, givenName } = input.prescriber;
    if (!collegiateNumber || !surnames || !givenName) {
      throw new Error("[oml-builder] prescriber needs collegiateNumber, surnames and givenName (ORC-12 / OBR-16)");
    }
  }

  const placer = input.placerReference
    ? `${e(input.placerOrderNumber)}^${e(input.placerReference)}`
    : e(input.placerOrderNumber);
  // ORC-3.1 / OBR-3.1 = ECH petition number (the sticker). Component 1 only.
  const filler = e(input.labPetitionNumber);
  // ORC-10 = eva's fixed sender codes inside ECH's LIS (echevarne-config.ts).
  const orc10 = buildOrc10();
  const prescriber = input.prescriber
    ? `${e(input.prescriber.collegiateNumber)}^${e(input.prescriber.surnames)}^${e(input.prescriber.givenName)}`
    : "";
  const priority = input.priority ?? "N";
  const orderType = input.orderType ?? "A";

  input.tests.forEach((test, i) => {
    const orc = [
      "ORC",
      "NW",
      placer,
      filler,
      "",
      "SC",
      "",
      `^^^^^${priority}`,
      "",
      input.requestDateTime,
      orc10,
      "",
      prescriber,
      "",
      "",
      input.extractionDateTime,
      ...Array(13).fill(""),
      orderType,
    ].join("|");

    const obr = [
      "OBR",
      String(i + 1),
      e(input.placerOrderNumber),
      filler,
      test.description ? `${e(test.code)}^${e(test.description)}^^` : `${e(test.code)}^^^`,
      "",
      input.requestDateTime,
      ...(prescriber ? [...Array(9).fill(""), prescriber] : []),
    ].join("|");

    // SPM-2 empty by ECH's instruction; SPM-17 = extraction date/time.
    // Date lands at split-index 18, exactly where ECH's and the spec's examples put it.
    const spm = ["SPM", "1", ...Array(16).fill(""), input.extractionDateTime].join("|");

    const blg = "BLG|||";

    segments.push(orc, obr, spm, blg);
  });

  return segments.join("\r");
}
