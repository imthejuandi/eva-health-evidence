/**
 * Echevarne-assigned, FIXED identifiers for eva as a sender.
 *
 * Source: J. Fajardo, email 2026-09-07 («He añadido en azul nuestros códigos
 * que os identifican como remitente. Son fijos y sería necesario añadirlos al
 * ORC para que no los tengan que entrar los usuarios de forma manual»). They
 * ride ORC-10 (Entered By, XCN) at the spec-defined components:
 *
 *   10.9.1   Código Compañía/Mútua en LIS ECH        → companyCode
 *   10.14.1  Código Remitente de la petición en LIS  → senderCode
 *   10.22.1  Código Cargo de la petición en LIS ECH  → chargeCode
 *   10.23.1  Código Delegación de la petición en LIS → delegationCode
 *
 * Not secrets (they are routing codes inside ECH's LIS), so they live in
 * code with their provenance. If ECH ever changes them, this is the only
 * place to edit. Anti-invention rule: never guess these — they come from ECH.
 */
export interface EchSenderCodes {
  companyCode: string;
  senderCode: string;
  chargeCode: string;
  delegationCode: string;
}

export const ECH_SENDER_CODES: EchSenderCodes = {
  companyCode: "23502",
  senderCode: "23502",
  chargeCode: "23502",
  delegationCode: "01",
};

/** ORC-10 exactly as ECH wrote it: components 9, 14, 22 and 23 populated. */
export function buildOrc10(codes: EchSenderCodes = ECH_SENDER_CODES): string {
  const c: string[] = Array(23).fill("");
  c[8] = codes.companyCode; // 10.9
  c[13] = codes.senderCode; // 10.14
  c[21] = codes.chargeCode; // 10.22
  c[22] = codes.delegationCode; // 10.23
  return c.join("^");
}
