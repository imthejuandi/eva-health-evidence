/** The texts of a lab result's stored observations (`lab_results.lab_notes`, [{code, text}]). */
export function labNoteTexts(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((n) => (n && typeof n === "object" && typeof (n as { text?: unknown }).text === "string" ? (n as { text: string }).text.trim() : ""))
    .filter(Boolean);
}
