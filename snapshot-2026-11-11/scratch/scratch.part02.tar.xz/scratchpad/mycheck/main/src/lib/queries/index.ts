import { createClient } from "@/lib/supabase/server";
import { type SupabaseClient } from "@supabase/supabase-js";
import type {
  Profile,
  LabResult,
  BiomarkerValue,
  WearableData,
  ActionStep,
  BookedTest,
} from "./types";

export type { Profile, LabResult, BiomarkerValue, WearableData, ActionStep, BookedTest };

export async function getUserProfile(userId: string, client?: SupabaseClient): Promise<Profile | null> {
  const supabase = client ?? (await createClient());
  const { data } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .single();
  return data as Profile | null;
}

export async function getLatestLabResult(userId: string): Promise<LabResult | null> {
  const supabase = await createClient();
  // Only show completed ("ready") results — avoids a stale error/processing
  // record shadowing a successful one in the dashboard header.
  const { data } = await supabase
    .from("lab_results")
    .select("*")
    .eq("user_id", userId)
    .eq("status", "ready")
    .order("collection_date", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return data as LabResult | null;
}

export async function getBiomarkerValues(labResultId: string, client?: SupabaseClient): Promise<BiomarkerValue[]> {
  const supabase = client ?? (await createClient());
  const { data } = await supabase
    .from("biomarker_values")
    .select("*")
    .eq("lab_result_id", labResultId)
    .order("category", { ascending: true });
  const rows = (data as BiomarkerValue[]) ?? [];

  // Backfill missing categories from biomarker_references at query time.
  // For older rows (and any future rows where the reference lookup
  // failed during processing) `category` is "" or "uncategorized" — we
  // hydrate those by joining on biomarker_key against the panel_category
  // column. Avoids a SQL migration and keeps the dashboard's by-category
  // grouping populated regardless of when the lab was processed.
  const needsCategory = rows.filter(
    (r) => !r.category || r.category === "uncategorized",
  );
  if (needsCategory.length === 0) return rows;

  const keys = Array.from(new Set(needsCategory.map((r) => r.biomarker_key)));
  const { data: refs } = await supabase
    .from("biomarker_references")
    .select("biomarker_key, panel_category")
    .in("biomarker_key", keys);

  if (!refs || refs.length === 0) return rows;

  const categoryByKey = new Map<string, string>();
  for (const r of refs as Array<{ biomarker_key: string; panel_category: string | null }>) {
    if (r.panel_category && !categoryByKey.has(r.biomarker_key)) {
      categoryByKey.set(r.biomarker_key, r.panel_category);
    }
  }

  return rows.map((r) => {
    if (r.category && r.category !== "uncategorized") return r;
    const fallback = categoryByKey.get(r.biomarker_key);
    return fallback ? { ...r, category: fallback } : r;
  });
}

export async function getAllBiomarkerValuesForUser(userId: string): Promise<BiomarkerValue[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("biomarker_values")
    .select("*, lab_results!inner(user_id)")
    .eq("lab_results.user_id", userId)
    .order("created_at", { ascending: true });
  return (data as BiomarkerValue[]) ?? [];
}

export async function getWearableData(
  userId: string,
  days: number = 7,
  client?: SupabaseClient,
): Promise<WearableData[]> {
  const since = new Date();
  since.setDate(since.getDate() - days);

  const supabase = client ?? (await createClient());
  const { data } = await supabase
    .from("wearable_data")
    .select("*")
    .eq("user_id", userId)
    .gte("date", since.toISOString().split("T")[0])
    .order("date", { ascending: true });
  return (data as WearableData[]) ?? [];
}

export async function getActionSteps(userId: string): Promise<ActionStep[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("action_steps")
    .select("*")
    .eq("user_id", userId)
    .in("status", ["pending", "in_progress"])
    .order("priority", { ascending: true });
  return (data as ActionStep[]) ?? [];
}

/**
 * Patient-facing status mapping for the F5 cycle state machine: cycles carry
 * more granular operational states than the 5-step patient timeline needs, so
 * each cycle status collapses onto the closest patient-visible step.
 * (`error` deliberately reads as "processing" — operational incidents are
 * Ops' problem, not an alarm on the patient's dashboard.)
 */
const CYCLE_TO_BOOKING_STATUS: Record<string, BookedTest["status"]> = {
  awaiting_fulfillment: "scheduled",
  kit_assigned: "scheduled",
  shipped: "kit_sent",
  activated: "sample_received",
  order_sent: "sample_received",
  order_accepted: "sample_received",
  results_partial: "processing",
  results_final: "processing",
  error: "processing",
  completed: "completed",
  cancelled: "cancelled",
};

/** The joined lab_results row of a cycle (object or one-element array, depending on the relation shape). */
function labStatusOf(rel: unknown): string | null {
  const row = Array.isArray(rel) ? rel[0] : rel;
  const status = (row as { status?: unknown } | null | undefined)?.status;
  return typeof status === "string" ? status : null;
}

/**
 * Hybrid OML timing (ECH, 2026-09-03): the order is sent right after Ship,
 * so order_sent / order_accepted still mean "kit on its way" to the patient
 * until they register the extraction.
 */
function bookingStatusForCycle(status: string, extractionConfirmedAt: string | null, labResultStatus: string | null = null): BookedTest["status"] {
  if ((status === "order_sent" || status === "order_accepted") && !extractionConfirmedAt) return "kit_sent";
  // The pipeline closes the cycle when the interpretation is ready; until
  // that write lands (or if it was missed), a ready result is still "done".
  if (status === "results_final" && labResultStatus === "ready") return "completed";
  return CYCLE_TO_BOOKING_STATUS[status] ?? "processing";
}

export async function getBookedTests(userId: string): Promise<BookedTest[]> {
  const supabase = await createClient();
  const [{ data: legacy }, { data: cycles }] = await Promise.all([
    supabase
      .from("booked_tests")
      .select("*")
      .eq("user_id", userId)
      .neq("status", "cancelled")
      .order("scheduled_date", { ascending: true }),
    // New system of record (F4/F5). RLS: user reads own cycles only.
    supabase
      .from("test_cycles")
      .select("id, user_id, panel_type, status, due_date, dhl_tracking_out, extraction_confirmed_at, created_at, lab_results:lab_result_id ( status )")
      .eq("user_id", userId)
      .neq("status", "cancelled")
      .order("due_date", { ascending: true }),
  ]);

  // Cycles render through the same BookedTest shape so KitTimeline and the
  // /book dispatch section work unchanged, now with tracking attached.
  const virtual: BookedTest[] = (cycles ?? []).map((c) => ({
    id: c.id,
    user_id: c.user_id,
    panel_type: c.panel_type,
    status: bookingStatusForCycle(c.status, c.extraction_confirmed_at ?? null, labStatusOf(c.lab_results)),
    scheduled_date: c.due_date,
    created_at: c.created_at,
    dhl_tracking_out: c.dhl_tracking_out ?? null,
    cycle_id: c.id,
    extraction_confirmed_at: c.extraction_confirmed_at ?? null,
  }));

  return [...virtual, ...((legacy as BookedTest[]) ?? [])];
}
