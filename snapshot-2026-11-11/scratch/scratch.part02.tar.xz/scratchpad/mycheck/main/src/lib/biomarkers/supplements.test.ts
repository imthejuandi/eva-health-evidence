/**
 * Unit tests for supplements.ts — supplement dose parsing + biomarker offsets.
 */
import { describe, it, expect } from "vitest";
import {
  parseSupplementDose,
  resolveSupplementDose,
  creatineCreatinineOffsetMgDL,
  creatinineOffsetFromSupplements,
} from "./supplements";

describe("parseSupplementDose", () => {
  it("parses compact unit (10g)", () => {
    expect(parseSupplementDose("10g")).toEqual({ value: 10, unit: "g" });
  });

  it("parses spaced unit (10 g)", () => {
    expect(parseSupplementDose("10 g")).toEqual({ value: 10, unit: "g" });
  });

  it("parses long unit (10grams)", () => {
    expect(parseSupplementDose("10grams")).toEqual({ value: 10, unit: "g" });
  });

  it("returns null-unit when only a number is given", () => {
    expect(parseSupplementDose("5000")).toEqual({ value: 5000, unit: null });
  });

  it("parses micrograms variants", () => {
    expect(parseSupplementDose("1000 mcg")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("1000 ug")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("1000 µg")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("1000micrograms")).toEqual({ value: 1000, unit: "mcg" });
  });

  it("strips trailing /day suffix", () => {
    expect(parseSupplementDose("1000mcg/day")).toEqual({ value: 1000, unit: "mcg" });
  });

  it("handles decimals", () => {
    expect(parseSupplementDose("2.5 g")).toEqual({ value: 2.5, unit: "g" });
  });

  it("handles surrounding whitespace", () => {
    expect(parseSupplementDose("  2.5 g  ")).toEqual({ value: 2.5, unit: "g" });
  });

  it("normalizes mg variants", () => {
    expect(parseSupplementDose("400 milligrams")).toEqual({ value: 400, unit: "mg" });
    expect(parseSupplementDose("400mg")).toEqual({ value: 400, unit: "mg" });
  });

  it("normalizes IU variants", () => {
    expect(parseSupplementDose("5000 units")).toEqual({ value: 5000, unit: "iu" });
    expect(parseSupplementDose("5000IU")).toEqual({ value: 5000, unit: "iu" });
  });

  it("returns null when no numeric content", () => {
    expect(parseSupplementDose("daily")).toBeNull();
    expect(parseSupplementDose("")).toBeNull();
    expect(parseSupplementDose(null)).toBeNull();
    expect(parseSupplementDose(undefined)).toBeNull();
  });
});

describe("resolveSupplementDose", () => {
  it("uses parsed unit when present", () => {
    expect(resolveSupplementDose("creatine", "10g")).toEqual({ value: 10, unit: "g" });
  });

  it("applies default unit when none specified", () => {
    expect(resolveSupplementDose("creatine", "5")).toEqual({ value: 5, unit: "g" });
    expect(resolveSupplementDose("vitamin_d", "5000")).toEqual({ value: 5000, unit: "iu" });
    expect(resolveSupplementDose("b12", "1000")).toEqual({ value: 1000, unit: "mcg" });
  });

  it("returns null when dose can't be parsed", () => {
    expect(resolveSupplementDose("creatine", "daily")).toBeNull();
    expect(resolveSupplementDose("creatine", null)).toBeNull();
  });

  it("leaves unit null when supplement has no default", () => {
    expect(resolveSupplementDose("rare_unknown_supplement", "10")).toEqual({
      value: 10,
      unit: null,
    });
  });
});

describe("creatineCreatinineOffsetMgDL", () => {
  it("returns 0 for no supplementation", () => {
    expect(creatineCreatinineOffsetMgDL(0)).toBe(0);
    expect(creatineCreatinineOffsetMgDL(null)).toBe(0);
    expect(creatineCreatinineOffsetMgDL(undefined)).toBe(0);
    expect(creatineCreatinineOffsetMgDL(-5)).toBe(0);
  });

  it("applies linear formula for typical doses", () => {
    expect(creatineCreatinineOffsetMgDL(3)).toBeCloseTo(0.125, 5);
    expect(creatineCreatinineOffsetMgDL(5)).toBeCloseTo(0.175, 5);
    expect(creatineCreatinineOffsetMgDL(10)).toBeCloseTo(0.30, 5);
  });

  it("caps at 0.40 mg/dL for sustained high doses", () => {
    expect(creatineCreatinineOffsetMgDL(15)).toBeCloseTo(0.40, 5);
    expect(creatineCreatinineOffsetMgDL(20)).toBeCloseTo(0.40, 5);
    expect(creatineCreatinineOffsetMgDL(50)).toBeCloseTo(0.40, 5);
  });

  it("handles non-finite input gracefully", () => {
    expect(creatineCreatinineOffsetMgDL(NaN)).toBe(0);
    expect(creatineCreatinineOffsetMgDL(Infinity)).toBe(0);
  });
});

describe("creatinineOffsetFromSupplements", () => {
  it("returns 0 when supplements is null/empty", () => {
    expect(creatinineOffsetFromSupplements(null)).toBe(0);
    expect(creatinineOffsetFromSupplements(undefined)).toBe(0);
    expect(creatinineOffsetFromSupplements([])).toBe(0);
  });

  it("returns offset when creatine is in the list with grams dose", () => {
    expect(
      creatinineOffsetFromSupplements([{ key: "creatine", dose: "10g" }]),
    ).toBeCloseTo(0.30, 5);
  });

  it("uses default unit (grams) when no unit given for creatine", () => {
    expect(
      creatinineOffsetFromSupplements([{ key: "creatine", dose: "5" }]),
    ).toBeCloseTo(0.175, 5);
  });

  it("returns 0 when creatine not in the list", () => {
    expect(
      creatinineOffsetFromSupplements([
        { key: "b12", dose: "1000" },
        { key: "vitamin_d", dose: "5000" },
      ]),
    ).toBe(0);
  });

  it("returns 0 when creatine entered with wrong unit (e.g., mg)", () => {
    // Creatine sold by gram; if user enters "500mg" assume it's a mis-entry
    expect(
      creatinineOffsetFromSupplements([{ key: "creatine", dose: "500mg" }]),
    ).toBe(0);
  });

  it("handles the production case (10g/day)", () => {
    // User 7e397cf0's supplements from patient_context_versions
    const supplements = [
      { key: "b12", dose: "1000" },
      { key: "creatine", dose: "10g" },
      { key: "vitamin_d", dose: "5000" },
    ];
    expect(creatinineOffsetFromSupplements(supplements)).toBeCloseTo(0.30, 5);
  });
});
