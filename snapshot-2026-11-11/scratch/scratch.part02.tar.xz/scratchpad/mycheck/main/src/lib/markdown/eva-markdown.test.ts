import { describe, it, expect } from "vitest";
import { escapeHtml, renderInlineMarkdown, paragraphsHTML } from "./eva-markdown";

describe("escapeHtml", () => {
  it("escapes the five HTML-significant characters", () => {
    expect(escapeHtml(`<script>alert("x") & 'y'</script>`)).toBe(
      "&lt;script&gt;alert(&quot;x&quot;) &amp; &#39;y&#39;&lt;/script&gt;",
    );
  });

  it("does not double-escape ampersands", () => {
    expect(escapeHtml("A & B & C")).toBe("A &amp; B &amp; C");
  });
});

describe("renderInlineMarkdown", () => {
  it("renders bold and italic emphasis", () => {
    expect(renderInlineMarkdown("**bold** and *em*")).toBe(
      "<strong>bold</strong> and <em>em</em>",
    );
  });

  it("neutralises HTML smuggled inside emphasis markers", () => {
    expect(renderInlineMarkdown("**<b>x</b>**")).toBe(
      "<strong>&lt;b&gt;x&lt;/b&gt;</strong>",
    );
  });
});

describe("paragraphsHTML — XSS hardening", () => {
  it("escapes a <script> tag from model output", () => {
    const html = paragraphsHTML("<script>alert(1)</script>");
    expect(html).not.toContain("<script>");
    expect(html).toBe("<p>&lt;script&gt;alert(1)&lt;/script&gt;</p>");
  });

  it("escapes an <img onerror> payload", () => {
    const html = paragraphsHTML(`<img src=x onerror="alert(1)">`);
    expect(html).not.toMatch(/<img/i);
    expect(html).toContain("&lt;img");
  });
});

describe("paragraphsHTML — formatting preserved", () => {
  it("keeps bold inside a paragraph", () => {
    expect(paragraphsHTML("**Result:** high")).toBe(
      "<p><strong>Result:</strong> high</p>",
    );
  });

  it("renders bullet lists", () => {
    expect(paragraphsHTML("- one\n- two")).toBe(
      "<ul><li>one</li><li>two</li></ul>",
    );
  });

  it("converts single newlines within a paragraph to <br/>", () => {
    expect(paragraphsHTML("line one\nline two")).toBe(
      "<p>line one<br/>line two</p>",
    );
  });
});
