/**
 * profiles row → OmlPatient (PID segment), plus a readiness check the
 * fulfillment desk uses BEFORE shipping: the initial OML goes out at Ship,
 * so every PID field the spec marks R must exist by then.
 *
 * Spec (v2.8 §1.1.2.2): PID-3 document + type (R), PID-5 surname1^name (R),
 * PID-6 surname2 (R), PID-7 birth date (R), PID-8 sex M|F (R), PID-13 phones
 * (O, ≤2), PID-15 language (8 SPANISH · 9 CATALAN · 10 INGLÉS).
 *
 * Surnames: `last_name` is the primer apellido and `second_surname` the
 * segundo apellido, captured as separate fields on the profile page (a single
 * field split on whitespace mis-handled compound surnames). Rows created
 * before 2026-09-09 have no `second_surname`, so we fall back to splitting
 * `last_name` — legacy behaviour, replaced as soon as the user edits.
 *
 * Single-surname patients: ECH confirmed (2026-09) that PID-6 is NOT
 * mandatory on their side, so a patient with one surname ships with the field
 * empty. We never invent a second surname — repeating the first one would put
 * a false name in the lab's patient record.
 */
import type { OmlPatient } from "@/lib/lab-provider/oml-builder";
import { isIdDocumentType } from "@/lib/identity/document";
import { nhcFor } from "@/lib/cycles/identifiers";

export interface PatientProfileSlice {
  id: string;
  patient_number: number | null;
  first_name: string | null;
  /** Primer apellido. */
  last_name: string | null;
  /** Segundo apellido — explicit column; null on pre-2026-09-09 rows. */
  second_surname?: string | null;
  full_name: string | null;
  /** YYYY-MM-DD (HTML date input) — also tolerates DD/MM/YYYY. */
  date_of_birth: string | null;
  sex: string | null;
  phone: string | null;
  locale: string | null;
  id_document_type: string | null;
  id_document_number: string | null;
}

export type PatientMissingField =
  | "patient_number"
  | "first_name"
  | "last_name"
  | "date_of_birth"
  | "sex"
  | "id_document";

const LANGUAGE_BY_LOCALE: Record<string, string> = { es: "8", ca: "9", en: "10" };

export function hl7Date(dob: string): string | null {
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(dob.trim());
  if (iso) return `${iso[1]}${iso[2]}${iso[3]}`;
  const eu = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(dob.trim());
  if (eu) return `${eu[3]}${eu[2]}${eu[1]}`;
  return null;
}

function splitNames(p: PatientProfileSlice): { firstName: string; surname1: string; surname2: string } {
  const first = (p.first_name ?? p.full_name?.split(/\s+/)[0] ?? "").trim();
  const last = (p.last_name ?? "").trim();
  const second = (p.second_surname ?? "").trim();
  // Explicit fields win: a compound primer apellido ("García de la Torre")
  // stays intact. Only legacy rows without second_surname are split.
  if (second) return { firstName: first, surname1: last, surname2: second };
  const tokens = last.split(/\s+/).filter(Boolean);
  return { firstName: first, surname1: tokens[0] ?? "", surname2: tokens.slice(1).join(" ") };
}

export function patientReadiness(p: PatientProfileSlice): { ready: boolean; missing: PatientMissingField[] } {
  const missing: PatientMissingField[] = [];
  if (!p.patient_number || p.patient_number <= 0) missing.push("patient_number");
  const names = splitNames(p);
  if (!names.firstName) missing.push("first_name");
  if (!names.surname1) missing.push("last_name");
  // No check on surname2: ECH does not require PID-6, and foreign patients
  // frequently have a single surname.
  if (!p.date_of_birth || !hl7Date(p.date_of_birth)) missing.push("date_of_birth");
  if (p.sex !== "male" && p.sex !== "female") missing.push("sex");
  if (!isIdDocumentType(p.id_document_type) || !p.id_document_number) missing.push("id_document");
  return { ready: missing.length === 0, missing };
}

/** Throws with the list of missing fields — never emits a half PID. */
export function toOmlPatient(p: PatientProfileSlice): OmlPatient {
  const r = patientReadiness(p);
  if (!r.ready) {
    throw new Error(`[lab-bridge] patient profile not ready for the lab order: missing ${r.missing.join(", ")}`);
  }
  const names = splitNames(p);
  const phone = (p.phone ?? "").replace(/[^\d+]/g, "");
  return {
    document: { type: p.id_document_type as OmlPatient["document"]["type"], number: p.id_document_number! },
    nhc: nhcFor(p.patient_number!),
    firstName: names.firstName.toUpperCase(),
    surname1: names.surname1.toUpperCase(),
    surname2: names.surname2.toUpperCase(),
    birthDate: hl7Date(p.date_of_birth!)!,
    sex: p.sex === "male" ? "M" : "F",
    phones: phone ? [phone] : [],
    languageCode: LANGUAGE_BY_LOCALE[(p.locale ?? "es").slice(0, 2)] ?? "8",
  };
}
