export interface PaymentFailedData {
  firstName: string;
  locale: string;
}

export function renderPaymentFailed(data: PaymentFailedData, locale: string): string {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
  const profileUrl = `${appUrl}/${locale}/profile`;

  if (locale === "es") {
    return `
      <h1>Problema con tu pago, ${data.firstName}</h1>
      <p>No hemos podido procesar tu pago de suscripcion trimestral. Tu acceso a EVA Health puede verse interrumpido si no se resuelve.</p>
      <p>Por favor, actualiza tu metodo de pago para continuar disfrutando de:</p>
      <ul style="padding-left: 20px; margin: 16px 0;">
        <li style="margin-bottom: 6px;">Interpretacion de biomarcadores con rangos optimos</li>
        <li style="margin-bottom: 6px;">Asistente EVA AI</li>
        <li style="margin-bottom: 6px;">Kits de recogida trimestrales</li>
      </ul>
      <a href="${profileUrl}" class="cta">Actualizar Metodo de Pago</a>
    `;
  }

  return `
    <h1>Payment issue, ${data.firstName}</h1>
    <p>We were unable to process your quarterly subscription payment. Your EVA Health access may be interrupted if not resolved.</p>
    <p>Please update your payment method to continue enjoying:</p>
    <ul style="padding-left: 20px; margin: 16px 0;">
      <li style="margin-bottom: 6px;">Biomarker interpretation with optimal ranges</li>
      <li style="margin-bottom: 6px;">EVA AI assistant</li>
      <li style="margin-bottom: 6px;">Quarterly collection kits</li>
    </ul>
    <a href="${profileUrl}" class="cta">Update Payment Method</a>
  `;
}
