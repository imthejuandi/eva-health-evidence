/**
 * Lab result processing pipeline.
 *
 * Orchestrates: name matching → zone classification → calculated metrics →
 * biological age → DB persistence.
 */

import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { type SupabaseClient } from "@supabase/supabase-js";
import { matchBiomarkerName } from "./name-matcher";
import { buildEngineInputs } from "./engine-inputs";
import { classifyZone, ZONE_CONFIG, calculateAge } from "./zone-classifier";
import { calculate as calculateBioAge } from "./biological-age";
import {
  computeReferenceBA,
  computeComprehensiveBA,
  type KdmPatientContext,
  type KdmReferenceBAResult,
} from "./biological-age-kdm";
import type { SupplementEntry } from "./supplements";
import { recomputeAndCacheUserBA } from "./rolling-average-ba";
import { calculateAllMetrics } from "./calculated-metrics";
import { convertBiomarker } from "./unit-conversions";
import { remapToSeedKey } from "./key-aliases";
import { seedBiomarkerReferences } from "./seed-references";
import { getCanonicalUnit, validateCanonicalUnit, normalizeUnit } from "./canonical-units";
import type { BiomarkerInput, FullResult } from "./biological-age";
import type { CalculatedMetric } from "./calculated-metrics";
import type { Zone } from "./zone-classifier";

// ─── Input / Output types ───

/**
 * Raw biomarker from extraction.
 * biomarkerKey is optional: if provided (from user's manual confirmation),
 * it's used directly instead of running name matching again.
 * matchConfidence is optional but should be supplied alongside biomarkerKey
 * by the confirm route — it records how the row resolved to its key so we
 * can later audit how often users accept vs. correct fuzzy matches.
 */
export interface RawBiomarker {
  name: string;
  value: number;
  unit: string;
  /** "<" / ">" when the lab reported a bounded value ("<0,500"); `value` is the bound. */
  comparator?: "<" | ">";
  biomarkerKey?: string;
  matchConfidence?: "exact" | "alias" | "fuzzy" | "user";
}

export interface ProcessedBiomarker {
  biomarkerKey: string;
  name: string;
  value: number;
  unit: string;
  comparator?: "<" | ">" | null;
  zone: Zone;
  zoneLabel: string;
  zoneLabel_es: string;
  optimalLow: number | null;
  optimalHigh: number | null;
  matchConfidence: "exact" | "alias" | "fuzzy" | "user";
}

export interface UnmatchedBiomarker {
  name: string;
  value: number;
  unit: string;
  /** Reason why we couldn't process it. "unmatched" = name didn't match
   * any canonical biomarker. "unit_mismatch" = matched a biomarker but
   * couldn't auto-convert the supplied unit to the canonical one. */
  reason?: "unmatched" | "unit_mismatch";
  /** When reason=unit_mismatch, the canonical unit the seed expects. */
  expectedUnit?: string | null;
}

export interface ProcessingResult {
  processed: ProcessedBiomarker[];
  calculatedMetrics: CalculatedMetric[];
  /**
   * Legacy result object preserved for backward compatibility with admin
   * UI / API route responses. The `biologicalAge` number inside is the
   * KDM Reference BA when available, otherwise null. The longevity-score
   * fields (`longevityScore`, `lsGrade`, `confidence`) come from the
   * separate longevity-score engine.
   *
   * For the structured KDM result (including comprehensive BA + applied
   * Spanish recalibration markers), see `kdmBiologicalAge`.
   */
  biologicalAge: {
    biologicalAge: number | null;
    delta: number | null;
    longevityScore: number;
    lsGrade: string;
    confidence: string;
  } | null;
  /**
   * KDM v2.2 biological age — separate, mortality-validated metric. Null
   * when the KDM gate fails (< 8 base panel + Alb + Crea). Coexists with
   * the longevity score (`biologicalAge.longevityScore` above), which is
   * intentionally distinct (optimal-range-anchored vs population-anchored).
   */
  kdmBiologicalAge: {
    reference: KdmReferenceBAResult;
    comprehensive: KdmReferenceBAResult;
  };
  fullBioAgeResult: FullResult | null;
  unmatched: UnmatchedBiomarker[];
  /** Diagnostic: how many reference rows we could resolve for this sex+age */
  refMapSize: number;
  /** Diagnostic: sample of biomarker_keys that failed the refMap lookup */
  missingRefKeys: string[];
}

// ─── Pipeline ───

/**
 * Process lab results. Throws on any unrecoverable error (missing profile,
 * DB write failure). Does NOT silently fail.
 */
export async function processLabResults(
  userId: string,
  labResultId: string,
  rawBiomarkers: RawBiomarker[],
  client?: SupabaseClient,
  options?: {
    /**
     * The reported units come from a structured lab feed (HL7 OBX-6) and are
     * taken at face value: the CBC magnitude arbiter, built for OCR'd and
     * hand-typed reports whose unit label is often wrong, is switched off.
     */
    trustUnits?: boolean;
  },
): Promise<ProcessingResult> {
  // Service contexts (admin manual entry) pass a service-role client so the
  // cross-user writes below aren't blocked by RLS; user flows pass nothing and
  // get the RLS-bound client unchanged.
  const supabase = client ?? (await createClient());

  // 1. Get user profile (DOB, sex)
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("date_of_birth, sex")
    .eq("id", userId)
    .single();

  if (profileError) {
    throw new Error(`Failed to load profile: ${profileError.message}`);
  }

  if (!profile?.date_of_birth || !profile?.sex) {
    throw new Error("Profile incomplete: date_of_birth and sex are required for lab processing");
  }

  const age = calculateAge(profile.date_of_birth);
  if (isNaN(age)) {
    throw new Error(
      `Invalid date_of_birth format "${profile.date_of_birth}". Expected YYYY-MM-DD. Please update your profile.`,
    );
  }
  const sex = profile.sex as string;

  // 2. Match names + classify zones
  const processed: ProcessedBiomarker[] = [];
  const unmatched: UnmatchedBiomarker[] = [];

  // Fetch ALL reference ranges for this sex (across all age groups) and
  // then filter in code. This is resilient to age_group_en format variations
  // in the seed data (e.g. "18-25", "18 - 25", "18-25y", "All Adults") —
  // any format where we can extract a numeric low/high bound works.
  async function loadRefs() {
    return supabase
      .from("biomarker_references")
      .select("biomarker_key, sex, age_group_en, optimal_low, optimal_high, normal_low, normal_high, panel_category")
      .in("sex", [sex.toLowerCase(), "both"]);
  }

  let { data: allRefs, error: refsError } = await loadRefs();

  if (refsError) {
    throw new Error(`Failed to load biomarker references: ${refsError.message}`);
  }

  // Auto-seed path: if the table is empty, try to bootstrap it from the
  // committed JSON using the admin client. This makes reprocess work
  // end-to-end on a fresh database without requiring a local terminal.
  if (!allRefs || allRefs.length === 0) {
    console.log(
      "[process-results] biomarker_references empty — attempting auto-seed from committed JSON.",
    );
    const admin = createAdminClient();
    if (!admin) {
      throw new Error(
        "biomarker_references is empty and SUPABASE_SERVICE_ROLE_KEY is not set, " +
          "so auto-seed cannot run. Set the env var in Vercel and retry.",
      );
    }
    try {
      const { inserted } = await seedBiomarkerReferences(admin);
      console.log(`[process-results] Auto-seed complete: ${inserted} rows upserted.`);
    } catch (seedErr) {
      const msg = seedErr instanceof Error ? seedErr.message : String(seedErr);
      throw new Error(`biomarker_references auto-seed failed: ${msg}`);
    }
    // Re-fetch after seeding
    ({ data: allRefs, error: refsError } = await loadRefs());
    if (refsError) {
      throw new Error(`Failed to re-load biomarker_references after seed: ${refsError.message}`);
    }
    if (!allRefs || allRefs.length === 0) {
      throw new Error(
        "biomarker_references is still empty after auto-seed — check server logs " +
          "for the actual Supabase error.",
      );
    }
  }

  /**
   * Pick the reference row whose age_group_en range contains the user's age.
   * If multiple match, prefer sex-specific over "both".
   * If none match (unparseable age_group format), fall back to any row so at
   * least the biomarker gets SOME classification rather than silently failing.
   */
  const refMap = new Map<string, { optimal_low: number | null; optimal_high: number | null; normal_low: number | null; normal_high: number | null; panel_category: string | null }>();

  if (allRefs) {
    // Group by biomarker_key
    const byKey = new Map<string, typeof allRefs>();
    for (const ref of allRefs) {
      const arr = byKey.get(ref.biomarker_key) ?? [];
      arr.push(ref);
      byKey.set(ref.biomarker_key, arr);
    }

    for (const [key, refs] of byKey) {
      // Try to find a row whose age_group range contains `age`
      const matches = refs.filter((r) => ageGroupContains(r.age_group_en, age));
      let picked = matches.find((r) => r.sex === sex.toLowerCase()) ?? matches[0];
      // Fallback: no age-group match at all — take any row for this biomarker
      // so zone classification can still run. Log so we can fix the seed.
      if (!picked) {
        picked = refs.find((r) => r.sex === sex.toLowerCase()) ?? refs[0];
        if (picked) {
          console.warn(
            `[process-results] No age_group match for ${key} at age=${age}. ` +
              `Available: ${refs.map((r) => r.age_group_en).join(", ")}. Using fallback row.`,
          );
        }
      }
      if (picked) refMap.set(key, {
        optimal_low: picked.optimal_low,
        optimal_high: picked.optimal_high,
        normal_low: picked.normal_low,
        normal_high: picked.normal_high,
        panel_category: picked.panel_category ?? null,
      });
    }
  }

  // DIAGNOSTIC: dump the first 30 keys present in refMap so we can see what
  // biomarker_keys actually exist in the seeded database. Combined with the
  // per-biomarker lookup logs below, this makes classification failures
  // obvious in Vercel function logs.
  console.log(
    `[process-results] refMap built for sex=${sex.toLowerCase()}, age=${age}. ` +
      `${refMap.size} keys available. First 30: ${Array.from(refMap.keys()).slice(0, 30).join(", ")}`,
  );

  const missingRefKeys: string[] = [];

  const biomarkerValuesToInsert: Array<{
    lab_result_id: string;
    biomarker_key: string;
    biomarker_name: string;
    value: number;
    unit: string;
    zone: string;
    optimal_low: number | null;
    optimal_high: number | null;
    normal_low: number | null;
    normal_high: number | null;
    reported_value: number;
    reported_unit: string | null;
    comparator: "<" | ">" | null;
    category: string;
    match_confidence: "exact" | "alias" | "fuzzy" | "user";
  }> = [];

  for (const raw of rawBiomarkers) {
    // Prefer the user-provided biomarkerKey (from manual confirmation) over re-matching.
    // This respects the user's explicit selection in the UI.
    let biomarkerKey: string | null;
    let confidence: "exact" | "alias" | "fuzzy" | "user";

    if (raw.biomarkerKey) {
      biomarkerKey = raw.biomarkerKey;
      // If the caller told us how the row resolved (the confirm route
      // does), trust it. Otherwise default to "user" — historically this
      // path was only used for manual UI confirmations.
      confidence = raw.matchConfidence ?? "user";
    } else {
      const match = matchBiomarkerName(raw.name);
      if (!match.biomarkerKey || match.confidence === "none") {
        console.log(`[process-results] UNMATCHED name: "${raw.name}"`);
        unmatched.push({
          name: raw.name,
          value: raw.value,
          unit: raw.unit,
          reason: "unmatched",
        });
        continue;
      }
      biomarkerKey = match.biomarkerKey;
      confidence = match.confidence as "exact" | "alias" | "fuzzy";
    }

    // Remap the matcher's short canonical key to the seed's verbose slug
    // (e.g. "apolipoprotein_b" → "apolipoprotein_b_apob") and disambiguate
    // CBC differential %/absolute rows by looking at the reported unit.
    // Done BEFORE unit conversion because the conversion table keys off
    // seed-style biomarker keys (e.g. "testosterone_total" not "testosterone").
    const remappedKey = remapToSeedKey(biomarkerKey, raw.unit);
    if (remappedKey !== biomarkerKey) {
      console.log(
        `[process-results] Remapped key: ${biomarkerKey} → ${remappedKey} ` +
          `(unit="${raw.unit}")`,
      );
      biomarkerKey = remappedKey;
    }

    // Apply unit conversion BEFORE looking up the reference range.
    // This handles cholesterol (mmol/L → mg/dL), Urea (mmol/L → mg/dL),
    // BUN (mmol/L → mg/dL), etc. — same-molecule unit-system conversions
    // only. Cross-molecule scaling (Urea ↔ BUN) is NOT done here so each
    // marker keeps its own reference range; that conversion only happens
    // later inside the KDM joint estimator (which is anchored on BUN).
    // The converted value is what gets zone-classified and stored, so
    // downstream displays show the unit the EVA ranges expect.
    // Pass the canonical normal-high so convertBiomarker can spot a CBC
    // count reported on the raw cells/µL scale even when the unit string
    // is mislabelled (a /µL count tagged "10³/µL" is a common lab/OCR
    // quirk). The key is exact here, so refMap.get hits the right row.
    const conv = convertBiomarker(biomarkerKey, raw.value, raw.unit, {
      normalHigh: refMap.get(biomarkerKey)?.normal_high ?? null,
      trustUnit: options?.trustUnits === true,
    });
    if (conv.converted) {
      console.log(
        `[process-results] Converted ${raw.name} (${biomarkerKey}): ` +
          `${raw.value} ${raw.unit} → ${conv.value.toFixed(3)} ${conv.unit}. ${conv.note}`,
      );
    }
    const effectiveValue = conv.value;
    // A lab that prints no unit at all (Echevarne sends IDH/RDW and IDP bare)
    // gets the seed's canonical one, so the row never displays blank. The
    // gate below still rejects a unit that is present and wrong.
    const effectiveUnit = conv.unit || getCanonicalUnit(biomarkerKey) || "";

    // Canonical unit gate. After remap + conversion, the supplied unit
    // MUST match the seed's canonical unit for this biomarker_key. If
    // it doesn't, we refuse to insert the row — silently zone-classifying
    // a value in the wrong unit is the bug class that produced the
    // "Lymphocytes 2.10 10e3/µL marked critical low" screenshot. The
    // user gets a clear unit_mismatch error in the unmatched list.
    const canonical = getCanonicalUnit(biomarkerKey);
    if (canonical !== null) {
      const validation = validateCanonicalUnit(biomarkerKey, effectiveUnit);
      if (!validation.ok) {
        console.warn(
          `[process-results] UNIT MISMATCH for ${biomarkerKey} ("${raw.name}"): ` +
            `supplied "${effectiveUnit}" (normalized "${normalizeUnit(effectiveUnit)}") ` +
            `does not match canonical "${canonical}". Skipping row.`,
        );
        unmatched.push({
          name: raw.name,
          value: raw.value,
          unit: raw.unit,
          reason: "unit_mismatch",
          expectedUnit: canonical,
        });
        continue;
      }
    }

    // Primary lookup: exact match on the (possibly remapped) key
    let ref = refMap.get(biomarkerKey);
    const matcherKey: string = biomarkerKey; // narrow for use inside closures

    // Fallback: if the seed used a different slug (e.g. "blood_urea_nitrogen"
    // instead of "bun"), try substring matching against DB keys.
    if (!ref) {
      const dbKeys = Array.from(refMap.keys());
      // Prefer keys that CONTAIN the matcher key as a substring, or vice versa
      const fallback = dbKeys.find(
        (k) => k === matcherKey || k.includes(matcherKey) || matcherKey.includes(k),
      );
      if (fallback) {
        ref = refMap.get(fallback);
        console.log(
          `[process-results] Substring fallback: "${matcherKey}" → "${fallback}"`,
        );
        // Update biomarkerKey to the DB key so biomarker_values stores the
        // right reference and downstream queries find it
        biomarkerKey = fallback;
      }
    }

    if (!ref) {
      const sameLetter = Array.from(refMap.keys())
        .filter((k) => k[0] === matcherKey[0])
        .slice(0, 10)
        .join(", ") || "(none)";
      console.warn(
        `[process-results] NO REFERENCE for "${matcherKey}" (name="${raw.name}"). ` +
          `Available DB keys starting with same letter: ${sameLetter}`,
      );
      missingRefKeys.push(matcherKey);
    }
    const zone = ref
      ? classifyZone(effectiveValue, ref.optimal_low, ref.optimal_high, ref.normal_low, ref.normal_high)
      : ("unclassified" as Zone);

    const zoneConf = ZONE_CONFIG[zone];

    const entry: ProcessedBiomarker = {
      biomarkerKey,
      name: raw.name,
      value: effectiveValue,
      unit: effectiveUnit,
      comparator: raw.comparator ?? null,
      zone,
      zoneLabel: zoneConf.label,
      zoneLabel_es: zoneConf.label_es,
      optimalLow: ref?.optimal_low ?? null,
      optimalHigh: ref?.optimal_high ?? null,
      matchConfidence: confidence,
    };

    processed.push(entry);

    biomarkerValuesToInsert.push({
      lab_result_id: labResultId,
      biomarker_key: biomarkerKey,
      biomarker_name: raw.name,
      value: effectiveValue,
      unit: effectiveUnit,
      // What the lab actually printed, before any rescale/conversion — the
      // audit trail behind the canonical value ("your lab said 4.2 mmol/L").
      reported_value: raw.value,
      reported_unit: raw.unit || null,
      // A bounded value ("<0,500") keeps its comparator; the number is the bound.
      comparator: raw.comparator ?? null,
      zone,
      optimal_low: ref?.optimal_low ?? null,
      optimal_high: ref?.optimal_high ?? null,
      normal_low: ref?.normal_low ?? null,
      normal_high: ref?.normal_high ?? null,
      // Category was previously hard-coded to "" — meaning every row went
      // into a single empty bucket and the dashboard's by-category section
      // had nothing to group by. We now stamp the panel_category from
      // biomarker_references (e.g. "cardiovascular", "thyroid"). If the
      // ref lookup failed for some reason we fall back to "uncategorized"
      // rather than empty so the UI never silently hides the row.
      category: ref?.panel_category ?? "uncategorized",
      match_confidence: confidence,
    });
  }

  // 3. Persist biomarker_values — fail loudly on error
  if (biomarkerValuesToInsert.length > 0) {
    const { error: insertError } = await supabase
      .from("biomarker_values")
      .insert(biomarkerValuesToInsert);

    if (insertError) {
      throw new Error(`Failed to insert biomarker_values: ${insertError.message}`);
    }
  }

  // 4. Calculate derived metrics
  const calculatedMetrics = calculateAllMetrics(
    processed.map((p) => ({ biomarker_key: p.biomarkerKey, value: p.value })),
    sex,
  );

  // 5. Compute zone counts — these should ALWAYS be saved, regardless of
  // whether biological age can be calculated. Previously they were nested
  // inside the bio-age conditional, which meant users with < 8 biomarkers
  // saw zero counts on the dashboard even though the data was in biomarker_values.
  const optimalCount = processed.filter((p) => p.zone === "optimal").length;
  const attentionCount = processed.filter(
    (p) => p.zone === "below_optimal" || p.zone === "above_optimal",
  ).length;
  const actionCount = processed.filter(
    (p) => p.zone === "critical_low" || p.zone === "critical_high",
  ).length;

  // 6. Build engine inputs for the longevity-score engine: mapped DB keys
  // plus the computed ratios (NLR, HOMA-IR) — see engine-inputs.ts.
  const engineInputs: BiomarkerInput[] = buildEngineInputs(
    processed.map((p) => ({ biomarkerKey: p.biomarkerKey, value: p.value })),
    sex,
  );

  // 6a. Calculate longevity score (optimal-range-anchored, ≥8 markers gate).
  let biologicalAge: ProcessingResult["biologicalAge"] = null;
  let fullBioAgeResult: FullResult | null = null;
  const sexParam = sex.toLowerCase() === "female" ? "female" : "male";

  if (engineInputs.length >= 8) {
    const lsResult = calculateBioAge(engineInputs, sexParam, age);
    if (lsResult.longevityScore > 0) {
      fullBioAgeResult = lsResult;
      biologicalAge = {
        // `biologicalAge` is populated from the KDM result below — leave
        // null here and overwrite once KDM completes.
        biologicalAge: null,
        delta: null,
        longevityScore: lsResult.longevityScore,
        lsGrade: lsResult.lsGrade,
        confidence: lsResult.confidence,
      };
    }
  }

  // 6b. Fetch the patient context (medications + supplements) for KDM
  // lifestyle adjustments. The supplements list is used to apply the
  // creatine-dose-aware creatinine offset (Mayer 1985 / ISSN 2017). If no
  // context exists yet (older accounts, fresh signups), KDM runs without
  // lifestyle adjustments — safe degraded behavior.
  let kdmContext: KdmPatientContext | null = null;
  {
    const { data: contextRow } = await supabase
      .from("patient_context_versions")
      .select("supplements")
      .eq("user_id", userId)
      .order("version_number", { ascending: false })
      .limit(1)
      .maybeSingle();
    const supplements =
      contextRow && Array.isArray((contextRow as { supplements?: unknown }).supplements)
        ? ((contextRow as { supplements: SupplementEntry[] }).supplements)
        : null;
    kdmContext = { supplements };
  }

  // 6c. Calculate KDM v2.2 biological age (population-anchored, mortality-
  // validated). The KDM module accepts BiomarkerInput[] with either engine
  // codes or DB keys; we feed the DB keys here so non-engine markers (e.g.,
  // Calcium, Cystatin C, BUN, Total Cholesterol — base-panel-relevant but
  // not in the 39-code longevity engine) can contribute. The KDM gate
  // (≥ 8/14 base panel + Albumin + Creatinine) is enforced inside the
  // module; null result means gate failed.
  const kdmInputs: BiomarkerInput[] = processed.map((p) => ({
    code: p.biomarkerKey,
    value: p.value,
  }));
  const kdmReference = computeReferenceBA(kdmInputs, sexParam, age, kdmContext);
  const kdmComprehensive = computeComprehensiveBA(kdmInputs, sexParam, age, kdmContext);
  const kdmBiologicalAge = {
    reference: kdmReference,
    comprehensive: kdmComprehensive,
  };

  // Backfill legacy result shape: when KDM produced a Reference BA, surface
  // it on the legacy `biologicalAge` object so admin / email consumers see
  // the new mortality-validated number. When KDM gate failed but longevity
  // succeeded, the object still has the score but BA is null.
  if (biologicalAge && kdmReference) {
    biologicalAge.biologicalAge = kdmReference.BA;
    biologicalAge.delta = kdmReference.BA - age;
  } else if (!biologicalAge && kdmReference) {
    // KDM succeeded but longevity didn't (e.g., domain coverage failed).
    // Surface what we have so the dashboard can still show a BA.
    biologicalAge = {
      biologicalAge: kdmReference.BA,
      delta: kdmReference.BA - age,
      longevityScore: 0,
      lsGrade: "",
      confidence: "",
    };
  }

  // 7. Update lab_results with zone counts (always) + bio age + longevity.
  // Single update so counts are never missed when BA computation skips.
  const labResultUpdate: Record<string, number | string | string[] | null> = {
    optimal_count: optimalCount,
    attention_count: attentionCount,
    action_count: actionCount,
  };

  if (kdmReference) {
    labResultUpdate.biological_age = kdmReference.BA;
    labResultUpdate.bio_age_method = "KDM_v2.2_ReferenceBA";
    labResultUpdate.bio_age_n_markers = kdmReference.n_markers_used;
    labResultUpdate.bio_age_applied_spanish_calibration =
      kdmReference.applied_spanish_recalibration_markers;
  }
  if (kdmComprehensive) {
    labResultUpdate.biological_age_comprehensive = kdmComprehensive.BA;
  }
  if (biologicalAge) {
    labResultUpdate.longevity_score = biologicalAge.longevityScore;
    labResultUpdate.longevity_grade = biologicalAge.lsGrade;
  }

  const { error: updateError } = await supabase
    .from("lab_results")
    .update(labResultUpdate)
    .eq("id", labResultId);

  if (updateError) {
    throw new Error(`Failed to update lab_results: ${updateError.message}`);
  }

  // 8. Recompute the user's rolling-average BA across all recent labs and
  // cache it on `profiles.current_ba*`. This is what the dashboard reads.
  // We don't fail the whole pipeline if this errors — the per-lab BA was
  // already written above.
  try {
    await recomputeAndCacheUserBA(userId, supabase);
  } catch (err) {
    console.error("[processLabResults] recomputeAndCacheUserBA failed:", err);
  }

  return {
    processed,
    calculatedMetrics,
    biologicalAge,
    kdmBiologicalAge,
    fullBioAgeResult,
    unmatched,
    refMapSize: refMap.size,
    missingRefKeys: missingRefKeys.slice(0, 20),
  };
}

// ─── Lab-level metric recomputation (manual-edit path) ───

/**
 * Recompute every lab-level metric the dashboard reads — zone counts,
 * KDM biological age (Reference + Comprehensive), longevity score, and
 * the user's rolling-average BA cached on profile.current_ba* — from
 * the CURRENT biomarker_values rows for a single lab.
 *
 * This is the "edit path" version of steps 5-8 of processLabResults.
 * Whereas processLabResults works from the in-memory `processed` array
 * it just wrote, this loads the persisted state and recomputes — so
 * when /api/biomarker-values/[id] updates a single row, we can refresh
 * the whole panel's BA, score and counts without re-running name
 * matching, unit conversion or re-inserting biomarker_values (the row
 * being edited is already correctly classified by the PATCH handler).
 *
 * Idempotent. Throws only if the lab_results UPDATE fails; KDM /
 * longevity gates that don't pass simply leave their respective
 * columns unchanged on lab_results (we only write the ones we
 * recomputed). The rolling-average cache is best-effort: an error
 * there is logged but doesn't fail the whole recompute.
 */
export async function recomputeLabMetrics(
  userId: string,
  labResultId: string,
  supabase: ServerClient,
): Promise<void> {
  // 1. Profile (date_of_birth + sex). Required for age-dependent
  //    longevity scoring and KDM. If missing we can still recompute
  //    zone counts but skip BA/longevity.
  const { data: profile } = await supabase
    .from("profiles")
    .select("date_of_birth, sex")
    .eq("id", userId)
    .single();

  // 2. All biomarker_values for this lab.
  const { data: values, error: valuesError } = await supabase
    .from("biomarker_values")
    .select("biomarker_key, value, zone")
    .eq("lab_result_id", labResultId);
  if (valuesError) {
    throw new Error(
      `recomputeLabMetrics: failed to load biomarker_values: ${valuesError.message}`,
    );
  }
  if (!values || values.length === 0) {
    return;
  }

  // 3. Zone counts.
  const optimalCount = values.filter((v) => v.zone === "optimal").length;
  const attentionCount = values.filter(
    (v) => v.zone === "below_optimal" || v.zone === "above_optimal",
  ).length;
  const actionCount = values.filter(
    (v) => v.zone === "critical_low" || v.zone === "critical_high",
  ).length;

  const labResultUpdate: Record<string, number | string | string[] | null> = {
    optimal_count: optimalCount,
    attention_count: attentionCount,
    action_count: actionCount,
  };

  // 4. BA + longevity require a fully-populated profile. Without it we
  //    still ship the zone counts (above) — they're what the headline
  //    "X needs attention" tile reads.
  if (profile?.date_of_birth && profile?.sex) {
    const age = calculateAge(profile.date_of_birth);
    const sex = (profile.sex as string).toLowerCase();
    const sexParam: "female" | "male" = sex === "female" ? "female" : "male";

    if (Number.isFinite(age)) {
      // 4a. Longevity score — mapped engine codes plus computed ratios, ≥8 markers gate.
      const engineInputs: BiomarkerInput[] = buildEngineInputs(
        values.map((v) => ({ biomarkerKey: v.biomarker_key, value: Number(v.value) })),
        sexParam,
      );
      if (engineInputs.length >= 8) {
        const lsResult = calculateBioAge(engineInputs, sexParam, age);
        if (lsResult.longevityScore > 0) {
          labResultUpdate.longevity_score = lsResult.longevityScore;
          labResultUpdate.longevity_grade = lsResult.lsGrade;
        }
      }

      // 4b. KDM patient context — supplements drive the creatinine
      //     offset (Mayer 1985 / ISSN 2017). Missing context = KDM
      //     runs without lifestyle adjustments (degraded but safe).
      const { data: contextRow } = await supabase
        .from("patient_context_versions")
        .select("supplements")
        .eq("user_id", userId)
        .order("version_number", { ascending: false })
        .limit(1)
        .maybeSingle();
      const supplements =
        contextRow && Array.isArray((contextRow as { supplements?: unknown }).supplements)
          ? ((contextRow as { supplements: SupplementEntry[] }).supplements)
          : null;
      const kdmContext: KdmPatientContext = { supplements };

      // 4c. KDM Reference + Comprehensive BA.
      const kdmInputs: BiomarkerInput[] = values
        .filter((v) => Number.isFinite(Number(v.value)))
        .map((v) => ({ code: v.biomarker_key, value: Number(v.value) }));
      const kdmReference = computeReferenceBA(kdmInputs, sexParam, age, kdmContext);
      const kdmComprehensive = computeComprehensiveBA(kdmInputs, sexParam, age, kdmContext);

      if (kdmReference) {
        labResultUpdate.biological_age = kdmReference.BA;
        labResultUpdate.bio_age_method = "KDM_v2.2_ReferenceBA";
        labResultUpdate.bio_age_n_markers = kdmReference.n_markers_used;
        labResultUpdate.bio_age_applied_spanish_calibration =
          kdmReference.applied_spanish_recalibration_markers;
      }
      if (kdmComprehensive) {
        labResultUpdate.biological_age_comprehensive = kdmComprehensive.BA;
      }
    }
  }

  // 5. Persist everything we recomputed in a single UPDATE.
  const { error: updateError } = await supabase
    .from("lab_results")
    .update(labResultUpdate)
    .eq("id", labResultId);
  if (updateError) {
    throw new Error(
      `recomputeLabMetrics: lab_results update failed: ${updateError.message}`,
    );
  }

  // 6. Rolling-average BA → profile.current_ba*. Best-effort.
  try {
    await recomputeAndCacheUserBA(userId, supabase);
  } catch (err) {
    console.error("[recomputeLabMetrics] recomputeAndCacheUserBA failed:", err);
  }
}

type ServerClient = Awaited<ReturnType<typeof createClient>>;

// ─── Age group helper ───

/**
 * Check if an age_group_en string represents a range that contains `age`.
 * Tolerant of many formats:
 *   "18-25", "18 - 25", "18-25y", "18 to 25", "Adults 18-25",
 *   "96-100+", "96+", "65 and over", "Under 18",
 *   "All Adults" / "All Ages", and menopausal/hormonal labels
 *   ("Premenopausal", "Postmenopausal", "Ovulatory peak", …) which
 *   are context-gated rather than age-gated and should match any adult.
 */
function ageGroupContains(ageGroup: string | null | undefined, age: number): boolean {
  if (!ageGroup || !Number.isFinite(age)) return false;
  const str = ageGroup.toLowerCase().trim();

  // Non-age labels — match any adult so the sex filter does the narrowing.
  // The dataset uses these for female-specific hormonal windows and the
  // common "All Adults" fallback bucket.
  if (
    str === "all adults" ||
    str === "all ages" ||
    str === "adult" ||
    str === "adults" ||
    str.startsWith("premenopausal") ||
    str.startsWith("postmenopausal") ||
    str.startsWith("perimenopausal") ||
    str.startsWith("ovulatory") ||
    str.startsWith("follicular") ||
    str.startsWith("luteal")
  ) {
    return age >= 18;
  }

  // "18-25" / "18 - 25" / "18–25" / "18 to 25"
  const rangeMatch = str.match(/(\d{1,3})\s*(?:-|–|to|a)\s*(\d{1,3})/);
  if (rangeMatch) {
    const low = Number(rangeMatch[1]);
    const high = Number(rangeMatch[2]);
    return age >= low && age <= high;
  }

  // "96+" / "65 and over" / "65 or older" / "over 65"
  const openEndMatch = str.match(/(\d{1,3})\s*\+/) || str.match(/(\d{1,3})\s*(?:and|or)\s*(?:over|older|más)/) || str.match(/(?:over|mayor)\s*(?:de\s*)?(\d{1,3})/);
  if (openEndMatch) {
    return age >= Number(openEndMatch[1]);
  }

  // "under 18" / "below 18" / "menor de 18"
  const openStartMatch = str.match(/(?:under|below|menor\s*(?:de)?)\s*(\d{1,3})/);
  if (openStartMatch) {
    return age < Number(openStartMatch[1]);
  }

  return false;
}
