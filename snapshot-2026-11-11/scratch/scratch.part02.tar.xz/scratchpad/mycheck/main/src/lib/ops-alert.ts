/**
 * Structured, greppable operational log lines (OPS-010 pattern).
 *
 * The auto-resolve cron established the `[scope][ALERT]` / `[scope][OK]`
 * convention that the log-drain / dead-man's-switch monitoring greps for.
 * This helper centralizes it so the cycle-scheduler, lab bridge, and webhook
 * alerts emit the exact same shape instead of re-implementing it ad hoc.
 *
 *   opsAlert("stripe.webhook", "duplicate stripe_customer_id", { customerId })
 *   → console.error('[stripe.webhook][ALERT] duplicate stripe_customer_id {"customerId":...}')
 *
 * Sentry note: once @sentry/nextjs is wired (SENTRY_DSN set), captureException
 * calls can be added HERE so every alert reaches Sentry from one choke point.
 */

function fmt(meta?: Record<string, unknown>): string {
  if (!meta || Object.keys(meta).length === 0) return "";
  try {
    return " " + JSON.stringify(meta);
  } catch {
    return " [meta unserializable]";
  }
}

/** Something is wrong and an operator should look at it. */
export function opsAlert(scope: string, message: string, meta?: Record<string, unknown>): void {
  console.error(`[${scope}][ALERT] ${message}${fmt(meta)}`);
}

/** Periodic heartbeat proving a job ran fine (dead-man's-switch food). */
export function opsOk(scope: string, message: string, meta?: Record<string, unknown>): void {
  console.log(`[${scope}][OK] ${message}${fmt(meta)}`);
}
