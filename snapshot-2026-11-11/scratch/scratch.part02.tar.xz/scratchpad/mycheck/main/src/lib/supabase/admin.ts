import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Admin Supabase client that bypasses Row Level Security.
 *
 * Uses SUPABASE_SERVICE_ROLE_KEY — NEVER expose this key to the browser.
 * Only use this client in server-side route handlers and server actions
 * where you've already verified the user's identity and authorization.
 *
 * Use cases:
 * - Deleting rows when no user-facing DELETE RLS policy exists yet
 * - Cross-user cleanup tasks
 * - Admin reprocessing flows
 *
 * Returns null if the service role key is not configured, so callers
 * can gracefully fall back or return a clear error.
 */
export function createAdminClient(): SupabaseClient | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    return null;
  }

  return createClient(url, serviceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  });
}
