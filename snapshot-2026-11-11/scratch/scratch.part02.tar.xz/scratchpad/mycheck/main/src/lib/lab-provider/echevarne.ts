/**
 * Echevarne lab provider — HL7 v2.5 ORU^R01 parser per the OFFICIAL spec
 * "Especificación de la mensajería ECH_EVAHEALTH v2.8 (TCP/SFTP)"
 * (docs/vendor/echevarne/ — segment tables §1.3.2, examples §1.3.3).
 *
 * Field map (v2.8):
 *   ORC.2.1  placer order number  → eva's petition id = THE matching key
 *   ORC.3.1  filler order number  → ECH petition (providerReference); PID.4 mirrors it
 *   ORC.5    order status         → A = partial, CM = final
 *   ORC.27.1 specimen extraction datetime (new in v2.8) → collection date
 *   OBR.25 / OBX.11 result status → F final, P preliminary, C corrected
 *   OBX.2    value type           → NM numeric / TX text / ED encapsulated PDF
 *   OBX.3.1  ECH analyte code (proprietary) · OBX.3.4 LOINC "si se dispone"
 *   OBX.5    value (EU decimal comma; bounded values "<0,500" / ">8,000")
 *   OBX.6.2  unit description (component 2 — e.g. "^pg/mL")
 *   SPM.2.1  sample label code ("label de Trak" — the kit sticker)
 *   MSH.10   message control id   → lab_messages dedupe + ACK MSA-2
 *
 * Matching model: order-based. eva creates the petition (OML^O21) with its own
 * placer order number; the ORU echoes it back. There is NO eva user id inside
 * the message — the caller resolves placerOrderNumber → test_cycle → user.
 * `userId` is intentionally left unset.
 *
 * Transport is SFTP/TCP (files), not a signed webhook. verifyWebhook remains
 * for the legacy HTTP path only and stays FAIL-CLOSED (inert) unless
 * ECHEVARNE_WEBHOOK_SECRET is deliberately set.
 *
 * TODO(F0): ECH_CODE_TO_BIOMARKER below is a placeholder pending the real
 * Echevarne test catalog ("catálogo de prestaciones"). Unmapped codes return
 * "" and are skipped+logged downstream — never a crash.
 */

import { timingSafeEqual } from "node:crypto";
import type { LabProvider } from "./interface";
import type { BiomarkerResult, LabProviderResult, LabTextNote } from "./types";
import {
  getComponent,
  getField,
  getMshField,
  hl7DateToIso,
  hl7DateTimeToIso,
  parseHl7,
  parseHl7Value,
  unescapeHl7Text,
  segmentsByName,
  type Hl7Delimiters,
  type Hl7Segment,
} from "./hl7";

/**
 * ECH result code (OBX-3.1, «CÓDIGO RESULTADO ECHEVARNE») → eva biomarker_key.
 *
 * Source of truth: official catalog received from ECH 2026-08-25
 * (docs/vendor/echevarne/catalogo-2026-08-25.tsv). Values are verbatim
 * seed slugs from biomarker_references (see src/lib/biomarkers/name-matcher.ts
 * ALL_KEYS). Codes present in the catalog but with no eva reference range
 * (e.g. folate D0027, adiponectin D0412, urinalysis, vitamin A/B1/B6/C/E/K,
 * copper, selenium, iodine, cystatin C, fibrinogen, PTH, IGF-1, NT-proBNP,
 * progesterone, reverse T3, erythrocyte magnesium) are deliberately
 * unmapped — they surface with the raw ECH code so nothing is lost.
 * Open questions are tracked in docs/vendor/echevarne/catalogo-notas.md.
 */
const ECH_CODE_TO_BIOMARKER: Record<string, string> = {
  // ── Hemograma (SINÓNIMO H) ──
  H0000: "mchc",
  H0001: "mch",
  H0002: "mcv",
  H0003: "hematocrit",
  H0004: "hemoglobin",
  H0005: "red_blood_cell_count",
  H0006: "rdw", // IDH = índice de distribución de hematíes
  H0007: "white_blood_cell_count",
  H0008: "platelet_count",
  H0010: "eosinophils",
  H0011: "eosinophils_absolute",
  H0012: "basophils",
  H0013: "basophils_absolute",
  H0014: "lymphocytes",
  H0015: "lymphocytes_absolute",
  H0016: "monocytes",
  H0017: "monocytes_absolute",
  H0042: "mpv", // VPM
  H0137: "neutrophils",
  H0138: "neutrophils_absolute",
  // ── Metabólico ──
  B0000: "glucose_fasting",
  B0031: "hba1c", // %
  B0826: "hba1c", // mmol/mol — unit conversion happens downstream
  B0158: "fructosamine", // FRUC — µmol/L, Base Panel glycation marker (2026-09-22)
  D0154: "insulin_fasting",
  D0547: "leptin",
  // ── Lípidos ──
  B0001: "total_cholesterol",
  B0017: "hdl_cholesterol",
  B0018: "ldl_cholesterol",
  B0004: "triglycerides",
  B0839: "apolipoprotein_b_apob",
  B1381: "lipoproteina", // Lp(a) — seed slug of "Lipoprotein(a)"
  // ── Inflamación ──
  B0851: "hs_crp",
  D0190: "homocysteine",
  // ── Hígado ──
  B0005: "alt", // GPT
  B0006: "ast", // GOT
  B0007: "ggt",
  B0202: "alp",
  B0008: "total_bilirubin",
  B0020: "albumin",
  B0024: "total_protein",
  // ── Riñón / electrolitos ──
  B0003: "creatinine",
  B0025: "uric_acid",
  B0150: "bun",
  B0840: "microalbumin_urine",
  B0015: "sodium",
  B0016: "potassium",
  B0038: "chloride",
  B0010: "calcium_serum", // ojo: catálogo reporta mg/L
  B0792: "magnesium_serum",
  // ── Tiroides ──
  D0012: "tsh",
  D0105: "free_t4_thyroxine",
  D0127: "free_t3_triiodothyronine",
  I0425: "thyroid_peroxidase_antibodies_tpo",
  I2047: "thyroglobulin_antibodies_tgab",
  // ── Hierro ──
  D0021: "ferritin",
  B0013: "iron_serum", // sideremia
  B1386: "iron_binding_capacity_tibc",
  // ── Vitaminas / minerales ──
  D0282: "vitamin_d_25_oh",
  D0099: "vitamin_b12", // pg/mL
  B1618: "vitamin_b12", // pmol/L
  B1540: "zinc_serum",
  // ── Hormonas ──
  D0014: "testosterone_total",
  D0081: "estradiol",
  D0506: "dhea_sulfate",
  D0415: "cortisol_morning_8am",
  D0102: "shbg",
  D0063: "fsh",
  D0197: "luteinizing_hormone_lh",
  D0015: "prolactin",
  D0694: "anti_mullerian_hormone_amh", // pmol/L
  D0695: "anti_mullerian_hormone_amh", // ng/mL
  // ── Autoinmune ──
  I0015: "ana_screen",
  I0016: "ana_pattern",
  B0843: "rheumatoid_factor_rf",
  // ── Páncreas ──
  B0045: "amylase",
  B0269: "lipase",
  // ── PSA ──
  D0098: "psa_total",
  B1344: "psa_total",
  D0177: "psa_free",
  // ── Ácidos grasos (SINÓNIMO AGCIEN) ──
  T0596: "omega_3_epa",
  T0597: "omega_3_dha",
  T0598: "omega_6_linoleic_acid",
  T0602: "omega_6_arachidonic_acid",
  T0606: "omega_3_total",
  T0607: "omega_6_total",
  T0666: "arachidonic_acid_epa_ratio",
  T0725: "omega_6_omega_3_ratio",
  // T0603 "(C22:5)" NO mapeado a omega_3_dpa: podría ser DPA n-3 u
  // Osbond n-6 — preguntar a ECH antes de mapear.
  // ── Metales ──
  T0038: "lead_blood",
  T2064: "mercury_blood",
};

/**
 * LOINC (OBX-3.4, when ECH provides it) → eva biomarker_key. Fallback path
 * only — the primary path is ECH_CODE_TO_BIOMARKER above. Keys are verbatim
 * biomarker_references slugs.
 */
const LOINC_TO_BIOMARKER: Record<string, string> = {
  "2345-7": "glucose_fasting",
  "4548-4": "hba1c",
  "2093-3": "total_cholesterol",
  "2085-9": "hdl_cholesterol",
  "2089-1": "ldl_cholesterol",
  "2571-8": "triglycerides",
  "1988-5": "hs_crp",
  "1742-6": "alt",
  "1920-8": "ast",
};

/** Accept a raw HL7 string OR a JSON envelope that carries the message. */
function extractHl7Text(payload: unknown): string {
  if (typeof payload === "string") return payload;
  if (payload && typeof payload === "object") {
    const o = payload as Record<string, unknown>;
    for (const key of ["hl7", "message", "raw", "body"]) {
      if (typeof o[key] === "string") return o[key] as string;
    }
  }
  throw new Error(
    "[Echevarne] Expected a raw HL7 v2 message (string) or a { hl7 } JSON wrapper.",
  );
}

function firstComponent(field: string, d: Hl7Delimiters): string {
  // Component 1, then subcomponent 1 when the & separator is present
  // (EIP fields like SPM-2 nest as 2.1.1).
  const c = getComponent(field, 1, d);
  const sub = c.split(d.subcomponent)[0] ?? c;
  return sub.trim();
}

function obxStatus(seg: Hl7Segment): "final" | "preliminary" | "corrected" | "" {
  const s = getField(seg, 11).trim().toUpperCase();
  if (s === "F") return "final";
  if (s === "P") return "preliminary";
  if (s === "C") return "corrected";
  return "";
}

function bearerMatches(headers: Record<string, string>): boolean {
  const secret = process.env.ECHEVARNE_WEBHOOK_SECRET;
  if (!secret) return false;
  const m = /^Bearer\s+(.+)$/i.exec(headers["authorization"] ?? "");
  if (!m) return false;
  const provided = Buffer.from(m[1]);
  const expected = Buffer.from(secret);
  return provided.length === expected.length && timingSafeEqual(provided, expected);
}

export const EchevarneProvider: LabProvider = {
  name: "echevarne",
  payloadFormat: "hl7",

  parseResults(payload: unknown): LabProviderResult {
    const message = extractHl7Text(payload);
    const msg = parseHl7(message);
    const d = msg.delimiters;

    const messageControlId = getMshField(msg, 10).trim() || undefined;

    // Order-level identifiers. ORC repeats per prueba but carries the same
    // petition ids in every repetition — read the first, fall back to OBR.
    const orc = segmentsByName(msg, "ORC")[0];
    const obrFirst = segmentsByName(msg, "OBR")[0];
    const placerOrderNumber =
      firstComponent(getField(orc, 2), d) || firstComponent(getField(obrFirst, 2), d) || undefined;
    const providerReference =
      firstComponent(getField(orc, 3), d) || firstComponent(getField(obrFirst, 3), d);
    if (!providerReference) {
      // Never synthesize a reference (the old Date.now() fallback made every
      // unmatched message unique and defeated dedupe).
      throw new Error("[Echevarne] Message carries no filler order number (ORC.3.1/OBR.3.1)");
    }

    // ORC.5: CM = petición finalizada, A = aún parcial.
    const orcStatusRaw = getField(orc, 5).trim().toUpperCase();
    const orderStatus =
      orcStatusRaw === "CM" ? ("final" as const) : orcStatusRaw === "A" ? ("partial" as const) : undefined;

    // Extraction datetime: ORC.27.1 (v2.8) → SPM.18 → OBR.7 (legacy fallback).
    const spmFirst = segmentsByName(msg, "SPM")[0];
    const rawExtraction =
      firstComponent(getField(orc, 27), d) ||
      firstComponent(getField(spmFirst, 18), d) ||
      firstComponent(getField(obrFirst, 7), d);
    const collectionDate = hl7DateToIso(rawExtraction);
    const collectionDateTime = hl7DateTimeToIso(rawExtraction) || undefined;

    // Kit sticker / label de Trak: SPM.2.1 (first specimen).
    const kitLabelCode = firstComponent(getField(spmFirst, 2), d) || undefined;

    const biomarkers: BiomarkerResult[] = [];
    const textNotes: LabTextNote[] = [];
    let reportPdfBase64: string | undefined;

    for (const obx of segmentsByName(msg, "OBX")) {
      const valueType = getField(obx, 2).trim().toUpperCase(); // OBX-2: NM | TX | ED
      const code = getComponent(getField(obx, 3), 1, d).trim(); // OBX-3.1 ECH code
      const loinc = getComponent(getField(obx, 3), 4, d).trim(); // OBX-3.4 LOINC (si se dispone)
      const rawValue = getField(obx, 5);
      // OBX-6.2 carries the unit text per spec ("^pg/mL"); tolerate legacy
      // messages that put it in 6.1.
      const unit =
        getComponent(getField(obx, 6), 2, d).trim() ||
        getComponent(getField(obx, 6), 1, d).trim();
      const status = obxStatus(obx);

      if (valueType === "ED") {
        // Encapsulated report: OBX-5.5 = base64 PDF (PDF^AP^PDF^Base64^<b64>).
        const b64 = getComponent(rawValue, 5, d).trim();
        if (b64) reportPdfBase64 = b64;
        continue;
      }

      if (valueType === "TX") {
        // Free text: conclusions, valoraciones, microbiology germs and
        // antibiogram rows (whose S/I/R letter — or MIC bound — rides OBX-5
        // with the letter in OBX-6.2).
        const text = unescapeHl7Text(rawValue.trim() || unit).trim();
        if (code && text) textNotes.push({ code, text });
        continue;
      }

      // NM (and anything numeric-shaped): keep bounded values ("<0,500") with
      // their comparator instead of silently dropping them.
      const parsed = parseHl7Value(rawValue);
      if (!code || !parsed) continue;
      biomarkers.push({
        biomarker_key: code,
        value: parsed.value,
        unit,
        ...(parsed.comparator ? { comparator: parsed.comparator } : {}),
        ...(loinc ? { loincCode: loinc } : {}),
        ...(status ? { status } : {}),
      });
    }

    // HBA1 comes back as a pair: B0031 (%, NGSP) and B0826 (mmol/mol, IFCC)
    // — the same measurement twice. Both map to `hba1c`, so keeping both
    // stored two rows for one marker (training ORU X68800192, 2026-09-17).
    // The % row is the primary one; the IFCC row only stands in when the
    // % row is absent (downstream converts mmol/mol → %).
    const hasA1cPercent = biomarkers.some((b) => b.biomarker_key === "B0031");
    const dedupedBiomarkers = hasA1cPercent ? biomarkers.filter((b) => b.biomarker_key !== "B0826") : biomarkers;

    return {
      providerReference,
      placerOrderNumber,
      kitLabelCode,
      messageControlId,
      orderStatus,
      biomarkers: dedupedBiomarkers,
      ...(textNotes.length ? { textNotes } : {}),
      ...(reportPdfBase64 ? { reportPdfBase64 } : {}),
      collectionDate,
      collectionDateTime,
      rawPayload: message,
    };
  },

  // Resolve an ECH analyte code (OBX-3.1) to an eva biomarker_key, using the
  // LOINC (OBX-3.4) as fallback when provided. "" => unmapped; downstream
  // processing skips + logs it.
  mapBiomarkerName(providerCode: string, loincCode?: string): string {
    const code = providerCode.split("^")[0].trim();
    return (
      ECH_CODE_TO_BIOMARKER[code] ??
      (loincCode ? LOINC_TO_BIOMARKER[loincCode.trim()] ?? "" : "")
    );
  },

  verifyWebhook(headers: Record<string, string>, _body: string): boolean {
    return bearerMatches(headers);
  },
};
