/**
 * Identity document (documento de identidad) — validation + normalization.
 *
 * Why this exists: Echevarne requires a categorized patient identifier in
 * every lab order (PID.3.1 number + PID.3.5 type). The allowed type codes
 * below are the spec's exactly (confirmed by J. Fajardo, 2026-08-31). eva
 * captures the document on the profile page and refuses to ship a kit
 * without it, because the initial OML goes out at dispatch.
 *
 * DNI/NIF and NIE carry a mod-23 check letter; we validate it so a typo is
 * caught at the form instead of surfacing as a rejected order weeks later.
 */

export const ID_DOCUMENT_TYPES = [
  "DNI",
  "NIF",
  "CIF",
  "NIE",
  "PASAPORTE",
  "CENSO",
  "OTROS",
  "ID",
  "DNI_TUTOR",
  "NIF_TUTOR",
  "NIE_TUTOR",
] as const;

export type IdDocumentType = (typeof ID_DOCUMENT_TYPES)[number];

/** Types offered to adult patients in the profile form (eva is 18+; the
 *  *_TUTOR variants are for minors and CIF is for companies). */
export const PATIENT_DOCUMENT_TYPES: readonly IdDocumentType[] = [
  "DNI",
  "NIE",
  "PASAPORTE",
  "OTROS",
];

export function isIdDocumentType(v: unknown): v is IdDocumentType {
  return typeof v === "string" && (ID_DOCUMENT_TYPES as readonly string[]).includes(v);
}

/** Uppercase, strip spaces/dots/dashes — the form in which we store and send it. */
export function normalizeDocumentNumber(raw: string): string {
  return raw.toUpperCase().replace(/[\s.\-]/g, "");
}

const CHECK_LETTERS = "TRWAGMYFPDXBNJZSQVHLCKE";

/** Spanish DNI/NIF for natural persons: 8 digits + check letter. */
export function isValidDni(n: string): boolean {
  const m = /^(\d{8})([A-Z])$/.exec(n);
  if (!m) return false;
  return CHECK_LETTERS[Number(m[1]) % 23] === m[2];
}

/** Spanish NIE: X/Y/Z + 7 digits + check letter (X→0, Y→1, Z→2 for the checksum). */
export function isValidNie(n: string): boolean {
  const m = /^([XYZ])(\d{7})([A-Z])$/.exec(n);
  if (!m) return false;
  const prefix = { X: "0", Y: "1", Z: "2" }[m[1] as "X" | "Y" | "Z"];
  return CHECK_LETTERS[Number(prefix + m[2]) % 23] === m[3];
}

export type IdDocumentValidation =
  | { ok: true; type: IdDocumentType; number: string }
  | { ok: false; error: string };

/**
 * Validate a (type, number) pair. Returns the normalized number on success.
 * DNI/NIF (+ tutor variants) and NIE (+ tutor) are checksum-validated; the
 * rest (passport, census, other, generic id, CIF) only get a shape check
 * because their formats vary by country.
 */
export function validateIdDocument(type: unknown, rawNumber: unknown): IdDocumentValidation {
  if (!isIdDocumentType(type)) {
    return { ok: false, error: `Unsupported document type; expected one of ${ID_DOCUMENT_TYPES.join(", ")}` };
  }
  if (typeof rawNumber !== "string" || rawNumber.trim().length === 0) {
    return { ok: false, error: "Document number is required" };
  }
  const number = normalizeDocumentNumber(rawNumber);

  switch (type) {
    case "DNI":
    case "NIF":
    case "DNI_TUTOR":
    case "NIF_TUTOR":
      return isValidDni(number)
        ? { ok: true, type, number }
        : { ok: false, error: "Invalid DNI/NIF: expected 8 digits + check letter (e.g. 12345678Z)" };
    case "NIE":
    case "NIE_TUTOR":
      return isValidNie(number)
        ? { ok: true, type, number }
        : { ok: false, error: "Invalid NIE: expected X/Y/Z + 7 digits + check letter (e.g. X1234567L)" };
    default:
      return /^[A-Z0-9]{4,20}$/.test(number)
        ? { ok: true, type, number }
        : { ok: false, error: "Document number must be 4–20 letters/digits" };
  }
}
