import { describe, it, expect } from "vitest";
import { checkRateLimit, rateLimitEnabled, type RateLimitRule } from "./rate-limit";

// SEC-002 fail-open contract. The limiter is backed by Upstash Redis only when
// UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN are set. The test
// environment has neither, so these tests pin the documented behaviour: an
// unprovisioned deploy is NEVER broken — every request is allowed — and
// effective limiting turns on automatically once the store is configured.

describe("rate limiting (SEC-002 fail-open contract)", () => {
  it("reports disabled when Upstash env vars are absent", () => {
    expect(rateLimitEnabled).toBe(false);
  });

  it("allows the request (fails open) when no store is configured", async () => {
    const rule: RateLimitRule = { key: "test-contact", limit: 5, window: "1 m" };
    const r = await checkRateLimit(rule, "203.0.113.7");
    expect(r.success).toBe(true);
    expect(r.remaining).toBe(rule.limit);
    expect(r.reset).toBe(0);
  });

  it("does not throttle repeated calls while disabled", async () => {
    const rule: RateLimitRule = { key: "test-ai", limit: 1, window: "1 m" };
    const first = await checkRateLimit(rule, "203.0.113.7");
    const second = await checkRateLimit(rule, "203.0.113.7");
    expect(first.success).toBe(true);
    expect(second.success).toBe(true);
  });
});
