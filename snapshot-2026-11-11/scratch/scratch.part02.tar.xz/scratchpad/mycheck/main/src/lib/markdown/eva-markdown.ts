/**
 * Markdown rendering for assistant (EVA) chat replies.
 *
 * SECURITY: model output is UNTRUSTED — it can be steered by prompt injection
 * (e.g. via user-supplied lab data echoed back by the model). Every piece of
 * text is HTML-escaped *before* the bold/italic/list/paragraph transforms run,
 * so the only markup in the result is the small set of tags we add ourselves.
 * The returned string is therefore safe to inject via dangerouslySetInnerHTML.
 */

const HTML_ESCAPES: Record<string, string> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
};

/** Escape the five HTML-significant characters in a single pass. */
export function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (ch) => HTML_ESCAPES[ch]);
}

/** Escape, then apply inline **bold** / *italic* emphasis. */
export function renderInlineMarkdown(text: string): string {
  return escapeHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>");
}

export function renderParagraph(para: string): string {
  // Detect bullet list paragraphs (lines starting with - )
  const lines = para.split("\n");
  const isList = lines.every((l) => l.trim().startsWith("- "));
  if (isList) {
    const items = lines
      .map((l) => l.trim().replace(/^- /, ""))
      .map((l) => `<li>${renderInlineMarkdown(l)}</li>`)
      .join("");
    return `<ul>${items}</ul>`;
  }
  return `<p>${renderInlineMarkdown(para).replace(/\n/g, "<br/>")}</p>`;
}

export function paragraphsHTML(text: string): string {
  if (!text) return "";
  return text
    .replace(/[ \t]+\n/g, "\n")
    .trim()
    .split(/\n\s*\n/g)
    .map((p) => renderParagraph(p.trim()))
    .filter(Boolean)
    .join("");
}
