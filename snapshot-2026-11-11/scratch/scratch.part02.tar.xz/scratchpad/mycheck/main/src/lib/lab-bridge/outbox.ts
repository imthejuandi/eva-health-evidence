/**
 * Outbox — the app never talks to the SFTP itself. It builds the OML for a
 * cycle and QUEUES it in lab_messages (direction=out, status=queued); the
 * bridge uploads queued messages on its next pass.
 *
 * Hybrid timing agreed with ECH (2026-09-03): the INITIAL OML is queued when
 * Ops ships the kit (estimated extraction date), and the SAME order is
 * re-sent with the real date/time when the patient registers the extraction
 * (ECH overwrites order data on re-send and processes with the latest).
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import { buildOml } from "@/lib/lab-provider/oml-builder";
import { buildPlacerOrderNumber } from "@/lib/cycles/identifiers";
import { orderCodesForPanel, panelCodesFor, processingIdFromEnv, type PanelOrderCodes } from "./panel-codes";
import { toOmlPatient, type PatientProfileSlice } from "./patient-mapper";

/** Initial OML: the patient usually draws 1–3 days after delivery. */
export const ESTIMATED_EXTRACTION_OFFSET_DAYS = 3;
export const ESTIMATED_EXTRACTION_HOUR_LOCAL = 9;
export const LAB_TIMEZONE = "Europe/Madrid";

export interface OutboxCycle {
  id: string;
  seq: number;
  panel_type: string;
  placer_order_number: string | null;
  kit_label_code: string | null;
  extraction_confirmed_at: string | null;
}

export type OrderMessageKind = "initial" | "update";

export interface BuildOrderInput {
  cycle: OutboxCycle;
  profile: PatientProfileSlice;
  kind: OrderMessageKind;
  /** Wall clock — injected for determinism. */
  now: Date;
  /** 1 for the first OML of the cycle, 2 for the first re-send, … */
  messageSeq: number;
  processingId: "P" | "T";
  panelCodes?: PanelOrderCodes;
}

export interface BuiltOrderMessage {
  filename: string;
  raw: string;
  messageControlId: string;
  placerOrderNumber: string;
  extractionDateTime: string;
}

/** yyyyMMddHHmmss in the lab's timezone (Europe/Madrid). */
export function toHl7DateTime(d: Date, timeZone: string = LAB_TIMEZONE): string {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  const hour = get("hour") === "24" ? "00" : get("hour");
  return `${get("year")}${get("month")}${get("day")}${hour}${get("minute")}${get("second")}`;
}

export function estimatedExtraction(now: Date): string {
  const d = new Date(now.getTime() + ESTIMATED_EXTRACTION_OFFSET_DAYS * 86_400_000);
  const day = toHl7DateTime(d).slice(0, 8);
  return `${day}${String(ESTIMATED_EXTRACTION_HOUR_LOCAL).padStart(2, "0")}0000`;
}

export function buildOrderMessage(input: BuildOrderInput): BuiltOrderMessage {
  const { cycle, profile, kind, now, messageSeq } = input;
  if (!cycle.kit_label_code) {
    throw new Error("[lab-bridge] cycle has no kit_label_code (ECH petition number) — scan the sticker before building the order");
  }
  if (messageSeq < 1 || messageSeq > 999) throw new Error(`[lab-bridge] invalid messageSeq ${messageSeq}`);
  const placerOrderNumber =
    cycle.placer_order_number ?? buildPlacerOrderNumber(profile.patient_number ?? 0, cycle.seq);

  let extractionDateTime: string;
  if (kind === "update") {
    if (!cycle.extraction_confirmed_at) {
      throw new Error("[lab-bridge] update OML requires cycle.extraction_confirmed_at (patient-registered extraction)");
    }
    extractionDateTime = toHl7DateTime(new Date(cycle.extraction_confirmed_at));
  } else {
    extractionDateTime = estimatedExtraction(now);
  }

  const messageDateTime = toHl7DateTime(now);
  // MSH-10 is ST-20 and must be unique per message: placer (12) + M + seq.
  const messageControlId = `${placerOrderNumber}M${messageSeq}`;

  const raw = buildOml({
    messageControlId,
    messageDateTime,
    processingId: input.processingId,
    placerOrderNumber,
    requestDateTime: messageDateTime,
    extractionDateTime,
    labPetitionNumber: cycle.kit_label_code,
    patient: toOmlPatient(profile),
    tests: orderCodesForPanel(cycle.panel_type, input.panelCodes ?? panelCodesFor(input.processingId)),
  });

  return { filename: `${cycle.kit_label_code}.OML`, raw, messageControlId, placerOrderNumber, extractionDateTime };
}

export const PROFILE_SELECT_FOR_ORDER =
  "id, patient_number, first_name, last_name, second_surname, full_name, date_of_birth, sex, phone, locale, id_document_type, id_document_number";
export const CYCLE_SELECT_FOR_ORDER =
  "id, user_id, seq, panel_type, status, placer_order_number, kit_label_code, extraction_confirmed_at";

/**
 * Load cycle + profile, build the OML and queue it. Returns the lab_messages
 * id. Throws on any missing data — callers surface the message to Ops.
 */
export async function enqueueOmlForCycle(
  admin: SupabaseClient,
  cycleId: string,
  kind: OrderMessageKind,
  now: Date = new Date(),
  opts: { processingId?: "P" | "T"; panelCodes?: PanelOrderCodes } = {},
): Promise<{ messageId: string; messageControlId: string; filename: string }> {
  const { data: cycle, error: cErr } = await admin
    .from("test_cycles")
    .select(CYCLE_SELECT_FOR_ORDER)
    .eq("id", cycleId)
    .single();
  if (cErr || !cycle) throw new Error(`[lab-bridge] cycle ${cycleId} not found: ${cErr?.message ?? ""}`);

  const { data: profile, error: pErr } = await admin
    .from("profiles")
    .select(PROFILE_SELECT_FOR_ORDER)
    .eq("id", (cycle as { user_id: string }).user_id)
    .single();
  if (pErr || !profile) throw new Error(`[lab-bridge] profile for cycle ${cycleId} not found: ${pErr?.message ?? ""}`);

  const { count } = await admin
    .from("lab_messages")
    .select("id", { count: "exact", head: true })
    .eq("cycle_id", cycleId)
    .eq("direction", "out")
    .eq("msg_type", "OML");

  const built = buildOrderMessage({
    cycle: cycle as unknown as OutboxCycle,
    profile: profile as unknown as PatientProfileSlice,
    kind,
    now,
    messageSeq: (count ?? 0) + 1,
    processingId: opts.processingId ?? processingIdFromEnv(),
    panelCodes: opts.panelCodes,
  });

  const { data: inserted, error: iErr } = await admin
    .from("lab_messages")
    .insert({
      cycle_id: cycleId,
      direction: "out",
      msg_type: "OML",
      message_control_id: built.messageControlId,
      raw: built.raw,
      status: "queued",
    })
    .select("id")
    .single();
  if (iErr || !inserted) throw new Error(`[lab-bridge] could not queue OML: ${iErr?.message ?? ""}`);

  // Persist the placer on first build so the ORU can be matched later.
  if (!(cycle as OutboxCycle).placer_order_number) {
    await admin.from("test_cycles").update({ placer_order_number: built.placerOrderNumber }).eq("id", cycleId);
  }

  return { messageId: (inserted as { id: string }).id, messageControlId: built.messageControlId, filename: built.filename };
}
