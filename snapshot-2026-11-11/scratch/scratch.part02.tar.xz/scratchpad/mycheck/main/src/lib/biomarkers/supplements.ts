/**
 * Supplement parsing + biomarker offset application.
 *
 * The eva-health `patient_context_versions.supplements` JSONB field stores
 * supplements as `{key, dose}` where `dose` is free-text ("10g", "5000",
 * "1000mcg", etc.). This module normalizes those strings into structured
 * (value, unit) tuples and exposes per-supplement biomarker offsets used
 * in the KDM pipeline.
 *
 * Current biomarker offsets (literature-supported):
 *
 *   - Creatine supplementation → serum creatinine elevation:
 *     Mayer & Mannion 1985; Persky & Brazeau 2001; Banfi & Del Fabbro 2006;
 *     ISSN Position Stand 2017.
 *     Dose-dependent offset (chronic / post-loading):
 *       offset_mg_dL = min(0.05 + 0.025 × g_per_day, 0.40)
 *     Capped at 0.40 mg/dL because muscle creatine saturates beyond
 *     ~15-20 g/day; loading-phase 0.5-0.6 mg/dL spikes are transient.
 *
 * Future biomarker offsets (deferred to a separate PR):
 *
 *   - Iron supplementation → ferritin (varies wildly by dose/duration)
 *   - Levothyroxine → TSH suppression (binary suppression vs dose-dependent)
 *   - Statins → total cholesterol / LDL drop (well-characterized but already
 *     intended in the clinical signal — usually NOT something to "correct")
 *
 * See `docs/methodology.md` for the full rationale and citations.
 */

// ─── Public types ───

/**
 * Shape of one supplement entry from
 * `patient_context_versions.supplements`. The `key` is the supplement's
 * canonical identifier (e.g., "creatine", "vitamin_d"); `dose` is a
 * free-text string entered via the UI.
 */
export interface SupplementEntry {
  key: string;
  dose?: string | null;
}

/**
 * Parsed (value, unit) for a single dose string. `unit` is the lowercased
 * unit token from the input; if no unit was supplied, `unit` is `null`
 * and the caller can fall back to the supplement's `defaultUnit`.
 */
export interface ParsedDose {
  value: number;
  unit: string | null;
}

// ─── Default units per supplement (Spanish market convention) ───

/**
 * Default unit assumed when a user enters a bare numeric dose (e.g., "5000"
 * for vitamin D defaults to IU). Used by `parseSupplementDose`.
 *
 * If a supplement isn't in this map, the parser still extracts a numeric
 * value but the unit stays `null` — the caller decides what to do.
 */
export const SUPPLEMENT_DEFAULT_UNITS: Record<string, string> = {
  creatine: "g",
  vitamin_d: "iu",
  vitamin_b12: "mcg",
  b12: "mcg",
  iron: "mg",
  magnesium: "mg",
  omega_3: "g",
  fish_oil: "g",
  zinc: "mg",
  vitamin_c: "mg",
  vitamin_e: "mg",
  folate: "mcg",
  folic_acid: "mcg",
  coq10: "mg",
  vitamin_k2: "mcg",
  vitamin_a: "iu",
  selenium: "mcg",
};

// ─── Parsing ───

/**
 * Parse a free-text supplement dose into `{value, unit}`.
 *
 * Accepts common formats:
 *   "10g"          → { value: 10, unit: "g" }
 *   "10 g"         → { value: 10, unit: "g" }
 *   "10grams"      → { value: 10, unit: "g" }
 *   "5000"         → { value: 5000, unit: null }  (caller applies default)
 *   "1000 mcg"     → { value: 1000, unit: "mcg" }
 *   "1000mcg/day"  → { value: 1000, unit: "mcg" }
 *   "  2.5 g  "    → { value: 2.5, unit: "g" }
 *
 * Returns `null` if no number can be extracted.
 */
export function parseSupplementDose(dose: string | null | undefined): ParsedDose | null {
  if (!dose || typeof dose !== "string") return null;
  const trimmed = dose.trim().toLowerCase();
  if (!trimmed) return null;

  // Extract first numeric (handles decimals and scientific notation)
  const numMatch = trimmed.match(/-?\d+(?:\.\d+)?/);
  if (!numMatch) return null;
  const value = parseFloat(numMatch[0]);
  if (!Number.isFinite(value)) return null;

  // Extract unit token after the number (strip /day, /d, etc.)
  const after = trimmed.slice(numMatch.index! + numMatch[0].length).trim();
  const unitMatch = after.match(/^([a-zµμ]+)/);
  let unit: string | null = unitMatch ? unitMatch[1] : null;

  // Normalize unit synonyms
  if (unit) {
    if (unit === "grams" || unit === "gram") unit = "g";
    if (unit === "milligrams" || unit === "milligram" || unit === "miligrams") unit = "mg";
    if (unit === "micrograms" || unit === "microgram" || unit === "ug" || unit === "µg" || unit === "μg") unit = "mcg";
    if (unit === "units") unit = "iu";
  }

  return { value, unit };
}

/**
 * Resolve a supplement's dose to `{value, unit}` using the default unit
 * when the dose string doesn't specify one. Returns `null` if parsing fails.
 */
export function resolveSupplementDose(
  key: string,
  dose: string | null | undefined,
): ParsedDose | null {
  const parsed = parseSupplementDose(dose);
  if (!parsed) return null;
  if (parsed.unit) return parsed;
  const defaultUnit = SUPPLEMENT_DEFAULT_UNITS[key.toLowerCase()];
  return { value: parsed.value, unit: defaultUnit ?? null };
}

// ─── Biomarker offset: creatine → creatinine ───

/**
 * Compute the creatinine offset (mg/dL) to subtract before KDM computation,
 * given the user's daily creatine supplementation dose in grams.
 *
 * Formula (Mayer & Mannion 1985 + Persky & Brazeau 2001 + ISSN 2017):
 *   offset = min(0.05 + 0.025 × g_per_day, 0.40)
 *
 *   3 g/day    → 0.125 mg/dL
 *   5 g/day    → 0.175 mg/dL
 *   10 g/day   → 0.30 mg/dL
 *   20 g/day   → 0.40 mg/dL (cap, since muscle creatine saturates)
 *
 * Returns 0 if not supplementing.
 */
export function creatineCreatinineOffsetMgDL(
  gramsPerDay: number | null | undefined,
): number {
  if (typeof gramsPerDay !== "number" || !Number.isFinite(gramsPerDay) || gramsPerDay <= 0) {
    return 0;
  }
  return Math.min(0.05 + 0.025 * gramsPerDay, 0.4);
}

/**
 * Given the patient's supplements list, return the creatinine offset
 * (mg/dL) to apply for KDM purposes.
 *
 * Only the `creatine` supplement contributes today. If the supplement is
 * listed but the dose can't be parsed, or no unit could be inferred,
 * returns 0 (no correction — better to leave creatinine alone than to
 * apply a wrong-sized offset).
 *
 * Doses in grams are used directly. Other units are skipped (creatine is
 * almost always sold by the gram in the Spanish/EU market).
 */
export function creatinineOffsetFromSupplements(
  supplements: SupplementEntry[] | null | undefined,
): number {
  if (!Array.isArray(supplements)) return 0;
  for (const s of supplements) {
    if (!s?.key) continue;
    if (s.key.toLowerCase() !== "creatine") continue;
    const parsed = resolveSupplementDose(s.key, s.dose);
    if (!parsed) continue;
    if (parsed.unit && parsed.unit !== "g") continue; // skip non-gram doses
    return creatineCreatinineOffsetMgDL(parsed.value);
  }
  return 0;
}
