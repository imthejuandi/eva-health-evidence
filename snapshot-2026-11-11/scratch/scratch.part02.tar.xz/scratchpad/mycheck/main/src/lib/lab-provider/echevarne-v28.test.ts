/**
 * Spec-v2.8 fixture tests: the EchevarneProvider parser against the THREE
 * literal ORU^R01 sample messages from the official spec (§1.3.3.1–3), plus
 * ACK parsing/building against the spec's ACK examples and the OML builder
 * against the §1.1.2.8 shape. Fixtures: __fixtures__/echevarne-v28.ts.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { EchevarneProvider } from "./echevarne";
import { buildOml } from "./oml-builder";
import { buildOruAck, parseAck } from "./ack";
import {
  ORU_EX1_BIOQUIMICA,
  ORU_EX2_RAST_PARTIAL,
  ORU_EX3_MICRO,
  ACK_OML_OK,
  ACK_OML_ERROR,
} from "./__fixtures__/echevarne-v28";

describe("EX1 — bioquímica/hormonas + alergia (final, CM)", () => {
  const r = EchevarneProvider.parseResults(ORU_EX1_BIOQUIMICA);

  it("matches by ORC.2.1 placer and keeps ECH filler as providerReference", () => {
    expect(r.placerOrderNumber).toBe("20253989090");
    expect(r.providerReference).toBe("W88800130");
    expect(r.userId).toBeUndefined();
  });

  it("reads MSH-10, ORC.5=CM and the v2.8 extraction date ORC.27.1", () => {
    expect(r.messageControlId).toBe("W88800130-39");
    expect(r.orderStatus).toBe("final");
    expect(r.collectionDate).toBe("2025-12-31");
    expect(r.collectionDateTime).toBe("2025-12-31T00:00:00");
  });

  it("captures the kit label (label de Trak) from SPM.2.1", () => {
    expect(r.kitLabelCode).toBe("Z000010X");
  });

  it("parses NM rows with ECH code, LOINC at OBX-3.4 and unit at OBX-6.2", () => {
    expect(r.biomarkers).toHaveLength(3);
    expect(r.biomarkers[0]).toMatchObject({
      biomarker_key: "D0590",
      value: 50,
      unit: "pg/mL",
      loincCode: "2141-0",
      status: "final",
    });
    expect(r.biomarkers[1]).toMatchObject({ biomarker_key: "P0743", value: 0.11, unit: "KU/L", loincCode: "6844-5" });
    expect(r.biomarkers[2]).toMatchObject({ biomarker_key: "P2030", value: 0.01, unit: "mgA/L", loincCode: "56286-8" });
  });

  it("keeps TX conclusions as notes and extracts the base64 report PDF", () => {
    expect(r.textNotes?.map((n) => n.code)).toEqual(["P2082", "P2083"]);
    expect(r.reportPdfBase64).toBe("JVBERi0xLjQKJcfsj6I.......QolJUVPRgo=");
  });
});

describe("EX2 — RAST + catecolaminas (PARTIAL, A) with bounded value", () => {
  const r = EchevarneProvider.parseResults(ORU_EX2_RAST_PARTIAL);

  it("flags the order as partial from ORC.5=A", () => {
    expect(r.orderStatus).toBe("partial");
    expect(r.placerOrderNumber).toBe("0510101460");
    expect(r.providerReference).toBe("N00946463");
  });

  it("keeps the '<0,500' bounded value with its comparator (previously silently dropped)", () => {
    const bounded = r.biomarkers.find((b) => b.biomarker_key === "I1433");
    expect(bounded).toMatchObject({ value: 0.5, comparator: "<", unit: "U/mL", loincCode: "2345-7" });
  });

  it("parses the remaining numeric rows with EU comma decimals", () => {
    const byKey = Object.fromEntries(r.biomarkers.map((b) => [b.biomarker_key, b.value]));
    expect(byKey).toMatchObject({ B0313: 1350, T1634: 13.5, T1635: 69.5, T1636: 340.1 });
    expect(r.biomarkers).toHaveLength(5);
  });

  it("collects TX notes and the PDF; no SPM in this example → no kit label", () => {
    expect(r.textNotes?.map((n) => n.code)).toEqual(["I1434", "I1435", "T1690"]);
    expect(r.reportPdfBase64).toContain("JVBERi0xLjQ");
    expect(r.kitLabelCode).toBeUndefined();
  });
});

describe("EX3 — microbiología + antibiograma (all-TX)", () => {
  const r = EchevarneProvider.parseResults(ORU_EX3_MICRO);

  it("produces no numeric biomarkers (culture results are textual)", () => {
    expect(r.biomarkers).toHaveLength(0);
  });

  it("keeps germs, antibiogram letters (from OBX-6.2) and MIC bounds as notes", () => {
    const notes = r.textNotes ?? [];
    expect(notes.length).toBe(49);
    expect(notes.find((n) => n.code === "M9997")?.text).toBe("Corynebacterium striatum");
    // Antibiotic with empty OBX-5: the S/R letter rides OBX-6.2.
    expect(notes.find((n) => n.code === "PEN")?.text).toBe("R");
    // MIC bound kept as its raw text.
    expect(notes.find((n) => n.code === "AMP")?.text).toBe(">8,000");
  });

  it("still extracts label, ids and the PDF", () => {
    expect(r.kitLabelCode).toBe("Z000011J");
    expect(r.placerOrderNumber).toBe("20253967069");
    expect(r.providerReference).toBe("W88800151");
    expect(r.reportPdfBase64).toContain("JVBERi0xLjc");
  });
});

describe("ACK parsing (ECH answering our OML, spec §1.2.1)", () => {
  it("parses a CA ack and correlates via MSA-2", () => {
    const a = parseAck(ACK_OML_OK);
    expect(a.ok).toBe(true);
    expect(a.code).toBe("CA");
    expect(a.ackedMessageControlId).toBe("N00894051-93876");
    expect(a.messageControlId).toBe("251009");
  });

  it("parses a CE ack with the ERR code/description", () => {
    const a = parseAck(ACK_OML_ERROR);
    expect(a.ok).toBe(false);
    expect(a.code).toBe("CE");
    expect(a.errorCode).toBe("CODIGO_ERROR");
    expect(a.errorText).toBe("DESCRIPCIÓN_ERROR");
  });
});

describe("OML^O21 + ORU-ACK builders (identity via env, spec §1.1 / §1.4.1)", () => {
  beforeEach(() => {
    process.env.ECH_MSH_SENDING_APP = "EVAHEALTH";
    process.env.ECH_MSH_SENDING_FACILITY = "EVA001";
  });
  afterEach(() => {
    delete process.env.ECH_MSH_SENDING_APP;
    delete process.env.ECH_MSH_SENDING_FACILITY;
  });

  const baseInput = {
    messageControlId: "EVA-2026-000123-1",
    messageDateTime: "20260825120000",
    processingId: "T" as const,
    placerOrderNumber: "EVA000123001",
    requestDateTime: "20260825115900",
    extractionDateTime: "20260825083000",
    labPetitionNumber: "X68800190",
    patient: {
      document: { type: "DNI" as const, number: "12345678Z" },
      nhc: "EVA000123",
      firstName: "JOSEFA",
      surname1: "GARCIA",
      surname2: "RODRIGUEZ",
      birthDate: "19890127",
      sex: "F" as const,
      phones: ["931478526"],
      languageCode: "8",
    },
    tests: [{ code: "B5000", description: "Panel EVA base" }],
  };

  it("builds an OML with the spec's MSH shape and one ORC/OBR/SPM/BLG block per test", () => {
    const oml = buildOml(baseInput);
    const lines = oml.split("\r");
    expect(lines[0]).toBe(
      "MSH|^~\\&|EVAHEALTH|EVA001|LABTRAK|ECHEVARNE|20260825120000||OML^O21|EVA-2026-000123-1|T|2.5|||AL|||UTF-8",
    );
    expect(lines[1]).toContain("PID|1||12345678Z^^^^DNI~EVA000123^^^^NHC||GARCIA^JOSEFA|RODRIGUEZ|19890127|F");
    expect(lines.filter((l) => l.startsWith("ORC|NW|EVA000123001"))).toHaveLength(1);
    expect(lines.filter((l) => l.startsWith("BLG"))).toHaveLength(1);
    // ORC.15 (extraction) is REQUIRED: field 15 of the ORC segment.
    const orc = lines.find((l) => l.startsWith("ORC|"))!;
    expect(orc.split("|")[15]).toBe("20260825083000");
    // ECH petition number (sticker) in ORC-3.1 and OBR-3.1 — component 1, nothing in 3.3.
    expect(orc.split("|")[3]).toBe("X68800190");
    const obr = lines.find((l) => l.startsWith("OBR|"))!;
    expect(obr.split("|")[3]).toBe("X68800190");
    // ORC-10 = ECH's fixed sender codes, exactly as Joan wrote them (2026-09-07).
    expect(orc.split("|")[10]).toBe("^^^^^^^^23502^^^^^23502^^^^^^^^23502^01");
    // SPM-2 empty by ECH instruction; SPM-17 carries the extraction date.
    const spm = lines.find((l) => l.startsWith("SPM|"))!;
    // Same slot as Joan's example (2026-09-07) and spec §1.1.2.7: 19 fields, date last.
    expect(spm.split("|")).toHaveLength(19);
    expect(spm.split("|")[18]).toBe("20260825083000");
  });

  it("carries the prescriber in ORC-12 and OBR-16 when given, and rejects hyphenated/long ids", () => {
    const oml = buildOml({
      ...baseInput,
      prescriber: { collegiateNumber: "080812345", surnames: "LOPEZ GARCIA", givenName: "MARIA" },
    });
    const lines = oml.split("\r");
    expect(lines.find((l) => l.startsWith("ORC|"))!.split("|")[12]).toBe("080812345^LOPEZ GARCIA^MARIA");
    expect(lines.find((l) => l.startsWith("OBR|"))!.split("|")[16]).toBe("080812345^LOPEZ GARCIA^MARIA");
    expect(() => buildOml({ ...baseInput, placerOrderNumber: "EVA-2026-000123" })).toThrow(/alphanumeric/);
    expect(() => buildOml({ ...baseInput, patient: { ...baseInput.patient, nhc: "EVA-0A1B" } })).toThrow(/alphanumeric/);
    expect(() => buildOml({ ...baseInput, labPetitionNumber: "" })).toThrow(/labPetitionNumber/);
  });

  it("refuses to build without the ECH-assigned identity or required fields", () => {
    delete process.env.ECH_MSH_SENDING_APP;
    expect(() => buildOml(baseInput)).toThrow(/ECH_MSH_SENDING_APP/);
    process.env.ECH_MSH_SENDING_APP = "EVAHEALTH";
    expect(() => buildOml({ ...baseInput, extractionDateTime: "" })).toThrow(/extractionDateTime/);
  });

  it("a patient with a single surname goes out with PID-6 empty (ECH: not mandatory), never invented", () => {
    const oml = buildOml({ ...baseInput, patient: { ...baseInput.patient, surname2: "" } });
    const pid = oml.split("\r").find((s) => s.startsWith("PID"))!.split("|");
    expect(pid[5]).toBe("GARCIA^JOSEFA"); // PID-5 intact
    expect(pid[6]).toBe(""); // PID-6 empty, not a repeat of the first surname
  });

  it("PID-3 carries the identity document then eva's NHC, as two repetitions (ECH example 2026-08-31)", () => {
    const pid = buildOml(baseInput).split("\r").find((l) => l.startsWith("PID|"))!;
    expect(pid.split("|")[3]).toBe("12345678Z^^^^DNI~EVA000123^^^^NHC");
  });

  it("refuses to build without a categorized document or without the NHC", () => {
    expect(() =>
      buildOml({ ...baseInput, patient: { ...baseInput.patient, document: { type: "DNI", number: "" } } }),
    ).toThrow(/patient\.document/);
    expect(() => buildOml({ ...baseInput, patient: { ...baseInput.patient, nhc: "" } })).toThrow(/nhc/);
  });

  it("escapes HL7 delimiters in free-text values", () => {
    const oml = buildOml({
      ...baseInput,
      patient: { ...baseInput.patient, surname1: "GARCIA|LOPEZ^X" },
    });
    expect(oml).toContain("GARCIA\\F\\LOPEZ\\S\\X");
  });

  it("builds a CA ORU-ack that our own parser round-trips", () => {
    const ack = buildOruAck({
      messageControlId: "ACK-1",
      messageDateTime: "20260825120500",
      processingId: "T",
      ackedMessageControlId: "W88800130-39",
      ok: true,
    });
    expect(ack.split("\r")[1]).toBe("MSA|CA|W88800130-39");
    const parsed = parseAck(ack);
    expect(parsed.ok).toBe(true);
    expect(parsed.ackedMessageControlId).toBe("W88800130-39");
  });

  it("builds a CE ORU-ack carrying the ERR code", () => {
    const ack = buildOruAck({
      messageControlId: "ACK-2",
      messageDateTime: "20260825120500",
      processingId: "T",
      ackedMessageControlId: "W88800130-39",
      ok: false,
      errorCode: "UNMATCHED_ORDER",
      errorText: "Placer order not found",
    });
    const parsed = parseAck(ack);
    expect(parsed.ok).toBe(false);
    expect(parsed.errorCode).toBe("UNMATCHED_ORDER");
  });
});

describe("ECH_CODE_TO_BIOMARKER — real catalog map (2026-08-25)", () => {
  const map = (code: string, loinc?: string) =>
    EchevarneProvider.mapBiomarkerName(code, loinc);

  it("maps core panel result codes to verbatim biomarker_references slugs", () => {
    expect(map("B0000")).toBe("glucose_fasting");
    expect(map("B0031")).toBe("hba1c");
    expect(map("B0001")).toBe("total_cholesterol");
    expect(map("B0017")).toBe("hdl_cholesterol");
    expect(map("B0018")).toBe("ldl_cholesterol");
    expect(map("B0004")).toBe("triglycerides");
    expect(map("B0851")).toBe("hs_crp");
    expect(map("D0012")).toBe("tsh");
    expect(map("D0282")).toBe("vitamin_d_25_oh");
    expect(map("D0021")).toBe("ferritin");
    expect(map("B1381")).toBe("lipoproteina");
  });

  it("maps hemogram H-codes including Spanish acronyms (IDH→rdw, VPM→mpv)", () => {
    expect(map("H0004")).toBe("hemoglobin");
    expect(map("H0006")).toBe("rdw");
    expect(map("H0042")).toBe("mpv");
    expect(map("H0137")).toBe("neutrophils");
    expect(map("H0138")).toBe("neutrophils_absolute");
  });

  it("strips OBX-3 components before lookup", () => {
    expect(map("B0000^Glucosa / suero^ECH")).toBe("glucose_fasting");
  });

  it("keeps deliberately-unmapped codes unmapped (no invented keys)", () => {
    expect(map("T0603")).toBe(""); // (C22:5) — ambiguous n-3/n-6, pending ECH
    expect(map("D0027")).toBe(""); // folate — no eva reference range yet
    expect(map("B1001")).toBe(""); // "PEG" text comment
  });

  it("falls back to LOINC only when the ECH code is unknown", () => {
    expect(map("ZZZ9", "2345-7")).toBe("glucose_fasting");
    expect(map("B0017", "2345-7")).toBe("hdl_cholesterol");
  });
});

describe("HBA1 comes back as a pair — one hba1c row, not two", () => {
  const head =
    "MSH|^~\\&|LABTRAK|ECHEVARNE|EVAHEALTH|EVAHEALTH|20260917030000||ORU^R01|X68800199-1|T|2.5\r" +
    "PID|1||00000000T^^^^DNI~EVA000001^^^^NHC||GARCIA^JOSEFA|RODRIGUEZ|19890127|F\r" +
    "ORC|RE|EVA000001001|X68800199||CM\r" +
    "OBR|1|EVA000001001|X68800199|HBA1^HEMOGLOBINA A1 C\r";
  const pct = "OBX|1|NM|B0031^HEMOGLOBINA GLICOSILADA (A1C)||11,000|^%|4,300-6,100|H|||F\r";
  const ifcc = "OBX|2|NM|B0826^HEMOGLOBINA GLICOSILADA||97,000|^mmol/mol|23,000-43,000|H|||F\r";

  it("keeps only the % row (B0031) when both arrive — the case in training ORU X68800192", () => {
    const r = EchevarneProvider.parseResults(head + pct + ifcc);
    expect(r.biomarkers.map((b) => b.biomarker_key)).toEqual(["B0031"]);
    expect(r.biomarkers[0]).toMatchObject({ value: 11, unit: "%" });
  });

  it("keeps the IFCC row when it comes alone — downstream converts mmol/mol to %", () => {
    const r = EchevarneProvider.parseResults(head + ifcc);
    expect(r.biomarkers.map((b) => b.biomarker_key)).toEqual(["B0826"]);
    expect(r.biomarkers[0]).toMatchObject({ value: 97, unit: "mmol/mol" });
  });
});
