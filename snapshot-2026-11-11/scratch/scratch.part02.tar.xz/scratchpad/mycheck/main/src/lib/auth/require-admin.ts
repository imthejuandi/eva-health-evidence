import type { User } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Shared admin authorization (SEC-003).
 *
 * Replaces the plaintext ADMIN_EMAILS string match that was duplicated across
 * the admin layout and admin API routes. A single source of truth so the four
 * call sites cannot drift.
 *
 * Authorization model:
 *  - The authoritative gate is `profiles.is_admin = true`.
 *  - ADMIN_EMAILS is kept ONLY as a bootstrap seed so the very first admins can
 *    sign in before any row has been flagged (and as defense-in-depth alongside
 *    the edge pre-check in proxy.ts).
 *
 * Resilience: the `is_admin` column is added by migration
 * 20260603110000_admin_role_and_audit_log.sql. Until that migration is applied
 * the column does not exist and the select errors. We swallow that error and
 * fall back to the ADMIN_EMAILS check, so admin access keeps working before the
 * migration lands.
 *
 * MFA (SEC-003): admin access also enforces the Supabase Auth assurance level
 * (AAL2). Fails safe — an admin who has ENROLLED a second factor (nextLevel
 * 'aal2') must have stepped up this session (currentLevel 'aal2'), else access is
 * denied; this closes the gap where enrolled MFA was ignored by the code. Setting
 * ADMIN_REQUIRE_MFA=true additionally requires every admin to have completed AAL2
 * (full mandate), left OFF by default so the bootstrap admin is not locked out
 * before enrolling. The operator action (enable + enrol MFA in Supabase Auth)
 * remains gated; this is the code half.
 */

function bootstrapAdminEmails(): string[] {
  return (process.env.ADMIN_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

function isBootstrapAdmin(email: string | undefined | null): boolean {
  if (!email) return false;
  return bootstrapAdminEmails().includes(email.toLowerCase());
}

/**
 * Returns the authenticated user when they are an admin AND satisfy the MFA
 * assurance policy, otherwise null.
 *
 * Admin IF the user's email is in ADMIN_EMAILS (bootstrap seed) OR their profile
 * row has is_admin = true. Either way, the MFA assurance gate must also pass.
 */
export async function requireAdmin(): Promise<User | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const admin = isBootstrapAdmin(user.email) || (await isDbAdmin(supabase, user.id));
  if (!admin) return null;

  // SEC-003 — enforce the MFA assurance level for admins (fails safe; see note).
  if (!(await adminMfaSatisfied(supabase))) return null;

  return user;
}

type ServerClient = Awaited<ReturnType<typeof createClient>>;

/**
 * Authoritative DB-backed admin check. Defensive: a missing column (before the
 * 20260603110000 migration is applied) or a missing row is treated as "not a DB
 * admin" rather than throwing — the bootstrap seed keeps the first admins in.
 */
async function isDbAdmin(supabase: ServerClient, userId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("is_admin")
      .eq("id", userId)
      .single();
    if (error) return false;
    return (data as { is_admin?: boolean } | null)?.is_admin === true;
  } catch {
    return false;
  }
}

/**
 * SEC-003 — enforce Supabase Auth assurance level (AAL2) for admins.
 *  - Enrolled-but-not-stepped-up (nextLevel 'aal2', currentLevel !== 'aal2') → block.
 *  - ADMIN_REQUIRE_MFA=true → additionally require currentLevel 'aal2' outright.
 * Fails safe: if the level cannot be read, only block when MFA is hard-required.
 */
async function adminMfaSatisfied(supabase: ServerClient): Promise<boolean> {
  const hardRequire = process.env.ADMIN_REQUIRE_MFA === "true";
  try {
    const { data, error } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
    if (error || !data) return !hardRequire;
    const { currentLevel, nextLevel } = data;
    if (nextLevel === "aal2" && currentLevel !== "aal2") return false; // enrolled → must step up
    if (hardRequire && currentLevel !== "aal2") return false; // full mandate
    return true;
  } catch {
    return !hardRequire;
  }
}

export interface LogAdminActionParams {
  /** The acting admin (as returned by requireAdmin()). */
  actor: User;
  /** Stable action identifier, e.g. "enter_results", "reprocess", "update_booking". */
  action: string;
  /** The user the action acted upon, when applicable. */
  targetUserId?: string | null;
  /** Free-form identifier of the affected resource (lab result id, booking id, ...). */
  targetId?: string | null;
  /** Optional structured context for the action. */
  detail?: Record<string, unknown> | null;
}

/**
 * Append a row to public.admin_audit_log via the service-role client.
 *
 * Best-effort and fully non-blocking: it must NEVER throw or fail the request.
 * Any error (missing service-role key, missing table pre-migration, network) is
 * caught and logged so the audit trail can never break an admin mutation.
 */
export async function logAdminAction({
  actor,
  action,
  targetUserId = null,
  targetId = null,
  detail = null,
}: LogAdminActionParams): Promise<void> {
  try {
    const admin = createAdminClient();
    if (!admin) {
      console.error("[logAdminAction] service-role client unavailable; skipping audit log for", action);
      return;
    }

    const { error } = await admin.from("admin_audit_log").insert({
      actor_id: actor.id,
      actor_email: actor.email ?? null,
      action,
      target_user_id: targetUserId,
      target_id: targetId,
      detail,
    });

    if (error) {
      console.error("[logAdminAction] failed to write audit log:", error.message);
    }
  } catch (e) {
    console.error("[logAdminAction] unexpected error writing audit log:", e);
  }
}
