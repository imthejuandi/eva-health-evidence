/**
 * Unit tests for requireAdmin() — the admin authz gate + the SEC-003 MFA (AAL2)
 * enforcement. The Supabase server/admin clients are mocked so we can exercise
 * the bootstrap-vs-DB admin paths and every MFA branch deterministically.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const getUser = vi.fn();
const single = vi.fn();
const getAAL = vi.fn();

function makeClient() {
  return {
    auth: {
      getUser,
      mfa: { getAuthenticatorAssuranceLevel: getAAL },
    },
    from: () => ({ select: () => ({ eq: () => ({ single }) }) }),
  };
}

vi.mock("@/lib/supabase/server", () => ({
  createClient: vi.fn(async () => makeClient()),
}));
vi.mock("@/lib/supabase/admin", () => ({
  createAdminClient: vi.fn(() => null),
}));

import { requireAdmin } from "./require-admin";

const ADMIN_EMAIL = "admin@evahealth.es";
const u = (email: string = ADMIN_EMAIL) => ({ id: "u1", email });

beforeEach(() => {
  vi.clearAllMocks();
  process.env.ADMIN_EMAILS = ADMIN_EMAIL;
  delete process.env.ADMIN_REQUIRE_MFA;
  // Default: no MFA factor enrolled (aal1 / nextLevel aal1).
  getAAL.mockResolvedValue({ data: { currentLevel: "aal1", nextLevel: "aal1" }, error: null });
  single.mockResolvedValue({ data: { is_admin: false }, error: null });
});

describe("requireAdmin", () => {
  it("returns null when unauthenticated", async () => {
    getUser.mockResolvedValue({ data: { user: null } });
    expect(await requireAdmin()).toBeNull();
  });

  it("allows a bootstrap admin (ADMIN_EMAILS) with no MFA enrolled", async () => {
    getUser.mockResolvedValue({ data: { user: u() } });
    expect(await requireAdmin()).toMatchObject({ id: "u1" });
  });

  it("allows a DB admin (is_admin=true) not in ADMIN_EMAILS", async () => {
    process.env.ADMIN_EMAILS = "";
    getUser.mockResolvedValue({ data: { user: u("db@evahealth.es") } });
    single.mockResolvedValue({ data: { is_admin: true }, error: null });
    expect(await requireAdmin()).toMatchObject({ id: "u1" });
  });

  it("rejects a non-admin (not listed, is_admin=false)", async () => {
    process.env.ADMIN_EMAILS = "";
    getUser.mockResolvedValue({ data: { user: u("nobody@evahealth.es") } });
    expect(await requireAdmin()).toBeNull();
  });

  it("blocks an admin who enrolled MFA but has not stepped up (currentLevel aal1, nextLevel aal2)", async () => {
    getUser.mockResolvedValue({ data: { user: u() } });
    getAAL.mockResolvedValue({ data: { currentLevel: "aal1", nextLevel: "aal2" }, error: null });
    expect(await requireAdmin()).toBeNull();
  });

  it("allows an admin who has stepped up to aal2", async () => {
    getUser.mockResolvedValue({ data: { user: u() } });
    getAAL.mockResolvedValue({ data: { currentLevel: "aal2", nextLevel: "aal2" }, error: null });
    expect(await requireAdmin()).toMatchObject({ id: "u1" });
  });

  it("with ADMIN_REQUIRE_MFA=true, blocks an admin who has not completed aal2", async () => {
    process.env.ADMIN_REQUIRE_MFA = "true";
    getUser.mockResolvedValue({ data: { user: u() } });
    getAAL.mockResolvedValue({ data: { currentLevel: "aal1", nextLevel: "aal1" }, error: null });
    expect(await requireAdmin()).toBeNull();
  });

  it("fails safe (allows) when the AAL cannot be read and MFA is not hard-required", async () => {
    getUser.mockResolvedValue({ data: { user: u() } });
    getAAL.mockResolvedValue({ data: null, error: { message: "unavailable" } });
    expect(await requireAdmin()).toMatchObject({ id: "u1" });
  });
});
