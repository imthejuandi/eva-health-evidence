export interface SampleReceivedData {
  firstName: string;
  panelName: string;
  locale: string;
}

export function renderSampleReceived(data: SampleReceivedData, locale: string): string {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
  const dashboardUrl = `${appUrl}/${locale}/book`;

  if (locale === "es") {
    return `
      <h1>Hemos recibido tu muestra, ${data.firstName}</h1>
      <div style="margin: 20px 0;">
        <span class="stat">${data.panelName}</span>
      </div>
      <p>Tu muestra ha llegado al laboratorio. El analisis empieza ya.</p>
      <hr class="divider">
      <p style="font-weight: 700; margin-bottom: 8px;">Que sigue:</p>
      <ol style="padding-left: 20px;">
        <li style="margin-bottom: 6px;">Procesado clinico (5-7 dias habiles)</li>
        <li style="margin-bottom: 6px;">Analisis de resultados frente a rangos optimos EVA</li>
        <li style="margin-bottom: 6px;">Te avisamos en cuanto esten listos</li>
      </ol>
      <a href="${dashboardUrl}" class="cta">Ver el estado</a>
    `;
  }
  return `
    <h1>We've received your sample, ${data.firstName}</h1>
    <div style="margin: 20px 0;">
      <span class="stat">${data.panelName}</span>
    </div>
    <p>Your sample has arrived at the lab. Processing starts now.</p>
    <hr class="divider">
    <p style="font-weight: 700; margin-bottom: 8px;">What's next:</p>
    <ol style="padding-left: 20px;">
      <li style="margin-bottom: 6px;">Clinical processing (5-7 business days)</li>
      <li style="margin-bottom: 6px;">Analysis against EVA's optimal ranges</li>
      <li style="margin-bottom: 6px;">We'll email you the moment results are ready</li>
    </ol>
    <a href="${dashboardUrl}" class="cta">Track my kit</a>
  `;
}
