/**
 * Guards the optional-client contract used by the admin/service paths:
 * when a (service-role) client is injected, the query helpers use it and do
 * NOT fall back to the RLS-bound server client; when none is given, they do.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

const { createClientMock } = vi.hoisted(() => ({ createClientMock: vi.fn() }));
vi.mock("@/lib/supabase/server", () => ({ createClient: createClientMock }));

import { getUserProfile } from "./index";

function fakeClient(row: unknown) {
  const res = Promise.resolve({ data: row, error: null });
  const chain = { select: () => chain, eq: () => chain, single: () => res };
  return { from: vi.fn(() => chain) };
}

beforeEach(() => {
  createClientMock.mockReset();
  createClientMock.mockResolvedValue(fakeClient({ id: "rls-user" }));
});

describe("query helpers — optional client threading", () => {
  it("uses the injected client and does NOT create an RLS client", async () => {
    const injected = fakeClient({ id: "admin-target" });
    const profile = await getUserProfile("u1", injected as never);
    expect(injected.from).toHaveBeenCalledWith("profiles");
    expect(createClientMock).not.toHaveBeenCalled();
    expect(profile).toEqual({ id: "admin-target" });
  });

  it("falls back to the RLS server client when no client is injected", async () => {
    await getUserProfile("u1");
    expect(createClientMock).toHaveBeenCalledTimes(1);
  });
});
