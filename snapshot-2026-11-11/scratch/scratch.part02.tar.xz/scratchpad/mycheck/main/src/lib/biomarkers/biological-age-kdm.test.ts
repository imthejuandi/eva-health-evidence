/**
 * Unit tests for biological-age-kdm.ts.
 *
 * These tests cover the core joint estimator math (B.5). Sex stratification,
 * Spanish recalibration, log transforms, and gating are tested in later
 * commits as they're implemented.
 *
 * Run: `npx vitest run src/lib/biomarkers/biological-age-kdm.test.ts`
 */
import { describe, it, expect } from "vitest";
import {
  BASE_PANEL,
  MIN_BASE_PANEL_MARKERS,
  computeComprehensiveBA,
  computeReferenceBA,
  deriveFructosamineIfMissing,
  FRUCTOSAMINE_KDM_KEY,
  HBA1C_KDM_KEY,
  klemeraDoubalBa,
  passesKdmGate,
  resolveMarkerParams,
  resolveMarkerParamsWithRecalibration,
  resolveSCa,
  resolveSpanishRecalibratedQ,
  type KdmLibraryMarker,
  type KdmMarkerParams,
} from "./biological-age-kdm";
import library from "./data/marker_library_v2_2.json";

describe("klemeraDoubalBa — core math (B.5)", () => {
  // Hand-calculable single-marker case:
  //   k = 0.05  (1 unit Δvalue ⇒ 20 years CA)
  //   q = 5.0   (population mean at age 50)
  //   s = 1.0
  //   x = 6.0  ⇒ (x − q) = 1.0
  //   k / s² = 0.05
  //   num   = 1.0 · 0.05      = 0.050
  //   denom = (k/s)² = (0.05)² = 0.0025
  //   BA_E  = 0.050 / 0.0025  = 20.0
  //   s_BA² = 1 / 0.0025      = 400          ⇒ s_BA = 20.0
  //
  //   With CA-anchor, CA=50, s_ca=10 (so s_ca²=100):
  //   BA = (BA_E / s_BA² + CA / s_ca²) / (1 / s_BA² + 1 / s_ca²)
  //      = (20/400 + 50/100) / (1/400 + 1/100)
  //      = (0.05 + 0.5) / (0.0025 + 0.01)
  //      = 0.55 / 0.0125
  //      = 44.0
  it("matches hand-calculated values for a single-marker case", () => {
    const values = { TestMarker: 6.0 };
    const params: Record<string, KdmMarkerParams> = {
      TestMarker: { k: 0.05, q: 5.0, s: 1.0 },
    };
    const result = klemeraDoubalBa(
      values,
      params,
      50,
      true, // useCaAnchor
      { pooled: 10.0 },
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.BA_E).toBeCloseTo(20.0, 6);
    expect(result!.s_BA).toBeCloseTo(20.0, 6);
    expect(result!.BA).toBeCloseTo(44.0, 6);
    expect(result!.n_markers_used).toBe(1);
    expect(result!.used_markers).toEqual(["TestMarker"]);
  });

  it("returns BA = BA_E when useCaAnchor=false", () => {
    const result = klemeraDoubalBa(
      { TestMarker: 6.0 },
      { TestMarker: { k: 0.05, q: 5.0, s: 1.0 } },
      50,
      false,
      {},
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.BA).toBeCloseTo(result!.BA_E, 6);
    expect(result!.BA).toBeCloseTo(20.0, 6);
  });

  it("returns null when no marker contributed", () => {
    expect(
      klemeraDoubalBa({}, {}, 50, true, { pooled: 10.0 }, "male"),
    ).toBeNull();

    // Marker supplied but no params registered
    expect(
      klemeraDoubalBa(
        { Albúmina: 4.0 },
        {},
        50,
        true,
        { pooled: 10.0 },
        "male",
      ),
    ).toBeNull();
  });

  it("skips markers with non-finite values, zero s, or NaN params", () => {
    const params: Record<string, KdmMarkerParams> = {
      M1: { k: 0.05, q: 5.0, s: 1.0 },
      M2: { k: 0.05, q: 5.0, s: 0 }, // zero s → skip
      M3: { k: NaN, q: 5.0, s: 1.0 }, // NaN k → skip
      M4: { k: 0.05, q: 5.0, s: 1.0 },
    };
    const result = klemeraDoubalBa(
      {
        M1: 6.0,
        M2: 6.0,
        M3: 6.0,
        M4: NaN, // non-finite value → skip
        M5: 6.0, // no params → skip
      },
      params,
      50,
      false,
      {},
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.n_markers_used).toBe(1);
    expect(result!.used_markers).toEqual(["M1"]);
  });

  it("applies natural log when log_transformed=true", () => {
    // For log-transformed marker: v = ln(value)
    // With value=e (≈ 2.718), ln(value) = 1
    // q = 0, k = 1, s = 1  ⇒ (v − q) = 1, k/s² = 1, (k/s)² = 1
    // BA_E = 1 / 1 = 1
    const result = klemeraDoubalBa(
      { LogMarker: Math.E },
      { LogMarker: { k: 1, q: 0, s: 1, log_transformed: true } },
      50,
      false,
      {},
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.BA_E).toBeCloseTo(1.0, 6);
  });

  it("skips log-transformed markers with value <= 0", () => {
    const result = klemeraDoubalBa(
      { LogMarker: -1, GoodMarker: 6 },
      {
        LogMarker: { k: 1, q: 0, s: 1, log_transformed: true },
        GoodMarker: { k: 0.05, q: 5.0, s: 1.0 },
      },
      50,
      false,
      {},
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.used_markers).toEqual(["GoodMarker"]);
  });

  it("prefers sex-specific s_ca when available", () => {
    // Same inputs as the hand-calc test, but supply sex-specific s_ca.
    // Verify the male s_ca is used (not pooled).
    const valuesM = { TestMarker: 6.0 };
    const params: Record<string, KdmMarkerParams> = {
      TestMarker: { k: 0.05, q: 5.0, s: 1.0 },
    };
    // male s_ca = 5 (instead of pooled 10) → BA shrinks harder toward CA
    // s_ca² = 25, so:
    //   BA = (20/400 + 50/25) / (1/400 + 1/25)
    //      = (0.05 + 2.0) / (0.0025 + 0.04)
    //      = 2.05 / 0.0425
    //      = 48.235...
    const result = klemeraDoubalBa(
      valuesM,
      params,
      50,
      true,
      { male: 5, female: 15, pooled: 10 },
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.BA).toBeCloseTo(48.235294, 4);
  });

  it("falls back to pooled s_ca when sex-specific missing", () => {
    const params: Record<string, KdmMarkerParams> = {
      TestMarker: { k: 0.05, q: 5.0, s: 1.0 },
    };
    const result = klemeraDoubalBa(
      { TestMarker: 6.0 },
      params,
      50,
      true,
      { pooled: 10.0 }, // sex-specific absent
      "female",
    );
    expect(result).not.toBeNull();
    expect(result!.BA).toBeCloseTo(44.0, 6); // same as hand-calc
  });

  it("falls back to s_ca = 10 when nothing is provided", () => {
    const params: Record<string, KdmMarkerParams> = {
      TestMarker: { k: 0.05, q: 5.0, s: 1.0 },
    };
    const result = klemeraDoubalBa(
      { TestMarker: 6.0 },
      params,
      50,
      true,
      {}, // empty → default 10.0
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.BA).toBeCloseTo(44.0, 6);
  });

  it("multi-marker case sums contributions correctly", () => {
    // Two identical markers ⇒ doubled denom, same BA_E, halved s_BA².
    //   num = 2 × (1 × 0.05) = 0.1
    //   denom = 2 × 0.0025  = 0.005
    //   BA_E = 0.1 / 0.005 = 20.0   (same as single marker)
    //   s_BA² = 1 / 0.005 = 200    ⇒ s_BA ≈ 14.14
    const result = klemeraDoubalBa(
      { M1: 6.0, M2: 6.0 },
      {
        M1: { k: 0.05, q: 5.0, s: 1.0 },
        M2: { k: 0.05, q: 5.0, s: 1.0 },
      },
      50,
      false,
      {},
      "male",
    );
    expect(result).not.toBeNull();
    expect(result!.BA_E).toBeCloseTo(20.0, 6);
    expect(result!.s_BA).toBeCloseTo(Math.sqrt(200), 4);
    expect(result!.n_markers_used).toBe(2);
  });
});

describe("resolveMarkerParams — sex-aware lookup (B.6)", () => {
  it("picks kqs_M for sex-stratified marker when sex=male", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: true,
      kqs_M: { k: 0.01, q: 5.0, s: 1.0 },
      kqs_F: { k: 0.03, q: 3.5, s: 1.2 },
    };
    const p = resolveMarkerParams(entry, "male");
    expect(p).not.toBeNull();
    expect(p!.k).toBe(0.01);
    expect(p!.q).toBe(5.0);
    expect(p!.s).toBe(1.0);
  });

  it("picks kqs_F for sex-stratified marker when sex=female", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: true,
      kqs_M: { k: 0.01, q: 5.0, s: 1.0 },
      kqs_F: { k: 0.03, q: 3.5, s: 1.2 },
    };
    const p = resolveMarkerParams(entry, "female");
    expect(p!.k).toBe(0.03);
    expect(p!.q).toBe(3.5);
    expect(p!.s).toBe(1.2);
  });

  it("picks pooled kqs when sex_stratified is false", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: false,
      kqs: { k: 0.02, q: 4.0, s: 0.5 },
      kqs_M: { k: 999, q: 999, s: 999 }, // should be ignored
    };
    const p = resolveMarkerParams(entry, "male");
    expect(p!.k).toBe(0.02);
  });

  it("returns null when the chosen block is missing", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: true,
      kqs_M: null,
      kqs_F: { k: 0.03, q: 3.5, s: 1.2 },
    };
    expect(resolveMarkerParams(entry, "male")).toBeNull();
    expect(resolveMarkerParams(entry, "female")).not.toBeNull();
  });

  it("returns null when s is non-positive or NaN", () => {
    expect(
      resolveMarkerParams(
        { sex_stratified: false, kqs: { k: 0.1, q: 1, s: 0 } },
        "male",
      ),
    ).toBeNull();
    expect(
      resolveMarkerParams(
        { sex_stratified: false, kqs: { k: 0.1, q: 1, s: -1 } },
        "male",
      ),
    ).toBeNull();
    expect(
      resolveMarkerParams(
        { sex_stratified: false, kqs: { k: 0.1, q: 1, s: NaN } },
        "male",
      ),
    ).toBeNull();
  });

  it("propagates log_transformed flag from the library entry", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: false,
      kqs: { k: 0.1, q: 1, s: 0.5 },
      log_transformed: true,
    };
    const p = resolveMarkerParams(entry, "male");
    expect(p!.log_transformed).toBe(true);
  });
});

describe("KDM library integration: Uric Acid sex-stratification (B.6)", () => {
  // Uric Acid in the library is sex-stratified. Same input value (5.0 mg/dL)
  // should yield a different KDM BA contribution for males vs females because
  // their (k, q, s) tuples are very different (m: k=-0.0013, q=6.10; f: k=0.025, q=3.53).
  const uricEntry = (library as { markers: Record<string, KdmLibraryMarker> })
    .markers["Ácido Úrico"];

  it("library entry is sex-stratified", () => {
    expect(uricEntry.sex_stratified).toBe(true);
    expect(uricEntry.kqs_M).toBeTruthy();
    expect(uricEntry.kqs_F).toBeTruthy();
  });

  it("male vs female produce different (k, q, s)", () => {
    const pM = resolveMarkerParams(uricEntry, "male");
    const pF = resolveMarkerParams(uricEntry, "female");
    expect(pM!.k).not.toBeCloseTo(pF!.k, 4);
    expect(pM!.q).not.toBeCloseTo(pF!.q, 2);
  });

  it("same value produces different BA contribution for M vs F", () => {
    const pM = resolveMarkerParams(uricEntry, "male")!;
    const pF = resolveMarkerParams(uricEntry, "female")!;

    // CA=50, no anchor — pure BA_E to isolate marker-level effect
    const baM = klemeraDoubalBa(
      { uric: 5.0 },
      { uric: pM },
      50,
      false,
      {},
      "male",
    );
    const baF = klemeraDoubalBa(
      { uric: 5.0 },
      { uric: pF },
      50,
      false,
      {},
      "female",
    );
    expect(baM).not.toBeNull();
    expect(baF).not.toBeNull();
    // Different sex-specific (k, q) ⇒ different BA_E
    expect(baM!.BA_E).not.toBeCloseTo(baF!.BA_E, 0);
  });
});

describe("resolveSCa — per-tier s_ca lookup (B.6)", () => {
  it("returns Reference tier s_ca with all three keys present", () => {
    const s = resolveSCa("reference");
    expect(s.male).toBeCloseTo(24.678, 2);
    expect(s.female).toBeCloseTo(23.274, 2);
    expect(s.pooled).toBeCloseTo(23.977, 2);
  });

  it("returns Comprehensive tier s_ca with all three keys present", () => {
    const s = resolveSCa("comprehensive");
    expect(s.male).toBeCloseTo(14.003, 2);
    expect(s.female).toBeCloseTo(13.914, 2);
    expect(s.pooled).toBeCloseTo(14.106, 2);
  });

  it("Reference s_ca is wider than Comprehensive (less constrained → less shrinkage)", () => {
    const ref = resolveSCa("reference");
    const comp = resolveSCa("comprehensive");
    expect(ref.pooled).toBeGreaterThan(comp.pooled!);
  });
});

describe("resolveSpanishRecalibratedQ (B.7)", () => {
  it("returns q_spain for pooled recalibrated marker", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: false,
      spanish_recalibration: {
        calibration_status: "recalibrated_tier_1",
        q_spain: 71.73,
        q_NHANES: 87.57,
      } as KdmLibraryMarker["spanish_recalibration"],
    };
    expect(resolveSpanishRecalibratedQ(entry, "male")).toBeCloseTo(71.73, 4);
    expect(resolveSpanishRecalibratedQ(entry, "female")).toBeCloseTo(71.73, 4);
  });

  it("returns per-sex q_spain for sex-stratified marker when block present", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: true,
      spanish_recalibration: {
        calibration_status: "recalibrated_tier_2",
        per_sex: { M: { q_spain: 1.1 }, F: { q_spain: 0.9 } },
      },
    };
    expect(resolveSpanishRecalibratedQ(entry, "male")).toBeCloseTo(1.1, 4);
    expect(resolveSpanishRecalibratedQ(entry, "female")).toBeCloseTo(0.9, 4);
  });

  it("returns null when calibration_status is not recalibrated_*", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: false,
      spanish_recalibration: {
        calibration_status: "unrecalibrated",
        q_spain: 50,
      } as KdmLibraryMarker["spanish_recalibration"],
    };
    expect(resolveSpanishRecalibratedQ(entry, "male")).toBeNull();
  });

  it("returns null when block missing (sex-stratified library entry without per_sex)", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: true,
      spanish_recalibration: {
        calibration_status: "recalibrated_tier_2",
        // no per_sex
      },
    };
    expect(resolveSpanishRecalibratedQ(entry, "male")).toBeNull();
    expect(resolveSpanishRecalibratedQ(entry, "female")).toBeNull();
  });

  it("returns null when entry has no spanish_recalibration", () => {
    expect(resolveSpanishRecalibratedQ({}, "male")).toBeNull();
  });
});

describe("Log transform handling — hs-CRP end-to-end (B.8)", () => {
  // hs-CRP is log_transformed in the library (skewed distribution). For a
  // user value of 1.3 mg/L, the estimator should:
  //   1. Apply ln(1.3) ≈ 0.2624
  //   2. Compare to NHANES q (ln scale) = 0.2721
  //   3. (ln(1.3) − q) ≈ -0.0097  ⇒ very small contribution to BA_E
  //
  // The library hs-CRP entry uses k = 0.00752 and s = 1.207, log scale.
  const hsCrpEntry = (library as { markers: Record<string, KdmLibraryMarker> })
    .markers["PCR de Alta Sensibilidad (hs-PCR)"];

  it("library entry is log_transformed and not sex_stratified", () => {
    expect(hsCrpEntry.log_transformed).toBe(true);
    expect(hsCrpEntry.sex_stratified).toBe(false);
  });

  it("resolveMarkerParams propagates log_transformed=true", () => {
    const p = resolveMarkerParams(hsCrpEntry, "male");
    expect(p!.log_transformed).toBe(true);
  });

  it("estimator applies ln() before computing the deviation", () => {
    const p = resolveMarkerParams(hsCrpEntry, "male")!;
    // ln(1.3) ≈ 0.2624 — very close to q = 0.2721 (NHANES log-mean)
    // ⇒ (v − q) ≈ -0.0097
    // ⇒ BA_E = (v − q) / k = -0.0097 / 0.00752 ≈ -1.3 years
    const ba = klemeraDoubalBa(
      { "hs-CRP": 1.3 },
      { "hs-CRP": p },
      50,
      false,
      {},
      "male",
    );
    expect(ba).not.toBeNull();
    const expectedBaE = (Math.log(1.3) - p.q) / p.k;
    expect(ba!.BA_E).toBeCloseTo(expectedBaE, 4);
  });

  it("Spanish-recalibrated hs-CRP user at Spanish median ⇒ BA_E ≈ 0", () => {
    // Spanish median hs-CRP ≈ exp(0.0911609) ≈ 1.095 mg/L
    const r = resolveMarkerParamsWithRecalibration(hsCrpEntry, "male")!;
    expect(r.spanishRecalibrationApplied).toBe(true);

    const spanishMedian = Math.exp(r.params.q); // exp(q_spain)
    const ba = klemeraDoubalBa(
      { "hs-CRP": spanishMedian },
      { "hs-CRP": r.params },
      50,
      false,
      {},
      "male",
    );
    expect(ba!.BA_E).toBeCloseTo(0, 6);
  });

  it("rejects value ≤ 0 for log-transformed marker (already covered in B.5; sanity check with real entry)", () => {
    const p = resolveMarkerParams(hsCrpEntry, "male")!;
    const ba = klemeraDoubalBa(
      { "hs-CRP": 0 },
      { "hs-CRP": p },
      50,
      false,
      {},
      "male",
    );
    expect(ba).toBeNull(); // single-marker with skip ⇒ no contribution ⇒ null
  });
});

describe("resolveMarkerParamsWithRecalibration (B.7)", () => {
  it("swaps q to q_spain when available and flags applied=true", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: false,
      kqs: { k: 0.05, q: 88.0, s: 10.0 }, // NHANES q
      spanish_recalibration: {
        calibration_status: "recalibrated_tier_1",
        q_spain: 71.73,
      } as KdmLibraryMarker["spanish_recalibration"],
    };
    const r = resolveMarkerParamsWithRecalibration(entry, "male");
    expect(r).not.toBeNull();
    expect(r!.spanishRecalibrationApplied).toBe(true);
    expect(r!.params.q).toBeCloseTo(71.73, 4);
    expect(r!.params.k).toBe(0.05);
    expect(r!.params.s).toBe(10.0);
  });

  it("keeps NHANES q and flags applied=false when no q_spain", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: false,
      kqs: { k: 0.05, q: 88.0, s: 10.0 },
      spanish_recalibration: {
        calibration_status: "recalibrated_tier_2",
        // no q_spain
      } as KdmLibraryMarker["spanish_recalibration"],
    };
    const r = resolveMarkerParamsWithRecalibration(entry, "male");
    expect(r!.spanishRecalibrationApplied).toBe(false);
    expect(r!.params.q).toBe(88.0);
  });

  it("returns null when underlying params are unavailable", () => {
    const entry: KdmLibraryMarker = {
      sex_stratified: true,
      kqs_M: null,
      kqs_F: { k: 0.05, q: 5, s: 1 },
    };
    expect(resolveMarkerParamsWithRecalibration(entry, "male")).toBeNull();
    expect(
      resolveMarkerParamsWithRecalibration(entry, "female"),
    ).not.toBeNull();
  });

  it("returns BA ≈ CA for a Spanish-population-mean user (Glucose only)", () => {
    // Synthetic: user supplies only Glucosa (Ayunas) at the Spanish mean
    // (≈ 71.73 mg/dL). With Spanish recalibration applied, q_spain = 71.73,
    // so (value − q) ≈ 0 ⇒ BA_E ≈ 0. CA-anchored shrinkage then pulls BA
    // toward CA. The estimator's single-marker s_BA is large vs s_ca, so
    // BA should land very close to CA = 50.
    const glucose: KdmLibraryMarker = {
      sex_stratified: false,
      kqs: { k: 0.0086, q: 87.57, s: 10.0 }, // sample NHANES values
      log_transformed: false,
      spanish_recalibration: {
        calibration_status: "recalibrated_tier_1",
        q_spain: 71.73,
      } as KdmLibraryMarker["spanish_recalibration"],
    };
    const r = resolveMarkerParamsWithRecalibration(glucose, "male");
    expect(r!.spanishRecalibrationApplied).toBe(true);

    const ba = klemeraDoubalBa(
      { "Glucosa (Ayunas)": 71.73 }, // user at Spanish mean
      { "Glucosa (Ayunas)": r!.params },
      50,
      true,
      { pooled: 23.977 }, // Reference s_ca
      "male",
    );
    expect(ba).not.toBeNull();
    expect(ba!.BA_E).toBeCloseTo(0, 4); // value at q ⇒ contribution = 0
    // BA strongly pulled to CA via the CA anchor.
    expect(Math.abs(ba!.BA - 50)).toBeLessThan(1);
  });
});

describe("deriveFructosamineIfMissing — Cohen 2010 (B.9)", () => {
  it("computes Fructosamine = 19.97·HbA1c − 39.4 when missing", () => {
    const out = deriveFructosamineIfMissing({ [HBA1C_KDM_KEY]: 5.5 });
    // 19.97 × 5.5 − 39.4 = 109.835 − 39.4 = 70.435
    expect(out[FRUCTOSAMINE_KDM_KEY]).toBeCloseTo(70.435, 4);
  });

  it("matches the spec acceptance value (HbA1c=5.5% ⇒ Fructosamine ≈ 70.4)", () => {
    const out = deriveFructosamineIfMissing({ [HBA1C_KDM_KEY]: 5.5 });
    expect(out[FRUCTOSAMINE_KDM_KEY]).toBeCloseTo(70.4, 1);
  });

  it("preserves an existing measured Fructosamine value", () => {
    const out = deriveFructosamineIfMissing({
      [HBA1C_KDM_KEY]: 5.5,
      [FRUCTOSAMINE_KDM_KEY]: 200, // user-measured wins
    });
    expect(out[FRUCTOSAMINE_KDM_KEY]).toBe(200);
  });

  it("returns inputs unchanged when HbA1c is absent", () => {
    const inputs = { Albúmina: 4.4 };
    const out = deriveFructosamineIfMissing(inputs);
    expect(FRUCTOSAMINE_KDM_KEY in out).toBe(false);
  });

  it("returns inputs unchanged when HbA1c is non-finite", () => {
    expect(
      FRUCTOSAMINE_KDM_KEY in deriveFructosamineIfMissing({ [HBA1C_KDM_KEY]: NaN }),
    ).toBe(false);
    expect(
      FRUCTOSAMINE_KDM_KEY in
        deriveFructosamineIfMissing({ [HBA1C_KDM_KEY]: Infinity }),
    ).toBe(false);
  });

  it("derived Fructosamine contributes to BA when paired with library params", () => {
    // Smoke test: a single-marker BA using the real library Fructosamine
    // entry consumes the derived value cleanly.
    const fructEntry = (library as { markers: Record<string, KdmLibraryMarker> })
      .markers[FRUCTOSAMINE_KDM_KEY];
    expect(fructEntry).toBeDefined();
    const inputs = deriveFructosamineIfMissing({ [HBA1C_KDM_KEY]: 5.5 });
    const p = resolveMarkerParams(fructEntry, "male")!;
    const ba = klemeraDoubalBa(
      { [FRUCTOSAMINE_KDM_KEY]: inputs[FRUCTOSAMINE_KDM_KEY] },
      { [FRUCTOSAMINE_KDM_KEY]: p },
      50,
      false,
      {},
      "male",
    );
    expect(ba).not.toBeNull();
    expect(ba!.n_markers_used).toBe(1);
  });
});

describe("passesKdmGate (B.10)", () => {
  it("rejects when fewer than 8 base-panel markers present", () => {
    // 7 base markers including Alb + Crea — should fail
    const inputs: Record<string, number> = {
      Albúmina: 4.4,
      Creatinina: 0.9,
      "BUN (Nitrógeno Ureico en Sangre)": 14,
      "Ácido Úrico": 5.2,
      "Colesterol Total": 180,
      "Colesterol HDL": 55,
      Triglicéridos: 90,
    };
    expect(passesKdmGate(inputs)).toBe(false);
  });

  it("rejects when Albúmina is missing", () => {
    const inputs: Record<string, number> = {};
    for (const m of BASE_PANEL) inputs[m] = 1;
    delete inputs["Albúmina"];
    expect(passesKdmGate(inputs)).toBe(false);
  });

  it("rejects when Creatinina is missing", () => {
    const inputs: Record<string, number> = {};
    for (const m of BASE_PANEL) inputs[m] = 1;
    delete inputs["Creatinina"];
    expect(passesKdmGate(inputs)).toBe(false);
  });

  it("accepts when 8 base markers including Alb + Crea", () => {
    const inputs: Record<string, number> = {
      Albúmina: 4.4,
      Creatinina: 0.9,
      "BUN (Nitrógeno Ureico en Sangre)": 14,
      "Ácido Úrico": 5.2,
      "Colesterol Total": 180,
      "Colesterol HDL": 55,
      Triglicéridos: 90,
      "PCR de Alta Sensibilidad (hs-PCR)": 0.7,
    };
    expect(passesKdmGate(inputs)).toBe(true);
  });

  it("rejects non-finite mandatory values (NaN, Infinity)", () => {
    const inputs: Record<string, number> = {};
    for (const m of BASE_PANEL) inputs[m] = 1;
    inputs["Albúmina"] = NaN;
    expect(passesKdmGate(inputs)).toBe(false);
  });

  it("MIN_BASE_PANEL_MARKERS constant is 8 (Klemera-Doubal panel minimum)", () => {
    expect(MIN_BASE_PANEL_MARKERS).toBe(8);
  });
});

describe("computeReferenceBA — public API (B.10)", () => {
  // A realistic 8-marker base panel from the eva-health engine codes.
  // Values approximate a healthy mid-life male.
  const eightMarkerInputs = [
    { code: "ALBUMIN", value: 44 },
    { code: "CREATININE", value: 0.95 },
    { code: "blood_urea_nitrogen", value: 14 },
    { code: "URIC_ACID", value: 5.2 },
    { code: "total_cholesterol", value: 180 },
    { code: "HDL_C", value: 55 },
    { code: "TG", value: 90 },
    { code: "HSCRP", value: 0.7 },
  ];

  it("returns null when fewer than 8 base panel markers present", () => {
    const seven = eightMarkerInputs.slice(0, 7);
    expect(computeReferenceBA(seven, "male", 50)).toBeNull();
  });

  it("returns null when Albumin is missing even with 8+ other markers", () => {
    const noAlb = [...eightMarkerInputs.filter((b) => b.code !== "ALBUMIN")];
    // Add another to keep the marker count >= 8
    noAlb.push({ code: "ALP", value: 75 });
    noAlb.push({ code: "GGT", value: 18 });
    expect(computeReferenceBA(noAlb, "male", 50)).toBeNull();
  });

  it("returns a result when 8 base panel markers including Alb + Crea", () => {
    const result = computeReferenceBA(eightMarkerInputs, "male", 50);
    expect(result).not.toBeNull();
    expect(result!.n_markers_used).toBeGreaterThanOrEqual(7);
    expect(result!.BA).toBeGreaterThan(0);
    expect(result!.BA).toBeLessThan(120);
    expect(result!.used_markers.length).toBeGreaterThanOrEqual(7);
  });

  it("includes derived Fructosamine when HbA1c supplied", () => {
    const withHba1c = [
      ...eightMarkerInputs,
      { code: "HBA1C", value: 5.3 },
      { code: "VITD", value: 42 },
      { code: "TSH", value: 1.8 },
      { code: "FERRITIN", value: 80 },
    ];
    const result = computeReferenceBA(withHba1c, "male", 50);
    expect(result).not.toBeNull();
    // Fructosamine should appear in used_markers (derived from HbA1c)
    expect(result!.used_markers).toContain(FRUCTOSAMINE_KDM_KEY);
  });

  it("populates applied_spanish_recalibration_markers when q_spain swapped", () => {
    const withRecalMarkers = [
      ...eightMarkerInputs,
      { code: "VITD", value: 30 }, // pooled with q_spain
      { code: "TSH", value: 1.8 }, // pooled with q_spain
      { code: "FERRITIN", value: 80 },
    ];
    const result = computeReferenceBA(withRecalMarkers, "male", 50);
    expect(result).not.toBeNull();
    expect(
      result!.applied_spanish_recalibration_markers.length,
    ).toBeGreaterThan(0);
    expect(result!.applied_spanish_recalibration_markers).toContain(
      "Vitamina D (25-OH)",
    );
  });

  it("returns null for non-finite or non-positive age", () => {
    expect(computeReferenceBA(eightMarkerInputs, "male", NaN)).toBeNull();
    expect(computeReferenceBA(eightMarkerInputs, "male", 0)).toBeNull();
    expect(computeReferenceBA(eightMarkerInputs, "male", -1)).toBeNull();
  });

  it("produces different BA for male vs female on same input (sex-stratified markers active)", () => {
    const baM = computeReferenceBA(eightMarkerInputs, "male", 50);
    const baF = computeReferenceBA(eightMarkerInputs, "female", 50);
    expect(baM).not.toBeNull();
    expect(baF).not.toBeNull();
    // Uric Acid is sex-stratified ⇒ different contributions
    expect(baM!.BA).not.toBeCloseTo(baF!.BA, 1);
  });
});

describe("computeComprehensiveBA — public API (B.10)", () => {
  const baseInputs = [
    { code: "ALBUMIN", value: 44 },
    { code: "CREATININE", value: 0.95 },
    { code: "blood_urea_nitrogen", value: 14 },
    { code: "URIC_ACID", value: 5.2 },
    { code: "total_cholesterol", value: 180 },
    { code: "HDL_C", value: 55 },
    { code: "TG", value: 90 },
    { code: "HSCRP", value: 0.7 },
  ];

  it("returns null when base-panel gate fails (same gating as Reference)", () => {
    expect(computeComprehensiveBA(baseInputs.slice(0, 7), "male", 50)).toBeNull();
  });

  it("uses extended-panel markers in addition to the base panel", () => {
    const extended = [
      ...baseInputs,
      { code: "VITD", value: 40 },
      { code: "TSH", value: 1.8 },
      { code: "FERRITIN", value: 80 },
      // Non-base-panel extended markers
      { code: "APOB", value: 75 },
      { code: "LDL_C", value: 100 },
      { code: "HBA1C", value: 5.3 },
      { code: "ALT", value: 22 },
      { code: "AST", value: 20 },
      { code: "HGB", value: 14.5 },
    ];
    const ref = computeReferenceBA(extended, "male", 50);
    const comp = computeComprehensiveBA(extended, "male", 50);
    expect(ref).not.toBeNull();
    expect(comp).not.toBeNull();
    // Comprehensive uses more markers than Reference
    expect(comp!.n_markers_used).toBeGreaterThan(ref!.n_markers_used);
  });

  it("full extended-panel input ⇒ Reference vs Comprehensive both in [20,100], distinct (B.11.2)", () => {
    // Wide panel mixing engine codes + DB keys. Values are realistic mid-life
    // healthy reference points for a male, so resulting BA should land near
    // chronological age 50 ± typical variation. Both estimators must succeed.
    const fullPanel = [
      // Base panel
      { code: "ALBUMIN", value: 44 },
      { code: "CREATININE", value: 0.95 },
      { code: "blood_urea_nitrogen", value: 14 },
      { code: "URIC_ACID", value: 5.5 },
      { code: "ALP", value: 75 },
      { code: "GGT", value: 22 },
      { code: "total_cholesterol", value: 185 },
      { code: "HDL_C", value: 55 },
      { code: "TG", value: 100 },
      { code: "HSCRP", value: 0.8 },
      { code: "FERRITIN", value: 100 },
      { code: "VITD", value: 40 },
      { code: "TSH", value: 1.8 },
      { code: "HBA1C", value: 5.4 }, // also derives Fructosamine via Cohen 2010
      // Extended cardiovascular
      { code: "APOB", value: 75 },
      { code: "LDL_C", value: 100 },
      { code: "LPA", value: 20 },
      { code: "apolipoprotein_a1", value: 150 },
      // Extended metabolic / kidney
      { code: "GLUCOSE", value: 90 },
      { code: "INSULIN", value: 5 },
      { code: "EGFR", value: 95 },
      { code: "cystatin_c", value: 0.9 },
      // Extended liver
      { code: "ALT", value: 22 },
      { code: "AST", value: 20 },
      { code: "BILIRUBIN", value: 0.6 },
      { code: "total_protein", value: 7.0 },
      { code: "globulin", value: 2.6 },
      // Extended hematology
      { code: "HGB", value: 14.8 },
      { code: "hematocrit", value: 44 },
      { code: "MCV", value: 89 },
      { code: "PLT", value: 250000 },
      { code: "WBC", value: 6500 },
      { code: "LYMPH_PCT", value: 32 },
      { code: "RDW", value: 13.2 },
      { code: "red_blood_cell_count", value: 4900000 },
      // Extended iron
      { code: "TSAT", value: 30 },
      { code: "iron", value: 95 },
      { code: "total_iron_binding_capacity", value: 320 },
      // Hormones
      { code: "TESTOSTERONE", value: 5.5 },
      { code: "SHBG", value: 40 },
      // Thyroid
      { code: "FT4", value: 1.2 },
      { code: "FT3", value: 3.2 },
      // Nutrients
      { code: "B12", value: 600 },
      { code: "FOLATE", value: 12 },
      { code: "MAGNESIUM", value: 2.1 },
      { code: "ZINC", value: 95 },
      // Cardiovascular extra
      { code: "homocysteine", value: 9 },
      { code: "fibrinogen", value: 300 },
      { code: "calcium", value: 95 },
    ];

    const ref = computeReferenceBA(fullPanel, "male", 50);
    const comp = computeComprehensiveBA(fullPanel, "male", 50);

    expect(ref).not.toBeNull();
    expect(comp).not.toBeNull();
    // Both BAs in plausible adult range
    expect(ref!.BA).toBeGreaterThan(20);
    expect(ref!.BA).toBeLessThan(100);
    expect(comp!.BA).toBeGreaterThan(20);
    expect(comp!.BA).toBeLessThan(100);
    // Comprehensive uses substantially more markers
    expect(comp!.n_markers_used).toBeGreaterThanOrEqual(20);
    // The two estimators answer different questions and almost always
    // disagree by at least a fractional year on real data.
    expect(comp!.BA).not.toBeCloseTo(ref!.BA, 2);
  });
});
