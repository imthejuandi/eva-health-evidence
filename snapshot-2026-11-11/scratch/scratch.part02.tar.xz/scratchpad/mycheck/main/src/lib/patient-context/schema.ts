/**
 * Zod schemas for patient-context API payloads.
 *
 * Keys are validated against the canonical option arrays in options.ts
 * so a typo or stale client never lands a bogus value in jsonb. Unknown
 * keys are rejected, not silently dropped — better to fail loudly than
 * to lose data that should be flagged.
 */

import { z } from "zod";
import {
  MEDICATION_KEYS,
  SUPPLEMENT_KEYS,
  CONDITION_KEYS,
  SMOKING_STATUSES,
  CARDIO_INTENSITIES,
  DIET_PATTERNS,
  MENSTRUAL_REGULARITIES,
  CONTRACEPTION_OPTIONS,
  MENOPAUSE_STATUSES,
  HRT_OPTIONS,
  TRT_OPTIONS,
  FASTED_OPTIONS,
  LAST_WORKOUT_OPTIONS,
  DRAW_TIME_OPTIONS,
  THREE_POINT_OPTIONS,
} from "./options";

const medicationKeyEnum = z.enum(
  MEDICATION_KEYS,
);
const supplementKeyEnum = z.enum(
  SUPPLEMENT_KEYS,
);
const conditionKeyEnum = z.enum(
  CONDITION_KEYS,
);

export const MedicationItemSchema = z.object({
  key: medicationKeyEnum,
  dose: z.string().max(120).nullable().optional(),
  text: z.string().max(200).nullable().optional(),
});

export const SupplementItemSchema = z.object({
  key: supplementKeyEnum,
  dose: z.string().max(120).nullable().optional(),
  text: z.string().max(200).nullable().optional(),
});

export const ConditionsBlockSchema = z.object({
  keys: z.array(conditionKeyEnum).max(20),
});

export const LifestyleSchema = z.object({
  smoking_status: z
    .enum(SMOKING_STATUSES)
    .optional(),
  alcohol_drinks_per_week: z.number().int().min(0).max(100).optional(),
  cardio_sessions_per_week: z.number().int().min(0).max(14).optional(),
  cardio_dominant_intensity: z
    .enum(CARDIO_INTENSITIES)
    .optional(),
  resistance_sessions_per_week: z.number().int().min(0).max(14).optional(),
  diet_pattern: z
    .enum(DIET_PATTERNS)
    .optional(),
});

export const SexSpecificSchema = z.object({
  menstrual_regularity: z
    .enum(MENSTRUAL_REGULARITIES)
    .optional(),
  contraception: z
    .enum(CONTRACEPTION_OPTIONS)
    .optional(),
  menopause_status: z
    .enum(MENOPAUSE_STATUSES)
    .optional(),
  hrt: z.enum(HRT_OPTIONS).optional(),
  trt: z.enum(TRT_OPTIONS).optional(),
});

export const DurableContextSnapshotSchema = z.object({
  medications: z.array(MedicationItemSchema).max(30),
  supplements: z.array(SupplementItemSchema).max(30),
  conditions: ConditionsBlockSchema,
  lifestyle: LifestyleSchema,
  sex_specific: SexSpecificSchema,
});

export const TransientContextSchema = z.object({
  fasted: z
    .enum(FASTED_OPTIONS)
    .optional(),
  last_workout: z
    .enum(LAST_WORKOUT_OPTIONS)
    .optional(),
  currently_ill: z.boolean().optional(),
  cycle_day: z.number().int().min(1).max(45).nullable().optional(),
  draw_time: z
    .enum(DRAW_TIME_OPTIONS)
    .optional(),
  sleep_quality: z
    .enum(THREE_POINT_OPTIONS)
    .optional(),
  hydration: z
    .enum(THREE_POINT_OPTIONS)
    .optional(),
  skipped: z.boolean().optional(),
});

export type DurableContextSnapshotInput = z.infer<
  typeof DurableContextSnapshotSchema
>;
export type TransientContextInput = z.infer<typeof TransientContextSchema>;
