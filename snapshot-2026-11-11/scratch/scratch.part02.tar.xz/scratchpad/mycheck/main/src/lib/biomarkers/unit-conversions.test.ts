import { describe, it, expect } from "vitest";
import { convertBiomarker } from "./unit-conversions";
import { remapToSeedKey } from "./key-aliases";
import { validateCanonicalUnit } from "./canonical-units";

/**
 * CBC counts. Since 2026-09-17 the canonical unit is the RAW number of
 * cells per µL — Echevarne's convention and what its PDF shows the patient —
 * so partner results pass through untouched and the "thousands" (×10³/µL ≡
 * ×10⁹/L ≡ K/µL) and "millions" (×10⁶/µL, red cells) notations used by other
 * labs are multiplied back up. Pure decimal shifts, never a formula.
 */
describe("CBC counts: canonical is raw cells/µL (Echevarne, 2026-09-17)", () => {
  const cases: Array<[string, number, number]> = [
    ["lymphocytes_absolute", 2.34, 2340],
    ["monocytes_absolute", 0.5, 500],
    ["neutrophils_absolute", 4.2, 4200],
    ["eosinophils_absolute", 0.2, 200],
    ["basophils_absolute", 0.04, 40],
    ["white_blood_cell_count", 6.5, 6500],
    ["platelet_count", 250, 250000],
  ];

  it.each(cases)("scales %s from ×10³/µL up to raw cells/µL", (key, scaled, expected) => {
    const res = convertBiomarker(key, scaled, "x10³/µL");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(expected, 6);
    // Result must satisfy the canonical-unit gate so the row is stored.
    expect(validateCanonicalUnit(key, res.unit).ok).toBe(true);
  });

  it("accepts every thousands notation (mil/mm³, K/µL, 10^3/µL, 10⁹/L)", () => {
    for (const unit of ["mil/mm³", "K/µL", "10^3/µL", "10⁹/L"]) {
      expect(convertBiomarker("neutrophils_absolute", 4.2, unit).value).toBeCloseTo(4200, 6);
    }
  });

  it("leaves a raw count untouched under any raw notation, OCR-mangled ones included", () => {
    for (const unit of ["/µL", "/mm³", "células/µL", "/mL", "/mi", "/mcL"]) {
      const res = convertBiomarker("lymphocytes_absolute", 2340, unit);
      expect(res.converted).toBe(false);
      expect(res.value).toBe(2340);
      expect(validateCanonicalUnit("lymphocytes_absolute", res.unit).ok).toBe(true);
    }
  });

  it("red blood cells: ×10⁶/µL and 10^12/L scale up by a million; raw passes through", () => {
    expect(convertBiomarker("red_blood_cell_count", 4.85, "x10⁶/µL").value).toBeCloseTo(4_850_000, 6);
    expect(convertBiomarker("red_blood_cell_count", 4.85, "10^12/L").value).toBeCloseTo(4_850_000, 6);
    const raw = convertBiomarker("red_blood_cell_count", 4_850_000, "/µL");
    expect(raw.converted).toBe(false);
    expect(validateCanonicalUnit("red_blood_cell_count", raw.unit).ok).toBe(true);
  });

  it("is idempotent: converting the output again is a no-op", () => {
    const first = convertBiomarker("lymphocytes_absolute", 2.34, "x10³/µL");
    const second = convertBiomarker("lymphocytes_absolute", first.value, first.unit);
    expect(second.converted).toBe(false);
    expect(second.value).toBe(first.value);
  });
});

/**
 * The unit string cannot be trusted on its own — labs and OCR mislabel in
 * both directions — so the value's magnitude against the raw-scale
 * normal-high arbitrates, except for eosinophils and basophils, whose raw
 * counts are legitimately tiny.
 */
describe("CBC magnitude arbitration (mislabelled units)", () => {
  it("a raw count mislabelled 10³/µL stays raw when the normal-high says so", () => {
    const res = convertBiomarker("lymphocytes_absolute", 2331, "10³/µL", { normalHigh: 3500 });
    expect(res.converted).toBe(false);
    expect(res.value).toBe(2331);
  });

  it("a thousands value mislabelled /µL scales up only where no patient can be that low: total white and red cells", () => {
    expect(convertBiomarker("white_blood_cell_count", 4.5, "/µL", { normalHigh: 11000 }).value).toBeCloseTo(4500, 6);
    expect(convertBiomarker("red_blood_cell_count", 4.9, "/µL", { normalHigh: 5650000 }).value).toBeCloseTo(4900000, 6);
  });

  it("never second-guesses a small raw count that can be real in a sick patient", () => {
    // Severe thrombocytopenia, agranulocytosis, monocytopenia — ×1000 here would be the dangerous error.
    expect(convertBiomarker("platelet_count", 1500, "/µL", { normalHigh: 400000 }).value).toBe(1500);
    expect(convertBiomarker("neutrophils_absolute", 12, "/µL", { normalHigh: 7500 }).value).toBe(12);
    expect(convertBiomarker("monocytes_absolute", 2, "/µL", { normalHigh: 800 }).value).toBe(2);
    expect(convertBiomarker("eosinophils_absolute", 20, "/µL", { normalHigh: 500 }).value).toBe(20);
    expect(convertBiomarker("basophils_absolute", 5, "/µL", { normalHigh: 200 }).value).toBe(5);
  });

  it("without a usable unit, the magnitude decides", () => {
    expect(convertBiomarker("monocytes_absolute", 0.69, "", { normalHigh: 800 }).value).toBeCloseTo(690, 6);
    expect(convertBiomarker("monocytes_absolute", 690, "", { normalHigh: 800 }).value).toBe(690);
    expect(convertBiomarker("eosinophils_absolute", 0.3, "", { normalHigh: 500 }).value).toBeCloseTo(300, 6);
  });

  it("real thrombocytosis or lymphocytosis is not a unit error", () => {
    expect(convertBiomarker("platelet_count", 600, "x10³/µL", { normalHigh: 400000 }).value).toBeCloseTo(600000, 6);
    const lym = convertBiomarker("lymphocytes_absolute", 8000, "/µL", { normalHigh: 3500 });
    expect(lym.converted).toBe(false);
    expect(lym.value).toBe(8000);
  });
});

describe("trusted units: the lab's HL7 label decides, no magnitude arbitration (bridge, 2026-09-21)", () => {
  it("keeps Echevarne's '44 /µL' dummy as 44, where the arbiter would have made it 44 000", () => {
    const arbitrated = convertBiomarker("white_blood_cell_count", 44, "/µL", { normalHigh: 11000 });
    expect(arbitrated.value).toBe(44000);
    const trusted = convertBiomarker("white_blood_cell_count", 44, "/µL", { normalHigh: 11000, trustUnit: true });
    expect(trusted.converted).toBe(false);
    expect(trusted.value).toBe(44);
    expect(trusted.unit).toBe("/µL");
    expect(convertBiomarker("red_blood_cell_count", 4.9, "/µL", { normalHigh: 5650000, trustUnit: true }).value).toBe(4.9);
  });

  it("still multiplies an explicit thousands or millions label up to raw cells/µL", () => {
    const wbc = convertBiomarker("white_blood_cell_count", 6.5, "x10³/µL", { normalHigh: 11000, trustUnit: true });
    expect(wbc.converted).toBe(true);
    expect(wbc.value).toBeCloseTo(6500, 6);
    expect(convertBiomarker("red_blood_cell_count", 4.9, "x10⁶/µL", { normalHigh: 5650000, trustUnit: true }).value).toBeCloseTo(4900000, 6);
    // Even where the arbiter would have called the label a mislabel: the label wins.
    expect(convertBiomarker("lymphocytes_absolute", 2331, "10³/µL", { normalHigh: 3500, trustUnit: true }).value).toBeCloseTo(2331000, 6);
  });

  it("with no unit at all there is nothing to trust, so the magnitude still decides", () => {
    expect(convertBiomarker("monocytes_absolute", 0.69, "", { normalHigh: 800, trustUnit: true }).value).toBeCloseTo(690, 6);
    expect(convertBiomarker("monocytes_absolute", 690, "", { normalHigh: 800, trustUnit: true }).value).toBe(690);
  });

  it("a real Echevarne differential passes through unchanged, count and formula consistent", () => {
    const wbc = convertBiomarker("white_blood_cell_count", 6500, "/µL", { normalHigh: 11000, trustUnit: true });
    const neu = convertBiomarker("neutrophils_absolute", 3770, "/µL", { normalHigh: 7500, trustUnit: true });
    expect(wbc.value).toBe(6500);
    expect(neu.value).toBe(3770);
    expect(neu.converted).toBe(false);
  });
});

describe("CBC differential key routing by unit", () => {
  it("routes a raw /µL count to the absolute key", () => {
    expect(remapToSeedKey("lymphocytes", "/µL")).toBe("lymphocytes_absolute");
    expect(remapToSeedKey("basophils", "/mm³")).toBe("basophils_absolute");
  });

  it("keeps a percentage on the percentage key", () => {
    expect(remapToSeedKey("lymphocytes", "%")).toBe("lymphocytes");
  });

  it("routes the ×10³/µL notation to the absolute key", () => {
    expect(remapToSeedKey("neutrophils", "x10³/µL")).toBe("neutrophils_absolute");
  });

  it("routes OCR-mangled count units (/mi, /mL, /MI) to the absolute key", () => {
    // The phone screenshot showed the absolute count unit rendered as
    // "/MI" — any non-% unit on a differential line is an absolute count.
    expect(remapToSeedKey("lymphocytes", "/mi")).toBe("lymphocytes_absolute");
    expect(remapToSeedKey("lymphocytes", "/MI")).toBe("lymphocytes_absolute");
    expect(remapToSeedKey("monocytes", "/mL")).toBe("monocytes_absolute");
  });

  it("end-to-end: a /mi count routes to the absolute key and stays raw", () => {
    const key = remapToSeedKey("lymphocytes", "/mi");
    expect(key).toBe("lymphocytes_absolute");
    const conv = convertBiomarker(key, 2331, "/mi", { normalHigh: 3500 });
    expect(conv.converted).toBe(false);
    expect(conv.value).toBe(2331);
    expect(validateCanonicalUnit(key, conv.unit).ok).toBe(true);
  });
});

describe("AMH pmol/L → ng/mL (Echevarne D0694)", () => {
  it("divides by 7.14 and lands on the canonical unit", () => {
    const res = convertBiomarker("anti_mullerian_hormone_amh", 21.42, "pmol/L");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(3.0, 6);
    expect(res.unit).toBe("ng/mL");
    expect(validateCanonicalUnit("anti_mullerian_hormone_amh", res.unit).ok).toBe(true);
  });

  it("leaves ng/mL untouched", () => {
    const res = convertBiomarker("anti_mullerian_hormone_amh", 3.0, "ng/mL");
    expect(res.value).toBeCloseTo(3.0, 6);
  });
});

/**
 * Echevarne's serum units are canonical (2026-09-17): what the lab sends
 * passes through; the per-decilitre notations other labs use shift by ten.
 */
describe("Echevarne serum units are canonical (catalog 2026-08-25)", () => {
  it("calcium: mg/L passes through, mg/dL ×10, mmol/L ×40.08", () => {
    const ech = convertBiomarker("calcium_serum", 95, "mg/L");
    expect(ech.converted).toBe(false);
    expect(validateCanonicalUnit("calcium_serum", ech.unit).ok).toBe(true);
    expect(convertBiomarker("calcium_serum", 9.5, "mg/dL").value).toBeCloseTo(95, 6);
    expect(convertBiomarker("calcium_serum", 2.4, "mmol/L").value).toBeCloseTo(96.19, 2);
  });

  it("albumin and total protein: g/L passes through, g/dL ×10", () => {
    const alb = convertBiomarker("albumin", 45, "g/L");
    expect(alb.converted).toBe(false);
    expect(validateCanonicalUnit("albumin", alb.unit).ok).toBe(true);
    expect(convertBiomarker("albumin", 4.5, "g/dL").value).toBeCloseTo(45, 6);
    const tp = convertBiomarker("total_protein", 7.2, "g/dL");
    expect(tp.value).toBeCloseTo(72, 6);
    expect(validateCanonicalUnit("total_protein", tp.unit).ok).toBe(true);
  });

  it("testosterone (total): ng/mL passes through, ng/dL ÷100, nmol/L ×0.2884", () => {
    expect(convertBiomarker("testosterone_total", 5.5, "ng/mL").converted).toBe(false);
    const us = convertBiomarker("testosterone_total", 550, "ng/dL");
    expect(us.value).toBeCloseTo(5.5, 6);
    expect(validateCanonicalUnit("testosterone_total", us.unit).ok).toBe(true);
    expect(convertBiomarker("testosterone_total", 19.07, "nmol/L").value).toBeCloseTo(5.5, 2);
  });
});

describe("Lp(a) canonical unit is mg/dL (Echevarne alignment, 2026-08-25)", () => {
  it("passes mg/dL through as canonical", () => {
    expect(validateCanonicalUnit("lipoproteina", "mg/dL").ok).toBe(true);
  });

  it("converts nmol/L to mg/dL via ÷2.5 (isoform approximation)", () => {
    const res = convertBiomarker("lipoproteina", 75, "nmol/L");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(30, 6);
    expect(res.unit).toBe("mg/dL");
    expect(validateCanonicalUnit("lipoproteina", res.unit).ok).toBe(true);
  });

  it("converts µg/mL to mg/dL via ÷10", () => {
    const res = convertBiomarker("lipoproteina", 300, "µg/mL");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(30, 6);
    expect(res.unit).toBe("mg/dL");
  });
});

/**
 * Spanish labs write "UI" (unidades internacionales) where the seed says
 * "IU". Echevarne's training ORU X68800192 (2026-09-17) reported TSH as
 * "22,000 µUI/mL" and the row was silently dropped as a unit mismatch —
 * the only base-panel marker that failed to land.
 */
describe("Spanish UI ≡ IU, bare U ≡ IU", () => {
  it("TSH in µUI/mL (Echevarne) is the canonical unit and passes through", () => {
    const res = convertBiomarker("tsh", 22, "µUI/mL");
    expect(res.converted).toBe(false);
    expect(res.value).toBe(22);
    expect(validateCanonicalUnit("tsh", res.unit).ok).toBe(true);
  });

  it("TSH in mIU/L or mUI/L (other labs) is the same number, relabelled", () => {
    for (const unit of ["mIU/L", "mUI/L"]) {
      const res = convertBiomarker("tsh", 2.1, unit);
      expect(res.value).toBe(2.1);
      expect(validateCanonicalUnit("tsh", res.unit).ok).toBe(true);
    }
  });

  it("insulin µU/mL (Echevarne) ≡ µIU/mL ≡ µUI/mL; antibodies UI/mL ≡ IU/mL", () => {
    for (const unit of ["µU/mL", "µIU/mL", "µUI/mL"]) {
      expect(validateCanonicalUnit("insulin_fasting", unit).ok).toBe(true);
    }
    expect(validateCanonicalUnit("thyroid_peroxidase_antibodies_tpo", "UI/mL").ok).toBe(true);
    expect(validateCanonicalUnit("alt", "IU/L").ok).toBe(true);
  });
});
