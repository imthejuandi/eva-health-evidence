/**
 * Resolve one lab that sat in pending_context past the 72-hour threshold, on
 * the patient's behalf: stamp their last durable context (or an empty one),
 * run the interpretation, mark the lab ready, close its cycle and tell them.
 *
 * Runs under the cron with NO user session, so every helper receives the
 * service-role client explicitly. Before 2026-09-22 the helpers fell back to
 * the cookie-bound client, auth.uid() was NULL, RLS returned nothing and every
 * lab crossed the threshold into 'error' — invisible to the patient and
 * without an email (audit finding F09). Dependencies are injectable so the
 * flow is unit-tested without Gemini, Resend or a database.
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import { createNewVersion, getCurrentVersion } from "@/lib/patient-context";
import { emptySnapshot } from "@/lib/patient-context/options";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { completeCycleForLabResult } from "@/lib/cycles/close-cycle";
import { opsAlert } from "@/lib/ops-alert";
import { labNoteTexts } from "./notes";

export interface AutoResolveDeps {
  getCurrentVersion: typeof getCurrentVersion;
  createNewVersion: typeof createNewVersion;
  getUserProfile: typeof getUserProfile;
  getWearableData: typeof getWearableData;
  generateSummary: typeof generateSummary;
  sendEmail: typeof sendEmail;
  completeCycleForLabResult: typeof completeCycleForLabResult;
}

const defaultDeps: AutoResolveDeps = {
  getCurrentVersion,
  createNewVersion,
  getUserProfile,
  getWearableData,
  generateSummary,
  sendEmail,
  completeCycleForLabResult,
};

type Zone = "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high" | "unclassified";

export async function resolvePendingLab(
  admin: SupabaseClient,
  labId: string,
  userId: string,
  deps: AutoResolveDeps = defaultDeps,
): Promise<{ biomarkerCount: number; cyclesClosed: string[] }> {
  // Find or create a context version for this user. We deliberately do
  // NOT mint a new empty version when one already exists — using the
  // last saved version gives the AI more context than nothing.
  let versionId: string;
  const current = await deps.getCurrentVersion(userId, admin).catch(() => null);
  if (current) {
    versionId = current.id;
  } else {
    const created = await deps.createNewVersion(userId, emptySnapshot(), admin);
    versionId = created.id;
  }

  // Stamp the version + skipped transient, transition to processing.
  const { error: stampError } = await admin
    .from("lab_results")
    .update({
      patient_context_version_id: versionId,
      transient_context: { skipped: true, auto_resolved: true },
      status: "processing",
    })
    .eq("id", labId);
  if (stampError) throw new Error(`stamp failed: ${stampError.message}`);

  // Pull biomarker_values to feed the AI.
  const { data: bvRows, error: bvError } = await admin
    .from("biomarker_values")
    .select("biomarker_key, biomarker_name, value, unit, zone, optimal_low, optimal_high")
    .eq("lab_result_id", labId);
  if (bvError) throw new Error(`load biomarker_values: ${bvError.message}`);
  if (!bvRows || bvRows.length === 0) {
    throw new Error("no biomarker_values to interpret");
  }
  const processed = (bvRows as Record<string, unknown>[]).map((b) => ({
    biomarkerKey: String(b.biomarker_key),
    name: String(b.biomarker_name ?? b.biomarker_key),
    value: b.value as number,
    unit: String(b.unit ?? ""),
    zone: ((b.zone as string | null) ?? "unclassified") as Zone,
    zoneLabel: "",
    zoneLabel_es: "",
    optimalLow: (b.optimal_low ?? null) as number | null,
    optimalHigh: (b.optimal_high ?? null) as number | null,
    matchConfidence: "exact" as const,
  }));

  const profile = await deps.getUserProfile(userId, admin);
  if (!profile) throw new Error("profile not found");
  const wearable = await deps.getWearableData(userId, 30, admin);
  const { data: labRow } = await admin.from("lab_results").select("lab_notes").eq("id", labId).maybeSingle();

  await deps.generateSummary(
    userId,
    labId,
    processed,
    wearable.length > 0 ? wearable : null,
    profile,
    admin,
    { labNotes: labNoteTexts((labRow as { lab_notes?: unknown } | null)?.lab_notes) },
  );

  const { error: readyError } = await admin
    .from("lab_results")
    .update({ status: "ready" })
    .eq("id", labId);
  if (readyError) throw new Error(`set ready failed: ${readyError.message}`);

  // The interpretation is ready: the cycle that produced this result is done.
  const cyclesClosed = await deps.completeCycleForLabResult(admin, labId).catch((e) => {
    opsAlert("cron.auto-resolve", "lab ready but its cycle could not be closed", { labId, error: e instanceof Error ? e.message : String(e) });
    return [] as string[];
  });

  // Tell the user. The email still uses results-ready because the
  // interpretation IS ready — the dashboard banner clarifies that
  // they can refine context to regenerate.
  if (profile.email) {
    const firstName = profile.full_name?.split(" ")[0] ?? "";
    const locale = profile.locale ?? "en";
    deps
      .sendEmail(
        profile.email,
        "results-ready",
        {
          firstName,
          biomarkerCount: processed.length,
          biologicalAge: null,
          baDelta: null,
          longevityScore: null,
          locale,
        },
        locale,
      )
      .catch((err) => console.error("[cron.auto-resolve] email failed:", err));
  }

  return { biomarkerCount: processed.length, cyclesClosed };
}
