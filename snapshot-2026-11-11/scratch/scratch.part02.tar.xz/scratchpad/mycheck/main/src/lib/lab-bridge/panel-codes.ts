/**
 * Which Echevarne tests compose each eva panel — the ONLY place the OML
 * learns what to order (OBR-4.1 = catalog «SINÓNIMO ECHEVARNE»).
 *
 * ⛔ Anti-invention: the composition of each panel is a MEDICAL + business
 * decision (docs/vendor/echevarne/catalogo-notas.md → "Composición de
 * paneles"). The Base Panel was fixed on 2026-09-22; Full and specialty
 * panels are still EMPTY, so their production orders cannot be built and the
 * fulfillment desk refuses to ship them: a kit must never leave without a
 * complete order behind it.
 *
 * TRAINING is different: while MSH-11 = T (ECH_PROCESSING_ID=T, the preview /
 * staging environment) we order the three tests Joan Fajardo already
 * processed for us in training (GLU, COL, H — 2026-09-07/09), so the full
 * circuit can be exercised end to end through the real mailbox. This table is
 * never used when processingId is "P".
 *
 * Codes here MUST come from docs/vendor/echevarne/catalogo-2026-08-25.tsv.
 */
import type { OmlTest } from "@/lib/lab-provider/oml-builder";

export type PanelOrderCodes = Record<string, readonly OmlTest[]>;

export const ECH_PANEL_ORDER_CODES: PanelOrderCodes = {
  /**
   * Base Panel — composition fixed by the founder on 2026-09-22 (13 tests;
   * medical director's counter-signature pending). It is the KDM v2.2 base
   * panel (marker_library_v2_2.json::meta.base_panel) minus ferritin,
   * vitamin D and TSH, plus ApoB and ALT — so the biological-age gate
   * (≥ 8 of 14 with albumin + creatinine) passes on the Base Panel alone.
   * Codes verbatim from docs/vendor/echevarne/catalogo-2026-08-25.tsv
   * (SINÓNIMO ECHEVARNE → result code → unit):
   *   ALBS  → B0020 albumin              g/L
   *   FAL   → B0202 alp                  U/L
   *   PCUL  → B0851 hs_crp               mg/L
   *   CR1   → B0003 creatinine           mg/dL
   *   BUN   → B0150 bun                  mg/dL
   *   AU1   → B0025 uric_acid            mg/dL
   *   COL   → B0001 total_cholesterol    mg/dL
   *   HDLC  → B0017 hdl_cholesterol      mg/dL
   *   TRIG  → B0004 triglycerides        mg/dL
   *   APOB  → B0839 apolipoprotein_b_apob mg/dL
   *   GPT   → B0005 alt                  U/L
   *   GGT   → B0007 ggt                  U/L
   *   FRUC  → B0158 fructosamine         µmol/L
   *
   * Sample logistics: every test is TUBO SUERO GEL — one tube per kit.
   */
  base: [
    { code: "ALBS", description: "ALBÚMINA / SUERO" },
    { code: "FAL", description: "FOSFATASA ALCALINA / SUERO" },
    { code: "PCUL", description: "PROTEÍNA C REACTIVA ULTRASENSIBLE / SUERO" },
    { code: "CR1", description: "CREATININA / SUERO" },
    { code: "BUN", description: "NITRÓGENO UREICO (BUN) / SUERO" },
    { code: "AU1", description: "ÁCIDO ÚRICO / SUERO" },
    { code: "COL", description: "COLESTEROL / SUERO" },
    { code: "HDLC", description: "HDL-COLESTEROL / SUERO" },
    { code: "TRIG", description: "TRIGLICÉRIDOS / SUERO" },
    { code: "APOB", description: "APOLIPOPROTEÍNA B / SUERO" },
    { code: "GPT", description: "ALT-GPT / SUERO" },
    { code: "GGT", description: "GAMMA-GT / SUERO" },
    { code: "FRUC", description: "FRUCTOSAMINA / SUERO" },
  ],
  // Full Panel (120+ markers) — still undecided, so it stays fail-closed.
  full: [],
};

/** Training-only composition (mirrors OML nº 1–3 processed by ECH). */
export const TRAINING_PANEL_ORDER_CODES: PanelOrderCodes = {
  base: [
    { code: "GLU", description: "GLUCOSA / SUERO" },
    { code: "COL", description: "COLESTEROL / SUERO" },
    { code: "H", description: "HEMOGRAMA" },
  ],
  full: [
    { code: "GLU", description: "GLUCOSA / SUERO" },
    { code: "COL", description: "COLESTEROL / SUERO" },
    { code: "H", description: "HEMOGRAMA" },
  ],
};

/** The table that applies for a given MSH-11: production is strict; training may fall back. */
export function panelCodesFor(processingId: "P" | "T"): PanelOrderCodes {
  if (processingId === "P") return ECH_PANEL_ORDER_CODES;
  const merged: PanelOrderCodes = { ...TRAINING_PANEL_ORDER_CODES };
  for (const [panel, codes] of Object.entries(ECH_PANEL_ORDER_CODES)) {
    if (codes.length > 0) merged[panel] = codes; // a decided production panel wins even in training
  }
  return merged;
}

export function processingIdFromEnv(env: NodeJS.ProcessEnv = process.env): "P" | "T" {
  return env.ECH_PROCESSING_ID === "P" ? "P" : "T";
}

export function orderCodesForPanel(panelType: string, table: PanelOrderCodes = ECH_PANEL_ORDER_CODES): OmlTest[] {
  const codes = table[panelType];
  if (!codes || codes.length === 0) {
    throw new Error(
      `[lab-bridge] Panel '${panelType}' has no Echevarne order codes configured. ` +
        "Decide the panel composition (docs/vendor/echevarne/catalogo-notas.md) before shipping kits.",
    );
  }
  return codes.map((c) => ({ ...c }));
}

export function panelIsOrderable(panelType: string, table: PanelOrderCodes = ECH_PANEL_ORDER_CODES): boolean {
  const codes = table[panelType];
  return Boolean(codes && codes.length > 0);
}
