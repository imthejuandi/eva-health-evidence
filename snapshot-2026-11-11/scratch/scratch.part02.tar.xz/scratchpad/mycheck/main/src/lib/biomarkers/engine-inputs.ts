/**
 * The one way biomarker rows become Longevity Score engine inputs.
 *
 * Two rules the 2026-09-21 audit found broken in two places at once:
 *   1. Engine codes come from DB_KEY_TO_ENGINE_CODE — never from a guess.
 *   2. Ratios the engine scores (NLR, HOMA-IR) are COMPUTED from their
 *      components by calculated-metrics, never taken from a raw row. The
 *      neutrophil percentage used to be pushed as "NLR" (a 60 % read as a
 *      ratio of 60 → critical on every hemogram); HOMA-IR never reached the
 *      engine at all.
 *
 * Values are in eva's canonical units (Echevarne's, since 2026-09-17) and the
 * engine registry is kept in the same units — longevity-score.test.ts asserts
 * that for every mapped key.
 */
import { DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
import { calculateAllMetrics } from "./calculated-metrics";
import type { BiomarkerInput } from "./longevity-score";

const METRIC_TO_ENGINE_CODE: Record<string, string> = {
  nlr: "NLR",
  homa_ir: "HOMA_IR",
};

export function buildEngineInputs(
  rows: ReadonlyArray<{ biomarkerKey: string; value: number }>,
  sex: string,
): BiomarkerInput[] {
  const inputs: BiomarkerInput[] = [];
  const seen = new Set<string>();
  for (const r of rows) {
    if (!Number.isFinite(r.value)) continue;
    const code = DB_KEY_TO_ENGINE_CODE[r.biomarkerKey];
    if (!code || seen.has(code)) continue;
    seen.add(code);
    inputs.push({ code, value: r.value });
  }
  const metrics = calculateAllMetrics(
    rows.filter((r) => Number.isFinite(r.value)).map((r) => ({ biomarker_key: r.biomarkerKey, value: r.value })),
    sex,
  );
  for (const m of metrics) {
    const code = METRIC_TO_ENGINE_CODE[m.metricKey];
    if (!code || seen.has(code)) continue;
    seen.add(code);
    inputs.push({ code, value: m.value });
  }
  return inputs;
}
