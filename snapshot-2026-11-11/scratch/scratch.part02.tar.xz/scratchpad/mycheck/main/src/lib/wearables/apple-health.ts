import JSZip from "jszip";
import { XMLParser } from "fast-xml-parser";
import type { WearableAdapter, WearableDayData, WearableImportResult } from "./interface";

// HealthKit type identifiers → our field names
const HK_TYPE_MAP: Record<string, keyof WearableDayData> = {
  HKQuantityTypeIdentifierHeartRateVariabilitySDNN: "hrv_ms",
  HKQuantityTypeIdentifierRestingHeartRate: "resting_hr_bpm",
  HKQuantityTypeIdentifierRespiratoryRate: "respiratory_rate",
  HKQuantityTypeIdentifierStepCount: "steps",
  HKQuantityTypeIdentifierActiveEnergyBurned: "active_energy_kcal",
  HKQuantityTypeIdentifierVO2Max: "vo2_max",
  HKQuantityTypeIdentifierOxygenSaturation: "blood_oxygen_pct",
};

const SLEEP_TYPE = "HKCategoryTypeIdentifierSleepAnalysis";

interface HKRecord {
  "@_type": string;
  "@_value"?: string;
  "@_startDate": string;
  "@_endDate": string;
  "@_unit"?: string;
}

function parseDate(dateStr: string): string {
  // Apple Health format: "2026-03-06 08:30:00 +0100"
  const d = new Date(dateStr);
  return d.toISOString().split("T")[0];
}

function parseSleepHours(startDate: string, endDate: string): number {
  const start = new Date(startDate);
  const end = new Date(endDate);
  return (end.getTime() - start.getTime()) / (1000 * 60 * 60);
}

export class AppleHealthAdapter implements WearableAdapter {
  source = "apple_health";

  async parseExport(fileBuffer: Buffer): Promise<WearableImportResult> {
    // Unzip the export
    const zip = await JSZip.loadAsync(fileBuffer);

    // Find export.xml (may be at root or inside apple_health_export/)
    let xmlContent: string | null = null;
    for (const [path, file] of Object.entries(zip.files)) {
      if (path.endsWith("export.xml") || path.endsWith("Export.xml")) {
        xmlContent = await file.async("string");
        break;
      }
    }

    if (!xmlContent) {
      throw new Error("export.xml not found in ZIP file");
    }

    // Parse XML
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: "@_",
      isArray: (tagName) => tagName === "Record",
    });

    const parsed = parser.parse(xmlContent);
    const records: HKRecord[] = parsed?.HealthData?.Record ?? [];

    if (!Array.isArray(records) || records.length === 0) {
      return { source: this.source, daysImported: 0, dateRange: null, data: [] };
    }

    // Aggregate by day
    const dayMap = new Map<string, {
      hrv_values: number[];
      resting_hr_values: number[];
      respiratory_values: number[];
      steps_total: number;
      energy_total: number;
      vo2_values: number[];
      oxygen_values: number[];
      sleep_hours_total: number;
    }>();

    function getDay(date: string) {
      const key = parseDate(date);
      if (!dayMap.has(key)) {
        dayMap.set(key, {
          hrv_values: [], resting_hr_values: [], respiratory_values: [],
          steps_total: 0, energy_total: 0, vo2_values: [], oxygen_values: [],
          sleep_hours_total: 0,
        });
      }
      return dayMap.get(key)!;
    }

    for (const record of records) {
      const type = record["@_type"];
      const value = parseFloat(record["@_value"] ?? "0");

      // Sleep: calculate from start/end times
      if (type === SLEEP_TYPE) {
        // Only count actual sleep (InBed type has value "HKCategoryValueSleepAnalysisInBed")
        const hours = parseSleepHours(record["@_startDate"], record["@_endDate"]);
        if (hours > 0 && hours < 24) {
          // Attribute to the start date
          const day = getDay(record["@_startDate"]);
          day.sleep_hours_total += hours;
        }
        continue;
      }

      // Quantity types
      const field = HK_TYPE_MAP[type];
      if (!field || isNaN(value)) continue;

      const day = getDay(record["@_startDate"]);

      switch (field) {
        case "hrv_ms":
          day.hrv_values.push(value);
          break;
        case "resting_hr_bpm":
          day.resting_hr_values.push(value);
          break;
        case "respiratory_rate":
          day.respiratory_values.push(value);
          break;
        case "steps":
          day.steps_total += value;
          break;
        case "active_energy_kcal":
          day.energy_total += value;
          break;
        case "vo2_max":
          day.vo2_values.push(value);
          break;
        case "blood_oxygen_pct":
          // HealthKit stores as decimal (0.98), convert to percentage
          day.oxygen_values.push(value > 1 ? value : value * 100);
          break;
      }
    }

    // Convert to WearableDayData
    const data: WearableDayData[] = [];
    const avg = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : null;
    const round1 = (n: number | null) => n != null ? Math.round(n * 10) / 10 : null;

    for (const [date, day] of dayMap) {
      const sleepHrs = round1(day.sleep_hours_total > 0 ? Math.min(day.sleep_hours_total, 24) : null);

      data.push({
        date,
        hrv_ms: round1(avg(day.hrv_values)),
        resting_hr_bpm: round1(avg(day.resting_hr_values)),
        sleep_hours: sleepHrs,
        sleep_quality_score: sleepHrs != null ? Math.min(100, Math.round((sleepHrs / 8) * 100)) : null,
        respiratory_rate: round1(avg(day.respiratory_values)),
        steps: day.steps_total > 0 ? Math.round(day.steps_total) : null,
        active_energy_kcal: day.energy_total > 0 ? Math.round(day.energy_total) : null,
        vo2_max: round1(avg(day.vo2_values)),
        blood_oxygen_pct: round1(avg(day.oxygen_values)),
        recovery_score: null, // Not available in Apple Health
      });
    }

    // Sort by date
    data.sort((a, b) => a.date.localeCompare(b.date));

    const dateRange = data.length > 0
      ? { start: data[0].date, end: data[data.length - 1].date }
      : null;

    return {
      source: this.source,
      daysImported: data.length,
      dateRange,
      data,
    };
  }
}
