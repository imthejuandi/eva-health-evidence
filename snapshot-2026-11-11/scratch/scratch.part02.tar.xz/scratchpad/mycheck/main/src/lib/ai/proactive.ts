/**
 * Proactive Insights Engine — STUB
 *
 * Future push notification system that generates personalized health insights
 * based on biomarker trends, wearable patterns, and upcoming milestones.
 *
 * Planned triggers:
 *
 * 1. QUARTERLY RETEST REMINDER
 *    - 2 weeks before retest date → "Your quarterly panel is coming up"
 *    - Suggest which biomarkers to prioritize based on last results
 *
 * 2. WEARABLE TREND ALERTS
 *    - HRV drops >15% over 7 days → "Your HRV has been declining"
 *    - Sleep average drops below 6.5h → "Your sleep quality needs attention"
 *    - Resting HR increases >10% → "Your resting heart rate is elevated"
 *
 * 3. ACTION STEP FOLLOW-UPS
 *    - 30 days after action step created → "Have you started [step]?"
 *    - 90 days after → "Time to retest [biomarker] to check progress"
 *
 * 4. SEASONAL INSIGHTS
 *    - Winter → "Vitamin D levels often drop in winter — consider checking"
 *    - Post-holiday → "Great time to check metabolic markers after the holidays"
 *
 * 5. MILESTONE CELEBRATIONS
 *    - Bio age improves → "Your biological age dropped by 2 years!"
 *    - Longevity score reaches new tier → "You've reached 'Excellent' status!"
 *    - Biomarker moves from attention → optimal → "Your Vitamin D is now optimal!"
 *
 * Implementation plan:
 * - Cron job (Vercel Cron or Supabase Edge Function) runs daily
 * - Checks each user's state against trigger conditions
 * - Generates insight via Claude (short, 1-2 sentences)
 * - Stores in `notifications` table
 * - Sends push/email based on user preferences
 *
 * Dependencies needed:
 * - notifications table (user_id, type, title, body, read, created_at)
 * - user notification preferences (email, push, in-app)
 * - Cron scheduler (Vercel Cron Functions)
 * - Push notification service (web-push or FCM)
 *
 * TODO: Implement in Stage 11 (Notifications & Engagement)
 */

export type InsightType =
  | "retest_reminder"
  | "wearable_alert"
  | "action_followup"
  | "seasonal"
  | "milestone";

export interface ProactiveInsight {
  type: InsightType;
  title: string;
  title_es: string;
  body: string;
  body_es: string;
  priority: "low" | "medium" | "high";
  relatedBiomarkers?: string[];
}

// Placeholder — will be implemented in Stage 11
export async function generateProactiveInsights(
  _userId: string,
): Promise<ProactiveInsight[]> {
  return [];
}
