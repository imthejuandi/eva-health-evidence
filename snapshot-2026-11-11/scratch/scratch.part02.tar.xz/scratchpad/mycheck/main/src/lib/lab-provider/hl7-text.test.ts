import { describe, it, expect } from "vitest";
import { unescapeHl7Text } from "./hl7";
import { EchevarneProvider } from "./echevarne";

describe("unescapeHl7Text — lab observations read as the lab wrote them", () => {
  it("undoes the HL7 escapes and turns \\.br\\ into line breaks", () => {
    expect(unescapeHl7Text("Suero lip\\S\\mico\\.br\\Se recomienda ayuno \\T\\ repetir")).toBe("Suero lip^mico\nSe recomienda ayuno & repetir");
    expect(unescapeHl7Text("a\\F\\b\\R\\c\\E\\d")).toBe("a|b~c\\d");
    expect(unescapeHl7Text("sin escapes")).toBe("sin escapes");
  });

  it("the parser keeps every TX observation, unescaped and verbatim", () => {
    const oru = [
      "MSH|^~\\&|LABTRAK|ECHEVARNE|EVAHEALTH|EVAHEALTH|20260922100000||ORU^R01|X1-1|P|2.5|||AL|ER|||UTF-8",
      "PID|1||00000000T^^^^DNI||PRUEBA^PACIENTE||19800101|F",
      "ORC|RE|EVA000001001|X1||CM",
      "OBR|1|EVA000001001|X1|LDLC^LDL-COLESTEROL^^",
      "OBX|1|NM|B0018^LDL^^^^B0018||193,000|^mg/dL|<100|H|||F",
      "OBX|2|TX|B0101^Comentario VLDL^^^^B0101||Suero lip\\S\\mico: el LDL calculado no es valorable.\\.br\\Repetir en ayunas.||||||F",
      "OBX|3|NM|B0851^PCR^^^^B0851||<0,500|^mg/L|<3.01|N|||F",
    ].join("\r");
    const parsed = EchevarneProvider.parseResults(oru);
    expect(parsed.textNotes).toEqual([{ code: "B0101", text: "Suero lip^mico: el LDL calculado no es valorable.\nRepetir en ayunas." }]);
    const crp = parsed.biomarkers.find((b) => b.biomarker_key === "B0851");
    expect(crp).toMatchObject({ value: 0.5, comparator: "<", unit: "mg/L" });
  });
});
