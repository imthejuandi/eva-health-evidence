/**
 * Everything the bridge needs from the database, behind one interface so the
 * sync loop is testable in memory and runs on Supabase in production.
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import type { LabProviderResult } from "@/lib/lab-provider/types";
import { EchevarneProvider } from "@/lib/lab-provider/echevarne";
import { processLabResults, type ProcessedBiomarker } from "@/lib/biomarkers/process-results";

export interface OutboundMessage {
  id: string;
  cycleId: string;
  messageControlId: string;
  raw: string;
  /** numeroPeticionLab.OML — from the cycle's kit_label_code. */
  filename: string;
  status: "queued" | "sent" | "processed" | "error";
  createdAt: string;
  sentAt?: string | null;
}

export interface BridgeCycle {
  id: string;
  userId: string;
  status: string;
  seq: number;
  kitLabelCode: string | null;
  placerOrderNumber: string | null;
  /** The lab_results row already recorded for this cycle, if any. */
  labResultId: string | null;
}

export interface ArchiveInboundInput {
  msgType: "ORU" | "ACK";
  messageControlId: string;
  raw: string;
  cycleId?: string | null;
}

/**
 * Outcome of archiving an inbound message. `duplicate` means this MSH-10 was
 * archived on an earlier pass; `status` then says how far that pass got —
 * 'processed' is done, 'received' means it died mid-way, 'error' means it
 * could not be matched — so the caller can tell "already handled" from
 * "archived but never finished" (found by the 2026-09-21 audit: the two were
 * one and the same, and a failure between archiving and recording ended in a
 * CA to the lab with no result recorded).
 */
export interface ArchiveInboundResult {
  id: string | null;
  duplicate: boolean;
  status?: "received" | "processed" | "error";
  cycleId?: string | null;
}

export interface RecordedResults {
  labResultId: string;
  processed: number;
  unmatched: number;
  /** True when a final/corrected report replaced the values of the cycle's existing result. */
  replaced?: boolean;
}

export interface BridgeStore {
  listQueuedOutbound(): Promise<OutboundMessage[]>;
  markOutboundSent(id: string, at: Date): Promise<void>;
  findOutboundByControlId(controlId: string): Promise<OutboundMessage | null>;
  /** CA → cycle order_accepted; CE → cycle error with oml_ack = 'CE:<code>'. */
  markOutboundAcked(id: string, ack: { ok: boolean; code: string; text?: string }, at: Date): Promise<void>;
  /** Archives with MSH-10 dedupe. On a duplicate, returns the existing row's id and status. */
  archiveInbound(input: ArchiveInboundInput): Promise<ArchiveInboundResult>;
  /**
   * Closes an inbound row and, once the message is matched, ties it to its
   * cycle — that link is what makes the raw HL7 part of the customer's
   * history (retention decision 2026-09-17) and what the GDPR cascade
   * follows. Found unlinked in staging on 2026-09-21.
   */
  markInboundProcessed(id: string, error?: string, cycleId?: string | null): Promise<void>;
  findCycleByPlacer(placer: string): Promise<BridgeCycle | null>;
  recordResults(cycle: BridgeCycle, parsed: LabProviderResult, at: Date): Promise<RecordedResults>;
  setCycleStatus(cycleId: string, status: string, patch?: Record<string, unknown>): Promise<void>;
  /** Outbound messages sent before `before` that never got an ACK. */
  listSentWithoutAck(before: Date): Promise<OutboundMessage[]>;
  /** OMLs of this cycle still waiting for their ACK (status 'sent'). */
  listUnackedOutboundForCycle(cycleId: string): Promise<OutboundMessage[]>;
  /**
   * Results arrived for an order the lab never acknowledged: the ORU proves
   * they processed it, so the OML is closed and the cycle records
   * oml_ack = 'ORU' (never 'CA' — no CA was received).
   */
  markOutboundImpliedAck(id: string, at: Date): Promise<void>;
  /** The ACK we wrote for an ORU — every message is archived, both directions. */
  archiveOutboundAck(input: { cycleId: string | null; messageControlId: string; raw: string }, at: Date): Promise<void>;
}

// ─── In-memory implementation (tests) ───

export class InMemoryBridgeStore implements BridgeStore {
  outbound: OutboundMessage[] = [];
  inbound: { id: string; msgType: string; messageControlId: string; raw: string; cycleId?: string | null; status: string; error?: string }[] = [];
  cycles: (BridgeCycle & { patch: Record<string, unknown> })[] = [];
  results: { cycleId: string; labResultId: string; biomarkers: number; orderStatus?: string }[] = [];
  private seq = 0;

  private nextId(prefix: string): string {
    this.seq += 1;
    return `${prefix}-${this.seq}`;
  }

  addCycle(c: Omit<BridgeCycle, "id" | "labResultId"> & { id?: string; labResultId?: string | null }): BridgeCycle & { patch: Record<string, unknown> } {
    const row = { ...c, id: c.id ?? this.nextId("cyc"), labResultId: c.labResultId ?? null, patch: {} };
    this.cycles.push(row);
    return row;
  }

  queueOutbound(m: Omit<OutboundMessage, "id" | "status" | "createdAt"> & { createdAt?: string }): OutboundMessage {
    const row: OutboundMessage = { ...m, id: this.nextId("out"), status: "queued", createdAt: m.createdAt ?? new Date(0).toISOString() };
    this.outbound.push(row);
    return row;
  }

  async listQueuedOutbound() {
    return this.outbound.filter((m) => m.status === "queued").sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }
  async markOutboundSent(id: string, at: Date) {
    const m = this.outbound.find((x) => x.id === id)!;
    m.status = "sent";
    m.sentAt = at.toISOString();
    const c = this.cycles.find((x) => x.id === m.cycleId);
    if (c && ["shipped", "activated"].includes(c.status)) {
      c.status = "order_sent";
      c.patch.oml_sent_at = at.toISOString();
    }
  }
  async findOutboundByControlId(controlId: string) {
    return this.outbound.find((m) => m.messageControlId === controlId) ?? null;
  }
  async markOutboundAcked(id: string, ack: { ok: boolean; code: string; text?: string }, at: Date) {
    const m = this.outbound.find((x) => x.id === id)!;
    m.status = ack.ok ? "processed" : "error";
    const c = this.cycles.find((x) => x.id === m.cycleId);
    if (!c) return;
    if (ack.ok) {
      if (["shipped", "activated", "order_sent"].includes(c.status)) c.status = "order_accepted";
      c.patch.oml_ack = "CA"; // a late CA also replaces an implied 'ORU'
    } else {
      c.status = "error";
      c.patch.oml_ack = `CE:${ack.code}${ack.text ? ` ${ack.text}` : ""}`;
    }
    void at; // test_cycles has no acked_at column; the Supabase store records nothing either
  }
  async archiveInbound(input: ArchiveInboundInput): Promise<ArchiveInboundResult> {
    const existing = this.inbound.find((i) => i.messageControlId === input.messageControlId);
    if (existing) {
      return { id: existing.id, duplicate: true, status: existing.status as ArchiveInboundResult["status"], cycleId: existing.cycleId ?? null };
    }
    const id = this.nextId("in");
    this.inbound.push({ id, ...input, status: "received" });
    return { id, duplicate: false };
  }
  async markInboundProcessed(id: string, error?: string, cycleId?: string | null) {
    const i = this.inbound.find((x) => x.id === id)!;
    i.status = error ? "error" : "processed";
    i.error = error;
    if (cycleId) i.cycleId = cycleId;
  }
  async findCycleByPlacer(placer: string) {
    return this.cycles.find((c) => c.placerOrderNumber === placer) ?? null;
  }
  replacements = 0;
  async recordResults(cycle: BridgeCycle, parsed: LabProviderResult) {
    const mapped = parsed.biomarkers.filter((b) => EchevarneProvider.mapBiomarkerName(b.biomarker_key, b.loincCode));
    const c = this.cycles.find((x) => x.id === cycle.id);
    // A cycle that already has a result is corrected in place — one result per cycle.
    if (cycle.labResultId) {
      const existing = this.results.find((r) => r.labResultId === cycle.labResultId);
      if (existing) {
        existing.biomarkers = mapped.length;
        existing.orderStatus = parsed.orderStatus;
      } else {
        this.results.push({ cycleId: cycle.id, labResultId: cycle.labResultId, biomarkers: mapped.length, orderStatus: parsed.orderStatus });
      }
      this.replacements += 1;
      return { labResultId: cycle.labResultId, processed: mapped.length, unmatched: parsed.biomarkers.length - mapped.length, replaced: true };
    }
    const labResultId = this.nextId("lab");
    this.results.push({ cycleId: cycle.id, labResultId, biomarkers: mapped.length, orderStatus: parsed.orderStatus });
    if (c) c.labResultId = labResultId;
    return { labResultId, processed: mapped.length, unmatched: parsed.biomarkers.length - mapped.length, replaced: false };
  }
  async setCycleStatus(cycleId: string, status: string, patch: Record<string, unknown> = {}) {
    const c = this.cycles.find((x) => x.id === cycleId);
    if (!c) return;
    c.status = status;
    Object.assign(c.patch, patch);
    if (typeof patch.lab_result_id === "string") c.labResultId = patch.lab_result_id;
  }
  async listSentWithoutAck(before: Date) {
    return this.outbound.filter((m) => {
      if (m.status !== "sent" || !m.sentAt || new Date(m.sentAt) >= before) return false;
      const c = this.cycles.find((x) => x.id === m.cycleId);
      return !c || c.status !== "cancelled"; // a cancelled order is nobody's stale order
    });
  }
  async listUnackedOutboundForCycle(cycleId: string) {
    return this.outbound.filter((m) => m.cycleId === cycleId && m.status === "sent");
  }
  async markOutboundImpliedAck(id: string) {
    const m = this.outbound.find((x) => x.id === id)!;
    m.status = "processed";
    const c = this.cycles.find((x) => x.id === m.cycleId);
    if (c && !c.patch.oml_ack) c.patch.oml_ack = "ORU";
  }
  outboundAcks: { cycleId: string | null; messageControlId: string; raw: string; sentAt: string }[] = [];
  async archiveOutboundAck(input: { cycleId: string | null; messageControlId: string; raw: string }, at: Date) {
    this.outboundAcks.push({ ...input, sentAt: at.toISOString() });
  }
}

// ─── Supabase implementation (production) ───

type Row = Record<string, unknown>;

export class SupabaseBridgeStore implements BridgeStore {
  constructor(private readonly admin: SupabaseClient) {}

  private toOutbound(r: Row): OutboundMessage {
    const cycle = (Array.isArray(r.test_cycles) ? r.test_cycles[0] : r.test_cycles) as Row | null;
    return {
      id: String(r.id),
      cycleId: String(r.cycle_id),
      messageControlId: String(r.message_control_id),
      raw: String(r.raw),
      filename: `${cycle?.kit_label_code ?? "UNKNOWN"}.OML`,
      status: r.status as OutboundMessage["status"],
      createdAt: String(r.created_at),
      sentAt: (r.sent_at as string | null) ?? null,
    };
  }

  async listQueuedOutbound() {
    const { data, error } = await this.admin
      .from("lab_messages")
      .select("id, cycle_id, message_control_id, raw, status, created_at, sent_at, test_cycles:cycle_id ( kit_label_code )")
      .eq("direction", "out")
      .eq("msg_type", "OML")
      .eq("status", "queued")
      .order("created_at", { ascending: true });
    if (error) throw error;
    return ((data ?? []) as Row[]).map((r) => this.toOutbound(r));
  }

  async markOutboundSent(id: string, at: Date) {
    const { data, error } = await this.admin
      .from("lab_messages")
      .update({ status: "sent", sent_at: at.toISOString() })
      .eq("id", id)
      .select("cycle_id")
      .single();
    if (error) throw error;
    const cycleId = (data as Row).cycle_id as string;
    await this.admin
      .from("test_cycles")
      .update({ status: "order_sent", oml_sent_at: at.toISOString(), updated_at: at.toISOString() })
      .eq("id", cycleId)
      .in("status", ["shipped", "activated"]);
    await this.admin.from("test_cycles").update({ oml_sent_at: at.toISOString() }).eq("id", cycleId).is("oml_sent_at", null);
  }

  async findOutboundByControlId(controlId: string) {
    const { data, error } = await this.admin
      .from("lab_messages")
      .select("id, cycle_id, message_control_id, raw, status, created_at, sent_at, test_cycles:cycle_id ( kit_label_code )")
      .eq("direction", "out")
      .eq("message_control_id", controlId)
      .maybeSingle();
    // A transient database error must surface as a failed file, never as
    // "unknown OML" — that answer goes to the lab and cannot be taken back.
    if (error) throw error;
    return data ? this.toOutbound(data as Row) : null;
  }

  async markOutboundAcked(id: string, ack: { ok: boolean; code: string; text?: string }, at: Date) {
    const { data, error } = await this.admin
      .from("lab_messages")
      .update({ status: ack.ok ? "processed" : "error", error: ack.ok ? null : `${ack.code} ${ack.text ?? ""}`.trim() })
      .eq("id", id)
      .select("cycle_id")
      .single();
    if (error) throw error;
    const cycleId = (data as Row).cycle_id as string;
    if (ack.ok) {
      await this.admin
        .from("test_cycles")
        .update({ status: "order_accepted", oml_ack: "CA", updated_at: at.toISOString() })
        .eq("id", cycleId)
        .in("status", ["shipped", "activated", "order_sent"]);
      // A CA that arrives late — after the results, or recovered from
      // procesados after an implied ORU ack — still records the truth.
      await this.admin
        .from("test_cycles")
        .update({ oml_ack: "CA" })
        .eq("id", cycleId)
        .or("oml_ack.is.null,oml_ack.eq.ORU");
    } else {
      await this.admin
        .from("test_cycles")
        .update({ status: "error", oml_ack: `CE:${ack.code}`, updated_at: at.toISOString() })
        .eq("id", cycleId);
    }
  }

  /**
   * Dedupe is per (direction, MSH-10) — migration 20260921000000. ECH's ACKs
   * carry OUR OML's MSH-10 as their own, so a table-wide UNIQUE made every
   * ACK look like a duplicate of the order it acknowledged (rounds 1–4).
   */
  async archiveInbound(input: ArchiveInboundInput): Promise<ArchiveInboundResult> {
    const { data, error } = await this.admin
      .from("lab_messages")
      .insert({
        cycle_id: input.cycleId ?? null,
        direction: "in",
        msg_type: input.msgType,
        message_control_id: input.messageControlId,
        raw: input.raw,
        status: "received",
      })
      .select("id")
      .single();
    if (error) {
      if (error.code !== "23505") throw error;
      // Already archived: hand back that row so the pass can see whether the
      // earlier attempt actually finished.
      const { data: existing, error: lookupError } = await this.admin
        .from("lab_messages")
        .select("id, status, cycle_id")
        .eq("direction", "in")
        .eq("message_control_id", input.messageControlId)
        .maybeSingle();
      if (lookupError) throw lookupError;
      const r = (existing ?? null) as Row | null;
      return {
        id: r ? String(r.id) : null,
        duplicate: true,
        status: (r?.status as ArchiveInboundResult["status"]) ?? "processed",
        cycleId: (r?.cycle_id as string | null) ?? null,
      };
    }
    return { id: (data as Row).id as string, duplicate: false };
  }

  async markInboundProcessed(id: string, error?: string, cycleId?: string | null) {
    const { error: updateError } = await this.admin
      .from("lab_messages")
      .update({ status: error ? "error" : "processed", error: error ?? null, ...(cycleId ? { cycle_id: cycleId } : {}) })
      .eq("id", id);
    if (updateError) throw updateError;
  }

  async findCycleByPlacer(placer: string) {
    const { data, error } = await this.admin
      .from("test_cycles")
      .select("id, user_id, status, seq, kit_label_code, placer_order_number, lab_result_id")
      .eq("placer_order_number", placer)
      .maybeSingle();
    // Same rule as findOutboundByControlId: a database error is not "no such
    // cycle" — that would send the lab a CE it has no reason to receive.
    if (error) throw error;
    if (!data) return null;
    const r = data as Row;
    return {
      id: String(r.id), userId: String(r.user_id), status: String(r.status), seq: Number(r.seq),
      kitLabelCode: (r.kit_label_code as string | null) ?? null, placerOrderNumber: (r.placer_order_number as string | null) ?? null,
      labResultId: (r.lab_result_id as string | null) ?? null,
    };
  }

  /** The seed's localized name per mapped key — the desk and the patient see `biomarker_name`. */
  private async mapForPipeline(cycle: BridgeCycle, parsed: LabProviderResult) {
    const keys = Array.from(new Set(parsed.biomarkers.map((b) => EchevarneProvider.mapBiomarkerName(b.biomarker_key, b.loincCode)).filter(Boolean)));
    const [{ data: profile }, { data: refs }] = await Promise.all([
      this.admin.from("profiles").select("locale").eq("id", cycle.userId).maybeSingle(),
      keys.length ? this.admin.from("biomarker_references").select("biomarker_key, name_en, name_es").in("biomarker_key", keys) : Promise.resolve({ data: [] as Row[] }),
    ]);
    const es = String((profile as Row | null)?.locale ?? "es").startsWith("es");
    const nameByKey = new Map<string, string>();
    for (const r of (refs ?? []) as Row[]) {
      const name = es ? r.name_es ?? r.name_en : r.name_en ?? r.name_es;
      if (typeof name === "string" && !nameByKey.has(String(r.biomarker_key))) nameByKey.set(String(r.biomarker_key), name);
    }
    return parsed.biomarkers.map((b) => {
      const key = EchevarneProvider.mapBiomarkerName(b.biomarker_key, b.loincCode);
      const comparator = b.comparator ? { comparator: b.comparator } : {};
      return key
        ? { name: nameByKey.get(key) ?? key, biomarkerKey: key, matchConfidence: "exact" as const, value: b.value, unit: b.unit, ...comparator }
        : { name: b.biomarker_key, value: b.value, unit: b.unit, ...comparator };
    });
  }

  async recordResults(cycle: BridgeCycle, parsed: LabProviderResult, at: Date): Promise<RecordedResults> {
    const mapped = await this.mapForPipeline(cycle, parsed);

    // One result per cycle: a final report after a partial one, or a
    // corrected report, replaces the values of the result the cycle already
    // has (decision 2026-09-22) — never a second lab_results, never a second
    // email. Falls through to a fresh insert only if that result was deleted.
    if (cycle.labResultId) {
      const replaced = await this.replaceResults(cycle, parsed, mapped, at);
      if (replaced) return replaced;
    }

    const { data: lab, error } = await this.admin
      .from("lab_results")
      .insert({
        user_id: cycle.userId,
        source: "echevarne",
        panel_type: "lab_partner",
        status: "pending_context",
        collection_date: parsed.collectionDate,
        lab_notes: parsed.textNotes ?? [],
        strengths: [],
        needs_attention: [],
      })
      .select("id")
      .single();
    if (error || !lab) throw new Error(`lab_results insert failed: ${error?.message ?? ""}`);
    const labResultId = (lab as Row).id as string;

    // Units come straight from the lab's OBX-6, so they are trusted as
    // reported: no magnitude arbitration on cell counts (2026-09-21).
    let result: Awaited<ReturnType<typeof processLabResults>>;
    try {
      result = await processLabResults(cycle.userId, labResultId, mapped, this.admin, { trustUnits: true });
    } catch (e) {
      // Nothing half-recorded may survive: the empty lab_results row would
      // otherwise sit orphaned (biomarker_values cascade with it) while the
      // inbound message is retried on the next pass.
      await this.admin.from("lab_results").delete().eq("id", labResultId);
      throw e;
    }
    // The webhook path always told the patient; the bridge path did not
    // (found 2026-09-21: a result sat invisible, waiting for context).
    await this.notifyContextNeeded(cycle.userId, labResultId, result.processed.length);

    await this.admin
      .from("test_cycles")
      .update({ lab_result_id: labResultId, updated_at: at.toISOString() })
      .eq("id", cycle.id);

    return { labResultId, processed: result.processed.length, unmatched: result.unmatched?.length ?? 0, replaced: false };
  }

  /**
   * Replace the values of the cycle's existing result with a new report's.
   * The row keeps its id, status and the patient's context; if the
   * interpretation had already been generated it is generated again over
   * the corrected values. Returns null when the result no longer exists.
   */
  private async replaceResults(
    cycle: BridgeCycle,
    parsed: LabProviderResult,
    mapped: Awaited<ReturnType<SupabaseBridgeStore["mapForPipeline"]>>,
    at: Date,
  ): Promise<RecordedResults | null> {
    const labResultId = cycle.labResultId!;
    const { data: lab, error } = await this.admin.from("lab_results").select("id, status").eq("id", labResultId).maybeSingle();
    if (error) throw error;
    if (!lab) return null;

    const { error: deleteError } = await this.admin.from("biomarker_values").delete().eq("lab_result_id", labResultId);
    if (deleteError) throw deleteError;
    const result = await processLabResults(cycle.userId, labResultId, mapped, this.admin, { trustUnits: true });
    const { error: updateError } = await this.admin
      .from("lab_results")
      .update({ collection_date: parsed.collectionDate, lab_notes: parsed.textNotes ?? [], corrected_at: at.toISOString() })
      .eq("id", labResultId);
    if (updateError) throw updateError;

    if (String((lab as Row).status) === "ready") {
      await this.regenerateInterpretation(cycle.userId, labResultId, (parsed.textNotes ?? []).map((n) => n.text));
    }
    await this.admin.from("test_cycles").update({ updated_at: at.toISOString() }).eq("id", cycle.id);
    return { labResultId, processed: result.processed.length, unmatched: result.unmatched?.length ?? 0, replaced: true };
  }

  /** The interpretation a corrected result carries must describe the corrected values. Never fatal. */
  private async regenerateInterpretation(userId: string, labResultId: string, labNotes: string[]): Promise<void> {
    try {
      const [{ getUserProfile, getBiomarkerValues, getWearableData }, { generateSummary }] = await Promise.all([
        import("@/lib/queries"),
        import("@/lib/ai/generate-summary"),
      ]);
      const [profile, values, wearable] = await Promise.all([
        getUserProfile(userId, this.admin),
        getBiomarkerValues(labResultId, this.admin),
        getWearableData(userId, 30, this.admin),
      ]);
      if (!profile || values.length === 0) return;
      const processed = values.map((b) => ({
        biomarkerKey: b.biomarker_key,
        name: b.biomarker_name ?? b.biomarker_key,
        value: b.value,
        unit: b.unit ?? "",
        comparator: b.comparator ?? null,
        zone: b.zone as ProcessedBiomarker["zone"],
        zoneLabel: "",
        zoneLabel_es: "",
        optimalLow: b.optimal_low,
        optimalHigh: b.optimal_high,
        matchConfidence: "exact" as const,
      }));
      await this.admin.from("lab_results").update({ status: "processing" }).eq("id", labResultId);
      try {
        await generateSummary(userId, labResultId, processed, wearable.length ? wearable : null, profile, this.admin, { labNotes });
      } finally {
        await this.admin.from("lab_results").update({ status: "ready" }).eq("id", labResultId);
      }
    } catch (e) {
      console.error("[lab-bridge] interpretation could not be regenerated after a corrected report", e);
    }
  }

  /** Same email the webhook path sends: "your results are in, confirm the context". Never fatal. */
  private async notifyContextNeeded(userId: string, labResultId: string, biomarkerCount: number): Promise<void> {
    try {
      const { data } = await this.admin.from("profiles").select("email, full_name, locale").eq("id", userId).maybeSingle();
      const p = (data ?? null) as Row | null;
      const email = typeof p?.email === "string" ? p.email : "";
      if (!email) return;
      const locale = String(p?.locale ?? "es").slice(0, 2);
      const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
      const { sendEmail } = await import("@/lib/email/send");
      await sendEmail(
        email,
        "context-needed",
        {
          firstName: String(p?.full_name ?? "").split(" ")[0] ?? "",
          biomarkerCount,
          contextUrl: `${appUrl}/${locale}/labs/${labResultId}/context`,
          locale,
        },
        locale,
      );
    } catch (e) {
      console.error("[lab-bridge] context-needed email failed", e);
    }
  }

  async setCycleStatus(cycleId: string, status: string, patch: Record<string, unknown> = {}) {
    await this.admin.from("test_cycles").update({ status, updated_at: new Date().toISOString(), ...patch }).eq("id", cycleId);
  }

  /**
   * The timeout is measured from the upload, not from the queueing: an order
   * can sit queued for days (ECH's mailbox denied writes 09-09→09-15) and must
   * not be reported stale the moment it finally goes out. `sent_at` is null
   * only for rows written before the column existed; `.lt` drops them, which is
   * the safe side (we under-alert rather than cry wolf).
   */
  async listSentWithoutAck(before: Date) {
    const { data } = await this.admin
      .from("lab_messages")
      .select("id, cycle_id, message_control_id, raw, status, created_at, sent_at, test_cycles:cycle_id!inner ( kit_label_code, status )")
      .eq("direction", "out")
      .eq("msg_type", "OML")
      .eq("status", "sent")
      .lt("sent_at", before.toISOString())
      // A cancelled cycle (e.g. a petition number ECH says is already used,
      // resent under another) must not keep crying "no ACK" every pass.
      .neq("test_cycles.status", "cancelled");
    return ((data ?? []) as Row[]).map((r) => this.toOutbound(r));
  }

  async listUnackedOutboundForCycle(cycleId: string) {
    const { data } = await this.admin
      .from("lab_messages")
      .select("id, cycle_id, message_control_id, raw, status, created_at, sent_at, test_cycles:cycle_id ( kit_label_code )")
      .eq("direction", "out")
      .eq("msg_type", "OML")
      .eq("cycle_id", cycleId)
      .eq("status", "sent");
    return ((data ?? []) as Row[]).map((r) => this.toOutbound(r));
  }

  async markOutboundImpliedAck(id: string, at: Date) {
    const { data, error } = await this.admin
      .from("lab_messages")
      .update({ status: "processed" })
      .eq("id", id)
      .select("cycle_id")
      .single();
    if (error) throw error;
    const cycleId = (data as Row).cycle_id as string;
    // Only when nothing was recorded: a real CA/CE, if one ever came, wins.
    await this.admin
      .from("test_cycles")
      .update({ oml_ack: "ORU", updated_at: at.toISOString() })
      .eq("id", cycleId)
      .is("oml_ack", null);
  }

  async archiveOutboundAck(input: { cycleId: string | null; messageControlId: string; raw: string }, at: Date) {
    const { error } = await this.admin.from("lab_messages").insert({
      cycle_id: input.cycleId,
      direction: "out",
      msg_type: "ACK",
      message_control_id: input.messageControlId,
      raw: input.raw,
      status: "sent",
      sent_at: at.toISOString(),
    });
    // 23505 = same control id twice (re-ACK of a re-delivered ORU within one second): already archived.
    if (error && error.code !== "23505") throw error;
  }
}
