import Stripe from "stripe";
import { createClient } from "@/lib/supabase/server";

export function getStripe() {
  return new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2026-03-25.dahlia" });
}

/**
 * Grace window after subscription_period_end during which "active" still
 * counts. Covers webhook delivery lag around renewals without granting
 * meaningful free access; a missed cancellation webhook now expires access
 * days after the paid period instead of never.
 */
const PERIOD_END_GRACE_MS = 3 * 24 * 60 * 60 * 1000;

/**
 * "active" must be backed by a paid period that hasn't lapsed. A NULL
 * period_end passes (legacy rows and the moment between checkout and the
 * first subscription.updated webhook); a period_end older than the grace
 * window fails even if a lost webhook left the status stuck on "active".
 */
function activeWithinPeriod(profile: {
  subscription_status?: string | null;
  subscription_period_end?: string | null;
}): boolean {
  if (profile.subscription_status !== "active") return false;
  const end = profile.subscription_period_end;
  if (!end) return true;
  const endMs = Date.parse(end);
  if (Number.isNaN(endMs)) return true;
  return endMs + PERIOD_END_GRACE_MS > Date.now();
}

export async function isActiveSubscriber(userId: string): Promise<boolean> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select("subscription_status, subscription_period_end")
    .eq("id", userId)
    .single();
  return data ? activeWithinPeriod(data) : false;
}

/**
 * Decide whether a profile has access to paid-only features (EVA AI
 * chat, wearable imports). Two distinct paid paths qualify:
 *
 *   1. An active recurring quarterly subscription
 *      (subscription_status === "active").
 *   2. A completed Full Panel one-time purchase
 *      (full_panel_purchased_at is set).
 *
 * "past_due" intentionally does NOT qualify so the gate stays simple.
 * Once Stripe flips
 * a recovered subscription back to "active" via the webhook, access
 * resumes automatically.
 *
 * "active" is additionally bounded by subscription_period_end plus a
 * grace window — a lost cancellation webhook no longer grants access
 * forever. Callers should select subscription_period_end alongside the
 * other two columns (a missing field behaves like NULL = no bound).
 *
 * Pure function: takes the columns it needs so it can be called from
 * server routes (after a DB read) and from RSC pages (using the
 * profile already fetched for the layout) without refetching.
 */
export function hasPaidAccess(
  profile:
    | {
        subscription_status?: string | null;
        subscription_period_end?: string | null;
        full_panel_purchased_at?: string | null;
      }
    | null
    | undefined,
): boolean {
  if (!profile) return false;
  if (activeWithinPeriod(profile)) return true;
  if (profile.full_panel_purchased_at) return true;
  return false;
}

/**
 * Server-side variant: looks up the columns from Supabase and returns
 * the boolean. Use this in API routes that don't already have the
 * profile loaded.
 */
export async function userHasPaidAccess(userId: string): Promise<boolean> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select("subscription_status, subscription_period_end, full_panel_purchased_at")
    .eq("id", userId)
    .single();
  return hasPaidAccess(data);
}

export async function getSubscriptionDetails(userId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select("subscription_status, subscription_period_end, stripe_customer_id")
    .eq("id", userId)
    .single();
  return data;
}

export function getCurrentQuarter(): string {
  const now = new Date();
  const q = Math.ceil((now.getMonth() + 1) / 3);
  return `${now.getFullYear()}-Q${q}`;
}

export async function getOrCreateCustomer(
  userId: string,
  email: string,
): Promise<string> {
  const supabase = await createClient();
  const { data: profile } = await supabase
    .from("profiles")
    .select("stripe_customer_id")
    .eq("id", userId)
    .single();

  if (profile?.stripe_customer_id) {
    return profile.stripe_customer_id;
  }

  const stripe = getStripe();
  const customer = await stripe.customers.create({
    email,
    metadata: { userId },
  });

  await supabase
    .from("profiles")
    .update({ stripe_customer_id: customer.id })
    .eq("id", userId);

  return customer.id;
}
