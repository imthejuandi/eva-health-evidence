export interface KitShippedData {
  firstName: string;
  panelName: string;
  trackingNumber?: string | null;
  trackingUrl?: string | null;
  locale: string;
}

export function renderKitShipped(data: KitShippedData, locale: string): string {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
  const dashboardUrl = `${appUrl}/${locale}/book`;
  const trackBlock =
    data.trackingNumber && data.trackingUrl
      ? `<p style="margin-top: 16px;"><a href="${data.trackingUrl}" class="cta">${
          locale === "es" ? "Seguir el envio" : "Track shipment"
        }</a><br><span style="font-size:11px;color:#8a7f76;font-family:monospace;">${data.trackingNumber}</span></p>`
      : data.trackingNumber
        ? `<p style="margin-top: 12px; font-family: monospace; font-size: 12px; color: #4c463f;">${
            locale === "es" ? "Seguimiento" : "Tracking"
          }: ${data.trackingNumber}</p>`
        : "";

  if (locale === "es") {
    return `
      <h1>Tu kit esta en camino, ${data.firstName}</h1>
      <div style="margin: 20px 0;">
        <span class="stat">${data.panelName}</span>
      </div>
      <p>Hemos preparado tu kit y ya esta de camino a tu direccion. Llegara en los proximos 3-5 dias habiles.</p>
      ${trackBlock}
      <hr class="divider">
      <p style="font-weight: 700; margin-bottom: 8px;">Cuando llegue:</p>
      <ol style="padding-left: 20px;">
        <li style="margin-bottom: 6px;">Abre el kit y lee las instrucciones</li>
        <li style="margin-bottom: 6px;">Recoge tu muestra siguiendo el paso a paso (500µL, sin aguja)</li>
        <li style="margin-bottom: 6px;">Envia la muestra con el sobre prepagado el mismo dia</li>
      </ol>
      <a href="${dashboardUrl}" class="cta">Ver el estado de mi kit</a>
    `;
  }
  return `
    <h1>Your kit is on its way, ${data.firstName}</h1>
    <div style="margin: 20px 0;">
      <span class="stat">${data.panelName}</span>
    </div>
    <p>We've prepared your kit and it's heading to you now. Expect it in the next 3-5 business days.</p>
    ${trackBlock}
    <hr class="divider">
    <p style="font-weight: 700; margin-bottom: 8px;">When it arrives:</p>
    <ol style="padding-left: 20px;">
      <li style="margin-bottom: 6px;">Open the kit and read the instructions</li>
      <li style="margin-bottom: 6px;">Collect your sample following the steps (500µL, no needle)</li>
      <li style="margin-bottom: 6px;">Mail the sample back the same day with the prepaid envelope</li>
    </ol>
    <a href="${dashboardUrl}" class="cta">Track my kit</a>
  `;
}
