/**
 * The one-line summary of a bridge pass, shared by the admin desk (live
 * result and persisted history) and the run log. Kept free of server-only
 * imports so the client bundle can use it.
 */
export interface BridgePassSummary {
  uploaded: string[];
  acks: string[];
  orus: string[];
  duplicates: string[];
  /** ORUs processed again because an earlier pass archived them but never finished. Absent on rows logged before 2026-09-22. */
  retried?: string[];
  /** Final/corrected reports (MSH-10) that replaced the values of a cycle's existing result. Absent before 2026-09-22. */
  corrected?: string[];
  otherEnvironment: string[];
  errors: { file: string; error: string }[];
  alerts: { scope: string; message: string; meta?: Record<string, unknown> }[];
  ms: number;
  processingId: "P" | "T";
}

export function formatBridgeSummary(s: BridgePassSummary): string {
  const list = (xs: string[]) => xs.join(", ") || "—";
  const retried = s.retried?.length ? ` · retried ${s.retried.length} (${list(s.retried)})` : "";
  const corrected = s.corrected?.length ? ` · corrected ${s.corrected.length} (${list(s.corrected)})` : "";
  return (
    `[${s.processingId}] uploaded ${s.uploaded.length} (${list(s.uploaded)}) · ACKs ${s.acks.length} (${list(s.acks)})` +
    ` · ORUs ${s.orus.length} (${list(s.orus)})${retried}${corrected} · duplicates ${s.duplicates.length} · other env ${s.otherEnvironment.length}` +
    ` · errors ${s.errors.length}${s.errors.length ? ": " + s.errors.map((e) => `${e.file}: ${e.error}`).join("; ") : ""}` +
    ` · alerts ${s.alerts.length}${s.alerts.length ? ": " + s.alerts.map((a) => a.message).join("; ") : ""}` +
    ` · ${s.ms} ms`
  );
}

/** "3 min ago" style relative time for the desk; falls back to the ISO date past a day. */
export function ago(iso: string, now: Date = new Date()): string {
  const s = Math.max(0, Math.round((now.getTime() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  return iso.slice(0, 16).replace("T", " ");
}
