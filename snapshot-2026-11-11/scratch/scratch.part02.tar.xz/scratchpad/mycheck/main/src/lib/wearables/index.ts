export type { WearableAdapter, WearableDayData, WearableImportResult } from "./interface";
export { AppleHealthAdapter } from "./apple-health";
export { OuraAdapter } from "./oura";
export { WhoopAdapter } from "./whoop";
export { GarminAdapter } from "./garmin";

import type { WearableAdapter } from "./interface";
import { AppleHealthAdapter } from "./apple-health";

const adapters: Record<string, () => WearableAdapter> = {
  apple_health: () => new AppleHealthAdapter(),
};

export function getAdapter(source: string): WearableAdapter {
  const factory = adapters[source];
  if (!factory) throw new Error(`Unknown wearable source: ${source}`);
  return factory();
}
