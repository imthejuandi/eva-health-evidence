/**
 * One bridge pass wired to the real world (env → SFTP + Supabase). Shared by
 * the cron route (scheduled, CRON_SECRET) and the admin trigger (manual,
 * admin session) so both run exactly the same code.
 */
import { createAdminClient } from "@/lib/supabase/admin";
import { opsAlert, opsOk } from "@/lib/ops-alert";
import { readSftpConfigFromEnv, connectRealSftp } from "./sftp";
import { SupabaseBridgeStore } from "./store";
import { runBridgeSync, type BridgeSyncReport } from "./sync";
import { processingIdFromEnv } from "./panel-codes";
import { formatBridgeSummary, type BridgePassSummary } from "./summary";
import { sweepCompletableCycles } from "@/lib/cycles/close-cycle";
import type { SupabaseClient } from "@supabase/supabase-js";

export type { BridgePassSummary } from "./summary";

/**
 * One row per pass in `lab_bridge_runs` — the desk's only window into the
 * unattended cron. Never fatal: a pass that ran must never be reported as
 * failed because its log line could not be written. Prunes rows older than
 * 90 days on the way.
 */
async function logRun(
  admin: SupabaseClient,
  row: { started_at: Date; trigger: string; processing_id: "P" | "T"; ok: boolean; error?: string; summary?: BridgePassSummary },
): Promise<void> {
  try {
    const s = row.summary;
    await admin.from("lab_bridge_runs").insert({
      started_at: row.started_at.toISOString(),
      finished_at: new Date().toISOString(),
      trigger: row.trigger,
      processing_id: row.processing_id,
      ok: row.ok,
      error: row.error ?? null,
      uploaded: s?.uploaded.length ?? 0,
      acks: s?.acks.length ?? 0,
      orus: s?.orus.length ?? 0,
      duplicates: s?.duplicates.length ?? 0,
      other_env: s?.otherEnvironment.length ?? 0,
      errors: s?.errors ?? [],
      alerts: s?.alerts ?? [],
      summary: s ? formatBridgeSummary(s) : `[${row.processing_id}] ${row.error ?? "failed"}`,
      ms: s?.ms ?? null,
    });
    await admin.from("lab_bridge_runs").delete().lt("started_at", new Date(Date.now() - 90 * 86_400_000).toISOString());
  } catch (e) {
    console.error("[lab-bridge] could not log the run", e);
  }
}

export type BridgePassResult =
  | { ok: true; summary: BridgePassSummary }
  | { ok: false; status: 503; error: string };

/**
 * Explicit on/off switch, separate from the credentials. Preview (staging,
 * MSH-11 = T) and Production (P) share Echevarne's single mailbox, and the
 * first pass that runs takes each file — so Production must hold its
 * credentials without polling until it gets its own mailbox (asked ECH,
 * 2026-09-17). Anything but the literal "true" keeps the bridge dormant:
 * cron ticks and the admin button both answer 503 and touch nothing.
 */
export function bridgeEnabledFromEnv(env: NodeJS.ProcessEnv = process.env): boolean {
  return env.ECH_BRIDGE_ENABLED === "true";
}

export async function runBridgePassFromEnv(trigger: string): Promise<BridgePassResult> {
  if (!bridgeEnabledFromEnv()) return { ok: false, status: 503, error: "Bridge disabled (ECH_BRIDGE_ENABLED is not \"true\")" };
  const cfg = readSftpConfigFromEnv();
  if (!cfg) return { ok: false, status: 503, error: "ECH_SFTP_* not configured" };
  const admin = createAdminClient();
  if (!admin) return { ok: false, status: 503, error: "Service role not configured" };

  const started = Date.now();
  const processingId = processingIdFromEnv();
  if (processingId === "P" && !cfg.hostKeySha256) {
    // Not blocking (the fingerprint has to come from ECH first), but never silent.
    opsAlert("lab-bridge", "SFTP host key is not pinned in production: set ECH_SFTP_HOST_KEY_SHA256 (fingerprint from Echevarne) so the bridge refuses any other server", { trigger });
  }
  let conn: Awaited<ReturnType<typeof connectRealSftp>>;
  try {
    conn = await connectRealSftp(cfg);
  } catch (e) {
    const error = `SFTP connection failed: ${e instanceof Error ? e.message : String(e)}`;
    opsAlert("lab-bridge", error, { trigger });
    await logRun(admin, { started_at: new Date(started), trigger, processing_id: processingId, ok: false, error });
    return { ok: false, status: 503, error };
  }
  try {
    const report: BridgeSyncReport = await runBridgeSync({
      sftp: conn.sftp,
      store: new SupabaseBridgeStore(admin),
      now: new Date(),
      baseDir: process.env.ECH_SFTP_BASE_DIR ?? "/files",
      processingId: processingIdFromEnv(),
      // ECH's mailbox refuses .tmp files, so direct write is the default.
      atomicUpload: process.env.ECH_SFTP_ATOMIC_UPLOAD === "true",
      // Only once ECH echoes our MSH-11 in its ORUs (asked 2026-09-17).
      honourProcessingId: process.env.ECH_HONOUR_PROCESSING_ID === "true",
      onAlert: (a) => opsAlert(a.scope, a.message, a.meta),
    });
    // Cycles whose result has been interpreted close here too (results_final
    // → completed), so a missed call at the moment the lab turned 'ready'
    // never leaves a cycle open for the scheduler. Never fails the pass.
    try {
      const swept = await sweepCompletableCycles(admin);
      if (swept.stuckWithoutResult.length) {
        const a = { scope: "bridge.cycles", message: "results_final cycles with no lab result — need Ops", meta: { cycleIds: swept.stuckWithoutResult } };
        report.alerts.push(a);
        opsAlert(a.scope, a.message, a.meta);
      }
    } catch (e) {
      report.errors.push({ file: "test_cycles", error: `completion sweep failed: ${e instanceof Error ? e.message : String(e)}` });
    }
    const summary: BridgePassSummary = {
      uploaded: report.uploaded,
      acks: report.acksProcessed,
      orus: report.orusProcessed,
      duplicates: report.duplicates,
      retried: report.retried,
      corrected: report.corrected,
      otherEnvironment: report.otherEnvironment,
      errors: report.errors,
      alerts: report.alerts,
      ms: Date.now() - started,
      processingId: processingIdFromEnv(),
    };
    const meta = { trigger, uploaded: summary.uploaded.length, acks: summary.acks.length, orus: summary.orus.length, errors: summary.errors.length, ms: summary.ms };
    if (report.errors.length) opsAlert("lab-bridge", "pass finished with errors", { ...meta, errors: report.errors });
    else opsOk("lab-bridge", "pass ok", meta);
    await logRun(admin, { started_at: new Date(started), trigger, processing_id: processingId, ok: true, summary });
    return { ok: true, summary };
  } finally {
    await conn.close().catch(() => undefined);
  }
}
