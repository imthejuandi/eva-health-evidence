import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { buildOrderMessage, estimatedExtraction, toHl7DateTime, type OutboxCycle } from "./outbox";
import { patientReadiness, toOmlPatient, hl7Date, type PatientProfileSlice } from "./patient-mapper";
import { orderCodesForPanel, panelIsOrderable, panelCodesFor } from "./panel-codes";

const PANEL_CODES = {
  base: [
    { code: "GLU", description: "GLUCOSA / SUERO" },
    { code: "COL", description: "COLESTEROL / SUERO" },
    { code: "H", description: "HEMOGRAMA" },
  ],
};

// Legacy shape on purpose (both surnames in last_name, no second_surname):
// exercises the fallback path that pre-2026-09-09 rows still take.
const profile: PatientProfileSlice = {
  id: "u1", patient_number: 42, first_name: "Josefa", last_name: "García Rodríguez", full_name: "Josefa García Rodríguez",
  date_of_birth: "1989-01-27", sex: "female", phone: "+34 931 478 526", locale: "es",
  id_document_type: "DNI", id_document_number: "12345678Z",
};

const cycle: OutboxCycle = {
  id: "c1", seq: 1, panel_type: "base", placer_order_number: null, kit_label_code: "X68800191", extraction_confirmed_at: null,
};

describe("patient readiness — everything PID needs must exist before Ship", () => {
  it("accepts a complete profile and maps it to the spec's PID shape", () => {
    expect(patientReadiness(profile)).toEqual({ ready: true, missing: [] });
    const p = toOmlPatient(profile);
    expect(p).toMatchObject({
      document: { type: "DNI", number: "12345678Z" }, nhc: "EVA000042",
      firstName: "JOSEFA", surname1: "GARCÍA", surname2: "RODRÍGUEZ", birthDate: "19890127", sex: "F",
      phones: ["+34931478526"], languageCode: "8",
    });
  });

  it("uses the explicit second_surname and keeps a compound primer apellido intact", () => {
    const compound = {
      ...profile,
      last_name: "García de la Torre",
      second_surname: "Ruiz",
    };
    expect(patientReadiness(compound)).toEqual({ ready: true, missing: [] });
    const p = toOmlPatient(compound);
    expect(p.surname1).toBe("GARCÍA DE LA TORRE");
    expect(p.surname2).toBe("RUIZ");
  });

  it("falls back to splitting last_name only on legacy rows (no second_surname)", () => {
    const legacy = { ...profile, last_name: "García Rodríguez", second_surname: null };
    const p = toOmlPatient(legacy);
    expect(p.surname1).toBe("GARCÍA");
    expect(p.surname2).toBe("RODRÍGUEZ");
  });

  it("lists every missing field instead of emitting a half PID", () => {
    const r = patientReadiness({ ...profile, date_of_birth: null, sex: null, id_document_number: null });
    expect(r.ready).toBe(false);
    expect(r.missing).toEqual(["date_of_birth", "sex", "id_document"]);
    expect(() => toOmlPatient({ ...profile, sex: null })).toThrow(/missing sex/);
  });

  it("a single surname does not block the shipment — ECH does not require PID-6", () => {
    const foreigner = { ...profile, first_name: "John", last_name: "Smith", second_surname: null };
    expect(patientReadiness(foreigner)).toEqual({ ready: true, missing: [] });
    expect(toOmlPatient(foreigner).surname2).toBe("");
  });

  it("reads both date formats and rejects garbage", () => {
    expect(hl7Date("1989-01-27")).toBe("19890127");
    expect(hl7Date("27/01/1989")).toBe("19890127");
    expect(hl7Date("January 27")).toBeNull();
  });
});

describe("panel order codes — fail closed until the medical decision", () => {
  it("throws for a panel with no configured codes (Full Panel is still undecided)", () => {
    expect(panelIsOrderable("full")).toBe(false);
    expect(() => orderCodesForPanel("full")).toThrow(/no Echevarne order codes/);
  });

  it("Base Panel orders the 13 catalog codes fixed on 2026-09-22 (one serum tube)", () => {
    const codes = orderCodesForPanel("base").map((c) => c.code);
    expect(codes).toEqual(["ALBS", "FAL", "PCUL", "CR1", "BUN", "AU1", "COL", "HDLC", "TRIG", "APOB", "GPT", "GGT", "FRUC"]);
    // A configured production panel wins in training too.
    expect(orderCodesForPanel("base", panelCodesFor("T")).map((c) => c.code)).toEqual(codes);
    expect(panelIsOrderable("base", panelCodesFor("P"))).toBe(true);
  });
  it("returns copies when configured", () => {
    const codes = orderCodesForPanel("base", PANEL_CODES);
    expect(codes.map((c) => c.code)).toEqual(["GLU", "COL", "H"]);
    codes[0].code = "MUTATED";
    expect(PANEL_CODES.base[0].code).toBe("GLU");
  });
});

describe("buildOrderMessage — initial (estimated) and update (real) OMLs", () => {
  beforeEach(() => {
    process.env.ECH_MSH_SENDING_APP = "EVAHEALTH";
    process.env.ECH_MSH_SENDING_FACILITY = "EVAHEALTH";
  });
  afterEach(() => {
    delete process.env.ECH_MSH_SENDING_APP;
    delete process.env.ECH_MSH_SENDING_FACILITY;
  });
  const now = new Date("2026-09-08T10:00:00Z"); // 12:00 Europe/Madrid (CEST)

  it("formats HL7 datetimes in the lab's timezone", () => {
    expect(toHl7DateTime(now)).toBe("20260908120000");
    expect(estimatedExtraction(now)).toBe("20260911090000");
  });

  it("initial OML: file named by the sticker, placer derived from patient_number, estimated extraction", () => {
    const m = buildOrderMessage({ cycle, profile, kind: "initial", now, messageSeq: 1, processingId: "T", panelCodes: PANEL_CODES });
    expect(m.filename).toBe("X68800191.OML");
    expect(m.placerOrderNumber).toBe("EVA000042001");
    expect(m.messageControlId).toBe("EVA000042001M1");
    expect(m.messageControlId.length).toBeLessThanOrEqual(20);
    expect(m.extractionDateTime).toBe("20260911090000");
    const lines = m.raw.split("\r");
    expect(lines[0]).toContain("|OML^O21|EVA000042001M1|T|2.5|");
    expect(lines[1]).toContain("PID|1||12345678Z^^^^DNI~EVA000042^^^^NHC||GARCÍA^JOSEFA|RODRÍGUEZ|19890127|F");
    expect(lines.filter((l) => l.startsWith("OBR|"))).toHaveLength(3);
    const orc = lines.find((l) => l.startsWith("ORC|"))!.split("|");
    expect(orc[2]).toBe("EVA000042001");
    expect(orc[3]).toBe("X68800191");
    expect(orc[15]).toBe("20260911090000");
  });

  it("update OML: same placer, next message id, REAL extraction from the cycle", () => {
    const m = buildOrderMessage({
      cycle: { ...cycle, placer_order_number: "EVA000042001", extraction_confirmed_at: "2026-09-10T06:30:00Z" },
      profile, kind: "update", now, messageSeq: 2, processingId: "T", panelCodes: PANEL_CODES,
    });
    expect(m.placerOrderNumber).toBe("EVA000042001");
    expect(m.messageControlId).toBe("EVA000042001M2");
    expect(m.extractionDateTime).toBe("20260910083000"); // 06:30Z = 08:30 Madrid
  });

  it("refuses to build without sticker, without real date on update, or with an unconfigured panel", () => {
    expect(() => buildOrderMessage({ cycle: { ...cycle, kit_label_code: null }, profile, kind: "initial", now, messageSeq: 1, processingId: "T", panelCodes: PANEL_CODES })).toThrow(/kit_label_code/);
    expect(() => buildOrderMessage({ cycle, profile, kind: "update", now, messageSeq: 2, processingId: "T", panelCodes: PANEL_CODES })).toThrow(/extraction_confirmed_at/);
    // An undecided panel still fails closed …
    expect(() => buildOrderMessage({ cycle: { ...cycle, panel_type: "full" }, profile, kind: "initial", now, messageSeq: 1, processingId: "P" })).toThrow(/no Echevarne order codes/);
    // … and the Base Panel orders its 13 catalog codes (2026-09-22) with no table passed in.
    const real = buildOrderMessage({ cycle, profile, kind: "initial", now, messageSeq: 1, processingId: "P" });
    const obrs = real.raw.split("\r").filter((l) => l.startsWith("OBR|"));
    expect(obrs).toHaveLength(13);
    expect(obrs.map((l) => l.split("|")[4].split("^")[0])).toEqual(["ALBS", "FAL", "PCUL", "CR1", "BUN", "AU1", "COL", "HDLC", "TRIG", "APOB", "GPT", "GGT", "FRUC"]);
  });
});
