/**
 * Canonical unit lookup and unit string normalization.
 *
 * The seed JSONs assign each biomarker_key a single canonical unit
 * ("Lymphocytes (Absolute)" → "x10³/µL", "Glucose (Fasting)" → "mg/dL", …).
 * Labs report the same biomarkers in many notational variants ("10e3/uL",
 * "K/µL", "mg/dl", "mcg/dL", "umol/l"). We need to:
 *
 *   1. Normalize a raw unit string into a canonical comparable form so
 *      "10e3/µL", "10^3/uL", "x10³/µL", "K/µL" all collapse to the same key.
 *   2. Look up the seed-defined canonical unit for any biomarker_key.
 *   3. Decide whether two units "match" after normalization.
 *
 * This module is the single source of truth for "what unit does this
 * biomarker want?" — convertBiomarker handles numeric scaling, this
 * module handles identity comparison + lookup.
 */

import enDataRaw from "../../../supabase/seed-data/biomarker-ranges-en.json";

interface EnRow {
  Biomarker: string;
  Unit: string;
}

// ─── Build canonical map at module load ───
// One entry per biomarker_key. Same key with different units (which
// shouldn't happen in our seed, but defensively) keeps the first one.

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

const enRows = (enDataRaw as { biomarker_ranges: EnRow[] }).biomarker_ranges;

const CANONICAL_UNIT_BY_KEY: Map<string, string> = new Map();
for (const r of enRows) {
  const key = slugify(r.Biomarker);
  if (!CANONICAL_UNIT_BY_KEY.has(key)) {
    CANONICAL_UNIT_BY_KEY.set(key, r.Unit ?? "");
  }
}

/**
 * Look up the seed's canonical unit for a biomarker_key.
 * Returns null if the key isn't in the seed.
 */
export function getCanonicalUnit(biomarkerKey: string): string | null {
  return CANONICAL_UNIT_BY_KEY.get(biomarkerKey) ?? null;
}

// ─── Unit string normalization ───

/**
 * Normalize a unit string to a canonical comparable form.
 *
 *   "x10³/µL"  → "10^3/ul"
 *   "10e3/µL"  → "10^3/ul"
 *   "10^3/uL"  → "10^3/ul"
 *   "K/µL"     → "10^3/ul"
 *   "mg/dL"    → "mg/dl"
 *   "µmol/L"   → "umol/l"
 *   "mcg/dL"   → "ug/dl"
 *   "%"        → "%"
 *
 * Rules:
 *   1. Lowercase, strip whitespace.
 *   2. Replace common Greek/notation chars: µ→u, ³→3, ⁶→6, ⁹→9, ×→x.
 *   3. Replace mcg with ug, mc with u (for micro).
 *   4. K-prefix collapses to 10^3, M-prefix to 10^6.
 *   5. Variants of "10^N", "10*N", "10eN", "x10^N" all collapse to "10^N".
 */
export function normalizeUnit(raw: string | null | undefined): string {
  if (!raw) return "";
  let u = String(raw).toLowerCase().trim();

  // Greek + superscripts + multiplication signs
  u = u
    .replace(/µ/g, "u")
    .replace(/μ/g, "u") // U+03BC
    .replace(/³/g, "3")
    .replace(/⁶/g, "6")
    .replace(/⁹/g, "9")
    .replace(/²/g, "2")
    .replace(/×/g, "x")
    .replace(/·|•/g, "")
    .replace(/\s+/g, "");

  // mcg / mcgr / mc → ug / mc → u
  u = u.replace(/mcg/g, "ug").replace(/mcl/g, "ul").replace(/mc/g, "u");

  // Spanish "UI" (unidades internacionales) ≡ "IU". Echevarne writes
  // "µUI/mL", "mUI/L", "UI/mL"; the seed and the conversion rules speak
  // "IU". Only the token right before a "/" or the end, so "uiu" (µIU) and
  // "miu" are produced and nothing else is touched.
  u = u.replace(/ui(?=\/|$)/g, "iu");
  // A bare "U" is the same international unit: µU/mL ≡ µIU/mL (Echevarne's
  // insulin label), U/L ≡ IU/L (enzymes). Only right before "/" or the end.
  u = u.replace(/(^|m|u|k)u(?=\/|$)/g, "$1iu");

  // Strip common modifiers
  u = u.replace(/\bsi\b/g, ""); // "U/L SI"

  // K/µL ≡ 10³/µL, M/µL ≡ 10⁶/µL (treat the prefix as 10^N).
  // Only when followed by /<volume> so we don't catch things like "kIU".
  u = u.replace(/^k\/(u?l|ml|nl)$/i, "10^3/$1");
  u = u.replace(/^m\/(u?l|ml|nl)$/i, "10^6/$1");
  // Sometimes labs write "K/uL" or "M/uL" without the slash variant
  // already covered above.

  // Collapse 10-power notations:
  //   10*3, 10e3, 10^3, x10^3, x10*3, *10^3 → 10^3
  // Apply to digits 1-2 wide.
  u = u.replace(/x?\*?10\s*[\^*ex]\s*(\d{1,2})/g, "10^$1");
  //   10³ (already replaced above) leaves bare "103" — re-add the caret
  u = u.replace(/(?<!\d)10(\d)(?=\s*\/)/g, "10^$1");
  //   "x10^3" → "10^3"
  u = u.replace(/x10\^/g, "10^");

  // Per-volume cell-count equivalence. These pairs are NUMERICALLY
  // identical — only the notation differs — so we collapse to a single
  // canonical form. 1 cell/µL = 10^6 cells/L, so:
  //   10^3 / µL  ≡  10^9 / L   (e.g. WBC, lymph absolute, platelets)
  //   10^6 / µL  ≡  10^12 / L  (e.g. RBC)
  if (u === "10^9/l") u = "10^3/ul";
  if (u === "10^12/l") u = "10^6/ul";

  // Period after dl/l (e.g. "mg/dl.")
  u = u.replace(/\.$/g, "");

  return u;
}

/**
 * True if two unit strings represent the same unit after normalization.
 * Treats "" (unknown/missing) as matching anything so legacy rows
 * without a unit don't fail hard.
 */
export function unitsMatch(a: string | null | undefined, b: string | null | undefined): boolean {
  const na = normalizeUnit(a);
  const nb = normalizeUnit(b);
  if (!na || !nb) return true;
  return na === nb;
}

/**
 * Result of canonical-unit validation for a single biomarker.
 */
export interface UnitValidationResult {
  ok: boolean;
  /** The seed's canonical unit, or null if the biomarker_key is unknown */
  canonical: string | null;
  /** The supplied unit (normalized form) */
  supplied: string;
  reason?: string;
}

/**
 * Verify that the supplied unit matches the seed's canonical unit for
 * this biomarker_key. Pass this AFTER convertBiomarker has run, so the
 * supplied unit reflects any conversion that happened.
 *
 * If the biomarker isn't in the seed at all, this returns ok=true with
 * canonical=null — we can't validate what we don't know about.
 */
export function validateCanonicalUnit(
  biomarkerKey: string,
  unit: string,
): UnitValidationResult {
  const canonical = getCanonicalUnit(biomarkerKey);
  if (canonical === null) {
    return { ok: true, canonical: null, supplied: normalizeUnit(unit) };
  }
  if (unitsMatch(canonical, unit)) {
    return { ok: true, canonical, supplied: normalizeUnit(unit) };
  }
  return {
    ok: false,
    canonical,
    supplied: normalizeUnit(unit),
    reason: `Unit "${unit}" does not match canonical "${canonical}" for ${biomarkerKey}`,
  };
}
