import { Ratelimit, type Duration } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

/**
 * Per-IP, per-route rate limiting (SEC-002).
 *
 * Backed by Upstash Redis (sliding window) when configured. When the Upstash
 * env vars are absent the limiter FAILS OPEN — every request is allowed — so
 * an unprovisioned or local deploy is never broken. Effective limiting turns
 * on automatically once UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN are
 * set in the environment. A shared store is required for correctness on
 * serverless (per-instance memory would not be enforced across instances).
 */

const url = process.env.UPSTASH_REDIS_REST_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN;
const redis = url && token ? new Redis({ url, token }) : null;

/** True when a shared rate-limit store is configured (limits are enforced). */
export const rateLimitEnabled = redis !== null;

export interface RateLimitRule {
  /** Stable key namespacing the limiter (e.g. "contact"). */
  key: string;
  /** Max requests allowed within the window. */
  limit: number;
  /** Window length, e.g. "1 m", "1 h". */
  window: Duration;
}

export interface RateLimitResult {
  success: boolean;
  remaining: number;
  /** Unix ms timestamp when the window resets (0 when limiting is disabled). */
  reset: number;
}

// One Ratelimit instance per rule key, created lazily and reused.
const limiters = new Map<string, Ratelimit>();

function getLimiter(rule: RateLimitRule): Ratelimit {
  let limiter = limiters.get(rule.key);
  if (!limiter) {
    limiter = new Ratelimit({
      redis: redis!,
      limiter: Ratelimit.slidingWindow(rule.limit, rule.window),
      prefix: `rl:${rule.key}`,
      analytics: false,
    });
    limiters.set(rule.key, limiter);
  }
  return limiter;
}

/**
 * Check (and consume) one unit against `rule` for `identifier` (e.g. an IP).
 * Fails open (success: true) when no store is configured.
 */
export async function checkRateLimit(
  rule: RateLimitRule,
  identifier: string,
): Promise<RateLimitResult> {
  if (!redis) {
    return { success: true, remaining: rule.limit, reset: 0 };
  }
  const r = await getLimiter(rule).limit(identifier);
  return { success: r.success, remaining: r.remaining, reset: r.reset };
}
