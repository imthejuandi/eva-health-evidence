/**
 * HL7 ACK handling for the Echevarne exchange, per spec v2.8 §2.1 (structure),
 * §1.2.1 (ECH acking our OML) and §1.4.1 (us acking their ORU).
 *
 * Two directions:
 *   buildOruAck() — eva → ECH after receiving an ORU^R01. CA = processed,
 *     CE = could not process (ECH will RESEND until acked CA, then raise a
 *     manual alert after N attempts — so never CA a message we failed to
 *     persist, and always CA a duplicate we already have).
 *   parseAck() — ECH → eva answering our OML^O21. MSA-2 echoes our MSH-10 so
 *     the caller can resolve which petition was accepted/rejected.
 *
 * Deterministic: timestamps and control ids are inputs, never the clock.
 */

import { getField, getMshField, parseHl7, segmentsByName, getComponent } from "./hl7";
import { hl7Escape } from "./oml-builder";

export interface OruAckInput {
  /** MSH-10 of THIS ack message (unique). */
  messageControlId: string;
  /** MSH-7, yyyyMMddHHmmss. */
  messageDateTime: string;
  /** P | T — mirror the message being acked. */
  processingId: "P" | "T";
  /** MSH-10 of the ORU being acknowledged → MSA-2. */
  ackedMessageControlId: string;
  /** true → MSA-1 CA (processed). false → CE + ERR segment. */
  ok: boolean;
  /** ERR-5.1 / ERR-5.2 when ok=false. */
  errorCode?: string;
  errorText?: string;
}

/**
 * Build the ACK^R01 answering an Echevarne ORU. Sender/receiver mirror the
 * spec example (§1.4.1): we are the CLIENTE side.
 * Env (assigned by ECH, TODO(F0)): ECH_MSH_SENDING_APP, ECH_MSH_SENDING_FACILITY.
 */
export function buildOruAck(input: OruAckInput): string {
  const sendingApp = process.env.ECH_MSH_SENDING_APP;
  const sendingFacility = process.env.ECH_MSH_SENDING_FACILITY;
  if (!sendingApp || !sendingFacility) {
    throw new Error(
      "[ack] ECH_MSH_SENDING_APP / ECH_MSH_SENDING_FACILITY not set — these identifiers come from Echevarne (F0).",
    );
  }
  const msh = [
    "MSH",
    "^~\\&",
    hl7Escape(sendingApp),
    hl7Escape(sendingFacility),
    "LABTRAK",
    "ECHEVARNE",
    input.messageDateTime,
    "",
    "ACK^R01",
    hl7Escape(input.messageControlId),
    input.processingId,
    "2.5",
    "",
    "",
    "AL",
    "ER",
  ].join("|");

  const msa = ["MSA", input.ok ? "CA" : "CE", hl7Escape(input.ackedMessageControlId)].join("|");

  if (input.ok) return [msh, msa].join("\r");

  const err = [
    "ERR",
    "",
    "ORU",
    "",
    "E",
    `${hl7Escape(input.errorCode ?? "ERROR")}^${hl7Escape(input.errorText ?? "Processing failed")}`,
    "",
    "",
    "",
    "",
  ].join("|");
  return [msh, msa, err].join("\r");
}

export interface ParsedAck {
  /** CA = accepted · CE = rejected (spec table §2.1.1.2.1). */
  code: "CA" | "CE" | string;
  ok: boolean;
  /** MSA-2 — the MSH-10 of OUR message being answered (petition correlation). */
  ackedMessageControlId: string;
  /** MSH-10 of the ack itself. */
  messageControlId: string;
  /** ERR-5 when present. */
  errorCode?: string;
  errorText?: string;
}

/** Parse an ACK from Echevarne (answering our OML). Throws on non-ACK payloads. */
export function parseAck(raw: string): ParsedAck {
  const msg = parseHl7(raw);
  const msa = segmentsByName(msg, "MSA")[0];
  if (!msa) throw new Error("[ack] Not an ACK: missing MSA segment");
  const code = getField(msa, 1).trim().toUpperCase();
  const ackedMessageControlId = getField(msa, 2).trim();
  const err = segmentsByName(msg, "ERR")[0];
  const errField = err ? getField(err, 5) : "";
  const errorCode = err ? getComponent(errField, 1, msg.delimiters).trim() : undefined;
  const errorText = err ? getComponent(errField, 2, msg.delimiters).trim() : undefined;
  return {
    code,
    ok: code === "CA",
    ackedMessageControlId,
    messageControlId: getMshField(msg, 10).trim(),
    ...(errorCode ? { errorCode } : {}),
    ...(errorText ? { errorText } : {}),
  };
}
