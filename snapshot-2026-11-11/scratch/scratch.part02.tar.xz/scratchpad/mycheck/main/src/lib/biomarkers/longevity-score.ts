/**
 * Longevity Score Algorithm v4.0 (penalty engine)
 *
 * Entry: `calculateLongevityScore(values, sex, age) → FullResult`
 * Back-compat alias: `calculate` (re-exported from biological-age.ts)
 *
 * This module owns the LONGEVITY SCORE — a 1-100 deviation-from-optimal-range
 * metric that answers "how close to longevity-medicine optimal are you?"
 *
 * The returned FullResult ALSO contains a `biologicalAge` field, but that
 * value is the LEGACY penalty-derived BA (a deviation heuristic, NOT
 * mortality-validated). New callers should source biological age from
 * `biological-age-kdm.ts` (KDM v2.2 joint estimator on NHANES + Spanish
 * recalibration, HR/SD 1.37 mortality-validated). The orchestrator in
 * process-results.ts overwrites `biologicalAge` with the KDM result before
 * persisting to DB.
 *
 * Split rationale: see audit/longevity_score_audit_report.md
 */

// ─── Constants ───

const LS_FLOOR = 1;
const LS_CEILING = 100;
const BA_FLOOR = 18.0;
const BA_CEILING = 99.0;

const MAX_MARKER_PENALTY = 1.0;
const PENALTY_STEEPNESS = 2.0;
const BONUS_RATIO = 0.3;

const MINIMUM_TOTAL_MARKERS = 8;
const MINIMUM_DOMAINS_COVERED = 4;

const BA_SENSITIVITY = 0.5;

// Population-average expected penalty ratios by age group
const POPULATION_AVG_PENALTY_RATIO: Record<string, number> = {
  "18-24": 0.04,
  "25-29": 0.05,
  "30-34": 0.08,
  "35-39": 0.10,
  "40-44": 0.13,
  "45-49": 0.15,
  "50-54": 0.18,
  "55-59": 0.21,
  "60-64": 0.24,
  "65-69": 0.27,
  "70-74": 0.30,
  "75-79": 0.34,
  "80+": 0.38,
};

// ─── Enums ───

export type Tier = 1 | 2 | 3 | 4;
export type Zone = "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high";
export type Confidence = "high" | "moderate" | "low" | "insufficient";

const TIER_WEIGHTS: Record<Tier, number> = { 1: 3.0, 2: 2.0, 3: 1.5, 4: 1.0 };

// ─── Data Types ───

interface OptimalRange {
  optimalLow: number | null;
  optimalHigh: number | null;
  criticalLow?: number | null;
  criticalHigh?: number | null;
}

interface BiomarkerDef {
  name: string;
  code: string;
  unit: string;
  tier: Tier;
  category: string;
  optimalMale: OptimalRange | null;
  optimalFemale: OptimalRange | null;
  ageDependent: boolean;
  ageRanges: Record<string, OptimalRange>;
}

export interface BiomarkerInput {
  code: string;
  value: number;
}

export interface MarkerScore {
  code: string;
  name: string;
  value: number;
  unit: string;
  zone: Zone;
  rawPenalty: number;
  weightedPenalty: number;
  rawBonus: number;
  weightedBonus: number;
  netContribution: number;
  tier: Tier;
  tierWeight: number;
  optimalLow: number | null;
  optimalHigh: number | null;
  category: string;
  lsPointsImpact: number;
  baYearsImpact: number;
  suppressed: boolean;
  suppressedBy: string | null;
  bonusEligible: boolean;
}

export interface DomainCoverage {
  domain: string;
  description: string;
  covered: boolean;
  markersPresent: string[];
  markersPossible: Set<string>;
}

export interface ValidationResult {
  valid: boolean;
  totalMarkers: number;
  domainsCovered: number;
  domainsRequired: number;
  domainDetails: DomainCoverage[];
  missingDomains: string[];
  errorMessage: string | null;
}

export interface FullResult {
  confidence: Confidence;
  chronologicalAge: number;
  validation: ValidationResult;
  longevityScore: number;
  lsPenaltyPoints: number;
  lsBonusPoints: number;
  lsGrade: string;
  biologicalAge: number;
  baDelta: number;
  baExpectedAvgRatio: number;
  netPenaltyRatio: number;
  totalWeightedPenalty: number;
  totalWeightedBonus: number;
  netWeightedScore: number;
  maxPossibleWeightedPenalty: number;
  markerScores: MarkerScore[];
  suppressedMarkers: MarkerScore[];
  markersMeasured: number;
  markersScored: number;
  markersAvailable: number;
  topAgingDrivers: MarkerScore[];
  topProtective: MarkerScore[];
}

// ─── Bonus-eligible markers ───

const BONUS_ELIGIBLE: Record<string, { type: "bounded" | "lower_better" | "higher_better"; deepTarget?: number }> = {
  APOB: { type: "lower_better", deepTarget: 40.0 },
  HBA1C: { type: "bounded" },
  GLUCOSE: { type: "bounded" },
  HOMA_IR: { type: "lower_better", deepTarget: 0.3 },
  HSCRP: { type: "lower_better", deepTarget: 0.2 },
  EGFR: { type: "higher_better", deepTarget: 120.0 },
  INSULIN: { type: "lower_better", deepTarget: 2.0 },
  HDL_C: { type: "bounded" },
  TG: { type: "lower_better", deepTarget: 50.0 },
  ALT: { type: "bounded" },
  RDW: { type: "bounded" },
  ALBUMIN: { type: "bounded" },
  VITD: { type: "bounded" },
  TESTOSTERONE: { type: "bounded" },
  LPA: { type: "lower_better", deepTarget: 7.0 },
};

// ─── Required domains ───

const REQUIRED_DOMAINS: Record<string, { description: string; markerCodes: Set<string>; minimumCount: number }> = {
  cardiovascular: { description: "At least one atherogenic particle or lipid marker", markerCodes: new Set(["APOB", "LDL_C", "HDL_C", "TG"]), minimumCount: 1 },
  // Fructosamine is the Base Panel's glycation marker (2–3 week window; the
  // Panel carries no HbA1c or glucose), so it must satisfy this domain.
  metabolic: { description: "At least one glycemic or insulin sensitivity marker", markerCodes: new Set(["HBA1C", "GLUCOSE", "INSULIN", "HOMA_IR", "FRUCTOSAMINE"]), minimumCount: 1 },
  inflammatory: { description: "At least one inflammatory marker", markerCodes: new Set(["HSCRP", "NLR", "WBC"]), minimumCount: 1 },
  organ_function: { description: "At least one liver or kidney function marker", markerCodes: new Set(["ALT", "AST", "GGT", "EGFR", "CREATININE", "ALBUMIN"]), minimumCount: 1 },
  hematology: { description: "At least one red cell or CBC marker", markerCodes: new Set(["HGB", "RDW", "MCV", "PLT"]), minimumCount: 1 },
};

const REDUNDANT_GROUPS = [
  { name: "Atherogenic particles", priorityOrder: ["APOB", "LDL_C"] },
  { name: "Insulin resistance", priorityOrder: ["HOMA_IR", "INSULIN"] },
];

// ─── Biomarker registry (from v4 PDF) ───
//
// UNITS: every range below is in eva's CANONICAL unit for that marker — the
// unit `biomarker_values.value` is stored in, which since 2026-09-17 is
// Echevarne's (raw cells/µL for counts, g/L for albumin, ng/mL for
// testosterone, µU/mL for insulin). The engine receives stored values as-is,
// so a registry range in any other unit silently misclassifies every value
// (the 2026-09-21 audit found WBC, PLT, albumin and testosterone still in the
// old units: every hemogram scored critical). longevity-score.test.ts asserts
// registry unit == canonical unit for every mapped DB key.

function r(optLow: number | null, optHigh: number | null, critLow?: number | null, critHigh?: number | null): OptimalRange {
  return { optimalLow: optLow, optimalHigh: optHigh, criticalLow: critLow ?? null, criticalHigh: critHigh ?? null };
}

function buildRegistry(): Record<string, BiomarkerDef> {
  const reg: Record<string, BiomarkerDef> = {};
  function add(name: string, code: string, unit: string, tier: Tier, category: string, male: OptimalRange | null, female: OptimalRange | null, ageDependent = false, ageRanges: Record<string, OptimalRange> = {}) {
    reg[code] = { name, code, unit, tier, category, optimalMale: male, optimalFemale: female, ageDependent, ageRanges };
  }

  // Tier 1
  add("Apolipoprotein B", "APOB", "mg/dL", 1, "cardiovascular", r(null, 80, null, 160), r(null, 80, null, 160));
  add("LDL Cholesterol", "LDL_C", "mg/dL", 1, "cardiovascular", r(null, 100, null, 190), r(null, 100, null, 190));
  add("Hemoglobin A1c", "HBA1C", "%", 1, "metabolic", r(4.5, 5.4, 3.8, 6.5), r(4.5, 5.4, 3.8, 6.5));
  add("Fasting Glucose", "GLUCOSE", "mg/dL", 1, "metabolic", r(72, 90, 54, 126), r(72, 90, 54, 126));
  add("Fasting Insulin", "INSULIN", "\u00b5U/mL", 1, "metabolic", r(null, 6, null, 25), r(null, 6, null, 25));
  add("HOMA-IR", "HOMA_IR", "", 1, "metabolic", r(null, 1.0, null, 4.0), r(null, 1.0, null, 4.0));
  // Fructosamine (\u00b5mol/L): glycated serum protein, 2\u20133 week glycemic window.
  // Optimal ceiling provisional (medical sign-off pending); the critical
  // ceiling sits above Echevarne's reference (122\u2013236 \u00b5mol/L).
  add("Fructosamine", "FRUCTOSAMINE", "\u00b5mol/L", 2, "metabolic", r(null, 200, null, 300), r(null, 200, null, 300));
  add("hs-CRP", "HSCRP", "mg/L", 1, "inflammatory", r(null, 1.0, null, 10.0), r(null, 1.0, null, 10.0));
  add("eGFR", "EGFR", "mL/min/1.73m\u00b2", 1, "organ_function", null, null, true, {
    "male|18-29": r(100, null, 60), "male|30-39": r(95, null, 60), "male|40-49": r(90, null, 60),
    "male|50-59": r(85, null, 60), "male|60-69": r(75, null, 45), "male|70+": r(65, null, 40),
    "female|18-29": r(100, null, 60), "female|30-39": r(95, null, 60), "female|40-49": r(90, null, 60),
    "female|50-59": r(85, null, 60), "female|60-69": r(75, null, 45), "female|70+": r(65, null, 40),
  });

  // Tier 2
  add("HDL Cholesterol", "HDL_C", "mg/dL", 2, "cardiovascular", r(50, 90, 25), r(55, 100, 30));
  add("Triglycerides", "TG", "mg/dL", 2, "cardiovascular", r(null, 100, null, 500), r(null, 100, null, 500));
  add("Lipoprotein(a)", "LPA", "mg/dL", 2, "cardiovascular", r(null, 30, null, 75), r(null, 30, null, 75));
  add("ALT (GPT)", "ALT", "U/L", 2, "organ_function", r(7, 30, null, 100), r(7, 19, null, 80));
  add("Red Cell Distribution Width", "RDW", "%", 2, "hematology", r(11, 13, null, 16.5), r(11, 13, null, 16.5));
  add("Albumin", "ALBUMIN", "g/L", 2, "organ_function", r(42, 50, 30), r(42, 50, 30));
  add("25-OH Vitamin D", "VITD", "ng/mL", 2, "nutrients", r(40, 60, 10, 100), r(40, 60, 10, 100));
  // ng/mL (Echevarne): the v4 ng/dL brackets ÷ 100.
  add("Total Testosterone", "TESTOSTERONE", "ng/mL", 2, "hormonal", null, null, true, {
    "male|18-29": r(6.0, 9.0, 2.5), "male|30-39": r(5.5, 9.0, 2.3), "male|40-49": r(5.0, 8.5, 2.2),
    "male|50-59": r(4.5, 8.0, 2.0), "male|60-69": r(4.0, 7.5, 1.8), "male|70+": r(3.5, 7.0, 1.5),
  });
  add("Estradiol", "ESTRADIOL", "pg/mL", 2, "hormonal", null, null, true, {
    "female|18-29": r(30, 120, 10), "female|30-39": r(30, 120, 10), "female|40-49": r(20, 120, 10),
    "female|50-59": r(5, 40), "female|60-69": r(5, 40), "female|70+": r(5, 40),
  });

  // Tier 3
  // Raw cells/\u00b5L (Echevarne): the v4 \u00d710\u00b3/\u00b5L brackets \u00d7 1000.
  add("White Blood Cell Count", "WBC", "/\u00b5L", 3, "hematology", r(4000, 7000, 2500, 15000), r(4000, 7000, 2500, 15000));
  add("Lymphocyte Percent", "LYMPH_PCT", "%", 3, "hematology", r(25, 45, 10, 60), r(25, 45, 10, 60));
  add("Neutrophil-to-Lymphocyte Ratio", "NLR", "", 3, "inflammatory", r(0.8, 2.5, null, 6), r(0.8, 2.5, null, 6));
  add("Ferritin", "FERRITIN", "ng/mL", 3, "iron", r(40, 150, 10, 400), r(30, 100, 8, 300));
  add("Transferrin Saturation", "TSAT", "%", 3, "iron", r(20, 45, 10, 70), r(20, 45, 10, 70));
  add("TSH", "TSH", "\u00b5IU/mL", 3, "thyroid", r(0.5, 2.5, 0.1, 10), r(0.5, 2.5, 0.1, 10));
  add("Sex Hormone Binding Globulin", "SHBG", "nmol/L", 3, "hormonal", r(25, 60, 10, 100), r(30, 80, 15, 120));
  add("Uric Acid", "URIC_ACID", "mg/dL", 3, "metabolic", r(3, 6.0, null, 9), r(2.5, 5, null, 8));
  add("Gamma-GT", "GGT", "U/L", 3, "organ_function", r(9, 30, null, 120), r(6, 20, null, 80));
  add("AST (GOT)", "AST", "U/L", 3, "organ_function", r(10, 30, null, 100), r(10, 25, null, 80));
  add("Hemoglobin", "HGB", "g/dL", 3, "hematology", r(14, 17.5, 10, 19.5), r(12.5, 15.5, 9, 17));

  // Tier 4
  add("Mean Corpuscular Volume", "MCV", "fL", 4, "hematology", r(82, 98, 70, 110), r(82, 98, 70, 110));
  add("Vitamin B12", "B12", "pg/mL", 4, "nutrients", r(500, 1000, 150), r(500, 1000, 150));
  add("Folate (B9)", "FOLATE", "ng/mL", 4, "nutrients", r(10, null, 3), r(10, null, 3));
  add("Creatinine", "CREATININE", "mg/dL", 4, "organ_function", r(0.7, 1.2, null, 2), r(0.5, 1.0, null, 1.8));
  // Raw cells/\u00b5L (Echevarne): the v4 \u00d710\u00b3/\u00b5L brackets \u00d7 1000.
  add("Platelets", "PLT", "/\u00b5L", 4, "hematology", r(150000, 300000, 80000, 500000), r(150000, 300000, 80000, 500000));
  add("Magnesium", "MAGNESIUM", "mg/dL", 4, "nutrients", r(2, 2.5, 1.2), r(2, 2.5, 1.2));
  add("Zinc", "ZINC", "\u00b5g/dL", 4, "nutrients", r(80, 120, 50), r(80, 120, 50));
  add("Free T4", "FT4", "ng/dL", 4, "thyroid", r(1, 1.5, 0.5, 2.5), r(1, 1.5, 0.5, 2.5));
  add("Free T3", "FT3", "pg/mL", 4, "thyroid", r(2.5, 3.5, 1.5, 5), r(2.5, 3.5, 1.5, 5));
  add("Total Bilirubin", "BILIRUBIN", "mg/dL", 4, "organ_function", r(0.3, 1.2, null, 3), r(0.3, 1.2, null, 3));
  add("Alkaline Phosphatase", "ALP", "U/L", 4, "organ_function", r(40, 100, null, 200), r(35, 100, null, 200));

  return reg;
}

/**
 * Longevity tier of every engine biomarker, keyed by engine code
 * (1 = highest weight, see TIER_WEIGHTS; 4 = lowest). Exported so
 * other surfaces — notably the AI summary's biomarker-evolution
 * context — can rank markers by the SAME priority the Longevity
 * Score engine applies, rather than a separate, looser notion of
 * "important" (e.g. "is it in the standard panel").
 */
export const BIOMARKER_TIER: Record<string, Tier> = Object.fromEntries(
  Object.values(buildRegistry()).map((m) => [m.code, m.tier]),
) as Record<string, Tier>;

// ─── Helpers ───

function getAgeGroup(age: number): string {
  if (age < 30) return "18-29";
  if (age < 40) return "30-39";
  if (age < 50) return "40-49";
  if (age < 60) return "50-59";
  if (age < 70) return "60-69";
  return "70+";
}

function getBaAgeGroup(age: number): string {
  if (age < 25) return "18-24";
  if (age < 30) return "25-29";
  if (age < 35) return "30-34";
  if (age < 40) return "35-39";
  if (age < 45) return "40-44";
  if (age < 50) return "45-49";
  if (age < 55) return "50-54";
  if (age < 60) return "55-59";
  if (age < 65) return "60-64";
  if (age < 70) return "65-69";
  if (age < 75) return "70-74";
  if (age < 80) return "75-79";
  return "80+";
}

function getOptimalRange(m: BiomarkerDef, sex: "male" | "female", age: number): OptimalRange | null {
  if (m.ageDependent) {
    return m.ageRanges[`${sex}|${getAgeGroup(age)}`] ?? null;
  }
  return sex === "male" ? m.optimalMale : m.optimalFemale;
}

function classifyZone(v: number, o: OptimalRange): Zone {
  let ok = true;
  if (o.optimalLow != null && v < o.optimalLow) ok = false;
  if (o.optimalHigh != null && v > o.optimalHigh) ok = false;
  if (ok) return "optimal";

  if (o.optimalLow != null && v < o.optimalLow) {
    if (o.criticalLow != null && v <= o.criticalLow) return "critical_low";
    return "below_optimal";
  }
  if (o.optimalHigh != null && v > o.optimalHigh) {
    if (o.criticalHigh != null && v >= o.criticalHigh) return "critical_high";
    return "above_optimal";
  }
  return "optimal";
}

function calcPenalty(v: number, o: OptimalRange, steep = PENALTY_STEEPNESS): number {
  const below = o.optimalLow != null && v < o.optimalLow;
  const above = o.optimalHigh != null && v > o.optimalHigh;
  if (!below && !above) return 0;

  if (below) {
    const b = o.optimalLow!;
    if (o.criticalLow != null) {
      const md = b - o.criticalLow;
      if (md <= 0) return 1;
      return Math.min(((b - v) / md) ** steep, 1);
    }
    const syn = b > 0 ? b * 0.5 : 10;
    return Math.min(((b - v) / syn) ** steep, 1);
  }

  const b = o.optimalHigh!;
  if (o.criticalHigh != null) {
    const md = o.criticalHigh - b;
    if (md <= 0) return 1;
    return Math.min(((v - b) / md) ** steep, 1);
  }
  const syn = b > 0 ? b * 0.5 : 10;
  return Math.min(((v - b) / syn) ** steep, 1);
}

function calcBonus(v: number, o: OptimalRange, code: string): number {
  if (!(code in BONUS_ELIGIBLE)) return 0;
  if (o.optimalLow != null && v < o.optimalLow) return 0;
  if (o.optimalHigh != null && v > o.optimalHigh) return 0;

  const cfg = BONUS_ELIGIBLE[code];
  if (cfg.type === "bounded") {
    if (o.optimalLow == null || o.optimalHigh == null) return 0;
    const mid = (o.optimalLow + o.optimalHigh) / 2;
    const hw = (o.optimalHigh - o.optimalLow) / 2;
    if (hw <= 0) return 0;
    const ratio = Math.max(1 - Math.abs(v - mid) / hw, 0);
    return Math.min(ratio ** 1.5, 1);
  }
  if (cfg.type === "lower_better") {
    const dt = cfg.deepTarget!;
    if (o.optimalHigh == null) return 0;
    const rw = o.optimalHigh - dt;
    if (rw <= 0) return v <= dt ? 1 : 0;
    if (v <= dt) return 1;
    return Math.min(Math.max((o.optimalHigh - v) / rw, 0) ** 1.5, 1);
  }
  if (cfg.type === "higher_better") {
    const dt = cfg.deepTarget!;
    if (o.optimalLow == null) return 0;
    const rw = dt - o.optimalLow;
    if (rw <= 0) return v >= dt ? 1 : 0;
    if (v >= dt) return 1;
    return Math.min(Math.max((v - o.optimalLow) / rw, 0) ** 1.5, 1);
  }
  return 0;
}

// ─── Validation ───

function validateMarkers(codes: Set<string>, reg: Record<string, BiomarkerDef>, sex: "male" | "female", age: number): ValidationResult {
  const scorable = new Set<string>();
  for (const c of codes) {
    if (c in reg && getOptimalRange(reg[c], sex, age) != null) scorable.add(c);
  }

  const domainDetails: DomainCoverage[] = [];
  let dc = 0;
  const missing: string[] = [];

  for (const [dn, dd] of Object.entries(REQUIRED_DOMAINS)) {
    const present = [...scorable].filter((c) => dd.markerCodes.has(c));
    const covered = present.length >= dd.minimumCount;
    if (covered) dc++;
    else missing.push(dn);
    domainDetails.push({ domain: dn, description: dd.description, covered, markersPresent: present.sort(), markersPossible: dd.markerCodes });
  }

  const t = scorable.size;
  const ok = t >= MINIMUM_TOTAL_MARKERS && dc >= MINIMUM_DOMAINS_COVERED;
  let err: string | null = null;
  if (!ok) {
    const parts: string[] = [];
    if (t < MINIMUM_TOTAL_MARKERS) parts.push(`Need ${MINIMUM_TOTAL_MARKERS}+ markers, got ${t}.`);
    if (dc < MINIMUM_DOMAINS_COVERED) parts.push(`Need ${MINIMUM_DOMAINS_COVERED}/5 domains, got ${dc}.`);
    err = parts.join(" ");
  }

  return { valid: ok, totalMarkers: t, domainsCovered: dc, domainsRequired: MINIMUM_DOMAINS_COVERED, domainDetails, missingDomains: missing, errorMessage: err };
}

function resolveRedundancies(codes: Set<string>): Record<string, string> {
  const sup: Record<string, string> = {};
  for (const g of REDUNDANT_GROUPS) {
    let best: string | null = null;
    for (const c of g.priorityOrder) {
      if (codes.has(c)) { best = c; break; }
    }
    if (!best) continue;
    for (const c of g.priorityOrder) {
      if (c !== best && codes.has(c)) sup[c] = best;
    }
  }
  return sup;
}

function assessConfidence(ms: number, t1: number, t2: number, dc: number): Confidence {
  if (dc < MINIMUM_DOMAINS_COVERED || ms < MINIMUM_TOTAL_MARKERS) return "insufficient";
  if (t1 >= 5 && t2 >= 4 && dc >= 5) return "high";
  if (t1 >= 3 && t2 >= 2 && dc >= 4) return "moderate";
  return "low";
}

// ─── Score conversions ───

function netRatioToLongevityScore(netRatio: number): number {
  const k = 3.0;
  const raw = 100 * Math.exp(-k * netRatio);
  return Math.max(LS_FLOOR, Math.min(LS_CEILING, Math.round(raw)));
}

function longevityGrade(score: number): string {
  if (score >= 95) return "Elite";
  if (score >= 85) return "Excellent";
  if (score >= 75) return "Very Good";
  if (score >= 65) return "Good";
  if (score >= 50) return "Average";
  if (score >= 35) return "Below Average";
  if (score >= 20) return "Poor";
  return "Critical";
}

function netRatioToBiologicalAge(netRatio: number, chronoAge: number): number {
  const ageGroup = getBaAgeGroup(chronoAge);
  const expected = POPULATION_AVG_PENALTY_RATIO[ageGroup] ?? 0.15;
  const deviation = netRatio - expected;
  const shift = deviation * 100 * BA_SENSITIVITY;
  const bioAge = chronoAge + shift;
  return Math.round(Math.max(BA_FLOOR, Math.min(BA_CEILING, bioAge)) * 10) / 10;
}

// ─── Main engine ───

export function calculateLongevityScore(
  results: BiomarkerInput[],
  sex: "male" | "female",
  chronologicalAge: number,
): FullResult {
  const registry = buildRegistry();
  const codes = new Set(results.filter((r) => r.code in registry).map((r) => r.code));
  const val = validateMarkers(codes, registry, sex, chronologicalAge);

  const empty: FullResult = {
    confidence: "insufficient", chronologicalAge, validation: val,
    longevityScore: -1, lsPenaltyPoints: 0, lsBonusPoints: 0,
    lsGrade: "Insufficient Data", biologicalAge: -1, baDelta: 0,
    baExpectedAvgRatio: 0, netPenaltyRatio: 0,
    totalWeightedPenalty: 0, totalWeightedBonus: 0,
    netWeightedScore: 0, maxPossibleWeightedPenalty: 0,
    markerScores: [], suppressedMarkers: [],
    markersMeasured: codes.size, markersScored: 0, markersAvailable: 0,
    topAgingDrivers: [], topProtective: [],
  };

  if (!val.valid) return empty;

  const sups = resolveRedundancies(codes);
  const scored: MarkerScore[] = [];
  const suppressed: MarkerScore[] = [];
  let twp = 0, twb = 0, mwp = 0;
  const tierCounts: Record<Tier, number> = { 1: 0, 2: 0, 3: 0, 4: 0 };

  for (const res of results) {
    if (!(res.code in registry)) continue;
    const md = registry[res.code];
    const opt = getOptimalRange(md, sex, chronologicalAge);
    if (!opt) continue;

    const tw = TIER_WEIGHTS[md.tier];
    const z = classifyZone(res.value, opt);
    const rp = calcPenalty(res.value, opt);
    const wp = rp * tw;
    const rb = calcBonus(res.value, opt, res.code);
    const wb = rb * tw * BONUS_RATIO;
    const nc = wp - wb;
    const isSup = res.code in sups;

    const s: MarkerScore = {
      code: res.code, name: md.name, value: res.value, unit: md.unit,
      zone: z, rawPenalty: round4(rp), weightedPenalty: round4(wp),
      rawBonus: round4(rb), weightedBonus: round4(wb),
      netContribution: round4(nc), tier: md.tier, tierWeight: tw,
      optimalLow: opt.optimalLow, optimalHigh: opt.optimalHigh,
      category: md.category, lsPointsImpact: 0, baYearsImpact: 0,
      suppressed: isSup, suppressedBy: sups[res.code] ?? null,
      bonusEligible: res.code in BONUS_ELIGIBLE,
    };

    if (isSup) {
      suppressed.push(s);
    } else {
      scored.push(s);
      twp += wp;
      twb += wb;
      mwp += MAX_MARKER_PENALTY * tw;
      tierCounts[md.tier]++;
    }
  }

  const net = Math.max(twp - twb, 0);
  const nr = mwp > 0 ? net / mwp : 0;

  // Longevity Score
  const ls = netRatioToLongevityScore(nr);
  const grade = longevityGrade(ls);

  // LS per-marker impact
  if (mwp > 0) {
    for (const s of scored) {
      const hypNet = Math.max(net - s.netContribution, 0);
      const hypRatio = hypNet / mwp;
      const hypLs = netRatioToLongevityScore(hypRatio);
      s.lsPointsImpact = round1(hypLs - ls);
    }
  }

  // Biological Age
  const ba = netRatioToBiologicalAge(nr, chronologicalAge);

  // BA per-marker impact
  if (mwp > 0) {
    for (const s of scored) {
      const hypNet = Math.max(net - s.netContribution, 0);
      const hypRatio = hypNet / mwp;
      const hypBa = netRatioToBiologicalAge(hypRatio, chronologicalAge);
      s.baYearsImpact = round2(ba - hypBa);
    }
  }

  const conf = assessConfidence(scored.length, tierCounts[1], tierCounts[2], val.domainsCovered);

  const drivers = scored.filter((s) => s.baYearsImpact > 0).sort((a, b) => b.baYearsImpact - a.baYearsImpact).slice(0, 5);
  const protective = scored.filter((s) => s.baYearsImpact < 0).sort((a, b) => a.baYearsImpact - b.baYearsImpact).slice(0, 5);

  const ma = Object.values(registry).filter((md) => getOptimalRange(md, sex, chronologicalAge) != null).length;
  const ageGrp = getBaAgeGroup(chronologicalAge);
  const expAvg = POPULATION_AVG_PENALTY_RATIO[ageGrp] ?? 0.15;

  const penRatio = mwp > 0 ? twp / mwp : 0;
  const lsPenPts = round1(100 - netRatioToLongevityScore(penRatio));
  const lsBonPts = round1(netRatioToLongevityScore(nr) - netRatioToLongevityScore(penRatio));

  return {
    confidence: conf, chronologicalAge, validation: val,
    longevityScore: ls, lsPenaltyPoints: lsPenPts, lsBonusPoints: lsBonPts,
    lsGrade: grade, biologicalAge: ba, baDelta: round1(ba - chronologicalAge),
    baExpectedAvgRatio: expAvg, netPenaltyRatio: round4(nr),
    totalWeightedPenalty: round4(twp), totalWeightedBonus: round4(twb),
    netWeightedScore: round4(net), maxPossibleWeightedPenalty: round4(mwp),
    markerScores: scored, suppressedMarkers: suppressed,
    markersMeasured: codes.size, markersScored: scored.length, markersAvailable: ma,
    topAgingDrivers: drivers, topProtective: protective,
  };
}

function round1(n: number): number { return Math.round(n * 10) / 10; }
function round2(n: number): number { return Math.round(n * 100) / 100; }
function round4(n: number): number { return Math.round(n * 10000) / 10000; }
