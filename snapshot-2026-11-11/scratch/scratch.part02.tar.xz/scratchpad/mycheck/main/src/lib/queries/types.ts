export interface Profile {
  id: string;
  /** Legacy single-field name. Kept writable for backwards compatibility
   * with callers (emails, AI prompts) that haven't migrated yet. New
   * writes should also populate first_name / last_name. */
  full_name: string;
  first_name: string | null;
  /** Primer apellido (PID-5.1). Legacy rows may hold both surnames. */
  last_name: string | null;
  /** Segundo apellido (PID-6.1) — required by the lab; null on legacy rows. */
  second_surname: string | null;
  email: string;
  date_of_birth: string | null;
  sex: "male" | "female" | null;
  height_cm: number | null;
  weight_kg: number | null;
  health_knowledge: "beginner" | "familiar" | "optimizer" | null;
  onboarding_completed: boolean;
  subscription_status: "free" | "active" | "cancelled" | "past_due";
  subscription_period_end: string | null;
  /* Set by the Stripe webhook when the user completes a Full Panel
   * one-time purchase. Non-null means the user has paid for the Full
   * Panel at least once and retains access to paid-only features
   * (EVA AI chat, wearable imports) even without an active recurring
   * subscription. See hasPaidAccess() in src/lib/stripe/helpers.ts. */
  full_panel_purchased_at: string | null;
  /* Shipping address — populated by the Stripe checkout webhook on
   * checkout.session.completed and editable from the profile page. */
  address_line1: string | null;
  address_line2: string | null;
  address_city: string | null;
  address_postal_code: string | null;
  address_province: string | null;
  address_country: string | null;
  phone: string | null;
  /* Identity document for the lab order (PID.3) — required by Echevarne on
   * every OML. Captured on the profile page; a kit cannot ship without it.
   * Type ∈ the spec's PID.3.5 codes (see src/lib/identity/document.ts). */
  id_document_type: string | null;
  id_document_number: string | null;
  /* Consent / legal-acceptance records (T2.6). terms/privacy/age stamped at
   * signup; marketing_opt_in is toggled from the profile page (LEG-007).
   * All nullable / default-false so rows predating the
   * 20260603120000_consent_columns migration read cleanly. */
  terms_accepted_at: string | null;
  privacy_accepted_at: string | null;
  age_confirmed_at: string | null;
  marketing_opt_in: boolean | null;
  marketing_opt_in_at: string | null;
  locale: string;
  /**
   * Cached rolling-average biological age, written by
   * `recomputeAndCacheUserBA()` after every lab upload.
   *
   * Computed by AVERAGING biomarker values across all the user's labs
   * in a recent time window (6 months preferred, 12 months fallback),
   * then running the KDM joint estimator on the averaged panel. This is
   * the single BA value the dashboard displays — stable across visits
   * because it smooths inter-lab measurement noise.
   *
   * Null when the user has no labs, or when the gate fails.
   */
  current_ba: number | null;
  /** "Comprehensive" (preferred) or "Reference" (fallback). */
  current_ba_method: "Comprehensive" | "Reference" | null;
  /** How many labs contributed to the rolling average. */
  current_ba_n_labs_averaged: number | null;
  /** 6, 12, or null (single-lab fallback). */
  current_ba_window_months: number | null;
  /** Marker count contributing to the joint estimator (post-averaging). */
  current_ba_n_markers_used: number | null;
  /** ISO timestamp of the most recent recompute. */
  current_ba_computed_at: string | null;
  created_at: string;
}

export interface LabResult {
  id: string;
  user_id: string;
  source: string;
  collection_date: string;
  /**
   * Biological age in years.
   *
   * From 2026-05-26 onward this is the KDM v2.2 Reference BA
   * (mortality-validated joint estimator over 14-marker base panel).
   * Pre-migration rows hold the legacy penalty-derived deviation
   * heuristic — distinguishable via `bio_age_method == null`.
   * See supabase/migrations/20260526000000_kdm_v2_2_integration.sql.
   */
  biological_age: number | null;
  /**
   * KDM v2.2 Comprehensive BA — full-panel joint estimator companion.
   * Available when the user has uploaded an extended panel.
   */
  biological_age_comprehensive: number | null;
  /**
   * Provenance tag for `biological_age`. `"KDM_v2.2_ReferenceBA"` on rows
   * written after the 2026-05-26 migration. `null` on legacy rows.
   */
  bio_age_method: string | null;
  /**
   * How many markers contributed to the Reference BA joint estimator
   * (max 14, gate requires ≥ 8 + Albumin + Creatinine).
   */
  bio_age_n_markers: number | null;
  /**
   * Spanish KDM marker names whose population mean (q) was swapped from
   * NHANES to a Spanish-cohort value during BA computation. Used by the
   * methodology page for per-user transparency.
   */
  bio_age_applied_spanish_calibration: string[] | null;
  longevity_score: number | null;
  longevity_grade: string | null;
  summary_narrative: string | null;
  summary_narrative_es: string | null;
  strengths: string[];
  needs_attention: string[];
  optimal_count: number;
  attention_count: number;
  action_count: number;
  status: string;
  created_at: string;
  /** Observations the lab sent with the result, shown as part of it (2026-09-22). */
  lab_notes?: LabNote[] | null;
  /** Set when a final/corrected report replaced this result's values. */
  corrected_at?: string | null;
}

export interface BiomarkerValue {
  id: string;
  lab_result_id: string;
  biomarker_key: string;
  biomarker_name: string;
  category: string;
  value: number;
  unit: string;
  zone: "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high" | "unclassified";
  optimal_low: number | null;
  optimal_high: number | null;
  normal_low: number | null;
  normal_high: number | null;
  /** What the lab printed, before any rescale/conversion (null on rows stored before 2026-09-17). */
  reported_value?: number | null;
  reported_unit?: string | null;
  /** "<" / ">" when the lab reported a bounded value; `value` is the bound (2026-09-22). */
  comparator?: "<" | ">" | null;
  interpretation: string | null;
  created_at: string;
}

/** A free-text observation the lab sent with the result (OBX TX), verbatim. */
export interface LabNote {
  code: string;
  text: string;
}

export interface WearableData {
  id: string;
  user_id: string;
  date: string;
  hrv_ms: number | null;
  resting_hr_bpm: number | null;
  sleep_hours: number | null;
  respiratory_rate: number | null;
  recovery_score: number | null;
  steps: number | null;
  source: string;
}

export interface ActionStep {
  id: string;
  user_id: string;
  lab_result_id: string;
  priority: number;
  title: string;
  /** Spanish rendering of the action title. Populated by the AI
   * pipeline alongside `title`; consumers pick by profile locale. */
  title_es: string | null;
  description: string;
  description_es: string | null;
  category: string;
  related_biomarker_keys: string[];
  status: "pending" | "in_progress" | "completed" | "dismissed";
  created_at: string;
}

export interface BookedTest {
  id: string;
  user_id: string;
  panel_type: string;
  status: "scheduled" | "kit_sent" | "sample_received" | "processing" | "completed" | "cancelled";
  scheduled_date: string | null;
  created_at: string;
  /** DHL tracking for the outbound kit — present on test_cycles-backed rows (F5). */
  dhl_tracking_out?: string | null;
  /** Set on test_cycles-backed rows: enables the patient "register extraction" step (F6). */
  cycle_id?: string | null;
  extraction_confirmed_at?: string | null;
}
