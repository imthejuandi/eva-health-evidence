/**
 * A chainable stand-in for supabase-js for unit tests: every builder method
 * records itself and returns the builder; awaiting it hands the recorded call
 * to `respond`, which the test uses to script the database. Lets the code
 * that touches real tables (bridge store, cycle closing, cron resolvers) be
 * tested without a database.
 */
import type { SupabaseClient } from "@supabase/supabase-js";

export type FakeCall = { table: string; ops: { op: string; args: unknown[] }[] };
export type FakeResponse = { data?: unknown; error?: unknown; count?: number | null };

const METHODS = ["insert", "select", "update", "upsert", "delete", "eq", "neq", "in", "is", "or", "not", "lt", "gt", "gte", "lte", "order", "limit", "range", "single", "maybeSingle"];

export function fakeSupabase(respond: (call: FakeCall) => FakeResponse) {
  const calls: FakeCall[] = [];
  const client = {
    from(table: string) {
      const call: FakeCall = { table, ops: [] };
      calls.push(call);
      const builder: Record<string, unknown> = {};
      for (const m of METHODS) {
        builder[m] = (...args: unknown[]) => {
          call.ops.push({ op: m, args });
          return builder;
        };
      }
      builder.then = (resolve: (v: unknown) => void, reject?: (e: unknown) => void) => {
        try {
          resolve({ data: null, error: null, count: null, ...respond(call) });
        } catch (e) {
          reject?.(e);
        }
      };
      return builder;
    },
  };
  return { client: client as unknown as SupabaseClient, calls };
}

/** "insert.select.single" — the builder chain of a recorded call. */
export const ops = (c: FakeCall): string => c.ops.map((o) => o.op).join(".");

/** The arguments of the first `op` in a recorded call, if any. */
export const argsOf = (c: FakeCall, op: string, matchFirstArg?: unknown): unknown[] | undefined =>
  c.ops.find((o) => o.op === op && (matchFirstArg === undefined || o.args[0] === matchFirstArg))?.args;
