import type { ProcessedBiomarker } from "@/lib/biomarkers/process-results";
import type { WearableData, Profile } from "@/lib/queries/types";
import { type SupabaseClient } from "@supabase/supabase-js";
import { generateMasterInterpretation } from "@/lib/ai/generate-master-interpretation";
import { applyTier } from "@/lib/ai/apply-tier";

/**
 * Orchestrate the full lab interpretation pipeline:
 *
 *   1. Produce the master (optimizer-tier source of truth) and persist
 *      it to the *_master columns plus a fresh action_steps batch with
 *      master_* fields populated.
 *   2. Materialize the user's currently-selected health_knowledge tier
 *      from that master into the active columns the dashboard reads.
 *      Optimizer tier is a pure copy (no second Gemini call); beginner
 *      and familiar are rephrased in a single batched call.
 *
 * Callers (lab upload, admin reprocess, webhook) keep the same
 * signature they had before this refactor.
 */
export async function generateSummary(
  userId: string,
  labResultId: string,
  processedBiomarkers: ProcessedBiomarker[],
  wearableData: WearableData[] | null,
  profile: Profile,
  client?: SupabaseClient,
  options?: {
    /** Free-text observations the lab sent with the report (verbatim), e.g. an interference note. */
    labNotes?: string[];
  },
): Promise<void> {
  await generateMasterInterpretation(
    userId,
    labResultId,
    processedBiomarkers,
    wearableData,
    profile,
    client,
    options?.labNotes,
  );

  const tier = profile.health_knowledge ?? "beginner";
  await applyTier(labResultId, tier, client);
}
