import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { validateIdDocument } from "@/lib/identity/document";

/**
 * PATCH /api/profile/address
 *
 * Accepts any subset of the shipping fields and updates the user's
 * profile row. Initial values are populated by the Stripe webhook on
 * checkout.session.completed; this route lets the user correct or
 * change them before the next quarterly kit ships.
 *
 * Field whitelist matches the columns added in
 * supabase/migrations/20260501000000_add_shipping_address.sql.
 */

interface AddressBody {
  address_line1?: string | null;
  address_line2?: string | null;
  address_city?: string | null;
  address_postal_code?: string | null;
  address_province?: string | null;
  address_country?: string | null;
  phone?: string | null;
  /** Identity document for the lab order (PID.3). Both or neither. */
  id_document_type?: string | null;
  id_document_number?: string | null;
}

const FIELDS: (keyof AddressBody)[] = [
  "address_line1",
  "address_line2",
  "address_city",
  "address_postal_code",
  "address_province",
  "address_country",
  "phone",
  "id_document_type",
  "id_document_number",
];

function trimOrNull(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const trimmed = v.trim();
  return trimmed.length === 0 ? null : trimmed;
}

export async function PATCH(req: NextRequest) {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = (await req.json().catch(() => ({}))) as AddressBody;

    const update: Record<string, string | null> = {};
    for (const f of FIELDS) {
      if (f in body) {
        update[f] = trimOrNull(body[f]);
      }
    }

    // Light validation — Spain ships only for now (matches the
    // allowed_countries allowlist in the checkout route). Country
    // code must be ISO 3166-1 alpha-2 if provided.
    if (update.address_country && !/^[A-Z]{2}$/.test(update.address_country)) {
      return NextResponse.json(
        { error: "address_country must be an ISO 3166-1 alpha-2 code (e.g. ES)" },
        { status: 400 },
      );
    }

    // Identity document: validated as a pair. Echevarne rejects orders
    // without a categorized identifier, so we refuse half-filled input here
    // rather than at ship time. Clearing both is allowed.
    if ("id_document_type" in update || "id_document_number" in update) {
      const type = update.id_document_type ?? null;
      const number = update.id_document_number ?? null;
      if (type === null && number === null) {
        update.id_document_type = null;
        update.id_document_number = null;
      } else {
        const v = validateIdDocument(type, number);
        if (!v.ok) {
          return NextResponse.json({ error: v.error }, { status: 400 });
        }
        update.id_document_type = v.type;
        update.id_document_number = v.number;
      }
    }

    if (Object.keys(update).length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 });
    }

    const { error } = await supabase
      .from("profiles")
      .update(update)
      .eq("id", user.id);

    if (error) {
      console.error("[profile/address] update failed:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ ok: true, updated: Object.keys(update) });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Update failed";
    console.error("[profile/address]", e);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
