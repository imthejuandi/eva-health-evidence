"use client";

/**
 * /about — biographical chapter rhythm.
 *
 * Phase 2 of the design propagation effort, after a polish pass
 * and a "high-end visual design" finishing pass. The earlier
 * version of this file was too text-heavy; it has since been
 * compressed so each chapter breathes on a single core idea,
 * then given a final typographic and spatial refinement:
 *
 *   · Page-level film grain overlay (fixed, 5% opacity) for the
 *     "printed on creamy paper" physical feel called out in
 *     .impeccable.md, implemented as a pointer-events-none SVG
 *     feTurbulence layer on a fixed pseudo-element (the only
 *     performance-safe place for grain textures — never on
 *     scrolling content).
 *
 *   · OpenType features (liga/calt/kern on the whole page,
 *     dlig on the founder blockquote, tnum on mono labels)
 *     and text-rendering: optimizeLegibility for real print-
 *     quality kerning without per-element overrides.
 *
 *   · Ledger rhythm refinement: § 03 team split tightened from
 *     4/8 to 3/9 so the content column breathes more; § 03 row
 *     padding bumped to py-12/py-16; § 04 principle row padding
 *     bumped to py-12/py-20 now that each row carries a title
 *     + description; all ledger intros moved from mt-16/mt-24
 *     to mt-14/mt-20 so the divide-y rows sit closer to their
 *     headlines.
 *
 *   · Editorial label tracking on all 10px mono eyebrows bumped
 *     from [2px] / [1.8px] to a consistent [2.4px] — the
 *     standard tracking weight for uppercase labels at that
 *     point size.
 *
 * Chapter structure, unchanged from the polish pass:
 *
 *   § 01 — The mission     (cream, xlarge)
 *                          monumental headline + one anchor sentence,
 *                          asymmetric body in the right column
 *
 *   § 02 — The founder     (cream-alt, xlarge)
 *                          single-paragraph italic pull quote with a
 *                          terra opening glyph; mirrors landing § 06
 *
 *   § 03 — The team        (cream, large)
 *                          divide-y ledger of role + name + short bio.
 *                          Eyebrow color encodes status (terra filled
 *                          / jade open seat / gold catch-all)
 *
 *   § 04 — The principles  (cream-alt, xlarge)
 *                          book-style ledger — italic terra Roman
 *                          numeral prefix + Sentient title, with a
 *                          short BodyProse line underneath saying
 *                          what the principle means in practice
 *                          for EVA. Baseline aligned.
 *
 *   § 05 — The horizon     (cream, xlarge)
 *                          centered close, hand-drawn underline under
 *                          the last word, italic LedeItalic vision
 *                          body. Body copy preserves the original
 *                          "not defined by blood testing / technology
 *                          is a tool" statement but deliberately omits
 *                          the future-tech list (wearables, genetics,
 *                          CGM, microbiome, etc.) so the brand stays
 *                          uncommitted to any specific tool.
 *
 * No dark sections (the landing's § 03 / § 07 dark moments earn
 * their drama; /about is downstream and stays warm throughout).
 * No icons. No feature cards. No gradient avatars. No Chief
 * Medical Officer has been appointed yet, so the medical-
 * leadership entry is presented as an open role we are hiring
 * for — never a fictitious person.
 */

import type { CSSProperties } from "react";
import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { CTAButton } from "@/components/marketing/CTAButton";
import {
  ChapterMarker,
  SectionHeadline,
  SubHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
  HandDrawnUnderline,
} from "@/components/marketing/editorial";

export default function AboutPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";

  /* ──────────────────────────────────────────────────────────────
   * Locale copy.
   *
   * Polish pass deliberately compresses the mission + founder +
   * principles down to their core idea per chapter, then a
   * feedback round restored short team bios (with JD's expanded
   * to include his Amazon alumnus / two masters / hospitality
   * background) and restored the original § 05 vision statement
   * with only the specific future-technology list removed.
   *
   * No CMO is appointed yet: the medical-leadership entry is an
   * open role (medicalPill / medicalRole) we are hiring for, not
   * a fictitious person.
   *
   * § 05 visionBody preserves the original "not defined by blood
   * testing / technology is a tool / real product is understanding"
   * spine, with the enumerated wearables/genetics/imaging/CGM/
   * microbiome list excised — the brand stays uncommitted to any
   * specific future tool.
   * ────────────────────────────────────────────────────────────── */
  const t =
    locale === "es"
      ? {
          chapter01: "§ 01 · La mision",
          chapter02: "§ 02 · El fundador",
          chapter03: "§ 03 · El equipo",
          chapter04: "§ 04 · Los principios",
          chapter05: "§ 05 · El horizonte",
          missionTitle:
            "Enseñarte lo que estar sano realmente significa para ti.",
          missionBody:
            "EVA Health es una empresa de salud preventiva de precision en Madrid. Traducimos el ruido medico en comprension: lo que tu cuerpo te dice, en lenguaje sobre el que puedes actuar.",
          founderQuote:
            "Creci viendo a mi padre, medico de cuidados paliativos, luchar contra enfermedades que se habian ido formando en silencio durante años. Construi EVA para que pudieramos evitar llegar hasta ellas.",
          founderName: "Juan Diego Lago",
          founderTitle: "Fundador y CEO, EVA Health",
          teamTitle: "Un equipo pequeño. Una mision larga.",
          jdRole: "Fundador y CEO",
          jdDesc:
            "Hijo de un medico de cuidados paliativos. Ex-Amazon con dos masteres y experiencia previa en hosteleria. Ahora dedicado a construir la plataforma de salud preventiva que deseaba que existiera.",
          // No CMO appointed yet — present medical leadership as an open role
          // we are hiring for, never a fictitious person.
          medicalPill: "Estamos contratando",
          medicalRole: "Direccion Medica",
          medicalDesc:
            "Buscamos liderazgo medico colegiado que ayude a definir los protocolos de salud preventiva de EVA.",
          cmoPill: "Estamos contratando",
          cmoTitle: "Director de Marketing",
          cmoDesc:
            "Buscamos un CMO que crea que la educacion en salud puede cambiar vidas.",
          joinPill: "Unete a la mision",
          joinTitle: "Posiciones Abiertas",
          joinDesc:
            "Estamos construyendo el futuro de la salud preventiva. Si compartes nuestra mision, queremos conocerte.",
          valuesTitle: "En lo que creemos.",
          val1: "Claridad sobre complejidad",
          val1Desc:
            "Tus datos medicos, traducidos a un lenguaje claro sobre el que puedes actuar.",
          val2: "Comprension sobre informacion",
          val2Desc:
            "No solo te entregamos numeros, te enseñamos lo que las señales de tu cuerpo significan.",
          val3: "Prevencion sobre reaccion",
          val3Desc:
            "Detectar pronto para vivir bien mas tiempo. Proteger la salud antes de perderla.",
          val4: "Tus datos, tu poder",
          val4Desc:
            "Privacidad primero, siempre bajo tu control. Nunca vendemos tus datos.",
          visionTitle: "Esto es solo el comienzo.",
          visionBody:
            "EVA no se define por los analisis de sangre. Estamos dedicados a la salud preventiva de precision y siempre nos expandiremos hacia lo que ofrezca a nuestros clientes una vision mas profunda de su salud. La tecnologia es una herramienta; el verdadero producto es la comprension.",
          visionCta: "Comienza tu camino",
        }
      : {
          chapter01: "§ 01 · The mission",
          chapter02: "§ 02 · The founder",
          chapter03: "§ 03 · The team",
          chapter04: "§ 04 · The principles",
          chapter05: "§ 05 · The horizon",
          missionTitle: "Teach you what being healthy really means for you.",
          missionBody:
            "EVA Health is a precision preventative care company in Madrid. We translate medical noise into understanding: what your body is telling you, in language you can act on.",
          founderQuote:
            "I grew up watching my father, a palliative care physician, fight diseases that had been forming silently for years. I built EVA so we could avoid reaching them.",
          founderName: "Juan Diego Lago",
          founderTitle: "Founder & CEO, EVA Health",
          teamTitle: "A small team. A long mission.",
          jdRole: "Founder & CEO",
          jdDesc:
            "Son of a palliative care physician. Ex-Amazon with two master's degrees and a prior background in hospitality. Now dedicated to building the preventative health platform he wished existed.",
          // No CMO appointed yet — present medical leadership as an open role
          // we are hiring for, never a fictitious person.
          medicalPill: "We're hiring",
          medicalRole: "Chief Medical Officer",
          medicalDesc:
            "We're recruiting licensed medical leadership to help shape EVA's preventive-care protocols.",
          cmoPill: "We're hiring",
          cmoTitle: "Chief Marketing Officer",
          cmoDesc:
            "We're looking for a CMO who believes health education can change lives.",
          joinPill: "Join the mission",
          joinTitle: "Open roles",
          joinDesc:
            "We're building the future of preventative health. If you share our mission, we want to hear from you.",
          valuesTitle: "What we believe.",
          val1: "Clarity over complexity",
          val1Desc:
            "Your medical data, translated into plain language you can act on.",
          val2: "Understanding over information",
          val2Desc:
            "We don't just hand you numbers, we teach you what your body's signals mean.",
          val3: "Prevention over reaction",
          val3Desc:
            "Catch it early so you live well longer. Protect health before it's lost.",
          val4: "Your data, your power",
          val4Desc:
            "Privacy-first, always in your control. We never sell your data.",
          visionTitle: "This is just the beginning.",
          visionBody:
            "EVA is not defined by blood testing. We are dedicated to precision preventative care and will always expand into whatever gives our clients deeper insight into their health. The technology is a tool; the real product is understanding.",
          visionCta: "Start your journey",
        };

  /* ──────────────────────────────────────────────────────────────
   * § 05 vision headline — split off the last word so we can wrap
   * it in `relative inline-block` and slide a HandDrawnUnderline
   * underneath. Works for both EN ("beginning.") and ES
   * ("comienzo."), which both end on a single emphatic noun.
   * ────────────────────────────────────────────────────────────── */
  const visionWords = t.visionTitle.split(" ");
  const visionLastWord = visionWords.pop() ?? t.visionTitle;
  const visionLeadWords = visionWords.join(" ");

  /* ──────────────────────────────────────────────────────────────
   * § 03 — team roster.
   *
   * Four entries. Each row carries an eyebrow (role / status),
   * a name (SubHeadline), and a short bio (BodyProse compact
   * muted). Eyebrow color encodes status:
   *
   *   terra (#97472c) → filled / present
   *   jade  (#3a665e) → open seat / future hire
   *   gold  (#c49332) → catch-all open invitation
   *
   * One filled row (JD), two open leadership seats (medical +
   * marketing), one catch-all invitation. The colour-tier
   * distinction is the only chrome — no borders, no cards, no
   * avatars.
   * ────────────────────────────────────────────────────────────── */
  const team: Array<{
    eyebrow: string;
    eyebrowColor: string;
    name: string;
    bio: string;
  }> = [
    {
      eyebrow: t.jdRole,
      eyebrowColor: "#97472c",
      name: t.founderName,
      bio: t.jdDesc,
    },
    {
      eyebrow: t.medicalPill,
      eyebrowColor: "#3a665e",
      name: t.medicalRole,
      bio: t.medicalDesc,
    },
    {
      eyebrow: t.cmoPill,
      eyebrowColor: "#3a665e",
      name: t.cmoTitle,
      bio: t.cmoDesc,
    },
    {
      eyebrow: t.joinPill,
      eyebrowColor: "#c49332",
      name: t.joinTitle,
      bio: t.joinDesc,
    },
  ];

  /* ──────────────────────────────────────────────────────────────
   * § 04 — principles.
   *
   * Book-style ledger. Each row carries an italic terra Roman-
   * numeral prefix (sized at ~60% of the title so it reads as a
   * label rather than a competing element), a Sentient title in
   * ink, and a short description that says what the principle
   * means in practice for EVA. The numeral still sits on the
   * baseline of the title's first line via items-baseline, and
   * the description flows below in BodyProse compact muted.
   * ────────────────────────────────────────────────────────────── */
  const principles: Array<{
    numeral: string;
    title: string;
    body: string;
  }> = [
    { numeral: "I", title: t.val1, body: t.val1Desc },
    { numeral: "II", title: t.val2, body: t.val2Desc },
    { numeral: "III", title: t.val3, body: t.val3Desc },
    { numeral: "IV", title: t.val4, body: t.val4Desc },
  ];

  return (
    <div
      /* ─────────────────────────────────────────────────────────
       * Page-level typographic polish.
       *
       * font-feature-settings enables standard ligatures,
       * contextual alternates, and explicit kerning across all
       * Sentient / Manrope / DM Mono descendants — Sentient's
       * display sizes in particular benefit from calt + liga,
       * and explicit kern pairs tighten the headline glyph
       * rhythm without per-element overrides.
       *
       * text-rendering: optimizeLegibility is a browser hint
       * that trades a touch of CPU for visibly better kerning
       * and ligature application; on a short editorial page
       * like /about the tradeoff is obviously worth it.
       *
       * antialiased = -webkit-font-smoothing: antialiased, which
       * on macOS/iOS produces lighter strokes for the display
       * serif — closer to print weight. No effect elsewhere.
       * ───────────────────────────────────────────────────────── */
      className="relative antialiased [font-feature-settings:'liga','calt','kern']"
      style={{ textRendering: "optimizeLegibility" }}
    >
      {/* ─── Film grain overlay ─────────────────────────────────
          Fixed, pointer-events-none SVG noise pattern at ~5%
          opacity — gives the page the "printed on creamy paper"
          physical feel called out in .impeccable.md ("a hand-
          bound wellness zine printed on creamy paper") without
          adding any real weight. Fixed positioning means it
          stays glued to the viewport rather than scrolling with
          the content, which is the correct behaviour for a
          film-grain-on-glass effect and is the performance-safe
          pattern per the high-end visual design guardrails
          (grain on a fixed pseudo-element, never on scrolling
          content). The filter ID is scoped with "eva-" so it
          can't collide with any other SVG filter on the page. */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[1] opacity-[0.05] mix-blend-multiply"
        style={{
          backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='eva-grain'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23eva-grain)'/></svg>")`,
          backgroundSize: "220px 220px",
        }}
      />

      {/* ─── § 01 THE MISSION ─────────────────────────────────────
          Anchor chapter. Monumental headline crashing in from the
          left of the 12-col grid; one short body sentence shifts
          off-axis to the right column. Same visual grammar as
          Shortfall § 02 on the landing, so the two pages rhyme. */}
      <SectionShell tone="cream" size="xlarge">
        <ScrollReveal>
          <ChapterMarker>{t.chapter01}</ChapterMarker>
        </ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-6 md:mt-10">
          <SectionHeadline scale="monumental" maxCh={18}>
            {t.missionTitle}
          </SectionHeadline>
        </ScrollReveal>
        <div className="mt-14 grid grid-cols-12 gap-6 md:mt-20 md:gap-12">
          <ScrollReveal
            delay={0.12}
            className="col-span-12 md:col-span-7 md:col-start-6"
          >
            <BodyProse maxCh={56}>{t.missionBody}</BodyProse>
          </ScrollReveal>
        </div>
      </SectionShell>

      {/* ─── § 02 THE FOUNDER ─────────────────────────────────────
          Single-paragraph cinematic italic blockquote — the
          loudest typographic moment on the page. Two sentences
          (~150 chars), clamped to max-w-[22ch] so the quote
          naturally appears off-centre-left. Oversized terra
          opening glyph as a float-left drop; closing glyph sits
          inline at the end. Attribution row below in mono.
          Mirrors landing § 06 FounderCinematic. */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ScrollReveal>
          <ChapterMarker>{t.chapter02}</ChapterMarker>
        </ScrollReveal>
        <ScrollReveal delay={0.08} className="mt-12 md:mt-16">
          <blockquote
            /* Sentient italic at display sizes picks up a real
               print-quality feel from the following features:
                 "liga" / "dlig" — standard + discretionary ligatures
                 "calt"          — contextual alternates (letter-pair swaps)
                 "kern"          — explicit kerning pairs
               hanging-punctuation would let the opening quote
               hang into the margin natively — Safari honours it,
               Chrome doesn't yet, so the float-left drop glyph
               below remains the portable implementation. */
            className="font-[family-name:var(--font-sentient)] max-w-[22ch] text-[36px] font-medium italic leading-[1.16] text-[#1d1b18] [font-feature-settings:'liga','dlig','calt','kern'] md:text-[76px] md:leading-[1.12] md:tracking-[-2px] lg:text-[92px] lg:tracking-[-2.6px]"
            style={
              {
                textWrap: "balance",
                hangingPunctuation: "first last",
              } as CSSProperties
            }
          >
            {/* Float-left oversized opening quote glyph — sits as
                a drop so the first line wraps around it. Aria-
                hidden because the <blockquote> already signals
                "quotation" to assistive tech. */}
            <span
              aria-hidden
              className="float-left mr-[0.06em] mt-[-0.06em] font-[family-name:var(--font-sentient)] text-[1.4em] font-medium leading-[0.85] text-[#97472c]"
            >
              &ldquo;
            </span>
            {t.founderQuote}
            <span aria-hidden className="text-[#97472c]">
              &rdquo;
            </span>
          </blockquote>
        </ScrollReveal>
        <ScrollReveal delay={0.18} className="mt-14 md:mt-24">
          <div className="flex flex-wrap items-baseline gap-x-8 gap-y-2 border-t border-[#1d1b18]/15 pt-6">
            <p className="font-[family-name:var(--font-sentient)] text-[22px] font-medium text-[#1d1b18] [font-feature-settings:'liga','calt','kern'] md:text-[28px]">
              {t.founderName}
            </p>
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76] [font-feature-settings:'tnum','calt','kern']">
              {t.founderTitle}
            </p>
          </div>
        </ScrollReveal>
      </SectionShell>

      {/* ─── § 03 THE TEAM ────────────────────────────────────────
          Divide-y ledger of four rows. Each row carries an eyebrow
          (role / status, mono, color-coded) in the left column
          and a name + short bio in the right column. 4/8 column
          split at md+, stacked at mobile. The eyebrow sits on the
          same baseline as the first line of the name (via
          items-baseline), and the bio flows below without
          affecting that alignment. Eyebrow color encodes status
          (terra filled, jade open seat, gold catch-all), which
          is the only chrome on the section. */}
      <SectionShell tone="cream" size="large">
        <ScrollReveal>
          <ChapterMarker>{t.chapter03}</ChapterMarker>
        </ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-6 md:mt-10">
          <SectionHeadline scale="standard" maxCh={20}>
            {t.teamTitle}
          </SectionHeadline>
        </ScrollReveal>

        {/* Ledger — 3/9 column split tightens the eyebrow gutter
            (was 4/8) so the content column breathes more, and the
            whole ledger sits closer to its headline (mt-14/mt-20
            instead of mt-16/mt-24). py-12/py-16 per row is a
            half-notch more generous than the previous py-10/py-14
            so the rows don't crowd when bios run two lines. */}
        <div className="mt-14 divide-y divide-[#1d1b18]/12 border-y border-[#1d1b18]/12 md:mt-20">
          {team.map((row, i) => (
            <ScrollReveal
              key={`${row.eyebrow}-${row.name}`}
              delay={0.08 + i * 0.05}
            >
              <div className="grid grid-cols-12 items-baseline gap-x-6 gap-y-5 py-12 md:gap-x-12 md:py-16">
                <div className="col-span-12 md:col-span-3">
                  <p
                    className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] [font-feature-settings:'tnum','calt','kern']"
                    style={{ color: row.eyebrowColor }}
                  >
                    {row.eyebrow}
                  </p>
                </div>
                <div className="col-span-12 md:col-span-9">
                  <SubHeadline as="h3">{row.name}</SubHeadline>
                  <BodyProse
                    size="compact"
                    tone="muted"
                    className="mt-5 md:mt-6"
                    maxCh={58}
                  >
                    {row.bio}
                  </BodyProse>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </SectionShell>

      {/* ─── § 04 THE PRINCIPLES ──────────────────────────────────
          Book-style ledger. Italic terra Roman-numeral prefix
          (fixed-width column so all four share a left edge and
          all four titles begin at the same X) + Sentient title
          in ink + a short BodyProse line underneath saying what
          the principle means in practice for EVA. Numeral still
          sits on the baseline of the title's first line via
          items-baseline; the body flows below without affecting
          alignment. */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ScrollReveal>
          <ChapterMarker>{t.chapter04}</ChapterMarker>
        </ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-6 md:mt-10">
          <SectionHeadline scale="standard" maxCh={14}>
            {t.valuesTitle}
          </SectionHeadline>
        </ScrollReveal>

        {/* Ledger — tighter mt-14/mt-20 so the ledger sits closer
            to its headline, and more generous py-12/py-20 per row
            now that each row carries a title + description (the
            previous py-10/py-16 was tuned for title-only rows). */}
        <div className="mt-14 divide-y divide-[#1d1b18]/12 border-y border-[#1d1b18]/12 md:mt-20">
          {principles.map((p, i) => (
            <ScrollReveal key={p.numeral} delay={0.08 + i * 0.06}>
              <div className="flex items-baseline gap-5 py-12 md:gap-10 md:py-20">
                {/* Italic Roman numeral prefix — terra, sized at
                    ~60% of the title so it reads as a label rather
                    than a competing element. Fixed width so all
                    four numerals share a left edge and all four
                    titles begin at the same X. */}
                <span
                  className="w-[44px] shrink-0 font-[family-name:var(--font-sentient)] text-[20px] font-medium italic leading-[1] text-[#97472c] md:w-[68px] md:text-[32px] lg:w-[84px] lg:text-[40px]"
                  aria-hidden
                >
                  {p.numeral}
                </span>
                <div className="min-w-0 flex-1">
                  <SubHeadline as="h3">{p.title}</SubHeadline>
                  <BodyProse
                    size="compact"
                    tone="muted"
                    className="mt-4 md:mt-6"
                    maxCh={58}
                  >
                    {p.body}
                  </BodyProse>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </SectionShell>

      {/* ─── § 05 THE HORIZON ─────────────────────────────────────
          Centered close on cream — no dark section. Breaking the
          asymmetric rhythm by centering the entire composition is
          the same gravity move the landing's § 05 Reveal makes.
          The HandDrawnUnderline draws under the last word
          ("beginning." / "comienzo."), the only such mark on the
          page. The vision body is three short declarative
          sentences in italic LedeItalic — open-ended on tools so
          the brand isn't committed to any specific technology. */}
      <SectionShell tone="cream" size="xlarge">
        <ScrollReveal>
          <ChapterMarker align="center">{t.chapter05}</ChapterMarker>
        </ScrollReveal>

        <div className="mt-10 flex flex-col items-center text-center md:mt-14">
          <ScrollReveal delay={0.08}>
            <SectionHeadline
              scale="grand"
              maxCh={16}
              balance={false}
              className="mx-auto"
            >
              {visionLeadWords}{" "}
              <span className="relative inline-block whitespace-nowrap">
                {visionLastWord}
                <HandDrawnUnderline offset="md" />
              </span>
            </SectionHeadline>
          </ScrollReveal>

          <ScrollReveal delay={0.18} className="mt-10 md:mt-14">
            <LedeItalic maxCh={46} className="mx-auto">
              {t.visionBody}
            </LedeItalic>
          </ScrollReveal>

          <ScrollReveal delay={0.28} className="mt-12 md:mt-16">
            <CTAButton href={`/${locale}/signup`}>{t.visionCta}</CTAButton>
          </ScrollReveal>
        </div>
      </SectionShell>
    </div>
  );
}
