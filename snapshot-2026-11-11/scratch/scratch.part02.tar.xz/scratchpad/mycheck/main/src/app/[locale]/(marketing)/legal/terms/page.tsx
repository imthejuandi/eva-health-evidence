"use client";

import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { SectionTag } from "@/components/marketing/SectionTag";

export default function TermsPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";

  if (locale === "es") return <TermsES />;
  return <TermsEN />;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-10">
      <h2 className="font-[family-name:var(--font-manrope)] text-[20px] font-extrabold text-[#1d1b18]">
        {title}
      </h2>
      <div className="mt-4 space-y-4 font-[family-name:var(--font-inter)] text-[15px] leading-relaxed text-[#4c463f]">
        {children}
      </div>
    </div>
  );
}

function TermsEN() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-3xl">
        <ScrollReveal>
          <SectionTag text="Legal" />
          <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[48px]">
            Terms of Service
          </h1>
          <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] font-medium uppercase tracking-[1.5px] text-[#8a7f76]">
            Last updated: March 2026
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <Section title="Service Description">
            <p>
              EVA Health is an educational health platform that helps you understand your biomarker data through personalised interpretation and actionable insights. EVA is <strong>not</strong> a medical provider. Our service is not a substitute for professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare professional for medical decisions.
            </p>
          </Section>

          <Section title="Eligibility">
            <p>
              You must be at least 18 years old to create an account and use EVA Health. By creating an account, you confirm that you meet this age requirement.
            </p>
          </Section>

          <Section title="Your Account">
            <p>
              You are responsible for maintaining the security of your account credentials. Do not share your login with others. You are responsible for all activity that occurs under your account. If you suspect unauthorised access, contact us immediately at hello@evahealth.es.
            </p>
          </Section>

          <Section title="Subscription">
            <p>
              EVA Health operates on a quarterly subscription model at <strong>€99 per quarter</strong>. Your subscription automatically renews at the end of each quarter unless cancelled. You can cancel at any time through your account settings; cancellation takes effect at the end of the current billing period. No partial refunds are provided for the current quarter.
            </p>
          </Section>

          <Section title="Your Content">
            <p>
              Lab results, health data, and any other information you upload to EVA remain your property. By uploading content, you grant EVA a limited licence to process this data solely to provide you with our service. We do not sell, share, or use your health data for any purpose beyond delivering your personalised health insights.
            </p>
          </Section>

          <Section title="Prohibited Use">
            <p>You agree not to:</p>
            <ul className="ml-5 list-disc space-y-2">
              <li>Share your account credentials with others or allow multiple people to use a single account</li>
              <li>Use automated tools to scrape, crawl, or extract data from the platform</li>
              <li>Attempt to reverse-engineer, decompile, or disassemble any part of the service</li>
              <li>Use the service for any unlawful purpose</li>
              <li>Misrepresent your identity or provide false information</li>
            </ul>
          </Section>

          <Section title="Limitation of Liability">
            <p>
              EVA Health provides health education and biomarker interpretation, not medical diagnosis or treatment. We are not liable for health decisions you make based on information provided through our platform. Our service is informational and educational in nature. Critical biomarker results include clear guidance to seek immediate medical attention, but ultimately your health decisions are your own.
            </p>
            <p>
              To the maximum extent permitted by Spanish law, EVA Health&rsquo;s total liability is limited to the amount you have paid for the service in the 12 months preceding any claim.
            </p>
          </Section>

          <Section title="Governing Law">
            <p>
              These terms are governed by the laws of Spain. Any disputes arising from these terms or your use of the service shall be submitted to the courts of Madrid, Spain, without prejudice to any mandatory consumer protection provisions that may apply in your country of residence.
            </p>
          </Section>

          <Section title="Changes to These Terms">
            <p>
              We may update these terms from time to time. We will notify you of any material changes at least 30 days in advance via the email address associated with your account. Continued use of the service after the effective date constitutes acceptance of the updated terms.
            </p>
          </Section>

          <Section title="Contact">
            <p>
              For questions about these terms:<br />
              <strong>EVA Health S.L.</strong><br />
              Madrid, Spain<br />
              hello@evahealth.es
            </p>
          </Section>
        </ScrollReveal>
      </div>
    </section>
  );
}

function TermsES() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-3xl">
        <ScrollReveal>
          <SectionTag text="Legal" />
          <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[48px]">
            Terminos del Servicio
          </h1>
          <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] font-medium uppercase tracking-[1.5px] text-[#8a7f76]">
            Ultima actualizacion: Marzo 2026
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <Section title="Descripcion del Servicio">
            <p>
              EVA Health es una plataforma educativa de salud que te ayuda a entender tus datos de biomarcadores a traves de interpretacion personalizada e informacion accionable. EVA <strong>no</strong> es un proveedor medico. Nuestro servicio no sustituye el consejo medico profesional, el diagnostico ni el tratamiento. Consulta siempre a un profesional sanitario cualificado para decisiones medicas.
            </p>
          </Section>

          <Section title="Elegibilidad">
            <p>
              Debes tener al menos 18 años para crear una cuenta y usar EVA Health. Al crear una cuenta, confirmas que cumples este requisito de edad.
            </p>
          </Section>

          <Section title="Tu Cuenta">
            <p>
              Eres responsable de mantener la seguridad de las credenciales de tu cuenta. No compartas tu inicio de sesion con otros. Eres responsable de toda la actividad que ocurra bajo tu cuenta. Si sospechas de acceso no autorizado, contactanos inmediatamente en hello@evahealth.es.
            </p>
          </Section>

          <Section title="Suscripcion">
            <p>
              EVA Health opera con un modelo de suscripcion trimestral a <strong>€99 por trimestre</strong>. Tu suscripcion se renueva automaticamente al final de cada trimestre a menos que la canceles. Puedes cancelar en cualquier momento a traves de la configuracion de tu cuenta; la cancelacion surte efecto al final del periodo de facturacion actual. No se proporcionan reembolsos parciales por el trimestre en curso.
            </p>
          </Section>

          <Section title="Tu Contenido">
            <p>
              Los resultados de laboratorio, datos de salud y cualquier otra informacion que subas a EVA siguen siendo de tu propiedad. Al subir contenido, nos otorgas una licencia limitada para procesar estos datos unicamente para proporcionarte nuestro servicio. No vendemos, compartimos ni usamos tus datos de salud para ningun proposito mas alla de entregar tus informacion de salud personalizada.
            </p>
          </Section>

          <Section title="Uso Prohibido">
            <p>Aceptas no:</p>
            <ul className="ml-5 list-disc space-y-2">
              <li>Compartir las credenciales de tu cuenta con otros ni permitir que multiples personas usen una sola cuenta</li>
              <li>Usar herramientas automatizadas para extraer datos de la plataforma</li>
              <li>Intentar aplicar ingenieria inversa, descompilar o desensamblar cualquier parte del servicio</li>
              <li>Usar el servicio para cualquier proposito ilegal</li>
              <li>Falsificar tu identidad o proporcionar informacion falsa</li>
            </ul>
          </Section>

          <Section title="Limitacion de Responsabilidad">
            <p>
              EVA Health proporciona educacion de salud e interpretacion de biomarcadores, no diagnostico ni tratamiento medico. No somos responsables de las decisiones de salud que tomes basandote en la informacion proporcionada a traves de nuestra plataforma. Nuestro servicio es de naturaleza informativa y educativa. Los resultados criticos de biomarcadores incluyen orientacion clara para buscar atencion medica inmediata, pero en ultima instancia, tus decisiones de salud son tuyas.
            </p>
            <p>
              En la medida maxima permitida por la legislacion española, la responsabilidad total de EVA Health se limita al importe que hayas pagado por el servicio en los 12 meses anteriores a cualquier reclamacion.
            </p>
          </Section>

          <Section title="Ley Aplicable">
            <p>
              Estos terminos se rigen por las leyes de España. Cualquier disputa derivada de estos terminos o tu uso del servicio se sometera a los tribunales de Madrid, España, sin perjuicio de las disposiciones imperativas de proteccion al consumidor que puedan ser aplicables en tu pais de residencia.
            </p>
          </Section>

          <Section title="Cambios en Estos Terminos">
            <p>
              Podemos actualizar estos terminos periodicamente. Te notificaremos de cualquier cambio material con al menos 30 dias de antelacion a traves del correo electronico asociado a tu cuenta. El uso continuado del servicio despues de la fecha efectiva constituye aceptacion de los terminos actualizados.
            </p>
          </Section>

          <Section title="Contacto">
            <p>
              Para consultas sobre estos terminos:<br />
              <strong>EVA Health S.L.</strong><br />
              Madrid, España<br />
              hello@evahealth.es
            </p>
          </Section>
        </ScrollReveal>
      </div>
    </section>
  );
}
