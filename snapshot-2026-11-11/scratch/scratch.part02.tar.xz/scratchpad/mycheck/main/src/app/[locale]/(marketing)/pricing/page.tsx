"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { panels } from "@/config/panels";
import { HeroSection } from "@/components/marketing/pricing-v2/HeroSection";
import { HowItWorks } from "@/components/marketing/pricing-v2/HowItWorks";
import { SpecimenReport } from "@/components/marketing/pricing-v2/SpecimenReport";
import { ComparisonMatrix } from "@/components/marketing/pricing-v2/ComparisonMatrix";
import { BiomarkerGrid } from "@/components/marketing/pricing-v2/BiomarkerGrid";
import { SpecialtyPanelsSection } from "@/components/marketing/pricing-v2/SpecialtyPanelsSection";
import { SocialProof } from "@/components/marketing/pricing-v2/SocialProof";
import { FoundersBlock } from "@/components/marketing/pricing-v2/FoundersBlock";
import { CancelAnytimeBanner } from "@/components/marketing/pricing-v2/CancelAnytimeBanner";
import { FAQTabs } from "@/components/marketing/pricing-v2/FAQTabs";
import { FinalCTA } from "@/components/marketing/pricing-v2/FinalCTA";
import { StickyConversionBar } from "@/components/marketing/pricing-v2/StickyConversionBar";
import { getBiomarkersForLocale } from "@/components/marketing/pricing-v2/biomarker-data";
import { getCopy } from "./copy";
import type { PlanCardProps } from "@/components/marketing/pricing-v2/PlanCard";

type CheckoutPlan = "quarterly" | "annual" | "full_panel";

export default function PricingPage() {
  const params = useParams();
  const router = useRouter();
  const locale = ((params.locale as string) ?? "es") as "en" | "es";
  const [loading, setLoading] = useState<CheckoutPlan | null>(null);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<"free" | "quarterly" | "full">("quarterly");

  const t = getCopy(locale);

  async function handleCheckout(plan: CheckoutPlan) {
    setLoading(plan);
    setCheckoutError(null);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale, plan }),
      });
      if (res.status === 401) {
        // Carry the intent so signup can resume checkout afterwards.
        router.push(`/${locale}/signup?intent=${plan}`);
        return;
      }
      const data = await res.json();
      if (data.url) {
        window.location.assign(data.url);
        return;
      }
      // API returned a non-2xx with an error message.
      setCheckoutError(
        data.error ??
          (locale === "es"
            ? "No se pudo iniciar el checkout. Intentalo de nuevo."
            : "Couldn't start checkout. Please try again."),
      );
    } catch {
      setCheckoutError(
        locale === "es"
          ? "Error de conexion. Comprueba tu red y vuelve a intentarlo."
          : "Network error. Check your connection and try again.",
      );
    } finally {
      setLoading(null);
    }
  }

  const buildPlans = (): PlanCardProps[] => [
    {
      id: "free",
      eyebrow: t.plans.free.eyebrow,
      name: t.plans.free.name,
      price: t.plans.free.price,
      priceSuffix: t.plans.free.priceSuffix,
      tagline: t.plans.free.tagline,
      features: t.plans.free.features,
      ctaLabel: t.plans.free.cta,
      ctaHref: `/${locale}/upload`,
      accent: "jade",
      onSelect: setSelectedPlan,
      footnote: t.plans.free.footnote,
    },
    {
      id: "quarterly",
      eyebrow: t.plans.quarterly.eyebrow,
      name: t.plans.quarterly.name,
      price: t.plans.quarterly.price,
      priceSuffix: t.plans.quarterly.priceSuffix,
      tagline: t.plans.quarterly.tagline,
      features: t.plans.quarterly.features,
      ctaLabel: t.plans.quarterly.cta,
      ctaOnClick: () => handleCheckout("quarterly"),
      mostPopular: true,
      mostPopularLabel: t.mostPopular,
      accent: "terra",
      loading: loading === "quarterly",
      onSelect: setSelectedPlan,
      footnote: t.plans.quarterly.footnote,
      // Annual billing variant of the same plan (F3). Same product in
      // Stripe, second recurring price; kit cadence stays quarterly.
      secondaryCta: {
        label: t.annualOffer.label,
        onClick: () => handleCheckout("annual"),
        loading: loading === "annual",
      },
    },
    {
      id: "full",
      eyebrow: t.plans.full.eyebrow,
      name: t.plans.full.name,
      price: t.plans.full.price,
      priceSuffix: t.plans.full.priceSuffix,
      tagline: t.plans.full.tagline,
      features: t.plans.full.features,
      ctaLabel: t.plans.full.cta,
      ctaOnClick: () => handleCheckout("full_panel"),
      accent: "gold",
      loading: loading === "full_panel",
      onSelect: setSelectedPlan,
      footnote: t.plans.full.footnote,
    },
  ];

  const plans = buildPlans();
  const specialtyPanels = Object.values(panels).filter(
    (p) => p.id !== "base" && p.id !== "full",
  );
  const biomarkers = getBiomarkersForLocale(locale);

  // Sticky bar: reflect the selected plan
  const stickyPrice =
    selectedPlan === "free"
      ? t.plans.free.price
      : selectedPlan === "full"
        ? t.plans.full.price
        : t.plans.quarterly.price;
  const stickySuffix =
    selectedPlan === "free"
      ? t.plans.free.priceSuffix
      : selectedPlan === "full"
        ? t.plans.full.priceSuffix
        : t.plans.quarterly.priceSuffix;
  const stickyLabel =
    selectedPlan === "free"
      ? t.plans.free.name
      : selectedPlan === "full"
        ? t.plans.full.name
        : t.plans.quarterly.name;
  const handleStickyCta = () => {
    if (selectedPlan === "free") router.push(`/${locale}/upload`);
    else if (selectedPlan === "full") handleCheckout("full_panel");
    else handleCheckout("quarterly");
  };

  const handleQuoteSubmit = async ({ panelId, email }: { panelId: string; email: string }) => {
    // Lightweight fire-and-forget: log to console. Wire to a real endpoint later.
    console.log("[quote-request]", { panelId, email, locale });
    await new Promise((r) => setTimeout(r, 400));
  };

  return (
    <main className="bg-eva-surface">
      <div data-pricing-hero>
        <HeroSection
          eyebrow={t.hero.eyebrow}
          headline={t.hero.headline}
          highlightWord={t.hero.highlightWord}
          subhead={t.hero.subhead}
          plans={plans}
          trustItems={t.trustItems}
        />
      </div>

      <HowItWorks
        eyebrow={t.howItWorks.eyebrow}
        headline={t.howItWorks.headline}
        steps={t.howItWorks.steps}
      />

      <SpecimenReport
        eyebrow={t.specimen.eyebrow}
        headline={t.specimen.headline}
        kicker={t.specimen.kicker}
        meta={t.specimen.meta}
        rows={t.specimen.rows}
        pullQuote={t.specimen.pullQuote}
        signature={t.specimen.signature}
      />

      <ComparisonMatrix
        eyebrow={t.comparison.eyebrow}
        headline={t.comparison.headline}
        columns={t.comparison.columns}
        groups={t.comparison.groups}
        mostPopularLabel={t.mostPopular}
      />

      <BiomarkerGrid
        eyebrow={t.biomarkers.eyebrow}
        headline={t.biomarkers.headline}
        kicker={t.biomarkers.kicker}
        markers={biomarkers}
        closeLabel={t.biomarkers.close}
        detectsLabel={t.biomarkers.detects}
        rangeLabel={t.biomarkers.range}
        mattersLabel={t.biomarkers.matters}
        categories={t.biomarkers.categories}
      />

      <SpecialtyPanelsSection
        eyebrow={t.specialty.eyebrow}
        headline={t.specialty.headline}
        kicker={t.specialty.kicker}
        locale={locale}
        panels={specialtyPanels}
        includedLabel={t.specialty.included}
        quoteLabel={t.specialty.quote}
        addonSuffix={t.specialty.addonSuffix}
        biomarkersLabel={t.specialty.biomarkers}
        formEmailLabel={t.specialty.formEmailLabel}
        formEmailPlaceholder={t.specialty.formEmailPlaceholder}
        formSubmitLabel={t.specialty.formSubmit}
        formSuccess={t.specialty.formSuccess}
        formError={t.specialty.formError}
        onQuoteSubmit={handleQuoteSubmit}
      />

      <SocialProof
        eyebrow={t.social.eyebrow}
        headline={t.social.headline}
        stat={t.social.stat}
        testimonials={t.social.testimonials}
        pressLabel={t.social.pressLabel}
        pressLogos={t.social.pressLogos}
      />

      <FoundersBlock
        eyebrow={t.founders.eyebrow}
        quote={t.founders.quote}
        attribution={t.founders.attribution}
        role={t.founders.role}
        aboutLabel={t.founders.aboutLabel}
        aboutHref={`/${locale}/about`}
        cmoName={t.founders.cmoName}
        cmoRole={t.founders.cmoRole}
        cmoNote={t.founders.cmoNote}
      />

      <CancelAnytimeBanner
        eyebrow={t.cancel.eyebrow}
        headline={t.cancel.headline}
        promises={t.cancel.promises}
        ctaLabel={t.cancel.cta}
        onCta={() => handleCheckout("quarterly")}
        loading={loading === "quarterly"}
      />

      <FAQTabs
        eyebrow={t.faq.eyebrow}
        headline={t.faq.headline}
        categories={t.faq.categories}
      />

      <FinalCTA
        eyebrow={t.final.eyebrow}
        headline={t.final.headline}
        subhead={t.final.subhead}
        plans={plans}
        escapeHatchLabel={t.final.escapeHatch}
        escapeHatchHref={`/${locale}/upload`}
      />

      <StickyConversionBar
        label={stickyLabel}
        price={stickyPrice}
        priceSuffix={stickySuffix}
        ctaLabel={t.sticky.cta}
        onCta={handleStickyCta}
        loading={loading !== null}
        dismissLabel={t.sticky.dismiss}
      />

      {/* Checkout error toast — surfaces server / Stripe errors so the
          user understands why a button click didn't proceed. Auto-
          dismisses on the next click attempt. */}
      {checkoutError && (
        <div
          role="alert"
          className="fixed inset-x-4 bottom-24 z-50 mx-auto max-w-md rounded-[16px] border border-[#b04040]/30 bg-[#fef8f2] p-4 shadow-[0_18px_50px_-12px_rgba(176,64,64,0.35)]"
        >
          <div className="flex items-start gap-3">
            <span
              aria-hidden
              className="mt-1 inline-block h-2 w-2 shrink-0 rounded-full bg-[#b04040]"
            />
            <div className="flex-1 font-[family-name:var(--font-manrope)] text-[13px] leading-[1.5] text-[#1d1b18]">
              {checkoutError}
            </div>
            <button
              type="button"
              onClick={() => setCheckoutError(null)}
              aria-label="Dismiss"
              className="-m-1 p-1 text-[#8a7f76] transition-colors hover:text-[#1d1b18]"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
