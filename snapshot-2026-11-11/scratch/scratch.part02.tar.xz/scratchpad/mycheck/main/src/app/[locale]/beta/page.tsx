import { redirect } from "next/navigation";
import { BetaClient } from "./beta-client";

interface BetaPageProps {
  params: Promise<{ locale: string }>;
}

export default async function BetaPage({ params }: BetaPageProps) {
  const { locale } = await params;
  // Once the launch flip flag is set, /beta becomes a dead URL.
  // Redirect bookmarked / shared links to the marketing landing
  // instead of showing a gate form that does nothing.
  if (process.env.BETA_GATE_ENABLED === "false") {
    redirect(`/${locale}`);
  }
  return <BetaClient locale={locale} />;
}
