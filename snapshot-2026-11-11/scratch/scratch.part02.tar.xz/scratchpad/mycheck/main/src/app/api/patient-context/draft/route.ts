import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { clearDraft, getDraft, saveDraft } from "@/lib/patient-context";
import {
  DurableContextSnapshotSchema,
  TransientContextSchema,
} from "@/lib/patient-context/schema";

/**
 * Patient-context draft autosave. The upload UI POSTs here every couple
 * of seconds while the user is editing context so bouncing the tab
 * never loses progress. Cleared (via DELETE) on a successful save to
 * the canonical /api/patient-context endpoint.
 */

const DraftBodySchema = z.object({
  durable: DurableContextSnapshotSchema,
  transient: TransientContextSchema.optional(),
});

export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const draft = await getDraft(user.id).catch((err: Error) => {
    console.error("[patient-context.draft.GET] load failed:", err);
    return null;
  });
  return NextResponse.json({ draft });
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const raw = await req.json().catch(() => null);
  const parsed = DraftBodySchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid draft", details: parsed.error.issues },
      { status: 400 },
    );
  }

  try {
    await saveDraft(user.id, parsed.data);
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[patient-context.draft.POST] save failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to save draft" },
      { status: 500 },
    );
  }
}

export async function DELETE() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    await clearDraft(user.id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[patient-context.draft.DELETE] clear failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to clear draft" },
      { status: 500 },
    );
  }
}
