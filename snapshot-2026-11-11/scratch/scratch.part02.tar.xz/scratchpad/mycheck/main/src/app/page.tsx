import { redirect } from "next/navigation";
import { routing } from "@/i18n/routing";

/**
 * Non-localized root. Every real page lives under `app/[locale]/`, and the
 * document shell (`<html lang>`) is rendered by `app/[locale]/layout.tsx` — so
 * "/" must not render its own (shell-less) content. Redirect to the default
 * locale. The proxy also redirects "/", but this keeps the route valid even if
 * the proxy is bypassed (e.g. a direct crawler / health-check hit) and avoids
 * prerendering an orphan, `<html>`-less fragment.
 */
export default function RootIndex() {
  redirect(`/${routing.defaultLocale}`);
}
