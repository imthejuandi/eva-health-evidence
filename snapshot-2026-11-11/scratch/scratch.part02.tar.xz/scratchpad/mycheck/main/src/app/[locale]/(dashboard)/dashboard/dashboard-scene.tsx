"use client";

/**
 * MergedScene — constellation variant for the merged direction.
 *
 * Identical to the Direction B scene except for the Scene component's
 * rotation behaviour, per the user's feedback on the original:
 *   - No continuous drift rotation (the original added `t * 0.04` to
 *     targetRy which made the whole group keep turning).
 *   - Parallax tilt is clamped to a small range so the map always
 *     faces the viewer.
 *   - Small return-to-zero spring when the cursor leaves the canvas.
 *
 * Everything else — the nodes, rings, filaments, glow, and hover
 * behaviour — is the same as the original constellation.
 */

import { useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import { useReducedMotion } from "framer-motion";
import * as THREE from "three";
import type { BiomarkerValue } from "@/lib/queries/types";
import { formatCategoryLabel } from "@/lib/dashboard-format";

const ZONE_COLOR: Record<BiomarkerValue["zone"], string> = {
  optimal: "#3a665e",
  below_optimal: "#c49332",
  above_optimal: "#c49332",
  critical_low: "#b04040",
  critical_high: "#b04040",
  // Unclassified markers are filtered out of the orb in buildOrbLayout
  // — this colour is here only so the type record is exhaustive.
  unclassified: "#8a7f76",
};

export type NodeDatum = {
  id: string;
  key: string;
  name: string;
  category: string;
  zone: BiomarkerValue["zone"];
  value: number;
  unit: string;
  position: [number, number, number];
  color: string;
};

/* Specimen-plate composition.
 *
 * Two encoded axes plus a set of derived "plate" properties:
 *
 *   1. Angle is CATEGORY, with each category's slice sized proportionally
 *      to how many markers it contains. Dense categories get more
 *      breathing room; sparse categories stay crisp. The orb's silhouette
 *      itself encodes "where this person's panel is heavy."
 *
 *   2. Radius is ZONE TIER. Optimal markers sit innermost (closer to
 *      centre = healthier); attention in the middle band; action on
 *      the outermost band. Three reference rings are drawn independent
 *      of how many tiers the user actually populates so the orb's
 *      footprint is stable across users.
 *
 *   3. Each wedge carries a "health balance" — the dominant zone tier —
 *      which the Scene uses to tint the wedge's background wash. A
 *      mostly-optimal category reads as jade, mostly-attention as gold,
 *      mostly-action as terra. Before reading any label, the colour
 *      composition of the orb already tells the user something.
 */
type ZoneTier = "optimal" | "attention" | "action";

function zoneTier(zone: BiomarkerValue["zone"]): ZoneTier {
  if (zone === "optimal") return "optimal";
  if (zone === "critical_low" || zone === "critical_high") return "action";
  return "attention";
}

export const ZONE_TIER_RADIUS: Record<ZoneTier, number> = {
  // Inner-ring radius pushed out so the longevity numeral overlay
  // (180px score + 56px bio/chrono age row + delta) sits cleanly inside
  // the optimal ring instead of overlapping the inner band of dots.
  // Action ring also grows so the three rings stay readably spaced.
  optimal: 2.0,
  attention: 2.7,
  action: 3.4,
};

// Minimum slice size as a fraction of the full circle. Categories with
// only one or two markers should still get a readable wedge — without a
// minimum, a 1-of-100 category disappears to ~3.6° and reads as noise.
const MIN_SLICE_FRACTION = 0.035;

// Fractional inset on each side of a slice so wedges read as distinct
// groups rather than merging into a continuous ring.
const SLICE_INSET = 0.07;

// Tier wash colours for the wedge backgrounds (in OKLCH for a calmer,
// editorial feel — these are the same hue families as the dot colours
// but pulled way back in chroma so they layer behind the dots).
export const WEDGE_TIER_TINT: Record<ZoneTier, string> = {
  optimal: "#bcece1", // pale jade
  attention: "#f4d99a", // pale gold
  action: "#e8b3a3", // pale terra
};

export type WedgeDatum = {
  category: string;
  startAngle: number;
  endAngle: number;
  centerAngle: number;
  // Health balance derived from the marker mix. Used to tint the wedge
  // background — a mostly-optimal category gets a jade wash, mostly-
  // attention gold, mostly-action terra.
  balance: ZoneTier;
  count: number;
  optimal: number;
  attention: number;
  action: number;
};

export type OrbLayout = {
  nodes: NodeDatum[];
  wedges: WedgeDatum[];
};

function dominantTier(
  optimal: number,
  attention: number,
  action: number,
): ZoneTier {
  if (action > 0 && action >= attention) return "action";
  if (attention > 0 && attention >= optimal) return "attention";
  return "optimal";
}

// Tiny deterministic radial jitter so dots don't sit on a perfect ring
// — the hand-drawn feel comes from this. Keyed on biomarker_key so the
// same biomarker is always at the same offset across re-renders.
function jitterFor(key: string, range: number): number {
  let h = 0;
  for (let i = 0; i < key.length; i++) {
    h = (h * 31 + key.charCodeAt(i)) | 0;
  }
  const norm = ((h % 1000) + 1000) % 1000; // 0..999
  return ((norm / 999) - 0.5) * 2 * range;
}

export function buildOrbLayout(biomarkers: BiomarkerValue[]): OrbLayout {
  // Filter out markers we can't place meaningfully on the orb:
  //   - zone "unclassified" — ref-range lookup failed during processing,
  //     so we have no defensible position to draw it at.
  //   - category "" or "uncategorized" — same root cause, no panel
  //     mapping. They'd otherwise pile up under a single grey wedge
  //     that adds noise without telling the user anything.
  // Both are still surfaced in the BiomarkerSection below the hero so
  // the data isn't hidden — just kept out of the headline visual.
  const placeable = biomarkers.filter(
    (b) =>
      b.zone !== "unclassified" &&
      !!b.category &&
      b.category !== "uncategorized",
  );

  const byCategory = new Map<string, BiomarkerValue[]>();
  for (const b of placeable) {
    const arr = byCategory.get(b.category) ?? [];
    arr.push(b);
    byCategory.set(b.category, arr);
  }
  const categories = Array.from(byCategory.keys()).sort();
  const nCategories = categories.length;
  if (nCategories === 0) return { nodes: [], wedges: [] };

  const total = placeable.length;
  const TWO_PI = Math.PI * 2;
  const minSlice = MIN_SLICE_FRACTION * TWO_PI;

  // Two-pass slice sizing: every category gets minSlice, then the
  // remainder of the circle is split proportionally to count. This
  // lets a 1-marker category and a 20-marker category coexist legibly.
  const reservedMin = Math.min(minSlice * nCategories, TWO_PI * 0.8);
  const effectiveMin = reservedMin / nCategories;
  const remaining = Math.max(0, TWO_PI - reservedMin);

  const slices = categories.map((cat) => {
    const count = byCategory.get(cat)!.length;
    return effectiveMin + remaining * (count / total);
  });

  // Start at 12 o'clock and run clockwise.
  let cursor = -Math.PI / 2;
  const wedges: WedgeDatum[] = [];
  const nodes: NodeDatum[] = [];

  categories.forEach((cat, catIdx) => {
    const markers = byCategory
      .get(cat)!
      .slice()
      .sort((a, b) => a.biomarker_key.localeCompare(b.biomarker_key));
    const n = markers.length;
    const sliceSize = slices[catIdx];
    const startAngle = cursor;
    const endAngle = cursor + sliceSize;
    cursor = endAngle;

    const optimal = markers.filter((m) => m.zone === "optimal").length;
    const action = markers.filter(
      (m) => m.zone === "critical_low" || m.zone === "critical_high",
    ).length;
    const attention = n - optimal - action;

    wedges.push({
      category: cat,
      startAngle,
      endAngle,
      centerAngle: (startAngle + endAngle) / 2,
      balance: dominantTier(optimal, attention, action),
      count: n,
      optimal,
      attention,
      action,
    });

    // Place each marker within its wedge. Markers are spread angularly
    // by sort order; their radius is tier-driven, with a small
    // deterministic jitter so the orb looks hand-placed rather than
    // mathematically precise.
    const inset = sliceSize * SLICE_INSET;
    const usable = sliceSize - 2 * inset;
    markers.forEach((m, i) => {
      const subAngle =
        n === 1
          ? startAngle + sliceSize / 2
          : startAngle + inset + (i / (n - 1)) * usable;
      const tier = zoneTier(m.zone);
      const baseR = ZONE_TIER_RADIUS[tier];
      const r = baseR + jitterFor(m.biomarker_key, 0.08);
      const z = jitterFor(m.id, 0.05);
      nodes.push({
        id: m.id,
        key: m.biomarker_key,
        name: m.biomarker_name,
        category: m.category,
        zone: m.zone,
        value: m.value,
        unit: m.unit,
        position: [Math.cos(subAngle) * r, Math.sin(subAngle) * r, z],
        color: ZONE_COLOR[m.zone],
      });
    });
  });

  return { nodes, wedges };
}

// Backward-compat for the marketing reveal-constellation, which calls
// buildNodes directly. Keep returning just the node list.
export function buildNodes(biomarkers: BiomarkerValue[]): NodeDatum[] {
  return buildOrbLayout(biomarkers).nodes;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Node — visually static. Previously each node had its own useFrame
 * doing Math.sin pulse + 4 lerp calls (scale × 2 + opacity × 2). With
 * ~50 nodes and the canvas's frameloop="always" that's ~12k lerp calls
 * per second on the main thread, which on mobile saturated input
 * processing and made scroll feel laggy / stuck. We now compute the
 * scale and opacity directly from props/state and let JSX/React drive
 * the values — instant feedback on hover and category-select instead
 * of a smooth lerp, but no per-frame work.
 * ────────────────────────────────────────────────────────────────────────── */
function Node({
  node,
  highlighted,
  dimmed,
  onHover,
  onUnhover,
  onPin,
  enableHover = true,
}: {
  node: NodeDatum;
  highlighted: boolean;
  dimmed: boolean;
  onHover: (n: NodeDatum, screen: { x: number; y: number }) => void;
  onUnhover: () => void;
  onPin: (n: NodeDatum, screen: { x: number; y: number }) => void;
  enableHover?: boolean;
}) {
  const [hovered, setHovered] = useState(false);
  const { camera, size } = useThree();

  // Marker size encodes zone severity. Optimal markers are small and
  // calm — they're "fine, move on." Attention markers sit larger so
  // they catch the eye. Action markers are largest with the strongest
  // glow so they read as urgent before any number is interpreted.
  const baseSize =
    node.zone === "optimal"
      ? 0.065
      : node.zone === "critical_low" || node.zone === "critical_high"
        ? 0.13
        : 0.095;

  const tierGlowOpacity =
    node.zone === "optimal"
      ? 0.14
      : node.zone === "critical_low" || node.zone === "critical_high"
        ? 0.34
        : 0.22;

  const tierGlowScale =
    node.zone === "optimal"
      ? 1.7
      : node.zone === "critical_low" || node.zone === "critical_high"
        ? 2.2
        : 1.9;

  // Category-selection emphasis: highlighted nodes scale up and brighten
  // their halo; non-matching nodes shrink and fade so the user's eye
  // locks onto the selected category. Without a selection, every node
  // sits at its natural tier-derived weight.
  const emphasis = highlighted ? 1.7 : dimmed ? 0.55 : 1;
  const coreScale = (hovered ? 1.55 : 1) * emphasis;
  const glowScale = (hovered ? 2.4 : tierGlowScale) * emphasis;
  const coreOpacity = dimmed ? 0.2 : 1;
  const glowOpacity = dimmed
    ? 0.04
    : highlighted
      ? Math.min(0.45, tierGlowOpacity + 0.12)
      : tierGlowOpacity;

  // Hover handlers are only attached when enableHover is true (desktop).
  // On touch we deliberately omit them so R3F's events manager does not
  // raycast the scene on every pointermove.
  const hoverHandlers = enableHover
    ? {
        onPointerOver: (e: { stopPropagation: () => void }) => {
          e.stopPropagation();
          setHovered(true);
          if (typeof document !== "undefined") {
            document.body.style.cursor = "pointer";
          }
          const v = new THREE.Vector3(...node.position);
          v.project(camera);
          onHover(node, {
            x: ((v.x + 1) / 2) * size.width,
            y: ((-v.y + 1) / 2) * size.height,
          });
        },
        onPointerOut: (e: { stopPropagation: () => void }) => {
          e.stopPropagation();
          setHovered(false);
          if (typeof document !== "undefined") {
            document.body.style.cursor = "";
          }
          onUnhover();
        },
      }
    : {};

  return (
    <group
      position={node.position}
      {...hoverHandlers}
      // Click pins the tooltip so touch users can select nodes reliably.
      // stopPropagation keeps the canvas onPointerMissed handler from
      // firing and immediately unpinning.
      onClick={(e) => {
        e.stopPropagation();
        const v = new THREE.Vector3(...node.position);
        v.project(camera);
        onPin(node, {
          x: ((v.x + 1) / 2) * size.width,
          y: ((-v.y + 1) / 2) * size.height,
        });
      }}
    >
      <mesh scale={glowScale}>
        <sphereGeometry args={[baseSize * 2.2, 16, 16]} />
        <meshBasicMaterial
          color={node.color}
          transparent
          opacity={glowOpacity}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
      <mesh scale={coreScale}>
        <sphereGeometry args={[baseSize, 16, 16]} />
        <meshBasicMaterial
          color={node.color}
          transparent
          opacity={coreOpacity}
          toneMapped={false}
        />
      </mesh>
    </group>
  );
}

/* Ring + Filaments — same as the original. */
function Ring({ radius }: { radius: number }) {
  const geo = useMemo(() => {
    const segments = 128;
    const pts: number[] = [];
    for (let i = 0; i < segments; i++) {
      const a0 = (i / segments) * Math.PI * 2;
      const a1 = ((i + 0.6) / segments) * Math.PI * 2;
      pts.push(
        Math.cos(a0) * radius,
        Math.sin(a0) * radius,
        0,
        Math.cos(a1) * radius,
        Math.sin(a1) * radius,
        0,
      );
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute(
      "position",
      new THREE.Float32BufferAttribute(new Float32Array(pts), 3),
    );
    return g;
  }, [radius]);

  return (
    <lineSegments geometry={geo}>
      <lineBasicMaterial
        color="#1d1b18"
        transparent
        opacity={0.08}
        depthWrite={false}
      />
    </lineSegments>
  );
}

/* WedgeBackground — a transparent tinted sector behind a category's
 * arc. Tint reflects the category's dominant tier so the orb starts
 * to "feel" the data before any label is read. The wedge insets
 * slightly on each side so adjacent wedges read as separate plates
 * with thin warm gaps between them.
 */
function WedgeBackground({
  wedge,
  highlighted,
  dimmed,
}: {
  wedge: WedgeDatum;
  highlighted: boolean;
  dimmed: boolean;
}) {
  const inner = ZONE_TIER_RADIUS.optimal - 0.55;
  const outer = ZONE_TIER_RADIUS.action + 0.4;
  const sliceSize = wedge.endAngle - wedge.startAngle;
  const inset = sliceSize * SLICE_INSET;
  const start = wedge.startAngle + inset;
  const length = sliceSize - 2 * inset;

  const tint = WEDGE_TIER_TINT[wedge.balance];
  const opacity = dimmed ? 0.04 : highlighted ? 0.45 : 0.14;

  return (
    <mesh>
      <ringGeometry args={[inner, outer, 48, 1, start, length]} />
      <meshBasicMaterial
        color={tint}
        transparent
        opacity={opacity}
        depthWrite={false}
      />
    </mesh>
  );
}

/* CenterAnchor — a small specimen-plate marker at the orb's centre.
 * Two concentric rings + a tiny dot, all in ink at low opacity. Reads
 * as a calibration point on a hand-drawn chart. */
function CenterAnchor() {
  return (
    <group>
      <mesh>
        <ringGeometry args={[0.16, 0.165, 64]} />
        <meshBasicMaterial
          color="#1d1b18"
          transparent
          opacity={0.22}
          depthWrite={false}
        />
      </mesh>
      <mesh>
        <ringGeometry args={[0.07, 0.073, 48]} />
        <meshBasicMaterial
          color="#1d1b18"
          transparent
          opacity={0.35}
          depthWrite={false}
        />
      </mesh>
      <mesh>
        <circleGeometry args={[0.018, 16]} />
        <meshBasicMaterial
          color="#1d1b18"
          transparent
          opacity={0.6}
          depthWrite={false}
        />
      </mesh>
    </group>
  );
}

/* HighlightFilaments — only drawn when a category is selected, this
 * traces a single line through that category's markers in angular
 * order so the highlighted set reads as a connected constellation
 * pattern rather than scattered points. */
function HighlightFilaments({
  nodes,
  highlightedCategory,
}: {
  nodes: NodeDatum[];
  highlightedCategory: string | null;
}) {
  const geo = useMemo(() => {
    if (!highlightedCategory) return null;
    const inCat = nodes
      .filter((n) => n.category === highlightedCategory)
      .slice()
      .sort((a, b) => Math.atan2(a.position[1], a.position[0]) - Math.atan2(b.position[1], b.position[0]));
    if (inCat.length < 2) return null;
    const pts: number[] = [];
    for (let i = 0; i < inCat.length - 1; i++) {
      const a = inCat[i].position;
      const b = inCat[i + 1].position;
      pts.push(a[0], a[1], a[2], b[0], b[1], b[2]);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute(
      "position",
      new THREE.Float32BufferAttribute(new Float32Array(pts), 3),
    );
    return g;
  }, [nodes, highlightedCategory]);

  if (!geo) return null;

  return (
    <lineSegments geometry={geo}>
      <lineBasicMaterial
        color="#97472c"
        transparent
        opacity={0.55}
        depthWrite={false}
      />
    </lineSegments>
  );
}

/* CategoryLabel — small-caps mono category name placed just outside
 * the action ring at the wedge's centre angle. Always visible (this
 * is the editorial / specimen-plate move — labels belong on the chart,
 * not in a hover state).
 *
 * Anchor position flips left/right based on which side of the orb the
 * label sits on, so the text reads outward from the centre. */
function CategoryLabel({
  wedge,
  locale,
  highlightedCategory,
}: {
  wedge: WedgeDatum;
  locale: string;
  highlightedCategory: string | null;
}) {
  const labelRadius = ZONE_TIER_RADIUS.action + 0.55;
  const x = Math.cos(wedge.centerAngle) * labelRadius;
  const y = Math.sin(wedge.centerAngle) * labelRadius;
  const isLeft = Math.cos(wedge.centerAngle) < -0.05;
  const isRight = Math.cos(wedge.centerAngle) > 0.05;
  const align: "left" | "right" | "center" = isLeft
    ? "right"
    : isRight
      ? "left"
      : "center";

  const isHighlighted =
    highlightedCategory != null && wedge.category === highlightedCategory;
  const isDimmed =
    highlightedCategory != null && wedge.category !== highlightedCategory;

  return (
    <Html
      position={[x, y, 0]}
      center
      pointerEvents="none"
      transform={false}
      sprite={false}
      style={{
        // textAlign needs to apply to the inline-block child below so
        // we keep the wrapper a fixed centred origin and shift the
        // label horizontally based on which side of the orb it's on.
        transform:
          align === "right"
            ? "translateX(-50%)"
            : align === "left"
              ? "translateX(50%)"
              : "translateX(0)",
        whiteSpace: "nowrap",
        pointerEvents: "none",
        opacity: isDimmed ? 0.35 : 1,
        transition: "opacity 200ms ease",
      }}
    >
      <div
        style={{
          fontFamily: "var(--font-dm-mono)",
          fontSize: "10px",
          letterSpacing: "1.4px",
          textTransform: "uppercase",
          fontWeight: isHighlighted ? 800 : 600,
          color: isHighlighted ? "#1d1b18" : "#8a7f76",
          textAlign: align,
        }}
      >
        {formatCategoryLabel(wedge.category, locale)}
      </div>
    </Html>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * Scene — FIX: no continuous rotation, parallax is tiny, and the group
 * always returns to facing the viewer.
 * ────────────────────────────────────────────────────────────────────────── */
function Scene({
  nodes,
  wedges,
  locale,
  highlightedCategory,
  onHover,
  onUnhover,
  onPin,
  enableParallax,
  enableHover = true,
  showLabels = true,
}: {
  nodes: NodeDatum[];
  wedges: WedgeDatum[];
  locale: string;
  highlightedCategory: string | null;
  onHover: (n: NodeDatum, screen: { x: number; y: number }) => void;
  onUnhover: () => void;
  onPin: (n: NodeDatum, screen: { x: number; y: number }) => void;
  enableParallax: boolean;
  enableHover?: boolean;
  showLabels?: boolean;
}) {
  const group = useRef<THREE.Group>(null);
  const { viewport } = useThree();

  // Three reference rings — one per zone tier. Always rendered so the
  // orb has a stable shape; an empty ring just reads as "no markers
  // in that zone, that's the point."
  const ringRadii = useMemo(
    () => [
      ZONE_TIER_RADIUS.optimal,
      ZONE_TIER_RADIUS.attention,
      ZONE_TIER_RADIUS.action,
    ],
    [],
  );

  // Outer extent fed into the fit-to-viewport scaling. When labels
  // are showing we reserve a small leader band outside the action ring
  // for the perimeter category names; when they're hidden (mobile /
  // touch) the orb shrinks the band even further. The action ring
  // itself was bumped up — see ZONE_TIER_RADIUS — so the inner ring
  // ends up large enough that the centre numerals fit inside.
  const outerExtent = ZONE_TIER_RADIUS.action + (showLabels ? 0.55 : 0.3);

  // Scale the whole orb so it fits inside the canvas regardless of
  // aspect ratio. On a portrait phone the horizontal visible space at
  // z=0 is the limiting dimension; on a wide desktop the vertical is.
  // We treat showLabels as the desktop / mobile signal — when labels
  // are visible (desktop) the orb fills more of the canvas (98%) so
  // the centre numerals get plenty of room to breathe. On mobile we
  // hold at 94% to leave the glow halo a comfortable margin.
  const fitScale = useMemo(() => {
    if (outerExtent <= 0) return 1;
    const minVisible = Math.min(viewport.width, viewport.height);
    const targetPct = showLabels ? 0.98 : 0.94;
    const target = (minVisible * targetPct) / 2;
    return target / outerExtent;
  }, [viewport.width, viewport.height, outerExtent, showLabels]);

  return (
    <group ref={group} scale={fitScale}>
      {enableParallax && <ParallaxTilt groupRef={group} />}

      {/* Layer 1 — wedge backgrounds (tinted by category health) */}
      {wedges.map((w) => {
        const highlighted =
          highlightedCategory != null && w.category === highlightedCategory;
        const dimmed =
          highlightedCategory != null && w.category !== highlightedCategory;
        return (
          <WedgeBackground
            key={w.category}
            wedge={w}
            highlighted={highlighted}
            dimmed={dimmed}
          />
        );
      })}

      {/* Layer 2 — three zone rings (optimal / attention / action) */}
      {ringRadii.map((r) => (
        <Ring key={r} radius={r} />
      ))}

      {/* Layer 3 — center anchor (specimen-plate calibration mark) */}
      <CenterAnchor />

      {/* Layer 4 — connection filaments for the highlighted category */}
      <HighlightFilaments
        nodes={nodes}
        highlightedCategory={highlightedCategory}
      />

      {/* Layer 5 — biomarker dots */}
      {nodes.map((n) => {
        const highlighted =
          highlightedCategory != null && n.category === highlightedCategory;
        const dimmed =
          highlightedCategory != null && n.category !== highlightedCategory;
        return (
          <Node
            key={n.id}
            node={n}
            highlighted={highlighted}
            dimmed={dimmed}
            onHover={onHover}
            onUnhover={onUnhover}
            onPin={onPin}
            enableHover={enableHover}
          />
        );
      })}

      {/* Layer 6 — category labels around the perimeter */}
      {showLabels &&
        wedges.map((w) => (
          <CategoryLabel
            key={w.category}
            wedge={w}
            locale={locale}
            highlightedCategory={highlightedCategory}
          />
        ))}
    </group>
  );
}

/* ParallaxTilt — runs only on devices with fine pointer input. Lerps
 * the parent group's rotation toward a target derived from cursor
 * position. Mounting this is what triggers R3F's continuous render
 * loop on desktop; on touch we skip it entirely. */
function ParallaxTilt({ groupRef }: { groupRef: React.RefObject<THREE.Group | null> }) {
  const { pointer } = useThree();
  useFrame(() => {
    const g = groupRef.current;
    if (!g) return;
    g.rotation.x = THREE.MathUtils.lerp(g.rotation.x, pointer.y * 0.08, 0.05);
    g.rotation.y = THREE.MathUtils.lerp(g.rotation.y, pointer.x * 0.08, 0.05);
  });
  return null;
}

export function DashboardCanvas({
  nodes,
  wedges = [],
  locale,
  highlightedCategory,
  onHover,
  onUnhover,
  onPin,
  onUnpin,
  enableParallax,
  enableHover = true,
  showLabels = true,
}: {
  nodes: NodeDatum[];
  wedges?: WedgeDatum[];
  locale: string;
  highlightedCategory: string | null;
  onHover: (n: NodeDatum, screen: { x: number; y: number }) => void;
  onUnhover: () => void;
  onPin: (n: NodeDatum, screen: { x: number; y: number }) => void;
  onUnpin: () => void;
  enableParallax: boolean;
  enableHover?: boolean;
  showLabels?: boolean;
}) {
  // A11Y-003 / PERF-006: a reduced-motion preference disables the
  // continuous parallax tilt. ParallaxTilt is the only useFrame in the
  // scene and it's gated on this flag, and the canvas's frameloop is
  // too — so forcing parallax off both freezes the per-frame loop
  // (frameloop becomes "demand") and skips mounting the useFrame
  // entirely. The canvas stays interactive: R3F still invalidates on
  // hover / pin / category changes, so tooltips and selection work.
  const reduced = useReducedMotion();
  const parallax = enableParallax && !reduced;

  return (
    // R3F's `style` prop lands on its wrapper div, not the inner
    // <canvas> element, so vertical pan gestures starting on the canvas
    // itself were getting captured and the page felt stuck. The
    // dashboard-canvas-host class below sets touch-action: pan-y on the
    // canvas DOM node itself.
    <div className="dashboard-canvas-host h-full w-full">
      <Canvas
        // On devices with parallax we need the continuous render loop
        // for the tilt animation. Without parallax there's nothing
        // animating per-frame, so frameloop="demand" stops the render
        // loop between interactions and gives the main thread back to
        // scroll. R3F invalidates automatically on prop/state changes
        // (hover, category select), so the canvas still updates when
        // it needs to.
        frameloop={parallax ? "always" : "demand"}
        dpr={[1, 1.75]}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
        }}
        camera={{ position: [0, 0, 7], fov: 50 }}
        style={{ background: "transparent", touchAction: "pan-y" }}
        // Empty taps on the canvas background clear the pinned node so
        // tapping away on mobile dismisses the tooltip.
        onPointerMissed={onUnpin}
      >
        <Scene
          nodes={nodes}
          wedges={wedges}
          locale={locale}
          highlightedCategory={highlightedCategory}
          onHover={onHover}
          onUnhover={onUnhover}
          onPin={onPin}
          enableParallax={enableParallax}
          enableHover={enableHover}
          showLabels={showLabels}
        />
      </Canvas>
    </div>
  );
}
