import { SkeletonBiomarkerDetail } from "@/components/ui/Skeleton";
export default function BiomarkerLoading() { return <SkeletonBiomarkerDetail />; }
