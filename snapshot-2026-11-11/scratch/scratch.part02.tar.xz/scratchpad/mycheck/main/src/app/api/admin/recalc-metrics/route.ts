import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";
import { recomputeLabMetrics } from "@/lib/biomarkers/process-results";

/**
 * POST /api/admin/recalc-metrics — recompute the lab-level metrics (zone
 * counts, Longevity Score, KDM biological age, rolling-average BA) for every
 * lab result from its stored biomarker_values.
 *
 * Needed whenever the scoring changes under stored data — e.g. 2026-09-22,
 * when the Longevity Score registry moved to Echevarne's units and NLR became
 * a computed ratio: every score stored since 2026-09-17 was deflated.
 * Idempotent; biomarker_values are not touched. Audited.
 *
 * Body (optional): { labResultId } to recompute one; { since } (ISO date) to
 * bound the sweep; nothing = every lab result with values.
 */
export const maxDuration = 300;

const BodySchema = z
  .object({
    labResultId: z.string().uuid().optional(),
    since: z.string().datetime().optional(),
  })
  .strict();

export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const client = createAdminClient();
  if (!client) return NextResponse.json({ error: "Service role not configured" }, { status: 503 });

  const rawBody = await req.text();
  let body: unknown = {};
  if (rawBody.trim()) {
    try {
      body = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
    }
  }
  const parsed = BodySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid request", details: parsed.error.issues }, { status: 400 });

  let query = client.from("lab_results").select("id, user_id").order("created_at", { ascending: true });
  if (parsed.data.labResultId) query = query.eq("id", parsed.data.labResultId);
  if (parsed.data.since) query = query.gte("created_at", parsed.data.since);
  const { data: labs, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const results: { id: string; ok: boolean; error?: string }[] = [];
  for (const lab of (labs ?? []) as { id: string; user_id: string }[]) {
    try {
      await recomputeLabMetrics(lab.user_id, lab.id, client);
      results.push({ id: lab.id, ok: true });
    } catch (e) {
      results.push({ id: lab.id, ok: false, error: e instanceof Error ? e.message : String(e) });
    }
  }
  const failed = results.filter((r) => !r.ok);

  await logAdminAction({
    actor: admin,
    action: "recalc_metrics",
    targetId: parsed.data.labResultId ?? null,
    detail: { since: parsed.data.since ?? null, total: results.length, failed: failed.length, failedIds: failed.map((f) => f.id).slice(0, 50) },
  });

  return NextResponse.json({ total: results.length, ok: results.length - failed.length, failed });
}
