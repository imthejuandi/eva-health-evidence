import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { sendEmail } from "@/lib/email/send";
import { panels } from "@/config/panels";

const VALID_STATUSES = [
  "scheduled",
  "kit_sent",
  "sample_received",
  "processing",
  "completed",
  "cancelled",
] as const;

type Status = (typeof VALID_STATUSES)[number];

const BodySchema = z.object({
  bookingId: z.string().uuid(),
  status: z.enum(VALID_STATUSES),
  trackingNumber: z.string().nullish(),
  trackingUrl: z.string().nullish(),
});

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  // Admin acts on another user's booking → service-role client (authz enforced above).
  const supabase = createAdminClient();
  if (!supabase) return NextResponse.json({ error: "Server misconfigured" }, { status: 503 });

  const parsed = BodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "bookingId and a valid status are required",
        details: parsed.error.issues,
      },
      { status: 400 },
    );
  }
  const { bookingId, status, trackingNumber, trackingUrl } = parsed.data;

  // Fetch the booking + the owner's profile so we can compose the
  // notification email after a successful status update.
  const { data: booking, error: fetchError } = await supabase
    .from("booked_tests")
    .select(
      "id, user_id, panel_type, status, scheduled_date, profiles:user_id ( first_name, full_name, email, locale )",
    )
    .eq("id", bookingId)
    .single();

  if (fetchError || !booking) {
    return NextResponse.json(
      { error: fetchError?.message ?? "Booking not found" },
      { status: 404 },
    );
  }

  const previousStatus = booking.status as Status;

  const { error: updateError } = await supabase
    .from("booked_tests")
    .update({ status })
    .eq("id", bookingId);
  if (updateError) {
    return NextResponse.json({ error: updateError.message }, { status: 500 });
  }

  await logAdminAction({
    actor: admin,
    action: "update_booking",
    targetUserId: booking.user_id,
    targetId: bookingId,
    detail: { status, previousStatus },
  });

  // Per-status email triggers. Failure-tolerant — Resend errors are
  // logged but don't fail the status update so admins don't have to
  // retry the whole flip.
  // Supabase types the joined profiles relation as an array even when
  // the foreign key resolves to a single row; normalize either shape.
  type ProfileSlice = {
    first_name: string | null;
    full_name: string | null;
    email: string | null;
    locale: string | null;
  };
  const rawProfile = booking.profiles as
    | ProfileSlice
    | ProfileSlice[]
    | null
    | undefined;
  const profile: ProfileSlice | null = Array.isArray(rawProfile)
    ? (rawProfile[0] ?? null)
    : (rawProfile ?? null);
  const userEmail = profile?.email ?? null;
  const locale = profile?.locale === "es" ? "es" : "en";
  const firstName =
    profile?.first_name ??
    profile?.full_name?.split(" ")[0] ??
    (locale === "es" ? "Cliente" : "there");
  const panelKey = booking.panel_type ?? "base";
  const panelDef = panels[panelKey];
  const panelName = panelDef
    ? locale === "es"
      ? panelDef.name_es
      : panelDef.name
    : panelKey;

  const transitionedTo = (next: Status) =>
    previousStatus !== next && status === next;

  try {
    if (transitionedTo("kit_sent") && userEmail) {
      await sendEmail(
        userEmail,
        "kit-shipped",
        {
          firstName,
          panelName,
          trackingNumber: trackingNumber ?? null,
          trackingUrl: trackingUrl ?? null,
          locale,
        },
        locale,
      );
    } else if (transitionedTo("sample_received") && userEmail) {
      await sendEmail(
        userEmail,
        "sample-received",
        { firstName, panelName, locale },
        locale,
      );
    }
    // The 'completed' transition is handled separately by the
    // lab-results pipeline which fires the existing 'results-ready'
    // template once the actual lab data lands. Sending another
    // status-flip email here would duplicate it.
  } catch (e) {
    console.error("[admin/bookings] email send failed:", e);
  }

  return NextResponse.json({
    success: true,
    bookingId,
    previousStatus,
    status,
  });
}
