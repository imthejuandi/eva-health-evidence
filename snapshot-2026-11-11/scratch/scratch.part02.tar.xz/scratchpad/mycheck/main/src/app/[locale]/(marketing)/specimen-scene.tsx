"use client";

/**
 * HeroSpecimenScene — the shader-driven specimen at the centre of
 * the bold landing hero. An icosphere is displaced by 3D simplex
 * noise in the vertex shader; the fragment shader paints it with
 * rim-lit warm earth tones that breathe with time.
 *
 * Cursor parallax is applied to the group rotation, but kept tight
 * so the thing always faces the viewer. Designed to be a visual
 * anchor, not a toy — the reader should be able to look away from
 * it and read the typography without fighting motion.
 */

import { useMemo, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useReducedMotion } from "framer-motion";
import * as THREE from "three";

const SIMPLEX_GLSL = /* glsl */ `
  vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}
  vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}
  float snoise(vec3 v){
    const vec2 C = vec2(1.0/6.0, 1.0/3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i  = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod(i, 289.0);
    vec4 p = permute(permute(permute(
              i.z + vec4(0.0, i1.z, i2.z, 1.0))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0))
            + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 1.0/7.0;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ * ns.x + ns.yyyy;
    vec4 y = y_ * ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0)*2.0 + 1.0;
    vec4 s1 = floor(b1)*2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
    p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
  }
`;

const VERT = /* glsl */ `
  uniform float uTime;
  uniform float uBreath;
  varying vec3 vWorldNormal;
  varying vec3 vWorldPosition;
  varying float vDisplacement;
  ${SIMPLEX_GLSL}
  void main() {
    // Much gentler displacement than the first draft — the specimen
    // reads as a living sphere with a subtle skin, not a pulsing
    // morph. Time is also slowed significantly so the motion feels
    // like breath rather than animation.
    float n1 = snoise(normal * 1.1 + uTime * 0.08);
    float n2 = snoise(normal * 2.4 + uTime * 0.14);
    float d = n1 * (0.06 + uBreath * 0.02) + n2 * 0.015;
    vec3 displaced = position + normal * d;

    // Approximate new normal via sampled tangents for a correct rim.
    vec3 t1 = normalize(cross(normal, vec3(0.0, 1.0, 0.001)));
    vec3 t2 = normalize(cross(normal, t1));
    float eps = 0.04;
    vec3 nb1 = position + t1 * eps;
    vec3 nb2 = position + t2 * eps;
    nb1 += normal *
      snoise(normalize(nb1) * 1.1 + uTime * 0.08) *
      (0.06 + uBreath * 0.02);
    nb2 += normal *
      snoise(normalize(nb2) * 1.1 + uTime * 0.08) *
      (0.06 + uBreath * 0.02);
    vec3 newNormal = normalize(cross(nb1 - displaced, nb2 - displaced));
    newNormal = normalize(mix(normal, newNormal, 0.5));

    vec4 worldPos = modelMatrix * vec4(displaced, 1.0);
    vWorldPosition = worldPos.xyz;
    vWorldNormal = normalize(mat3(modelMatrix) * newNormal);
    vDisplacement = d;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`;

const FRAG = /* glsl */ `
  uniform vec3 uColorCore;
  uniform vec3 uColorMid;
  uniform vec3 uColorRim;
  uniform vec3 uCameraPosition;
  varying vec3 vWorldNormal;
  varying vec3 vWorldPosition;
  varying float vDisplacement;
  void main() {
    vec3 viewDir = normalize(uCameraPosition - vWorldPosition);
    float ndv = max(0.0, dot(vWorldNormal, viewDir));
    // Wider rim so the edge glow is softer and more diffuse.
    float rim = pow(1.0 - ndv, 3.2);

    // Base mix — warmer at the core, cooler toward the ridges.
    // Tighter smoothstep window so the overall tone is more uniform
    // and there's less high-contrast movement.
    float ridge = smoothstep(-0.05, 0.15, vDisplacement);
    vec3 base = mix(uColorCore, uColorMid, ridge);

    // Softer rim intensity — the specimen glows at its edges but
    // doesn't burn out.
    vec3 color = base + uColorRim * rim * 0.55;

    // Gentle ambient so the shadow side doesn't go full black.
    color += base * 0.14;
    gl_FragColor = vec4(color, 1.0);
  }
`;

function Specimen() {
  const mat = useRef<THREE.ShaderMaterial>(null);
  const group = useRef<THREE.Group>(null);
  // `size` is the canvas pixel dimensions; R3F updates it automatically
  // on container resize. We read it to scale the specimen down for
  // narrow viewports so the sphere never clips against the canvas edges.
  const { camera, pointer, size } = useThree();

  // useMemo gives us a stable uniforms object for the initial mount.
  // Per-frame mutations happen through `mat.current.uniforms.*` —
  // three.js clones the initial object onto the material, so the
  // material owns the live state and React 19's lint (which forbids
  // mutating hook returns directly) is satisfied.
  const initialUniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uBreath: { value: 1 },
      uColorCore: { value: new THREE.Color("#97472c") },
      uColorMid: { value: new THREE.Color("#3a665e") },
      uColorRim: { value: new THREE.Color("#f6c38a") },
      uCameraPosition: { value: new THREE.Vector3() },
    }),
    [],
  );

  useFrame(({ clock }) => {
    if (!mat.current) return;
    const t = clock.getElapsedTime();
    const u = mat.current.uniforms;
    u.uTime.value = t;
    // Much slower breath (~0.45 Hz instead of 1.15 Hz) with a
    // smaller amplitude so it reads as life, not animation.
    u.uBreath.value = 1 + Math.sin(t * 0.45) * 0.08;
    (u.uCameraPosition.value as THREE.Vector3).copy(camera.position);

    if (group.current) {
      // Very tight parallax (~±2-3°) with no additive drift — the
      // specimen stays face-on and only responds to the cursor.
      const targetRx = pointer.y * 0.04;
      const targetRy = pointer.x * 0.06;
      group.current.rotation.x = THREE.MathUtils.lerp(
        group.current.rotation.x,
        targetRx,
        0.03,
      );
      group.current.rotation.y = THREE.MathUtils.lerp(
        group.current.rotation.y,
        targetRy,
        0.03,
      );

      // Responsive scaling — shrink the group on narrow viewports so
      // the 1.8-unit-radius specimen always fits inside the visible
      // frustum with ~20% margin. Derivation:
      //   visibleHeight = 2 * z * tan(fov/2) = 2 * 7.5 * tan(22°) ≈ 6.06
      //   visibleWidth  = visibleHeight * aspect
      //   We want sphere diameter (3.6) ≤ 0.8 * visibleWidth
      //   → scale ≤ (0.8 * 6.06 * aspect) / 3.6 = 1.346 * aspect
      // Capped at 1 so desktop never zooms in.
      const aspect = size.width / Math.max(1, size.height);
      const targetScale = Math.min(1, 1.35 * aspect);
      const currentScale = group.current.scale.x;
      group.current.scale.setScalar(
        THREE.MathUtils.lerp(currentScale, targetScale, 0.08),
      );
    }
  });

  return (
    <group ref={group}>
      {/* Core specimen */}
      <mesh>
        <icosahedronGeometry args={[1.8, 72]} />
        <shaderMaterial
          ref={mat}
          vertexShader={VERT}
          fragmentShader={FRAG}
          uniforms={initialUniforms}
        />
      </mesh>
      {/* Inner warm glow — softened so the rim doesn't blur the
          typography that sits in front of the specimen. */}
      <mesh scale={1.16}>
        <sphereGeometry args={[1.8, 32, 32]} />
        <meshBasicMaterial
          color="#d97b5c"
          transparent
          opacity={0.07}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
      {/* Outer soft halo — barely-there ambient wash. */}
      <mesh scale={1.44}>
        <sphereGeometry args={[1.8, 32, 32]} />
        <meshBasicMaterial
          color="#bcece1"
          transparent
          opacity={0.03}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
    </group>
  );
}

export function HeroSpecimenScene() {
  // A11Y-003 / PERF-006: when the visitor prefers reduced motion we
  // skip mounting the <Canvas> altogether. This both respects the
  // motion preference (no continuous shader/breath/parallax loop) and
  // saves the GPU/main-thread cost of running react-three-fiber's
  // frameloop. In its place we paint a calm, static stand-in that
  // mirrors the specimen's warm earth palette and rim glow so the hero
  // still reads as a deliberate composition rather than empty space.
  const reduced = useReducedMotion();

  if (reduced) {
    return (
      <div
        aria-hidden
        className="h-full w-full"
        style={{
          background:
            // Core warm terra fading through jade-tinged mid tones to a
            // soft cream rim, matching the shader's uColorCore/Mid/Rim.
            "radial-gradient(circle at 50% 50%, #97472c 0%, #7a4030 26%, #3a665e 58%, rgba(246,195,138,0.12) 78%, transparent 88%)",
        }}
      />
    );
  }

  return (
    <Canvas
      dpr={[1, 2]}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
      }}
      // Camera pulled back from 6 to 7.5 so the specimen reads as
      // an ambient presence behind the typography instead of a
      // full-bleed centrepiece.
      camera={{ position: [0, 0, 7.5], fov: 44 }}
      style={{ background: "transparent", touchAction: "pan-y" }}
    >
      <Specimen />
    </Canvas>
  );
}
