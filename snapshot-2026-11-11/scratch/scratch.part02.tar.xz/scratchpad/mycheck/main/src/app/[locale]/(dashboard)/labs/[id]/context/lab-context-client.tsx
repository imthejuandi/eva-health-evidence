"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { DashboardChrome, EditorialMasthead } from "@/components/dashboard";
import { PatientContextGate } from "@/components/dashboard/PatientContextGate";
import { fadeUp } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import type { TransientContext } from "@/lib/patient-context/options";

interface Props {
  locale: string;
  profileLocale: "en" | "es";
  userSex: "male" | "female" | null;
  labId: string;
  collectionDate: string | null;
}

/**
 * Webhook-flow context gate. The user lands here via the
 * "context-needed" email after a lab partner has dropped results in.
 * Confirming the gate POSTs to /api/lab-results/[id]/context, which
 * snapshots context + transitions the lab from pending_context →
 * processing → ready and finally fires the "results-ready" email.
 */
export function LabContextClient({
  locale,
  profileLocale,
  userSex,
  labId,
  collectionDate,
}: Props) {
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const heading =
    locale === "es"
      ? collectionDate
        ? `Resultados del ${collectionDate}`
        : "Tu nueva analitica"
      : collectionDate
        ? `Results from ${collectionDate}`
        : "Your new panel";

  const lede =
    locale === "es"
      ? "Confirma tu contexto y te entregamos la interpretacion. Esto solo toma un momento."
      : "Confirm your context and we'll deliver your interpretation. This only takes a moment.";

  async function onConfirm(versionId: string, transient: TransientContext) {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch(`/api/lab-results/${labId}/context`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          contextVersionId: versionId,
          transientContext: transient,
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        throw new Error(e.error || `HTTP ${res.status}`);
      }
      router.push(`/${locale}/labs`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to confirm");
      setSubmitting(false);
    }
  }

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1100px]">
          <motion.div variants={fadeUp}>
            <EditorialMasthead issue={locale === "es" ? "Contexto" : "Context"} />
          </motion.div>

          <motion.section variants={fadeUp} className="mt-10 md:mt-16">
            <p
              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
            >
              {locale === "es" ? "§ Confirma contexto" : "§ Confirm context"}
            </p>
            <h1
              className={`mt-4 ${FONT_CLASS.cormorant} text-[48px] font-medium leading-[0.95] tracking-[-1px] text-[#1d1b18] md:text-[80px] md:tracking-[-3px]`}
            >
              {heading}
            </h1>
            <p className="mt-4 max-w-[60ch] text-[15px] leading-[1.55] text-[#5b554f]">
              {lede}
            </p>
          </motion.section>

          <motion.div variants={fadeUp} className="mt-10">
            <PatientContextGate
              profileLocale={profileLocale}
              userSex={userSex}
              submitting={submitting}
              onConfirm={onConfirm}
            />
          </motion.div>

          {error && (
            <p
              role="alert"
              className="mt-6 rounded-md border border-[#b04040]/30 bg-[#fef8f2] p-3 text-[13px] text-[#b04040]"
            >
              {error}
            </p>
          )}
        </div>
      </div>
    </DashboardChrome>
  );
}
