import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET() {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const userId = user.id;

    const [profile, labResults, biomarkerValues, wearableData, actionSteps, chatMessages, bookedTests, patientContextVersions, patientContextDraft] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).single().then(r => r.data),
      supabase.from("lab_results").select("*").eq("user_id", userId).order("created_at").then(r => r.data ?? []),
      supabase.from("biomarker_values").select("*, lab_results!inner(user_id)").eq("lab_results.user_id", userId).then(r => r.data ?? []),
      supabase.from("wearable_data").select("*").eq("user_id", userId).order("date").then(r => r.data ?? []),
      supabase.from("action_steps").select("*").eq("user_id", userId).then(r => r.data ?? []),
      supabase.from("chat_messages").select("*").eq("user_id", userId).order("created_at").then(r => r.data ?? []),
      supabase.from("booked_tests").select("*").eq("user_id", userId).then(r => r.data ?? []),
      supabase.from("patient_context_versions").select("*").eq("user_id", userId).order("version_number").then(r => r.data ?? []),
      supabase.from("patient_context_drafts").select("*").eq("user_id", userId).maybeSingle().then(r => r.data),
    ]);

    // Kit cycles are user-visible via RLS; lab_messages is deny-all (raw HL7,
    // service-role only) but its user-linked rows ARE this user's personal
    // data, so the export must include them — read via the admin client
    // scoped to the user's own cycle ids. Both tables are pre-F2-tolerant:
    // a missing-table error (42P01) degrades to empty lists.
    let testCycles: unknown[] = [];
    let labMessages: unknown[] = [];
    {
      const { data, error } = await supabase
        .from("test_cycles")
        .select("*")
        .eq("user_id", userId)
        .order("seq");
      if (!error && data) testCycles = data;
      const cycleIds = (data ?? []).map((c: { id: string }) => c.id);
      const admin = createAdminClient();
      if (admin && cycleIds.length > 0) {
        const { data: msgs, error: msgErr } = await admin
          .from("lab_messages")
          .select("id, cycle_id, direction, msg_type, message_control_id, status, created_at, raw")
          .in("cycle_id", cycleIds)
          .order("created_at");
        if (!msgErr && msgs) labMessages = msgs;
      }
    }

    const exportData = {
      exported_at: new Date().toISOString(),
      user: { id: userId, email: user.email },
      profile,
      lab_results: labResults,
      biomarker_values: biomarkerValues.map(({ lab_results: _, ...rest }) => rest),
      wearable_data: wearableData,
      action_steps: actionSteps,
      chat_messages: chatMessages,
      booked_tests: bookedTests,
      test_cycles: testCycles,
      lab_messages: labMessages,
      patient_context_versions: patientContextVersions,
      patient_context_draft: patientContextDraft,
    };

    return new Response(JSON.stringify(exportData, null, 2), {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="eva-health-export-${new Date().toISOString().split("T")[0]}.json"`,
      },
    });
  } catch {
    return NextResponse.json({ error: "Export failed" }, { status: 500 });
  }
}
