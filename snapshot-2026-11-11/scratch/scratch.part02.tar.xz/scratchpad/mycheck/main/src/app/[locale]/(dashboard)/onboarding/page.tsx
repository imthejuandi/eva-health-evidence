"use client";

import { useState, type ReactNode } from "react";
import { useParams, useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { createClient } from "@/lib/supabase/client";
import {
  europeanToIso,
  formatEuropeanInput,
} from "@/lib/biomarkers/date-format";
import {
  DashboardChrome,
  EditorialMasthead,
  PrimaryPill,
  GhostLink,
} from "@/components/dashboard";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

type HealthLevel = "beginner" | "familiar" | "optimizer";

interface ProfileData {
  first_name: string;
  last_name: string;
  date_of_birth: string;
  sex: "male" | "female" | "";
  height_cm: string;
  weight_kg: string;
  health_knowledge: HealthLevel | "";
}

const STEP_LABELS: Record<number, { en: string; es: string }> = {
  0: { en: "Welcome", es: "Bienvenida" },
  1: { en: "Identity", es: "Identidad" },
  2: { en: "Knowledge", es: "Saber" },
  3: { en: "Begin", es: "Empieza" },
};

const ROMAN = ["I", "II", "III", "IV"];

/* ──────────────────────────────────────────────────────────────────────
 * ChapterTrack — serif numeral progress strip along a hairline rule.
 * Replaces the four pill-dots from the previous version.
 * ────────────────────────────────────────────────────────────────────── */
function ChapterTrack({
  step,
  locale,
}: {
  step: number;
  locale: string;
}) {
  return (
    <ol className="grid grid-cols-4 border-y border-[#1d1b18]/15">
      {ROMAN.map((num, i) => {
        const label = STEP_LABELS[i]?.[locale === "es" ? "es" : "en"] ?? "";
        const isDone = i < step;
        const isActive = i === step;
        const colour = isDone ? "#3a665e" : isActive ? "#97472c" : "#8a7f76";
        return (
          <li
            key={num}
            className="relative flex flex-col items-start gap-1 px-3 py-4 md:px-5"
            style={{
              borderRight:
                i < ROMAN.length - 1 ? "1px solid rgba(29,27,24,0.10)" : "none",
            }}
          >
            <p
              className={`${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.6px] md:text-[10px]`}
              style={{ color: colour }}
            >
              § {num}
            </p>
            <p
              className={`${FONT_CLASS.cormorant} text-[18px] font-medium leading-tight md:text-[22px] ${
                isActive ? "italic" : ""
              }`}
              style={{ color: colour }}
            >
              {label}
            </p>
            {isActive && (
              <span
                aria-hidden
                className="absolute inset-x-0 bottom-0 h-[2px] origin-left bg-[#97472c] [animation:onboardPulse_1.4s_ease-in-out_infinite]"
              />
            )}
          </li>
        );
      })}
      <style jsx>{`
        @keyframes onboardPulse {
          0%,
          100% {
            transform: scaleX(0.4);
            opacity: 0.6;
          }
          50% {
            transform: scaleX(1);
            opacity: 1;
          }
        }
      `}</style>
    </ol>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * SectionHeader — kicker + Cormorant title with optional italic accent.
 * ────────────────────────────────────────────────────────────────────── */
function SectionHeader({
  kicker,
  title,
  accent,
  subtitle,
}: {
  kicker: string;
  title: string;
  accent?: string;
  subtitle?: string;
}) {
  return (
    <header className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className="inline-block h-px w-8 bg-[#1d1b18]/25 md:w-12"
        />
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]`}
        >
          {kicker}
        </p>
      </div>
      <h2
        className={`${FONT_CLASS.cormorant} text-[40px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[56px] md:tracking-[-1px]`}
        style={{ textWrap: "balance" } as React.CSSProperties}
      >
        {title}{" "}
        {accent && <span className="italic text-[#97472c]">{accent}</span>}
      </h2>
      {subtitle && (
        <p
          className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#8a7f76] md:text-[15px]`}
        >
          {subtitle}
        </p>
      )}
    </header>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * HairlineField — label above + hairline-underline serif input.
 * Mirrors the pattern used on /profile.
 * ────────────────────────────────────────────────────────────────────── */
function HairlineField({
  label,
  required,
  helper,
  error,
  children,
}: {
  label: string;
  required?: boolean;
  helper?: string;
  error?: string | null;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span
        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
      >
        {label}
        {required && <span className="ml-1 text-[#97472c]">*</span>}
      </span>
      {children}
      {error ? (
        <span
          className={`${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
        >
          {error}
        </span>
      ) : helper ? (
        <span
          className={`${FONT_CLASS.manrope} text-[12px] italic text-[#8a7f76]`}
        >
          {helper}
        </span>
      ) : null}
    </label>
  );
}

const hairlineInputClass = `w-full border-b border-[#1d1b18]/20 bg-transparent py-2 ${FONT_CLASS.cormorant} text-[20px] text-[#1d1b18] outline-none transition-colors placeholder:italic placeholder:text-[#8a7f76]/60 focus:border-[#97472c] md:text-[22px]`;

/* ──────────────────────────────────────────────────────────────────────
 * SegmentedChooser — N-card editorial chooser. Each card has an
 * italic Cormorant label, optional helper line, and a ✓ / ○ marker.
 * ────────────────────────────────────────────────────────────────────── */
function SegmentedChooser<T extends string>({
  value,
  options,
  onChange,
  cols = 3,
}: {
  value: T | "";
  options: { key: T; label: string; helper?: string }[];
  onChange: (key: T) => void;
  cols?: 2 | 3;
}) {
  const gridCls =
    cols === 2 ? "sm:grid-cols-2" : "sm:grid-cols-2 md:grid-cols-3";
  return (
    <div className={`grid gap-3 ${gridCls} md:gap-4`}>
      {options.map((opt) => {
        const active = value === opt.key;
        return (
          <button
            key={opt.key}
            type="button"
            onClick={() => onChange(opt.key)}
            className={`group relative flex h-full min-h-[110px] flex-col items-start justify-between rounded-[14px] border p-4 text-left transition-all md:p-5 ${
              active
                ? "border-[#97472c] bg-[rgba(151,71,44,0.05)]"
                : "border-[#1d1b18]/12 bg-[#fef8f2]/60 hover:border-[#1d1b18]/30"
            }`}
          >
            <span
              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] ${
                active ? "text-[#97472c]" : "text-[#8a7f76]"
              }`}
            >
              {active ? "✓" : "○"}
            </span>
            <p
              className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic leading-tight md:text-[22px] ${
                active ? "text-[#97472c]" : "text-[#1d1b18]"
              }`}
            >
              {opt.label}
            </p>
            {opt.helper && (
              <p
                className={`${FONT_CLASS.manrope} text-[11px] leading-[1.45] text-[#8a7f76]`}
              >
                {opt.helper}
              </p>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * Per-card signature motifs. Each tells a different story so the three
 * cards stop reading as the same template thrice.
 *  · KitMotif      — a quartet of marks on a hairline timeline (4 ×/yr)
 *  · UploadMotif   — paper sheet with extracted data lines
 *  · PanelMotif    — a tall biomarker bar field for the deep one-shot
 * ────────────────────────────────────────────────────────────────────── */
function KitMotif({ colour }: { colour: string }) {
  return (
    <svg width="96" height="44" viewBox="0 0 96 44" fill="none" aria-hidden>
      <line
        x1="8"
        y1="22"
        x2="88"
        y2="22"
        stroke={colour}
        strokeOpacity={0.22}
        strokeWidth="1"
        strokeDasharray="2 4"
      />
      {[0, 1, 2, 3].map((i) => (
        <g key={i} transform={`translate(${8 + i * 26}, 0)`}>
          <circle cx="0" cy="22" r={i === 0 ? 4 : 3} fill={colour} fillOpacity={0.85 - i * 0.18} />
          <line x1="0" y1="28" x2="0" y2="38" stroke={colour} strokeOpacity={0.32} strokeWidth="1" strokeLinecap="round" />
        </g>
      ))}
    </svg>
  );
}

function UploadMotif({ colour }: { colour: string }) {
  return (
    <svg width="64" height="52" viewBox="0 0 64 52" fill="none" aria-hidden>
      <path
        d="M8 4 L40 4 L54 18 L54 48 L8 48 Z"
        stroke={colour}
        strokeOpacity={0.55}
        strokeWidth="1"
        fill={colour}
        fillOpacity={0.05}
      />
      <path d="M40 4 L40 18 L54 18" stroke={colour} strokeOpacity={0.55} strokeWidth="1" fill="none" />
      <line x1="14" y1="28" x2="36" y2="28" stroke={colour} strokeOpacity={0.45} strokeWidth="1" strokeLinecap="round" />
      <line x1="14" y1="34" x2="46" y2="34" stroke={colour} strokeOpacity={0.65} strokeWidth="1" strokeLinecap="round" />
      <line x1="14" y1="40" x2="42" y2="40" stroke={colour} strokeOpacity={0.4} strokeWidth="1" strokeLinecap="round" />
    </svg>
  );
}

function PanelMotif({ colour }: { colour: string }) {
  const bars = [9, 16, 12, 24, 19, 30, 26, 34];
  return (
    <svg width="104" height="44" viewBox="0 0 104 44" fill="none" aria-hidden>
      {bars.map((h, i) => (
        <rect
          key={i}
          x={i * 13}
          y={40 - h}
          width="7"
          height={h}
          rx="1.2"
          fill={colour}
          fillOpacity={0.22 + i * 0.07}
        />
      ))}
      <line x1="0" y1="40" x2="104" y2="40" stroke={colour} strokeOpacity={0.25} strokeWidth="0.75" />
    </svg>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * BentoEntryCard — double-bezel editorial card for the Entry Path step.
 * Outer cream shell with a hairline ring sits around an inner core that
 * carries an accent-tinted top panel (signature motif + chapter numeral),
 * an eyebrow pill kicker, a serif title with italic accent, a value tag
 * (price / cadence / depth), body copy, and a button-in-button arrow chip.
 * Hover lifts the whole card with a slow ease-out-expo curve and slides
 * the chip diagonally for haptic tension.
 * ────────────────────────────────────────────────────────────────────── */
function BentoEntryCard({
  index,
  kicker,
  title,
  accent,
  body,
  cta,
  valueTag,
  motif,
  accentColour,
  onClick,
  disabled,
}: {
  index: number;
  kicker: string;
  title: string;
  accent: string;
  body: string;
  cta: string;
  valueTag: string;
  motif: ReactNode;
  accentColour: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  const num = String(index).padStart(2, "0");
  return (
    <motion.button
      type="button"
      variants={fadeUp}
      onClick={onClick}
      disabled={disabled}
      className="group relative flex h-full min-h-[420px] flex-col rounded-[28px] p-1.5 text-left transition-[transform,box-shadow] duration-700 ease-[cubic-bezier(0.32,0.72,0,1)] hover:-translate-y-1 hover:shadow-[0_30px_80px_-30px_rgba(151,71,44,0.32)] disabled:cursor-not-allowed disabled:opacity-60"
      style={{
        backgroundColor: "rgba(254,248,242,0.45)",
        boxShadow: "inset 0 0 0 1px rgba(29,27,24,0.07)",
      }}
    >
      {/* Inner core — concentric radius (28 - 6 = 22) */}
      <div
        className="relative flex flex-1 flex-col overflow-hidden rounded-[22px] bg-[#fef8f2]"
        style={{ boxShadow: "inset 0 1px 0 0 rgba(255,255,255,0.7)" }}
      >
        {/* Signature top panel */}
        <div
          className="relative h-[128px] overflow-hidden"
          style={{
            background: `radial-gradient(120% 100% at 0% 100%, ${accentColour}1A 0%, ${accentColour}08 45%, transparent 75%)`,
          }}
        >
          {/* Bottom hairline */}
          <div
            className="absolute inset-x-7 bottom-0 h-px"
            style={{ backgroundColor: `${accentColour}30` }}
          />
          {/* Chapter numeral, top-right */}
          <span
            aria-hidden
            className={`absolute right-6 top-4 select-none ${FONT_CLASS.cormorant} text-[56px] font-medium italic leading-none tabular-nums transition-colors duration-700 ease-[cubic-bezier(0.32,0.72,0,1)]`}
            style={{ color: `${accentColour}55` }}
          >
            {num}
          </span>
          {/* Per-card motif, bottom-left */}
          <div className="absolute bottom-5 left-7 transition-transform duration-700 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:-translate-y-0.5">
            {motif}
          </div>
        </div>

        {/* Body */}
        <div className="flex flex-1 flex-col p-6 md:p-7">
          {/* Eyebrow pill kicker */}
          <span
            className={`inline-flex w-max items-center gap-2 rounded-full px-2.5 py-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.8px]`}
            style={{
              backgroundColor: `${accentColour}14`,
              color: accentColour,
            }}
          >
            <span
              aria-hidden
              className="h-[3px] w-[3px] rounded-full"
              style={{ backgroundColor: accentColour }}
            />
            {kicker}
          </span>

          {/* Title */}
          <h3
            className={`mt-4 max-w-[15ch] ${FONT_CLASS.cormorant} text-[28px] font-medium leading-[1.04] tracking-[-0.4px] text-[#1d1b18] md:text-[32px]`}
            style={{ textWrap: "balance" } as React.CSSProperties}
          >
            {title}{" "}
            <span className="italic" style={{ color: accentColour }}>
              {accent}
            </span>
          </h3>

          {/* Value tag — cadence / price / depth in mono */}
          <p
            className={`mt-3 ${FONT_CLASS.dmMono} text-[10.5px] font-semibold uppercase tracking-[1.6px] text-[#4c463f]`}
          >
            {valueTag}
          </p>

          {/* Body copy */}
          <p
            className={`mt-3 ${FONT_CLASS.manrope} text-[13.5px] leading-[1.65] text-[#4c463f]`}
            style={{ textWrap: "pretty" } as React.CSSProperties}
          >
            {body}
          </p>

          {/* Button-in-button CTA */}
          <div className="mt-auto flex items-center gap-3 pt-7">
            <span
              className={`${FONT_CLASS.manrope} text-[12.5px] font-semibold tracking-[-0.1px] text-[#1d1b18]`}
            >
              {cta}
            </span>
            <span
              aria-hidden
              className="ml-auto flex h-8 w-8 items-center justify-center rounded-full transition-[transform,background-color] duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:translate-x-1 group-hover:-translate-y-px"
              style={{ backgroundColor: `${accentColour}1A` }}
            >
              <svg
                className="h-3 w-3"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.75}
                stroke={accentColour}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                />
              </svg>
            </span>
          </div>
        </div>
      </div>
    </motion.button>
  );
}

export default function OnboardingPage() {
  const params = useParams();
  const router = useRouter();
  const locale = (params.locale as string) ?? "es";
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<ProfileData>({
    first_name: "",
    last_name: "",
    date_of_birth: "",
    sex: "",
    height_cm: "",
    weight_kg: "",
    health_knowledge: "",
  });
  const [dobError, setDobError] = useState<string | null>(null);

  const t =
    locale === "es"
      ? {
          // Hero / step 0
          kickerWelcome: "§ La bienvenida",
          welcomeTitle: "Conoce tu cuerpo.",
          welcomeAccent: "Adueñate de tu salud.",
          welcomeLede:
            "EVA reinterpreta tus marcadores frente a rangos optimos para la longevidad — convierte datos clinicos en una lectura clara, personal y accionable.",
          welcomeCta: "Empezar",
          // Step 1 — Identity
          kickerIdentity: "§ I — Identidad",
          identityTitle: "Cuentanos",
          identityAccent: "lo basico.",
          identitySubtitle:
            "Solo lo necesario para personalizar tus rangos optimos. Lo guardamos cifrado.",
          firstName: "Nombre",
          lastName: "Apellido",
          dob: "Fecha de nacimiento",
          dobHelper: "DD/MM/AAAA",
          dobInvalid: "Fecha invalida. Usa DD/MM/AAAA.",
          sex: "Sexo biologico",
          sexNote:
            "Necesario para los rangos estratificados por sexo.",
          sexMale: "Masculino",
          sexFemale: "Femenino",
          height: "Altura (cm)",
          heightHelper: "Opcional",
          weight: "Peso (kg)",
          weightHelper: "Opcional",
          // Step 2 — Knowledge
          kickerKnowledge: "§ II — Saber",
          knowledgeTitle: "Cuanto",
          knowledgeAccent: "ya sabes.",
          knowledgeSubtitle:
            "Lo que elijas aqui decide como te explicamos cada biomarcador, resumen y accion. La interpretacion clinica no cambia, solo el lenguaje. Puedes cambiar de nivel cuando quieras desde tu perfil.",
          beginner: "Empezando",
          beginnerHelper:
            "Para quien empieza. Como una clase de bachillerato, sin jerga y con analogias.",
          familiar: "Algo familiar",
          familiarHelper:
            "Para quien lee su propio analisis. Nombres reales con un 'por que importa' breve.",
          optimizer: "Optimizador",
          optimizerHelper:
            "Para clinicos y biohackers serios. Terminologia medica, mecanismo y magnitud.",
          knowledgeNote:
            "El diagnostico es el mismo en los tres niveles, solo cambia como te lo contamos. Podras ajustarlo en Perfil cuando quieras.",
          // Step 3 — Path
          kickerPath: "§ III — Empezar",
          pathTitle: "Por donde",
          pathAccent: "empiezas.",
          pathSubtitle:
            "Eliges tu primer paso. Puedes cambiar de opinion cuando quieras.",
          pathKitKicker: "Trimestral · En casa",
          pathKitTitle: "Pide tu",
          pathKitAccent: "kit EVA.",
          pathKitBody:
            "Recogida de 500µL sin aguja. Te llega en 3-5 dias y vuelve al laboratorio en sobre prepagado. Cuatro paneles al ano, suscripcion trimestral.",
          pathKitCta: "Reservar mi kit",
          pathKitValue: "4 paneles · al ano",
          pathUploadKicker: "Gratis · Datos existentes",
          pathUploadTitle: "Sube un",
          pathUploadAccent: "informe.",
          pathUploadBody:
            "Sin coste. PDF, JPG, PNG o HEIC. Lo extraemos y lo interpretamos contra los rangos optimos EVA para que veas que esta dentro y que no.",
          pathUploadCta: "Subir analisis gratis",
          pathUploadValue: "0 € · siempre gratis",
          pathFullKicker: "Pago unico · En clinica",
          pathFullTitle: "Reserva el",
          pathFullAccent: "panel completo.",
          pathFullBody:
            "Mas de 80 marcadores en una sola extraccion. Una foto profunda y unica de tu salud, sin compromiso de suscripcion.",
          pathFullCta: "Reservar panel completo",
          pathFullValue: "80+ marcadores · pago unico",
          // Nav
          back: "Atras",
          next: "Siguiente",
          required: "Obligatorio",
        }
      : {
          kickerWelcome: "§ The welcome",
          welcomeTitle: "Know your body.",
          welcomeAccent: "Own your health.",
          welcomeLede:
            "EVA reinterprets your markers against longevity-optimal ranges — turning clinical data into a clear, personal, actionable reading.",
          welcomeCta: "Begin",
          kickerIdentity: "§ I — Identity",
          identityTitle: "Tell us",
          identityAccent: "the basics.",
          identitySubtitle:
            "Just what we need to personalise your optimal ranges. Stored encrypted.",
          firstName: "First name",
          lastName: "Last name",
          dob: "Date of birth",
          dobHelper: "DD/MM/YYYY",
          dobInvalid: "Invalid date. Use DD/MM/YYYY.",
          sex: "Biological sex",
          sexNote: "Required for sex-stratified ranges.",
          sexMale: "Male",
          sexFemale: "Female",
          height: "Height (cm)",
          heightHelper: "Optional",
          weight: "Weight (kg)",
          weightHelper: "Optional",
          kickerKnowledge: "§ II — Knowledge",
          knowledgeTitle: "How much",
          knowledgeAccent: "you already know.",
          knowledgeSubtitle:
            "What you pick here decides how every biomarker, summary and action step is written for you. The clinical reading itself doesn't change, only the wording. You can switch tier any time from your profile.",
          beginner: "Just starting",
          beginnerHelper:
            "For first-timers. Written like a high-school class. Plain English, no jargon, everyday analogies.",
          familiar: "Somewhat familiar",
          familiarHelper:
            "For confident readers. Standard biomarker names with a one-line 'why it matters' alongside each value.",
          optimizer: "Deep optimizer",
          optimizerHelper:
            "For clinicians and deep biohackers. Full medical terminology, mechanism, pathway and magnitude.",
          knowledgeNote:
            "Same diagnosis at every level; only the explanation shifts. You can change it in Profile whenever you want.",
          kickerPath: "§ III — Begin",
          pathTitle: "Where you'll",
          pathAccent: "start.",
          pathSubtitle:
            "Pick your first move. You can change your mind any time.",
          pathKitKicker: "Quarterly · At home",
          pathKitTitle: "Order your",
          pathKitAccent: "EVA kit.",
          pathKitBody:
            "Needle-free 500µL collection. Arrives in 3-5 days and ships back in a prepaid envelope. Four panels a year on a quarterly subscription.",
          pathKitCta: "Reserve my kit",
          pathKitValue: "4 panels · per year",
          pathUploadKicker: "Free · Existing data",
          pathUploadTitle: "Upload a",
          pathUploadAccent: "report.",
          pathUploadBody:
            "No cost. PDF, JPG, PNG or HEIC. We extract it and read it against EVA's optimal ranges so you can see what's in range and what isn't.",
          pathUploadCta: "Upload labs free",
          pathUploadValue: "€0 · always free",
          pathFullKicker: "One-time · In clinic",
          pathFullTitle: "Book the",
          pathFullAccent: "full panel.",
          pathFullBody:
            "Over 80 markers in a single draw. A deep, one-shot snapshot of your health — no subscription commitment.",
          pathFullCta: "Book full panel",
          pathFullValue: "80+ markers · one-time",
          back: "Back",
          next: "Next",
          required: "Required",
        };

  function canAdvance(): boolean {
    if (step === 1) {
      // Date must not just be non-empty — it must actually parse. Without
      // this guard, half-typed dates like "12/13" let users march all the
      // way to the entry-path step and then bounce silently when their
      // selection tries to persist an invalid date.
      return (
        profile.first_name.trim() !== "" &&
        profile.last_name.trim() !== "" &&
        europeanToIso(profile.date_of_birth) !== null &&
        profile.sex !== ""
      );
    }
    if (step === 2) {
      return profile.health_knowledge !== "";
    }
    return true;
  }

  type Entry =
    | { kind: "redirect"; path: string }
    | { kind: "checkout"; plan: "quarterly" | "full_panel" };

  async function handleEntry(entry: Entry) {
    const iso = europeanToIso(profile.date_of_birth);
    if (!iso) {
      setDobError(t.dobInvalid);
      setStep(1);
      return;
    }
    setDobError(null);
    setSaving(true);
    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setSaving(false);
        return;
      }
      const firstName = profile.first_name.trim();
      const lastName = profile.last_name.trim();
      const fullName = [firstName, lastName].filter(Boolean).join(" ");
      await supabase.from("profiles").upsert({
        id: user.id,
        first_name: firstName,
        last_name: lastName,
        full_name: fullName,
        date_of_birth: iso,
        sex: profile.sex,
        height_cm: profile.height_cm ? parseFloat(profile.height_cm) : null,
        weight_kg: profile.weight_kg ? parseFloat(profile.weight_kg) : null,
        health_knowledge: profile.health_knowledge,
        onboarding_completed: true,
      });

      // Welcome email on first onboarding completion (covers password,
      // magic-link and OAuth signups alike). Fire-and-forget: the server
      // route is idempotent via profiles.welcome_email_sent_at.
      fetch("/api/emails/welcome", { method: "POST" }).catch(() => {});

      if (entry.kind === "checkout") {
        // Persist onboarding before leaving for Stripe so the user lands
        // back inside the chromed dashboard regardless of payment outcome.
        const res = await fetch("/api/stripe/checkout", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ locale, plan: entry.plan }),
        });
        const data = await res.json();
        if (data.url) {
          window.location.assign(data.url);
          return;
        }
        setSaving(false);
        return;
      }

      router.push(`/${locale}${entry.path}`);
    } catch {
      setSaving(false);
    }
  }

  return (
    <DashboardChrome animate={false}>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1100px]">
          {/* Masthead */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <EditorialMasthead
              issue={locale === "es" ? "Bienvenida" : "Onboarding"}
            />
          </motion.div>

          {/* Chapter progress strip */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mt-8 md:mt-10"
          >
            <ChapterTrack step={step} locale={locale} />
          </motion.div>

          {/* Step content — re-mounts on each step change so motion variants
              fire fresh entrances. */}
          <motion.div
            key={step}
            variants={staggerTight}
            initial="hidden"
            animate="show"
            className="mt-12 md:mt-16"
          >
            {/* ── Step 0 — Welcome ── */}
            {step === 0 && (
              <motion.section
                variants={fadeUp}
                className="grid gap-10 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-9">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                  >
                    {t.kickerWelcome}
                  </p>
                  <h1
                    className={`mt-4 ${FONT_CLASS.cormorant} text-[64px] font-medium leading-[0.92] tracking-[-1.5px] text-[#1d1b18] md:text-[112px] md:tracking-[-4px]`}
                    style={{ textWrap: "balance" } as React.CSSProperties}
                  >
                    {t.welcomeTitle}{" "}
                    <span className="italic text-[#97472c]">
                      {t.welcomeAccent}
                    </span>
                  </h1>
                  <p
                    className={`mt-7 max-w-[52ch] ${FONT_CLASS.manrope} text-[16px] leading-[1.65] text-[#4c463f] md:text-[17px]`}
                    style={{ textWrap: "pretty" } as React.CSSProperties}
                  >
                    {t.welcomeLede}
                  </p>
                  <div className="mt-9">
                    <PrimaryPill onClick={() => setStep(1)}>
                      {t.welcomeCta}
                    </PrimaryPill>
                  </div>
                </div>
              </motion.section>
            )}

            {/* ── Step 1 — Identity ── */}
            {step === 1 && (
              <motion.section
                variants={fadeUp}
                className="grid gap-6 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-4 md:pt-2">
                  <SectionHeader
                    kicker={t.kickerIdentity}
                    title={t.identityTitle}
                    accent={t.identityAccent}
                    subtitle={t.identitySubtitle}
                  />
                </div>
                <div className="md:col-span-8 md:pt-2">
                  <div className="grid gap-5 md:grid-cols-2 md:gap-6">
                    <HairlineField label={t.firstName} required>
                      <input
                        type="text"
                        required
                        value={profile.first_name}
                        onChange={(e) =>
                          setProfile({ ...profile, first_name: e.target.value })
                        }
                        className={hairlineInputClass}
                      />
                    </HairlineField>
                    <HairlineField label={t.lastName} required>
                      <input
                        type="text"
                        required
                        value={profile.last_name}
                        onChange={(e) =>
                          setProfile({ ...profile, last_name: e.target.value })
                        }
                        className={hairlineInputClass}
                      />
                    </HairlineField>
                    <HairlineField
                      label={t.dob}
                      required
                      helper={t.dobHelper}
                      error={dobError}
                    >
                      <input
                        type="text"
                        inputMode="numeric"
                        required
                        placeholder="DD/MM/YYYY"
                        pattern="\d{2}/\d{2}/\d{4}"
                        maxLength={10}
                        value={profile.date_of_birth}
                        onChange={(e) => {
                          setProfile({
                            ...profile,
                            date_of_birth: formatEuropeanInput(e.target.value),
                          });
                          if (dobError) setDobError(null);
                        }}
                        className={hairlineInputClass}
                      />
                    </HairlineField>
                    <div className="md:col-span-2">
                      <p
                        className={`mb-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                      >
                        {t.sex}
                        <span className="ml-1 text-[#97472c]">*</span>
                      </p>
                      <div className="grid grid-cols-2 gap-3 md:gap-4">
                        {(["male", "female"] as const).map((s) => {
                          const active = profile.sex === s;
                          return (
                            <button
                              key={s}
                              type="button"
                              onClick={() => setProfile({ ...profile, sex: s })}
                              className={`group relative flex h-full min-h-[80px] items-center justify-between rounded-[14px] border p-4 text-left transition-all md:p-5 ${
                                active
                                  ? "border-[#97472c] bg-[rgba(151,71,44,0.05)]"
                                  : "border-[#1d1b18]/12 bg-[#fef8f2]/60 hover:border-[#1d1b18]/30"
                              }`}
                            >
                              <p
                                className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic md:text-[22px] ${
                                  active ? "text-[#97472c]" : "text-[#1d1b18]"
                                }`}
                              >
                                {s === "male" ? t.sexMale : t.sexFemale}
                              </p>
                              <span
                                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] ${
                                  active ? "text-[#97472c]" : "text-[#8a7f76]"
                                }`}
                              >
                                {active ? "✓" : "○"}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                      <p
                        className={`mt-3 ${FONT_CLASS.manrope} text-[12px] italic text-[#8a7f76]`}
                      >
                        {t.sexNote}
                      </p>
                    </div>
                    <HairlineField label={t.height} helper={t.heightHelper}>
                      <input
                        type="number"
                        value={profile.height_cm}
                        onChange={(e) =>
                          setProfile({ ...profile, height_cm: e.target.value })
                        }
                        className={hairlineInputClass}
                      />
                    </HairlineField>
                    <HairlineField label={t.weight} helper={t.weightHelper}>
                      <input
                        type="number"
                        value={profile.weight_kg}
                        onChange={(e) =>
                          setProfile({ ...profile, weight_kg: e.target.value })
                        }
                        className={hairlineInputClass}
                      />
                    </HairlineField>
                  </div>
                  <div className="mt-9 flex flex-wrap items-center gap-x-6 gap-y-3">
                    <PrimaryPill
                      onClick={() => canAdvance() && setStep(2)}
                      disabled={!canAdvance()}
                    >
                      {t.next}
                    </PrimaryPill>
                    <GhostLink onClick={() => setStep(0)}>← {t.back}</GhostLink>
                  </div>
                </div>
              </motion.section>
            )}

            {/* ── Step 2 — Knowledge ── */}
            {step === 2 && (
              <motion.section
                variants={fadeUp}
                className="grid gap-6 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-4 md:pt-2">
                  <SectionHeader
                    kicker={t.kickerKnowledge}
                    title={t.knowledgeTitle}
                    accent={t.knowledgeAccent}
                    subtitle={t.knowledgeSubtitle}
                  />
                </div>
                <div className="md:col-span-8 md:pt-2">
                  <SegmentedChooser
                    value={profile.health_knowledge}
                    onChange={(key) =>
                      setProfile({ ...profile, health_knowledge: key })
                    }
                    options={[
                      {
                        key: "beginner",
                        label: t.beginner,
                        helper: t.beginnerHelper,
                      },
                      {
                        key: "familiar",
                        label: t.familiar,
                        helper: t.familiarHelper,
                      },
                      {
                        key: "optimizer",
                        label: t.optimizer,
                        helper: t.optimizerHelper,
                      },
                    ]}
                  />
                  <p
                    className={`mt-5 max-w-[58ch] ${FONT_CLASS.manrope} text-[13px] leading-[1.6] italic text-[#8a7f76]`}
                  >
                    {t.knowledgeNote}
                  </p>
                  <div className="mt-9 flex flex-wrap items-center gap-x-6 gap-y-3">
                    <PrimaryPill
                      onClick={() => canAdvance() && setStep(3)}
                      disabled={!canAdvance()}
                    >
                      {t.next}
                    </PrimaryPill>
                    <GhostLink onClick={() => setStep(1)}>← {t.back}</GhostLink>
                  </div>
                </div>
              </motion.section>
            )}

            {/* ── Step 3 — Begin (Entry path bento) ── */}
            {step === 3 && (
              <motion.section
                variants={fadeUp}
                className="grid gap-6 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-12">
                  <SectionHeader
                    kicker={t.kickerPath}
                    title={t.pathTitle}
                    accent={t.pathAccent}
                    subtitle={t.pathSubtitle}
                  />
                </div>
                <motion.div
                  variants={staggerTight}
                  initial="hidden"
                  animate="show"
                  className="grid gap-4 md:col-span-12 md:grid-cols-3 md:gap-5"
                >
                  <BentoEntryCard
                    index={1}
                    kicker={t.pathKitKicker}
                    title={t.pathKitTitle}
                    accent={t.pathKitAccent}
                    body={t.pathKitBody}
                    cta={t.pathKitCta}
                    valueTag={t.pathKitValue}
                    motif={<KitMotif colour="#97472c" />}
                    accentColour="#97472c"
                    onClick={() => handleEntry({ kind: "checkout", plan: "quarterly" })}
                    disabled={saving}
                  />
                  <BentoEntryCard
                    index={2}
                    kicker={t.pathUploadKicker}
                    title={t.pathUploadTitle}
                    accent={t.pathUploadAccent}
                    body={t.pathUploadBody}
                    cta={t.pathUploadCta}
                    valueTag={t.pathUploadValue}
                    motif={<UploadMotif colour="#3a665e" />}
                    accentColour="#3a665e"
                    onClick={() => handleEntry({ kind: "redirect", path: "/upload" })}
                    disabled={saving}
                  />
                  <BentoEntryCard
                    index={3}
                    kicker={t.pathFullKicker}
                    title={t.pathFullTitle}
                    accent={t.pathFullAccent}
                    body={t.pathFullBody}
                    cta={t.pathFullCta}
                    valueTag={t.pathFullValue}
                    motif={<PanelMotif colour="#c49332" />}
                    accentColour="#c49332"
                    onClick={() => handleEntry({ kind: "checkout", plan: "full_panel" })}
                    disabled={saving}
                  />
                </motion.div>
                <div className="md:col-span-12">
                  <GhostLink onClick={() => setStep(2)}>← {t.back}</GhostLink>
                </div>
              </motion.section>
            )}
          </motion.div>

          <div className="h-12 md:h-20" />
        </div>
      </div>
    </DashboardChrome>
  );
}
