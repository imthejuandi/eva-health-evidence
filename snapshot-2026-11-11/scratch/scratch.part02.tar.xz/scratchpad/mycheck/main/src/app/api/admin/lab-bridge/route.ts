import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";
import { runBridgePassFromEnv } from "@/lib/lab-bridge/run";
import { SupabaseBridgeStore } from "@/lib/lab-bridge/store";
import { replayInboundOru, type InboundMessageRow } from "@/lib/lab-bridge/replay";

/**
 * POST /api/admin/lab-bridge — the desk's two hands on the bridge.
 *
 *   (no body, or { action: "run" })
 *     One bridge pass by hand: same code as the cron. Useful during training
 *     with ECH and as a manual kick between cron ticks.
 *
 *   { action: "replay", labMessageId, force? }
 *     Re-run the recording of an ORU from its archived copy in
 *     lab_messages.raw — no SFTP, no ACK (see src/lib/lab-bridge/replay.ts).
 *     `force` records a new lab result on a cycle that already has one.
 *
 * Every call is audited.
 */
export const maxDuration = 120;

const BodySchema = z
  .object({
    action: z.enum(["run", "replay"]).default("run"),
    labMessageId: z.string().uuid().optional(),
    force: z.boolean().optional(),
  })
  .strict();

export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const rawBody = await req.text();
  let body: unknown = {};
  if (rawBody.trim()) {
    try {
      body = JSON.parse(rawBody);
    } catch {
      return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
    }
  }
  const parsed = BodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request", details: parsed.error.issues }, { status: 400 });
  }

  if (parsed.data.action === "replay") {
    const { labMessageId, force } = parsed.data;
    if (!labMessageId) return NextResponse.json({ error: "labMessageId is required for a replay" }, { status: 400 });
    const client = createAdminClient();
    if (!client) return NextResponse.json({ error: "Service role not configured" }, { status: 503 });

    const result = await replayInboundOru(
      {
        store: new SupabaseBridgeStore(client),
        now: new Date(),
        loadInbound: async (id): Promise<InboundMessageRow | null> => {
          const { data, error } = await client
            .from("lab_messages")
            .select("id, msg_type, message_control_id, raw, status, cycle_id")
            .eq("id", id)
            .eq("direction", "in")
            .maybeSingle();
          if (error) throw error;
          if (!data) return null;
          const r = data as Record<string, unknown>;
          return {
            id: String(r.id),
            msgType: String(r.msg_type),
            messageControlId: String(r.message_control_id),
            raw: String(r.raw),
            status: String(r.status),
            cycleId: (r.cycle_id as string | null) ?? null,
          };
        },
      },
      labMessageId,
      { force: force === true },
    );
    await logAdminAction({
      actor: admin,
      action: "lab_bridge_replay",
      targetId: labMessageId,
      detail: result.ok
        ? { cycleId: result.cycleId, labResultId: result.labResultId, processed: result.processed, unmatched: result.unmatched, force: force === true }
        : { code: result.code, message: result.message, force: force === true },
    });
    if (!result.ok) {
      const status = result.code === "NOT_FOUND" ? 404 : 409;
      return NextResponse.json({ error: result.message, code: result.code }, { status });
    }
    return NextResponse.json(result);
  }

  // The run log shows this label on the desk: who pressed the button, not a UUID.
  const result = await runBridgePassFromEnv(`admin:${admin.email ?? admin.id}`);
  await logAdminAction({
    actor: admin,
    action: "lab_bridge_run",
    detail: result.ok
      ? { uploaded: result.summary.uploaded, acks: result.summary.acks, orus: result.summary.orus, retried: result.summary.retried ?? [], errors: result.summary.errors.length, ms: result.summary.ms }
      : { error: result.error },
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status });
  return NextResponse.json(result.summary);
}
