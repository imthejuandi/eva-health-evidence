"use client";

import { useEffect, useState } from "react";
import { useParams, usePathname } from "next/navigation";
import Link from "next/link";
import { MobileDock } from "@/components/dashboard";
import { SkipLink } from "@/components/marketing/SkipLink";
import { createClient } from "@/lib/supabase/client";

type Plan = "free" | "quarterly" | "full_panel";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const navItems = [
  { key: "home", path: "/dashboard", iconD: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-4 0a1 1 0 01-1-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 01-1 1" },
  { key: "labs", path: "/labs", iconD: "M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" },
  { key: "eva-ai", path: "/eva-ai", iconD: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.455 2.456L21.75 6l-1.036.259a3.375 3.375 0 00-2.455 2.456z" },
  { key: "book", path: "/book", iconD: "M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5" },
  { key: "profile", path: "/profile", iconD: "M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" },
];

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const params = useParams();
  const pathname = usePathname();
  const locale = (params.locale as string) ?? "es";
  const [plan, setPlan] = useState<Plan>("free");
  const [firstName, setFirstName] = useState<string>("");

  // Onboarding is a focused flow: hide the persistent chrome (sidebar +
  // mobile dock) and let it own the full viewport. Once onboarding is
  // complete the user lands back inside the chromed dashboard.
  const isOnboarding = pathname.startsWith(`/${locale}/onboarding`);

  // Resolve the user's current plan once on layout mount. Layouts in App
  // Router persist across sibling-route navigation, so this runs once per
  // dashboard session — not on every page change. The pill colour matches
  // the plan: jade for quarterly, terra for full panel, neutral for free.
  useEffect(() => {
    let cancelled = false;
    async function loadPlan() {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user || cancelled) return;
      const [{ data: profile }, { data: tests }] = await Promise.all([
        supabase
          .from("profiles")
          .select("subscription_status, first_name")
          .eq("id", user.id)
          .single(),
        supabase
          .from("booked_tests")
          .select("panel_type, status")
          .eq("user_id", user.id)
          .eq("panel_type", "full")
          .in("status", ["scheduled", "kit_sent", "sample_received", "processing"])
          .limit(1),
      ]);
      if (cancelled) return;
      if (profile?.first_name) setFirstName(profile.first_name);
      if (profile?.subscription_status === "active") {
        setPlan("quarterly");
      } else if (tests && tests.length > 0) {
        setPlan("full_panel");
      } else {
        setPlan("free");
      }
    }
    loadPlan();
    return () => {
      cancelled = true;
    };
  }, []);

  const t =
    locale === "es"
      ? {
          home: "Inicio",
          labs: "Analisis",
          "eva-ai": "EVA AI",
          book: "Reservar",
          profile: "Perfil",
          planFree: "Gratis",
          planQuarterly: "Trimestral",
          planFull: "Panel completo",
          planKicker: "§ Plan",
          indexKicker: "§ Indice",
        }
      : {
          home: "Home",
          labs: "Labs",
          "eva-ai": "EVA AI",
          book: "Book",
          profile: "Profile",
          planFree: "Free",
          planQuarterly: "Quarterly",
          planFull: "Full panel",
          planKicker: "§ Plan",
          indexKicker: "§ Index",
        };

  const planLabel =
    plan === "quarterly" ? t.planQuarterly : plan === "full_panel" ? t.planFull : t.planFree;
  const monogram = firstName ? firstName.trim().charAt(0).toUpperCase() : "◇";
  const planClass =
    plan === "quarterly"
      ? "bg-[rgba(58,102,94,0.10)] text-[#3a665e]"
      : plan === "full_panel"
        ? "bg-[rgba(151,71,44,0.10)] text-[#97472c]"
        : "bg-[rgba(29,27,24,0.06)] text-[#8a7f76]";

  function isActive(path: string) {
    const stripped = pathname.replace(`/${locale}`, "");
    if (path === "/dashboard") return stripped === "/dashboard" || stripped === "/";
    return stripped.startsWith(path);
  }

  if (isOnboarding) {
    return (
      <div className="min-h-screen bg-[#fef8f2]">
        <SkipLink />
        <main id="main" tabIndex={-1}>
          {children}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fef8f2]">
      <SkipLink />
      {/* ─── DESKTOP SIDEBAR (≥1024px) ───
          Collapses to a 72px icon rail and expands to 268px on hover or
          keyboard focus. Morph runs on the iOS drawer curve
          (cubic-bezier(0.32, 0.72, 0, 1)) at 500ms — slower than typical
          UI motion, but the sidebar is a rare interaction so the extra
          settle reads as elegant rather than sluggish. The expanded
          panel floats over content so there's no reflow. */}
      <aside
        className="group fixed inset-y-0 left-0 z-40 hidden w-[72px] flex-col overflow-hidden border-r border-[rgba(29,27,24,0.06)] transition-[width,box-shadow] duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] hover:w-[268px] hover:shadow-[0_30px_70px_-30px_rgba(151,71,44,0.32)] focus-within:w-[268px] focus-within:shadow-[0_30px_70px_-30px_rgba(151,71,44,0.32)] lg:flex"
        style={{
          background:
            "linear-gradient(180deg, #fef8f2 0%, rgba(254,248,242,0.96) 100%)",
        }}
      >
        {/* Logo */}
        <div className="flex h-[80px] items-center px-6 transition-[padding] duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:px-7 group-focus-within:px-7">
          <Link
            href={`/${locale}/dashboard`}
            className="flex items-baseline gap-2 whitespace-nowrap font-[family-name:var(--font-logo)] text-[24px] font-light lowercase tracking-[-0.5px] text-[#1d1b18]"
          >
            eva
            {/* Tiny terra dot reveals before "Health" — a small typographic flourish */}
            <span
              aria-hidden
              className="h-1 w-1 -translate-x-1 rounded-full bg-[#97472c] opacity-0 transition-[opacity,transform] duration-300 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:translate-x-0 group-hover:opacity-80 group-focus-within:translate-x-0 group-focus-within:opacity-80"
            />
            <span className="bg-gradient-to-r from-[#97472c] to-[#d97b5c] bg-clip-text font-[family-name:var(--font-manrope)] text-[16px] font-bold uppercase tracking-[1.4px] text-transparent opacity-0 transition-opacity duration-200 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:opacity-100 group-focus-within:opacity-100">
              Health
            </span>
          </Link>
        </div>

        {/* Hairline rule under logo — only really visible expanded */}
        <div aria-hidden className="mx-5 h-px bg-[#1d1b18]/[0.06]" />

        {/* Editorial kicker — nav as "§ Index" */}
        <p className="mt-5 px-7 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#97472c]/55 opacity-0 transition-opacity duration-200 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:opacity-100 group-focus-within:opacity-100">
          {t.indexKicker}
        </p>

        {/* Nav items */}
        <nav className="mt-3 flex flex-1 flex-col gap-0.5 px-3">
          {navItems.map((item, i) => {
            const active = isActive(item.path);
            const num = String(i + 1).padStart(2, "0");
            return (
              <Link
                key={item.key}
                href={`/${locale}${item.path}`}
                className={`group/item relative flex items-center gap-3.5 whitespace-nowrap rounded-[12px] px-3 py-2.5 transition-[background-color,padding,transform] duration-300 ease-[cubic-bezier(0.32,0.72,0,1)] active:scale-[0.97] group-hover:px-4 group-focus-within:px-4 ${
                  active
                    ? "bg-[rgba(151,71,44,0.05)]"
                    : "hover:bg-[rgba(29,27,24,0.025)]"
                }`}
              >
                {/* Active marker — typesetter's bullet in the left margin */}
                {active && (
                  <span
                    aria-hidden
                    className="absolute -left-[3px] top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-[#97472c]"
                    style={{ boxShadow: "0 0 0 3px #fef8f2" }}
                  />
                )}
                {/* Icon — refined stroke, lighter weight */}
                <svg
                  className={`h-[18px] w-[18px] shrink-0 transition-colors duration-200 ${
                    active
                      ? "text-[#97472c]"
                      : "text-[#8a7f76] group-hover/item:text-[#1d1b18]"
                  }`}
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={active ? 1.6 : 1.25}
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d={item.iconD} />
                </svg>
                {/* Label */}
                <span
                  className={`flex-1 font-[family-name:var(--font-manrope)] text-[13.5px] tracking-[-0.1px] opacity-0 transition-[opacity,color] duration-200 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:opacity-100 group-focus-within:opacity-100 ${
                    active
                      ? "font-semibold text-[#1d1b18]"
                      : "font-medium text-[#4c463f]"
                  }`}
                >
                  {t[item.key as keyof typeof t]}
                </span>
                {/* Mono numeral — chapter rhythm */}
                <span
                  aria-hidden
                  className={`font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold tabular-nums tracking-[1.4px] opacity-0 transition-[opacity,color] duration-200 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:opacity-100 group-focus-within:opacity-100 ${
                    active ? "text-[#97472c]" : "text-[#1d1b18]/30"
                  }`}
                >
                  {num}
                </span>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-3 pb-5 pt-4">
          <p className="mb-2.5 px-3 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#97472c]/50 opacity-0 transition-opacity duration-200 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:opacity-100 group-focus-within:opacity-100">
            {t.planKicker}
          </p>
          <div className="flex items-center gap-3 whitespace-nowrap rounded-[12px] px-2 py-2 transition-[padding] duration-300 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:px-3 group-focus-within:px-3">
            {/* Serif monogram — square cream tile with hairline ring */}
            <div
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] bg-[#fef8f2]"
              style={{ boxShadow: "inset 0 0 0 1px rgba(151,71,44,0.18)" }}
            >
              <span className="font-[family-name:var(--font-cormorant)] text-[18px] font-medium italic leading-none text-[#97472c]">
                {monogram}
              </span>
            </div>
            <div className="min-w-0 flex-1 opacity-0 transition-opacity duration-200 ease-[cubic-bezier(0.32,0.72,0,1)] group-hover:opacity-100 group-focus-within:opacity-100">
              <span
                className={`inline-block rounded-full px-2 py-0.5 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1px] ${planClass}`}
              >
                {planLabel}
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* ─── MAIN CONTENT ─── */}
      {/* Padding matches the COLLAPSED sidebar width (72px). When the
          sidebar expands on hover it floats over the content rather
          than pushing it, so the orb stays anchored. */}
      <main id="main" tabIndex={-1} className="pb-24 lg:pb-0 lg:pl-[72px]">
        {children}
      </main>

      {/* ─── MOBILE DOCK (<1024px) ─── */}
      {/* Floating pill-shaped dock, lifted from the investors deck
          mobile pattern. Uses the same isActive helper as the desktop
          sidebar so the two stay in sync. */}
      <MobileDock
        items={navItems.map((item) => ({
          key: item.key,
          href: `/${locale}${item.path}`,
          label: t[item.key as keyof typeof t],
          iconD: item.iconD,
          active: isActive(item.path),
        }))}
      />
    </div>
  );
}
