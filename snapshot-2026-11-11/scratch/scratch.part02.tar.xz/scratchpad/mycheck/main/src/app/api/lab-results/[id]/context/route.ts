import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { completeCycleForLabResult } from "@/lib/cycles/close-cycle";
import { labNoteTexts } from "@/lib/lab-results/notes";
import { snapshotToLab } from "@/lib/patient-context";
import { TransientContextSchema } from "@/lib/patient-context/schema";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";

/**
 * POST /api/lab-results/[id]/context
 *
 * Stamp a patient_context_versions row + per-draw transient context
 * onto a lab. Behaviour branches on the lab's current status:
 *
 *   * pending_context  — webhook-ingested lab waiting for the user to
 *                        confirm context. Transition to "processing",
 *                        run the AI pipeline, transition to "ready",
 *                        send the results-ready email.
 *
 *   * any other status — upload-flow lab. Just stamp the context. The
 *                        existing /confirm route runs the pipeline once
 *                        the user finishes biomarker review.
 *
 * Body: { contextVersionId: uuid, transientContext: TransientContext }
 */

const BodySchema = z.object({
  contextVersionId: z.string().uuid(),
  transientContext: TransientContextSchema,
});

export async function POST(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> },
) {
  const { id: labResultId } = await ctx.params;
  if (!/^[0-9a-fA-F-]{36}$/.test(labResultId)) {
    return NextResponse.json({ error: "Invalid lab id" }, { status: 400 });
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const parsed = BodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid body", details: parsed.error.issues },
      { status: 400 },
    );
  }
  const { contextVersionId, transientContext } = parsed.data;

  // Lab must exist and belong to the caller.
  const { data: lab, error: labError } = await supabase
    .from("lab_results")
    .select("id, user_id, status, collection_date, lab_notes")
    .eq("id", labResultId)
    .eq("user_id", user.id)
    .single();
  if (labError || !lab) {
    return NextResponse.json({ error: "Lab not found" }, { status: 404 });
  }

  // Version must exist and belong to the caller. RLS enforces this too,
  // but a clearer 404 here saves the client a guess.
  const { data: version, error: versionError } = await supabase
    .from("patient_context_versions")
    .select("id, user_id")
    .eq("id", contextVersionId)
    .eq("user_id", user.id)
    .maybeSingle();
  if (versionError || !version) {
    return NextResponse.json(
      { error: "Patient context version not found" },
      { status: 404 },
    );
  }

  try {
    await snapshotToLab(labResultId, contextVersionId, transientContext);
  } catch (err) {
    console.error("[lab.context.POST] snapshot failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Snapshot failed" },
      { status: 500 },
    );
  }

  // Upload-flow labs land in "processing" by default and rely on
  // /confirm to drive the AI pipeline. Nothing more to do here.
  if (lab.status !== "pending_context") {
    return NextResponse.json({ ok: true, ran_pipeline: false });
  }

  // Webhook-flow lab. Transition to "processing", run the pipeline,
  // transition to "ready" (or "error"), then fire the email.
  const { error: toProcessingError } = await supabase
    .from("lab_results")
    .update({ status: "processing" })
    .eq("id", labResultId);
  if (toProcessingError) {
    console.error("[lab.context.POST] transition to processing failed:", toProcessingError);
    return NextResponse.json(
      { error: "Failed to start processing" },
      { status: 500 },
    );
  }

  try {
    const profile = await getUserProfile(user.id);
    if (!profile) {
      throw new Error("Profile not found");
    }
    // Webhook flow: biomarker_values were already inserted by the
    // webhook handler when the lab arrived. processLabResults is
    // idempotent enough only if biomarker rows aren't re-inserted —
    // we skip it here and go straight to the AI step. (For webhook
    // labs we re-derive the processed biomarker list from the rows.)
    const { data: bvRows, error: bvError } = await supabase
      .from("biomarker_values")
      .select("biomarker_key, biomarker_name, value, unit, zone, optimal_low, optimal_high")
      .eq("lab_result_id", labResultId);
    if (bvError) throw new Error(`Failed to load biomarker_values: ${bvError.message}`);
    if (!bvRows || bvRows.length === 0) {
      throw new Error("No biomarker values to interpret on this lab");
    }

    const processed = bvRows.map((b) => ({
      biomarkerKey: b.biomarker_key,
      name: b.biomarker_name ?? b.biomarker_key,
      value: b.value as number,
      unit: b.unit ?? "",
      zone: (b.zone ?? "unclassified") as
        | "critical_low"
        | "below_optimal"
        | "optimal"
        | "above_optimal"
        | "critical_high"
        | "unclassified",
      zoneLabel: "",
      zoneLabel_es: "",
      optimalLow: (b.optimal_low ?? null) as number | null,
      optimalHigh: (b.optimal_high ?? null) as number | null,
      matchConfidence: "exact" as const,
    }));

    const wearable = await getWearableData(user.id, 30);
    await generateSummary(
      user.id,
      labResultId,
      processed,
      wearable.length > 0 ? wearable : null,
      profile,
      undefined,
      { labNotes: labNoteTexts((lab as { lab_notes?: unknown }).lab_notes) },
    );

    const { error: readyError } = await supabase
      .from("lab_results")
      .update({ status: "ready" })
      .eq("id", labResultId);
    if (readyError) {
      console.error("[lab.context.POST] set ready failed:", readyError);
    } else {
      // The cycle that produced this result is done (results_final →
      // completed). The patient's session cannot write test_cycles (RLS
      // grants SELECT only), so this goes through the service-role client;
      // the bridge pass and the daily scheduler sweep any miss.
      const admin = createAdminClient();
      if (admin) {
        await completeCycleForLabResult(admin, labResultId).catch((err) =>
          console.error("[lab.context.POST] cycle completion failed:", err),
        );
      }
    }

    // Now (and only now) tell the user their results are ready.
    const firstName = profile.full_name?.split(" ")[0] ?? "";
    const locale = profile.locale ?? "en";
    sendEmail(
      user.email ?? "",
      "results-ready",
      {
        firstName,
        biomarkerCount: processed.length,
        biologicalAge: null,
        baDelta: null,
        longevityScore: null,
        locale,
      },
      locale,
    ).catch((err) => console.error("[lab.context.POST] email failed:", err));

    return NextResponse.json({ ok: true, ran_pipeline: true });
  } catch (err) {
    console.error("[lab.context.POST] pipeline failed:", err);
    await supabase
      .from("lab_results")
      .update({ status: "error" })
      .eq("id", labResultId);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Pipeline failed" },
      { status: 500 },
    );
  }
}

