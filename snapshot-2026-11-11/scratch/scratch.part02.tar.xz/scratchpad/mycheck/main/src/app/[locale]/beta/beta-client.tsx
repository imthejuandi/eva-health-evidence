"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion, type Variants } from "framer-motion";
import {
  ChapterMarker,
  HeroHeadline,
  LedeItalic,
} from "@/components/marketing/editorial";

const DISPLAY = "font-[family-name:var(--font-sentient)]";
const MONO = "font-[family-name:var(--font-dm-mono)]";
const BODY = "font-[family-name:var(--font-manrope)]";

/* Reveal curve borrowed from the marketing landing. Slow ease-out so
 * the editorial composition settles in like a printed page being laid
 * down, not a dashboard widget popping in. */
const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.85, ease: [0.16, 1, 0.3, 1] },
  },
};

const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } },
};

/* Roman numeral for the current year. Keeps the pre-launch dispatch
 * dated in the same monumental style as the marketing chapter
 * markers without baking a hardcoded year that goes stale on Jan 1. */
function yearRoman(year: number): string {
  const map: Array<[number, string]> = [
    [1000, "M"], [900, "CM"], [500, "D"], [400, "CD"],
    [100, "C"], [90, "XC"], [50, "L"], [40, "XL"],
    [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"],
  ];
  let n = year;
  let out = "";
  for (const [val, sym] of map) {
    while (n >= val) {
      out += sym;
      n -= val;
    }
  }
  return out;
}

type WaitlistStatus = "idle" | "sending" | "subscribed" | "duplicate" | "error";
type AccessStatus = "idle" | "checking" | "wrong" | "ok";

export function BetaClient({ locale }: { locale: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const next = searchParams.get("next") ?? "";

  const [email, setEmail] = useState("");
  const [waitlistStatus, setWaitlistStatus] = useState<WaitlistStatus>("idle");
  const emailRef = useRef<HTMLInputElement>(null);

  const [password, setPassword] = useState("");
  const [accessStatus, setAccessStatus] = useState<AccessStatus>("idle");
  const passwordRef = useRef<HTMLInputElement>(null);

  /* Roman year is stable per render but the year itself changes
   * across midnight on Jan 1. Computing in a memo keeps the SSR
   * + client output identical for the lifetime of the page view. */
  const dispatchCaption = useMemo(() => {
    const now = new Date();
    return `PRIVATE BETA · ${yearRoman(now.getFullYear())}`;
  }, []);

  // Inline copy. Mirrors the existing marketing voice: chapter markers,
  // monumental Sentient headlines, italic lede, mono utility lines.
  // Spanish strings avoid accents (the existing app strips them in
  // user-facing copy for layout consistency).
  const t =
    locale === "es"
      ? {
          chapter: "§ 00 · DISPATCHO",
          heroLeading: "EVA esta en",
          heroAccent: "beta privada.",
          lede:
            "Estamos abriendo el acceso por oleadas. Manda tu email y te avisamos cuando te toque. Si ya eres tester, usa tu codigo abajo.",
          waitlistLabel: "§ Lista de espera",
          waitlistTitle: "Une tu",
          waitlistAccent: "lectura.",
          waitlistBody:
            "Avisamos a los testers en orden de inscripcion. Sin spam, una sola nota cuando se libera tu plaza.",
          emailPlaceholder: "tu@email.com",
          waitlistCta: "Apuntarme",
          waitlistSending: "Enviando...",
          waitlistSubscribed: "Anotado. Te escribimos pronto.",
          waitlistDuplicate: "Ya estabas. Te escribimos cuando toque.",
          waitlistError: "Algo fallo. Intentalo otra vez.",
          accessLabel: "§ Ya tienes acceso",
          accessTitle: "Soy",
          accessAccent: "tester.",
          accessBody:
            "Introduce el codigo que recibiste y entras directo al sitio.",
          passwordPlaceholder: "Codigo de acceso",
          accessCta: "Entrar",
          accessChecking: "Comprobando...",
          accessWrong: "Codigo incorrecto.",
          dispatchPrefix: "Madrid",
          year: "MMXXVI",
        }
      : {
          chapter: "§ 00 · DISPATCH",
          heroLeading: "EVA is in",
          heroAccent: "private beta.",
          lede:
            "We're opening access in waves. Drop your email and we'll write when your seat is ready. If you already have a tester code, use it below.",
          waitlistLabel: "§ The waitlist",
          waitlistTitle: "Join the",
          waitlistAccent: "reading.",
          waitlistBody:
            "We notify testers in the order they sign up. No newsletter, no spam, one short note when your seat opens.",
          emailPlaceholder: "you@email.com",
          waitlistCta: "Add me to the list",
          waitlistSending: "Sending...",
          waitlistSubscribed: "On the list. We'll be in touch.",
          waitlistDuplicate: "You're already on the list. We'll be in touch.",
          waitlistError: "Something went wrong. Try again.",
          accessLabel: "§ Already in",
          accessTitle: "I'm a",
          accessAccent: "beta tester.",
          accessBody:
            "Enter the access code we sent you and you'll head straight in.",
          passwordPlaceholder: "Access code",
          accessCta: "Enter",
          accessChecking: "Checking...",
          accessWrong: "Wrong code.",
          dispatchPrefix: "Madrid",
          year: "MMXXVI",
        };

  async function handleWaitlist(e: React.FormEvent) {
    e.preventDefault();
    if (!email || waitlistStatus === "sending") return;
    setWaitlistStatus("sending");
    try {
      const res = await fetch("/api/beta-subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, locale }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setWaitlistStatus("error");
        return;
      }
      setWaitlistStatus(data.status === "duplicate" ? "duplicate" : "subscribed");
      if (data.status !== "duplicate") setEmail("");
    } catch {
      setWaitlistStatus("error");
    }
  }

  async function handleAccess(e: React.FormEvent) {
    e.preventDefault();
    if (!password || accessStatus === "checking") return;
    setAccessStatus("checking");
    try {
      const res = await fetch("/api/beta-access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, next }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setAccessStatus("wrong");
        return;
      }
      setAccessStatus("ok");
      // Hard navigation so the new cookie is sent on the next request.
      const dest = data.next && typeof data.next === "string" ? data.next : `/${locale}`;
      window.location.assign(dest);
    } catch {
      setAccessStatus("wrong");
    }
  }

  // Subtle UX nicety: clear the wrong-code error as soon as the user
  // edits the field, so the message doesn't shame them while they're
  // still typing.
  useEffect(() => {
    if (accessStatus === "wrong" && password.length === 0) setAccessStatus("idle");
  }, [password, accessStatus]);

  // One-shot autofocus into the email field on desktop. Empty deps so
  // it fires exactly once on mount — never on re-renders triggered by
  // typing into the password field below. (Previously this lived in a
  // nested `FocusEmailOnDesktop` component declared inside BetaClient,
  // which gave it a new identity on every render: each keystroke in
  // the password input would unmount + remount the helper and steal
  // focus back to email mid-typing.)
  useEffect(() => {
    if (!window.matchMedia("(min-width: 768px)").matches) return;
    emailRef.current?.focus({ preventScroll: true });
  }, []);

  return (
    <main className="relative min-h-dvh w-full">
      {/* Atmospheric wash. Two soft radial pools — terra in the upper
          left, faint jade in the lower right — give the cream surface
          a printed-page warmth without leaning on a heavy gradient.
          Pointer-events-none so it never blocks the form. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          backgroundImage:
            "radial-gradient(60% 50% at 18% 14%, rgba(151,71,44,0.10), transparent 60%), radial-gradient(55% 45% at 82% 88%, rgba(58,102,94,0.08), transparent 65%)",
        }}
      />
      {/* Hairline rule strip — top edge marker that visually separates
          the brand row from the open page below it. Same trick the
          marketing landing uses to anchor the masthead. */}
      <div
        aria-hidden
        className="absolute inset-x-0 top-[78px] -z-10 h-px bg-[#1d1b18]/10 md:top-[88px]"
      />

      {/* ── Top bar — wordmark left, dispatch caption right ───────── */}
      <header className="flex items-center justify-between px-5 pt-6 md:px-12 md:pt-8">
        <p className={`${DISPLAY} text-[20px] font-medium tracking-[-0.5px] text-[#1d1b18] md:text-[22px]`}>
          EVA
          <span className="italic text-[#97472c]">.</span>
        </p>
        <p className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#8a7f76] md:text-[11px] md:tracking-[2.4px]`}>
          {dispatchCaption}
        </p>
      </header>

      <motion.div
        variants={stagger}
        initial="hidden"
        animate="show"
        className="mx-auto flex max-w-[1200px] flex-col px-5 pb-20 pt-16 md:px-12 md:pb-32 md:pt-24"
      >
        {/* ── Chapter marker ──────────────────────────────────────── */}
        <motion.div variants={fadeUp}>
          <ChapterMarker color="terra">{t.chapter}</ChapterMarker>
        </motion.div>

        {/* ── Hero headline ───────────────────────────────────────── */}
        <motion.div variants={fadeUp} className="mt-5 md:mt-7">
          <HeroHeadline>
            {t.heroLeading}
            <br />
            <span className="italic text-[#97472c]">{t.heroAccent}</span>
          </HeroHeadline>
        </motion.div>

        {/* ── Editorial lede ──────────────────────────────────────── */}
        <motion.div variants={fadeUp} className="mt-7 max-w-[58ch] md:mt-10">
          <LedeItalic>{t.lede}</LedeItalic>
        </motion.div>

        {/* ── Primary action — waitlist ───────────────────────────── */}
        <motion.section
          variants={fadeUp}
          className="mt-12 md:mt-16"
          aria-labelledby="waitlist-heading"
        >
          <p
            className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]`}
          >
            {t.waitlistLabel}
          </p>
          <h2
            id="waitlist-heading"
            className={`mt-3 ${DISPLAY} text-[36px] font-medium leading-[0.95] tracking-[-0.8px] text-[#1d1b18] md:text-[56px] md:tracking-[-2px]`}
            style={{ textWrap: "balance" }}
          >
            {t.waitlistTitle}{" "}
            <span className="italic text-[#97472c]">{t.waitlistAccent}</span>
          </h2>
          <p
            className={`mt-4 max-w-[52ch] ${BODY} text-[14px] leading-[1.65] text-[#4c463f] md:text-[16px]`}
            style={{ textWrap: "pretty" }}
          >
            {t.waitlistBody}
          </p>

          <form
            onSubmit={handleWaitlist}
            className="mt-7 flex w-full max-w-[560px] flex-col gap-3 sm:flex-row"
            noValidate
          >
            <label className="relative flex-1">
              <span className="sr-only">{t.emailPlaceholder}</span>
              <input
                ref={emailRef}
                type="email"
                required
                autoComplete="email"
                inputMode="email"
                placeholder={t.emailPlaceholder}
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (waitlistStatus !== "sending") setWaitlistStatus("idle");
                }}
                className={`${BODY} h-[52px] w-full rounded-full border border-[#1d1b18]/15 bg-white px-5 text-[14px] text-[#1d1b18] outline-none transition-colors placeholder:text-[#8a7f76] focus:border-[#97472c] focus:ring-2 focus:ring-[#97472c]/20`}
              />
            </label>
            <button
              type="submit"
              disabled={waitlistStatus === "sending"}
              className={`${BODY} group inline-flex h-[52px] shrink-0 items-center justify-center gap-3 rounded-full bg-[#1d1b18] px-7 text-[13px] font-semibold text-[#fef8f2] transition-transform hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60`}
              style={{ boxShadow: "0 18px 50px -12px rgba(151,71,44,0.45)" }}
            >
              {waitlistStatus === "sending"
                ? t.waitlistSending
                : t.waitlistCta}
              <span
                aria-hidden
                className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
              >
                <svg
                  className="h-3 w-3"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                  />
                </svg>
              </span>
            </button>
          </form>

          {/* Waitlist status line. Reserves a row of height so the
              layout doesn't jump when the message flips in. */}
          <div className="mt-3 min-h-[20px]">
            {waitlistStatus === "subscribed" && (
              <p className={`${BODY} text-[13px] italic text-[#3a665e]`}>
                {t.waitlistSubscribed}
              </p>
            )}
            {waitlistStatus === "duplicate" && (
              <p className={`${BODY} text-[13px] italic text-[#8a7f76]`}>
                {t.waitlistDuplicate}
              </p>
            )}
            {waitlistStatus === "error" && (
              <p className={`${BODY} text-[13px] italic text-[#b04040]`}>
                {t.waitlistError}
              </p>
            )}
          </div>
        </motion.section>

        {/* ── Hairline divider ────────────────────────────────────── */}
        <motion.div
          variants={fadeUp}
          aria-hidden
          className="my-12 h-px w-full max-w-[560px] bg-[#1d1b18]/12 md:my-16"
        />

        {/* ── Secondary action — beta tester password ────────────── */}
        <motion.section
          variants={fadeUp}
          className="max-w-[560px]"
          aria-labelledby="access-heading"
        >
          <p
            className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#3a665e] md:text-[11px] md:tracking-[2.4px]`}
          >
            {t.accessLabel}
          </p>
          <h3
            id="access-heading"
            className={`mt-2 ${DISPLAY} text-[24px] font-medium leading-[1.1] tracking-[-0.5px] text-[#1d1b18] md:text-[30px] md:tracking-[-1px]`}
          >
            {t.accessTitle}{" "}
            <span className="italic text-[#3a665e]">{t.accessAccent}</span>
          </h3>
          <p
            className={`mt-2 ${BODY} text-[13px] leading-[1.6] text-[#4c463f] md:text-[14px]`}
          >
            {t.accessBody}
          </p>

          <form onSubmit={handleAccess} className="mt-5 flex flex-col gap-3 sm:flex-row" noValidate>
            <label className="relative flex-1">
              <span className="sr-only">{t.passwordPlaceholder}</span>
              <input
                ref={passwordRef}
                type="password"
                required
                autoComplete="current-password"
                placeholder={t.passwordPlaceholder}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`${MONO} h-[48px] w-full rounded-full border bg-transparent px-5 text-[13px] tracking-[1px] text-[#1d1b18] outline-none transition-colors placeholder:tracking-[1.5px] placeholder:text-[#8a7f76] ${
                  accessStatus === "wrong"
                    ? "border-[#b04040] focus:ring-2 focus:ring-[#b04040]/20"
                    : "border-[#1d1b18]/20 focus:border-[#3a665e] focus:ring-2 focus:ring-[#3a665e]/15"
                }`}
              />
            </label>
            <button
              type="submit"
              disabled={accessStatus === "checking" || accessStatus === "ok"}
              className={`${BODY} inline-flex h-[48px] shrink-0 items-center justify-center gap-2 rounded-full border border-[#1d1b18]/25 bg-transparent px-6 text-[12px] font-semibold uppercase tracking-[1.6px] text-[#1d1b18] transition-colors hover:border-[#1d1b18] disabled:cursor-not-allowed disabled:opacity-60`}
            >
              {accessStatus === "checking"
                ? t.accessChecking
                : t.accessCta}
              <span aria-hidden className="text-[14px] leading-none">→</span>
            </button>
          </form>

          <div className="mt-3 min-h-[20px]">
            {accessStatus === "wrong" && (
              <p className={`${BODY} text-[13px] italic text-[#b04040]`}>
                {t.accessWrong}
              </p>
            )}
          </div>
        </motion.section>

        {/* ── Footer attribution ──────────────────────────────────── */}
        <motion.footer
          variants={fadeUp}
          className="mt-16 flex items-center gap-3 md:mt-24"
        >
          <span aria-hidden className="h-px w-12 bg-[#1d1b18]/25 md:w-16" />
          <p
            className={`${MONO} text-[9.5px] font-semibold uppercase tracking-[2px] text-[#8a7f76] md:text-[10px]`}
          >
            {t.dispatchPrefix} · {t.year}
          </p>
        </motion.footer>
      </motion.div>
    </main>
  );
}
