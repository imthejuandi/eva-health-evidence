"use client";

/**
 * /metodologia — short trust-signal page for the KDM v2.2.1 biological age.
 *
 * This page is the destination of the "¿Cómo se calcula?" link in the
 * dashboard's KDM provenance row (see `dashboard-client.tsx` § VitalsStrip).
 * It's deliberately short (~400 words rendered) and oriented toward
 * non-specialist trust signals: who validated the model, against what,
 * with what numbers, and where to read more.
 *
 * For the deep methodology (the 10-section "completa" document with full
 * citations), see ./completa/page.tsx.
 */

import { useParams } from "next/navigation";
import {
  ChapterMarker,
  SectionHeadline,
  SubHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
  HandDrawnUnderline,
} from "@/components/marketing/editorial";
import { CTAButton } from "@/components/marketing/CTAButton";

export default function MetodologiaPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const es = locale === "es";

  const t = es
    ? {
        ch01: "§ 01 · La pregunta",
        ch02: "§ 02 · La evidencia",
        ch03: "§ 03 · El método",
        ch04: "§ 04 · La transparencia",

        heroTitle: "Cómo medimos tu edad biológica.",
        heroLede:
          "No es una opinión. No es un score genérico. Es una predicción de mortalidad validada en 18.570 personas — con un margen de incertidumbre que reconocemos abiertamente.",

        // § 02 Trust signals
        sigTitle: "Tres números que importan.",
        sigBody:
          "El algoritmo se valida contra mortalidad real, usando un protocolo de validación cruzada (5-fold) que separa los datos de entrenamiento de los de validación.",
        sig1Eye: "HAZARD RATIO",
        sig1Val: "1.29",
        sig1Label: "por desviación estándar",
        sig1Desc:
          "Cada desviación estándar de aceleración de edad biológica corresponde a un 29% más de riesgo relativo de mortalidad. Validación fuera de muestra (5-fold CV); intervalo de confianza 95% [1.20, 1.40].",
        sig2Eye: "C-STATISTIC",
        sig2Val: "0.77",
        sig2Label: "discriminación predictiva",
        sig2Desc:
          "Cuando comparamos dos personas, el modelo identifica correctamente cuál tiene mayor riesgo el 77% del tiempo. La versión Comprehensive (panel extendido) sube a 0.78 con HR/SD 1.49.",
        sig3Eye: "POBLACIÓN",
        sig3Val: "18.570",
        sig3Label: "adultos NHANES",
        sig3Desc:
          "Entrenado en datos del National Health and Nutrition Examination Survey (1999-2018), con seguimiento de mortalidad hasta 2019. Recalibrado para España con 11 de 14 marcadores del panel base.",

        // § 03 Method
        methodTitle: "Klemera-Doubal, recalibrado para España.",
        methodBody:
          "Tu edad biológica se calcula con el método de Klemera-Doubal (2006), un estimador estadístico que combina múltiples biomarcadores en un único número de años. Cada biomarcador contribuye proporcionalmente a lo bien que predice la edad cronológica en la población de referencia.",
        methodBody2:
          "Para el mercado español hemos recalibrado los valores promedio de 11 de 14 marcadores del panel base usando cohortes españolas: PESA (Fernández-Friera 2015), ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja y SEQC. Incluye recalibración por sexo para Creatinina, Ácido Úrico, GGT, HDL, Hemoglobina y Testosterona Total (corregido en mayo de 2026 tras detectar que estos valores no se estaban aplicando). Un español con valores típicos para su edad obtiene una edad biológica cercana a su edad real — no a la media estadounidense.",
        methodCallout:
          "La edad biológica responde a una pregunta diferente que el score de longevidad. La primera te dice cómo envejeces frente a la población; la segunda, qué tan cerca estás de lo óptimo.",

        // § 04 Transparency
        transTitle: "Lo que el modelo sabe — y lo que no.",
        transKnows: "Lo que el modelo capta:",
        transKnowsItems: [
          "Trayectoria de envejecimiento poblacional para 14 biomarcadores clave (riñón, hígado, inflamación, glicación, lípidos, nutrición).",
          "Diferencias entre sexos en 19 marcadores con dimorfismo conocido.",
          "Suplementación de creatina (ajuste automático del valor de creatinina, basado en literatura ISSN 2017).",
          "Cistatina C cuando está disponible, en lugar de la creatinina (marcador renal no afectado por masa muscular).",
        ],
        transLimits: "Lo que el modelo no captura:",
        transLimitsItems: [
          "Variaciones agudas (deshidratación, ejercicio reciente, comida pre-analítica).",
          "Composición corporal (masa muscular vs masa grasa) más allá de la suplementación de creatina.",
          "Medicamentos que afectan biomarcadores (estatinas, ACE inhibidores, levotiroxina).",
          "Genética, epigenética, telómeros — métodos válidos pero complementarios.",
        ],

        ctaTitle: "Lee la metodología completa.",
        ctaBody:
          "El documento completo cubre los datos de entrenamiento, la calibración española, el método matemático, la validación contra mortalidad y nuestras limitaciones, con referencias a literatura primaria.",
        ctaButton: "Ver metodología completa",
      }
    : {
        ch01: "§ 01 · The question",
        ch02: "§ 02 · The evidence",
        ch03: "§ 03 · The method",
        ch04: "§ 04 · Transparency",

        heroTitle: "How we measure your biological age.",
        heroLede:
          "Not an opinion. Not a generic score. A mortality prediction validated in 18,570 people — with an uncertainty margin we acknowledge openly.",

        sigTitle: "Three numbers that matter.",
        sigBody:
          "The algorithm is validated against real mortality using out-of-sample cross-validation (5-fold), so the numbers below reflect performance on held-out data, not the training set.",
        sig1Eye: "HAZARD RATIO",
        sig1Val: "1.29",
        sig1Label: "per standard deviation",
        sig1Desc:
          "Each standard deviation of biological age acceleration corresponds to a 29% higher relative mortality risk. Out-of-sample (5-fold CV); 95% CI [1.20, 1.40].",
        sig2Eye: "C-STATISTIC",
        sig2Val: "0.77",
        sig2Label: "predictive discrimination",
        sig2Desc:
          "When comparing two people, the model correctly identifies which one has higher risk 77% of the time. The Comprehensive version (extended panel) rises to 0.78 with HR/SD 1.49.",
        sig3Eye: "POPULATION",
        sig3Val: "18,570",
        sig3Label: "NHANES adults",
        sig3Desc:
          "Trained on the U.S. National Health and Nutrition Examination Survey (1999-2018), with mortality follow-up through 2019. Recalibrated for Spain on 11 of 14 base-panel markers.",

        methodTitle: "Klemera-Doubal, recalibrated for Spain.",
        methodBody:
          "Your biological age is calculated with the Klemera-Doubal method (2006), a statistical estimator that combines multiple biomarkers into a single number of years. Each biomarker contributes proportionally to how well it predicts chronological age in the reference population.",
        methodBody2:
          "For the Spanish market we recalibrated the population means of 11 of 14 base-panel markers using Spanish cohorts: PESA (Fernández-Friera 2015), ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, and SEQC. Includes per-sex recalibration for Creatinine, Uric Acid, GGT, HDL, Hemoglobin, and Total Testosterone (corrected in May 2026 after detecting these values weren't being applied). A Spanish person with typical values for their age gets a biological age close to their real age — not the U.S. average.",
        methodCallout:
          "Biological age answers a different question than the longevity score. The first tells you how you're aging vs. the population; the second, how close you are to optimal.",

        transTitle: "What the model knows — and what it doesn't.",
        transKnows: "What the model captures:",
        transKnowsItems: [
          "Population aging trajectory for 14 key biomarkers (kidney, liver, inflammation, glycation, lipids, nutrition).",
          "Sex differences across 19 markers with known dimorphism.",
          "Creatine supplementation (automatic creatinine adjustment based on ISSN 2017 literature).",
          "Cystatin C when available, in place of creatinine (kidney marker unaffected by muscle mass).",
        ],
        transLimits: "What the model doesn't capture:",
        transLimitsItems: [
          "Acute variations (dehydration, recent exercise, pre-analytical meals).",
          "Body composition (muscle vs fat mass) beyond creatine supplementation.",
          "Medications affecting biomarkers (statins, ACE inhibitors, levothyroxine).",
          "Genetics, epigenetics, telomeres — valid but complementary methods.",
        ],

        ctaTitle: "Read the full methodology.",
        ctaBody:
          "The full document covers training data, Spanish calibration, the mathematical method, mortality validation, and our limitations, with references to primary literature.",
        ctaButton: "Read the full methodology",
      };

  return (
    <main className="relative bg-[#fef8f2] text-[#1d1b18]">
      {/* ═══════════════════════════════════════════════════════════
       * § 01 — Hero: the question
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ChapterMarker>{t.ch01}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">
          {t.heroTitle.split(" ").slice(0, -2).join(" ")}{" "}
          <span className="relative inline-block">
            {t.heroTitle.split(" ").slice(-2).join(" ")}
            <HandDrawnUnderline />
          </span>
        </SectionHeadline>
        <LedeItalic className="mt-8 md:mt-10 max-w-2xl">{t.heroLede}</LedeItalic>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 02 — Trust signals (3 cards)
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ChapterMarker>{t.ch02}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.sigTitle}</SectionHeadline>
        <BodyProse className="mt-6 max-w-2xl">{t.sigBody}</BodyProse>

        <div className="mt-14 md:mt-20 grid grid-cols-1 md:grid-cols-3 gap-px bg-[#1d1b18]/10 border border-[#1d1b18]/10">
          {[
            { eye: t.sig1Eye, val: t.sig1Val, label: t.sig1Label, desc: t.sig1Desc },
            { eye: t.sig2Eye, val: t.sig2Val, label: t.sig2Label, desc: t.sig2Desc },
            { eye: t.sig3Eye, val: t.sig3Val, label: t.sig3Label, desc: t.sig3Desc },
          ].map((s, i) => (
            <div key={i} className="bg-[#fef8f2] p-8 md:p-10">
              <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
                {s.eye}
              </p>
              <p
                className="mt-4 font-[family-name:var(--font-cormorant)] text-[56px] md:text-[72px] font-medium leading-none text-[#3a665e]"
                style={{ fontVariantNumeric: "tabular-nums" }}
              >
                {s.val}
              </p>
              <p className="mt-2 font-[family-name:var(--font-dm-mono)] text-[11px] uppercase tracking-[1.4px] text-[#4c463f]/70">
                {s.label}
              </p>
              <p className="mt-5 text-[15px] leading-relaxed text-[#4c463f]">
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 03 — Method
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ChapterMarker>{t.ch03}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.methodTitle}</SectionHeadline>
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-7">
            <BodyProse>{t.methodBody}</BodyProse>
            <BodyProse className="mt-6">{t.methodBody2}</BodyProse>
          </div>
          <aside className="lg:col-span-5 lg:pl-8 lg:border-l lg:border-[#1d1b18]/10">
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
              {es ? "Importante" : "Important"}
            </p>
            <LedeItalic className="mt-4">{t.methodCallout}</LedeItalic>
          </aside>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 04 — Transparency
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ChapterMarker>{t.ch04}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.transTitle}</SectionHeadline>

        <div className="mt-12 md:mt-16 grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16">
          <div>
            <SubHeadline className="text-[#3a665e]">{t.transKnows}</SubHeadline>
            <ul className="mt-6 space-y-4">
              {t.transKnowsItems.map((item, i) => (
                <li key={i} className="flex gap-4">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#3a665e]/60 mt-1.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[15px] leading-relaxed text-[#4c463f]">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SubHeadline className="text-[#97472c]">{t.transLimits}</SubHeadline>
            <ul className="mt-6 space-y-4">
              {t.transLimitsItems.map((item, i) => (
                <li key={i} className="flex gap-4">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#97472c]/60 mt-1.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[15px] leading-relaxed text-[#4c463f]">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * CTA — link to deep methodology
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="large">
        <div className="text-center max-w-2xl mx-auto">
          <SectionHeadline>{t.ctaTitle}</SectionHeadline>
          <BodyProse className="mt-6">{t.ctaBody}</BodyProse>
          <div className="mt-10">
            <CTAButton
              variant="primary"
              href={`/${locale}/metodologia/completa`}
            >
              {t.ctaButton}
            </CTAButton>
          </div>
        </div>
      </SectionShell>
    </main>
  );
}
