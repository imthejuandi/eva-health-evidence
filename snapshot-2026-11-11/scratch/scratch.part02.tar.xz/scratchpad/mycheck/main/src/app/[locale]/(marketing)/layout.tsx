import { MarketingNav } from "@/components/marketing/MarketingNav";
import { MarketingFooter } from "@/components/marketing/MarketingFooter";
import { ScrollProgress } from "@/components/marketing/ScrollProgress";
import { CookieConsent } from "@/components/marketing/CookieConsent";
import { SkipLink } from "@/components/marketing/SkipLink";

interface MarketingLayoutProps {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}

export default async function MarketingLayout({
  children,
  params,
}: MarketingLayoutProps) {
  const { locale } = await params;

  return (
    <div className="min-h-dvh w-full bg-eva-surface text-eva-on-surface">
      <SkipLink />
      {/* Marketing display faces — scoped to marketing only.
          Next hoists bare <link> elements into <head>, so these
          become preloads on marketing routes and are absent from the
          dashboard bundle. One Fontshare request loads both faces.
           - Sentient: used by the editorial + bold landing variants
           - Sprat: used by the midnight dark-luxury variant */}
      <link
        rel="stylesheet"
        href="https://api.fontshare.com/v2/css?f[]=sentient@400,500,600,700&f[]=sprat@400,500,600,700&display=swap"
      />
      <ScrollProgress />
      <MarketingNav />
      {/* pt-[100px] gives the sub-pages (how-it-works, science,
          pricing, about, contact, blog, legal/*) their nav-pill
          clearance so their first headings don't collide with the
          floating Dynamic-Island banner. The landing hero wants
          the opposite — its shader + ambient wash should fill the
          very top of the viewport — so it cancels this padding
          locally with `-mt-[100px]` on its own section. That keeps
          the layout simple (one rule for everyone) and puts the
          landing-specific override where it belongs. */}
      <main id="main" tabIndex={-1} className="w-full pt-[100px]">{children}</main>
      <MarketingFooter locale={locale} />
      <CookieConsent />
      <div className="grain-overlay" />
    </div>
  );
}
