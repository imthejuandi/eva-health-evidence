import type { Metadata } from "next";

/**
 * Layout for the pre-launch beta gate. Deliberately minimal: no
 * MarketingNav (we don't want the gated visitor wandering off into
 * /pricing or /science), no MarketingFooter (same), no scroll
 * progress bar (single-screen composition). Just the cream surface,
 * the Sentient + Sprat display faces preloaded from Fontshare, and
 * a soft grain overlay for paper texture.
 */
export const metadata: Metadata = {
  title: "EVA Health — Private beta",
  description:
    "EVA is in private beta. Join the waitlist, or enter the beta password if you have one.",
  robots: { index: false, follow: false },
};

export default function BetaLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="relative min-h-dvh w-full overflow-hidden bg-eva-surface text-eva-on-surface">
      <link
        rel="stylesheet"
        href="https://api.fontshare.com/v2/css?f[]=sentient@400,500,600,700&display=swap"
      />
      {children}
      <div className="grain-overlay pointer-events-none" />
    </div>
  );
}
