"use client";

import { useState, useCallback, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { useDropzone } from "react-dropzone";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  DashboardChrome,
  EditorialMasthead,
  PrimaryPill,
} from "@/components/dashboard";
import { PatientContextGate } from "@/components/dashboard/PatientContextGate";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import type { TransientContext } from "@/lib/patient-context/options";

interface ExtractedBiomarker {
  name: string;
  value: number;
  unit: string;
  referenceRange: string;
  flag: string | null;
  matchedKey: string | null;
  matchedName: string | null;
  // "user" is set when the row was manually mapped via the picker. The
  // extract route only ever returns exact/alias/fuzzy/none; the client
  // upgrades to "user" the moment a marker is picked from the list.
  matchConfidence: "exact" | "alias" | "fuzzy" | "user" | "none";
  zone: string | null;
  zoneLabel: string | null;
  zoneColor: string | null;
  skip: boolean;
  // Rule 1: fuzzy and "none" matches require an explicit user tap
  // before they can be saved. exact + alias start true automatically.
  // Toggling the picker also sets confirmed=true once the user picks.
  confirmed: boolean;
  // Rule 1 (additional B): the extract route flags values that are
  // wildly out of the canonical normal range as implausible (likely an
  // OCR slip). The UI shows a warning chip and requires the user to
  // confirm the row before it can be saved.
  implausible: boolean;
  // When the row was auto-matched to a canonical key that turned out
  // not to exist in the user's reference list, we demote it to
  // unmatched but preserve the original guess + the source of the
  // rejection so the UI can show "we thought this was X, but it's
  // not a valid marker for your profile" instead of treating it as
  // an ordinary unrecognised row. Cleared the moment the user
  // re-picks via the manual dropdown.
  invalidatedKey: string | null;
  invalidatedName: string | null;
  invalidatedBy: "allow_list" | "server" | null;
}

interface BiomarkerReference {
  biomarker_key: string;
  name_en: string;
  name_es: string;
  unit_en: string | null;
  panel_category: string | null;
}

interface ExtractedBiomarkerApi {
  name: string;
  value: number;
  unit: string;
  referenceRange: string;
  flag: string | null;
  matchedKey: string | null;
  matchedName: string | null;
  matchConfidence: "exact" | "alias" | "fuzzy" | "none";
  zone: string | null;
  zoneLabel: string | null;
  zoneColor: string | null;
  implausible?: boolean;
}

interface ExtractionResponse {
  extractedBiomarkers: ExtractedBiomarkerApi[];
  unmatchedCount: number;
  labResultId: string;
  collectionDate: string | null;
}

interface UploadClientProps {
  locale: string;
  /**
   * Profile language preference. Drives the language of biomarker
   * names everywhere lab content surfaces (matched-name column,
   * picker options, picker selections), so users always see lab
   * content in their persisted language regardless of which URL
   * locale they happen to be browsing under.
   */
  profileLocale: "en" | "es";
  /** Profile sex, gates the sex-specific block in the context gate. */
  userSex: "male" | "female" | null;
  totalUploadsUsed: number;
  isSubscriber: boolean;
  userId: string;
}

const MAX_FREE_UPLOADS = 5;
const ACCEPTED_TYPES = {
  "application/pdf": [".pdf"],
  "image/jpeg": [".jpg", ".jpeg"],
  "image/png": [".png"],
  "image/heic": [".heic"],
};
const MAX_SIZE = 10 * 1024 * 1024; // 10MB

/* ──────────────────────────────────────────────────────────────────────
 * Inline SubmissionMasthead removed — uses shared EditorialMasthead. */

/* ──────────────────────────────────────────────────────────────────────
 * StepIndicator — five chapter markers reading "Drop / Extract /
 * Review / Context / Save" with the active one in terra and completed
 * ones in jade. Context is its own chapter (Rule 4) so the user is
 * forced into a single-task screen for the introspective questions
 * rather than answering them on a wall of biomarker numbers.
 * ────────────────────────────────────────────────────────────────────── */
function StepIndicator({
  step,
  locale,
  saving,
}: {
  step: 0 | 1 | 2 | 3;
  locale: string;
  saving: boolean;
}) {
  const labels =
    locale === "es"
      ? ["Soltar", "Extraer", "Revisar", "Contexto", "Guardar"]
      : ["Drop", "Extract", "Review", "Context", "Save"];

  // Live status — the saving flag promotes step 3 → 4 visually while
  // the confirm POST is in flight.
  const liveStep = saving ? 4 : step;

  return (
    <ol className="grid grid-cols-5 border-y border-[#1d1b18]/15">
      {labels.map((label, i) => {
        const num = ["I", "II", "III", "IV", "V"][i];
        const isDone = i < liveStep;
        const isActive = i === liveStep;
        const colour = isDone ? "#3a665e" : isActive ? "#97472c" : "#8a7f76";
        return (
          <li
            key={label}
            className="relative flex flex-col items-start gap-1 px-2 py-4 md:px-4"
            style={{
              borderRight: i < 4 ? "1px solid rgba(29,27,24,0.10)" : "none",
            }}
          >
            <p
              className={`${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.6px] md:text-[10px]`}
              style={{ color: colour }}
            >
              § {num}
            </p>
            <p
              className={`${FONT_CLASS.cormorant} text-[18px] font-medium leading-tight md:text-[22px] ${
                isActive ? "italic" : ""
              }`}
              style={{ color: colour }}
            >
              {label}
            </p>
            {isActive && !isDone && (
              <span
                aria-hidden
                className="absolute inset-x-0 bottom-0 h-[2px] origin-left bg-[#97472c] [animation:stepPulse_1.4s_ease-in-out_infinite]"
              />
            )}
          </li>
        );
      })}
      <style jsx>{`
        @keyframes stepPulse {
          0%, 100% { transform: scaleX(0.4); opacity: 0.6; }
          50%      { transform: scaleX(1);   opacity: 1;   }
        }
      `}</style>
    </ol>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * SectionHeader — kicker + title with italic accent + optional sub.
 * ────────────────────────────────────────────────────────────────────── */
function SectionHeader({
  kicker,
  title,
  accent,
  subtitle,
}: {
  kicker: string;
  title: string;
  accent?: string;
  subtitle?: string;
}) {
  return (
    <header className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <span aria-hidden className="inline-block h-px w-8 bg-[#1d1b18]/25 md:w-12" />
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]`}
        >
          {kicker}
        </p>
      </div>
      <h2
        className={`${FONT_CLASS.cormorant} text-[44px] font-medium leading-[0.95] tracking-[-0.8px] text-[#1d1b18] md:text-[64px] md:tracking-[-1.5px]`}
        style={{ textWrap: "balance" } as React.CSSProperties}
      >
        {title}{" "}
        {accent && <span className="italic text-[#97472c]">{accent}</span>}
      </h2>
      {subtitle && (
        <p
          className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f] md:text-[16px]`}
          style={{ textWrap: "pretty" } as React.CSSProperties}
        >
          {subtitle}
        </p>
      )}
    </header>
  );
}

/* PrimaryPill now imported from @/components/dashboard. */

export function UploadClient({
  locale,
  profileLocale,
  userSex,
  totalUploadsUsed,
  isSubscriber,
}: UploadClientProps) {
  const router = useRouter();
  const [step, setStep] = useState<0 | 1 | 2 | 3>(0);
  const [files, setFiles] = useState<File[]>([]);
  const [extracting, setExtracting] = useState(false);
  const [biomarkers, setBiomarkers] = useState<ExtractedBiomarker[]>([]);
  const [labResultId, setLabResultId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);
  const [collectionDate, setCollectionDate] = useState<string>(() =>
    new Date().toISOString().split("T")[0],
  );
  const [dateFromPdf, setDateFromPdf] = useState(false);
  const [references, setReferences] = useState<BiomarkerReference[]>([]);
  const [openPickerIdx, setOpenPickerIdx] = useState<number | null>(null);
  const [pickerQuery, setPickerQuery] = useState("");

  // Rule 4 — patient-context gate. The user must confirm or update
  // their durable context before a lab can be saved. We hold both the
  // selected version id and the per-draw transient block in local
  // state and send them along in the /confirm body so the lab_result
  // row carries them when the AI pipeline runs.
  const [contextVersionId, setContextVersionId] = useState<string | null>(null);
  const [transientContext, setTransientContext] = useState<TransientContext | null>(
    null,
  );

  // Load the canonical biomarker list for the manual-match picker.
  // Filtered server-side by the user's sex + age so the user never sees
  // a male-only marker on a female profile and vice versa.
  useEffect(() => {
    let cancelled = false;
    fetch("/api/biomarker-references", { credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((data) => {
        if (cancelled) return;
        setReferences(data.references ?? []);
      })
      .catch((err) => {
        console.error("[upload] Failed to load biomarker references:", err);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Re-validate every auto-matched row against the loaded reference
  // allow-list. The extract route's matcher can resolve a name to a
  // canonical key that has no row in biomarker_references for the
  // user's sex+age — e.g. a male-only marker for a female profile, or
  // a calculated metric in the matcher's ALL_KEYS that the seed
  // doesn't actually carry. /confirm would reject those with a 422
  // (`One or more biomarker keys are not in the reference list`), but
  // surfacing that at step V (Save) leaves the user stuck. Instead we
  // demote any row whose matchedKey isn't in the loaded references
  // back to "unmatched" so it counts toward needsActionCount and the
  // "Continue → Context" gate at step III refuses to advance until
  // the user either picks a valid marker from the dropdown or skips
  // the row.
  useEffect(() => {
    if (references.length === 0) return;
    const valid = new Set(references.map((r) => r.biomarker_key));
    setBiomarkers((prev) => {
      let changed = false;
      const next = prev.map((b) => {
        if (b.matchedKey && !valid.has(b.matchedKey)) {
          changed = true;
          return {
            ...b,
            // Preserve the original guess so the UI can show "we
            // thought this was X" instead of pretending the row was
            // never matched.
            invalidatedKey: b.matchedKey,
            invalidatedName: b.matchedName,
            invalidatedBy: "allow_list" as const,
            matchedKey: null,
            matchedName: null,
            matchConfidence: "none" as const,
            confirmed: false,
            // Zone + implausibility were derived from a reference that
            // doesn't apply to this user — clear them so the row
            // doesn't display a misleading badge or warning.
            zone: null,
            zoneLabel: null,
            zoneColor: null,
            implausible: false,
          };
        }
        return b;
      });
      return changed ? next : prev;
    });
  }, [references]);

  const uploadsRemaining = MAX_FREE_UPLOADS - totalUploadsUsed;
  const canUpload = isSubscriber || uploadsRemaining > 0;

  const t =
    locale === "es"
      ? {
          back: "Volver al panel",
          // Hero
          kickerHero: "§ El envio",
          heroTitle: "Sube una",
          heroAccent: "lectura.",
          heroLede:
            "Tu kit fuera de EVA tambien cuenta. Subelo aqui y lo leemos contra los rangos optimos de longevidad, no contra el rango clinico generico.",
          counterFree: "Subida {n} de {max} gratuitas",
          counterPro: "Subidas ilimitadas",
          // Drop zone
          kickerDrop: "§ I · Soltar",
          dropTitle: "Suelta tu",
          dropAccent: "informe.",
          dropLede:
            "PDF, JPG, PNG o HEIC. Hasta 10MB por archivo. Acepta resultados de cualquier laboratorio.",
          dropBig: "Arrastra aqui o pulsa para elegir",
          dropSub: "PDF · JPG · PNG · HEIC · max 10MB",
          dropActive: "Suelta cuando quieras",
          filesSelected: "archivos listos",
          remove: "Quitar",
          analyzeCta: "Extraer marcadores",
          // Extract
          kickerExtract: "§ II · Extraer",
          extractTitle: "Leyendo tu",
          extractAccent: "despacho.",
          extractLede:
            "Nuestra IA esta identificando cada marcador del documento. Tarda unos segundos por archivo.",
          // Review
          kickerReview: "§ III · Revisar",
          reviewTitle: "La hoja de",
          reviewAccent: "pruebas.",
          reviewLede:
            "Verifica los marcadores extraidos. Edita valores, omite los que no quieras guardar y confirma cuando todo este listo.",
          matchedSuffix: "marcadores reconocidos",
          unmatchedSuffix: "sin reconocer",
          dateLabel: "Fecha de la muestra",
          dateHint:
            "El dia en que se tomo la muestra. Importante para tu historial.",
          dateFromPdf: "Detectada del PDF. Corrigela si no es correcta.",
          colOriginal: "Nombre original",
          colValue: "Valor",
          colUnit: "Unidad",
          colMatched: "Marcador EVA",
          colSkip: "Omitir",
          continueToContext: "Continuar al contexto →",
          continueToContextHint:
            "Confirma los datos del dia de la extraccion en el siguiente paso.",
          // Context chapter (Rule 4)
          kickerContext: "§ IV · Contexto",
          contextTitle: "El relato del",
          contextAccent: "cuerpo.",
          contextLede:
            "Tu interpretacion cambia si tomas creatina, si entrenaste fuerte la vispera o si llevas un tratamiento cronico. Confirma lo que sigue siendo cierto antes de archivar la lectura.",
          backToReview: "← Volver a revisar",
          confirmCta: "Firmar y archivar",
          confirming: "Archivando...",
          // Rule 1 — manual matching + confirmation
          pickerPick: "Elegir marcador",
          pickerChange: "Cambiar",
          pickerSearch: "Buscar marcador...",
          pickerEmpty: "Sin resultados",
          pickerClose: "Cerrar",
          matchExact: "exacto",
          matchAlias: "alias",
          matchFuzzy: "aproximado",
          matchUser: "manual",
          needsConfirmTap: "Toca para confirmar",
          confirmedTag: "Confirmado",
          fuzzyHint:
            "Coincidencia aproximada. Confirma o elige otro marcador.",
          unmatchedHint:
            "No reconocido. Elige un marcador EVA o omitelo.",
          invalidTag: "No valido para tu perfil",
          invalidHintClient: (name: string) =>
            `Lo identificamos como "${name}", pero no esta en tu lista de referencia (sexo/edad). Elige otro o omitelo.`,
          invalidHintServer: (name: string) =>
            `El servidor rechazo "${name}" al guardar. Elige otro marcador o omite esta fila.`,
          implausibleTag: "Valor inusual",
          implausibleHint:
            "Este valor esta muy fuera del rango normal. Verifica que sea correcto antes de guardar.",
          summaryReady: "{n} listo para guardar",
          summarySkipped: "{n} omitido",
          summaryNeedsAction: "{n} requiere atencion",
          summaryInvalid: "{n} no valido",
          confirmBlockedReason:
            "Confirma los marcadores aproximados o no reconocidos antes de guardar.",
          serverRejectedBanner:
            "El guardado fallo porque algunos marcadores no estan en tu lista de referencia. Los hemos marcado abajo — elige uno valido o omitelos y vuelve a guardar.",
          // Paywall
          kickerPaywall: "§ Limite alcanzado",
          paywallTitle: "Cinco lecturas",
          paywallAccent: "archivadas.",
          paywallLede:
            "Has llenado tus subidas gratuitas. Con la suscripcion, sube sin limites y recibe el kit trimestral incluido.",
          paywallCta: "Ver planes",
          // Errors
          dismiss: "Cerrar",
        }
      : {
          back: "Back to dashboard",
          kickerHero: "§ The submission",
          heroTitle: "File a",
          heroAccent: "reading.",
          heroLede:
            "Bloodwork from outside EVA still counts. Upload it here and we read it against EVA's longevity-optimal ranges, not the generic clinical range.",
          counterFree: "Upload {n} of {max} free",
          counterPro: "Unlimited uploads",
          kickerDrop: "§ I · Drop",
          dropTitle: "Drop your",
          dropAccent: "report.",
          dropLede:
            "PDF, JPG, PNG or HEIC. Up to 10MB per file. Any lab provider works.",
          dropBig: "Drag here or click to choose",
          dropSub: "PDF · JPG · PNG · HEIC · max 10MB",
          dropActive: "Drop when ready",
          filesSelected: "files queued",
          remove: "Remove",
          analyzeCta: "Extract markers",
          kickerExtract: "§ II · Extract",
          extractTitle: "Reading your",
          extractAccent: "dispatch.",
          extractLede:
            "Our AI is identifying every marker on the document. A few seconds per file.",
          kickerReview: "§ III · Review",
          reviewTitle: "The proof",
          reviewAccent: "sheet.",
          reviewLede:
            "Verify the extracted markers. Edit values, skip the ones you don't want stored, and confirm when everything looks right.",
          matchedSuffix: "markers matched",
          unmatchedSuffix: "unmatched",
          dateLabel: "Sample date",
          dateHint:
            "The day the sample was taken. Important for your history.",
          dateFromPdf: "Detected from the PDF. Fix it if it's wrong.",
          colOriginal: "Original name",
          colValue: "Value",
          colUnit: "Unit",
          colMatched: "EVA marker",
          colSkip: "Skip",
          continueToContext: "Continue to context →",
          continueToContextHint:
            "Confirm the day-of-draw details in the next step.",
          // Context chapter (Rule 4)
          kickerContext: "§ IV · Context",
          contextTitle: "What the body",
          contextAccent: "carries.",
          contextLede:
            "Your interpretation changes if you take creatine, trained hard the day before, or are on chronic therapy. Confirm what's still true before we file your reading.",
          backToReview: "← Back to review",
          confirmCta: "Sign off and file",
          confirming: "Filing...",
          // Rule 1 — manual matching + confirmation
          pickerPick: "Pick a marker",
          pickerChange: "Change",
          pickerSearch: "Search markers...",
          pickerEmpty: "No matches",
          pickerClose: "Close",
          matchExact: "exact",
          matchAlias: "alias",
          matchFuzzy: "fuzzy",
          matchUser: "manual",
          needsConfirmTap: "Tap to confirm",
          confirmedTag: "Confirmed",
          fuzzyHint:
            "Fuzzy match. Confirm or pick a different marker.",
          unmatchedHint:
            "Not recognised. Pick an EVA marker or skip this row.",
          invalidTag: "Not valid for your profile",
          invalidHintClient: (name: string) =>
            `We identified this as "${name}", but it isn't in your reference list (sex/age). Pick another or skip.`,
          invalidHintServer: (name: string) =>
            `The server rejected "${name}" at save. Pick another marker or skip this row.`,
          implausibleTag: "Unusual value",
          implausibleHint:
            "This value is far outside the normal range. Verify it is correct before saving.",
          summaryReady: "{n} ready to save",
          summarySkipped: "{n} skipped",
          summaryNeedsAction: "{n} needs attention",
          summaryInvalid: "{n} invalid",
          confirmBlockedReason:
            "Confirm fuzzy or unmatched markers before saving.",
          serverRejectedBanner:
            "Save failed because some markers aren't in your reference list. We've flagged them below — pick a valid marker or skip them and try again.",
          kickerPaywall: "§ Limit reached",
          paywallTitle: "Five readings",
          paywallAccent: "filed.",
          paywallLede:
            "You've used your free uploads. With the subscription you upload without limits and the quarterly kit is included.",
          paywallCta: "See plans",
          dismiss: "Dismiss",
        };

  // ── Handlers ──

  const onDrop = useCallback((accepted: File[]) => {
    setFiles((prev) => [...prev, ...accepted]);
    setError(null);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    maxSize: MAX_SIZE,
    disabled: !canUpload,
  });

  function removeFile(idx: number) {
    setFiles((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleAnalyze() {
    if (files.length === 0) return;
    setStep(1);
    setExtracting(true);
    setError(null);
    try {
      const formData = new FormData();
      for (const file of files) formData.append("files", file);
      const res = await fetch("/api/lab-results/extract", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Extraction failed");
      }
      const data: ExtractionResponse = await res.json();
      // exact + alias matches start pre-confirmed (high precision); fuzzy
      // and unmatched ("none") rows require an explicit user tap before
      // they can be saved. Implausible rows (extreme value vs. canonical
      // normal range) also start unconfirmed regardless of confidence.
      //
      // Allow-list crosscheck: if the references list has already loaded
      // by the time the user finished extracting, validate matchedKey
      // against it inline so the gate at step III never lets through a
      // row that /confirm would reject as missing-from-references. If
      // references haven't loaded yet, the useEffect above will catch
      // these rows once the fetch completes.
      const validKeys =
        references.length > 0
          ? new Set(references.map((r) => r.biomarker_key))
          : null;
      setBiomarkers(
        data.extractedBiomarkers.map((b) => {
          const keyIsValid =
            !b.matchedKey || !validKeys || validKeys.has(b.matchedKey);
          const matchedKey = keyIsValid ? b.matchedKey : null;
          const matchedName = keyIsValid ? b.matchedName : null;
          const matchConfidence = keyIsValid ? b.matchConfidence : "none";
          return {
            ...b,
            matchedKey,
            matchedName,
            matchConfidence,
            zone: keyIsValid ? b.zone : null,
            zoneLabel: keyIsValid ? b.zoneLabel : null,
            zoneColor: keyIsValid ? b.zoneColor : null,
            skip: false,
            implausible: keyIsValid ? (b.implausible ?? false) : false,
            confirmed:
              keyIsValid &&
              !b.implausible &&
              !!matchedKey &&
              (matchConfidence === "exact" || matchConfidence === "alias"),
            // Preserve the original auto-match guess + tag the source
            // when we couldn't validate it against the loaded refs.
            invalidatedKey: keyIsValid ? null : (b.matchedKey ?? null),
            invalidatedName: keyIsValid ? null : (b.matchedName ?? null),
            invalidatedBy: keyIsValid ? null : ("allow_list" as const),
          };
        }),
      );
      setLabResultId(data.labResultId);
      if (data.collectionDate) {
        setCollectionDate(data.collectionDate);
        setDateFromPdf(true);
      } else {
        setDateFromPdf(false);
      }
      setStep(2);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unknown error");
      setStep(0);
    } finally {
      setExtracting(false);
    }
  }

  function updateBiomarker(
    idx: number,
    field: keyof ExtractedBiomarker,
    value: unknown,
  ) {
    setBiomarkers((prev) =>
      prev.map((b, i) => (i === idx ? { ...b, [field]: value } : b)),
    );
  }

  async function handleConfirm() {
    if (!labResultId) return;
    if (!contextVersionId) {
      setError(
        locale === "es"
          ? "Confirma tu contexto antes de guardar."
          : "Confirm your context before saving.",
      );
      return;
    }
    setConfirming(true);
    setError(null);
    // Rule 1: only rows that are (a) not skipped, (b) have a canonical
    // match, and (c) have been confirmed by the user (auto for
    // exact/alias, manual tap for fuzzy/manual/implausible) reach the
    // server. The server allow-list rechecks the keys against
    // biomarker_references so a tampered payload still can't write an
    // un-rangeable row.
    const confirmedBiomarkers = biomarkers
      .filter((b) => !b.skip && b.matchedKey && b.confirmed)
      .map((b) => ({
        name: b.name,
        value: b.value,
        unit: b.unit,
        biomarkerKey: b.matchedKey as string,
        // "none" can't happen at this point (matchedKey is set), so the
        // remaining values map cleanly onto the server enum.
        matchConfidence: (b.matchConfidence === "none"
          ? "user"
          : b.matchConfidence) as "exact" | "alias" | "fuzzy" | "user",
      }));
    try {
      const res = await fetch("/api/lab-results/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          labResultId,
          biomarkers: confirmedBiomarkers,
          collectionDate,
          contextVersionId,
          transientContext: transientContext ?? {},
        }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        // Server-side allow-list rejection: parse unknownKeys and mark
        // the corresponding rows so the user sees exactly which markers
        // need fixing, then bounce back to Review. Without this the
        // user is stuck on the Context step with a generic toast and
        // no idea which biomarkers are the problem.
        if (
          res.status === 422 &&
          Array.isArray(errData.unknownKeys) &&
          errData.unknownKeys.length > 0
        ) {
          const bad = new Set<string>(errData.unknownKeys);
          setBiomarkers((prev) =>
            prev.map((b) =>
              b.matchedKey && bad.has(b.matchedKey)
                ? {
                    ...b,
                    invalidatedKey: b.matchedKey,
                    invalidatedName: b.matchedName,
                    invalidatedBy: "server" as const,
                    matchedKey: null,
                    matchedName: null,
                    matchConfidence: "none" as const,
                    confirmed: false,
                    zone: null,
                    zoneLabel: null,
                    zoneColor: null,
                    implausible: false,
                  }
                : b,
            ),
          );
          setError(t.serverRejectedBanner);
          setStep(2);
          if (typeof window !== "undefined") {
            // Defer to the next frame so the layout settles before we
            // scroll to the first flagged row.
            requestAnimationFrame(() => {
              const el = document.querySelector(
                '[data-row-state="invalidated"]',
              );
              if (el && "scrollIntoView" in el) {
                (el as HTMLElement).scrollIntoView({
                  behavior: "smooth",
                  block: "center",
                });
              }
            });
          }
          setConfirming(false);
          return;
        }
        throw new Error(errData.error || `Confirm failed (${res.status})`);
      }
      router.push(`/${locale}/labs`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to save results");
      setConfirming(false);
    }
  }

  // Rule 1 — three derived counts drive the summary chip and the
  // confirm-button gate:
  //   readyCount      : will be saved (matched + confirmed + not skipped)
  //   needsActionCount: matched but unconfirmed, OR implausible, OR unmatched
  //                     and not skipped — i.e. blocking the save
  //   skippedCount    : explicitly skipped rows
  const readyCount = biomarkers.filter(
    (b) => b.matchedKey && b.confirmed && !b.skip && !b.implausible,
  ).length;
  const skippedCount = biomarkers.filter((b) => b.skip).length;
  const needsActionCount = biomarkers.filter(
    (b) => !b.skip && (!b.matchedKey || !b.confirmed || b.implausible),
  ).length;
  // Invalidated rows are a strict subset of needsAction — they're the
  // ones the user can't fix by re-confirming because the auto-match
  // resolved to a key that's not in their reference list. Surface the
  // count separately so the user knows how many of the "needs
  // attention" rows specifically need a manual pick (vs. a tap-to-
  // confirm on a fuzzy match).
  const invalidatedCount = biomarkers.filter(
    (b) => !b.skip && !b.matchedKey && !!b.invalidatedBy,
  ).length;
  // Legacy alias kept until the rest of the file is migrated to the new
  // names (renders use these below).
  const matchedCount = readyCount;
  const unmatchedCount = biomarkers.filter((b) => !b.matchedKey && !b.skip).length;

  // Picker filtering. Lowercase the query once per render and check both
  // English and Spanish names so a Spanish user typing "creatinina" still
  // finds the canonical row.
  const pickerSuggestions = useMemo(() => {
    const q = pickerQuery.trim().toLowerCase();
    if (q.length === 0) return references.slice(0, 50);
    return references
      .filter(
        (r) =>
          r.name_en.toLowerCase().includes(q) ||
          r.name_es.toLowerCase().includes(q) ||
          r.biomarker_key.includes(q),
      )
      .slice(0, 50);
  }, [pickerQuery, references]);

  function selectMarker(idx: number, ref: BiomarkerReference) {
    setBiomarkers((prev) =>
      prev.map((b, i) =>
        i === idx
          ? {
              ...b,
              matchedKey: ref.biomarker_key,
              // Use profileLocale (not URL locale) so the matched-name
              // language always matches the user's saved preference,
              // even if they happen to be browsing under the other locale.
              matchedName: profileLocale === "es" ? ref.name_es : ref.name_en,
              // A manual pick is always "user" confidence regardless of
              // what the matcher had originally guessed. The user has
              // explicitly chosen it, so it's automatically confirmed.
              matchConfidence: "user",
              confirmed: true,
              // Manual selection overrides an implausibility warning —
              // the user has seen the value and the new mapping and is
              // accepting both. (They can still untick "skip" or change
              // the value if they want.)
              implausible: false,
              // Zone needs re-classification against the newly chosen
              // reference, but we don't have ranges client-side. The
              // server re-classifies on confirm; clear the stale zone
              // so the row doesn't display a misleading badge.
              zone: null,
              zoneLabel: null,
              zoneColor: null,
              // The user has overridden any prior auto-match
              // invalidation by explicitly picking — clear the
              // "we thought this was X" attribution.
              invalidatedKey: null,
              invalidatedName: null,
              invalidatedBy: null,
            }
          : b,
      ),
    );
    setOpenPickerIdx(null);
    setPickerQuery("");
  }

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1100px]">
          {/* Masthead + back */}
          <motion.div variants={fadeUp}>
            <EditorialMasthead issue={locale === "es" ? "Envio" : "Submission"} />
          </motion.div>

          <motion.div variants={fadeUp} className="mt-8">
            <Link
              href={`/${locale}/dashboard`}
              className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
            >
              <span aria-hidden>←</span>
              {t.back}
            </Link>
          </motion.div>

          {/* Hero */}
          <motion.section
            variants={fadeUp}
            className="mt-10 grid gap-10 md:mt-16 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-8">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
              >
                {t.kickerHero}
              </p>
              <h1
                className={`mt-4 ${FONT_CLASS.cormorant} text-[64px] font-medium leading-[0.92] tracking-[-1.5px] text-[#1d1b18] md:text-[112px] md:tracking-[-4px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.heroTitle}{" "}
                <span className="italic text-[#97472c]">{t.heroAccent}</span>
              </h1>
              <p
                className={`mt-6 max-w-[52ch] ${FONT_CLASS.manrope} text-[16px] leading-[1.65] text-[#4c463f] md:text-[17px]`}
                style={{ textWrap: "pretty" } as React.CSSProperties}
              >
                {t.heroLede}
              </p>
            </div>
            <div className="md:col-span-4 md:pt-2">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#3a665e]`}
              >
                {isSubscriber
                  ? t.counterPro
                  : t.counterFree
                      .replace("{n}", String(totalUploadsUsed + 1))
                      .replace("{max}", String(MAX_FREE_UPLOADS))}
              </p>
            </div>
          </motion.section>

          {/* Step indicator */}
          <motion.div variants={fadeUp} className="mt-12 md:mt-16">
            <StepIndicator step={step} locale={locale} saving={confirming} />
          </motion.div>

          {/* Paywall */}
          {!canUpload && (
            <motion.section
              variants={fadeUp}
              className="mt-12 grid gap-6 md:mt-16 md:grid-cols-12 md:gap-10"
            >
              <div className="md:col-span-5">
                <SectionHeader
                  kicker={t.kickerPaywall}
                  title={t.paywallTitle}
                  accent={t.paywallAccent}
                />
              </div>
              <div className="md:col-span-7 md:pt-2">
                <p
                  className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f] md:text-[16px]`}
                  style={{ textWrap: "pretty" } as React.CSSProperties}
                >
                  {t.paywallLede}
                </p>
                <div className="mt-7">
                  <Link
                    href={`/${locale}/pricing`}
                    className={`group inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0`}
                  >
                    {t.paywallCta}
                    <span
                      aria-hidden
                      className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
                    >
                      <svg
                        className="h-3 w-3"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                        />
                      </svg>
                    </span>
                  </Link>
                </div>
              </div>
            </motion.section>
          )}

          {/* Step 0 — Drop zone */}
          {step === 0 && canUpload && (
            <motion.section
              variants={fadeUp}
              className="mt-12 grid gap-6 md:mt-16 md:grid-cols-12 md:gap-10"
            >
              <div className="md:col-span-5">
                <SectionHeader
                  kicker={t.kickerDrop}
                  title={t.dropTitle}
                  accent={t.dropAccent}
                  subtitle={t.dropLede}
                />
              </div>
              <div className="md:col-span-7 md:pt-2">
                <div
                  {...getRootProps()}
                  className={`group flex min-h-[260px] cursor-pointer flex-col items-center justify-center rounded-[20px] border-2 border-dashed p-10 text-center transition-all ${
                    isDragActive
                      ? "border-[#97472c] bg-[rgba(151,71,44,0.06)]"
                      : "border-[#1d1b18]/25 bg-[#fef8f2]/40 hover:border-[#97472c]/55 hover:bg-[rgba(151,71,44,0.025)]"
                  }`}
                >
                  <input {...getInputProps()} />
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
                  >
                    § Drop
                  </p>
                  <p
                    className={`mt-3 ${FONT_CLASS.cormorant} text-[28px] font-medium italic leading-[1.1] text-[#1d1b18] md:text-[36px]`}
                  >
                    {isDragActive ? t.dropActive : t.dropBig}
                  </p>
                  <p
                    className={`mt-3 ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.8px] text-[#8a7f76]`}
                  >
                    {t.dropSub}
                  </p>
                </div>

                {files.length > 0 && (
                  <motion.div
                    variants={staggerTight}
                    initial="hidden"
                    animate="show"
                    className="mt-6"
                  >
                    <p
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]`}
                    >
                      {files.length} {t.filesSelected}
                    </p>
                    <ul className="mt-3 border-t border-[#1d1b18]/15">
                      {files.map((file, i) => (
                        <motion.li
                          key={i}
                          variants={fadeUp}
                          className="flex items-center justify-between gap-4 border-b border-[#1d1b18]/10 py-3"
                        >
                          <div className="min-w-0 flex-1">
                            <p
                              className={`truncate ${FONT_CLASS.cormorant} text-[18px] font-medium italic text-[#1d1b18]`}
                            >
                              {file.name}
                            </p>
                            <p
                              className={`mt-1 ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                            >
                              {(file.size / 1024).toFixed(0)} KB
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeFile(i)}
                            className={`shrink-0 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] underline decoration-[#1d1b18]/15 underline-offset-[5px] transition-colors hover:text-[#b04040] hover:decoration-[#b04040]/40`}
                          >
                            {t.remove}
                          </button>
                        </motion.li>
                      ))}
                    </ul>
                    <div className="mt-7">
                      <PrimaryPill
                        onClick={handleAnalyze}
                        loading={extracting}
                        disabled={extracting}
                      >
                        {t.analyzeCta}
                      </PrimaryPill>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.section>
          )}

          {/* Step 1 — Extracting */}
          {step === 1 && (
            <motion.section
              variants={fadeUp}
              className="mt-14 grid gap-6 md:mt-20 md:grid-cols-12 md:gap-10"
            >
              <div className="md:col-span-5">
                <SectionHeader
                  kicker={t.kickerExtract}
                  title={t.extractTitle}
                  accent={t.extractAccent}
                  subtitle={t.extractLede}
                />
              </div>
              <div className="md:col-span-7 md:pt-2">
                <div className="relative h-1 w-full overflow-hidden rounded-full bg-[#1d1b18]/8">
                  <span
                    aria-hidden
                    className="absolute inset-y-0 left-0 w-1/3 origin-left bg-[#97472c] [animation:extractSweep_1.6s_ease-in-out_infinite]"
                  />
                </div>
                <ul className="mt-6 border-t border-[#1d1b18]/15">
                  {files.map((f, i) => (
                    <li
                      key={i}
                      className="flex items-baseline gap-3 border-b border-[#1d1b18]/10 py-3"
                    >
                      <span
                        aria-hidden
                        className="inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-[#97472c] [animation:dotPulse_1.4s_ease-in-out_infinite]"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                      <p
                        className={`flex-1 truncate ${FONT_CLASS.cormorant} text-[18px] italic text-[#1d1b18]`}
                      >
                        {f.name}
                      </p>
                      <span
                        className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#97472c]`}
                      >
                        {locale === "es" ? "Leyendo" : "Reading"}
                      </span>
                    </li>
                  ))}
                </ul>
                <style jsx>{`
                  @keyframes extractSweep {
                    0%   { transform: translateX(-100%); }
                    50%  { transform: translateX(150%); }
                    100% { transform: translateX(350%); }
                  }
                  @keyframes dotPulse {
                    0%, 100% { opacity: 0.35; transform: scale(0.85); }
                    50%      { opacity: 1;    transform: scale(1.15); }
                  }
                `}</style>
              </div>
            </motion.section>
          )}

          {/* Step 2 — Review proof sheet */}
          {step === 2 && (
            <motion.section
              variants={fadeUp}
              className="mt-12 md:mt-16"
            >
              <div className="grid gap-6 md:grid-cols-12 md:gap-10">
                <div className="md:col-span-5">
                  <SectionHeader
                    kicker={t.kickerReview}
                    title={t.reviewTitle}
                    accent={t.reviewAccent}
                    subtitle={t.reviewLede}
                  />
                </div>
                <div className="md:col-span-7 md:pt-2">
                  {/* Stats strip — Rule 1: surface ready / needs-attention /
                       skipped so the user can't miss why save is blocked. */}
                  <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2 border-b border-[#1d1b18]/15 pb-3">
                    <span
                      className={`${FONT_CLASS.cormorant} text-[40px] font-medium leading-none tabular-nums text-[#3a665e]`}
                    >
                      {String(readyCount).padStart(2, "0")}
                    </span>
                    <span
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                    >
                      {t.summaryReady.replace("{n}", "").trim() ||
                        t.matchedSuffix}
                    </span>
                    {needsActionCount > 0 && (
                      <>
                        <span aria-hidden className="h-px w-6 bg-[#1d1b18]/15" />
                        <span
                          className={`${FONT_CLASS.cormorant} text-[28px] font-medium leading-none italic tabular-nums text-[#c49332]`}
                        >
                          {String(needsActionCount).padStart(2, "0")}
                        </span>
                        <span
                          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#c49332]`}
                        >
                          {t.summaryNeedsAction.replace("{n}", "").trim()}
                        </span>
                      </>
                    )}
                    {invalidatedCount > 0 && (
                      <>
                        <span aria-hidden className="h-px w-6 bg-[#1d1b18]/15" />
                        <span
                          className={`${FONT_CLASS.cormorant} text-[28px] font-medium leading-none italic tabular-nums text-[#b04040]`}
                        >
                          {String(invalidatedCount).padStart(2, "0")}
                        </span>
                        <span
                          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#b04040]`}
                        >
                          {t.summaryInvalid.replace("{n}", "").trim()}
                        </span>
                      </>
                    )}
                    {skippedCount > 0 && (
                      <>
                        <span aria-hidden className="h-px w-6 bg-[#1d1b18]/15" />
                        <span
                          className={`${FONT_CLASS.cormorant} text-[24px] font-medium leading-none tabular-nums text-[#8a7f76]`}
                        >
                          {String(skippedCount).padStart(2, "0")}
                        </span>
                        <span
                          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                        >
                          {t.summarySkipped.replace("{n}", "").trim()}
                        </span>
                      </>
                    )}
                  </div>

                  {/* Date */}
                  <div className="mt-6">
                    <label
                      htmlFor="collection-date"
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                    >
                      {t.dateLabel}
                    </label>
                    <input
                      id="collection-date"
                      type="date"
                      value={collectionDate}
                      max={new Date().toISOString().split("T")[0]}
                      onChange={(e) => {
                        setCollectionDate(e.target.value);
                        setDateFromPdf(false);
                      }}
                      className={`mt-2 block w-full max-w-xs border-b border-[#1d1b18]/30 bg-transparent py-1.5 ${FONT_CLASS.cormorant} text-[20px] tabular-nums text-[#1d1b18] outline-none focus:border-[#97472c]`}
                    />
                    <p
                      className={`mt-2 ${FONT_CLASS.manrope} text-[12px] italic leading-[1.55] text-[#8a7f76]`}
                    >
                      {dateFromPdf ? t.dateFromPdf : t.dateHint}
                    </p>
                  </div>
                </div>
              </div>

              {/* Proof sheet — biomarker rows */}
              <div className="mt-10 border-t border-[#1d1b18]/20 md:mt-14">
                {/* Column headers */}
                <div
                  className={`hidden md:grid md:grid-cols-[1.2fr_0.6fr_0.5fr_1.4fr_0.4fr] md:gap-4 md:border-b md:border-[#1d1b18]/15 md:py-3 ${FONT_CLASS.dmMono} md:text-[9.5px] md:font-semibold md:uppercase md:tracking-[1.6px] md:text-[#8a7f76]`}
                >
                  <span>{t.colOriginal}</span>
                  <span>{t.colValue}</span>
                  <span>{t.colUnit}</span>
                  <span>{t.colMatched}</span>
                  <span className="text-right">{t.colSkip}</span>
                </div>

                {biomarkers.map((b, i) => {
                  const isUnmatched = !b.matchedKey;
                  const isInvalidated = isUnmatched && !!b.invalidatedBy;
                  const needsConfirm = !b.skip && !!b.matchedKey && !b.confirmed;
                  // Stronger rose tint + left border for invalidated
                  // rows so the user can scan a long list and spot the
                  // ones that need attention without reading every hint.
                  const rowTint = b.skip
                    ? ""
                    : b.implausible
                      ? "bg-[rgba(176,64,64,0.06)] border-l-2 border-l-[#b04040]"
                      : isInvalidated
                        ? "bg-[rgba(176,64,64,0.05)] border-l-2 border-l-[#b04040]"
                        : isUnmatched || needsConfirm
                          ? "bg-[rgba(196,147,50,0.04)]"
                          : "";
                  const confidenceLabel =
                    b.matchConfidence === "exact"
                      ? t.matchExact
                      : b.matchConfidence === "alias"
                        ? t.matchAlias
                        : b.matchConfidence === "fuzzy"
                          ? t.matchFuzzy
                          : t.matchUser;
                  const invalidatedDisplayName =
                    b.invalidatedName ?? b.invalidatedKey ?? "";
                  return (
                    <div
                      key={i}
                      data-row-state={
                        isInvalidated ? "invalidated" : undefined
                      }
                      className={`grid grid-cols-2 gap-3 border-b border-[#1d1b18]/10 py-4 transition-colors md:grid-cols-[1.2fr_0.6fr_0.5fr_1.4fr_0.4fr] md:gap-4 md:py-3 ${rowTint} ${b.skip ? "opacity-40" : ""}`}
                    >
                      <div className="md:col-span-1">
                        <p
                          className={`${FONT_CLASS.cormorant} text-[18px] font-medium italic leading-tight text-[#1d1b18] md:text-[19px]`}
                        >
                          {b.name}
                        </p>
                        {isInvalidated && !b.skip && (
                          <p
                            className={`mt-1 ${FONT_CLASS.manrope} text-[11px] leading-[1.4] text-[#b04040]`}
                          >
                            {b.invalidatedBy === "server"
                              ? t.invalidHintServer(invalidatedDisplayName)
                              : t.invalidHintClient(invalidatedDisplayName)}
                          </p>
                        )}
                        {b.implausible && (
                          <p
                            className={`mt-1 ${FONT_CLASS.manrope} text-[11px] leading-[1.4] text-[#b04040]`}
                          >
                            {t.implausibleHint}
                          </p>
                        )}
                        {!b.implausible && isUnmatched && !isInvalidated && !b.skip && (
                          <p
                            className={`mt-1 ${FONT_CLASS.manrope} text-[11px] italic leading-[1.4] text-[#8a7f76]`}
                          >
                            {t.unmatchedHint}
                          </p>
                        )}
                        {!b.implausible &&
                          !isUnmatched &&
                          b.matchConfidence === "fuzzy" &&
                          !b.confirmed && (
                            <p
                              className={`mt-1 ${FONT_CLASS.manrope} text-[11px] italic leading-[1.4] text-[#8a7f76]`}
                            >
                              {t.fuzzyHint}
                            </p>
                          )}
                      </div>
                      <div>
                        <input
                          type="number"
                          step="any"
                          value={b.value}
                          onChange={(e) =>
                            updateBiomarker(
                              i,
                              "value",
                              parseFloat(e.target.value) || 0,
                            )
                          }
                          className={`w-20 border-b border-[#1d1b18]/30 bg-transparent py-1 text-right ${FONT_CLASS.dmMono} text-[16px] tabular-nums text-[#1d1b18] outline-none focus:border-[#97472c]`}
                        />
                      </div>
                      <span
                        className={`self-center ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.2px] text-[#8a7f76]`}
                      >
                        {b.unit}
                      </span>
                      <div className="self-center">
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          {b.matchedName ? (
                            <span
                              className={`${FONT_CLASS.manrope} text-[13px] text-[#1d1b18]`}
                            >
                              {b.matchedName}
                            </span>
                          ) : isInvalidated ? (
                            <span
                              className={`inline-flex items-center gap-1 rounded-full bg-[#b04040] px-2 py-0.5 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.3px] text-[#f7f1e8]`}
                            >
                              <span aria-hidden className="inline-block h-1 w-1 rounded-full bg-[#f7f1e8]" />
                              {t.invalidTag}
                            </span>
                          ) : (
                            <span
                              className={`${FONT_CLASS.manrope} text-[13px] italic text-[#c49332]`}
                            >
                              {locale === "es" ? "sin reconocer" : "unmatched"}
                            </span>
                          )}
                          {b.matchedName && (
                            <span
                              className={`${FONT_CLASS.dmMono} text-[9px] font-semibold uppercase tracking-[1.3px] text-[#8a7f76]`}
                            >
                              · {confidenceLabel}
                            </span>
                          )}
                        </div>
                        <div className="mt-1.5 flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              setOpenPickerIdx(
                                openPickerIdx === i ? null : i,
                              )
                            }
                            disabled={b.skip}
                            className={`inline-flex items-center gap-1 rounded-full border border-[#1d1b18]/20 px-2.5 py-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.4px] text-[#1d1b18] transition-colors hover:border-[#97472c] hover:text-[#97472c] disabled:opacity-40`}
                          >
                            {b.matchedKey ? t.pickerChange : t.pickerPick}
                          </button>
                          {needsConfirm && (
                            <button
                              type="button"
                              onClick={() =>
                                updateBiomarker(i, "confirmed", true)
                              }
                              className={`inline-flex items-center gap-1 rounded-full bg-[#97472c] px-2.5 py-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.4px] text-[#f7f1e8] transition-colors hover:bg-[#7d3a23]`}
                            >
                              {t.needsConfirmTap}
                            </button>
                          )}
                          {!needsConfirm &&
                            b.matchedKey &&
                            !b.skip &&
                            !b.implausible && (
                              <span
                                className={`inline-flex items-center gap-1 rounded-full bg-[rgba(58,102,94,0.14)] px-2 py-0.5 ${FONT_CLASS.dmMono} text-[9px] font-semibold uppercase tracking-[1.2px] text-[#3a665e]`}
                              >
                                <span
                                  aria-hidden
                                  className="inline-block h-1 w-1 rounded-full bg-[#3a665e]"
                                />
                                {t.confirmedTag}
                              </span>
                            )}
                          {b.implausible && !b.skip && (
                            <button
                              type="button"
                              onClick={() => {
                                updateBiomarker(i, "implausible", false);
                                updateBiomarker(i, "confirmed", true);
                              }}
                              className={`inline-flex items-center gap-1 rounded-full bg-[#b04040] px-2.5 py-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.4px] text-[#f7f1e8] transition-colors hover:bg-[#933333]`}
                            >
                              {t.implausibleTag} · {t.needsConfirmTap}
                            </button>
                          )}
                        </div>
                        {openPickerIdx === i && (
                          <div className="mt-2 rounded-[12px] border border-[#1d1b18]/15 bg-[#fbf6ee] p-3 shadow-[0_18px_50px_-12px_rgba(29,27,24,0.18)]">
                            <input
                              type="text"
                              autoFocus
                              value={pickerQuery}
                              onChange={(e) => setPickerQuery(e.target.value)}
                              placeholder={t.pickerSearch}
                              className={`w-full border-b border-[#1d1b18]/25 bg-transparent py-1 ${FONT_CLASS.manrope} text-[13px] text-[#1d1b18] outline-none focus:border-[#97472c]`}
                            />
                            <ul className="mt-2 max-h-56 overflow-y-auto">
                              {pickerSuggestions.length === 0 && (
                                <li
                                  className={`px-1 py-2 ${FONT_CLASS.manrope} text-[12px] italic text-[#8a7f76]`}
                                >
                                  {t.pickerEmpty}
                                </li>
                              )}
                              {pickerSuggestions.map((ref) => (
                                <li key={ref.biomarker_key}>
                                  <button
                                    type="button"
                                    onClick={() => selectMarker(i, ref)}
                                    className={`flex w-full items-baseline justify-between gap-3 rounded-md px-2 py-1.5 text-left transition-colors hover:bg-[rgba(151,71,44,0.08)]`}
                                  >
                                    <span
                                      className={`${FONT_CLASS.manrope} text-[13px] text-[#1d1b18]`}
                                    >
                                      {profileLocale === "es" ? ref.name_es : ref.name_en}
                                    </span>
                                    {ref.unit_en && (
                                      <span
                                        className={`${FONT_CLASS.dmMono} text-[9.5px] uppercase tracking-[1.2px] text-[#8a7f76]`}
                                      >
                                        {ref.unit_en}
                                      </span>
                                    )}
                                  </button>
                                </li>
                              ))}
                            </ul>
                            <button
                              type="button"
                              onClick={() => {
                                setOpenPickerIdx(null);
                                setPickerQuery("");
                              }}
                              className={`mt-2 ${FONT_CLASS.dmMono} text-[9.5px] uppercase tracking-[1.4px] text-[#8a7f76] hover:text-[#1d1b18]`}
                            >
                              {t.pickerClose}
                            </button>
                          </div>
                        )}
                      </div>
                      <label className="flex items-center justify-end gap-2 self-center">
                        <input
                          type="checkbox"
                          checked={b.skip}
                          onChange={(e) =>
                            updateBiomarker(i, "skip", e.target.checked)
                          }
                          className="h-4 w-4 rounded border-[#1d1b18]/30 text-[#97472c] focus:ring-[#97472c]"
                        />
                        <span
                          className={`${FONT_CLASS.dmMono} text-[9.5px] uppercase tracking-[1.4px] text-[#8a7f76] md:hidden`}
                        >
                          {t.colSkip}
                        </span>
                      </label>
                    </div>
                  );
                })}
              </div>

              {/* End-of-Review CTA: advance into the Context chapter.
                  The button is disabled until every biomarker row is
                  either skipped or confirmed — same gating as before,
                  just relocated. */}
              <div className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-3">
                <PrimaryPill
                  onClick={() => {
                    setStep(3);
                    if (typeof window !== "undefined") {
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }
                  }}
                  disabled={readyCount === 0 || needsActionCount > 0}
                >
                  {t.continueToContext}
                </PrimaryPill>
                {needsActionCount > 0 ? (
                  <p
                    className={`${FONT_CLASS.manrope} text-[12px] italic leading-[1.4] text-[#c49332]`}
                  >
                    {t.confirmBlockedReason}
                  </p>
                ) : readyCount > 0 ? (
                  <p
                    className={`${FONT_CLASS.manrope} text-[12px] italic leading-[1.4] text-[#8a7f76]`}
                  >
                    {t.continueToContextHint}
                  </p>
                ) : null}
              </div>
            </motion.section>
          )}

          {/* Rule 4 — Context chapter. Renders as a discrete step after
              Review so the user is on a single-task screen for the
              introspective questions instead of answering them with a
              wall of biomarker numbers competing for attention. */}
          {step === 3 && (
            <motion.section
              variants={fadeUp}
              className="mt-10 grid gap-10 md:mt-16 md:grid-cols-12 md:gap-10"
            >
              <div className="md:col-span-5">
                <SectionHeader
                  kicker={t.kickerContext}
                  title={t.contextTitle}
                  accent={t.contextAccent}
                  subtitle={t.contextLede}
                />
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className={`mt-6 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
                >
                  {t.backToReview}
                </button>
              </div>

              <div className="md:col-span-7">
                <PatientContextGate
                  profileLocale={profileLocale}
                  userSex={userSex}
                  onConfirm={async (versionId, transient) => {
                    setContextVersionId(versionId);
                    setTransientContext(transient);
                  }}
                />

                <div className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-3">
                  <PrimaryPill
                    onClick={handleConfirm}
                    loading={confirming}
                    disabled={confirming || !contextVersionId}
                  >
                    {confirming ? t.confirming : t.confirmCta}
                  </PrimaryPill>
                  {!contextVersionId && (
                    <p
                      className={`${FONT_CLASS.manrope} text-[12px] italic leading-[1.4] text-[#8a7f76]`}
                    >
                      {locale === "es"
                        ? "Confirma tu contexto arriba para activar el guardado."
                        : "Confirm your context above to enable save."}
                    </p>
                  )}
                </div>
              </div>
            </motion.section>
          )}

          {/* Inline error toast */}
          {error && (
            <div
              role="alert"
              className="mt-10 flex items-start gap-3 rounded-[16px] border border-[#b04040]/30 bg-[#fef8f2] p-4 shadow-[0_18px_50px_-12px_rgba(176,64,64,0.30)]"
            >
              <span
                aria-hidden
                className="mt-1 inline-block h-2 w-2 shrink-0 rounded-full bg-[#b04040]"
              />
              <div
                className={`flex-1 ${FONT_CLASS.manrope} text-[13px] leading-[1.5] text-[#1d1b18]`}
              >
                {error}
              </div>
              <button
                type="button"
                onClick={() => setError(null)}
                className="-m-1 p-1 text-[#8a7f76] transition-colors hover:text-[#1d1b18]"
                aria-label={t.dismiss}
              >
                <svg
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          )}

          <div className="h-12 md:h-20" />
        </div>
      </div>
    </DashboardChrome>
  );
}
