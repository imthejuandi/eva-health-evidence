import { NextRequest, NextResponse } from "next/server";
import { opsAlert } from "@/lib/ops-alert";
import { enqueueOmlForCycle } from "@/lib/lab-bridge/outbox";
import { patientReadiness, type PatientProfileSlice } from "@/lib/lab-bridge/patient-mapper";
import { panelIsOrderable, panelCodesFor, processingIdFromEnv } from "@/lib/lab-bridge/panel-codes";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { sendEmail } from "@/lib/email/send";
import { panels } from "@/config/panels";
import { validateAdminAction, type AdminCycleAction } from "@/lib/cycles/transitions";

/**
 * Fulfillment desk API (F5): the ADMIN slice of the test_cycles state
 * machine. Explicit actions with required payloads — the route cannot be
 * driven any→any (the defect the legacy bookings panel had), transitions are
 * validated server-side against the CURRENT status, values are PERSISTED
 * (the legacy panel emailed the tracking number and then dropped it), emails
 * fire only on real transitions, and every mutation lands in admin_audit_log
 * with its values.
 */

const BodySchema = z.object({
  cycleId: z.string().uuid(),
  action: z.enum(["assign_kit", "ship", "reopen", "cancel", "complete"]),
  /** Echevarne sticker code — scanner-as-keyboard input (assign_kit). */
  kitLabelCode: z.string().trim().min(3).max(64).nullish(),
  /** DHL tracking pasted from the portal (ship). */
  trackingNumber: z.string().trim().min(4).max(64).nullish(),
  trackingUrl: z.string().trim().url().max(500).nullish(),
});

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const supabase = createAdminClient();
  if (!supabase) return NextResponse.json({ error: "Server misconfigured" }, { status: 503 });

  const parsed = BodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid request", details: parsed.error.issues },
      { status: 400 },
    );
  }
  const { cycleId, action, kitLabelCode, trackingNumber, trackingUrl } = parsed.data;

  const { data: cycle, error: fetchError } = await supabase
    .from("test_cycles")
    .select(
      "id, user_id, seq, panel_type, status, due_date, kit_label_code, dhl_tracking_out, profiles:user_id ( id, patient_number, first_name, last_name, second_surname, full_name, email, locale, phone, date_of_birth, sex, id_document_type, id_document_number )",
    )
    .eq("id", cycleId)
    .single();
  if (fetchError || !cycle) {
    return NextResponse.json(
      { error: fetchError?.message ?? "Cycle not found" },
      { status: 404 },
    );
  }

  const previousStatus = cycle.status as string;
  const verdict = validateAdminAction(action as AdminCycleAction, previousStatus, {
    kitLabelCode,
    trackingNumber,
  });
  if (!verdict.ok) {
    return NextResponse.json({ error: verdict.error }, { status: 409 });
  }

  // Shipping gate: the initial OML to Echevarne goes out at dispatch (hybrid
  // timing), so everything the order needs must exist NOW — a complete PID
  // (document, both surnames, birth date, sex) and a configured panel. A kit
  // that ships without an order arrives at the lab as a manual reception →
  // no results through the integration. Ops cannot fix a profile; the
  // patient must complete it.
  if (action === "ship") {
    const prof = (Array.isArray(cycle.profiles) ? cycle.profiles[0] : cycle.profiles) as
      | PatientProfileSlice
      | null
      | undefined;
    const readiness: { ready: boolean; missing: string[] } = prof
      ? patientReadiness(prof)
      : { ready: false, missing: ["profile"] };
    if (!readiness.ready) {
      return NextResponse.json(
        {
          error: `Patient profile incomplete for the lab order (missing: ${readiness.missing.join(", ")}). The patient must complete it under Profile before this kit can ship.`,
          code: "PATIENT_NOT_READY",
          missing: readiness.missing,
        },
        { status: 422 },
      );
    }
    if (!panelIsOrderable(String(cycle.panel_type), panelCodesFor(processingIdFromEnv()))) {
      return NextResponse.json(
        {
          error: `Panel '${cycle.panel_type}' has no Echevarne order codes configured yet — the order cannot be built, so the kit must not ship.`,
          code: "PANEL_NOT_CONFIGURED",
        },
        { status: 422 },
      );
    }
  }

  const update: Record<string, unknown> = {
    status: verdict.to,
    updated_at: new Date().toISOString(),
  };
  if (action === "assign_kit") update.kit_label_code = kitLabelCode;
  if (action === "ship") update.dhl_tracking_out = trackingNumber;
  if (action === "reopen") update.kit_label_code = null; // free the sticker for a re-scan

  const { error: updateError } = await supabase
    .from("test_cycles")
    .update(update)
    .eq("id", cycleId)
    .eq("status", previousStatus); // optimistic guard vs concurrent admins
  if (updateError) {
    // 23505 → that sticker code is already bound to another cycle.
    if (updateError.code === "23505") {
      return NextResponse.json(
        { error: `Kit label '${kitLabelCode}' is already assigned to another cycle` },
        { status: 409 },
      );
    }
    return NextResponse.json({ error: updateError.message }, { status: 500 });
  }

  // Hybrid OML timing: the initial order leaves with the kit (estimated
  // extraction). Queued here; the bridge uploads it on its next pass. The
  // status already moved, so a failure here is alerted, never hidden.
  if (action === "ship") {
    try {
      await enqueueOmlForCycle(supabase, cycleId, "initial", new Date());
    } catch (e) {
      opsAlert("admin.cycles", "kit shipped but the initial OML could not be queued", {
        cycleId,
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  await logAdminAction({
    actor: admin,
    action: `cycle_${action}`,
    targetUserId: cycle.user_id,
    targetId: cycleId,
    detail: {
      previousStatus,
      status: verdict.to,
      // Persisted AND audited (the legacy panel lost these values entirely).
      ...(kitLabelCode ? { kitLabelCode } : {}),
      ...(trackingNumber ? { trackingNumber } : {}),
    },
  });

  // kit-shipped email — only on the real kit_assigned→shipped transition, so
  // re-clicks and undo/redo loops can't re-send it. Tracking is real now.
  if (action === "ship") {
    type ProfileSlice = {
      first_name: string | null;
      full_name: string | null;
      email: string | null;
      locale: string | null;
    };
    const rawProfile = cycle.profiles as ProfileSlice | ProfileSlice[] | null | undefined;
    const profile: ProfileSlice | null = Array.isArray(rawProfile)
      ? (rawProfile[0] ?? null)
      : (rawProfile ?? null);
    if (profile?.email) {
      const locale = profile.locale === "es" ? "es" : "en";
      const panelDef = panels[cycle.panel_type ?? "base"];
      const panelName = panelDef
        ? locale === "es"
          ? panelDef.name_es
          : panelDef.name
        : (cycle.panel_type ?? "base");
      sendEmail(
        profile.email,
        "kit-shipped",
        {
          firstName:
            profile.first_name ??
            profile.full_name?.split(" ")[0] ??
            (locale === "es" ? "Cliente" : "there"),
          panelName,
          trackingNumber: trackingNumber ?? null,
          trackingUrl:
            trackingUrl ??
            (trackingNumber
              ? `https://www.dhl.com/es-es/home/tracking.html?tracking-id=${encodeURIComponent(trackingNumber)}`
              : null),
          locale,
        },
        locale,
      ).catch((e) => console.error("[admin/cycles] kit-shipped email failed:", e));
    }
  }

  return NextResponse.json({ success: true, cycleId, previousStatus, status: verdict.to });
}
