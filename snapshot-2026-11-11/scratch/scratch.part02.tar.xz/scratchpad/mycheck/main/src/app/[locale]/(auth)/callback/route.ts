import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next"); // optional explicit redirect target (e.g. /es/reset-password)
  const locale = request.url.match(/\/(\w{2})\/callback/)?.[1] ?? "es";

  // We build the response lazily after the auth exchange so we can apply
  // the Set-Cookie headers directly to THIS response. Without this pattern,
  // cookies set via cookies() from next/headers do not reliably propagate
  // through NextResponse.redirect() in App Router route handlers.
  const cookiesToSet: Array<{ name: string; value: string; options: Record<string, unknown> }> = [];

  if (code) {
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return request.cookies.getAll();
          },
          setAll(cookies) {
            for (const c of cookies) {
              cookiesToSet.push({
                name: c.name,
                value: c.value,
                options: (c.options as unknown as Record<string, unknown>) ?? {},
              });
            }
          },
        },
      }
    );

    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      // OAuth signups can't carry consent metadata through signInWithOAuth,
      // so /signup forwards the recorded consents as query params and we
      // stamp them here (GDPR-003/013). First time only — the
      // `.is("terms_accepted_at", null)` filter means a stale/replayed URL
      // never overwrites the original consent timestamps. Best-effort like
      // the password flow's persistConsent.
      if (searchParams.get("consents") === "1") {
        const {
          data: { user: consentUser },
        } = await supabase.auth.getUser();
        if (consentUser) {
          const nowIso = new Date().toISOString();
          const consentUpdate: Record<string, unknown> = {
            terms_accepted_at: nowIso,
            privacy_accepted_at: nowIso,
            age_confirmed_at: nowIso,
          };
          if (searchParams.get("mkt") === "1") {
            consentUpdate.marketing_opt_in = true;
            consentUpdate.marketing_opt_in_at = nowIso;
          }
          const { error: consentError } = await supabase
            .from("profiles")
            .update(consentUpdate)
            .eq("id", consentUser.id)
            .is("terms_accepted_at", null);
          if (consentError) {
            console.error("[callback] Failed to stamp OAuth consents:", consentError);
          }
        }
      }

      let target: string;

      // If an explicit `next` was provided (e.g. password recovery),
      // honor it — but only if it's a same-origin absolute path to prevent
      // open redirects.
      if (next && next.startsWith("/") && !next.startsWith("//")) {
        target = `${origin}${next}`;
      } else {
        // Default: check onboarding status and route accordingly
        const {
          data: { user },
        } = await supabase.auth.getUser();

        let needsOnboarding = true;
        if (user) {
          const { data: profile } = await supabase
            .from("profiles")
            .select("onboarding_completed")
            .eq("id", user.id)
            .single();
          needsOnboarding = !profile || !profile.onboarding_completed;
        }

        target = needsOnboarding
          ? `${origin}/${locale}/onboarding`
          : `${origin}/${locale}/dashboard`;
      }

      const response = NextResponse.redirect(target);
      // Apply the auth cookies to THIS redirect response
      for (const c of cookiesToSet) {
        response.cookies.set(c.name, c.value, c.options);
      }
      return response;
    }
  }

  // Auth error — redirect to login
  return NextResponse.redirect(`${origin}/${locale}/login`);
}
