"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { panels } from "@/config/panels";
import {
  DashboardChrome,
  KitTimeline,
  ActivateKitForm,
  EditorialMasthead,
  PrimaryPill,
  GhostLink,
} from "@/components/dashboard";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import {
  yearRoman,
  quarterRoman,
  formatDayMonth,
} from "@/lib/dashboard-format";
import type { Profile, LabResult, BookedTest } from "@/lib/queries/types";

interface BookClientProps {
  locale: string;
  userId: string;
  profile: Profile | null;
  latestLab: LabResult | null;
  bookedTests: BookedTest[];
}

function getQuarterWindow(): { start: Date; end: Date; q: number; year: number } {
  const now = new Date();
  const q = Math.ceil((now.getMonth() + 1) / 3);
  const year = now.getFullYear();
  const startMonth = (q - 1) * 3;
  const start = new Date(year, startMonth, 1);
  const end = new Date(year, startMonth + 3, 0);
  return { start, end, q, year };
}

/* Inline AlmanacMasthead removed — uses shared EditorialMasthead. */

/* ──────────────────────────────────────────────────────────────────────
 * EditorialKickerHeader — kicker rail + Cormorant title with italic
 * accent + optional Manrope subtitle. Reused for every section.
 * ────────────────────────────────────────────────────────────────────── */
function SectionHeader({
  kicker,
  title,
  accent,
  subtitle,
  layout = "stacked",
}: {
  kicker: string;
  title: string;
  accent?: string;
  subtitle?: string;
  layout?: "stacked" | "split";
}) {
  return (
    <header
      className={`flex flex-col gap-3 ${
        layout === "split"
          ? "md:flex-row md:items-end md:justify-between md:gap-10"
          : ""
      }`}
    >
      <div className="flex items-center gap-3">
        <span aria-hidden className="inline-block h-px w-8 bg-[#1d1b18]/25 md:w-12" />
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]`}
        >
          {kicker}
        </p>
      </div>
      <h2
        className={`${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[56px] md:tracking-[-1px]`}
        style={{ textWrap: "balance" } as React.CSSProperties}
      >
        {title}{" "}
        {accent && <span className="italic text-[#97472c]">{accent}</span>}
      </h2>
      {subtitle && (
        <p
          className={`${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#8a7f76] md:text-[15px]`}
        >
          {subtitle}
        </p>
      )}
    </header>
  );
}

/* PrimaryPill + GhostLink now imported from @/components/dashboard. */

export function BookClient({
  locale,
  profile,
  bookedTests,
}: BookClientProps) {
  const [pendingPlan, setPendingPlan] = useState<"quarterly" | "annual" | "full_panel" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const subStatus = profile?.subscription_status ?? "free";
  const isActive = subStatus === "active";
  const isPastDue = subStatus === "past_due";
  const isCancelled = subStatus === "cancelled";
  const isFree = subStatus === "free";

  const quarter = getQuarterWindow();
  const startDayMonth = formatDayMonth(quarter.start.toISOString(), locale);
  const endDayMonth = formatDayMonth(quarter.end.toISOString(), locale);

  // Most recent live (non-cancelled) booking — drives the kit timeline.
  const activeBooking =
    [...bookedTests]
      .filter((b) => b.status !== "cancelled")
      .sort((a, b) =>
        (b.scheduled_date ?? "").localeCompare(a.scheduled_date ?? ""),
      )[0] ?? null;

  const t =
    locale === "es"
      ? {
          back: "Volver al panel",
          idDocMissing:
            "Nos falta tu documento de identidad. El laboratorio lo exige para registrar tu muestra y sin el no podemos enviar tu kit.",
          idDocCta: "Completar en mi perfil",
          // Hero — varies by state
          kickerFree: "§ Empezar",
          freeTitle: "Elige tu",
          freeAccent: "lectura.",
          freeLede:
            "Suscribete a la lectura trimestral o llevate un panel completo unico. Las dos opciones llegan a tu casa con todo lo necesario.",
          kickerActive: "§ Tu trimestre",
          activeAccent: "en curso.",
          activePeriodLabel: "Periodo",
          activeMember: "Miembro EVA Trimestral",
          renewsLabel: "Renueva el",
          kickerPastDue: "§ Pago pendiente",
          pastDueTitle: "Hay un pago",
          pastDueAccent: "que ajustar.",
          pastDueLede:
            "Tu suscripcion esta marcada como pendiente de pago. Actualiza tu metodo de pago para seguir recibiendo tus kits trimestrales.",
          kickerCancelled: "§ Pausada",
          cancelledTitle: "Tu suscripcion",
          cancelledAccent: "esta pausada.",
          cancelledLede:
            "Cuando quieras volver, tu historial sigue donde lo dejaste. Reactiva en un click.",
          // CTAs
          subscribeQuarterly: "Suscribirme · €99 / trimestre",
          subscribeAnnual: "O paga el año: 396 €/año",
          buyFullPanel: "Panel Completo · €499",
          reactivate: "Reactivar suscripcion",
          manageSub: "Gestionar suscripcion",
          // Section: dispatch in flight
          kickerDispatch: "§ I · El despacho",
          dispatchTitle: "El kit",
          dispatchAccent: "en camino.",
          dispatchSubtitle:
            "Sigue el progreso de tu lectura desde que se programa hasta que tienes los resultados.",
          noDispatchTitle: "Sin despacho",
          noDispatchAccent: "programado.",
          noDispatchBody:
            "Cuando renueves tu trimestre se programara automaticamente el siguiente kit.",
          // Section: add full panel
          kickerExtra: "§ II · Panel completo",
          extraTitle: "Anade una lectura",
          extraAccent: "completa.",
          extraLede:
            "120+ marcadores en una sola visita al laboratorio. Util como linea base, antes de un cambio importante o como extra al panel trimestral.",
          extraDetail1: "120+ marcadores",
          extraDetail2: "En laboratorio",
          extraDetail3: "Pago unico",
          extraCta: "Pedir el panel completo",
          // Section: specialty
          kickerSpecialty: "§ III · Especialidad",
          specialtyTitle: "Otros",
          specialtyAccent: "perfiles.",
          specialtySubtitle:
            "Hormonal, cardiovascular, tiroides y otros perfiles. Como cada panel se adapta al laboratorio, te damos un presupuesto a medida.",
          quote: "Pedir presupuesto",
          // Section: coming
          kickerComing: "§ IV · Proximamente",
          comingTitle: "Consultas con un",
          comingAccent: "medico.",
          comingBody:
            "Estamos creando una red de medicos enfocados en prevencion y longevidad. Pronto podras reservarles aqui mismo.",
          // Footer
          footerQuote: "La biologia premia la constancia.",
          footerAccent: "Vuelve cada trimestre.",
          backToDash: "Volver al panel",
          // Errors
          errorFallback: "No se pudo iniciar el checkout. Intentalo de nuevo.",
          dismiss: "Cerrar",
        }
      : {
          back: "Back to dashboard",
          idDocMissing:
            "We're missing your identity document. The lab requires it to register your sample, and we can't ship your kit without it.",
          idDocCta: "Complete it in my profile",
          kickerFree: "§ Begin",
          freeTitle: "Choose your",
          freeAccent: "reading.",
          freeLede:
            "Subscribe to the quarterly reading or take a one-time full panel. Both arrive at your door with everything you need.",
          kickerActive: "§ Your quarter",
          activeAccent: "in motion.",
          activePeriodLabel: "Period",
          activeMember: "EVA Quarterly Member",
          renewsLabel: "Renews",
          kickerPastDue: "§ Payment past due",
          pastDueTitle: "There's a payment",
          pastDueAccent: "to settle.",
          pastDueLede:
            "Your subscription is flagged as past due. Update your payment method to keep your quarterly kits coming.",
          kickerCancelled: "§ Paused",
          cancelledTitle: "Your subscription",
          cancelledAccent: "is paused.",
          cancelledLede:
            "Whenever you want to come back, your history is still here. Reactivate in one click.",
          subscribeQuarterly: "Subscribe · €99 / quarter",
          subscribeAnnual: "Or pay yearly: €396/year",
          buyFullPanel: "Full Panel · €499",
          reactivate: "Reactivate subscription",
          manageSub: "Manage subscription",
          kickerDispatch: "§ I · The dispatch",
          dispatchTitle: "Your kit,",
          dispatchAccent: "in transit.",
          dispatchSubtitle:
            "Follow your reading from the moment it's scheduled to the moment results land.",
          noDispatchTitle: "No dispatch",
          noDispatchAccent: "scheduled.",
          noDispatchBody:
            "Once your quarter renews, the next kit is scheduled automatically.",
          kickerExtra: "§ II · Full panel",
          extraTitle: "Add a complete",
          extraAccent: "reading.",
          extraLede:
            "120+ markers in a single in-lab visit. Useful as a baseline, before a major change, or layered on top of the quarterly panel.",
          extraDetail1: "120+ markers",
          extraDetail2: "In-lab",
          extraDetail3: "One-time",
          extraCta: "Order the full panel",
          kickerSpecialty: "§ III · Specialty",
          specialtyTitle: "Other",
          specialtyAccent: "profiles.",
          specialtySubtitle:
            "Hormone, cardiovascular, thyroid, and other profiles. Pricing varies by lab. We send you a tailored quote.",
          quote: "Request a quote",
          kickerComing: "§ IV · Coming next",
          comingTitle: "On-demand",
          comingAccent: "physicians.",
          comingBody:
            "We're building a network of prevention-focused doctors. Soon you'll be able to book them right here.",
          footerQuote: "Biology rewards consistency.",
          footerAccent: "Come back each quarter.",
          backToDash: "Back to dashboard",
          errorFallback: "Couldn't start checkout. Please try again.",
          dismiss: "Dismiss",
        };

  async function startCheckout(plan: "quarterly" | "annual" | "full_panel") {
    setPendingPlan(plan);
    setError(null);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale, plan }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.assign(data.url);
        return;
      }
      setError(data.error ?? t.errorFallback);
    } catch {
      setError(t.errorFallback);
    } finally {
      setPendingPlan(null);
    }
  }

  async function openPortal() {
    try {
      const res = await fetch("/api/stripe/portal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.assign(data.url);
        return;
      }
      setError(data.error ?? t.errorFallback);
    } catch {
      setError(t.errorFallback);
    }
  }

  const specialtyPanels = Object.values(panels).filter(
    (p) => p.id !== "base" && p.id !== "full",
  );

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1200px]">
          {/* ── Masthead + back ── */}
          <motion.div variants={fadeUp}>
            <EditorialMasthead issue={locale === "es" ? "El almanaque" : "The almanac"} withQuarter />
          </motion.div>

          <motion.div variants={fadeUp} className="mt-8">
            <Link
              href={`/${locale}/dashboard`}
              className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
            >
              <span aria-hidden>←</span>
              {t.back}
            </Link>
          </motion.div>

          {/* ── Hero — state-aware ── */}
          <motion.section
            variants={fadeUp}
            className="relative mt-10 md:mt-16"
          >
            {isFree && (
              <div className="grid gap-10 md:grid-cols-12 md:gap-10">
                <div className="md:col-span-7">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                  >
                    {t.kickerFree}
                  </p>
                  <h1
                    className={`mt-4 ${FONT_CLASS.cormorant} text-[64px] font-medium leading-[0.92] tracking-[-1.5px] text-[#1d1b18] md:text-[112px] md:tracking-[-4px]`}
                    style={{ textWrap: "balance" } as React.CSSProperties}
                  >
                    {t.freeTitle}{" "}
                    <span className="italic text-[#97472c]">{t.freeAccent}</span>
                  </h1>
                  <p
                    className={`mt-6 max-w-[52ch] ${FONT_CLASS.manrope} text-[16px] leading-[1.65] text-[#4c463f] md:text-[17px]`}
                    style={{ textWrap: "pretty" } as React.CSSProperties}
                  >
                    {t.freeLede}
                  </p>
                  <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
                    <PrimaryPill
                      onClick={() => startCheckout("quarterly")}
                      loading={pendingPlan === "quarterly"}
                      disabled={pendingPlan !== null}
                    >
                      {t.subscribeQuarterly}
                    </PrimaryPill>
                    <GhostLink onClick={() => startCheckout("annual")}>
                      {t.subscribeAnnual}
                    </GhostLink>
                    <GhostLink onClick={() => startCheckout("full_panel")}>
                      {t.buyFullPanel}
                    </GhostLink>
                  </div>
                </div>
              </div>
            )}

            {(isActive || isPastDue) && (
              <div className="grid gap-10 md:grid-cols-12 md:gap-10">
                <div className="md:col-span-7">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                  >
                    {isPastDue ? t.kickerPastDue : t.kickerActive}
                  </p>
                  {isPastDue ? (
                    <>
                      <h1
                        className={`mt-4 ${FONT_CLASS.cormorant} text-[56px] font-medium leading-[0.92] tracking-[-1.5px] text-[#1d1b18] md:text-[88px] md:tracking-[-3px]`}
                        style={{ textWrap: "balance" } as React.CSSProperties}
                      >
                        {t.pastDueTitle}{" "}
                        <span className="italic text-[#c49332]">
                          {t.pastDueAccent}
                        </span>
                      </h1>
                      <p
                        className={`mt-6 max-w-[52ch] ${FONT_CLASS.manrope} text-[16px] leading-[1.65] text-[#4c463f]`}
                      >
                        {t.pastDueLede}
                      </p>
                    </>
                  ) : (
                    <>
                      {/* Editorial date treatment for the active quarter */}
                      <div className="mt-4 flex items-baseline gap-3 md:gap-4">
                        <span
                          className={`${FONT_CLASS.cormorant} text-[88px] font-medium leading-none tabular-nums tracking-[-3px] text-[#1d1b18] md:text-[144px] md:tracking-[-5px]`}
                        >
                          Q{quarterRoman(quarter.start)}
                        </span>
                        <div className="min-w-0">
                          <p
                            className={`${FONT_CLASS.cormorant} text-[24px] font-medium italic leading-tight text-[#97472c] md:text-[32px]`}
                          >
                            {t.activeAccent}
                          </p>
                          <p
                            className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                          >
                            {yearRoman(quarter.year)}
                          </p>
                        </div>
                      </div>
                      <p
                        className={`mt-6 ${FONT_CLASS.manrope} text-[14px] uppercase tracking-[1.4px] text-[#8a7f76]`}
                      >
                        {t.activePeriodLabel} ·{" "}
                        <span className={`${FONT_CLASS.cormorant} normal-case tracking-normal text-[16px] italic text-[#1d1b18]`}>
                          {startDayMonth.day} {startDayMonth.month} –{" "}
                          {endDayMonth.day} {endDayMonth.month}
                        </span>
                      </p>
                    </>
                  )}
                </div>

                {/* Identity document nudge — the lab requires it on every
                    order and Ops cannot ship a kit without it. */}
                {(isActive || isPastDue) &&
                  !(profile?.id_document_type && profile?.id_document_number) && (
                    <div
                      role="alert"
                      className="md:col-span-12 rounded-[16px] border border-[#c49332]/40 bg-[rgba(196,147,50,0.08)] p-5"
                    >
                      <p className={`${FONT_CLASS.manrope} text-[13px] leading-[1.55] text-[#1d1b18]`}>
                        {t.idDocMissing}
                      </p>
                      <div className="mt-3">
                        <Link
                          href={`/${locale}/profile`}
                          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#97472c] underline underline-offset-4`}
                        >
                          {t.idDocCta}
                        </Link>
                      </div>
                    </div>
                  )}
                {/* Subscription card */}
                <div className="md:col-span-5 md:pt-2">
                  <div className="rounded-[20px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-6 backdrop-blur-sm">
                    <p
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] ${
                        isPastDue ? "text-[#c49332]" : "text-[#3a665e]"
                      }`}
                    >
                      {t.activeMember}
                    </p>
                    {profile?.subscription_period_end && (
                      <p
                        className={`mt-3 ${FONT_CLASS.cormorant} text-[20px] font-medium leading-tight text-[#1d1b18] md:text-[24px]`}
                      >
                        {t.renewsLabel}{" "}
                        <span className="italic text-[#97472c]">
                          {new Date(
                            profile.subscription_period_end,
                          ).toLocaleDateString(
                            locale === "es" ? "es-ES" : "en-GB",
                            { day: "numeric", month: "long", year: "numeric" },
                          )}
                        </span>
                      </p>
                    )}
                    <div className="mt-5">
                      <GhostLink onClick={openPortal}>{t.manageSub}</GhostLink>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {isCancelled && (
              <div className="grid gap-10 md:grid-cols-12 md:gap-10">
                <div className="md:col-span-8">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#b04040] md:text-[11px]`}
                  >
                    {t.kickerCancelled}
                  </p>
                  <h1
                    className={`mt-4 ${FONT_CLASS.cormorant} text-[56px] font-medium leading-[0.92] tracking-[-1.5px] text-[#1d1b18] md:text-[88px] md:tracking-[-3px]`}
                    style={{ textWrap: "balance" } as React.CSSProperties}
                  >
                    {t.cancelledTitle}{" "}
                    <span className="italic text-[#97472c]">
                      {t.cancelledAccent}
                    </span>
                  </h1>
                  <p
                    className={`mt-6 max-w-[52ch] ${FONT_CLASS.manrope} text-[16px] leading-[1.65] text-[#4c463f]`}
                  >
                    {t.cancelledLede}
                  </p>
                  <div className="mt-8">
                    <PrimaryPill
                      onClick={() => startCheckout("quarterly")}
                      loading={pendingPlan === "quarterly"}
                      disabled={pendingPlan !== null}
                    >
                      {t.reactivate}
                    </PrimaryPill>
                  </div>
                </div>
              </div>
            )}
          </motion.section>

          {/* ── § I — The dispatch (kit lifecycle) — only for paid users ── */}
          {(isActive || isPastDue) && (
            <>
              <div
                aria-hidden
                className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20"
              />
              <motion.section
                variants={fadeUp}
                className="grid gap-6 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-5 md:pt-2">
                  <SectionHeader
                    kicker={t.kickerDispatch}
                    title={activeBooking ? t.dispatchTitle : t.noDispatchTitle}
                    accent={
                      activeBooking ? t.dispatchAccent : t.noDispatchAccent
                    }
                    subtitle={
                      activeBooking ? t.dispatchSubtitle : undefined
                    }
                  />
                </div>
                <div className="md:col-span-7 md:pt-2">
                  {activeBooking ? (
                    <>
                      <KitTimeline booking={activeBooking} locale={locale} />
                      {activeBooking.cycle_id &&
                        ["kit_sent", "sample_received"].includes(activeBooking.status) && (
                          <ActivateKitForm
                            cycleId={activeBooking.cycle_id}
                            locale={locale}
                            extractionConfirmedAt={activeBooking.extraction_confirmed_at ?? null}
                          />
                        )}
                    </>
                  ) : (
                    <p
                      className={`${FONT_CLASS.cormorant} text-[22px] italic leading-[1.3] text-[#8a7f76] md:text-[26px]`}
                    >
                      {t.noDispatchBody}
                    </p>
                  )}
                </div>
              </motion.section>
            </>
          )}

          {/* ── § II — Add the full panel ── */}
          <div
            aria-hidden
            className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20"
          />
          <motion.section
            variants={fadeUp}
            className="relative grid gap-6 md:grid-cols-12 md:gap-10"
          >
            {/* Hanging chapter numeral */}
            <span
              aria-hidden
              className={`pointer-events-none absolute -top-6 right-2 select-none ${FONT_CLASS.cormorant} text-[120px] font-medium italic leading-[0.78] tabular-nums text-[#1d1b18]/[0.05] md:right-6 md:text-[200px]`}
            >
              02
            </span>
            <div className="relative md:col-span-5 md:pt-2">
              <SectionHeader
                kicker={t.kickerExtra}
                title={t.extraTitle}
                accent={t.extraAccent}
              />
            </div>
            <div className="relative md:col-span-7 md:pt-2">
              <p
                className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f] md:text-[16px]`}
                style={{ textWrap: "pretty" } as React.CSSProperties}
              >
                {t.extraLede}
              </p>
              <div className="mt-6 flex flex-wrap items-baseline gap-x-5 gap-y-2">
                {[t.extraDetail1, t.extraDetail2, t.extraDetail3].map(
                  (d, i) => (
                    <span
                      key={i}
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]`}
                    >
                      {d}
                    </span>
                  ),
                )}
              </div>
              <div className="mt-7">
                <PrimaryPill
                  onClick={() => startCheckout("full_panel")}
                  loading={pendingPlan === "full_panel"}
                  disabled={pendingPlan !== null}
                >
                  {t.extraCta} · €499
                </PrimaryPill>
              </div>
            </div>
          </motion.section>

          {/* ── § III — Specialty profiles ── */}
          <div
            aria-hidden
            className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20"
          />
          <motion.section variants={fadeUp}>
            <SectionHeader
              kicker={t.kickerSpecialty}
              title={t.specialtyTitle}
              accent={t.specialtyAccent}
              subtitle={t.specialtySubtitle}
              layout="split"
            />
            <motion.div
              variants={staggerTight}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: "-10%" }}
              className="mt-10 grid gap-3 sm:grid-cols-2 md:mt-14 md:gap-4 lg:grid-cols-3"
            >
              {specialtyPanels.map((panel, i) => {
                const name = locale === "es" ? panel.name_es : panel.name;
                const desc =
                  locale === "es" ? panel.description_es : panel.description;
                const num = String(i + 1).padStart(2, "0");
                return (
                  <motion.div key={panel.id} variants={fadeUp}>
                    <Link
                      href={`/${locale}/pricing#${panel.id}`}
                      className="group relative flex h-full min-h-[180px] flex-col overflow-hidden rounded-[16px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-5 backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:border-[#1d1b18]/30 hover:shadow-[0_18px_50px_-18px_rgba(151,71,44,0.30)]"
                    >
                      <span
                        aria-hidden
                        className={`pointer-events-none absolute -right-1 -top-3 select-none ${FONT_CLASS.cormorant} text-[80px] font-medium italic leading-[0.78] tabular-nums text-[#1d1b18]/[0.05] transition-colors group-hover:text-[#1d1b18]/[0.10]`}
                      >
                        {num}
                      </span>
                      <h3
                        className={`relative ${FONT_CLASS.cormorant} text-[24px] font-medium italic leading-[1.1] text-[#1d1b18] md:text-[28px]`}
                        style={{ textWrap: "balance" } as React.CSSProperties}
                      >
                        {name}
                      </h3>
                      <p
                        className={`relative mt-3 ${FONT_CLASS.manrope} text-[13px] leading-[1.55] text-[#4c463f]`}
                      >
                        {desc}
                      </p>
                      <div
                        className={`relative mt-auto pt-5 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c]`}
                      >
                        {t.quote}{" "}
                        <span
                          aria-hidden
                          className="ml-1 inline-block transition-transform group-hover:translate-x-0.5"
                        >
                          →
                        </span>
                      </div>
                    </Link>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.section>

          {/* ── § IV — Coming next (placeholder) ── */}
          <div
            aria-hidden
            className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20"
          />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-5">
              <SectionHeader
                kicker={t.kickerComing}
                title={t.comingTitle}
                accent={t.comingAccent}
              />
            </div>
            <div className="md:col-span-7 md:pt-2">
              <p
                className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] italic text-[#8a7f76] md:text-[16px]`}
              >
                {t.comingBody}
              </p>
            </div>
          </motion.section>

          {/* ── Footer pull-quote ── */}
          <div
            aria-hidden
            className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20"
          />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:items-end md:gap-10"
          >
            <div className="md:col-span-7">
              <h2
                className={`${FONT_CLASS.cormorant} text-[36px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[52px] md:tracking-[-1px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.footerQuote}{" "}
                <span className="italic text-[#97472c]">{t.footerAccent}</span>
              </h2>
            </div>
            <div className="md:col-span-5 md:pb-2">
              <Link
                href={`/${locale}/dashboard`}
                className={`${FONT_CLASS.manrope} text-[13px] font-medium text-[#4c463f] underline decoration-[#1d1b18]/20 underline-offset-[6px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/60`}
              >
                {t.backToDash} →
              </Link>
            </div>
          </motion.section>

          {/* Inline error toast */}
          {error && (
            <div
              role="alert"
              className="mt-10 flex items-start gap-3 rounded-[16px] border border-[#b04040]/30 bg-[#fef8f2] p-4 shadow-[0_18px_50px_-12px_rgba(176,64,64,0.30)]"
            >
              <span
                aria-hidden
                className="mt-1 inline-block h-2 w-2 shrink-0 rounded-full bg-[#b04040]"
              />
              <div
                className={`flex-1 ${FONT_CLASS.manrope} text-[13px] leading-[1.5] text-[#1d1b18]`}
              >
                {error}
              </div>
              <button
                type="button"
                onClick={() => setError(null)}
                className="-m-1 p-1 text-[#8a7f76] transition-colors hover:text-[#1d1b18]"
                aria-label={t.dismiss}
              >
                <svg
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          )}

          <div className="h-12 md:h-20" />
        </div>
      </div>
    </DashboardChrome>
  );
}
