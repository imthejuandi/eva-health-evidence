import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { z } from "zod";
import { getStripe } from "@/lib/stripe/helpers";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendEmail } from "@/lib/email/send";

// ─── Runtime validation for the slices of the Stripe event payload we
// actually consume. Stripe's own TS types cover the verified `event`
// object, but several of the nested fields we read (shipping_details,
// current_period_end, invoice line periods, subscription/billing_reason
// on Invoice) are either loosely typed or version-dependent on the SDK,
// so we narrow them at runtime instead of casting through `unknown`.
// Every field is `.optional()`/`.nullish()` because Stripe only sends
// what was collected — absence is expected, not an error. ───

const AddressSchema = z
  .object({
    line1: z.string().nullish(),
    line2: z.string().nullish(),
    city: z.string().nullish(),
    postal_code: z.string().nullish(),
    state: z.string().nullish(),
    country: z.string().nullish(),
  })
  .partial();

// checkout.session.completed: shipping address + phone collected via
// Stripe's shipping_address_collection / phone_number_collection.
const CheckoutShippingSchema = z
  .object({
    shipping_details: z
      .object({
        address: AddressSchema.nullish(),
        phone: z.string().nullish(),
      })
      .nullish(),
    customer_details: z
      .object({ phone: z.string().nullish() })
      .nullish(),
  })
  .partial();

// customer.subscription.updated: current_period_end is read off the
// subscription to stamp subscription_period_end.
const SubscriptionExtraSchema = z
  .object({
    current_period_end: z.number().int().positive().nullish(),
  })
  .partial();

// invoice.payment_succeeded / .payment_failed: we read whether the
// invoice belongs to a subscription, its billing_reason, and the first
// line item's period end.
const InvoiceExtraSchema = z
  .object({
    subscription: z.union([z.string(), z.object({}).passthrough()]).nullish(),
    billing_reason: z.string().nullish(),
    lines: z
      .object({
        data: z
          .array(
            z
              .object({
                period: z
                  .object({ end: z.number().int().positive().nullish() })
                  .nullish(),
              })
              .partial(),
          )
          .nullish(),
      })
      .nullish(),
  })
  .partial();

export async function POST(req: NextRequest) {
  const stripe = getStripe();
  const body = await req.text();
  const sig = req.headers.get("stripe-signature");

  if (!sig || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Missing signature" }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("[stripe/webhook] Signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  // Use the service-role client. A Stripe webhook carries no user session, so
  // the anon/SSR client runs as the `anon` role and RLS silently blocks every
  // profiles write — subscriptions would never actually activate. Service role
  // is the correct identity for a signature-verified webhook, and it is what
  // lets the billing-column guard (which rejects anon/authenticated writes to
  // subscription_status etc.) coexist with legitimate activation.
  const admin = createAdminClient();
  if (!admin) {
    console.error("[stripe/webhook] SUPABASE_SERVICE_ROLE_KEY not configured");
    return NextResponse.json({ error: "Server misconfigured" }, { status: 500 });
  }
  // Capture the narrowed (non-null) client so the nested helper and the event
  // handlers type-check without re-narrowing inside closures.
  const supabase = admin;

  // ── Event dedupe (at-least-once delivery). Stripe redelivers events; the
  // stripe_events table (migration 20260825*) records SUCCESSFULLY processed
  // event ids so a redelivery becomes a no-op instead of double-inserting
  // kits. Order matters: we check before processing and record only AFTER
  // success — recording upfront would make a failure + Stripe retry look like
  // a duplicate and silently drop the event. Tolerant of the table not
  // existing yet (migration pending behind OPS-004): logs and processes
  // without dedupe — same behavior as before.
  {
    const { data: seen, error: dedupeError } = await supabase
      .from("stripe_events")
      .select("id")
      .eq("id", event.id)
      .maybeSingle();
    if (dedupeError && dedupeError.code !== "42P01") {
      console.error("[stripe/webhook] stripe_events lookup failed:", dedupeError);
    }
    if (seen) {
      return NextResponse.json({ received: true, duplicate: true });
    }
  }

  async function getProfileByCustomer(customerId: string) {
    // Deliberately NOT .single(): stripe_customer_id has no UNIQUE constraint
    // yet (migration drafted), and .single() errors on duplicates — which used
    // to silently skip the event and desync entitlement. Take the oldest row
    // and alert loudly on duplicates instead.
    const { data, error } = await supabase
      .from("profiles")
      .select("id, email, full_name, locale")
      .eq("stripe_customer_id", customerId)
      .order("created_at", { ascending: true })
      .limit(2);
    if (error) {
      console.error("[stripe/webhook] profile lookup failed:", error);
      return null;
    }
    if (!data || data.length === 0) return null;
    if (data.length > 1) {
      console.error(
        `[stripe/webhook][ALERT] duplicate stripe_customer_id=${customerId} across profiles — using oldest row`,
      );
    }
    return data[0];
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.userId;
        const plan = session.metadata?.plan; // 'quarterly' | 'annual' | 'full_panel'
        if (userId) {
          // Build the update payload incrementally so we only write
          // fields we actually have data for.
          const update: Record<string, unknown> = {
            stripe_customer_id: session.customer as string,
          };

          // Recurring plans (quarterly/annual) grant "active" status and
          // record WHICH plan on the entitlement. Full Panel is a one-time
          // purchase and should NOT activate the subscription entitlement.
          if (plan === "quarterly" || plan === "annual") {
            update.subscription_status = "active";
            update.plan = plan;
          }

          // Full Panel is a paid plan even though it isn't recurring.
          // Stamp the purchase timestamp so paid-only features (EVA AI
          // chat, wearable imports) recognise the user as paying. Once
          // set, this column is never cleared: a Full Panel buyer keeps
          // access for life because there is no renewal cadence.
          if (plan === "full_panel") {
            update.full_panel_purchased_at = new Date().toISOString();
          }

          // Persist shipping address + phone collected via Stripe's
          // shipping_address_collection / phone_number_collection.
          // Stripe's TS type is loose here, so we narrow at runtime.
          const ship = CheckoutShippingSchema.parse(session);
          const addr = ship.shipping_details?.address;
          if (addr?.line1) update.address_line1 = addr.line1;
          if (addr?.line2) update.address_line2 = addr.line2;
          if (addr?.city) update.address_city = addr.city;
          if (addr?.postal_code) update.address_postal_code = addr.postal_code;
          if (addr?.state) update.address_province = addr.state;
          if (addr?.country) update.address_country = addr.country;
          const phone =
            ship.shipping_details?.phone ?? ship.customer_details?.phone ?? null;
          if (phone) update.phone = phone;

          const { error: profileError } = await supabase
            .from("profiles")
            .update(update)
            .eq("id", userId);
          if (profileError) {
            console.error("[stripe/webhook] entitlement update failed:", profileError);
            throw profileError; // 500 → Stripe retries
          }

          // Entitlement-only by design (target architecture rule 2): the
          // webhook records WHAT the user is entitled to; the cycle-scheduler
          // cron is the ONLY creator of test cycles/kits and sends the
          // booking-confirmed email when it creates one. No kit inserts here.
        }
        break;
      }

      case "customer.subscription.updated": {
        const sub = event.data.object as Stripe.Subscription;
        const profile = await getProfileByCustomer(sub.customer as string);
        if (profile) {
          const status = sub.status === "active" ? "active"
            : sub.status === "past_due" ? "past_due"
            : sub.status === "canceled" ? "cancelled"
            : "free";
          const update: Record<string, unknown> = { subscription_status: status };
          // Only stamp the period end when the payload actually carries one.
          // On newer Stripe API shapes current_period_end moved off the
          // subscription object; the old unconditional write nulled a valid
          // subscription_period_end on every update.
          const periodEnd =
            SubscriptionExtraSchema.parse(sub).current_period_end ?? null;
          if (periodEnd) {
            const endIso = new Date(periodEnd * 1000).toISOString();
            update.subscription_period_end = endIso;
            // Entitlement date the cycle-scheduler gates on (F2 column).
            update.paid_until = endIso.split("T")[0];
          } else {
            console.warn(
              "[stripe/webhook] subscription.updated without current_period_end — leaving stored period end untouched",
            );
          }
          await supabase.from("profiles").update(update).eq("id", profile.id);
        }
        break;
      }

      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        const profile = await getProfileByCustomer(sub.customer as string);
        if (profile) {
          await supabase.from("profiles").update({
            subscription_status: "cancelled",
            // Clear the stale renewal date so the UI stops showing
            // "renews on ..." for a dead subscription, and end the
            // entitlement window the scheduler gates on.
            subscription_period_end: null,
            paid_until: null,
            plan: null,
          }).eq("id", profile.id);
        }
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        const invExtra = InvoiceExtraSchema.parse(invoice);
        if (invExtra.subscription) {
          const profile = await getProfileByCustomer(invoice.customer as string);
          if (profile) {
            const periodEnd = invExtra.lines?.data?.[0]?.period?.end;
            const update: Record<string, unknown> = { subscription_status: "active" };
            if (periodEnd) {
              const endIso = new Date(periodEnd * 1000).toISOString();
              update.subscription_period_end = endIso;
              update.paid_until = endIso.split("T")[0];
            }
            await supabase.from("profiles").update(update).eq("id", profile.id);
            // Entitlement-only: extending paid_until IS the renewal action.
            // The cycle-scheduler reads it and creates the next kit cycle
            // when the cadence says it's due — never from this webhook.
          }
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const profile = await getProfileByCustomer(invoice.customer as string);
        if (profile) {
          await supabase.from("profiles").update({
            subscription_status: "past_due",
          }).eq("id", profile.id);
          // Fix: the payment-failed template existed but had zero call
          // sites — users were never told their card bounced.
          if (profile.email) {
            const locale = profile.locale ?? "es";
            sendEmail(
              profile.email,
              "payment-failed",
              { firstName: profile.full_name?.split(" ")[0] ?? "", locale },
              locale,
            ).catch((err) =>
              console.error("[stripe/webhook] payment-failed email failed:", err),
            );
          }
        }
        break;
      }
    }
  } catch (e) {
    // Event processing failed (DB error, malformed/unexpected payload
    // slice, etc.). Return 500 so Stripe retries the delivery. Profile
    // writes are idempotent updates; kit inserts are deduped by the
    // stripe_events guard above once its migration is applied.
    // Returning 200 here would tell Stripe "success", stop retries, and
    // let entitlements silently drift out of sync with the payment state
    // (user pays but stays `free`, or a cancellation is never applied).
    console.error("[stripe/webhook] Handler error:", e);
    return NextResponse.json(
      { error: "Webhook handler failed" },
      { status: 500 },
    );
  }

  // Reached only after the event was processed successfully — record the id
  // so redeliveries of this event become no-ops. Best-effort: a failed insert
  // (or missing table pre-migration) only means one redelivery re-runs the
  // idempotent profile updates.
  {
    const { error: recordError } = await supabase
      .from("stripe_events")
      .insert({ id: event.id, type: event.type });
    if (recordError && recordError.code !== "42P01" && recordError.code !== "23505") {
      console.error("[stripe/webhook] stripe_events record failed:", recordError);
    }
  }

  return NextResponse.json({ received: true });
}
