import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { calculateAge } from "@/lib/biomarkers/zone-classifier";

/**
 * GET /api/biomarker-references
 *
 * Returns the list of canonical biomarkers the signed-in user can pick
 * from when manually mapping an extracted-but-unrecognized row in the
 * upload review step. The list is narrowed by the user's sex and age
 * so they never see a male-only marker as a female user (and vice
 * versa). Multiple age-group rows for the same key collapse into one
 * entry — the picker only needs the key, display name and canonical
 * unit, not the range itself.
 *
 * Response shape: { references: Array<{ biomarker_key, name_en, name_es, unit_en, panel_category }> }
 */
export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("date_of_birth, sex")
    .eq("id", user.id)
    .single();

  if (profileError || !profile) {
    return NextResponse.json({ error: "Profile not found" }, { status: 404 });
  }
  if (!profile.date_of_birth || !profile.sex) {
    return NextResponse.json(
      { error: "Please complete your profile (date of birth and sex)." },
      { status: 400 }
    );
  }

  const age = calculateAge(profile.date_of_birth);
  if (isNaN(age)) {
    return NextResponse.json(
      { error: "Invalid date_of_birth on profile." },
      { status: 400 }
    );
  }

  const sex = profile.sex.toLowerCase();

  const { data: rows, error: refsError } = await supabase
    .from("biomarker_references")
    .select("biomarker_key, name_en, name_es, unit_en, sex, age_group_en, panel_category")
    .in("sex", [sex, "both"]);

  if (refsError) {
    return NextResponse.json({ error: refsError.message }, { status: 500 });
  }

  // Collapse to one row per biomarker_key. Prefer the row whose
  // age_group_en contains the user's age; fall back to the first row
  // for keys whose age_group format we can't parse.
  const byKey = new Map<string, typeof rows[number]>();
  for (const row of rows ?? []) {
    const existing = byKey.get(row.biomarker_key);
    if (!existing) {
      byKey.set(row.biomarker_key, row);
      continue;
    }
    const existingMatches = ageGroupContains(existing.age_group_en, age);
    const candidateMatches = ageGroupContains(row.age_group_en, age);
    if (candidateMatches && !existingMatches) {
      byKey.set(row.biomarker_key, row);
    } else if (candidateMatches && row.sex === sex && existing.sex !== sex) {
      // Both match age; prefer the sex-specific row over "both"
      byKey.set(row.biomarker_key, row);
    }
  }

  const references = Array.from(byKey.values())
    .map((r) => ({
      biomarker_key: r.biomarker_key,
      name_en: r.name_en,
      name_es: r.name_es,
      unit_en: r.unit_en,
      panel_category: r.panel_category,
    }))
    .sort((a, b) => a.name_en.localeCompare(b.name_en));

  return NextResponse.json({ references });
}

function ageGroupContains(ageGroup: string | null | undefined, age: number): boolean {
  if (!ageGroup || !Number.isFinite(age)) return false;
  const str = ageGroup.toLowerCase().trim();
  if (
    str === "all adults" ||
    str === "all ages" ||
    str === "adult" ||
    str === "adults" ||
    str.startsWith("premenopausal") ||
    str.startsWith("postmenopausal") ||
    str.startsWith("perimenopausal") ||
    str.includes("luteal") ||
    str.includes("follicular") ||
    str.includes("ovulatory")
  ) {
    return age >= 18;
  }
  const rangeMatch = str.match(/(\d{1,3})\s*(?:-|–|to|a)\s*(\d{1,3})/);
  if (rangeMatch) {
    const low = Number(rangeMatch[1]);
    const high = Number(rangeMatch[2]);
    return age >= low && age <= high;
  }
  const openEnd = str.match(/(\d{1,3})\s*\+/)
    || str.match(/(\d{1,3})\s*(?:and|or)\s*(?:over|older|más)/)
    || str.match(/(?:over|mayor)\s*(?:de\s*)?(\d{1,3})/);
  if (openEnd) return age >= Number(openEnd[1]);
  const openStart = str.match(/(?:under|below|menor\s*(?:de)?)\s*(\d{1,3})/);
  if (openStart) return age < Number(openStart[1]);
  return false;
}
