"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import { useParams } from "next/navigation";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const params = useParams();
  const locale = (params.locale as string) ?? "es";

  const t = locale === "es"
    ? {
        title: "Restablecer contraseña",
        subtitle: "Te enviaremos un enlace para crear una nueva contraseña.",
        email: "Correo electrónico",
        placeholder: "tu@ejemplo.com",
        sendLink: "Enviar enlace de recuperación",
        checkEmail: "Revisa tu correo para restablecer tu contraseña",
        backToLogin: "Volver a iniciar sesión",
      }
    : {
        title: "Reset your password",
        subtitle: "We'll send you a link to create a new password.",
        email: "Email",
        placeholder: "you@example.com",
        sendLink: "Send reset link",
        checkEmail: "Check your email to reset your password",
        backToLogin: "Back to sign in",
      };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const supabase = createClient();
    // Send the user DIRECTLY to the reset-password page. It handles the
    // PKCE code / token_hash exchange itself on the client, which is more
    // reliable than bouncing through the /callback route handler.
    const { error: authError } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/${locale}/reset-password`,
    });

    if (authError) {
      setError(authError.message);
    } else {
      setSubmitted(true);
    }
    setLoading(false);
  }

  if (submitted) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg text-center">
          <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-gradient-to-br from-[#C4704B] to-[#A0522D] flex items-center justify-center">
            <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <p className="text-lg font-medium text-[#1a1a2e]">{t.checkEmail}</p>
          <Link
            href={`/${locale}/login`}
            className="mt-4 inline-block text-sm font-medium text-[#C4704B] hover:underline"
          >
            {t.backToLogin}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold text-[#1a1a2e]">{t.title}</h1>
          <p className="mt-2 text-sm text-gray-500">{t.subtitle}</p>
        </div>

        {error && (
          <div
            id="form-error"
            role="alert"
            className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-600"
          >
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              {t.email}
            </label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t.placeholder}
              required
              aria-invalid={!!error}
              aria-describedby="form-error"
              className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-gradient-to-r from-[#C4704B] to-[#A0522D] px-4 py-3 font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "..." : t.sendLink}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-500">
          <Link
            href={`/${locale}/login`}
            className="font-medium text-[#C4704B] hover:underline"
          >
            {t.backToLogin}
          </Link>
        </p>
      </div>
    </div>
  );
}
