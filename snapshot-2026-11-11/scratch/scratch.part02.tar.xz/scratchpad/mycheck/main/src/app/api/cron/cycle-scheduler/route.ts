import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendEmail } from "@/lib/email/send";
import { opsAlert, opsOk } from "@/lib/ops-alert";
import {
  decideNextCycle,
  STUCK_THRESHOLDS,
  type SchedulerCycle,
  type SchedulerProfile,
} from "@/lib/cycles/scheduler";
import { sweepCompletableCycles } from "@/lib/cycles/close-cycle";

/**
 * Cycle-scheduler cron (F4) — THE only creator of test cycles.
 *
 * Runs the golden rule: "entitlement covers the date AND a cycle is due AND
 * no cycle is open → create it". Payments never create kits (the Stripe
 * webhook is entitlement-only); this cron closes the loop for quarterly AND
 * annual plans identically, plus one-time Full Panel purchases.
 *
 * ⏰ CADENCE REMINDER (decision 2026-08-25): scheduled DAILY in vercel.json
 * because the team stays on Vercel Hobby until the Echevarne connection goes
 * live. When the account upgrades to Pro (planned at go-live), flip the
 * vercel.json schedule to every 15–60 min — no code change needed here.
 *
 * Also runs the stuck-cycle alert sweep ([ALERT] lines for the log-drain /
 * ops): shipped-but-never-activated, order_sent-without-ACK, and
 * activated-without-result cycles.
 *
 * Auth: same fail-closed CRON_SECRET bearer as the auto-resolve cron.
 */

export const maxDuration = 60;

const BATCH_LIMIT = 100; // profiles per run — a backlog drains across runs

export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret) {
    console.error("[cron.cycle-scheduler] CRON_SECRET missing — refusing to run");
    return NextResponse.json({ error: "Not configured" }, { status: 503 });
  }
  // Constant-time compare to avoid a timing oracle on the cron secret.
  const provided = Buffer.from(req.headers.get("authorization") ?? "");
  const expected = Buffer.from(`Bearer ${secret}`);
  if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: "Admin client unavailable" }, { status: 503 });
  }

  const today = new Date().toISOString().split("T")[0];
  let created = 0;
  let skipped = 0;
  let errors = 0;
  const activeWithoutPlan: string[] = [];

  try {
    // Candidates: anyone whose entitlement could owe a cycle. The decision
    // function re-checks precisely; this query just bounds the scan.
    const { data: profiles, error: profilesError } = await admin
      .from("profiles")
      .select(
        "id, patient_number, email, full_name, locale, subscription_status, plan, paid_until, full_panel_purchased_at, next_panel_type",
      )
      .or("full_panel_purchased_at.not.is.null,and(subscription_status.eq.active,paid_until.not.is.null)")
      .limit(BATCH_LIMIT);
    if (profilesError) throw profilesError;

    for (const profile of profiles ?? []) {
      const { data: cycles, error: cyclesError } = await admin
        .from("test_cycles")
        .select("seq, status, panel_type, extraction_confirmed_at, created_at")
        .eq("user_id", profile.id);
      if (cyclesError) {
        errors++;
        opsAlert("cron.cycle-scheduler", "cycles read failed", {
          userId: profile.id,
          error: cyclesError.message,
        });
        continue;
      }

      const decision = decideNextCycle(
        profile as SchedulerProfile,
        (cycles ?? []) as SchedulerCycle[],
        today,
      );
      if (!decision.create) {
        skipped++;
        // A paying subscriber the scheduler cannot serve is never a silent skip.
        if (decision.reason === "not-entitled" && profile.subscription_status === "active" && !profile.plan) {
          activeWithoutPlan.push(profile.id);
        }
        continue;
      }

      const { error: insertError } = await admin.from("test_cycles").insert({
        user_id: profile.id,
        seq: decision.create.seq,
        panel_type: decision.create.panel_type,
        status: "awaiting_fulfillment",
        due_date: decision.create.due_date,
        placer_order_number: decision.create.placer_order_number,
      });
      if (insertError) {
        // 23505 = the one_open_cycle_per_user (or seq) unique index fired:
        // a concurrent run already created it — the constraint doing its job.
        if (insertError.code === "23505") {
          skipped++;
          continue;
        }
        errors++;
        opsAlert("cron.cycle-scheduler", "cycle insert failed", {
          userId: profile.id,
          error: insertError.message,
        });
        continue;
      }

      created++;
      // booking-confirmed moved here from the Stripe webhook: the cycle row
      // is the source of truth and this transition is its email.
      if (profile.email) {
        const locale = profile.locale ?? "es";
        const arrival = new Date();
        arrival.setDate(arrival.getDate() + 5); // kit arrives in ~5 days
        sendEmail(
          profile.email,
          "booking-confirmed",
          {
            firstName: profile.full_name?.split(" ")[0] ?? "",
            panelName: decision.create.panel_type,
            scheduledDate: arrival.toLocaleDateString(
              locale === "es" ? "es-ES" : "en-GB",
              { day: "numeric", month: "long", year: "numeric" },
            ),
            locale,
          },
          locale,
        ).catch((err) =>
          console.error("[cron.cycle-scheduler] booking-confirmed email failed:", err),
        );
      }
    }

    // ── Stuck-cycle sweep (alerts only; reminder EMAILS land with the
    // kit-reminder template in F5/F6 — tracked in the plan).
    const now = Date.now();
    const shippedCutoff = new Date(
      now - STUCK_THRESHOLDS.shippedNoActivation * 86_400_000,
    ).toISOString();
    const ackCutoff = new Date(
      now - STUCK_THRESHOLDS.orderSentNoAckHours * 3_600_000,
    ).toISOString();
    const resultCutoff = new Date(
      now - STUCK_THRESHOLDS.activatedNoResult * 86_400_000,
    ).toISOString();

    const [stuckShipped, stuckAck, stuckResult, errored] = await Promise.all([
      admin.from("test_cycles").select("id", { count: "exact", head: true })
        .eq("status", "shipped").lt("updated_at", shippedCutoff),
      admin.from("test_cycles").select("id", { count: "exact", head: true })
        .eq("status", "order_sent").lt("oml_sent_at", ackCutoff),
      admin.from("test_cycles").select("id", { count: "exact", head: true })
        .in("status", ["activated", "order_accepted", "results_partial"])
        .lt("updated_at", resultCutoff),
      admin.from("test_cycles").select("id", { count: "exact", head: true })
        .eq("status", "error"),
    ]);

    // Close cycles whose result has been interpreted (results_final →
    // completed) before counting what is stuck: an open cycle blocks the
    // next one, so this sweep is what lets a subscriber's second kit exist.
    const swept = await sweepCompletableCycles(admin).catch((e) => {
      opsAlert("cron.cycle-scheduler", "completion sweep failed", { error: e instanceof Error ? e.message : String(e) });
      return { completed: [] as string[], stuckWithoutResult: [] as string[] };
    });

    const stuck = {
      shippedNoActivation: stuckShipped.count ?? 0,
      orderSentNoAck: stuckAck.count ?? 0,
      awaitingResultTooLong: stuckResult.count ?? 0,
      inError: errored.count ?? 0,
      resultsFinalWithoutResult: swept.stuckWithoutResult.length,
    };
    if (Object.values(stuck).some((n) => n > 0)) {
      opsAlert("cron.cycle-scheduler", "stuck cycles need attention", { ...stuck, resultsFinalWithoutResultIds: swept.stuckWithoutResult });
    }
    if (activeWithoutPlan.length) {
      opsAlert("cron.cycle-scheduler", "active subscribers with no plan on their profile — no cycle can be scheduled for them", { count: activeWithoutPlan.length, userIds: activeWithoutPlan.slice(0, 50) });
    }

    opsOk("cron.cycle-scheduler", "run complete", { created, skipped, errors, completed: swept.completed.length, ...stuck });
    return NextResponse.json({ created, skipped, errors, completed: swept.completed.length, stuck });
  } catch (e) {
    opsAlert("cron.cycle-scheduler", "run failed", {
      error: e instanceof Error ? e.message : String(e),
    });
    return NextResponse.json({ error: "Scheduler run failed" }, { status: 500 });
  }
}
