import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#fef8f2] px-5 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#97472c] to-[#d97b5c] shadow-[0_12px_40px_rgba(151,71,44,0.15)]">
        <span className="font-[family-name:var(--font-manrope)] text-[28px] font-bold text-white">404</span>
      </div>
      <h1 className="mt-6 font-[family-name:var(--font-cormorant)] text-[36px] font-bold text-[#1d1b18]">Page not found</h1>
      <p className="mx-auto mt-3 max-w-md font-[family-name:var(--font-inter)] text-[15px] text-[#4c463f]">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex rounded-[100px] bg-gradient-to-br from-[#97472c] to-[#d97b5c] px-7 py-3.5 font-[family-name:var(--font-manrope)] text-[14px] font-bold text-white shadow-[0_12px_40px_rgba(151,71,44,0.2)] transition-all hover:-translate-y-0.5"
      >
        Go home
      </Link>
    </div>
  );
}
