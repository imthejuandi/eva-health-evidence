import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { BiomarkerDetailClient } from "./detail-client";

interface BiomarkerDetailProps {
  params: Promise<{ locale: string; key: string }>;
}

export default async function BiomarkerDetailPage({ params }: BiomarkerDetailProps) {
  const { locale, key } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/${locale}/login`);

  const profile = await getUserProfile(user.id);

  // Get all historical values for this biomarker across all lab results
  const { data: historicalValues } = await supabase
    .from("biomarker_values")
    .select("*, lab_results!inner(user_id, collection_date, source)")
    .eq("biomarker_key", key)
    .eq("lab_results.user_id", user.id)
    .order("created_at", { ascending: true });

  // Get the latest value (last in the sorted array)
  const latest = historicalValues && historicalValues.length > 0
    ? historicalValues[historicalValues.length - 1]
    : null;

  // Get reference range info
  const { data: reference } = await supabase
    .from("biomarker_references")
    .select("*")
    .eq("biomarker_key", key)
    .in("sex", [profile?.sex?.toLowerCase() ?? "both", "both"])
    .limit(1)
    .single();

  // Get wearable data for correlation
  const wearable = await getWearableData(user.id, 30);

  return (
    <BiomarkerDetailClient
      locale={locale}
      biomarkerKey={key}
      latest={latest}
      historicalValues={historicalValues ?? []}
      reference={reference}
      wearable={wearable}
    />
  );
}
