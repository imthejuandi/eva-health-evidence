import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { getUserProfile } from "@/lib/queries";
import { ProfileClient } from "./profile-client";

interface ProfilePageProps {
  params: Promise<{ locale: string }>;
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const { locale } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect(`/${locale}/login`);

  const profile = await getUserProfile(user.id);

  return (
    <ProfileClient
      locale={locale}
      email={user.email ?? ""}
      profile={profile}
    />
  );
}
