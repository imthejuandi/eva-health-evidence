"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { DashboardChrome, EditorialMasthead } from "@/components/dashboard";
// AI-safety surface (T2.4 / AI-001 / AI-011): point-of-use AI + medical
// notices. Imported separately so the existing component import stays
// untouched for the concurrent markdown-rendering PR (#38).
import { AiNotice, MedicalDisclaimer } from "@/components/dashboard";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import { yearRoman, quarterRoman } from "@/lib/dashboard-format";
import { paragraphsHTML } from "@/lib/markdown/eva-markdown";

/* Right-rail caption for the Consultation masthead. Captures the
 * current month + year + quarter at render time so the page always
 * reads with today's date — "MAY MMXXVI · QII" in May, "JUNE MMXXVI
 * · QII" in June, etc. */
function ConsultationVolCaption({ locale }: { locale: string }) {
  const now = new Date();
  const monthName = now
    .toLocaleDateString(locale === "es" ? "es-ES" : "en-GB", { month: "long" })
    .toUpperCase();
  return (
    <>
      {monthName}{" "}
      <span className="text-[#1d1b18]">{yearRoman(now.getFullYear())}</span>{" "}
      <span className="text-[#1d1b18]/40">·</span> Q{quarterRoman(now)}
    </>
  );
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  created_at?: string;
}

interface EvaAIClientProps {
  locale: string;
  initialMessages: Message[];
}

interface Suggestion {
  kicker: { en: string; es: string };
  question: { en: string; es: string };
  accent: string;
}

// Four prompts. The first is a deliberately general "give me the
// overview" question that works for any reader regardless of which
// markers they have on file — EVA composes a personalised response
// from whatever data exists. The remaining three target specific
// angles users tend to ask about.
const SUGGESTIONS: Suggestion[] = [
  {
    kicker: { en: "Overview", es: "Resumen" },
    question: {
      en: "Walk me through my latest reading",
      es: "Cuentame mi ultima lectura",
    },
    accent: "#97472c",
  },
  {
    kicker: { en: "Plan", es: "Plan" },
    question: {
      en: "What should I focus on this quarter?",
      es: "En que deberia enfocarme este trimestre?",
    },
    accent: "#3a665e",
  },
  {
    kicker: { en: "Biological age", es: "Edad biologica" },
    question: {
      en: "Explain my biological age",
      es: "Explicame mi edad biologica",
    },
    accent: "#c49332",
  },
  {
    kicker: { en: "Wearable", es: "Wearable" },
    question: {
      en: "How does my sleep affect my labs?",
      es: "Como afecta mi sueno a mis analisis?",
    },
    accent: "#d97b5c",
  },
];

/* Inline ConsultationMasthead removed — page now uses the shared
 * EditorialMasthead with `withQuarter` for the Vol. + quarter caption. */

/* ──────────────────────────────────────────────────────────────────────
 * SuggestionCard — bento-style prompt card. Hairline border, hanging
 * italic Cormorant numeral as a chapter glyph, accent kicker with a
 * hairline lead-in, italic Cormorant question, "Ask →" footer with a
 * sliding arrow.
 * ────────────────────────────────────────────────────────────────────── */
function SuggestionCard({
  kicker,
  question,
  accent,
  askLabel,
  onClick,
  index,
}: {
  kicker: string;
  question: string;
  accent: string;
  askLabel: string;
  onClick: () => void;
  index: number;
}) {
  const num = String(index + 1).padStart(2, "0");
  return (
    <motion.button
      type="button"
      variants={fadeUp}
      onClick={onClick}
      className="group relative flex h-full min-h-[130px] flex-col items-start justify-between overflow-hidden rounded-[16px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-4 text-left backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:border-[#1d1b18]/30 hover:shadow-[0_14px_40px_-18px_rgba(151,71,44,0.28)] md:min-h-[140px] md:p-5"
    >
      {/* Hanging serif numeral — chapter glyph (compact) */}
      <span
        aria-hidden
        className={`pointer-events-none absolute -right-1 -top-2 select-none ${FONT_CLASS.cormorant} text-[60px] font-medium italic leading-[0.78] tabular-nums text-[#1d1b18]/[0.06] transition-colors group-hover:text-[#1d1b18]/[0.10] md:text-[84px]`}
      >
        {num}
      </span>

      {/* Kicker + hairline lead */}
      <div className="relative flex items-center gap-2.5">
        <span
          aria-hidden
          className="h-px w-5"
          style={{ backgroundColor: accent, opacity: 0.55 }}
        />
        <p
          className={`${FONT_CLASS.dmMono} text-[9px] font-semibold uppercase tracking-[1.6px]`}
          style={{ color: accent }}
        >
          {kicker}
        </p>
      </div>

      {/* Italic Cormorant question */}
      <p
        className={`relative mt-3 max-w-[20ch] ${FONT_CLASS.cormorant} text-[17px] font-medium italic leading-[1.18] text-[#1d1b18] md:mt-3 md:text-[20px]`}
        style={{ textWrap: "balance" } as React.CSSProperties}
      >
        {question}
      </p>

      {/* Ask → footer */}
      <div
        className={`relative mt-3 flex items-center gap-1.5 ${FONT_CLASS.dmMono} text-[9px] font-semibold uppercase tracking-[1.4px] transition-colors`}
        style={{ color: accent }}
      >
        <span>{askLabel}</span>
        <svg
          aria-hidden
          className="h-2.5 w-2.5 transition-transform duration-300 group-hover:translate-x-1"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
          />
        </svg>
      </div>
    </motion.button>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * StreamCursor — terra ink-fill cursor pulses at the end of the
 * streaming response. Replaces the generic three-dot typing indicator.
 * ────────────────────────────────────────────────────────────────────── */
function StreamCursor() {
  return (
    <span
      aria-hidden
      className="ml-1 inline-block h-[1.05em] w-[6px] -translate-y-[2px] bg-[#97472c] align-middle [animation:inkPulse_1.2s_ease-in-out_infinite]"
    />
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * Presentation helpers. Markdown rendering moved to
 * @/lib/markdown/eva-markdown — model output is HTML-escaped before the
 * bold/italic/list pass, so it is XSS-safe for dangerouslySetInnerHTML.
 * ────────────────────────────────────────────────────────────────────── */
function formatTime(ts: string | undefined, locale: string): string {
  if (!ts) return "";
  const d = new Date(ts);
  return d.toLocaleTimeString(locale === "es" ? "es-ES" : "en-GB", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

/* ──────────────────────────────────────────────────────────────────────
 * MessageQ — the user's question. Mono "Q · 14:32" kicker, then the
 * question itself in serif italic Cormorant.
 * ────────────────────────────────────────────────────────────────────── */
function MessageQ({
  content,
  ts,
  locale,
}: {
  content: string;
  ts?: string;
  locale: string;
}) {
  const time = formatTime(ts, locale);
  return (
    <motion.article
      variants={fadeUp}
      className="grid gap-3 md:grid-cols-12 md:gap-8"
    >
      <div className="md:col-span-2 md:pt-2">
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#1d1b18]/70`}
        >
          Q{time && <span className="ml-2 text-[#8a7f76]">· {time}</span>}
        </p>
      </div>
      <div className="md:col-span-10">
        <p
          className={`${FONT_CLASS.cormorant} text-[22px] font-medium italic leading-[1.25] text-[#1d1b18] md:text-[28px] md:leading-[1.2]`}
          style={{ textWrap: "pretty" } as React.CSSProperties}
        >
          {content}
        </p>
      </div>
    </motion.article>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * MessageA — EVA's reply. Mono "EVA · 14:33" kicker, then a Manrope
 * prose stack (max 60ch) with the streaming cursor pinned to the end
 * while tokens are still landing.
 * ────────────────────────────────────────────────────────────────────── */
function MessageA({
  content,
  ts,
  isStreaming,
  locale,
}: {
  content: string;
  ts?: string;
  isStreaming: boolean;
  locale: string;
}) {
  const time = formatTime(ts, locale);
  const html = paragraphsHTML(content);
  return (
    <motion.article
      variants={fadeUp}
      className="grid gap-3 md:grid-cols-12 md:gap-8"
    >
      <div className="md:col-span-2 md:pt-1">
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
        >
          EVA{time && <span className="ml-2 text-[#8a7f76]">· {time}</span>}
        </p>
      </div>
      <div className="md:col-span-10">
        {content.length === 0 && isStreaming ? (
          <p
            className={`${FONT_CLASS.cormorant} text-[18px] italic leading-[1.4] text-[#8a7f76] md:text-[20px]`}
          >
            {locale === "es" ? "Pensando" : "Thinking"}
            <StreamCursor />
          </p>
        ) : (
          <div
            className={`eva-prose max-w-[60ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.7] text-[#1d1b18] md:text-[16px]`}
          >
            <div dangerouslySetInnerHTML={{ __html: html }} />
            {isStreaming && <StreamCursor />}
          </div>
        )}
      </div>
    </motion.article>
  );
}

export function EvaAIClient({ locale, initialMessages }: EvaAIClientProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const t =
    locale === "es"
      ? {
          back: "Volver al panel",
          kickerConsult: "§ La consulta",
          heroTitle: "Hola. Soy EVA.",
          heroAccent: "Tu lectura, en conversacion.",
          heroLede:
            "Pregunta sobre tus marcadores, tu plan o tu rutina. Las respuestas usan tu ultima lectura como contexto.",
          ask: "Pregunta",
          placeholder: "Pregunta a EVA sobre tu lectura...",
          send: "Enviar",
          errorMsg: "Lo siento, algo salio mal. Intentalo de nuevo.",
          composerHint: "Enter para enviar · Mayus + Enter para nueva linea",
        }
      : {
          back: "Back to dashboard",
          kickerConsult: "§ The consult",
          heroTitle: "Hi, I'm EVA.",
          heroAccent: "Your reading, in conversation.",
          heroLede:
            "Ask about your markers, your plan, or your routine. Answers always use your latest reading as context.",
          ask: "Ask",
          placeholder: "Ask EVA about your reading...",
          send: "Send",
          errorMsg: "Sorry, something went wrong. Please try again.",
          composerHint: "Enter to send · Shift + Enter for newline",
        };

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, []);

  useEffect(() => {
    if (messages.length > 0) scrollToBottom();
  }, [messages, scrollToBottom]);

  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || streaming) return;

      const now = new Date().toISOString();
      const userMsg: Message = {
        id: `u-${Date.now()}`,
        role: "user",
        content: text.trim(),
        created_at: now,
      };
      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setStreaming(true);

      const assistantId = `a-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: assistantId,
          role: "assistant",
          content: "",
          created_at: new Date().toISOString(),
        },
      ]);

      try {
        const res = await fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: text.trim() }),
        });
        if (!res.ok) throw new Error("Chat failed");

        const reader = res.body?.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        if (reader) {
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() ?? "";
            for (const line of lines) {
              if (!line.startsWith("data: ")) continue;
              const data = line.slice(6).trim();
              if (data === "[DONE]") break;
              try {
                const parsed = JSON.parse(data);
                if (parsed.text) {
                  setMessages((prev) =>
                    prev.map((m) =>
                      m.id === assistantId
                        ? { ...m, content: m.content + parsed.text }
                        : m,
                    ),
                  );
                }
              } catch {
                /* skip malformed */
              }
            }
          }
        }
      } catch {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId ? { ...m, content: t.errorMsg } : m,
          ),
        );
      }
      setStreaming(false);
      setTimeout(() => inputRef.current?.focus(), 0);
    },
    [streaming, t.errorMsg],
  );

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    sendMessage(input);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }

  const isEmpty = messages.length === 0;
  const lastAssistantId = [...messages]
    .reverse()
    .find((m) => m.role === "assistant")?.id;

  return (
    <DashboardChrome animate={false}>
      <div className="px-5 pt-8 pb-44 md:px-10 md:pt-14 md:pb-32">
        <div className="mx-auto max-w-[920px]">
          {/* Masthead */}
          <EditorialMasthead
              issue={locale === "es" ? "Consulta" : "Consultation"}
              volSuffix={<ConsultationVolCaption locale={locale} />}
            />

          {isEmpty ? (
            /* ── Empty state — compact hero + 4 prompt bento (1 viewport) ── */
            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="show"
              className="mt-6 md:mt-10"
            >
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
              >
                {t.kickerConsult}
              </p>
              <h1
                className={`mt-3 ${FONT_CLASS.cormorant} text-[40px] font-medium leading-[0.95] tracking-[-0.8px] text-[#1d1b18] md:text-[64px] md:tracking-[-2px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.heroTitle}{" "}
                <span className="italic text-[#97472c]">{t.heroAccent}</span>
              </h1>
              <p
                className={`mt-4 max-w-[44ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.55] text-[#4c463f] md:text-[15px]`}
                style={{ textWrap: "pretty" } as React.CSSProperties}
              >
                {t.heroLede}
              </p>

              {/* AI transparency notice (AI-011 / AI Act Art. 50) — at the
                  first interaction, make clear EVA is an AI, not a doctor. */}
              <AiNotice locale={locale} className="mt-5 max-w-[60ch]" />

              <motion.div
                variants={staggerTight}
                initial="hidden"
                animate="show"
                className="mt-7 grid grid-cols-2 gap-3 md:mt-9 md:grid-cols-4 md:gap-4"
              >
                {SUGGESTIONS.map((s, i) => (
                  <SuggestionCard
                    key={i}
                    index={i}
                    kicker={locale === "es" ? s.kicker.es : s.kicker.en}
                    question={
                      locale === "es" ? s.question.es : s.question.en
                    }
                    accent={s.accent}
                    askLabel={t.ask}
                    onClick={() =>
                      sendMessage(
                        locale === "es" ? s.question.es : s.question.en,
                      )
                    }
                  />
                ))}
              </motion.div>
            </motion.div>
          ) : (
            /* ── Transcript ── */
            <motion.div
              variants={staggerTight}
              initial="hidden"
              animate="show"
              className="mt-10 space-y-12 md:mt-16 md:space-y-16"
            >
              <div className="space-y-4">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                >
                  {t.kickerConsult}
                </p>
                {/* AI transparency notice (AI-011) kept visible above the
                    transcript while the user reads EVA's replies. */}
                <AiNotice locale={locale} className="max-w-[60ch]" />
              </div>

              {messages.map((msg, i) => {
                const isLastAssistant =
                  msg.role === "assistant" && msg.id === lastAssistantId;
                const previousRole = i > 0 ? messages[i - 1].role : null;
                const showRule = i > 0 && previousRole !== msg.role;
                return (
                  <div key={msg.id}>
                    {showRule && (
                      <div
                        aria-hidden
                        className="mb-12 h-px w-full bg-[#1d1b18]/8 md:mb-16"
                      />
                    )}
                    {msg.role === "user" ? (
                      <MessageQ
                        content={msg.content}
                        ts={msg.created_at}
                        locale={locale}
                      />
                    ) : (
                      <MessageA
                        content={msg.content}
                        ts={msg.created_at}
                        isStreaming={streaming && isLastAssistant}
                        locale={locale}
                      />
                    )}
                  </div>
                );
              })}
            </motion.div>
          )}

          {/* Point-of-use medical disclaimer (CLAIM-006 / AI-001) — quiet,
              secondary, at the foot of the reading column. */}
          <MedicalDisclaimer
            locale={locale}
            className="mt-12 border-t border-[#1d1b18]/8 pt-6 md:mt-16"
          />

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* ── Composer ── always at the bottom of the viewport above the
          mobile dock and to the right of the desktop sidebar. */}
      <div className="fixed bottom-20 left-0 right-0 z-30 px-4 pb-2 lg:bottom-0 lg:left-[72px] lg:px-10 lg:pb-6">
        <form
          onSubmit={handleSubmit}
          className="mx-auto max-w-[920px] rounded-[24px] border border-[#1d1b18]/12 bg-[#fef8f2]/95 p-2 shadow-[0_-4px_30px_-12px_rgba(151,71,44,0.20),0_18px_50px_-20px_rgba(29,27,24,0.18)] backdrop-blur-md transition-shadow focus-within:border-[#97472c]/40 focus-within:shadow-[0_-4px_30px_-12px_rgba(151,71,44,0.30),0_22px_60px_-22px_rgba(151,71,44,0.30)]"
        >
          <div className="flex items-end gap-2">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t.placeholder}
              aria-label={t.placeholder}
              disabled={streaming}
              rows={1}
              className={`flex-1 resize-none bg-transparent px-4 py-3 ${FONT_CLASS.manrope} text-[15px] text-[#1d1b18] outline-none placeholder:italic placeholder:text-[#8a7f76] disabled:opacity-60 md:py-3.5 md:text-[16px]`}
              style={{ minHeight: "48px", maxHeight: "180px" }}
            />
            <button
              type="submit"
              disabled={streaming || !input.trim()}
              aria-label={t.send}
              className="group relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#1d1b18] text-[#fef8f2] shadow-[0_8px_24px_-8px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0 md:h-12 md:w-12"
            >
              <svg
                className="h-4 w-4 transition-transform group-hover:translate-x-0.5 md:h-5 md:w-5"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                />
              </svg>
            </button>
          </div>
          <p
            className={`hidden px-4 pb-1 pt-0.5 ${FONT_CLASS.dmMono} text-[9.5px] uppercase tracking-[1.6px] text-[#8a7f76] md:block`}
          >
            {t.composerHint}
          </p>
        </form>
      </div>

      <style jsx global>{`
        @keyframes inkPulse {
          0%,
          100% {
            opacity: 1;
            transform: translateY(-2px) scaleY(1);
          }
          50% {
            opacity: 0.35;
            transform: translateY(-2px) scaleY(0.85);
          }
        }

        .eva-prose p {
          margin: 0 0 14px 0;
        }
        .eva-prose p:last-child {
          margin-bottom: 0;
        }
        .eva-prose strong {
          font-weight: 600;
          color: #1d1b18;
        }
        .eva-prose em {
          font-style: italic;
          color: #97472c;
        }
        .eva-prose ul {
          margin: 14px 0;
          padding-left: 0;
          list-style: none;
        }
        .eva-prose li {
          position: relative;
          margin-bottom: 8px;
          padding-left: 1.5em;
        }
        .eva-prose li::before {
          content: "—";
          position: absolute;
          left: 0;
          color: #97472c;
          font-weight: 500;
        }
      `}</style>
    </DashboardChrome>
  );
}
