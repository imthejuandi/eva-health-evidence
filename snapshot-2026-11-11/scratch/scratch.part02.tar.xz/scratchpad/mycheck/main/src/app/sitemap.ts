import type { MetadataRoute } from "next";

const BASE_URL = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
const LOCALES = ["es", "en"];

const MARKETING_PAGES = [
  "",
  "/about",
  "/how-it-works",
  "/pricing",
  "/science",
  "/contact",
  "/legal/privacy",
  "/legal/terms",
  "/legal/cookies",
];

export default function sitemap(): MetadataRoute.Sitemap {
  const entries: MetadataRoute.Sitemap = [];

  for (const page of MARKETING_PAGES) {
    for (const locale of LOCALES) {
      entries.push({
        url: `${BASE_URL}/${locale}${page}`,
        lastModified: new Date(),
        changeFrequency: page === "" ? "weekly" : "monthly",
        priority: page === "" ? 1.0 : page === "/pricing" ? 0.9 : 0.7,
        alternates: {
          languages: Object.fromEntries(LOCALES.map((l) => [l, `${BASE_URL}/${l}${page}`])),
        },
      });
    }
  }

  return entries;
}
