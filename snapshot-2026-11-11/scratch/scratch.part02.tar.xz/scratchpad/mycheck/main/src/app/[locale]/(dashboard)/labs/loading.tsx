import { SkeletonLabs } from "@/components/ui/Skeleton";
export default function LabsLoading() { return <SkeletonLabs />; }
