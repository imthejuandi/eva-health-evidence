"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import { useParams, useRouter, useSearchParams } from "next/navigation";

type Mode = "password" | "magic";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  // Consent gates. termsConsent = Terms of Service + Privacy Policy acceptance
  // (GDPR-003/013); healthConsent = SEPARATE, explicit Art. 9 special-category
  // health-data consent (kept granular per GDPR Art. 7(2)/(4) + Recital 43 —
  // deliberately NOT bundled into the Terms box); ageConfirm = the 18+ check
  // (LEG-008). All three REQUIRED. marketingOptIn is OPTIONAL (LEG-007).
  const [termsConsent, setTermsConsent] = useState(false);
  const [healthConsent, setHealthConsent] = useState(false);
  const [ageConfirm, setAgeConfirm] = useState(false);
  const [marketingOptIn, setMarketingOptIn] = useState(false);
  const [mode, setMode] = useState<Mode>("password");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const locale = (params.locale as string) ?? "es";

  // Carry the post-signup intent through the email-confirmation round
  // trip. Pricing redirects unauthenticated subscribe / buy clicks to
  // /signup?intent=quarterly|full_panel; we forward that to the auth
  // callback as `next=/checkout-resume?intent=…` so once the user
  // confirms their email they land on a tiny client component that
  // auto-fires checkout instead of dropping them on the dashboard.
  const intent = searchParams.get("intent");
  const intentIsValid = intent === "quarterly" || intent === "annual" || intent === "full_panel";
  const callbackUrl = (() => {
    if (typeof window === "undefined") return "";
    const base = `${window.location.origin}/${locale}/callback`;
    if (!intentIsValid) return base;
    const next = `/${locale}/checkout-resume?intent=${intent}`;
    return `${base}?next=${encodeURIComponent(next)}`;
  })();

  const t = locale === "es"
    ? {
        welcome: "Bienvenido a EVA Health",
        subtitle: "Comienza tu camino hacia la salud de precisión",
        email: "Correo electrónico",
        emailPlaceholder: "tu@ejemplo.com",
        password: "Contraseña",
        passwordPlaceholder: "Mínimo 8 caracteres",
        confirmPassword: "Confirmar contraseña",
        signup: "Registrarse",
        sendMagicLink: "Enviar enlace mágico",
        haveAccount: "¿Ya tienes cuenta?",
        login: "Iniciar sesión",
        checkEmailConfirm: "Revisa tu correo para confirmar tu cuenta",
        checkEmailMagic: "Revisa tu correo para el enlace mágico",
        // Terms + Privacy acceptance (GDPR-003/013). Rendered with the two
        // policy links interpolated between the surrounding fragments.
        termsConsentBefore: "He leído y acepto los ",
        termsLink: "Términos del Servicio",
        termsConsentMiddle: " y la ",
        privacyLink: "Política de Privacidad",
        termsConsentAfter: ".",
        termsRequired:
          "Debes aceptar los Términos y la Política de Privacidad para crear una cuenta",
        // Separate, explicit Art. 9 special-category health-data consent (GDPR-003).
        healthConsent:
          "Consiento de forma explícita que EVA Health trate mis datos de salud de categoría especial (Art. 9 RGPD), como se describe en la Política de Privacidad.",
        healthRequired:
          "Debes consentir el tratamiento de tus datos de salud para crear una cuenta",
        // 18+ age confirmation (LEG-008).
        ageConsent: "Confirmo que tengo 18 años o más.",
        ageRequired:
          "Debes confirmar que tienes 18 años o más para crear una cuenta",
        // Marketing opt-in (LEG-007) — optional.
        marketingConsent:
          "Quiero recibir consejos de salud, novedades y ofertas de EVA Health por correo electrónico. (Opcional — puedes darte de baja cuando quieras.)",
        passwordTooShort: "La contraseña debe tener al menos 8 caracteres",
        passwordMismatch: "Las contraseñas no coinciden",
        useMagicLink: "Registrarse con enlace mágico",
        usePassword: "Registrarse con contraseña",
        continueWithGoogle: "Continuar con Google",
        or: "o",
      }
    : {
        welcome: "Welcome to EVA Health",
        subtitle: "Start your precision health journey",
        email: "Email",
        emailPlaceholder: "you@example.com",
        password: "Password",
        passwordPlaceholder: "At least 8 characters",
        confirmPassword: "Confirm password",
        signup: "Sign up",
        sendMagicLink: "Send magic link",
        haveAccount: "Already have an account?",
        login: "Log in",
        checkEmailConfirm: "Check your email to confirm your account",
        checkEmailMagic: "Check your email for the magic link",
        // Terms + Privacy acceptance (GDPR-003/013). Rendered with the two
        // policy links interpolated between the surrounding fragments.
        termsConsentBefore: "I have read and accept the ",
        termsLink: "Terms of Service",
        termsConsentMiddle: " and the ",
        privacyLink: "Privacy Policy",
        termsConsentAfter: ".",
        termsRequired:
          "You must accept the Terms and Privacy Policy to create an account",
        // Separate, explicit Art. 9 special-category health-data consent (GDPR-003).
        healthConsent:
          "I explicitly consent to EVA Health processing my special-category health data (Art. 9 GDPR), as described in the Privacy Policy.",
        healthRequired:
          "You must consent to health-data processing to create an account",
        // 18+ age confirmation (LEG-008).
        ageConsent: "I confirm that I am 18 years of age or older.",
        ageRequired:
          "You must confirm you are 18 or older to create an account",
        // Marketing opt-in (LEG-007) — optional.
        marketingConsent:
          "I'd like to receive health tips, product news and offers from EVA Health by email. (Optional — you can unsubscribe any time.)",
        passwordTooShort: "Password must be at least 8 characters",
        passwordMismatch: "Passwords do not match",
        useMagicLink: "Sign up with magic link",
        usePassword: "Sign up with password",
        continueWithGoogle: "Continue with Google",
        or: "or",
      };

  // Persist the recorded consents to the user's profile row after signup.
  // BEST-EFFORT by design (try/catch + console.error): the profile row is
  // created by the handle_new_user trigger and the consent UI/gating above
  // is the source of truth for blocking signup. If the consent columns are
  // absent (deploy landed before the 20260603120000 migration) this write
  // fails harmlessly and signup still completes. terms/privacy/age are only
  // reached once the required boxes are checked, so we stamp all three now;
  // marketing fields are written only when the optional box is ticked.
  async function persistConsent() {
    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;
      const nowIso = new Date().toISOString();
      const consent: Record<string, unknown> = {
        terms_accepted_at: nowIso,
        privacy_accepted_at: nowIso,
        age_confirmed_at: nowIso,
      };
      if (marketingOptIn) {
        consent.marketing_opt_in = true;
        consent.marketing_opt_in_at = nowIso;
      }
      const { error: consentError } = await supabase
        .from("profiles")
        .update(consent)
        .eq("id", user.id);
      if (consentError) {
        console.error("[signup] Failed to persist consent:", consentError);
      }
    } catch (e) {
      console.error("[signup] Failed to persist consent:", e);
    }
  }

  async function handlePasswordSignup(e: React.FormEvent) {
    e.preventDefault();

    if (!termsConsent) {
      setError(t.termsRequired);
      return;
    }

    if (!healthConsent) {
      setError(t.healthRequired);
      return;
    }

    if (!ageConfirm) {
      setError(t.ageRequired);
      return;
    }

    if (password.length < 8) {
      setError(t.passwordTooShort);
      return;
    }

    if (password !== confirmPassword) {
      setError(t.passwordMismatch);
      return;
    }

    setLoading(true);
    setError(null);

    const nowIso = new Date().toISOString();
    const supabase = createClient();
    const { data, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: callbackUrl,
        data: {
          gdpr_consent: true,
          gdpr_consent_at: nowIso,
          terms_accepted_at: nowIso,
          privacy_accepted_at: nowIso,
          age_confirmed_at: nowIso,
          marketing_opt_in: marketingOptIn,
          marketing_opt_in_at: marketingOptIn ? nowIso : null,
        },
      },
    });

    if (authError) {
      setError(authError.message);
      setLoading(false);
      return;
    }

    // Email confirmation is disabled in Supabase, so signUp returns a
    // session immediately. Route the user straight into the app instead
    // of the legacy "check your email" stub. Honor a pending checkout
    // intent so subscribe-then-signup flows resume Stripe.
    if (data.session) {
      // Best-effort persist of the recorded consents to the profile row
      // before navigating; never blocks signup (see persistConsent).
      await persistConsent();
      const next = intentIsValid
        ? `/${locale}/checkout-resume?intent=${intent}`
        : `/${locale}/onboarding`;
      router.push(next);
      router.refresh();
      return;
    }

    // Fallback: if confirmation is re-enabled later, the legacy screen
    // still works.
    setSubmitted(true);
    setLoading(false);
  }

  async function handleMagicSignup(e: React.FormEvent) {
    e.preventDefault();

    if (!termsConsent) {
      setError(t.termsRequired);
      return;
    }

    if (!healthConsent) {
      setError(t.healthRequired);
      return;
    }

    if (!ageConfirm) {
      setError(t.ageRequired);
      return;
    }

    setLoading(true);
    setError(null);

    // Magic-link signup redirects to email and returns no immediate session,
    // so the recorded consents ride along in the auth user metadata here.
    const nowIso = new Date().toISOString();
    const supabase = createClient();
    const { error: authError } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: callbackUrl,
        data: {
          gdpr_consent: true,
          gdpr_consent_at: nowIso,
          terms_accepted_at: nowIso,
          privacy_accepted_at: nowIso,
          age_confirmed_at: nowIso,
          marketing_opt_in: marketingOptIn,
          marketing_opt_in_at: marketingOptIn ? nowIso : null,
        },
      },
    });

    if (authError) {
      setError(authError.message);
    } else {
      setSubmitted(true);
    }
    setLoading(false);
  }

  async function handleGoogle() {
    if (!termsConsent) {
      setError(t.termsRequired);
      return;
    }
    // Art. 9 health-data consent is REQUIRED on every signup path. The OAuth
    // flow previously skipped this check, creating accounts with no recorded
    // special-category consent (GDPR-003).
    if (!healthConsent) {
      setError(t.healthRequired);
      return;
    }
    if (!ageConfirm) {
      setError(t.ageRequired);
      return;
    }
    setError(null);
    const supabase = createClient();
    // signInWithOAuth cannot carry user metadata (unlike signUp), so the
    // recorded consents ride the callback URL and /callback stamps them onto
    // the profile after the code exchange (first time only). Same pattern as
    // the existing `next` param, so the Supabase redirect allowlist already
    // tolerates query strings here.
    const sep = callbackUrl.includes("?") ? "&" : "?";
    const redirectWithConsents = `${callbackUrl}${sep}consents=1${marketingOptIn ? "&mkt=1" : ""}`;
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: redirectWithConsents,
      },
    });
  }

  // Shared consent block rendered above the submit button in both the
  // password and magic-link forms. Two REQUIRED checkboxes (Terms+Privacy
  // and 18+) gate submission; the marketing box is OPTIONAL. Returned from
  // a function so each form gets an independent element tree.
  function renderConsentFields() {
    return (
      <div className="space-y-3">
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={termsConsent}
            onChange={(e) => setTermsConsent(e.target.checked)}
            aria-required="true"
            className="mt-1 h-4 w-4 rounded border-gray-300 text-[#C4704B] focus:ring-[#C4704B]"
          />
          <span className="text-sm text-gray-600">
            {t.termsConsentBefore}
            <Link
              href={`/${locale}/legal/terms`}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-[#C4704B] hover:underline"
            >
              {t.termsLink}
            </Link>
            {t.termsConsentMiddle}
            <Link
              href={`/${locale}/legal/privacy`}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-[#C4704B] hover:underline"
            >
              {t.privacyLink}
            </Link>
            {t.termsConsentAfter}
          </span>
        </label>

        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={healthConsent}
            onChange={(e) => setHealthConsent(e.target.checked)}
            aria-required="true"
            className="mt-1 h-4 w-4 rounded border-gray-300 text-[#C4704B] focus:ring-[#C4704B]"
          />
          <span className="text-sm text-gray-600">{t.healthConsent}</span>
        </label>

        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={ageConfirm}
            onChange={(e) => setAgeConfirm(e.target.checked)}
            aria-required="true"
            className="mt-1 h-4 w-4 rounded border-gray-300 text-[#C4704B] focus:ring-[#C4704B]"
          />
          <span className="text-sm text-gray-600">{t.ageConsent}</span>
        </label>

        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={marketingOptIn}
            onChange={(e) => setMarketingOptIn(e.target.checked)}
            className="mt-1 h-4 w-4 rounded border-gray-300 text-[#C4704B] focus:ring-[#C4704B]"
          />
          <span className="text-sm text-gray-600">{t.marketingConsent}</span>
        </label>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg text-center">
          <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-gradient-to-br from-[#C4704B] to-[#A0522D] flex items-center justify-center">
            <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <p className="text-lg font-medium text-[#1a1a2e]">
            {mode === "password" ? t.checkEmailConfirm : t.checkEmailMagic}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold text-[#1a1a2e]">{t.welcome}</h1>
          <p className="mt-2 text-sm text-gray-500">{t.subtitle}</p>
        </div>

        {error && (
          <div
            id="form-error"
            role="alert"
            className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-600"
          >
            {error}
          </div>
        )}

        {mode === "password" ? (
          <form onSubmit={handlePasswordSignup} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                {t.email}
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                required
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                {t.password}
              </label>
              <input
                id="password"
                type="password"
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                required
                minLength={8}
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                {t.confirmPassword}
              </label>
              <input
                id="confirmPassword"
                type="password"
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                required
                minLength={8}
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>

            {renderConsentFields()}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-gradient-to-r from-[#C4704B] to-[#A0522D] px-4 py-3 font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {loading ? "..." : t.signup}
            </button>
          </form>
        ) : (
          <form onSubmit={handleMagicSignup} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                {t.email}
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                required
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>

            {renderConsentFields()}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-gradient-to-r from-[#C4704B] to-[#A0522D] px-4 py-3 font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {loading ? "..." : t.sendMagicLink}
            </button>
          </form>
        )}

        <button
          type="button"
          onClick={() => {
            setMode(mode === "password" ? "magic" : "password");
            setError(null);
          }}
          className="mt-3 w-full text-center text-sm text-[#C4704B] hover:underline"
        >
          {mode === "password" ? t.useMagicLink : t.usePassword}
        </button>

        <div className="my-6 flex items-center">
          <div className="flex-1 border-t border-gray-200" />
          <span className="mx-4 text-sm text-gray-400">{t.or}</span>
          <div className="flex-1 border-t border-gray-200" />
        </div>

        <button
          onClick={handleGoogle}
          className="flex w-full items-center justify-center gap-3 rounded-lg border border-gray-300 bg-white px-4 py-3 font-medium text-[#1a1a2e] transition-colors hover:bg-gray-50"
        >
          <svg className="h-5 w-5" viewBox="0 0 24 24">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
          </svg>
          {t.continueWithGoogle}
        </button>

        <p className="mt-6 text-center text-sm text-gray-500">
          {t.haveAccount}{" "}
          <Link
            href={`/${locale}/login`}
            className="font-medium text-[#C4704B] hover:underline"
          >
            {t.login}
          </Link>
        </p>
      </div>
    </div>
  );
}
