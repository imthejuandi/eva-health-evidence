import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { z } from "zod";

// SEC-013 — validate + length-cap every field before it reaches the outbound
// email. The email is format-checked (it is used as replyTo); name and
// category are stripped of CR/LF so they cannot inject extra header lines into
// the subject sent to the internal inbox.
const ContactSchema = z.object({
  name: z.string().trim().min(1).max(200),
  email: z
    .string()
    .trim()
    .max(254)
    .regex(/^[^@\s]+@[^@\s]+\.[^@\s]+$/),
  message: z.string().trim().min(1).max(5000),
  category: z.string().trim().min(1).max(50),
});

export async function POST(req: NextRequest) {
  try {
    const parsed = ContactSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please provide a valid name, email, category, and message." },
        { status: 400 },
      );
    }
    const { name, email, message, category } = parsed.data;
    const oneLine = (s: string) => s.replace(/[\r\n]+/g, " ");

    const resend = new Resend(process.env.RESEND_API_KEY);

    await resend.emails.send({
      from: "EVA Health <noreply@evahealth.es>",
      to: "hello@evahealth.es",
      replyTo: email,
      subject: `[${oneLine(category)}] Contact from ${oneLine(name)}`,
      text: `Name: ${name}\nEmail: ${email}\nCategory: ${category}\n\nMessage:\n${message}`,
    });

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json(
      { error: "Failed to send message" },
      { status: 500 },
    );
  }
}
