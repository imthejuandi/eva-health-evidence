"use client";

import dynamic from "next/dynamic";
import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { CTAButton } from "@/components/marketing/CTAButton";
import {
  ChapterMarker, SectionHeadline, LedeItalic,
  BodyProse, SectionShell,
} from "@/components/marketing/editorial";
import { NormalVsOptimalFlip } from "@/components/marketing/how-it-works/NormalVsOptimalFlip";
import { TrendlineSVG } from "@/components/marketing/how-it-works/TrendlineSVG";
import { TassoAnimation } from "@/components/marketing/how-it-works/TassoAnimation";
import { AIChat } from "@/components/marketing/how-it-works/AIChat";
import type { AIPart } from "@/components/marketing/how-it-works/AIChat";

const RevealConstellation = dynamic(
  () => import("../reveal-constellation").then((m) => m.RevealConstellation),
  { ssr: false, loading: () => null },
);

export default function HowItWorksPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const es = locale === "es";

  const t = es ? {
    ch01: "§ 01 · El protocolo", ch02: "§ 02 · La verdad", ch03: "§ 03 · El sistema", ch04: "§ 04 · Tu cuerpo", ch05: "§ 05 · EVA AI", ch06: "§ 06 · La cadencia", ch07: "§ 07 · La invitacion",
    premium: "EVA Premium",
    // § 01 The Drop
    dropTitle: "Un test. En casa. Nada mas.",
    dropBody: "Tu kit llega con un dispositivo de recoleccion. Se pega a tu brazo, presionas un boton, y recoge la muestra de forma indolora. Lo envias de vuelta. Ese es todo el protocolo.",
    dropStat1: "En casa", dropStat2: "5 min", dropStat3: "Indoloro",
    tassoStick: "Pega a tu brazo", tassoClick: "Presiona el boton", tassoWait: "Se recoge la muestra", tassoDone: "Listo: envialo de vuelta",
    tassoDescStick: "El adhesivo crea un sello en tu brazo", tassoDescClick: "La micro-lanceta se activa con presion suave", tassoDescWait: "El vacio extrae 500\u03bcL de sangre capilar", tassoDescDone: "Tapa el tubo y envialo al laboratorio",
    tapContinue: "Toca para continuar", tapRestart: "Toca para reiniciar",
    // § 02 The Lie
    lieTitle: "'Normal' se construyo con personas enfermas.",
    lieBody: "Los rangos de referencia son promedios poblacionales: una poblacion cansada, inflamada, con resistencia a la insulina y envejeciendo mas rapido de lo que deberia. Cuando tu medico dice 'normal', quiere decir que no estas peor que la media. EVA hace una pregunta diferente: ¿estas optimo?",
    lieStd: "Estandar", lieOpt: "EVA Optimo", lieStdV: "Normal", lieOptV: "Por debajo del optimo",
    lieCap: "Tu laboratorio dijo 'bien'. Nosotros encontramos un problema.",
    // § 03 The System
    sysTitle: "Cinco zonas. No dos.",
    sysBody: "Los laboratorios tradicionales dan un resultado binario: normal o no. EVA clasifica cada biomarcador en cinco zonas, cada una con una accion clara.",
    zones: [
      { l: "Critico Bajo", d: "Atencion medica", c: "#b04040" }, { l: "Bajo Optimo", d: "Cambios de estilo de vida", c: "#c49332" },
      { l: "Optimo", d: "Mantén tu enfoque", c: "#3a665e" }, { l: "Alto Optimo", d: "Revisar con orientacion", c: "#c49332" },
      { l: "Critico Alto", d: "Atencion medica", c: "#b04040" },
    ],
    sysAction: "Intervencion de estilo de vida. Aumenta alimentos ricos en hierro. Repite en 90 dias.",
    // § 04 The Dashboard
    dashTitle: "Tu cuerpo, leido.",
    dashBody: "26 biomarcadores. Siete sistemas. Un mapa vivo. Cada punto es una lectura. Cada color es una zona. Toca cualquier nodo para ver la historia detras.",
    dashLede: "El verdadero producto es la comprension.",
    dashChrono: "En tu carnet", dashDelta: "Años mas joven", dashBioAge: "Edad biologica",
    // § 05 EVA AI
    aiTitle: "Tu asistente de salud con contexto.",
    aiBody: "EVA AI lee tu panel completo, tus tendencias de wearables y tu historial. Convierte datos crudos en orientacion proactiva.",
    aiQ1: "¿Por que mi energia ha estado baja?",
    aiA1: [{ t: "Tu ferritina de " }, { v: "38 ng/mL", c: "#c49332" }, { t: " esta por debajo del optimo (50-150). Combinado con la caida de VFC, tus reservas de hierro estan afectando la recuperacion." }] as AIPart[],
    aiQ2: "¿Deberia preocuparme por mi colesterol?",
    aiA2: [{ t: "Tu ApoB de " }, { v: "95 mg/dL", c: "#c49332" }, { t: " esta por encima del optimo (<80). ApoB es mejor predictor de riesgo cardiovascular que LDL. Hablemos de los proximos pasos." }] as AIPart[],
    aiInput: "Pregunta a EVA...",
    // § 06 The Cadence
    cadTitle: "El envejecimiento se mueve en tendencias, no en fotos.",
    cadBody: "Cada trimestre, EVA lee tu linea base de nuevo. 15 biomarcadores, 4 veces al año, 60 puntos de datos rastreando como envejeces. Cada lectura afina la señal.",
    cadQ1: "T1", cadQ2: "T2", cadQ3: "T3", cadQ4: "T4", cadOpt: "Optimo",
    panels: [
      { eye: "Panel Base", c: "#97472c", d: "15 biomarcadores esenciales", p: "Incluido" },
      { eye: "Especializados", c: "#3a665e", d: "Hormonas, cardio, tiroides, nutrientes", p: "Consultanos" },
      { eye: "Completo Lab", c: "#c49332", d: "40+ biomarcadores en laboratorio", p: "€499" },
    ],
    // § 07 The Invitation
    ctaTitle: "Ve lo que 'normal' esta ocultando.",
    ctaBody: "Sube analisis que ya tengas. EVA los reinterpretara contra rangos optimos: gratis, sin suscripcion, sin kit. En menos de un minuto, veras la distancia entre 'bien' y 'optimo'.",
    ctaPrimary: "Sube tus analisis", ctaSecondary: "Pide tu kit",
  } : {
    ch01: "§ 01 · The protocol", ch02: "§ 02 · The truth", ch03: "§ 03 · The system", ch04: "§ 04 · Your body", ch05: "§ 05 · EVA AI", ch06: "§ 06 · The cadence", ch07: "§ 07 · The invitation",
    premium: "EVA Premium",
    // § 01 The Drop
    dropTitle: "One test. At home. That's it.",
    dropBody: "Your kit arrives with a collection device. It sticks to your arm, you press a button, and it collects your sample painlessly. You mail it back. That's the entire protocol.",
    dropStat1: "At home", dropStat2: "5 min", dropStat3: "Painless",
    tassoStick: "Stick to your arm", tassoClick: "Press the button", tassoWait: "Sample collects itself", tassoDone: "Done: mail it back",
    tassoDescStick: "Adhesive creates a seal on your upper arm", tassoDescClick: "Micro-lancet activates with gentle pressure", tassoDescWait: "Vacuum draws 500\u03bcL of capillary blood", tassoDescDone: "Cap the tube and mail to the lab",
    tapContinue: "Tap to continue", tapRestart: "Tap to restart",
    // § 02 The Lie
    lieTitle: "'Normal' was built from sick people.",
    lieBody: "Reference ranges are population averages: a population that's tired, inflamed, insulin-resistant, and ageing faster than it should. When your doctor says 'normal,' they mean you're no worse than average. EVA asks a different question: are you optimal?",
    lieStd: "Standard", lieOpt: "EVA Optimal", lieStdV: "Normal", lieOptV: "Below Optimal",
    lieCap: "Your lab said 'fine.' We found a problem.",
    // § 03 The System
    sysTitle: "Five zones. Not two.",
    sysBody: "Traditional labs give a binary result: normal or not. EVA classifies every biomarker into five zones, each with a clear directive.",
    zones: [
      { l: "Critical Low", d: "Medical attention", c: "#b04040" }, { l: "Below Optimal", d: "Lifestyle changes", c: "#c49332" },
      { l: "Optimal", d: "Maintain approach", c: "#3a665e" }, { l: "Above Optimal", d: "Review with guidance", c: "#c49332" },
      { l: "Critical High", d: "Medical attention", c: "#b04040" },
    ],
    sysAction: "Lifestyle intervention. Increase iron-rich foods. Retest in 90 days.",
    // § 04 The Dashboard
    dashTitle: "Your body, read.",
    dashBody: "26 biomarkers. Seven systems. One living map. Every dot is a reading. Every colour is a zone. Tap any node to see the story beneath.",
    dashLede: "The real product is understanding.",
    dashChrono: "On your ID", dashDelta: "Years younger", dashBioAge: "Biological age",
    // § 05 EVA AI
    aiTitle: "Your context-aware health assistant.",
    aiBody: "EVA AI reads your full panel, wearable trends, and history. It turns raw data into proactive guidance.",
    aiQ1: "Why has my energy been low?",
    aiA1: [{ t: "Your ferritin at " }, { v: "38 ng/mL", c: "#c49332" }, { t: " is below optimal (50-150). Combined with the HRV dip, your iron stores are impacting recovery." }] as AIPart[],
    aiQ2: "Should I worry about my cholesterol?",
    aiA2: [{ t: "Your ApoB at " }, { v: "95 mg/dL", c: "#c49332" }, { t: " is above optimal (<80). ApoB is a better predictor of cardiovascular risk than LDL. Let's talk next steps." }] as AIPart[],
    aiInput: "Ask EVA...",
    // § 06 The Cadence
    cadTitle: "Ageing moves in trendlines, not snapshots.",
    cadBody: "Every quarter, EVA reads your baseline again. 15 biomarkers, 4 times a year, 60 data points tracking how you age. Each reading sharpens the signal.",
    cadQ1: "Q1", cadQ2: "Q2", cadQ3: "Q3", cadQ4: "Q4", cadOpt: "Optimal",
    panels: [
      { eye: "Base Panel", c: "#97472c", d: "15 core biomarkers", p: "Included" },
      { eye: "Specialty", c: "#3a665e", d: "Hormones, cardio, thyroid, nutrients", p: "Contact us" },
      { eye: "Full Lab", c: "#c49332", d: "40+ biomarkers at partner lab", p: "€499" },
    ],
    // § 07 The Invitation
    ctaTitle: "See what normal is hiding.",
    ctaBody: "Upload bloodwork you already have. EVA will reinterpret it against optimal ranges: free, no subscription, no kit needed. In under a minute, you'll see the distance between 'fine' and 'optimal.'",
    ctaPrimary: "Upload your labs", ctaSecondary: "Order your kit",
  };

  return (
    <div className="relative antialiased [font-feature-settings:'liga','calt','kern']" style={{ textRendering: "optimizeLegibility" }}>
      {/* Film grain */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-[1] opacity-[0.04] mix-blend-multiply" style={{ backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='g'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23g)'/></svg>")`, backgroundSize: "200px" }} />

      {/* ═══ § 01 THE DROP (EASY) ═══════════════════════════════ */}
      <SectionShell tone="cream" size="xxlarge">
        <ScrollReveal><ChapterMarker>{t.ch01}</ChapterMarker></ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-5 md:mt-8">
          <SectionHeadline scale="monumental" maxCh={16}>{t.dropTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.1} className="mt-6 md:mt-10">
          <BodyProse maxCh={48}>{t.dropBody}</BodyProse>
        </ScrollReveal>
        {/* Tasso device animation */}
        <div className="mt-10 md:mt-16">
          <TassoAnimation 
            labels={{ stick: t.tassoStick, click: t.tassoClick, wait: t.tassoWait, done: t.tassoDone }} 
            descriptions={{ stick: t.tassoDescStick, click: t.tassoDescClick, wait: t.tassoDescWait, done: t.tassoDescDone }}
            tapContinue={t.tapContinue}
            tapRestart={t.tapRestart}
          />
        </div>

        {/* Stat tokens */}
        <ScrollReveal delay={0.15} className="mt-10 md:mt-14">
          <div className="grid grid-cols-3 gap-4 md:max-w-[480px] md:gap-6">
            {[t.dropStat1, t.dropStat2, t.dropStat3].map((s) => (
              <div key={s} className="border-b border-[#97472c]/20 pb-3 md:pb-4">
                <p className="font-[family-name:var(--font-dm-mono)] text-[12px] font-bold uppercase tracking-[1.5px] text-[#1d1b18] md:text-[14px] md:tracking-[2px]">{s}</p>
              </div>
            ))}
          </div>
        </ScrollReveal>
      </SectionShell>

      {/* ═══ § 02 THE LIE (WOW) ═══════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xxlarge">
        <ScrollReveal><ChapterMarker>{t.ch02}</ChapterMarker></ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-5 md:mt-8">
          <SectionHeadline scale="monumental" maxCh={18}>{t.lieTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.1} className="mt-6 md:mt-10">
          <BodyProse maxCh={54}>{t.lieBody}</BodyProse>
        </ScrollReveal>
        <NormalVsOptimalFlip stdLabel={t.lieStd} optLabel={t.lieOpt} stdVerdict={t.lieStdV} optVerdict={t.lieOptV} className="mt-12 md:mt-16" />
        <ScrollReveal delay={0.2} className="mt-6 md:mt-8">
          <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#c49332] md:text-[11px]">{t.lieCap}</p>
        </ScrollReveal>
      </SectionShell>

      {/* ═══ § 03 THE SYSTEM (POWERFUL) — DARK ═══════════════════ */}
      <SectionShell tone="dark" size="large">
        <ScrollReveal><ChapterMarker color="terra-light" align="center">{t.ch03}</ChapterMarker></ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-5 text-center md:mt-8">
          <SectionHeadline scale="monumental" maxCh={14} color="inverse" className="mx-auto">{t.sysTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.1} className="mx-auto mt-5 text-center md:mt-8">
          <BodyProse tone="inverse" maxCh={50} className="mx-auto">{t.sysBody}</BodyProse>
        </ScrollReveal>
        {/* Zone bar */}
        <ScrollReveal delay={0.14} className="mt-10 md:mt-16">
          <div className="flex h-[28px] overflow-hidden rounded-full md:h-[44px]" aria-hidden>
            <div className="flex-[1] bg-[#b04040]/25" /><div className="flex-[1.5] bg-[#c49332]/25" /><div className="flex-[2] bg-[#3a665e]/35" /><div className="flex-[1.5] bg-[#c49332]/25" /><div className="flex-[1] bg-[#b04040]/25" />
          </div>
          <div className="-mx-6 mt-4 flex gap-3 overflow-x-auto px-6 pb-1 sm:mx-0 sm:mt-6 sm:grid sm:grid-cols-5 sm:gap-4 sm:overflow-visible sm:px-0 md:mt-8">
            {t.zones.map((z) => <div key={z.l} className="min-w-[110px] shrink-0 text-center sm:min-w-0"><p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.8px] md:text-[10px]" style={{ color: z.c }}>{z.l}</p><p className="mt-1 font-[family-name:var(--font-manrope)] text-[11px] leading-[1.4] text-[#fef8f2]/60 md:text-[13px]">{z.d}</p></div>)}
          </div>
        </ScrollReveal>
        {/* Ferritin specimen on dark + action directive */}
        <ScrollReveal delay={0.18} className="mx-auto mt-10 max-w-[720px] md:mt-16">
          <div className="rounded-lg bg-[#fef8f2]/[0.04] p-4 md:rounded-xl md:p-6">
            <div className="flex items-center justify-between">
              <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#fef8f2] md:text-[15px]">Ferritin</span>
              <span className="font-[family-name:var(--font-dm-mono)] text-[13px] font-bold text-[#c49332] [font-feature-settings:'tnum'] md:text-[14px]">38 <span className="text-[10px] text-[#fef8f2]/40">ng/mL</span></span>
            </div>
            <div className="relative mt-3 h-[16px] w-full md:mt-4 md:h-[20px]">
              <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#fef8f2]/10" />
              <div className="absolute top-1/2 h-[10px] -translate-y-1/2 rounded-full md:h-[12px]" style={{ left: "21%", width: "53%", background: "linear-gradient(90deg, rgba(58,102,94,0.3), rgba(58,102,94,0.5))" }} />
              <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2" style={{ left: "15%" }}>
                <span className="block h-[16px] w-[3px] rounded-full bg-[#c49332] md:h-[20px]" style={{ boxShadow: "0 0 10px rgba(196,147,50,0.6)" }} />
              </div>
            </div>
            <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.5px] text-[#c49332] md:mt-4 md:text-[11px]">{t.sysAction}</p>
          </div>
        </ScrollReveal>
      </SectionShell>

      {/* ═══ § 04 THE DASHBOARD (POWERFUL) — 3D ═══════════════ */}
      <SectionShell tone="cream" size="xxlarge">
        <ScrollReveal><ChapterMarker align="center">{t.ch04}</ChapterMarker></ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-5 text-center md:mt-8">
          <SectionHeadline scale="monumental" maxCh={14} className="mx-auto">{t.dashTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.1} className="mx-auto mt-5 text-center md:mt-8">
          <BodyProse maxCh={50} className="mx-auto">{t.dashBody}</BodyProse>
        </ScrollReveal>

        {/* Triptych: chrono / constellation / delta */}
        <ScrollReveal delay={0.14} className="mt-12 md:mt-20">
          <div className="grid grid-cols-1 items-center gap-8 md:gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,2fr)_minmax(0,1fr)]">
            {/* Chrono age */}
            <div className="text-center lg:text-right">
              <p className="font-[family-name:var(--font-sentient)] text-[56px] font-medium leading-[0.9] tracking-[-1.5px] text-[#8a7f76] md:text-[72px] lg:text-[84px]" style={{ fontVariantNumeric: "tabular-nums" }}>34</p>
              <p className="mt-2 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] md:text-[10px]">{t.dashChrono}</p>
            </div>
            {/* 3D constellation */}
            <div className="flex justify-center">
              <RevealConstellation bioAge={29} locale={locale} labels={{ bioAge: t.dashBioAge, tapHint: "" }} />
            </div>
            {/* Delta */}
            <div className="text-center lg:text-left">
              <p className="font-[family-name:var(--font-sentient)] text-[56px] font-medium leading-[0.9] tracking-[-1.5px] text-[#3a665e] md:text-[72px] lg:text-[84px]" style={{ fontVariantNumeric: "tabular-nums" }}>−5</p>
              <p className="mt-2 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#3a665e] md:text-[10px]">{t.dashDelta}</p>
            </div>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={0.2} className="mt-10 text-center md:mt-14">
          <LedeItalic color="jade" maxCh={34} className="mx-auto">{t.dashLede}</LedeItalic>
        </ScrollReveal>
      </SectionShell>

      {/* ═══ § 05 EVA AI (INTELLIGENT) — ambient wash ═══════════ */}
      <section className="relative overflow-hidden bg-[#f8f3ed] py-14 md:py-40">
        <div aria-hidden className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 30%, rgba(151,71,44,0.07), transparent 55%), radial-gradient(circle at 75% 80%, rgba(58,102,94,0.05), transparent 50%)" }} />
        <div className="relative mx-auto max-w-[1480px] px-5 md:px-12">
          <ScrollReveal>
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <ChapterMarker>{t.ch05}</ChapterMarker>
              <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#c49332] md:text-[10px]">· {t.premium}</span>
            </div>
          </ScrollReveal>
          <ScrollReveal delay={0.05} className="mt-5 md:mt-8">
            <SectionHeadline scale="monumental" maxCh={18}>{t.aiTitle}</SectionHeadline>
          </ScrollReveal>
          <ScrollReveal delay={0.1} className="mt-5 md:mt-8">
            <BodyProse maxCh={46}>{t.aiBody}</BodyProse>
          </ScrollReveal>
          <AIChat premium={t.premium} q1={t.aiQ1} a1={t.aiA1} q2={t.aiQ2} a2={t.aiA2} placeholder={t.aiInput} className="mt-10 md:mt-16" />
        </div>
      </section>

      {/* ═══ § 06 THE CADENCE (ONGOING) ═══════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ScrollReveal><ChapterMarker>{t.ch06}</ChapterMarker></ScrollReveal>
        <ScrollReveal delay={0.05} className="mt-5 md:mt-8">
          <SectionHeadline scale="monumental" maxCh={18}>{t.cadTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.1} className="mt-5 md:mt-8">
          <BodyProse maxCh={54}>{t.cadBody}</BodyProse>
        </ScrollReveal>
        {/* Trendline */}
        <ScrollReveal delay={0.14} className="mx-auto mt-10 max-w-[640px] md:mt-16">
          <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#8a7f76] md:text-[10px]">Ferritin (ng/mL)</p>
          <TrendlineSVG labels={{ q1: t.cadQ1, q2: t.cadQ2, q3: t.cadQ3, q4: t.cadQ4, optimal: t.cadOpt }} className="mt-2" />
        </ScrollReveal>
        {/* Panel options */}
        <div className="mt-12 divide-y divide-[#1d1b18]/8 border-y border-[#1d1b18]/8 md:mt-16">
          {t.panels.map((p, i) => (
            <ScrollReveal key={p.eye} delay={0.06 + i * 0.04}>
              <div className="grid grid-cols-1 gap-2 py-8 md:grid-cols-12 md:items-baseline md:gap-x-10 md:py-12">
                <div className="md:col-span-3"><p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] md:text-[10px]" style={{ color: p.c }}>{p.eye}</p></div>
                <div className="md:col-span-9">
                  <BodyProse size="compact" tone="muted" maxCh={54}>{p.d}</BodyProse>
                  <p className="mt-2 font-[family-name:var(--font-dm-mono)] text-[10px] font-bold uppercase tracking-[1.8px] [font-feature-settings:'tnum'] md:mt-3 md:text-[11px]" style={{ color: p.c }}>{p.p}</p>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </SectionShell>

      {/* ═══ § 07 THE INVITATION (CTA) ═══════════════════════ */}
      <section className="relative overflow-hidden bg-[#fef8f2] py-16 md:py-44">
        {/* Subtle warm wash */}
        <div aria-hidden className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(circle at 50% 50%, rgba(151,71,44,0.04), transparent 60%)" }} />
        <div className="relative mx-auto max-w-[1480px] px-5 md:px-12">
          <ScrollReveal><ChapterMarker align="center">{t.ch07}</ChapterMarker></ScrollReveal>
          <div className="mt-6 flex flex-col items-center text-center md:mt-10">
            <ScrollReveal delay={0.06}>
              <SectionHeadline scale="monumental" maxCh={16} balance={false} className="mx-auto">{t.ctaTitle}</SectionHeadline>
            </ScrollReveal>
            <ScrollReveal delay={0.12} className="mt-6 md:mt-10">
              <BodyProse maxCh={46} className="mx-auto">{t.ctaBody}</BodyProse>
            </ScrollReveal>
            <ScrollReveal delay={0.18} className="mt-8 flex flex-col items-center gap-4 sm:flex-row md:mt-12">
              <CTAButton href={`/${locale}/upload`}>{t.ctaPrimary}</CTAButton>
              <CTAButton variant="secondary" href={`/${locale}/signup`}>{t.ctaSecondary}</CTAButton>
            </ScrollReveal>
          </div>
        </div>
      </section>
    </div>
  );
}
