import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { processLabResults } from "@/lib/biomarkers/process-results";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { snapshotToLab } from "@/lib/patient-context";
import { TransientContextSchema } from "@/lib/patient-context/schema";

// ─── Zod schema for request body ───
const ConfirmBodySchema = z.object({
  labResultId: z.string().uuid({ message: "labResultId must be a UUID" }),
  biomarkers: z
    .array(
      z.object({
        name: z.string().min(1),
        value: z.number().finite(),
        unit: z.string(),
        biomarkerKey: z.string().min(1),
        // Rule 1: how the row resolved to its canonical key. exact/alias
        // are auto-accepted at extract; fuzzy must have been confirmed
        // in the review UI; user is a manual selection from the
        // reference list. The server validates the value is one of these.
        matchConfidence: z.enum(["exact", "alias", "fuzzy", "user"]),
      })
    )
    .min(1, { message: "At least one biomarker is required" }),
  // Optional: override the auto-set collection date. Required to be
  // YYYY-MM-DD so it slots straight into the lab_results date column.
  collectionDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "collectionDate must be YYYY-MM-DD")
    .optional(),
  // Rule 4: the upload UI's context gate hands the chosen
  // patient_context_versions id + per-draw transient block down here
  // so /confirm can snapshot them onto lab_results before the AI
  // pipeline runs. Both are required from the upload flow; we accept
  // them as optional in the schema to keep the legacy admin
  // enter-results path compiling, but reject the request below if
  // they're missing.
  contextVersionId: z.string().uuid().optional(),
  transientContext: TransientContextSchema.optional(),
});

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  let labResultId: string | null = null;

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Validate request body with Zod
    const rawBody = await req.json().catch(() => null);
    const parseResult = ConfirmBodySchema.safeParse(rawBody);
    if (!parseResult.success) {
      return NextResponse.json(
        { error: "Invalid request body", details: parseResult.error.issues },
        { status: 400 }
      );
    }
    const {
      labResultId: lrId,
      biomarkers,
      collectionDate,
      contextVersionId,
      transientContext,
    } = parseResult.data;
    labResultId = lrId;

    // 1. Get profile and verify upload limit
    const profile = await getUserProfile(user.id);
    if (!profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    }

    // Require DOB and sex before processing
    if (!profile.date_of_birth || !profile.sex) {
      return NextResponse.json(
        { error: "Please complete your profile (date of birth and sex) before confirming lab results." },
        { status: 400 }
      );
    }

    const isSubscriber = profile.subscription_status === "active";
    const totalUsed = ((profile as unknown as Record<string, unknown>).total_uploads_used as number) ?? 0;
    if (!isSubscriber && totalUsed >= 5) {
      return NextResponse.json({ error: "Upload limit reached" }, { status: 403 });
    }

    // Verify lab_result belongs to user
    const { data: labResult, error: labError } = await supabase
      .from("lab_results")
      .select("id, user_id")
      .eq("id", labResultId)
      .eq("user_id", user.id)
      .single();

    if (labError || !labResult) {
      return NextResponse.json({ error: "Lab result not found" }, { status: 404 });
    }

    // Rule 1: every submitted biomarker_key MUST exist in
    // biomarker_references. The Zod schema enforces non-empty strings;
    // this enforces "matches a canonical key we actually have ranges
    // for". A row without a reference can't be zone-classified or
    // interpreted, so we reject the whole request — making the failure
    // mode obvious to the client rather than silently dropping rows.
    const submittedKeys = Array.from(new Set(biomarkers.map((b) => b.biomarkerKey)));
    const { data: knownRefs, error: refLookupError } = await supabase
      .from("biomarker_references")
      .select("biomarker_key")
      .in("biomarker_key", submittedKeys);
    if (refLookupError) {
      console.error("[confirm] biomarker_references lookup failed:", refLookupError);
      return NextResponse.json(
        { error: "Failed to validate biomarker keys" },
        { status: 500 }
      );
    }
    const knownSet = new Set((knownRefs ?? []).map((r) => r.biomarker_key));
    const unknownKeys = submittedKeys.filter((k) => !knownSet.has(k));
    if (unknownKeys.length > 0) {
      return NextResponse.json(
        {
          error: "One or more biomarker keys are not in the reference list",
          unknownKeys,
        },
        { status: 422 }
      );
    }

    // 2. Update status to processing. Also stamp the user-confirmed
    //    collection_date if supplied, so historical trends reflect the
    //    actual date the sample was drawn rather than today's upload date.
    const updatePayload: Record<string, string> = {
      status: "processing",
      source: "user_upload",
      panel_type: "uploaded",
    };
    if (collectionDate) {
      updatePayload.collection_date = collectionDate;
    }
    const { error: statusError } = await supabase
      .from("lab_results")
      .update(updatePayload)
      .eq("id", labResultId);

    if (statusError) {
      console.error("[confirm] Failed to set processing status:", statusError);
      // Non-fatal, continue
    }

    // Rule 4: snapshot the user's chosen patient_context_versions row +
    // the per-draw transient block onto the lab BEFORE the pipeline
    // runs. The AI prompt (Rule 2, separate PR) reads them from
    // lab_results.patient_context_version_id, so the row must carry
    // them by the time generateSummary fires.
    if (contextVersionId) {
      // Verify the version belongs to the caller. RLS prevents another
      // user's id from leaking through, but an explicit 404 is clearer.
      const { data: version, error: versionError } = await supabase
        .from("patient_context_versions")
        .select("id")
        .eq("id", contextVersionId)
        .eq("user_id", user.id)
        .maybeSingle();
      if (versionError || !version) {
        return NextResponse.json(
          { error: "Patient context version not found" },
          { status: 404 },
        );
      }
      try {
        await snapshotToLab(labResultId, contextVersionId, transientContext ?? {});
      } catch (snapErr) {
        console.error("[confirm] Failed to snapshot context:", snapErr);
        return NextResponse.json(
          { error: "Failed to save patient context" },
          { status: 500 },
        );
      }
    }

    // 3. Process biomarkers — pass biomarkerKey + matchConfidence so the
    //    user's manual selection is respected and the audit trail records
    //    how confident the match was.
    const result = await processLabResults(
      user.id,
      labResultId,
      biomarkers.map((b) => ({
        name: b.name,
        value: b.value,
        unit: b.unit,
        biomarkerKey: b.biomarkerKey,
        matchConfidence: b.matchConfidence,
      }))
    );

    if (result.processed.length === 0) {
      throw new Error("No biomarkers could be processed");
    }

    // 4. Generate AI summary + action steps
    const wearable = await getWearableData(user.id, 30);
    await generateSummary(
      user.id,
      labResultId,
      result.processed,
      wearable.length > 0 ? wearable : null,
      profile,
    );

    // 5. Update status to ready
    const { error: readyError } = await supabase
      .from("lab_results")
      .update({ status: "ready" })
      .eq("id", labResultId);

    if (readyError) {
      console.error("[confirm] Failed to set ready status:", readyError);
    }

    // 6. Increment upload count
    const { error: counterError } = await supabase
      .from("profiles")
      .update({ total_uploads_used: totalUsed + 1 })
      .eq("id", user.id);

    if (counterError) {
      console.error("[confirm] Failed to increment upload counter:", counterError);
    }

    // 7. Send results-ready email (fire-and-forget)
    const firstName = profile.full_name?.split(" ")[0] ?? "";
    const locale = profile.locale ?? "en";
    sendEmail(
      user.email ?? "",
      "results-ready",
      {
        firstName,
        biomarkerCount: result.processed.length,
        biologicalAge: result.biologicalAge?.biologicalAge ?? null,
        baDelta: result.biologicalAge?.delta ?? null,
        longevityScore: result.biologicalAge?.longevityScore ?? null,
        locale,
      },
      locale
    ).catch((err) => {
      console.error("[confirm] Email send failed:", err);
    });

    // 8. Return result
    return NextResponse.json({
      labResultId,
      processed: result.processed.length,
      unmatched: result.unmatched.length,
      biologicalAge: result.biologicalAge,
      calculatedMetrics: result.calculatedMetrics.length,
    });
  } catch (e) {
    console.error("[confirm] Error:", e);

    // Revert status to "error" so the UI can distinguish failure from in-progress
    if (labResultId) {
      const { error: revertError } = await supabase
        .from("lab_results")
        .update({ status: "error" })
        .eq("id", labResultId);

      if (revertError) {
        console.error("[confirm] Failed to revert status to error:", revertError);
      }
    }

    const message = e instanceof Error ? e.message : "Failed to process";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
