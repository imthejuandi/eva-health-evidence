import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Analytics } from "@vercel/analytics/next";
import { ToastProvider } from "@/components/ui/Toast";
import { routing } from "@/i18n/routing";

/**
 * Locale layout — owns the document shell so `<html lang>` matches the active
 * locale (A11Y-001 / SEO-005) and supplies localized, per-locale metadata with
 * canonical + hreflang alternates (SEO-001 / SEO-002). Renders the `<html>` /
 * `<body>` that the (pass-through) root layout deliberately omits.
 *
 * NOTE: we intentionally do NOT add `generateStaticParams`/`setRequestLocale`
 * here. The marketing/auth pages are client components that read
 * `useParams()`/`useSearchParams()`, so they render dynamically today; opting
 * them into static prerendering surfaces a CSR-bailout error on the auth pages.
 * Converting to static generation (with Suspense boundaries + the next-intl /
 * RSC migration) is the deferred Wave 4B refactor — see PM-DECISION-LOG D-W4.2.
 */

const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";

const META = {
  es: {
    title: "EVA Health — Salud preventiva de precisión",
    description:
      "Tus análisis dicen que estás bien. Tu cuerpo sabe otra cosa. EVA reinterpreta tus biomarcadores frente a rangos optimizados para la longevidad.",
  },
  en: {
    title: "EVA Health — Precision Preventative Health",
    description:
      "Your labs say you're fine. Your body knows different. EVA reinterprets your biomarkers against longevity-optimised ranges.",
  },
} as const;

type Locale = (typeof routing.locales)[number];

function isLocale(value: string): value is Locale {
  return (routing.locales as readonly string[]).includes(value);
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const m = isLocale(locale) ? META[locale] : META[routing.defaultLocale];
  return {
    metadataBase: new URL(APP_URL),
    title: m.title,
    description: m.description,
    alternates: {
      canonical: `/${locale}`,
      languages: {
        es: "/es",
        en: "/en",
        "x-default": `/${routing.defaultLocale}`,
      },
    },
    openGraph: {
      type: "website",
      url: `/${locale}`,
      siteName: "EVA Health",
      title: m.title,
      description: m.description,
      locale: locale === "es" ? "es_ES" : "en_GB",
    },
    twitter: {
      card: "summary_large_image",
      title: m.title,
      description: m.description,
    },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();

  const m = isLocale(locale) ? META[locale] : META[routing.defaultLocale];
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "EVA Health",
    url: APP_URL,
    description: m.description,
  };

  return (
    <html lang={locale} className="antialiased font-sans">
      <head>
        {process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN && (
          <script
            defer
            data-domain={process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN}
            src="https://plausible.io/js/script.js"
          />
        )}
      </head>
      <body className="min-h-screen bg-[#0a0e1a] font-sans text-white">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <ToastProvider>{children}</ToastProvider>
        <Analytics />
      </body>
    </html>
  );
}
