"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { DashboardChrome, EditorialMasthead } from "@/components/dashboard";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import {
  yearRoman,
  quarterRoman,
  formatDayMonth,
  fmtValue,
} from "@/lib/dashboard-format";
import type { Zone } from "@/lib/biomarkers/zone-config";

interface LabSummary {
  id: string;
  collection_date: string | null;
  source: string | null;
  status: string | null;
  created_at: string;
}

interface BiomarkerValueRow {
  id: string;
  biomarker_key: string;
  biomarker_name: string | null;
  value: number;
  unit: string;
  zone: string;
  created_at: string;
}

interface ManageLabsClientProps {
  locale: string;
  labs: LabSummary[];
  selectedLabId: string | null;
  biomarkers: BiomarkerValueRow[];
}

function zoneAccent(zone: string): { stroke: string; label: { en: string; es: string } } {
  if (zone === "optimal")
    return { stroke: "#3a665e", label: { en: "Optimal", es: "Optimo" } };
  if (zone === "below_optimal" || zone === "above_optimal")
    return { stroke: "#c49332", label: { en: "Attention", es: "Atencion" } };
  if (zone === "critical_low" || zone === "critical_high")
    return { stroke: "#b04040", label: { en: "Action", es: "Accion" } };
  return { stroke: "#8a7f76", label: { en: "—", es: "—" } };
}

function sourceLabel(source: string | null, locale: string): string {
  if (source === "eva_kit") return "EVA kit";
  if (source === "user_upload") return locale === "es" ? "Subido" : "Upload";
  return locale === "es" ? "Otro" : "Other";
}

/* Inline ArchiveMasthead removed — page now uses the shared
 * EditorialMasthead from @/components/dashboard with a custom
 * volSuffix that carries the lab count. */

/* ──────────────────────────────────────────────────────────────────────
 * EditorialDeleteModal — replaces native confirms. Warm but serious:
 * cream surface, terra accent on the "remove" CTA, ghost link for
 * "keep". Closes on Escape and on backdrop click.
 * ────────────────────────────────────────────────────────────────────── */
function EditorialDeleteModal({
  open,
  kicker,
  title,
  body,
  cancelLabel,
  confirmLabel,
  busyLabel,
  busy,
  error,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  kicker: string;
  title: string;
  body: string;
  cancelLabel: string;
  confirmLabel: string;
  busyLabel: string;
  busy: boolean;
  error: string | null;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !busy) onCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, busy, onCancel]);

  if (!open) return null;
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="archive-delete-title"
      className="fixed inset-0 z-50 flex items-end justify-center bg-[#1d1b18]/55 px-4 py-6 backdrop-blur-sm md:items-center md:py-0"
      onClick={(e) => {
        if (e.target === e.currentTarget && !busy) onCancel();
      }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-[460px] rounded-t-[28px] bg-[#fef8f2] p-7 shadow-[0_30px_80px_-20px_rgba(151,71,44,0.4)] md:rounded-[28px] md:p-9"
      >
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#b04040]`}
        >
          {kicker}
        </p>
        <h3
          id="archive-delete-title"
          className={`mt-4 ${FONT_CLASS.cormorant} text-[34px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[40px] md:tracking-[-0.8px]`}
          style={{ textWrap: "balance" } as React.CSSProperties}
        >
          {title}
        </h3>
        <p
          className={`mt-4 ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f]`}
          style={{ textWrap: "pretty" } as React.CSSProperties}
        >
          {body}
        </p>
        {error && (
          <p
            className={`mt-3 ${FONT_CLASS.manrope} text-[13px] italic text-[#b04040]`}
          >
            {error}
          </p>
        )}
        <div className="mt-7 flex items-center justify-end gap-5">
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className={`${FONT_CLASS.manrope} text-[13px] font-medium text-[#4c463f] underline decoration-[#1d1b18]/20 underline-offset-[6px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/60 disabled:opacity-50`}
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={busy}
            className={`group inline-flex items-center gap-3 rounded-full bg-[#b04040] px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(176,64,64,0.55)] transition-transform hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60`}
          >
            {busy ? busyLabel : confirmLabel}
            <span
              aria-hidden
              className="flex h-5 w-5 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
            >
              <svg
                className="h-3 w-3"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={2}
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                />
              </svg>
            </span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}

export function ManageLabsClient({
  locale,
  labs,
  selectedLabId,
  biomarkers,
}: ManageLabsClientProps) {
  const router = useRouter();
  const selectedLab = labs.find((l) => l.id === selectedLabId) ?? null;

  const [editingDate, setEditingDate] = useState(false);
  const [dateValue, setDateValue] = useState<string>(
    selectedLab?.collection_date ?? "",
  );
  const [dateSaving, setDateSaving] = useState(false);
  const [dateError, setDateError] = useState<string | null>(null);

  const [editingValueId, setEditingValueId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [editUnit, setEditUnit] = useState("");
  const [valueSaving, setValueSaving] = useState(false);
  const [valueError, setValueError] = useState<string | null>(null);

  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const [search, setSearch] = useState("");

  const t =
    locale === "es"
      ? {
          back: "Volver a Analisis",
          archiveKicker: "§ El archivo",
          archiveTitle: "Cada lectura,",
          archiveAccent: "guardada.",
          archiveSubtitle:
            "Pulsa cualquier entrada para editar la fecha, los valores o eliminar la lectura.",
          empty: "Aun no has subido ninguna lectura.",
          uploadCta: "Subir tu primera lectura",
          dispatchOf: "Despacho",
          drawnOn: "Extraido",
          uploadedOn: "Archivado",
          biomarkerCount: "marcadores",
          collectionDate: "Fecha de la muestra",
          editDate: "Editar fecha",
          save: "Guardar",
          cancel: "Cancelar",
          saving: "Guardando...",
          search: "Buscar marcador",
          edit: "Editar",
          editHint: "Los cambios recalculan la zona automaticamente.",
          noBiomarkers: "Esta lectura no tiene marcadores.",
          delete: "Eliminar lectura",
          confirmDeleteKicker: "§ Confirma la baja",
          confirmDeleteTitle: "Quitar esta lectura?",
          confirmDeleteBody:
            "Eliminamos el despacho y todos sus marcadores. La operacion no se puede deshacer.",
          confirmDelete: "Si, eliminar",
          deleting: "Eliminando...",
          openEditor: "Abrir editor",
          closeEditor: "Cerrar",
          invalidDate: "Fecha invalida",
          invalidValue: "Valor invalido",
          status: "Estado",
        }
      : {
          back: "Back to Labs",
          archiveKicker: "§ The archive",
          archiveTitle: "Every reading,",
          archiveAccent: "kept.",
          archiveSubtitle:
            "Tap any entry to edit the date, the values, or remove the reading entirely.",
          empty: "You haven't filed any readings yet.",
          uploadCta: "File your first reading",
          dispatchOf: "Dispatch",
          drawnOn: "Drawn",
          uploadedOn: "Filed",
          biomarkerCount: "markers",
          collectionDate: "Collection date",
          editDate: "Edit date",
          save: "Save",
          cancel: "Cancel",
          saving: "Saving...",
          search: "Search marker",
          edit: "Edit",
          editHint: "Edits automatically recalculate the zone.",
          noBiomarkers: "This reading has no markers.",
          delete: "Remove reading",
          confirmDeleteKicker: "§ Confirm removal",
          confirmDeleteTitle: "Remove this reading?",
          confirmDeleteBody:
            "We'll delete the dispatch and every marker on it. This cannot be undone.",
          confirmDelete: "Yes, remove",
          deleting: "Removing...",
          openEditor: "Open editor",
          closeEditor: "Close",
          invalidDate: "Invalid date",
          invalidValue: "Invalid value",
          status: "Status",
        };

  function selectLab(id: string) {
    cancelValueEdit();
    cancelDateEdit();
    setSearch("");
    router.push(`/${locale}/labs/manage?lab=${id}`);
  }

  function clearSelection() {
    cancelValueEdit();
    cancelDateEdit();
    setSearch("");
    router.push(`/${locale}/labs/manage`);
  }

  function startDateEdit() {
    if (!selectedLab) return;
    setDateValue(selectedLab.collection_date ?? "");
    setEditingDate(true);
    setDateError(null);
  }

  function cancelDateEdit() {
    setEditingDate(false);
    setDateError(null);
  }

  async function saveDate() {
    if (!selectedLab) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateValue)) {
      setDateError(t.invalidDate);
      return;
    }
    setDateSaving(true);
    setDateError(null);
    try {
      const res = await fetch(`/api/lab-results/${selectedLab.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ collectionDate: dateValue }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Save failed (${res.status})`);
      }
      setEditingDate(false);
      router.refresh();
    } catch (e) {
      setDateError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setDateSaving(false);
    }
  }

  function startValueEdit(b: BiomarkerValueRow) {
    cancelDateEdit();
    setEditingValueId(b.id);
    setEditValue(String(b.value));
    setEditUnit(b.unit ?? "");
    setValueError(null);
  }

  function cancelValueEdit() {
    setEditingValueId(null);
    setValueError(null);
  }

  async function saveValueEdit() {
    if (!editingValueId) return;
    const parsed = parseFloat(editValue.replace(",", "."));
    if (!Number.isFinite(parsed)) {
      setValueError(t.invalidValue);
      return;
    }
    setValueSaving(true);
    setValueError(null);
    try {
      const res = await fetch(`/api/biomarker-values/${editingValueId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value: parsed, unit: editUnit || undefined }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Save failed (${res.status})`);
      }
      setEditingValueId(null);
      router.refresh();
    } catch (e) {
      setValueError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setValueSaving(false);
    }
  }

  async function deleteLab() {
    if (!selectedLab) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      const res = await fetch(`/api/lab-results/${selectedLab.id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Delete failed (${res.status})`);
      }
      setConfirmingDelete(false);
      router.push(`/${locale}/labs/manage`);
      router.refresh();
    } catch (e) {
      setDeleteError(e instanceof Error ? e.message : "Delete failed");
    } finally {
      setDeleting(false);
    }
  }

  const filtered = biomarkers.filter((b) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (b.biomarker_name ?? "").toLowerCase().includes(q) ||
      b.biomarker_key.toLowerCase().includes(q)
    );
  });

  /* ── Empty state ── */
  if (labs.length === 0) {
    return (
      <DashboardChrome>
        <div className="px-5 py-10 md:px-10 md:py-16">
          <div className="mx-auto max-w-[1200px]">
            <motion.div variants={fadeUp}>
              <EditorialMasthead
              issue={locale === "es" ? "El archivo" : "The archive"}
              volSuffix={
                <>
                  <span className="tabular-nums text-[#1d1b18]">00</span>{" "}
                  {locale === "es" ? "lecturas" : "readings"}
                </>
              }
            />
            </motion.div>

            <motion.div variants={fadeUp} className="mt-12 md:mt-20">
              <Link
                href={`/${locale}/labs`}
                className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
              >
                <span aria-hidden>←</span>
                {t.back}
              </Link>
              <p
                className={`mt-8 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
              >
                {t.archiveKicker}
              </p>
              <h1
                className={`mt-4 max-w-[14ch] ${FONT_CLASS.cormorant} text-[56px] font-medium leading-[0.95] tracking-[-1px] text-[#1d1b18] md:text-[88px] md:tracking-[-2.5px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.archiveTitle}{" "}
                <span className="italic text-[#97472c]">{t.archiveAccent}</span>
              </h1>

              <div className="mt-10 max-w-[44ch] border-t border-[#1d1b18]/15 pt-8">
                <p
                  className={`${FONT_CLASS.cormorant} text-[24px] italic leading-[1.25] text-[#4c463f] md:text-[28px]`}
                >
                  {t.empty}
                </p>
                <Link
                  href={`/${locale}/upload`}
                  className={`mt-7 inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0`}
                >
                  {t.uploadCta}
                  <span
                    aria-hidden
                    className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15"
                  >
                    <svg
                      className="h-3 w-3"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth={2}
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                      />
                    </svg>
                  </span>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </DashboardChrome>
    );
  }

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1200px]">
          {/* ── Masthead ── */}
          <motion.div variants={fadeUp}>
            <EditorialMasthead
              issue={locale === "es" ? "El archivo" : "The archive"}
              volSuffix={
                <>
                  <span className="tabular-nums text-[#1d1b18]">
                    {String(labs.length).padStart(2, "0")}
                  </span>{" "}
                  {locale === "es" ? "lecturas" : "readings"}
                </>
              }
            />
          </motion.div>

          {/* ── Header ── */}
          <motion.section
            variants={fadeUp}
            className="relative mt-10 md:mt-14"
          >
            <Link
              href={`/${locale}/labs`}
              className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
            >
              <span aria-hidden>←</span>
              {t.back}
            </Link>

            <div className="mt-8 grid gap-6 md:grid-cols-12 md:items-end md:gap-10">
              <div className="md:col-span-7">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                >
                  {t.archiveKicker}
                </p>
                <h1
                  className={`mt-4 ${FONT_CLASS.cormorant} text-[56px] font-medium leading-[0.95] tracking-[-1px] text-[#1d1b18] md:text-[88px] md:tracking-[-2.5px]`}
                  style={{ textWrap: "balance" } as React.CSSProperties}
                >
                  {t.archiveTitle}{" "}
                  <span className="italic text-[#97472c]">{t.archiveAccent}</span>
                </h1>
              </div>
              <div className="md:col-span-5 md:pb-3">
                <p
                  className={`max-w-[42ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f]`}
                  style={{ textWrap: "pretty" } as React.CSSProperties}
                >
                  {t.archiveSubtitle}
                </p>
              </div>
            </div>
          </motion.section>

          {/* ── Archive entries ── */}
          <motion.div
            variants={staggerTight}
            initial="hidden"
            animate="show"
            className="mt-12 md:mt-20"
          >
            <div className="border-t-2 border-[#1d1b18]/20">
              {labs.map((lab, i) => {
                const isSelected = lab.id === selectedLabId;
                const num = String(labs.length - i).padStart(2, "0");
                const drawn = lab.collection_date
                  ? formatDayMonth(lab.collection_date, locale)
                  : null;
                const filed = formatDayMonth(lab.created_at, locale);
                const ready = lab.status === "ready";
                return (
                  <motion.article
                    key={lab.id}
                    variants={fadeUp}
                    aria-current={isSelected ? "true" : undefined}
                    className={`relative border-b border-[#1d1b18]/15 transition-colors ${
                      isSelected ? "bg-[rgba(151,71,44,0.025)]" : ""
                    }`}
                  >
                    {/* Hanging numeral as chapter glyph */}
                    <span
                      aria-hidden
                      className={`pointer-events-none absolute -left-2 top-4 select-none ${FONT_CLASS.cormorant} text-[110px] font-medium italic leading-[0.78] tabular-nums text-[#1d1b18]/[0.04] md:-left-1 md:top-6 md:text-[160px] ${
                        isSelected ? "text-[#97472c]/[0.08]" : ""
                      }`}
                    >
                      {num}
                    </span>

                    <div className="relative grid gap-6 px-2 py-8 md:grid-cols-12 md:gap-10 md:py-12">
                      {/* Left rail — date + meta */}
                      <button
                        type="button"
                        onClick={() => (isSelected ? clearSelection() : selectLab(lab.id))}
                        className="group/header relative text-left md:col-span-5"
                      >
                        <p
                          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
                        >
                          {t.dispatchOf}{" "}
                          <span className="text-[#1d1b18]/60">№ {num}</span>
                        </p>

                        {drawn ? (
                          <div className="mt-5 flex items-baseline gap-3">
                            <span
                              className={`${FONT_CLASS.cormorant} text-[56px] font-medium leading-none tabular-nums tracking-[-2px] text-[#1d1b18] md:text-[80px] md:tracking-[-3px]`}
                            >
                              {drawn.day}
                            </span>
                            <div className="min-w-0">
                              <p
                                className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic leading-tight text-[#97472c] md:text-[24px]`}
                              >
                                {drawn.month}
                              </p>
                              <p
                                className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                              >
                                {yearRoman(drawn.year)}{" "}
                                <span className="text-[#1d1b18]/40">·</span>{" "}
                                Q{quarterRoman(new Date(lab.collection_date!))}
                              </p>
                            </div>
                          </div>
                        ) : (
                          <p
                            className={`mt-5 ${FONT_CLASS.cormorant} text-[40px] italic leading-none text-[#8a7f76] md:text-[56px]`}
                          >
                            {locale === "es" ? "Sin fecha" : "Undated"}
                          </p>
                        )}

                        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1.5">
                          <span
                            className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                          >
                            {sourceLabel(lab.source, locale)}
                          </span>
                          <span aria-hidden className="h-px w-4 bg-[#1d1b18]/15" />
                          <span
                            className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                          >
                            {t.uploadedOn}{" "}
                            <span className="tabular-nums text-[#1d1b18]/70">
                              {filed.day} {filed.month.slice(0, 3)} {filed.year}
                            </span>
                          </span>
                          {!ready && (
                            <span
                              className={`${FONT_CLASS.dmMono} rounded-full border border-[#c49332]/40 px-2 py-0.5 text-[9px] uppercase tracking-[1.4px] text-[#c49332]`}
                            >
                              {lab.status ?? "—"}
                            </span>
                          )}
                        </div>

                        {/* Open / Close affordance */}
                        <span
                          className={`mt-5 inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] transition-colors ${
                            isSelected
                              ? "text-[#97472c]"
                              : "text-[#8a7f76] group-hover/header:text-[#1d1b18]"
                          }`}
                        >
                          {isSelected ? t.closeEditor : t.openEditor}
                          <svg
                            aria-hidden
                            className={`h-3 w-3 transition-transform duration-300 ${
                              isSelected ? "rotate-180" : ""
                            }`}
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={2}
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M19.5 8.25l-7.5 7.5-7.5-7.5"
                            />
                          </svg>
                        </span>
                      </button>

                      {/* Right column when collapsed: status only */}
                      {!isSelected && (
                        <div className="md:col-span-7 md:flex md:items-end md:justify-end md:pb-2">
                          <span
                            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] ${
                              ready ? "text-[#3a665e]" : "text-[#c49332]"
                            }`}
                          >
                            <span aria-hidden className="mr-2 inline-block h-[3px] w-[3px] -translate-y-[2px] rounded-full" style={{ backgroundColor: ready ? "#3a665e" : "#c49332" }} />
                            {ready
                              ? locale === "es"
                                ? "Lista para leer"
                                : "Ready to read"
                              : lab.status ?? "—"}
                          </span>
                        </div>
                      )}

                      {/* Right column when selected: full editor */}
                      {isSelected && selectedLab && (
                        <div className="md:col-span-7">
                          {/* Date editor */}
                          <div className="border-b border-[#1d1b18]/10 pb-6">
                            <p
                              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]`}
                            >
                              {t.collectionDate}
                            </p>
                            {editingDate ? (
                              <div className="mt-3 flex flex-wrap items-center gap-3">
                                <input
                                  type="date"
                                  value={dateValue}
                                  max={new Date().toISOString().split("T")[0]}
                                  onChange={(e) => setDateValue(e.target.value)}
                                  className={`border-b border-[#1d1b18]/30 bg-transparent py-1.5 ${FONT_CLASS.dmMono} text-[14px] text-[#1d1b18] outline-none focus:border-[#97472c]`}
                                />
                                <button
                                  type="button"
                                  onClick={saveDate}
                                  disabled={dateSaving}
                                  className={`${FONT_CLASS.manrope} text-[12px] font-semibold uppercase tracking-[1.4px] text-[#97472c] underline decoration-[#97472c]/30 underline-offset-[5px] transition-colors hover:decoration-[#97472c] disabled:opacity-60`}
                                >
                                  {dateSaving ? t.saving : t.save}
                                </button>
                                <button
                                  type="button"
                                  onClick={cancelDateEdit}
                                  disabled={dateSaving}
                                  className={`${FONT_CLASS.manrope} text-[12px] font-medium uppercase tracking-[1.4px] text-[#8a7f76] transition-colors hover:text-[#1d1b18] disabled:opacity-60`}
                                >
                                  {t.cancel}
                                </button>
                              </div>
                            ) : (
                              <div className="mt-2 flex items-baseline gap-4">
                                <span
                                  className={`${FONT_CLASS.cormorant} text-[26px] font-medium tabular-nums text-[#1d1b18] md:text-[28px]`}
                                >
                                  {selectedLab.collection_date
                                    ? new Date(selectedLab.collection_date).toLocaleDateString(
                                        locale === "es" ? "es-ES" : "en-GB",
                                        { day: "numeric", month: "long", year: "numeric" },
                                      )
                                    : "—"}
                                </span>
                                <button
                                  type="button"
                                  onClick={startDateEdit}
                                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] underline decoration-[#1d1b18]/15 underline-offset-[5px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/45`}
                                >
                                  {t.editDate}
                                </button>
                              </div>
                            )}
                            {dateError && (
                              <p
                                className={`mt-2 ${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
                              >
                                {dateError}
                              </p>
                            )}
                          </div>

                          {/* Search + count */}
                          <div className="mt-6 flex flex-col gap-4 border-b border-[#1d1b18]/10 pb-3 md:flex-row md:items-end md:justify-between md:gap-6">
                            <div className="flex items-baseline gap-3">
                              <span
                                className={`${FONT_CLASS.cormorant} text-[40px] font-medium leading-none tabular-nums text-[#1d1b18]`}
                              >
                                {String(biomarkers.length).padStart(2, "0")}
                              </span>
                              <span
                                className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.8px] text-[#8a7f76]`}
                              >
                                {t.biomarkerCount}
                              </span>
                            </div>

                            {biomarkers.length > 0 && (
                              <label className="group relative flex items-center gap-2 border-b border-[#1d1b18]/15 py-1 transition-colors focus-within:border-[#97472c]">
                                <svg
                                  aria-hidden
                                  className="h-3.5 w-3.5 text-[#8a7f76] transition-colors group-focus-within:text-[#97472c]"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  strokeWidth={1.5}
                                  stroke="currentColor"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M21 21l-4.34-4.34m0 0A7.5 7.5 0 105.66 5.66a7.5 7.5 0 0011 11z"
                                  />
                                </svg>
                                <input
                                  type="text"
                                  placeholder={t.search}
                                  value={search}
                                  onChange={(e) => setSearch(e.target.value)}
                                  className={`w-full bg-transparent ${FONT_CLASS.manrope} text-[13px] italic text-[#1d1b18] outline-none placeholder:not-italic placeholder:text-[#8a7f76] md:w-[200px]`}
                                />
                              </label>
                            )}
                          </div>

                          {/* Edit hint */}
                          <p
                            className={`mt-4 ${FONT_CLASS.manrope} text-[12px] italic text-[#8a7f76]`}
                          >
                            {t.editHint}
                          </p>

                          {/* Biomarker rows */}
                          <div className="mt-2">
                            {filtered.length === 0 ? (
                              <p
                                className={`py-10 text-center ${FONT_CLASS.cormorant} text-[20px] italic text-[#8a7f76] md:text-[24px]`}
                              >
                                {t.noBiomarkers}
                              </p>
                            ) : (
                              <ul className="border-t border-[#1d1b18]/10">
                                {filtered.map((b) => {
                                  const z = zoneAccent((b.zone ?? "unclassified") as Zone);
                                  const isEditing = editingValueId === b.id;
                                  const displayName =
                                    b.biomarker_name ?? b.biomarker_key.replace(/_/g, " ");

                                  return (
                                    <li
                                      key={b.id}
                                      className="relative border-b border-[#1d1b18]/10"
                                    >
                                      <div className="flex flex-col gap-3 py-4 md:flex-row md:items-center md:justify-between">
                                        <div className="min-w-0 flex-1">
                                          <p
                                            className={`truncate ${FONT_CLASS.cormorant} text-[19px] font-medium leading-tight text-[#1d1b18] md:text-[22px]`}
                                          >
                                            {displayName}
                                          </p>
                                          <p
                                            className={`mt-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.8px]`}
                                            style={{ color: z.stroke }}
                                          >
                                            {locale === "es" ? z.label.es : z.label.en}
                                          </p>
                                        </div>

                                        {isEditing ? (
                                          <div className="flex flex-wrap items-center gap-3">
                                            <input
                                              type="text"
                                              inputMode="decimal"
                                              value={editValue}
                                              onChange={(e) => setEditValue(e.target.value)}
                                              autoFocus
                                              className={`w-20 border-b border-[#1d1b18]/30 bg-transparent py-1 text-right ${FONT_CLASS.dmMono} text-[16px] tabular-nums text-[#1d1b18] outline-none focus:border-[#97472c]`}
                                            />
                                            <input
                                              type="text"
                                              value={editUnit}
                                              onChange={(e) => setEditUnit(e.target.value)}
                                              placeholder="mg/dL"
                                              className={`w-20 border-b border-[#1d1b18]/15 bg-transparent py-1 ${FONT_CLASS.dmMono} text-[11px] uppercase tracking-[1.2px] text-[#8a7f76] outline-none focus:border-[#97472c]`}
                                            />
                                            <button
                                              type="button"
                                              onClick={saveValueEdit}
                                              disabled={valueSaving}
                                              className={`${FONT_CLASS.manrope} text-[11px] font-semibold uppercase tracking-[1.4px] text-[#97472c] underline decoration-[#97472c]/30 underline-offset-[5px] transition-colors hover:decoration-[#97472c] disabled:opacity-60`}
                                            >
                                              {valueSaving ? t.saving : t.save}
                                            </button>
                                            <button
                                              type="button"
                                              onClick={cancelValueEdit}
                                              disabled={valueSaving}
                                              className={`${FONT_CLASS.manrope} text-[11px] font-medium uppercase tracking-[1.4px] text-[#8a7f76] transition-colors hover:text-[#1d1b18] disabled:opacity-60`}
                                            >
                                              {t.cancel}
                                            </button>
                                          </div>
                                        ) : (
                                          <div className="flex items-baseline gap-4">
                                            <span
                                              className={`${FONT_CLASS.dmMono} text-[18px] font-medium tabular-nums text-[#1d1b18] md:text-[22px]`}
                                            >
                                              {fmtValue(b.value)}
                                            </span>
                                            <span
                                              className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.2px] text-[#8a7f76]`}
                                            >
                                              {b.unit}
                                            </span>
                                            <button
                                              type="button"
                                              onClick={() => startValueEdit(b)}
                                              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] underline decoration-[#1d1b18]/15 underline-offset-[5px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/45`}
                                            >
                                              {t.edit}
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                    </li>
                                  );
                                })}
                              </ul>
                            )}
                            {valueError && (
                              <p
                                className={`mt-3 ${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
                              >
                                {valueError}
                              </p>
                            )}
                          </div>

                          {/* Delete row */}
                          <div className="mt-10 flex items-center gap-3 border-t border-[#1d1b18]/15 pt-5">
                            <span aria-hidden className="h-px flex-1 bg-[#1d1b18]/12" />
                            <button
                              type="button"
                              onClick={() => {
                                setConfirmingDelete(true);
                                setDeleteError(null);
                              }}
                              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#b04040] underline decoration-[#b04040]/40 underline-offset-[5px] transition-colors hover:decoration-[#b04040]`}
                            >
                              {t.delete}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.article>
                );
              })}
            </div>
          </motion.div>

          {/* ── Footer CTA ── */}
          <motion.section
            variants={fadeUp}
            className="mt-16 flex flex-col gap-6 border-t border-[#1d1b18]/10 pt-10 md:flex-row md:items-end md:justify-between md:gap-10"
          >
            <p
              className={`max-w-[36ch] ${FONT_CLASS.cormorant} text-[28px] font-medium leading-[1.15] text-[#1d1b18] md:text-[36px]`}
              style={{ textWrap: "balance" } as React.CSSProperties}
            >
              {locale === "es"
                ? "El archivo crece contigo."
                : "The archive grows with you."}{" "}
              <span className="italic text-[#97472c]">
                {locale === "es" ? "Anade la siguiente." : "File the next one."}
              </span>
            </p>
            <Link
              href={`/${locale}/upload`}
              className={`group inline-flex items-center gap-3 self-start rounded-full bg-[#1d1b18] px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0`}
            >
              {locale === "es" ? "Subir lectura" : "File a reading"}
              <span
                aria-hidden
                className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
              >
                <svg
                  className="h-3 w-3"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={2}
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                  />
                </svg>
              </span>
            </Link>
          </motion.section>
        </div>
      </div>

      <EditorialDeleteModal
        open={confirmingDelete}
        kicker={t.confirmDeleteKicker}
        title={t.confirmDeleteTitle}
        body={t.confirmDeleteBody}
        cancelLabel={t.cancel}
        confirmLabel={t.confirmDelete}
        busyLabel={t.deleting}
        busy={deleting}
        error={deleteError}
        onCancel={() => setConfirmingDelete(false)}
        onConfirm={deleteLab}
      />
    </DashboardChrome>
  );
}
