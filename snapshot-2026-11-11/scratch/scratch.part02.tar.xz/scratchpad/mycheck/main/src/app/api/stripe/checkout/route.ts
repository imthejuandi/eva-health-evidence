import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getStripe, getOrCreateCustomer } from "@/lib/stripe/helpers";

type CheckoutPlan = "quarterly" | "annual" | "full_panel";

const SUBSCRIPTION_PLANS: ReadonlySet<string> = new Set(["quarterly", "annual"]);

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const locale = (body.locale as string) ?? "en";
    const plan = (body.plan as CheckoutPlan) ?? "quarterly";

    // Derive the redirect target from the live request origin so the
    // post-checkout landing page always matches the host the user
    // started checkout from. Avoids the historical bug where a stale
    // NEXT_PUBLIC_APP_URL env var (e.g. set to localhost during early
    // testing) caused production users to be redirected to localhost
    // after paying. The env var is kept as a last-resort fallback for
    // edge runtimes that don't expose origin.
    const appUrl =
      req.nextUrl.origin ||
      process.env.NEXT_PUBLIC_APP_URL ||
      "http://localhost:3000";

    const customerId = await getOrCreateCustomer(user.id, user.email!);
    const stripe = getStripe();

    if (plan !== "full_panel" && !SUBSCRIPTION_PLANS.has(plan)) {
      return NextResponse.json({ error: `Unknown plan: ${plan}` }, { status: 400 });
    }

    const isFullPanel = plan === "full_panel";
    // Same product, two recurring prices: quarterly and annual (decision
    // 2026-08 — docs/lab-integration-message-logistics.md §6). The webhook
    // records which plan was bought via metadata; kit cadence is paced by the
    // cycle-scheduler, never by the billing interval directly.
    const priceId = isFullPanel
      ? process.env.STRIPE_PRICE_ID_FULL_PANEL
      : plan === "annual"
        ? process.env.STRIPE_PRICE_ID_ANNUAL
        : process.env.STRIPE_PRICE_ID_QUARTERLY;

    if (!priceId) {
      return NextResponse.json(
        { error: `Missing Stripe price ID for plan: ${plan}` },
        { status: 500 },
      );
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: isFullPanel ? "payment" : "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      // Collect a shipping address inside Stripe Checkout. The webhook
      // handler reads it back from `session.shipping_details` and saves
      // it to the user's profile. Limited to ES for now — expand the
      // allowlist when we're ready to ship internationally.
      shipping_address_collection: {
        allowed_countries: ["ES"],
      },
      // Phone number is useful for the carrier; Stripe's checkout asks
      // for it inline when this flag is on.
      phone_number_collection: { enabled: true },
      success_url: `${appUrl}/${locale}/dashboard?${isFullPanel ? "fullpanel=true" : "subscribed=true"}`,
      cancel_url: `${appUrl}/${locale}/pricing`,
      metadata: { userId: user.id, plan },
    });

    return NextResponse.json({ url: session.url });
  } catch (e) {
    // Surface the underlying Stripe / Supabase error to the caller so
    // misconfigured price IDs, currency mismatches, etc. are visible
    // in the browser console + Vercel logs instead of producing a
    // silent "Checkout failed" generic.
    const message = e instanceof Error ? e.message : "Checkout failed";
    console.error("[stripe/checkout]", e);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
