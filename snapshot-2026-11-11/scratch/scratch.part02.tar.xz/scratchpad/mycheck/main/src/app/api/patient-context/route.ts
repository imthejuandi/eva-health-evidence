import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createNewVersion, getCurrentVersion, toSnapshot } from "@/lib/patient-context";
import { DurableContextSnapshotSchema } from "@/lib/patient-context/schema";

/**
 * GET /api/patient-context
 * Returns the user's current durable-context version (or null if they
 * have never filled in their context). Used by the upload flow's
 * context gate to render the "still accurate?" summary.
 */
export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const row = await getCurrentVersion(user.id).catch((err: Error) => {
    console.error("[patient-context.GET] load failed:", err);
    return null;
  });
  if (!row) return NextResponse.json({ version: null });
  return NextResponse.json({
    version: {
      id: row.id,
      version_number: row.version_number,
      is_empty: row.is_empty,
      created_at: row.created_at,
      snapshot: toSnapshot(row),
    },
  });
}

/**
 * POST /api/patient-context
 * Creates a new version row from the submitted snapshot. Append-only:
 * the previous version (if any) remains intact so prior lab_results
 * keep pointing at the context they were interpreted under.
 *
 * Body: { snapshot: DurableContextSnapshot }
 */
export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const raw = await req.json().catch(() => null);
  const parsed = DurableContextSnapshotSchema.safeParse(raw?.snapshot);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid snapshot", details: parsed.error.issues },
      { status: 400 },
    );
  }

  try {
    const row = await createNewVersion(user.id, parsed.data);
    return NextResponse.json({
      version: {
        id: row.id,
        version_number: row.version_number,
        is_empty: row.is_empty,
        created_at: row.created_at,
      },
    });
  } catch (err) {
    console.error("[patient-context.POST] create failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to save context" },
      { status: 500 },
    );
  }
}
