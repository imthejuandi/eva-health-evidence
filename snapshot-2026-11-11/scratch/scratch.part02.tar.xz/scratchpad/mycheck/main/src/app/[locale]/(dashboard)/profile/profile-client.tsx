"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useDropzone } from "react-dropzone";
import { motion } from "framer-motion";
import { createClient } from "@/lib/supabase/client";
import {
  europeanToIso,
  isoToEuropean,
  formatEuropeanInput,
} from "@/lib/biomarkers/date-format";
import {
  DashboardChrome,
  EditorialMasthead,
  PrimaryPill,
  GhostLink,
  EditorialModal,
} from "@/components/dashboard";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import { FONT_CLASS } from "@/lib/dashboard-tokens";
import type { Profile } from "@/lib/queries/types";

interface ProfileClientProps {
  locale: string;
  email: string;
  profile: Profile | null;
}

type HealthLevel = "beginner" | "familiar" | "optimizer";

/* ──────────────────────────────────────────────────────────────────────
 * Editorial primitives — kept inline; will graduate to the shared
 * dashboard layer in the Task 8 polish pass if reused on a third page.
 * ────────────────────────────────────────────────────────────────────── */

/* Inline DossierMasthead removed — uses shared EditorialMasthead. */

function SectionHeader({
  kicker,
  title,
  accent,
  subtitle,
}: {
  kicker: string;
  title: string;
  accent?: string;
  subtitle?: string;
}) {
  return (
    <header className="flex flex-col gap-3">
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className="inline-block h-px w-8 bg-[#1d1b18]/25 md:w-12"
        />
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]`}
        >
          {kicker}
        </p>
      </div>
      <h2
        className={`${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[48px] md:tracking-[-1px]`}
        style={{ textWrap: "balance" } as React.CSSProperties}
      >
        {title}{" "}
        {accent && <span className="italic text-[#97472c]">{accent}</span>}
      </h2>
      {subtitle && (
        <p
          className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#8a7f76] md:text-[15px]`}
        >
          {subtitle}
        </p>
      )}
    </header>
  );
}

function HairlineField({
  label,
  helper,
  error,
  children,
}: {
  label: string;
  helper?: string;
  error?: string | null;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span
        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
      >
        {label}
      </span>
      {children}
      {error ? (
        <span
          className={`${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
        >
          {error}
        </span>
      ) : helper ? (
        <span
          className={`${FONT_CLASS.manrope} text-[12px] italic text-[#8a7f76]`}
        >
          {helper}
        </span>
      ) : null}
    </label>
  );
}

const hairlineInputClass = `w-full border-b border-[#1d1b18]/20 bg-transparent py-2 ${FONT_CLASS.cormorant} text-[20px] text-[#1d1b18] outline-none transition-colors placeholder:italic placeholder:text-[#8a7f76]/60 focus:border-[#97472c] md:text-[22px]`;

function SegmentedChooser<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T | "";
  options: { key: T; label: string; helper?: string }[];
  onChange: (key: T) => void;
}) {
  return (
    <div className="grid gap-3 sm:grid-cols-3 md:gap-4">
      {options.map((opt) => {
        const active = value === opt.key;
        return (
          <button
            key={opt.key}
            type="button"
            onClick={() => onChange(opt.key)}
            className={`group relative flex h-full min-h-[110px] flex-col items-start justify-between rounded-[14px] border p-4 text-left transition-all md:p-5 ${
              active
                ? "border-[#97472c] bg-[rgba(151,71,44,0.05)]"
                : "border-[#1d1b18]/12 bg-[#fef8f2]/60 hover:border-[#1d1b18]/30"
            }`}
          >
            <span
              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] ${
                active ? "text-[#97472c]" : "text-[#8a7f76]"
              }`}
            >
              {active ? "✓" : "○"}
            </span>
            <p
              className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic leading-tight md:text-[22px] ${
                active ? "text-[#97472c]" : "text-[#1d1b18]"
              }`}
            >
              {opt.label}
            </p>
            {opt.helper && (
              <p
                className={`${FONT_CLASS.manrope} text-[11px] text-[#8a7f76]`}
              >
                {opt.helper}
              </p>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* PrimaryPill, GhostLink, and EditorialModal now imported from
 * @/components/dashboard. */

/* ──────────────────────────────────────────────────────────────────────
 * Profile client
 * ────────────────────────────────────────────────────────────────────── */

export function ProfileClient({ locale, email, profile }: ProfileClientProps) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [knowledgeSaving, setKnowledgeSaving] = useState(false);
  const [knowledgeSaved, setKnowledgeSaved] = useState(false);

  const legacyParts = (profile?.full_name ?? "").trim().split(/\s+/);
  const initialFirstName = profile?.first_name ?? legacyParts[0] ?? "";
  const initialLastName =
    profile?.last_name ??
    (legacyParts.length > 1 ? legacyParts.slice(1).join(" ") : "");

  const [form, setForm] = useState({
    first_name: initialFirstName,
    last_name: initialLastName,
    second_surname: profile?.second_surname ?? "",
    date_of_birth: isoToEuropean(profile?.date_of_birth ?? ""),
    sex: profile?.sex ?? "",
    height_cm: profile?.height_cm?.toString() ?? "",
    weight_kg: profile?.weight_kg?.toString() ?? "",
    health_knowledge: (profile?.health_knowledge ?? "") as HealthLevel | "",
  });
  const [dobError, setDobError] = useState<string | null>(null);

  const [showWearableModal, setShowWearableModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [wearableUploading, setWearableUploading] = useState(false);
  const [wearableResult, setWearableResult] = useState<{
    daysImported: number;
    dateRange: { start: string; end: string };
  } | null>(null);
  const [wearableError, setWearableError] = useState<string | null>(null);

  const [addr, setAddr] = useState({
    address_line1: profile?.address_line1 ?? "",
    address_line2: profile?.address_line2 ?? "",
    address_city: profile?.address_city ?? "",
    address_postal_code: profile?.address_postal_code ?? "",
    address_province: profile?.address_province ?? "",
    address_country: profile?.address_country ?? "ES",
    phone: profile?.phone ?? "",
    // Identity document — required by the lab on every order (PID.3).
    id_document_type: profile?.id_document_type ?? "",
    id_document_number: profile?.id_document_number ?? "",
  });
  const [addrSaving, setAddrSaving] = useState(false);
  const [addrSaved, setAddrSaved] = useState(false);
  const [addrError, setAddrError] = useState<string | null>(null);

  const [subBusy, setSubBusy] = useState<"checkout" | "portal" | null>(null);
  const [subError, setSubError] = useState<string | null>(null);

  // Marketing-email consent (LEG-007). Withdrawal/management lives here so
  // opt-in given at signup can be revoked "as easily as it was given".
  const [marketingOptIn, setMarketingOptIn] = useState<boolean>(
    profile?.marketing_opt_in ?? false,
  );
  const [marketingSaving, setMarketingSaving] = useState(false);
  const [marketingError, setMarketingError] = useState<string | null>(null);

  const onWearableDrop = useCallback(async (accepted: File[]) => {
    if (accepted.length === 0) return;
    setWearableUploading(true);
    setWearableError(null);
    try {
      const formData = new FormData();
      formData.append("file", accepted[0]);
      formData.append("source", "apple_health");
      const res = await fetch("/api/wearables/import", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "Import failed");
      }
      const data = await res.json();
      setWearableResult(data);
    } catch (e) {
      setWearableError(e instanceof Error ? e.message : "Failed");
    } finally {
      setWearableUploading(false);
    }
  }, []);

  const {
    getRootProps: getWearableRootProps,
    getInputProps: getWearableInputProps,
  } = useDropzone({
    onDrop: onWearableDrop,
    accept: { "application/zip": [".zip"] },
    maxFiles: 1,
    maxSize: 500 * 1024 * 1024,
  });

  const t =
    locale === "es"
      ? {
          back: "Volver al panel",
          // Hero
          kickerHero: "§ El dossier",
          heroTitle: "Tu",
          heroAccent: "credencial.",
          heroLede:
            "La identidad que da contexto a cada lectura. Manten esto al dia y la IA y los emails te llamaran como debe.",
          // Plan pill labels
          activePlan: "Suscripcion activa",
          freePlan: "Plan gratuito",
          pastDuePlan: "Pago pendiente",
          cancelledPlan: "Cancelada",
          // Identity
          kickerIdentity: "§ I · Identidad",
          identityTitle: "Quien",
          identityAccent: "eres.",
          identitySubtitle:
            "Nombre, fecha de nacimiento y biometria basica. Usados en cada interpretacion clinica.",
          firstName: "Nombre",
          lastName: "Primer apellido",
          secondSurname: "Segundo apellido",
          secondSurnameHelper: "Si no tienes, dejalo vacio.",
          surnameHelper:
            "El laboratorio necesita los apellidos por separado para identificar tu muestra.",
          dob: "Fecha de nacimiento",
          dobHelper: "DD/MM/AAAA",
          dobInvalid: "Fecha invalida. Usa DD/MM/AAAA.",
          sex: "Sexo biologico",
          sexMale: "Masculino",
          sexFemale: "Femenino",
          height: "Altura (cm)",
          weight: "Peso (kg)",
          save: "Guardar cambios",
          saving: "Guardando...",
          saved: "Guardado",
          // Body & knowledge
          kickerKnowledge: "§ II · Cuerpo y saber",
          knowledgeTitle: "Cuanto",
          knowledgeAccent: "ya sabes.",
          knowledgeSubtitle:
            "Lo que elijas aqui decide como te explicamos cada biomarcador y cada accion. La interpretacion clinica no cambia, solo el lenguaje. Cambialo cuando quieras y la siguiente lectura saldra con el nuevo tono.",
          beginner: "Empezando",
          beginnerHelper: "Como en clase de bachillerato. Sin jerga, con analogias.",
          familiar: "Algo familiar",
          familiarHelper: "Termino medio. Nombres reales con contexto breve.",
          optimizer: "Optimizador",
          optimizerHelper: "Profundidad clinica. Mecanismo, via y magnitud.",
          knowledgeNote:
            "Tu eliges como leerte. El diagnostico es el mismo en los tres niveles, cambia solo la forma de contarlo.",
          knowledgeSave: "Guardar nivel",
          knowledgeSaved: "Nivel guardado",
          knowledgeSavingLabel: "Reescribiendo tu lectura...",
          // Devices
          kickerDevices: "§ III · Dispositivos",
          devicesTitle: "Tus",
          devicesAccent: "wearables.",
          devicesSubtitle:
            "Conecta Apple Health para correlacionar sueno, HRV y descanso con tus marcadores.",
          appleHealth: "Apple Health",
          notConnected: "Sin conectar",
          connect: "Conectar",
          syncAgain: "Sincronizar",
          comingSoon: "Proximamente",
          devicesLockedKicker: "§ Solo para socios",
          devicesLockedTitle: "Wearables para",
          devicesLockedAccent: "miembros.",
          devicesLockedBody:
            "La integracion con Apple Health, Oura, Whoop y Garmin es exclusiva para clientes de los planes Trimestral o Panel Completo. Te leemos sueno, HRV y recuperacion junto a tus biomarcadores para que la lectura sea completa.",
          devicesLockedCta: "Ver planes",
          // Shipping
          kickerShipping: "§ IV · Envio",
          shippingTitle: "A donde llega",
          shippingAccent: "tu kit.",
          shippingSubtitle:
            "Tu kit trimestral se envia a esta direccion. La capturamos en tu primer pago; aqui puedes editarla antes del proximo envio.",
          shippingNoneTitle: "Sin direccion archivada",
          shippingNoneBody:
            "La capturamos automaticamente cuando hagas tu primera compra. Si quieres adelantarte, rellena los campos.",
          idDocTitle: "Documento de identidad",
          idDocHelp:
            "El laboratorio lo exige para registrar tu muestra. Sin el no podemos enviar tu kit.",
          idDocType: "Tipo de documento",
          idDocNumber: "Numero",
          idDocTypes: { DNI: "DNI", NIE: "NIE", PASAPORTE: "Pasaporte", OTROS: "Otro" },
          idDocPickType: "Selecciona…",
          addrLine1: "Direccion (linea 1)",
          addrLine2: "Direccion (linea 2)",
          addrCity: "Ciudad",
          addrPostal: "Codigo postal",
          addrProvince: "Provincia",
          addrCountry: "Pais",
          addrPhone: "Telefono",
          addrSave: "Guardar direccion",
          addrSaving: "Guardando...",
          addrSaved: "Direccion actualizada",
          addrError: "No se pudo guardar.",
          // Subscription
          kickerSub: "§ V · Suscripcion",
          subTitleActive: "Tu plan",
          subTitleFree: "Empieza tu",
          subTitlePastDue: "Pago",
          subTitleCancelled: "Suscripcion",
          subAccentActive: "trimestral.",
          subAccentFree: "suscripcion.",
          subAccentPastDue: "pendiente.",
          subAccentCancelled: "pausada.",
          subFreeBody:
            "Sube analisis gratis. Suscribete para recibir kits trimestrales y acceso completo.",
          subActiveBody: "Renueva el ",
          subPastDueBody:
            "Tu suscripcion esta pendiente de pago. Actualiza el metodo de pago para mantener tus envios trimestrales.",
          subCancelledBody:
            "Cuando quieras volver, tu historial sigue donde lo dejaste.",
          subscribeCta: "Suscribirme · €99 / trimestre",
          manageSub: "Gestionar en Stripe",
          reactivate: "Reactivar suscripcion",
          // Language
          kickerLang: "§ VI · Idioma",
          langTitle: "En que",
          langAccent: "te leemos.",
          // Communications (marketing opt-in / withdrawal — LEG-007)
          kickerComms: "§ VII · Comunicaciones",
          commsTitle: "Lo que te",
          commsAccent: "enviamos.",
          commsSubtitle:
            "Decide si quieres recibir consejos de salud, novedades y ofertas por correo. Esto no afecta a los emails esenciales sobre tu cuenta, pedidos o resultados.",
          marketingLabel: "Correos de marketing",
          marketingHelperOn:
            "Activado — recibes consejos, novedades y ofertas. Desactívalo cuando quieras.",
          marketingHelperOff:
            "Desactivado — solo te escribimos lo imprescindible sobre tu cuenta.",
          marketingSaving: "Guardando...",
          marketingError: "No se pudo actualizar. Inténtalo de nuevo.",
          // Archive
          kickerArchive: "§ VIII · Archivo y cuenta",
          archiveTitle: "Tus datos,",
          archiveAccent: "tuyos.",
          archiveSubtitle:
            "Descarga todo lo que tenemos sobre ti, o cierra la puerta para siempre.",
          exportData: "Descargar mis datos",
          deleteAccount: "Eliminar mi cuenta",
          // Support
          kickerSupport: "§ IX · Soporte",
          supportTitle: "Cuando",
          supportAccent: "necesites.",
          chatWithUs: "Chatea con nosotros",
          emailSupport: "Soporte por email",
          faq: "Preguntas frecuentes",
          // Logout
          logoutQuote: "Cierra sesion cuando termines.",
          logoutAccent: "Tu lectura te espera la proxima vez.",
          logout: "Cerrar sesion",
          // Modals
          wearableModalKicker: "§ Importar Apple Health",
          wearableModalTitle: "Sube tu",
          wearableModalAccent: "exportacion.",
          wearableHowTo: "Como exportar:",
          wearableStep1: "Abre la app Salud en tu iPhone",
          wearableStep2: "Toca tu foto de perfil arriba a la derecha",
          wearableStep3: "Selecciona 'Exportar todos los datos de Salud'",
          wearableStep4: "Sube el ZIP aqui",
          wearableDrop: "Arrastra el ZIP aqui o pulsa",
          wearableSize: "export.zip · hasta 500MB",
          wearableProcessing: "Procesando...",
          wearableImported: "{n} dias importados",
          deleteModalKicker: "§ Eliminar la cuenta",
          deleteModalTitle: "Eliminar tu",
          deleteModalAccent: "cuenta.",
          deleteBody:
            "Esta accion es permanente. Eliminamos todos tus datos de salud, resultados, mensajes y suscripcion.",
          deleteConfirmLabel:
            "Escribe DELETE_MY_ACCOUNT para confirmar",
          cancel: "Cancelar",
          delete: "Eliminar",
          deletingLabel: "Eliminando...",
        }
      : {
          back: "Back to dashboard",
          kickerHero: "§ The dossier",
          heroTitle: "Your",
          heroAccent: "credentials.",
          heroLede:
            "The identity that gives every reading its context. Keep this current and the AI and emails will call you the right things.",
          activePlan: "Subscription active",
          freePlan: "Free plan",
          pastDuePlan: "Payment past due",
          cancelledPlan: "Cancelled",
          kickerIdentity: "§ I · Identity",
          identityTitle: "Who you",
          identityAccent: "are.",
          identitySubtitle:
            "Name, date of birth, basic biometrics. Every clinical interpretation reads against these.",
          firstName: "First name",
          lastName: "First surname",
          secondSurname: "Second surname",
          secondSurnameHelper: "Leave it empty if you don't have one.",
          surnameHelper:
            "The lab needs your surnames as separate fields to identify your sample.",
          dob: "Date of birth",
          dobHelper: "DD/MM/YYYY",
          dobInvalid: "Invalid date. Use DD/MM/YYYY.",
          sex: "Biological sex",
          sexMale: "Male",
          sexFemale: "Female",
          height: "Height (cm)",
          weight: "Weight (kg)",
          save: "Save changes",
          saving: "Saving...",
          saved: "Saved",
          kickerKnowledge: "§ II · Body & knowledge",
          knowledgeTitle: "How much",
          knowledgeAccent: "you already know.",
          knowledgeSubtitle:
            "What you pick here decides how every biomarker and action step is written for you. The clinical reading itself doesn't change. Only the wording does. Switch tier whenever you want; the next reading comes back in the new tone.",
          beginner: "Just starting",
          beginnerHelper: "High-school level. Plain English, everyday analogies.",
          familiar: "Somewhat familiar",
          familiarHelper: "In between. Real names, with a one-line why.",
          optimizer: "Deep optimizer",
          optimizerHelper: "Clinician depth. Mechanism, pathway, magnitude.",
          knowledgeNote:
            "You pick how you want to be read. The diagnosis is the same across all three tiers; only the explanation shifts.",
          knowledgeSave: "Save tier",
          knowledgeSaved: "Tier saved",
          knowledgeSavingLabel: "Rephrasing your reading...",
          kickerDevices: "§ III · Devices",
          devicesTitle: "Your",
          devicesAccent: "wearables.",
          devicesSubtitle:
            "Connect Apple Health so we can correlate sleep, HRV and recovery with your markers.",
          appleHealth: "Apple Health",
          notConnected: "Not connected",
          connect: "Connect",
          syncAgain: "Sync again",
          comingSoon: "Coming soon",
          devicesLockedKicker: "§ Members only",
          devicesLockedTitle: "Wearables are",
          devicesLockedAccent: "for members.",
          devicesLockedBody:
            "Apple Health, Oura, Whoop and Garmin integration is reserved for Quarterly subscribers and Full Panel buyers. We read your sleep, HRV and recovery alongside your bloodwork so the picture is complete.",
          devicesLockedCta: "See plans",
          kickerShipping: "§ IV · Shipping",
          shippingTitle: "Where your",
          shippingAccent: "kit lands.",
          shippingSubtitle:
            "Your quarterly kit ships to this address. We capture it on your first payment; edit it any time before the next shipment.",
          shippingNoneTitle: "No address on file yet",
          shippingNoneBody:
            "Stripe captures it automatically on your first purchase. If you need to change it before then, fill in the fields below.",
          idDocTitle: "Identity document",
          idDocHelp:
            "The lab requires it to register your sample. We can't ship your kit without it.",
          idDocType: "Document type",
          idDocNumber: "Number",
          idDocTypes: { DNI: "DNI", NIE: "NIE", PASAPORTE: "Passport", OTROS: "Other" },
          idDocPickType: "Select…",
          addrLine1: "Address line 1",
          addrLine2: "Address line 2",
          addrCity: "City",
          addrPostal: "Postal code",
          addrProvince: "Province",
          addrCountry: "Country",
          addrPhone: "Phone",
          addrSave: "Save address",
          addrSaving: "Saving...",
          addrSaved: "Address updated",
          addrError: "Couldn't save.",
          kickerSub: "§ V · Subscription",
          subTitleActive: "Your",
          subTitleFree: "Start your",
          subTitlePastDue: "Payment",
          subTitleCancelled: "Subscription",
          subAccentActive: "quarterly plan.",
          subAccentFree: "subscription.",
          subAccentPastDue: "past due.",
          subAccentCancelled: "paused.",
          subFreeBody:
            "Upload existing labs free. Subscribe to receive quarterly kits and full platform access.",
          subActiveBody: "Renews ",
          subPastDueBody:
            "Your subscription is flagged as past due. Update your payment method to keep your quarterly kits coming.",
          subCancelledBody:
            "Whenever you want to come back, your history is still here.",
          subscribeCta: "Subscribe · €99 / quarter",
          manageSub: "Manage in Stripe",
          reactivate: "Reactivate subscription",
          kickerLang: "§ VI · Language",
          langTitle: "What we",
          langAccent: "speak to you in.",
          kickerComms: "§ VII · Communications",
          commsTitle: "What we",
          commsAccent: "send you.",
          commsSubtitle:
            "Choose whether to receive health tips, product news and offers by email. This doesn't affect essential emails about your account, orders or results.",
          marketingLabel: "Marketing emails",
          marketingHelperOn:
            "On — you'll get tips, news and offers. Turn it off any time.",
          marketingHelperOff:
            "Off — we'll only email you essential account messages.",
          marketingSaving: "Saving...",
          marketingError: "Couldn't update. Please try again.",
          kickerArchive: "§ VIII · Archive & account",
          archiveTitle: "Your data,",
          archiveAccent: "yours.",
          archiveSubtitle:
            "Download everything we have on you, or close the door for good.",
          exportData: "Export my data",
          deleteAccount: "Delete my account",
          kickerSupport: "§ IX · Support",
          supportTitle: "When you",
          supportAccent: "need us.",
          chatWithUs: "Chat with us",
          emailSupport: "Email support",
          faq: "Frequently asked",
          logoutQuote: "Log out when you're done.",
          logoutAccent: "Your reading will be here next time.",
          logout: "Log out",
          wearableModalKicker: "§ Import Apple Health",
          wearableModalTitle: "Drop your",
          wearableModalAccent: "export.",
          wearableHowTo: "How to export:",
          wearableStep1: "Open the Health app on your iPhone",
          wearableStep2: "Tap your profile picture (top right)",
          wearableStep3: "Select 'Export All Health Data'",
          wearableStep4: "Drop the ZIP here",
          wearableDrop: "Drag the ZIP here or click",
          wearableSize: "export.zip · up to 500MB",
          wearableProcessing: "Processing...",
          wearableImported: "{n} days imported",
          deleteModalKicker: "§ Remove the account",
          deleteModalTitle: "Delete your",
          deleteModalAccent: "account.",
          deleteBody:
            "This action is permanent. We'll erase all your health data, results, messages and subscription.",
          deleteConfirmLabel: "Type DELETE_MY_ACCOUNT to confirm",
          cancel: "Cancel",
          delete: "Delete",
          deletingLabel: "Deleting...",
        };

  const fullName = [form.first_name, form.last_name, form.second_surname].filter(Boolean).join(" ");
  const initials =
    fullName
      .split(" ")
      .map((n) => n[0])
      .join("")
      .slice(0, 2)
      .toUpperCase() || "?";

  const subStatus = profile?.subscription_status ?? "free";
  const isActive = subStatus === "active";
  const isPastDue = subStatus === "past_due";
  const isCancelled = subStatus === "cancelled";
  const isFree = subStatus === "free";
  // Paid-only feature gate: active quarterly subscribers and Full Panel
  // buyers qualify. Mirrors hasPaidAccess() in src/lib/stripe/helpers.ts;
  // duplicated inline here so this client component does not pull in
  // the server-only Stripe/Supabase imports.
  const isPaid = isActive || !!profile?.full_panel_purchased_at;

  const planPillLabel = isActive
    ? t.activePlan
    : isPastDue
      ? t.pastDuePlan
      : isCancelled
        ? t.cancelledPlan
        : t.freePlan;
  const planPillClass = isActive
    ? "border border-[#3a665e]/30 text-[#3a665e]"
    : isPastDue
      ? "border border-[#c49332]/40 text-[#c49332]"
      : isCancelled
        ? "border border-[#b04040]/30 text-[#b04040]"
        : "border border-[#1d1b18]/15 text-[#8a7f76]";

  async function handleSave() {
    let dobIso: string | null = null;
    if (form.date_of_birth.trim()) {
      dobIso = europeanToIso(form.date_of_birth);
      if (!dobIso) {
        setDobError(t.dobInvalid);
        return;
      }
    }
    setDobError(null);
    setSaving(true);
    setSaved(false);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const firstName = form.first_name.trim();
    const lastName = form.last_name.trim();
    const secondSurname = form.second_surname.trim();
    const fullNameOut = [firstName, lastName, secondSurname].filter(Boolean).join(" ");
    await supabase.from("profiles").upsert({
      id: user.id,
      first_name: firstName,
      last_name: lastName,
      second_surname: secondSurname || null,
      full_name: fullNameOut,
      date_of_birth: dobIso,
      sex: form.sex || null,
      height_cm: form.height_cm ? parseFloat(form.height_cm) : null,
      weight_kg: form.weight_kg ? parseFloat(form.weight_kg) : null,
      health_knowledge: form.health_knowledge || null,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
    router.refresh();
  }

  async function handleSaveKnowledge() {
    if (!form.health_knowledge) return;
    setKnowledgeSaving(true);
    setKnowledgeSaved(false);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setKnowledgeSaving(false);
      return;
    }
    const { error: updateError } = await supabase
      .from("profiles")
      .update({ health_knowledge: form.health_knowledge })
      .eq("id", user.id);
    if (updateError) {
      console.error("[profile] Failed to save knowledge tier:", updateError);
      setKnowledgeSaving(false);
      return;
    }
    try {
      await fetch("/api/lab-results/regenerate-summary", { method: "POST" });
    } catch (e) {
      console.error("[profile] Summary regeneration request failed:", e);
    }
    setKnowledgeSaving(false);
    setKnowledgeSaved(true);
    setTimeout(() => setKnowledgeSaved(false), 2200);
    router.refresh();
  }

  async function handleSaveAddress(e: React.FormEvent) {
    e.preventDefault();
    setAddrSaving(true);
    setAddrSaved(false);
    setAddrError(null);
    try {
      const res = await fetch("/api/profile/address", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(addr),
      });
      const data = await res.json();
      if (!res.ok) {
        setAddrError(data.error ?? null);
      } else {
        setAddrSaved(true);
        setTimeout(() => setAddrSaved(false), 2200);
        router.refresh();
      }
    } catch {
      setAddrError("Network error");
    } finally {
      setAddrSaving(false);
    }
  }

  async function handleToggleMarketing(next: boolean) {
    // Optimistic flip; revert if the write fails. Writes both the flag and
    // the change timestamp so opt-in AND withdrawal are demonstrably recorded.
    setMarketingError(null);
    setMarketingSaving(true);
    setMarketingOptIn(next);
    const supabase = createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setMarketingOptIn(!next);
      setMarketingSaving(false);
      return;
    }
    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        marketing_opt_in: next,
        marketing_opt_in_at: new Date().toISOString(),
      })
      .eq("id", user.id);
    if (updateError) {
      console.error("[profile] Failed to update marketing opt-in:", updateError);
      setMarketingOptIn(!next);
      setMarketingError(t.marketingError);
      setMarketingSaving(false);
      return;
    }
    setMarketingSaving(false);
    router.refresh();
  }

  async function handleSubscribe() {
    setSubBusy("checkout");
    setSubError(null);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale, plan: "quarterly" }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.assign(data.url);
        return;
      }
      setSubError(data.error ?? "Couldn't start checkout");
    } catch {
      setSubError("Network error");
    } finally {
      setSubBusy(null);
    }
  }

  async function handlePortal() {
    setSubBusy("portal");
    setSubError(null);
    try {
      const res = await fetch("/api/stripe/portal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ locale }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.assign(data.url);
        return;
      }
      setSubError(data.error ?? "Couldn't open portal");
    } catch {
      setSubError("Network error");
    } finally {
      setSubBusy(null);
    }
  }

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push(`/${locale}/login`);
  }

  function switchLocale(newLocale: string) {
    const path = window.location.pathname.replace(`/${locale}`, `/${newLocale}`);
    router.push(path);
  }

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1100px]">
          {/* Masthead + back */}
          <motion.div variants={fadeUp}>
            <EditorialMasthead issue={locale === "es" ? "El dossier" : "The dossier"} />
          </motion.div>

          <motion.div variants={fadeUp} className="mt-8">
            <Link
              href={`/${locale}/dashboard`}
              className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
            >
              <span aria-hidden>←</span>
              {t.back}
            </Link>
          </motion.div>

          {/* Hero */}
          <motion.section
            variants={fadeUp}
            className="mt-10 grid gap-10 md:mt-16 md:grid-cols-12 md:items-center md:gap-10"
          >
            <div className="md:col-span-3">
              <div
                className="flex h-28 w-28 items-center justify-center rounded-full md:h-36 md:w-36"
                style={{
                  background:
                    "radial-gradient(circle at 35% 30%, rgba(217,123,92,0.55), rgba(151,71,44,0.25) 60%, rgba(151,71,44,0.10) 100%)",
                  boxShadow:
                    "inset 0 1px 0 rgba(255,255,255,0.45), 0 18px 50px -16px rgba(151,71,44,0.45)",
                }}
              >
                <span
                  className={`${FONT_CLASS.cormorant} text-[44px] font-medium italic text-[#fef8f2] md:text-[56px]`}
                >
                  {initials}
                </span>
              </div>
            </div>
            <div className="md:col-span-9">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
              >
                {t.kickerHero}
              </p>
              <h1
                className={`mt-3 ${FONT_CLASS.cormorant} text-[48px] font-medium leading-[0.95] tracking-[-1px] text-[#1d1b18] md:text-[80px] md:tracking-[-2.5px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {fullName ? (
                  <>
                    {fullName.split(" ")[0]}{" "}
                    <span className="italic text-[#97472c]">
                      {fullName.split(" ").slice(1).join(" ") || t.heroAccent}
                    </span>
                  </>
                ) : (
                  <>
                    {t.heroTitle}{" "}
                    <span className="italic text-[#97472c]">{t.heroAccent}</span>
                  </>
                )}
              </h1>
              <div className="mt-5 flex flex-wrap items-baseline gap-x-4 gap-y-2">
                <p
                  className={`${FONT_CLASS.cormorant} text-[18px] italic text-[#4c463f] md:text-[20px]`}
                >
                  {email}
                </p>
                <span
                  className={`inline-block rounded-full bg-[#fef8f2]/60 px-3 py-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.6px] backdrop-blur-sm ${planPillClass}`}
                >
                  {planPillLabel}
                </span>
              </div>
              <p
                className={`mt-5 max-w-[52ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f] md:text-[16px]`}
                style={{ textWrap: "pretty" } as React.CSSProperties}
              >
                {t.heroLede}
              </p>
            </div>
          </motion.section>

          {/* § I — Identity */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerIdentity}
                title={t.identityTitle}
                accent={t.identityAccent}
                subtitle={t.identitySubtitle}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <div className="grid gap-5 md:grid-cols-2 md:gap-6">
                <HairlineField label={t.firstName}>
                  <input
                    type="text"
                    value={form.first_name}
                    onChange={(e) =>
                      setForm({ ...form, first_name: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <HairlineField label={t.lastName} helper={t.surnameHelper}>
                  <input
                    type="text"
                    value={form.last_name}
                    onChange={(e) =>
                      setForm({ ...form, last_name: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                {/* PID-6.1: its own field because splitting one "Apellidos"
                    box on whitespace mis-handled compound surnames. Optional —
                    ECH confirmed PID-6 is not mandatory, and many foreign
                    patients have a single surname. */}
                <HairlineField label={t.secondSurname} helper={t.secondSurnameHelper}>
                  <input
                    type="text"
                    value={form.second_surname}
                    onChange={(e) =>
                      setForm({ ...form, second_surname: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <HairlineField
                  label={t.dob}
                  helper={t.dobHelper}
                  error={dobError}
                >
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="DD/MM/YYYY"
                    pattern="\d{2}/\d{2}/\d{4}"
                    maxLength={10}
                    value={form.date_of_birth}
                    onChange={(e) => {
                      setForm({
                        ...form,
                        date_of_birth: formatEuropeanInput(e.target.value),
                      });
                      if (dobError) setDobError(null);
                    }}
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <div className="md:col-span-2">
                  <p
                    className={`mb-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                  >
                    {t.sex}
                  </p>
                  <div className="grid grid-cols-2 gap-3 md:gap-4">
                    {(["male", "female"] as const).map((s) => {
                      const active = form.sex === s;
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setForm({ ...form, sex: s })}
                          className={`group relative flex h-full min-h-[80px] items-center justify-between rounded-[14px] border p-4 text-left transition-all md:p-5 ${
                            active
                              ? "border-[#97472c] bg-[rgba(151,71,44,0.05)]"
                              : "border-[#1d1b18]/12 bg-[#fef8f2]/60 hover:border-[#1d1b18]/30"
                          }`}
                        >
                          <p
                            className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic md:text-[22px] ${
                              active ? "text-[#97472c]" : "text-[#1d1b18]"
                            }`}
                          >
                            {s === "male" ? t.sexMale : t.sexFemale}
                          </p>
                          <span
                            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] ${
                              active ? "text-[#97472c]" : "text-[#8a7f76]"
                            }`}
                          >
                            {active ? "✓" : "○"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <HairlineField label={t.height}>
                  <input
                    type="number"
                    value={form.height_cm}
                    onChange={(e) =>
                      setForm({ ...form, height_cm: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <HairlineField label={t.weight}>
                  <input
                    type="number"
                    value={form.weight_kg}
                    onChange={(e) =>
                      setForm({ ...form, weight_kg: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
              </div>
              <div className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-3">
                <PrimaryPill
                  onClick={handleSave}
                  loading={saving}
                  disabled={saving}
                >
                  {saved ? t.saved : saving ? t.saving : t.save}
                </PrimaryPill>
                {saved && (
                  <span
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#3a665e]`}
                  >
                    ✓ {t.saved}
                  </span>
                )}
              </div>
            </div>
          </motion.section>

          {/* § II — Body & Knowledge */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerKnowledge}
                title={t.knowledgeTitle}
                accent={t.knowledgeAccent}
                subtitle={t.knowledgeSubtitle}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <SegmentedChooser
                value={form.health_knowledge}
                onChange={(key) => setForm({ ...form, health_knowledge: key })}
                options={[
                  { key: "beginner", label: t.beginner, helper: t.beginnerHelper },
                  {
                    key: "familiar",
                    label: t.familiar,
                    helper: t.familiarHelper,
                  },
                  {
                    key: "optimizer",
                    label: t.optimizer,
                    helper: t.optimizerHelper,
                  },
                ]}
              />
              <p
                className={`mt-4 max-w-[58ch] ${FONT_CLASS.manrope} text-[13px] leading-[1.6] italic text-[#8a7f76]`}
              >
                {t.knowledgeNote}
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-3">
                <PrimaryPill
                  onClick={handleSaveKnowledge}
                  loading={knowledgeSaving}
                  disabled={knowledgeSaving || !form.health_knowledge}
                >
                  {knowledgeSaved
                    ? t.knowledgeSaved
                    : knowledgeSaving
                      ? t.knowledgeSavingLabel
                      : t.knowledgeSave}
                </PrimaryPill>
                {knowledgeSaved && (
                  <span
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#3a665e]`}
                  >
                    ✓ {t.knowledgeSaved}
                  </span>
                )}
              </div>
            </div>
          </motion.section>

          {/* § III — Devices */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerDevices}
                title={t.devicesTitle}
                accent={t.devicesAccent}
                subtitle={t.devicesSubtitle}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              {isPaid ? (
                <motion.div
                  variants={staggerTight}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true, margin: "-15%" }}
                  className="space-y-3"
                >
                  {/* Apple Health — connected */}
                  <motion.div
                    variants={fadeUp}
                    className="flex items-center justify-between rounded-[16px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-5 backdrop-blur-sm"
                  >
                    <div className="min-w-0">
                      <p
                        className={`${FONT_CLASS.cormorant} text-[24px] font-medium italic text-[#1d1b18] md:text-[26px]`}
                      >
                        {t.appleHealth}
                      </p>
                      <p
                        className={`mt-1 ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                      >
                        {wearableResult
                          ? `${wearableResult.daysImported} ${
                              locale === "es" ? "dias importados" : "days imported"
                            }`
                          : t.notConnected}
                      </p>
                    </div>
                    <GhostLink onClick={() => setShowWearableModal(true)}>
                      {wearableResult ? t.syncAgain : t.connect}
                    </GhostLink>
                  </motion.div>
                  {/* Coming soon — Oura/Whoop/Garmin */}
                  {["Oura", "Whoop", "Garmin"].map((name) => (
                    <motion.div
                      key={name}
                      variants={fadeUp}
                      className="flex items-center justify-between rounded-[16px] border border-[#1d1b18]/8 bg-[#fef8f2]/40 p-5 opacity-50"
                    >
                      <p
                        className={`${FONT_CLASS.cormorant} text-[22px] font-medium italic text-[#1d1b18]`}
                      >
                        {name}
                      </p>
                      <span
                        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                      >
                        {t.comingSoon}
                      </span>
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <motion.div
                  variants={fadeUp}
                  className="rounded-[18px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-6 md:p-7"
                >
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c]`}
                  >
                    {t.devicesLockedKicker}
                  </p>
                  <h3
                    className={`mt-3 ${FONT_CLASS.cormorant} text-[28px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[32px]`}
                    style={{ textWrap: "balance" } as React.CSSProperties}
                  >
                    {t.devicesLockedTitle}{" "}
                    <span className="italic text-[#97472c]">
                      {t.devicesLockedAccent}
                    </span>
                  </h3>
                  <p
                    className={`mt-3 max-w-[58ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#4c463f]`}
                    style={{ textWrap: "pretty" } as React.CSSProperties}
                  >
                    {t.devicesLockedBody}
                  </p>
                  <Link
                    href={`/${locale}/pricing`}
                    className={`mt-5 inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-5 py-2.5 ${FONT_CLASS.manrope} text-[12px] font-semibold text-[#fef8f2] transition-transform hover:-translate-y-0.5`}
                    style={{
                      boxShadow: "0 14px 40px -12px rgba(151,71,44,0.45)",
                    }}
                  >
                    {t.devicesLockedCta}
                    <span
                      aria-hidden
                      className="flex h-5 w-5 items-center justify-center rounded-full bg-[#fef8f2]/15"
                    >
                      <svg
                        className="h-2.5 w-2.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={2}
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                        />
                      </svg>
                    </span>
                  </Link>
                </motion.div>
              )}
            </div>
          </motion.section>

          {/* § IV — Shipping */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerShipping}
                title={t.shippingTitle}
                accent={t.shippingAccent}
                subtitle={t.shippingSubtitle}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              {!profile?.address_line1 && (
                <div className="mb-5 rounded-[14px] border border-[#c49332]/35 bg-[rgba(196,147,50,0.06)] p-4">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#c49332]`}
                  >
                    {t.shippingNoneTitle}
                  </p>
                  <p
                    className={`mt-2 ${FONT_CLASS.manrope} text-[13px] leading-[1.55] text-[#4c463f]`}
                  >
                    {t.shippingNoneBody}
                  </p>
                </div>
              )}
              <form
                onSubmit={handleSaveAddress}
                className="grid gap-5 md:grid-cols-2 md:gap-6"
              >
                <div className="md:col-span-2">
                  <HairlineField label={t.addrLine1}>
                    <input
                      type="text"
                      value={addr.address_line1}
                      onChange={(e) =>
                        setAddr({ ...addr, address_line1: e.target.value })
                      }
                      className={hairlineInputClass}
                    />
                  </HairlineField>
                </div>
                <div className="md:col-span-2">
                  <HairlineField label={t.addrLine2}>
                    <input
                      type="text"
                      value={addr.address_line2}
                      onChange={(e) =>
                        setAddr({ ...addr, address_line2: e.target.value })
                      }
                      className={hairlineInputClass}
                    />
                  </HairlineField>
                </div>
                <HairlineField label={t.addrCity}>
                  <input
                    type="text"
                    value={addr.address_city}
                    onChange={(e) =>
                      setAddr({ ...addr, address_city: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <HairlineField label={t.addrPostal}>
                  <input
                    type="text"
                    value={addr.address_postal_code}
                    onChange={(e) =>
                      setAddr({ ...addr, address_postal_code: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <HairlineField label={t.addrProvince}>
                  <input
                    type="text"
                    value={addr.address_province}
                    onChange={(e) =>
                      setAddr({ ...addr, address_province: e.target.value })
                    }
                    className={hairlineInputClass}
                  />
                </HairlineField>
                <HairlineField label={t.addrCountry}>
                  <input
                    type="text"
                    maxLength={2}
                    value={addr.address_country}
                    onChange={(e) =>
                      setAddr({
                        ...addr,
                        address_country: e.target.value
                          .toUpperCase()
                          .slice(0, 2),
                      })
                    }
                    className={`${hairlineInputClass} uppercase`}
                  />
                </HairlineField>
                <div className="md:col-span-2">
                  <HairlineField label={t.addrPhone}>
                    <input
                      type="tel"
                      value={addr.phone}
                      onChange={(e) =>
                        setAddr({ ...addr, phone: e.target.value })
                      }
                      className={hairlineInputClass}
                    />
                  </HairlineField>
                </div>
                {/* Identity document — the lab (Echevarne) requires a
                    categorized identifier on every order; a kit cannot ship
                    without it. Saved through the same address endpoint. */}
                <div className="md:col-span-2 mt-2">
                  <p className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#1d1b18]`}>
                    {t.idDocTitle}
                  </p>
                  <p className={`mt-1 ${FONT_CLASS.manrope} text-[12px] leading-[1.5] text-[#8a7f76]`}>
                    {t.idDocHelp}
                  </p>
                </div>
                <HairlineField label={t.idDocType}>
                  <select
                    value={addr.id_document_type}
                    onChange={(e) =>
                      setAddr({ ...addr, id_document_type: e.target.value })
                    }
                    className={hairlineInputClass}
                  >
                    <option value="">{t.idDocPickType}</option>
                    {(["DNI", "NIE", "PASAPORTE", "OTROS"] as const).map((k) => (
                      <option key={k} value={k}>{t.idDocTypes[k]}</option>
                    ))}
                  </select>
                </HairlineField>
                <HairlineField label={t.idDocNumber}>
                  <input
                    type="text"
                    autoComplete="off"
                    value={addr.id_document_number}
                    onChange={(e) =>
                      setAddr({ ...addr, id_document_number: e.target.value.toUpperCase() })
                    }
                    className={`${hairlineInputClass} uppercase`}
                  />
                </HairlineField>
                <div className="md:col-span-2 mt-2 flex flex-wrap items-center gap-x-5 gap-y-3">
                  <PrimaryPill
                    type="submit"
                    loading={addrSaving}
                    disabled={addrSaving}
                  >
                    {addrSaving ? t.addrSaving : t.addrSave}
                  </PrimaryPill>
                  {addrSaved && !addrError && (
                    <span
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#3a665e]`}
                    >
                      ✓ {t.addrSaved}
                    </span>
                  )}
                  {addrError && (
                    <span
                      className={`${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
                    >
                      {t.addrError} {addrError}
                    </span>
                  )}
                </div>
              </form>
            </div>
          </motion.section>

          {/* § V — Subscription */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerSub}
                title={
                  isActive
                    ? t.subTitleActive
                    : isPastDue
                      ? t.subTitlePastDue
                      : isCancelled
                        ? t.subTitleCancelled
                        : t.subTitleFree
                }
                accent={
                  isActive
                    ? t.subAccentActive
                    : isPastDue
                      ? t.subAccentPastDue
                      : isCancelled
                        ? t.subAccentCancelled
                        : t.subAccentFree
                }
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <p
                className={`max-w-[52ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f]`}
              >
                {isFree && t.subFreeBody}
                {isPastDue && t.subPastDueBody}
                {isCancelled && t.subCancelledBody}
                {isActive && profile?.subscription_period_end && (
                  <>
                    {t.subActiveBody}
                    <span
                      className={`${FONT_CLASS.cormorant} text-[18px] italic text-[#97472c]`}
                    >
                      {new Date(profile.subscription_period_end).toLocaleDateString(
                        locale === "es" ? "es-ES" : "en-GB",
                        { day: "numeric", month: "long", year: "numeric" },
                      )}
                    </span>
                    .
                  </>
                )}
              </p>
              <div className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-3">
                {isFree || isCancelled ? (
                  <PrimaryPill
                    onClick={handleSubscribe}
                    loading={subBusy === "checkout"}
                    disabled={subBusy !== null}
                  >
                    {isCancelled ? t.reactivate : t.subscribeCta}
                  </PrimaryPill>
                ) : (
                  <PrimaryPill
                    onClick={handlePortal}
                    loading={subBusy === "portal"}
                    disabled={subBusy !== null}
                  >
                    {t.manageSub}
                  </PrimaryPill>
                )}
                {subError && (
                  <span
                    className={`${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
                  >
                    {subError}
                  </span>
                )}
              </div>
            </div>
          </motion.section>

          {/* § VI — Language */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerLang}
                title={t.langTitle}
                accent={t.langAccent}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <div className="grid grid-cols-2 gap-3 md:max-w-md md:gap-4">
                {(
                  [
                    { key: "es", label: "Espanol" },
                    { key: "en", label: "English" },
                  ] as const
                ).map((l) => {
                  const active = locale === l.key;
                  return (
                    <button
                      key={l.key}
                      type="button"
                      onClick={() => switchLocale(l.key)}
                      className={`group relative flex items-center justify-between rounded-[14px] border p-4 text-left transition-all md:p-5 ${
                        active
                          ? "border-[#97472c] bg-[rgba(151,71,44,0.05)]"
                          : "border-[#1d1b18]/12 bg-[#fef8f2]/60 hover:border-[#1d1b18]/30"
                      }`}
                    >
                      <p
                        className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic md:text-[22px] ${
                          active ? "text-[#97472c]" : "text-[#1d1b18]"
                        }`}
                      >
                        {l.label}
                      </p>
                      <span
                        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] ${
                          active ? "text-[#97472c]" : "text-[#8a7f76]"
                        }`}
                      >
                        {active ? "✓" : "○"}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </motion.section>

          {/* § VII — Communications (marketing opt-in / withdrawal) */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerComms}
                title={t.commsTitle}
                accent={t.commsAccent}
                subtitle={t.commsSubtitle}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <div className="flex items-center justify-between gap-5 rounded-[16px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-5 backdrop-blur-sm">
                <div className="min-w-0">
                  <p
                    className={`${FONT_CLASS.cormorant} text-[24px] font-medium italic text-[#1d1b18] md:text-[26px]`}
                  >
                    {t.marketingLabel}
                  </p>
                  <p
                    className={`mt-1 ${FONT_CLASS.manrope} text-[13px] leading-[1.5] text-[#8a7f76]`}
                  >
                    {marketingOptIn
                      ? t.marketingHelperOn
                      : t.marketingHelperOff}
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={marketingOptIn}
                  aria-label={t.marketingLabel}
                  disabled={marketingSaving}
                  onClick={() => handleToggleMarketing(!marketingOptIn)}
                  className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition-colors disabled:opacity-50 ${
                    marketingOptIn ? "bg-[#97472c]" : "bg-[#1d1b18]/20"
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${
                      marketingOptIn ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </button>
              </div>
              {marketingError && (
                <p
                  className={`mt-3 ${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
                >
                  {marketingError}
                </p>
              )}
            </div>
          </motion.section>

          {/* § VIII — Archive & Account */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerArchive}
                title={t.archiveTitle}
                accent={t.archiveAccent}
                subtitle={t.archiveSubtitle}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <ul className="border-t border-[#1d1b18]/15">
                <li className="flex items-center justify-between border-b border-[#1d1b18]/10 py-4">
                  <p
                    className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic text-[#1d1b18] md:text-[22px]`}
                  >
                    {t.exportData}
                  </p>
                  <a
                    href="/api/gdpr/export"
                    download
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#3a665e] underline decoration-[#3a665e]/30 underline-offset-[5px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/45`}
                  >
                    {locale === "es" ? "Descargar" : "Download"}{" "}
                    <span aria-hidden>↓</span>
                  </a>
                </li>
                <li className="flex items-center justify-between border-b border-[#1d1b18]/10 py-4">
                  <p
                    className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic text-[#1d1b18] md:text-[22px]`}
                  >
                    {t.deleteAccount}
                  </p>
                  <GhostLink
                    onClick={() => setShowDeleteModal(true)}
                    intent="danger"
                  >
                    {locale === "es" ? "Eliminar" : "Delete"}
                  </GhostLink>
                </li>
              </ul>
            </div>
          </motion.section>

          {/* § IX — Support */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <SectionHeader
                kicker={t.kickerSupport}
                title={t.supportTitle}
                accent={t.supportAccent}
              />
            </div>
            <div className="md:col-span-8 md:pt-2">
              <ul className="border-t border-[#1d1b18]/15">
                {[
                  { label: t.chatWithUs, href: `/${locale}/contact` },
                  { label: t.emailSupport, href: "mailto:hello@evahealth.es" },
                  { label: t.faq, href: `/${locale}/how-it-works` },
                ].map((item) => (
                  <li
                    key={item.label}
                    className="border-b border-[#1d1b18]/10 py-4"
                  >
                    <Link
                      href={item.href}
                      className={`group flex items-center justify-between ${FONT_CLASS.cormorant} text-[20px] font-medium italic text-[#1d1b18] transition-colors hover:text-[#97472c] md:text-[22px]`}
                    >
                      {item.label}
                      <span
                        aria-hidden
                        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c] transition-transform group-hover:translate-x-0.5`}
                      >
                        →
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </motion.section>

          {/* Logout */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:items-end md:gap-10"
          >
            <div className="md:col-span-7">
              <h2
                className={`${FONT_CLASS.cormorant} text-[32px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[44px] md:tracking-[-1px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.logoutQuote}{" "}
                <span className="italic text-[#97472c]">{t.logoutAccent}</span>
              </h2>
            </div>
            <div className="md:col-span-5 md:pb-2">
              <PrimaryPill onClick={handleLogout} intent="danger">
                {t.logout}
              </PrimaryPill>
            </div>
          </motion.section>

          <div className="h-12 md:h-20" />
        </div>
      </div>

      {/* Apple Health upload modal */}
      <EditorialModal
        open={showWearableModal}
        onClose={() => setShowWearableModal(false)}
        kicker={t.wearableModalKicker}
        title={t.wearableModalTitle}
        accent={t.wearableModalAccent}
        busy={wearableUploading}
      >
        <div className="rounded-[14px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-4">
          <p
            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
          >
            {t.wearableHowTo}
          </p>
          <ol
            className={`mt-3 list-decimal space-y-1.5 pl-5 ${FONT_CLASS.manrope} text-[13px] leading-[1.55] text-[#4c463f]`}
          >
            <li>{t.wearableStep1}</li>
            <li>{t.wearableStep2}</li>
            <li>{t.wearableStep3}</li>
            <li>{t.wearableStep4}</li>
          </ol>
        </div>
        <div
          {...getWearableRootProps()}
          className="mt-5 flex min-h-[140px] cursor-pointer flex-col items-center justify-center rounded-[16px] border-2 border-dashed border-[#1d1b18]/25 bg-[#fef8f2]/40 p-6 text-center transition-colors hover:border-[#97472c]/55"
        >
          <input {...getWearableInputProps()} />
          {wearableUploading ? (
            <div className="flex items-center gap-3">
              <div className="h-4 w-4 animate-spin rounded-full border-2 border-[#97472c] border-t-transparent" />
              <span
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c]`}
              >
                {t.wearableProcessing}
              </span>
            </div>
          ) : (
            <>
              <p
                className={`${FONT_CLASS.cormorant} text-[22px] font-medium italic text-[#1d1b18] md:text-[26px]`}
              >
                {t.wearableDrop}
              </p>
              <p
                className={`mt-2 ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
              >
                {t.wearableSize}
              </p>
            </>
          )}
        </div>
        {wearableResult && (
          <p
            className={`mt-4 ${FONT_CLASS.cormorant} text-[20px] italic text-[#3a665e]`}
          >
            ✓{" "}
            {t.wearableImported.replace(
              "{n}",
              String(wearableResult.daysImported),
            )}
          </p>
        )}
        {wearableError && (
          <p
            className={`mt-3 ${FONT_CLASS.manrope} text-[13px] italic text-[#b04040]`}
          >
            {wearableError}
          </p>
        )}
      </EditorialModal>

      {/* Delete account modal */}
      <EditorialModal
        open={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        kicker={t.deleteModalKicker}
        title={t.deleteModalTitle}
        accent={t.deleteModalAccent}
        busy={deleting}
      >
        <p
          className={`${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#4c463f]`}
        >
          {t.deleteBody}
        </p>
        <div className="mt-5">
          <HairlineField label={t.deleteConfirmLabel}>
            <input
              type="text"
              value={deleteConfirm}
              onChange={(e) => setDeleteConfirm(e.target.value)}
              placeholder="DELETE_MY_ACCOUNT"
              className={`w-full border-b border-[#1d1b18]/30 bg-transparent py-2 ${FONT_CLASS.dmMono} text-[15px] uppercase tracking-[1.5px] text-[#1d1b18] outline-none placeholder:tracking-[1.5px] placeholder:text-[#8a7f76]/60 focus:border-[#b04040]`}
            />
          </HairlineField>
        </div>
        <div className="mt-7 flex items-center justify-end gap-5">
          <GhostLink
            onClick={() => {
              if (deleting) return;
              setShowDeleteModal(false);
              setDeleteConfirm("");
            }}
          >
            {t.cancel}
          </GhostLink>
          <PrimaryPill
            intent="danger"
            disabled={deleteConfirm !== "DELETE_MY_ACCOUNT" || deleting}
            loading={deleting}
            onClick={async () => {
              setDeleting(true);
              try {
                await fetch("/api/gdpr/delete", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ confirmation: "DELETE_MY_ACCOUNT" }),
                });
                window.location.assign(`/${locale}`);
              } catch {
                setDeleting(false);
              }
            }}
          >
            {deleting ? t.deletingLabel : t.delete}
          </PrimaryPill>
        </div>
      </EditorialModal>
    </DashboardChrome>
  );
}
