import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { runBridgePassFromEnv } from "@/lib/lab-bridge/run";

/**
 * GET /api/cron/lab-bridge — one scheduled pass of the Echevarne SFTP bridge.
 *
 * Scheduled every 10 min by Vercel Cron (vercel.json) — needs the Pro plan
 * (Juan upgraded 2026-09-17; Hobby refuses sub-daily crons). Vercel only runs
 * crons on the PRODUCTION deployment, so this fires for real once the branch
 * is on main and the Production env carries ECH_SFTP_* + CRON_SECRET; until
 * then each tick answers 503 below and does nothing. Ops keeps the same pass
 * on demand from the fulfillment desk (POST /api/admin/lab-bridge). ECH does
 * not require a fixed source IP (confirmed 2026-09-15), so nothing else is
 * needed to host the bridge here.
 *
 * Fail-closed: no CRON_SECRET, no SFTP config or no service role → nothing runs.
 */
export const maxDuration = 120;

export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret) {
    console.error("[cron.lab-bridge] CRON_SECRET missing — refusing to run");
    return NextResponse.json({ error: "Not configured" }, { status: 503 });
  }
  const provided = Buffer.from(req.headers.get("authorization") ?? "");
  const expected = Buffer.from(`Bearer ${secret}`);
  if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const result = await runBridgePassFromEnv("cron");
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status });
  return NextResponse.json(result.summary);
}
