import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * PATCH /api/lab-results/[id]
 *
 * Edit a lab_result's user-facing metadata. Currently exposes the
 * collection_date only — everything else is derived from processing
 * and shouldn't be hand-edited. RLS enforces ownership via the existing
 * UPDATE policy on lab_results.
 *
 * Body: { collectionDate: "YYYY-MM-DD" }
 *
 * DELETE /api/lab-results/[id]
 *
 * Remove a lab_result the user no longer wants. biomarker_values and
 * action_steps cascade via the FK on delete. Uses the admin client if
 * available to bypass any RLS edge case; otherwise falls back to the
 * user client which requires the migration 20260410000000 delete
 * policies. Verifies by re-querying — if the row still exists, surfaces
 * a clear error instead of pretending success.
 */

const BodySchema = z.object({
  collectionDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "collectionDate must be YYYY-MM-DD"),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;

  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const parsed = BodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }
    const { collectionDate } = parsed.data;

    // Reject future dates — lab collection dates can't be in the future.
    const today = new Date().toISOString().split("T")[0];
    if (collectionDate > today) {
      return NextResponse.json(
        { error: "Collection date cannot be in the future" },
        { status: 400 },
      );
    }

    // Verify ownership before update (RLS would also block it, but an
    // explicit check gives a cleaner 404).
    const { data: existing, error: fetchError } = await supabase
      .from("lab_results")
      .select("id, user_id")
      .eq("id", id)
      .single();

    if (fetchError || !existing) {
      return NextResponse.json({ error: "Lab result not found" }, { status: 404 });
    }
    if (existing.user_id !== user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { data: updated, error: updateError } = await supabase
      .from("lab_results")
      .update({ collection_date: collectionDate })
      .eq("id", id)
      .select()
      .single();

    if (updateError) {
      return NextResponse.json(
        { error: `Update failed: ${updateError.message}` },
        { status: 500 },
      );
    }

    return NextResponse.json({ success: true, labResult: updated });
  } catch (e) {
    console.error("[lab-results PATCH] Error:", e);
    const message = e instanceof Error ? e.message : "Update failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;

  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Verify ownership with the user client so RLS still enforces the
    // auth.uid() check — never trust an id from the URL.
    const { data: existing, error: fetchError } = await supabase
      .from("lab_results")
      .select("id, user_id")
      .eq("id", id)
      .single();

    if (fetchError || !existing) {
      return NextResponse.json({ error: "Lab result not found" }, { status: 404 });
    }
    if (existing.user_id !== user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Prefer the admin client for the actual delete so we don't depend on
    // the delete-policy migration being applied. Fall back to the user
    // client which works once the migration is in place.
    const admin = createAdminClient();
    const writer = admin ?? supabase;

    const { error: deleteError } = await writer
      .from("lab_results")
      .delete()
      .eq("id", id);

    if (deleteError) {
      return NextResponse.json(
        { error: `Delete failed: ${deleteError.message}` },
        { status: 500 },
      );
    }

    // Verify — Supabase swallows RLS-rejected DELETEs silently, so
    // re-check and surface a clear error if the row is still there.
    const { data: stillThere } = await supabase
      .from("lab_results")
      .select("id")
      .eq("id", id)
      .maybeSingle();

    if (stillThere) {
      return NextResponse.json(
        {
          error:
            "Delete was silently rejected. This usually means the DELETE " +
            "RLS policies migration (20260410000000_add_delete_policies.sql) " +
            "hasn't been applied, or SUPABASE_SERVICE_ROLE_KEY isn't set.",
        },
        { status: 500 },
      );
    }

    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("[lab-results DELETE] Error:", e);
    const message = e instanceof Error ? e.message : "Delete failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
