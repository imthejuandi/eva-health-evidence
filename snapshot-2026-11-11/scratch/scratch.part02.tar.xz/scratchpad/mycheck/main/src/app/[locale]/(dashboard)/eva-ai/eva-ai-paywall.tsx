import Link from "next/link";
import { DashboardChrome, EditorialMasthead } from "@/components/dashboard";
import { FONT_CLASS } from "@/lib/dashboard-tokens";

interface EvaAIPaywallProps {
  locale: string;
}

/**
 * Stand-in for the EVA AI consultation when the viewer is not on a
 * paid plan. Sits at the same /eva-ai route so deep links keep
 * resolving; replaces the chat surface itself with a single
 * editorial card explaining that the assistant is reserved for
 * Quarterly subscribers and Full Panel buyers, plus a CTA to the
 * pricing page where both plans are listed.
 */
export function EvaAIPaywall({ locale }: EvaAIPaywallProps) {
  const t =
    locale === "es"
      ? {
          issue: "Consulta",
          kicker: "§ Solo para socios",
          title: "EVA es para",
          accent: "miembros.",
          lede: "Tu asistente clinico personal es exclusivo para clientes de los planes Trimestral o Panel Completo. Te lee la analitica con tu nivel, conecta tus wearables y guia tu siguiente paso entre kits.",
          plansLabel: "Lo que abre el acceso",
          plan1Title: "Trimestral",
          plan1Body:
            "Suscripcion recurrente. Kit en casa cada trimestre, EVA AI ilimitada, integracion de wearables y panel completo en el dashboard.",
          plan1Price: "99 € / trimestre",
          plan2Title: "Panel Completo",
          plan2Body:
            "Pago unico. Mas de 40 biomarcadores en una extraccion clinica, interpretacion completa y acceso permanente a EVA AI y wearables.",
          plan2Price: "499 € · pago unico",
          cta: "Ver planes",
          back: "Volver al panel",
          backHref: "/dashboard",
          plansHref: "/pricing",
        }
      : {
          issue: "Consultation",
          kicker: "§ Members only",
          title: "EVA is for",
          accent: "members.",
          lede: "Your personal clinical assistant is exclusive to Quarterly subscribers and Full Panel buyers. EVA reads your bloodwork at your level, ties your wearable data into the picture, and guides your next move between kits.",
          plansLabel: "What unlocks access",
          plan1Title: "Quarterly",
          plan1Body:
            "Recurring subscription. At-home kit every quarter, unlimited EVA AI, wearable integration and the full dashboard panel.",
          plan1Price: "€99 / quarter",
          plan2Title: "Full Panel",
          plan2Body:
            "One-time payment. 40+ biomarkers from a single clinical draw, full reinterpretation, and lifetime access to EVA AI and wearables.",
          plan2Price: "€499 · one-time",
          cta: "See plans",
          back: "Back to dashboard",
          backHref: "/dashboard",
          plansHref: "/pricing",
        };

  return (
    <DashboardChrome animate={false}>
      <div className="px-5 pt-8 pb-32 md:px-10 md:pt-14 md:pb-32">
        <div className="mx-auto max-w-[920px]">
          <EditorialMasthead issue={t.issue} />

          <section className="mt-10 md:mt-16">
            <p
              className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
            >
              {t.kicker}
            </p>
            <h1
              className={`mt-3 ${FONT_CLASS.cormorant} text-[44px] font-medium leading-[0.95] tracking-[-0.8px] text-[#1d1b18] md:text-[72px] md:tracking-[-2px]`}
              style={{ textWrap: "balance" } as React.CSSProperties}
            >
              {t.title}{" "}
              <span className="italic text-[#97472c]">{t.accent}</span>
            </h1>
            <p
              className={`mt-6 max-w-[58ch] ${FONT_CLASS.manrope} text-[15px] leading-[1.65] text-[#4c463f] md:text-[17px]`}
              style={{ textWrap: "pretty" } as React.CSSProperties}
            >
              {t.lede}
            </p>

            <p
              className={`mt-12 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#8a7f76] md:text-[11px]`}
            >
              {t.plansLabel}
            </p>

            <div className="mt-5 grid gap-4 md:grid-cols-2 md:gap-5">
              <article className="rounded-[18px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-6 md:p-7">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c]`}
                >
                  {t.plan1Price}
                </p>
                <h2
                  className={`mt-3 ${FONT_CLASS.cormorant} text-[28px] font-medium italic text-[#1d1b18] md:text-[32px]`}
                >
                  {t.plan1Title}
                </h2>
                <p
                  className={`mt-3 ${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#4c463f]`}
                >
                  {t.plan1Body}
                </p>
              </article>
              <article className="rounded-[18px] border border-[#1d1b18]/12 bg-[#fef8f2]/60 p-6 md:p-7">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c]`}
                >
                  {t.plan2Price}
                </p>
                <h2
                  className={`mt-3 ${FONT_CLASS.cormorant} text-[28px] font-medium italic text-[#1d1b18] md:text-[32px]`}
                >
                  {t.plan2Title}
                </h2>
                <p
                  className={`mt-3 ${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#4c463f]`}
                >
                  {t.plan2Body}
                </p>
              </article>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3">
              <Link
                href={`/${locale}${t.plansHref}`}
                className={`group inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] transition-transform hover:-translate-y-0.5`}
                style={{ boxShadow: "0 18px 50px -12px rgba(151,71,44,0.45)" }}
              >
                {t.cta}
                <span
                  aria-hidden
                  className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15"
                >
                  <svg
                    className="h-3 w-3"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                    />
                  </svg>
                </span>
              </Link>
              <Link
                href={`/${locale}${t.backHref}`}
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
              >
                ← {t.back}
              </Link>
            </div>
          </section>
        </div>
      </div>
    </DashboardChrome>
  );
}
