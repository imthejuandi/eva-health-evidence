import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { getUserProfile } from "@/lib/queries";
import { UploadClient } from "./upload-client";

interface UploadPageProps {
  params: Promise<{ locale: string }>;
}

export default async function UploadPage({ params }: UploadPageProps) {
  const { locale } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect(`/${locale}/login`);

  const profile = await getUserProfile(user.id);
  const totalUploadsUsed = ((profile as unknown as Record<string, unknown>)?.total_uploads_used as number) ?? 0;
  const subscriptionStatus = profile?.subscription_status ?? "free";
  const isSubscriber = subscriptionStatus === "active";
  // Profile locale (the user's persisted language preference) is what
  // drives lab-content localization — matched names, picker options,
  // and clinical strings — so the language remains consistent even if
  // the user happens to browse under a different URL locale.
  const profileLocale = profile?.locale === "es" ? "es" : "en";
  const userSex: "male" | "female" | null =
    profile?.sex === "male" || profile?.sex === "female" ? profile.sex : null;

  return (
    <UploadClient
      locale={locale}
      profileLocale={profileLocale}
      userSex={userSex}
      totalUploadsUsed={totalUploadsUsed}
      isSubscriber={isSubscriber}
      userId={user.id}
    />
  );
}
