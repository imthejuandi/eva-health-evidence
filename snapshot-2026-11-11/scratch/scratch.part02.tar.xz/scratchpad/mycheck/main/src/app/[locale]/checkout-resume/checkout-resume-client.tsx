"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

type Intent = "quarterly" | "annual" | "full_panel";

export function CheckoutResumeClient({ locale }: { locale: string }) {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const fired = useRef(false);

  useEffect(() => {
    if (fired.current) return;
    fired.current = true;

    const raw = searchParams.get("intent");
    const intent: Intent | null =
      raw === "quarterly" || raw === "annual" || raw === "full_panel" ? raw : null;
    if (!intent) {
      router.replace(`/${locale}/dashboard`);
      return;
    }

    (async () => {
      try {
        const res = await fetch("/api/stripe/checkout", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ locale, plan: intent }),
        });
        if (res.status === 401) {
          // Auth cookie didn't make it through somehow — bounce to login
          // with the same intent so they can resume after authenticating.
          router.replace(`/${locale}/login?intent=${intent}`);
          return;
        }
        const data = await res.json();
        if (data.url) {
          window.location.assign(data.url);
          return;
        }
        setError(
          data.error ??
            (locale === "es"
              ? "No se pudo iniciar el checkout."
              : "Couldn't start checkout."),
        );
      } catch {
        setError(
          locale === "es"
            ? "Error de conexion. Vuelve a intentarlo."
            : "Network error. Please try again.",
        );
      }
    })();
  }, [locale, router, searchParams]);

  const t =
    locale === "es"
      ? {
          masthead: "EVA · Reanudando checkout",
          title: "Llevandote a Stripe.",
          accent: "Un momento.",
          lede: "Estamos preparando tu pago seguro. Te redirigimos automaticamente.",
          retry: "Volver a precios",
          errorKicker: "§ Error",
        }
      : {
          masthead: "EVA · Resuming checkout",
          title: "Taking you to Stripe.",
          accent: "One moment.",
          lede: "Preparing your secure checkout. You'll be redirected automatically.",
          retry: "Back to pricing",
          errorKicker: "§ Error",
        };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#fef8f2] text-[#1d1b18]">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[1]"
        style={{
          background:
            "radial-gradient(circle at 20% 20%, rgba(217,123,92,0.14), transparent 50%), radial-gradient(circle at 80% 30%, rgba(188,236,225,0.22), transparent 55%), radial-gradient(circle at 50% 85%, rgba(196,147,50,0.12), transparent 60%)",
        }}
      />
      <div className="relative z-[2] flex min-h-screen items-center justify-center px-6 py-10">
        <div className="w-full max-w-[640px]">
          <p
            className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#1d1b18]"
          >
            {t.masthead}
          </p>
          <span aria-hidden className="mt-3 block h-px w-full bg-[#1d1b18]/15" />

          {!error ? (
            <>
              <h1
                className="mt-10 font-[family-name:var(--font-cormorant)] text-[44px] font-medium leading-[0.95] tracking-[-1px] text-[#1d1b18] md:text-[72px] md:tracking-[-2px]"
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.title}{" "}
                <span className="italic text-[#97472c]">{t.accent}</span>
              </h1>
              <p
                className="mt-6 max-w-[44ch] font-[family-name:var(--font-manrope)] text-[15px] leading-[1.65] text-[#4c463f] md:text-[16px]"
                style={{ textWrap: "pretty" } as React.CSSProperties}
              >
                {t.lede}
              </p>

              <div className="mt-10 flex items-center gap-4">
                <span
                  aria-hidden
                  className="inline-block h-1 w-12 origin-left bg-[#97472c] [animation:resumeBar_1.2s_ease-in-out_infinite]"
                  style={{ transformOrigin: "left center" }}
                />
                <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]">
                  {locale === "es" ? "Conectando" : "Connecting"}
                </span>
              </div>
            </>
          ) : (
            <>
              <p
                className="mt-10 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#b04040]"
              >
                {t.errorKicker}
              </p>
              <h1
                className="mt-3 font-[family-name:var(--font-cormorant)] text-[36px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[48px]"
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {error}
              </h1>
              <button
                type="button"
                onClick={() => router.push(`/${locale}/pricing`)}
                className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-6 py-3 font-[family-name:var(--font-manrope)] text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0"
              >
                {t.retry}
                <span
                  aria-hidden
                  className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15"
                >
                  <svg
                    className="h-3 w-3"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                    />
                  </svg>
                </span>
              </button>
            </>
          )}
        </div>
      </div>

      <style jsx>{`
        @keyframes resumeBar {
          0% {
            transform: scaleX(0);
            opacity: 1;
          }
          50% {
            transform: scaleX(1);
            opacity: 0.85;
          }
          100% {
            transform: scaleX(0);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
}
