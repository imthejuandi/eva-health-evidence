"use client";

import { useParams } from "next/navigation";

export default function Error({ reset }: { error: Error; reset: () => void }) {
  const params = useParams();
  const locale = (params.locale as string) ?? "en";

  const t = locale === "es"
    ? { title: "Algo salio mal", desc: "Ha ocurrido un error inesperado. Estamos trabajando en solucionarlo.", retry: "Intentar de nuevo", home: "Ir al inicio" }
    : { title: "Something went wrong", desc: "An unexpected error occurred. We're working to fix it.", retry: "Try again", home: "Go home" };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#fef8f2] px-5 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-[rgba(176,64,64,0.08)]">
        <span className="text-[40px]">⚠️</span>
      </div>
      <h1 className="mt-6 font-[family-name:var(--font-manrope)] text-[28px] font-extrabold text-[#1d1b18]">{t.title}</h1>
      <p className="mx-auto mt-3 max-w-md font-[family-name:var(--font-inter)] text-[15px] text-[#4c463f]">{t.desc}</p>
      <div className="mt-8 flex gap-4">
        <button
          onClick={reset}
          className="rounded-[100px] bg-gradient-to-br from-[#97472c] to-[#d97b5c] px-7 py-3.5 font-[family-name:var(--font-manrope)] text-[14px] font-bold text-white shadow-[0_12px_40px_rgba(151,71,44,0.2)] transition-all hover:-translate-y-0.5"
        >
          {t.retry}
        </button>
        <a
          href={`/${locale}`}
          className="rounded-[100px] border-[1.5px] border-[#97472c] px-7 py-3.5 font-[family-name:var(--font-manrope)] text-[14px] font-bold text-[#97472c] transition-colors hover:bg-[rgba(151,71,44,0.05)]"
        >
          {t.home}
        </a>
      </div>
    </div>
  );
}
