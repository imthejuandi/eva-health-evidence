"use client";

import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { SectionTag } from "@/components/marketing/SectionTag";

export default function PrivacyPolicyPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";

  if (locale === "es") return <PrivacyES />;
  return <PrivacyEN />;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-10">
      <h2 className="font-[family-name:var(--font-manrope)] text-[20px] font-extrabold text-[#1d1b18]">
        {title}
      </h2>
      <div className="mt-4 space-y-4 font-[family-name:var(--font-inter)] text-[15px] leading-relaxed text-[#4c463f]">
        {children}
      </div>
    </div>
  );
}

function PrivacyEN() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-3xl">
        <ScrollReveal>
          <SectionTag text="Legal" />
          <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[48px]">
            Privacy Policy
          </h1>
          <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] font-medium uppercase tracking-[1.5px] text-[#8a7f76]">
            Last updated: March 2026
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <Section title="Data Controller">
            <p>
              EVA Health S.L., headquartered in Madrid, Spain, is the data controller responsible for your personal data. You can reach us at hello@evahealth.es.
            </p>
          </Section>

          <Section title="What We Collect">
            <p><strong>Account information:</strong> Name, email address, and authentication credentials when you create an account.</p>
            <p><strong>Health biomarker data:</strong> Blood test results, biomarker values, and calculated health metrics. This is classified as special category data under GDPR Article 9 and is only processed with your explicit consent.</p>
            <p><strong>Wearable data:</strong> If you connect a wearable device, we receive heart rate variability, sleep data, resting heart rate, recovery scores, and activity metrics.</p>
            <p><strong>Usage analytics:</strong> We use Plausible Analytics, which is privacy-friendly and does not use cookies or track individual users. We collect aggregate page views and traffic sources only.</p>
          </Section>

          <Section title="Legal Basis for Processing">
            <p><strong>Explicit consent (GDPR Article 9(2)(a)):</strong> Required before we process any health or biomarker data. You provide this consent during signup and can withdraw it at any time.</p>
            <p><strong>Contract performance (GDPR Article 6(1)(b)):</strong> Processing necessary to provide your subscription service, deliver results, and manage your account.</p>
            <p><strong>Legitimate interest (GDPR Article 6(1)(f)):</strong> Aggregate, anonymised analytics to improve our service. No personal data is involved in this processing.</p>
          </Section>

          <Section title="Health Data Consent">
            <p>
              Your health data is special category data under GDPR. We will never process your biomarker results, wearable data, or any health-related information without your explicit, informed consent. This consent is collected separately during account creation and can be withdrawn at any time through your account settings or by contacting us.
            </p>
          </Section>

          <Section title="How We Store Your Data">
            <p>
              Your data is stored on Supabase infrastructure within the European Union, encrypted at rest and in transit. Some processing — notably AI-powered analysis by Google (Gemini) — may involve transferring your data outside the EEA, carried out under appropriate data-transfer safeguards.
            </p>
          </Section>

          <Section title="Third-Party Processors">
            <p>We work with the following processors, all bound by data processing agreements:</p>
            <ul className="ml-5 list-disc space-y-2">
              <li><strong>Supabase</strong>: Database and authentication (EU region)</li>
              <li><strong>Stripe</strong>: Payment processing (PCI DSS compliant, does not receive health data)</li>
              <li><strong>Google (Gemini)</strong>: AI-powered health analysis (processes biomarker data to generate insights; may involve transfer outside the EEA under appropriate safeguards)</li>
              <li><strong>Resend</strong>: Transactional emails (receives email addresses only)</li>
              <li><strong>Plausible Analytics</strong>: Privacy-friendly web analytics (no personal data, no cookies)</li>
            </ul>
          </Section>

          <Section title="Data Retention">
            <p><strong>Active accounts:</strong> Your data is retained for as long as your account is active.</p>
            <p><strong>After deletion:</strong> Account data is permanently deleted within 30 days of account deletion. Health data is deleted immediately upon request.</p>
            <p><strong>Legal obligations:</strong> We may retain certain data as required by Spanish tax and commercial law.</p>
          </Section>

          <Section title="Your Rights">
            <p>Under GDPR, you have the right to:</p>
            <ul className="ml-5 list-disc space-y-2">
              <li><strong>Access</strong>: Request a copy of all personal data we hold about you</li>
              <li><strong>Rectification</strong>: Correct any inaccurate personal data</li>
              <li><strong>Erasure</strong>: Request deletion of your personal data</li>
              <li><strong>Portability</strong>: Receive your data in a structured, machine-readable format</li>
              <li><strong>Withdraw consent</strong>: Withdraw your consent for health data processing at any time</li>
              <li><strong>Object</strong>: Object to processing based on legitimate interest</li>
              <li><strong>Lodge a complaint</strong>: File a complaint with the Agencia Española de Proteccion de Datos (AEPD), the Spanish Data Protection Authority, at www.aepd.es</li>
            </ul>
            <p>To exercise any of these rights, contact us at hello@evahealth.es.</p>
          </Section>

          <Section title="Contact">
            <p>
              For any privacy-related questions or to exercise your rights:<br />
              <strong>EVA Health S.L.</strong><br />
              Madrid, Spain<br />
              hello@evahealth.es
            </p>
          </Section>
        </ScrollReveal>
      </div>
    </section>
  );
}

function PrivacyES() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-3xl">
        <ScrollReveal>
          <SectionTag text="Legal" />
          <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[48px]">
            Politica de Privacidad
          </h1>
          <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] font-medium uppercase tracking-[1.5px] text-[#8a7f76]">
            Ultima actualizacion: Marzo 2026
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <Section title="Responsable del Tratamiento">
            <p>
              EVA Health S.L., con sede en Madrid, España, es el responsable del tratamiento de tus datos personales. Puedes contactarnos en hello@evahealth.es.
            </p>
          </Section>

          <Section title="Que Datos Recopilamos">
            <p><strong>Informacion de cuenta:</strong> Nombre, direccion de correo electronico y credenciales de autenticacion al crear una cuenta.</p>
            <p><strong>Datos de biomarcadores de salud:</strong> Resultados de analisis de sangre, valores de biomarcadores y metricas de salud calculadas. Estos se clasifican como datos de categoria especial segun el Articulo 9 del RGPD y solo se procesan con tu consentimiento explicito.</p>
            <p><strong>Datos de wearables:</strong> Si conectas un dispositivo wearable, recibimos variabilidad de frecuencia cardiaca, datos de sueño, frecuencia cardiaca en reposo, puntuaciones de recuperacion y metricas de actividad.</p>
            <p><strong>Analitica de uso:</strong> Utilizamos Plausible Analytics, que respeta la privacidad y no usa cookies ni rastrea usuarios individuales. Solo recopilamos vistas de pagina agregadas y fuentes de trafico.</p>
          </Section>

          <Section title="Base Legal del Tratamiento">
            <p><strong>Consentimiento explicito (RGPD Articulo 9(2)(a)):</strong> Requerido antes de procesar cualquier dato de salud o biomarcadores. Lo proporcionas durante el registro y puedes retirarlo en cualquier momento.</p>
            <p><strong>Ejecucion de contrato (RGPD Articulo 6(1)(b)):</strong> Tratamiento necesario para proporcionar tu servicio de suscripcion, entregar resultados y gestionar tu cuenta.</p>
            <p><strong>Interes legitimo (RGPD Articulo 6(1)(f)):</strong> Analitica agregada y anonimizada para mejorar nuestro servicio. No se involucran datos personales.</p>
          </Section>

          <Section title="Consentimiento para Datos de Salud">
            <p>
              Tus datos de salud son datos de categoria especial bajo el RGPD. Nunca procesaremos tus resultados de biomarcadores, datos de wearables o cualquier informacion relacionada con la salud sin tu consentimiento explicito e informado. Este consentimiento se recoge por separado durante la creacion de la cuenta y puede retirarse en cualquier momento a traves de la configuracion de tu cuenta o contactandonos.
            </p>
          </Section>

          <Section title="Como Almacenamos Tus Datos">
            <p>
              Tus datos se almacenan en infraestructura de Supabase dentro de la Union Europea, cifrados en reposo y en transito. Algunos tratamientos —en particular el analisis con IA por Google (Gemini)— pueden implicar la transferencia de tus datos fuera del EEE, realizada con las garantias adecuadas de transferencia de datos.
            </p>
          </Section>

          <Section title="Encargados del Tratamiento">
            <p>Trabajamos con los siguientes encargados, todos vinculados por acuerdos de tratamiento de datos:</p>
            <ul className="ml-5 list-disc space-y-2">
              <li><strong>Supabase</strong>: Base de datos y autenticacion (region UE)</li>
              <li><strong>Stripe</strong>: Procesamiento de pagos (cumple PCI DSS, no recibe datos de salud)</li>
              <li><strong>Google (Gemini)</strong>: Analisis de salud con IA (procesa datos de biomarcadores para generar informacion; puede implicar transferencia fuera del EEE con las garantias adecuadas)</li>
              <li><strong>Resend</strong>: Emails transaccionales (solo recibe direcciones de email)</li>
              <li><strong>Plausible Analytics</strong>: Analitica web respetuosa con la privacidad (sin datos personales, sin cookies)</li>
            </ul>
          </Section>

          <Section title="Retencion de Datos">
            <p><strong>Cuentas activas:</strong> Tus datos se conservan mientras tu cuenta este activa.</p>
            <p><strong>Tras eliminacion:</strong> Los datos de cuenta se eliminan permanentemente dentro de los 30 dias siguientes a la eliminacion de la cuenta. Los datos de salud se eliminan inmediatamente a peticion.</p>
            <p><strong>Obligaciones legales:</strong> Podemos conservar ciertos datos segun lo requiera la legislacion fiscal y mercantil española.</p>
          </Section>

          <Section title="Tus Derechos">
            <p>Bajo el RGPD, tienes derecho a:</p>
            <ul className="ml-5 list-disc space-y-2">
              <li><strong>Acceso</strong>: Solicitar una copia de todos los datos personales que tenemos sobre ti</li>
              <li><strong>Rectificacion</strong>: Corregir cualquier dato personal inexacto</li>
              <li><strong>Supresion</strong>: Solicitar la eliminacion de tus datos personales</li>
              <li><strong>Portabilidad</strong>: Recibir tus datos en un formato estructurado y legible por maquina</li>
              <li><strong>Retirar consentimiento</strong>: Retirar tu consentimiento para el procesamiento de datos de salud en cualquier momento</li>
              <li><strong>Oposicion</strong>: Oponerte al tratamiento basado en interes legitimo</li>
              <li><strong>Reclamacion</strong>: Presentar una reclamacion ante la Agencia Española de Proteccion de Datos (AEPD) en www.aepd.es</li>
            </ul>
            <p>Para ejercer cualquiera de estos derechos, contactanos en hello@evahealth.es.</p>
          </Section>

          <Section title="Contacto">
            <p>
              Para cualquier consulta sobre privacidad o para ejercer tus derechos:<br />
              <strong>EVA Health S.L.</strong><br />
              Madrid, España<br />
              hello@evahealth.es
            </p>
          </Section>
        </ScrollReveal>
      </div>
    </section>
  );
}
