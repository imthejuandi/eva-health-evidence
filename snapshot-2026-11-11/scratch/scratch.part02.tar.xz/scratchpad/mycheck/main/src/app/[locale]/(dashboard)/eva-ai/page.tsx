import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { hasPaidAccess } from "@/lib/stripe/helpers";
import { EvaAIClient } from "./eva-ai-client";
import { EvaAIPaywall } from "./eva-ai-paywall";

interface EvaAIPageProps {
  params: Promise<{ locale: string }>;
}

export default async function EvaAIPage({ params }: EvaAIPageProps) {
  const { locale } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect(`/${locale}/login`);

  // EVA AI chat is exclusive to paying customers (Quarterly subscribers
  // and Full Panel buyers). Free users land on a paywall card with
  // a CTA to /pricing instead of the chat surface.
  const { data: paidProfile } = await supabase
    .from("profiles")
    .select("subscription_status, subscription_period_end, full_panel_purchased_at")
    .eq("id", user.id)
    .single();
  if (!hasPaidAccess(paidProfile)) {
    return <EvaAIPaywall locale={locale} />;
  }

  const { data: messages } = await supabase
    .from("chat_messages")
    .select("id, role, content, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(20);

  return (
    <EvaAIClient
      locale={locale}
      initialMessages={(messages ?? []).reverse()}
    />
  );
}
