import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { getUserProfile, getLatestLabResult, getBookedTests } from "@/lib/queries";
import { BookClient } from "./book-client";

interface BookPageProps {
  params: Promise<{ locale: string }>;
}

export default async function BookPage({ params }: BookPageProps) {
  const { locale } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/${locale}/login`);

  // /book is the booking + subscription-management hub for any logged-in
  // user, regardless of subscription state. Free users see plan-purchase
  // CTAs; active subscribers see their current kit + add-on options;
  // past-due / cancelled users see reactivation. The previous redirect-
  // to-pricing gate is gone so the page is always reachable.
  const [profile, latestLab, bookedTests] = await Promise.all([
    getUserProfile(user.id),
    getLatestLabResult(user.id),
    getBookedTests(user.id),
  ]);

  return (
    <BookClient
      locale={locale}
      userId={user.id}
      profile={profile}
      latestLab={latestLab}
      bookedTests={bookedTests}
    />
  );
}
