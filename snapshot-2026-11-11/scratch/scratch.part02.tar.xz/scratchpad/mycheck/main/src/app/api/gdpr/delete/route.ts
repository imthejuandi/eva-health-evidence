import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getStripe } from "@/lib/stripe/helpers";
import type { SupabaseClient } from "@supabase/supabase-js";

/**
 * Recursively collect the full object paths under `prefix` in `bucket`.
 * Supabase `list()` returns immediate children only, with synthetic folder
 * entries (id === null) for nested prefixes — so we recurse into those and
 * paginate, to fully cover the lab-uploads/{userId}/{timestamp}/{file} layout
 * for users with many uploads.
 */
async function collectStoragePaths(
  admin: SupabaseClient,
  bucket: string,
  prefix: string,
): Promise<string[]> {
  const out: string[] = [];
  const pageSize = 100;
  let offset = 0;

  for (;;) {
    const { data, error } = await admin.storage
      .from(bucket)
      .list(prefix, { limit: pageSize, offset });
    if (error) throw error;
    if (!data || data.length === 0) break;

    for (const entry of data) {
      const path = `${prefix}/${entry.name}`;
      if (entry.id === null) {
        out.push(...(await collectStoragePaths(admin, bucket, path)));
      } else {
        out.push(path);
      }
    }

    if (data.length < pageSize) break;
    offset += pageSize;
  }

  return out;
}

export async function POST(req: NextRequest) {
  try {
    // Identify the caller from their own (RLS-bound) session.
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { confirmation } = await req.json();
    if (confirmation !== "DELETE_MY_ACCOUNT") {
      return NextResponse.json({ error: "Confirmation required" }, { status: 400 });
    }

    const userId = user.id;
    const email = user.email;

    // Erasure is privileged: deleting the auth user and wiping rows that the
    // caller has no DELETE RLS policy for both require the service role. The
    // previous implementation used the anon/SSR client, so auth.admin.deleteUser
    // failed and several deletes silently affected 0 rows under RLS — the
    // account was never actually erased (GDPR-002). Fail loudly rather than
    // half-delete if the service role is not configured.
    const admin = createAdminClient();
    if (!admin) {
      console.error("[gdpr/delete] SUPABASE_SERVICE_ROLE_KEY not configured");
      return NextResponse.json(
        { error: "Account deletion is temporarily unavailable" },
        { status: 503 },
      );
    }

    // Read the Stripe customer id BEFORE deletion — the profiles row (and the
    // id) is gone once the cascade runs.
    const { data: profile } = await admin
      .from("profiles")
      .select("stripe_customer_id")
      .eq("id", userId)
      .single();
    const stripeCustomerId = profile?.stripe_customer_id ?? null;

    // ── Commit point ──────────────────────────────────────────────────────
    // Deleting the auth user cascades (ON DELETE CASCADE from profiles) to
    // every table holding this user's data: lab_results → biomarker_values /
    // action_steps, wearable_data, booked_tests, chat_messages,
    // patient_context_versions, patient_context_drafts. This is one atomic
    // delete, so a failure here leaves all data intact (and nothing below has
    // run yet) — the caller can safely retry.
    const { error: deleteError } = await admin.auth.admin.deleteUser(userId);
    if (deleteError) throw deleteError;

    // ── Post-commit, best-effort external cleanup ─────────────────────────
    // These resources are not covered by the DB cascade. Failures here leave
    // the account already erased, so we log rather than fail the request.

    // 1. Cancel any active Stripe subscription.
    if (stripeCustomerId) {
      try {
        const stripe = getStripe();
        const subs = await stripe.subscriptions.list({
          customer: stripeCustomerId,
          status: "active",
        });
        for (const sub of subs.data) {
          await stripe.subscriptions.cancel(sub.id);
        }
      } catch (e) {
        console.error("[gdpr/delete] stripe cleanup failed", e);
      }
    }

    // 2. Remove uploaded files. Objects live at lab-uploads/{userId}/{ts}/{file},
    //    so enumerate recursively — a flat list() returns only the {ts} folders,
    //    not the file objects, which would leave the user's lab PDFs/images.
    try {
      const paths = await collectStoragePaths(admin, "lab-uploads", userId);
      for (let i = 0; i < paths.length; i += 100) {
        const { error } = await admin.storage
          .from("lab-uploads")
          .remove(paths.slice(i, i + 100));
        if (error) throw error;
      }
    } catch (e) {
      console.error("[gdpr/delete] storage cleanup failed", e);
    }

    // 3. Remove the user from the marketing list (keyed by email, not user_id).
    if (email) {
      const { error } = await admin
        .from("email_subscribers")
        .delete()
        .eq("email", email);
      if (error) console.error("[gdpr/delete] email_subscribers cleanup failed", error);
    }

    return NextResponse.json({ deleted: true });
  } catch (e) {
    console.error("[gdpr/delete]", e);
    return NextResponse.json({ error: "Deletion failed" }, { status: 500 });
  }
}
