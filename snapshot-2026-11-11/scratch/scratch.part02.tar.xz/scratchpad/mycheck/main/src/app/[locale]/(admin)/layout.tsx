import { requireAdmin } from "@/lib/auth/require-admin";
import { redirect } from "next/navigation";

interface AdminLayoutProps {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}

export default async function AdminLayout({ children, params }: AdminLayoutProps) {
  const { locale } = await params;

  // Authoritative server-side admin gate (SEC-003). requireAdmin() returns the
  // user only when they are an admin; non-admins (and unauthenticated users)
  // get null and are redirected away.
  const user = await requireAdmin();
  if (!user) redirect(`/${locale}/dashboard`);

  return (
    <div className="min-h-screen bg-[#fef8f2]">
      <header className="border-b border-[#e7e2dc] px-6 py-4">
        <div className="flex items-center justify-between">
          <h1 className="flex items-baseline gap-1.5">
            <span className="font-[family-name:var(--font-logo)] text-[22px] font-light lowercase tracking-[-0.5px] text-[#1d1b18]">eva</span>
            <span className="font-[family-name:var(--font-manrope)] text-[16px] font-bold uppercase tracking-[0.06em] text-[#97472c]">Admin</span>
          </h1>
          <span className="font-[family-name:var(--font-inter)] text-[12px] text-[#8a7f76]">{user.email}</span>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
}
