import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { sendEmail } from "@/lib/email/send";

/**
 * Sends the welcome email to the authenticated user, exactly once.
 *
 * Trigger: onboarding completion (fire-and-forget from the client). The
 * welcome template existed with zero call sites — no user ever received it.
 *
 * Idempotency: an atomic claim on profiles.welcome_email_sent_at (update
 * WHERE null RETURNING). Re-POSTs after the first success are 200 no-ops, so
 * the client can call this blindly. Before the column's migration is applied
 * the claim errors (42703); we then skip sending rather than risk duplicate
 * mails on every onboarding re-run.
 */
export async function POST() {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data: claimed, error: claimError } = await supabase
      .from("profiles")
      .update({ welcome_email_sent_at: new Date().toISOString() })
      .eq("id", user.id)
      .is("welcome_email_sent_at", null)
      .select("full_name, locale")
      .maybeSingle();

    if (claimError) {
      if (claimError.code === "42703") {
        console.warn(
          "[emails/welcome] welcome_email_sent_at column missing — skipping send (apply pending migration)",
        );
        return NextResponse.json({ sent: false, reason: "migration-pending" });
      }
      console.error("[emails/welcome] claim failed:", claimError);
      return NextResponse.json({ error: "Claim failed" }, { status: 500 });
    }

    if (!claimed) {
      // Already sent previously — idempotent no-op.
      return NextResponse.json({ sent: false, reason: "already-sent" });
    }

    if (user.email) {
      const locale = claimed.locale ?? "es";
      sendEmail(
        user.email,
        "welcome",
        { firstName: claimed.full_name?.split(" ")[0] ?? "", locale },
        locale,
      ).catch((err) => console.error("[emails/welcome] send failed:", err));
    }

    return NextResponse.json({ sent: true });
  } catch (e) {
    console.error("[emails/welcome]", e);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
