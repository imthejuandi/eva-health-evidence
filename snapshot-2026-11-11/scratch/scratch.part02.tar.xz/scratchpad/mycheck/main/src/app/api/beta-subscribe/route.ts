import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

/**
 * Add an email to the beta waitlist. Writes to the existing
 * email_subscribers table with source='beta_waitlist' so the gate's
 * leads land in the same list the blog signup feeds.
 *
 * Returns:
 *   200 { ok: true, status: 'subscribed' | 'duplicate' }
 *   400 { error: 'invalid_email' }
 *   500 { error: 'subscribe_failed' }
 */
export async function POST(req: NextRequest) {
  let body: { email?: string; locale?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const email = (body.email ?? "").trim().toLowerCase();
  const locale = body.locale === "en" ? "en" : "es";

  // Minimal email shape check. The DB column is unique so we don't
  // need server-side dedup; we just need to reject obvious junk
  // before the round-trip.
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: "invalid_email" }, { status: 400 });
  }

  const supabase = await createClient();
  const { error } = await supabase
    .from("email_subscribers")
    .insert({ email, source: "beta_waitlist", locale });

  if (error) {
    // Postgres unique-violation: the email is already on the list.
    // Treat this as success from the user's perspective so we don't
    // leak which addresses are subscribed.
    if (error.code === "23505") {
      return NextResponse.json({ ok: true, status: "duplicate" });
    }
    console.error("[beta-subscribe] insert failed:", error);
    return NextResponse.json({ error: "subscribe_failed" }, { status: 500 });
  }

  return NextResponse.json({ ok: true, status: "subscribed" });
}
