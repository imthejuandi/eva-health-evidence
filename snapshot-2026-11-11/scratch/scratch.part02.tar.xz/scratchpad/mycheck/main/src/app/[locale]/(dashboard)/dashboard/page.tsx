import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import {
  getUserProfile,
  getLatestLabResult,
  getBiomarkerValues,
  getWearableData,
  getActionSteps,
  getBookedTests,
} from "@/lib/queries";
import { DashboardClient } from "./dashboard-client";

interface DashboardPageProps {
  params: Promise<{ locale: string }>;
}

export default async function DashboardPage({ params }: DashboardPageProps) {
  const { locale } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect(`/${locale}/login`);

  const [profile, latestLab, wearable, actionSteps, bookedTests] =
    await Promise.all([
      getUserProfile(user.id),
      getLatestLabResult(user.id),
      // 14 days — gives the wearable trend deltas enough history to
      // compute a meaningful delta (compares the last value against
      // the first-half average).
      getWearableData(user.id, 14),
      getActionSteps(user.id),
      getBookedTests(user.id),
    ]);

  const biomarkers = latestLab ? await getBiomarkerValues(latestLab.id) : [];

  // Results that arrived (bridge or webhook) but still wait for the patient's
  // context — invisible otherwise, since the dashboard reads "ready" only.
  const { data: pendingLabs } = await supabase
    .from("lab_results")
    .select("id, collection_date, created_at")
    .eq("user_id", user.id)
    .eq("status", "pending_context")
    .order("created_at", { ascending: false });

  return (
    <DashboardClient
      locale={locale}
      pendingLabs={pendingLabs ?? []}
      profile={profile}
      latestLab={latestLab}
      biomarkers={biomarkers}
      wearable={wearable}
      actionSteps={actionSteps}
      bookedTests={bookedTests}
    />
  );
}
