import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { data: latest } = await supabase
      .from("lab_results")
      .select("id, status, source, collection_date, biological_age, longevity_score, longevity_grade, optimal_count, attention_count, action_count, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (!latest) {
      return NextResponse.json({ hasResults: false, latest: null });
    }

    return NextResponse.json({ hasResults: true, latest });
  } catch {
    return NextResponse.json({ error: "Failed to fetch status" }, { status: 500 });
  }
}
