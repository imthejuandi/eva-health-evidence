"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import { useParams, useRouter, useSearchParams } from "next/navigation";

export default function ResetPasswordPage() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [hasSession, setHasSession] = useState(false);
  const [success, setSuccess] = useState(false);
  const params = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const locale = (params.locale as string) ?? "es";

  const t = locale === "es"
    ? {
        title: "Crear nueva contraseña",
        subtitle: "Ingresa una contraseña segura para tu cuenta.",
        newPassword: "Nueva contraseña",
        confirmPassword: "Confirmar contraseña",
        placeholder: "Mínimo 8 caracteres",
        updatePassword: "Actualizar contraseña",
        passwordTooShort: "La contraseña debe tener al menos 8 caracteres",
        passwordMismatch: "Las contraseñas no coinciden",
        success: "Contraseña actualizada. Redirigiendo...",
        invalidSession:
          "Enlace de recuperación no válido o expirado. Solicita uno nuevo.",
        requestNew: "Solicitar nuevo enlace",
        checking: "Verificando enlace...",
      }
    : {
        title: "Create new password",
        subtitle: "Enter a strong password for your account.",
        newPassword: "New password",
        confirmPassword: "Confirm password",
        placeholder: "At least 8 characters",
        updatePassword: "Update password",
        passwordTooShort: "Password must be at least 8 characters",
        passwordMismatch: "Passwords do not match",
        success: "Password updated. Redirecting...",
        invalidSession:
          "Recovery link is invalid or expired. Please request a new one.",
        requestNew: "Request new link",
        checking: "Verifying link...",
      };

  // Handle the recovery token in the URL and verify the session.
  // Supports both PKCE (?code=xxx) and token-hash (?token_hash=xxx&type=recovery) formats.
  useEffect(() => {
    const supabase = createClient();
    let cancelled = false;

    async function verifyRecovery() {
      const code = searchParams.get("code");
      const tokenHash = searchParams.get("token_hash");
      const type = searchParams.get("type");

      // 1. If we already have a session (user came back to the page), use it.
      const { data: existing } = await supabase.auth.getUser();
      if (existing.user) {
        if (!cancelled) {
          setHasSession(true);
          setChecking(false);
        }
        return;
      }

      // 2. PKCE flow: exchange the code for a session
      if (code) {
        const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
        if (cancelled) return;
        if (!exchangeError) {
          setHasSession(true);
          setChecking(false);
          // Clean the code from the URL so a refresh doesn't try to re-exchange
          window.history.replaceState({}, "", `/${locale}/reset-password`);
          return;
        }
        console.error("[reset-password] exchangeCodeForSession failed:", exchangeError.message);
      }

      // 3. Token-hash flow: verify the OTP
      if (tokenHash && type === "recovery") {
        const { error: verifyError } = await supabase.auth.verifyOtp({
          token_hash: tokenHash,
          type: "recovery",
        });
        if (cancelled) return;
        if (!verifyError) {
          setHasSession(true);
          setChecking(false);
          window.history.replaceState({}, "", `/${locale}/reset-password`);
          return;
        }
        console.error("[reset-password] verifyOtp failed:", verifyError.message);
      }

      // 4. Also check the URL fragment (legacy #access_token flow, just in case)
      if (typeof window !== "undefined" && window.location.hash.includes("access_token")) {
        // The Supabase client auto-detects session from hash, give it a moment
        await new Promise((r) => setTimeout(r, 200));
        const { data: retry } = await supabase.auth.getUser();
        if (!cancelled && retry.user) {
          setHasSession(true);
          setChecking(false);
          window.history.replaceState({}, "", `/${locale}/reset-password`);
          return;
        }
      }

      // No session could be established
      if (!cancelled) {
        setHasSession(false);
        setChecking(false);
      }
    }

    verifyRecovery();
    return () => { cancelled = true; };
  }, [searchParams, locale]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (password.length < 8) {
      setError(t.passwordTooShort);
      return;
    }
    if (password !== confirmPassword) {
      setError(t.passwordMismatch);
      return;
    }

    setLoading(true);
    setError(null);

    const supabase = createClient();
    const { error: updateError } = await supabase.auth.updateUser({ password });

    if (updateError) {
      setError(updateError.message);
      setLoading(false);
      return;
    }

    setSuccess(true);
    // Redirect to dashboard after a brief pause
    setTimeout(() => {
      router.push(`/${locale}/dashboard`);
      router.refresh();
    }, 1500);
  }

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
        <p className="text-sm text-gray-500">{t.checking}</p>
      </div>
    );
  }

  if (!hasSession) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg text-center">
          <p className="text-sm text-red-600">{t.invalidSession}</p>
          <Link
            href={`/${locale}/forgot-password`}
            className="mt-4 inline-block text-sm font-medium text-[#C4704B] hover:underline"
          >
            {t.requestNew}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold text-[#1a1a2e]">{t.title}</h1>
          <p className="mt-2 text-sm text-gray-500">{t.subtitle}</p>
        </div>

        {error && (
          <div
            id="form-error"
            role="alert"
            className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-600"
          >
            {error}
          </div>
        )}

        {success && (
          <div className="mb-4 rounded-lg bg-green-50 p-3 text-sm text-green-700">
            {t.success}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              {t.newPassword}
            </label>
            <input
              id="password"
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t.placeholder}
              required
              minLength={8}
              disabled={success}
              aria-invalid={!!error}
              aria-describedby="form-error"
              className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B] disabled:opacity-60"
            />
          </div>
          <div>
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
              {t.confirmPassword}
            </label>
            <input
              id="confirmPassword"
              type="password"
              autoComplete="new-password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder={t.placeholder}
              required
              minLength={8}
              disabled={success}
              aria-invalid={!!error}
              aria-describedby="form-error"
              className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B] disabled:opacity-60"
            />
          </div>
          <button
            type="submit"
            disabled={loading || success}
            className="w-full rounded-lg bg-gradient-to-r from-[#C4704B] to-[#A0522D] px-4 py-3 font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "..." : t.updatePassword}
          </button>
        </form>
      </div>
    </div>
  );
}
