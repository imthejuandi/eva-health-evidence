import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/lib/auth/require-admin";
import { AdminClient, type FulfillmentCycle, type BridgeRunRow } from "./admin-client";

interface AdminPageProps {
  params: Promise<{ locale: string }>;
}

export default async function AdminPage({ params }: AdminPageProps) {
  const { locale } = await params;

  // The (admin) layout already gates, but the service-role reads below make
  // this page re-verify on its own — defense in depth, not layout-trust.
  const adminUser = await requireAdmin();
  if (!adminUser) redirect(`/${locale}/dashboard`);

  // The fulfillment queue lists OTHER users' bookings/results/profiles. The
  // cookie-bound client is RLS-scoped to own rows, which renders the queue
  // empty for every admin — these reads need the service-role client.
  const admin = createAdminClient();
  if (!admin) {
    console.error("[admin] SUPABASE_SERVICE_ROLE_KEY not configured — queue would be empty");
  }
  const supabase = admin ?? (await createClient());

  // Fulfillment queue (F5): open cycles with the ship-to info Ops needs.
  const { data: cycles } = await supabase
    .from("test_cycles")
    .select(
      "id, user_id, seq, panel_type, status, due_date, placer_order_number, kit_label_code, dhl_tracking_out, extraction_confirmed_at, oml_sent_at, oml_ack, created_at, updated_at, profiles:user_id (full_name, email, phone, address_line1, address_line2, address_city, address_postal_code, address_province, id_document_type, id_document_number)",
    )
    .not("status", "in", "(completed,cancelled)")
    .order("due_date", { ascending: true })
    .limit(100);

  // Fetch pending bookings with user info
  const { data: bookings } = await supabase
    .from("booked_tests")
    .select("*, profiles(full_name, email)")
    .neq("status", "completed")
    .neq("status", "cancelled")
    .order("created_at", { ascending: false })
    .limit(50);

  // Fetch recent lab results for processing log
  const { data: labResults } = await supabase
    .from("lab_results")
    .select("*, profiles(full_name, email)")
    .order("created_at", { ascending: false })
    .limit(50);

  // Fetch all users for search
  const { data: users } = await supabase
    .from("profiles")
    .select("id, full_name, email")
    .order("full_name");

  // Last passes of the lab bridge, cron included — the desk's only window
  // into what runs unattended every 10 minutes.
  const { data: bridgeRuns } = await supabase
    .from("lab_bridge_runs")
    .select("id, started_at, trigger, processing_id, ok, error, summary")
    .order("started_at", { ascending: false })
    .limit(10);

  return (
    <AdminClient
      locale={locale}
      cycles={(cycles ?? []) as unknown as FulfillmentCycle[]}
      bridgeRuns={(bridgeRuns ?? []) as BridgeRunRow[]}
      bookings={bookings ?? []}
      labResults={labResults ?? []}
      users={users ?? []}
    />
  );
}
