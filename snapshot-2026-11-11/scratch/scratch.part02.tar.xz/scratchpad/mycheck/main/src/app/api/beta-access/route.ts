import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";

/**
 * Validate the beta password and set the eva_beta_access cookie.
 *
 * Soft gate, not real authentication. The point is to keep random
 * traffic off the pre-launch site, not to defend against a motivated
 * attacker. The shared password lives in the BETA_ACCESS_PASSWORD env
 * var; if it is unset the gate fails closed (503) rather than falling
 * back to a default. The cookie holds the literal value "1"; the proxy
 * only checks for presence + that exact value.
 *
 * On success the response sets the cookie and returns
 * { ok: true, next: "<deep link or />" }. The client is responsible
 * for the actual navigation so the cookie is sent on the next request.
 */
function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

export async function POST(req: NextRequest) {
  // SEC-016 — fail closed if the gate password is not configured, instead of
  // falling back to a public-in-repo default like "EvaTesting".
  const expected = process.env.BETA_ACCESS_PASSWORD;
  if (!expected) {
    return NextResponse.json(
      { error: "Beta access is not configured." },
      { status: 503 },
    );
  }

  let body: { password?: string; next?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  // SEC-016 — constant-time comparison to avoid a timing side-channel on the
  // shared password.
  if (typeof body.password !== "string" || !safeEqual(body.password, expected)) {
    return NextResponse.json(
      { error: "incorrect_password" },
      { status: 401 },
    );
  }

  // Sanitize the post-unlock redirect: only accept same-origin
  // paths that start with "/" and are not the gate itself. Prevents
  // an attacker crafting a poisoned link that bounces unlocked
  // visitors to a phishing host or back to /beta in a loop.
  const rawNext = typeof body.next === "string" ? body.next : "";
  const safeNext =
    rawNext.startsWith("/") &&
    !rawNext.startsWith("//") &&
    !rawNext.includes("/beta")
      ? rawNext
      : "/";

  const res = NextResponse.json({ ok: true, next: safeNext });
  res.cookies.set("eva_beta_access", "1", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30, // 30 days
  });
  return res;
}
