import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getAdapter } from "@/lib/wearables";
import { hasPaidAccess } from "@/lib/stripe/helpers";

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    // Wearable import is a paid-only feature. Mirror the gate on EVA
    // AI chat: active quarterly subscribers and Full Panel buyers
    // qualify. Free users get 402; the profile UI surfaces a paywall
    // in place of the Connect button.
    const { data: paidProfile } = await supabase
      .from("profiles")
      .select("subscription_status, subscription_period_end, full_panel_purchased_at")
      .eq("id", user.id)
      .single();
    if (!hasPaidAccess(paidProfile)) {
      return NextResponse.json(
        { error: "Subscription required", code: "paid_only" },
        { status: 402 },
      );
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const source = (formData.get("source") as string) ?? "apple_health";

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    // SEC-009 — bound export size + type before buffering. Apple Health
    // exports are large (export.zip / export.xml), so the cap is generous
    // but still blocks abusive multi-hundred-MB uploads.
    const MAX_EXPORT_BYTES = 100 * 1024 * 1024; // 100 MB
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    if (!new Set(["zip", "xml"]).has(ext)) {
      return NextResponse.json(
        { error: "Unsupported export. Upload an Apple Health .zip or .xml export." },
        { status: 415 },
      );
    }
    if (file.size > MAX_EXPORT_BYTES) {
      return NextResponse.json(
        { error: `Export too large (max ${MAX_EXPORT_BYTES / (1024 * 1024)} MB).` },
        { status: 413 },
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const adapter = getAdapter(source);
    const result = await adapter.parseExport(buffer);

    if (result.data.length === 0) {
      return NextResponse.json({ error: "No data found in export" }, { status: 400 });
    }

    // Upsert into wearable_data (ON CONFLICT user_id+date+source → UPDATE)
    const rows = result.data.map((day) => ({
      user_id: user.id,
      date: day.date,
      source,
      hrv_ms: day.hrv_ms,
      resting_hr_bpm: day.resting_hr_bpm,
      sleep_hours: day.sleep_hours,
      respiratory_rate: day.respiratory_rate,
      steps: day.steps,
      recovery_score: day.recovery_score,
    }));

    // Batch upsert in chunks of 100
    const BATCH_SIZE = 100;
    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
      const batch = rows.slice(i, i + BATCH_SIZE);
      const { error } = await supabase
        .from("wearable_data")
        .upsert(batch, { onConflict: "user_id,date,source" });

      if (error) {
        console.error("[wearable-import] Upsert error:", error.message);
        return NextResponse.json({ error: "Failed to save data" }, { status: 500 });
      }
    }

    return NextResponse.json({
      daysImported: result.daysImported,
      dateRange: result.dateRange,
      source,
    });
  } catch (e) {
    console.error("[wearable-import] Error:", e);
    const msg = e instanceof Error ? e.message : "Import failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
