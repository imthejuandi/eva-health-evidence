"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";

type Mode = "password" | "magic";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<Mode>("password");
  const [magicSent, setMagicSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const params = useParams();
  const router = useRouter();
  const locale = (params.locale as string) ?? "es";

  const t = locale === "es"
    ? {
        welcome: "Bienvenido a EVA Health",
        subtitle: "Inicia sesión para acceder a tu panel de salud",
        email: "Correo electrónico",
        emailPlaceholder: "tu@ejemplo.com",
        password: "Contraseña",
        passwordPlaceholder: "Tu contraseña",
        signIn: "Iniciar sesión",
        sendMagicLink: "Enviar enlace mágico",
        continueWithGoogle: "Continuar con Google",
        or: "o",
        noAccount: "¿No tienes cuenta?",
        signup: "Registrarse",
        checkEmail: "Revisa tu correo para el enlace mágico",
        forgotPassword: "¿Olvidaste tu contraseña?",
        useMagicLink: "Iniciar sesión con enlace mágico",
        usePassword: "Iniciar sesión con contraseña",
        emailNotConfirmed: "Por favor confirma tu correo antes de iniciar sesión.",
        invalidCredentials: "Correo o contraseña incorrectos.",
      }
    : {
        welcome: "Welcome to EVA Health",
        subtitle: "Sign in to access your health dashboard",
        email: "Email",
        emailPlaceholder: "you@example.com",
        password: "Password",
        passwordPlaceholder: "Your password",
        signIn: "Sign in",
        sendMagicLink: "Send magic link",
        continueWithGoogle: "Continue with Google",
        or: "or",
        noAccount: "Don't have an account?",
        signup: "Sign up",
        checkEmail: "Check your email for the magic link",
        forgotPassword: "Forgot your password?",
        useMagicLink: "Sign in with magic link",
        usePassword: "Sign in with password",
        emailNotConfirmed: "Please confirm your email before signing in.",
        invalidCredentials: "Invalid email or password.",
      };

  async function handlePasswordLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const supabase = createClient();
    const { data, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (authError) {
      // Map Supabase errors to friendlier messages
      const msg = authError.message.toLowerCase();
      if (msg.includes("email not confirmed")) {
        setError(t.emailNotConfirmed);
      } else if (msg.includes("invalid login credentials") || msg.includes("invalid")) {
        setError(t.invalidCredentials);
      } else {
        setError(authError.message);
      }
      setLoading(false);
      return;
    }

    if (data.session) {
      // Check onboarding status and redirect
      const { data: profile } = await supabase
        .from("profiles")
        .select("onboarding_completed")
        .eq("id", data.user.id)
        .single();

      const next = !profile || !profile.onboarding_completed
        ? `/${locale}/onboarding`
        : `/${locale}/dashboard`;
      router.push(next);
      router.refresh();
    } else {
      setLoading(false);
    }
  }

  async function handleMagicLink(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const supabase = createClient();
    const { error: authError } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/${locale}/callback`,
      },
    });

    if (authError) {
      setError(authError.message);
    } else {
      setMagicSent(true);
    }
    setLoading(false);
  }

  async function handleGoogle() {
    const supabase = createClient();
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/${locale}/callback`,
      },
    });
  }

  if (magicSent) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg text-center">
          <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-gradient-to-br from-[#C4704B] to-[#A0522D] flex items-center justify-center">
            <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <p className="text-lg font-medium text-[#1a1a2e]">{t.checkEmail}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#F5F0EB]">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold text-[#1a1a2e]">{t.welcome}</h1>
          <p className="mt-2 text-sm text-gray-500">{t.subtitle}</p>
        </div>

        {error && (
          <div
            id="form-error"
            role="alert"
            className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-600"
          >
            {error}
          </div>
        )}

        {mode === "password" ? (
          <form onSubmit={handlePasswordLogin} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                {t.email}
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                required
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  {t.password}
                </label>
                <Link
                  href={`/${locale}/forgot-password`}
                  className="text-xs font-medium text-[#C4704B] hover:underline"
                >
                  {t.forgotPassword}
                </Link>
              </div>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                required
                minLength={8}
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-gradient-to-r from-[#C4704B] to-[#A0522D] px-4 py-3 font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {loading ? "..." : t.signIn}
            </button>
          </form>
        ) : (
          <form onSubmit={handleMagicLink} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                {t.email}
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                required
                aria-invalid={!!error}
                aria-describedby="form-error"
                className="mt-1 block w-full rounded-lg border border-gray-300 px-4 py-3 text-[#1a1a2e] placeholder-gray-500 focus:border-[#C4704B] focus:outline-none focus:ring-1 focus:ring-[#C4704B]"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-gradient-to-r from-[#C4704B] to-[#A0522D] px-4 py-3 font-medium text-white transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {loading ? "..." : t.sendMagicLink}
            </button>
          </form>
        )}

        {/* Toggle between password / magic link */}
        <button
          type="button"
          onClick={() => {
            setMode(mode === "password" ? "magic" : "password");
            setError(null);
          }}
          className="mt-3 w-full text-center text-sm text-[#C4704B] hover:underline"
        >
          {mode === "password" ? t.useMagicLink : t.usePassword}
        </button>

        <div className="my-6 flex items-center">
          <div className="flex-1 border-t border-gray-200" />
          <span className="mx-4 text-sm text-gray-400">{t.or}</span>
          <div className="flex-1 border-t border-gray-200" />
        </div>

        <button
          onClick={handleGoogle}
          className="flex w-full items-center justify-center gap-3 rounded-lg border border-gray-300 bg-white px-4 py-3 font-medium text-[#1a1a2e] transition-colors hover:bg-gray-50"
        >
          <svg className="h-5 w-5" viewBox="0 0 24 24">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
          </svg>
          {t.continueWithGoogle}
        </button>

        <p className="mt-6 text-center text-sm text-gray-500">
          {t.noAccount}{" "}
          <Link
            href={`/${locale}/signup`}
            className="font-medium text-[#C4704B] hover:underline"
          >
            {t.signup}
          </Link>
        </p>
      </div>
    </div>
  );
}
