"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { SectionTag } from "@/components/marketing/SectionTag";
import { CTAButton } from "@/components/marketing/CTAButton";
import { Rocket, TrendingUp, Handshake, Briefcase } from "lucide-react";

export default function ContactPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const [form, setForm] = useState({ name: "", email: "", message: "", category: "General" });
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  const t =
    locale === "es"
      ? {
          pageTag: "Contacto",
          pageTitle: "Hablemos",
          pageDesc: "Ya sea que quieras empezar tu camino de salud, explorar una asociacion o unirte a nuestro equipo, estamos aqui.",
          startTitle: "Comienza Tu Camino de Salud",
          startDesc: "Suscribete o sube tus analisis existentes gratis.",
          startCta: "Registrarse",
          uploadCta: "Sube Tus Analisis Gratis",
          investorTitle: "Consultas de Inversores",
          investorDesc: "Estamos en etapa pre-seed. Hablemos sobre nuestra vision.",
          partnerTitle: "Colaboraciones",
          partnerDesc: "Laboratorios, wearables e integraciones de salud.",
          careersTitle: "Carreras",
          careersDesc: "Estamos construyendo el futuro de la salud preventiva.",
          careersLink: "Ver posiciones abiertas",
          formTag: "Enviar un Mensaje",
          formName: "Nombre",
          formEmail: "Correo electronico",
          formCategory: "Categoria",
          formMessage: "Mensaje",
          formSubmit: "Enviar Mensaje",
          formSending: "Enviando...",
          formSent: "Mensaje enviado. Te responderemos pronto.",
          formError: "Error al enviar. Intentalo de nuevo.",
          catGeneral: "General",
          catInvestor: "Inversor",
          catPartnership: "Colaboracion",
          catPress: "Prensa",
          catSupport: "Soporte",
        }
      : {
          pageTag: "Contact",
          pageTitle: "Let's talk",
          pageDesc: "Whether you want to start your health journey, explore a partnership, or join our team, we're here.",
          startTitle: "Start Your Health Journey",
          startDesc: "Subscribe or upload your existing labs for free.",
          startCta: "Sign Up",
          uploadCta: "Upload Your Labs Free",
          investorTitle: "Investor Inquiries",
          investorDesc: "We're at pre-seed stage. Let's talk about our vision.",
          partnerTitle: "Partnership Inquiries",
          partnerDesc: "Labs, wearables, and health integrations.",
          careersTitle: "Careers",
          careersDesc: "We're building the future of preventative health.",
          careersLink: "See open positions",
          formTag: "Send a Message",
          formName: "Name",
          formEmail: "Email",
          formCategory: "Category",
          formMessage: "Message",
          formSubmit: "Send Message",
          formSending: "Sending...",
          formSent: "Message sent. We'll get back to you soon.",
          formError: "Failed to send. Please try again.",
          catGeneral: "General",
          catInvestor: "Investor",
          catPartnership: "Partnership",
          catPress: "Press",
          catSupport: "Support",
        };

  const categories = [t.catGeneral, t.catInvestor, t.catPartnership, t.catPress, t.catSupport];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("sending");
    try {
      const res = await fetch("/api/emails/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      setStatus("sent");
      setForm({ name: "", email: "", message: "", category: "General" });
    } catch {
      setStatus("error");
    }
  }

  const inputClass =
    "w-full rounded-[16px] border border-[#e7e2dc] bg-white px-5 py-3.5 font-[family-name:var(--font-inter)] text-[14px] text-[#1d1b18] outline-none transition-colors placeholder:text-[#8a7f76] focus:border-[#97472c] focus:ring-1 focus:ring-[#97472c]";

  return (
    <>
      {/* ─── HEADER ─── */}
      <section className="px-5 py-20 md:px-8 md:py-28">
        <div className="mx-auto max-w-3xl text-center">
          <ScrollReveal>
            <SectionTag text={t.pageTag} color="jade" />
            <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[52px]">
              {t.pageTitle}
            </h1>
            <p className="mx-auto mt-5 max-w-xl font-[family-name:var(--font-inter)] text-[16px] leading-relaxed text-[#4c463f]">
              {t.pageDesc}
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* ─── ENTRY POINTS ─── */}
      <section className="bg-[#f8f3ed] px-5 py-20 md:px-8 md:py-28">
        <div className="mx-auto max-w-5xl">
          <div className="grid gap-6 sm:grid-cols-2">
            {/* Start Journey */}
            <ScrollReveal delay={0.05}>
              <div className="rounded-[32px] bg-white p-8 shadow-[0_20px_60px_rgba(29,27,24,0.04)]">
                <div className="flex h-12 w-12 items-center justify-center rounded-[14px] bg-gradient-to-br from-[#97472c] to-[#d97b5c]"><Rocket className="h-5 w-5 text-white" strokeWidth={2} /></div>
                <h3 className="mt-4 font-[family-name:var(--font-manrope)] text-[16px] font-bold text-[#1d1b18]">
                  {t.startTitle}
                </h3>
                <p className="mt-2 font-[family-name:var(--font-inter)] text-[14px] leading-relaxed text-[#4c463f]">
                  {t.startDesc}
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  <CTAButton href={`/${locale}/signup`} className="!px-5 !py-2.5 !text-[13px]">
                    {t.startCta}
                  </CTAButton>
                  <CTAButton variant="ghost" href={`/${locale}/upload`} className="!px-5 !py-2.5 !text-[13px]">
                    {t.uploadCta}
                  </CTAButton>
                </div>
              </div>
            </ScrollReveal>

            {/* Investors */}
            <ScrollReveal delay={0.1}>
              <div className="rounded-[32px] bg-white p-8 shadow-[0_20px_60px_rgba(29,27,24,0.04)]">
                <div className="flex h-12 w-12 items-center justify-center rounded-[14px] bg-gradient-to-br from-[#3a665e] to-[#bcece1]"><TrendingUp className="h-5 w-5 text-white" strokeWidth={2} /></div>
                <h3 className="mt-4 font-[family-name:var(--font-manrope)] text-[16px] font-bold text-[#1d1b18]">
                  {t.investorTitle}
                </h3>
                <p className="mt-2 font-[family-name:var(--font-inter)] text-[14px] leading-relaxed text-[#4c463f]">
                  {t.investorDesc}
                </p>
                <a
                  href="mailto:investors@evahealth.es"
                  className="mt-4 inline-block font-[family-name:var(--font-manrope)] text-[14px] font-bold text-[#97472c] transition-colors hover:text-[#d97b5c]"
                >
                  investors@evahealth.es →
                </a>
              </div>
            </ScrollReveal>

            {/* Partnerships */}
            <ScrollReveal delay={0.15}>
              <div className="rounded-[32px] bg-white p-8 shadow-[0_20px_60px_rgba(29,27,24,0.04)]">
                <div className="flex h-12 w-12 items-center justify-center rounded-[14px] bg-gradient-to-br from-[#c49332] to-[#e8c76a]"><Handshake className="h-5 w-5 text-white" strokeWidth={2} /></div>
                <h3 className="mt-4 font-[family-name:var(--font-manrope)] text-[16px] font-bold text-[#1d1b18]">
                  {t.partnerTitle}
                </h3>
                <p className="mt-2 font-[family-name:var(--font-inter)] text-[14px] leading-relaxed text-[#4c463f]">
                  {t.partnerDesc}
                </p>
                <a
                  href="mailto:partners@evahealth.es"
                  className="mt-4 inline-block font-[family-name:var(--font-manrope)] text-[14px] font-bold text-[#97472c] transition-colors hover:text-[#d97b5c]"
                >
                  partners@evahealth.es →
                </a>
              </div>
            </ScrollReveal>

            {/* Careers */}
            <ScrollReveal delay={0.2}>
              <div className="rounded-[32px] bg-white p-8 shadow-[0_20px_60px_rgba(29,27,24,0.04)]">
                <div className="flex h-12 w-12 items-center justify-center rounded-[14px] bg-[rgba(138,127,118,0.10)]"><Briefcase className="h-5 w-5 text-[#8a7f76]" strokeWidth={2} /></div>
                <h3 className="mt-4 font-[family-name:var(--font-manrope)] text-[16px] font-bold text-[#1d1b18]">
                  {t.careersTitle}
                </h3>
                <p className="mt-2 font-[family-name:var(--font-inter)] text-[14px] leading-relaxed text-[#4c463f]">
                  {t.careersDesc}
                </p>
                <CTAButton variant="ghost" href={`/${locale}/about#team`} className="mt-4 !px-5 !py-2.5 !text-[13px]">
                  {t.careersLink} →
                </CTAButton>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* ─── CONTACT FORM ─── */}
      <section className="px-5 py-20 md:px-8 md:py-28">
        <div className="mx-auto max-w-xl">
          <ScrollReveal>
            <SectionTag text={t.formTag} />
          </ScrollReveal>

          <ScrollReveal delay={0.1}>
            <form onSubmit={handleSubmit} className="mt-8 flex flex-col gap-4">
              <input
                type="text"
                required
                placeholder={t.formName}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className={inputClass}
              />
              <input
                type="email"
                required
                placeholder={t.formEmail}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={inputClass}
              />
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className={inputClass}
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <textarea
                required
                rows={5}
                placeholder={t.formMessage}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className={`${inputClass} resize-none`}
              />
              <CTAButton
                type="submit"
                disabled={status === "sending"}
                className="!w-full !text-center"
              >
                {status === "sending" ? t.formSending : t.formSubmit}
              </CTAButton>

              {status === "sent" && (
                <p className="text-center font-[family-name:var(--font-inter)] text-[14px] text-[#3a665e]">
                  {t.formSent}
                </p>
              )}
              {status === "error" && (
                <p className="text-center font-[family-name:var(--font-inter)] text-[14px] text-[#b04040]">
                  {t.formError}
                </p>
              )}
            </form>
          </ScrollReveal>
        </div>
      </section>
    </>
  );
}
