import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";

  return {
    rules: [
      {
        userAgent: "*",
        allow: ["/"],
        disallow: ["/dashboard", "/labs", "/biomarker", "/eva-ai", "/book", "/profile", "/upload", "/onboarding", "/admin", "/api/", "/callback", "/beta", "/checkout-resume"],
      },
    ],
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}
