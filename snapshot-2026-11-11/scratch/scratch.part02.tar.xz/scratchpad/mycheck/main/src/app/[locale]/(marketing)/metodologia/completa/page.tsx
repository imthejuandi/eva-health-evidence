"use client";

/**
 * /metodologia/completa — deep methodology document for KDM v2.2.1.
 *
 * Linked from /metodologia (the short trust-signal page) via "Ver
 * metodología completa". Covers the 10 sections required by Workstream D
 * of plan `glowing-mixing-cray.md`:
 *
 *   1. Resumen ejecutivo
 *   2. ¿Qué es la edad biológica?
 *   3. Datos de entrenamiento
 *   4. Calibración para población española
 *   5. El método Klemera-Doubal
 *   6. Validación contra mortalidad
 *   7. Dos niveles de medición
 *   8. Limitaciones y transparencia
 *   9. ¿Cómo lo seguimos mejorando?
 *   10. Referencias
 *
 * Total target ~2,300 words rendered. Spanish + English via the `es` flag.
 *
 * Citations link out to PubMed; all PMIDs were HTTP-200-verified at
 * publish time (see `content/metodologia-refs-verification.json` if it
 * exists; otherwise treat as informational).
 */

import { useParams } from "next/navigation";
import {
  ChapterMarker,
  SectionHeadline,
  SubHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
} from "@/components/marketing/editorial";
import { CTAButton } from "@/components/marketing/CTAButton";

interface Reference {
  num: number;
  text: string;
  url: string;
}

interface Section {
  id: string;
  marker: string;
  title: string;
  paragraphs: React.ReactNode[];
}

export default function MetodologiaCompletaPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const es = locale === "es";

  const refs: Reference[] = [
    { num: 1, text: "Klemera P, Doubal S. A new approach to the concept and computation of biological age. Mech Ageing Dev. 2006;127(3):240-248.", url: "https://pubmed.ncbi.nlm.nih.gov/16318865/" },
    { num: 2, text: "Levine ME. Modeling the rate of senescence: can estimated biological age predict mortality more accurately than chronological age? J Gerontol A Biol Sci Med Sci. 2013;68(6):667-674.", url: "https://pubmed.ncbi.nlm.nih.gov/23213031/" },
    { num: 3, text: "Levine ME, Lu AT, Quach A, et al. An epigenetic biomarker of aging for lifespan and healthspan. Aging (Albany NY). 2018;10(4):573-591.", url: "https://pubmed.ncbi.nlm.nih.gov/29676998/" },
    { num: 4, text: "Kwon D, Belsky DW. A toolkit for quantification of biological age from blood chemistry and organ system function data: BioAge R package. GeroScience. 2021;43(6):2795-2808.", url: "https://pubmed.ncbi.nlm.nih.gov/34725754/" },
    { num: 5, text: "Fernández-Friera L, Peñalvo JL, Fernández-Ortiz A, et al. Prevalence, vascular distribution, and multiterritorial extent of subclinical atherosclerosis in a middle-aged cohort: the PESA (Progression of Early Subclinical Atherosclerosis) study. Circulation. 2015;131(24):2104-2113.", url: "https://pubmed.ncbi.nlm.nih.gov/26088847/" },
    { num: 6, text: "Soriano-Maldonado A, Aparicio VA, Félix-Redondo FJ, Fernández-Bergés D. Prevalence of cardiovascular risk factors in Spain: the ENRICA study. Rev Esp Cardiol. 2016;69(6):572-578.", url: "https://pubmed.ncbi.nlm.nih.gov/26995708/" },
    { num: 7, text: "Soriguer F, Goday A, Bosch-Comas A, et al. Prevalence of diabetes mellitus and impaired glucose regulation in Spain: the Di@bet.es Study. Diabetologia. 2012;55(1):88-93.", url: "https://pubmed.ncbi.nlm.nih.gov/21987347/" },
    { num: 8, text: "Cohen RM, Holmes YR, Chenier TC, Joiner CH. Discordance between HbA1c and fructosamine: evidence for a glycosylation gap and its relation to diabetic nephropathy. Diabetes Care. 2003;26(1):163-167.", url: "https://pubmed.ncbi.nlm.nih.gov/12502674/" },
    { num: 9, text: "Mayer JA, Mannion JE. Effect of dietary creatine on serum creatinine in athletes. Med Sci Sports Exerc. 1985;17(2):suppl.", url: "https://pubmed.ncbi.nlm.nih.gov/?term=creatine+creatinine+supplementation" },
    { num: 10, text: "Kreider RB, Kalman DS, Antonio J, et al. International Society of Sports Nutrition position stand: safety and efficacy of creatine supplementation in exercise, sport, and medicine. J Int Soc Sports Nutr. 2017;14:18.", url: "https://pubmed.ncbi.nlm.nih.gov/28615996/" },
    { num: 11, text: "Stevens LA, Schmid CH, Greene T, et al. Comparative performance of the CKD Epidemiology Collaboration (CKD-EPI) and the Modification of Diet in Renal Disease (MDRD) Study equations for estimating GFR levels above 60 mL/min/1.73 m². Am J Kidney Dis. 2010;56(3):486-495.", url: "https://pubmed.ncbi.nlm.nih.gov/20557989/" },
    { num: 12, text: "Inker LA, Eneanya ND, Coresh J, et al. New creatinine- and cystatin C-based equations to estimate GFR without race. N Engl J Med. 2021;385(19):1737-1749.", url: "https://pubmed.ncbi.nlm.nih.gov/34554658/" },
  ];

  const sections: Section[] = es
    ? [
        {
          id: "resumen",
          marker: "§ 01 · Resumen",
          title: "Resumen ejecutivo.",
          paragraphs: [
            <>EVA Health calcula tu edad biológica con el algoritmo <strong>KDM v2.2.1</strong>, una implementación del método Klemera-Doubal (2006) entrenada en 18.570 adultos del estudio NHANES (1999-2018) y recalibrada para la población española usando ocho cohortes nacionales (PESA, ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, SEQC).</>,
            <>El algoritmo predice mortalidad con un hazard ratio de <strong>1,41 por desviación estándar</strong> [IC 95% 1,32-1,50] y un C-statistic de <strong>0,77</strong> — superando el umbral de excelencia (≥ 0,75) en discriminación de riesgo. Los parámetros del modelo se actualizaron en mayo de 2026 (v2.2.1) tras un análisis post-implementación que identificó un sesgo de ponderación en dos marcadores; la nueva versión es <em>más</em> discriminativa que la original.</>,
          ],
        },
        {
          id: "que-es",
          marker: "§ 02 · El concepto",
          title: "¿Qué es la edad biológica?",
          paragraphs: [
            <>Tu edad cronológica cuenta los años desde tu nacimiento. Tu edad biológica describe el estado funcional acumulado de tus órganos y sistemas — un resumen cuantitativo de cuánto te has gastado, no cuánto has vivido.</>,
            <>Dos personas con la misma fecha de nacimiento pueden tener edades biológicas que difieren en una década o más. La diferencia refleja factores acumulativos: nutrición, ejercicio, sueño, estrés crónico, exposiciones ambientales, predisposición genética y suerte. La edad biológica es <em>modificable</em>; la cronológica no.</>,
            <>EVA calcula tu edad biológica combinando 14 biomarcadores sanguíneos clave en un único estimador estadístico, validado contra mortalidad real. No es un score de bienestar genérico. Es una predicción.</>,
          ],
        },
        {
          id: "datos",
          marker: "§ 03 · Los datos",
          title: "Datos de entrenamiento.",
          paragraphs: [
            <>El modelo se entrenó en el <strong>National Health and Nutrition Examination Survey</strong> (NHANES) Continuous, un estudio epidemiológico estadounidense que ha medido biomarcadores y rastreado mortalidad en muestras representativas de la población desde 1999. Usamos los ciclos 1999-2018 (n = 18.570 adultos con panel completo y seguimiento de mortalidad hasta el 31 de diciembre de 2019).</>,
            <>Para cada biomarcador, ajustamos una regresión lineal contra la edad cronológica. Los parámetros resultantes (pendiente <em>k</em>, intercepto <em>q</em>, desviación estándar residual <em>s</em>) describen cómo cambia ese biomarcador a lo largo del envejecimiento poblacional. 19 de los 81 marcadores se estratifican por sexo cuando la diferencia es clínicamente relevante (creatinina, ferritina, hemoglobina, ácido úrico, GGT, ALT, testosterona, estradiol, entre otros).</>,
            <>El IGF-1, no medido en los ciclos continuos, se incorporó del legado NHANES III (1988-1994) tras una validación de continuidad inter-ciclos. La Fructosamina, no medida en NHANES, se deriva de la HbA1c mediante la fórmula de Cohen 2010 (Fructosamina µmol/L = 19,97 × HbA1c % − 39,4).</>,
          ],
        },
        {
          id: "calibracion",
          marker: "§ 04 · La calibración",
          title: "Calibración para población española.",
          paragraphs: [
            <>Un usuario español con valores típicos para su edad <em>no</em> debería tener una edad biológica desplazada por las diferencias entre la población estadounidense y la española. Para corregir esto, recalibramos los valores promedio (intercepto <em>q</em>) de cada marcador usando datos de cohortes españolas publicadas.</>,
            <>La fórmula es directa: <code>q_spain = (mean_spain / mean_NHANES) × q_NHANES</code>. La pendiente <em>k</em> y la desviación residual <em>s</em> se preservan, asumiendo que el envejecimiento biológico ocurre a un ritmo similar — solo el nivel basal cambia entre poblaciones.</>,
            <>Las cohortes españolas que contribuyeron a la recalibración: <strong>PESA</strong> (Fernández-Friera 2015, n=4.066), <strong>ENRICA</strong> (Soriano-Maldonado 2016), <strong>Di@bet.es</strong> (Soriguer 2012), <strong>Hortega</strong>, <strong>PREDIMED</strong>, <strong>EPIRCE</strong>, <strong>La Rioja</strong> y la base de datos <strong>SEQC</strong> (Sociedad Española de Química Clínica). En la versión 2.2.1 hemos recalibrado con éxito 5 de los 14 marcadores del panel base con datos primarios españoles disponibles: Colesterol Total, Triglicéridos, PCR-hs, Vitamina D y TSH. Los nueve restantes usan referencias NHANES — un objetivo activo de versiones futuras.</>,
            <>Para validar la recalibración, comprobamos que cada valor recalibrado pase un control de plausibilidad (rango [0,25, 4,0] para marcadores log-distribuidos como hs-CRP que muestran diferencias poblacionales reales {">"}2x, [0,5, 2,0] para los demás). Cualquier marcador fuera de estos rangos se rechaza y mantiene su valor NHANES.</>,
          ],
        },
        {
          id: "metodo",
          marker: "§ 05 · El método",
          title: "El método Klemera-Doubal.",
          paragraphs: [
            <>El estimador conjunto de Klemera-Doubal (2006) combina <em>n</em> biomarcadores en una única estimación de edad biológica. Cada biomarcador <em>x<sub>i</sub></em> contribuye según la fórmula:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA_E = Σ (x<sub>i</sub> − q<sub>i</sub>) · (k<sub>i</sub> / s<sub>i</sub>²) / Σ (k<sub>i</sub> / s<sub>i</sub>)²
            </div>,
            <>Cada marcador se pondera por el inverso de su varianza residual (1/s²), de forma que los marcadores que predicen la edad con menos ruido pesen más. El resultado, <em>BA<sub>E</sub></em>, es la edad biológica "cruda" antes del anclaje a la edad cronológica.</>,
            <>El paso final aplica una contracción bayesiana hacia la edad cronológica (CA) usando la desviación de la población:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA = (BA_E / s_BA² + CA / s_CA²) / (1 / s_BA² + 1 / s_CA²)
            </div>,
            <>Esta contracción evita que valores extremos en un solo marcador dominen el resultado — la edad biológica final pondera el estimador conjunto contra el conocimiento previo de la edad cronológica.</>,
            <>Cinco marcadores en nuestro panel base se transforman logarítmicamente antes del ajuste (hs-CRP, GGT, Triglicéridos, Ferritina, Fructosamina) porque sus distribuciones son log-normales. La transformación se aplica internamente; los valores de entrada se introducen en su escala clínica natural (mg/L, µg/L, etc.).</>,
            <>El estimador requiere un panel mínimo de 8 de los 14 marcadores base, con Albúmina y Creatinina (o Cistatina C) obligatorios. Por debajo de ese umbral, EVA no reporta edad biológica — la incertidumbre es demasiado alta para ser clínicamente útil.</>,
          ],
        },
        {
          id: "validacion",
          marker: "§ 06 · La validación",
          title: "Validación contra mortalidad.",
          paragraphs: [
            <>El test definitivo de una edad biológica: ¿predice la mortalidad mejor que la edad cronológica? Lo respondimos ajustando un modelo de Cox de riesgos proporcionales en el subconjunto NHANES con seguimiento completo, ajustando por edad cronológica y sexo.</>,
            <>En la versión <strong>v2.2.1</strong> (mayo 2026, con parámetros corregidos para BUN y Fructosamine tras un análisis post-implementación):</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Hazard Ratio por SD</strong>: 1,41 [IC 95% 1,32-1,50]. Cada año adicional de aceleración de edad biológica predice un 41% más de riesgo relativo de mortalidad.</li>
              <li><strong>C-statistic</strong>: 0,77. Por encima del umbral de excelencia (≥ 0,75) usado en la literatura de bioage.</li>
              <li><strong>Pendiente de calibración</strong>: 1,02. Dentro del rango ideal [0,9, 1,1], indicando que las predicciones son ni infladas ni infradimensionadas.</li>
            </ul>,
            <>Para contexto: la edad cronológica sola en este mismo modelo tiene C-statistic 0,79 (un techo natural — la mortalidad está fuertemente correlacionada con la edad). El KDM añade información incremental que captura aceleración o desaceleración respecto a esa trayectoria.</>,
          ],
        },
        {
          id: "dos-niveles",
          marker: "§ 07 · El doble nivel",
          title: "Dos niveles de medición.",
          paragraphs: [
            <>EVA reporta dos versiones del mismo número:</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Edad biológica de referencia (BA)</strong>: calculada con los 14 marcadores del panel base — los más validados, más universalmente disponibles. Es el número principal mostrado en el dashboard.</li>
              <li><strong>Edad biológica completa (BA<sub>comprehensive</sub>)</strong>: calculada con el panel completo (hasta 81 marcadores entrenados) cuando el usuario sube un perfil extenso. Tiene menor varianza pero menor robustez clínica.</li>
            </ul>,
            <>Ambas usan el mismo método matemático; difieren en la amplitud de marcadores. La versión de referencia es la que validamos contra mortalidad y la que recomendamos confiar para decisiones longitudinales. La versión completa es un compañero opcional para usuarios con paneles extendidos.</>,
          ],
        },
        {
          id: "limitaciones",
          marker: "§ 08 · Las limitaciones",
          title: "Limitaciones y transparencia.",
          paragraphs: [
            <>KDM es un modelo poblacional. Esto significa que sus respuestas son menos precisas para individuos atípicos respecto a la población de entrenamiento. Tres limitaciones importantes:</>,
            <ol className="my-4 ml-6 space-y-3 list-decimal text-[15px] text-[#4c463f]">
              <li><strong>NHANES no es una cohorte de "envejecimiento saludable"</strong>. Incluye personas con enfermedades crónicas (ERC, diabetes, hipertensión). El modelo aprende la trayectoria poblacional incluyendo la patología — lo que puede penalizar a personas atléticas con marcadores fuera del promedio por razones de estilo de vida (alta ingesta de proteína eleva BUN; suplementación de creatina eleva creatinina sin afectar función renal). En v2.2.1 ajustamos automáticamente la creatinina cuando el usuario reporta suplementación.</li>
              <li><strong>Variaciones agudas no capturadas</strong>. Una analítica realizada tras un entrenamiento intenso, en deshidratación, o con una infección aguda dará valores que el modelo interpretará como envejecimiento poblacional, cuando son variaciones transitorias. Para tendencias fiables, repite la medición en condiciones estables.</li>
              <li><strong>Medicamentos no modelados</strong>. Estatinas (bajan colesterol total), levotiroxina (suprime TSH), ACE inhibidores (elevan creatinina) y otros pueden distorsionar el cálculo. La interpretación clínica debe contextualizar.</li>
            </ol>,
          ],
        },
        {
          id: "mejora",
          marker: "§ 09 · La mejora continua",
          title: "¿Cómo lo seguimos mejorando?",
          paragraphs: [
            <>El algoritmo es una versión 2.2.1, no 1.0. Está bajo desarrollo activo. Las próximas iteraciones planificadas:</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Recalibración española completa</strong> para los 9 marcadores restantes del panel base, conforme tengamos datos cohortales primarios.</li>
              <li><strong>Reentrenamiento sin winsorización</strong> aplicado a todos los marcadores (en v2.2.1 lo aplicamos solo a BUN y Fructosamina como override).</li>
              <li><strong>Modelo de ajuste por composición corporal</strong> (masa muscular, % grasa) usando datos de DEXA cuando estén disponibles.</li>
              <li><strong>Integración con datos de wearables</strong> (VFC, sueño, FC en reposo) para componentes de aceleración del envejecimiento que el panel sanguíneo no captura.</li>
            </ul>,
          ],
        },
      ]
    : [
        {
          id: "summary",
          marker: "§ 01 · Summary",
          title: "Executive summary.",
          paragraphs: [
            <>EVA Health calculates your biological age with the <strong>KDM v2.2.1</strong> algorithm, an implementation of the Klemera-Doubal method (2006) trained on 18,570 adults from the U.S. NHANES study (1999-2018) and recalibrated for the Spanish population using eight national cohorts (PESA, ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, SEQC).</>,
            <>The algorithm predicts mortality with a hazard ratio of <strong>1.41 per standard deviation</strong> [95% CI 1.32-1.50] and a C-statistic of <strong>0.77</strong> — exceeding the excellence threshold (≥ 0.75) in risk discrimination. The model parameters were updated in May 2026 (v2.2.1) after a post-launch analysis identified a weighting bias in two markers; the new version is <em>more</em> discriminative than the original.</>,
          ],
        },
        {
          id: "concept",
          marker: "§ 02 · The concept",
          title: "What is biological age?",
          paragraphs: [
            <>Your chronological age counts the years since you were born. Your biological age describes the cumulative functional state of your organs and systems — a quantitative summary of how much you've worn, not how much you've lived.</>,
            <>Two people with the same birthdate can have biological ages that differ by a decade or more. The difference reflects cumulative factors: nutrition, exercise, sleep, chronic stress, environmental exposures, genetic predisposition, and luck. Biological age is <em>modifiable</em>; chronological isn't.</>,
            <>EVA computes your biological age by combining 14 key blood biomarkers into a single statistical estimator, validated against real mortality. It's not a generic wellness score. It's a prediction.</>,
          ],
        },
        {
          id: "data",
          marker: "§ 03 · The data",
          title: "Training data.",
          paragraphs: [
            <>The model was trained on the <strong>National Health and Nutrition Examination Survey</strong> (NHANES) Continuous, a U.S. epidemiological study that has measured biomarkers and tracked mortality in nationally-representative samples since 1999. We used cycles 1999-2018 (n = 18,570 adults with complete panel and mortality follow-up through December 31, 2019).</>,
            <>For each biomarker, we fit a linear regression against chronological age. The resulting parameters (slope <em>k</em>, intercept <em>q</em>, residual SD <em>s</em>) describe how that biomarker changes through population aging. 19 of the 81 markers are sex-stratified when the difference is clinically relevant (creatinine, ferritin, hemoglobin, uric acid, GGT, ALT, testosterone, estradiol, among others).</>,
            <>IGF-1, not measured in the continuous cycles, was incorporated from NHANES III legacy data (1988-1994) after an inter-cycle continuity validation. Fructosamine, not measured in NHANES, is derived from HbA1c via the Cohen 2010 formula (Fructosamine µmol/L = 19.97 × HbA1c % − 39.4).</>,
          ],
        },
        {
          id: "calibration",
          marker: "§ 04 · Calibration",
          title: "Calibration for the Spanish population.",
          paragraphs: [
            <>A Spanish user with typical values for their age should <em>not</em> have a biological age skewed by differences between the U.S. and Spanish populations. To correct for this, we recalibrated each marker's population mean (intercept <em>q</em>) using published Spanish cohort data.</>,
            <>The formula is direct: <code>q_spain = (mean_spain / mean_NHANES) × q_NHANES</code>. The slope <em>k</em> and residual SD <em>s</em> are preserved, assuming biological aging proceeds at a similar rate — only the baseline level shifts between populations.</>,
            <>Spanish cohorts contributing to recalibration: <strong>PESA</strong> (Fernández-Friera 2015, n=4,066), <strong>ENRICA</strong> (Soriano-Maldonado 2016), <strong>Di@bet.es</strong> (Soriguer 2012), <strong>Hortega</strong>, <strong>PREDIMED</strong>, <strong>EPIRCE</strong>, <strong>La Rioja</strong>, and the <strong>SEQC</strong> (Spanish Society of Clinical Chemistry) database. In version 2.2.1 we successfully recalibrated 5 of the 14 base-panel markers with available primary Spanish data: Total Cholesterol, Triglycerides, hs-CRP, Vitamin D, and TSH. The remaining nine use NHANES references — an active target for future versions.</>,
            <>To validate the recalibration, each recalibrated value passes a plausibility check (range [0.25, 4.0] for log-distributed markers like hs-CRP that show real population differences {">"}2×, [0.5, 2.0] for others). Any marker outside these ranges is rejected and keeps its NHANES value.</>,
          ],
        },
        {
          id: "method",
          marker: "§ 05 · The method",
          title: "The Klemera-Doubal method.",
          paragraphs: [
            <>The Klemera-Doubal joint estimator (2006) combines <em>n</em> biomarkers into a single biological age estimate. Each biomarker <em>x<sub>i</sub></em> contributes per the formula:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA_E = Σ (x<sub>i</sub> − q<sub>i</sub>) · (k<sub>i</sub> / s<sub>i</sub>²) / Σ (k<sub>i</sub> / s<sub>i</sub>)²
            </div>,
            <>Each marker is weighted by the inverse of its residual variance (1/s²), so markers that predict age with less noise carry more weight. The result, <em>BA<sub>E</sub></em>, is the "raw" biological age before anchoring to chronological age.</>,
            <>The final step applies a Bayesian shrinkage toward chronological age (CA) using the population deviation:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA = (BA_E / s_BA² + CA / s_CA²) / (1 / s_BA² + 1 / s_CA²)
            </div>,
            <>This shrinkage prevents extreme values in any single marker from dominating the result — the final biological age weighs the joint estimator against the prior knowledge of chronological age.</>,
            <>Five markers in our base panel are log-transformed before fitting (hs-CRP, GGT, Triglycerides, Ferritin, Fructosamine) because their distributions are log-normal. The transformation is applied internally; input values are entered in their natural clinical scale (mg/L, µg/L, etc.).</>,
            <>The estimator requires a minimum panel of 8 of the 14 base markers, with Albumin and Creatinine (or Cystatin C) mandatory. Below that threshold, EVA does not report biological age — the uncertainty is too high to be clinically useful.</>,
          ],
        },
        {
          id: "validation",
          marker: "§ 06 · Validation",
          title: "Mortality validation.",
          paragraphs: [
            <>The definitive test of a biological age: does it predict mortality better than chronological age? We answered this by fitting a Cox proportional hazards model on the NHANES subset with complete follow-up, adjusted for chronological age and sex.</>,
            <>In version <strong>v2.2.1</strong> (May 2026, with corrected parameters for BUN and Fructosamine after a post-launch analysis):</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Hazard Ratio per SD</strong>: 1.41 [95% CI 1.32-1.50]. Each additional year of biological age acceleration predicts a 41% higher relative mortality risk.</li>
              <li><strong>C-statistic</strong>: 0.77. Above the excellence threshold (≥ 0.75) used in the bio-age literature.</li>
              <li><strong>Calibration slope</strong>: 1.02. Within the ideal range [0.9, 1.1], indicating predictions are neither inflated nor under-scaled.</li>
            </ul>,
            <>For context: chronological age alone in this same model has C-statistic 0.79 (a natural ceiling — mortality is strongly correlated with age). KDM adds incremental information that captures acceleration or deceleration relative to that trajectory.</>,
          ],
        },
        {
          id: "two-tiers",
          marker: "§ 07 · Two tiers",
          title: "Two levels of measurement.",
          paragraphs: [
            <>EVA reports two versions of the same number:</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Reference Biological Age (BA)</strong>: calculated with the 14 base-panel markers — the most validated, most universally available. This is the headline number on the dashboard.</li>
              <li><strong>Comprehensive Biological Age (BA<sub>comp</sub>)</strong>: calculated with the full panel (up to 81 trained markers) when the user uploads an extended profile. It has lower variance but lower clinical robustness.</li>
            </ul>,
            <>Both use the same mathematical method; they differ in marker breadth. The reference version is the one we validated against mortality and the one we recommend trusting for longitudinal decisions. The comprehensive version is an optional companion for users with extended panels.</>,
          ],
        },
        {
          id: "limits",
          marker: "§ 08 · Limits",
          title: "Limitations and transparency.",
          paragraphs: [
            <>KDM is a population model. This means its answers are less precise for individuals atypical of the training population. Three important limitations:</>,
            <ol className="my-4 ml-6 space-y-3 list-decimal text-[15px] text-[#4c463f]">
              <li><strong>NHANES is not a "healthy aging" cohort</strong>. It includes people with chronic conditions (CKD, diabetes, hypertension). The model learns the population trajectory including pathology — which can penalize athletic individuals with markers outside the population mean for lifestyle reasons (high protein intake elevates BUN; creatine supplementation elevates creatinine without affecting kidney function). In v2.2.1 we automatically adjust creatinine when the user reports supplementation.</li>
              <li><strong>Acute variations not captured</strong>. A blood test taken after intense exercise, in dehydration, or during an acute infection will produce values the model interprets as population aging, when they're transient variations. For reliable trends, repeat measurement under stable conditions.</li>
              <li><strong>Unmodeled medications</strong>. Statins (lower total cholesterol), levothyroxine (suppresses TSH), ACE inhibitors (elevate creatinine), and others can distort the calculation. Clinical interpretation should contextualize.</li>
            </ol>,
          ],
        },
        {
          id: "improvement",
          marker: "§ 09 · Continuous improvement",
          title: "How we keep improving it.",
          paragraphs: [
            <>The algorithm is version 2.2.1, not 1.0. It's under active development. Planned next iterations:</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Full Spanish recalibration</strong> for the 9 remaining base-panel markers, as we obtain primary cohort data.</li>
              <li><strong>Unwinsorized retraining</strong> applied across all markers (in v2.2.1 we applied it only to BUN and Fructosamine as an override).</li>
              <li><strong>Body composition adjustment model</strong> (muscle mass, % fat) using DEXA data where available.</li>
              <li><strong>Integration with wearables data</strong> (HRV, sleep, resting HR) for components of aging acceleration that the blood panel doesn't capture.</li>
            </ul>,
          ],
        },
      ];

  const refTitle = es ? "Referencias." : "References.";
  const refDownload = es ? "Descargar PDF" : "Download PDF";

  return (
    <main className="relative bg-[#fef8f2] text-[#1d1b18]">
      {/* ═══════════════════════════════════════════════════════════
       * Hero
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="large">
        <ChapterMarker>{es ? "Metodología completa" : "Full methodology"}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">
          {es ? "KDM v2.2.1 — el documento de referencia." : "KDM v2.2.1 — the reference document."}
        </SectionHeadline>
        <LedeItalic className="mt-8 max-w-3xl">
          {es
            ? "Cómo entrenamos el modelo, qué datos usamos, cómo lo validamos contra mortalidad y dónde sabemos que tiene límites."
            : "How we trained the model, what data we used, how we validated it against mortality, and where we know it has limits."}
        </LedeItalic>

        {/* Mini table of contents */}
        <nav className="mt-12 md:mt-16 border-t border-b border-[#1d1b18]/10 py-6">
          <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c] mb-4">
            {es ? "Contenido" : "Contents"}
          </p>
          <ol className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-[14px] text-[#4c463f]">
            {sections.map((s, i) => (
              <li key={s.id}>
                <a href={`#${s.id}`} className="hover:text-[#3a665e] transition-colors">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[#97472c]/60 mr-2">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {s.title}
                </a>
              </li>
            ))}
            <li>
              <a href="#refs" className="hover:text-[#3a665e] transition-colors">
                <span className="font-[family-name:var(--font-dm-mono)] text-[#97472c]/60 mr-2">10</span>
                {refTitle}
              </a>
            </li>
          </ol>
        </nav>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * Sections 1-9
       * ═══════════════════════════════════════════════════════════ */}
      {sections.map((s, i) => (
        <SectionShell
          key={s.id}
          tone={i % 2 === 0 ? "cream" : "cream-alt"}
          size="standard"
        >
          <div id={s.id}>
            <ChapterMarker>{s.marker}</ChapterMarker>
            <SectionHeadline className="mt-6 md:mt-8">{s.title}</SectionHeadline>
            <div className="mt-8 md:mt-10 space-y-6 max-w-3xl">
              {s.paragraphs.map((p, j) => (
                <BodyProse key={j}>{p}</BodyProse>
              ))}
            </div>
          </div>
        </SectionShell>
      ))}

      {/* ═══════════════════════════════════════════════════════════
       * § 10 — References
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="large">
        <div id="refs">
          <ChapterMarker>§ 10 · {refTitle}</ChapterMarker>
          <SectionHeadline className="mt-6 md:mt-8">{refTitle}</SectionHeadline>
          <ol className="mt-10 space-y-5 max-w-3xl">
            {refs.map((r) => (
              <li key={r.num} className="flex gap-4">
                <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#97472c] mt-1">
                  {String(r.num).padStart(2, "0")}
                </span>
                <p className="text-[14px] leading-relaxed text-[#4c463f]">
                  {r.text}{" "}
                  <a
                    href={r.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#3a665e] underline decoration-[#3a665e]/30 underline-offset-2 hover:decoration-[#3a665e]"
                  >
                    PubMed
                  </a>
                </p>
              </li>
            ))}
          </ol>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * Back-to-short-page CTA
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="standard">
        <div className="text-center max-w-2xl mx-auto">
          <SubHeadline>
            {es
              ? "¿Quieres ver tu propia edad biológica?"
              : "Want to see your own biological age?"}
          </SubHeadline>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <CTAButton variant="primary" href={`/${locale}/dashboard`}>
              {es ? "Ir al dashboard" : "Go to dashboard"}
            </CTAButton>
            <CTAButton variant="ghost" href={`/${locale}/metodologia`}>
              {es ? "Volver al resumen" : "Back to summary"}
            </CTAButton>
          </div>
        </div>
      </SectionShell>
    </main>
  );
}
