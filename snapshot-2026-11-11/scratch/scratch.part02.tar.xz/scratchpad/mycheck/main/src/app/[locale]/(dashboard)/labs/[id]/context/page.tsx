import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import { getUserProfile } from "@/lib/queries";
import { LabContextClient } from "./lab-context-client";

interface PageProps {
  params: Promise<{ locale: string; id: string }>;
}

/**
 * Standalone context-gate screen for a lab that arrived via the
 * webhook. The email the user receives points here. Same UX as the
 * inline gate in the upload flow — uses the shared
 * PatientContextGate component — but committing the gate triggers
 * the AI pipeline directly (no biomarker review step, those were
 * already extracted by the webhook).
 *
 * The page redirects away if the lab isn't actually waiting on
 * context — no point letting the user re-stamp a ready/processing lab.
 */
export default async function LabContextPage({ params }: PageProps) {
  const { locale, id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/${locale}/login`);

  const profile = await getUserProfile(user.id);
  if (!profile?.date_of_birth || !profile?.sex) {
    redirect(`/${locale}/onboarding`);
  }

  const { data: lab } = await supabase
    .from("lab_results")
    .select("id, user_id, status, collection_date, source")
    .eq("id", id)
    .eq("user_id", user.id)
    .maybeSingle();
  if (!lab) notFound();

  // If the lab is already past the gate, send the user to its result
  // detail page rather than letting them re-stamp context onto a lab
  // that is already being interpreted (or done).
  if (lab.status !== "pending_context") {
    redirect(`/${locale}/labs`);
  }

  const profileLocale = profile.locale === "es" ? "es" : "en";
  const userSex: "male" | "female" | null =
    profile.sex === "male" || profile.sex === "female" ? profile.sex : null;

  return (
    <LabContextClient
      locale={locale}
      profileLocale={profileLocale}
      userSex={userSex}
      labId={lab.id}
      collectionDate={lab.collection_date}
    />
  );
}
