import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { regenerateMasterForLab } from "@/lib/ai/regenerate-master";
import { getUserProfile } from "@/lib/queries";

// Two Gemini calls + 2×N DB writes on a panel-sized batch; the default
// 10s function budget isn't enough on larger panels.
export const maxDuration = 60;

/**
 * Re-materialize the user's latest lab in the tier currently set on
 * their profile. Used by the profile page's "Save tier" button when
 * the user changes their health_knowledge level.
 *
 * Architecture: applyTier reads the lab's master (optimizer-tier
 * source of truth) and rephrases it into the requested tier. The
 * clinical content is preserved exactly; only wording shifts. If the
 * master is missing (legacy lab uploaded before the master columns
 * existed) we lazily backfill it once from the persisted
 * biomarker_values, then apply the tier.
 *
 * The optimizer tier is a no-op rephrase (master copied verbatim into
 * the active columns), so users on that tier pay no AI cost on tier
 * changes once their master exists.
 *
 * The shared `regenerateMasterForLab` helper does the actual work and
 * is also used by /api/biomarker-values/[id] PATCH so the two regen
 * paths stay in lockstep.
 */
export async function POST() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: latestLab } = await supabase
    .from("lab_results")
    .select("id")
    .eq("user_id", user.id)
    .order("collection_date", { ascending: false, nullsFirst: false })
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!latestLab) {
    return NextResponse.json({ regenerated: false, reason: "no_lab" });
  }

  const profile = await getUserProfile(user.id);
  if (!profile) {
    return NextResponse.json({ error: "Profile missing" }, { status: 400 });
  }

  try {
    const result = await regenerateMasterForLab(latestLab.id, user.id, {
      profile,
      supabase,
    });
    if (!result.ok) {
      if (result.reason === "no_biomarkers") {
        return NextResponse.json({ regenerated: false, reason: "no_biomarkers" });
      }
      if (result.reason === "master_missing_after_regen") {
        return NextResponse.json(
          { error: "Master still missing after backfill" },
          { status: 500 },
        );
      }
      return NextResponse.json({ error: result.reason }, { status: 400 });
    }
    return NextResponse.json({
      regenerated: true,
      tier: result.tier,
      labResultId: result.labResultId,
    });
  } catch (e) {
    console.error("[regenerate-summary] failed:", e);
    const message = e instanceof Error ? e.message : "Regeneration failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
