"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { SectionTag } from "@/components/marketing/SectionTag";
import { createClient } from "@/lib/supabase/client";

export default function BlogPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error" | "duplicate">("idle");

  const t =
    locale === "es"
      ? {
          pageTag: "Blog",
          pageTitle: "El Blog de EVA Health",
          comingSoon: "Proximamente",
          pageDesc:
            "Estamos construyendo una biblioteca de educacion de salud basada en evidencia. Vuelve pronto.",
          signupTitle: "Se el primero en saber",
          signupDesc: "Dejanos tu email y te avisaremos cuando publiquemos nuestro primer articulo.",
          placeholder: "tu@email.com",
          cta: "Avisarme",
          sending: "Enviando...",
          sent: "Te avisaremos cuando lancemos el blog.",
          duplicate: "Ya estas suscrito. Te avisaremos pronto.",
          error: "Error. Intentalo de nuevo.",
        }
      : {
          pageTag: "Blog",
          pageTitle: "The EVA Health Blog",
          comingSoon: "Coming Soon",
          pageDesc:
            "We're building a library of evidence-based health education. Check back soon.",
          signupTitle: "Be the first to know",
          signupDesc: "Leave your email and we'll notify you when we publish our first article.",
          placeholder: "you@email.com",
          cta: "Notify Me",
          sending: "Sending...",
          sent: "We'll notify you when the blog launches.",
          duplicate: "You're already subscribed. We'll be in touch.",
          error: "Something went wrong. Try again.",
        };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return;
    setStatus("sending");

    try {
      const supabase = createClient();
      const { error } = await supabase
        .from("email_subscribers")
        .insert({ email, source: "blog", locale });

      if (error) {
        if (error.code === "23505") {
          setStatus("duplicate");
        } else {
          setStatus("error");
        }
        return;
      }

      setStatus("sent");
      setEmail("");
    } catch {
      setStatus("error");
    }
  }

  return (
    <>
      <section className="px-5 py-20 md:px-8 md:py-28">
        <div className="mx-auto max-w-3xl text-center">
          <ScrollReveal>
            <SectionTag text={t.pageTag} color="jade" />
            <span className="mt-6 inline-block rounded-full bg-[rgba(196,147,50,0.12)] px-4 py-1.5 font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[1.5px] text-[#c49332]">
              {t.comingSoon}
            </span>
            <h1 className="mt-5 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[52px]">
              {t.pageTitle}
            </h1>
            <p className="mx-auto mt-5 max-w-xl font-[family-name:var(--font-inter)] text-[16px] leading-relaxed text-[#4c463f]">
              {t.pageDesc}
            </p>
          </ScrollReveal>
        </div>
      </section>

      <section className="bg-[#f8f3ed] px-5 py-20 md:px-8 md:py-28">
        <div className="mx-auto max-w-md text-center">
          <ScrollReveal>
            <h2 className="font-[family-name:var(--font-manrope)] text-[24px] font-extrabold text-[#1d1b18]">
              {t.signupTitle}
            </h2>
            <p className="mt-3 font-[family-name:var(--font-inter)] text-[15px] text-[#4c463f]">
              {t.signupDesc}
            </p>
          </ScrollReveal>

          <ScrollReveal delay={0.1}>
            <form onSubmit={handleSubmit} className="mt-6 flex gap-3">
              <input
                type="email"
                required
                placeholder={t.placeholder}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 rounded-[100px] border border-[#e7e2dc] bg-white px-5 py-3.5 font-[family-name:var(--font-inter)] text-[14px] text-[#1d1b18] outline-none transition-colors placeholder:text-[#8a7f76] focus:border-[#97472c] focus:ring-1 focus:ring-[#97472c]"
              />
              <button
                type="submit"
                disabled={status === "sending"}
                className="shrink-0 rounded-[100px] bg-gradient-to-br from-[#97472c] to-[#d97b5c] px-6 py-3.5 font-[family-name:var(--font-manrope)] text-[14px] font-bold text-white shadow-[0_12px_40px_rgba(151,71,44,0.2)] transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_48px_rgba(151,71,44,0.3)] disabled:opacity-60"
              >
                {status === "sending" ? t.sending : t.cta}
              </button>
            </form>

            {status === "sent" && (
              <p className="mt-4 font-[family-name:var(--font-inter)] text-[14px] text-[#3a665e]">
                {t.sent}
              </p>
            )}
            {status === "duplicate" && (
              <p className="mt-4 font-[family-name:var(--font-inter)] text-[14px] text-[#c49332]">
                {t.duplicate}
              </p>
            )}
            {status === "error" && (
              <p className="mt-4 font-[family-name:var(--font-inter)] text-[14px] text-[#b04040]">
                {t.error}
              </p>
            )}
          </ScrollReveal>
        </div>
      </section>
    </>
  );
}
