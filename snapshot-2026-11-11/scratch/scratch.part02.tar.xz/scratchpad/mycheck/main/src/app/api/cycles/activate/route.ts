import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { enqueueOmlForCycle } from "@/lib/lab-bridge/outbox";
import { opsAlert } from "@/lib/ops-alert";

/**
 * POST /api/cycles/activate — the patient registers the REAL extraction.
 *
 * Hybrid timing (ECH, 2026-09-03): the initial OML already went out at ship
 * with an estimated date; this queues the SAME order again with the real
 * date/time (ECH overwrites and processes with the latest data). Only the
 * cycle's owner can activate; allowed while the kit is out (shipped,
 * order_sent, order_accepted). Status is not changed here — the bridge and
 * the lab drive it from now on; the timestamp is what the timeline shows.
 */
const Body = z.object({
  cycleId: z.string().uuid(),
  /** ISO datetime of the blood draw, as entered by the patient. */
  extractionAt: z.string().datetime({ offset: true }),
});

const ACTIVATABLE = ["shipped", "order_sent", "order_accepted", "activated"];

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request", details: parsed.error.issues }, { status: 400 });
  }
  const { cycleId, extractionAt } = parsed.data;
  const extraction = new Date(extractionAt);
  const now = new Date();
  if (extraction.getTime() > now.getTime() + 60 * 60 * 1000) {
    return NextResponse.json({ error: "Extraction time cannot be in the future" }, { status: 400 });
  }
  if (extraction.getTime() < now.getTime() - 30 * 86_400_000) {
    return NextResponse.json({ error: "Extraction time is too far in the past" }, { status: 400 });
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: "Not configured" }, { status: 503 });

  const { data: cycle } = await admin
    .from("test_cycles")
    .select("id, user_id, status")
    .eq("id", cycleId)
    .single();
  if (!cycle || (cycle as { user_id: string }).user_id !== user.id) {
    return NextResponse.json({ error: "Cycle not found" }, { status: 404 });
  }
  const status = (cycle as { status: string }).status;
  if (!ACTIVATABLE.includes(status)) {
    return NextResponse.json({ error: `Cycle cannot be activated from status '${status}'` }, { status: 409 });
  }

  const { error: upErr } = await admin
    .from("test_cycles")
    .update({ extraction_confirmed_at: extraction.toISOString(), updated_at: now.toISOString() })
    .eq("id", cycleId)
    .eq("status", status);
  if (upErr) return NextResponse.json({ error: upErr.message }, { status: 500 });

  try {
    const queued = await enqueueOmlForCycle(admin, cycleId, "update", now);
    return NextResponse.json({ ok: true, extractionAt: extraction.toISOString(), queuedMessage: queued.messageControlId });
  } catch (e) {
    // The extraction is saved; the order update failed to build (e.g. panel
    // codes not configured). Ops must look — the lab will process with the
    // estimated date otherwise.
    opsAlert("cycles.activate", "extraction saved but OML update could not be queued", { cycleId, error: e instanceof Error ? e.message : String(e) });
    return NextResponse.json({ ok: true, extractionAt: extraction.toISOString(), queuedMessage: null, warning: "order update not queued" });
  }
}
