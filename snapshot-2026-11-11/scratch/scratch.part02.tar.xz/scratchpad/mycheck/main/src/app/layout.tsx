import "./globals.css";

/**
 * Root layout — intentionally a pass-through.
 *
 * Because every user-facing route lives under `app/[locale]/`, the
 * `<html>`/`<body>` shell is rendered by `app/[locale]/layout.tsx`, where the
 * active locale is available so `<html lang={locale}>` is correct for both `es`
 * and `en` (A11Y-001 / SEO-005). This is the documented next-intl pattern and is
 * endorsed by the fork's i18n guide (`node_modules/next/dist/docs/01-app/02-guides/internationalization.md`,
 * "The root layout can also be nested in the new folder"). Keep `globals.css`
 * imported here so styles load for any non-localized special routes too.
 */
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return children;
}
