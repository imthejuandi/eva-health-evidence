"use client";

import { useParams } from "next/navigation";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { SectionTag } from "@/components/marketing/SectionTag";

export default function CookiePolicyPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";

  if (locale === "es") return <CookiesES />;
  return <CookiesEN />;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-10">
      <h2 className="font-[family-name:var(--font-manrope)] text-[20px] font-extrabold text-[#1d1b18]">
        {title}
      </h2>
      <div className="mt-4 space-y-4 font-[family-name:var(--font-inter)] text-[15px] leading-relaxed text-[#4c463f]">
        {children}
      </div>
    </div>
  );
}

function CookiesEN() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-3xl">
        <ScrollReveal>
          <SectionTag text="Legal" />
          <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[48px]">
            Cookie Policy
          </h1>
          <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] font-medium uppercase tracking-[1.5px] text-[#8a7f76]">
            Last updated: March 2026
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <Section title="Our Approach to Cookies">
            <p>
              EVA Health is committed to your privacy. We use minimal cookies, only what is technically necessary for the site to function. We do not use advertising cookies or third-party tracking cookies of any kind.
            </p>
          </Section>

          <Section title="Essential Cookies">
            <p>
              These cookies are strictly necessary for the website to function and cannot be disabled.
            </p>
            <div className="overflow-hidden rounded-[16px] border border-[#e7e2dc]">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-[#e7e2dc] bg-[#f8f3ed]">
                    <th className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76]">Cookie</th>
                    <th className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76]">Purpose</th>
                    <th className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76]">Duration</th>
                  </tr>
                </thead>
                <tbody className="font-[family-name:var(--font-inter)] text-[13px]">
                  <tr className="border-b border-[#f8f3ed]">
                    <td className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[12px] text-[#1d1b18]">sb-*</td>
                    <td className="px-4 py-3 text-[#4c463f]">Supabase authentication session</td>
                    <td className="px-4 py-3 text-[#8a7f76]">Session</td>
                  </tr>
                  <tr className="border-b border-[#f8f3ed]">
                    <td className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[12px] text-[#1d1b18]">eva-cookie-consent</td>
                    <td className="px-4 py-3 text-[#4c463f]">Remembers your cookie preference</td>
                    <td className="px-4 py-3 text-[#8a7f76]">1 year</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Section>

          <Section title="Analytics: No Cookies">
            <p>
              We use <strong>Plausible Analytics</strong> for understanding how visitors use our website. Plausible is a privacy-friendly analytics tool that is fundamentally different from traditional analytics:
            </p>
            <ul className="ml-5 list-disc space-y-2">
              <li>Plausible does <strong>not use cookies</strong> at all</li>
              <li>It does not track individual users across sessions</li>
              <li>It does not collect personal data</li>
              <li>All data is aggregated: we see page view counts and traffic sources, not individual behaviour</li>
              <li>It is fully compliant with GDPR, CCPA, and PECR without requiring cookie consent</li>
            </ul>
            <p>
              This means you can browse EVA Health knowing that no analytics cookies are placed on your device and no personal data is collected for analytics purposes.
            </p>
          </Section>

          <Section title="Third-Party Advertising Cookies">
            <p>
              <strong>We do not use any third-party advertising cookies.</strong> EVA Health does not serve ads, does not participate in ad networks, and does not allow any third party to place advertising or tracking cookies on our website.
            </p>
          </Section>

          <Section title="How to Manage Cookies">
            <p>
              Since we only use essential cookies required for authentication, disabling them may prevent you from logging into your account. You can manage cookies through your browser settings:
            </p>
            <ul className="ml-5 list-disc space-y-2">
              <li><strong>Chrome:</strong> Settings → Privacy and Security → Cookies</li>
              <li><strong>Firefox:</strong> Settings → Privacy & Security → Cookies</li>
              <li><strong>Safari:</strong> Preferences → Privacy → Cookies</li>
              <li><strong>Edge:</strong> Settings → Privacy → Cookies</li>
            </ul>
          </Section>

          <Section title="Contact">
            <p>
              Questions about our cookie practices? Contact us at hello@evahealth.es.
            </p>
          </Section>
        </ScrollReveal>
      </div>
    </section>
  );
}

function CookiesES() {
  return (
    <section className="px-5 py-20 md:px-8 md:py-28">
      <div className="mx-auto max-w-3xl">
        <ScrollReveal>
          <SectionTag text="Legal" />
          <h1 className="mt-4 font-[family-name:var(--font-cormorant)] text-[36px] font-bold leading-[1.1] tracking-[-1px] text-[#1d1b18] md:text-[48px]">
            Politica de Cookies
          </h1>
          <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] font-medium uppercase tracking-[1.5px] text-[#8a7f76]">
            Ultima actualizacion: Marzo 2026
          </p>
        </ScrollReveal>

        <ScrollReveal delay={0.1}>
          <Section title="Nuestro Enfoque sobre Cookies">
            <p>
              EVA Health esta comprometida con tu privacidad. Usamos cookies minimas, solo lo que es tecnicamente necesario para que el sitio funcione. No usamos cookies publicitarias ni cookies de seguimiento de terceros de ningun tipo.
            </p>
          </Section>

          <Section title="Cookies Esenciales">
            <p>
              Estas cookies son estrictamente necesarias para que el sitio web funcione y no se pueden desactivar.
            </p>
            <div className="overflow-hidden rounded-[16px] border border-[#e7e2dc]">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-[#e7e2dc] bg-[#f8f3ed]">
                    <th className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76]">Cookie</th>
                    <th className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76]">Proposito</th>
                    <th className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76]">Duracion</th>
                  </tr>
                </thead>
                <tbody className="font-[family-name:var(--font-inter)] text-[13px]">
                  <tr className="border-b border-[#f8f3ed]">
                    <td className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[12px] text-[#1d1b18]">sb-*</td>
                    <td className="px-4 py-3 text-[#4c463f]">Sesion de autenticacion de Supabase</td>
                    <td className="px-4 py-3 text-[#8a7f76]">Sesion</td>
                  </tr>
                  <tr className="border-b border-[#f8f3ed]">
                    <td className="px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[12px] text-[#1d1b18]">eva-cookie-consent</td>
                    <td className="px-4 py-3 text-[#4c463f]">Recuerda tu preferencia de cookies</td>
                    <td className="px-4 py-3 text-[#8a7f76]">1 año</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </Section>

          <Section title="Analitica: Sin Cookies">
            <p>
              Utilizamos <strong>Plausible Analytics</strong> para entender como los visitantes usan nuestro sitio web. Plausible es una herramienta de analitica respetuosa con la privacidad que es fundamentalmente diferente de la analitica tradicional:
            </p>
            <ul className="ml-5 list-disc space-y-2">
              <li>Plausible <strong>no usa cookies</strong> en absoluto</li>
              <li>No rastrea usuarios individuales entre sesiones</li>
              <li>No recopila datos personales</li>
              <li>Todos los datos son agregados: vemos conteos de vistas de pagina y fuentes de trafico, no comportamiento individual</li>
              <li>Es totalmente compatible con RGPD, CCPA y PECR sin requerir consentimiento de cookies</li>
            </ul>
            <p>
              Esto significa que puedes navegar por EVA Health sabiendo que no se colocan cookies de analitica en tu dispositivo y no se recopilan datos personales con fines analiticos.
            </p>
          </Section>

          <Section title="Cookies Publicitarias de Terceros">
            <p>
              <strong>No usamos ninguna cookie publicitaria de terceros.</strong> EVA Health no muestra anuncios, no participa en redes publicitarias y no permite que ningun tercero coloque cookies publicitarias o de seguimiento en nuestro sitio web.
            </p>
          </Section>

          <Section title="Como Gestionar las Cookies">
            <p>
              Dado que solo usamos cookies esenciales requeridas para la autenticacion, desactivarlas puede impedirte iniciar sesion en tu cuenta. Puedes gestionar las cookies a traves de la configuracion de tu navegador:
            </p>
            <ul className="ml-5 list-disc space-y-2">
              <li><strong>Chrome:</strong> Configuracion → Privacidad y Seguridad → Cookies</li>
              <li><strong>Firefox:</strong> Configuracion → Privacidad y Seguridad → Cookies</li>
              <li><strong>Safari:</strong> Preferencias → Privacidad → Cookies</li>
              <li><strong>Edge:</strong> Configuracion → Privacidad → Cookies</li>
            </ul>
          </Section>

          <Section title="Contacto">
            <p>
              ¿Preguntas sobre nuestras practicas de cookies? Contactanos en hello@evahealth.es.
            </p>
          </Section>
        </ScrollReveal>
      </div>
    </section>
  );
}
