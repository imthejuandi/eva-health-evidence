import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { processLabResults } from "@/lib/biomarkers/process-results";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";

const BodySchema = z.object({
  userId: z.string().uuid(),
  biomarkers: z
    .array(
      z.object({
        name: z.string(),
        value: z.number().finite(),
        unit: z.string(),
        biomarkerKey: z.string(),
      }),
    )
    .min(1),
  locale: z.string().default("en"),
});

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    // Admin acts on another user's rows → use the service-role client (authz is
    // already enforced above) so RLS doesn't block the cross-user writes.
    const supabase = createAdminClient();
    if (!supabase) return NextResponse.json({ error: "Server misconfigured" }, { status: 503 });

    const parsed = BodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }
    const { userId, biomarkers, locale } = parsed.data;

    // 1. Create lab_results record
    const { data: labResult, error: labErr } = await supabase.from("lab_results").insert({
      user_id: userId,
      source: "lab_partner",
      panel_type: "base",
      status: "processing",
      collection_date: new Date().toISOString().split("T")[0],
      strengths: [],
      needs_attention: [],
    }).select("id").single();

    if (labErr || !labResult) {
      return NextResponse.json({ error: "Failed to create lab result" }, { status: 500 });
    }

    // 2. Process through pipeline
    const result = await processLabResults(
      userId,
      labResult.id,
      biomarkers.map((b) => ({ name: b.name, value: b.value, unit: b.unit })),
      supabase,
    );

    // 3. Generate AI summary
    const profile = await getUserProfile(userId, supabase);
    const wearable = await getWearableData(userId, 30, supabase);
    if (profile) {
      await generateSummary(userId, labResult.id, result.processed, wearable.length > 0 ? wearable : null, profile, supabase);
    }

    // 4. Update status to ready
    await supabase.from("lab_results").update({ status: "ready" }).eq("id", labResult.id);

    // 5. Send results-ready email
    if (profile) {
      const targetEmail = profile.email ?? "";
      const firstName = profile.full_name?.split(" ")[0] ?? "";
      sendEmail(targetEmail, "results-ready", {
        firstName,
        biomarkerCount: result.processed.length,
        biologicalAge: result.biologicalAge?.biologicalAge ?? null,
        baDelta: result.biologicalAge?.delta ?? null,
        longevityScore: result.biologicalAge?.longevityScore ?? null,
        locale: profile.locale ?? locale,
      }, profile.locale ?? locale).catch(() => {});
    }

    await logAdminAction({
      actor: admin,
      action: "enter_results",
      targetUserId: userId,
      targetId: labResult.id,
      detail: { processed: result.processed.length },
    });

    return NextResponse.json({
      labResultId: labResult.id,
      processed: result.processed.length,
      biologicalAge: result.biologicalAge,
    });
  } catch (e) {
    console.error("[admin/enter-results]", e);
    return NextResponse.json({ error: "Processing failed" }, { status: 500 });
  }
}
