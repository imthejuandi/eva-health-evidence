import { CheckoutResumeClient } from "./checkout-resume-client";

interface CheckoutResumePageProps {
  params: Promise<{ locale: string }>;
}

/**
 * Landing target after a user completes signup with a checkout intent.
 * The signup page sets emailRedirectTo to .../callback?next=/${locale}/
 * checkout-resume?intent={plan}, the auth callback exchanges the code
 * and redirects here, and the client component below auto-fires the
 * /api/stripe/checkout call so the user lands on Stripe's hosted
 * checkout without having to click Subscribe a second time.
 */
export default async function CheckoutResumePage({
  params,
}: CheckoutResumePageProps) {
  const { locale } = await params;
  return <CheckoutResumeClient locale={locale} />;
}
