export type PanelPricingMode = "included" | "addon" | "quote";

export interface PanelDefinition {
  id: string;
  name: string;
  name_es: string;
  icon: string;
  location: "at_home" | "in_lab";
  location_es: string;
  price: string;
  price_es: string;
  description: string;
  description_es: string;
  included_in_subscription: boolean;
  biomarker_count?: number;
  /**
   * How this panel is priced on the pricing page.
   * - "included": part of the base subscription, no extra cost
   * - "addon": extra monthly/quarterly fee shown via `addonPriceEur`
   * - "quote": user submits inline form to request a quote
   *
   * Flip this value (and `addonPriceEur`) to change per-panel pricing
   * without touching any component code.
   */
  pricingMode?: PanelPricingMode;
  /** Extra EUR added per quarter when `pricingMode === "addon"`. */
  addonPriceEur?: number;
}

export const panels: Record<string, PanelDefinition> = {
  base: {
    id: "base",
    name: "Base Panel",
    name_es: "Panel Base",
    icon: "🩸",
    location: "at_home",
    location_es: "En casa",
    price: "€99/trimestre incluido",
    price_es: "€99/trimestre incluido",
    description:
      "Essential biomarkers for metabolic, cardiovascular, and nutritional health. Included in your subscription.",
    description_es:
      "Biomarcadores esenciales para salud metabólica, cardiovascular y nutricional. Incluido en tu suscripción.",
    included_in_subscription: true,
    biomarker_count: 13,
    pricingMode: "included",
  },
  hormonal: {
    id: "hormonal",
    name: "Hormone Panel",
    name_es: "Panel Hormonal",
    icon: "⚡",
    location: "at_home",
    location_es: "En casa",
    price: "Consúltanos",
    price_es: "Consúltanos",
    description:
      "Comprehensive hormonal profile including sex hormones, cortisol, and DHEA-S.",
    description_es:
      "Perfil hormonal completo incluyendo hormonas sexuales, cortisol y DHEA-S.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
  cardiovascular: {
    id: "cardiovascular",
    name: "Cardiovascular Panel",
    name_es: "Panel Cardiovascular",
    icon: "❤️",
    location: "at_home",
    location_es: "En casa",
    price: "Consúltanos",
    price_es: "Consúltanos",
    description:
      "Advanced lipid subfractions, ApoB, Lp(a), and inflammatory markers for heart health.",
    description_es:
      "Subfracciones lipídicas avanzadas, ApoB, Lp(a) y marcadores inflamatorios para salud cardíaca.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
  thyroid: {
    id: "thyroid",
    name: "Thyroid Panel",
    name_es: "Panel Tiroideo",
    icon: "🦋",
    location: "at_home",
    location_es: "En casa",
    price: "Consúltanos",
    price_es: "Consúltanos",
    description:
      "Full thyroid function including TSH, Free T3, Free T4, and thyroid antibodies.",
    description_es:
      "Función tiroidea completa incluyendo TSH, T3 libre, T4 libre y anticuerpos tiroideos.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
  nutrients: {
    id: "nutrients",
    name: "Nutrient Panel",
    name_es: "Panel Nutricional",
    icon: "🥗",
    location: "at_home",
    location_es: "En casa",
    price: "Consúltanos",
    price_es: "Consúltanos",
    description:
      "Key vitamins and minerals: B12, folate, iron, zinc, magnesium, and more.",
    description_es:
      "Vitaminas y minerales clave: B12, folato, hierro, zinc, magnesio y más.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
  inflammatory: {
    id: "inflammatory",
    name: "Inflammatory Panel",
    name_es: "Panel Inflamatorio",
    icon: "🔥",
    location: "at_home",
    location_es: "En casa",
    price: "Consúltanos",
    price_es: "Consúltanos",
    description:
      "Inflammation and immune markers including hs-CRP, IL-6, TNF-α, and homocysteine.",
    description_es:
      "Marcadores de inflamación e inmunidad incluyendo hs-PCR, IL-6, TNF-α y homocisteína.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
  liver: {
    id: "liver",
    name: "Liver Panel",
    name_es: "Panel Hepático",
    icon: "🫁",
    location: "at_home",
    location_es: "En casa",
    price: "Consúltanos",
    price_es: "Consúltanos",
    description:
      "Liver function markers: ALT, AST, GGT, bilirubin, and albumin.",
    description_es:
      "Marcadores de función hepática: ALT, AST, GGT, bilirrubina y albúmina.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
  full: {
    id: "full",
    name: "Full Lab Panel",
    name_es: "Panel Completo de Laboratorio",
    icon: "🔬",
    location: "in_lab",
    location_es: "En laboratorio",
    price: "€499",
    price_es: "€499",
    description:
      "Comprehensive in-lab panel covering all biomarker categories for a complete health picture.",
    description_es:
      "Panel completo en laboratorio que cubre todas las categorías de biomarcadores para una imagen completa de tu salud.",
    included_in_subscription: false,
    pricingMode: "quote",
  },
};
