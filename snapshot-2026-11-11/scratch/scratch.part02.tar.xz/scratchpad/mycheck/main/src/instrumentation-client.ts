/**
 * Browser observability bootstrap (OPS-001).
 *
 * Env-gated on NEXT_PUBLIC_SENTRY_DSN (a DSN is publishable, not a secret) —
 * absent, this file is a no-op. NEVER send health data to Sentry; beforeSend
 * strips known health keys defensively. Session replay stays disabled except
 * a small on-error sample, mirroring the original commented config.
 */
import * as Sentry from "@sentry/nextjs";

const dsn = process.env.NEXT_PUBLIC_SENTRY_DSN;

if (dsn) {
  Sentry.init({
    dsn,
    tracesSampleRate: 0.1,
    replaysSessionSampleRate: 0,
    replaysOnErrorSampleRate: 0.1,
    beforeSend(event) {
      if (event.extra) {
        delete event.extra.biomarkers;
        delete event.extra.labResults;
        delete event.extra.wearableData;
        delete event.extra.chatMessages;
        delete event.extra.healthData;
      }
      return event;
    },
  });
}
