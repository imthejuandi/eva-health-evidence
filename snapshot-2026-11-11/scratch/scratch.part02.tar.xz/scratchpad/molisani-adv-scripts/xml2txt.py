import sys, re
import xml.etree.ElementTree as ET
src, dst = sys.argv[1], sys.argv[2]
data = open(src, 'rb').read().decode('utf-8', 'replace')
# strip DOCTYPE
data = re.sub(r'<!DOCTYPE[^>]*>', '', data, flags=re.S)
root = ET.fromstring(data)
out = []
def walk(el, depth=0):
    tag = el.tag if isinstance(el.tag, str) else ''
    block = tag in ('p','title','th','td','tr','caption','label','article-title','abstract','sec','table-wrap','fig','ref','list-item','disp-formula')
    txt = ''.join(el.itertext()) if tag in ('p','title','th','td','article-title','label','caption','ref','disp-formula') else None
    if txt is not None:
        out.append(('  '*depth) + '[' + tag + '] ' + re.sub(r'\s+', ' ', txt).strip())
        return
    for ch in el:
        walk(ch, depth+1 if block else depth)
walk(root)
open(dst, 'w').write('\n'.join(out))
