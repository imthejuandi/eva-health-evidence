import sys, zipfile, re
src, dst = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(src)
names = z.namelist()
print('\n'.join(names[:80]))
xml = z.read('word/document.xml').decode('utf-8','replace')
# paragraphs
paras = re.findall(r'<w:p[ >].*?</w:p>', xml, flags=re.S)
out=[]
for p in paras:
    # mark table cells boundaries roughly
    texts = re.findall(r'<w:t[^>]*>(.*?)</w:t>', p, flags=re.S)
    t = ''.join(texts)
    t = t.replace('&amp;','&').replace('&lt;','<').replace('&gt;','>').replace('&quot;','"').replace('&apos;',"'")
    if t.strip():
        out.append(t)
open(dst,'w').write('\n'.join(out))
print('paragraphs:', len(out))
