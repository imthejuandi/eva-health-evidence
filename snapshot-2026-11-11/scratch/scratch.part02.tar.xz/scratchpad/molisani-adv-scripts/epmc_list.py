import json,sys
d=json.load(open(sys.argv[1]))
print('hitCount', d.get('hitCount'))
for r in d['resultList']['result']:
    print(r.get('source'), r.get('id'), r.get('pmcid'), r.get('pubYear'), (r.get('journalTitle') or '')[:30], '|', (r.get('title') or '')[:150], '|', (r.get('authorString') or '')[:60])
