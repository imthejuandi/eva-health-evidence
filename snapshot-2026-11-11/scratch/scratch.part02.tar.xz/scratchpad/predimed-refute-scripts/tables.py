import sys, re
import xml.etree.ElementTree as ET
root = ET.parse(sys.argv[1]).getroot()
def t(el): return re.sub(r'\s+', ' ', ''.join(el.itertext())).strip()
for tw in root.iter('table-wrap'):
    lab = tw.find('label'); cap = tw.find('caption')
    print('\n=== TABLE', t(lab) if lab is not None else '', '|', t(cap) if cap is not None else '')
    for tr in tw.iter('tr'):
        print('  | ' + ' | '.join(t(c) for c in tr if c.tag in ('td','th')))
    foot = tw.find('table-wrap-foot')
    if foot is not None: print('  FOOT:', t(foot))
for fig in root.iter('fig'):
    lab = fig.find('label'); cap = fig.find('caption')
    print('\n=== FIG', t(lab) if lab is not None else '', '|', t(cap) if cap is not None else '')
# reference 12, 13, 20, 22
for ref in root.iter('ref'):
    rid = ref.get('id')
    if rid in ('R12','R13','R19','R20','R21','R22','CR12','B12','bib12','R10'):
        print('REF', rid, t(ref))
