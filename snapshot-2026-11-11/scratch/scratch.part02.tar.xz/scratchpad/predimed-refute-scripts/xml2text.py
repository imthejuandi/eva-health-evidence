import sys, re
import xml.etree.ElementTree as ET
path = sys.argv[1]
tree = ET.parse(path)
root = tree.getroot()
def text_of(el):
    return re.sub(r'\s+', ' ', ''.join(el.itertext())).strip()
# print title, abstract, affiliations, then all sections with titles
for tag in ['ArticleTitle','article-title']:
    for el in root.iter(tag):
        print('TITLE:', text_of(el)); break
mode = sys.argv[2] if len(sys.argv) > 2 else 'all'
if mode == 'pubmed':
    for el in root.iter('AbstractText'):
        lab = el.get('Label')
        print(f'[{lab}]', text_of(el))
    for el in root.iter('Affiliation'):
        print('AFF:', text_of(el))
    for el in root.iter('Journal'):
        print('JOURNAL:', text_of(el))
    for el in root.iter('ArticleId'):
        print('ID:', el.get('IdType'), el.text)
    for el in root.iter('PublicationType'):
        print('PUBTYPE:', el.text)
    for el in root.iter('GrantID'):
        print('GRANT:', el.text)
else:
    # PMC: walk front/body/back
    for el in root.iter('aff'):
        print('AFF:', text_of(el))
    for el in root.iter('abstract'):
        print('ABSTRACT:', text_of(el))
    body = root.find('.//body')
    def walk(sec, depth=0):
        for child in sec:
            if child.tag == 'sec':
                t = child.find('title')
                print('\n' + '#'*(depth+1), text_of(t) if t is not None else '')
                walk(child, depth+1)
            elif child.tag == 'p':
                print(text_of(child))
            elif child.tag in ('table-wrap','fig'):
                lab = child.find('label'); cap = child.find('caption')
                print(f'[{child.tag}]', text_of(lab) if lab is not None else '', text_of(cap) if cap is not None else '')
                if child.tag == 'table-wrap':
                    for tr in child.iter('tr'):
                        print('  | ' + ' | '.join(text_of(c) for c in tr if c.tag in ('td','th')))
    if body is not None:
        walk(body)
    back = root.find('.//back')
    if back is not None:
        for sec in back.iter('sec'):
            t = sec.find('title')
            print('\nBACK-SEC:', text_of(t) if t is not None else '')
            for p in sec.findall('p'):
                print(text_of(p))
        for fn in back.iter('fn'):
            print('FN:', text_of(fn))
        for sm in root.iter('supplementary-material'):
            print('SUPP:', text_of(sm), [ (k,v) for k,v in sm.attrib.items()])
            for m in sm.iter('media'):
                print('  MEDIA:', m.attrib)
