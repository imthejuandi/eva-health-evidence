# Methodology claims for counsel

Stream E, 2026-09-25. For review before Gate 2 (Thu 1 Oct 2026). Audit reference: CONSISTENCY.md, C8.

> **Applied on 29 October 2026, on the CEO's instruction, before counsel's review.** Rows 1 to 16, the version labels
> and the Spanish-means count were put on both pages. Where this file left a choice to counsel, the more cautious
> wording was used: "prediction" and "validated" are replaced by "tested against recorded deaths", and the unrecorded
> interval, calibration slope and age-only C-statistic are removed. The marker library shows the count: it holds
> Spanish means for 9 of the 14 markers. The pages also say the Spanish adjustment has not been tested against
> mortality. The science page's claim that Klemera-Doubal "remains the most rigorously tested way" is replaced by "one of
> the most widely used and cited ways" (`docs/biomarker-evidence/bioage-model-selection/DECISION.md`, section 4).
>
> **Corrected again on 29 October 2026, after an independent review.** Some applied text from the table below is
> superseded on the pages:
> - Rows 3, 6 and 10: 1.39 and 1.65 are per SD of biological age, from a Cox model that also contains age and sex
>   (`scripts/comprehensive_ba_mortality_validation.py`, `BA_z`). They are not per SD of acceleration.
> - Rows 4, 6 and 11: 0.77 is no longer shown as the model's own discrimination. The pages give the gain over age and
>   sex instead: about 0.009, with age and sex alone at 0.7712 (`ml/biological-age/MODEL-CARD.md`, section 10).
> - Spanish wording: "comprobada" (verified) is replaced by "evaluada" or "se evaluó".
> - Sources of the Spanish means: the main PESA paper for three markers (PMID 25882487, not 26088847); a 400-person
>   PESA subsample for four (creatinine, uric acid, GGT, hs-CRP), where the per-sex means used for creatinine, uric
>   acid and GGT are not in the cited files; Díaz-López et al. 2021 for vitamin D (PMID 33866793); Alonso et al. 2025
>   for TSH (PMID 41419981). The pages no longer call them population means. The marker library's citations were
>   corrected to match.
> - Rows 7 and 14 to 16: the pages now say the reference model takes up to 14 markers and the 13-test Base Panel
>   supplies 10, and that the dashboard shows the Comprehensive value, averaged over recent labs.
> - The pages now list known limits and say that a new model will replace this one once it passes its validation
>   and release conditions.
> - The dashboard badge "Calibrado para población española" now reads "Ajustado en parte con medias españolas
>   publicadas".
>
> Counsel can still review the new text. The pages, not the table below, hold the current wording.

The two methodology pages quote three different validation results for the same model. These are performance
claims. Nothing on these pages was changed (true when this file was written on 25 September 2026; see the notes
above). This file lists every performance claim and a proposed replacement from the deployed model, v2.2.2.

Pages (line numbers as at commit 691de67; this stream does not touch these files):
- **M** = `src/app/[locale]/(marketing)/metodologia/page.tsx`
- **C** = `src/app/[locale]/(marketing)/metodologia/completa/page.tsx`

## Where the v2.2.2 numbers come from

| Figure | Value | Where found |
|---|---|---|
| Deployed version | v2.2.2 | `src/lib/biomarkers/biological-age-kdm.ts` line 43 ("v2.2.2 (full Path B, this commit)") and line 55 ("← deployed") |
| HR per SD, Reference | 1.391, shown as 1.39 | same file, line 55; rounded on line 65 |
| HR per SD, Comprehensive | 1.654, shown as 1.65 | same file, line 55; rounded on line 65 |
| C-statistic, Reference | 0.77 | same file, line 12 ("C-stat 0.770"); `src/lib/biomarkers/data/path_b_overrides.json` line 10 |
| C-statistic, Comprehensive | 0.775 | `path_b_overrides.json` line 11 only |
| Population | 18,570 NHANES adults, 1999–2018, follow-up to 2019 | `biological-age-kdm.ts` lines 7, 11 and 50 |

Checks:
- Line 12 of `biological-age-kdm.ts` pairs C 0.770 with HR 1.373 [1.29, 1.46], and line 13 gives a calibration
  slope of 1.027. Those are the original v2.2 results (the same as `model_meta.mortality_validation` in
  `src/lib/biomarkers/data/marker_library_v2_2.json`, lines 69–75).
- The v2.2.2 table (lines 50–55) gives HR per SD only. The v2.2.2 C-statistics are in `path_b_overrides.json`
  (`_meta.validation_summary`), which the module imports (line 79). Both give 0.77 for the Reference panel.
- The repo stores no 95% interval, no calibration slope and no age-only C-statistic for v2.2.2.

## Read first: in-sample versus held-out

- 1.39, 1.65 and 0.77 are in-sample: the model was fitted and tested on the same NHANES adults.
  `scripts/honest_holdout_validation.py` labels them "in-sample (what we reported)" (lines 279–284).
- Line 11 of `biological-age-kdm.ts` calls the v2.2 run "held-out follow-up". The holdout script (lines 5–7)
  says the reported figures used the same subjects as the fit.
- The C-statistic belongs to a Cox model that includes age, sex and biological age together
  (`scripts/comprehensive_ba_mortality_validation.py`, lines 188–191). It is not the discrimination of
  biological age on its own.
- Page M shows held-out figures instead (5-fold cross-validation): Reference HR 1.29, Comprehensive HR 1.49
  and C 0.78. Their only record is the message of commit bb148a2 (26 May 2026): "Reference HR/SD = 1.29 ± 0.07,
  C-stat = 0.77; Comprehensive HR/SD = 1.49 ± 0.10, C-stat = 0.78". The page's interval [1.20, 1.40] is not in
  that record.
- Page C shows 1.41 [1.32–1.50]. The same commit calls 1.41 in-sample. It matches v2.2.1 (1.406, `biological-age-kdm.ts` line 54).
- The proposals below use the v2.2.2 figures, as asked. They must then say the figures come from the data the
  model was built on. Do not call 1.39 "out-of-sample".
- The alternative is to keep held-out figures. A statistician would re-run them and store the output first.

## Claims and proposed replacements

| # | Where (EN / ES) | Current text | Proposed replacement (v2.2.2) | Note |
|---|---|---|---|---|
| 1 | M:103 / M:42 | EN: "A mortality prediction validated in 18,570 people — with an uncertainty margin we acknowledge openly."<br>ES: "Es una predicción de mortalidad validada en 18.570 personas — con un margen de incertidumbre que reconocemos abiertamente." | EN: "Tested against mortality in 18,570 NHANES adults."<br>ES: "Comprobada frente a la mortalidad en 18.570 adultos de NHANES." | 18,570 matches. "Prediction" of a person's mortality is a prognostic claim: counsel decides. Without an interval (row 3), drop "uncertainty margin". |
| 2 | M:107 / M:47 | EN: "The algorithm is validated against real mortality using out-of-sample cross-validation (5-fold), so the numbers below reflect performance on held-out data, not the training set."<br>ES: "El algoritmo se valida contra mortalidad real, usando un protocolo de validación cruzada (5-fold) que separa los datos de entrenamiento de los de validación." | EN: "The algorithm was tested against recorded deaths in NHANES, the same data it was built on."<br>ES: "El algoritmo se comprobó frente a las muertes registradas en NHANES, los mismos datos con los que se construyó." | Needed if 1.39 replaces 1.29. Keep the current text only with held-out figures. |
| 3 | M:109–112 / M:49–52 | EN: "1.29 per standard deviation … Each standard deviation of biological age acceleration corresponds to a 29% higher relative mortality risk. Out-of-sample (5-fold CV); 95% CI [1.20, 1.40]."<br>ES: "1.29 por desviación estándar … Cada desviación estándar de aceleración de edad biológica corresponde a un 29% más de riesgo relativo de mortalidad. Validación fuera de muestra (5-fold CV); intervalo de confianza 95% [1.20, 1.40]." | EN: "1.39 per standard deviation … Each standard deviation of biological age acceleration goes with about 39% higher relative mortality risk (Reference panel, NHANES)."<br>ES: "1,39 por desviación estándar … Cada desviación estándar de aceleración de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (panel de referencia, NHANES)." | No v2.2.2 interval in the repo: drop it or re-run. The ES page writes "1.29" and "18.570"; use a decimal comma. |
| 4 | M:114–117 / M:54–57 | EN: "0.77 … When comparing two people, the model correctly identifies which one has higher risk 77% of the time. The Comprehensive version (extended panel) rises to 0.78 with HR/SD 1.49."<br>ES: "0.77 … Cuando comparamos dos personas, el modelo identifica correctamente cuál tiene mayor riesgo el 77% del tiempo. La versión Comprehensive (panel extendido) sube a 0.78 con HR/SD 1.49." | EN: "0.77 … When comparing two people, the model correctly identifies which one has higher risk 77% of the time. The model also includes age and sex. The Comprehensive version (extended panel): C-statistic 0.775, HR per SD 1.65."<br>ES: "0,77 … Cuando comparamos dos personas, el modelo identifica correctamente cuál tiene mayor riesgo el 77% del tiempo. El modelo incluye también la edad y el sexo. La versión Comprehensive (panel extendido): C-statistic 0,775, HR por DE 1,65." | 0.77 is unchanged. The 77% describes the whole model, not biological age alone. |
| 5 | M:119–122 / M:59–62 | EN: "18,570 NHANES adults … Trained on the U.S. National Health and Nutrition Examination Survey (1999-2018), with mortality follow-up through 2019. Recalibrated for Spain on 11 of 14 base-panel markers."<br>ES: "18.570 adultos NHANES … Entrenado en datos del National Health and Nutrition Examination Survey (1999-2018), con seguimiento de mortalidad hasta 2019. Recalibrado para España con 11 de 14 marcadores del panel base." | Keep 18,570, 1999–2018 and 2019. Replace "11 of 14" with the confirmed count (see "Other claims"). | The population figures match `biological-age-kdm.ts`. |
| 6 | C:196 / C:80 | EN: "The algorithm predicts mortality with a hazard ratio of 1.41 per standard deviation [95% CI 1.32-1.50] and a C-statistic of 0.77 — exceeding the excellence threshold (≥ 0.75) in risk discrimination. The model parameters were updated in May 2026 (v2.2.1) after a post-launch analysis identified a weighting bias in two markers; the new version is more discriminative than the original."<br>ES: "El algoritmo predice mortalidad con un hazard ratio de 1,41 por desviación estándar [IC 95% 1,32-1,50] y un C-statistic de 0,77 — superando el umbral de excelencia (≥ 0,75) en discriminación de riesgo. Los parámetros del modelo se actualizaron en mayo de 2026 (v2.2.1) tras un análisis post-implementación que identificó un sesgo de ponderación en dos marcadores; la nueva versión es más discriminativa que la original." | EN: "In the NHANES data it was built on, the hazard ratio is 1.39 per standard deviation (1.65 with the Comprehensive panel) and the C-statistic is 0.77. In May 2026 (v2.2.2) every marker was refitted on unwinsorised NHANES values."<br>ES: "En los datos de NHANES con los que se construyó, el hazard ratio es de 1,39 por desviación estándar (1,65 con el panel completo) y el C-statistic de 0,77. En mayo de 2026 (v2.2.2) se reajustaron todos los marcadores con valores de NHANES sin winsorizar." | No v2.2.2 interval: drop it. "≥ 0.75" is EVA's own acceptance rule (`biological-age-kdm.ts` line 57), not a literature threshold. Drop "more discriminative": v2.2.2 (1.391) is above v2.2 (1.367) but below v2.2.1 (1.406) (lines 53–55). |
| 7 | C:206 / C:90 | EN: "EVA computes your biological age by combining 14 key blood biomarkers into a single statistical estimator, validated against real mortality. It's not a generic wellness score. It's a prediction."<br>ES: "EVA calcula tu edad biológica combinando 14 biomarcadores sanguíneos clave en un único estimador estadístico, validado contra mortalidad real. No es un score de bienestar genérico. Es una predicción." | EN: "… into a single statistical estimator, tested against recorded deaths in NHANES."<br>ES: "… en un único estimador estadístico, comprobado frente a las muertes registradas en NHANES." | No figure. "It's a prediction": counsel decides. The dashboard shows the Comprehensive value (up to 81 markers) when it can (`src/lib/biomarkers/rolling-average-ba.ts` lines 264–276). |
| 8 | C:254 / C:138 | EN: "We answered this by fitting a Cox proportional hazards model on the NHANES subset with complete follow-up, adjusted for chronological age and sex."<br>ES: "Lo respondimos ajustando un modelo de Cox de riesgos proporcionales en el subconjunto NHANES con seguimiento completo, ajustando por edad cronológica y sexo." | Keep. Add EN: "These are the same adults the model was built on."<br>ES: "Son los mismos adultos con los que se construyó el modelo." | Matches the validation script (line 188). |
| 9 | C:255 / C:139 | EN: "In version v2.2.1 (May 2026, with corrected parameters for BUN and Fructosamine after a post-launch analysis):"<br>ES: "En la versión v2.2.1 (mayo 2026, con parámetros corregidos para BUN y Fructosamine tras un análisis post-implementación):" | EN: "In version v2.2.2 (May 2026, every marker refitted on unwinsorised NHANES values):"<br>ES: "En la versión v2.2.2 (mayo 2026, todos los marcadores reajustados con valores de NHANES sin winsorizar):" | `biological-age-kdm.ts` lines 43–48. |
| 10 | C:257 / C:141 | EN: "Hazard Ratio per SD: 1.41 [95% CI 1.32-1.50]. Each additional year of biological age acceleration predicts a 41% higher relative mortality risk."<br>ES: "Hazard Ratio por SD: 1,41 [IC 95% 1,32-1,50]. Cada año adicional de aceleración de edad biológica predice un 41% más de riesgo relativo de mortalidad." | EN: "Hazard ratio per SD: 1.39 (Reference) and 1.65 (Comprehensive). Each standard deviation of biological age acceleration goes with about 39% higher relative mortality risk (Reference)."<br>ES: "Hazard ratio por DE: 1,39 (referencia) y 1,65 (completa). Cada desviación estándar de aceleración de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (referencia)." | The current text says "per year"; the figure is per standard deviation. No v2.2.2 interval. |
| 11 | C:258 / C:142 | EN: "C-statistic: 0.77. Above the excellence threshold (≥ 0.75) used in the bio-age literature."<br>ES: "C-statistic: 0,77. Por encima del umbral de excelencia (≥ 0,75) usado en la literatura de bioage." | EN: "C-statistic: 0.77 (Reference) and 0.775 (Comprehensive), for a model that also includes age and sex."<br>ES: "C-statistic: 0,77 (referencia) y 0,775 (completa), en un modelo que incluye también la edad y el sexo." | "≥ 0.75" is EVA's own acceptance rule (line 57). No literature source in the repo. |
| 12 | C:259 / C:143 | EN: "Calibration slope: 1.02. Within the ideal range [0.9, 1.1], indicating predictions are neither inflated nor under-scaled."<br>ES: "Pendiente de calibración: 1,02. Dentro del rango ideal [0,9, 1,1], indicando que las predicciones son ni infladas ni infradimensionadas." | Remove, or re-run for v2.2.2 and store the result. | The repo has a slope only for v2.2: 1.027 (`biological-age-kdm.ts` line 13). |
| 13 | C:261 / C:145 | EN: "For context: chronological age alone in this same model has C-statistic 0.79 (a natural ceiling — mortality is strongly correlated with age). KDM adds incremental information that captures acceleration or deceleration relative to that trajectory."<br>ES: "Para contexto: la edad cronológica sola en este mismo modelo tiene C-statistic 0,79 (un techo natural — la mortalidad está fuertemente correlacionada con la edad). El KDM añade información incremental que captura aceleración o desaceleración respecto a esa trayectoria." | Remove, or source it. | No 0.79 in the repo. As written, age alone (0.79) beats the model with biological age (0.77). That contradicts "adds incremental information". |
| 14 | C:271 / C:155 | EN: "Reference Biological Age (BA): calculated with the 14 base-panel markers — the most validated, most universally available. This is the headline number on the dashboard."<br>ES: "Edad biológica de referencia (BA): calculada con los 14 marcadores del panel base — los más validados, más universalmente disponibles. Es el número principal mostrado en el dashboard." | EN: "… This is the number on the dashboard when the Comprehensive value cannot be calculated."<br>ES: "… Es el número del dashboard cuando no se puede calcular la versión completa." | The dashboard shows Comprehensive first (`rolling-average-ba.ts` lines 264–276). "Most validated": both tiers were validated in v2.2.2. |
| 15 | C:272 / C:156 | EN: "Comprehensive Biological Age (BA comp): calculated with the full panel (up to 81 trained markers) when the user uploads an extended profile. It has lower variance but lower clinical robustness."<br>ES: "Edad biológica completa (BA comprehensive): calculada con el panel completo (hasta 81 marcadores entrenados) cuando el usuario sube un perfil extenso. Tiene menor varianza pero menor robustez clínica." | EN: "… Validated the same way: HR per SD 1.65, C-statistic 0.775."<br>ES: "… Validada de la misma forma: HR por DE 1,65, C-statistic 0,775." | "Lower clinical robustness" has no source in the repo. |
| 16 | C:274 / C:158 | EN: "The reference version is the one we validated against mortality and the one we recommend trusting for longitudinal decisions."<br>ES: "La versión de referencia es la que validamos contra mortalidad y la que recomendamos confiar para decisiones longitudinales." | EN: "Both versions were tested against mortality in NHANES (HR per SD 1.39 and 1.65)."<br>ES: "Ambas versiones se comprobaron frente a la mortalidad en NHANES (HR por DE 1,39 y 1,65)." | v2.2.2 validated both tiers (`biological-age-kdm.ts` lines 50–58). The recommendation conflicts with the dashboard, which shows Comprehensive first. |

## Version labels on the same pages

- "v2.2.1" appears at C:195 / C:79 (summary), C:255 / C:139 (row 9), C:284 / C:168 (limitations),
  C:295 / C:179 (roadmap) and C:317 (page title, both languages). Proposed: "v2.2.2".
- C:298 / C:182 lists "unwinsorized retraining across all markers" as future work. v2.2.2 already did it
  (`biological-age-kdm.ts` lines 43–48). Remove it from the roadmap.
- The dashboard labels the value "KDM_v2.2.3" internally; users do not see it (`dashboard-client.tsx` on this
  branch, line 410). Commit bb148a2 calls v2.2.3 the Spanish recalibration fix on top of v2.2.2. Choose one
  version name for the pages.

## Other claims that disagree

- Spanish recalibration. M:62 / M:122 and M:69 / M:128 say "11 of 14" base-panel markers. C:110 / C:226 say
  "5 of the 14", and C:181 / C:297 say "the 9 remaining". The marker library holds Spanish values for 9 of the
  14: 5 for both sexes (total cholesterol, triglycerides, hs-CRP, vitamin D, TSH) and 4 by sex (creatinine, HDL,
  uric acid, GGT). Engineering should confirm the number before a page states it.
- The dashboard shows an average of recent labs (`rolling-average-ba.ts`). The validation used one panel per
  person. The dashboard links to page M ("How is this calculated?").
- Outside these pages: the science page says Klemera-Doubal "remains the most rigorously tested way to estimate
  biological age" and "predicts long-term health more reliably than simpler approaches"
  (`src/app/[locale]/(marketing)/science/page.tsx` on this branch, `bioAgeCred`, ES line 218, EN line 335). No
  source in the repo.
