"use client";

/**
 * /metodologia/completa — deep methodology document for KDM v2.2.2.
 *
 * Linked from /metodologia (the short trust-signal page) via "Ver
 * metodología completa". Covers the 10 sections required by Workstream D
 * of plan `glowing-mixing-cray.md`:
 *
 *   1. Resumen ejecutivo
 *   2. ¿Qué es la edad biológica?
 *   3. Datos de entrenamiento
 *   4. Ajuste con medias españolas
 *   5. El método Klemera-Doubal
 *   6. Evaluación frente a la mortalidad
 *   7. Dos niveles de medición
 *   8. Limitaciones y transparencia
 *   9. ¿Qué viene después?
 *   10. Referencias
 *
 * Total target ~2,300 words rendered. Spanish + English via the `es` flag.
 *
 * Citations link out to PubMed. On 29 October 2026 each PMID was checked
 * against its PubMed record (title, authors, journal), not only that the
 * link loads: a link that loads can still point to the wrong paper.
 */

import { useParams } from "next/navigation";
import {
  ChapterMarker,
  SectionHeadline,
  SubHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
} from "@/components/marketing/editorial";
import { CTAButton } from "@/components/marketing/CTAButton";

interface Reference {
  num: number;
  text: string;
  url: string;
}

interface Section {
  id: string;
  marker: string;
  title: string;
  paragraphs: React.ReactNode[];
}

export default function MetodologiaCompletaPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const es = locale === "es";

  const refs: Reference[] = [
    { num: 1, text: "Klemera P, Doubal S. A new approach to the concept and computation of biological age. Mech Ageing Dev. 2006;127(3):240-248.", url: "https://pubmed.ncbi.nlm.nih.gov/16318865/" },
    { num: 2, text: "Levine ME. Modeling the rate of senescence: can estimated biological age predict mortality more accurately than chronological age? J Gerontol A Biol Sci Med Sci. 2013;68(6):667-674.", url: "https://pubmed.ncbi.nlm.nih.gov/23213031/" },
    { num: 3, text: "Levine ME, Lu AT, Quach A, et al. An epigenetic biomarker of aging for lifespan and healthspan. Aging (Albany NY). 2018;10(4):573-591.", url: "https://pubmed.ncbi.nlm.nih.gov/29676998/" },
    { num: 4, text: "Kwon D, Belsky DW. A toolkit for quantification of biological age from blood chemistry and organ function test data: BioAge. GeroScience. 2021;43(6):2795-2808.", url: "https://pubmed.ncbi.nlm.nih.gov/34725754/" },
    { num: 5, text: "Fernández-Friera L, Peñalvo JL, Fernández-Ortiz A, et al. Prevalence, vascular distribution, and multiterritorial extent of subclinical atherosclerosis in a middle-aged cohort: the PESA (Progression of Early Subclinical Atherosclerosis) study. Circulation. 2015;131(24):2104-2113.", url: "https://pubmed.ncbi.nlm.nih.gov/25882487/" },
    { num: 6, text: "Díaz-López A, Paz-Graniel I, Alonso-Sanz R, et al. Vitamin D deficiency in primary health care users at risk in Spain. Nutr Hosp. 2021;38(5):1058-1067.", url: "https://pubmed.ncbi.nlm.nih.gov/33866793/" },
    { num: 7, text: "Alonso SP, Colomo N, Lago-Sampedro A, et al. Population-based national incidence of thyroid dysfunction in Spain. Sci Rep. 2025;16(1):3230.", url: "https://pubmed.ncbi.nlm.nih.gov/41419981/" },
    { num: 8, text: "Kreider RB, Kalman DS, Antonio J, et al. International Society of Sports Nutrition position stand: safety and efficacy of creatine supplementation in exercise, sport, and medicine. J Int Soc Sports Nutr. 2017;14:18.", url: "https://pubmed.ncbi.nlm.nih.gov/28615996/" },
    { num: 9, text: "Stevens LA, Schmid CH, Greene T, et al. Comparative performance of the CKD Epidemiology Collaboration (CKD-EPI) and the Modification of Diet in Renal Disease (MDRD) Study equations for estimating GFR levels above 60 mL/min/1.73 m². Am J Kidney Dis. 2010;56(3):486-495.", url: "https://pubmed.ncbi.nlm.nih.gov/20557989/" },
    { num: 10, text: "Inker LA, Eneanya ND, Coresh J, et al. New creatinine- and cystatin C-based equations to estimate GFR without race. N Engl J Med. 2021;385(19):1737-1749.", url: "https://pubmed.ncbi.nlm.nih.gov/34554658/" },
  ];

  const sections: Section[] = es
    ? [
        {
          id: "resumen",
          marker: "§ 01 · Resumen",
          title: "Resumen ejecutivo.",
          paragraphs: [
            <>EVA Health calcula tu edad biológica con el algoritmo <strong>KDM v2.2.2</strong>, una implementación del método Klemera-Doubal (2006) construida con datos del estudio NHANES de Estados Unidos (1999-2018) y evaluada frente a la mortalidad en 18.570 adultos. En 9 de sus 14 marcadores de referencia usa medias publicadas de estudios españoles, sobre todo del estudio PESA.</>,
            <>En los datos de NHANES con los que se construyó, el hazard ratio es de <strong>1,39 por desviación estándar de edad biológica</strong> (1,65 en la versión completa), en un modelo que también incluye la edad y el sexo. La edad y el sexo solos ya dan un C-statistic de 0,77, y esta edad biológica lo sube unas <strong>0,009</strong>: una ganancia pequeña (sección 06). En mayo de 2026 (v2.2.2) se reajustaron con valores de NHANES sin winsorizar 80 de los 81 marcadores entrenados.</>,
            <>EVA está evaluando un modelo nuevo, entrenado con datos de mortalidad, que sustituirá a este cuando supere su validación y las condiciones para su lanzamiento (sección 09).</>,
          ],
        },
        {
          id: "que-es",
          marker: "§ 02 · El concepto",
          title: "¿Qué es la edad biológica?",
          paragraphs: [
            <>Tu edad cronológica cuenta los años desde tu nacimiento. Tu edad biológica describe el estado funcional acumulado de tus órganos y sistemas — un resumen cuantitativo de cuánto te has gastado, no cuánto has vivido.</>,
            <>Dos personas con la misma fecha de nacimiento pueden tener edades biológicas que difieren en una década o más. La diferencia refleja factores acumulativos: nutrición, ejercicio, sueño, estrés crónico, exposiciones ambientales, predisposición genética y suerte. La edad biológica es <em>modificable</em>; la cronológica no.</>,
            <>EVA calcula tu edad biológica combinando marcadores sanguíneos en un único estimador estadístico, evaluado frente a las muertes registradas en NHANES. El modelo de referencia admite hasta 14 marcadores; el Panel Base de EVA, de 13 pruebas, aporta 10 de ellos. No es un score de bienestar genérico.</>,
          ],
        },
        {
          id: "datos",
          marker: "§ 03 · Los datos",
          title: "Datos de entrenamiento.",
          paragraphs: [
            <>El modelo se entrenó en el <strong>National Health and Nutrition Examination Survey</strong> (NHANES) Continuous, un estudio epidemiológico estadounidense que ha medido biomarcadores y rastreado mortalidad en muestras representativas de la población desde 1999. Usamos los ciclos 1999-2018. La evaluación frente a la mortalidad incluyó a 18.570 adultos con al menos 8 de los 14 marcadores de referencia, entre ellos albúmina y creatinina, y con seguimiento de mortalidad hasta el 31 de diciembre de 2019.</>,
            <>Para cada biomarcador, ajustamos una regresión lineal contra la edad cronológica. Los parámetros resultantes (pendiente <em>k</em>, intercepto <em>q</em>, desviación estándar residual <em>s</em>) describen cómo cambia ese biomarcador a lo largo del envejecimiento poblacional. 16 de los 81 marcadores entrenados tienen parámetros distintos para hombres y mujeres (creatinina, ferritina, hemoglobina, ácido úrico, GGT, ALT, testosterona, estradiol, entre otros).</>,
            <>El IGF-1, no medido en los ciclos continuos, se incorporó del legado NHANES III (1988-1994). La fructosamina, que NHANES no mide, se deriva de la HbA1c con la fórmula Fructosamina (µmol/L) = 19,97 × HbA1c (%) − 39,4. Como el modelo se entrenó con esa fructosamina derivada, desde el 25 de septiembre de 2026 una fructosamina medida en laboratorio no se usa por defecto.</>,
          ],
        },
        {
          id: "calibracion",
          marker: "§ 04 · El ajuste español",
          title: "Ajuste con medias españolas.",
          paragraphs: [
            <>Un usuario español con valores típicos para su edad <em>no</em> debería tener una edad biológica desplazada por las diferencias entre la población estadounidense y la española. Para reducir ese efecto, sustituimos el intercepto <em>q</em> de 9 de los 14 marcadores de referencia usando medias publicadas de estudios españoles.</>,
            <>Para los marcadores en escala lineal, <code>q_spain = (mean_spain / mean_NHANES) × q_NHANES</code>. Para los que el modelo usa en escala logarítmica (triglicéridos, PCR-hs, GGT y TSH), <code>q_spain = q_NHANES + ln(mean_spain / mean_NHANES)</code>. Aquí q_NHANES es el intercepto original de NHANES, anterior al reajuste de mayo de 2026. La pendiente <em>k</em> y la desviación residual <em>s</em> no cambian: suponemos que los marcadores cambian con la edad al mismo ritmo en ambas poblaciones y que solo cambia el nivel de partida.</>,
            <>Así, 9 de los 14 marcadores de referencia usan medias españolas: cinco iguales para ambos sexos (colesterol total, triglicéridos, PCR-hs, vitamina D y TSH) y cuatro distintas por sexo (creatinina, HDL, ácido úrico y GGT). Los otros cinco (albúmina, BUN, fosfatasa alcalina, ferritina y fructosamina) usan las medias de NHANES. La versión completa aplica el mismo ajuste a hasta ocho marcadores más, como el colesterol LDL, la hemoglobina o la testosterona total.</>,
            <>Las fuentes son resúmenes publicados de grupos concretos, no datos individuales ni muestras de toda la población española. Para el colesterol total, el HDL y los triglicéridos, el estudio <strong>PESA</strong> (Fernández-Friera 2015), con empleados asintomáticos de 40 a 54 años de un banco de Madrid. Para la creatinina, el ácido úrico, la GGT y la PCR-hs, una submuestra de 400 participantes de PESA. Ninguna de las fuentes citadas da valores por sexo para la creatinina, el ácido úrico y la GGT, así que no hemos podido verificar las medias por sexo que usamos para estos tres marcadores. Para la vitamina D, un estudio de Díaz-López y colaboradores (2021) en usuarios de atención primaria de La Rioja con riesgo de déficit. Para la TSH, un estudio nacional de Alonso y colaboradores (2025) en 1.629 adultos con función tiroidea normal. El ajuste no se ha evaluado todavía frente a la mortalidad en la población española.</>,
          ],
        },
        {
          id: "metodo",
          marker: "§ 05 · El método",
          title: "El método Klemera-Doubal.",
          paragraphs: [
            <>El estimador conjunto de Klemera-Doubal (2006) combina <em>n</em> biomarcadores en una única estimación de edad biológica. Cada biomarcador <em>x<sub>i</sub></em> contribuye según la fórmula:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA_E = Σ (x<sub>i</sub> − q<sub>i</sub>) · (k<sub>i</sub> / s<sub>i</sub>²) / Σ (k<sub>i</sub> / s<sub>i</sub>)²
            </div>,
            <>Cada marcador aporta su propia estimación de la edad, (<em>x</em> − <em>q</em>) / <em>k</em>, y pesa en proporción a (<em>k</em> / <em>s</em>)². Así pesan más los marcadores que cambian mucho con la edad en relación con su dispersión residual. El resultado, <em>BA<sub>E</sub></em>, es la edad biológica “cruda” antes del anclaje a la edad cronológica.</>,
            <>El paso final aplica una contracción bayesiana hacia la edad cronológica (CA) usando la desviación de la población:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA = (BA_E / s_BA² + CA / s_CA²) / (1 / s_BA² + 1 / s_CA²)
            </div>,
            <>Esta contracción acerca el resultado a la edad cronológica: la edad biológica final pondera el estimador conjunto frente a la edad cronológica. Cuantos menos marcadores, más pesa la edad cronológica.</>,
            <>Seis de los 14 marcadores de referencia se transforman logarítmicamente antes del ajuste (PCR-hs, GGT, triglicéridos, ferritina, TSH y fructosamina) porque sus distribuciones son log-normales. La transformación se aplica internamente; los valores de entrada se introducen en su escala clínica natural (mg/L, µg/L, etc.).</>,
            <>El estimador requiere al menos 8 de los 14 marcadores de referencia, con albúmina y creatinina (o cistatina C) obligatorias. Por debajo de ese umbral, EVA no calcula la edad biológica.</>,
          ],
        },
        {
          id: "validacion",
          marker: "§ 06 · La evaluación",
          title: "Evaluación frente a la mortalidad.",
          paragraphs: [
            <>La pregunta clave para una edad biológica es si aporta información sobre la mortalidad más allá de la edad cronológica. Para estudiarlo ajustamos un modelo de Cox de riesgos proporcionales en el subconjunto de NHANES con seguimiento de mortalidad, con la edad biológica, la edad cronológica y el sexo. Son los mismos adultos con los que se construyó el modelo.</>,
            <>En la versión <strong>v2.2.2</strong> (mayo de 2026, con 80 de los 81 marcadores entrenados reajustados con valores de NHANES sin winsorizar):</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Hazard ratio por desviación estándar de edad biológica</strong>: 1,39 (referencia) y 1,65 (completa), en un modelo que también incluye la edad y el sexo. A igual edad y sexo, cada desviación estándar de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (referencia).</li>
              <li><strong>C-statistic</strong>: 0,77 (referencia) y 0,775 (completa). Es el valor de todo el modelo, con la edad y el sexo, no el de la edad biológica sola.</li>
            </ul>,
            <>La respuesta es que aporta algo, pero poco. En una evaluación interna posterior, con datos de NHANES de 2007 a 2014, la edad y el sexo solos dieron un C-statistic de 0,77. Añadir esta edad biológica, calculada con los marcadores del Panel Base de EVA, lo subió unas <strong>0,009</strong>. Esos años forman parte de los datos con los que se construyó el modelo.</>,
          ],
        },
        {
          id: "dos-niveles",
          marker: "§ 07 · El doble nivel",
          title: "Dos niveles de medición.",
          paragraphs: [
            <>El modelo tiene dos versiones:</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Edad biológica de referencia (BA)</strong>: usa solo los 14 marcadores de referencia; con el Panel Base de EVA, 10 de ellos. Se guarda con cada analítica y es la cifra que aparece en la página de cada analítica.</li>
              <li><strong>Edad biológica completa (BA<sub>comprehensive</sub>)</strong>: usa todos los marcadores que el modelo admite, hasta 81 marcadores entrenados; con el Panel Base, 12 de sus 13 pruebas. Es la cifra del dashboard. Se evaluó de la misma forma: HR por desviación estándar de edad biológica 1,65, C-statistic 0,775.</li>
            </ul>,
            <>Ambas usan el mismo método matemático y los mismos requisitos mínimos; difieren en cuántos marcadores usan. Por eso, siempre que se puede calcular la versión de referencia, también se puede calcular la completa. El dashboard la calcula sobre la media de tus analíticas de los últimos 6 meses; si tienes menos de dos, de los últimos 12; y si no, sobre tu última analítica. La evaluación frente a la mortalidad, en cambio, usó una sola analítica por persona, en los mismos datos con los que se construyó el modelo.</>,
          ],
        },
        {
          id: "limitaciones",
          marker: "§ 08 · Las limitaciones",
          title: "Limitaciones y transparencia.",
          paragraphs: [
            <>KDM es un modelo poblacional. Esto significa que sus respuestas son menos precisas para individuos atípicos respecto a la población de entrenamiento. Estas son sus limitaciones principales:</>,
            <ol className="my-4 ml-6 space-y-3 list-decimal text-[15px] text-[#4c463f]">
              <li><strong>Gran parte del resultado es la edad cronológica</strong>. Con el Panel Base, para un hombre típico de 45 años, la edad cronológica pesa un 78% en la cifra del dashboard y un 60% en la versión de referencia.</li>
              <li><strong>Varía entre analíticas</strong>. En las simulaciones de EVA, dos extracciones separadas unas semanas, sin cambios reales, variaron unos 2 años en la cifra del dashboard y unos 4 en la versión de referencia (una desviación estándar). Un cambio pequeño entre dos resultados puede deberse solo a esa variación.</li>
              <li><strong>Puede dar una edad mayor que la cronológica</strong>. En una evaluación interna con datos de NHANES, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica.</li>
              <li><strong>No se ha evaluado en España</strong>. Todas las cifras de mortalidad proceden de NHANES, en Estados Unidos, y de los mismos datos con los que se construyó el modelo. El ajuste con medias españolas no se ha evaluado frente a la mortalidad.</li>
              <li><strong>NHANES no es una cohorte de "envejecimiento saludable"</strong>. Incluye personas con enfermedades crónicas (ERC, diabetes, hipertensión). El modelo aprende la trayectoria poblacional incluyendo la patología — lo que puede penalizar a personas atléticas con marcadores fuera del promedio por razones de estilo de vida (alta ingesta de proteína eleva BUN; suplementación de creatina eleva creatinina sin afectar función renal). Ajustamos automáticamente la creatinina cuando el usuario reporta suplementación.</li>
              <li><strong>Variaciones agudas no capturadas</strong>. Una analítica realizada tras un entrenamiento intenso, en deshidratación, o con una infección aguda dará valores que el modelo interpretará como envejecimiento poblacional, cuando son variaciones transitorias. Para tendencias fiables, repite la medición en condiciones estables.</li>
              <li><strong>Medicamentos no modelados</strong>. Estatinas (bajan colesterol total), levotiroxina (suprime TSH), ACE inhibidores (elevan creatinina) y otros pueden distorsionar el cálculo. La interpretación clínica debe contextualizar.</li>
            </ol>,
          ],
        },
        {
          id: "mejora",
          marker: "§ 09 · Lo que viene",
          title: "¿Qué viene después?",
          paragraphs: [
            <>EVA está evaluando un modelo nuevo, entrenado con datos de mortalidad, que sustituirá a este cuando supere su validación y las condiciones para su lanzamiento. Hasta entonces, este documento describe el modelo que calcula tu edad biológica hoy.</>,
          ],
        },
      ]
    : [
        {
          id: "summary",
          marker: "§ 01 · Summary",
          title: "Executive summary.",
          paragraphs: [
            <>EVA Health calculates your biological age with the <strong>KDM v2.2.2</strong> algorithm, an implementation of the Klemera-Doubal method (2006) built on data from the U.S. NHANES study (1999-2018) and tested against recorded deaths in 18,570 adults. For 9 of its 14 reference markers it uses published means from Spanish studies, mostly from the PESA study.</>,
            <>In the NHANES data it was built on, the hazard ratio is <strong>1.39 per standard deviation of biological age</strong> (1.65 in the Comprehensive version), in a model that also includes age and sex. Age and sex alone already give a C-statistic of 0.77, and this biological age raises it by about <strong>0.009</strong>: a small gain (section 06). In May 2026 (v2.2.2), 80 of the 81 trained markers were refitted on unwinsorized NHANES values.</>,
            <>EVA is evaluating a new model, trained on mortality data, that will replace this one once it passes its validation and release conditions (section 09).</>,
          ],
        },
        {
          id: "concept",
          marker: "§ 02 · The concept",
          title: "What is biological age?",
          paragraphs: [
            <>Your chronological age counts the years since you were born. Your biological age describes the cumulative functional state of your organs and systems — a quantitative summary of how much you've worn, not how much you've lived.</>,
            <>Two people with the same birthdate can have biological ages that differ by a decade or more. The difference reflects cumulative factors: nutrition, exercise, sleep, chronic stress, environmental exposures, genetic predisposition, and luck. Biological age is <em>modifiable</em>; chronological isn't.</>,
            <>EVA computes your biological age by combining blood markers into a single statistical estimator, tested against recorded deaths in NHANES. The reference model accepts up to 14 markers; the 13-test EVA Base Panel supplies 10 of them. It is not a generic wellness score.</>,
          ],
        },
        {
          id: "data",
          marker: "§ 03 · The data",
          title: "Training data.",
          paragraphs: [
            <>The model was trained on the <strong>National Health and Nutrition Examination Survey</strong> (NHANES) Continuous, a U.S. epidemiological study that has measured biomarkers and tracked mortality in nationally-representative samples since 1999. We used cycles 1999-2018. The testing against recorded deaths included 18,570 adults with at least 8 of the 14 reference markers, including albumin and creatinine, and with mortality follow-up through December 31, 2019.</>,
            <>For each biomarker, we fit a linear regression against chronological age. The resulting parameters (slope <em>k</em>, intercept <em>q</em>, residual SD <em>s</em>) describe how that biomarker changes through population aging. 16 of the 81 trained markers have separate parameters for men and women (creatinine, ferritin, hemoglobin, uric acid, GGT, ALT, testosterone, estradiol, among others).</>,
            <>IGF-1, not measured in the continuous cycles, was incorporated from NHANES III legacy data (1988-1994). Fructosamine, which NHANES does not measure, is derived from HbA1c with the formula Fructosamine (µmol/L) = 19.97 × HbA1c (%) − 39.4. Because the model was trained on this derived value, since September 25, 2026 a laboratory-measured fructosamine is not used by default.</>,
          ],
        },
        {
          id: "calibration",
          marker: "§ 04 · Spanish adjustment",
          title: "Adjustment with Spanish means.",
          paragraphs: [
            <>A Spanish user with typical values for their age should <em>not</em> have a biological age skewed by differences between the U.S. and Spanish populations. To reduce this effect, we replaced the intercept <em>q</em> of 9 of the 14 reference markers using published means from Spanish studies.</>,
            <>For markers on a linear scale, <code>q_spain = (mean_spain / mean_NHANES) × q_NHANES</code>. For those the model uses on a log scale (triglycerides, hs-CRP, GGT and TSH), <code>q_spain = q_NHANES + ln(mean_spain / mean_NHANES)</code>. Here q_NHANES is the original NHANES intercept, from before the May 2026 refit. The slope <em>k</em> and residual SD <em>s</em> are unchanged: we assume the markers change with age at the same rate in both populations and only the starting level differs.</>,
            <>So 9 of the 14 reference markers use Spanish means: five the same for both sexes (total cholesterol, triglycerides, hs-CRP, vitamin D and TSH) and four different by sex (creatinine, HDL, uric acid and GGT). The other five (albumin, BUN, alkaline phosphatase, ferritin and fructosamine) use NHANES means. The Comprehensive version applies the same adjustment to up to eight more markers, such as LDL cholesterol, hemoglobin or total testosterone.</>,
            <>The sources are published summaries of specific groups, not individual data and not samples of the whole Spanish population. For total cholesterol, HDL and triglycerides, the <strong>PESA</strong> study (Fernández-Friera 2015), with asymptomatic employees aged 40 to 54 of a bank in Madrid. For creatinine, uric acid, GGT and hs-CRP, a subsample of 400 PESA participants. None of the cited sources gives values by sex for creatinine, uric acid and GGT, so we could not verify the per-sex means we use for these three markers. For vitamin D, a study by Díaz-López and colleagues (2021) in primary-care users in La Rioja at risk of deficiency. For TSH, a national study by Alonso and colleagues (2025) in 1,629 adults with normal thyroid function. The adjustment has not yet been tested against recorded deaths in the Spanish population.</>,
          ],
        },
        {
          id: "method",
          marker: "§ 05 · The method",
          title: "The Klemera-Doubal method.",
          paragraphs: [
            <>The Klemera-Doubal joint estimator (2006) combines <em>n</em> biomarkers into a single biological age estimate. Each biomarker <em>x<sub>i</sub></em> contributes per the formula:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA_E = Σ (x<sub>i</sub> − q<sub>i</sub>) · (k<sub>i</sub> / s<sub>i</sub>²) / Σ (k<sub>i</sub> / s<sub>i</sub>)²
            </div>,
            <>Each marker gives its own estimate of age, (<em>x</em> − <em>q</em>) / <em>k</em>, weighted in proportion to (<em>k</em> / <em>s</em>)². So markers that change a lot with age relative to their residual spread carry more weight. The result, <em>BA<sub>E</sub></em>, is the “raw” biological age before anchoring to chronological age.</>,
            <>The final step applies a Bayesian shrinkage toward chronological age (CA) using the population deviation:</>,
            <div className="my-4 px-6 py-4 bg-[#f8f3ed] border-l-4 border-[#3a665e] font-[family-name:var(--font-dm-mono)] text-[14px] text-[#1d1b18]">
              BA = (BA_E / s_BA² + CA / s_CA²) / (1 / s_BA² + 1 / s_CA²)
            </div>,
            <>This shrinkage pulls the result toward chronological age: the final biological age weighs the joint estimator against chronological age. The fewer the markers, the more chronological age weighs.</>,
            <>Six of the 14 reference markers are log-transformed before fitting (hs-CRP, GGT, triglycerides, ferritin, TSH and fructosamine) because their distributions are log-normal. The transformation is applied internally; input values are entered in their natural clinical scale (mg/L, µg/L, etc.).</>,
            <>The estimator requires at least 8 of the 14 reference markers, with albumin and creatinine (or cystatin C) mandatory. Below that threshold, EVA does not compute a biological age.</>,
          ],
        },
        {
          id: "validation",
          marker: "§ 06 · Testing",
          title: "Testing against recorded deaths.",
          paragraphs: [
            <>The key question for a biological age is whether it adds information about mortality beyond chronological age. To study it, we fitted a Cox proportional hazards model on the NHANES subset with mortality follow-up, with biological age, chronological age and sex. These are the same adults the model was built on.</>,
            <>In version <strong>v2.2.2</strong> (May 2026, with 80 of the 81 trained markers refitted on unwinsorized NHANES values):</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Hazard ratio per standard deviation of biological age</strong>: 1.39 (Reference) and 1.65 (Comprehensive), in a model that also includes age and sex. At the same age and sex, each standard deviation of biological age goes with about 39% higher relative mortality risk (Reference).</li>
              <li><strong>C-statistic</strong>: 0.77 (Reference) and 0.775 (Comprehensive). This is the value of the whole model, with age and sex, not of biological age alone.</li>
            </ul>,
            <>The answer is that it adds a little, but not much. In a later internal evaluation on NHANES data from 2007 to 2014, age and sex alone gave a C-statistic of 0.77. Adding this biological age, computed from the markers of the EVA Base Panel, raised it by about <strong>0.009</strong>. Those years are part of the data the model was built on.</>,
          ],
        },
        {
          id: "two-tiers",
          marker: "§ 07 · Two tiers",
          title: "Two levels of measurement.",
          paragraphs: [
            <>The model has two versions:</>,
            <ul className="my-4 ml-6 space-y-2 list-disc text-[15px] text-[#4c463f]">
              <li><strong>Reference Biological Age (BA)</strong>: uses only the 14 reference markers; with the EVA Base Panel, 10 of them. It is stored with each lab result and is the figure shown on each lab result page.</li>
              <li><strong>Comprehensive Biological Age (BA<sub>comp</sub>)</strong>: uses every marker the model accepts, up to 81 trained markers; with the Base Panel, 12 of its 13 tests. It is the figure on the dashboard. Tested the same way: HR per standard deviation of biological age 1.65, C-statistic 0.775.</li>
            </ul>,
            <>Both use the same mathematical method and the same minimum requirements; they differ in how many markers they use. So whenever the Reference version can be calculated, the Comprehensive one can too. The dashboard calculates it on the average of your lab results from the last 6 months; if you have fewer than two, from the last 12; otherwise, on your latest lab result. The testing against recorded deaths, by contrast, used one lab result per person, in the same data the model was built on.</>,
          ],
        },
        {
          id: "limits",
          marker: "§ 08 · Limits",
          title: "Limitations and transparency.",
          paragraphs: [
            <>KDM is a population model. This means its answers are less precise for individuals atypical of the training population. These are its main limitations:</>,
            <ol className="my-4 ml-6 space-y-3 list-decimal text-[15px] text-[#4c463f]">
              <li><strong>A large part of the result is chronological age</strong>. With the Base Panel, for a typical 45-year-old man, chronological age carries 78% of the weight in the dashboard figure and 60% in the Reference version.</li>
              <li><strong>It varies between lab tests</strong>. In EVA simulations, two draws a few weeks apart, with no real change, varied by about 2 years in the dashboard figure and about 4 in the Reference version (one standard deviation). A small change between two results may be only this variation.</li>
              <li><strong>It can read older than chronological age</strong>. In an internal evaluation on NHANES data, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average.</li>
              <li><strong>It has not been tested in Spain</strong>. All mortality figures come from NHANES, in the United States, and from the same data the model was built on. The adjustment with Spanish means has not been tested against recorded deaths.</li>
              <li><strong>NHANES is not a "healthy aging" cohort</strong>. It includes people with chronic conditions (CKD, diabetes, hypertension). The model learns the population trajectory including pathology — which can penalize athletic individuals with markers outside the population mean for lifestyle reasons (high protein intake elevates BUN; creatine supplementation elevates creatinine without affecting kidney function). We automatically adjust creatinine when the user reports supplementation.</li>
              <li><strong>Acute variations not captured</strong>. A blood test taken after intense exercise, in dehydration, or during an acute infection will produce values the model interprets as population aging, when they're transient variations. For reliable trends, repeat measurement under stable conditions.</li>
              <li><strong>Unmodeled medications</strong>. Statins (lower total cholesterol), levothyroxine (suppresses TSH), ACE inhibitors (elevate creatinine), and others can distort the calculation. Clinical interpretation should contextualize.</li>
            </ol>,
          ],
        },
        {
          id: "improvement",
          marker: "§ 09 · What comes next",
          title: "What comes next.",
          paragraphs: [
            <>EVA is evaluating a new model, trained on mortality data, that will replace this one once it passes its validation and release conditions. Until then, this document describes the model that calculates your biological age today.</>,
          ],
        },
      ];

  const refTitle = es ? "Referencias." : "References.";
  const refDownload = es ? "Descargar PDF" : "Download PDF";

  return (
    <main className="relative bg-[#fef8f2] text-[#1d1b18]">
      {/* ═══════════════════════════════════════════════════════════
       * Hero
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="large">
        <ChapterMarker>{es ? "Metodología completa" : "Full methodology"}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">
          {es ? "KDM v2.2.2 — el documento de referencia." : "KDM v2.2.2 — the reference document."}
        </SectionHeadline>
        <LedeItalic className="mt-8 max-w-3xl">
          {es
            ? "Cómo entrenamos el modelo, qué datos usamos, cómo lo evaluamos frente a la mortalidad y dónde sabemos que tiene límites."
            : "How we trained the model, what data we used, how we tested it against recorded deaths, and where we know it has limits."}
        </LedeItalic>

        {/* Mini table of contents */}
        <nav className="mt-12 md:mt-16 border-t border-b border-[#1d1b18]/10 py-6">
          <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c] mb-4">
            {es ? "Contenido" : "Contents"}
          </p>
          <ol className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-[14px] text-[#4c463f]">
            {sections.map((s, i) => (
              <li key={s.id}>
                <a href={`#${s.id}`} className="hover:text-[#3a665e] transition-colors">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[#97472c]/60 mr-2">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  {s.title}
                </a>
              </li>
            ))}
            <li>
              <a href="#refs" className="hover:text-[#3a665e] transition-colors">
                <span className="font-[family-name:var(--font-dm-mono)] text-[#97472c]/60 mr-2">10</span>
                {refTitle}
              </a>
            </li>
          </ol>
        </nav>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * Sections 1-9
       * ═══════════════════════════════════════════════════════════ */}
      {sections.map((s, i) => (
        <SectionShell
          key={s.id}
          tone={i % 2 === 0 ? "cream" : "cream-alt"}
          size="standard"
        >
          <div id={s.id}>
            <ChapterMarker>{s.marker}</ChapterMarker>
            <SectionHeadline className="mt-6 md:mt-8">{s.title}</SectionHeadline>
            <div className="mt-8 md:mt-10 space-y-6 max-w-3xl">
              {s.paragraphs.map((p, j) => (
                <BodyProse key={j}>{p}</BodyProse>
              ))}
            </div>
          </div>
        </SectionShell>
      ))}

      {/* ═══════════════════════════════════════════════════════════
       * § 10 — References
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="large">
        <div id="refs">
          <ChapterMarker>§ 10 · {refTitle}</ChapterMarker>
          <SectionHeadline className="mt-6 md:mt-8">{refTitle}</SectionHeadline>
          <ol className="mt-10 space-y-5 max-w-3xl">
            {refs.map((r) => (
              <li key={r.num} className="flex gap-4">
                <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#97472c] mt-1">
                  {String(r.num).padStart(2, "0")}
                </span>
                <p className="text-[14px] leading-relaxed text-[#4c463f]">
                  {r.text}{" "}
                  <a
                    href={r.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#3a665e] underline decoration-[#3a665e]/30 underline-offset-2 hover:decoration-[#3a665e]"
                  >
                    PubMed
                  </a>
                </p>
              </li>
            ))}
          </ol>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * Back-to-short-page CTA
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="standard">
        <div className="text-center max-w-2xl mx-auto">
          <SubHeadline>
            {es
              ? "¿Quieres ver tu propia edad biológica?"
              : "Want to see your own biological age?"}
          </SubHeadline>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <CTAButton variant="primary" href={`/${locale}/dashboard`}>
              {es ? "Ir al dashboard" : "Go to dashboard"}
            </CTAButton>
            <CTAButton variant="ghost" href={`/${locale}/metodologia`}>
              {es ? "Volver al resumen" : "Back to summary"}
            </CTAButton>
          </div>
        </div>
      </SectionShell>
    </main>
  );
}
