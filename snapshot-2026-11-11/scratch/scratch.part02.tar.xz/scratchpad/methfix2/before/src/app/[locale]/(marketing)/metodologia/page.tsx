"use client";

/**
 * /metodologia — short trust-signal page for the KDM v2.2.2 biological age.
 *
 * This page is the destination of the "¿Cómo se calcula?" link in the
 * dashboard's KDM provenance row (see `dashboard-client.tsx` § VitalsStrip).
 * It's deliberately short and oriented toward non-specialist readers: how
 * the model was tested, against what, with what numbers, its known limits,
 * and where to read more.
 *
 * For the deep methodology (the 10-section "completa" document with full
 * citations), see ./completa/page.tsx.
 */

import { useParams } from "next/navigation";
import {
  ChapterMarker,
  SectionHeadline,
  SubHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
  HandDrawnUnderline,
} from "@/components/marketing/editorial";
import { CTAButton } from "@/components/marketing/CTAButton";

export default function MetodologiaPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const es = locale === "es";

  const t = es
    ? {
        ch01: "§ 01 · La pregunta",
        ch02: "§ 02 · La evidencia",
        ch03: "§ 03 · El método",
        ch04: "§ 04 · La transparencia",

        heroTitle: "Cómo medimos tu edad biológica.",
        heroLede:
          "No es una opinión ni un score genérico. Es una estimación evaluada frente a la mortalidad en 18.570 adultos de NHANES, con limitaciones que explicamos abiertamente.",

        // § 02 Trust signals
        sigTitle: "Tres números que importan.",
        sigBody:
          "El algoritmo se evaluó frente a las muertes registradas en NHANES, los mismos datos con los que se construyó.",
        sig1Eye: "HAZARD RATIO",
        sig1Val: "1,39",
        sig1Label: "por desviación estándar",
        sig1Desc:
          "A igual edad y sexo, cada desviación estándar de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (versión de referencia, NHANES). En la versión completa, la cifra es 1,65.",
        sig2Eye: "C-STATISTIC",
        sig2Val: "+0,009",
        sig2Label: "sobre la edad y el sexo",
        sig2Desc:
          "La edad y el sexo solos ya dan un C-statistic de 0,77. Calculada con los marcadores del Panel Base de EVA, esta edad biológica lo sube unas 0,009: una ganancia pequeña. Son datos de NHANES de 2007 a 2014, que forman parte de los datos con los que se construyó el modelo.",
        sig3Eye: "POBLACIÓN",
        sig3Val: "18.570",
        sig3Label: "adultos NHANES",
        sig3Desc:
          "Entrenado con datos del National Health and Nutrition Examination Survey de Estados Unidos (1999-2018), con seguimiento de mortalidad hasta 2019. En 9 de sus 14 marcadores de referencia usa medias publicadas de estudios españoles.",

        // § 03 Method
        methodTitle: "Klemera-Doubal, ajustado en parte con medias españolas.",
        methodBody:
          "Tu edad biológica se calcula con el método de Klemera-Doubal (2006), un estimador estadístico que combina múltiples biomarcadores en un único número de años. Cada biomarcador pesa más cuanto más claramente cambia con la edad en la población de referencia.",
        methodBody2:
          "Para el mercado español hemos sustituido las medias de 9 de los 14 marcadores de referencia por valores publicados de estudios españoles, sobre todo del estudio PESA (Fernández-Friera 2015), con adultos de 40 a 54 años. En cuatro de ellos (creatinina, HDL, ácido úrico y GGT), las medias son distintas para hombres y mujeres; en tres de esos cuatro no hemos podido verificar las medias por sexo en las fuentes citadas. Albúmina, BUN, fosfatasa alcalina, ferritina y fructosamina siguen usando las medias de NHANES. La versión completa aplica el mismo ajuste a hasta ocho marcadores más, entre ellos la hemoglobina y la testosterona total, también por sexo. Las medias por sexo se aplican desde mayo de 2026, tras detectar que no se estaban aplicando. El objetivo es que una persona española con valores típicos para su edad obtenga una edad biológica cercana a su edad real, y no a la media estadounidense. Este ajuste no se ha evaluado todavía frente a la mortalidad en la población española.",
        methodCallout:
          "La edad biológica responde a una pregunta diferente que el score de longevidad. La primera te dice cómo envejeces frente a la población; la segunda, qué tan cerca estás de lo óptimo.",

        // § 04 Transparency
        transTitle: "Lo que el modelo sabe — y lo que no.",
        transKnows: "Lo que el modelo capta:",
        transKnowsItems: [
          "Trayectoria de envejecimiento poblacional de sus 14 marcadores de referencia (riñón, hígado, inflamación, glicación, lípidos, nutrición). El Panel Base de EVA, de 13 pruebas, aporta 10 de ellos. Su fructosamina medida no se usa: el modelo se entrenó con una fructosamina derivada de la HbA1c.",
          "Diferencias entre hombres y mujeres: 16 de los 81 marcadores entrenados tienen parámetros distintos por sexo.",
          "Suplementación de creatina (ajuste automático del valor de creatinina, basado en literatura ISSN 2017).",
          "Cistatina C cuando está disponible, en lugar de la creatinina (marcador renal no afectado por masa muscular).",
        ],
        transLimits: "Lo que el modelo no captura:",
        transLimitsItems: [
          "Variaciones agudas (deshidratación, ejercicio reciente, comida pre-analítica).",
          "Composición corporal (masa muscular vs masa grasa) más allá de la suplementación de creatina.",
          "Medicamentos que afectan biomarcadores (estatinas, ACE inhibidores, levotiroxina).",
          "Genética, epigenética, telómeros — métodos válidos pero complementarios.",
        ],
        transKnown: "Límites conocidos de esta versión:",
        transKnownItems: [
          "Gran parte del resultado es tu edad cronológica. Con el Panel Base, para un hombre típico de 45 años, la edad cronológica pesa un 78% en la cifra del dashboard y un 60% en la versión de referencia.",
          "La cifra varía entre analíticas aunque nada haya cambiado. En las simulaciones de EVA, dos extracciones separadas unas semanas variaron unos 2 años en la cifra del dashboard y unos 4 en la versión de referencia (una desviación estándar).",
          "Puede dar una edad mayor que la cronológica. En una evaluación interna con datos de NHANES, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica.",
          "No se ha evaluado frente a la mortalidad en España. Las cifras de mortalidad proceden de NHANES, en Estados Unidos, y de los mismos datos con los que se construyó el modelo.",
        ],

        ctaTitle: "Lee la metodología completa.",
        ctaBody:
          "El documento completo cubre los datos de entrenamiento, el ajuste con medias españolas, el método matemático, la evaluación frente a la mortalidad y nuestras limitaciones, con referencias a literatura primaria.",
        ctaButton: "Ver metodología completa",
      }
    : {
        ch01: "§ 01 · The question",
        ch02: "§ 02 · The evidence",
        ch03: "§ 03 · The method",
        ch04: "§ 04 · Transparency",

        heroTitle: "How we measure your biological age.",
        heroLede:
          "Not an opinion, and not a generic score. An estimate tested against recorded deaths in 18,570 NHANES adults, with limits we explain openly.",

        sigTitle: "Three numbers that matter.",
        sigBody:
          "The algorithm was tested against recorded deaths in NHANES, the same data it was built on.",
        sig1Eye: "HAZARD RATIO",
        sig1Val: "1.39",
        sig1Label: "per standard deviation",
        sig1Desc:
          "At the same age and sex, each standard deviation of biological age goes with about 39% higher relative mortality risk (Reference version, NHANES). In the Comprehensive version, the figure is 1.65.",
        sig2Eye: "C-STATISTIC",
        sig2Val: "+0.009",
        sig2Label: "over age and sex",
        sig2Desc:
          "Age and sex alone already give a C-statistic of 0.77. Computed from the markers in EVA's Base Panel, this biological age raises it by about 0.009: a small gain. These are NHANES data from 2007 to 2014, which are part of the data the model was built on.",
        sig3Eye: "POPULATION",
        sig3Val: "18,570",
        sig3Label: "NHANES adults",
        sig3Desc:
          "Trained on the U.S. National Health and Nutrition Examination Survey (1999-2018), with mortality follow-up through 2019. For 9 of its 14 reference markers it uses published means from Spanish studies.",

        methodTitle: "Klemera-Doubal, partly adjusted with Spanish means.",
        methodBody:
          "Your biological age is calculated with the Klemera-Doubal method (2006), a statistical estimator that combines multiple biomarkers into a single number of years. Each biomarker weighs more the more clearly it changes with age in the reference population.",
        methodBody2:
          "For the Spanish market we replaced the means of 9 of the 14 reference markers with published values from Spanish studies, mostly the PESA study (Fernández-Friera 2015), with adults aged 40 to 54. For four of them (creatinine, HDL, uric acid and GGT), the means differ for men and women; for three of those four we could not verify the per-sex means in the cited sources. Albumin, BUN, alkaline phosphatase, ferritin and fructosamine still use NHANES means. The Comprehensive version applies the same adjustment to up to eight more markers, including hemoglobin and total testosterone, also by sex. The per-sex means have been applied since May 2026, after we found they were not being applied. The aim is that a Spanish person with typical values for their age gets a biological age close to their real age, not the U.S. average. This adjustment has not yet been tested against recorded deaths in the Spanish population.",
        methodCallout:
          "Biological age answers a different question than the longevity score. The first tells you how you're aging vs. the population; the second, how close you are to optimal.",

        transTitle: "What the model knows — and what it doesn't.",
        transKnows: "What the model captures:",
        transKnowsItems: [
          "Population aging trajectory of its 14 reference markers (kidney, liver, inflammation, glycation, lipids, nutrition). EVA's 13-test Base Panel supplies 10 of them. Its measured fructosamine is not used: the model was trained on a fructosamine derived from HbA1c.",
          "Sex differences: 16 of the 81 trained markers have separate parameters for men and women.",
          "Creatine supplementation (automatic creatinine adjustment based on ISSN 2017 literature).",
          "Cystatin C when available, in place of creatinine (kidney marker unaffected by muscle mass).",
        ],
        transLimits: "What the model doesn't capture:",
        transLimitsItems: [
          "Acute variations (dehydration, recent exercise, pre-analytical meals).",
          "Body composition (muscle vs fat mass) beyond creatine supplementation.",
          "Medications affecting biomarkers (statins, ACE inhibitors, levothyroxine).",
          "Genetics, epigenetics, telomeres — valid but complementary methods.",
        ],
        transKnown: "Known limits of this version:",
        transKnownItems: [
          "A large part of the result is your chronological age. With the Base Panel, for a typical 45-year-old man, chronological age carries 78% of the weight in the dashboard figure and 60% in the Reference version.",
          "The figure varies between lab tests even when nothing has changed. In EVA's simulations, two draws a few weeks apart varied by about 2 years in the dashboard figure and about 4 in the Reference version (one standard deviation).",
          "It can read older than chronological age. In an internal evaluation on NHANES data, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average.",
          "It has not been tested against recorded deaths in Spain. The mortality figures come from NHANES, in the United States, and from the same data the model was built on.",
        ],

        ctaTitle: "Read the full methodology.",
        ctaBody:
          "The full document covers training data, the adjustment with Spanish means, the mathematical method, testing against recorded deaths, and our limitations, with references to primary literature.",
        ctaButton: "Read the full methodology",
      };

  return (
    <main className="relative bg-[#fef8f2] text-[#1d1b18]">
      {/* ═══════════════════════════════════════════════════════════
       * § 01 — Hero: the question
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ChapterMarker>{t.ch01}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">
          {t.heroTitle.split(" ").slice(0, -2).join(" ")}{" "}
          <span className="relative inline-block">
            {t.heroTitle.split(" ").slice(-2).join(" ")}
            <HandDrawnUnderline />
          </span>
        </SectionHeadline>
        <LedeItalic className="mt-8 md:mt-10 max-w-2xl">{t.heroLede}</LedeItalic>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 02 — Trust signals (3 cards)
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ChapterMarker>{t.ch02}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.sigTitle}</SectionHeadline>
        <BodyProse className="mt-6 max-w-2xl">{t.sigBody}</BodyProse>

        <div className="mt-14 md:mt-20 grid grid-cols-1 md:grid-cols-3 gap-px bg-[#1d1b18]/10 border border-[#1d1b18]/10">
          {[
            { eye: t.sig1Eye, val: t.sig1Val, label: t.sig1Label, desc: t.sig1Desc },
            { eye: t.sig2Eye, val: t.sig2Val, label: t.sig2Label, desc: t.sig2Desc },
            { eye: t.sig3Eye, val: t.sig3Val, label: t.sig3Label, desc: t.sig3Desc },
          ].map((s, i) => (
            <div key={i} className="bg-[#fef8f2] p-8 md:p-10">
              <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
                {s.eye}
              </p>
              <p
                className="mt-4 font-[family-name:var(--font-cormorant)] text-[56px] md:text-[72px] font-medium leading-none text-[#3a665e]"
                style={{ fontVariantNumeric: "tabular-nums" }}
              >
                {s.val}
              </p>
              <p className="mt-2 font-[family-name:var(--font-dm-mono)] text-[11px] uppercase tracking-[1.4px] text-[#4c463f]/70">
                {s.label}
              </p>
              <p className="mt-5 text-[15px] leading-relaxed text-[#4c463f]">
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 03 — Method
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ChapterMarker>{t.ch03}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.methodTitle}</SectionHeadline>
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-7">
            <BodyProse>{t.methodBody}</BodyProse>
            <BodyProse className="mt-6">{t.methodBody2}</BodyProse>
          </div>
          <aside className="lg:col-span-5 lg:pl-8 lg:border-l lg:border-[#1d1b18]/10">
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
              {es ? "Importante" : "Important"}
            </p>
            <LedeItalic className="mt-4">{t.methodCallout}</LedeItalic>
          </aside>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 04 — Transparency
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ChapterMarker>{t.ch04}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.transTitle}</SectionHeadline>

        <div className="mt-12 md:mt-16 grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16">
          <div>
            <SubHeadline className="text-[#3a665e]">{t.transKnows}</SubHeadline>
            <ul className="mt-6 space-y-4">
              {t.transKnowsItems.map((item, i) => (
                <li key={i} className="flex gap-4">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#3a665e]/60 mt-1.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[15px] leading-relaxed text-[#4c463f]">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SubHeadline className="text-[#97472c]">{t.transLimits}</SubHeadline>
            <ul className="mt-6 space-y-4">
              {t.transLimitsItems.map((item, i) => (
                <li key={i} className="flex gap-4">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#97472c]/60 mt-1.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[15px] leading-relaxed text-[#4c463f]">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Known limits of this version. Each item is backed by EVA's own
            files: docs/biomarker-evidence/longevity/base-panel/ASSESSMENT.md
            (F1, F5), ml/biological-age/REPORT.md and REPORT-baselines.md
            (T3, T7), docs/biomarker-evidence/bioage-model-selection/DECISION.md
            and METHODOLOGY-CLAIMS-FOR-COUNSEL.md. */}
        <div className="mt-12 md:mt-16 max-w-3xl">
          <SubHeadline className="text-[#97472c]">{t.transKnown}</SubHeadline>
          <ul className="mt-6 space-y-4">
            {t.transKnownItems.map((item, i) => (
              <li key={i} className="flex gap-4">
                <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#97472c]/60 mt-1.5">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-[15px] leading-relaxed text-[#4c463f]">
                  {item}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * CTA — link to deep methodology
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="large">
        <div className="text-center max-w-2xl mx-auto">
          <SectionHeadline>{t.ctaTitle}</SectionHeadline>
          <BodyProse className="mt-6">{t.ctaBody}</BodyProse>
          <div className="mt-10">
            <CTAButton
              variant="primary"
              href={`/${locale}/metodologia/completa`}
            >
              {t.ctaButton}
            </CTAButton>
          </div>
        </div>
      </SectionShell>
    </main>
  );
}
