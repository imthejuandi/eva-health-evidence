import sys, json
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
SUPP_URL = "https://repisalud.isciii.es/bitstreams/0000edfa-0139-4fbd-b866-8f3e4f626c51/download"
SUPP_CITE = ("Mastrangelo A, Robles-Vera I, Mañanes D, et al. (2025). Imidazole propionate is a driver and therapeutic target "
             "in atherosclerosis. Nature 645:254-261 (PMID 40670786). Supplementary information: PESA subsample, n=400 "
             "(PESA cohort: Fernández-Friera et al., Circulation 2015, PMID 25882487). The file reports both sexes "
             "together, so the per-sex means used here are not from it.")
reps = [
 # creatinine: n_in_source 400 is the PESA subsample; the main PESA paper does not report creatinine
 ('"source_citation": "Fernández-Friera L, Peñalvo JL, Fernández-Ortiz A, et al. (2015). Prevalence, Vascular Distribution, and Multiterritorial Extent of Subclinical Atherosclerosis in a Middle-Aged Cohort: The PESA (Progression of Early Subclinical Atherosclerosis) Study. Circulation",\n        "source_url": "https://pubmed.ncbi.nlm.nih.gov/26088847/",\n        "n_in_source": 400,',
  '"source_citation": "' + SUPP_CITE + '",\n        "source_url": "' + SUPP_URL + '",\n        "n_in_source": 400,', 1),
 ('"source_citation": "PESA-CNIC investigators (2015). PESA-CNIC supplementary data (parent: Fernández-Friera et al., Circulation 2015). Circulation (parent paper)",',
  '"source_citation": "' + SUPP_CITE + '",', 1),
 ('"source_citation": "PESA-CNIC investigators (2015). PESA-CNIC supplementary (parent: Fernández-Friera et al., Circulation 2015). Circulation (parent paper)",',
  '"source_citation": "' + SUPP_CITE + '",', 1),
 ('"source_citation": "PESA-CNIC investigators (2015). PESA-CNIC supplementary (parent: Fernández-Friera 2015). Circulation (parent)",',
  '"source_citation": "' + SUPP_CITE + '",', 1),
 ('"source_citation": "PESA-CNIC investigators (2015). PESA-CNIC supplementary (Fernández-Friera 2015). Circulation (parent)",',
  '"source_citation": "' + SUPP_CITE + '",', 1),
 # PESA main paper: the old link opened an unrelated Croatian paper (PMID 26088847)
 ('"source_url": "https://pubmed.ncbi.nlm.nih.gov/26088847/",', '"source_url": "https://pubmed.ncbi.nlm.nih.gov/25882487/",', 6),
 # vitamin D: the n=21,490 study is Díaz-López et al. 2021, not "Fernández-García JC"
 ('"source_citation": "Fernández-García JC et al. (2021). Deficiencia de vitamina D en usuarios de atención primaria con riesgo de hipovitaminosis D. Nutrición Hospitalaria",\n        "source_url": "http://scielo.isciii.es/scielo.php?script=sci_arttext&pid=S0212-16112021000600022",',
  '"source_citation": "Díaz-López A, Paz-Graniel I, Alonso-Sanz R, et al. (2021). Vitamin D deficiency in primary health care users at risk in Spain. Nutr Hosp 38(5):1058-1067 (PMID 33866793). Primary-care users in La Rioja at risk of deficiency, with a vitamin D test.",\n        "source_url": "https://pubmed.ncbi.nlm.nih.gov/33866793/",', 1),
]
for old, new, expected in reps:
    n = s.count(old)
    if n != expected:
        print("FAIL count", n, "expected", expected, old[:100]); sys.exit(1)
    s = s.replace(old, new)
json.loads(s)  # must still parse
open(p, 'w', encoding='utf-8').write(s)
print("ok")
