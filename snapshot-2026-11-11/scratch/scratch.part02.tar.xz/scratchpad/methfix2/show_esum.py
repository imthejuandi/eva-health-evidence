import json, sys
d = json.load(open(sys.argv[1]))
r = d['result']
for uid in r['uids']:
    e = r[uid]
    auth = ', '.join(a['name'] for a in e.get('authors', [])[:6])
    print(f"{uid} | {e.get('source')} {e.get('pubdate')};{e.get('volume')}({e.get('issue')}):{e.get('pages')} | {auth}")
    print('    TITLE:', e.get('title'))
    print('    pubtype:', e.get('pubtype'), '| doi:', [x['value'] for x in e.get('articleids', []) if x['idtype'] in ('doi','pmc')])
