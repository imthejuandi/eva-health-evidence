import json, sys
lib = json.load(open('/home/user/eva-health/src/lib/biomarkers/data/marker_library_v2_2.json'))
M = lib['markers']
for k,e in M.items():
    sr = e.get('spanish_recalibration') or {}
    st = sr.get('calibration_status') or ''
    if st.startswith('recalibrated_'):
        print('=====', k)
        print(json.dumps(sr, ensure_ascii=False, indent=1)[:2500])
