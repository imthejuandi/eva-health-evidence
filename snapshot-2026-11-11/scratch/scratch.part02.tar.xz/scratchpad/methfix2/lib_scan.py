import json, sys
lib = json.load(open('/home/user/eva-health/src/lib/biomarkers/data/marker_library_v2_2.json'))
pb = json.load(open('/home/user/eva-health/src/lib/biomarkers/data/path_b_overrides.json'))
M = lib['markers']
base = lib['meta']['base_panel']
def trained(e):
    if e.get('sex_stratified'):
        return bool(e.get('kqs_M')) and bool(e.get('kqs_F'))
    return bool(e.get('kqs'))
tr = [k for k,e in M.items() if trained(e)]
print('total markers', len(M), 'trained', len(tr))
print('path_b markers', len(pb['markers']))
print('trained not in path_b:', [k for k in tr if k not in pb['markers']])
print('path_b not trained:', [k for k in pb['markers'] if k not in tr])
print('log_transformed in base:', [k for k in base if M[k].get('log_transformed')])
print('log_transformed among trained:', [k for k in tr if M[k].get('log_transformed')])
print('sex_stratified among trained:', len([k for k in tr if M[k].get('sex_stratified')]), [k for k in tr if M[k].get('sex_stratified')])
print('meta sex_stratified not trained:', [k for k in lib['meta']['sex_stratified_markers'] if k not in tr])
print('sex_stratified flag in library (all):', len([k for k,e in M.items() if e.get('sex_stratified')]))
print()
for k,e in M.items():
    sr = e.get('spanish_recalibration') or {}
    st = sr.get('calibration_status')
    if k in base or (st and st.startswith('recalibrated_')):
        ps = sr.get('per_sex') or {}
        print(('BASE ' if k in base else '     ')+k, '| log' if e.get('log_transformed') else '', '| sex' if e.get('sex_stratified') else '', '| status:', st,
              '| q_spain:', sr.get('q_spain'), '| perM:', (ps.get('M') or {}).get('q_spain') if ps else None, '| perF:', (ps.get('F') or {}).get('q_spain') if ps else None,
              '| trained:', trained(e), '| pathB:', k in pb['markers'])
