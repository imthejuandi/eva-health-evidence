import sys
root = sys.argv[1]
edits = {
"src/lib/biomarkers/rolling-average-ba.ts": [
(""" *   - Comprehensive BA is preferred when the joint estimator computes —
 *     it uses every KDM-mapped marker and has higher mortality
 *     discrimination (HR/SD 1.49 vs Reference 1.29).
 *   - Reference BA is the fallback when Comprehensive returns null.
 *   - Both share the same gate (≥ 8 of 14 base panel + Albumin + Creatinine).
""",
""" *   - Comprehensive BA is preferred when the joint estimator computes.
 *     It uses every KDM-mapped marker. Its stored v2.2.2 figure is HR 1.65
 *     per SD of biological age, against 1.39 for the Reference, from Cox
 *     models with age and sex fitted on the same NHANES subjects the model
 *     was built on (in-sample, not a held-out comparison of the tiers).
 *   - Reference BA is the fallback when Comprehensive returns null.
 *   - Both share the same gate (≥ 8 of 14 base panel + Albumin + Creatinine),
 *     and the Comprehensive uses a superset of the Reference's markers, so
 *     the fallback is not reached in practice: every client whose BA is
 *     computed here gets the Comprehensive value.
"""),
],
"src/lib/biomarkers/biological-age.ts": [
(""" *   - Use `computeReferenceBA` / `computeComprehensiveBA` from
 *     `./biological-age-kdm` for mortality-validated biological age
 *     (KDM v2.2 joint estimator, HR/SD 1.37 in NHANES n=18,570).
""",
""" *   - Use `computeReferenceBA` / `computeComprehensiveBA` from
 *     `./biological-age-kdm` for the KDM biological age (KDM v2.2.2 joint
 *     estimator; in-sample HR 1.39 Reference / 1.65 Comprehensive per SD of
 *     biological age, Cox model with age and sex, NHANES n=18,570; not
 *     tested outside NHANES).
"""),
],
"src/lib/biomarkers/biological-age-kdm.ts": [
(""" * KDM v2.2 Biological Age module — mortality-validated joint estimator.
""",
""" * KDM v2.2 Biological Age module: the Klemera-Doubal joint estimator.
"""),
(""" * Levine 2013; Kwon & Belsky 2021). The library data was trained on
 * NHANES Continuous 1999-2018 (n=18,570) with Spanish-cohort recalibration
 * via PESA / ENRICA / Di@bet.es / Hortega / PREDIMED / EPIRCE / La Rioja
 * (see `data/marker_library_v2_2.json::model_meta`).
 *
 * Validation (NHANES held-out follow-up through 2019):
 *   - Reference BA  : HR per SD = 1.373 [1.29, 1.46], C-stat 0.770
 *   - Calibration slope = 1.027
""",
""" * Levine 2013; Kwon & Belsky 2021). The library data was trained on
 * NHANES Continuous 1999-2018 (n=18,570). For 17 markers a published
 * Spanish summary mean replaces the NHANES intercept q (mostly from PESA;
 * each marker's source is in its `spanish_recalibration` block in
 * `data/marker_library_v2_2.json`). No Spanish individual-level or outcome
 * data is used.
 *
 * Original v2.2 mortality check (NHANES, follow-up through 2019). These
 * figures are in-sample: they come from the same subjects the parameters
 * were fitted on (scripts/honest_holdout_validation.py), and they predate
 * v2.2.2 (see the table below):
 *   - Reference BA  : HR per SD of biological age = 1.373 [1.29, 1.46], in
 *     a Cox model with age and sex. C-stat 0.770 is for that whole model; in
 *     EVA's 2007-2014 NHANES comparison, age and sex alone give C 0.771 and
 *     KDM adds about 0.009 (ml/biological-age/MODEL-CARD.md, section 10).
 *   - Calibration slope = 1.027 (v2.2 only; none is stored for v2.2.2).
"""),
(""" * Mortality re-validation on n=18,570 NHANES subjects across configs:
""",
""" * Mortality re-check on n=18,570 NHANES subjects across configs (in-sample;
 * HR/SD is per SD of biological age, from Cox(BA_z, age, sex)):
"""),
(""" * Both tiers pass the spec thresholds (HR/SD ≥ 1.02, C-stat ≥ 0.75,
 * calibration slope ∈ [0.9, 1.1]). v2.2.2 essentially eliminates the
 * population-level Reference/Comprehensive discrepancy while preserving
 * mortality predictiveness.
 *
 * See `scripts/comprehensive_ba_mortality_validation.py` for the run that
 * justifies full Path B; see `generate_path_b_full_overrides.py` for the
 * refit pipeline. The Comprehensive BA carries the larger mortality
 * signal (HR/SD 1.65 vs 1.39) — it's the more discriminative model when
 * the user uploads an extended panel.
""",
""" * Both tiers clear the spec's HR/SD ≥ 1.02 and C-stat ≥ 0.75 (C 0.77 and
 * 0.775 in `data/path_b_overrides.json` `_meta.validation_summary`, both
 * in-sample). No calibration slope is stored for v2.2.2, so the spec's
 * slope range [0.9, 1.1] is unchecked for this version. v2.2.2 essentially
 * eliminates the population-level Reference/Comprehensive discrepancy
 * (mean Δ +0.07 y).
 *
 * See `scripts/comprehensive_ba_mortality_validation.py` for the run that
 * justifies full Path B; see `generate_path_b_full_overrides.py` for the
 * refit pipeline. The Comprehensive BA has the larger in-sample HR/SD
 * (1.65 vs 1.39). Each is per SD of its own tier's BA and both are
 * in-sample, so neither figure is a held-out comparison of the tiers.
"""),
(""" * trained KDM parameters. Typically wider standard error; treated as a
 * supplementary headline when sufficient data is uploaded.
""",
""" * trained KDM parameters. The dashboard's rolling average shows this tier
 * first, for every client (`rolling-average-ba.ts`).
"""),
(""" * every KDM-mapped marker (not just the 14-marker base panel). Used as a
 * supplementary metric when the user has uploaded an extended panel.
""",
""" * every KDM-mapped marker (not just the 14-marker base panel). The
 * dashboard's rolling average shows this tier first (`rolling-average-ba.ts`).
"""),
],
"src/lib/biomarkers/process-results.ts": [
("""   * KDM v2.2 biological age — separate, mortality-validated metric. Null
   * when the KDM gate fails (< 8 base panel + Alb + Crea). Coexists with
""",
"""   * KDM v2.2 biological age, a separate metric (tested against NHANES
   * deaths, in-sample only). Null
   * when the KDM gate fails (< 8 base panel + Alb + Crea). Coexists with
"""),
("""  // it on the legacy `biologicalAge` object so admin / email consumers see
  // the new mortality-validated number. When KDM gate failed but longevity
""",
"""  // it on the legacy `biologicalAge` object so admin / email consumers see
  // the KDM Reference number. When KDM gate failed but longevity
"""),
],
"src/lib/queries/types.ts": [
("""   * From 2026-05-26 onward this is the KDM v2.2 Reference BA
   * (mortality-validated joint estimator over 14-marker base panel).
""",
"""   * From 2026-05-26 onward this is the KDM v2.2 Reference BA
   * (joint estimator over the 14-marker base panel; tested against NHANES
   * deaths in-sample only).
"""),
("""   * KDM v2.2 Comprehensive BA — full-panel joint estimator companion.
   * Available when the user has uploaded an extended panel.
""",
"""   * KDM v2.2 Comprehensive BA, the full-panel joint estimator. Computed
   * whenever the Reference BA is (same gate, more markers); the dashboard's
   * rolling average shows this tier first.
"""),
],
}
for rel, reps in edits.items():
    p = root + "/" + rel
    s = open(p, encoding='utf-8').read()
    for old, new in reps:
        n = s.count(old)
        if n != 1:
            print("FAIL", rel, n, old[:80]); sys.exit(1)
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print("ok", rel, len(reps))
