import sys
import xml.etree.ElementTree as ET
root = ET.parse(sys.argv[1]).getroot()
for art in root.findall('.//PubmedArticle'):
    pmid = art.findtext('.//MedlineCitation/PMID')
    title = ''.join(art.find('.//ArticleTitle').itertext()) if art.find('.//ArticleTitle') is not None else ''
    journal = art.findtext('.//Journal/ISOAbbreviation')
    year = art.findtext('.//Journal/JournalIssue/PubDate/Year') or art.findtext('.//Journal/JournalIssue/PubDate/MedlineDate')
    affs = set()
    for a in art.findall('.//AffiliationInfo/Affiliation'):
        affs.add(''.join(a.itertext()))
    countries = []
    for a in affs:
        countries.append(a.split(',')[-1].strip().rstrip('.'))
    abst = ' '.join(''.join(x.itertext()) for x in art.findall('.//Abstract/AbstractText'))
    pmc = ''
    for aid in art.findall('.//PubmedData/ArticleIdList/ArticleId'):
        if aid.get('IdType') == 'pmc':
            pmc = aid.text
    print('=' * 100)
    print('PMID', pmid, pmc, year, journal)
    print('TITLE:', title)
    print('AFFIL COUNTRIES:', sorted(set(countries))[:15])
    print('ABSTRACT:', abst[:2500])
