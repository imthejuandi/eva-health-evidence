import sys, re
import xml.etree.ElementTree as ET

src = sys.argv[1]
dst = sys.argv[2]
tree = ET.parse(src)
root = tree.getroot()

out = []
def walk(el, depth=0):
    tag = el.tag
    if tag in ('title',):
        out.append('\n### ' + ''.join(el.itertext()).strip() + '\n')
        return
    if tag in ('p', 'td', 'th', 'caption', 'label', 'article-title', 'kwd'):
        txt = ' '.join(''.join(el.itertext()).split())
        if tag in ('td', 'th'):
            out.append(' | ' + txt)
        else:
            out.append('\n' + txt + '\n')
        return
    if tag == 'tr':
        out.append('\nROW:')
        for c in el:
            walk(c, depth+1)
        return
    for c in el:
        walk(c, depth+1)

walk(root)
text = ''.join(out)
text = re.sub(r'\n{3,}', '\n\n', text)
with open(dst, 'w') as f:
    f.write(text)
print(len(text))
