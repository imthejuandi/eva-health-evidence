import sys, re
import xml.etree.ElementTree as ET
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
src, dst = sys.argv[1], sys.argv[2]
root = ET.parse(src).getroot()
body = root.find(W + 'body')
lines = []
def para_text(p):
    parts = []
    for node in p.iter():
        if node.tag == W + 't' and node.text:
            parts.append(node.text)
        elif node.tag == W + 'tab':
            parts.append('\t')
    return ''.join(parts)
for child in body:
    if child.tag == W + 'p':
        t = para_text(child).strip()
        if t:
            lines.append(t)
    elif child.tag == W + 'tbl':
        lines.append('[TABLE]')
        for tr in child.iter(W + 'tr'):
            cells = []
            for tc in tr.findall(W + 'tc'):
                ct = ' '.join(para_text(p).strip() for p in tc.iter(W + 'p'))
                cells.append(' '.join(ct.split()))
            lines.append(' | '.join(cells))
        lines.append('[/TABLE]')
with open(dst, 'w') as f:
    f.write('\n'.join(lines))
print(len(lines))
