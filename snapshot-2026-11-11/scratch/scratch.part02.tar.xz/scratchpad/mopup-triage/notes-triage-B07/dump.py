import json,glob,sys
fam=sys.argv[1]
led=json.load(open(f'docs/signoff/work/ledger/{fam}.json'))['issues']
want=[i for i in led if i['status']=='physician_question' and i['source']['lens'].startswith('J')]
for i in want:
    d=json.load(open(i['source']['judge_file']))
    print('=====',i['id'],'|',i['source']['lens'],'r',i['source']['round'],i['severity'],'| rounds',i['rounds'])
    print('RES:',i['resolution'])
    found=0
    for k in ('blocking','minor'):
        for it in d.get(k,[]):
            if it.get('family')==fam and it.get('row_key')==i['row_key'] and it.get('check_id')==i['check_id'] and it.get('side')==i['side']:
                found+=1
                print('['+k+']',json.dumps(it,ensure_ascii=False))
    if not found: print('NOT FOUND; summary:',i['summary'])
