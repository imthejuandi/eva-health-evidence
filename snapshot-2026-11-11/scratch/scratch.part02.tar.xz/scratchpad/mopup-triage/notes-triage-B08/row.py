import json,sys
fam=sys.argv[1]; idxs=[int(x) for x in sys.argv[2].split(',')]; fields=sys.argv[3].split(',') if len(sys.argv)>3 else None
p=f'/home/user/eva-health/docs/signoff/work/decisions/{fam}.json'
txt=open(p).read(); lines=txt.split('\n')
d=json.loads(txt)
# line of each final_row start: find occurrences of '"marker_key"' in order within final_rows
starts=[i+1 for i,l in enumerate(lines) if l.startswith('      "marker_key"')]
def ln(s,after):
    key=json.dumps(s,ensure_ascii=False)[1:-1][:60]
    for i in range(after-1,len(lines)):
        if key in lines[i]: return i+1
    return None
def show(k,v,base,ind=''):
    if fields and k.split('.')[0].split('[')[0] not in fields: return
    if isinstance(v,dict):
        for kk,vv in v.items(): show(k+'.'+kk,vv,base)
    elif isinstance(v,list):
        for n,vv in enumerate(v): show(f'{k}[{n}]',vv,base)
    else:
        l=ln(v,base) if isinstance(v,str) and v else ''
        print(f'  {k} (L{l}): {v}')
for i in idxs:
    r=d['final_rows'][i]
    print(f"=== [{i}] {r['marker_key']}|{r['sex']}|{r['age_group']}|{r['physiological_state']} starts L{starts[i]}")
    for k,v in r.items(): show(k,v,starts[i])
