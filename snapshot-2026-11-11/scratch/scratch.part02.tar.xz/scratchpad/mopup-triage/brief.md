# Triage brief: EVA workstream 1 mop-up round (ruling M-10)

You are a triage agent. You read with the judge role, and you wrote and fixed no row of your families. Your families, batch and label are in the message that sent you here.

## Context
EVA is a preventive-health app. A licensed physician will sign each family's optimal levels, ranges and client texts. Judges (lenses J1 to J6) raised issues on the families' rows over earlier rounds; the ledger, docs/signoff/work/ledger/<family>.json, holds them. 530 judge-raised items across 30 families are now in the state physician_question, against a cap of 20 questions for the physician (check G8). Before the round's single pass, each item gets one class, so the fixable ones are fixed now and only real choices reach the physician. You close nothing: a judge-raised item is closed only by the lens that raised it, in the closing pass, or by the final cold panel.

The repository is /home/user/eva-health (read only). The final rulings for the round are in docs/signoff/work/governance/mopup-rulings.md (M-10 is yours); the programme's other rulings are in docs/signoff/work/governance/fable-ws3-decisions.md (D-01 to D-44) and central-fix-decisions.md (CEO-1 to CEO-17).

## Your task
For each of your families, take every ledger issue whose status is "physician_question" and whose source.lens is J1 to J6. Count them first and confirm the count in the message that sent you. Give each exactly one class, with evidence:
- a: already gone in today's files. Give the file, the line and the text you read today in docs/signoff/work/decisions/<family>.json (and what it compiles to, if that matters).
- b: the same subject as an owned item. Link it: an item of /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/ws1-mopup/items.json (built 11 November, before the rulings; its owners may since have changed by the rulings), a ruling (M-nn, D-nn, CEO-nn), a known issue (docs/signoff/work/central/known-issues.md, C-nn), a workstream 3 package (docs/signoff/work/ws3/README.md, WS3-nn) or an Echevarne item.
- c: a defect the files themselves show that the family's fixer can correct without moving a bound, a unit, a grade or a row: wrong arithmetic, a reference to a question that does not exist, a text that contradicts the row's own number, a sentence against wording-rules.md, a Spanish text that does not say what the English says. Write fixer_text exactly: the row, the field, and the change in both languages. An item that would move a bound never goes here.
- d: a choice only the physician can make. Write physician_theme (a short label, reused across items on the same theme) and physician_question in plain words, with the options.
- e: not an issue under the definitions. Quote the sentence of docs/signoff/PLAN.md, docs/signoff/ACCEPTANCE-TEST.md or a governance rule that allows what the judge objected to.
Read what was raised in the judge's own file (source.judge_file) and the issue's evidence_paths; read the decided row as it is now; read the governance rules it touches (docs/signoff/work/governance/wording-rules.md, state-rules.md, critical-limits.json, action-limits.json, and the definitions in docs/signoff/ACCEPTANCE-TEST.md). When you are unsure between d and another class, choose d: never hide a real choice from the physician. When an item is partly fixed, class it on what is left.

Also record observations: anything else you see on these rows that could mislead or harm a client, with file and line. Nothing you see is discarded.

## Output
One file per family: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/<family>.json, following docs/signoff/work/mopup/triage-schema.json exactly. The commit field is the output of git -C /home/user/eva-health rev-parse --short HEAD when you start. Validate your file yourself before you finish: valid JSON, every judge-raised physician question of the family exactly once, no other item, counts that add up.

## Rules
Read only on the repository. Write only your triage files, plus notes under /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-<your label>/ if you need them; delete nothing. No database access. Do not run the acceptance-test runner or the test suites. Change no ledger, decision, verify, research or other file.

Your final message is the return value, short: per family the counts by class, the class d themes with their item counts, the number of observations, and anything you could not class and why.
