# triage-B01a (agent a60e8052c623d5323)

triage-B01a, batch B01, family f03_kidney. Commit read: 2934686. Count confirmed: 46 judge-raised physician questions (J1 21, J3 11, J2 8, J5 6; 15 blocking, 31 minor).

Output: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f03_kidney.json. I validated it myself: valid JSON, the 46 ledger ids each once and no other, schema keys present, counts add up. The schema file was not run through a validator tool.

**Counts by class**
- a (already gone): 8
- b (owned elsewhere): 22
- c (fixer can correct): 5
- d (physician's choice): 11
- e: 0
- Could not class: none.

**Class d themes (7 themes, 11 items)**
- Urea shown against an interval EVA derives from BUN: 4. Covers accepting the derived 21 to 54 mg/dL at all (research question f03-Q08 was never put to him), the rounding gaps against BUN, and the label "laboratory's interval".
- BUN and urea optimal ceiling (grade C band, f03-DQ08): 2. One is all-cause against cardiovascular mortality; the other is whether a reported 16 mg/dL is optimal when the higher-risk quartile starts at 16.0.
- eGFR optimal band at ages 40 to 84 (f03-DQ10): 1. f03-DQ10 has no option that lowers or drops the band for 70 to 84.
- eGFR below 60 at 85 and over, how soon to see a doctor: 1.
- Cystatin C optimal ceiling 0.72 mg/L (f03-DQ06): 1. The share of healthy adults who reach it is not computed, and the client text has no "minority" sentence.
- Pregnancy named as a cause in the kidney below-range texts: 1.
- Kidney questions written in research but not put to the physician: 1. These are the equation (CKD-EPI 2021 or EKFC, already asked under D-28), the reference floor 60 or 75 at 18 to 39, the KDIGO wording check, and the restored ceiling 105.

**Class c (5 fixer items, none moves a bound)**
- Urea reference source arithmetic: 53.6 should be 53.5, in English, Spanish and the notes.
- Citations of questions that do not exist in the decision file (f03-Q02, Q03, Q14, VQ01, VQ03, Q04, Q07, Q08), on the eGFR, BUN and urea rows.
- AL-17 Spanish follow-up drops "risk" ("ecuación de fallo renal") on the three eGFR rows.
- Creatinine exercise rule says most non-collapsed marathon runners were above range; the family's own record f03-E28 does not support that.
- eGFR 85+ change note says "U-shaped with mortality", where f03-E07 reports a non-significant trend.

**Class a (8)**
- Three items on the stale BUN and urea clinical-note sentences (the M-12 items). The sentences are gone from the rows.
- Three items on the September summaries in biomarker-sources.json. The stored B01-r4 compile now generates summaries from the rows. I linked them to C-09, because the fix to compile-sources.js still waits for its review.
- Two S5 items (creatinine 6 mg/dL scoring Elite). WS3-04 withholds the score on any critical value; I read this in longevity-score.ts lines 710 to 715.

**Class b (22), main links**
- K1 patterns (9): workstream 1-K under M-09 and C-13, with f03-JUDGE-11 to 14 and the f03-K1 items. The physician's f03-DQ04 stays in the family file.
- Three figures for the female creatinine share (3): f03-JUDGE-06 and -16.
- eGFR texts that say the app computes none (2): f03-HANDOFF-04 and -06.
- Score (3): WS3-09.
- Grade C given by the fixer, not the verifier (2): f03-JUDGE-02 and -03.
- Change records (2): f03-C21-01 and -04.
- N1 interpolation method (1): C-14.
- "Optimal" label on a row with no band (1): f03-JUDGE-19, WS3-11.

**Observations: 15.** The ones that matter most:
- The urea client messages call EVA's derived limits "the laboratory's reference interval", which will not match the client's own report.
- The creatinine in-range message sends the client to "your eGFR message", but the computed eGFR is shown nowhere until WS3-34.
- f03-HANDOFF-04 to 06 do not name reference_source and its Spanish twin, which also say the app computes no eGFR.
- f03-C21-01 and -02 offer "restore the production value", which would put an optimal band on a class e row.
- The creatinine critical message uses the "today" sentence where the table says "emergency", and the verifier's question on this (f03-VQ04) is in no physician question.
- BUN population shares are stated three ways, as creatinine's are.
- nhanes/n1-resolutions.json does not exist, although two physician questions point to it.

**Three calls worth a second look**
- The three biomarker-sources items are class a on the strength of the stored B01-r4 compile, while items.json of 11 November has them as central "in repair".
- The two S5 items are class a on the code, not on the S5 check, which WS3-22 says does not yet prove the rule.
- For the missing question ids, the J1 item is class c (repair the citations) and the J5 item is class d (put the questions to the physician).

Notes and the build script are in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B01a/. Nothing in the repository was changed.


# triage-B01b (agent a7cc32e564aeecbae)

triage-B01b, batch B01, commit 2934686. Both files are written and pass my own check against the schema (valid JSON, every judge-raised physician question once, no other item, counts add up). Item counts confirmed: f01 15, f04 13.

Files:
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f01_albumin_proteins.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f04_inflammation.json
- Build script (notes only): /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B01b/build.py

| Family | a | b | c | d | e | total | observations |
|---|---|---|---|---|---|---|---|
| f01_albumin_proteins | 0 | 8 | 3 | 4 | 0 | 15 | 9 |
| f04_inflammation | 2 | 6 | 2 | 2 | 1 | 13 | 9 |

**Class d themes, f01 (4 items)**
- Globulin unit, g/dL or g/L: 2 items (D1 from J3, D4 from J2). The register entry DR-2026-09-25-12 is still pending the physician's countersignature.
- Older adults, albumin optimal band at 70 and over: 1 item (C3 from J5). The row says "see PQ-3", but that question exists only in the research file.
- Albumin method (dye) and fixed cut-offs: 1 item (action limit of 35 g/L, from J2). Linked to f01-HANDOFF-02, the methods letter.

**Class d themes, f04 (2 items)**
- Fibrinogen, a critical low limit: 1 item (G7 from J5). The row defers to f04-Q05, which is not among the decision's questions.
- Pregnancy and lactation, what is shown (D-12, M-05): 1 item (N1 on the hs-CRP pregnancy row, from J3). The row is gone; the choice left is M-05's "below 3 mg/L or no interval", with the fact that more than half of healthy third-trimester women are above 3 mg/L.

**Class c (5 fixer items, none moves a bound, unit, grade or row)**
- f01 G2: replace the dangling PQ-1 to PQ-5 references, in English and Spanish where a Spanish field exists.
- f01 E1 (two items): set the follow-up of F01-F07 to 13.1 years and correct "Table 2" to "Table 3" in F01-F06. Both are confirmed in the source cache.
- f04 C2: in F04-DQ-1 mark option (a) as recommended and label option (b) as against PLAN section 4 and D-12. The option is kept, not removed.
- f04 E1: re-attach f04-E12, f04-E13 and f04-E14 to the general hs-CRP row so the pregnancy figures in the method note compile and are quote-checked.

**Class a (2, both f04)**
- E2 on the hs-CRP ceiling (round 1): the quote is confirmed, the sex statement is written and the band rule is stated.
- G6 on the "seed duplicate" sentence: it has been rewritten and now agrees with the compile.

**Class e (1, f04)**
- M2, menstruation not named among the causes: wording-rules section 4 asks for "at least one" benign cause, and the message names six. The suggestion is kept as an observation.

**Class b**: the linked items are in the files (G6 summaries, K1, N1, X1, the in-range zone, Q1 state handling, the fibrinogen class, C-21).

**Nothing was left unclassed, but three calls are weak and you may want to overrule them**
- f01 N1 globulin (J3) is classed b against C-14. C-14 covers unresolved N1 rules, not the fact that N1 has no data for total protein, globulin or the ratio, and no item owns that gap. It is also an observation.
- f04 D4 fibrinogen (J2) is classed b against WS3-27, which names a refused result to the client. No package adds the fibrinogen alias or the g/L factor. It is also an observation.
- f04 G7 is classed d, so its text fix for the dangling f04-Q01, Q02, Q04 and Q05 references sits only in the item's notes and an observation, not in a fixer_text. Add it to the f04 fixer's list by hand if you want it in the round.

**Evidence read outside the repository**: several "still present" and "partly gone" statements rest on the check run and compile of 11 November in the ws1-mopup scratch folder. The G6 items stay class b because the stored compiles in the repository still carry the September summaries.

**Observations worth reading first**
- Research questions dropped on the way to the decision files, while the rows still cite them: F01-PQ-3 and F01-PQ-5; f04-Q01, Q02, Q04, Q05 and Q06.
- The albumin/globulin ratio ceiling of 2.53 is labelled "Echevarne interval" although no laboratory prints it.
- The hs-CRP follow-up above 10 mg/L lacks the standard safety-net sentence.
- F04-DQ-5 asks the physician to sign a fibrinogen summary that the compile no longer publishes.
- The globulin unit change has no workstream 3 package for the app's conversion or for K1.


# triage-B02a (agent a8ffaac77c521c8d0)

triage-B02a, batch B02, family f05_glycaemia. Count confirmed: 35 judge-raised physician questions (J1 9, J2 16, J3 5, J5 5; 34 minor, 1 blocking). All 35 are classed, each once.

Output: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f05_glycaemia.json (commit 2934686). It is valid JSON, its ids match the ledger exactly and the counts add up. The `jsonschema` module is not installed, so I checked the schema's required fields and enums by hand, not with a validator.

**Counts by class**

| Class | Count | What they are |
|---|---|---|
| a | 5 | D2 Embarazo label (the C-12 repair); E2 quotes of f05-E45 and f05-E16 now found in the cache; two L2 items on the table's field names (gone with WS3-18) |
| b | 12 | D-12 ×2, D-20 ×2, central-blocked-02 ×2 (family page), central-blocked-03 (grade C table), M-05/f05-D3-01, M-13, M-04/f05-M1-01, C-28, and the blocking K1 item (f05-JUDGE-03, M-09, WS3-11) |
| c | 5 | see below |
| d | 13 | 11 themes, see below |
| e | 0 | |

**Class c (5 items, 4 edits, none touches a bound)**
- Fructosamine and insulin `notes`: the sentence "this row already shows the laboratory interval only" is untrue of the rows; rewrite it to point to state rule 2.1 (English-only field).
- HOMA-IR above-range text, English and Spanish: drop "without diabetes" / "sin diabetes", which no opened source supports. Two ledger items (J3 and J1) share this one edit.
- HOMA-IR above-range text, English and Spanish: "It suggests insulin resistance" becomes "It can mean that your body needs more insulin… (insulin resistance)".
- `physician_questions`: add the questions the rows and change reasons cite but the decisions file does not hold (f05-Q04, Q05, Q08, Q09, Q10 with L01, VQ1, VQ4).

**Class d themes**

| Theme | Items |
|---|---|
| Rounding to the reported precision before a result is classified (no owner today; D-17 covers critical limits only) | 2 |
| HOMA-IR optimal ceiling of 1.8 at older ages (locked band, grade C) | 2 |
| Insulin uploaded in pmol/L: conversion factor 6.945 or 6.0 (f05-Q09) | 1 |
| HbA1c optimal floor: 4.5% or 5.0% (f05-VQ1) | 1 |
| Fructosamine: follow-up or critical limit for Base Panel clients | 1 |
| Wording for bands that rest on mortality studies, all families (f08-VQ04) | 1 |
| Fasting glucose just below the laboratory floor: how soon to see a doctor | 1 |
| Haemolysed sample: insulin and HOMA-IR | 1 |
| HOMA-IR limits come from a different insulin assay than Echevarne uses | 1 |
| Locked glucose optimal band (74 to 90) against its outcome source (80 to 94) | 1 |
| Glucose and HbA1c in declared pregnancy and lactation (extends D-12) | 1 |

**Observations: 11.** The ones most likely to matter:
- **AL-06 wording differs between row and table.** The table says "another test on the same sample"; the row says "a different test done at the same time". Glucose and HbA1c come from different tubes, and under D-22 the app shows the table's sentence. The correction (f05-VQ2) sits only in the verify file and nothing owns the table edit.
- **Pregnancy and HbA1c of 6.5% or more.** A pregnant client gets no diabetes follow-up anywhere. The J5 item that raised it ended "refuted", and f05-VQ4 is only in the verify file.
- **Nothing between 126 and 400 mg/dL.** One glucose text covers 100 to 399 mg/dL with "in the next few weeks" as its strongest urgency. The 400 or 450 choice (f05-Q04) is only in the research file.
- **HOMA-IR above-optimal text.** It presents 2.05, a cut-off for men, as valid for all adults.
- **"Optimal" label.** Fructosamine, insulin and the HbA1c pregnancy row still read "Optimal" in range until WS3-11.

The rest are a stale code line reference in the insulin text, small Spanish additions ("para confirmarlo"), the missing assay sentence in the method notes, the HbA1c floor meeting its rule only in the less adjusted model, the 5.9% sentence inside the pregnancy in-range text, and row texts that promise fasting and draw-time behaviour the app does not have yet.

**Nothing left unclassed.** Three points for the orchestrator:
- The two rounding items are d only because no work package owns the app change for reference limits; a central item should be opened whatever the physician answers.
- Evidence for the five class a items, and the "still failing" lines in several class b items, cite the 11 November runner result in `ws1-mopup/checks-all.json` (commit ee548ec), which is outside the repository. I did not run the runner.
- The PMID 26121452 quote behind the haemolysis item was not re-opened by me.

Working notes are in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B02a/ (`findings.txt`, `build.py`). No repository file was changed.


# triage-B02b (agent ab0032ad59e56d612)

triage-B02b, batch B02, commit 2934686. Both files are written and validated against the schema (valid JSON, every judge-raised physician question once, no other item, counts add up). Repository untouched.

Files:
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f02_liver_enzymes.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f08_uric_acid_metabolic.json
- Notes and the build script: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B02b/

Counts confirmed against the ledgers: f02 19, f08 18.

| Family | a | b | c | d | e | total | observations |
|---|---|---|---|---|---|---|---|
| f02_liver_enzymes | 7 | 7 | 1 | 4 | 0 | 19 | 6 |
| f08_uric_acid_metabolic | 2 | 8 | 1 | 7 | 0 | 18 | 7 |

**f02 class d themes (4 items, 4 themes)**
- Optimal band at ages 18 and 19 (1): ALP has no band for men aged 18 but the adult band for women aged 18-19 and men aged 19.
- Outcome sentences that rest on mortality studies (1): ALT messages say "liver disease was least common" for studies that counted deaths. This is the pack-wide question f08-VQ04.
- GGT optimal ceiling for men (1): 25 U/L counts as optimal but is the first value of the source's middle tertile, and the ceiling follows cause-specific deaths.
- Laboratory limits printed as '<X' (1): a result exactly at X reads in range in EVA; cross-family with f05 insulin.

**f08 class d themes (7 items, 6 themes)**
- Uric acid optimal floor in older adults (2): the men's item is F08-DQ-4; the women's item has no question today.
- Uric acid optimal ceiling for women (1, blocking): 5 mg/dL rests on one cohort with a median follow-up of 3.6 years. Linked to f08-JUDGE-01.
- Uric acid reference ceiling (1): F08-DQ-2. Linked to f08-N1-01.
- Leptin reference interval for women and men (1): F08-DQ-3.
- Adiponectin results from other laboratories (1): uploads are labelled against Echevarne's ELISA interval while Echevarne's own code is unmapped.
- Pre-analytical advice without an opened source (1): the 48-hour exercise rule appears in a client message.

**Class c (2 fixer items, no bound named as a bound)**
- f02 G2 ggt male: `f02-Q03` is cited in five method notes but is not in the decision's physician_questions. The fix copies it in as F02-DQ-3 and updates the references in both languages. I added a part of my own: the GGT critical_none_reason states the version 3 refusal as fact, and the fix rewords it as a proposal.
- f08 G2 adiponectin female: the same fix for `f08-Q05` (as F08-DQ-5), plus f08-Q03, f08-VQ03, f08-VQ04 and f08-VQ05.
- Both fixer texts contain the phrase "3 x the upper limit" or question ids with digits. The f02 text quotes the refusal multiple, which is not a row bound; if the builder's bound filter trips on it, part (3) of that text needs its own item.

**Judgement calls you may want to overrule**
- Three f08 items (G6 J2, L1 J1, L1 J2) are one defect: `critical-limits.json` line 495 still gives uric acid as "3.7-7 men, 3.1-6 women". I classed them b linked to M-07, but M-07 does not name this field and no item in items.json owns it. It needs adding to the orchestrator's edit; it is also recorded as an observation.
- f08 E3 (women's ceiling, blocking) is classed d, not b. The verifier's re-verdict under f08-JUDGE-01 settles only the grade; the choice of ceiling stays with the physician.
- The f08 N1 uric acid and N1 leptin items are classed d although the judges' remedies are done, because what remains is the physician's answer to F08-DQ-2 and F08-DQ-3.
- The class a items on removed lactation rows rest on the decision files and the stored B02-r2 compile of 8 November; there is no later compile of these families.

**Observations worth acting on**
- Standing questions in the research and verify files (eight in f02, five in f08, plus F02-DQ-1 and F08-DQ-1 on pregnancy) are in no ledger item. If pack assembly reads questions only from the decision file or the ledger, they never reach the physician.
- The ALP row for men aged 18 carries the adult method note, with the 67 U/L ceiling and version 3 text it does not have.
- The inclusive-ceiling pattern recurs: uric acid men at 6.0, women at 5.0, GGT men at 25.
- The stored B02-r2 sources file still has September caveats for uric acid, adiponectin (which uses "mortality") and leptin, and prints f02-E02 and f02-E03 as grade C confirmed. Both are owned (C-09, M-13); check at the next compile.

Nothing was left unclassed.


# triage-B03a (agent aec43198f6bde0a6d)

Triage-B03a, batch B03: both families are classed and both files validate. Counts confirmed against the ledgers: f06_lipids_core 24, f07_apolipoproteins 16, every judge-raised physician question exactly once. Nothing was left unclassed.

Commit read: 2934686. HEAD moved to be70988 while I worked, but no decision, ledger, research, verify or governance file of these families changed in between. Nothing in the repository was touched.

## f06_lipids_core (24)

| a | b | c | d | e |
|---|---|---|---|---|
| 1 | 13 | 2 | 7 | 1 |

- **a (1):** G2. The decisions file exists and records every change the judge listed.
- **b (13):** linked to D-12 (C2 non-HDL), WS3-16 (C2 triglycerides), central-blocked-02 (C3 and definition:age_groups, both waiting on family pages), f06-D30-02 (E3), f06-N1-06 (G6), f06-K1-01 under M-09 (K1), D-16 (L1), M-04 (three M1 items), WS3-20 (P1) and WS3-19 (P2).
- **c (2):**
  - E1 non-HDL: the optimal message says "in genetic studies and clinical trials", while the row's own note says none measured non-HDL. Both languages are written out.
  - E1 total cholesterol: record f06-E26 is cited as "Richardson TG, et al."; the cached PubMed record says Daghlas I, Gill D. The verifier noted it but the record was never corrected. This fix is in the research file, so it needs the evidence pass, which f06 does not have switched on today.
- **e (1):** E4 total cholesterol. The E4 sentence of ACCEPTANCE-TEST.md is met (age statement on f06-E16, physician question F06-DQ-2); the judge's objection is to how much the frozen runner tests.
- **d (7), by theme:**
  - Value exactly at a printed '<' or '>' limit: 2 (D3 on LDL; definition:reference_interval with no row)
  - Older adults (70 and over): keep the optimal bands: 1 (women's HDL)
  - HDL cholesterol in women: the optimal band of 60 to 90 mg/dL: 1 (ceiling 90 against a nadir of 93)
  - Total cholesterol: optimal ceiling of 180 mg/dL for both sexes and all ages: 1
  - Triglycerides: optimal ceiling of 80 mg/dL: 1 (no source states 80)
  - Total/HDL cholesterol ratio: one limit of 5 for both sexes: 1
- **Observations:** 10.

## f07_apolipoproteins (16)

| a | b | c | d | e |
|---|---|---|---|---|
| 0 | 8 | 2 | 6 | 0 |

- **b (8):** linked to D-12 (C2 ApoB), f07-M1-01 with M-04 (D1 and M1 on APOE), C-11 (D2: the Spanish category is still "Genetics"), M-13 (both E2 items), f07-C21-02 (G2) and central-blocked-02 (definition:age_groups).
- **c (2):**
  - D4 Lp(a): the app no longer divides nmol/L by 2.5 (C-18 done), but the method note and a pre-analytical text still describe the conversion as current. Both languages are written out.
  - M4 Lp(a): "Pregnancy can double it" is sourced (f07-E39, "2x increase"), but 2 is missing from explanatory_numbers.
- **d (6), by theme:**
  - ApoA1: Echevarne's interval against published intervals: 2 (upper limit 169 against FINRISK 200; lower limit, which is F07-DQ-1)
  - Value exactly at a printed '<' or '>' limit: 1 (Lp(a) exactly 50; same theme as f06)
  - Lp(a) limit of 50 mg/dL: laboratory interval or guideline decision limit: 1
  - Lp(a): repeat measurement in women (age 50 or the menopause): 1
  - APOE genotype: whether EVA shows it, and with which text: 1
- **Observations:** 10.

Across the two families that is 13 class d items under 10 themes; the printed-limit theme is shared by both.

## Points for the orchestrator

- **APOE is in today's compile against its own row.** The row says it must not enter the seed until f07-VQ01 and f07-Q05 are answered. As compiled, every genotype would read a green "Optimal" above text that links e4 to Alzheimer's disease.
- **f07-M1-01 may not be doable as written.** The round 2 fixer records that the validator requires one reference bound per row; with no bound, the row's only message sits on an unreachable zone. The route (a genotype row with no bound, or non_rows) should be decided before the session.
- **E3 on LDL needs a builder change.** f06-F01 and f06-V01 to f06-V06 have no verifier verdict, so the compiled sources show them ungraded. They must be on the verifier's list for f06, or condition 5 of M-01 blocks it from writing those verdicts.
- **Triglyceride row and signed table disagree.** The row splits AL-11 at 500 with two texts and uses 175 mg/dL for non-fasting; action-limits.json AL-11 has one text for 150 to 999 and says a non-fasting result above 150 "is not classified". No item owns this. The triglyceride entry of critical-limits.json also has no comparison or decimals field yet.
- **Three stored production Lp(a) values** were converted by dividing by 2.5 and are still classified as mg/dL. No item owns them.
- **Negative calculated non-HDL.** If HDL is entered above total cholesterol, the value would read "optimal" once the floor of 0 becomes none under M-04.
- **Stale code references in method notes.** LDL, both HDL rows, triglycerides, ApoB and Lp(a) cite score-engine ranges and line numbers that no longer exist in longevity-score.ts.

## Two judgement calls you may want to overturn

- **Total cholesterol optimal band (f06) is d, not c.** The message sentence "coronary heart disease became steadily more common above about 180 mg/dL" rests on death outcomes, which looks like a wording-rule fix. I left it with the physician because the verifier and the judge read the rule differently and the number itself is in question in the same item.
- **Lp(a) basis (f07) is d.** Changing reference_basis from laboratory interval to decision limit moves no bound, but it changes what N1, D3 and the pregnancy rule do with the row; f06 put the same kind of choice to the physician in F06-DQ-3.

Files are in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage:
- f06_lipids_core.json
- f07_apolipoproteins.json
- notes-triage-B03a/ (build scripts and judge extracts)


# triage-B03b (agent aa3211e1ed49996fe)

triage-B03b, batch B03, family f27_lipoprotein_subfractions: all 26 judge-raised physician questions classed (count confirmed: 26; 25 minor, 1 blocking).

Output: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f27_lipoprotein_subfractions.json

Validation: valid JSON, each of the 26 ledger ids exactly once, no other item, counts add up, and class c/d fields are present only where required. The `jsonschema` module is not installed, so the schema was checked by hand against triage-schema.json, not by a validator.

Commit read at start: 2934686. HEAD moved to cc5c254 during the run; no f27 decision or ledger file and nothing under governance or central changed between the two.

**Counts by class**

| Class | Count | What |
|---|---|---|
| a | 1 | J3 G2 (no decision file): the file now exists with 12 change records and G2 passes |
| b | 8 | See below |
| c | 4 | See below |
| d | 12 | Six themes, see below |
| e | 1 | J5 physiological state: PLAN.md section 4 and state-rules.md 3.3 and 4.2 put no state flag or state pass on these rows |

**Class b links (8)**
- **C-09** (2): the two stale September caveats in the compiled sources (ldl_small, ldl_particle_number).
- **f27-JUDGE-08** (2, including the one blocking item): in-range values of class e rows shown as "Optimal" (WS3-11, WS3-12, D-14). Still present in zone-classifier.ts today.
- **f27-JUDGE-07** (2): no family page or written age policy (C3 and J1 age groups).
- **D-12** (1): pregnancy. All six rows have basis population_study, so the value is shown with no interval.
- **M-10** (1): the G8 cap and consolidation of questions.

**Class c fixer items (4)**
- **ldl_peak_size, method_note (EN and ES) and the unit change reason:** remove the "Å converts by dividing by 10" sentence. It contradicts the same note's "different quantity, values only", and the app has no Å factor.
- **ldl_medium and ldl_small, reference_source (EN and ES):** "about the 30th percentile" becomes 33rd and 31st, to match the file's own change reasons and the arithmetic.
- **hdl_large, rcv.source (English-only field):** the 6% precision is for total HDL-P, not the large subclass, so no RCV figure is given.
- **ldl_particle_number, rcv.narrow_band_justification (English-only field):** null replaced by a text with no numbers; linked to f27-HANDOFF-01.

No fixer text names or moves a bound.

**Class d themes (12 items, 6 themes)**

| Theme | Items | Link |
|---|---|---|
| LDL pattern row: retire or keep | 4 | CEO-14, f27-Q05 |
| LDL size: display name | 2 | f27-Q06; no owner for the rename |
| Liposcale-only rule for uploaded results | 2 | f27-Q07; fasting and capillary parts are owned by D-20, D-21, WS3-20 |
| LDL particle number: optimal ceiling (grade C) | 2 | f27-JUDGE-01 |
| LDL particle number: the bounds above age 70 | 1 | f27-JUDGE-07 |
| Liposcale subfraction limits: flag against a quartile, or show the value only | 1 | f27-JUDGE-05 |

**Observations: 12** (11 on the rows, 1 housekeeping). The ones that matter most:
- **Name matcher:** J2's round-2 finding was merged into J1's P1 ledger id and has no item of its own. Liposcale report lines such as LDL-TG, VLDL-C and LDL-P match LDL or HDL cholesterol and could be stored as such. I did not re-run it today.
- **Method recording:** no ruling, package or known issue owns recording the analytical method of an upload, while every row's client text promises "Liposcale only".
- **Unconfirmed claim in messages:** three rows say "your laboratory's Liposcale report" sets the limit, which f27-Q01 still asks to confirm on a real Echevarne report.
- **Basis field and pregnancy:** under D-12 the reference_basis field decides whether a cardiovascular target is shown as the interval in pregnancy.
- **Physician questions:** the decision file's physician_questions is empty; the eleven question texts live only in the research and verify files.
- **Others:** inconsistent age flags in the row notes, a copied medication note on the size row, and J5's proposals on menopause and oral contraception (kept from the class e item).

**Could not class:** none. Three were judgement calls, taken as d under the "when unsure" rule:
- The display-name pair: the row has no name field, so no fixer can change it.
- The method-gate pair: partly owned, classed on what is left.
- E4: the judge's source is in no evidence record, so the files show no fixer defect.

**Housekeeping:** I first wrote one notes file one level too high in mopup-triage/ and moved it at once into notes-triage-B03b/. Nothing was deleted and no repository file was touched. The build script for the triage file is /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B03b/build_f27.py.


# triage-B04 (agent abe5ad726a37bf59c)

Triage B04 is done: all 49 judge-raised physician questions are classed, each exactly once (f09 36, f10 6, f11 7, matching the expected counts). Nothing was left unclassed, but six items are class b on a loose link and need your decision (below).

The files are valid JSON with matching ids and summing counts; I checked them against the schema by hand because `jsonschema` is not installed. Commit read: `2934686`. HEAD moved to `be70988` while I worked; that commit touches only app source (15 files under `src/` and a migration), none of the files I read.

## Counts by class

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f09_red_cells | 6 | 15 | 4 | 11 | 0 | 36 | 8 |
| f10_red_cell_indices | 2 | 3 | 0 | 1 | 0 | 6 | 4 |
| f11_platelets | 3 | 2 | 1 | 1 | 0 | 7 | 5 |

The one blocking item (f09 K1, haemoglobin against haematocrit) is class b, linked to f09-JUDGE-01 under M-09.

## Class d themes

**f09 (11 items, 6 themes)**
- Haemoglobin limits in declared pregnancy and lactation: 3. Pregnancy: 11.0 g/dL throughout or limits by trimester. Lactation: 12.0 or Echevarne's 11.5. This extends the D-12 question.
- Haemoglobin optimal band, class and grade: 2. One cohort, reverse causation not described, graded B; and the women's floor under 60.
- Haematocrit ceilings 52% and 48% in place of Echevarne's 55% and 51%: 2. The guideline text was never opened; the figures come through two secondary papers.
- WHO anaemia cut-offs, age scope and adjustment for altitude and smoking: 2.
- Thalassaemia trait wording: 1. "Harmless" against the reproductive point; state rule 6.3 itself says "benign".
- "The laboratory's interval" wording on uploaded reports: 1.

**f10 (1 item)**
- RDW limit until Echevarne confirms what its IDH line measures (the family's F10-DQ-1).

**f11 (1 item)**
- Platelet follow-up limits that are not in the action-limits table.

## Class c items (5)

- **f09 M3:** drop "so it is not anaemia" / "así que no es una anemia" from the below-optimal message of the two general haemoglobin rows.
- **f09 P1:** add "trans men" to the testosterone note on eight rows.
- **f09 P2:** the draw-time note says variation is "less than the gaps between EVA's limits", which contradicts the row's own RCV of about 8%; ten rows.
- **f09 E1:** evidence pass. Remove the stale links from f09-E25 to the upper limit of the two haematocrit state rows and link f09-E30 instead.
- **f11 E1:** evidence pass. Record f11-E21 quotes 20,000 but is linked to the low critical limit of 30,000; remove that link and the links to the removed pregnancy row.

No fixer text moves a bound, unit, grade or row. Two things the builder should know:
- The two evidence-pass texts have to name which limit a `supports` link points to ("upper reference limit", "low critical limit"). If the builder refuses on such words, they need a manual pass.
- f11 has no evidence pass in `items.json` today, so its class c item needs one added.

## Decisions for you

- **Six class b items have no item that owns the actual work.** I linked each to the nearest owner and said so in its notes and in the observations.
  - f09 G6 and f09 L1 are linked to M-07. `critical-limits.json` lines 275 and 339 still give the reference intervals as 12-15.5 for women's haemoglobin and 150,000-450,000 for platelets. M-07's edit list does not name the `eva_reference_interval` field.
  - Four N1 items (f09, f10 twice, f11) are linked to C-14. Nobody is listed to add the NHANES blood-count variables to the distributions generator, so N1 says nothing on seven of the nine B04 markers.
- **Two class d items may not be the physician's to answer.**
  - The uploaded-reports wording could be ruled centrally in `wording-rules.md`.
  - The platelet follow-ups could become a table edit drafted by you, as M-08 did for neutrophils.
  I classed both d because nothing owns them and a client can be misled.
- **f09 E3 is a judge-challenged grade B on a single source**, like the f06 and f08 rows the builder already sends to the verifier's re-verdict list. Adding the two general haemoglobin rows there would let the verifier confirm or lower the grade before the physician reads it.

## Observations most worth reading

- **f11, line 117:** one below-range message calls every platelet count from 30,000 to 129,999/µL "mildly low" with a "harmless cause" and the "next few weeks" urgency. The follow-up below 100,000 is shown nowhere, and the family asks the physician no question about it.
- **f09, lines 452 and 1014:** the pregnancy above-range texts name pre-eclampsia and say "sooner if you have a headache, changes in your vision or new swelling" under a "next few weeks" sentence.
- **f09 K1:** the text-only remedy (the haematocrit below-range message deferring to haemoglobin, as the red-cell rows already do) may be lost now that K1 is out of the round.
- **f10, line 380:** "below the upper limit the laboratory prints (22%)" is untrue for the uploaded reports that are the only source of blood counts today.

## Files

- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f09_red_cells.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f10_red_cell_indices.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f11_platelets.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B04/build.py (the script that wrote the three files)

One stray scratch dump, `notes-triage-B04-judges.txt`, sits directly in the `mopup-triage` folder instead of the notes folder; I left it because the brief says to delete nothing. Nothing in the repository was changed.


# triage-B05 (agent a9da2c5c06b5a0738)

triage-B05, batch B05: all 41 judge-raised physician questions classed (22 + 7 + 12, matching the expected counts); nothing left unclassed. Files validated by hand against the schema (no jsonschema module here): valid JSON, each ledger id once, counts add up.

Commit read: 2934686 at start. HEAD moved to cc5c254 during the run (WS3-35 merge); of the files I used only `docs/signoff/work/ws3/README.md` changed, and no class depends on it.

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f12_white_cells_core | 2 | 11 | 5 | 4 | 0 | 22 | 10 |
| f13_white_cells_other | 0 | 6 | 1 | 0 | 0 | 7 | 5 |
| f14_iron | 2 | 7 | 0 | 3 | 0 | 12 | 6 |
| All | 4 | 24 | 6 | 7 | 0 | 41 | 21 |

**Class d themes (7 items, 5 themes)**
- f12, "White blood cell count: optimal band (floor, ceiling and the ages it covers)": 1 item. Joins F12-DQ-3 and F12-DQ-4.
- f12, "NLR: optimal band, and whether it holds at older ages": 1 item. The 2.0 ceiling from 75, where the typical ratio is already 2.0 or more.
- f12, "Duffy-null benign variant: message wording and the score": 2 items.
- f14, "Oral oestrogen note on TIBC and serum iron": 1 item.
- f14, "Transferrin saturation: basis and values of the reference limits": 2 items (J1 and J3 on the same row). Restates f14-Q02 and VQ-f14-01.

**Class c (6 fixer items, all text only)**
- f12 lymphocyte percentage, below-range message: add that a lower percentage is more common at older ages. Two ledger items (J5 M2, J1 N1) carry the same change; make it once.
- f12 F12-DQ-4: the stale N1 figure 61.8% becomes 63.6%. English only, as the question has no Spanish field.
- f12 NLR method note, four rows: add the Rotterdam paper's statement that samples were stored at −80 °C, which is in the cached source.
- f12 women's white cell count, above-optimal message: add pregnancy.
- f13 eosinophil count, above-range message: one sentence on why EVA's 500/µL differs from the 575/µL the laboratory prints, plus 575 in explanatory_numbers.

**Judgement calls you may want to overrule**
- Two b links are loose and need a central item, since the rulings do not name the field. Both are also observations:
  - `critical-limits.json` lines 372 and 403 still read "3,800-? women" and "1,710-? women"; linked to M-07.
  - AL-14.1 and AL-14.2 still say "a (ANC is scored)" (`action-limits.json` lines 2132 and 2201); linked to f12-TABLE-01 / M-08.
- Four b items point to the Echevarne methods letter (launch-track L4): the three f13 "<X" limits and the f14 ferritin limit of 31. The flagging rule is not yet in the letter's list. Echevarne's own HL7 training message flags a value equal to a "<X" limit as high, while EVA reads it as in range.
- The f12 Duffy wording item (J5 M2 on neutrophils) is d, not c. Adding "does not raise infection risk" to a message also shown at 500 to 999/µL would conflict with M-08 point 3.
- The f12 C3 item is d, not b (family pages), because the band's extrapolation to women under 50 and to 85 and over is a real choice.
- The f13 L2 item (family-added action limits not in the table) is b linked to D-22, not e.

**Observations worth reading first**
- f12: the low-neutrophil message reassures with the benign-variant line across 500 to 999/µL.
- f12 and f13: action limits that sit inside the interval, or only on rows, never reach the client. Example: lymphocytes below 1,000/µL read "in range".
- f12: critical row texts say "under" and "over", against D-17's "at or".
- Check E1 accepts any digit in a quote as "the number"; no item covers it.
- N1 has no data for the white-cell differential or the iron markers; no item adds them.
- f14: 46.1% of healthy men under 53 fall below the 20% TSAT floor, and no check reports it.

Files are in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/:
- f12_white_cells_core.json
- f13_white_cells_other.json
- f14_iron.json
- notes-triage-B05/build.py (the generator; also holds judge-entries.txt and row dumps)


# triage-B06 (agent a958be21b50525cb5)

Triage-B06 is done: all 39 judge-raised physician questions are classed, each exactly once (f15 13, f16 6, f18 20 — the expected counts). Commit read: 2934686. The files are valid JSON and pass my own checks (ids, lens and severity match the ledger; counts add up); `jsonschema` is not installed, so the schema was checked by hand against the required fields and enums. The repository is untouched.

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f15_thyroid | 7 | 3 | 0 | 3 | 0 | 13 | 7 |
| f16_bone_mineral | 0 | 1 | 1 | 4 | 0 | 6 | 6 |
| f18_electrolytes | 1 | 12 | 1 | 6 | 0 | 20 | 8 |
| **Total** | 8 | 16 | 2 | 13 | 0 | 39 | 21 |

**Class d themes (13 items, 7 themes)**
- **Results uploaded from other laboratories** — 4 items: f15 thyroglobulin antibodies, f16 PTH (with the unmapped Echevarne code D0151), f18 chloride, f18 plasma potassium. One shared question, linked to D-39.
- **Magnesium optimal floor (grade C band)** — 4 items, all f18: E3 (J1), N1 (J5), optimal band (J2), and the 18-19 policy (J2). One shared question.
- **TSH upper limit in older adults** — 1 (f15).
- **Result exactly at a printed '<x' cut-off** — 1 (f15, TPO at 13.8).
- **Vitamin D floor (locked decision)** — 1 (f16); a change needs a CEO decision under PLAN.md section 2.
- **PTH in older adults** — 1 (f16).
- **Calcium critical low and symptoms** — 1 (f16).

**Class c (2 fixer items, texts written in both languages)**
- **f16 calcium method note:** the sentence "the seeder keeps row 161 and row 100 should be removed at compile" contradicts the compile, as the file's own notes say.
- **f18 sodium pre-analytical note:** "on average 6.1 mmol/L lower when total protein was above 79 g/L" is reworded without the average.

**Items I could not class cleanly**
- **f18 D4 (mmol/L refused for sodium, potassium, chloride):** classed b against the WS3-13 follow-up, the nearest owner. No package actually lists the identity rule mmol/L = mEq/L as work to do, so a workstream 3 item is needed.
- **f18 G6 sodium (exactly 120):** classed b against D-17 and M-08 point 4. M-08 names only potassium 6.0 and bilirubin 15, so the builder must add the sodium row's comparison words and AL-10's condition to the fixer's list.
- **f15 D3 at age 20 (J1):** classed b against f15-D3-01 to -03 (re-cut to 18-20 and 21+). The decision file's own question f15-Q09 recommends the opposite, and Echevarne has not said which band it prints at 20.
- **Three f15 D3 items classed a (18-19 messages):** the quoted sentence is gone today, but the replacement "From age 20, EVA compares…" becomes untrue once the rows are re-cut.

**Observations that matter most**
- **Questions may not reach the physician:** the f16 decision file's `physician_questions` list is empty and f18's holds only two, while the research and verify files hold the rest (f16-Q02/Q03/Q05/Q06, VQ-f16-01 to -04, f18-Q03/Q05, VQ-f18-04/06).
- **Unit refusal skips the critical check:** an uploaded potassium or sodium in mmol/L is refused as a unit mismatch, and a refused value is never compared with a critical limit.
- **Potassium exactly 5.5:** AL-09b's machine fields say "above 5.5" while its text says "at or above", so 5.5 gets neither follow-up if rendered from the fields.
- **Critical comparison words are strict on five more limits** (sodium, magnesium, potassium low, calcium low) than the two M-08 names.
- **Magnesium critical messages** say the limit is "set by EVA's responsible physician" while the signed table has no magnesium entry yet (M-07 pending).
- **Vitamin D below-range message** cites only the reassuring half of the UK study; the row's own notes cite its higher cardiovascular mortality at 20 to 29 ng/mL.
- **Stale class labels in `action-limits.json`:** AL-08 says class a (TSH is c); AL-09 and AL-10 say "e pending family f18" (rows are c).

Files are in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage:
- f15_thyroid.json
- f16_bone_mineral.json
- f18_electrolytes.json
- notes-triage-B06/build.py


# triage-B07 (agent a1fb98940fe882771)

triage-B07 (batch B07), read at commit 2934686. All 47 judge-raised physician questions are classed, each exactly once; the expected counts are confirmed (f17 12, f25 20, f26 15). The three files are valid JSON and pass my own check against the ledger ids, lens, severity, counts and class-specific fields; the `jsonschema` package is not installed, so the schema was checked by hand. Nothing in the repository was changed. HEAD moved to be70988 while I worked.

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f17_b_vitamins | 2 | 1 | 2 | 7 | 0 | 12 | 7 |
| f25_trace_minerals | 3 | 6 | 6 | 5 | 0 | 20 | 7 |
| f26_other_vitamins | 0 | 7 | 4 | 4 | 0 | 15 | 6 |
| All | 5 | 14 | 12 | 16 | 0 | 47 | 20 |

**Class d themes (16 items, 11 themes)**
- Oral oestrogen note (state rule 4.2), markers to add to the list: 3 (f25 copper twice, f26 vitamin B6)
- Pregnancy and breastfeeding, exceptions to the interval-only rule (state rule 2.1): 2 (f17 active B12; f17 total B12, which is F17-DQ-01)
- Follow-ups the families added that are not in the signed action-limits table: 2 (f17 homocysteine above 30 µmol/L; f17 active B12's in-range "soon" sentence)
- Unit shown for a marker, and uploads printed in another notation of the same unit: 2 (f17 folate; f26 vitamins K1, A and C)
- Older adults, one adult limit at every age: 1 (f17 homocysteine)
- Serum MMA, the published age limits or one limit for 40 to 69: 1 (f17)
- Selenium, no lower limit so no low value is ever flagged: 1 (f25)
- Medicine names as possible causes in client messages: 1 (f25 copper "valproate")
- Urine iodine, classify one sample on WHO's group criteria or show the value only: 1 (f25)
- Vitamin C lower limit, the laboratory's 5 mg/L or a guideline deficiency cut-off: 1 (f26; the confirmed blocking item, which is f26-DQ01)
- Vitamin B6 lower limit, 20 or 30 nmol/L: 1 (f26)

**Items that fit no class cleanly**
- **The two unit items (f17 folate D1, f26 vitamin K1 D4).** They are real and unfixed, the fix moves a unit or is app code, and I found no owner in items.json, known-issues, the workstream 3 packages or the rulings. I classed them d with a plain question, but they are mostly engineering: the orchestrator should open a central or workstream 3 item for them.
- **f26 E3 (records f26-F01 to F15 carry only author-proposed grades).** Classed b against f26-D30-01, but that verifier item covers the vitamin C row only, at "texts only" depth. Its scope needs widening, or the pack must label the records as ungraded.
- **f26 G6 (CHANGES.md counts ×10 unit rescales as tighten or loosen).** Classed b against C-03, the nearest owner; no known issue names this rule.

**Class c points the builder should know**
- **f25 now has six fixer items**, so under M-10 it joins the round fully, not only for the verifier step.
- **f17 gains two fixer items** where it had none. One is a research-file citation fix (f17-E35: the authors are Refsum et al., not Morkbak; the cached PubMed record confirms it), which belongs to the evidence pass.
- **Three fixer texts quote a printed figure inside a sentence** (selenium "<150", iodine "≥300", the vitamin C note). No bound moves, but the builder's "names a bound" filter may trip on them.
- **Two f25 fixer texts rest partly on sources I could not open.** The exact copy of WHO Table 1 for iodine and the MASHAD age range of 35 to 65 for copper are the judge's readings; each text tells the fixer to confirm before writing.
- **I verified the f26-F15 ages** by fetching the Europe PMC full text today; the repository's cached copy does not contain them.

**Observations most worth a central item**
- **Results with no unit:** `canonical-units.ts` line 146 lets a result with no unit pass the unit check. After the ×10 unit change of vitamins A and C, a unitless result in the old unit would read falsely "below range".
- **Row-level follow-ups missing from the table:** total B12 below 350 pg/mL and active B12 below 70 pmol/L are not in `action-limits.json`, and total B12's in-range text carries the same "soon" sentence as active B12 with no ledger item.
- **Two B12 codes:** D0099 and B1618 both map to `vitamin_b12` with no de-duplication.
- **Pre-analytical rules the app does not have:** the zinc draw-time and haemolysis rules and the vitamins' fasting rules describe behaviour that waits on WS3-20.
- **Static "recorded in your context" wording:** the B1 and B6 below-range texts say "medicines recorded in your context" to every client.
- **Amiodarone:** the iodine above-range text names it, the same question as valproate.
- **f26-F15 basis class:** it has the same wrong class as F12 to F14.

Files are in /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage:
- f17_b_vitamins.json
- f25_trace_minerals.json
- f26_other_vitamins.json
- notes-triage-B07/ (working scripts and dumps)


# triage-B08 (agent adf045702debf96e8)

Triage B08 (label triage-B08) is done: all 60 judge-raised physician questions are classed, each exactly once, and nothing was left unclassed. Counts confirmed against the ledgers first: f19 24, f20 30, f21 6.

Files (each parses, covers its ledger ids exactly, and counts add up; `jsonschema` is not installed, so I checked required fields, enums and lengths by script instead):
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f19_male_hormones.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f20_female_hormones.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f21_adrenal_growth.json

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f19_male_hormones | 1 | 14 | 3 | 6 | 0 | 24 | 8 |
| f20_female_hormones | 1 | 12 | 5 | 11 | 1 | 30 | 9 |
| f21_adrenal_growth | 1 | 2 | 0 | 3 | 0 | 6 | 4 |

**Class d themes (20 items, 13 themes; two themes span families)**
- f19:
  - Free testosterone: EVA interval, method gate or value only (2)
  - Free testosterone by age and menopause (2)
  - Women's total testosterone action limit after 50 (1)
  - Oral oestrogen: extend the list of state rule 4.2 (1; shared with f21)
- f20:
  - Markers that reach EVA only from other laboratories (3; shared with f21)
  - AMH at 46 and over (2)
  - Women with no cycle day: no-phase rows against state rule 5 (2)
  - AMH at 18 to 21 (1)
  - Pregnancy and lactation: sex hormones shown as a value only (1)
  - Luteal progesterone lower limit and the luteal cycle days (1)
  - Postmenopausal estradiol by immunoassay (1)
- f21:
  - DHEA-S at 19 to 21 (1)
  - Oral oestrogen: extend the list of state rule 4.2 (1)
  - Markers that reach EVA only from other laboratories (1)

Most d items point to a question the family already wrote. Several of these sit only in the research or verify files (PQ-f20-03, -04, -06, -07, -09, -11; f19-Q02 to Q04; f21-Q03, Q04), so pack assembly has to carry them from there.

**The five blocking items are all class b**, each the exact source key of an owned item: f19 K1 ×2 (f19-JUDGE-01, f19-JUDGE-02; ruling M-09), f20 luteal cycle days (f20-JUDGE-02), f20 "Optimal" label on class d rows ×2 (f20-JUDGE-06, f20-JUDGE-07).

**Class c (8 fixer items, none moves a bound):**
- f19:
  - Move a supports link: f19-E32 should support the women's total testosterone 50+ row, and f19-E30 should not.
  - Reword "No NHANES distribution exists for check N1" on the 12 total testosterone and SHBG rows.
  - Label the fasting rule on the four women's rows as extended from guidelines written for men.
- f20:
  - Add the age-20 overlap sentence to the prolactin 21+ method note.
  - AMH 46+ messages say "based on population studies" while the row's own source field says no source states 1.5.
  - AMH messages say "other hormonal contraception" where the source covers the pill and the ring only.
  - "Spans the whole menstrual cycle" is false on the progesterone 18-20 and 21+ rows.
  - The same sentence is false on the 18-20 rows of estradiol, FSH and LH.

**Judgement calls to check**
- **FSH/LH labelled mIU/L (f20 D4):** classed b against the new package WS3-38, whose text does not name FSH or LH. If you would rather have the physician decide, the item's notes carry the question.
- **Free Androgen Index bands (f19):** classed b against WS3-34, the nearest package. No owned item actually removes the optimal bands from the seed's calculated-metrics block; it is in the observations as needing its own central item.
- **Prolactin 21+ upper limit (f20 N1):** the one class e. The row copies Echevarne's interval and the judge's own estimate is about 12% outside, inside N1's 2 to 15%.
- **Two N1 items in f19 on the same subject:** split on purpose, one c (the row sentence) and one b (C-14, NHANES coverage in workstream 1-K).

**Observations most worth acting on**
- F20-DQ-02 asks the physician to accept an interim "until the app reads the menopause status"; since WS3-14 the app does read it, so the question is out of date.
- With the merged picker, a woman under 50 with no cycle day will be classified on f20's no-phase rows once seeded, against state rule 5.
- The f19 postmenopausal SHBG row's below-range message names PCOS (same defect as the one fixed on DHEA-S 61+); no ledger item covers it.
- The four family action limits (testosterone ×3, FSH) are in the rows but in no table; no item adds them to action-limits.json, which has 17 of 20 source entries used.
- items.json f20-D3-01 tells the fixer to cut the estradiol ovulatory row by age, but the D3 failure is the label the compile writes.
- No verifier item names evidence records f19-F01 to F09, which carry the fixer's proposed grade C.
- The cortisol row should not go live before WS3-20: until then an afternoon sample gets the low-morning-cortisol message.

**Commit:** the files record 2934686, the commit at start. The branch moved to be70988 while I worked (WS3-35 merge, WS3-37 and WS3-38 added). None of the decision, ledger, governance, research or verify files I read changed. ws3/README.md line numbers in the evidence are marked "at 2934686". The one citation of `src/lib/biomarkers/row-gate.ts`, a file that arrived mid-triage, also gives the equivalent lines in `process-results.ts` at the start commit.

I wrote only the three triage files and notes under /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B08/. Nothing in the repository was changed, and I did not run the acceptance-test runner or any test suite.


# triage-B09 (agent ab49abef8f5592fc1)

triage-B09, batch B09: all 49 judge-raised physician questions are classed, each exactly once (f22_prostate 15, f28_autoimmunity 11, f29_cardiac_toxins 23, matching the expected counts). Nothing was left unclassed, but three class c items need the verifier, not the fixer (see below).

Files (valid JSON, counts add up, checked by script against the schema's required fields and enums; the `jsonschema` package is not installed, so no formal schema run):
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f22_prostate.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f28_autoimmunity.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f29_cardiac_toxins.json
- Generator and notes: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B09/build.py

The commit field is 2934686, HEAD when I started. HEAD moved to cc5c254 during the work (WS3-35 merge); `git diff --stat` shows no change to the decisions, ledger or governance folders between the two.

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f22_prostate | 0 | 9 | 2 | 4 | 0 | 15 | 6 |
| f28_autoimmunity | 0 | 3 | 2 | 6 | 0 | 11 | 5 |
| f29_cardiac_toxins | 0 | 9 | 5 | 7 | 2 | 23 | 7 |

**Class d themes (17 items, 8 themes)**
- **Exact-limit convention** (a result equal to a printed '<X' or '>=X' limit): 4 items. f22 has 1 (PSA '<4' from 70); f29 has 3 (lead '<5', NT-proBNP '<125', mercury 14.9 standing for 15).
- **PSA from age 70** (limit, stopping sentence, urgency): 2 items, f22.
- **PSA below the ages at which the guideline offers testing**: 1 item, f22.
- **ANA titer and rheumatoid factor, one limit for women and for adults over 60**: 4 items, f28.
- **ANA rows** (keep the encodings, hold them, or retire them): 2 items, f28.
- **NT-proBNP** (ceilings, heart-stress limits and urgency by age): 2 items, f29.
- **Blood lead** (critical limit at 80 µg/dL, and pregnancy): 1 item, f29.
- **Blood mercury** (limit used while the German HBM values are under revision): 1 item, f29.

**Class c (9 items)**
- **f22:**
  - free-PSA text gains the assay caveat;
  - the above-range texts of the three PSA rows for 18 to 69 gain a sentence that the laboratory report prints '<4', and 4 is added to `explanatory_numbers`.
- **f29:**
  - lead above-range text gains the pregnancy sentence the mercury row already uses;
  - lead in-range text changes "below 5" to "up to 5";
  - both NT-proBNP above-range texts drop the unsourced "heart specialists use a value above this level";
  - mercury in-range text names both HBM values;
  - f29-V01 gets a verifier verdict.
- **f28:** two items, both the missing verifier verdict on f28-VE01.

**Class e (2 items, f29)**
- The hormone-therapy note on NT-proBNP: state-rules.md 4.2 lists the rows that carry the note, and NT-proBNP is not one.
- "48 hours" of hard exercise: it is the standard benign cause in wording-rules.md section 4.

**Class b links**
- M-13: 3 items
- M-08: 2 items
- WS3-29: 5 items
- WS3-11: 1 item
- C-14: 1 item
- M-10: 1 item
- central-blocked-02: 2 items
- Fixer or workstream 3 items in items.json: f22-E1-01, f22-M1-01, f22-JUDGE-02, f28-E1-01, f29-E1-01, f29-JUDGE-01

**Points for the orchestrator**
1. **Three class c items are for the verifier stage.** f28 E1 and E3 on ana_titer and f29 E3 on lead are the same defect: f28-VE01 and f29-V01 were written by the verifier and have no `evidence_verdicts` entry, so the compile publishes them with grade null. A fixer may not write the verify file or assign a grade. No owned item covers this pattern, and the judges' own texts name it on f06-F01 and f12-V03 too. If the builder turns class c into fixer items automatically, these three need re-routing.
2. **I could not test the builder's refusal rule.** Several `fixer_text` entries quote numbers (5 µg/dL, 15 µg/L, 4 ng/mL) while changing wording only; build-items.cjs does not yet have the "names a bound" rule.
3. **The free-PSA floor may not be removable by the fixer.** Two class b items point to f22-M1-01 and f22-JUDGE-02 (set the floor to none). The f22 fixer's own notes say row-checks.js line 65 rejects a row with no reference bound, so this may need the central route (families.json `non_rows`, CEO-14).
4. **Family-added action limits have no table entry.** RF above 42 IU/mL, mercury above 5 µg/L, NT-proBNP 300 ng/L from 75 and the extra PSA limits are on rows only. WS3-29 renders from the generated action-limits table, so these never reach a client unless the table or generator takes them in.
5. **The ANA encodings are a release hazard.** If applied before the upload reader and values-only rule exist, a negative report written '<1/80' can show "Your ANA test is positive". No workstream 3 package is named for it.
6. **The families' own physician questions are in no page the physician reads.** The texts of f29-Q01 to Q04 and f29-VQ01 to VQ03 sit only in the research and verify files; the questions page holds just the ledger list. I did not open the f22 and f28 pages, but their questions also sit in the research and verify files.

The other observations, each with file and line, are in the three files.


# triage-B10 (agent a62a4518070f12c12)

Triage B10 (label triage-B10) is complete: all 33 judge-raised physician questions are classed, each exactly once, and nothing was left unclassed. The counts matched the message (f23 10, f24 4, f30 19). Commit read: 2934686. The files are valid JSON and pass my own checks (ids, lens and severity match the ledger; counts add up); the `jsonschema` library is not installed, so the schema was checked by hand against its required fields.

Files:
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f23_omega3.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f24_omega6_ratios.json
- /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/f30_urine_pancreas_bilirubin.json
- Notes and the build script: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-triage/notes-triage-B10/

| Family | a | b | c | d | e | Total | Observations |
|---|---|---|---|---|---|---|---|
| f23_omega3 | 0 | 3 | 4 | 3 | 0 | 10 | 7 |
| f24_omega6_ratios | 1 | 3 | 0 | 0 | 0 | 4 | 4 |
| f30_urine_pancreas_bilirubin | 2 | 9 | 0 | 8 | 0 | 19 | 10 |

**Class d themes**
- **Total omega-3: optimal floor of 4% (grade C):** 2 items (f23), linked to f23-JUDGE-01.
- **Uploads on another method or specimen (D-39):** 2 items (1 in f23, 1 in f30).
- **Pregnancy: exceptions to state rule 2.1 (D-12):** 1 item (f30).
- **Result exactly at a laboratory limit printed as '<x':** 2 items (f30).
- **Amylase and lipase: follow-up at 3 times the upper limit and pain wording:** 2 items (f30).
- **Total bilirubin: Echevarne's lower ceiling from age 90:** 1 item (f30).
- **Total bilirubin on the twice-yearly test list:** 1 item (f30).

**Class c**
- All four fixer items are in f23 and change texts or notes only: the contraceptive-pill wording on DHA ("may raise"), two notes on the total omega-3 and EPA rows, and the DPA clinical note. No bound, unit, grade or row moves.
- f23 is listed `in_round: false` in items.json; under M-10 these four items bring it into the round.
- The builder's rule for refusing a class c text that "names a bound" is not written yet. The fixer texts quote existing sentences that contain numbers, so they may need a look when that rule lands.

**Points for the orchestrator from the observations**
- **Fixer items that could damage correct rows:** f24-D3-01, f24-D3-02, f30-D3-01 and f30-D3-02 tell the fixer to "correct the bounds", "record reference_basis population", "correct the unit" or "cut the row". The rows equal Echevarne's catalogue; D3 fails only because the frozen runner mismatches unit labels and cannot parse ages written `.006-60`. These should be central items with "change nothing on the row".
- **Family questions that do not reach the physician:** the research and verify questions the rows cite (f23-Q01 to Q07, f24-Q and VQ, f30-Q01 to Q07 and VQ01 to VQ04) are in no questions file; `questions/<family>.md` holds only the ledger section. Several are real choices covered by no ledger item:
  - f30-VQ03: yellow skin or eyes gets "in the next few weeks".
  - f30-Q02: urine albumin of 11 to 29 mg/L reads as plain in range.
  - f30-Q03: bilirubin critical limit of 15 mg/dL or none.
  - f23-Q05, f23-Q07, f23-VQ03 and f24-VQ02.
- **Omega-3 Index calculated metric:** the seed still says "<4% = high risk". It belongs to no family and C-25 names only the Biological Age row, so it needs its own central item.
- **Row follow-ups absent from the signed table:** f30-AL-UAC, f30-AL-AMY3 and f30-AL-LIP3 are not in action-limits.json, so under D-22 no client sees them, yet the rows' none-because reasons rest on them.
- **Pregnant client and urine albumin:** until WS3-15 she gets the general row, which tells her to repeat on first-morning urine; NICE NG133 advises against that sample in pregnancy.
- **f30-TABLE-01 is too narrow:** it should also cover the stale class label "e pending family f30" on AL-13.1 to AL-13.3 and the two different jaundice follow-up sentences in the table and the rows.
- **Tested_2x_Year:** the flag is carried from production on all 173 seed rows (67 say Yes) and no family, check or ruling reviewed it.
- **Gates that exist only as row text:** the f23 and f24 fasting, method and specimen gates and the DPA values-only gate have no app input. The specimen of an uploaded result is in no workstream 3 package.
- **f23 and f24 contradiction:** a client can read "optimal" on total omega-3 and "below range" on the omega-6/omega-3 ratio for the same eating habit (f24-VQ01); this is for workstream 1-K.

I changed nothing in the repository.
