import sys,re
# usage: g.py file regex [width] [maxhits]
f,rx=sys.argv[1],sys.argv[2]
w=int(sys.argv[3]) if len(sys.argv)>3 else 400
mx=int(sys.argv[4]) if len(sys.argv)>4 else 40
r=re.compile(rx)
n=0
for i,l in enumerate(open(f),1):
    m=r.search(l)
    if m:
        s=max(0,m.start()-w//2); print(f"{i}: ...{l[s:s+w].strip()}"); n+=1
        if n>=mx: break
