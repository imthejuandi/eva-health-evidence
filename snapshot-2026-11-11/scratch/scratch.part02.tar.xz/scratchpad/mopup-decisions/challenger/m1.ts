import { reachableZones } from "/home/user/eva-health/scripts/signoff/checks/messages";
console.log("hb preg 11-16", [...reachableZones({ normal_low: 11, normal_high: 16, optimal_low: null, optimal_high: null })]);
console.log("eos preg -575", [...reachableZones({ normal_low: null, normal_high: 575, optimal_low: null, optimal_high: null })]);
console.log("ldl 0-100 opt -60", [...reachableZones({ normal_low: 0, normal_high: 100, optimal_low: null, optimal_high: 60 })]);
console.log("ldl null-100 opt -60", [...reachableZones({ normal_low: null, normal_high: 100, optimal_low: null, optimal_high: 60 })]);
