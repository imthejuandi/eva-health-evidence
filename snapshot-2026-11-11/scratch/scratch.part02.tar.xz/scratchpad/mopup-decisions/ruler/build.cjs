const P = "docs/signoff/work/";
const rulings = [
{
id: "M-01",
ruling: "All rows that differ from the verifier's row get a fresh verdict in the round: the 55 of today, plus every row a fixer, an author or the evidence pass touches in the round. The session ends a family only when the comparison command returns an empty list for it. Depth is set by what changed. (a) The 10 rows whose optimal bounds or grade changed, the 9 whose reference bound or band rule changed and the 4 challenged grades: the verifier opens every source of the changed bound and grades the bound as compiled. (b) The 36 rows where only texts changed: the verifier checks each changed field against wording-rules.md, state-rules.md, critical-limits.json and the row's own numbers, and confirms that bounds, unit and grade are the ones of its file. Where an optimal bound's only evidence record is the fixer's (eGFR at 18 to 39, ceiling 110; the four NLR rows, floor 0.37), the verifier writes its own record from a source it opened, or corrects the row by removing the bound. A row still listed at the end is recorded as unreviewed, cannot score (D-02) and becomes a physician question.",
plain_rationale: "The programme's rule is that an independent verifier grades every row, never the agent that changed it. Since decision CEO-6 a single late text edit leaves every field of a row without a recorded reason, so the narrow reading would leave 45 rows changed and unchecked and most of the 277 unexplained changes open. The wider scope costs about 18 more verifier agents and is the only reading that leaves no row resting on its fixer.",
facts_checked: [
"I ran the plan's comparison (changedAfterVerdict in docs/signoff/tools/lib/compile-diff.js) on all 30 files of " + P + "decisions/ and " + P + "verify/: 55 of 260 rows differ, in 18 families; 10 in optimal bounds or grade (f03: 5, f12: 5), 9 in a reference bound, band rule or reference basis, 36 in texts only. The plan's counts are right.",
"D-30 in " + P + "governance/fable-ws3-decisions.md names 'optimal bounds or grade' and counts 17 of 101; CEO-6 in " + P + "governance/central-fix-decisions.md lets a verdict document a field only when the decision changed nothing in the row after it.",
"The scorecards show who gave today's verdicts: the verifiers of B02, B03 and B05 to B10 reported claude-opus-5-5 and B04's reported claude-fable-5-1 (" + P + "scorecard-B02.md to scorecard-B10.md, Agents table).",
"I did not re-run the plan's simulation (277 unexplained changes falling to 9)."
],
plan_changes: "Plan section 4.2, verifier notes: add the two depths (a) and (b) and the rule that the verifier never keeps a bound on the fixer's record alone. Stop rule: 'comparison empty' is a condition of 'content complete' as well as of 'pass'. Verifier stage: runs in every family where any earlier stage wrote a row, a record or a supports link, not only where today's list has a row.",
departure_recorded: "LOOP-PROMPT.md 2.2 has the verifier audit the author's research file once, in round 1. In the mop-up the verifier gives a second verdict on the decided rows as compiled, in a later round, as D-30 orders. Enter it in the decision register with the D-30 reference.",
physician_question: "none"
},
{
id: "M-02",
ruling: "The mop-up is recorded as one bounded pass per family, ordered by D-30: round 3 for B02 to B10, round 5 for f01, f03 and f04. It has no loop and no second pass. After it, a family's rows change only in workstream 1-K (M-09) or by a later signed change. The register entry also records B01's round 4, which already went past the plan's limit of 3 and has no entry today.",
plain_rationale: "The plan allows three rounds per family. Nine batches stopped after two, so their mop-up is inside the limit. The three pilot families have already run four, so their mop-up is a fifth round and must be written down as an exception, with its reason: a recorded ruling (D-30) orders it and it is a single pass that cannot repeat.",
facts_checked: [
"PLAN.md section 7: 'at most 3 rounds per family'.",
P + "checks/ holds f01, f03 and f04 files for rounds 1 to 4 and round 1 and 2 files for the other families checked (f02, f05, f30); " + P + "scorecard-B01.md says 'round limit 4', scorecard-B02.md to B10.md say 'round limit 2'; decisions/f03_kidney.json is at round 4.",
"A search of " + P + "governance/decision-register.md and central-fix-decisions.md finds no entry for B01's fourth round.",
"The brief says decision-register.md records CEO-1 to CEO-17. It does not: they are in central-fix-decisions.md, and the register has no entry for them or for the batch loop's deviations, which CEO-17 point 1 says are 'listed in the decision register'."
],
plan_changes: "Plan section 4.2 stop rule: add 'no further family round follows; what is left goes to the ledger as a physician question or to a central item'. Decision register: one new entry (see the departure), and a pointer from the register to the CEO-17 deviation list in central-fix-decisions.md.",
departure_recorded: "PLAN.md section 7 and the coordinator prompt of LOOP-PROMPT.md limit a family to 3 rounds. f01, f03 and f04 ran a fourth round on 8 November and run a fifth in the mop-up. The mop-up round is also not a full round of the loop: it has no judge round and no refuters, and its fixer acts on a list of items from the orchestrator (check failures, hand-offs from rulings, triaged minor items), where the coordinator prompt says 'Fix only issues both refuters confirm'.",
physician_question: "none"
},
{
id: "M-03",
ruling: "Verifier, closing lens, the triage of M-10, the author of new rows and the check of the governance table edits (M-07, M-08) run on Fable 5.2 at maximum effort. Fixer and evidence pass run on Opus at maximum effort. The runner stays on Opus at medium effort. No other model may stand in for the verifier or the closing lens: a session that cannot get Fable 5.2 for them stops and is resumed by its run id. The scorecard records the model each agent reported.",
plain_rationale: "The grade is the judgement the physician and the score rely on, so it gets the strongest model, and a different model from the fixer's makes the check more independent. The fixer's work is listed item by item and every row it touches is graded again by the verifier in the same session, so Opus at maximum effort is enough there. New rows are few (four families), so putting their author on the strongest model follows the plan at almost no cost. With my other rulings the round needs about 80 to 90 Fable agents, not 30.",
facts_checked: [
"PLAN.md section 9 and LOOP-PROMPT.md section 4 ask for the most capable model at maximum effort for authors, verifiers, judges, refuters and every agent call.",
"docs/signoff/workflows/ws1-batch.js lines 45 to 52 set author and fixer to Opus at high effort, verifier to Fable at max, judge to Fable at high; the README says the account's usage limit is the reason.",
"The scorecards show what ran: every role of B02, B03 and B05 to B10 reported claude-opus-5-5. The deviation list under CEO-17 in central-fix-decisions.md says 'since 9 November every clinical role of a new batch runs on Fable 5.2 at maximum effort', which does not match B05 to B10 (started 10 November).",
"I could not check whether Fable credits cover 80 to 90 agents; " + P + "ws3/README.md line 169 asks when the usage credits return."
],
plan_changes: "Plan section 4.3 role_models: author becomes [\"fable\",\"max\"]; add the triage role. Add the rule that an override of the verifier or judge model is refused by the script. Plan section 5: restate the Fable agent count. Central: correct the sentence about models in the CEO-17 deviation list to what the scorecards show. If credits are short, the order of priority is verifier, closing lens, triage, author.",
departure_recorded: "PLAN.md section 9 and LOOP-PROMPT.md section 4: the fixer and the evidence pass run on Opus, not on the most capable model. CEO-17 accepted per-role models 'for the batches only', so the mop-up needs its own line.",
physician_question: "none"
},
{
id: "M-04",
ruling: "The fixers do not touch the reference floor of 0 on apoB, LDL-C, non-HDL-C and HOMA-IR in this round. The 0 is not part of the CEO's locked clinical decisions, and that is entered in the decision register. It is part of the frozen baseline of check E6, so it changes only after an approved change of that baseline: LOCKED_BASELINE in scripts/signoff/checks/evidence.ts, normal_low null for the four rows, through a Fable 5.2 review and approved-changes.json. If that approval is recorded before the rebuild, the four items stay with the fixers and the verifier follows. If not, they are central items, the four M1 failures stay open as a known issue, and the floors are removed in workstream 1-K with a verifier verdict. The route through a CEO question in questions/ceo-locked.md is not used. The floors on apoE genotype and free PSA are not locked and go to the fixers as planned.",
plain_rationale: "No one can have a result below zero, so the 0 changes nothing a client sees; it only makes one check ask for a message that could never be shown. But the frozen test compares these four rows with their values of 6 November, floor included, and it passes today. A fixer who removed the floor would turn that check red and make a locked decision look silently changed. The clean route is to correct the baseline first, with its own approval.",
facts_checked: [
"scripts/signoff/checks/evidence.ts lines 587 to 594: LOCKED_BASELINE holds normal_low 0 for apolipoprotein_b_apob, ldl_cholesterol, non_hdl_cholesterol and homa_ir; lockedDiffs compares normal_low.",
"The plan's own check run (scratchpad/ws1-mopup/checks-all.json): E6 passes with 0 changes; M1 fails on 6 zones: apoB, HOMA-IR, LDL-C, non-HDL-C, apoE genotype, free PSA.",
"docs/biomarker-evidence/longevity/GATE-1-DECISIONS.md, L34 and G1: the decisions name the optimal targets (60, 90, 70; 1.8) and the upper limits (100, 130, 100; 3.46). Neither mentions a lower limit.",
"E6's exception route (lines 624 to 640) marks a whole locked decision as backed once one question with grade A or B evidence from 2024 to 2026 is recorded, so using it for the floor would also hide any other change to that row.",
"f06 already removed the floor of total cholesterol and triglycerides (both rows show reference_low changed after the verdict), and neither fails M1."
],
plan_changes: "items.json: f05-M1-01, f06-M1-01, f06-M1-02 and f07-M1-02 move from family_fixer to central, with 'needs: approved change of the E6 baseline'. Plan section 7: M1 goes from 6 to 4, not to 0, unless the approval lands before the rebuild. Plan section 6 item 6: this ruling goes into the fixer notes ('do not change reference_low on a locked row'). New central item: the E6 baseline change and its review.",
departure_recorded: "none. The change to the frozen runner goes through the approval route of ACCEPTANCE-TEST.md, not through the round.",
physician_question: "none"
},
{
id: "M-05",
ruling: "Hold all nine rows in this round: no below-range or above-range message of a pregnancy or lactation row is deleted now. The nine items move from the fixers to a central item: delete when check M1 lists the messages as unreachable, which needs the app's state rule (WS3-15, WS3-16) and the runner's state probes (WS3-17), and only for markers where the physician has not allowed an exception. The five state rows on the laboratory's interval (HbA1c in pregnancy; haematocrit and eosinophils in pregnancy and lactation) are kept, not removed. Their five D3 failures become a central item: D3 reads the label 'Pregnancy' or 'Lactation' as an age band it cannot find in the catalogue. In this round the fixers change these rows only for other listed items.",
plain_rationale: "Under D-12 the app shows a pregnant or breastfeeding client the laboratory's interval and nothing else, whatever texts the rows hold, so deleting the texts changes nothing for her. Today's test cannot see that rule: it would count about 16 deleted messages as missing and the families could not pass. For HbA1c, haematocrit and eosinophils the ordinary row carries a guideline limit, so the state row is the only place EVA holds Echevarne's printed interval; removing it would leave these women with no interval at all. Haemoglobin, ferritin and HbA1c are also the exceptions the physician is asked about, and he should see the exact texts.",
facts_checked: [
"scripts/signoff/checks/messages.ts, reachableZones (line 22): reachability is computed from the row's bounds only; the file has no pregnancy or lactation rule. With the messages deleted, M1 would report HbA1c 2, haemoglobin 4, haematocrit 4, eosinophils 2, ferritin 4: 16 new failures. The plan's claim that the deletion moves M1 forward is wrong for today's runner.",
P + "decisions/: hba1c ordinary row 4.3 to 5.6 on a decision limit, pregnancy row 4.3 to 6.1 on Echevarne's interval; haematocrit women 36 to 48 on a decision limit, state rows 36 to 51 on Echevarne's; eosinophils ordinary row up to 500 on a decision limit, state rows up to 575 on Echevarne's; haemoglobin (11 to 16, 12 to 16) and ferritin (31 to 291) state rows on decision limits.",
"D-12 (" + P + "governance/fable-ws3-decisions.md): the interval shown is 'the family's pregnancy or lactation row where its basis is the laboratory's, otherwise the ordinary row', and with only a guideline limit 'the value is shown without an interval'; the messages 'are listed for deletion by M1 unless the physician amends 2.1'. Its physician question names haemoglobin, ferritin, ALT, AST and HbA1c.",
"scripts/signoff/checks/data.ts line 341: the five D3 failures read 'the catalogue has no band covering this row's ages'; the rows' reference sources cite the catalogue lines for women (haematocrit: line 184, 36 to 51).",
"The in-range message of the haemoglobin pregnancy row says 'EVA shows only this interval (11.0 to 16.0 g/dL)', which D-12 does not show for a row on a guideline limit."
],
plan_changes: "items.json: the 9 state_row_messages items and the 5 D3 items (f05-D3-01, f09-D3-01, f09-D3-02, f13-D3-01, f13-D3-02) move from family_fixer to central; fixer items fall from 152 to 138 before the other rulings. Plan section 7: D3 goes from 16 to 5, not to 0. New central items: (1) deletion of the unreachable state-row texts after WS3-17, with a verifier verdict on the rows; (2) D3 or the compile's label for state rows, through the frozen-file route; (3) pack assembly marks the state rows' texts 'not shown under state rule 2.1' on the family pages; (4) the in-range texts of the haemoglobin and ferritin state rows go with (1).",
departure_recorded: "none. D-12's hand-off is kept, with its timing made explicit: the deletion follows M1's list.",
physician_question: "Added to the D-12 question: for haemoglobin, ferritin and HbA1c you see the row's below-range and above-range texts as written; if you keep rule 2.1 unchanged they are deleted, and if you allow the exception for a marker they are the texts you sign. May the HbA1c pregnancy row show Echevarne's 4.3 to 6.1%?"
},
{
id: "M-06",
ruling: "The uACR row is in the round only if all four are in the rebuild commit: (1) the key urine_albumin_creatinine_ratio in families.json under f30; (2) its class c in marker-classes.json; (3) the approved change of docs/signoff/tools/inputs/static.js (B0848 mapped to the new key and no longer to microalbumin_urine), with its entry in approved-changes.json; (4) the rebuilt f30 input and brief. The rebuild does not wait for (3). If any is missing, f30 runs without an author stage for uACR and the row stays a listed central item, and the pack says the ratio is not classified. A package to map B0848 in the app is added to workstream 3's list either way.",
plain_rationale: "The albumin-to-creatinine ratio is the kidney screening test the plan names, and EVA has a signed follow-up for it but no row. Adding the row needs a change to a frozen tool, which has its own approval. Ten sessions should not wait for one screening row; if the approval is late, the row is written later as a recorded exception.",
facts_checked: [
"docs/vendor/echevarne/catalogo-2026-08-25-original-win1252.csv lines 51 and 52: B0840 is the concentration in mg/L ('<30'), B0848 the ratio in mg/g creat ('<30').",
"docs/signoff/tools/inputs/static.js line 58 maps microalbumin_urine to B0848, the ratio's code, while the decided f30 row cites B0840 and src/lib/lab-provider/echevarne.ts line 116 maps B0840 to microalbumin_urine. The frozen tool points the mg/L marker at the wrong code today; the plan does not say this.",
"families.json and marker-classes.json hold microalbumin_urine only; action-limits.json AL-03 is keyed urine_albumin_creatinine_ratio (30 mg/g, KDIGO, 'soon').",
"scripts/signoff/lib/hash.ts line 71 puts all of docs/signoff/tools in the frozen list."
],
plan_changes: "Plan section 6 item 5: state the four conditions and that the static.js change is a correction of an existing line as well as an addition. Plan section 5: B10's author stage for uACR is conditional. Workstream 3 list: new package, the app's mapping of B0848. If the row misses the round, its later pass (author, verifier, fixer, verifier, and the judging of M-11 point 4) is a fourth round for f30 and gets its own register entry.",
departure_recorded: "none if the row is in the round. If it is written later: a fourth round for f30, against PLAN.md section 7.",
physician_question: "none"
},
{
id: "M-07",
ruling: "Add both to critical-limits.json before the rebuild, as proposed entries for the physician's session 1; the fixers do not remove the limits. Urea: high 214 mg/dL, no low limit, BUN's action class ('today') and sentences, citing the table's own sources S3 and S4, which state 214 mg/dL for urea. Magnesium: low 1.0 and high 4.9 mg/dL, action class 'today', citing the records the family used (f18-E62, f18-E13, f18-E61), with the conversion written in the entry. Both entries are marked as outside check L1's list of 26 analytes. An agent that did not write them, on Fable 5.2, opens the sources and confirms quotes and conversions before the commit. If the physician refuses an entry, the limit leaves the row as a signed change.",
plain_rationale: "D-18 allows a critical limit on a row only if the signed table has an entry for it. Echevarne reports urea, not BUN, so taking urea's limit away would leave EVA's own clients without the same-day warning that BUN has. Both numbers come from sources already quoted in the files, so adding the entries invents nothing, and the physician signs or refuses each one.",
facts_checked: [
P + "governance/critical-limits.json: 26 entries, none for urea or magnesium. The BUN entry quotes S3 (PMC6178782) 'Urea BUN > 214 mg/dl (35.6 mmol/l) > 100 mg/dl' and S4 'Urea (mg/dl) 170 (51-245)* 21 214 (80-250)* 14'.",
P + "decisions/f03_kidney.json: urea critical_high 214, supported by f03-E23, the same S3 quote. decisions/f18_electrolytes.json: magnesium_serum critical 1 and 4.9 mg/dL; f18-E62 (PMC6559616) 'Magnesium < 0.41 mmol/L ... > 2.00 mmol/L', f18-E13 (Manchester list) low 0.4 mmol/L with no high limit, f18-E61 (2024 survey) medians 0.41 and 2.02 mmol/L.",
"My arithmetic: 0.41 mmol/L x 2.431 = 0.997 mg/dL and 2.00 x 2.431 = 4.86 mg/dL. At one decimal, 'at or below 1.0' is one step stricter than the source's 'below 0.41 mmol/L'; 'at or above 4.9' matches the source.",
"The table's entries have no comparison or decimals field yet (potassium entry read), so D-17's governance edit is still to do.",
"D-18's physician question already asks whether urea gets its own entry."
],
plan_changes: "Plan section 6 item 4: critical-limits.json gets the two entries and, in the same edit, D-17's comparison and decimals fields on every numeric entry; the plan did not list the D-17 fields. Run check L1 on a scratch copy before the commit, because coverage_check counts 26 entries. items.json: f03-HANDOFF-03 and f18-HANDOFF-05 close when the entries are committed; their critical-tier texts are aligned by the fixers like the other 28.",
departure_recorded: "none",
physician_question: "Do you sign a critical limit for urea of 214 mg/dL (BUN's 100 mg/dL converted) with BUN's sentence? Do you sign critical limits for magnesium of 1.0 and 4.9 mg/dL (0.41 and 2.0 mmol/L), with the action 'contact a doctor today'? For the low limit, is a result of exactly 1.0 mg/dL critical, or only values below it?"
},
{
id: "M-08",
ruling: "Settled centrally in action-limits.json before the rebuild, checked by an agent that did not write the edits; the fixers then align the rows. (1) Potassium: the table stands at above 5.0 mEq/L. The row's first follow-up starts above 5.0, its reference ceiling stays 5.1, and no text calls 5.1 out of range. (2) PSA: the rows stand. AL-15.1 and AL-15.2 become 'at or below 1' and 'at or below 2 ng/mL' and quote the EAU recommendation. (3) Neutrophils: the rows stand. AL-14 gains the tier below 1,000/µL and above 500/µL with the rows' sources, and the benign-variant note applies only from 1,000/µL up to the row's floor. Ancestry stays in the sentence and is not a condition. (4) 'At or above': D-17 already rules it. Potassium 6.0 and bilirubin 15 are critical at the limit itself; the rows' action limits end below 6.0 and below 15, and every row text that states a critical comparison says 'or higher' or 'or lower'.",
plain_rationale: "Where the table and a row disagree, I took the reading that follows the quoted source and tells the client more. For potassium that is the guideline's definition, which adds a repeat test at exactly 5.1. For neutrophils it is the row, because the table would tell someone with a count of 700 that a harmless variant is the likely cause. For PSA the row follows the guideline's recommendation and leaves no value without advice. The fourth point was decided on 10 November.",
facts_checked: [
"action-limits.json AL-09.1: comparator '>' 5, quoting 'K+ > 5 mmol/L' and 'mild (>5.0 to <5.5 mEq/L)'; its applies_to says a first value 'between 5.1 and 5.9 is repeated'. Row potassium: reference 3.5 to 5.1, first action limit 'above 5.1', condition 'a result of 5.1 stays in range (f18-Q03)'.",
"AL-15.1 and AL-15.2: '<' 1 and '<' 2, quoting 'baseline PSA < 1ng/mL at 40 years or < 2ng/mL at 60 years'. Rows: '1 ng/mL or less', '2 ng/mL or less', citing f22-E05: 'for those initially at risk: males with a PSA level of > 1 ng/mL at 40 years of age; ... > 2ng/mL at 60 years ... Postpone follow-up for up to eight years in those not at risk', which the verifier found word for word. With the table's reading a result of exactly 1.0 has no advice.",
"AL-14.1 and AL-14.2: one tier from the row's floor down to above 500/µL, a 'benign-cause note'. Rows: a second tier below 1,000/µL citing f12-E25 (PMID 26791682: odds ratio for viral infection 4.77 below 1.0 G/L) and f12-E20 (Duffy-null lower limit 1,210/µL). Judge J1's issue on this was confirmed by both refuters (f12-JUDGE-02).",
"D-17: 'at or below the low limit, at or above the high limit'. The table says 'at or above 6.0' and 'at or above 15'; the rows say 'above 6.0 the critical limit applies' and 'values above 15 mg/dL'. Judge item f18-JUDGE-01 (6.0 gets three follow-ups) is the same point.",
"The disputed items on AL-02's ages (f22-JUDGE-01) and the sodium wording (f18-JUDGE-02) are not among the four and stay on the physician's list."
],
plan_changes: "Plan section 6 item 4: action-limits.json carries these four edits. items.json: f18-TABLE-01, f22-TABLE-01, f12-TABLE-01, f30-TABLE-01 and f12-JUDGE-02 turn into fixer items worded as above, with f18-JUDGE-01; the fixers of f18, f12, f22 and f30 align action_limits, messages and notes. Fixer notes, all families: a text that states a critical comparison follows D-17.",
departure_recorded: "none",
physician_question: "Potassium: should the repeat-test follow-up start above 5.0 mEq/L (the ESC definition, so at 5.1, which is inside Echevarne's interval) or above the laboratory's ceiling of 5.1? PSA: is a result of exactly 1.0 ng/mL at 40 to 49, or 2.0 at 60 to 69, 'not at risk' (next test in up to eight years)? Neutrophils: do you sign a separate follow-up below 1,000/µL, and with which urgency?"
},
{
id: "M-09",
ruling: "Confirmed: the 19 opposite-category patterns of K1, and the 24 one-step patterns, are out of the round and belong to workstream 1-K. A fixer in the round moves no bound to pass a coherence check. Condition on 1-K: every row it changes is changed in the family's decision file with a change record, gets a verifier verdict on Fable 5.2 before the single compile, and the comparison command is empty for all 30 families at that compile.",
plain_rationale: "Coherence between markers is a question across families: several of the 19 patterns come from a formula (eGFR from creatinine, total protein from albumin and globulin), not from one family's row. The plan gives that work to its own workstream. The condition matters because any row changed after its verdict is again a row nobody graded, which is the problem this round exists to remove.",
facts_checked: [
"checks-all.json, K1: 19 opposite patterns in 7 relationships: BUN/creatinine ratio 2, eGFR by CKD-EPI 4, free testosterone 3, HOMA-IR 2, NLR 2, total protein 2, TSAT 4; 24 one-step patterns.",
"PLAN.md section 8 gives 'coherence across families, then the single compile' to WS1-K, with at most 2 rounds (section 7); ACCEPTANCE-TEST.md K1 asks 0 opposite pairs.",
"D-30: 'A script makes the comparison on every compile'; LOOP-PROMPT.md 2.5: 'A fix that only satisfies a check without meeting the definitions is wrong'."
],
plan_changes: "Plan section 7, last line: add the condition on workstream 1-K. K1 is run again after the round, because the round changes rows that K1 reads (the NLR floor, the creatinine and eGFR rows).",
departure_recorded: "none",
physician_question: "none"
},
{
id: "M-10",
ruling: "A central triage before the rebuild, not the fixers: ten agents on Fable 5.2 with the judge role, one per batch, that wrote and fixed none of the rows. Each sorts every minor item of its families into one of four groups, with the evidence: (a) a defect the files themselves show (wrong arithmetic, a reference to a question that does not exist, a text that contradicts the row's own number, a quote not found), which enters the family's items file for the fixer; an item that would move a bound never goes here; (b) already gone in today's files; (c) part of an existing central, workstream 3 or Echevarne item, linked to it; (d) a decision only the physician can take. The triage closes nothing. An item of (a) or (b) is closed by a script result where a check shows it, otherwise by the raising lens in the closing pass (M-11). After the round, pack assembly merges what is left of all physician questions into at most 20 decisions for part A, each listing its ledger ids, with the full list in the uncertainty register. If more than 20 real decisions remain, the CEO is told; no item is dropped to meet the cap.",
plain_rationale: "The ledgers hold 715 open physician questions against a cap of 20, and many of the 490 minor ones are plain defects, not decisions. This round is the last time a family's rows can be fixed, so the fixable ones should be found before it, by reviewers with no stake in the rows. Fixers must not decide which criticisms of their own family count.",
facts_checked: [
P + "ledger/ (30 files, 1,687 issues): minor and physician question 490; blocking and physician question 225; blocking and disputed 44; minor and closed 64. By lens the 490 are J1 181, J2 138, J3 101, J5 70.",
"ACCEPTANCE-TEST.md G8: 'Open physician questions stay within caps: at most 20 for part A'. PLAN.md section 1: every unresolved item 'becomes a question for the physician, never a silent gap'; section 7: 'the raising judge or the cold panel closes an issue'.",
"Samples from items.json show defects among the minor items: f05 'f05-E16 ... is not found in its source (score 0.333)'; f01 'PQ-3 is not among the decision's physician_questions'; f03 '25 x 2.14 = 53.5' against a stated 53.6.",
"docs/signoff/tools/ledger.js has no state between 'physician_question' and the closed states, so an item leaves the count only by being closed."
],
plan_changes: "New step before the rebuild: triage, about 10 Fable agents, output " + P + "mopup/triage/<family>.json. build-items.cjs reads it: group (a) becomes fixer items, groups (a) and (b) join stages.closing_lenses. Plan section 3.1: the line '490 ... not in the round' goes. Plan section 5: the closing pass grows to one agent per lens per session where that lens holds listed items (up to 40 agents). Pack assembly (workstream 4): the merge into at most 20 part A decisions.",
departure_recorded: "LOOP-PROMPT.md has no triage stage, and its coordinator prompt says 'Fix only issues both refuters confirm'. In the mop-up the fixer also fixes minor judge items that a triage agent reproduced from the files; no refuter saw them.",
physician_question: "none from the triage itself; group (d) feeds the part A decisions list."
},
{
id: "M-11",
ruling: "Accepted, with four conditions. (1) The closing lens is a fresh agent on Fable 5.2 at maximum effort with the frozen role text of its lens. It reads the compiled copy, the check results and the listed ledger items, never the fixer's notes. (2) 'Not raised again' closes the item with closed_by naming the lens and the pass. 'Raised again' leaves it open with its evidence, and it becomes a physician question or stays disputed at the end. (3) It opens no new ledger issue on old content, but it writes anything it sees that could mislead or harm a client into a separate observations list in its output file; the orchestrator turns each into a central item. (4) In a family with an author stage, lenses J1 and J2 also read the new rows in full under the frozen judge prompt and may raise issues on them. Those issues enter the ledger as open, are never dropped, and the orchestrator records before workstream 1-K whether the row gets a repair.",
plain_rationale: "A full judge round on 28 families would raise new issues with no round left to fix them, and the plan's round limit forbids another. Letting the lens that raised an issue confirm that it is gone is what the plan itself asks for closing an issue. The risks are a judge told to stay silent about something unsafe, and brand-new rows that no judge has read; conditions 3 and 4 remove both. The final cold panel of six lenses still reads everything from scratch.",
facts_checked: [
"LOOP-PROMPT.md section 1: each round runs the judges and sends every blocking issue to two refuters. PLAN.md section 7: 'the raising judge or the cold panel closes an issue' and '1 cold final pass with no fixing'.",
"CEO-17 point 2 (central-fix-decisions.md): the final run uses all six lenses from the frozen texts with no instruction to pass over known issues.",
"Plan section 4.1: a start_round run of ws1-batch.js would re-judge 112 lens and family pairs. I confirmed that the verifier is reached only when a run starts at round 1 (ws1-batch.js line 1002 inside the first-round branch) and did not recount the 112.",
"items.json: closing lenses today are f03 J1, J2, J3; f04 J2; f12 J1; f18 J2; f22 J2. Author stages: f14, f15, f20, f30."
],
plan_changes: "Plan section 4.2 stage 7: add conditions 1 to 4, the observations list in the output schema, and the new-row reading for f14, f15, f20, f30 (and uACR if it is in). Plan section 5: about 8 more Fable agents for condition 4, on top of M-10's.",
departure_recorded: "LOOP-PROMPT.md section 1 steps 5 and 6 and prompt 2.3: the mop-up round has no judge round and no refuters. The raising lens re-reads only listed items and may not open new blocking issues on existing content; new rows are judged once, without refuters.",
physician_question: "none"
},
{
id: "M-12",
ruling: "Yes. The three items (f03-JUDGE-04, raised by J3; f03-JUDGE-05 and f03-JUDGE-10, raised by J2) are closed in the closing pass by the lens that raised each, not by the orchestrator. The f03 fixer also removes the outdated remark in the urea row's bookkeeping notes that the seed note 'still say[s] the interval starts at 15 mg/dL'.",
plain_rationale: "The texts the judges objected to are gone from the files. The plan says only the raising judge or the final panel may close an issue, so the same lens confirms it in the closing pass, at no extra cost: f03 already has all three lenses there.",
facts_checked: [
P + "decisions/f03_kidney.json: the BUN and urea clinical notes, in English and Spanish, no longer hold 'between 7 and 10 mg/dL' or 'starts at 15 mg/dL'; they now say urea's interval, 21 to 54 mg/dL, is BUN's 10 to 25 multiplied by 2.14.",
"The phrase 'starts at 15 mg/dL' survives only in final_rows[7].notes, a bookkeeping field the compile does not publish.",
"items.json: all three were confirmed by both refuters and are open at the round limit; f03's closing lenses are J1, J2 and J3."
],
plan_changes: "items.json: the three items keep owner central with closing_pass true; add a fixer item for the stale bookkeeping note.",
departure_recorded: "none",
physician_question: "none"
},
{
id: "M-13",
ruling: "Not confirmed: no catalogue record is dropped. Before the rebuild the orchestrator runs a one-off script that writes Echevarne's catalogue file into the source cache for each of the 46 evidence records that cite it by repository URL, with the file's path, commit and SHA-256 in the cache entry as where it was fetched from. The frozen quote checker then finds all 46 quotes. The verifier's grades on these records are left as they are. The other five records stay with the evidence pass: f02-E02 and f02-E03 (a DOI the offline run could not open), f03-D06, f18-E12 and f29-E51 (quote not found). The evidence pass corrects a quote from the opened source and never sets a grade; if a source stays unopenable, the verifier regrades the record to D in the same session.",
plain_rationale: "These records quote Echevarne's own catalogue, which is a file in EVA's repository; the checker fails only because it cannot open a link to a private repository. The quotes are true and can be checked exactly, so the honest fix is to let the checker read the file. Deleting them would also have thinned the evidence behind several sex splits. This lifts the quote check from 97.1% to 99.7%, with room to spare.",
facts_checked: [
"The plan's count is wrong: 12 of the 17 failing records cite the catalogue by repository URL (f05-E13, E14; f07-E15, E20, E21, E33; f09-E27 to E32), not 13. In all, 46 records in 11 families cite it that way and none is in " + P + "sources-cache/; the other 34 are the '34 unopenable records at grade D'.",
"My test, in my scratch folder only: I wrote the text of docs/vendor/echevarne/catalogo-2026-08-25.tsv into a scratch cache under the 46 identifiers and ran the unchanged docs/signoff/tools/quote-check.js with --offline --cache-dir. All 46 quotes were found (f05 2, f07 4, f09 6, f14 2, f15 5, f17 4, f22 5, f25 4, f26 6, f28 3, f29 5). The repository was untouched.",
"E2 today: 1,698 of 1,749 found (97.1%); with the 46 found, 1,744 of 1,749 (99.7%) against a rule of 98%.",
"f09-E29 to E32 also support the sex splits of haematocrit and the red-cell count, beside one other record (f09-E46); the plan's fix would have unlinked them from those splits too.",
"ws1-batch.js lines 461 to 481: the evidence-repair prompt forbids changing 'evidence id, row, bound, grade, verdict or message' and says 'Never raise a grade'."
],
plan_changes: "Plan section 6: new central step in the rebuild, the cache entries for the 46 catalogue identifiers, written by a short script that calls writeCache of docs/signoff/tools/lib/sources.js and changes no frozen file; run E2 afterwards. items.json: the 12 catalogue E2 items go; 5 remain. Plan section 3.4 note 'E2 has no margin' and section 7's '98.1%' are replaced by 99.7%. Plan section 4.2 stage 1: a record or supports link the evidence pass adds or changes is graded by the verifier in the same session, so the verifier stage also runs in f18, f22, f28 and f29 where that happens.",
departure_recorded: "PLAN.md section 5 says quotes are checked against text 'fetched from PubMed, Europe PMC, PMC or the guideline page'. For Echevarne's catalogue the text is read from the repository file the record's URL names, and the cache entry says so.",
physician_question: "none"
},
{
id: "M-14",
ruling: "Yes. items.json and the per-family items files are rebuilt with docs/signoff/work/mopup/build-items.cjs on the rebuild commit, after WS3-09, the governance edits (M-07, M-08), the cache step (M-13) and the triage (M-10), and committed in that commit with its hash and the day's check counts. The builder is first updated for these rulings. The orchestrator writes a short comparison with today's list that explains every item that appeared or disappeared. Each session's setup stops if the items file's commit is not the commit it started from, or an ancestor of it.",
plain_rationale: "Every count in the plan comes from the files as they stood at one commit, and the repository has already moved since. Sessions start from a clean checkout and cannot write the list themselves, so it must be rebuilt and committed once, on the day, from the state they will actually work on. The comparison guards against an item vanishing only because the builder changed.",
facts_checked: [
"items.json built_from: commit ee548ec. The branch is now at 2239b01 (git log: WS3-14 merged in 3674978 after the plan), and C1's 28 failures are assigned to WS3-14 to WS3-17.",
"D-43: inputs and briefs are rebuilt once, 'after WS3-08 and WS3-09', when no batch runs. " + P + "ws3/README.md: WS3-08 merged (9bbf545), WS3-09 'planned'. The round cannot start before WS3-09 is merged.",
"docs/signoff/work/mopup/ holds build-items.cjs and plan.md only; the per-family files do not exist yet.",
"The plan's caveat holds: its check run was offline, and E2 can differ online (f02-E02 and f02-E03 failed as 'not in cache (offline)')."
],
plan_changes: "Plan section 6 item 2: add the order of the steps, the commit hash in each items file and the comparison note. Plan section 4.2 stage 0: the commit test. build-items.cjs: owners changed by M-04, M-05, M-08 and M-13, and the triage input of M-10.",
departure_recorded: "none",
physician_question: "none"
}
];
const out = JSON.stringify({ rulings });
JSON.parse(out);
require("fs").writeFileSync(process.argv[2], out);
console.log(rulings.length, out.length);
