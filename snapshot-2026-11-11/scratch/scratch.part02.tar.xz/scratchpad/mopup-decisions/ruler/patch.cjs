const fs=require("fs");let s=fs.readFileSync("build.cjs","utf8");
const a="f09-E29 to E32 are the only records behind the sex splits of haematocrit and the red-cell count; dropping them would open E1 failures.";
const b="f09-E29 to E32 also support the sex splits of haematocrit and the red-cell count, beside one other record (f09-E46); the plan's fix would have unlinked them from those splits too.";
const c="Deleting records would also have removed the only evidence for several sex splits.";
const d="Deleting them would also have thinned the evidence behind several sex splits.";
if(!s.includes(a)||!s.includes(c))throw new Error("missing");s=s.replace(a,b).replace(c,d);fs.writeFileSync("build.cjs",s);
