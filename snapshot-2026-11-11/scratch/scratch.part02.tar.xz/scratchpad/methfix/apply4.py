import sys
R = '/home/user/eva-health/'


PENDING = {}


def apply(path, pairs):
    s = open(R + path, encoding='utf-8').read()
    for old, new, count in pairs:
        n = s.count(old)
        if n != count:
            sys.exit(f"{path}: expected {count} of {old[:90]!r}, found {n}")
        s = s.replace(old, new)
    PENDING[path] = s
    print('checked', path, len(pairs))


M = 'src/app/[locale]/(marketing)/metodologia/page.tsx'
apply(M, [
    # HR: the SD is taken over the whole sample; 1.39 and 1.65 are in different units.
    ('alrededor de un 39% mayor (versión de referencia, NHANES). En la versión completa, la cifra es 1,65.",',
     'alrededor de un 39% mayor (versión de referencia, NHANES). La desviación estándar se mide en toda la muestra, con personas de todas las edades. En la versión completa, la cifra es 1,65, en sus propias unidades: las dos cifras no se pueden comparar entre sí.",', 1),
    ('about 39% higher relative mortality risk (Reference version, NHANES). In the Comprehensive version, the figure is 1.65.",',
     'about 39% higher relative mortality risk (Reference version, NHANES). The standard deviation is measured across the whole sample, people of all ages. In the Comprehensive version, the figure is 1.65, in its own units: the two figures cannot be compared.",', 1),
    # The aim of the Spanish adjustment is not yet shown to hold.
    ('y no desplazada por las diferencias con la población de Estados Unidos. Este ajuste no se ha evaluado todavía frente a la mortalidad en la población española.",',
     'y no desplazada por las diferencias con la población de Estados Unidos. No sabemos todavía si se cumple, y el ajuste no se ha evaluado frente a la mortalidad en la población española.",', 1),
    ('not one shifted by differences from the U.S. population. This adjustment has not yet been tested against recorded deaths in the Spanish population.",',
     'not one shifted by differences from the U.S. population. We do not yet know whether it does, and the adjustment has not been tested against recorded deaths in the Spanish population.",', 1),
    # Creatine: the offset is EVA's own estimate.
    ('"Suplementación de creatina (ajuste automático del valor de creatinina, basado en literatura ISSN 2017).",',
     '"Suplementación de creatina (EVA resta a la creatinina una cantidad estimada según la dosis declarada).",', 1),
    ('"Creatine supplementation (automatic creatinine adjustment based on ISSN 2017 literature).",',
     '"Creatine supplementation (EVA subtracts an estimated, dose-based amount from creatinine).",', 1),
    ('(estatinas, ACE inhibidores, levotiroxina)', '(estatinas, inhibidores de la ECA, levotiroxina)', 1),
    # The +3.5-year figure is on U.S. adults with the Spanish values applied.
    ('"Puede dar una edad mayor que la cronológica. En una evaluación interna con datos de NHANES, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica.",',
     '"Puede dar una edad mayor que la cronológica. En una evaluación interna con datos de NHANES, de adultos de Estados Unidos y con el ajuste español ya aplicado, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica. No se ha medido en personas españolas.",', 1),
    ('"It can read older than chronological age. In an internal evaluation on NHANES data, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average.",',
     '"It can read older than chronological age. In an internal evaluation on NHANES data from U.S. adults, with the Spanish adjustment already applied, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average. This has not been measured in Spanish people.",', 1),
    # NUMBERS.md section D: +1.7 and +1.8 years.
    ('sube la versión de referencia unos 2 años, y la cifra del dashboard algo menos de 1.",',
     'sube la versión de referencia casi 2 años, y la cifra del dashboard algo menos de 1.",', 1),
    ('raises the Reference version by about 2 years, and the dashboard figure by just under 1.",',
     'raises the Reference version by almost 2 years, and the dashboard figure by just under 1.",', 1),
    ('        // NUMBERS.md (sections A, C, D and E), ASSESSMENT.md (F1, F3, F4, F5)\n        // and KDM-DIRECTION.md,\n',
     '        // NUMBERS.md (sections A, C, D and E) and ASSESSMENT.md (F1, F3, F4, F5),\n        // docs/biomarker-evidence/longevity/KDM-DIRECTION.md,\n', 1),
])

C = 'src/app/[locale]/(marketing)/metodologia/completa/page.tsx'
ES_80 = ' En mayo de 2026 (v2.2.2) se reajustaron 80 de los 81 marcadores entrenados con valores de NHANES sin winsorizar.'
EN_80 = ' In May 2026 (v2.2.2), 80 of the 81 trained markers were refitted on unwinsorized NHANES values.'
apply(C, [
    # §01: the HR figures come from the May 2026 run; the refit sentence moves to §03.
    ('<>En los datos de NHANES con los que se construyó, el hazard ratio es de <strong>1,39 por desviación estándar de edad biológica</strong>',
     '<>En la evaluación de mayo de 2026, en los datos de NHANES con los que se construyó, el hazard ratio fue de <strong>1,39 por desviación estándar de edad biológica</strong>', 1),
    ('una ganancia pequeña (sección 06).' + ES_80 + '</>', 'una ganancia pequeña (sección 06).</>', 1),
    ('Uno de ellos, el PSA, solo tiene parámetros para hombres.</>', 'Uno de ellos, el PSA, solo tiene parámetros para hombres.' + ES_80 + '</>', 1),
    ('<>In the NHANES data it was built on, the hazard ratio is <strong>1.39 per standard deviation of biological age</strong>',
     '<>In the May 2026 evaluation, on the NHANES data it was built on, the hazard ratio was <strong>1.39 per standard deviation of biological age</strong>', 1),
    ('a small gain (section 06).' + EN_80 + '</>', 'a small gain (section 06).</>', 1),
    ('One of them, PSA, has parameters for men only.</>', 'One of them, PSA, has parameters for men only.' + EN_80 + '</>', 1),
    ('16 de los 81 marcadores entrenados se ajustan por separado', 'Dieciséis de los 81 marcadores entrenados se ajustan por separado', 1),
    ('16 of the 81 trained markers are fitted separately', 'Sixteen of the 81 trained markers are fitted separately', 1),
    # Release wording: the conditions in PROPOSAL.md.
    ('cuando supere su validación y las condiciones para su lanzamiento', 'cuando cumpla las condiciones fijadas para su lanzamiento', 2),
    ('once it passes its validation and release conditions', 'once it meets the conditions set for its release', 2),
    # §02: no claims EVA's files do not support.
    ('<>Tu edad cronológica cuenta los años desde tu nacimiento. Tu edad biológica describe el estado funcional acumulado de tus órganos y sistemas — un resumen cuantitativo de cuánto te has gastado, no cuánto has vivido.</>',
     '<>Tu edad cronológica cuenta los años desde tu nacimiento. Tu edad biológica es una estimación: la edad con la que mejor encajan tus marcadores sanguíneos en la población de referencia, combinada con tu edad cronológica.</>', 1),
    ('<>Dos personas con la misma fecha de nacimiento pueden tener edades biológicas que difieren en una década o más. La diferencia refleja factores acumulativos: nutrición, ejercicio, sueño, estrés crónico, exposiciones ambientales, predisposición genética y suerte. La edad biológica es <em>modificable</em>; la cronológica no.</>',
     '<>Dos personas de la misma edad pueden obtener cifras distintas. Parte de la diferencia puede ser variación normal entre analíticas (sección 08).</>', 1),
    ("<>Your chronological age counts the years since you were born. Your biological age describes the cumulative functional state of your organs and systems — a quantitative summary of how much you've worn, not how much you've lived.</>",
     '<>Your chronological age counts the years since you were born. Your biological age is an estimate: the age your blood markers best match in the reference population, combined with your chronological age.</>', 1),
    ("<>Two people with the same birthdate can have biological ages that differ by a decade or more. The difference reflects cumulative factors: nutrition, exercise, sleep, chronic stress, environmental exposures, genetic predisposition, and luck. Biological age is <em>modifiable</em>; chronological isn't.</>",
     '<>Two people of the same age can get different figures. Part of the difference can be normal variation between lab tests (section 08).</>', 1),
    # §05: cite references 2 and 3.
    ('en una única estimación de edad biológica. Cada biomarcador <em>x<sub>i</sub></em> contribuye',
     'en una única estimación de edad biológica. Nuestra implementación sigue a Klemera y Doubal (2006), Levine (2013) y Kwon y Belsky (2021). Cada biomarcador <em>x<sub>i</sub></em> contribuye', 1),
    ('into a single biological age estimate. Each biomarker <em>x<sub>i</sub></em> contributes',
     'into a single biological age estimate. Our implementation follows Klemera and Doubal (2006), Levine (2013) and Kwon and Belsky (2021). Each biomarker <em>x<sub>i</sub></em> contributes', 1),
    # §06: SD scale, and the two C-statistics.
    ('alrededor de un 39% mayor (referencia).</li>',
     'alrededor de un 39% mayor (referencia). La desviación estándar se mide en toda la muestra, con personas de todas las edades. Cada cifra está en las unidades de su versión, así que las dos no se pueden comparar entre sí.</li>', 1),
    ('about 39% higher relative mortality risk (Reference).</li>',
     "about 39% higher relative mortality risk (Reference). The standard deviation is measured across the whole sample, people of all ages. Each figure is in its own version's units, so the two cannot be compared.</li>", 1),
    ('<li><strong>C-statistic</strong>: 0,77 (referencia) y 0,775 (completa). Es el valor de todo el modelo, con la edad y el sexo, no el de la edad biológica sola.</li>',
     '<li><strong>C-statistic</strong>: 0,77 (referencia) y 0,775 (completa), de todo el modelo con la edad y el sexo. En esta muestra no se guardó el de la edad y el sexo solos, así que estas cifras no indican cuánto aporta la edad biológica.</li>', 1),
    ('<li><strong>C-statistic</strong>: 0.77 (Reference) and 0.775 (Comprehensive). This is the value of the whole model, with age and sex, not of biological age alone.</li>',
     '<li><strong>C-statistic</strong>: 0.77 (Reference) and 0.775 (Comprehensive), for the whole model with age and sex. The value for age and sex alone was not stored for this sample, so these figures do not show what biological age adds.</li>', 1),
    # §07: the versions also differ in s_CA.
    ('difieren en cuántos marcadores usan. Por eso,', 'difieren en cuántos marcadores usan y en el peso que dan a la edad cronológica (sección 05). Por eso,', 1),
    ('they differ in how many markers they use. So whenever', 'they differ in how many markers they use and in how much weight they give chronological age (section 05). So whenever', 1),
    # §08: +3.5 context, HDL/GGT size, creatine attribution, ACE inhibitors.
    ('En una evaluación interna con datos de NHANES, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica.</li>',
     'En una evaluación interna con datos de NHANES, de adultos de Estados Unidos y con el ajuste español ya aplicado, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica. No se ha medido en personas españolas.</li>', 1),
    ('In an internal evaluation on NHANES data, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average.</li>',
     'In an internal evaluation on NHANES data from U.S. adults, with the Spanish adjustment already applied, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average. This has not been measured in Spanish people.</li>', 1),
    ('sube la versión de referencia unos 2 años, y la cifra del dashboard algo menos de 1.</li>',
     'sube la versión de referencia casi 2 años, y la cifra del dashboard algo menos de 1.</li>', 1),
    ('raises the Reference version by about 2 years, and the dashboard figure by just under 1.</li>',
     'raises the Reference version by almost 2 years, and the dashboard figure by just under 1.</li>', 1),
    ('suplementación de creatina eleva creatinina sin afectar función renal). Ajustamos automáticamente la creatinina cuando el usuario reporta suplementación (Kreider 2017).</li>',
     'suplementación de creatina eleva creatinina sin afectar función renal, Kreider 2017). Cuando el usuario declara que toma creatina, restamos a la creatinina una cantidad que depende de la dosis, hasta 0,40 mg/dL. Es una estimación de EVA.</li>', 1),
    ('creatine supplementation elevates creatinine without affecting kidney function). We automatically adjust creatinine when the user reports supplementation (Kreider 2017).</li>',
     "creatine supplementation elevates creatinine without affecting kidney function, Kreider 2017). When the user reports taking creatine, we subtract a dose-based amount from creatinine, up to 0.40 mg/dL. This is EVA's estimate.</li>", 1),
    ('ACE inhibidores (elevan creatinina)', 'inhibidores de la ECA (elevan creatinina)', 1),
    # §09 title parity with the Spanish question.
    ('title: "What comes next.",', 'title: "What comes next?",', 1),
])

S = 'src/app/[locale]/(marketing)/science/page.tsx'
apply(S, [
    ('bioAgeLede: "Tu fecha de nacimiento te dice cuánto tiempo has vivido. Tus biomarcadores dicen cuánto tiempo tu cuerpo ha ido deteriorándose. No son el mismo número.",',
     'bioAgeLede: "Tu fecha de nacimiento te dice cuánto tiempo has vivido. Tus biomarcadores permiten estimar cómo envejece tu cuerpo frente a la población. Las dos cifras no tienen por qué coincidir.",', 1),
    ('bioAgeLede: "Your birthday tells you how long you have been alive. Your biomarkers tell you how long your body has been wearing down. They are not the same number.",',
     'bioAgeLede: "Your birthday tells you how long you have been alive. Your biomarkers give an estimate of how your body is aging compared with the population. The two numbers need not match.",', 1),
    ('contrastLine1: "La edad biológica te compara con todos los demás de tu edad.",',
     'contrastLine1: "La edad biológica te compara con la población de referencia.",', 1),
    ('contrastLine1: "Biological age compares you to everyone else your age.",',
     'contrastLine1: "Biological age compares you with a reference population.",', 1),
])

D = 'src/app/[locale]/(dashboard)/dashboard/dashboard-client.tsx'
apply(D, [
    ('kdmCalibration: "Ajustado en parte a valores españoles",', 'kdmCalibration: "Estimación ajustada en parte a valores españoles",', 1),
    ('kdmCalibration: "Partly adjusted to Spanish values",', 'kdmCalibration: "An estimate, partly adjusted to Spanish values",', 1),
])

L = 'src/app/[locale]/(dashboard)/labs/labs-client.tsx'
apply(L, [
    ('kicker: "§ Lectura biológica",', 'kicker: "§ Edad biológica estimada",', 1),
    ('kicker: "§ Specimen reading",', 'kicker: "§ Estimated biological age",', 1),
])

AI = 'src/app/[locale]/(dashboard)/eva-ai/eva-ai-client.tsx'
apply(AI, [
    ('kicker: { en: "Biological age", es: "Edad biologica" },', 'kicker: { en: "Biological age", es: "Edad biológica" },', 1),
    ('es: "Explicame mi edad biologica",', 'es: "Explícame mi edad biológica",', 1),
])

H = 'src/app/[locale]/(marketing)/page.tsx'
apply(H, [
    ('{ id: 3, title: "15 marcadores, 4× al año" },', '{ id: 3, title: "13 pruebas, 4× al año" },', 1),
    ('{ id: 3, title: "15 markers, 4× a year" },', '{ id: 3, title: "13 tests, 4× a year" },', 1),
    (' * needle-free kit that captures a sample for ~15 biomarkers per\n', ' * needle-free kit that captures a sample for the 13 Base Panel tests per\n', 1),
    (' * markers" — which was wrong. More data is always better; the 15\n', ' * markers" — which was wrong. More data is always better; the 13\n', 1),
    (' * a high-signal baseline at home every 3 months produces 60 data\n', ' * a high-signal baseline at home every 3 months produces 52 data\n', 1),
])

T = 'src/lib/marketing-translations.ts'
apply(T, [
    ('pricingDesc: "15 biomarcadores base + calculo de Edad Biologica + plataforma completa de inteligencia de salud. Elige que medir cada trimestre. Cancela cuando quieras.",',
     'pricingDesc: "13 pruebas del Panel Base + cálculo de la edad biológica + plataforma completa de inteligencia de salud. Elige qué medir cada trimestre. Cancela cuando quieras.",', 1),
    ('pricingDesc: "15 base biomarkers + Biological Age calculation + full health intelligence platform. Choose what to measure each quarter. Cancel anytime.",',
     'pricingDesc: "13 Base Panel tests + Biological Age calculation + full health intelligence platform. Choose what to measure each quarter. Cancel anytime.",', 1),
])

P = 'src/app/[locale]/(marketing)/pricing/copy.ts'
EN_OLD = '''      {
        code: "HbA1c",
        name: "Hemoglobin A1c",
        value: "5.2",
        unit: "%",
        position: 48,
        zoneMid: 42,
        zoneWidth: 35,
        status: "optimal",
      },
      {
        code: "Ins",
        name: "Fasting Insulin",
        value: "4.8",
        unit: "µIU/mL",
        position: 32,
        zoneMid: 35,
        zoneWidth: 40,
        status: "optimal",
      },
      {
        code: "Vit D",
        name: "25(OH) Vitamin D",
        value: "38",
        unit: "ng/mL",
        position: 74,
        zoneMid: 60,
        zoneWidth: 22,
        status: "watch",
      },
      {
        code: "Ferr",
        name: "Ferritin",
        value: "92",
        unit: "ng/mL",
        position: 54,
        zoneMid: 50,
        zoneWidth: 60,
        status: "optimal",
      },
'''
ES_OLD = EN_OLD.replace('"Hemoglobin A1c"', '"Hemoglobina A1c"').replace('"Fasting Insulin"', '"Insulina en ayunas"') \
    .replace('"25(OH) Vitamin D"', '"25(OH) Vitamina D"').replace('"Ferritin"', '"Ferritina"')


def rows(names, uric):
    ggt, alt, ua, alb = names
    return f'''      {{
        code: "GGT",
        name: "{ggt}",
        value: "16",
        unit: "U/L",
        position: 24,
        zoneMid: 22,
        zoneWidth: 30,
        status: "optimal",
      }},
      {{
        code: "ALT",
        name: "{alt}",
        value: "19",
        unit: "U/L",
        position: 30,
        zoneMid: 32,
        zoneWidth: 36,
        status: "optimal",
      }},
      {{
        code: "UA",
        name: "{ua}",
        value: "{uric}",
        unit: "mg/dL",
        position: 44,
        zoneMid: 45,
        zoneWidth: 34,
        status: "optimal",
      }},
      {{
        code: "Alb",
        name: "{alb}",
        value: "41",
        unit: "g/L",
        position: 56,
        zoneMid: 74,
        zoneWidth: 30,
        status: "watch",
      }},
'''


apply(P, [
    (EN_OLD, rows(("Gamma-glutamyl transferase", "Alanine aminotransferase", "Uric acid", "Albumin"), "4.6"), 1),
    (ES_OLD, rows(("Gamma-glutamil transferasa", "Alanina aminotransferasa", "Ácido úrico", "Albúmina"), "4,6"), 1),
    ('''        code: "hs-PCR",
        name: "PCR Ultrasensible",
        value: "0.6",''', '''        code: "hs-PCR",
        name: "PCR Ultrasensible",
        value: "0,6",''', 1),
])


for path, text in PENDING.items():
    open(R + path, 'w', encoding='utf-8').write(text)
    print('written', path)
