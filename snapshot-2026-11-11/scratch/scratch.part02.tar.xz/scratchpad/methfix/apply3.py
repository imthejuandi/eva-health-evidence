import sys, json
R='/home/user/eva-health/'
def apply(path, pairs):
    s=open(R+path,encoding='utf-8').read()
    for old,new,count in pairs:
        n=s.count(old)
        if n!=count: sys.exit(f"{path}: expected {count} of {old[:80]!r}, found {n}")
        s=s.replace(old,new)
    open(R+path,'w',encoding='utf-8').write(s); print('ok', path, len(pairs))

M='src/app/[locale]/(marketing)/metodologia/page.tsx'
apply(M,[
 ('heroTitle: "Cómo medimos tu edad biológica."','heroTitle: "Cómo estimamos tu edad biológica."',1),
 ('heroTitle: "How we measure your biological age."','heroTitle: "How we estimate your biological age."',1),
 ('lo sube unas 0,009','lo sube unos 0,009',1),
 ('methodTitle: "Klemera-Doubal, ajustado en parte con medias españolas."','methodTitle: "Klemera-Doubal, ajustado en parte con valores españoles."',1),
 ('methodTitle: "Klemera-Doubal, partly adjusted with Spanish means."','methodTitle: "Klemera-Doubal, partly adjusted with Spanish values."',1),
 ('en tres de esos cuatro no hemos podido verificar las medias por sexo en las fuentes citadas.','en tres de esos cuatro (creatinina, ácido úrico y GGT) no hemos podido verificar las medias por sexo en las fuentes citadas.',1),
 ('entre ellos la hemoglobina y la testosterona total, también por sexo.','entre ellos la hemoglobina y la testosterona total, también por sexo. Para estas dos tampoco hemos podido verificar las medias por sexo en las fuentes citadas.',1),
 ('cercana a su edad real, y no a la media estadounidense.','cercana a su edad real, y no desplazada por las diferencias con la población de Estados Unidos.',1),
 ('for three of those four we could not verify the per-sex means in the cited sources.','for three of those four (creatinine, uric acid and GGT) we could not verify the per-sex means in the cited sources.',1),
 ('including hemoglobin and total testosterone, also by sex.','including hemoglobin and total testosterone, also by sex. For these two, we could not verify the per-sex means in the cited sources either.',1),
 ('close to their real age, not the U.S. average.','close to their real age, not one shifted by differences from the U.S. population.',1),
 ('"Cistatina C cuando está disponible, en lugar de la creatinina (marcador renal menos afectado por la masa muscular).",',
  '"Cistatina C cuando está disponible, en lugar de la creatinina (marcador renal menos afectado por la masa muscular), en la versión completa del dashboard. En la versión de referencia, la creatinina se retira y la cistatina C no se usa.",',1),
 ('"Cystatin C when available, in place of creatinine (kidney marker less affected by muscle mass).",',
  '"Cystatin C when available, in place of creatinine (kidney marker less affected by muscle mass), in the Comprehensive version shown on the dashboard. In the Reference version, creatinine is removed and cystatin C is not used.",',1),
 ('        // Items 5 to 8 are the known limits of this version. Each is backed\n        // by EVA\'s own files: docs/biomarker-evidence/longevity/base-panel/\n        // NUMBERS.md (sections A and E) and ASSESSMENT.md (F1, F5),',
  '        // Items 5 to 10 are the known limits of this version. Each is backed\n        // by EVA\'s own files: docs/biomarker-evidence/longevity/base-panel/\n        // NUMBERS.md (sections A, C, D and E), ASSESSMENT.md (F1, F3, F4, F5)\n        // and KDM-DIRECTION.md,',1),
 ('          "No se ha evaluado frente a la mortalidad en España. Las cifras de mortalidad proceden de NHANES, en Estados Unidos, y de los mismos datos con los que se construyó el modelo.",\n        ],',
  '          "No se ha evaluado frente a la mortalidad en España. Las cifras de mortalidad proceden de NHANES, en Estados Unidos, y de los mismos datos con los que se construyó el modelo.",\n          "Algunas mejoras pueden subir la cifra: el modelo solo tiene en cuenta cómo cambia cada marcador con la edad en NHANES. Con el Panel Base, en un hombre típico de 45 años, subir el HDL de 47 a 57 mg/dL o bajar la GGT de 32 a 15 U/L sube la versión de referencia unos 2 años, y la cifra del dashboard algo menos de 1.",\n          "La cifra depende de qué pruebas se hicieron. En simulaciones de EVA, la misma persona dio en la versión de referencia entre 3 y 7 años más con solo el Panel Base que con un panel completo, en seis de siete casos.",\n        ],',1),
 ('        // Items 5 to 8: see the source note on the Spanish list above.','        // Items 5 to 10: see the source note on the Spanish list above.',1),
 ('          "It has not been tested against recorded deaths in Spain. The mortality figures come from NHANES, in the United States, and from the same data the model was built on.",\n        ],',
  '          "It has not been tested against recorded deaths in Spain. The mortality figures come from NHANES, in the United States, and from the same data the model was built on.",\n          "Some improvements can raise the figure: the model only takes into account how each marker changes with age in NHANES. With the Base Panel, for a typical 45-year-old man, raising HDL from 47 to 57 mg/dL or lowering GGT from 32 to 15 U/L raises the Reference version by about 2 years, and the dashboard figure by just under 1.",\n          "The figure depends on which tests were done. In EVA\'s simulations, the same person read 3 to 7 years older in the Reference version with the Base Panel alone than with a full panel, in six of seven cases.",\n        ],',1),
 ('el ajuste con medias españolas, el método matemático','el ajuste con valores españoles, el método matemático',1),
 ('the adjustment with Spanish means, the mathematical method','the adjustment with Spanish values, the mathematical method',1),
])

C='src/app/[locale]/(marketing)/metodologia/completa/page.tsx'
apply(C,[
 (' *   4. Ajuste con medias españolas',' *   4. Ajuste con valores españoles',1),
 ('title: "Ajuste con medias españolas.",','title: "Ajuste con valores españoles.",',1),
 ('title: "Adjustment with Spanish means.",','title: "Adjustment with Spanish values.",',1),
 ('en 1.629 adultos con función tiroidea normal.','en 1.629 adultos con función tiroidea normal. Esa fuente también da la mediana, no la media.',1),
 ('in 1,629 adults with normal thyroid function.','in 1,629 adults with normal thyroid function. That source also gives the median, not the mean.',1),
 ('como el colesterol LDL, la hemoglobina o la testosterona total.</>','como el colesterol LDL, la hemoglobina o la testosterona total. Sus valores proceden de PESA y de otros estudios españoles; para la hemoglobina y la testosterona total tampoco hemos podido verificar las medias por sexo.</>',1),
 ('such as LDL cholesterol, hemoglobin or total testosterone.</>','such as LDL cholesterol, hemoglobin or total testosterone. Their values come from PESA and other Spanish studies; for hemoglobin and total testosterone we could not verify the per-sex means either.</>',1),
 ('El ajuste con medias españolas no se ha evaluado frente a la mortalidad.</li>',
  'El ajuste con valores españoles no se ha evaluado frente a la mortalidad.</li>\n              <li><strong>Algunas mejoras pueden subir la cifra</strong>. El modelo solo tiene en cuenta cómo cambia cada marcador con la edad en NHANES. Con el Panel Base, en un hombre típico de 45 años, subir el HDL de 47 a 57 mg/dL o bajar la GGT de 32 a 15 U/L sube la versión de referencia unos 2 años, y la cifra del dashboard algo menos de 1.</li>\n              <li><strong>La cifra depende de qué pruebas se hicieron</strong>. En simulaciones de EVA, la misma persona dio en la versión de referencia entre 3 y 7 años más con solo el Panel Base que con un panel completo, en seis de siete casos.</li>',1),
 ('The adjustment with Spanish means has not been tested against recorded deaths.</li>',
  'The adjustment with Spanish values has not been tested against recorded deaths.</li>\n              <li><strong>Some improvements can raise the figure</strong>. The model only takes into account how each marker changes with age in NHANES. With the Base Panel, for a typical 45-year-old man, raising HDL from 47 to 57 mg/dL or lowering GGT from 32 to 15 U/L raises the Reference version by about 2 years, and the dashboard figure by just under 1.</li>\n              <li><strong>The figure depends on which tests were done</strong>. In EVA\'s simulations, the same person read 3 to 7 years older in the Reference version with the Base Panel alone than with a full panel, in six of seven cases.</li>',1),
 ('lo subió unas <strong>0,009</strong>','lo subió unos <strong>0,009</strong>',2),
 ('la ganancia fue de unas 0,003','la ganancia fue de unos 0,003',1),
 ('Para estudiarlo ajustamos','Para estudiarlo, ajustamos',1),
 ('<>En la versión <strong>v2.2.2</strong> (mayo de 2026):</>','<>En la evaluación hecha en mayo de 2026 para la versión <strong>v2.2.2</strong>, con parámetros algo distintos de los que se usan hoy:</>',1),
 ('<>In version <strong>v2.2.2</strong> (May 2026):</>','<>In the evaluation run in May 2026 for version <strong>v2.2.2</strong>, with parameters slightly different from those in use today:</>',1),
 ('<>El IGF-1, no medido en los ciclos continuos, se incorporó del legado NHANES III (1988-1994).','<>El IGF-1 se tomó de NHANES III (1988-1994).',1),
 ('<>IGF-1, not measured in the continuous cycles, was incorporated from NHANES III legacy data (1988-1994).','<>IGF-1 was taken from NHANES III (1988-1994).',1),
])

S='src/app/[locale]/(marketing)/science/page.tsx'
apply(S,[
 ('dataEyebrow: "↳ La ciencia, en práctica",','dataEyebrow: "↳ La ciencia, en la práctica",',1),
 ('aiUserMsg: "My biological age came back 3 years younger. What moved it?",','aiUserMsg: "My biological age dropped 3 years. What moved it?",',1),
])
apply('src/app/[locale]/(dashboard)/dashboard/dashboard-client.tsx',[('older: "años más mayor",','older: "años mayor",',1)])

H='src/app/[locale]/(marketing)/page.tsx'
apply(H,[
 ('"Nuestro panel base lee 15 biomarcadores fundamentales de longevidad (ApoB, hs-CRP, insulina en ayunas, y los que realmente predicen el envejecimiento) en casa, cada 3 meses. Son 60 puntos al año sobre lo que de verdad importa. El panel completo de 165+ está a un clic cuando quieras ir más profundo. Abajo: cinco lecturas reales que tu médico llamaría «bien».",',
  '"Nuestro Panel Base lee 13 pruebas en casa, cada 3 meses, entre ellas ApoB, PCR-hs y fructosamina, además de lípidos, riñón e hígado. Son 52 resultados al año. El panel completo de 165+ está a un clic cuando quieras ir más profundo. Abajo: cinco lecturas reales que tu médico llamaría «bien».",',1),
 ('"Our base panel reads 15 foundational longevity markers (ApoB, hs-CRP, fasting insulin, and the biomarkers that actually track ageing) at home, every 3 months. Sixty data points a year on what truly moves. The full 165+ panel is one click away when you want to go deeper. Below: five real readings your GP would call \\u201cfine.\\u201d",',
  '"Our Base Panel reads 13 tests at home, every 3 months, including ApoB, hs-CRP and fructosamine, plus lipids, kidney and liver. That is 52 results a year. The full 165+ panel is one click away when you want to go deeper. Below: five real readings your GP would call \\u201cfine.\\u201d",',1),
 ('"Cada 3 meses, 15 biomarcadores fundamentales de longevidad: ApoB, hs-CRP, insulina en ayunas, y los que marcan el envejecimiento. Repetidos, se vuelven una trayectoria.",',
  '"Cada 3 meses, las 13 pruebas del Panel Base: ApoB, PCR-hs, fructosamina, lípidos, riñón e hígado. Repetidas, se vuelven una trayectoria.",',1),
 ('"Every quarter, 15 foundational longevity markers: ApoB, hs-CRP, fasting insulin, and the biomarkers that actually track ageing. Repeated, they become a trendline.",',
  '"Every quarter, the 13 Base Panel tests: ApoB, hs-CRP, fructosamine, lipids, kidney and liver. Repeated, they become a trendline.",',1),
 ('EVA la mide cada trimestre, y la ve moverse mientras tú cambias.','EVA la estima cada trimestre y sigue su tendencia.',1),
 ('Eva measures it every quarter, and watches it move as you change.','EVA estimates it every quarter and follows its trend.',1),
])
HW='src/app/[locale]/(marketing)/how-it-works/page.tsx'
apply(HW,[
 ('"Cada trimestre, EVA lee tu linea base de nuevo. 15 biomarcadores, 4 veces al año, 60 puntos de datos rastreando como envejeces. Cada lectura afina la señal."',
  '"Cada trimestre, EVA lee tu línea base de nuevo. 13 pruebas, 4 veces al año, 52 resultados que siguen cómo envejeces. Cada lectura afina la señal."',1),
 ('d: "15 biomarcadores esenciales"','d: "13 pruebas esenciales"',1),
 ('"Every quarter, EVA reads your baseline again. 15 biomarkers, 4 times a year, 60 data points tracking how you age. Each reading sharpens the signal."',
  '"Every quarter, EVA reads your baseline again. 13 tests, 4 times a year, 52 results tracking how you age. Each reading sharpens the signal."',1),
 ('d: "15 core biomarkers"','d: "13 core tests"',1),
])
P='src/app/[locale]/(marketing)/pricing/copy.ts'
apply(P,[
 ('"15 core biomarkers, needle-free at-home kit"','"13 core biomarkers, needle-free at-home kit"',1),
 ('Receive 15 biomarkers reinterpreted','Receive 13 biomarkers reinterpreted',1),
 ('{ label: "Biomarkers analyzed", cells: ["Uploaded", "15", "40+"] }','{ label: "Biomarkers analyzed", cells: ["Uploaded", "13", "40+"] }',1),
 ('"15-biomarker panel, needle-free kit','"13-biomarker panel, needle-free kit',1),
 ('"15 biomarcadores esenciales, kit sin aguja"','"13 biomarcadores esenciales, kit sin aguja"',1),
 ('Recibe 15 biomarcadores reinterpretados','Recibe 13 biomarcadores reinterpretados',1),
 ('{ label: "Biomarcadores analizados", cells: ["Los tuyos", "15", "40+"] }','{ label: "Biomarcadores analizados", cells: ["Los tuyos", "13", "40+"] }',1),
 ('"Panel de 15 biomarcadores, kit sin aguja','"Panel de 13 biomarcadores, kit sin aguja',1),
])
apply('src/lib/email/templates/welcome.ts',[
 ('15 biomarcadores base con interpretacion de rangos optimos','13 biomarcadores base con interpretación de rangos óptimos',1),
 ('15 base biomarkers with longevity-optimal range interpretation','13 base biomarkers with longevity-optimal range interpretation',1),
])
# library: testosterone citation (text only)
L='src/lib/biomarkers/data/marker_library_v2_2.json'
apply(L,[('"source_citation": "García-Cruz E, Serapio O, et al. (citing prior Valencia blood bank study) (2008). Cambios en las hormonas sexuales en varones mayores de 50 años (citing Valencia reference study). Actas Urológicas Españolas",',
          '"source_citation": "Martínez Jabaloyas JM, Queipo Zaragoza A, Ferrandis Cortes C, et al. (2008). Cambios en las hormonas sexuales en varones mayores de 50 años. Prevalencia de niveles bajos de testosterona y factores de riesgo. Actas Urol Esp 32(6):603-610 (PMID 18655343). Study of 230 men over 50; the women\'s value is not from it.",',1)])
json.load(open(R+L,encoding='utf-8')); print('library json ok')
CF='docs/biomarker-evidence/longevity/METHODOLOGY-CLAIMS-FOR-COUNSEL.md'
apply(CF,[
 ('> Spanish means for 9 of the 14 markers.','> Spanish values for 9 of the 14 markers; four are medians (creatinine, GGT, hs-CRP and TSH; Alonso et al. give TSH\n> only as a median, Table 1).',1),
 ('> **Corrected again on 29 October 2026, after two independent reviews.**','> **Corrected again on 29 October 2026, after an independent review; a second review followed, and its fixes were\n> applied the same day.** The pages use v2.2.2, the version name of the deployed parameters; the per-sex Spanish fix of\n> May 2026 is described in the text.',1),
])
