import sys
ROOT='/home/user/eva-health/src/app/[locale]/(marketing)/'
def apply(path, pairs):
    s=open(path,encoding='utf-8').read()
    for old,new,count in pairs:
        n=s.count(old)
        if n!=count:
            sys.exit(f"{path}: expected {count} of {old[:70]!r}, found {n}")
        s=s.replace(old,new)
    open(path,'w',encoding='utf-8').write(s)
    print('edited', path.split('(marketing)/')[1], len(pairs), 'replacements')

M=ROOT+'metodologia/page.tsx'
apply(M, [
 ("No es una opinión. No es un score genérico. Es una predicción de mortalidad validada en 18.570 personas — con un margen de incertidumbre que reconocemos abiertamente.",
  "No es una opinión ni un score genérico. Es una estimación comprobada frente a la mortalidad en 18.570 adultos de NHANES, con limitaciones que explicamos abiertamente.",1),
 ("El algoritmo se valida contra mortalidad real, usando un protocolo de validación cruzada (5-fold) que separa los datos de entrenamiento de los de validación.",
  "El algoritmo se comprobó frente a las muertes registradas en NHANES, los mismos datos con los que se construyó.",1),
 ('sig1Val: "1.29",\n        sig1Label: "por desviación estándar",', 'sig1Val: "1,39",\n        sig1Label: "por desviación estándar",',1),
 ("Cada desviación estándar de aceleración de edad biológica corresponde a un 29% más de riesgo relativo de mortalidad. Validación fuera de muestra (5-fold CV); intervalo de confianza 95% [1.20, 1.40].",
  "Cada desviación estándar de aceleración de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (panel de referencia, NHANES).",1),
 ('sig2Val: "0.77",\n        sig2Label: "discriminación predictiva",', 'sig2Val: "0,77",\n        sig2Label: "discriminación predictiva",',1),
 ("Cuando comparamos dos personas, el modelo identifica correctamente cuál tiene mayor riesgo el 77% del tiempo. La versión Comprehensive (panel extendido) sube a 0.78 con HR/SD 1.49.",
  "Cuando comparamos dos personas, el modelo identifica correctamente cuál tiene mayor riesgo el 77% del tiempo. El modelo incluye también la edad y el sexo. La versión Comprehensive (panel extendido): C-statistic 0,775, HR por DE 1,65.",1),
 ("Entrenado en datos del National Health and Nutrition Examination Survey (1999-2018), con seguimiento de mortalidad hasta 2019. Recalibrado para España con 11 de 14 marcadores del panel base.",
  "Entrenado en datos del National Health and Nutrition Examination Survey (1999-2018), con seguimiento de mortalidad hasta 2019. Usa medias de población española en 9 de los 14 marcadores del panel base.",1),
 ('methodTitle: "Klemera-Doubal, recalibrado para España."', 'methodTitle: "Klemera-Doubal, ajustado con datos españoles."',1),
 ("Para el mercado español hemos recalibrado los valores promedio de 11 de 14 marcadores del panel base usando cohortes españolas: PESA (Fernández-Friera 2015), ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja y SEQC. Incluye recalibración por sexo para Creatinina, Ácido Úrico, GGT, HDL, Hemoglobina y Testosterona Total (corregido en mayo de 2026 tras detectar que estos valores no se estaban aplicando). Un español con valores típicos para su edad obtiene una edad biológica cercana a su edad real — no a la media estadounidense.",
  "Para el mercado español hemos sustituido los valores promedio de 9 de los 14 marcadores del panel base por valores publicados de estudios españoles, sobre todo el estudio PESA (Fernández-Friera 2015). Incluye recalibración por sexo para Creatinina, Ácido Úrico, GGT, HDL, Hemoglobina y Testosterona Total (corregido en mayo de 2026 tras detectar que estos valores no se estaban aplicando). Albúmina, BUN, fosfatasa alcalina, ferritina y fructosamina siguen usando las referencias de NHANES. El objetivo es que un español con valores típicos para su edad obtenga una edad biológica cercana a su edad real, y no a la media estadounidense. Este ajuste no se ha comprobado todavía frente a la mortalidad en población española.",1),
 ("Not an opinion. Not a generic score. A mortality prediction validated in 18,570 people — with an uncertainty margin we acknowledge openly.",
  "Not an opinion, and not a generic score. An estimate tested against mortality in 18,570 NHANES adults, with limits we explain openly.",1),
 ("The algorithm is validated against real mortality using out-of-sample cross-validation (5-fold), so the numbers below reflect performance on held-out data, not the training set.",
  "The algorithm was tested against recorded deaths in NHANES, the same data it was built on.",1),
 ('sig1Val: "1.29",\n        sig1Label: "per standard deviation",', 'sig1Val: "1.39",\n        sig1Label: "per standard deviation",',1),
 ("Each standard deviation of biological age acceleration corresponds to a 29% higher relative mortality risk. Out-of-sample (5-fold CV); 95% CI [1.20, 1.40].",
  "Each standard deviation of biological age acceleration goes with about 39% higher relative mortality risk (Reference panel, NHANES).",1),
 ("When comparing two people, the model correctly identifies which one has higher risk 77% of the time. The Comprehensive version (extended panel) rises to 0.78 with HR/SD 1.49.",
  "When comparing two people, the model correctly identifies which one has higher risk 77% of the time. The model also includes age and sex. The Comprehensive version (extended panel): C-statistic 0.775, HR per SD 1.65.",1),
 ("Trained on the U.S. National Health and Nutrition Examination Survey (1999-2018), with mortality follow-up through 2019. Recalibrated for Spain on 11 of 14 base-panel markers.",
  "Trained on the U.S. National Health and Nutrition Examination Survey (1999-2018), with mortality follow-up through 2019. Uses Spanish population means for 9 of the 14 base-panel markers.",1),
 ('methodTitle: "Klemera-Doubal, recalibrated for Spain."', 'methodTitle: "Klemera-Doubal, adjusted with Spanish data."',1),
 ("For the Spanish market we recalibrated the population means of 11 of 14 base-panel markers using Spanish cohorts: PESA (Fernández-Friera 2015), ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, and SEQC. Includes per-sex recalibration for Creatinine, Uric Acid, GGT, HDL, Hemoglobin, and Total Testosterone (corrected in May 2026 after detecting these values weren't being applied). A Spanish person with typical values for their age gets a biological age close to their real age — not the U.S. average.",
  "For the Spanish market we replaced the population means of 9 of the 14 base-panel markers with published values from Spanish studies, mostly the PESA study (Fernández-Friera 2015). Includes per-sex recalibration for Creatinine, Uric Acid, GGT, HDL, Hemoglobin, and Total Testosterone (corrected in May 2026 after detecting these values weren't being applied). Albumin, BUN, alkaline phosphatase, ferritin and fructosamine still use NHANES references. The aim is that a Spanish person with typical values for their age gets a biological age close to their real age, not the U.S. average. This adjustment has not yet been tested against mortality in the Spanish population.",1),
])

C=ROOT+'metodologia/completa/page.tsx'
apply(C, [
 (" * /metodologia/completa — deep methodology document for KDM v2.2.1.", " * /metodologia/completa — deep methodology document for KDM v2.2.2.",1),
 ("<>EVA Health calcula tu edad biológica con el algoritmo <strong>KDM v2.2.1</strong>, una implementación del método Klemera-Doubal (2006) entrenada en 18.570 adultos del estudio NHANES (1999-2018) y recalibrada para la población española usando ocho cohortes nacionales (PESA, ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, SEQC).</>",
  "<>EVA Health calcula tu edad biológica con el algoritmo <strong>KDM v2.2.2</strong>, una implementación del método Klemera-Doubal (2006) entrenada en 18.570 adultos del estudio NHANES (1999-2018), con medias de población española en 9 de los 14 marcadores del panel base, tomadas sobre todo del estudio PESA.</>",1),
 ("<>El algoritmo predice mortalidad con un hazard ratio de <strong>1,41 por desviación estándar</strong> [IC 95% 1,32-1,50] y un C-statistic de <strong>0,77</strong> — superando el umbral de excelencia (≥ 0,75) en discriminación de riesgo. Los parámetros del modelo se actualizaron en mayo de 2026 (v2.2.1) tras un análisis post-implementación que identificó un sesgo de ponderación en dos marcadores; la nueva versión es <em>más</em> discriminativa que la original.</>",
  "<>En los datos de NHANES con los que se construyó, el hazard ratio es de <strong>1,39 por desviación estándar</strong> (1,65 con el panel completo) y el C-statistic de <strong>0,77</strong>. En mayo de 2026 (v2.2.2) se reajustaron todos los marcadores con valores de NHANES sin winsorizar.</>",1),
 ("<>EVA calcula tu edad biológica combinando 14 biomarcadores sanguíneos clave en un único estimador estadístico, validado contra mortalidad real. No es un score de bienestar genérico. Es una predicción.</>",
  "<>EVA calcula tu edad biológica combinando 14 biomarcadores sanguíneos clave en un único estimador estadístico, comprobado frente a las muertes registradas en NHANES. No es un score de bienestar genérico.</>",1),
 ("<>Las cohortes españolas que contribuyeron a la recalibración: <strong>PESA</strong> (Fernández-Friera 2015, n=4.066), <strong>ENRICA</strong> (Soriano-Maldonado 2016), <strong>Di@bet.es</strong> (Soriguer 2012), <strong>Hortega</strong>, <strong>PREDIMED</strong>, <strong>EPIRCE</strong>, <strong>La Rioja</strong> y la base de datos <strong>SEQC</strong> (Sociedad Española de Química Clínica). En la versión 2.2.1 hemos recalibrado con éxito 5 de los 14 marcadores del panel base con datos primarios españoles disponibles: Colesterol Total, Triglicéridos, PCR-hs, Vitamina D y TSH. Los nueve restantes usan referencias NHANES — un objetivo activo de versiones futuras.</>",
  "<>Las fuentes españolas de las medias: el estudio <strong>PESA</strong> (Fernández-Friera 2015, n=4.066) para colesterol total, colesterol HDL, triglicéridos, PCR-hs, creatinina, ácido úrico y GGT; un estudio en atención primaria (Fernández-García 2021) para la vitamina D; y un estudio poblacional nacional (Alonso 2025) para la TSH. Así, 9 de los 14 marcadores del panel base usan medias españolas: cinco para ambos sexos (colesterol total, triglicéridos, PCR-hs, vitamina D y TSH) y cuatro por sexo (creatinina, HDL, ácido úrico y GGT). Los cinco restantes (albúmina, BUN, fosfatasa alcalina, ferritina y fructosamina) usan referencias de NHANES. Estas medias proceden de resúmenes publicados, no de datos individuales, y el ajuste no se ha comprobado todavía frente a la mortalidad en población española.</>",1),
 ('title: "Validación contra mortalidad.",', 'title: "Comprobación frente a la mortalidad.",',1),
 ("Lo respondimos ajustando un modelo de Cox de riesgos proporcionales en el subconjunto NHANES con seguimiento completo, ajustando por edad cronológica y sexo.</>",
  "Lo respondimos ajustando un modelo de Cox de riesgos proporcionales en el subconjunto NHANES con seguimiento completo, ajustando por edad cronológica y sexo. Son los mismos adultos con los que se construyó el modelo.</>",1),
 ("<>En la versión <strong>v2.2.1</strong> (mayo 2026, con parámetros corregidos para BUN y Fructosamine tras un análisis post-implementación):</>",
  "<>En la versión <strong>v2.2.2</strong> (mayo 2026, todos los marcadores reajustados con valores de NHANES sin winsorizar):</>",1),
 ("<li><strong>Hazard Ratio por SD</strong>: 1,41 [IC 95% 1,32-1,50]. Cada año adicional de aceleración de edad biológica predice un 41% más de riesgo relativo de mortalidad.</li>",
  "<li><strong>Hazard ratio por DE</strong>: 1,39 (referencia) y 1,65 (completa). Cada desviación estándar de aceleración de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (referencia).</li>",1),
 ("<li><strong>C-statistic</strong>: 0,77. Por encima del umbral de excelencia (≥ 0,75) usado en la literatura de bioage.</li>",
  "<li><strong>C-statistic</strong>: 0,77 (referencia) y 0,775 (completa), en un modelo que incluye también la edad y el sexo.</li>",1),
 ("              <li><strong>Pendiente de calibración</strong>: 1,02. Dentro del rango ideal [0,9, 1,1], indicando que las predicciones son ni infladas ni infradimensionadas.</li>\n","",1),
 ("            <>Para contexto: la edad cronológica sola en este mismo modelo tiene C-statistic 0,79 (un techo natural — la mortalidad está fuertemente correlacionada con la edad). El KDM añade información incremental que captura aceleración o desaceleración respecto a esa trayectoria.</>,\n","",1),
 ("<li><strong>Edad biológica de referencia (BA)</strong>: calculada con los 14 marcadores del panel base — los más validados, más universalmente disponibles. Es el número principal mostrado en el dashboard.</li>",
  "<li><strong>Edad biológica de referencia (BA)</strong>: calculada con los 14 marcadores del panel base. Es el número del dashboard cuando no se puede calcular la versión completa.</li>",1),
 ("cuando el usuario sube un perfil extenso. Tiene menor varianza pero menor robustez clínica.</li>",
  "cuando el usuario sube un perfil extenso. Comprobada de la misma forma: HR por DE 1,65, C-statistic 0,775.</li>",1),
 ("<>Ambas usan el mismo método matemático; difieren en la amplitud de marcadores. La versión de referencia es la que validamos contra mortalidad y la que recomendamos confiar para decisiones longitudinales. La versión completa es un compañero opcional para usuarios con paneles extendidos.</>",
  "<>Ambas usan el mismo método matemático; difieren en la amplitud de marcadores. Ambas versiones se comprobaron frente a la mortalidad en NHANES (HR por DE 1,39 y 1,65), en los mismos datos con los que se construyeron.</>",1),
 ("En v2.2.1 ajustamos automáticamente la creatinina cuando el usuario reporta suplementación.", "Ajustamos automáticamente la creatinina cuando el usuario reporta suplementación.",1),
 ("<>El algoritmo es una versión 2.2.1, no 1.0.", "<>El algoritmo es una versión 2.2.2, no 1.0.",1),
 ("para los 9 marcadores restantes del panel base, conforme tengamos datos cohortales primarios.", "para los 5 marcadores restantes del panel base, conforme tengamos datos cohortales primarios.",1),
 ("              <li><strong>Reentrenamiento sin winsorización</strong> aplicado a todos los marcadores (en v2.2.1 lo aplicamos solo a BUN y Fructosamina como override).</li>\n","",1),
 ("<>EVA Health calculates your biological age with the <strong>KDM v2.2.1</strong> algorithm, an implementation of the Klemera-Doubal method (2006) trained on 18,570 adults from the U.S. NHANES study (1999-2018) and recalibrated for the Spanish population using eight national cohorts (PESA, ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, SEQC).</>",
  "<>EVA Health calculates your biological age with the <strong>KDM v2.2.2</strong> algorithm, an implementation of the Klemera-Doubal method (2006) trained on 18,570 adults from the U.S. NHANES study (1999-2018), with Spanish population means for 9 of the 14 base-panel markers, taken mostly from the PESA study.</>",1),
 ("<>The algorithm predicts mortality with a hazard ratio of <strong>1.41 per standard deviation</strong> [95% CI 1.32-1.50] and a C-statistic of <strong>0.77</strong> — exceeding the excellence threshold (≥ 0.75) in risk discrimination. The model parameters were updated in May 2026 (v2.2.1) after a post-launch analysis identified a weighting bias in two markers; the new version is <em>more</em> discriminative than the original.</>",
  "<>In the NHANES data it was built on, the hazard ratio is <strong>1.39 per standard deviation</strong> (1.65 with the Comprehensive panel) and the C-statistic is <strong>0.77</strong>. In May 2026 (v2.2.2) every marker was refitted on unwinsorised NHANES values.</>",1),
 ("<>EVA computes your biological age by combining 14 key blood biomarkers into a single statistical estimator, validated against real mortality. It's not a generic wellness score. It's a prediction.</>",
  "<>EVA computes your biological age by combining 14 key blood biomarkers into a single statistical estimator, tested against recorded deaths in NHANES. It's not a generic wellness score.</>",1),
 ("<>Spanish cohorts contributing to recalibration: <strong>PESA</strong> (Fernández-Friera 2015, n=4,066), <strong>ENRICA</strong> (Soriano-Maldonado 2016), <strong>Di@bet.es</strong> (Soriguer 2012), <strong>Hortega</strong>, <strong>PREDIMED</strong>, <strong>EPIRCE</strong>, <strong>La Rioja</strong>, and the <strong>SEQC</strong> (Spanish Society of Clinical Chemistry) database. In version 2.2.1 we successfully recalibrated 5 of the 14 base-panel markers with available primary Spanish data: Total Cholesterol, Triglycerides, hs-CRP, Vitamin D, and TSH. The remaining nine use NHANES references — an active target for future versions.</>",
  "<>The Spanish sources of the means: the <strong>PESA</strong> study (Fernández-Friera 2015, n=4,066) for total cholesterol, HDL cholesterol, triglycerides, hs-CRP, creatinine, uric acid and GGT; a primary-care study (Fernández-García 2021) for vitamin D; and a national population study (Alonso 2025) for TSH. So 9 of the 14 base-panel markers use Spanish means: five for both sexes (total cholesterol, triglycerides, hs-CRP, vitamin D and TSH) and four by sex (creatinine, HDL, uric acid and GGT). The other five (albumin, BUN, alkaline phosphatase, ferritin and fructosamine) use NHANES references. These means come from published summaries, not individual data, and the adjustment has not yet been tested against mortality in the Spanish population.</>",1),
 ("We answered this by fitting a Cox proportional hazards model on the NHANES subset with complete follow-up, adjusted for chronological age and sex.</>",
  "We answered this by fitting a Cox proportional hazards model on the NHANES subset with complete follow-up, adjusted for chronological age and sex. These are the same adults the model was built on.</>",1),
 ("<>In version <strong>v2.2.1</strong> (May 2026, with corrected parameters for BUN and Fructosamine after a post-launch analysis):</>",
  "<>In version <strong>v2.2.2</strong> (May 2026, every marker refitted on unwinsorised NHANES values):</>",1),
 ("<li><strong>Hazard Ratio per SD</strong>: 1.41 [95% CI 1.32-1.50]. Each additional year of biological age acceleration predicts a 41% higher relative mortality risk.</li>",
  "<li><strong>Hazard ratio per SD</strong>: 1.39 (Reference) and 1.65 (Comprehensive). Each standard deviation of biological age acceleration goes with about 39% higher relative mortality risk (Reference).</li>",1),
 ("<li><strong>C-statistic</strong>: 0.77. Above the excellence threshold (≥ 0.75) used in the bio-age literature.</li>",
  "<li><strong>C-statistic</strong>: 0.77 (Reference) and 0.775 (Comprehensive), for a model that also includes age and sex.</li>",1),
 ("              <li><strong>Calibration slope</strong>: 1.02. Within the ideal range [0.9, 1.1], indicating predictions are neither inflated nor under-scaled.</li>\n","",1),
 ("            <>For context: chronological age alone in this same model has C-statistic 0.79 (a natural ceiling — mortality is strongly correlated with age). KDM adds incremental information that captures acceleration or deceleration relative to that trajectory.</>,\n","",1),
 ("<li><strong>Reference Biological Age (BA)</strong>: calculated with the 14 base-panel markers — the most validated, most universally available. This is the headline number on the dashboard.</li>",
  "<li><strong>Reference Biological Age (BA)</strong>: calculated with the 14 base-panel markers. This is the number on the dashboard when the Comprehensive value cannot be calculated.</li>",1),
 ("when the user uploads an extended profile. It has lower variance but lower clinical robustness.</li>",
  "when the user uploads an extended profile. Tested the same way: HR per SD 1.65, C-statistic 0.775.</li>",1),
 ("<>Both use the same mathematical method; they differ in marker breadth. The reference version is the one we validated against mortality and the one we recommend trusting for longitudinal decisions. The comprehensive version is an optional companion for users with extended panels.</>",
  "<>Both use the same mathematical method; they differ in marker breadth. Both versions were tested against mortality in NHANES (HR per SD 1.39 and 1.65), on the same data they were built on.</>",1),
 ("In v2.2.1 we automatically adjust creatinine when the user reports supplementation.", "We automatically adjust creatinine when the user reports supplementation.",1),
 ("<>The algorithm is version 2.2.1, not 1.0.", "<>The algorithm is version 2.2.2, not 1.0.",1),
 ("for the 9 remaining base-panel markers, as we obtain primary cohort data.", "for the 5 remaining base-panel markers, as we obtain primary cohort data.",1),
 ("              <li><strong>Unwinsorized retraining</strong> applied across all markers (in v2.2.1 we applied it only to BUN and Fructosamine as an override).</li>\n","",1),
 ('{es ? "KDM v2.2.1 — el documento de referencia." : "KDM v2.2.1 — the reference document."}', '{es ? "KDM v2.2.2 — el documento de referencia." : "KDM v2.2.2 — the reference document."}',1),
 ('"Cómo entrenamos el modelo, qué datos usamos, cómo lo validamos contra mortalidad y dónde sabemos que tiene límites."', '"Cómo entrenamos el modelo, qué datos usamos, cómo lo comprobamos frente a la mortalidad y dónde sabemos que tiene límites."',1),
 ('"How we trained the model, what data we used, how we validated it against mortality, and where we know it has limits."', '"How we trained the model, what data we used, how we tested it against mortality, and where we know it has limits."',1),
])

S=ROOT+'science/page.tsx'
apply(S, [
 ('bioAgeCred: "El metodo Klemera-Doubal fue publicado en 2006 y sigue siendo la forma mas rigurosamente probada de estimar la edad biologica. Predice la salud a largo plazo con mas fiabilidad que los enfoques mas simples en grandes estudios poblacionales.",',
  'bioAgeCred: "El metodo Klemera-Doubal fue publicado en 2006 y es uno de los metodos mas usados y citados para estimar la edad biologica a partir de analisis de sangre.",',1),
 ('bioAgeCred: "The Klemera-Doubal method was published in 2006 and remains the most rigorously tested way to estimate biological age. It predicts long-term health more reliably than simpler approaches in large population studies.",',
  'bioAgeCred: "The Klemera-Doubal method was published in 2006 and is one of the most widely used and cited ways to estimate biological age from blood tests.",',1),
])
