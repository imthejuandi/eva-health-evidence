import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin("./src/i18n/request.ts");

const nextConfig: NextConfig = {
  // The Echevarne SFTP bridge uses ssh2 (native optional deps + .node
  // binaries). Keep it out of the Turbopack server bundle and let Node
  // require it at runtime — see node_modules/next/dist/docs/…/serverExternalPackages.md.
  serverExternalPackages: ["ssh2-sftp-client", "ssh2"],
  experimental: {
    optimizePackageImports: ["lucide-react", "recharts", "@react-three/drei", "framer-motion"],
  },
};

export default withNextIntl(nextConfig);
