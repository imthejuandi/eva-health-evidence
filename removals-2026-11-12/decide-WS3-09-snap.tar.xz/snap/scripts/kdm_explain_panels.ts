/**
 * Internal report: biological-age explanations on fixed synthetic panels.
 *
 * Runs `explainBiologicalAge` (Reference and Comprehensive) on six fixed
 * panels, with optimal bands from the reviewed seed rows
 * (`supabase/seed-data/biomarker-ranges-en.json`) picked per person with
 * `pickReferenceRow`, and writes a Markdown report. No patient data, no
 * database, nothing stored.
 *
 * Usage: npx tsx scripts/kdm_explain_panels.ts [out.md]
 *   (default: docs/biomarker-evidence/longevity/KDM-EXPLAIN-PANELS.md)
 */
import fs from "node:fs";
import path from "node:path";
import seed from "../supabase/seed-data/biomarker-ranges-en.json";
import {
  explainBiologicalAge,
  type BiologicalAgeExplanation,
  type MarkerMove,
  type OptimalBand,
} from "../src/lib/biomarkers/biological-age-explain";
import { FRUCTOSAMINE_KDM_KEY, type KdmPatientContext, type SCaTier, type Sex } from "../src/lib/biomarkers/biological-age-kdm";
import { pickReferenceRow } from "../src/lib/biomarkers/reference-row";

const OUT = process.argv[2] ?? path.resolve(__dirname, "../docs/biomarker-evidence/longevity/KDM-EXPLAIN-PANELS.md");

// ─── Reviewed rows ───

interface SeedRow {
  Biomarker: string;
  Unit: string;
  Sex: string;
  Age_Group: string;
  Optimal_Low: number | null;
  Optimal_High: number | null;
}
interface Row extends OptimalBand {
  biomarker_key: string;
  name: string;
  unit: string;
  sex: string;
  age_group_en: string;
}

// From Gate 1 these rows have no bounds at all; the seed still carries the old ones.
const NO_BOUNDS_FROM_GATE_1 = new Set(["basophils", "eosinophils", "lymphocytes", "monocytes", "neutrophils", "omega_6_arachidonic_acid"]);

// Same key and sex as seed-references.ts; duplicates keep the last row, as the seeder does.
const slugify = (name: string) =>
  name.toLowerCase().replace(/[()]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
const ROWS = [
  ...new Map(
    (seed as unknown as { biomarker_ranges: SeedRow[] }).biomarker_ranges.map((r): [string, Row] => {
      const row: Row = {
        biomarker_key: slugify(r.Biomarker),
        name: r.Biomarker,
        unit: r.Unit,
        sex: r.Sex.toLowerCase(),
        age_group_en: r.Age_Group,
        optimal_low: r.Optimal_Low,
        optimal_high: r.Optimal_High,
      };
      if (NO_BOUNDS_FROM_GATE_1.has(row.biomarker_key)) Object.assign(row, { optimal_low: null, optimal_high: null });
      return [`${row.biomarker_key}|${row.sex}|${row.age_group_en}`, row];
    }),
  ).values(),
];

// The rules of ageGroupContains (process-results.ts) for the labels the seed uses.
function ageGroupContains(label: string, age: number): boolean {
  const range = label.match(/(\d+)\s*-\s*(\d+)/);
  if (range) return age >= Number(range[1]) && age <= Number(range[2]);
  const open = label.match(/(\d+)\s*\+/);
  if (open) return age >= Number(open[1]);
  return age >= 18; // "All Adults", menopausal status, cycle phase
}

function bandsFor(sex: Sex, age: number): Record<string, OptimalBand> {
  const byKey = new Map<string, Row[]>();
  for (const r of ROWS) {
    if ((r.sex !== sex && r.sex !== "both") || !ageGroupContains(r.age_group_en, age)) continue;
    byKey.set(r.biomarker_key, [...(byKey.get(r.biomarker_key) ?? []), r]);
  }
  const out: Record<string, OptimalBand> = {};
  for (const [key, rows] of byKey) {
    const r = pickReferenceRow(rows, sex, age);
    if (r) out[key] = { optimal_low: r.optimal_low, optimal_high: r.optimal_high };
  }
  return out;
}

// ─── Fixed panels (DB keys, engine units) ───

interface Panel {
  label: string;
  sex: Sex;
  age: number;
  values: Record<string, number>;
  context?: KdmPatientContext;
}

const PANELS: Panel[] = [
  {
    label: "Typical man, 45",
    sex: "male",
    age: 45,
    values: {
      albumin: 44, creatinine: 1.0, bun: 15, uric_acid: 6.0, alp: 72, ggt: 32, total_cholesterol: 205,
      hdl_cholesterol: 47, triglycerides: 140, hs_crp: 1.8, ferritin: 180, vitamin_d_25_oh: 24, tsh: 1.9, hba1c: 5.5,
      apolipoprotein_b_apob: 105, ldl_cholesterol: 130, glucose_fasting: 96, alt: 30, ast: 25, total_bilirubin: 0.7,
      hemoglobin: 15.2, hematocrit: 45, mcv: 90, rdw: 13.2, platelet_count: 240000, white_blood_cell_count: 6800,
      lymphocytes: 30, red_blood_cell_count: 5000000, egfr_creatinine_based: 95, vitamin_b12: 450, shbg: 35,
      testosterone_total: 4.8,
    },
  },
  {
    label: "Typical woman, 45",
    sex: "female",
    age: 45,
    values: {
      albumin: 43, creatinine: 0.75, bun: 13, uric_acid: 4.5, alp: 65, ggt: 18, total_cholesterol: 200,
      hdl_cholesterol: 60, triglycerides: 95, hs_crp: 1.5, ferritin: 60, vitamin_d_25_oh: 24, tsh: 2.1, hba1c: 5.4,
      apolipoprotein_b_apob: 90, ldl_cholesterol: 121, glucose_fasting: 90, alt: 18, ast: 20, total_bilirubin: 0.5,
      hemoglobin: 13.4, hematocrit: 40, mcv: 89, rdw: 13.4, platelet_count: 260000, white_blood_cell_count: 6500,
      lymphocytes: 31, red_blood_cell_count: 4500000, egfr_creatinine_based: 100, vitamin_b12: 480, shbg: 60,
      testosterone_total: 0.3,
    },
  },
  {
    label: "Woman, 70",
    sex: "female",
    age: 70,
    values: {
      albumin: 41, creatinine: 0.9, bun: 20, uric_acid: 5.4, alp: 85, ggt: 25, total_cholesterol: 215,
      hdl_cholesterol: 58, triglycerides: 130, hs_crp: 2.5, ferritin: 130, vitamin_d_25_oh: 26, tsh: 2.6, hba1c: 5.9,
      apolipoprotein_b_apob: 100, ldl_cholesterol: 131, glucose_fasting: 102, alt: 18, ast: 22, total_bilirubin: 0.6,
      hemoglobin: 13.2, hematocrit: 40, mcv: 92, rdw: 14.2, platelet_count: 230000, white_blood_cell_count: 6300,
      lymphocytes: 27, red_blood_cell_count: 4400000, egfr_creatinine_based: 69, vitamin_b12: 420, shbg: 75,
    },
  },
  {
    label: "Treated lipid patient (man, 58, statin + ezetimibe)",
    sex: "male",
    age: 58,
    values: {
      albumin: 44, creatinine: 1.0, bun: 16, uric_acid: 6.2, alp: 75, ggt: 35, total_cholesterol: 115,
      hdl_cholesterol: 45, triglycerides: 100, hs_crp: 1.2, ferritin: 200, vitamin_d_25_oh: 26, tsh: 2.0, hba1c: 5.7,
      apolipoprotein_b_apob: 55, ldl_cholesterol: 50, glucose_fasting: 100, alt: 35, ast: 28, total_bilirubin: 0.7,
      hemoglobin: 15.0, hematocrit: 44, mcv: 91, rdw: 13.5, platelet_count: 230000, white_blood_cell_count: 7000,
      lymphocytes: 28, red_blood_cell_count: 4900000, egfr_creatinine_based: 87, vitamin_b12: 400, shbg: 40,
      testosterone_total: 4.2,
    },
  },
  {
    label: "Athlete with high creatinine (man, 32, no creatine)",
    sex: "male",
    age: 32,
    values: {
      albumin: 47, creatinine: 1.35, bun: 19, uric_acid: 5.5, alp: 60, ggt: 15, total_cholesterol: 175,
      hdl_cholesterol: 65, triglycerides: 60, hs_crp: 0.3, ferritin: 70, vitamin_d_25_oh: 38, tsh: 1.5, hba1c: 5.1,
      apolipoprotein_b_apob: 70, ldl_cholesterol: 98, glucose_fasting: 85, alt: 30, ast: 35, total_bilirubin: 1.0,
      hemoglobin: 15.8, hematocrit: 46, mcv: 91, rdw: 12.6, platelet_count: 220000, white_blood_cell_count: 5200,
      lymphocytes: 35, red_blood_cell_count: 5100000, egfr_creatinine_based: 72, vitamin_b12: 550, shbg: 38,
      testosterone_total: 6.0,
    },
  },
  {
    label: "Vitamin D 22 ng/mL, ferritin 30 ng/mL (woman, 38)",
    sex: "female",
    age: 38,
    values: {
      albumin: 43, creatinine: 0.72, bun: 12, uric_acid: 4.0, alp: 58, ggt: 14, total_cholesterol: 185,
      hdl_cholesterol: 62, triglycerides: 80, hs_crp: 0.8, ferritin: 30, vitamin_d_25_oh: 22, tsh: 1.8, hba1c: 5.2,
      apolipoprotein_b_apob: 80, ldl_cholesterol: 107, glucose_fasting: 86, alt: 15, ast: 17, total_bilirubin: 0.5,
      hemoglobin: 12.6, hematocrit: 38, mcv: 85, rdw: 13.8, platelet_count: 280000, white_blood_cell_count: 6000,
      lymphocytes: 33, red_blood_cell_count: 4400000, egfr_creatinine_based: 110, vitamin_b12: 380, shbg: 65,
      testosterone_total: 0.25,
    },
  },
];

// The typical man's tests as the Base Panel is ordered (13 tests, fructosamine measured).
const ORDERED_BASE = ["albumin", "alp", "hs_crp", "creatinine", "bun", "uric_acid", "total_cholesterol", "hdl_cholesterol", "triglycerides", "apolipoprotein_b_apob", "alt", "ggt"];
const typical = PANELS[0];
const pickValues = (codes: string[]) => Object.fromEntries(codes.map((c) => [c, typical.values[c]]));
const FRUCTOSAMINE_PANELS: Panel[] = [
  { ...typical, label: "Typical man, 45: Base Panel, fructosamine 190 µmol/L", values: { ...pickValues(ORDERED_BASE), fructosamine: 190 } },
  { ...typical, label: "Same tests, HbA1c 5.5% instead of fructosamine", values: { ...pickValues(ORDERED_BASE), hba1c: 5.5 } },
];

// ─── Report ───

const NAME = new Map(ROWS.map((r) => [r.biomarker_key, r.name]));
const UNIT = new Map(ROWS.map((r) => [r.biomarker_key, r.unit]));
const name = (code: string) => NAME.get(code) ?? code;
const yrs = (n: number) => `${n >= 0 ? "+" : "−"}${Math.abs(n).toFixed(Math.abs(n) < 0.05 ? 2 : 1)}`;
const moveText = (m: MarkerMove) => `${name(m.code)} ${m.from} → ${m.to} (${yrs(m.delta)})`;
const list = (items: string[]) => (items.length ? items.join("; ") : "none");

let worstResidual = 0;
function explain(p: Panel, tier: SCaTier): BiologicalAgeExplanation {
  const values = Object.entries(p.values).map(([code, value]) => ({ code, value }));
  const e = explainBiologicalAge(values, p.sex, p.age, bandsFor(p.sex, p.age), tier, p.context);
  if (!e) throw new Error(`${p.label}: no ${tier} biological age (gate failed)`);
  if (!e.check.ok) throw new Error(`${p.label}: contributions do not add up to BA − CA`);
  worstResidual = Math.max(worstResidual, Math.abs(e.check.sum - e.check.gap));
  return e;
}

function table(panels: Panel[], tier: SCaTier): string[] {
  return [
    "| Panel | CA | BA | BA − CA | Largest contributions (years) | Potential BA | Counted moves (years) | Conflicts: moves toward optimal that raise the BA (years) |",
    "|---|---|---|---|---|---|---|---|",
    ...panels.map((p) => {
      const e = explain(p, tier);
      const top = e.contributions.slice(0, 3).map((c) => {
        const label = c.marker === FRUCTOSAMINE_KDM_KEY && c.code !== "fructosamine" ? "Fructosamine (from HbA1c)" : name(c.code);
        return `${label} ${yrs(c.years)}`;
      });
      return `| ${p.label} | ${p.age} | ${e.ba.toFixed(1)} | ${yrs(e.ba - e.ca)} | ${top.join("; ")} | ${e.potentialBA.toFixed(1)} | ${list(e.potential.map(moveText))} | ${list(e.conflicts.map(moveText))} |`;
    }),
  ];
}

const reference = table(PANELS, "reference");
const comprehensive = table(PANELS, "comprehensive");
const fructosamine = table(FRUCTOSAMINE_PANELS, "reference");
const codes = [...new Set(PANELS.flatMap((p) => Object.keys(p.values)))];
const md = [
  "# Biological-age explanations on fixed panels",
  "",
  "Generated by `scripts/kdm_explain_panels.ts` with `explainBiologicalAge` (`src/lib/biomarkers/biological-age-explain.ts`). Internal only: synthetic panels, no patient data, nothing stored or shown to users.",
  "",
  "- **Model.** The deployed KDM biological age, unchanged: same adapter, units, Path B parameters and s_CA as `computeReferenceBA` / `computeComprehensiveBA`. Reference is the stored biological age; Comprehensive uses every marker the model has parameters for.",
  `- **Contributions.** Each marker's exact share of BA − CA, in years (positive = older). They add up to BA − CA: the largest difference over all rows below is ${worstResidual.toExponential(1)} years.`,
  "- **Potential BA.** Every marker outside its optimal band is moved to the nearest edge of the band, and only the moves that lower the BA are counted (direction rule); the counted moves are then applied together. A move toward optimal that raises the BA is listed as a conflict and never counted.",
  "- **Optimal bands.** Reviewed rows from `supabase/seed-data/biomarker-ranges-en.json`, picked per person with `pickReferenceRow`. From Gate 1 the five white-cell percentage rows and arachidonic acid have no bounds, so lymphocyte % is never moved.",
  "- **Fructosamine.** Derived from HbA1c in the six panels, as in the model's training data. The last section shows a measured value.",
  "",
  "## Reference biological age (the stored number)",
  "",
  ...reference,
  "",
  "## Comprehensive biological age",
  "",
  ...comprehensive,
  "",
  "## Measured fructosamine",
  "",
  "The model's fructosamine parameters were fitted on values derived from HbA1c (19.97 × HbA1c − 39.4, about 70 µmol/L at 45). The Base Panel measures fructosamine, whose reference range is 122–236 µmol/L. A measured value inside the optimal band reads as decades of aging:",
  "",
  ...fructosamine,
  "",
  "## Spanish recalibration of log-scale markers",
  "",
  "For log-transformed markers, the library's Spanish q is the NHANES q (a log) multiplied by the ratio of Spanish to NHANES means. On a log scale that ratio adds ln(ratio) instead. Triglycerides, hs-CRP, GGT, TSH, insulin and total testosterone are affected: part of their shares above (triglycerides older, hs-CRP younger, testosterone older in women) is this offset, the same for everyone of a sex. The mortality validation cannot see an offset like this or the fructosamine one, because it standardizes the BA and adjusts for age and sex.",
  "",
  "## Panel values",
  "",
  `| Marker (unit) | ${PANELS.map((p) => p.label).join(" | ")} |`,
  `|---|${PANELS.map(() => "---").join("|")}|`,
  ...codes
    .filter((c) => PANELS.some((p) => c in p.values))
    .map((c) => `| ${name(c)} (${UNIT.get(c) ?? ""}) | ${PANELS.map((p) => p.values[c] ?? "–").join(" | ")} |`),
  "",
];
fs.writeFileSync(OUT, md.join("\n"));
console.log(JSON.stringify({ out: path.relative(process.cwd(), OUT), panels: PANELS.length + FRUCTOSAMINE_PANELS.length, worst_residual_years: worstResidual }));
