#!/usr/bin/env python3
"""
Generate Path B (unwinsorized) overrides for ALL trained markers in the
KDM library. Sex-stratified markers get separate M/F entries.

Output: src/lib/biomarkers/data/path_b_overrides.json

Validation: see scripts/comprehensive_ba_mortality_validation.py — Path B
applied to all markers preserves HR/SD ≥ 1.39 (Reference) and 1.65
(Comprehensive), C-stat ≥ 0.77 for both tiers, and brings the population-
level Mean Comp − Mean Ref discrepancy from −1.59 (v2.2.1) to +0.07.
"""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2")
LIBRARY_PATH = ROOT / "output" / "marker_library_v2_2.json"
CLEANED_PATH = ROOT / "output" / "nhanes_continuous_cleaned.parquet"
OUT_PATH = Path("/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/path_b_overrides.json")


def fit_ols(values, ages, log_transformed):
    if log_transformed:
        valid = (values > 0) & np.isfinite(ages) & np.isfinite(values)
        x = ages[valid]
        y = np.log(values[valid])
    else:
        valid = np.isfinite(values) & np.isfinite(ages)
        x = ages[valid]
        y = values[valid]
    if len(x) < 100:
        return None
    xm, ym = x.mean(), y.mean()
    sxy = ((x - xm) * (y - ym)).sum()
    sxx = ((x - xm) ** 2).sum()
    k = float(sxy / sxx)
    q = float(ym - k * xm)
    resid = y - (q + k * x)
    s = float(resid.std(ddof=2))
    ss_tot = ((y - ym) ** 2).sum()
    ss_res = (resid ** 2).sum()
    r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else 0.0
    return {"k": k, "q": q, "s": s, "r2": r2, "n": int(valid.sum())}


def main():
    print("Loading library + raw NHANES (unwinsorized)...")
    library = json.loads(LIBRARY_PATH.read_text())
    library_markers = library["markers"]

    # Load LONG format with `value` column (the raw, pre-winsorization values)
    df_long = pd.read_parquet(CLEANED_PATH)
    df_long = df_long.dropna(subset=["value", "age", "sex"]).copy()
    df_long = df_long[df_long["value"] > 0]
    df_long = df_long[df_long["age"] >= 18]  # adults only — matches training

    print(f"  loaded {len(df_long):,} rows, {df_long['marker_es'].nunique()} unique markers\n")

    overrides = {
        "_meta": {
            "method": "Path B — OLS refit on raw (unwinsorized) NHANES values",
            "source": "scripts/generate_path_b_full_overrides.py",
            "training_data": "NHANES Continuous 1999-2018",
            "validation": "see scripts/comprehensive_ba_mortality_validation.py",
            "validation_summary": {
                "reference_hr_per_sd": 1.39,
                "comprehensive_hr_per_sd": 1.65,
                "reference_c_stat": 0.770,
                "comprehensive_c_stat": 0.775,
                "mean_discrepancy_comp_minus_ref": 0.07,
            },
        },
        "markers": {},
    }

    refit_count = 0
    skip_count = 0
    for name, m in library_markers.items():
        if m.get("kdm_contribution") != "trained":
            skip_count += 1
            continue
        sex_strat = m.get("sex_stratified", False)
        log = m.get("log_transformed", False)
        sub_all = df_long[df_long["marker_es"] == name]
        if len(sub_all) < 100:
            skip_count += 1
            continue

        entry = {"log_transformed": log, "sex_stratified": sex_strat}

        if sex_strat:
            for sex in ("M", "F"):
                sub = sub_all[sub_all["sex"] == sex]
                if len(sub) < 100:
                    continue
                fit = fit_ols(sub["value"].to_numpy(), sub["age"].to_numpy(), log)
                if fit:
                    entry[f"kqs_{sex}"] = fit
        else:
            fit = fit_ols(sub_all["value"].to_numpy(), sub_all["age"].to_numpy(), log)
            if fit:
                entry["kqs"] = fit

        # Only include if we got at least one fit
        if "kqs" in entry or "kqs_M" in entry or "kqs_F" in entry:
            overrides["markers"][name] = entry
            refit_count += 1

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps(overrides, indent=2, ensure_ascii=False))
    print(f"  re-fit {refit_count} markers (skipped {skip_count})")
    print(f"  wrote {OUT_PATH}")

    # Summary stats
    base = ["BUN (Nitrógeno Ureico en Sangre)", "Fructosamina", "Albúmina",
            "Creatinina", "Colesterol Total", "Colesterol HDL", "Triglicéridos",
            "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
            "TSH", "Ácido Úrico", "ALP (Fosfatasa Alcalina)",
            "GGT (Gamma-glutamil Transferasa)"]
    print("\nBase panel refit summary:")
    print(f"{'marker':50s} {'k':>10s} {'q':>10s} {'s':>10s} {'R²':>8s}")
    print("-" * 90)
    for m in base:
        e = overrides["markers"].get(m, {})
        if "kqs" in e:
            f = e["kqs"]
            print(f"{m[:48]:48s} {f['k']:>10.4f} {f['q']:>10.4f} {f['s']:>10.4f} {f['r2']:>8.4f}")
        elif "kqs_M" in e:
            f = e["kqs_M"]
            print(f"{m[:46]+' (M)':48s} {f['k']:>10.4f} {f['q']:>10.4f} {f['s']:>10.4f} {f['r2']:>8.4f}")
            f = e.get("kqs_F", {})
            if f:
                print(f"{m[:46]+' (F)':48s} {f['k']:>10.4f} {f['q']:>10.4f} {f['s']:>10.4f} {f['r2']:>8.4f}")


if __name__ == "__main__":
    main()
