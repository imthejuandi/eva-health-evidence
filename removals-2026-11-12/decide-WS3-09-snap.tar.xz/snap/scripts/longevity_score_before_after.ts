/**
 * Internal report: the longevity score on fixed synthetic panels.
 *
 * Scores seven fixed panels with the score (calculateLongevityScoreV2, score 2.0) and writes a Markdown report.
 * The rows are the seed's (supabase/seed-data/biomarker-ranges-en.json) with the families' decided rows for the
 * markers the score specification names (docs/signoff/work/decisions), picked per person as processing picks
 * them: a marker scores only through a row whose optimal band is the one the verifier graded, so the seed as it
 * stands before the sign-off compile gives too few scoring markers. No patient data, no database, nothing stored.
 *
 * Its report of 29 September 2026, docs/biomarker-evidence/longevity/SCORE-BEFORE-AFTER.md, also scored the
 * panels with the first score, which has since been removed. That report is kept as history (and
 * scripts/base_panel_assessment.ts checks its figures), so this script no longer writes it: the output path
 * is required.
 *
 * Usage: npx tsx scripts/longevity_score_before_after.ts <out.md>
 */
import fs from "node:fs";
import path from "node:path";
import {
  calculateLongevityScoreV2,
  REVIEWED_ROW_KEY,
  type FullResult,
  type MarkerScore,
  type ReviewedRow,
} from "../src/lib/biomarkers/longevity-score";
import { buildEngineInputs } from "../src/lib/biomarkers/engine-inputs";
import { DB_KEY_TO_ENGINE_CODE } from "../src/lib/biomarkers/name-matcher";
import { pickReferenceRows } from "../src/lib/biomarkers/reference-row";
import { signedRows } from "../src/lib/biomarkers/__tests__/fixtures/reviewed-rows";

const OUT_ARG = process.argv[2];
if (!OUT_ARG) {
  console.error("Usage: npx tsx scripts/longevity_score_before_after.ts <out.md>");
  process.exit(1);
}
const OUT = path.resolve(OUT_ARG);

// ─── Reviewed rows ───

// The seed's rows under their database keys, with the decided rows for the markers the score names.
const ROWS = signedRows();
const NAME = new Map(ROWS.map((r) => [r.biomarker_key, r.name_en]));
const UNIT = new Map(ROWS.map((r) => [r.biomarker_key, r.unit_en]));

// ─── Fixed panels (stored keys and units) ───

type Sex = "male" | "female";
interface Panel {
  label: string;
  sex: Sex;
  age: number;
  values: Record<string, number>;
  /** A sentence about the result, checked against it (throws if it does not hold). */
  explain?: (r: FullResult) => string;
}

const marker = (r: FullResult, code: string) => [...r.markerScores, ...r.suppressedMarkers].find((m) => m.code === code);
function check(ok: boolean, what: string): void {
  if (!ok) throw new Error(`Report note no longer true: ${what}`);
}

// The typical man, typical woman and woman of 70 are the panels of KDM-EXPLAIN-PANELS.md, with the other
// markers the score reads added (insulin, the white-cell differential, iron saturation, Lp(a), thyroid).
// Labels and values as in SCORE-BEFORE-AFTER.md and base-panel/panels.json, which carry the same panels.
const PANELS: Panel[] = [
  {
    label: "Typical man, 45",
    sex: "male",
    age: 45,
    values: {
      albumin: 44, creatinine: 1.0, bun: 15, uric_acid: 6.0, alp: 72, ggt: 32, total_cholesterol: 205,
      hdl_cholesterol: 47, triglycerides: 140, hs_crp: 1.8, ferritin: 180, vitamin_d_25_oh: 24, tsh: 1.9, hba1c: 5.5,
      apolipoprotein_b_apob: 105, ldl_cholesterol: 130, glucose_fasting: 96, alt: 30, ast: 25, total_bilirubin: 0.7,
      hemoglobin: 15.2, hematocrit: 45, mcv: 90, rdw: 13.2, platelet_count: 240000, white_blood_cell_count: 6800,
      neutrophils: 60, lymphocytes: 30, lymphocytes_absolute: 2040, red_blood_cell_count: 5000000,
      egfr_creatinine_based: 95, vitamin_b12: 450, shbg: 35, testosterone_total: 4.8, insulin_fasting: 9,
      iron_saturation_tsat: 30, lipoproteina: 20, magnesium_serum: 2.1, zinc_serum: 85, free_t4_thyroxine: 1.2,
      free_t3_triiodothyronine: 3.2,
    },
    explain: (r) =>
      `Vitamin D alone costs ${fmt(marker(r, "VITD")!.lsPointsImpact)} points: the score it would have without that penalty, minus the score it has.`,
  },
  {
    label: "Typical woman, 45",
    sex: "female",
    age: 45,
    values: {
      albumin: 43, creatinine: 0.75, bun: 13, uric_acid: 4.5, alp: 65, ggt: 18, total_cholesterol: 200,
      hdl_cholesterol: 60, triglycerides: 95, hs_crp: 1.5, ferritin: 60, vitamin_d_25_oh: 24, tsh: 2.1, hba1c: 5.4,
      apolipoprotein_b_apob: 90, ldl_cholesterol: 121, glucose_fasting: 90, alt: 18, ast: 20, total_bilirubin: 0.5,
      hemoglobin: 13.4, hematocrit: 40, mcv: 89, rdw: 13.4, platelet_count: 260000, white_blood_cell_count: 6500,
      neutrophils: 59, lymphocytes: 31, lymphocytes_absolute: 2015, red_blood_cell_count: 4500000,
      egfr_creatinine_based: 100, vitamin_b12: 480, shbg: 60, testosterone_total: 0.3, insulin_fasting: 7,
      iron_saturation_tsat: 25, lipoproteina: 15, estradiol: 80, magnesium_serum: 2.0, zinc_serum: 80,
      free_t4_thyroxine: 1.1, free_t3_triiodothyronine: 3.0,
    },
  },
  {
    label: "Treated lipid patient (man, 58, statin + ezetimibe)",
    sex: "male",
    age: 58,
    values: {
      albumin: 44, creatinine: 1.0, bun: 16, uric_acid: 6.2, alp: 75, ggt: 35, total_cholesterol: 110,
      hdl_cholesterol: 45, triglycerides: 100, hs_crp: 1.2, ferritin: 200, vitamin_d_25_oh: 26, tsh: 2.0, hba1c: 5.7,
      apolipoprotein_b_apob: 50, ldl_cholesterol: 45, glucose_fasting: 100, alt: 35, ast: 28, total_bilirubin: 0.7,
      hemoglobin: 15.0, hematocrit: 44, mcv: 91, rdw: 13.5, platelet_count: 230000, white_blood_cell_count: 7000,
      neutrophils: 62, lymphocytes: 28, lymphocytes_absolute: 1960, red_blood_cell_count: 4900000,
      egfr_creatinine_based: 87, vitamin_b12: 400, shbg: 40, testosterone_total: 4.2, insulin_fasting: 10,
    },
    explain: (r) => {
      check(marker(r, "APOB")?.zone === "optimal" && marker(r, "APOB")?.rawPenalty === 0, "apoB 50 optimal");
      check(marker(r, "LDL_C")?.zone === "optimal" && marker(r, "LDL_C")?.suppressedBy === "APOB", "LDL-C 45 optimal, not counted");
      return "Treatment costs nothing: apoB 50 and LDL-C 45 mg/dL are optimal (no optimal floor), and LDL-C is not counted because apoB is scored.";
    },
  },
  {
    label: "Athlete (man, 32): creatinine 1.25, CK 450",
    sex: "male",
    age: 32,
    values: {
      albumin: 47, creatinine: 1.25, bun: 19, uric_acid: 5.5, alp: 60, ggt: 15, total_cholesterol: 175,
      hdl_cholesterol: 65, triglycerides: 60, hs_crp: 0.3, ferritin: 70, vitamin_d_25_oh: 38, tsh: 1.5, hba1c: 5.1,
      apolipoprotein_b_apob: 70, ldl_cholesterol: 98, glucose_fasting: 85, alt: 30, ast: 35, total_bilirubin: 1.0,
      hemoglobin: 15.8, hematocrit: 46, mcv: 91, rdw: 12.6, platelet_count: 220000, white_blood_cell_count: 5200,
      neutrophils: 55, lymphocytes: 35, lymphocytes_absolute: 1820, red_blood_cell_count: 5100000,
      egfr_creatinine_based: 78, vitamin_b12: 550, shbg: 38, testosterone_total: 6.0, insulin_fasting: 4,
      creatine_kinase: 450,
    },
    explain: (r) => {
      check(!DB_KEY_TO_ENGINE_CODE.creatine_kinase, "CK is not a score marker");
      // CKD-EPI 2021 (race-free), man: 142 × min(Scr/0.9, 1)^−0.302 × max(Scr/0.9, 1)^−1.200 × 0.9938^age.
      const egfr = 142 * Math.min(1.25 / 0.9, 1) ** -0.302 * Math.max(1.25 / 0.9, 1) ** -1.2 * 0.9938 ** 32;
      // The laboratory's eGFR on the panel is a value only and no eGFR is a score input (rulings D-06 and D-28).
      check(Math.round(egfr) === 78 && marker(r, "EGFR") === undefined, "eGFR 78 for creatinine 1.25 at 32, and no eGFR in the score");
      check(marker(r, "AST") === undefined && marker(r, "CREATININE") === undefined, "AST and creatinine are not score markers");
      const out = r.markerScores.filter((m) => m.zone === "critical_low" || m.zone === "critical_high");
      check(out.length === 0, "no scoring marker is out of range");
      return `CK (creatine kinase), AST and creatinine are not score markers, so their values change nothing. The laboratory's eGFR of 78 is shown as a value only and does not count toward the score; it equals what CKD-EPI 2021 gives for creatinine 1.25 at 32. No scoring marker is outside its reference interval: the score is ${r.longevityScore} (${r.lsGrade}).`;
    },
  },
  {
    label: "Woman, 70",
    sex: "female",
    age: 70,
    values: {
      albumin: 41, creatinine: 0.9, bun: 20, uric_acid: 5.4, alp: 85, ggt: 25, total_cholesterol: 215,
      hdl_cholesterol: 58, triglycerides: 130, hs_crp: 2.5, ferritin: 130, vitamin_d_25_oh: 26, tsh: 2.6, hba1c: 5.9,
      apolipoprotein_b_apob: 100, ldl_cholesterol: 131, glucose_fasting: 102, alt: 18, ast: 22, total_bilirubin: 0.6,
      hemoglobin: 13.2, hematocrit: 40, mcv: 92, rdw: 14.2, platelet_count: 230000, white_blood_cell_count: 6300,
      neutrophils: 63, lymphocytes: 27, lymphocytes_absolute: 1700, red_blood_cell_count: 4400000,
      egfr_creatinine_based: 69, vitamin_b12: 420, shbg: 75, insulin_fasting: 8, estradiol: 12,
    },
  },
  {
    label: "Metabolic syndrome (man, 52)",
    sex: "male",
    age: 52,
    values: {
      glucose_fasting: 108, insulin_fasting: 18, triglycerides: 210, hdl_cholesterol: 38, hba1c: 5.9,
      apolipoprotein_b_apob: 115, ldl_cholesterol: 140, total_cholesterol: 220, hs_crp: 3.5, alt: 45, ast: 30, ggt: 55,
      uric_acid: 7.2, albumin: 44, creatinine: 1.0, egfr_creatinine_based: 88, hemoglobin: 15.4, rdw: 13.6, mcv: 88,
      platelet_count: 250000, white_blood_cell_count: 7800, neutrophils: 63, lymphocytes: 28, lymphocytes_absolute: 2180,
      ferritin: 250, vitamin_d_25_oh: 20, tsh: 2.2, vitamin_b12: 400, shbg: 22, testosterone_total: 3.2,
      total_bilirubin: 0.6, alp: 80, iron_saturation_tsat: 28, magnesium_serum: 1.9,
    },
  },
  {
    label: "Vitamin D 24 ng/mL, everything else optimal in both versions (woman, 38)",
    sex: "female",
    age: 38,
    values: {
      vitamin_d_25_oh: 24, apolipoprotein_b_apob: 60, ldl_cholesterol: 55, hba1c: 5.0, glucose_fasting: 82,
      insulin_fasting: 4.5, hs_crp: 0.3, egfr_creatinine_based: 110, hdl_cholesterol: 70, triglycerides: 65,
      lipoproteina: 12, alt: 15, rdw: 12.3, albumin: 45, estradiol: 80, white_blood_cell_count: 5200, neutrophils: 55,
      lymphocytes: 32, lymphocytes_absolute: 1660, ferritin: 70, iron_saturation_tsat: 30, tsh: 1.8, shbg: 60,
      uric_acid: 4.0, ggt: 14, ast: 18, hemoglobin: 13.8, mcv: 88, vitamin_b12: 600, creatinine: 0.75,
      platelet_count: 240000, magnesium_serum: 2.1, zinc_serum: 95, free_t4_thyroxine: 1.2,
      free_t3_triiodothyronine: 3.2, total_bilirubin: 0.6, alp: 60,
    },
    explain: (r) => {
      const d = marker(r, "VITD")!;
      check(d.zone === "critical_low", "vitamin D out of range");
      check(r.longevityScore < 100 && Math.abs(r.totalWeightedPenalty - d.weightedPenalty) < 1e-3, "vitamin D is the whole penalty");
      check(r.markerScores.every((m) => m.code === "VITD" || m.rawPenalty === 0), "everything else optimal");
      return `Vitamin D is the only marker outside its optimal band, and out of range under the reviewed row. The score has no bonus, so its penalty (${fmt(d.weightedPenalty)}) is the whole cost: ${r.longevityScore} (${r.lsGrade}).`;
    },
  },
];

// Keys with no reviewed row, for the panel table.
const OTHER_NAMES: Record<string, [string, string]> = { creatine_kinase: ["Creatine kinase (CK), not a score marker", "U/L"] };

// ─── Penalties ───

const fmt = (x: number | null | undefined) => (x == null ? "–" : String(Math.round(x * 1000) / 1000));
const band = (lo: number | null | undefined, hi: number | null | undefined) =>
  lo == null && hi == null ? "none" : lo == null ? `≤${fmt(hi)}` : hi == null ? `≥${fmt(lo)}` : `${fmt(lo)}–${fmt(hi)}`;

// The reviewed category, with the bounds that put the value there.
function reason(m: MarkerScore, row: ReviewedRow): string {
  const optimal = band(row.optimal_low, row.optimal_high);
  const reference = band(row.normal_low, row.normal_high);
  switch (m.zone) {
    case "optimal": return `optimal (${optimal})`;
    case "below_optimal": return `in range, below optimal ${optimal} (reference ${reference})`;
    case "above_optimal": return `in range, above optimal ${optimal} (reference ${reference})`;
    case "critical_low": return `out of range, below the reference ${reference} (optimal ${optimal})`;
    default: return `out of range, above the reference ${reference} (optimal ${optimal})`;
  }
}

interface Penalty {
  marker: string;
  value: string;
  penalty: string;
  counted: number;
  reason: string;
}

// Every marker the score read for the panel, with its counted weighted penalty (0 when a redundant marker
// is scored instead), largest first.
function penalties(p: Panel, r: FullResult): Penalty[] {
  const picked = pickReferenceRows(ROWS, p.sex, p.age).picked;
  const out: Penalty[] = [];
  for (const m of [...r.markerScores, ...r.suppressedMarkers]) {
    const key = REVIEWED_ROW_KEY[m.code];
    const unit = UNIT.get(key) ?? m.unit;
    out.push({
      marker: NAME.get(key) ?? m.name,
      value: `${fmt(m.value)}${unit && unit !== "ratio" && unit !== "index" ? ` ${unit}` : ""}`,
      penalty: m.suppressed ? `${fmt(m.rawPenalty)}, not counted (${m.suppressedBy} scored instead)` : `${fmt(m.rawPenalty)} × ${m.weight} = ${fmt(m.weightedPenalty)}`,
      counted: m.suppressed ? 0 : m.weightedPenalty,
      reason: reason(m, picked.get(key)!),
    });
  }
  return out.sort((a, b) => b.counted - a.counted || a.marker.localeCompare(b.marker));
}

// ─── Report ───

const summary: string[] = [];
const sections: string[] = [];
const across = new Map<string, { total: number; panels: number }>();
for (const p of PANELS) {
  const stored = Object.entries(p.values).map(([biomarkerKey, value]) => ({ biomarkerKey, value }));
  const r = calculateLongevityScoreV2(buildEngineInputs(stored), p.sex, p.age, ROWS);
  if (!r.validation.valid) throw new Error(`${p.label}: not scorable (${r.validation.errorMessage})`);
  summary.push(
    `| ${p.label} | ${r.longevityScore} (${r.lsGrade}) | ${r.markersScored} | ${fmt(r.totalWeightedPenalty)} of ${fmt(r.maxPossibleWeightedPenalty)} | ${r.markerScores.map((m) => m.code).join(", ")} |`,
  );
  const all = penalties(p, r).filter((c) => c.counted >= 0.0005);
  for (const c of all) {
    const a = across.get(c.marker) ?? { total: 0, panels: 0 };
    across.set(c.marker, { total: a.total + c.counted, panels: a.panels + 1 });
  }
  sections.push(
    `### ${p.label}`,
    "",
    `Score ${r.longevityScore} (${r.lsGrade}). Weighted penalty ${fmt(r.totalWeightedPenalty)} of a possible ${fmt(r.maxPossibleWeightedPenalty)}.${p.explain ? ` ${p.explain(r)}` : ""}`,
    "",
    "| Marker | Value | Penalty (share × weight) | Why: the band the value sits in |",
    "|---|---|---|---|",
    ...all.slice(0, 5).map((c) => `| ${c.marker} | ${c.value} | ${c.penalty} | ${c.reason} |`),
    "",
    ...(all.length < 5 ? [`No other marker costs anything (${all.length} do).`, ""] : []),
  );
}
const acrossRows = [...across].sort((a, b) => b[1].total - a[1].total || a[0].localeCompare(b[0])).slice(0, 12);

const keys = [...new Set(PANELS.flatMap((p) => Object.keys(p.values)))];
const label = (k: string) => {
  const [name, unit] = OTHER_NAMES[k] ?? [NAME.get(k) ?? k, UNIT.get(k) ?? ""];
  return `${name}${unit ? ` (${unit})` : ""}`;
};
const md = [
  "# Longevity score on fixed panels",
  "",
  "Generated by `scripts/longevity_score_before_after.ts`. Internal only: synthetic panels, no patient data, nothing stored.",
  "",
  "- **Score.** `calculateLongevityScoreV2`, the only score: each range read from the reviewed row picked for the person (`pickReferenceRows`, as processing picks it). Penalty as a share of the marker's weight: 0 when optimal; in range 0.4 × (d / band)²; out of range 0.4 + 0.6 × min(e / w, 1), w the band on that side or 25% of the limit when there is none. There is no bonus (ruling D-03). Only the markers of the score specification count (`src/lib/biomarkers/data/score-spec.json`), each through a row whose optimal band the verifier graded A or B. No eGFR counts toward the score: a laboratory's own eGFR is shown as a value only, and the eGFR the app computes from creatinine does not score yet. Lowest grade \"Needs attention\".",
  "- **Rows.** `supabase/seed-data/biomarker-ranges-en.json` with the families' decided rows (`docs/signoff/work/decisions`) for the markers the score names: the rows after the sign-off compile.",
  "- **Inputs.** Each panel's stored values go through `buildEngineInputs`, as in processing: non-HDL cholesterol is computed from total and HDL cholesterol. No fasting answer is given, as in processing today, so fasting glucose does not score.",
  "- **Penalties.** Per marker, the counted weighted penalty: share of the weight × weight (3 for a grade A band, 2 for grade B), 0 when the marker is replaced by a member of its group (apoB over non-HDL and LDL cholesterol, HbA1c over glucose, ALT over GGT). The score is 100 × e^(−3 × penalty / possible penalty).",
  "- **History.** `SCORE-BEFORE-AFTER.md` (29 September 2026) also scored these panels with the first score, since removed.",
  "",
  "## Summary",
  "",
  "| Panel | Score (grade) | Markers scored | Weighted penalty | Scoring markers |",
  "|---|---|---|---|---|",
  ...summary,
  "",
  "## Across the seven panels",
  "",
  "The markers whose counted penalty is largest, summed over the panels.",
  "",
  "| Marker | Total counted penalty | Panels where it costs |",
  "|---|---|---|",
  ...acrossRows.map(([m, a]) => `| ${m} | ${fmt(a.total)} | ${a.panels} |`),
  "",
  "## The five largest penalties per panel",
  "",
  ...sections,
  "## Panel values",
  "",
  `| Marker (unit) | ${PANELS.map((p) => p.label).join(" | ")} |`,
  `|---|${PANELS.map(() => "---").join("|")}|`,
  ...keys.map((k) => `| ${label(k)} | ${PANELS.map((p) => p.values[k] ?? "–").join(" | ")} |`),
  "",
];
fs.writeFileSync(OUT, md.join("\n"));
console.log(JSON.stringify({ out: path.relative(process.cwd(), OUT), panels: PANELS.length }));
