#!/usr/bin/env python3
"""
Hybrid Path B: apply unwinsorized refit ONLY to extended-only markers
(those not in the 14-marker base panel). Base panel keeps v2.2.1 params.

Goal: preserve Reference BA HR/SD = 1.41 (best Reference mortality
discrimination) while fixing the Comprehensive drift from cumulative
extended-marker bias.
"""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index

ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2")
LIBRARY_PATH = ROOT / "output" / "marker_library_v2_2.json"
CLEANED_PATH = ROOT / "output" / "nhanes_continuous_cleaned.parquet"
PATH_B_FULL_JSON = Path("/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/path_b_overrides.json")

BASE_PANEL = {
    "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
    "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
    "Colesterol Total", "Colesterol HDL", "Triglicéridos",
    "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
    "TSH", "Fructosamina",
}
MANDATORY = ["Albúmina", "Creatinina"]
MIN_BASE = 8

# v2.2.1 overrides (Path B-light) — base panel only modifies BUN + Fructosamine
V221_LIGHT = {
    "BUN (Nitrógeno Ureico en Sangre)": {"k": 0.1344, "q": 7.1314, "s": 5.4758},
    "Fructosamina": {"k": 0.0044, "q": 4.0785, "s": 0.2052},
}


def resolve_params(entry, sex, marker, base_override=None, extended_override=None):
    """Resolve (k, q, s) for a marker.

    - If marker is in base panel: use base_override if provided, else library.
    - If marker is extended-only: use extended_override if provided, else library.
    """
    in_base = marker in BASE_PANEL

    # Pick the right override layer
    if in_base and base_override and marker in base_override:
        o = base_override[marker]
        return {"k": o["k"], "q": o["q"], "s": o["s"],
                "log": entry.get("log_transformed", False)}
    if (not in_base) and extended_override and marker in extended_override:
        # Sex-stratified vs pooled extended override
        eo = extended_override[marker]
        if eo.get("sex_stratified"):
            block = eo.get("kqs_M") if sex == "M" else eo.get("kqs_F")
            if not block:
                return None
            return {"k": block["k"], "q": block["q"], "s": block["s"],
                    "log": entry.get("log_transformed", False)}
        block = eo.get("kqs")
        if not block:
            return None
        return {"k": block["k"], "q": block["q"], "s": block["s"],
                "log": entry.get("log_transformed", False)}

    # Fall back to library
    if entry.get("sex_stratified"):
        block = entry.get("kqs_M") if sex == "M" else entry.get("kqs_F")
    else:
        block = entry.get("kqs")
    if not block or block.get("k") is None:
        return None
    k, q, s = block["k"], block["q"], block["s"]
    sr = entry.get("spanish_recalibration", {})
    if sr.get("calibration_status", "").startswith("recalibrated"):
        if entry.get("sex_stratified"):
            per_sex = (sr.get("per_sex") or {}).get(sex, {}) or {}
            qs = per_sex.get("q_spain")
            if qs is not None:
                q = qs
        else:
            qs = sr.get("q_spain")
            if qs is not None:
                q = qs
    return {"k": k, "q": q, "s": s, "log": entry.get("log_transformed", False)}


def kd_ba(values, library_markers, sex, ca, s_ca, base_override, ext_override, restrict_to_base):
    base_present = [m for m in BASE_PANEL if m in values and pd.notna(values[m])]
    if len(base_present) < MIN_BASE:
        return None
    for m in MANDATORY:
        if m not in values or pd.isna(values[m]):
            return None
    num = denom = 0.0
    used = 0
    for marker, value in values.items():
        if pd.isna(value) or not math.isfinite(value):
            continue
        if restrict_to_base and marker not in BASE_PANEL:
            continue
        entry = library_markers.get(marker)
        if not entry:
            continue
        p = resolve_params(entry, sex, marker, base_override, ext_override)
        if not p or p["s"] <= 0:
            continue
        v = math.log(value) if p["log"] and value > 0 else value
        if not math.isfinite(v):
            continue
        num += (v - p["q"]) * (p["k"] / (p["s"] ** 2))
        denom += (p["k"] / p["s"]) ** 2
        used += 1
    if denom == 0:
        return None
    ba_e = num / denom
    s_ba2 = 1.0 / denom
    s_ca2 = s_ca ** 2
    return (ba_e / s_ba2 + ca / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)


def cox(df, ba_col):
    sub = df.dropna(subset=[ba_col, "age", "follow_up_years", "died"]).copy()
    if len(sub) < 100 or sub["died"].sum() < 100:
        return None
    sub["BA_z"] = (sub[ba_col] - sub[ba_col].mean()) / sub[ba_col].std()
    sub["sex_M"] = (sub["sex"] == "M").astype(int)
    sub["T"] = sub["follow_up_years"]
    sub["E"] = sub["died"].astype(int)
    cph = CoxPHFitter()
    cph.fit(sub[["BA_z", "age", "sex_M", "T", "E"]], duration_col="T", event_col="E", show_progress=False)
    hr = float(np.exp(cph.params_["BA_z"]))
    ci = cph.confidence_intervals_.loc["BA_z"].tolist()
    c_stat = float(concordance_index(sub["T"], -cph.predict_partial_hazard(sub), sub["E"]))
    return {"hr": hr, "hr_lo": float(np.exp(ci[0])), "hr_hi": float(np.exp(ci[1])), "c_stat": c_stat}


def main():
    library = json.loads(LIBRARY_PATH.read_text())
    library_markers = library["markers"]
    df_long = pd.read_parquet(CLEANED_PATH)
    df_long_w = df_long.copy()
    df_long_w["v"] = np.where(df_long_w["value_log"].notna(),
                              np.exp(df_long_w["value_log"]),
                              df_long_w["value_winsorized"])
    wide = df_long_w.pivot_table(
        index=["SEQN", "cycle", "age", "sex", "follow_up_years", "died"],
        columns="marker_es", values="v", aggfunc="first",
    ).reset_index()

    path_b_full = json.loads(PATH_B_FULL_JSON.read_text())["markers"]

    s_ca_ref = {"M": 24.678, "F": 23.274}
    s_ca_comp = {"M": 14.003, "F": 13.914}

    # Config D = HYBRID: v2.2.1 base + full Path B extended-only
    print("Computing BA for each subject — HYBRID config (v2.2.1 base + full Path B extended)...")
    refs, comps = [], []
    for _, row in wide.iterrows():
        sex = row["sex"]
        ca = row["age"]
        if pd.isna(sex) or pd.isna(ca):
            refs.append(np.nan)
            comps.append(np.nan)
            continue
        values = {m: row.get(m) for m in library_markers if m in wide.columns}
        sca_r = s_ca_ref.get(sex, 24.0)
        sca_c = s_ca_comp.get(sex, 14.0)
        refs.append(kd_ba(values, library_markers, sex, ca, sca_r,
                          base_override=V221_LIGHT, ext_override=path_b_full,
                          restrict_to_base=True))
        comps.append(kd_ba(values, library_markers, sex, ca, sca_c,
                           base_override=V221_LIGHT, ext_override=path_b_full,
                           restrict_to_base=False))
    wide["BA_ref"] = refs
    wide["BA_comp"] = comps

    print("\n" + "=" * 80)
    print("HYBRID config — Cox PH mortality validation (n=18,570)")
    print("=" * 80)
    for label, col in (("Reference", "BA_ref"), ("Comprehensive", "BA_comp")):
        r = cox(wide, col)
        if r:
            print(f"  {label:14s}: HR/SD = {r['hr']:.4f} [{r['hr_lo']:.3f}, {r['hr_hi']:.3f}], C-stat = {r['c_stat']:.4f}")

    sub = wide.dropna(subset=["BA_ref", "BA_comp"])
    delta = sub["BA_comp"] - sub["BA_ref"]
    print(f"\n  Reference mean: {sub['BA_ref'].mean():.2f}")
    print(f"  Comprehensive mean: {sub['BA_comp'].mean():.2f}")
    print(f"  Mean (Comp - Ref): {delta.mean():+.3f}")
    print(f"  SD (Comp - Ref): {delta.std():.3f}")

    print("\n" + "=" * 80)
    print("HEAD-TO-HEAD: HYBRID vs v2.2.1 vs v2.2.2")
    print("=" * 80)
    print(f"{'config':25s} {'Ref HR':>10s} {'Comp HR':>10s} {'Mean Δ':>10s}")
    print("-" * 80)
    print(f"{'v2.2.1 (deployed)':25s} {1.406:>10.3f} {1.658:>10.3f} {-1.59:>10.3f}")
    print(f"{'v2.2.2 (full Path B)':25s} {1.391:>10.3f} {1.654:>10.3f} {+0.07:>10.3f}")
    ref_r = cox(wide, "BA_ref")
    comp_r = cox(wide, "BA_comp")
    if ref_r and comp_r:
        print(f"{'HYBRID (proposed)':25s} {ref_r['hr']:>10.3f} {comp_r['hr']:>10.3f} {delta.mean():>10.3f}")


if __name__ == "__main__":
    main()
