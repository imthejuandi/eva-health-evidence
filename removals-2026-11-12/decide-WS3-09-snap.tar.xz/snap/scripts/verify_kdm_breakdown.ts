/**
 * Verbose verification of the KDM BA computation for lab 7e397cf0.
 *
 * Re-runs the same input through resolveMarkerParamsWithRecalibration
 * and prints per-marker contribution to BA_E so we can see exactly which
 * inputs drive the +10y delta from chronological age.
 */
import libraryData from "../src/lib/biomarkers/data/marker_library_v2_2.json";
import { kdmInputsFromBiomarkerValues } from "../src/lib/biomarkers/kdm-adapter";
import {
  BASE_PANEL,
  deriveFructosamineIfMissing,
  resolveMarkerParamsWithRecalibration,
  resolveSCa,
  type KdmLibraryMarker,
} from "../src/lib/biomarkers/biological-age-kdm";

const library = libraryData as unknown as {
  markers: Record<string, KdmLibraryMarker>;
};

// User 7e397cf0, male, CA=30, collection 2026-05-05
const sex: "male" = "male";
const ca = 30;
const biomarkers = [
  { code: "shbg", value: 21.8 },
  { code: "red_blood_cell_count", value: 4.81 },
  { code: "hemoglobin", value: 15.6 },
  { code: "mchc", value: 32.9 },
  { code: "white_blood_cell_count", value: 5.3 },
  { code: "neutrophils", value: 43.8 },
  { code: "eosinophils", value: 3 },
  { code: "basophils", value: 0.9 },
  { code: "neutrophils_absolute", value: 2.3 },
  { code: "lymphocytes_absolute", value: 2.2 },
  { code: "monocytes_absolute", value: 0.6 },
  { code: "eosinophils_absolute", value: 0.2 },
  { code: "basophils_absolute", value: 0 },
  { code: "platelet_count", value: 270 },
  { code: "mpv", value: 10.1 },
  { code: "glucose_fasting", value: 87 },
  { code: "bun", value: 16.36 },
  { code: "total_bilirubin", value: 0.8 },
  { code: "uric_acid", value: 5.8 },
  { code: "calcium_serum", value: 9.3 },
  { code: "total_cholesterol", value: 170 },
  { code: "total_protein", value: 7.3 },
  { code: "albumin", value: 4.75 },
  { code: "free_t4_thyroxine", value: 1 },
  { code: "iron_serum", value: 172 },
  { code: "lymphocytes", value: 40.5 },
  { code: "non_hdl_cholesterol", value: 133 },
  { code: "monocytes", value: 11.8 },
  { code: "testosterone_free", value: 11.65 },
  { code: "hba1c", value: 5.5 },
  { code: "creatinine", value: 1.26 },
  { code: "magnesium_serum", value: 1.9 },
  { code: "mch", value: 32.5 },
  { code: "homocysteine", value: 10.1 },
  { code: "ferritin", value: 177 },
  { code: "hematocrit", value: 47.5 },
  { code: "ldl_cholesterol", value: 113 },
  { code: "iron_saturation_tsat", value: 58.88 },
  { code: "vitamin_b12", value: 600 },
  { code: "hdl_cholesterol", value: 37 },
  { code: "apolipoprotein_b_apob", value: 79 },
  { code: "hs_crp", value: 1.1 },
  { code: "triglycerides", value: 102 },
  { code: "mcv", value: 98.8 },
  { code: "lipoproteina", value: 13 },
  { code: "testosterone_total", value: 473 },
  { code: "vitamin_d_25_oh", value: 25 },
];

const adapted = kdmInputsFromBiomarkerValues(biomarkers);
const filled = deriveFructosamineIfMissing(adapted.inputs);
const basePanelSet = new Set(BASE_PANEL);

console.log("=".repeat(95));
console.log(`KDM Reference BA breakdown — male, CA=${ca}, lab 7e397cf0`);
console.log("=".repeat(95));
console.log("");
console.log("Per-marker contribution to BA_E (Reference, 14-marker base panel only):");
console.log(
  "marker".padEnd(40) +
    "x".padStart(8) +
    "q".padStart(10) +
    "k".padStart(10) +
    "s".padStart(8) +
    "(x-q)".padStart(9) +
    "yrs".padStart(10) +
    "  src",
);
console.log("-".repeat(95));

let numSum = 0;
let denomSum = 0;
const perMarker: Array<{
  name: string;
  v: number;
  q: number;
  contrib_years: number;
  spanish: boolean;
}> = [];

for (const [markerKey, rawValue] of Object.entries(filled)) {
  if (!basePanelSet.has(markerKey)) continue;
  const entry = library.markers[markerKey];
  if (!entry) continue;
  const r = resolveMarkerParamsWithRecalibration(entry, sex);
  if (!r) continue;
  const { k, q, s, log_transformed } = r.params;
  if (!Number.isFinite(k) || !Number.isFinite(q) || !Number.isFinite(s) || s <= 0)
    continue;

  let v = rawValue;
  if (log_transformed) {
    if (rawValue <= 0) continue;
    v = Math.log(rawValue);
  }

  const contrib_num = (v - q) * (k / (s * s));
  const contrib_denom = (k / s) ** 2;
  // Each marker's "implied years above q" if it were the only contributor:
  const impliedYears = (v - q) / k;

  numSum += contrib_num;
  denomSum += contrib_denom;

  perMarker.push({
    name: markerKey,
    v: rawValue,
    q,
    contrib_years: impliedYears,
    spanish: r.spanishRecalibrationApplied,
  });

  const src = r.spanishRecalibrationApplied ? "q_spain" : "q_NHANES";
  const xDisp = log_transformed ? `${rawValue.toFixed(2)}(ln=${v.toFixed(3)})` : rawValue.toFixed(2);
  console.log(
    markerKey.padEnd(40) +
      xDisp.padStart(8) +
      q.toFixed(3).padStart(10) +
      k.toFixed(4).padStart(10) +
      s.toFixed(3).padStart(8) +
      (v - q).toFixed(3).padStart(9) +
      impliedYears.toFixed(2).padStart(10) +
      "  " +
      src,
  );
}

const BA_E = numSum / denomSum;
const s_BA = Math.sqrt(1.0 / denomSum);
const sCa = resolveSCa("reference");
const sCaUsed = sCa.male ?? sCa.pooled ?? 10;
const sBA2 = 1.0 / denomSum;
const sCa2 = sCaUsed * sCaUsed;
const BA = (BA_E / sBA2 + ca / sCa2) / (1.0 / sBA2 + 1.0 / sCa2);

console.log("-".repeat(95));
console.log("");
console.log("Aggregate math:");
console.log(`  num   = Σ (x-q)·(k/s²) = ${numSum.toFixed(6)}`);
console.log(`  denom = Σ (k/s)²       = ${denomSum.toFixed(6)}`);
console.log("");
console.log(`  BA_E  = num / denom           = ${BA_E.toFixed(2)} years`);
console.log(`  s_BA  = √(1/denom)            = ${s_BA.toFixed(2)} years`);
console.log(`  s_CA  = (Reference, male)     = ${sCaUsed.toFixed(2)} years`);
console.log("");
console.log("CA-anchored shrinkage (Klemera-Doubal eq. 39):");
const wBaE = sCa2 / (sBA2 + sCa2);
const wCa = sBA2 / (sBA2 + sCa2);
console.log(`  weight on BA_E  = s_CA² / (s_BA² + s_CA²) = ${wBaE.toFixed(3)}`);
console.log(`  weight on CA    = s_BA² / (s_BA² + s_CA²) = ${wCa.toFixed(3)}`);
console.log(
  `  BA = ${wBaE.toFixed(3)} × ${BA_E.toFixed(2)} + ${wCa.toFixed(3)} × ${ca}`,
);
console.log(`     = ${(wBaE * BA_E).toFixed(2)} + ${(wCa * ca).toFixed(2)}`);
console.log(`     = ${BA.toFixed(2)} years`);
console.log("");
console.log("Compare to what was written to the DB: 40.57");
console.log("");

console.log("=".repeat(95));
console.log("Per-marker plain-language interpretation");
console.log("=".repeat(95));
console.log("");
perMarker.sort((a, b) => b.contrib_years - a.contrib_years);
console.log(
  "marker".padEnd(40) +
    "value".padStart(10) +
    "pop mean".padStart(12) +
    "yrs above pop".padStart(16) +
    "  basis",
);
console.log("-".repeat(95));
for (const m of perMarker) {
  const entry = library.markers[m.name];
  const log = entry?.log_transformed;
  // For log markers, recover raw-scale mean by exp(q)
  const popMean = log ? Math.exp(m.q) : m.q;
  const popDisplay = log
    ? `${popMean.toFixed(2)} (ln ${m.q.toFixed(2)})`
    : popMean.toFixed(2);
  const arrow = m.contrib_years > 0 ? "↑" : "↓";
  console.log(
    m.name.padEnd(40) +
      m.v.toFixed(2).padStart(10) +
      popDisplay.padStart(12) +
      `${arrow} ${m.contrib_years.toFixed(1)}`.padStart(16) +
      "  " +
      (m.spanish ? "Spanish q_spain" : "NHANES q"),
  );
}
console.log("");
console.log(
  "(Note: 'yrs above pop' = (x-q)/k = years of CA this single marker's value would imply if it were the only marker. The joint estimator weights these by 1/s² and combines them.)",
);
