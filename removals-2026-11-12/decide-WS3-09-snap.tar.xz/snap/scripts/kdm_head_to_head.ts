/**
 * Head-to-head BA comparison for user 7e397cf0:
 *   1. Our KDM v2.2 full 14-marker base panel (as deployed)        — what we wrote: 40.57
 *   2. Our KDM v2.2 restricted to Levine PhenoAge 9-marker subset  — ChatGPT-style "regular KDM" proxy
 *   3. Our KDM v2.2 with creatinine offset for 10g/day creatine     — proposed fix
 *   4. Our KDM v2.2 dropping creatinine entirely                    — most conservative
 *
 * This isolates: panel composition vs lifestyle-correction effects.
 */
import {
  klemeraDoubalBa,
  resolveMarkerParamsWithRecalibration,
  resolveSCa,
  type KdmLibraryMarker,
  type KdmMarkerParams,
} from "../src/lib/biomarkers/biological-age-kdm";
import { kdmInputsFromBiomarkerValues } from "../src/lib/biomarkers/kdm-adapter";
import { deriveFructosamineIfMissing } from "../src/lib/biomarkers/biological-age-kdm";
import libraryData from "../src/lib/biomarkers/data/marker_library_v2_2.json";

const library = libraryData as unknown as {
  markers: Record<string, KdmLibraryMarker>;
};

const sex: "male" = "male";
const ca = 30;

const biomarkers = [
  { code: "albumin", value: 4.75 },
  { code: "creatinine", value: 1.26 },
  { code: "bun", value: 16.36 },
  { code: "uric_acid", value: 5.8 },
  { code: "total_cholesterol", value: 170 },
  { code: "hdl_cholesterol", value: 37 },
  { code: "triglycerides", value: 102 },
  { code: "hs_crp", value: 1.1 },
  { code: "ferritin", value: 177 },
  { code: "vitamin_d_25_oh", value: 25 },
  { code: "hba1c", value: 5.5 },
  // Levine PhenoAge needs these (not all base panel)
  { code: "glucose_fasting", value: 87 },
  { code: "lymphocytes", value: 40.5 },
  { code: "mcv", value: 98.8 },
  { code: "white_blood_cell_count", value: 5.3 },
];

const adapted = kdmInputsFromBiomarkerValues(biomarkers);
const filled = deriveFructosamineIfMissing(adapted.inputs);

function computeBa(
  inputs: Record<string, number>,
  label: string,
): { BA: number; n: number; markers: string[] } | null {
  const params: Record<string, KdmMarkerParams> = {};
  for (const key of Object.keys(inputs)) {
    const e = library.markers[key];
    if (!e) continue;
    const r = resolveMarkerParamsWithRecalibration(e, sex);
    if (!r) continue;
    params[key] = r.params;
  }
  const sCa = resolveSCa("reference");
  const ba = klemeraDoubalBa(inputs, params, ca, true, sCa, sex);
  if (!ba) return null;
  return {
    BA: ba.BA,
    n: ba.n_markers_used,
    markers: ba.used_markers,
  };
}

console.log("=".repeat(80));
console.log("Head-to-head BA — user 7e397cf0 (male, CA=30, supplements 10g/day creatine)");
console.log("=".repeat(80));

// 1. Our v2.2 full base panel
const FULL_BASE_PANEL = new Set([
  "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
  "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
  "Colesterol Total", "Colesterol HDL", "Triglicéridos",
  "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
  "TSH", "Fructosamina",
]);
const basePanelOnly: Record<string, number> = {};
for (const [k, v] of Object.entries(filled)) {
  if (FULL_BASE_PANEL.has(k)) basePanelOnly[k] = v;
}
const r1 = computeBa(basePanelOnly, "full");
console.log("\n[1] Our KDM v2.2 — full 14-marker base panel");
console.log(`    BA = ${r1?.BA.toFixed(2)}, n_used = ${r1?.n}`);
console.log(`    markers: ${r1?.markers.join(", ")}`);

// 2. Levine PhenoAge subset (intersection with our library)
// Levine uses: Albumin, Creatinine, Glucose, ln(CRP), Lymphocyte%, MCV, WBC, RDW, ALP
// Of these, intersection with the eva-health KDM base panel + extended:
const LEVINE_SUBSET = new Set([
  "Albúmina",
  "Creatinina",
  "Glucosa (Ayunas)",
  "PCR de Alta Sensibilidad (hs-PCR)",
  "Linfocitos",
  "VCM (Volumen Corpuscular Medio)",
  "Recuento de Glóbulos Blancos",
  // RDW and ALP not in user's May lab
]);
const levineOnly: Record<string, number> = {};
for (const [k, v] of Object.entries(filled)) {
  if (LEVINE_SUBSET.has(k)) levineOnly[k] = v;
}
const r2 = computeBa(levineOnly, "levine");
console.log("\n[2] Our KDM v2.2 — restricted to Levine PhenoAge subset (7 of 9; user lacks RDW + ALP)");
console.log(`    BA = ${r2?.BA.toFixed(2)}, n_used = ${r2?.n}`);
console.log(`    markers: ${r2?.markers.join(", ")}`);

// 3. With creatinine offset for 10g/day creatine (0.05 + 0.025 × 10 = 0.30 mg/dL)
const baseAdjusted = { ...basePanelOnly };
if ("Creatinina" in baseAdjusted) {
  baseAdjusted["Creatinina"] = Math.max(0, baseAdjusted["Creatinina"] - 0.30);
}
const r3 = computeBa(baseAdjusted, "adjusted");
console.log("\n[3] Our KDM v2.2 — full base panel WITH creatinine offset -0.30 mg/dL (10g/day creatine)");
console.log(`    Creatinina: 1.26 → 0.96 mg/dL (literature-supported offset)`);
console.log(`    BA = ${r3?.BA.toFixed(2)}, n_used = ${r3?.n}`);

// 4. Drop creatinine entirely (most conservative)
const baseNoCreat = { ...basePanelOnly };
delete baseNoCreat["Creatinina"];
const r4 = computeBa(baseNoCreat, "no_creat");
console.log("\n[4] Our KDM v2.2 — base panel DROPPING creatinine entirely");
console.log(`    BA = ${r4?.BA.toFixed(2)}, n_used = ${r4?.n}`);

// 5. Both adjustments: creatinine offset + drop BUN (since user's elevated BUN is likely lifestyle/protein)
const baseNoBunCreatAdjusted = { ...baseAdjusted };
delete baseNoBunCreatAdjusted["BUN (Nitrógeno Ureico en Sangre)"];
const r5 = computeBa(baseNoBunCreatAdjusted, "no_bun_adjusted");
console.log("\n[5] Our KDM v2.2 — base panel WITH creatinine offset AND dropping BUN");
console.log(`    BA = ${r5?.BA.toFixed(2)}, n_used = ${r5?.n}`);

console.log("\n" + "=".repeat(80));
console.log("Summary:");
console.log("=".repeat(80));
console.log(`  [1] Full v2.2 panel (as deployed):       BA = ${r1?.BA.toFixed(2)} (Δ ${(r1!.BA - ca).toFixed(1)}y)`);
console.log(`  [2] Levine 7/9 subset (no BUN/UA/Fruct): BA = ${r2?.BA.toFixed(2)} (Δ ${(r2!.BA - ca).toFixed(1)}y)`);
console.log(`  [3] Creatinine -0.30 adjustment:         BA = ${r3?.BA.toFixed(2)} (Δ ${(r3!.BA - ca).toFixed(1)}y)`);
console.log(`  [4] Drop creatinine entirely:            BA = ${r4?.BA.toFixed(2)} (Δ ${(r4!.BA - ca).toFixed(1)}y)`);
console.log(`  [5] Adjust creatinine + drop BUN:        BA = ${r5?.BA.toFixed(2)} (Δ ${(r5!.BA - ca).toFixed(1)}y)`);
