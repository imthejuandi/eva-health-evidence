#!/usr/bin/env python3
"""
Validate Comprehensive BA against mortality — and test whether applying
Path B (unwinsorized refit) to ALL markers fixes the Reference/Comprehensive
discrepancy without sacrificing mortality predictiveness.

Three configurations evaluated against NHANES n=18,570 with Cox PH:

  CONFIG A: Path 0 (current production v2.2)
            Winsorized parameters for all markers.

  CONFIG B: Path B-light (current production v2.2.1)
            Unwinsorized (k,q,s) for BUN + Fructosamine. Rest winsorized.

  CONFIG C: Path B-full (proposed)
            Unwinsorized (k,q,s) for ALL trained markers.

For each config, compute Reference + Comprehensive BA, run Cox PH against
mortality with age + sex covariates, and report HR/SD, C-statistic,
calibration slope.

This tells us whether the noise-amplifier markers (low R², high weight)
in the Comprehensive panel actually predict mortality or just inflate
BA estimates.
"""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index

ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2")
LIBRARY_PATH = ROOT / "output" / "marker_library_v2_2.json"
CLEANED_PATH = ROOT / "output" / "nhanes_continuous_cleaned.parquet"
NHANES_ROOT = ROOT / "output" / "raw_nhanes"

BASE_PANEL = {
    "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
    "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
    "Colesterol Total", "Colesterol HDL", "Triglicéridos",
    "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
    "TSH", "Fructosamina",
}
MANDATORY = ["Albúmina", "Creatinina"]
MIN_BASE = 8

# ─── Path B overrides ───
# Already deployed (Path B-light) — sourced from raw NHANES refit
PATH_B_LIGHT = {
    "BUN (Nitrógeno Ureico en Sangre)": {"k": 0.1344, "q": 7.1314, "s": 5.4758},
    "Fructosamina": {"k": 0.0044, "q": 4.0785, "s": 0.2052},
}


def fit_ols(values: np.ndarray, ages: np.ndarray, log_transformed: bool):
    """OLS y = q + k*age. Returns (k, q, s, r²)."""
    if log_transformed:
        valid = (values > 0) & np.isfinite(ages) & np.isfinite(values)
        x = ages[valid]
        y = np.log(values[valid])
    else:
        valid = np.isfinite(values) & np.isfinite(ages)
        x = ages[valid]
        y = values[valid]
    if len(x) < 100:
        return None
    xm, ym = x.mean(), y.mean()
    sxy = ((x - xm) * (y - ym)).sum()
    sxx = ((x - xm) ** 2).sum()
    k = sxy / sxx
    q = ym - k * xm
    resid = y - (q + k * x)
    s = float(resid.std(ddof=2))
    ss_tot = ((y - ym) ** 2).sum()
    ss_res = (resid ** 2).sum()
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {"k": float(k), "q": float(q), "s": s, "r2": float(r2), "n": int(valid.sum())}


def refit_unwinsorized_all(wide: pd.DataFrame, library: dict) -> dict:
    """For each trained marker, refit OLS on unwinsorized raw data.
    Returns {marker_name: {k, q, s, r2}}."""
    print("  Re-fitting all markers without winsorization...")
    overrides = {}
    library_markers = library["markers"]
    for name, m in library_markers.items():
        if m.get("kdm_contribution") != "trained":
            continue
        if name not in wide.columns:
            continue
        sex_strat = m.get("sex_stratified", False)
        log = m.get("log_transformed", False)
        if sex_strat:
            # Re-fit per sex
            for sex_key, sex_filter in (("M", "M"), ("F", "F")):
                sub = wide[wide["sex"] == sex_filter]
                vals = sub[name].dropna().to_numpy()
                ages = sub.loc[sub[name].notna(), "age"].to_numpy()
                # Use UNWINSORIZED raw values — note wide has the
                # `value_winsorized` from training; we want raw. Skip
                # for sex-stratified for now to keep things simple
                # (the worst offenders aren't sex-stratified anyway).
                pass
            continue  # leave sex-stratified at library values for now
        else:
            sub = wide[[name, "age"]].dropna()
            if len(sub) < 100:
                continue
            fit = fit_ols(sub[name].to_numpy(), sub["age"].to_numpy(), log)
            if fit:
                overrides[name] = fit
    return overrides


def resolve_params(entry, sex, marker, overrides=None):
    if overrides and marker in overrides:
        o = overrides[marker]
        return {"k": o["k"], "q": o["q"], "s": o["s"],
                "log": entry.get("log_transformed", False)}
    if entry.get("sex_stratified"):
        block = entry.get("kqs_M") if sex == "M" else entry.get("kqs_F")
    else:
        block = entry.get("kqs")
    if not block or block.get("k") is None:
        return None
    k, q, s = block["k"], block["q"], block["s"]
    sr = entry.get("spanish_recalibration", {})
    if sr.get("calibration_status", "").startswith("recalibrated"):
        if entry.get("sex_stratified"):
            per_sex = (sr.get("per_sex") or {}).get(sex, {}) or {}
            qs = per_sex.get("q_spain")
            if qs is not None:
                q = qs
        else:
            qs = sr.get("q_spain")
            if qs is not None:
                q = qs
    return {"k": k, "q": q, "s": s, "log": entry.get("log_transformed", False)}


def kd_ba(values, library_markers, sex, ca, s_ca, overrides, restrict_to_base):
    """KDM joint estimator. Returns BA or None if gate fails."""
    base_present = [m for m in BASE_PANEL if m in values and pd.notna(values[m])]
    if len(base_present) < MIN_BASE:
        return None
    for m in MANDATORY:
        if m not in values or pd.isna(values[m]):
            return None
    num = denom = 0.0
    used = 0
    for marker, value in values.items():
        if pd.isna(value) or not math.isfinite(value):
            continue
        if restrict_to_base and marker not in BASE_PANEL:
            continue
        entry = library_markers.get(marker)
        if not entry:
            continue
        p = resolve_params(entry, sex, marker, overrides)
        if not p or p["s"] <= 0:
            continue
        v = math.log(value) if p["log"] and value > 0 else value
        if not math.isfinite(v):
            continue
        num += (v - p["q"]) * (p["k"] / (p["s"] ** 2))
        denom += (p["k"] / p["s"]) ** 2
        used += 1
    if denom == 0 or used == 0:
        return None
    ba_e = num / denom
    s_ba2 = 1.0 / denom
    s_ca2 = s_ca ** 2
    return (ba_e / s_ba2 + ca / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)


def cox(df, ba_col, label):
    sub = df.dropna(subset=[ba_col, "age", "follow_up_years", "died"]).copy()
    if len(sub) < 100 or sub["died"].sum() < 100:
        return None
    sub["BA_z"] = (sub[ba_col] - sub[ba_col].mean()) / sub[ba_col].std()
    sub["sex_M"] = (sub["sex"] == "M").astype(int)
    sub["T"] = sub["follow_up_years"]
    sub["E"] = sub["died"].astype(int)
    cph = CoxPHFitter()
    cph.fit(sub[["BA_z", "age", "sex_M", "T", "E"]], duration_col="T", event_col="E", show_progress=False)
    hr = float(np.exp(cph.params_["BA_z"]))
    ci = cph.confidence_intervals_.loc["BA_z"].tolist()
    c_stat = float(concordance_index(sub["T"], -cph.predict_partial_hazard(sub), sub["E"]))
    return {"label": label, "n": int(len(sub)), "events": int(sub["E"].sum()),
            "hr": hr, "hr_lo": float(np.exp(ci[0])), "hr_hi": float(np.exp(ci[1])),
            "c_stat": c_stat}


def main():
    print("Loading library + cleaned NHANES...")
    library = json.loads(LIBRARY_PATH.read_text())
    library_markers = library["markers"]
    df_long = pd.read_parquet(CLEANED_PATH)

    # Pivot to wide using the UNWINSORIZED raw value for the refit, but
    # winsorized for the BA estimator (matches deployed behavior on inputs).
    df_long_w = df_long.copy()
    df_long_w["v"] = np.where(df_long_w["value_log"].notna(),
                              np.exp(df_long_w["value_log"]),
                              df_long_w["value_winsorized"])
    wide = df_long_w.pivot_table(
        index=["SEQN", "cycle", "age", "sex", "follow_up_years", "died"],
        columns="marker_es", values="v", aggfunc="first",
    ).reset_index()

    # Also pivot RAW (unwinsorized) values for full-panel refit
    df_raw = df_long.dropna(subset=["value"]).copy()
    wide_raw = df_raw.pivot_table(
        index=["SEQN", "cycle", "age", "sex"],
        columns="marker_es", values="value", aggfunc="first",
    ).reset_index()
    print(f"  wide shape: {wide.shape} | raw shape: {wide_raw.shape}")

    # Refit all markers on unwinsorized raw data (CONFIG C)
    path_b_full = refit_unwinsorized_all(wide_raw, library)
    print(f"  refit {len(path_b_full)} markers without winsorization\n")

    # s_ca values from phase_4_log (computed during training)
    s_ca_ref = {"M": 24.678, "F": 23.274}
    s_ca_comp = {"M": 14.003, "F": 13.914}

    configs = [
        ("A (current v2.2)", None),
        ("B (current v2.2.1)", PATH_B_LIGHT),
        ("C (full Path B)", path_b_full),
    ]

    print("Computing BA for each subject across all configs...")
    for label, overrides in configs:
        print(f"  {label}...")
        ref_col = f"BA_ref_{label.split()[0]}"
        comp_col = f"BA_comp_{label.split()[0]}"
        ref_list, comp_list = [], []
        for _, row in wide.iterrows():
            sex = row["sex"]
            ca = row["age"]
            if pd.isna(sex) or pd.isna(ca):
                ref_list.append(np.nan)
                comp_list.append(np.nan)
                continue
            values = {m: row.get(m) for m in library_markers if m in wide.columns}
            sca_r = s_ca_ref.get(sex, 24.0)
            sca_c = s_ca_comp.get(sex, 14.0)
            ref_list.append(kd_ba(values, library_markers, sex, ca, sca_r, overrides, True))
            comp_list.append(kd_ba(values, library_markers, sex, ca, sca_c, overrides, False))
        wide[ref_col] = ref_list
        wide[comp_col] = comp_list

    print("\n" + "=" * 90)
    print("MORTALITY VALIDATION (Cox PH, n=18,570, age + sex adjusted)")
    print("=" * 90)
    print(f"{'config':25s} {'tier':14s} {'HR/SD':>10s} {'95% CI':>20s} {'C-stat':>8s}")
    print("-" * 90)
    for label, _ in configs:
        short = label.split()[0]
        for tier, col in (("Reference", f"BA_ref_{short}"), ("Comprehensive", f"BA_comp_{short}")):
            r = cox(wide, col, label)
            if r:
                ci = f"[{r['hr_lo']:.3f}, {r['hr_hi']:.3f}]"
                print(f"{label:25s} {tier:14s} {r['hr']:>10.4f} {ci:>20s} {r['c_stat']:>8.4f}")

    # Discrepancy in mean BA (Reference vs Comprehensive)
    print("\n" + "=" * 90)
    print("REFERENCE vs COMPREHENSIVE BA — population-level discrepancy")
    print("=" * 90)
    print(f"{'config':25s} {'mean Ref':>10s} {'mean Comp':>11s} {'mean Δ':>10s} {'SD Δ':>10s}")
    print("-" * 90)
    for label, _ in configs:
        short = label.split()[0]
        ref_col = f"BA_ref_{short}"
        comp_col = f"BA_comp_{short}"
        sub = wide.dropna(subset=[ref_col, comp_col])
        delta = sub[comp_col] - sub[ref_col]
        print(f"{label:25s} {sub[ref_col].mean():>10.2f} {sub[comp_col].mean():>11.2f} "
              f"{delta.mean():>10.3f} {delta.std():>10.3f}")


if __name__ == "__main__":
    main()
