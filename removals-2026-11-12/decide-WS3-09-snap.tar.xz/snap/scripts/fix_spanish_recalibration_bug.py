#!/usr/bin/env python3
"""
Fix the build_library.py bug that dropped per_sex.q_spain for sex-stratified
markers. The bug: build_library.py line 189 checks `if "slope" in rc:` and
only writes q_NHANES/q_spain when slope is at the top level (pooled
markers). Sex-stratified markers have the recalibration data in
`rc["per_sex"]["M"|"F"]`, which never gets copied to the deployed library.

Affected base panel markers (all 4 had silent no-op Spanish recalibration):
  - Creatinina    (M/F)
  - Ácido Úrico   (M/F)
  - GGT           (M/F)
  - Colesterol HDL (M/F)

Reads the intermediate `spanish_recalibration.json` from the training
output, extracts per_sex.q_spain for each, patches the deployed library
JSON in eva-health.
"""
import json
from pathlib import Path

TRAINING_RECALIB = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2/output/spanish_recalibration.json")
DEPLOYED_LIBRARY = Path("/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/marker_library_v2_2.json")

# Affected markers — also a sanity check we don't touch ones that were correctly handled
SEX_STRATIFIED_RECALIBRATED = [
    "Creatinina",
    "Ácido Úrico",
    "GGT (Gamma-glutamil Transferasa)",
    "Colesterol HDL",
    "Hemoglobina",
    "Testosterona Total",
]


def main():
    recalib = json.loads(TRAINING_RECALIB.read_text())
    library = json.loads(DEPLOYED_LIBRARY.read_text())

    patched = []
    for marker in SEX_STRATIFIED_RECALIBRATED:
        rc = recalib.get(marker)
        if not rc:
            print(f"⊘ {marker}: not in training recalibration output, skipping")
            continue

        per_sex = rc.get("per_sex")
        if not per_sex:
            print(f"⊘ {marker}: recalibration has no per_sex block, skipping")
            continue

        lib_marker = library["markers"].get(marker)
        if not lib_marker:
            print(f"✗ {marker}: not in deployed library, BUG")
            continue

        sr = lib_marker.get("spanish_recalibration")
        if not sr:
            print(f"⊘ {marker}: no spanish_recalibration block in library, skipping")
            continue

        # Build the per_sex structure (sliced to the relevant numeric fields)
        new_per_sex = {}
        for sex in ("M", "F"):
            block = per_sex.get(sex)
            if not block:
                continue
            entry = {}
            for key in ("slope", "intercept", "q_NHANES", "q_spain", "mean_NHANES", "mean_spain"):
                if key in block:
                    entry[key] = block[key]
            if entry:
                new_per_sex[sex] = entry

        if not new_per_sex:
            print(f"⊘ {marker}: per_sex empty, skipping")
            continue

        # Patch the library
        sr["per_sex"] = new_per_sex
        patched.append(marker)
        m_str = ", ".join(
            f"{sex}: q_spain={new_per_sex[sex].get('q_spain', '?'):.4f}"
            for sex in new_per_sex
        )
        print(f"✓ {marker} → patched {m_str}")

    # Write back
    DEPLOYED_LIBRARY.write_text(
        json.dumps(library, indent=2, ensure_ascii=False) + "\n"
    )
    print(f"\nPatched {len(patched)} markers. Wrote {DEPLOYED_LIBRARY}.")


if __name__ == "__main__":
    main()
