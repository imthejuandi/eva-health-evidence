#!/usr/bin/env python3
"""
KDM panel re-validation: does the biological age predict mortality as well
without the markers that read a move toward optimal as aging?
(docs/biomarker-evidence/longevity/KDM-DIRECTION.md)

Four panels, each scored in both tiers (Reference = 14-marker base panel;
Comprehensive = every marker with parameters), on the same NHANES subjects:

  current  the deployed v2.2.2 panel
  A        current minus Vitamin D
  B        A minus Ferritin and HDL-C
  C        B minus TSH and GGT

Method: as scripts/comprehensive_ba_mortality_validation.py. Same NHANES file
and wide table (value_log back-transformed, else value_winsorized), same gate
(>= 8 of the 14 base markers, albumin and creatinine present), same Cox PH on
BA_z + age + sex (lifelines): HR per SD with its 95% CI, C-statistic.

What is refit for a panel change, and nothing else:
  - s_CA, per tier and sex: the SD of (BA_E - CA) over the sample, the
    estimator of scripts/honest_holdout_validation.py. It is the only model
    parameter that depends on the panel (kdm_s_ca.json keeps one per panel),
    so it is re-estimated for every panel, the current one included, and the
    four panels are scored the same way.
  - Marker parameters (k, q, s) are NOT refit: each is a regression of one
    marker on age and does not depend on the panel. They are read from this
    repository exactly as src/lib/biomarkers/biological-age-kdm.ts resolves
    them (library, sex stratification, Spanish q, Path B overrides).
  - The gate is NOT changed: it is applied once, with the current panel, and
    fixes the sample, so every panel is scored on the same subjects.
A reproduction row scores the current panel with the deployed s_CA
(kdm_s_ca.json), to compare with the published v2.2.2 figures.

Pre-registered rule (printed with the result): a candidate panel is adopted
only if its C-statistic is within 0.005 of the current panel's and its
HR-per-SD 95% CI overlaps the current one's.

Usage (runbook: docs/runbooks/kdm-panel-revalidation.md):
  python3 scripts/kdm_panel_revalidation.py --dry-run      # synthetic data, seconds
  python3 scripts/kdm_panel_revalidation.py [--nhanes PATH] [--out FILE]
"""
import argparse
import hashlib
import json
import math
import statistics
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import lifelines
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index

REPO = Path(__file__).resolve().parent.parent
DATA = REPO / "src" / "lib" / "biomarkers" / "data"
LIBRARY_PATH = DATA / "marker_library_v2_2.json"
PATH_B_PATH = DATA / "path_b_overrides.json"
S_CA_PATH = DATA / "kdm_s_ca.json"
NHANES_PATH = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2") / "output" / "nhanes_continuous_cleaned.parquet"
LONG_COLUMNS = ["SEQN", "cycle", "age", "sex", "follow_up_years", "died", "marker_es", "value", "value_log", "value_winsorized"]

MANDATORY = ["Albúmina", "Creatinina"]
MIN_BASE = 8
PANELS = [
    ("current", []),
    ("A", ["Vitamina D (25-OH)"]),
    ("B", ["Vitamina D (25-OH)", "Ferritina", "Colesterol HDL"]),
    ("C", ["Vitamina D (25-OH)", "Ferritina", "Colesterol HDL", "TSH", "GGT (Gamma-glutamil Transferasa)"]),
]
SHORT = {"Vitamina D (25-OH)": "vitamin D", "Ferritina": "ferritin", "Colesterol HDL": "HDL-C",
         "TSH": "TSH", "GGT (Gamma-glutamil Transferasa)": "GGT"}
TIERS = [("Reference", "reference", True), ("Comprehensive", "comprehensive", False)]
C_MARGIN = 0.005
# Published v2.2.2 validation (path_b_overrides.json _meta, biological-age-kdm.ts header).
PUBLISHED = {"Reference": (1.391, 0.770), "Comprehensive": (1.654, 0.775)}
PUBLISHED_N = 18570
RULE = ("a candidate panel is adopted only if its C-statistic is within 0.005 of the current "
        "panel's and its HR-per-SD 95% CI overlaps the current one's.")


def log(msg):
    print(msg, file=sys.stderr, flush=True)


def require(path, hint=""):
    if not Path(path).is_file():
        sys.exit(f"ERROR: required file not found: {path}{hint}")


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


# ─── Model, as src/lib/biomarkers/biological-age-kdm.ts ───

def resolve_params(entry, path_b, sex):
    """(k, q, s, log) for one marker and sex ("M"/"F"), or None: the library
    block (sex-stratified or pooled), the Spanish q when recalibrated, then the
    Path B override of k and s (and of q, unless the Spanish q applied)."""
    strat = entry.get("sex_stratified")
    block = entry.get("kqs_M" if sex == "M" else "kqs_F") if strat else entry.get("kqs")
    if not block:
        return None
    k, q, s = block.get("k"), block.get("q"), block.get("s")
    if not (finite(k) and finite(q) and finite(s) and s > 0):
        return None
    spanish = None
    sr = entry.get("spanish_recalibration") or {}
    if str(sr.get("calibration_status") or "").startswith("recalibrated_"):
        src = ((sr.get("per_sex") or {}).get(sex) or {}) if strat else sr
        if finite(src.get("q_spain")):
            spanish = src["q_spain"]
            q = spanish
    if path_b:
        pb = path_b.get("kqs_M" if sex == "M" else "kqs_F") if path_b.get("sex_stratified") else path_b.get("kqs")
        if pb:
            k, s = pb["k"], pb["s"]
            if spanish is None:
                q = pb["q"]
    if not (finite(k) and finite(q) and finite(s) and s > 0):
        return None
    return (k, q, s, bool(entry.get("log_transformed")))


def resolve_all(library_markers, path_b_markers, sex):
    out = {}
    for name, entry in library_markers.items():
        p = resolve_params(entry, path_b_markers.get(name), sex)
        if p:
            out[name] = p
    return out


def passes_gate(values, base_panel):
    """>= 8 base-panel markers, albumin and creatinine present (kd_ba in the existing scripts)."""
    present = sum(1 for m in base_panel if finite(values.get(m)))
    return present >= MIN_BASE and all(finite(values.get(m)) for m in MANDATORY)


def marker_terms(values, params):
    """{marker: (numerator term, denominator term)} of one subject: the markers
    the estimator uses (value present; > 0 when log-transformed)."""
    out = {}
    for m, x in values.items():
        p = params.get(m)
        if p is None or not finite(x):
            continue
        k, q, s, is_log = p
        if is_log:
            if x <= 0:
                continue
            x = math.log(x)
        out[m] = ((x - q) * (k / (s * s)), (k / s) ** 2)
    return out


def panel_sums(terms, panel):
    num = den = 0.0
    for m, (n, d) in terms.items():
        if m in panel:
            num += n
            den += d
    return num, den


def anchored_ba(num, den, ca, s_ca):
    """CA-anchored BA (Klemera & Doubal 2006 eq. 39), as klemeraDoubalBa."""
    ba_e = num / den
    s_ba2 = 1.0 / den
    s_ca2 = s_ca ** 2
    return (ba_e / s_ba2 + ca / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)


def estimate_s_ca(subjects, sums):
    """{sex: SD of (BA_E - CA)} over the sample (ddof=1), as honest_holdout_validation.py."""
    gaps = {"M": [], "F": []}
    for (sex, ca), (num, den) in zip(subjects, sums):
        gaps[sex].append(num / den - ca)
    for sex, g in gaps.items():
        if len(g) < 100:
            sys.exit(f"ERROR: only {len(g)} subjects of sex {sex} in the sample; s_CA needs at least 100")
    return {sex: statistics.stdev(g) for sex, g in gaps.items()}


# ─── Data ───

def build_wide(df_long):
    """One row per subject, one column per marker, as the existing scripts pivot
    it. Subjects without follow-up drop out here (NaN index values)."""
    df = df_long.copy()
    df["v"] = np.where(df["value_log"].notna(), np.exp(df["value_log"]), df["value_winsorized"])
    return df.pivot_table(
        index=["SEQN", "cycle", "age", "sex", "follow_up_years", "died"],
        columns="marker_es", values="v", aggfunc="first",
    ).reset_index()


def synthetic_long(params, n=3000, seed=7):
    """Long table shaped like the NHANES file, drawn from the model itself with
    a latent pace of aging that also drives mortality. For --dry-run only."""
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(n):
        sex = "M" if rng.random() < 0.5 else "F"
        age = float(rng.uniform(20, 85))
        pace = float(rng.normal())
        t = float(rng.exponential(1.0 / (0.004 * math.exp(0.085 * (age - 50) + 0.5 * pace))))
        for m, (k, q, s, is_log) in params[sex].items():
            if m not in MANDATORY and rng.random() < 0.2:
                continue
            y = q + k * (age + 8 * pace) + s * float(rng.normal())
            value = math.exp(y) if is_log else y
            rows.append({"SEQN": i, "cycle": "synthetic", "age": age, "sex": sex,
                         "follow_up_years": min(t, 12.0), "died": int(t <= 12.0), "marker_es": m,
                         "value": value, "value_log": y if is_log else np.nan, "value_winsorized": value})
    return pd.DataFrame(rows)


# ─── Cox PH, as cox() in comprehensive_ba_mortality_validation.py ───

def cox(df, ba_col):
    sub = df.dropna(subset=[ba_col, "age", "follow_up_years", "died"]).copy()
    sub["BA_z"] = (sub[ba_col] - sub[ba_col].mean()) / sub[ba_col].std()
    sub["sex_M"] = (sub["sex"] == "M").astype(int)
    sub["T"] = sub["follow_up_years"]
    sub["E"] = sub["died"].astype(int)
    cph = CoxPHFitter()
    cph.fit(sub[["BA_z", "age", "sex_M", "T", "E"]], duration_col="T", event_col="E", show_progress=False)
    ci = cph.confidence_intervals_.loc["BA_z"].tolist()
    c_stat = float(concordance_index(sub["T"], -cph.predict_partial_hazard(sub[["BA_z", "age", "sex_M"]]), sub["E"]))
    return {"n": int(len(sub)), "deaths": int(sub["E"].sum()), "hr": float(np.exp(cph.params_["BA_z"])),
            "hr_lo": float(np.exp(ci[0])), "hr_hi": float(np.exp(ci[1])), "c": c_stat}


# ─── Rule and report ───

def rule_check(cand, current):
    """(C-statistic within 0.005, 95% CIs overlap), on unrounded values."""
    c_ok = abs(cand["c"] - current["c"]) <= C_MARGIN
    ci_ok = cand["hr_lo"] <= current["hr_hi"] and current["hr_lo"] <= cand["hr_hi"]
    return c_ok, ci_ok


def yes_no(ok):
    return "yes" if ok else "**no**"


def row(tier, label, removed, s_ca, r, delta_c="–", overlap="–", meets="–"):
    return (f"| {tier} | {label} | {removed} | {s_ca['M']:.2f} / {s_ca['F']:.2f} | {r['n']:,} | {r['deaths']:,} | "
            f"{r['hr']:.3f} [{r['hr_lo']:.3f}, {r['hr_hi']:.3f}] | {r['c']:.4f} | {delta_c} | {overlap} | {meets} |")


def report(results, header):
    """results: {tier: {"deployed": (s_ca, r), label: (s_ca, r)}} -> Markdown lines."""
    lines = header + [
        "",
        "| Tier | Panel | Markers removed | s_CA men / women (years) | n | Deaths | HR per SD [95% CI] | C-statistic | ΔC vs current | CI overlaps current | Meets rule |",
        "|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    verdicts = {label: [] for label, _ in PANELS[1:]}
    for tier, _, _ in TIERS:
        hr_pub, c_pub = PUBLISHED[tier]
        s_ca, r = results[tier]["deployed"]
        lines.append(row(tier, f"current, deployed s_CA (published: HR {hr_pub:.3f}, C {c_pub:.3f}, n {PUBLISHED_N:,})", "–", s_ca, r))
        s_ca, cur = results[tier]["current"]
        lines.append(row(tier, "current", "–", s_ca, cur, "baseline", "baseline", "baseline"))
        for label, dropped in PANELS[1:]:
            s_ca, r = results[tier][label]
            c_ok, ci_ok = rule_check(r, cur)
            verdicts[label].append((tier, c_ok, ci_ok, r["c"] - cur["c"]))
            lines.append(row(tier, label, ", ".join(SHORT[m] for m in dropped), s_ca, r,
                             f"{r['c'] - cur['c']:+.4f}", yes_no(ci_ok), yes_no(c_ok and ci_ok)))
    lines.append("")
    for label, checks in verdicts.items():
        ok = all(c and o for _, c, o, _ in checks)
        why = "; ".join(
            f"{tier}: " + ", ".join(
                ([] if c else [f"C-statistic {d:+.4f} (outside ±{C_MARGIN})"]) + ([] if o else ["HR-per-SD CI does not overlap"])
            ) for tier, c, o, d in checks if not (c and o))
        better = [tier for tier, _, _, d in checks if d > C_MARGIN]
        note = f" C-statistic above the current one by more than {C_MARGIN} in {', '.join(better)}: the rule as written does not cover an improvement; bring it to Gate 2." if better else ""
        lines.append(f"- Panel {label}: {'meets the rule in both tiers' if ok else 'does not meet the rule (' + why + ')'}.{note}")
    return lines


def git_sha():
    try:
        out = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=REPO, capture_output=True, text=True, timeout=10)
        return out.stdout.strip() or "unknown"
    except (OSError, subprocess.SubprocessError):
        return "unknown"


def main():
    ap = argparse.ArgumentParser(description="KDM panel re-validation against NHANES mortality.")
    ap.add_argument("--nhanes", type=Path, default=NHANES_PATH, help=f"cleaned NHANES parquet (default: {NHANES_PATH})")
    ap.add_argument("--out", type=Path, help="also write the Markdown result to this file")
    ap.add_argument("--dry-run", action="store_true", help="run every step on synthetic data (no NHANES file needed)")
    args = ap.parse_args()
    t0 = time.time()

    for path in (LIBRARY_PATH, PATH_B_PATH, S_CA_PATH):
        require(path, " (run the script from a checkout of the eva-health repository)")
    library = json.loads(LIBRARY_PATH.read_text(encoding="utf-8"))
    markers = library["markers"]
    path_b = json.loads(PATH_B_PATH.read_text(encoding="utf-8"))["markers"]
    s_ca_file = json.loads(S_CA_PATH.read_text(encoding="utf-8"))
    base = list(library["meta"]["base_panel"])
    params = {sex: resolve_all(markers, path_b, sex) for sex in ("M", "F")}
    for _, dropped in PANELS:
        unknown = [m for m in dropped if m not in base]
        if unknown:
            sys.exit(f"ERROR: panel markers not in the base panel: {unknown}")

    if args.dry_run:
        log("DRY RUN: synthetic data")
        df_long = synthetic_long(params)
        source = "synthetic data (--dry-run)"
    else:
        require(args.nhanes, "\n  Pass the file with --nhanes PATH (see docs/runbooks/kdm-panel-revalidation.md).")
        log(f"Reading {args.nhanes} ...")
        df_long = pd.read_parquet(args.nhanes)
        source = f"`{args.nhanes}` (md5 {md5(args.nhanes)}, {len(df_long):,} rows)"
    missing = [c for c in LONG_COLUMNS if c not in df_long.columns]
    if missing:
        sys.exit(f"ERROR: columns missing from the NHANES table: {missing}")

    log("Pivoting to one row per subject ...")
    wide = build_wide(df_long)
    absent = [m for m in base if m not in wide.columns]
    if absent:
        sys.exit(f"ERROR: base-panel markers missing from the NHANES table: {absent}")
    columns = [m for m in markers if m in wide.columns]

    # The sample: every subject with follow-up who passes the current gate.
    subjects, terms, outcome = [], [], []
    for age, sex, follow_up, died, *row_values in wide[["age", "sex", "follow_up_years", "died"] + columns].itertuples(index=False, name=None):
        values = {m: x for m, x in zip(columns, row_values) if finite(x)}
        if sex not in ("M", "F") or not finite(age) or not passes_gate(values, base):
            continue
        subjects.append((sex, float(age)))
        terms.append(marker_terms(values, params[sex]))
        outcome.append((follow_up, died))
    if len(subjects) < (500 if args.dry_run else 1000):
        sexes = sorted(map(str, wide["sex"].dropna().unique()))
        sys.exit(f"ERROR: only {len(subjects)} subjects pass the gate (sex values found: {sexes}); check the data file")
    frame = pd.DataFrame({"age": [a for _, a in subjects], "sex": [s for s, _ in subjects],
                          "follow_up_years": [t for t, _ in outcome], "died": [d for _, d in outcome]})
    log(f"Sample: {len(frame):,} subjects")

    results = {}
    for tier, key, restrict in TIERS:
        tier_markers = set(base) if restrict else set(params["M"]) | set(params["F"])
        results[tier] = {}
        for label, dropped in PANELS:
            panel = tier_markers - set(dropped)
            sums = [panel_sums(t, panel) for t in terms]
            if any(den <= 0 for _, den in sums):
                sys.exit(f"ERROR: {tier} {label}: a subject in the sample has no marker of the panel")
            runs = [("s_ca", estimate_s_ca(subjects, sums))]
            if label == "current":
                runs.append(("deployed", {"M": s_ca_file[key]["male"], "F": s_ca_file[key]["female"]}))
            for which, s_ca in runs:
                col = f"BA_{key}_{label}_{which}"
                frame[col] = [anchored_ba(num, den, ca, s_ca[sex]) for (sex, ca), (num, den) in zip(subjects, sums)]
                log(f"Cox: {tier} {label} ({which}) ...")
                results[tier][label if which == "s_ca" else "deployed"] = (s_ca, cox(frame, col))

    n, deaths = results["Reference"]["current"][1]["n"], results["Reference"]["current"][1]["deaths"]
    header = [
        "## KDM panel re-validation" + (" — DRY RUN on synthetic data: the numbers mean nothing" if args.dry_run else ""),
        "",
        f"- Data: {source}.",
        f"- Model parameters: this repository at {git_sha()} (library md5 {md5(LIBRARY_PATH)}, Path B md5 {md5(PATH_B_PATH)}), resolved as biological-age-kdm.ts does. Marker parameters (k, q, s) are not refit.",
        f"- Sample: {n:,} subjects with follow-up passing the current gate (>= 8 of 14 base markers, albumin, creatinine), {deaths:,} deaths; the same subjects for every row. Published v2.2.2 validation: n {PUBLISHED_N:,}.",
        f"- Method: Cox PH on BA_z + age + sex (lifelines {lifelines.__version__}, pandas {pd.__version__}, numpy {np.__version__}). s_CA re-estimated per panel, tier and sex as the SD of (BA_E − CA) on the sample; the first row of each tier uses the deployed s_CA instead, for comparison with the published figures.",
        f"- Pre-registered rule: {RULE} Applied in each tier; a panel meets the rule only if both tiers do. Runtime {time.time() - t0:.0f} s.",
    ]
    for tier, _, _ in TIERS:
        r = results[tier]["deployed"][1]
        hr_pub, c_pub = PUBLISHED[tier]
        if not args.dry_run and (abs(r["hr"] - hr_pub) > 0.05 or abs(r["c"] - c_pub) > C_MARGIN or abs(n - PUBLISHED_N) > 0.01 * PUBLISHED_N):
            header.append(f"- WARNING: {tier}, current panel with the deployed s_CA, differs from the published validation (HR {r['hr']:.3f} vs {hr_pub:.3f}, C {r['c']:.4f} vs {c_pub:.3f}, n {n:,} vs {PUBLISHED_N:,}). See the runbook before reading the table.")
    text = "\n".join(report(results, header)) + "\n"
    print(text)
    if args.out:
        args.out.write_text(text, encoding="utf-8")
        log(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
