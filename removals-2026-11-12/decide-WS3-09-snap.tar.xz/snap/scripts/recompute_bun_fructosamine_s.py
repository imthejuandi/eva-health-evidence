#!/usr/bin/env python3
"""
Path B: recompute BUN and Fructosamine residual SDs WITHOUT winsorization,
using raw NHANES XPT files. Compare against the trained s values to see
how much winsorization is inflating their KDM weights.
"""
from pathlib import Path
import numpy as np
import pandas as pd

NHANES_ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2/output/raw_nhanes")

# All BIOPRO cycles 1999-2018
BIOPRO_FILES = [
    ("LAB18", "1999-2000"),
    ("L40_B", "2001-2002"),
    ("L40_C", "2003-2004"),
    ("BIOPRO_D", "2005-2006"),
    ("BIOPRO_E", "2007-2008"),
    ("BIOPRO_F", "2009-2010"),
    ("BIOPRO_G", "2011-2012"),
    ("BIOPRO_H", "2013-2014"),
    ("BIOPRO_I", "2015-2016"),
    ("BIOPRO_J", "2017-2018"),
]
DEMO_FILES = [
    ("DEMO", "1999-2000"),
    ("DEMO_B", "2001-2002"),
    ("DEMO_C", "2003-2004"),
    ("DEMO_D", "2005-2006"),
    ("DEMO_E", "2007-2008"),
    ("DEMO_F", "2009-2010"),
    ("DEMO_G", "2011-2012"),
    ("DEMO_H", "2013-2014"),
    ("DEMO_I", "2015-2016"),
    ("DEMO_J", "2017-2018"),
]
GHB_FILES = [
    ("LAB10", "1999-2000"),
    ("L10_B", "2001-2002"),
    ("L10_C", "2003-2004"),
    ("GHB_D", "2005-2006"),
    ("GHB_E", "2007-2008"),
    ("GHB_F", "2009-2010"),
    ("GHB_G", "2011-2012"),
    ("GHB_H", "2013-2014"),
    ("GHB_I", "2015-2016"),
    ("GHB_J", "2017-2018"),
]


def load_cycle(prefix: str, cycle: str) -> pd.DataFrame | None:
    fn = NHANES_ROOT / f"{prefix}_{cycle}.XPT"
    if not fn.exists():
        return None
    try:
        return pd.read_sas(fn, format="xport")
    except Exception as e:
        print(f"  failed to read {fn.name}: {e}")
        return None


def load_marker(files, value_col, label):
    print(f"Loading {label}...")
    rows = []
    for prefix, cycle in files:
        df = load_cycle(prefix, cycle)
        if df is None:
            print(f"  {prefix}_{cycle}: missing")
            continue
        # Identify SEQN column
        if "SEQN" not in df.columns:
            continue
        if value_col not in df.columns:
            print(f"  {prefix}_{cycle}: no {value_col}")
            continue
        sub = df[["SEQN", value_col]].copy()
        sub.columns = ["SEQN", "value"]
        sub["cycle"] = cycle
        rows.append(sub)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def load_age():
    print("Loading DEMO (ages)...")
    rows = []
    for prefix, cycle in DEMO_FILES:
        df = load_cycle(prefix, cycle)
        if df is None:
            continue
        # RIDAGEYR = age in years at screening
        if "SEQN" not in df.columns or "RIDAGEYR" not in df.columns:
            continue
        sub = df[["SEQN", "RIDAGEYR"]].copy()
        sub.columns = ["SEQN", "age"]
        sub["cycle"] = cycle
        rows.append(sub)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def fit_ols(values: np.ndarray, ages: np.ndarray):
    valid = np.isfinite(values) & np.isfinite(ages) & (values > 0)
    x = ages[valid]
    y = values[valid]
    if len(x) < 100:
        return None
    x_mean, y_mean = x.mean(), y.mean()
    sxy = ((x - x_mean) * (y - y_mean)).sum()
    sxx = ((x - x_mean) ** 2).sum()
    k = sxy / sxx
    q = y_mean - k * x_mean
    resid = y - (q + k * x)
    s = resid.std(ddof=2)
    ss_tot = ((y - y_mean) ** 2).sum()
    ss_res = (resid ** 2).sum()
    r2 = 1.0 - ss_res / ss_tot
    return {"n": int(valid.sum()), "k": float(k), "q": float(q), "s": float(s),
            "r2": float(r2)}


def fit_ols_log(values: np.ndarray, ages: np.ndarray):
    valid = np.isfinite(values) & np.isfinite(ages) & (values > 0)
    x = ages[valid]
    y = np.log(values[valid])
    if len(x) < 100:
        return None
    x_mean, y_mean = x.mean(), y.mean()
    sxy = ((x - x_mean) * (y - y_mean)).sum()
    sxx = ((x - x_mean) ** 2).sum()
    k = sxy / sxx
    q = y_mean - k * x_mean
    resid = y - (q + k * x)
    s = resid.std(ddof=2)
    ss_tot = ((y - y_mean) ** 2).sum()
    ss_res = (resid ** 2).sum()
    r2 = 1.0 - ss_res / ss_tot
    return {"n": int(valid.sum()), "k": float(k), "q": float(q), "s": float(s),
            "r2": float(r2)}


def main():
    bun = load_marker(BIOPRO_FILES, "LBXSBU", "BUN")
    age = load_age()
    hba1c = load_marker(GHB_FILES, "LBXGH", "HbA1c (for derived Fructosamine)")

    # Merge BUN + age
    bun_age = bun.merge(age[["SEQN", "age"]], on="SEQN", how="inner")
    bun_age = bun_age.dropna(subset=["value", "age"])
    bun_age = bun_age[bun_age["value"] > 0]
    # Adults only (match training: typical is age >= 18)
    bun_age = bun_age[bun_age["age"] >= 18]
    print(f"\nBUN+age merged: n={len(bun_age)}")

    # Sex-stratification not needed for BUN (it's pooled, not sex_stratified)

    # ─── BUN: fit raw vs winsorized ───
    raw = fit_ols(bun_age["value"].to_numpy(), bun_age["age"].to_numpy())
    print(f"\nBUN — UNWINSORIZED fit (raw NHANES):")
    print(f"  n={raw['n']}, k={raw['k']:.4f}, q={raw['q']:.4f}, s={raw['s']:.4f}, R²={raw['r2']:.4f}")

    # Winsorize 1st-99th percentile (no sex stratification for BUN — pooled)
    p01 = bun_age["value"].quantile(0.01)
    p99 = bun_age["value"].quantile(0.99)
    win_vals = bun_age["value"].clip(p01, p99).to_numpy()
    win = fit_ols(win_vals, bun_age["age"].to_numpy())
    print(f"\nBUN — WINSORIZED 1%-99% fit (matches training):")
    print(f"  p01={p01:.2f}, p99={p99:.2f}")
    print(f"  n={win['n']}, k={win['k']:.4f}, q={win['q']:.4f}, s={win['s']:.4f}, R²={win['r2']:.4f}")

    # Compare to library
    print(f"\nBUN — LIBRARY values (sex-stratified is False, training pipeline):")
    print(f"  k=0.1183, q=7.3387, s=4.3945, R²=0.1144")

    # Distribution stats
    print(f"\nBUN raw distribution:")
    print(f"  mean={bun_age['value'].mean():.2f}, std={bun_age['value'].std():.2f}, median={bun_age['value'].median():.2f}")
    print(f"  p1={bun_age['value'].quantile(0.01):.2f}, p99={bun_age['value'].quantile(0.99):.2f}, p99.5={bun_age['value'].quantile(0.995):.2f}, max={bun_age['value'].max():.2f}")
    print(f"  fraction above 30 mg/dL: {(bun_age['value'] > 30).mean()*100:.2f}%")
    print(f"  fraction above 50 mg/dL: {(bun_age['value'] > 50).mean()*100:.2f}%")

    # ─── Fructosamine (derived from HbA1c, log-transformed) ───
    hba1c_age = hba1c.merge(age[["SEQN", "age"]], on="SEQN", how="inner")
    hba1c_age = hba1c_age.dropna(subset=["value", "age"])
    hba1c_age = hba1c_age[hba1c_age["value"] > 0]
    hba1c_age = hba1c_age[hba1c_age["age"] >= 18]
    # Derive Fructosamine via Cohen 2010
    hba1c_age["fructosamine"] = 19.97 * hba1c_age["value"] - 39.4
    hba1c_age = hba1c_age[hba1c_age["fructosamine"] > 0]
    print(f"\nFructosamine (derived from HbA1c) + age merged: n={len(hba1c_age)}")

    raw_f = fit_ols_log(hba1c_age["fructosamine"].to_numpy(), hba1c_age["age"].to_numpy())
    print(f"\nFructosamine — UNWINSORIZED fit (log scale, raw derivation):")
    print(f"  n={raw_f['n']}, k={raw_f['k']:.4f}, q={raw_f['q']:.4f}, s={raw_f['s']:.4f}, R²={raw_f['r2']:.4f}")

    p01_f = hba1c_age["fructosamine"].quantile(0.01)
    p99_f = hba1c_age["fructosamine"].quantile(0.99)
    win_vals_f = hba1c_age["fructosamine"].clip(p01_f, p99_f).to_numpy()
    win_f = fit_ols_log(win_vals_f, hba1c_age["age"].to_numpy())
    print(f"\nFructosamine — WINSORIZED 1%-99% fit (matches training):")
    print(f"  p01={p01_f:.2f}, p99={p99_f:.2f}")
    print(f"  n={win_f['n']}, k={win_f['k']:.4f}, q={win_f['q']:.4f}, s={win_f['s']:.4f}, R²={win_f['r2']:.4f}")

    print(f"\nFructosamine — LIBRARY values:")
    print(f"  k=0.0046, q=4.0763, s=0.2059, R²=0.0813")

    # ─── Summary ───
    print("\n" + "=" * 80)
    print("Weight comparison — (k/s)² before/after winsorization correction")
    print("=" * 80)

    def weight(k, s):
        return (k / s) ** 2

    bun_lib_w = weight(0.1183, 4.3945)
    bun_raw_w = weight(raw["k"], raw["s"])
    bun_win_w = weight(win["k"], win["s"])
    fruct_lib_w = weight(0.0046, 0.2059)
    fruct_raw_w = weight(raw_f["k"], raw_f["s"])
    fruct_win_w = weight(win_f["k"], win_f["s"])

    print(f"\nBUN:")
    print(f"  Library (winsorized):  (k/s)² = {bun_lib_w:.6f}")
    print(f"  Re-fit winsorized:     (k/s)² = {bun_win_w:.6f}  (should match library)")
    print(f"  Re-fit UNWINSORIZED:   (k/s)² = {bun_raw_w:.6f}  (Path B candidate)")
    print(f"  Weight reduction Path B vs library: {(1 - bun_raw_w / bun_lib_w) * 100:.1f}%")

    print(f"\nFructosamine:")
    print(f"  Library (winsorized):  (k/s)² = {fruct_lib_w:.6f}")
    print(f"  Re-fit winsorized:     (k/s)² = {fruct_win_w:.6f}")
    print(f"  Re-fit UNWINSORIZED:   (k/s)² = {fruct_raw_w:.6f}")
    print(f"  Weight reduction Path B vs library: {(1 - fruct_raw_w / fruct_lib_w) * 100:.1f}%")


if __name__ == "__main__":
    main()
