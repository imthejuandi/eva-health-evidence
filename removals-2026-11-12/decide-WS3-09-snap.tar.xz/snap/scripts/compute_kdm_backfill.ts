/**
 * One-off backfill: compute KDM v2.2 BA for each existing ready lab_result.
 *
 * Reads `scripts/backfill_kdm_inputs.json` (an array of subjects with
 * lab_id, user_id, date_of_birth, sex, biomarkers[]). Computes Reference +
 * Comprehensive BA via the new code on the kdm-v2-2-integration branch.
 * Outputs `scripts/backfill_kdm_outputs.json` for application via the
 * Supabase MCP.
 *
 * Does NOT touch the database — purely a compute step. The writer step
 * happens outside via execute_sql.
 */
import fs from "node:fs";
import path from "node:path";
import {
  computeReferenceBA,
  computeComprehensiveBA,
  type KdmPatientContext,
} from "../src/lib/biomarkers/biological-age-kdm";
import type { SupplementEntry } from "../src/lib/biomarkers/supplements";

interface BiomarkerRow {
  code: string;
  value: number;
}

interface SubjectInput {
  lab_id: string;
  user_id: string;
  collection_date: string;
  legacy_ba: number;
  sex: "male" | "female";
  date_of_birth: string;
  biomarkers: BiomarkerRow[];
  supplements?: SupplementEntry[];
}

interface SubjectOutput {
  lab_id: string;
  user_id: string;
  collection_date: string;
  legacy_ba: number;
  age: number;
  sex: "male" | "female";
  n_biomarkers_input: number;
  reference: {
    BA: number;
    BA_E: number;
    s_BA: number;
    n_markers_used: number;
    used_markers: string[];
    applied_spanish_recalibration_markers: string[];
  } | null;
  comprehensive: {
    BA: number;
    BA_E: number;
    s_BA: number;
    n_markers_used: number;
    used_markers: string[];
    applied_spanish_recalibration_markers: string[];
  } | null;
  gate_passed: boolean;
}

function calculateAge(dob: string, asOf: string): number {
  // dob and asOf are ISO date strings (YYYY-MM-DD)
  const d = new Date(dob);
  const a = new Date(asOf);
  let age = a.getFullYear() - d.getFullYear();
  const m = a.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && a.getDate() < d.getDate())) {
    age--;
  }
  return age;
}

function main(): void {
  const inputPath = path.resolve(__dirname, "backfill_kdm_inputs.json");
  const outputPath = path.resolve(__dirname, "backfill_kdm_outputs.json");

  const subjects = JSON.parse(
    fs.readFileSync(inputPath, "utf8"),
  ) as SubjectInput[];

  const results: SubjectOutput[] = [];

  for (const s of subjects) {
    // Use the collection_date as "today" for age — matches how
    // processLabResults computes it (chronological age at draw).
    const age = calculateAge(s.date_of_birth, s.collection_date);
    const context: KdmPatientContext = { supplements: s.supplements ?? null };
    const ref = computeReferenceBA(s.biomarkers, s.sex, age, context);
    const comp = computeComprehensiveBA(s.biomarkers, s.sex, age, context);

    results.push({
      lab_id: s.lab_id,
      user_id: s.user_id,
      collection_date: s.collection_date,
      legacy_ba: s.legacy_ba,
      age,
      sex: s.sex,
      n_biomarkers_input: s.biomarkers.length,
      reference: ref,
      comprehensive: comp,
      gate_passed: ref !== null,
    });
  }

  fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));

  console.log("Backfill compute complete.");
  console.log(`Subjects processed: ${results.length}`);
  console.log(
    `Gate passed:        ${results.filter((r) => r.gate_passed).length}`,
  );
  console.log(
    `Gate failed:        ${results.filter((r) => !r.gate_passed).length}`,
  );
  console.log("");
  console.log("Per-subject summary:");
  console.log(
    "lab_id (8)  | CA  | legacy | KDM Ref | Δ vs CA | KDM Comp | n_used | spanish_recal".padEnd(
      100,
    ),
  );
  console.log("-".repeat(100));
  for (const r of results) {
    const lab8 = r.lab_id.slice(0, 8);
    const legacy = r.legacy_ba.toFixed(1).padStart(6);
    const refBa = r.reference ? r.reference.BA.toFixed(2).padStart(7) : "  (null)";
    const deltaCa = r.reference
      ? (r.reference.BA - r.age).toFixed(2).padStart(7)
      : "  (n/a)";
    const compBa = r.comprehensive
      ? r.comprehensive.BA.toFixed(2).padStart(8)
      : "  (null)";
    const nUsed = r.reference
      ? String(r.reference.n_markers_used).padStart(6)
      : "  (n/a)";
    const recalN = r.reference
      ? String(r.reference.applied_spanish_recalibration_markers.length)
      : "n/a";
    console.log(
      `${lab8}    | ${String(r.age).padStart(3)} | ${legacy} | ${refBa} | ${deltaCa} | ${compBa} | ${nUsed} | ${recalN}`,
    );
  }
  console.log("");
  console.log(`Wrote ${outputPath}`);
}

main();
