#!/usr/bin/env python3
"""
Diagnose the Reference vs Comprehensive BA discrepancy.

Hypothesis: the same winsorization bias that over-weighted BUN in the base
panel is likely affecting many extended-panel markers. The Comprehensive
estimator weights ALL trained markers, so the cumulative effect on BA_E
(and on s_ca, which was computed from biased BA_E values) is what's
driving Comprehensive BA to drift away from Reference BA.

Reports:
  1. Per-marker (k/s)² and R² for ALL trained markers, ranked by weight
     share — identifies the worst signal/weight-ratio offenders.
  2. Marker-by-marker BA contribution for our private-beta user 7e397cf0
     in BOTH Reference and Comprehensive panels — shows which extended
     markers push BA up.
  3. Recommended Path B targets — markers that, if re-fit on
     unwinsorized NHANES data, would reduce noise amplification.
"""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2")
LIBRARY_PATH = ROOT / "output" / "marker_library_v2_2.json"

# Production user 7e397cf0 — 30yo male with creatine 10g/day
USER_BIOMARKERS = {
    "SHBG (Globulina Fijadora de Hormonas Sexuales)": 21.8,
    "Recuento de Glóbulos Rojos": 4.81,
    "Hemoglobina": 15.6,
    "CHCM (Concentración de Hemoglobina Corpuscular Media)": 32.9,
    "Recuento de Glóbulos Blancos": 5.3,
    "Neutrófilos": 43.8,
    "Eosinófilos": 3,
    "Basófilos": 0.9,
    "Recuento de Plaquetas": 270,
    "Glucosa (Ayunas)": 87,
    "BUN (Nitrógeno Ureico en Sangre)": 16.36,
    "Bilirrubina Total": 0.8,
    "Ácido Úrico": 5.8,
    "Calcio (Sérico)": 9.3,
    "Colesterol Total": 170,
    "Proteínas Totales": 7.3,
    "Albúmina": 4.75,
    "T4 Libre (Tiroxina)": 1,
    "Hierro (Sérico)": 172,
    "Linfocitos": 40.5,
    "Monocitos": 11.8,
    "Testosterona Libre": 11.65,
    "HbA1c (Hemoglobina Glicosilada)": 5.5,
    "Creatinina": 0.96,  # AFTER creatine offset (1.26 - 0.30)
    "Magnesio (Sérico)": 1.9,
    "HCM (Hemoglobina Corpuscular Media)": 32.5,
    "Homocisteína": 10.1,
    "Ferritina": 177,
    "Hematocrito": 47.5,
    "Colesterol LDL": 113,
    "Saturación de Hierro (TSAT)": 58.88,
    "Vitamina B12 (Cobalamina)": 600,
    "Colesterol HDL": 37,
    "Apolipoproteína B (ApoB)": 79,
    "PCR de Alta Sensibilidad (hs-PCR)": 1.1,
    "Triglicéridos": 102,
    "VCM (Volumen Corpuscular Medio)": 98.8,
    "Lipoproteína(a)": 13,
    "Testosterona Total": 473,
    "Vitamina D (25-OH)": 25,
    "Fructosamina": 70.4,  # derived from HbA1c via Cohen 2010
}
USER_SEX = "M"
USER_CA = 30

BASE_PANEL = {
    "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
    "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
    "Colesterol Total", "Colesterol HDL", "Triglicéridos",
    "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
    "TSH", "Fructosamina",
}


def main():
    library = json.loads(LIBRARY_PATH.read_text())
    markers = library["markers"]

    rows = []
    for name, m in markers.items():
        if m.get("kdm_contribution") != "trained":
            continue
        if m.get("sex_stratified"):
            block = m.get("kqs_M") if USER_SEX == "M" else m.get("kqs_F")
        else:
            block = m.get("kqs")
        if not block or block.get("k") is None or block.get("s", 0) <= 0:
            continue
        k, q, s, r2 = block["k"], block["q"], block["s"], block.get("r_squared", 0)
        log = m.get("log_transformed", False)

        # User contribution (if marker uploaded)
        user_v = USER_BIOMARKERS.get(name)
        contribution_num = None
        if user_v is not None and user_v > 0:
            v = math.log(user_v) if log else user_v
            if math.isfinite(v):
                contribution_num = (v - q) * (k / (s * s))

        rows.append({
            "marker": name,
            "k": k,
            "q": q,
            "s": s,
            "r2": r2,
            "weight": (k / s) ** 2,
            "log": log,
            "base_panel": name in BASE_PANEL,
            "user_value": user_v,
            "user_contrib_num": contribution_num,
        })

    df = pd.DataFrame(rows)
    df["weight_pct"] = df["weight"] / df["weight"].sum() * 100
    df = df.sort_values("weight", ascending=False).reset_index(drop=True)

    print("=" * 110)
    print(f"FULL-PANEL WEIGHT ANALYSIS — {len(df)} trained markers (sex={USER_SEX})")
    print("=" * 110)
    print("Markers ranked by joint-estimator weight (k/s)². Low R² + high weight = noise amplifier.\n")
    print(
        "rank  marker".ljust(48)
        + "weight%".rjust(10) + "R²".rjust(8) + "  base?".ljust(8)
        + "user value".rjust(14) + "  contrib (yrs)".rjust(15)
    )
    print("-" * 110)

    for i, r in df.head(30).iterrows():
        flag = "★" if r["base_panel"] else " "
        user = f"{r['user_value']:.2f}" if r["user_value"] is not None else "—"
        # Single-marker implied "years from intercept"
        contrib_yrs = ""
        if r["user_contrib_num"] is not None and r["weight"] > 0:
            # Implied years above q = (v-q)/k
            v = math.log(r["user_value"]) if r["log"] and r["user_value"] > 0 else r["user_value"]
            implied = (v - r["q"]) / r["k"]
            contrib_yrs = f"{implied:+.1f}"
        print(
            f"{i+1:3d}.  {r['marker'][:42]:42s} "
            f"{r['weight_pct']:6.2f}%   {r['r2']:.3f}  {flag} "
            f"{user:>10s}    {contrib_yrs:>10s}"
        )

    print()
    print("=" * 110)
    print("Reference vs Comprehensive BA — joint estimator for user 7e397cf0")
    print("=" * 110)

    # Build base panel inputs and compute Reference BA
    s_ca_ref_M = 24.678
    s_ca_comp_M = 14.003

    def compute_ba(filter_fn, s_ca):
        num = denom = 0.0
        used = 0
        for _, r in df.iterrows():
            if not filter_fn(r):
                continue
            v = r["user_contrib_num"]
            if v is None or (isinstance(v, float) and math.isnan(v)):
                continue
            num += v
            denom += r["weight"]
            used += 1
        if denom == 0:
            return None
        ba_e = num / denom
        s_ba2 = 1.0 / denom
        s_ca2 = s_ca ** 2
        ba = (ba_e / s_ba2 + USER_CA / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)
        return ba, ba_e, math.sqrt(s_ba2), used

    ref = compute_ba(lambda r: r["base_panel"], s_ca_ref_M)
    comp = compute_ba(lambda r: True, s_ca_comp_M)

    print(f"\nReference  (14-marker base panel, s_ca={s_ca_ref_M:.2f}, n_used={ref[3]}):")
    print(f"  BA_E = {ref[1]:.2f}, s_BA = {ref[2]:.2f} → BA = {ref[0]:.2f}")
    print(f"\nComprehensive (full trained panel, s_ca={s_ca_comp_M:.2f}, n_used={comp[3]}):")
    print(f"  BA_E = {comp[1]:.2f}, s_BA = {comp[2]:.2f} → BA = {comp[0]:.2f}")
    print(f"\nDiscrepancy: {comp[0] - ref[0]:+.2f} years")

    # Decompose: top contributors to Comprehensive BA pushing UP vs DOWN
    print("\n" + "=" * 110)
    print("Top Comprehensive contributors pushing BA UP (positive num contribution)")
    print("=" * 110)
    contribs = df.dropna(subset=["user_contrib_num"]).copy()
    contribs["weighted_yrs"] = contribs["user_contrib_num"] / contribs["weight"].sum() * (1 / (1 / contribs["weight"].sum() + 1 / s_ca_comp_M**2))
    # Simpler view: just rank by abs contribution to num
    up = contribs[contribs["user_contrib_num"] > 0].sort_values("user_contrib_num", ascending=False).head(10)
    print(f"\n{'marker':45s} {'value':>10s} {'k':>10s} {'q':>10s} {'(v-q)·k/s²':>14s} {'R²':>8s} {'base?':>6s}")
    print("-" * 110)
    for _, r in up.iterrows():
        flag = "★" if r["base_panel"] else " "
        print(f"{r['marker'][:43]:43s} {r['user_value']:>10.2f} {r['k']:>10.4f} {r['q']:>10.4f} {r['user_contrib_num']:>14.5f} {r['r2']:>8.3f} {flag:>5s}")

    print("\n" + "=" * 110)
    print("Top Comprehensive contributors pushing BA DOWN (negative num contribution)")
    print("=" * 110)
    down = contribs[contribs["user_contrib_num"] < 0].sort_values("user_contrib_num").head(10)
    print(f"\n{'marker':45s} {'value':>10s} {'k':>10s} {'q':>10s} {'(v-q)·k/s²':>14s} {'R²':>8s} {'base?':>6s}")
    print("-" * 110)
    for _, r in down.iterrows():
        flag = "★" if r["base_panel"] else " "
        print(f"{r['marker'][:43]:43s} {r['user_value']:>10.2f} {r['k']:>10.4f} {r['q']:>10.4f} {r['user_contrib_num']:>14.5f} {r['r2']:>8.3f} {flag:>5s}")


if __name__ == "__main__":
    main()
