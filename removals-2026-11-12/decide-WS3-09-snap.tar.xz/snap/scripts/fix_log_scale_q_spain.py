#!/usr/bin/env python3
"""
Fix the Spanish recalibration of log-transformed KDM markers (2026-09-25).

How the recalibration was meant to work (methodology page, section 04, and
the library fields):
  Each marker's baseline level q is moved so that a Spanish person with values
  typical of the Spanish population for their age sits at BA = CA. The shift
  is proportional: `slope` = mean_spain / mean_NHANES, the ratio of the
  Spanish to the NHANES population mean on the clinical (raw) scale, and
  `intercept` = mean_spain - slope * mean_NHANES, which is 0 up to rounding.
  The deployed value is q_spain = slope * q_NHANES + intercept, with k and s
  kept from NHANES.

The bug:
  For a log-transformed marker, q is the intercept of ln(value) on age.
  Scaling the level by `slope` adds ln(slope) to q; the deployed q_spain
  multiplied the log-scale q by the raw-scale ratio instead. Triglycerides:
  q 4.5414 -> 3.3802 (x0.744), i.e. a Spanish typical level 69% below the
  NHANES one instead of 26% below.

The fix, for log-transformed markers only:
  q_spain = q_NHANES + ln(slope)   (k and s unchanged, as before)
The previous value is kept in the block as `q_spain_log_fix.previous_q_spain`
and in docs/biomarker-evidence/longevity/q-spain-log-fix.json.

Proof the method is right: the script first checks, on every recalibrated
block, that slope * q_NHANES + intercept reproduces the deployed q_spain (for
the linear markers this is the value in use and stays unchanged), that
q_NHANES is the library's own q, and, where the means are stored, that
slope = mean_spain / mean_NHANES and intercept = mean_spain - slope *
mean_NHANES. Any failed check aborts without writing.

Not in scope: scripts/fix_spanish_recalibration_bug.py (a different bug: it
copied per-sex q_spain blocks that build_library.py had dropped).

Usage:
  python3 scripts/fix_log_scale_q_spain.py           # patch the library, write the audit file
  python3 scripts/fix_log_scale_q_spain.py --check   # verify only (exit 1 if not patched)
Idempotent: on a patched library it verifies and rewrites the same bytes.
"""
import argparse
import json
import math
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
LIBRARY = REPO / "src" / "lib" / "biomarkers" / "data" / "marker_library_v2_2.json"
AUDIT = REPO / "docs" / "biomarker-evidence" / "longevity" / "q-spain-log-fix.json"
FIX_DATE = "2026-09-25"
RULE = ("log-transformed marker: q_spain = q_NHANES + ln(slope), slope = mean_spain / mean_NHANES "
        "on the clinical scale. The previous value was slope x q_NHANES, a raw-scale ratio "
        "multiplying a log-scale q.")
REL = 1e-12  # float tolerance, relative


def close(a, b, rel=REL):
    return abs(a - b) <= rel * max(1.0, abs(a), abs(b))


def blocks(library):
    """(marker, sex, entry, block) for every recalibrated block that holds a q_spain."""
    for name, entry in library["markers"].items():
        sr = entry.get("spanish_recalibration") or {}
        if not str(sr.get("calibration_status") or "").startswith("recalibrated_"):
            continue
        if entry.get("sex_stratified"):
            for sex in ("M", "F"):
                block = (sr.get("per_sex") or {}).get(sex)
                if block and block.get("q_spain") is not None:
                    yield name, sex, entry, block
        elif sr.get("q_spain") is not None:
            yield name, "pooled", entry, sr


def library_q(entry, sex):
    kqs = entry.get("kqs_" + sex) if entry.get("sex_stratified") else entry.get("kqs")
    return (kqs or {}).get("q")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--check", action="store_true", help="verify only; do not write")
    args = ap.parse_args()

    raw = LIBRARY.read_text(encoding="utf-8")
    library = json.loads(raw)
    rows, errors, pending = [], [], []

    for name, sex, entry, b in blocks(library):
        is_log = bool(entry.get("log_transformed"))
        slope, intercept, q_nhanes = b["slope"], b["intercept"], b["q_NHANES"]
        fix = b.get("q_spain_log_fix")
        deployed = fix["previous_q_spain"] if fix else b["q_spain"]
        label = f"{name} [{sex}]"

        # The recalibration as it was built, on every block.
        if not close(library_q(entry, sex), q_nhanes):
            errors.append(f"{label}: q_NHANES {q_nhanes} is not the library q {library_q(entry, sex)}")
        reproduced = slope * q_nhanes + intercept
        if not close(reproduced, deployed, 1e-9):
            errors.append(f"{label}: slope x q_NHANES + intercept = {reproduced}, deployed q_spain {deployed}")
        ratio = None
        if "mean_spain" in b and "mean_NHANES" in b:
            ratio = b["mean_spain"] / b["mean_NHANES"]
            if not close(ratio, slope):
                errors.append(f"{label}: slope {slope} != mean_spain / mean_NHANES {ratio}")
            if not close(b["mean_spain"] - slope * b["mean_NHANES"], intercept, 1e-9):
                errors.append(f"{label}: intercept {intercept} != mean_spain - slope x mean_NHANES")

        row = {
            "marker": name,
            "sex": sex,
            "log_transformed": is_log,
            "slope": slope,
            "intercept": intercept,
            "mean_ratio_check": ratio,
            "q_NHANES": q_nhanes,
            "q_spain_deployed": deployed,
            "slope_x_q_NHANES_plus_intercept": reproduced,
            "reproduction_error": reproduced - deployed,
        }

        if is_log:
            # Proportional map only: the intercept is rounding noise (at most one ulp of the mean).
            scale = abs(b.get("mean_spain", 1.0))
            if abs(intercept) > 1e-9 * max(1.0, scale):
                errors.append(f"{label}: intercept {intercept} is not ~0; ln(slope) would not be the shift")
            corrected = q_nhanes + math.log(slope)
            row.update({
                "q_spain_corrected": corrected,
                "shift": corrected - deployed,
                "spanish_to_nhanes_level_deployed": math.exp(deployed - q_nhanes),
                "spanish_to_nhanes_level_corrected": math.exp(corrected - q_nhanes),
            })
            if fix:
                if not close(b["q_spain"], corrected):
                    errors.append(f"{label}: patched q_spain {b['q_spain']} != q_NHANES + ln(slope) {corrected}")
            else:
                pending.append(label)
                b["q_spain"] = corrected
                b["q_spain_log_fix"] = {"date": FIX_DATE, "previous_q_spain": deployed, "rule": RULE}
        rows.append(row)

    print(f"{'marker':44s} {'sex':6s} {'log':3s} {'slope':>8s} {'deployed':>10s} {'repro err':>9s} {'corrected':>10s}")
    for r in rows:
        corr = f"{r['q_spain_corrected']:10.6f}" if r["log_transformed"] else f"{'(same)':>10s}"
        print(f"{r['marker'][:44]:44s} {r['sex']:6s} {'Y' if r['log_transformed'] else 'N':3s} "
              f"{r['slope']:8.4f} {r['q_spain_deployed']:10.6f} {r['reproduction_error']:9.1e} {corr}")
    worst = max(abs(r["reproduction_error"]) for r in rows)
    print(f"\n{len(rows)} recalibrated blocks; slope x q_NHANES + intercept reproduces every deployed "
          f"q_spain within {worst:.1e}.")

    if errors:
        print("\nERRORS (nothing written):", *errors, sep="\n  ", file=sys.stderr)
        sys.exit(2)
    if args.check:
        if pending:
            print("\nNOT PATCHED:", *pending, sep="\n  ", file=sys.stderr)
            sys.exit(1)
        print("Library already patched: log-transformed q_spain = q_NHANES + ln(slope).")
        return

    LIBRARY.write_text(json.dumps(library, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    audit = {
        "_comment_": ("Spanish recalibration of log-transformed KDM markers, fixed "
                      f"{FIX_DATE} by scripts/fix_log_scale_q_spain.py. One row per recalibrated "
                      "block. Linear markers: the deployed q_spain, reproduced from the library "
                      "fields and unchanged. Log-transformed markers: q_spain_deployed is the "
                      "previous value, q_spain_corrected the new one. spanish_to_nhanes_level_* "
                      "is the Spanish typical level as a multiple of the NHANES one at any age "
                      "(exp of the q difference); corrected it equals slope."),
        "rule": RULE,
        "library": str(LIBRARY.relative_to(REPO)),
        "rows": rows,
    }
    AUDIT.write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"\nPatched {len(pending)} log-transformed blocks. Wrote {LIBRARY.relative_to(REPO)} "
          f"and {AUDIT.relative_to(REPO)}.")


if __name__ == "__main__":
    main()
