#!/usr/bin/env python3
"""
Honest mortality validation with proper train/test split.

The original training reported HR/SD on the SAME subjects whose markers
were used to fit (k, q, s). That's optimistic — fitted parameters can
match training-set noise, inflating in-sample HR/SD. The honest test:

   1. Random 70/30 split (seed 42)
   2. Refit ALL marker (k, q, s) on 70% TRAIN only
   3. Compute Reference + Comprehensive BA on 30% TEST using train-only params
   4. Run Cox PH on TEST set
   5. Report out-of-sample HR/SD

Compare against the in-sample numbers we've been reporting to see how much
of the validation was overfitting vs real signal.
"""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index

ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2")
LIBRARY_PATH = ROOT / "output" / "marker_library_v2_2.json"
CLEANED_PATH = ROOT / "output" / "nhanes_continuous_cleaned.parquet"

BASE_PANEL = {
    "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
    "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
    "Colesterol Total", "Colesterol HDL", "Triglicéridos",
    "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
    "TSH", "Fructosamina",
}
MANDATORY = ["Albúmina", "Creatinina"]
MIN_BASE = 8


def fit_ols(values, ages, log_transformed):
    if log_transformed:
        valid = (values > 0) & np.isfinite(ages) & np.isfinite(values)
        x = ages[valid]
        y = np.log(values[valid])
    else:
        valid = np.isfinite(values) & np.isfinite(ages)
        x = ages[valid]
        y = values[valid]
    if len(x) < 100:
        return None
    xm, ym = x.mean(), y.mean()
    sxy = ((x - xm) * (y - ym)).sum()
    sxx = ((x - xm) ** 2).sum()
    k = float(sxy / sxx)
    q = float(ym - k * xm)
    resid = y - (q + k * x)
    s = float(resid.std(ddof=2))
    return {"k": k, "q": q, "s": s}


def refit_all(df_long, library_markers, sex_filter=None):
    """Refit all trained markers on the given subset. Sex-stratified per training spec."""
    overrides = {}
    for name, m in library_markers.items():
        if m.get("kdm_contribution") != "trained":
            continue
        sub = df_long[df_long["marker_es"] == name]
        if sex_filter:
            sub = sub[sub["sex"] == sex_filter]
        if len(sub) < 100:
            continue
        log = m.get("log_transformed", False)
        sex_strat = m.get("sex_stratified", False)
        entry = {"log_transformed": log, "sex_stratified": sex_strat}
        if sex_strat:
            for sx in ("M", "F"):
                ss = sub[sub["sex"] == sx]
                if len(ss) < 100:
                    continue
                fit = fit_ols(ss["value"].to_numpy(), ss["age"].to_numpy(), log)
                if fit:
                    entry[f"kqs_{sx}"] = fit
        else:
            fit = fit_ols(sub["value"].to_numpy(), sub["age"].to_numpy(), log)
            if fit:
                entry["kqs"] = fit
        if any(k in entry for k in ("kqs", "kqs_M", "kqs_F")):
            overrides[name] = entry
    return overrides


def kd_ba(values, sex, ca, s_ca, overrides, restrict_to_base):
    base_present = [m for m in BASE_PANEL if m in values and pd.notna(values[m])]
    if len(base_present) < MIN_BASE:
        return None
    for m in MANDATORY:
        if m not in values or pd.isna(values[m]):
            return None
    num = denom = 0.0
    used = 0
    for marker, value in values.items():
        if pd.isna(value) or not math.isfinite(value):
            continue
        if restrict_to_base and marker not in BASE_PANEL:
            continue
        entry = overrides.get(marker)
        if not entry:
            continue
        if entry.get("sex_stratified"):
            block = entry.get(f"kqs_{sex}")
        else:
            block = entry.get("kqs")
        if not block:
            continue
        k, q, s = block["k"], block["q"], block["s"]
        if s <= 0:
            continue
        log = entry.get("log_transformed", False)
        v = math.log(value) if log and value > 0 else value
        if not math.isfinite(v):
            continue
        num += (v - q) * (k / (s * s))
        denom += (k / s) ** 2
        used += 1
    if denom == 0:
        return None
    ba_e = num / denom
    s_ba2 = 1.0 / denom
    s_ca2 = s_ca ** 2
    return (ba_e / s_ba2 + ca / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)


def cox(df, ba_col):
    sub = df.dropna(subset=[ba_col, "age", "follow_up_years", "died"]).copy()
    if len(sub) < 100 or sub["died"].sum() < 100:
        return None
    sub["BA_z"] = (sub[ba_col] - sub[ba_col].mean()) / sub[ba_col].std()
    sub["sex_M"] = (sub["sex"] == "M").astype(int)
    sub["T"] = sub["follow_up_years"]
    sub["E"] = sub["died"].astype(int)
    cph = CoxPHFitter()
    cph.fit(sub[["BA_z", "age", "sex_M", "T", "E"]], duration_col="T", event_col="E", show_progress=False)
    hr = float(np.exp(cph.params_["BA_z"]))
    ci = cph.confidence_intervals_.loc["BA_z"].tolist()
    c_stat = float(concordance_index(sub["T"], -cph.predict_partial_hazard(sub), sub["E"]))
    return {"n": int(len(sub)), "events": int(sub["E"].sum()), "hr": hr,
            "hr_lo": float(np.exp(ci[0])), "hr_hi": float(np.exp(ci[1])), "c_stat": c_stat}


def main():
    print("Loading library + NHANES...")
    library = json.loads(LIBRARY_PATH.read_text())
    library_markers = library["markers"]
    df_long = pd.read_parquet(CLEANED_PATH)
    df_long = df_long.dropna(subset=["value", "age", "sex"]).copy()
    df_long = df_long[df_long["value"] > 0]
    df_long = df_long[df_long["age"] >= 18]

    # Unique subjects with mortality info
    subjects = df_long[["SEQN", "follow_up_years", "died"]].drop_duplicates("SEQN").dropna()
    print(f"  Unique subjects with mortality: {len(subjects):,}")
    print(f"  Total deaths: {int(subjects['died'].sum()):,}")

    # 70/30 split, seed 42
    rng = np.random.default_rng(42)
    idx = rng.permutation(len(subjects))
    n_train = int(0.7 * len(subjects))
    train_seqn = set(subjects.iloc[idx[:n_train]]["SEQN"])
    test_seqn = set(subjects.iloc[idx[n_train:]]["SEQN"])
    print(f"  Train: {len(train_seqn):,}  Test: {len(test_seqn):,}")

    # Refit ALL markers on TRAIN only
    print("\nRefitting all markers on TRAIN subset (no winsorization, no test-set leakage)...")
    df_train = df_long[df_long["SEQN"].isin(train_seqn)]
    train_overrides = refit_all(df_train, library_markers)
    print(f"  refit {len(train_overrides)} markers")

    # Estimate s_ca from TRAIN using TRAIN-FITTED params (avoids leakage)
    print("\nEstimating s_ca on TRAIN subset...")
    df_train_wide = df_train.pivot_table(
        index=["SEQN", "cycle", "age", "sex", "follow_up_years", "died"],
        columns="marker_es", values="value", aggfunc="first",
    ).reset_index()

    def ba_e_only(values, sex, overrides, restrict_to_base):
        # Same as kd_ba but returns BA_E (no anchor)
        bp = [m for m in BASE_PANEL if m in values and pd.notna(values[m])]
        if len(bp) < MIN_BASE:
            return None
        for m in MANDATORY:
            if m not in values or pd.isna(values[m]):
                return None
        num = denom = 0.0
        for marker, value in values.items():
            if pd.isna(value) or not math.isfinite(value):
                continue
            if restrict_to_base and marker not in BASE_PANEL:
                continue
            entry = overrides.get(marker)
            if not entry:
                continue
            if entry.get("sex_stratified"):
                block = entry.get(f"kqs_{sex}")
            else:
                block = entry.get("kqs")
            if not block:
                continue
            k, q, s = block["k"], block["q"], block["s"]
            if s <= 0:
                continue
            log = entry.get("log_transformed", False)
            v = math.log(value) if log and value > 0 else value
            if not math.isfinite(v):
                continue
            num += (v - q) * (k / (s * s))
            denom += (k / s) ** 2
        if denom == 0:
            return None
        return num / denom

    s_ca_train_ref = {}
    s_ca_train_comp = {}
    for sex in ("M", "F"):
        sub = df_train_wide[df_train_wide["sex"] == sex]
        accs_ref = []
        accs_comp = []
        for _, row in sub.iterrows():
            values = {m: row.get(m) for m in library_markers if m in df_train_wide.columns}
            ba_e_r = ba_e_only(values, sex, train_overrides, restrict_to_base=True)
            ba_e_c = ba_e_only(values, sex, train_overrides, restrict_to_base=False)
            if ba_e_r is not None:
                accs_ref.append(ba_e_r - row["age"])
            if ba_e_c is not None:
                accs_comp.append(ba_e_c - row["age"])
        s_ca_train_ref[sex] = float(np.std(accs_ref, ddof=1)) if len(accs_ref) >= 100 else 10.0
        s_ca_train_comp[sex] = float(np.std(accs_comp, ddof=1)) if len(accs_comp) >= 100 else 10.0
    print(f"  s_ca (TRAIN-fitted) Reference:     M={s_ca_train_ref['M']:.2f}, F={s_ca_train_ref['F']:.2f}")
    print(f"  s_ca (TRAIN-fitted) Comprehensive: M={s_ca_train_comp['M']:.2f}, F={s_ca_train_comp['F']:.2f}")

    # Compute BA on TEST subset using TRAIN-fitted params + TRAIN-fitted s_ca
    print("\nComputing BA on TEST subset using TRAIN-fitted params...")
    df_test = df_long[df_long["SEQN"].isin(test_seqn)]
    df_test_wide = df_test.pivot_table(
        index=["SEQN", "cycle", "age", "sex", "follow_up_years", "died"],
        columns="marker_es", values="value", aggfunc="first",
    ).reset_index()

    refs, comps = [], []
    for _, row in df_test_wide.iterrows():
        sex = row["sex"]
        ca = row["age"]
        if pd.isna(sex) or pd.isna(ca):
            refs.append(np.nan)
            comps.append(np.nan)
            continue
        values = {m: row.get(m) for m in library_markers if m in df_test_wide.columns}
        sca_r = s_ca_train_ref.get(sex, 24.0)
        sca_c = s_ca_train_comp.get(sex, 14.0)
        refs.append(kd_ba(values, sex, ca, sca_r, train_overrides, True))
        comps.append(kd_ba(values, sex, ca, sca_c, train_overrides, False))
    df_test_wide["BA_ref"] = refs
    df_test_wide["BA_comp"] = comps

    print("\n" + "=" * 80)
    print("HONEST OUT-OF-SAMPLE VALIDATION (held-out 30% of NHANES, n≈5,500)")
    print("=" * 80)
    r_ref = cox(df_test_wide, "BA_ref")
    r_comp = cox(df_test_wide, "BA_comp")
    if r_ref:
        print(f"  Reference     : n={r_ref['n']:,}, events={r_ref['events']:,}")
        print(f"                  HR/SD = {r_ref['hr']:.4f} [{r_ref['hr_lo']:.3f}, {r_ref['hr_hi']:.3f}], C-stat = {r_ref['c_stat']:.4f}")
    if r_comp:
        print(f"  Comprehensive : n={r_comp['n']:,}, events={r_comp['events']:,}")
        print(f"                  HR/SD = {r_comp['hr']:.4f} [{r_comp['hr_lo']:.3f}, {r_comp['hr_hi']:.3f}], C-stat = {r_comp['c_stat']:.4f}")

    print("\n" + "=" * 80)
    print("COMPARISON: in-sample (what we reported) vs honest out-of-sample")
    print("=" * 80)
    print(f"{'tier':14s} {'in-sample HR':>14s} {'out-of-sample HR':>18s} {'in-sample C-stat':>18s} {'out-of-sample C-stat':>22s}")
    print("-" * 88)
    print(f"{'Reference':14s} {1.391:>14.3f} {r_ref['hr']:>18.3f} {0.770:>18.3f} {r_ref['c_stat']:>22.3f}")
    print(f"{'Comprehensive':14s} {1.654:>14.3f} {r_comp['hr']:>18.3f} {0.775:>18.3f} {r_comp['c_stat']:>22.3f}")

    # CA-only Cox baseline for context
    print("\n" + "=" * 80)
    print("BASELINE: chronological age alone (no BA at all)")
    print("=" * 80)
    sub = df_test_wide.dropna(subset=["age", "follow_up_years", "died"]).copy()
    sub["age_z"] = (sub["age"] - sub["age"].mean()) / sub["age"].std()
    sub["sex_M"] = (sub["sex"] == "M").astype(int)
    sub["T"] = sub["follow_up_years"]
    sub["E"] = sub["died"].astype(int)
    cph = CoxPHFitter()
    cph.fit(sub[["age_z", "sex_M", "T", "E"]], duration_col="T", event_col="E", show_progress=False)
    hr = float(np.exp(cph.params_["age_z"]))
    c = float(concordance_index(sub["T"], -cph.predict_partial_hazard(sub), sub["E"]))
    print(f"  CA alone: HR/SD = {hr:.3f}, C-stat = {c:.3f}")
    print(f"  KDM Reference adds: ΔHR = {r_ref['hr']-1:.3f} over CA={hr-1:.3f}; ΔC-stat = {r_ref['c_stat']-c:+.3f}")
    print(f"  KDM Comprehensive adds: ΔHR = {r_comp['hr']-1:.3f} over CA; ΔC-stat = {r_comp['c_stat']-c:+.3f}")


if __name__ == "__main__":
    main()
