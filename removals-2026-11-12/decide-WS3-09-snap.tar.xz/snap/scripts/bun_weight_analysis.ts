/**
 * Diagnostic: is BUN over-weighted in our KDM joint estimator?
 *
 * Compares BUN's weight share vs its actual age-correlation strength (R²) to
 * other base-panel markers. Markers with high (k/s)² but low R² are suspect —
 * they dominate the estimator without actually being good aging signals.
 */
import library from "../src/lib/biomarkers/data/marker_library_v2_2.json";

const BASE_PANEL = [
  "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
  "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
  "Colesterol Total", "Colesterol HDL", "Triglicéridos",
  "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
  "TSH", "Fructosamina",
];

interface MarkerRow {
  marker: string;
  k: number;
  q: number;
  s: number;
  r_squared: number;
  weight: number;
  weight_pct: number;
}

const markers = (library as { markers: Record<string, unknown> }).markers as Record<string, {
  sex_stratified?: boolean;
  kqs?: { k: number; q: number; s: number; r_squared: number };
  kqs_M?: { k: number; q: number; s: number; r_squared: number };
}>;

const rows: MarkerRow[] = [];
let totalWeight = 0;

for (const m of BASE_PANEL) {
  const entry = markers[m];
  if (!entry) continue;
  const block = entry.sex_stratified ? entry.kqs_M : entry.kqs;
  if (!block) continue;
  const { k, q, s, r_squared } = block;
  if (!Number.isFinite(k) || !Number.isFinite(s) || s <= 0) continue;
  const weight = (k / s) ** 2;
  rows.push({ marker: m, k, q, s, r_squared, weight, weight_pct: 0 });
  totalWeight += weight;
}

rows.forEach((r) => (r.weight_pct = (r.weight / totalWeight) * 100));
rows.sort((a, b) => b.weight - a.weight);

console.log("=".repeat(110));
console.log("KDM v2.2 base-panel weight diagnostic — male (or pooled) parameters");
console.log("=".repeat(110));
console.log("Joint-estimator weight per marker = (k/s)². High weight means this marker dominates the BA.");
console.log("R² = fraction of variance the marker's age regression actually explains. Low R² = noisy aging signal.");
console.log("");
console.log(
  "marker".padEnd(38) +
    "k".padStart(10) +
    "s".padStart(10) +
    "k/s".padStart(10) +
    "weight".padStart(12) +
    "weight%".padStart(10) +
    "R²".padStart(10) +
    "  signal/weight ratio",
);
console.log("-".repeat(110));

for (const r of rows) {
  const ratio = (r.r_squared / r.weight_pct).toFixed(3);
  const flag =
    r.weight_pct > 20 && r.r_squared < 0.15
      ? " ⚠ HIGH WEIGHT, LOW R²"
      : r.weight_pct > 20
        ? " (high weight)"
        : "";
  console.log(
    r.marker.padEnd(38) +
      r.k.toExponential(2).padStart(10) +
      r.s.toFixed(3).padStart(10) +
      (r.k / r.s).toFixed(4).padStart(10) +
      r.weight.toExponential(3).padStart(12) +
      r.weight_pct.toFixed(1).padStart(9) + "%" +
      r.r_squared.toFixed(3).padStart(10) +
      "  " + ratio + flag,
  );
}

console.log("");
console.log("Interpretation:");
console.log("  - Markers with weight% > 20% AND R² < 0.15 dominate the estimator while being noisy aging signals.");
console.log("  - This is exactly the issue Levine PhenoAge avoided by excluding BUN, Uric Acid, etc. from the panel.");
console.log("  - For comparison: in Levine PhenoAge, the heaviest-weighted markers (RDW, ALP, Albumin) have R² > 0.2.");
