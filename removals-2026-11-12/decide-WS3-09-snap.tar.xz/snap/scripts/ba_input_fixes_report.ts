/**
 * Internal report: the three BA input fixes of 2026-09-25, before and after,
 * on fixed synthetic panels. No patient data, no database, nothing stored.
 *
 *   Fix 1  measured fructosamine set aside (FructosaminePolicy "hba1c_only")
 *   Fix 2  Spanish q of log-transformed markers = q_NHANES + ln(slope)
 *   Fix 3  calcium_serum, iron_serum, iron_binding_capacity_tibc mapped
 *
 * Each configuration is rebuilt from the model's own parts: adapter,
 * Fructosamine policy, lifestyle adjustments, gate, resolveKdmParams,
 * klemeraDoubalBa. "Before" a fix means: fructosamine "as_measured"; the
 * previous log-scale q_spain (kept in the library as
 * q_spain_log_fix.previous_q_spain); the three DB keys left out (the old
 * adapter skipped them). Self-checks: all three fixes together equal
 * computeReferenceBA / computeComprehensiveBA exactly, and "before" reproduces
 * the deployed numbers of KDM-EXPLAIN-PANELS.md.
 *
 * Usage: npx tsx scripts/ba_input_fixes_report.ts [out.md]
 *   (default: docs/biomarker-evidence/longevity/BA-INPUT-FIXES.md)
 *
 * Historical. Since 30 October 2026 applyLifestyleAdjustments drops the
 * estimated GFR and cystatin C, so "before" no longer reproduces the
 * Comprehensive figures of KDM-EXPLAIN-PANELS.md and the self-check fails.
 * BA-INPUT-FIXES.md records the 25 September change and is not regenerated;
 * to rerun the script, check out commit 82fd5cc.
 */
import fs from "node:fs";
import path from "node:path";
import { kdmInputsFromBiomarkerValues } from "../src/lib/biomarkers/kdm-adapter";
import {
  applyLifestyleAdjustments,
  computeComprehensiveBA,
  computeReferenceBA,
  countBasePanelMarkers,
  deriveFructosamineIfMissing,
  FRUCTOSAMINE_KDM_KEY,
  klemeraDoubalBa,
  passesKdmGate,
  resolveKdmParams,
  resolveSCa,
  type FructosaminePolicy,
  type SCaTier,
  type Sex,
} from "../src/lib/biomarkers/biological-age-kdm";
import type { BiomarkerInput } from "../src/lib/biomarkers/longevity-score";
import library from "../src/lib/biomarkers/data/marker_library_v2_2.json";

const OUT = process.argv[2] ?? path.resolve(__dirname, "../docs/biomarker-evidence/longevity/BA-INPUT-FIXES.md");
const TIERS: SCaTier[] = ["reference", "comprehensive"];
const NEW_KEYS = ["calcium_serum", "iron_serum", "iron_binding_capacity_tibc"];

// ─── Library: Spanish recalibration blocks ───

interface RecalBlock {
  slope: number;
  intercept: number;
  q_NHANES: number;
  q_spain: number;
  q_spain_log_fix?: { previous_q_spain: number };
}
interface LibEntry {
  log_transformed?: boolean;
  sex_stratified?: boolean;
  name_en?: string;
  spanish_recalibration?: (Partial<RecalBlock> & { calibration_status?: string; per_sex?: Partial<Record<"M" | "F", RecalBlock | null>> | null }) | null;
}
const MARKERS = (library as unknown as { markers: Record<string, LibEntry> }).markers;

interface Block { marker: string; sex: "M" | "F" | "pooled"; log: boolean; b: RecalBlock }
const BLOCKS: Block[] = Object.entries(MARKERS).flatMap(([marker, e]) => {
  const sr = e.spanish_recalibration;
  if (!sr?.calibration_status?.startsWith("recalibrated_")) return [];
  const one = (sex: Block["sex"], b: RecalBlock | null | undefined): Block[] =>
    b && typeof b.q_spain === "number" ? [{ marker, sex, log: !!e.log_transformed, b }] : [];
  return e.sex_stratified ? [...one("M", sr.per_sex?.M), ...one("F", sr.per_sex?.F)] : one("pooled", sr as RecalBlock);
});

function previousQ(marker: string, sex: Sex): number | undefined {
  const s = sex === "male" ? "M" : "F";
  return BLOCKS.find((x) => x.marker === marker && (x.sex === "pooled" || x.sex === s))?.b.q_spain_log_fix?.previous_q_spain;
}

// ─── The model, rebuilt per configuration ───

interface Config {
  fructosamine: FructosaminePolicy;
  spanishLogFix: boolean;
  newKeys: boolean;
}
const BEFORE: Config = { fructosamine: "as_measured", spanishLogFix: false, newKeys: false };
const CONFIGS: [string, Config][] = [
  ["Before", BEFORE],
  ["Fix 1", { ...BEFORE, fructosamine: "hba1c_only" }],
  ["Fix 2", { ...BEFORE, spanishLogFix: true }],
  ["Fix 3", { ...BEFORE, newKeys: true }],
  ["All three", { fructosamine: "hba1c_only", spanishLogFix: true, newKeys: true }],
];
const ALL = CONFIGS[4][1];

function prepare(values: BiomarkerInput[], cfg: Config): Record<string, number> {
  const kept = cfg.newKeys ? values : values.filter((v) => !NEW_KEYS.includes(v.code));
  const adapted = kdmInputsFromBiomarkerValues(kept).inputs;
  return applyLifestyleAdjustments(deriveFructosamineIfMissing(adapted, cfg.fructosamine), null);
}

function ba(values: BiomarkerInput[], sex: Sex, age: number, tier: SCaTier, cfg: Config): number | null {
  const inputs = prepare(values, cfg);
  if (!passesKdmGate(inputs)) return null;
  const { params, applied } = resolveKdmParams(inputs, sex, tier === "reference");
  if (!cfg.spanishLogFix) {
    for (const m of applied) {
      const q = previousQ(m, sex);
      if (q !== undefined) params[m] = { ...params[m], q };
    }
  }
  return klemeraDoubalBa(inputs, params, age, true, resolveSCa(tier), sex)?.BA ?? null;
}

/** The model's own training-scale fructosamine for the age: exp(q + k·CA). */
function typicalFructosamine(sex: Sex, age: number): number {
  const p = resolveKdmParams({ [FRUCTOSAMINE_KDM_KEY]: 1 }, sex, true).params[FRUCTOSAMINE_KDM_KEY];
  return Math.exp(p.q + p.k * age);
}

// ─── Panels ───

interface Panel {
  label: string;
  sex: Sex;
  age: number;
  values: Record<string, number>;
}
const toInputs = (v: Record<string, number>): BiomarkerInput[] => Object.entries(v).map(([code, value]) => ({ code, value }));

// The six panels of scripts/kdm_explain_panels.ts (same values), plus serum
// calcium (mg/L), iron and TIBC (µg/dL) so that fix 3 has something to map.
const EXPLAIN_PANELS: (Panel & { explained: [number, number]; extra: Record<string, number> })[] = [
  {
    label: "Typical man, 45", sex: "male", age: 45, explained: [46.6, 45.0],
    extra: { calcium_serum: 95, iron_serum: 95, iron_binding_capacity_tibc: 320 },
    values: {
      albumin: 44, creatinine: 1.0, bun: 15, uric_acid: 6.0, alp: 72, ggt: 32, total_cholesterol: 205,
      hdl_cholesterol: 47, triglycerides: 140, hs_crp: 1.8, ferritin: 180, vitamin_d_25_oh: 24, tsh: 1.9, hba1c: 5.5,
      apolipoprotein_b_apob: 105, ldl_cholesterol: 130, glucose_fasting: 96, alt: 30, ast: 25, total_bilirubin: 0.7,
      hemoglobin: 15.2, hematocrit: 45, mcv: 90, rdw: 13.2, platelet_count: 240000, white_blood_cell_count: 6800,
      lymphocytes: 30, red_blood_cell_count: 5000000, egfr_creatinine_based: 95, vitamin_b12: 450, shbg: 35,
      testosterone_total: 4.8,
    },
  },
  {
    label: "Typical woman, 45", sex: "female", age: 45, explained: [45.4, 45.7],
    extra: { calcium_serum: 94, iron_serum: 80, iron_binding_capacity_tibc: 340 },
    values: {
      albumin: 43, creatinine: 0.75, bun: 13, uric_acid: 4.5, alp: 65, ggt: 18, total_cholesterol: 200,
      hdl_cholesterol: 60, triglycerides: 95, hs_crp: 1.5, ferritin: 60, vitamin_d_25_oh: 24, tsh: 2.1, hba1c: 5.4,
      apolipoprotein_b_apob: 90, ldl_cholesterol: 121, glucose_fasting: 90, alt: 18, ast: 20, total_bilirubin: 0.5,
      hemoglobin: 13.4, hematocrit: 40, mcv: 89, rdw: 13.4, platelet_count: 260000, white_blood_cell_count: 6500,
      lymphocytes: 31, red_blood_cell_count: 4500000, egfr_creatinine_based: 100, vitamin_b12: 480, shbg: 60,
      testosterone_total: 0.3,
    },
  },
  {
    label: "Woman, 70", sex: "female", age: 70, explained: [77.9, 75.4],
    extra: { calcium_serum: 95, iron_serum: 75, iron_binding_capacity_tibc: 300 },
    values: {
      albumin: 41, creatinine: 0.9, bun: 20, uric_acid: 5.4, alp: 85, ggt: 25, total_cholesterol: 215,
      hdl_cholesterol: 58, triglycerides: 130, hs_crp: 2.5, ferritin: 130, vitamin_d_25_oh: 26, tsh: 2.6, hba1c: 5.9,
      apolipoprotein_b_apob: 100, ldl_cholesterol: 131, glucose_fasting: 102, alt: 18, ast: 22, total_bilirubin: 0.6,
      hemoglobin: 13.2, hematocrit: 40, mcv: 92, rdw: 14.2, platelet_count: 230000, white_blood_cell_count: 6300,
      lymphocytes: 27, red_blood_cell_count: 4400000, egfr_creatinine_based: 69, vitamin_b12: 420, shbg: 75,
    },
  },
  {
    label: "Treated lipid patient (man, 58)", sex: "male", age: 58, explained: [53.4, 54.1],
    extra: { calcium_serum: 96, iron_serum: 90, iron_binding_capacity_tibc: 310 },
    values: {
      albumin: 44, creatinine: 1.0, bun: 16, uric_acid: 6.2, alp: 75, ggt: 35, total_cholesterol: 115,
      hdl_cholesterol: 45, triglycerides: 100, hs_crp: 1.2, ferritin: 200, vitamin_d_25_oh: 26, tsh: 2.0, hba1c: 5.7,
      apolipoprotein_b_apob: 55, ldl_cholesterol: 50, glucose_fasting: 100, alt: 35, ast: 28, total_bilirubin: 0.7,
      hemoglobin: 15.0, hematocrit: 44, mcv: 91, rdw: 13.5, platelet_count: 230000, white_blood_cell_count: 7000,
      lymphocytes: 28, red_blood_cell_count: 4900000, egfr_creatinine_based: 87, vitamin_b12: 400, shbg: 40,
      testosterone_total: 4.2,
    },
  },
  {
    label: "Athlete, high creatinine (man, 32)", sex: "male", age: 32, explained: [43.0, 44.6],
    extra: { calcium_serum: 97, iron_serum: 110, iron_binding_capacity_tibc: 300 },
    values: {
      albumin: 47, creatinine: 1.35, bun: 19, uric_acid: 5.5, alp: 60, ggt: 15, total_cholesterol: 175,
      hdl_cholesterol: 65, triglycerides: 60, hs_crp: 0.3, ferritin: 70, vitamin_d_25_oh: 38, tsh: 1.5, hba1c: 5.1,
      apolipoprotein_b_apob: 70, ldl_cholesterol: 98, glucose_fasting: 85, alt: 30, ast: 35, total_bilirubin: 1.0,
      hemoglobin: 15.8, hematocrit: 46, mcv: 91, rdw: 12.6, platelet_count: 220000, white_blood_cell_count: 5200,
      lymphocytes: 35, red_blood_cell_count: 5100000, egfr_creatinine_based: 72, vitamin_b12: 550, shbg: 38,
      testosterone_total: 6.0,
    },
  },
  {
    label: "Vitamin D 22, ferritin 30 (woman, 38)", sex: "female", age: 38, explained: [32.2, 33.9],
    extra: { calcium_serum: 93, iron_serum: 60, iron_binding_capacity_tibc: 380 },
    values: {
      albumin: 43, creatinine: 0.72, bun: 12, uric_acid: 4.0, alp: 58, ggt: 14, total_cholesterol: 185,
      hdl_cholesterol: 62, triglycerides: 80, hs_crp: 0.8, ferritin: 30, vitamin_d_25_oh: 22, tsh: 1.8, hba1c: 5.2,
      apolipoprotein_b_apob: 80, ldl_cholesterol: 107, glucose_fasting: 86, alt: 15, ast: 17, total_bilirubin: 0.5,
      hemoglobin: 12.6, hematocrit: 38, mcv: 85, rdw: 13.8, platelet_count: 280000, white_blood_cell_count: 6000,
      lymphocytes: 33, red_blood_cell_count: 4400000, egfr_creatinine_based: 110, vitamin_b12: 380, shbg: 65,
      testosterone_total: 0.25,
    },
  },
];

// The Base Panel as ordered (13 tests), with the typical man's or woman's values
// for the twelve other tests and a measured fructosamine.
const BASE_TESTS = ["albumin", "alp", "hs_crp", "creatinine", "bun", "uric_acid", "total_cholesterol", "hdl_cholesterol", "triglycerides", "apolipoprotein_b_apob", "alt", "ggt"];
const baseTests = (sex: Sex) => {
  const src = EXPLAIN_PANELS[sex === "male" ? 0 : 1].values;
  return Object.fromEntries(BASE_TESTS.map((c) => [c, src[c]]));
};
const BASE_PANELS: Panel[] = (["male", "female"] as Sex[]).flatMap((sex) =>
  [35, 50, 65].flatMap((age) =>
    [170, 190, 210, 230].map((f) => ({
      label: `${sex === "male" ? "Man" : "Woman"}, ${age}, fructosamine ${f}`,
      sex,
      age,
      values: { ...baseTests(sex), fructosamine: f },
    })),
  ),
);

// ─── Checks ───

const fmt = (x: number | null) => (x === null ? "no BA" : x.toFixed(1));
const signed = (x: number, digits?: number) =>
  `${x >= 0 ? "+" : "−"}${Math.abs(x).toFixed(digits ?? (Math.abs(x) < 0.05 ? 2 : 1))}`;
const num = (x: number, digits: number) => (x < 0 ? `−${Math.abs(x).toFixed(digits)}` : x.toFixed(digits));
const problems: string[] = [];

for (const p of [...EXPLAIN_PANELS.map((e) => ({ ...e, values: { ...e.values, ...e.extra } })), ...BASE_PANELS]) {
  for (const tier of TIERS) {
    const prod = (tier === "reference" ? computeReferenceBA : computeComprehensiveBA)(toInputs(p.values), p.sex, p.age);
    const mine = ba(toInputs(p.values), p.sex, p.age, tier, ALL);
    if ((prod?.BA ?? null) !== mine) problems.push(`${p.label} ${tier}: rebuilt ${mine} vs production ${prod?.BA}`);
  }
}
for (const p of EXPLAIN_PANELS) {
  TIERS.forEach((tier, i) => {
    const before = ba(toInputs({ ...p.values, ...p.extra }), p.sex, p.age, tier, BEFORE)!;
    if (Math.abs(before - p.explained[i]) > 0.051) problems.push(`${p.label} ${tier}: before ${before} vs KDM-EXPLAIN-PANELS ${p.explained[i]}`);
  });
}
const base190 = ba(toInputs({ ...baseTests("male"), fructosamine: 190 }), "male", 45, "reference", BEFORE)!;
const baseHbA1c = ba(toInputs({ ...baseTests("male"), hba1c: 5.5 }), "male", 45, "reference", BEFORE)!;
if (Math.abs(base190 - 81.7) > 0.051 || Math.abs(baseHbA1c - 51.1) > 0.051) problems.push(`man 45 base panel: ${base190} / ${baseHbA1c} vs 81.7 / 51.1`);
if (problems.length) throw new Error(`Self-check failed (the script is historical, see its header):\n${problems.join("\n")}`);

// ─── Section 1: fructosamine options ───

const cohen = (f: number) => 0.017 * f + 1.61; // HbA1c % from fructosamine (Cohen 2003, NBT scale)
const toTraining = (a1c: number) => 19.97 * a1c - 39.4; // the model's own derivation
const OPTION_A = (f: number) => toTraining(cohen(f));
// Enzymatic → NBT by position in each method's reference interval (docs/biomarker-evidence/research/fructosamine.json, S10).
const OPTION_A_ASSAY = (f: number) => toTraining(cohen(226.4 + ((f - 179) / 29.1) * 16.1));
const MEASURED = [122, 150, 170, 190, 210, 230, 236, 260];

// Fix 1 in isolation: everything else as deployed.
const FIX1 = CONFIGS[1][1];
type FructosamineOption = "as_measured" | "a" | "a_assay" | "b";

/** BA of the Base Panel's other tests plus a fructosamine handled by `option`. */
function withFructosamine(sex: Sex, age: number, tier: SCaTier, f: number, option: FructosamineOption): number {
  const value = option === "a" ? OPTION_A(f) : option === "a_assay" ? OPTION_A_ASSAY(f) : f;
  return ba(toInputs({ ...baseTests(sex), fructosamine: value }), sex, age, tier, option === "b" ? FIX1 : BEFORE)!;
}
/** The same panel with fructosamine at its training-typical value, fed as is. */
const typicalBA = (sex: Sex, age: number, tier: SCaTier) =>
  ba(toInputs({ ...baseTests(sex), fructosamine: typicalFructosamine(sex, age) }), sex, age, tier, BEFORE)!;
function range(option: FructosamineOption, tier: SCaTier): string {
  const d = (["male", "female"] as Sex[]).flatMap((sex) =>
    [35, 50, 65].flatMap((age) => MEASURED.map((f) => withFructosamine(sex, age, tier, f, option) - typicalBA(sex, age, tier))),
  );
  return `${signed(Math.min(...d))} to ${signed(Math.max(...d))}`;
}

const optionRows = MEASURED.map((f) => {
  const cells = (["male", "female"] as Sex[]).flatMap((sex) =>
    (["as_measured", "a", "b"] as FructosamineOption[]).map((o) => fmt(withFructosamine(sex, 50, "reference", f, o))),
  );
  return `| ${f} | ${OPTION_A(f).toFixed(0)} | ${cells.join(" | ")} |`;
});
const typicalCells = (["male", "female"] as Sex[]).map((sex) => fmt(typicalBA(sex, 50, "reference")));

// Gate: what fix 1 alone does to the count of base-panel markers.
const THIN_CODES = ["albumin", "creatinine", "bun", "total_cholesterol", "hdl_cholesterol", "triglycerides", "ggt", "apolipoprotein_b_apob", "alt"];
const thin = Object.fromEntries(THIN_CODES.map((c) => [c, baseTests("male")[c]]));
const gateCases: [string, Record<string, number>][] = [
  ["Base Panel (13 tests)", { ...baseTests("male"), fructosamine: 190 }],
  ["Base Panel without hs-CRP, uric acid and ALP", { ...thin, fructosamine: 190 }],
  ["Same, plus HbA1c 5.5%", { ...thin, fructosamine: 190, hba1c: 5.5 }],
];
const gateRows = gateCases.map(([label, v]) => {
  const n = (cfg: Config) => countBasePanelMarkers(prepare(toInputs(v), cfg));
  const at = (cfg: Config) => fmt(ba(toInputs(v), "male", 45, "reference", cfg));
  return `| ${label} | ${n(BEFORE)} | ${n(FIX1)} | ${at(BEFORE)} | ${at(FIX1)} |`;
});
// The message the production code logs for the panel that loses its BA.
const warnings: string[] = [];
const originalWarn = console.warn;
console.warn = (msg: string) => warnings.push(msg);
const thinBA = computeReferenceBA(toInputs({ ...thin, fructosamine: 190 }), "male", 45);
console.warn = originalWarn;
const gateWarning = warnings.find((w) => w.includes("reference BA not computed"));
if (thinBA !== null || !gateWarning) throw new Error("Self-check failed: the thin panel should lose its BA with a warning");

// ─── Section 2: Spanish recalibration ───

const linear = BLOCKS.filter((x) => !x.log);
const worstLinear = Math.max(...linear.map((x) => Math.abs(x.b.slope * x.b.q_NHANES + x.b.intercept - x.b.q_spain)));
const sexLabel = (s: Block["sex"]) => (s === "pooled" ? "both" : s === "M" ? "men" : "women");
const logRows = BLOCKS.filter((x) => x.log).map((x) => {
  const prev = x.b.q_spain_log_fix!.previous_q_spain;
  return `| ${MARKERS[x.marker].name_en} | ${sexLabel(x.sex)} | ${x.b.slope.toFixed(3)} | ${num(x.b.q_NHANES, 4)} | ${num(prev, 4)} | ${num(x.b.q_spain, 4)} | ${Math.exp(prev - x.b.q_NHANES).toFixed(2)} | ${Math.exp(x.b.q_spain - x.b.q_NHANES).toFixed(2)} |`;
});
const tg = BLOCKS.find((x) => x.marker === "Triglicéridos")!;
const tgK = resolveKdmParams({ Triglicéridos: 1 }, "male", true).params["Triglicéridos"].k;
const tgLevel = (q: number) => Math.exp(q + tgK * 50).toFixed(0);

// ─── Section 4: before / after tables ───

function tables(panels: Panel[]): Record<SCaTier, string[]> {
  const out = {} as Record<SCaTier, string[]>;
  for (const tier of TIERS) {
    out[tier] = [
      `| Panel | CA | ${CONFIGS.map(([l]) => l).join(" | ")} | All three − before |`,
      `|---|---|${CONFIGS.map(() => "---").join("|")}|---|`,
      ...panels.map((p) => {
        const r = CONFIGS.map(([, cfg]) => ba(toInputs(p.values), p.sex, p.age, tier, cfg));
        const delta = r[0] !== null && r[4] !== null ? signed(r[4] - r[0]) : "–";
        return `| ${p.label} | ${p.age} | ${r.map(fmt).join(" | ")} | ${delta} |`;
      }),
    ];
  }
  return out;
}
const six = tables(EXPLAIN_PANELS.map((p) => ({ ...p, values: { ...p.values, ...p.extra } })));
const base = tables(BASE_PANELS);
/** Reference BA change from fix 2 alone, for one of the six panels. */
const fix2Effect = (p: (typeof EXPLAIN_PANELS)[number]) =>
  ba(toInputs({ ...p.values, ...p.extra }), p.sex, p.age, "reference", CONFIGS[2][1])! -
  ba(toInputs({ ...p.values, ...p.extra }), p.sex, p.age, "reference", BEFORE)!;

// ─── SQL (read-only, counts only; not run here) ───

const SQL_1 = `-- 1. Stored lab results whose KDM biological age used a measured fructosamine.
--    Before fix 1 a measured value (> 0) was always used when present, and won
--    over HbA1c, so every stored KDM BA with such a row used it.
with fructosamine_labs as (
  select distinct lab_result_id
  from public.biomarker_values
  where biomarker_key = 'fructosamine' and value > 0
),
hba1c_labs as (
  select distinct lab_result_id
  from public.biomarker_values
  where biomarker_key = 'hba1c'
),
base_without_fructosamine as (
  -- KDM base-panel markers per lab, counted as the gate counts them, fructosamine left out.
  select lab_result_id,
         count(distinct case biomarker_key
           when 'albumin' then 'albumin'
           when 'creatinine' then 'creatinine'
           when 'bun' then 'bun' when 'urea' then 'bun' when 'blood_urea_nitrogen' then 'bun'
           when 'uric_acid' then 'uric_acid'
           when 'alp' then 'alp' when 'alkaline_phosphatase' then 'alp'
           when 'ggt' then 'ggt'
           when 'total_cholesterol' then 'total_cholesterol'
           when 'hdl_cholesterol' then 'hdl_cholesterol'
           when 'triglycerides' then 'triglycerides'
           when 'hs_crp' then 'hs_crp'
           when 'ferritin' then 'ferritin'
           when 'vitamin_d_25_oh' then 'vitamin_d'
           when 'tsh' then 'tsh'
         end) as n
  from public.biomarker_values
  group by lab_result_id
),
affected as (
  select lr.user_id,
         lr.biological_age_comprehensive is not null as has_comprehensive,
         h.lab_result_id is not null as has_hba1c,
         coalesce(b.n, 0) as n_base
  from public.lab_results lr
  join fructosamine_labs f on f.lab_result_id = lr.id
  left join hba1c_labs h on h.lab_result_id = lr.id
  left join base_without_fructosamine b on b.lab_result_id = lr.id
  where lr.biological_age is not null
    and lr.bio_age_method = 'KDM_v2.2_ReferenceBA'
)
select count(*)                                             as lab_results_ba_used_measured_fructosamine,
       count(*) filter (where has_hba1c)                    as of_which_hba1c_present,
       count(*) filter (where has_comprehensive)            as of_which_comprehensive_ba_stored,
       count(*) filter (where not has_hba1c and n_base < 8) as of_which_no_ba_after_fix_1,
       count(distinct user_id)                              as users
from affected;`;

const SQL_2 = `-- 2. Profiles whose cached dashboard BA (profiles.current_ba, the rolling
--    average of rolling-average-ba.ts) averaged in a measured fructosamine.
--    Approximates its window: labs ready at current_ba_computed_at; the last
--    6 months if 2 or more labs, else 12 months if 2 or more, else the latest lab.
with prof as (
  select id as user_id, current_ba_computed_at as t
  from public.profiles
  where current_ba is not null and current_ba_computed_at is not null
),
labs as (
  select p.user_id, lr.id as lab_id, lr.collection_date, lr.created_at, p.t
  from prof p
  join public.lab_results lr
    on lr.user_id = p.user_id and lr.status = 'ready'
   and lr.collection_date is not null and lr.created_at <= p.t
),
n as (
  select user_id,
         count(*) filter (where collection_date >= (t - interval '6 months')::date)  as n6,
         count(*) filter (where collection_date >= (t - interval '12 months')::date) as n12
  from labs
  group by user_id
),
latest as (
  select distinct on (user_id) user_id, lab_id
  from labs
  order by user_id, collection_date desc, created_at desc
),
window_labs as (
  select l.user_id, l.lab_id
  from labs l join n using (user_id)
  where (n.n6 >= 2 and l.collection_date >= (l.t - interval '6 months')::date)
     or (n.n6 < 2 and n.n12 >= 2 and l.collection_date >= (l.t - interval '12 months')::date)
  union
  select la.user_id, la.lab_id
  from latest la join n using (user_id)
  where n.n12 < 2
)
select count(distinct w.user_id) as profiles_cached_ba_used_measured_fructosamine
from window_labs w
join public.biomarker_values bv
  on bv.lab_result_id = w.lab_id and bv.biomarker_key = 'fructosamine' and bv.value > 0;`;

// ─── Report ───

const md = [
  "# Biological-age input fixes: before and after",
  "",
  "Internal. Generated by `scripts/ba_input_fixes_report.ts` on synthetic panels. No patient data, no database. Nothing is deployed and no stored number changes; stored results keep their BA until Gate 2 decides on reprocessing.",
  "",
  "Self-checks passed: every “All three” number equals `computeReferenceBA` / `computeComprehensiveBA` on this branch, and every “Before” number of the six panels equals `KDM-EXPLAIN-PANELS.md` (the deployed model).",
  "",
  "## Summary",
  "",
  "| Problem | Verdict | Key numbers | Fix |",
  "|---|---|---|---|",
  `| 1. Measured fructosamine read on the wrong scale | Confirmed | Man, 45, Base Panel: Reference BA ${base190.toFixed(1)} with fructosamine 190; ${baseHbA1c.toFixed(1)} with HbA1c 5.5% instead; ${fmt(ba(toInputs({ ...baseTests("male"), fructosamine: 190 }), "male", 45, "reference", CONFIGS[1][1]))} after fix 1 | Set the measured value aside; derive it from HbA1c when present (option b) |`,
  `| 2. Spanish q of log-scale markers multiplied by a ratio | Confirmed | Fix 2, Reference BA: typical man, 45 ${signed(fix2Effect(EXPLAIN_PANELS[0]), 2)} years; typical woman, 45 ${signed(fix2Effect(EXPLAIN_PANELS[1]), 2)} | q_spain = q_NHANES + ln(slope) for the 8 log-scale blocks |`,
  "| 3. Serum iron, TIBC and calcium never reached the model | Confirmed | 0 of 3 DB keys matched the adapter | Map `iron_serum`, `iron_binding_capacity_tibc`, `calcium_serum` |",
  "",
  "- Each fix is one commit and can be cherry-picked alone; each alone passes typecheck and all tests.",
  "- Two numbers matter. `lab_results.biological_age` stores the Reference BA. The dashboard shows `profiles.current_ba`, a rolling average that prefers the Comprehensive BA.",
  "",
  "## 1. Fructosamine",
  "",
  "The model's fructosamine was never measured. NHANES has none: training derived it from HbA1c (19.97 × HbA1c − 39.4, about 70 µmol/L at HbA1c 5.5%). The Base Panel measures it on an enzymatic assay, reference 122–236 µmol/L. A measured value was used as is, and it won over the derived one when both existed.",
  "",
  "Options compared:",
  "- **(a) HbA1c equivalent.** Measured value → HbA1c = 0.017 × F + 1.61 (Cohen 2003) → 19.97 × HbA1c − 39.4.",
  "- **(b) HbA1c only.** Measured value set aside. The value derived from HbA1c is used when HbA1c is present.",
  "",
  `Reference BA at 50 with the Base Panel's other twelve tests; fix 1 alone, everything else as deployed. With fructosamine at its training-typical value for 50 the BA is ${typicalCells[0]} (man) and ${typicalCells[1]} (woman).`,
  "",
  "| Measured (µmol/L) | (a) training-scale value | Man: as measured | Man: (a) | Man: (b) | Woman: as measured | Woman: (a) | Woman: (b) |",
  "|---|---|---|---|---|---|---|---|",
  ...optionRows,
  "",
  "BA minus the BA of the same panel with fructosamine at its training-typical value, over 122–260 µmol/L, ages 35, 50 and 65, men and women:",
  "",
  "| Option | Reference BA | Comprehensive BA | Gate | Input the validation used |",
  "|---|---|---|---|---|",
  `| As measured (deployed) | ${range("as_measured", "reference")} | ${range("as_measured", "comprehensive")} | Counts it | No |`,
  `| (a) HbA1c equivalent | ${range("a", "reference")} | ${range("a", "comprehensive")} | Counts it | No: mapped value |`,
  `| (a) with an assay correction first | ${range("a_assay", "reference")} | ${range("a_assay", "comprehensive")} | Counts it | No: two approximate mappings |`,
  `| **(b) HbA1c only** | ${range("b", "reference")} | ${range("b", "comprehensive")} | Counts it only with HbA1c | Yes |`,
  "",
  "Why (a) fails:",
  "- Cohen's regression was fitted in diabetic patients on the NBT assay (reference 205–285 µmol/L). The Base Panel's enzymatic assay reads lower, and the research file says the regression is not validated for it.",
  "- On the enzymatic scale, 122–236 µmol/L maps to HbA1c 3.7–5.6%. The model reads the low half of the normal range as years of youth.",
  "- An assay correction first (enzymatic → NBT by position in each reference interval, research file S10) narrows the error but still moves the BA by several years, on a mapping the research file grades as approximate.",
  "",
  "**Recommendation: (b).** It feeds the model only the input it was trained and validated on. The measured value no longer moves the BA at all. Its cost: without HbA1c, the Base Panel's BA has no glycaemic marker. If glycaemia should count, order HbA1c (the trained analyte) in the Base Panel.",
  "",
  "Gate (≥ 8 of the 14 base markers, albumin and creatinine). Reference BA, man 45, fix 1 alone:",
  "",
  "| Panel | Base markers before | After fix 1 | BA before | BA after fix 1 |",
  "|---|---|---|---|---|",
  ...gateRows,
  "",
  "- (a) keeps the fructosamine in the count, so no panel changes gate status.",
  "- (b): the Base Panel keeps 10 of 14 and passes. A panel loses its BA only if it needed the measured value to reach 8. Then the code logs why (the production message, captured here):",
  "",
  `  > ${gateWarning}`,
  "",
  "- Dashboard badge: the Base Panel's `bio_age_n_markers` goes from 11 to 10.",
  "- Disable fix 1: `{ fructosamine: \"as_measured\" }` or `DEFAULT_FRUCTOSAMINE_POLICY`. Tests rebuild the old pipeline and match it exactly.",
  "",
  "## 2. Spanish recalibration of log-scale markers",
  "",
  "How it was meant to work (methodology page § 04; library fields): move each marker's baseline q by the ratio of the Spanish to the NHANES population mean, keeping k and s. `slope` = mean_spain / mean_NHANES on the clinical scale; `intercept` = mean_spain − slope × mean_NHANES, 0 up to rounding. Deployed: q_spain = slope × q_NHANES + intercept.",
  "",
  "Proof the method is read right:",
  `- All ${linear.length} linear blocks: slope × q_NHANES + intercept reproduces the deployed q_spain within ${worstLinear.toExponential(1)}. These values are in use and do not change.`,
  "- Where the means are stored (per-sex blocks), slope = mean_spain / mean_NHANES exactly, and intercept = mean_spain − slope × mean_NHANES to the last bit.",
  "- The same formula reproduces the 8 log-scale blocks too: the bug is in applying it to a log.",
  "- The means are on the clinical scale: GGT men 34.6 → 40.5 U/L, testosterone men 410 → 325 ng/dL. The insulin intercept (8.9e-16) is one rounding step of a mean between 4 and 8 µU/mL, a clinical-scale mean. The page's plausibility bounds also read slope as a ratio of levels: [0.25, 4] for log-distributed markers “that show real population differences > 2×”, such as hs-CRP at 0.335.",
  "",
  "Formula applied, log-transformed markers only: **q_spain = q_NHANES + ln(slope)**. Moving a level by a ratio adds its logarithm on a log scale. k and s are unchanged, as before.",
  "",
  "| Marker | Sex | slope | q_NHANES | q_spain before | q_spain after | Spanish level ÷ NHANES, before | after (= slope) |",
  "|---|---|---|---|---|---|---|---|",
  ...logRows,
  "",
  `Example: triglycerides at 50. NHANES typical ${tgLevel(tg.b.q_NHANES)} mg/dL. The Spanish typical level was ${tgLevel(tg.b.q_spain_log_fix!.previous_q_spain)} mg/dL; now ${tgLevel(tg.b.q_spain)} mg/dL (× ${tg.b.slope.toFixed(3)}).`,
  "",
  "- ALT is tagged `recalibrated_tier_2` but has no Spanish means or q_spain: it stays a no-op.",
  "- Old values: `q_spain_log_fix.previous_q_spain` in each block, and `q-spain-log-fix.json` (all 23 blocks). Script: `scripts/fix_log_scale_q_spain.py`.",
  "- The KDM parity fixture was regenerated with the unchanged Python builder. Only the synthesized inputs of these markers change; every expected BA is identical.",
  "",
  "## 3. Adapter keys",
  "",
  "| DB key (seed name) | Stored unit | Old adapter key | KDM marker | Conversion |",
  "|---|---|---|---|---|",
  "| `calcium_serum` (Calcium (Serum)) | mg/L | `calcium` | Calcio (Sérico), mg/dL | × 0.1 |",
  "| `iron_serum` (Iron (Serum)) | µg/dL | `iron` | Hierro (Sérico), µg/dL | none |",
  "| `iron_binding_capacity_tibc` (Iron Binding Capacity (TIBC)) | µg/dL | `total_iron_binding_capacity` | Capacidad de Fijación del Hierro (TIBC), µg/dL | none |",
  "",
  "- The old keys are not DB keys: no seed row, name-matcher entry or Echevarne code (B0010, B0013, B1386) produces them. Only tests used them.",
  "- None is a base-panel marker: the Reference BA does not change. The Comprehensive BA gains three markers.",
  "- New guard tests: every snake_case adapter key is a DB key or a listed synonym, read in the seed's unit.",
  "",
  "## 4. Before and after on fixed panels",
  "",
  "“Before” is the deployed model. “Fix n” is that fix alone.",
  "",
  "### The six panels of the explanation report",
  "",
  "Same values as `KDM-EXPLAIN-PANELS.md`, plus serum calcium, iron and TIBC so that fix 3 has an effect. They carry HbA1c and no measured fructosamine, so fix 1 changes nothing here.",
  "",
  "| Panel | Calcium (mg/L) | Iron (µg/dL) | TIBC (µg/dL) |",
  "|---|---|---|---|",
  ...EXPLAIN_PANELS.map((p) => `| ${p.label} | ${p.extra.calcium_serum} | ${p.extra.iron_serum} | ${p.extra.iron_binding_capacity_tibc} |`),
  "",
  "Reference BA (the stored number):",
  "",
  ...six.reference,
  "",
  "Fix 2 moves q by a constant per marker and sex, so with the same 14 base markers it moves every man's Reference BA by the same amount, and every woman's.",
  "",
  "Comprehensive BA:",
  "",
  ...six.comprehensive,
  "",
  "### Base Panel with measured fructosamine",
  "",
  "The 13 Base Panel tests. The other twelve take the typical man's or woman's values above. No HbA1c, so after fix 1 the BA runs on 10 base markers. Fix 3 has nothing to map here.",
  "",
  "Reference BA:",
  "",
  ...base.reference,
  "",
  "Comprehensive BA (adds ApoB and ALT):",
  "",
  ...base.comprehensive,
  "",
  "## 5. Stored results affected by problem 1",
  "",
  "Not run. Two plain SELECTs: no writes, counts only, no identifiers or values. Run each on its own, with authorisation. In psql they can also run inside `begin transaction read only;` … `rollback;`.",
  "",
  "The first query answers the question:",
  "",
  "```sql",
  SQL_1,
  "```",
  "",
  "The second covers the cached dashboard BA:",
  "",
  "```sql",
  SQL_2,
  "```",
  "",
  "- `of_which_no_ba_after_fix_1`: results that would lose their BA if reprocessed with fix 1.",
  "- Caveat: a result reprocessed with an empty BA keeps its old `biological_age`; `recomputeLabMetrics` only writes a BA when there is one.",
  "",
  "## Open points",
  "",
  "- **Mortality validation.** It used derived fructosamine only, so fix 1 restores the validated input. Fix 2 changes each q by a constant: for people with the same markers it shifts every BA equally, which HR per SD and the C-statistic do not see; expect small changes where panels differ. Fix 3 adds markers the validation's Comprehensive panel already had. Confirm with `scripts/kdm_panel_revalidation.py` on this branch (it reads the library from the checkout).",
  "- **Methodology page.** § 04 states q_spain = (mean_spain / mean_NHANES) × q_NHANES without the log-scale case. Not changed here (published pages wait for Gate 2 and counsel).",
  "- **hs-CRP.** Its Spanish ratio (0.335) was already flagged by the external audit. Fix 2 now applies it in full: hs-CRP reads older than before for the same value.",
  "- **Other trained markers with DB keys but no adapter entry** (not in scope, not changed): sodium, potassium, chloride, non-HDL cholesterol, MCH, MCHC, MPV, white-cell differential (% and absolute), blood lead and mercury, urine microalbumin, TPO and thyroglobulin antibodies, methylmalonic acid, total and free PSA. The mortality validation's Comprehensive panel used every trained marker, so this is a gap to decide on, not a one-line fix.",
  "- **`KDM-EXPLAIN-PANELS.md`** describes the deployed model. Regenerate it (`npx tsx scripts/kdm_explain_panels.ts`) when these fixes ship; the script runs on this branch, but its fixed paragraphs on measured fructosamine and the log-scale Spanish q describe the bugs and need new text.",
  "",
];
fs.writeFileSync(OUT, md.join("\n"));
console.log(JSON.stringify({ out: path.relative(process.cwd(), OUT), panels: EXPLAIN_PANELS.length + BASE_PANELS.length, warnings: warnings.length }));
