/**
 * C. Coverage, states and scope (C1-C3) of docs/signoff/ACCEPTANCE-TEST.md.
 * C1 runs the app's own picker (src/lib/biomarkers/reference-row.ts) over every marker, sex, age 18 to
 * 120 and the physiological states the app records (src/lib/patient-context/options.ts).
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, CheckResult, Failure } from "../types";
import { byKey, rowKey, rowsFor, sortFailures, type Row } from "../lib/seed";
import { ageGroupContains, pickReferenceRows, referenceRowFor } from "../../../src/lib/biomarkers/reference-row";
import { CONDITION_KEYS, CONTRACEPTION_OPTIONS, HRT_OPTIONS, MENOPAUSE_STATUSES, TRT_OPTIONS } from "../../../src/lib/patient-context/options";

const result = (id: string, failures: Failure[], summary: string, metrics?: Record<string, number | string | boolean>): CheckResult => ({
  id,
  status: failures.length ? "fail" : "pass",
  summary,
  failures: sortFailures(failures),
  ...(metrics ? { metrics } : {}),
});
const blocked = (id: string, on: string): CheckResult => ({ id, status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on });

/** The physiological states the app records, read from the patient-context options. */
export function recordedStates(): string[] {
  const states = new Set<string>(["none"]);
  for (const c of CONDITION_KEYS) if (/pregnan|lactat/.test(c)) states.add(c);
  for (const m of MENOPAUSE_STATUSES) states.add(`menopause:${m}`);
  for (const h of HRT_OPTIONS) if (h !== "none") states.add(`hrt:${h}`);
  for (const c of CONTRACEPTION_OPTIONS) if (c !== "none") states.add(`contraception:${c}`);
  for (const t of TRT_OPTIONS) if (t !== "none") states.add(`trt:${t}`);
  return [...states].sort();
}

const isLabelled = (ageGroup: string) => !/\d/.test(ageGroup);

export interface CoverageReport {
  failures: Failure[];
  metrics: Record<string, number | string | boolean>;
}

export function checkCoverage(rows: Row[], ageMin = 18, ageMax = 120, states: string[] = ["none"]): CoverageReport {
  const failures: Failure[] = [];
  const groups = byKey(rows);
  const reached = new Set<number>();
  let cells = 0;
  let resolved = 0;
  let gaps = 0;
  let overlaps = 0;
  let bothVsSex = 0;
  let labelledByProxy = 0;
  const gapKeys = new Set<string>();
  for (const [key, list] of [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    const sexes = new Set(list.map((r) => r.sex));
    const inScope = sexes.has("both") ? ["female", "male"] : ["female", "male"].filter((s) => sexes.has(s));
    for (const sex of inScope) {
      let gapFrom: number | null = null;
      let gapTo: number | null = null;
      const overlapSeen = new Set<string>();
      for (let age = ageMin; age <= ageMax; age++) {
        cells++;
        const own = list.filter((r) => r.sex === sex || r.sex === "both");
        const matches = own.filter((r) => ageGroupContains(r.age_group_en, age));
        const { row, ageMatched } = referenceRowFor(own, sex, age);
        if (!row || !ageMatched) {
          gaps++;
          if (gapFrom == null) gapFrom = age;
          gapTo = age;
          continue;
        }
        resolved++;
        reached.add(row.index);
        if (matches.length > 1) {
          const sexRows = matches.filter((r) => r.sex === sex);
          const bothRows = matches.filter((r) => r.sex === "both");
          const numeric = matches.filter((r) => !isLabelled(r.age_group_en));
          const sig = matches.map((r) => rowKey(r)).sort().join(" + ");
          if (!overlapSeen.has(sig)) {
            overlapSeen.add(sig);
            overlaps++;
            if (sexRows.length && bothRows.length) {
              bothVsSex++;
              failures.push({ key: `${key}|${sex}|${age}|both_overlaps_sex`, detail: `a "both" row overlaps a ${sex} row at age ${age}: ${sig}` });
            } else if (numeric.length > 1) {
              failures.push({ key: `${key}|${sex}|${age}|numeric_overlap`, detail: `${numeric.length} numeric age bands contain age ${age}: ${numeric.map((r) => r.age_group_en).sort().join(", ")}` });
            } else if (isLabelled(row.age_group_en)) {
              labelledByProxy++;
              failures.push({ key: `${key}|${sex}|${age}|labelled_by_age_proxy`, detail: `labelled row "${row.age_group_en}" is picked by the age proxy at age ${age}, not through a recorded state (${matches.length} labelled rows match)` });
            }
          }
        } else if (isLabelled(row.age_group_en) && row.age_group_en.toLowerCase() !== "all adults") {
          labelledByProxy++;
          if (!overlapSeen.has(row.age_group_en)) {
            overlapSeen.add(row.age_group_en);
            failures.push({ key: `${key}|${sex}|${age}|labelled_by_age_proxy`, detail: `labelled row "${row.age_group_en}" is the only row at age ${age}; it is reached without a recorded state` });
          }
        }
      }
      if (gapFrom != null) {
        gapKeys.add(key);
        failures.push({ key: `${key}|${sex}|gap`, detail: `no row for ${sex} from age ${gapFrom} to ${gapTo}` });
      }
    }
  }
  const unreachable = rows.filter((r) => !reached.has(r.index));
  for (const r of unreachable) failures.push({ key: `${rowKey(r)}|unreachable`, detail: `row at file index ${r.index} is never picked for any sex and age ${ageMin}-${ageMax}` });
  // The picker takes no state, so every recorded state resolves to the stateless pick.
  const stateless = states.filter((s) => s !== "none");
  return {
    failures,
    metrics: {
      markers: groups.size,
      grid_cells: cells,
      resolved_cells: resolved,
      resolved_share: cells ? Math.round((resolved / cells) * 10000) / 10000 : 0,
      gap_cells: gaps,
      gap_markers: gapKeys.size,
      overlap_cells: overlaps,
      both_vs_sex_overlaps: bothVsSex,
      labelled_rows_by_age_proxy: labelledByProxy,
      unreachable_rows: unreachable.length,
      states_recorded: states.length,
      states_ignored_by_picker: stateless.length,
      states: states.join(","),
    },
  };
}

const C1: Check = {
  id: "C1",
  group: "coverage",
  title: "Coverage through the app's own picker",
  how: "script",
  run(ctx) {
    const data = rowsFor(ctx);
    if (!data) return blocked("C1", `${ctx.seedDir}/biomarker-ranges-en.json`);
    const ageMin = Number(ctx.thresholds.C1_grid_age_min ?? 18);
    const ageMax = Number(ctx.thresholds.C1_grid_age_max ?? 120);
    const report = checkCoverage(data.rows, ageMin, ageMax, recordedStates());
    // pickReferenceRows is what the routes call; confirm it agrees with the per-row walk above.
    let pickerAgrees = true;
    for (const sex of ["female", "male"]) {
      for (const age of [ageMin, 30, 50, 70, ageMax]) {
        const { picked } = pickReferenceRows(data.rows, sex, age);
        for (const [key, row] of picked) {
          const own = data.rows.filter((r) => r.biomarker_key === key && (r.sex === sex || r.sex === "both"));
          if (referenceRowFor(own, sex, age).row !== row) pickerAgrees = false;
        }
      }
    }
    const f = report.failures;
    return result("C1", f, `${f.length} coverage problems: ${report.metrics.gap_markers} markers with gaps, ${report.metrics.both_vs_sex_overlaps} both-vs-sex overlaps, ${report.metrics.labelled_rows_by_age_proxy} labelled picks by age proxy, ${report.metrics.unreachable_rows} unreachable rows`, {
      ...report.metrics,
      pickReferenceRows_agrees: pickerAgrees,
    });
  },
};

const C2: Check = {
  id: "C2",
  group: "coverage",
  title: "Physiological states",
  how: "script",
  run(ctx) {
    const rules = path.join(ctx.workDir, "governance", "state-rules.md");
    if (!fs.existsSync(rules)) return blocked("C2", path.relative(ctx.root, rules));
    const fixtures = path.join(ctx.workDir, "checks", "state-fixtures-result.json");
    if (!fs.existsSync(fixtures)) return blocked("C2", `${path.relative(ctx.root, fixtures)} (state fixture results from the harness)`);
    const doc = ctx.load<{ fixtures?: { id: string; passed: boolean; detail?: string }[] }>(fixtures);
    const list = doc?.fixtures ?? [];
    const failures = list.filter((f) => !f.passed).map((f) => ({ key: f.id, detail: f.detail ?? "fixture failed" }));
    if (!list.length) failures.push({ key: "_none", detail: "no fixtures recorded" });
    return result("C2", failures, `${list.length - failures.length} of ${list.length} state fixtures behave as specified`, { fixtures: list.length });
  },
};

const SCOPE_RULES: { id: string; re: RegExp; what: string }[] = [
  { id: "adults_18", re: /\b18\b.*(and over|or older|y más|o más|en adelante|\+)|adult/i, what: "adults 18 and over" },
  { id: "not_pregnant", re: /not pregnant|no embarazad|pregnan|embaraz/i, what: "not pregnant" },
  { id: "not_acutely_ill", re: /acutely ill|acute illness|enfermedad aguda|enferm[oa]s? agud/i, what: "not acutely ill" },
  { id: "treated_patients", re: /treated|treatment|on therapy|medicat|tratad|tratamiento|medicac/i, what: "notes for treated patients" },
  { id: "ages_18_19", re: /18\s*(?:to|-|–|a)\s*19/i, what: "an explicit policy for ages 18 to 19" },
  { id: "ages_85_plus", re: /85\s*(?:and over|\+|or older|y más|o más|en adelante)/i, what: "an explicit policy for ages 85 and over" },
];

export function checkFamilyPage(text: string): string[] {
  return SCOPE_RULES.filter((r) => !r.re.test(text)).map((r) => r.what);
}

const C3: Check = {
  id: "C3",
  group: "coverage",
  title: "Family page scope",
  how: "script",
  run(ctx) {
    const dirs = [path.join(ctx.workDir, "families"), path.join(ctx.root, "docs/signoff/pack/families")];
    const dir = dirs.find((d) => fs.existsSync(d) && fs.readdirSync(d).some((f) => f.endsWith(".md")));
    if (!dir) return blocked("C3", `${path.relative(ctx.root, dirs[0])}/*.md (family pages)`);
    const families = ctx.load<{ families: Record<string, unknown> }>(path.join(ctx.workDir, "families.json"));
    const expected = Object.keys(families?.families ?? {}).sort();
    const pages = fs.readdirSync(dir).filter((f) => f.endsWith(".md")).sort();
    const failures: Failure[] = [];
    for (const p of pages) {
      const missing = checkFamilyPage(fs.readFileSync(path.join(dir, p), "utf8"));
      if (missing.length) failures.push({ key: p, detail: `scope statement lacks: ${missing.join("; ")}` });
    }
    for (const f of expected) if (!pages.some((p) => p.startsWith(f))) failures.push({ key: `${f}.md`, detail: "family has no page" });
    return result("C3", failures, `${pages.length - failures.filter((f) => pages.includes(f.key)).length} of ${pages.length} family pages state their scope (${expected.length} families expected)`, { pages: pages.length, families_expected: expected.length });
  },
};

export const checks: Check[] = [C1, C2, C3];
