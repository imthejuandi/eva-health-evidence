/**
 * B. Biological age, version 3 (B1-B6) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * B1 artifact lock: file sha256 and model_sha256 of ml/biological-age/model-v3.json, the source hashes recorded in
 *    src/lib/biomarkers/data/ba_v3_model.json, and the runs in ml/biological-age/harness/final_test_log.jsonl
 *    (records of event "start" and "complete", one pair per sealed run; two runs expected).
 * B2 runs the refusal fixtures of docs/signoff/work/v3/refusals.json through the adapter (bioAgeV3Record), and probes
 *    today's gaps whatever the fixtures: albumin 0 and 4.3 g/L, creatinine 2.0 mg/dL, hs-CRP 60 and 30 mg/L, age 82,
 *    pregnancy, lactation, missing sex, unit mismatch, collection method, bounded result. Each probe but the
 *    collection-method one declares a venous draw and must give its own rule's outcome (GAP_PROBES, probeOutcome).
 * B3 parity of the TypeScript module with the Python reference on
 *    src/lib/biomarkers/__tests__/fixtures/ba-v3-python-parity.json.
 * B4 docs/signoff/work/v3/validation-reruns.json; B5 docs/signoff/work/v3/ages-80-84.json;
 * B6 docs/signoff/work/v3/display-copy.json.
 */
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import type { Check, CheckResult, Ctx, Failure } from "../types";
import { sortFailures } from "../lib/seed";
import { computeBiologicalAgeV3, BA_V3_AGE_RANGE, type BiomarkerV3Input } from "../../../src/lib/biomarkers/biological-age-v3";
import { bioAgeV3Record, type BioAgeV3Reason, type BioAgeV3Record, type BioAgeV3Sources, type BioAgeV3ValueRow } from "../../../src/lib/biomarkers/biological-age-v3-adapter";

type Metrics = Record<string, number | string | boolean>;
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");
const result = (id: string, failures: Failure[], summary: string, metrics?: Metrics): CheckResult => ({ id, status: failures.length ? "fail" : "pass", summary, failures: sortFailures(failures), ...(metrics ? { metrics } : {}) });
const blocked = (id: string, on: string, metrics?: Metrics): CheckResult => ({ id, status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on, ...(metrics ? { metrics } : {}) });

// ─── B1 artifact lock ───

export const MODEL_PATH = "ml/biological-age/model-v3.json";
export const TS_MODEL_PATH = "src/lib/biomarkers/data/ba_v3_model.json";
export const FINAL_LOG_PATH = "ml/biological-age/harness/final_test_log.jsonl";
export const LOCKED_FILE_SHA256 = "367072a01cf8edf730f117c0ec4145dd3b5c0f18b980c43aa901bdd95539caa6";
export const LOCKED_MODEL_SHA256 = "dc60ee29d88621c716086434c9894779417a3189fe7c2ee5178f010eec45bb10";

export function sha256OfFile(file: string): string {
  return createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

export interface ArtifactLock {
  file_sha256: string | null;
  model_sha256: string | null;
  ts_source_file_sha256: string | null;
  ts_source_model_sha256: string | null;
  log_records: number;
  log_events: Record<string, number>;
  runs_started: number[];
  runs_completed: number[];
}

export function readArtifactLock(root: string): ArtifactLock {
  const m = path.resolve(root, MODEL_PATH);
  const t = path.resolve(root, TS_MODEL_PATH);
  const l = path.resolve(root, FINAL_LOG_PATH);
  const model = fs.existsSync(m) ? (JSON.parse(fs.readFileSync(m, "utf8")) as { model_sha256?: string }) : null;
  const ts = fs.existsSync(t) ? (JSON.parse(fs.readFileSync(t, "utf8")) as { source_file_sha256?: string; source_model_sha256?: string }) : null;
  const records = fs.existsSync(l)
    ? fs
        .readFileSync(l, "utf8")
        .split(/\r?\n/)
        .filter((s) => s.trim())
        .map((s) => JSON.parse(s) as { event?: string; run?: number })
    : [];
  const events: Record<string, number> = {};
  for (const r of records) events[String(r.event ?? "none")] = (events[String(r.event ?? "none")] ?? 0) + 1;
  const runs = (ev: string) => [...new Set(records.filter((r) => r.event === ev).map((r) => Number(r.run)))].sort((a, b) => a - b);
  return {
    file_sha256: fs.existsSync(m) ? sha256OfFile(m) : null,
    model_sha256: model?.model_sha256 ?? null,
    ts_source_file_sha256: ts?.source_file_sha256 ?? null,
    ts_source_model_sha256: ts?.source_model_sha256 ?? null,
    log_records: records.length,
    log_events: events,
    runs_started: runs("start"),
    runs_completed: runs("complete"),
  };
}

export function lockFailures(a: ArtifactLock, expectedRuns = 2, fileSha = LOCKED_FILE_SHA256, modelSha = LOCKED_MODEL_SHA256): Failure[] {
  const f: Failure[] = [];
  if (a.file_sha256 !== fileSha) f.push({ key: "model-v3.json|file_sha256", detail: `${a.file_sha256 ?? "missing"} != ${fileSha}` });
  if (a.model_sha256 !== modelSha) f.push({ key: "model-v3.json|model_sha256", detail: `${a.model_sha256 ?? "missing"} != ${modelSha}` });
  if (a.ts_source_file_sha256 !== fileSha) f.push({ key: "ba_v3_model.json|source_file_sha256", detail: `${a.ts_source_file_sha256 ?? "missing"} != ${fileSha}` });
  if (a.ts_source_model_sha256 !== modelSha) f.push({ key: "ba_v3_model.json|source_model_sha256", detail: `${a.ts_source_model_sha256 ?? "missing"} != ${modelSha}` });
  if (a.runs_started.length !== expectedRuns) f.push({ key: "final_test_log|runs", detail: `${a.runs_started.length} sealed runs started (${a.runs_started.join(", ")}), expected ${expectedRuns}` });
  return f;
}

const B1: Check = {
  id: "B1",
  group: "bioage",
  title: "Artifact lock",
  how: "script",
  run(ctx) {
    const a = readArtifactLock(ctx.root);
    const fp = String(ctx.thresholds.B1_file_sha256_prefix ?? "367072a0");
    const mp = String(ctx.thresholds.B1_model_sha256_prefix ?? "dc60ee29");
    if (!LOCKED_FILE_SHA256.startsWith(fp) || !LOCKED_MODEL_SHA256.startsWith(mp)) throw new Error("thresholds' hash prefixes do not match the locked hashes");
    const failures = lockFailures(a, Number(ctx.thresholds.B1_final_test_runs ?? 2));
    return result("B1", failures, failures.length ? `${failures.length} artifact lock breaks` : `artifact unchanged; ${a.runs_started.length} sealed runs in the final test log`, {
      file_sha256: a.file_sha256 ?? "missing",
      model_sha256: a.model_sha256 ?? "missing",
      log_records: a.log_records,
      log_events: Object.entries(a.log_events)
        .sort()
        .map(([k, v]) => `${k}:${v}`)
        .join(","),
      runs_started: a.runs_started.length,
      runs_completed: a.runs_completed.length,
    });
  },
};

// ─── B2 refusal table ───

const NOW = new Date("2026-11-06T12:00:00Z");
const DRAW = "2026-11-01";

export interface ProbeInput {
  values?: Record<string, number | string>;
  units?: Record<string, string>;
  comparators?: Record<string, "<" | ">">;
  age?: number;
  sex?: string | null;
  conditionKeys?: string[];
  collection_method?: string;
  labSource?: string | null;
}

export const HEALTHY_BASE: Record<string, number> = { albumin: 44, alp: 70, hs_crp: 1, creatinine: 0.9, bun: 14, ggt: 20 };
const EVA_UNITS: Record<string, string> = { albumin: "g/L", alp: "U/L", hs_crp: "mg/L", creatinine: "mg/dL", bun: "mg/dL", ggt: "U/L", hba1c: "%" };

/** A date of birth giving `age` completed years at the draw date. */
export function dobForAge(age: number): string {
  return `${2026 - age}-01-15`;
}

export function probeSources(p: ProbeInput): BioAgeV3Sources {
  const values: BioAgeV3ValueRow[] = Object.entries({ ...HEALTHY_BASE, ...(p.values ?? {}) })
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => ({ biomarker_key: k, value: v, unit: p.units?.[k] ?? EVA_UNITS[k] ?? null, comparator: p.comparators?.[k] ?? null }));
  return {
    values,
    drawDate: DRAW,
    otherResults: [],
    dateOfBirth: dobForAge(p.age ?? 50),
    sex: p.sex === undefined ? "male" : p.sex,
    conditionKeys: p.conditionKeys ?? [],
    supplements: null,
    now: NOW,
    labSource: p.labSource === undefined ? "echevarne" : p.labSource,
    // Adapter 1.3.0 reads the collection method and refuses any draw it does not know to be venous (absent or null is
    // "unknown": ba_v3_rules.json collection_method, unknown_counts_as "not venous"). A probe passes "venous" unless
    // the collection method is the rule it probes.
    ...(p.collection_method !== undefined ? { collectionMethod: p.collection_method } : {}),
  };
}

export function probe(p: ProbeInput): BioAgeV3Record {
  return bioAgeV3Record(probeSources(p));
}

/** What a probe must give: no figure for its own reason, a provisional figure, or a figure that uses the bound. */
export type ProbeExpectation = "refuse" | "provisional" | "bound_used";

/**
 * The probes of today's gaps. Each declares a venous draw at EVA's laboratory unless the collection method is the
 * rule it probes, so that no other refusal holds, and must give its own outcome: no biological age with the reason
 * of its rule as the record's reason (the first rule that holds), a provisional figure for hs-CRP 10 to 50 mg/L, or a
 * figure that uses a bounded result's bound.
 */
export const GAP_PROBES: { id: string; rule: string; input: ProbeInput; expect: ProbeExpectation; reason?: BioAgeV3Reason }[] = [
  { id: "albumin_0", rule: "Tietz plausibility, albumin 10 to 60 g/L", input: { values: { albumin: 0 }, collection_method: "venous" }, expect: "refuse", reason: "implausible_value" },
  { id: "albumin_4_3", rule: "albumin below 30 g/L and below the plausibility floor (4.3 is a g/dL value in a g/L field)", input: { values: { albumin: 4.3 }, collection_method: "venous" }, expect: "refuse", reason: "implausible_value" },
  { id: "creatinine_2_0", rule: "creatinine above the reference interval", input: { values: { creatinine: 2.0 }, collection_method: "venous" }, expect: "refuse", reason: "kidney" },
  { id: "hs_crp_60", rule: "hs-CRP above 50 mg/L gives none", input: { values: { hs_crp: 60 }, collection_method: "venous" }, expect: "refuse", reason: "crp_above_limit" },
  { id: "hs_crp_30", rule: "hs-CRP 10 to 50 mg/L is provisional", input: { values: { hs_crp: 30 }, collection_method: "venous" }, expect: "provisional" },
  { id: "age_82", rule: "ages outside the signed range (20 to 79 unless B5 holds)", input: { age: 82, collection_method: "venous" }, expect: "refuse", reason: "age_outside_signed_range" },
  { id: "pregnancy", rule: "pregnancy", input: { conditionKeys: ["pregnancy_current"], collection_method: "venous" }, expect: "refuse", reason: "pregnancy" },
  { id: "lactation", rule: "lactation", input: { conditionKeys: ["lactating"], collection_method: "venous" }, expect: "refuse", reason: "lactation" },
  { id: "sex_missing", rule: "missing sex", input: { sex: null, collection_method: "venous" }, expect: "refuse", reason: "sex_unknown" },
  { id: "unit_mismatch", rule: "unit mismatch", input: { units: { albumin: "g/dL" }, values: { albumin: 4.4 }, collection_method: "venous" }, expect: "refuse", reason: "unit_mismatch" },
  { id: "capillary", rule: "collection method other than venous Echevarne", input: { collection_method: "capillary", labSource: "home_kit" }, expect: "refuse", reason: "collection_method" },
  { id: "bounded_crp", rule: "a bounded result resolves to the bound", input: { values: { hs_crp: 0.3 }, comparators: { hs_crp: "<" }, collection_method: "venous" }, expect: "bound_used" },
];

/**
 * Whether a probe's record is what the probe expects: for "refuse", no figure and the record's reason the probe's
 * reason (a refusal for any other reason does not count); for "provisional", a figure marked provisional; for
 * "bound_used", a figure with hs-CRP bounded at 0.3.
 */
export function probeOutcome(rec: BioAgeV3Record, expect: ProbeExpectation, reason?: BioAgeV3Reason): { ok: boolean; got: string } {
  const got = rec.ba == null ? `no result (${rec.reason})` : `ba ${rec.ba.toFixed(2)}${rec.provisional ? " provisional" : ""}`;
  if (expect === "refuse") return { ok: rec.ba == null && reason !== undefined && rec.reason === reason, got: reason !== undefined && rec.ba == null && rec.reason !== reason ? `${got}, not ${reason}` : got };
  if (expect === "provisional") return { ok: rec.ba != null && rec.provisional === true, got };
  return { ok: rec.ba != null && rec.bounded_markers.some((b) => b.key === "hs_crp" && b.value === 0.3), got };
}

interface RefusalFixture {
  id: string;
  rule: string;
  input: ProbeInput;
  before?: string;
  expect_reason: string;
}

const B2: Check = {
  id: "B2",
  group: "bioage",
  title: "Numeric refusal table",
  how: "script",
  run(ctx) {
    const failures: Failure[] = [];
    const b5 = ctx.load<{ passes?: boolean }>(path.join(ctx.workDir, "v3", "ages-80-84.json"));
    for (const p of GAP_PROBES) {
      if (p.id === "age_82" && b5?.passes === true) continue;
      const o = probeOutcome(probe(p.input), p.expect, p.reason);
      if (!o.ok) failures.push({ key: `probe|${p.id}`, detail: `${p.rule}: adapter gives ${o.got}` });
    }
    const file = path.join(ctx.workDir, "v3", "refusals.json");
    const doc = ctx.load<{ fixtures?: RefusalFixture[] } | RefusalFixture[]>(file);
    const fixtures = doc == null ? null : Array.isArray(doc) ? doc : doc.fixtures ?? [];
    for (const f of fixtures ?? []) {
      const rec = probe(f.input);
      if (rec.reason !== f.expect_reason) failures.push({ key: `fixture|${f.id}`, detail: `${f.rule}: reason ${rec.reason ?? "none (ba " + rec.ba + ")"}, expected ${f.expect_reason}` });
    }
    const metrics: Metrics = { probes: GAP_PROBES.length, probe_gaps: failures.filter((f) => f.key.startsWith("probe|")).length, fixtures_present: fixtures != null, fixtures: fixtures?.length ?? 0 };
    if (!failures.length && fixtures == null) return blocked("B2", rel(ctx, file), metrics);
    return result("B2", failures, `${metrics.probe_gaps} of ${GAP_PROBES.length} refusal probes do not give their own rule's outcome${fixtures == null ? `; fixtures ${rel(ctx, file)} absent` : `; ${fixtures.length} fixtures run`}`, metrics);
  },
};

// ─── B3 parity ───

export const PARITY_FIXTURE = "src/lib/biomarkers/__tests__/fixtures/ba-v3-python-parity.json";

export function parity(root: string): { rows: number; max_diff: number; crp_capped_rows: number; clamp_kinds: number; failures: Failure[] } | null {
  const file = path.resolve(root, PARITY_FIXTURE);
  if (!fs.existsSync(file)) return null;
  const doc = JSON.parse(fs.readFileSync(file, "utf8")) as {
    units: Record<string, string>;
    rows: { tier: string; sex: string; age: number; values: Record<string, number>; ba: number; lower: number; upper: number; clamps_applied: [string, string][]; crp_capped: boolean }[];
  };
  let max = 0;
  const failures: Failure[] = [];
  const clamps = new Set<string>();
  let capped = 0;
  doc.rows.forEach((r, i) => {
    const inputs: BiomarkerV3Input[] = Object.entries(r.values).map(([code, value]) => ({ code, value, unit: doc.units[code] }));
    const out = computeBiologicalAgeV3(inputs, r.sex, r.age);
    r.clamps_applied.forEach(([k, s]) => clamps.add(`${r.tier}|${k}|${s}`));
    if (r.crp_capped) capped++;
    if (out.ba == null) {
      failures.push({ key: `row${String(i).padStart(4, "0")}`, detail: `no result (${out.reason})` });
      return;
    }
    const d = Math.max(Math.abs(out.ba - r.ba), Math.abs(out.interval[0] - r.lower), Math.abs(out.interval[1] - r.upper));
    if (out.tier !== r.tier) failures.push({ key: `row${String(i).padStart(4, "0")}|tier`, detail: `tier ${out.tier}, reference ${r.tier}` });
    max = Math.max(max, d);
  });
  return { rows: doc.rows.length, max_diff: max, crp_capped_rows: capped, clamp_kinds: clamps.size, failures };
}

const B3: Check = {
  id: "B3",
  group: "bioage",
  title: "TypeScript matches Python",
  how: "script",
  run(ctx) {
    const p = parity(ctx.root);
    if (!p) return blocked("B3", PARITY_FIXTURE);
    const tol = Number(ctx.thresholds.B3_parity_tolerance_years ?? 1e-9);
    const minRows = Number(ctx.thresholds.B3_fixture_rows_min ?? 500);
    const failures = [...p.failures];
    if (p.max_diff > tol) failures.push({ key: "max_diff", detail: `max difference ${p.max_diff} years > ${tol}` });
    if (p.rows < minRows) failures.push({ key: "rows", detail: `${p.rows} rows < ${minRows}` });
    if (p.crp_capped_rows === 0) failures.push({ key: "crp_cap", detail: "no row exercises the CRP cap" });
    return result("B3", failures, `${p.rows} rows, max difference ${p.max_diff.toExponential(2)} years (tolerance ${tol}); ${p.clamp_kinds} clamp kinds, ${p.crp_capped_rows} CRP-capped rows`, {
      rows: p.rows,
      max_diff_years: p.max_diff,
      clamp_kinds: p.clamp_kinds,
      crp_capped_rows: p.crp_capped_rows,
    });
  },
};

// ─── B4 validation re-runs ───

const B4: Check = {
  id: "B4",
  group: "bioage",
  title: "Validation re-runs after changes",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "v3", "validation-reruns.json");
    const d = ctx.load<{ tests?: Record<string, { status?: string; data?: string }>; sealed_test_run?: boolean }>(file);
    if (!d) return blocked("B4", rel(ctx, file));
    const failures: Failure[] = [];
    for (const t of ["T6", "T7", "T9", "T11"]) {
      const s = d.tests?.[t]?.status;
      if (s !== "pass") failures.push({ key: t, detail: `status ${s ?? "absent"}` });
    }
    if (d.sealed_test_run !== false) failures.push({ key: "sealed", detail: "file does not state sealed_test_run: false" });
    const lock = readArtifactLock(ctx.root);
    if (lock.runs_started.length !== Number(ctx.thresholds.B1_final_test_runs ?? 2)) failures.push({ key: "sealed|log", detail: `final_test_log.jsonl holds ${lock.runs_started.length} runs` });
    return result("B4", failures, `${4 - failures.filter((f) => /^T\d+$/.test(f.key)).length} of 4 re-runs pass; sealed test ${failures.some((f) => f.key.startsWith("sealed")) ? "not confirmed untouched" : "untouched"}`);
  },
};

// ─── B5 ages 80 to 84 ───

const B5: Check = {
  id: "B5",
  group: "bioage",
  title: "Ages 80 to 84",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "v3", "ages-80-84.json");
    const d = ctx.load<{ band_mean_diff_years?: Record<string, number>; hr_per_sd_lower95?: number; deaths?: number; validation_only?: boolean; signed_range?: [number, number] }>(file);
    if (!d) return blocked("B5", rel(ctx, file), { module_age_range: `${BA_V3_AGE_RANGE.min}-${BA_V3_AGE_RANGE.max}` });
    const tol = Number(ctx.thresholds.B5_band_mean_tolerance_years ?? 1.5);
    const hrMin = Number(ctx.thresholds.B5_hr_lower_bound_min ?? 1);
    const deathsMin = Number(ctx.thresholds.B5_deaths_min ?? 100);
    const crit: Failure[] = [];
    for (const sex of ["male", "female"]) {
      const v = d.band_mean_diff_years?.[sex];
      if (!(typeof v === "number" && Math.abs(v) <= tol)) crit.push({ key: `band_mean|${sex}`, detail: `T3 band mean difference ${v}, tolerance ${tol}` });
    }
    if (!(typeof d.hr_per_sd_lower95 === "number" && d.hr_per_sd_lower95 > hrMin)) crit.push({ key: "hr", detail: `HR per SD lower bound ${d.hr_per_sd_lower95}` });
    if (!(typeof d.deaths === "number" && d.deaths >= deathsMin)) crit.push({ key: "deaths", detail: `${d.deaths} deaths < ${deathsMin}` });
    const failures: Failure[] = [];
    if (d.validation_only !== true) failures.push({ key: "validation_only", detail: "file does not state validation_only: true" });
    const fallback = (ctx.thresholds.B5_fallback_age_range as number[] | undefined) ?? [20, 79];
    if (crit.length) {
      // The criteria fail: the signed range must be the fallback, and the module must refuse 80 for its age. The probe
      // declares a venous draw, so that the collection-method rule does not refuse it whatever the age rule does.
      const applied = d.signed_range?.[0] === fallback[0] && d.signed_range?.[1] === fallback[1];
      const at80 = probe({ age: 80, collection_method: "venous" });
      const refuses80 = at80.ba == null && at80.reason === "age_outside_signed_range";
      if (!applied || !refuses80) failures.push(...crit, { key: "fallback", detail: `criteria fail and the signed range is not ${fallback.join(" to ")} in both the file and the module (module refuses 80 for its age: ${refuses80}${at80.ba == null ? `, reason ${at80.reason}` : ""})` });
    }
    return result("B5", failures, crit.length ? `80-84 criteria fail (${crit.length}); fallback ${failures.length ? "not applied" : "applied"}` : "80-84 criteria hold", { criteria_failed: crit.length });
  },
};

// ─── B6 display rules ───

const FORBIDDEN = /\b(validated|validado|validada|predicts?|predice|predicción|prediction|mortality|mortalidad|death|muerte)\b/i;

export function stringsOf(v: unknown, prefix = ""): { path: string; text: string }[] {
  if (typeof v === "string") return [{ path: prefix, text: v }];
  if (Array.isArray(v)) return v.flatMap((x, i) => stringsOf(x, `${prefix}[${i}]`));
  if (v && typeof v === "object") return Object.keys(v as object).sort().flatMap((k) => stringsOf((v as Record<string, unknown>)[k], prefix ? `${prefix}.${k}` : k));
  return [];
}

const B6: Check = {
  id: "B6",
  group: "bioage",
  title: "Display rules",
  how: "script+judge",
  run(ctx) {
    const file = path.join(ctx.workDir, "v3", "display-copy.json");
    const d = ctx.load<{ en?: unknown; es?: unknown; rules?: { range_always_shown?: boolean; direction_only_when_interval_excludes_age?: boolean; reliable_change_years?: number } }>(file);
    if (!d) return blocked("B6", rel(ctx, file));
    const failures: Failure[] = [];
    const rc = Number(ctx.thresholds.B6_reliable_change_years ?? 4.3);
    if (d.rules?.range_always_shown !== true) failures.push({ key: "rule|range", detail: "rules.range_always_shown is not true" });
    if (d.rules?.direction_only_when_interval_excludes_age !== true) failures.push({ key: "rule|direction", detail: "rules.direction_only_when_interval_excludes_age is not true" });
    if (!(typeof d.rules?.reliable_change_years === "number" && Math.abs(d.rules.reliable_change_years - rc) < 0.5)) failures.push({ key: "rule|reliable_change", detail: `rules.reliable_change_years ${d.rules?.reliable_change_years}, about ${rc} expected` });
    const en = stringsOf(d.en);
    const es = stringsOf(d.es);
    if (!en.length || !es.length) failures.push({ key: "copy|languages", detail: "English and Spanish copy both required" });
    const enPaths = new Set(en.map((s) => s.path));
    const esPaths = new Set(es.map((s) => s.path));
    for (const p of [...enPaths].filter((p) => !esPaths.has(p))) failures.push({ key: `copy|es_missing|${p}`, detail: "English string without a Spanish one" });
    for (const p of [...esPaths].filter((p) => !enPaths.has(p))) failures.push({ key: `copy|en_missing|${p}`, detail: "Spanish string without an English one" });
    for (const [lang, list] of [["en", en], ["es", es]] as const) for (const s of list) if (FORBIDDEN.test(s.text)) failures.push({ key: `copy|${lang}|${s.path}`, detail: `forbidden wording: "${s.text.match(FORBIDDEN)?.[0]}"` });
    return result("B6", failures, `${failures.length} display rule violations in ${en.length + es.length} strings (the judge part runs in G8)`, { strings: en.length + es.length });
  },
};

export const checks: Check[] = [B1, B2, B3, B4, B5, B6];
