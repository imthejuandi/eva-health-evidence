/**
 * S. Score (S1-S6) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * S1 static: no v1 code path (calculateLongevityScore, longevityScoreVersion, LONGEVITY_SCORE_VERSION) left in src/.
 * S2 the scored set (REVIEWED_ROW_KEY of src/lib/biomarkers/longevity-score.ts, as scored by calculateLongevityScoreV2
 *    on the seed rows) against docs/signoff/work/governance/marker-classes.json: only class a markers may score.
 * S3 the acceptance test's redundancy groups, on a fixture panel with every member present: at most one member of a
 *    group is scored (the engine's REDUNDANT_GROUPS, read from the source text, are reported in the metrics).
 * S4 docs/signoff/work/score/weights.json: {mapping: {...}, markers: {key: {weight, grade, inversion_reason?}}}.
 * S5 properties with calculateLongevityScoreV2 and reviewedPenalty on the seed rows: 100 when all optimal; zero
 *    penalty inside optimal and non-decreasing away from it on 200 points per row; no top grade with a critical value
 *    over 1,000 seeded random panels; no score in declared pregnancy; regression fixtures
 *    (docs/signoff/work/score/regression.json) when present.
 * S6 docs/signoff/work/score/population-validity.json.
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, CheckResult, Ctx, Failure } from "../types";
import { loadSeed, sortFailures, type Row } from "../lib/seed";
import { calculateLongevityScoreV2, REVIEWED_ROW_KEY, reviewedPenalty, type BiomarkerInput, type FullResult, type ReviewedRow } from "../../../src/lib/biomarkers/longevity-score";
import { classifyZone } from "../../../src/lib/biomarkers/zone-classifier";
import { pickReferenceRows } from "../../../src/lib/biomarkers/reference-row";

type Metrics = Record<string, number | string | boolean>;
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");
const result = (id: string, failures: Failure[], summary: string, metrics?: Metrics): CheckResult => ({ id, status: failures.length ? "fail" : "pass", summary, failures: sortFailures(failures), ...(metrics ? { metrics } : {}) });
const blocked = (id: string, on: string, metrics?: Metrics): CheckResult => ({ id, status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on, ...(metrics ? { metrics } : {}) });

// ─── Shared helpers (also used by consistency.ts and personas.ts) ───

export interface SeedReviewedRow extends ReviewedRow {
  critical_low: number | null;
  critical_high: number | null;
  unit: string;
}

export function reviewedRows(rows: Row[]): SeedReviewedRow[] {
  return rows.map((r) => ({
    biomarker_key: r.biomarker_key,
    sex: r.sex,
    age_group_en: r.age_group_en,
    optimal_low: r.optimal_low,
    optimal_high: r.optimal_high,
    normal_low: r.normal_low,
    normal_high: r.normal_high,
    critical_low: r.critical_low,
    critical_high: r.critical_high,
    unit: r.unit_en,
  }));
}

export function seedReviewedRows(ctx: Ctx): SeedReviewedRow[] | null {
  const seed = loadSeed(ctx.seedDir);
  return seed ? reviewedRows(seed.rows) : null;
}

/** Engine code of a seed key (inverse of REVIEWED_ROW_KEY). */
export const CODE_FOR_KEY: Readonly<Record<string, string>> = Object.fromEntries(Object.entries(REVIEWED_ROW_KEY).map(([c, k]) => [k, c]));

/** A value inside the row's optimal category (classifyZone === "optimal"). */
export function optimalValue(r: ReviewedRow): number | null {
  const lo = r.optimal_low ?? r.normal_low;
  const hi = r.optimal_high ?? r.normal_high;
  let v: number | null = null;
  if (lo != null && hi != null) v = (lo + hi) / 2;
  else if (hi != null) v = hi * 0.8;
  else if (lo != null) v = lo * 1.2 + (lo === 0 ? 1 : 0);
  if (v == null) return null;
  return classifyZone(v, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high) === "optimal" ? v : null;
}

/** A value past the row's critical limit, or past its reference limit when the row has no critical fields. */
export function criticalValue(r: SeedReviewedRow, side: "low" | "high"): number | null {
  if (side === "high") {
    const lim = r.critical_high ?? r.normal_high;
    return lim == null ? null : lim + Math.max(Math.abs(lim) * 0.5, 1e-3);
  }
  const lim = r.critical_low ?? r.normal_low;
  return lim == null || lim <= 0 ? null : lim * 0.5;
}

/** Whether a value is critical: past a critical field when the row has one, else the classifier's out-of-range codes. */
export function isCritical(r: SeedReviewedRow, v: number): boolean {
  if (r.critical_low != null || r.critical_high != null) return (r.critical_low != null && v < r.critical_low) || (r.critical_high != null && v > r.critical_high);
  const z = classifyZone(v, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high);
  return z === "critical_low" || z === "critical_high";
}

/** Rows picked for one person, keyed by seed key (the app's picker). */
export function pickedFor(rows: readonly SeedReviewedRow[], sex: "male" | "female", age: number): Map<string, SeedReviewedRow> {
  return pickReferenceRows(rows, sex, age).picked;
}

/** A panel with every scorable engine code at an optimal value for the person. */
export function optimalPanel(rows: readonly SeedReviewedRow[], sex: "male" | "female", age: number): BiomarkerInput[] {
  const picked = pickedFor(rows, sex, age);
  const out: BiomarkerInput[] = [];
  for (const [code, key] of Object.entries(REVIEWED_ROW_KEY).sort()) {
    const r = picked.get(key);
    if (!r) continue;
    const v = optimalValue(r);
    if (v != null) out.push({ code, value: v });
  }
  return out;
}

/** Deterministic PRNG (mulberry32). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Lines of non-test source under src/ that match a pattern, as "file:line". */
export function grepSrc(root: string, pattern: RegExp): { where: string; text: string }[] {
  const out: { where: string; text: string }[] = [];
  const walk = (dir: string) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (e.name === "node_modules" || e.name === "__tests__") continue;
        walk(p);
      } else if (/\.(ts|tsx)$/.test(e.name) && !/\.test\.tsx?$/.test(e.name)) {
        fs.readFileSync(p, "utf8")
          .split(/\r?\n/)
          .forEach((line, i) => {
            if (pattern.test(line)) out.push({ where: `${path.relative(root, p).split(path.sep).join("/")}:${i + 1}`, text: line.trim() });
          });
      }
    }
  };
  const src = path.resolve(root, "src");
  if (fs.existsSync(src)) walk(src);
  return out;
}

export const TOP_GRADE = "Elite";

// ─── S1 single code path ───

const S1: Check = {
  id: "S1",
  group: "score",
  title: "Score v2 is the only code path",
  how: "script",
  run(ctx) {
    // Code lines only: a comment naming v1 is stale text, not a code path.
    const hits = grepSrc(ctx.root, /\bLONGEVITY_SCORE_VERSION\b|\blongevityScoreVersion\b|\bcalculateLongevityScore\b(?!V2)/).filter((h) => !/^(\*|\/\/|\/\*)/.test(h.text));
    const failures = hits.map((h) => ({ key: h.where, detail: h.text.slice(0, 160) }));
    return result("S1", failures, `${failures.length} lines still reference score v1 or its switch`, { lines: failures.length });
  },
};

// ─── S2 only class a scored ───

/** Seed keys the v2 engine scores for a person (scored or suppressed by redundancy). */
export function scoredKeys(rows: readonly SeedReviewedRow[], sex: "male" | "female", age: number): { scored: string[]; suppressed: string[]; result: FullResult } {
  const res = calculateLongevityScoreV2(optimalPanel(rows, sex, age), sex, age, rows);
  return {
    scored: res.markerScores.map((m) => REVIEWED_ROW_KEY[m.code]).sort(),
    suppressed: res.suppressedMarkers.map((m) => REVIEWED_ROW_KEY[m.code]).sort(),
    result: res,
  };
}

const S2: Check = {
  id: "S2",
  group: "score",
  title: "Only class a markers scored",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "governance", "marker-classes.json");
    const doc = ctx.load<{ markers?: Record<string, { draft_class?: string; class?: string; may_be_scored?: boolean }> }>(file);
    if (!doc?.markers) return blocked("S2", rel(ctx, file));
    const rows = seedReviewedRows(ctx);
    if (!rows) return blocked("S2", `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json`);
    const scored = new Set<string>();
    for (const sex of ["male", "female"] as const) for (const age of [30, 50, 70]) scoredKeys(rows, sex, age).scored.forEach((k) => scored.add(k));
    const failures: Failure[] = [];
    for (const k of [...scored].sort()) {
      const m = doc.markers[k];
      const cls = m?.class ?? m?.draft_class;
      if (!m) failures.push({ key: k, detail: "scored but has no entry in marker-classes.json" });
      else if (cls !== "a") failures.push({ key: k, detail: `scored but class ${cls}` });
      else if (m.may_be_scored === false) failures.push({ key: `${k}|may_be_scored`, detail: "class a but may_be_scored is false (non-priority member, method or grade)" });
    }
    const nonA = failures.filter((f) => !f.key.includes("|")).length;
    return result("S2", failures, `${nonA} non-class-a markers scored of ${scored.size} scored; ${failures.length - nonA} class-a markers scored although may_be_scored is false`, { scored: scored.size, catalogue_engine_codes: Object.keys(REVIEWED_ROW_KEY).length });
  },
};

// ─── S3 redundancy groups ───

export const ACCEPTANCE_GROUPS: Record<string, string[]> = {
  atherogenic_lipids: ["total_cholesterol", "non_hdl_cholesterol", "ldl_cholesterol", "apolipoprotein_b_apob"],
  glycaemia: ["glucose_fasting", "hba1c", "fructosamine"],
  kidney_filtration: ["creatinine", "egfr_creatinine_based", "cystatin_c"],
  red_cell_mass: ["hemoglobin", "hematocrit", "red_blood_cell_count"],
  iron: ["ferritin", "iron_serum", "iron_saturation_tsat"],
  liver_enzymes: ["ast", "alt", "ggt"],
  white_cells: ["white_blood_cell_count", "neutrophils_absolute", "nlr"],
};

export function engineRedundantGroups(root: string): string[][] {
  const file = path.resolve(root, "src/lib/biomarkers/longevity-score.ts");
  const src = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
  const block = src.match(/const REDUNDANT_GROUPS\s*=\s*\[([\s\S]*?)\];/);
  if (!block) return [];
  return [...block[1].matchAll(/priorityOrder:\s*\[([^\]]*)\]/g)].map((m) => [...m[1].matchAll(/"([A-Z0-9_]+)"/g)].map((x) => x[1]));
}

export function doubleCounted(scored: string[]): { group: string; members: string[] }[] {
  const s = new Set(scored);
  return Object.entries(ACCEPTANCE_GROUPS)
    .map(([group, keys]) => ({ group, members: keys.filter((k) => s.has(k)) }))
    .filter((g) => g.members.length > 1);
}

const S3: Check = {
  id: "S3",
  group: "score",
  title: "Redundancy groups",
  how: "script",
  run(ctx) {
    const rows = seedReviewedRows(ctx);
    if (!rows) return blocked("S3", `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json`);
    const failures: Failure[] = [];
    for (const sex of ["male", "female"] as const) {
      const { scored } = scoredKeys(rows, sex, 50);
      for (const g of doubleCounted(scored)) failures.push({ key: `${g.group}|${sex}`, detail: `${g.members.length} members scored together: ${g.members.join(", ")}` });
    }
    const engine = engineRedundantGroups(ctx.root);
    return result("S3", failures, `${failures.length} double-counted groups on the fixture panels (engine has ${engine.length} redundancy groups)`, {
      acceptance_groups: Object.keys(ACCEPTANCE_GROUPS).length,
      engine_groups: engine.map((g) => g.join(">")).join("; "),
    });
  },
};

// ─── S4 weights ───

const S4: Check = {
  id: "S4",
  group: "score",
  title: "Weights follow evidence grade",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "score", "weights.json");
    const doc = ctx.load<{ mapping?: unknown; markers?: Record<string, { weight?: number; grade?: string; inversion_reason?: string | null }> }>(file);
    if (!doc) return blocked("S4", rel(ctx, file));
    const failures: Failure[] = [];
    if (!doc.mapping) failures.push({ key: "mapping", detail: "no written evidence-grade to weight mapping" });
    const m = Object.entries(doc.markers ?? {}).sort(([a], [b]) => a.localeCompare(b));
    for (const [k, e] of m) if (typeof e.weight !== "number" || !/^[ABCD]$/.test(String(e.grade))) failures.push({ key: `${k}|entry`, detail: "weight or grade missing" });
    for (const [k, e] of m) {
      if (e.grade !== "C" && e.grade !== "D") continue;
      if (e.inversion_reason && e.inversion_reason.trim()) continue;
      const below = m.filter(([, o]) => (o.grade === "A" || o.grade === "B") && typeof o.weight === "number" && typeof e.weight === "number" && o.weight < e.weight).map(([ok]) => ok);
      if (below.length) failures.push({ key: `${k}|inversion`, detail: `grade ${e.grade} weight ${e.weight} above grade A/B markers ${below.slice(0, 5).join(", ")}${below.length > 5 ? ", ..." : ""} with no recorded reason` });
    }
    return result("S4", failures, `${failures.filter((f) => f.key.endsWith("|inversion")).length} unexplained inversions over ${m.length} weighted markers`, { markers: m.length });
  },
};

// ─── S5 properties ───

export interface MonotoneViolation {
  key: string;
  detail: string;
}

/** Zero inside optimal and non-decreasing away from it, on `points` points across the row's span. */
export function penaltyShape(r: ReviewedRow, points = 200): MonotoneViolation[] {
  const out: MonotoneViolation[] = [];
  const bounds = [r.normal_low, r.normal_high, r.optimal_low, r.optimal_high].filter((x): x is number => x != null);
  if (!bounds.length) return out;
  let lo = Math.min(...bounds);
  let hi = Math.max(...bounds);
  const span = Math.max(hi - lo, Math.abs(hi) * 0.25, 1e-6);
  lo = Math.max(lo - span, lo >= 0 ? 0 : lo - span);
  hi = hi + span;
  const xs = Array.from({ length: points }, (_, i) => lo + ((hi - lo) * i) / (points - 1));
  const zone = (v: number) => classifyZone(v, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high);
  const opt = xs.filter((v) => zone(v) === "optimal");
  const key = `${r.biomarker_key}|${r.sex}|${r.age_group_en}`;
  for (const v of opt) {
    const p = reviewedPenalty(v, r);
    if (p !== 0) {
      out.push({ key: `${key}|inside`, detail: `penalty ${p} at ${v} inside optimal` });
      break;
    }
  }
  if (!opt.length) return out;
  const oMin = Math.min(...opt);
  const oMax = Math.max(...opt);
  // Below the band: walking down from the band, the penalty never decreases.
  let prev = 0;
  for (const v of xs.filter((x) => x < oMin).reverse()) {
    const p = reviewedPenalty(v, r);
    if (p < prev - 1e-12) {
      out.push({ key: `${key}|below`, detail: `penalty falls from ${prev} to ${p} at ${v} moving away from optimal` });
      break;
    }
    prev = p;
  }
  prev = 0;
  for (const v of xs.filter((x) => x > oMax)) {
    const p = reviewedPenalty(v, r);
    if (p < prev - 1e-12) {
      out.push({ key: `${key}|above`, detail: `penalty falls from ${prev} to ${p} at ${v} moving away from optimal` });
      break;
    }
    prev = p;
  }
  return out;
}

/** 1,000 seeded panels: everything optimal or in range, one marker critical; the grade must not be the top grade. */
export function topGradeWithCritical(rows: readonly SeedReviewedRow[], panels = 1000, seed = 20261106): { failures: Failure[]; tested: number } {
  const rnd = mulberry32(seed);
  const failures: Failure[] = [];
  let tested = 0;
  for (let i = 0; i < panels; i++) {
    const sex = rnd() < 0.5 ? "male" : "female";
    const age = 20 + Math.floor(rnd() * 65);
    const picked = pickedFor(rows, sex, age);
    const panel: { code: string; value: number; row: SeedReviewedRow }[] = [];
    for (const [code, key] of Object.entries(REVIEWED_ROW_KEY).sort()) {
      const r = picked.get(key);
      const v = r ? optimalValue(r) : null;
      if (r && v != null) panel.push({ code, value: v, row: r });
    }
    // Only markers the engine scores for this person (not suppressed by redundancy, not sex-restricted).
    const base = calculateLongevityScoreV2(panel.map(({ code, value }) => ({ code, value })), sex, age, rows);
    const scoredCodes = new Set(base.markerScores.map((m) => m.code));
    const candidates = panel.filter((p) => scoredCodes.has(p.code) && (criticalValue(p.row, "high") != null || criticalValue(p.row, "low") != null));
    if (!candidates.length) continue;
    const pick = candidates[Math.floor(rnd() * candidates.length)];
    const side = criticalValue(pick.row, "high") != null && (criticalValue(pick.row, "low") == null || rnd() < 0.5) ? "high" : "low";
    pick.value = criticalValue(pick.row, side) as number;
    if (!isCritical(pick.row, pick.value)) continue;
    const res = calculateLongevityScoreV2(panel.map(({ code, value }) => ({ code, value })), sex, age, rows);
    if (res.longevityScore < 0) continue;
    tested++;
    if (res.lsGrade === TOP_GRADE)
      failures.push({ key: `panel${String(i).padStart(4, "0")}`, detail: `${sex} ${age}: ${pick.row.biomarker_key} ${Number(pick.value.toPrecision(10))} critical, score ${res.longevityScore} grade ${res.lsGrade}` });
  }
  return { failures, tested };
}

const S5: Check = {
  id: "S5",
  group: "score",
  title: "Score properties",
  how: "script",
  run(ctx) {
    const rows = seedReviewedRows(ctx);
    if (!rows) return blocked("S5", `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json`);
    const failures: Failure[] = [];
    // 100 when every scored marker is optimal.
    for (const sex of ["male", "female"] as const)
      for (const age of [25, 45, 65, 80]) {
        const res = calculateLongevityScoreV2(optimalPanel(rows, sex, age), sex, age, rows);
        const want = Number(ctx.thresholds.S5_score_when_all_optimal ?? 100);
        if (res.longevityScore !== want) failures.push({ key: `all_optimal|${sex}|${age}`, detail: `score ${res.longevityScore}, expected ${want}` });
      }
    // Penalty shape on every scored row.
    const points = Number(ctx.thresholds.S5_points_per_marker ?? 200);
    const scoredKeySet = new Set(Object.values(REVIEWED_ROW_KEY));
    const seen = new Set<string>();
    let shapes = 0;
    for (const r of rows) {
      const k = `${r.biomarker_key}|${r.sex}|${r.age_group_en}`;
      if (!scoredKeySet.has(r.biomarker_key) || seen.has(k)) continue;
      seen.add(k);
      shapes++;
      for (const v of penaltyShape(r, points)) failures.push({ key: `penalty|${v.key}`, detail: v.detail });
    }
    // No top grade with a critical value.
    const panels = Number(ctx.thresholds.S5_random_panels ?? 1000);
    const top = topGradeWithCritical(rows, panels);
    failures.push(...top.failures.map((f) => ({ key: `top_grade|${f.key}`, detail: f.detail })));
    // No score in declared pregnancy: the score function must take the physiological state and refuse.
    const preg = grepSrc(ctx.root, /pregnan/i).filter((h) => /longevity-score\.ts|process-results\.ts/.test(h.where));
    if (!preg.length) failures.push({ key: "pregnancy", detail: "no pregnancy rule: calculateLongevityScoreV2 (src/lib/biomarkers/longevity-score.ts) takes no physiological state and process-results.ts never withholds the score in declared pregnancy" });
    // Regression fixtures.
    const regFile = path.join(ctx.workDir, "score", "regression.json");
    const reg = ctx.load<{ fixtures?: { id: string; sex: "male" | "female"; age: number; values: BiomarkerInput[]; expected_score: number; change_reason?: string | null }[] }>(regFile);
    let regN = 0;
    for (const f of reg?.fixtures ?? []) {
      regN++;
      const res = calculateLongevityScoreV2(f.values, f.sex, f.age, rows);
      if (res.longevityScore !== f.expected_score && !(f.change_reason && f.change_reason.trim()))
        failures.push({ key: `regression|${f.id}`, detail: `score ${res.longevityScore}, fixture expects ${f.expected_score}, no explained row change` });
    }
    const critSource = rows.some((r) => r.critical_low != null || r.critical_high != null) ? "critical fields" : "classifier out-of-range codes (no critical fields in the seed)";
    return result("S5", failures, `${failures.length} property violations: ${top.failures.length} of ${top.tested} critical panels reach ${TOP_GRADE}; ${shapes} penalty curves checked`, {
      penalty_curves: shapes,
      critical_panels_tested: top.tested,
      critical_panels_top_grade: top.failures.length,
      critical_source: critSource,
      regression_fixtures: regN,
      regression_file_present: reg != null,
    });
  },
};

// ─── S6 population validity ───

const S6: Check = {
  id: "S6",
  group: "score",
  title: "Population validity",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "score", "population-validity.json");
    const d = ctx.load<{ hr_per_sd_lower95?: number; grade_mean_v3_minus_age?: { grade: string; mean: number }[]; grade_gap_years?: number; monotone?: boolean; spearman_rho?: number; sealed_waves_used?: boolean; waves?: string[] }>(file);
    if (!d) return blocked("S6", rel(ctx, file));
    const failures: Failure[] = [];
    const hrMin = Number(ctx.thresholds.S6_hr_lower_bound_min ?? 1);
    const gapMin = Number(ctx.thresholds.S6_grade_gap_years_min ?? 2);
    const rhoMin = Number(ctx.thresholds.S6_rho_min ?? 0.2);
    if (d.sealed_waves_used !== false) failures.push({ key: "sealed", detail: "file does not state sealed_waves_used: false" });
    if (!(typeof d.hr_per_sd_lower95 === "number" && d.hr_per_sd_lower95 > hrMin)) failures.push({ key: "hr", detail: `HR per SD lower 95% bound ${d.hr_per_sd_lower95}, must exceed ${hrMin}` });
    const means = d.grade_mean_v3_minus_age ?? [];
    let monotone = d.monotone;
    let gap = d.grade_gap_years;
    if (means.length >= 2) {
      // Ordered from top grade to lowest; the mean of (v3 age - age) must not decrease.
      monotone = means.every((m, i) => i === 0 || m.mean >= means[i - 1].mean);
      gap = means[means.length - 1].mean - means[0].mean;
    }
    if (monotone !== true) failures.push({ key: "monotone", detail: "mean (v3 age - age) not monotone across grades" });
    if (!(typeof gap === "number" && gap >= gapMin)) failures.push({ key: "gap", detail: `lowest grade ${gap} years older than the top, need ${gapMin}` });
    if (!(typeof d.spearman_rho === "number" && d.spearman_rho >= rhoMin)) failures.push({ key: "rho", detail: `Spearman rho ${d.spearman_rho}, need ${rhoMin}` });
    return result("S6", failures, `${failures.length} population validity failures (HR, grade monotonicity and gap, Spearman rho, sealed waves)`, { hr_lower: d.hr_per_sd_lower95 ?? "absent", rho: d.spearman_rho ?? "absent" });
  },
};

export const checks: Check[] = [S1, S2, S3, S4, S5, S6];
