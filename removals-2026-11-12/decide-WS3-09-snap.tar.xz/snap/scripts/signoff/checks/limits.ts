/**
 * L. Limits beyond the reference interval (L1-L2) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * L1 reads docs/signoff/work/governance/critical-limits.json and the critical fields of the seed rows
 *    (Critical_Low / Critical_High) for the 13 Base Panel analytes (families.json base_panel) plus the 15 analytes the
 *    acceptance test lists, and checks statically that the app classifier (src/lib/biomarkers/zone-classifier.ts)
 *    does not derive a "critical" label from the reference (normal) limits.
 * L2 reads docs/signoff/work/governance/action-limits.json and checks the listed entries are complete.
 *
 * critical-limits.json: an array, or {entries: [...]}, or an object keyed by marker. Each entry:
 *   {marker_key, critical_low|null, critical_high|null, none_because|null, sources: [{identifier|citation, ...}],
 *    alternatives: [...], action_en, action_es, recipient_role}
 * action-limits.json: an array or {entries: [...]}. Each entry:
 *   {id, marker_key(s), direction, value, condition?, follow_up_en, follow_up_es, sources}
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, CheckResult, Ctx, Failure } from "../types";
import { loadSeed, sortFailures } from "../lib/seed";

type Metrics = Record<string, number | string | boolean>;
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");

/** The 15 analytes the acceptance test adds to the Base Panel, as seed keys. */
export const L1_EXTRA_ANALYTES: Record<string, string> = {
  potassium: "potassium",
  sodium: "sodium",
  calcium: "calcium_serum",
  glucose: "glucose_fasting",
  haemoglobin: "hemoglobin",
  haematocrit: "hematocrit",
  platelets: "platelet_count",
  wbc: "white_blood_cell_count",
  absolute_neutrophils: "neutrophils_absolute",
  creatinine: "creatinine",
  bilirubin: "total_bilirubin",
  alt: "alt",
  ast: "ast",
  tsh: "tsh",
  hba1c: "hba1c",
};

/** The action-limit entries the acceptance test lists (each matched by any of its keys). */
export const L2_REQUIRED: Record<string, string[]> = {
  tsat_with_ferritin: ["iron_saturation_tsat", "ferritin"],
  psa: ["psa_total"],
  urine_acr: ["microalbumin_urine", "urine_albumin_creatinine_ratio", "uacr"],
  haemoglobin_polycythaemia: ["hemoglobin", "hematocrit"],
  calcium: ["calcium_serum"],
  diabetes_confirmation: ["hba1c", "glucose_fasting"],
  suppressed_tsh_older_adults: ["tsh"],
};

export function l1Analytes(ctx: Ctx): string[] {
  const fam = ctx.load<{ base_panel?: string[] }>(path.join(ctx.workDir, "families.json"));
  return [...new Set([...(fam?.base_panel ?? []), ...Object.values(L1_EXTRA_ANALYTES)])].sort();
}

function entriesOf(doc: unknown): Record<string, unknown>[] {
  if (Array.isArray(doc)) return doc as Record<string, unknown>[];
  if (doc && typeof doc === "object") {
    const d = doc as Record<string, unknown>;
    if (Array.isArray(d.entries)) return d.entries as Record<string, unknown>[];
    return Object.entries(d)
      .filter(([k, v]) => !k.startsWith("_") && v && typeof v === "object" && !Array.isArray(v))
      .map(([k, v]) => ({ marker_key: k, ...(v as Record<string, unknown>) }));
  }
  return [];
}
const nonEmpty = (v: unknown) => typeof v === "string" && v.trim().length > 0;
const isNum = (v: unknown) => typeof v === "number" && Number.isFinite(v);

/**
 * Lines of the classifier where a critical code is returned from a reference (normal) limit:
 * `if (normalLow != null && value < normalLow) return "critical_low";`.
 */
export function criticalFromReference(source: string): { line: number; text: string }[] {
  const out: { line: number; text: string }[] = [];
  const lines = source.split(/\r?\n/);
  lines.forEach((text, i) => {
    if (/return\s+["']critical_(low|high)["']/.test(text) && /normal(Low|High|_low|_high)/.test(text)) out.push({ line: i + 1, text: text.trim() });
  });
  return out;
}

export function criticalEntryProblems(e: Record<string, unknown>): string[] {
  const p: string[] = [];
  const hasValue = isNum(e.critical_low) || isNum(e.critical_high);
  if (!hasValue && !(nonEmpty(e.none_because) && /^none, because/i.test(String(e.none_because).trim())))
    p.push('no critical value and no "none, because ..." reason');
  if (!Array.isArray(e.sources) || !e.sources.length) p.push("no sources");
  if (!Array.isArray(e.alternatives)) p.push("no alternatives listed");
  if (hasValue && (!nonEmpty(e.action_en) || !nonEmpty(e.action_es))) p.push("no action wording in English and Spanish");
  if (hasValue && !nonEmpty(e.recipient_role)) p.push("no recipient role");
  return p;
}

const L1: Check = {
  id: "L1",
  group: "limits",
  title: "Critical limits table and classifier",
  how: "script",
  run(ctx) {
    const failures: Failure[] = [];
    const analytes = l1Analytes(ctx);
    // Static check of the app classifier.
    const classifierPath = "src/lib/biomarkers/zone-classifier.ts";
    const src = fs.existsSync(path.resolve(ctx.root, classifierPath)) ? fs.readFileSync(path.resolve(ctx.root, classifierPath), "utf8") : "";
    const derived = criticalFromReference(src);
    for (const d of derived) failures.push({ key: `classifier|${classifierPath}:${d.line}`, detail: `critical code derived from a reference limit: ${d.text}` });
    const ownZone = /critical_limit|criticalLow|critical_low\s*!=\s*null|criticalHigh/.test(src.replace(/return\s+["']critical_(low|high)["']/g, ""));
    if (!ownZone) failures.push({ key: `classifier|${classifierPath}|own_zone`, detail: "classifyZone takes no critical-limit fields: 'critical' is not its own zone fed by the critical limits" });
    // Seed critical fields.
    const seed = loadSeed(ctx.seedDir);
    const seedCritical = new Map<string, boolean>();
    for (const r of seed?.rows ?? []) if (analytes.includes(r.biomarker_key)) seedCritical.set(r.biomarker_key, (seedCritical.get(r.biomarker_key) ?? false) || r.critical_low != null || r.critical_high != null);
    // The table.
    const tableFile = path.join(ctx.workDir, "governance", "critical-limits.json");
    const table = ctx.load(tableFile);
    const entries = table == null ? [] : entriesOf(table);
    const byKey = new Map(entries.map((e) => [String(e.marker_key ?? ""), e]));
    let covered = 0;
    for (const a of analytes) {
      if (seed && !seedCritical.has(a)) failures.push({ key: `seed|${a}`, detail: "analyte has no seed row" });
      const e = byKey.get(a);
      if (!e) {
        if (table != null) failures.push({ key: `table|${a}`, detail: "no entry in critical-limits.json" });
        continue;
      }
      const probs = criticalEntryProblems(e);
      probs.forEach((p) => failures.push({ key: `table|${a}|${p.split(" ").slice(0, 3).join("_")}`, detail: p }));
      if (!probs.length) covered++;
      const hasValue = isNum(e.critical_low) || isNum(e.critical_high);
      if (hasValue && seed && !seedCritical.get(a)) failures.push({ key: `seed|${a}|critical_fields`, detail: "the table gives a critical limit but the seed rows carry no Critical_Low/Critical_High" });
    }
    const metrics: Metrics = {
      analytes: analytes.length,
      table_present: table != null,
      table_entries_complete: covered,
      seed_rows_with_critical_fields: [...seedCritical.values()].filter(Boolean).length,
      classifier_critical_from_reference_lines: derived.length,
    };
    if (table == null) {
      const on = rel(ctx, tableFile);
      if (!failures.length) return { id: "L1", status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on, metrics };
      return { id: "L1", status: "fail", summary: `${derived.length} classifier lines derive 'critical' from reference limits; critical-limits table absent (${on})`, failures: sortFailures(failures), metrics };
    }
    return {
      id: "L1",
      status: failures.length ? "fail" : "pass",
      summary: `${covered} of ${analytes.length} analytes complete; ${derived.length} classifier lines derive 'critical' from reference limits`,
      failures: sortFailures(failures),
      metrics,
    } satisfies CheckResult;
  },
};

const L2: Check = {
  id: "L2",
  group: "limits",
  title: "Action limits table",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "governance", "action-limits.json");
    const doc = ctx.load(file);
    if (doc == null) return { id: "L2", status: "blocked", summary: `blocked: ${rel(ctx, file)} is missing`, failures: [], blocked_on: rel(ctx, file) };
    const entries = entriesOf(doc);
    const failures: Failure[] = [];
    const keysOf = (e: Record<string, unknown>) => [e.marker_key, ...(Array.isArray(e.marker_keys) ? e.marker_keys : [])].map(String);
    for (const [name, keys] of Object.entries(L2_REQUIRED)) {
      const match = entries.filter((e) => String(e.id ?? "") === name || keysOf(e).some((k) => keys.includes(k)));
      if (!match.length) failures.push({ key: `${name}|missing`, detail: `no action-limit entry for ${name} (${keys.join(", ")})` });
    }
    let complete = 0;
    entries.forEach((e, i) => {
      const id = String(e.id ?? e.marker_key ?? `entry${i}`);
      const p: string[] = [];
      if (!isNum(e.value)) p.push("no numeric value");
      if (e.direction !== "below" && e.direction !== "above") p.push("direction is not below/above");
      if (!nonEmpty(e.follow_up_en) || !nonEmpty(e.follow_up_es)) p.push("no follow-up text in English and Spanish");
      if (!Array.isArray(e.sources) || !e.sources.length) p.push("no sources");
      p.forEach((x) => failures.push({ key: `${id}|${x.split(" ").slice(0, 2).join("_")}`, detail: x }));
      if (!p.length) complete++;
    });
    return {
      id: "L2",
      status: failures.length ? "fail" : "pass",
      summary: `${complete} of ${entries.length} action-limit entries complete; ${Object.keys(L2_REQUIRED).length} required entries checked`,
      failures: sortFailures(failures),
      metrics: { entries: entries.length, complete, required: Object.keys(L2_REQUIRED).length },
    };
  },
};

export const checks: Check[] = [L1, L2];
