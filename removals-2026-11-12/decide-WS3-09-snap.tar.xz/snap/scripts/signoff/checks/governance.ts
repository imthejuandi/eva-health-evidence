/**
 * G. Governance and integrity (G1-G7) of docs/signoff/ACCEPTANCE-TEST.md. G8 (AI pre-review) is in prereview.ts.
 *
 * G1 has three parts. (1) It compares the frozen inputs (everything the runner hashes except the seed files, which the
 *    loop changes by design: the test documents, thresholds, the judge prompts of docs/signoff/work/judges/lenses.json,
 *    the runner and the tools; lib/hash.ts inputFiles) with docs/signoff/work/checks/round-0.json. A change passes only
 *    when docs/signoff/work/governance/approved-changes.json records it ({file, sha256, commit, approved_by: "CEO"}).
 *    Round 0 passes this part by construction: it is the baseline. (2) Fixer diffs are checked against the ownership
 *    map (each family's owned_paths in families.json, plus governance/ownership-map.json when present) from
 *    docs/signoff/work/checks/round-<n>-changes.json ({"<agent or family>": ["path", ...]}), the complete record of
 *    every path changed in the round with the agent that changed it. Without that record the ownership part does not
 *    run. The loop's batch records <batch>-r<n>-changes.json are not read: they hold only the changed paths that
 *    contain the family id (see readRoundRecord). (3) "The compile is idempotent", at every round: when the seed
 *    directory is a compile output (it holds compile-report.json), docs/signoff/tools/compile.js runs again, with what
 *    compile-report.json records about its run and with the run's work dir, into a temporary folder, and every file it
 *    writes must equal the seed directory's byte for byte, and the reconciliation set D6 reads in the work dir must be
 *    the reconciliation files it writes (compileIdempotency). A seed directory that is not a compile output leaves this
 *    part blocked. G1 fails when any part fails, is blocked when no part fails and a part could not run, and passes
 *    only when all three pass.
 * G2 traces every seed row to decisions/<family>.json with a verifier verdict, validates each decisions file and its
 *    research and verify files with docs/signoff/tools/validate.js, and checks every ledger item's state. A final row
 *    carries no row key (common.schema.json row), so its key is built from its fields,
 *    marker_key|sex|age_group|physiological_state, the key the seed row's trace key reproduces. A seed row traces to
 *    the final row with its key only when it holds that row's six bounds, unit, reference basis and reference source
 *    (finalRowMismatches), and every other column the compile writes from the final row, in both files: the messages,
 *    Explanatory_Numbers, the other sign-off columns, the labels and the notes (pairMismatches, which rebuilds the
 *    pair with the compile's own compile-rows.js pairFromLoopRow). A seed row that production does not have (an added
 *    row: its database key is not in compile-baseline.js buildBaseline) is also rebuilt with the template row the
 *    compile would take for it, and must hold that row's columns too (addedRowTemplate, templateMismatches).
 * G3 runs the DSRT twice in-process on the same data (without G3 itself) and compares the hashes of the results.
 * G4-G6 read the pack in docs/signoff/pack/; G7 reads docs/signoff/work/cold-reader.json.
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import type { Check, CheckResult, Ctx, Failure } from "../types";
import { hashInputs, listFiles, sha256File, sha256String, stableStringify } from "../lib/hash";
import { outsideOwnership } from "../lib/ownership";
import { loadSeed, slugify, sortFailures, type RawEn, type RawEs, type Row } from "../lib/seed";
import { loadCompileTools, PRODUCTION_SNAPSHOT, RECONCILIATION_DIR, RECONCILIATION_PARTS, reconciliationSet } from "./data";

const result = (id: string, failures: Failure[], summary: string, metrics?: Record<string, number | string | boolean>): CheckResult => ({
  id,
  status: failures.length ? "fail" : "pass",
  summary,
  failures: sortFailures(failures),
  ...(metrics ? { metrics } : {}),
});
const blocked = (id: string, on: string, metrics?: Record<string, number | string | boolean>): CheckResult => ({ id, status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on, ...(metrics ? { metrics } : {}) });
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, p).split(path.sep).join("/");

// ─── G1 test integrity ───

/** Inputs that are frozen at round 0: every hashed input except the seed files. */
export function frozenInputs(inputs: Record<string, string>, seedDirRel: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [f, h] of Object.entries(inputs)) if (!f.startsWith(`${seedDirRel}/`) && !/^supabase\/seed-data\//.test(f)) out[f] = h;
  return out;
}

export interface FrozenChange {
  file: string;
  kind: "changed" | "added" | "removed";
  sha256: string | null;
}

export function diffFrozen(baseline: Record<string, string>, current: Record<string, string>): FrozenChange[] {
  const out: FrozenChange[] = [];
  for (const f of Object.keys(baseline)) {
    if (!(f in current)) out.push({ file: f, kind: "removed", sha256: null });
    else if (current[f] !== baseline[f]) out.push({ file: f, kind: "changed", sha256: current[f] });
  }
  for (const f of Object.keys(current)) if (!(f in baseline)) out.push({ file: f, kind: "added", sha256: current[f] });
  return out.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : 0));
}

export interface ApprovedChange {
  file: string;
  sha256: string | null;
  commit?: string;
  approved_by?: string;
}

export function unapproved(changes: FrozenChange[], approved: ApprovedChange[]): FrozenChange[] {
  return changes.filter((c) => !approved.some((a) => a.file === c.file && (a.sha256 ?? null) === c.sha256 && /^ceo$/i.test(String(a.approved_by ?? "")) && !!a.commit));
}

/** The ownership map: each family's owned_paths from families.json, merged with governance/ownership-map.json. */
export function ownershipMap(ctx: Ctx): Record<string, string[]> {
  const map: Record<string, string[]> = {};
  const fam = ctx.load<{ families?: Record<string, { owned_paths?: string[] }> }>(path.join(ctx.workDir, "families.json"));
  for (const [id, f] of Object.entries(fam?.families ?? {})) map[id] = [...(f.owned_paths ?? [])];
  const extra = ctx.load<Record<string, string[]>>(path.join(ctx.workDir, "governance", "ownership-map.json"));
  for (const [id, globs] of Object.entries(extra ?? {})) if (Array.isArray(globs)) map[id] = [...(map[id] ?? []), ...globs];
  return map;
}

/** The round's record of changed files per agent, the one file G1 judges ownership from. */
export function roundChangesFile(checksDir: string, round: number): string {
  return path.join(checksDir, `round-${round}-changes.json`);
}

/**
 * The round's record of changed files per agent, checks/round-<n>-changes.json ({"<agent or family>": ["path", ...]}):
 * the complete record of every path changed in round n with the agent that changed it. changes is null when the file
 * does not exist, and null with unreadable true when it is not a JSON object of path lists.
 *
 * The batch records checks/<batch>-r<n>-changes.json are not read. The loop writes them with `git status --porcelain
 * -uall | grep -F '<family>' | grep -v -F '<work>/checks/' | grep -v -F '<work>/compiled/' | node ownership.js
 * --family <family> --record …` (docs/signoff/workflows/ws1-batch.js, check step 2), so they hold only the changed
 * paths that contain the family id: an edit anywhere else is never in them, and they are no record of the round.
 */
export function readRoundRecord(file: string): { changes: Record<string, string[]> | null; unreadable: boolean } {
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return { changes: null, unreadable: false };
  let doc: unknown;
  try {
    doc = JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    doc = null;
  }
  const readable = !!doc && typeof doc === "object" && !Array.isArray(doc) && Object.values(doc).every((l) => Array.isArray(l) && l.every((p) => typeof p === "string"));
  return readable ? { changes: doc as Record<string, string[]>, unreadable: false } : { changes: null, unreadable: true };
}

/** Files each agent changed that fall outside what it owns. */
export function ownershipViolations(changes: Record<string, string[]>, map: Record<string, string[]>): Failure[] {
  const failures: Failure[] = [];
  for (const [agent, files] of Object.entries(changes)) {
    const owned = map[agent];
    if (!owned) {
      for (const f of files) failures.push({ key: `ownership|${agent}|${f}`, detail: `agent ${agent} has no entry in the ownership map` });
      continue;
    }
    for (const f of outsideOwnership(files, owned)) failures.push({ key: `ownership|${agent}|${f}`, detail: `outside ${agent}'s owned paths` });
  }
  return failures;
}

// ─── G1 the compile is idempotent ───

/** The file compile.js writes into --out-dir after its outputs, the record of its own run. A seed directory that holds it is a compile output. */
export const COMPILE_REPORT = "compile-report.json";
/** The folder of a compile output that holds the reconciliation files, when the compile was run with --reconciliation-dir there. */
export const RECONCILIATION_SUBDIR = "reconciliation";
/** The reconciliation files a compile output holds at its top when the compile was run with --reconciliation-dir set to --out-dir (rollback.sql is then the output folder's own). */
const RECONCILIATION_AT_TOP = new Set(["diff.json", "forward.sql"]);
/** A bound on the rerun's time, so that a compile that does not return fails G1 rather than stopping the run. */
const COMPILE_TIMEOUT_MS = 300_000;

/** What compile-report.json records about the compile's own run (compile.js reportOut: options, and per family where its rows came from). */
export interface CompileRun {
  /** --families, sorted as the report writes them; null for every family. */
  families: string[] | null;
  /** --migration-name, or the default the compile used. */
  migrationName: string;
  /** --write-seed: the compile wrote the seed files over the seed it read. */
  writeSeed: boolean;
  /** Per family: where its rows came from (decisions, verify, research, seed), the file, relative to the repository, and its sha256. */
  sources: Record<string, { source: unknown; file: unknown; sha256: unknown }>;
}

/**
 * compile-report.json read as the record of a compile's run, or why it cannot be: compile.js writes options.families
 * (null, or the --families list), options.migration_name, options.write_seed and, per family, source, source_file and
 * source_sha256 (compile.js lines 111 and 299). A family list the command line cannot give (empty, or not of family
 * ids) or a migration name that is not one is not a record of a run.
 */
export function readCompileRun(doc: unknown): { run: CompileRun | null; problem: string | null } {
  const isObject = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);
  if (!isObject(doc)) return { run: null, problem: "it is not a JSON object" };
  const o = doc.options;
  if (!isObject(o)) return { run: null, problem: "it has no options object" };
  const families = o.families;
  if (!(families === null || (Array.isArray(families) && families.length > 0 && families.every((f) => typeof f === "string" && /^[A-Za-z0-9_]+$/.test(f))))) return { run: null, problem: "options.families is neither null nor a list of family ids" };
  if (typeof o.migration_name !== "string" || !/^[A-Za-z0-9_]+$/.test(o.migration_name)) return { run: null, problem: "options.migration_name is not a migration name" };
  if (typeof o.write_seed !== "boolean") return { run: null, problem: "options.write_seed is not true or false" };
  if (!isObject(doc.families)) return { run: null, problem: "it has no families object" };
  const sources: CompileRun["sources"] = {};
  for (const [f, v] of Object.entries(doc.families)) sources[f] = isObject(v) ? { source: v.source, file: v.source_file, sha256: v.source_sha256 } : { source: undefined, file: undefined, sha256: undefined };
  return { run: { families: families as string[] | null, migrationName: o.migration_name, writeSeed: o.write_seed, sources }, problem: null };
}

/**
 * Where two texts first differ, for a failure detail: the line and column, and a short excerpt of each. held names the
 * file compared with the compile's: the seed directory's, or the work dir's for the reconciliation set D6 reads.
 */
export function firstDifference(seed: string, written: string, held = "the seed directory's file"): string {
  const a = seed.split("\n");
  const b = written.split("\n");
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    if (a[i] === b[i]) continue;
    if (a[i] === undefined) return `the compile writes ${b.length - a.length} more lines from line ${i + 1}`;
    if (b[i] === undefined) return `${held} has ${a.length - b.length} more lines from line ${i + 1}`;
    let c = 0;
    while (c < a[i].length && c < b[i].length && a[i][c] === b[i][c]) c++;
    const cut = (s: string) => JSON.stringify(s.slice(Math.max(0, c - 30), c + 50));
    return `first difference at line ${i + 1}, column ${c + 1}: ${held} has ${cut(a[i])}, the compile writes ${cut(b[i])}`;
  }
  return "the files differ in bytes that do not decode as text";
}

/**
 * A file G1 holds to what the rerun of the compile writes in its place. key: its failure key; shown: its path in a
 * detail; side: how firstDifference names it; file: where it is; written: what the rerun wrote; namesSources: a
 * diff.json, which names each family's source file by its path; lead: what a failure detail says first; problem: the
 * failure detail of a file that cannot be compared (the file D6 reads is not the one the compile writes there, or the
 * set lacks it).
 */
interface HeldFile {
  key: string;
  shown: string;
  side: string;
  file: string;
  written: Buffer;
  namesSources: boolean;
  lead?: string;
  problem?: string;
}
const SEED_SIDE = "the seed directory's file";
const WORK_SIDE = "the work dir's file";

/** The parts of the reconciliation set docs/signoff/tools/compile.js --reconciliation-dir writes: diff.json, forward.sql and rollback.sql (compile.js lines 34 and 302). */
const COMPILED_RECONCILIATION_PARTS = ["diff", "forward", "rollback"] as const;
/** What the checks read each of those parts as, for a failure detail (D6 reads all three; D5 the diff and the forward migration when no changes.json is next to the seed). */
const READ_AS: Record<(typeof COMPILED_RECONCILIATION_PARTS)[number], string> = {
  diff: "D6 reads it as the reconciliation diff, and D5 as the change list when no changes.json is next to the seed",
  forward: "D6 reads it as the forward migration, and D5 as the documented migration when no changes.json is next to the seed",
  rollback: "D6 reads it as the rollback",
};

/**
 * The reconciliation set D6 reads in the run's work dir (<work dir>/reconciliation, which compile.js
 * --reconciliation-dir writes when docs/signoff/work/reconciliation/README.md builds the set), as files held to the
 * rerun's (reconDir). For each part the compile writes, the file D6 picks in the work dir must be the file of that name
 * the rerun writes, with its bytes; data.ts reconciliationSet picks both, as D6 and D5 pick theirs. When the work dir's
 * folder holds none of the three parts, nothing is held: the set is not there (every B01 work copy). Otherwise a part
 * D6 picks under another name than the one the compile writes (such as a hand-made diff-a.json sorted before
 * diff.json), one the folder lacks, one the compile does not write, and one that is not a file each fail without a
 * comparison. reasons.json (an input of the compile, which the rerun reads too) and the reader results are not compile
 * outputs and are not held.
 */
function reconciliationSetHeld(ctx: Ctx, reconDir: string, options: string): HeldFile[] {
  const dir = path.join(ctx.workDir, RECONCILIATION_DIR);
  const shownDir = rel(ctx, dir);
  const key = (name: string) => `compile|work-dir/${RECONCILIATION_DIR}${name ? `/${name}` : ""}`;
  const run = `docs/signoff/tools/compile.js run again with what ${COMPILE_REPORT} records (${options})`;
  if (fs.existsSync(dir) && !fs.statSync(dir).isDirectory()) return [{ key: key(""), shown: shownDir, side: WORK_SIDE, file: dir, written: Buffer.alloc(0), namesSources: false, problem: `D6 reads the reconciliation set from ${shownDir}, which is not a folder` }];
  const held = reconciliationSet(dir).picked;
  const writes = reconciliationSet(reconDir).picked;
  const present = COMPILED_RECONCILIATION_PARTS.map((p) => held[p]).filter((f): f is string => !!f);
  if (!present.length) return [];
  const out: HeldFile[] = [];
  for (const p of COMPILED_RECONCILIATION_PARTS) {
    const entry = held[p];
    const name = writes[p];
    if (!entry && !name) continue;
    const shown = entry ?? name ?? p;
    const file = path.join(dir, shown);
    const item: HeldFile = { key: key(shown), shown: `${shownDir}/${shown}`, side: WORK_SIDE, file, written: name ? fs.readFileSync(path.join(reconDir, name)) : Buffer.alloc(0), namesSources: p === "diff", lead: `${READ_AS[p]}; it ` };
    if (!entry) item.problem = `D6 finds no ${p} file in ${shownDir} (no entry whose name matches ${RECONCILIATION_PARTS[p]}), which holds ${present.join(" and ")} of the reconciliation set: ${run} writes ${name} with them`;
    else if (!name) item.problem = `${READ_AS[p]}, and ${run} writes no ${p} file of the reconciliation set`;
    else if (entry !== name) item.problem = `${READ_AS[p]} (the first entry of ${shownDir}, in sorted order, whose name matches ${RECONCILIATION_PARTS[p]}), and ${run} writes ${name} there, not ${entry}`;
    else if (!fs.existsSync(file) || !fs.statSync(file).isFile()) item.problem = `${READ_AS[p]}, and it is not a file`;
    out.push(item);
  }
  return out;
}

/** The result of G1's third part. */
export interface IdempotencyResult {
  failures: Failure[];
  /** What this part could not run without, when it did not run, or compared nothing it could compare, and nothing failed. */
  blockedOn: string | null;
  summary: string;
  metrics: Record<string, number | string | boolean>;
}

/**
 * G1's "The compile is idempotent" (ACCEPTANCE-TEST.md line 122). A seed directory that holds compile-report.json is a
 * compile output, and its compile is run again: node docs/signoff/tools/compile.js under the root with what
 * compile-report.json records about its run (options.families as --families, options.migration_name as
 * --migration-name) and the run's work dir as --work-dir, into a temporary folder, with --reconciliation-dir in it.
 * compile-report.json records no other option: the rerun reads compile.js's defaults under the root, the seed
 * supabase/seed-data, the gate1 snapshot and supabase/migrations, as the loop runs the compile
 * (docs/signoff/workflows/ws1-batch.js: --out-dir and --families only). Then:
 * - each family's source and source file content must be the ones compile-report.json records (source,
 *   source_sha256); a family whose files differ fails ('compile|input|<family>'): the seed directory is not the compile
 *   of this work dir's files;
 * - every file the rerun writes into its output folder, compile-report.json aside, must equal the seed directory's
 *   file of that name byte for byte ('compile|<file>' when it differs or is missing): the two seed files,
 *   biomarker-sources.json, changes.json, CHANGES.md, migration.sql and rollback.sql. compile-report.json is read, not
 *   compared: it names the folder the compile read its family files from (source_file);
 * - each reconciliation file the rerun writes (diff.json, forward.sql, rollback.sql) that the seed directory holds,
 *   in its reconciliation folder (or diff.json and forward.sql at its top), must equal the rerun's byte for byte;
 * - so must the reconciliation set the checks read in the run's work dir, <work dir>/reconciliation: for the diff,
 *   the forward migration and the rollback, the file D6 picks there (and D5, for the first two, when no changes.json
 *   is next to the seed) must be the file of that name the rerun writes, with its bytes ('compile|work-dir/
 *   reconciliation/<file>'); a part D6 picks under another name, or one the set lacks, fails
 *   (reconciliationSetHeld). When the folder holds none of the three, there is nothing to compare. A set compiled with
 *   other families, inputs or reasons than the seed directory's is not the reconciliation of the seed being checked,
 *   and fails too.
 *   diff.json names a family's source file by its path (compile.js line 301), so where the rerun's work dir is not the
 *   folder compile-report.json records and a diff.json equals the rerun's once each of those paths is written as
 *   recorded, the file cannot be compared from this work dir and this part is blocked on it; any other difference
 *   fails.
 * A hand edit of the compile's outputs after the compile therefore fails, as does an output of other tools or other
 * inputs than the root's and the work dir's. A seed directory that is not a compile output, a compile that wrote its
 * seed files over the seed it read (--write-seed, which a rerun would repeat on supabase/seed-data) or a root without
 * compile.js leaves this part blocked, never passed; a compile-report.json that is not a record of a run, or a rerun
 * that does not complete, fails.
 */
export function compileIdempotency(ctx: Ctx): IdempotencyResult {
  const seedRel = rel(ctx, ctx.seedDir);
  const reportFile = path.join(ctx.seedDir, COMPILE_REPORT);
  const metrics: Record<string, number | string | boolean> = { compile_output: false, compile_rerun: false, compile_files_compared: 0, compile_files_differing: 0, compile_files_not_comparable: 0, compile_inputs_differing: 0, compile_reconciliation_set_files: 0 };
  const notRun = (why: string, on: string): IdempotencyResult => ({ failures: [], blockedOn: on, summary: `compile not rerun (${why})`, metrics });
  const failed = (key: string, detail: string, why: string): IdempotencyResult => ({ failures: [{ key, detail }], blockedOn: null, summary: `compile not rerun (${why})`, metrics });
  if (!fs.existsSync(reportFile) || !fs.statSync(reportFile).isFile()) return notRun(`${seedRel} holds no ${COMPILE_REPORT}, so it is not a compile output`, `${seedRel}/${COMPILE_REPORT} (a compile output as the seed directory, for the idempotency check)`);
  metrics.compile_output = true;
  const parse = (file: string): unknown => {
    try {
      return JSON.parse(fs.readFileSync(file, "utf8"));
    } catch {
      return null;
    }
  };
  const { run, problem } = readCompileRun(parse(reportFile));
  if (!run) return failed("compile|report", `${seedRel}/${COMPILE_REPORT} is not a record of a compile's run (${problem}), so the compile cannot be run again with its options`, `${seedRel}/${COMPILE_REPORT} cannot be read`);
  if (run.writeSeed) return notRun(`${COMPILE_REPORT} records --write-seed`, `the seed the compile read (${seedRel}/${COMPILE_REPORT} records --write-seed: the compile wrote its seed files over the seed it read, so its run cannot be repeated with the same inputs)`);
  const tool = path.join(ctx.root, "docs/signoff/tools/compile.js");
  if (!fs.existsSync(tool)) return notRun("no docs/signoff/tools/compile.js", "docs/signoff/tools/compile.js");
  const options = `${run.families ? `--families ${run.families.join(",")}` : "every family"}, --migration-name ${run.migrationName}, --work-dir ${rel(ctx, ctx.workDir)}`;
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-g1-compile-"));
  try {
    const outDir = path.join(tmp, "out");
    const reconDir = path.join(tmp, RECONCILIATION_SUBDIR);
    const args = [tool, "--out-dir", outDir, "--reconciliation-dir", reconDir, "--work-dir", ctx.workDir, "--migration-name", run.migrationName, ...(run.families ? ["--families", ...run.families] : [])];
    const proc = spawnSync(process.execPath, args, { cwd: ctx.root, encoding: "utf8", maxBuffer: 256 * 1024 * 1024, timeout: COMPILE_TIMEOUT_MS });
    const rerunReport = proc.status === 0 ? readCompileRun(parse(path.join(outDir, COMPILE_REPORT))).run : null;
    if (!rerunReport) {
      const said = String(proc.stderr || proc.error?.message || "").split(tmp).join("<temporary folder>").trim().split("\n")[0] ?? "";
      const how = proc.status === 0 ? `it wrote no readable ${COMPILE_REPORT}` : `exit ${proc.status ?? "none"}${proc.signal ? ` (${proc.signal})` : ""}${said ? `, ${said}` : ""}`;
      return failed("compile|run", `docs/signoff/tools/compile.js did not complete with what ${COMPILE_REPORT} records (${options}): ${how}`, "the compile did not complete");
    }
    metrics.compile_rerun = true;
    const failures: Failure[] = [];
    // The inputs compile-report.json records: each family's source and its file's content.
    const recorded = run.sources;
    const now = rerunReport.sources;
    const shownSource = (s: CompileRun["sources"][string] | undefined) => (s ? `source ${String(s.source)}${typeof s.file === "string" ? ` ${s.file}` : ""}${typeof s.sha256 === "string" ? ` sha256 ${s.sha256}` : ""}` : "no entry");
    for (const fam of [...new Set([...Object.keys(recorded), ...Object.keys(now)])].sort()) {
      const a = recorded[fam];
      const b = now[fam];
      if (a && b && a.source === b.source && (a.sha256 ?? null) === (b.sha256 ?? null)) continue;
      failures.push({ key: `compile|input|${fam}`, detail: `${COMPILE_REPORT} records ${shownSource(a)}; the compile run again on the work dir ${rel(ctx, ctx.workDir)} reads ${shownSource(b)}: the seed directory is not the compile of these inputs` });
    }
    metrics.compile_inputs_differing = failures.length;
    // Where the rerun's work dir is not the folder the compile read: each family's source file as the rerun names it and as recorded.
    const moved: [string, string][] = [];
    for (const fam of Object.keys(recorded).sort()) {
      const a = recorded[fam]?.file;
      const b = now[fam]?.file;
      if (typeof a === "string" && typeof b === "string" && a !== b) moved.push([b, a]);
    }
    const filesIn = (dir: string) => (fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => fs.statSync(path.join(dir, f)).isFile()).sort() : []);
    const compared: HeldFile[] = [];
    for (const f of filesIn(outDir)) if (f !== COMPILE_REPORT) compared.push({ key: `compile|${f}`, shown: `${seedRel}/${f}`, side: SEED_SIDE, file: path.join(ctx.seedDir, f), written: fs.readFileSync(path.join(outDir, f)), namesSources: false });
    for (const f of filesIn(reconDir)) {
      const written = fs.readFileSync(path.join(reconDir, f));
      for (const w of [`${RECONCILIATION_SUBDIR}/${f}`, ...(RECONCILIATION_AT_TOP.has(f) ? [f] : [])]) {
        const seedFile = path.join(ctx.seedDir, ...w.split("/"));
        if (fs.existsSync(seedFile)) compared.push({ key: `compile|${w}`, shown: `${seedRel}/${w}`, side: SEED_SIDE, file: seedFile, written, namesSources: f === "diff.json" });
      }
    }
    const fromSet = compared.length;
    compared.push(...reconciliationSetHeld(ctx, reconDir, options));
    const setFiles = compared.length - fromSet;
    const notComparable: string[] = [];
    let differing = 0;
    for (const c of compared) {
      if (c.problem) {
        differing++;
        failures.push({ key: c.key, detail: c.problem });
        continue;
      }
      if (!fs.existsSync(c.file)) {
        differing++;
        failures.push({ key: c.key, detail: `written by docs/signoff/tools/compile.js run again with what ${COMPILE_REPORT} records (${options}), missing from ${seedRel}` });
        continue;
      }
      const heldBytes = fs.readFileSync(c.file);
      if (heldBytes.equals(c.written)) continue;
      if (c.namesSources && moved.length) {
        let text = c.written.toString("utf8");
        for (const [mine, theirs] of moved) text = text.split(JSON.stringify(mine)).join(JSON.stringify(theirs));
        if (Buffer.from(text, "utf8").equals(heldBytes)) {
          notComparable.push(`${c.shown} run again from the work dir it names (${[...new Set(moved.map(([, a]) => path.posix.dirname(path.posix.dirname(a))))].join(", ")}, as ${COMPILE_REPORT} records it): it names each family's source file by its path, and this run reads them from ${rel(ctx, ctx.workDir)}`);
          continue;
        }
      }
      differing++;
      failures.push({ key: c.key, detail: `${c.lead ?? ""}differs from what docs/signoff/tools/compile.js writes when run again with what ${COMPILE_REPORT} records (${options}): ${firstDifference(heldBytes.toString("utf8"), c.written.toString("utf8"), c.side)}` });
    }
    metrics.compile_files_compared = compared.length;
    metrics.compile_files_differing = differing;
    metrics.compile_files_not_comparable = notComparable.length;
    metrics.compile_reconciliation_set_files = setFiles;
    const inputs = metrics.compile_inputs_differing ? `, ${metrics.compile_inputs_differing} families whose files differ from the ones ${COMPILE_REPORT} records` : "";
    const later = notComparable.length ? `, ${notComparable.length} not comparable byte for byte from this work dir` : "";
    const set = setFiles ? ` (${setFiles} of them the reconciliation set D6 reads, in ${rel(ctx, path.join(ctx.workDir, RECONCILIATION_DIR))})` : "";
    return { failures, blockedOn: failures.length || !notComparable.length ? null : notComparable.join("; "), summary: `compile rerun: ${differing} of ${compared.length} output files differ${set}${inputs}${later}`, metrics };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

const G1: Check = {
  id: "G1",
  group: "governance",
  title: "Test integrity",
  how: "script",
  run(ctx) {
    const current = frozenInputs(hashInputs(ctx.root, ctx.seedDir), rel(ctx, ctx.seedDir));
    const baselineFile = path.join(ctx.workDir, "checks", "round-0.json");
    const baselineDoc = ctx.load<{ inputs?: Record<string, string> }>(baselineFile);
    const metrics: Record<string, number | string | boolean> = { frozen_files: Object.keys(current).length, frozen_digest: sha256String(stableStringify(current)) };
    const failures: Failure[] = [];
    const blockedOn: string[] = [];
    const parts: string[] = [];
    if (ctx.round === 0) {
      // Round 0 is the baseline of the frozen inputs, and no fixer has changed anything yet.
      metrics.baseline = "this run";
      parts.push(`round 0 is the baseline: ${Object.keys(current).length} frozen files hashed`);
    } else {
      // Part 1: the frozen inputs against round 0.
      if (!baselineDoc?.inputs) {
        blockedOn.push(rel(ctx, baselineFile));
        parts.push(`frozen files not compared (no ${rel(ctx, baselineFile)})`);
      } else {
        const baseline = frozenInputs(baselineDoc.inputs, rel(ctx, ctx.seedDir));
        const approved = ctx.load<ApprovedChange[]>(path.join(ctx.workDir, "governance", "approved-changes.json")) ?? [];
        const changes = diffFrozen(baseline, current);
        const bad = unapproved(changes, Array.isArray(approved) ? approved : []);
        failures.push(...bad.map((c) => ({ key: `frozen|${c.file}`, detail: `${c.kind} since round 0 without a CEO-approved commit in governance/approved-changes.json` })));
        metrics.frozen_changes = changes.length;
        metrics.frozen_changes_unapproved = bad.length;
        parts.push(`${bad.length} frozen files changed without approval`);
      }
      // Part 2: the round's fixer diffs against the ownership map.
      const changesFile = roundChangesFile(path.join(ctx.workDir, "checks"), ctx.round);
      const record = readRoundRecord(changesFile);
      const roundChanges = record.changes;
      const outOfScope = roundChanges ? ownershipViolations(roundChanges, ownershipMap(ctx)) : [];
      failures.push(...outOfScope);
      // A record that exists but cannot be read is a defect of the loop's output, not missing external data: a failure.
      if (record.unreadable) failures.push({ key: `ownership|record|${path.basename(changesFile)}`, detail: `${rel(ctx, changesFile)} is not a JSON object of path lists; the round's edits were not checked against the ownership map` });
      if (!roundChanges && !record.unreadable) blockedOn.push(`${rel(ctx, changesFile)} (the round's changed files per agent, for the ownership check)`);
      metrics.ownership_checked = !!roundChanges;
      metrics.ownership_record = rel(ctx, changesFile);
      parts.push(roundChanges ? `${outOfScope.length} out-of-scope edits` : `ownership not checked (${record.unreadable ? "unreadable" : "no"} ${rel(ctx, changesFile)})`);
    }
    // Part 3, at every round: the compile is idempotent.
    const compile = compileIdempotency(ctx);
    Object.assign(metrics, compile.metrics);
    failures.push(...compile.failures);
    if (compile.blockedOn) blockedOn.push(compile.blockedOn);
    parts.push(compile.summary);
    const summary = parts.join("; ");
    // Any failure fails G1; otherwise a part that could not run blocks it; it passes only when every part ran and passed.
    if (!failures.length && blockedOn.length) return { id: "G1", status: "blocked", summary, failures: [], blocked_on: blockedOn.join("; "), metrics };
    return result("G1", failures, summary, metrics);
  },
};

// ─── G2 traceability ───

const LEDGER_STATES = new Set(["open", "confirmed", "disputed", "refuted", "fixed", "closed", "unreviewed", "physician_question"]);

interface FamiliesDoc {
  non_rows?: Record<string, string>;
  families?: Record<string, { keys?: string[] }>;
}

/** The physiological states of common.schema.json. */
export const PHYSIOLOGICAL_STATES = new Set(["none", "pregnancy", "lactation", "premenopausal", "perimenopausal", "postmenopausal", "hormone_therapy", "oral_contraception", "follicular", "ovulatory", "luteal"]);

/**
 * The state a labelled age group stands for in a row key (common.schema.json row_key). The labels are those the
 * compile writes for state rows (docs/signoff/tools/lib/compile-rows.js STATE_LABEL, LABEL_TO_STATE): the cycle
 * phases first, as "Premenopausal (follicular)" names both.
 */
export function stateOfAgeGroup(ageGroup: string): string {
  const s = ageGroup.toLowerCase();
  for (const st of ["follicular", "ovulatory", "luteal", "pregnancy", "lactation", "perimenopausal", "postmenopausal", "premenopausal"]) if (s.includes(st)) return st;
  if (s.includes("hormone therapy")) return "hormone_therapy";
  if (s.includes("oral contraception")) return "oral_contraception";
  return "none";
}

/**
 * A seed row's trace key, marker_key|sex|age_group|physiological_state. The state is the row's State column when
 * the compile wrote one (rows compiled from the loop's files), else the state its age-group label stands for. A state
 * row's age group is the band the compile appends to the state label ("Pregnancy 18-39"), else All Adults.
 */
export function rowTraceKey(r: Pick<Row, "biomarker_key" | "sex" | "age_group_en">, stateColumn?: unknown): string {
  const st = typeof stateColumn === "string" && PHYSIOLOGICAL_STATES.has(stateColumn) ? stateColumn : stateOfAgeGroup(r.age_group_en);
  const age = st === "none" ? r.age_group_en : (r.age_group_en.match(/\b(\d{1,3}-\d{1,3}|\d{1,3}\+)/)?.[1] ?? "All Adults");
  return `${r.biomarker_key}|${r.sex}|${age}|${st}`;
}

/** The fields of a final row (common.schema.json row) that make its key, and the values the compile writes into the seed. */
export interface FinalRowFields {
  marker_key?: string;
  sex?: string;
  age_group?: string;
  physiological_state?: string;
  unit?: unknown;
  reference_low?: unknown;
  reference_high?: unknown;
  optimal_low?: unknown;
  optimal_high?: unknown;
  critical_low?: unknown;
  critical_high?: unknown;
  reference_basis?: unknown;
  reference_source?: unknown;
}

/** A final row's key: marker_key|sex|age_group|physiological_state, as compile.js and validate.js build it. */
export function finalRowKey(d: FinalRowFields): string {
  return `${d.marker_key}|${d.sex}|${d.age_group}|${d.physiological_state}`;
}

/**
 * The seed columns a final row's values become (docs/signoff/tools/lib/compile-rows.js BOUNDS and EXT): the six bounds
 * and the unit. A seed row traces to a final row only when it holds these values.
 */
const TRACED_VALUES: [keyof Row & ("normal_low" | "normal_high" | "optimal_low" | "optimal_high" | "critical_low" | "critical_high"), keyof FinalRowFields, string][] = [
  ["normal_low", "reference_low", "Normal_Low"],
  ["normal_high", "reference_high", "Normal_High"],
  ["optimal_low", "optimal_low", "Optimal_Low"],
  ["optimal_high", "optimal_high", "Optimal_High"],
  ["critical_low", "critical_low", "Critical_Low"],
  ["critical_high", "critical_high", "Critical_High"],
];

/**
 * Where a seed row differs from the final row it traces to; [] when it holds the final row's values: the six bounds
 * and the unit, and the reference basis and source the compile writes as Reference_Basis and Reference_Source
 * (compile-rows.js EXT). The basis and source are compared as the seed row carries them for the other checks
 * (seed.ts buildRows: Reference_Basis, else reference_basis; Reference_Source, else Source or source), because D3
 * exempts a row from the catalogue comparison by its basis and source and N1 reads its basis.
 */
export function finalRowMismatches(r: Pick<Row, "unit_en" | "normal_low" | "normal_high" | "optimal_low" | "optimal_high" | "critical_low" | "critical_high" | "reference_basis" | "source">, d: FinalRowFields): string[] {
  const out: string[] = [];
  const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
  for (const [col, field, label] of TRACED_VALUES) {
    const seed = r[col] ?? null;
    const final = num(d[field]);
    if (seed !== final) out.push(`${label} ${seed ?? "null"} vs ${field} ${final ?? "null"}`);
  }
  if (r.unit_en !== d.unit) out.push(`Unit "${r.unit_en}" vs unit ${typeof d.unit === "string" ? `"${d.unit}"` : "null"}`);
  // Texts as seed.ts reads them: a non-empty string, else null.
  const text = (v: unknown): string | null => (typeof v === "string" && v.length ? v : null);
  const quoted = (v: string | null) => (v == null ? "null" : `"${v}"`);
  for (const [seed, field, label] of [
    [text(r.reference_basis), "reference_basis", "Reference_Basis"],
    [text(r.source), "reference_source", "Reference_Source"],
  ] as const) {
    const final = text(d[field]);
    if (seed !== final) out.push(`${label} ${quoted(seed)} vs ${field} ${quoted(final)}`);
  }
  return out;
}

/** The English and the Spanish row of one seed row, as the two seed files hold them at its index. */
export interface SeedPair {
  en: RawEn;
  es: RawEs;
}

/** A row of public.biomarker_references by column, as docs/signoff/tools/lib/compile-baseline.js buildBaseline holds production. */
export type ProductionRow = Record<string, unknown>;

/**
 * What G2 takes from docs/signoff/tools/lib/compile-rows.js: the function the compile writes a seed pair from a final
 * row with, the functions it picks that pair's template row with, and its column tables.
 */
export interface CompileRowsLib {
  pairFromLoopRow(row: unknown, template: SeedPair, markerPairs: SeedPair[], warn: (message: string) => void): SeedPair;
  /** The template row of a loop row among a marker's pairs: same sex and label, else same sex, else both, else the first (compile.js line 149). */
  pickTemplate(markerPairs: SeedPair[], sex: string, labelEn: string): SeedPair | null;
  /** The seed labels of a loop row's age group and state, reusing a label the marker's pairs give that state. */
  ageStateToLabel(ageGroup: unknown, state: unknown, markerPairs: SeedPair[], warn: (message: string) => void): [string, string];
  /** A seed pair from a production row, as compile.js builds the pairs of a production-only marker. */
  pairFromDbRow(row: ProductionRow, categoryEsByEn: Record<string, unknown>, warn: (message: string) => void): SeedPair;
  /** The database row the seeder writes for a seed pair. */
  dbRowFromPair(pair: SeedPair): ProductionRow;
  /** A database row's key, biomarker_key|sex|age_group_en. */
  dbKey(row: ProductionRow): string;
  /** [English column, Spanish column, database column, final-row field] */
  BOUNDS: [string, string, string, string][];
  /** [English column, Spanish column, database column, final-row zones] */
  MSGS: [string, string, string, string[]][];
  /** [English column, Spanish column, database column, final-row field, kind] */
  EXT: [string, string, string, string, string][];
  /** The final-row field that holds a sign-off text's Spanish version. */
  ES_TEXT: Record<string, string>;
  /** [English column, Spanish column, English field, Spanish field] */
  NOTE_COLS: [string, string, string, string][];
}

/** docs/signoff/tools/lib/compile-rows.js under root. */
export function loadCompileRows(root: string): CompileRowsLib {
  const req = createRequire(import.meta.url);
  return req(path.join(root, "docs/signoff/tools/lib/compile-rows.js")) as CompileRowsLib;
}

/** A value as written, for comparing two values exactly: null and an absent value alike, a text quoted, a number as JSON writes it, an array item by item in order. */
const canonical = (v: unknown): string =>
  v === undefined || v === null
    ? "null"
    : Array.isArray(v)
      ? `[${v.map(canonical).join(",")}]`
      : typeof v === "number"
        ? Number.isFinite(v)
          ? JSON.stringify(v)
          : `#${String(v)}`
        : typeof v === "string"
          ? JSON.stringify(v)
          : typeof v === "boolean"
            ? String(v)
            : `#${JSON.stringify(v)}`;
const shown = (v: unknown): string => (v === undefined || v === null ? "null" : typeof v === "string" || Array.isArray(v) ? JSON.stringify(v) : String(v));

/** The final-row field each seed column is written from, by "en:<column>" and "es:<column>" (compile-rows.js pairFromLoopRow). */
function writtenFrom(lib: CompileRowsLib): Map<string, string> {
  const m = new Map<string, string>([
    ["en:Sex", "sex"],
    ["es:Sexo", "sex"],
    ["en:Age_Group", "age_group and physiological_state"],
    ["es:Grupo_Edad", "age_group and physiological_state"],
    ["en:Unit", "unit"],
    ["es:Unidad", "unit_es, else unit"],
  ]);
  for (const [ce, cs, , field] of lib.BOUNDS) m.set(`en:${ce}`, field).set(`es:${cs}`, field);
  for (const [ce, cs, , zones] of lib.MSGS) m.set(`en:${ce}`, `messages.en.${zones.join(" or ")}`).set(`es:${cs}`, `messages.es.${zones.join(" or ")}`);
  for (const [ce, cs, , field] of lib.EXT) m.set(`en:${ce}`, field).set(`es:${cs}`, lib.ES_TEXT[field] ? `${lib.ES_TEXT[field]}, else ${field}` : field);
  for (const [ce, cs, fe, fs] of lib.NOTE_COLS) m.set(`en:${ce}`, fe).set(`es:${cs}`, fs);
  return m;
}

/** The English columns finalRowMismatches compares, as the checks read them (seed.ts buildRows); pairMismatches leaves them to it. */
const COMPARED_AS_READ = new Set([...TRACED_VALUES.map((t) => t[2]), "Unit", "Reference_Basis", "Reference_Source"]);

/**
 * Where a seed pair differs from the pair the compile writes from its final row; [] when it holds it. compile-rows.js
 * pairFromLoopRow rebuilds the pair from the final row with the seed pair as its template, as compile.js builds a
 * compiled row from a template row, and each column of both files is compared exactly (a text as written, a list
 * item by item in order): the age-group label and sex, the bounds and unit of the Spanish file, the five messages of
 * each file (the final row's zones as MSGS maps them), Explanatory_Numbers and the other sign-off columns of both
 * files, and the notes when the final row carries them. The columns the compile takes from the template (category,
 * name, tested twice a year, and the messages and notes of a final row that carries none) are the seed's own, so they
 * cannot differ here: for a row production has, D5 holds them to production and the change list, and for an added row
 * templateMismatches holds them to its template row. The English bounds, critical limits, unit, reference basis and
 * reference source are left to finalRowMismatches, which compares them as the checks read them. markerPairs are the
 * seed pairs of the row's marker, its own first: compile-rows.js ageStateToLabel takes a state row's label from the
 * first that has one.
 */
export function pairMismatches(pair: SeedPair, d: FinalRowFields, markerPairs: SeedPair[], lib: CompileRowsLib): string[] {
  const rebuilt = lib.pairFromLoopRow(d, pair, markerPairs, () => {});
  const from = writtenFrom(lib);
  const out: string[] = [];
  for (const side of ["en", "es"] as const) {
    for (const c of new Set([...Object.keys(rebuilt[side]), ...Object.keys(pair[side])])) {
      if (side === "en" && COMPARED_AS_READ.has(c)) continue;
      const seed = pair[side][c];
      const written = rebuilt[side][c];
      if (canonical(seed) !== canonical(written)) out.push(`${c} ${shown(seed)} vs ${from.get(`${side}:${c}`) ?? "the compile's value"} ${shown(written)}`);
    }
  }
  return out;
}

/** The template row of an added row, and which rows it was picked among. */
export interface AddedRowTemplate {
  pair: SeedPair;
  /** "seed": the seed's rows of the marker that production has; "production": production's rows of the marker. */
  among: "seed" | "production";
}

/**
 * The template row G2 holds an added seed row to (a row whose database key production does not have), as
 * runner-verify-r4-repair.json finding 1 requires: the row compile-rows.js pickTemplate picks, with the label
 * compile-rows.js ageStateToLabel gives the final row, as compile.js picks a template (lines 148-149), among the seed's
 * rows of the same marker that production has, or, when there are none, among production's rows of the marker built
 * with compile-rows.js pairFromDbRow, as compile.js builds the pairs of a marker the seed lacks (line 144); null when
 * there is neither. The compile picks among the rows of the seed it read. These rows stand in for them because D5 holds
 * a seed row production has to production and the documented changes on every column, and production's rows are what
 * the compile reads for a marker the seed lacks. So the columns the compile copies from the template (the names, the
 * category, Tested_2x_Year, and the messages and notes of a final row that carries none) are held to rows the change
 * list documents, not to the added row itself, which the same hand edit could change with the migration. Where today's
 * seed and production differ on those columns, an added row of a marker whose every production row the pack replaces
 * is held to production's value, not to the seed's that the compile copied, and fails.
 */
export function addedRowTemplate(d: FinalRowFields, markerPairs: SeedPair[], productionKeys: Set<string>, production: ProductionRow[], categoryEsByEn: Record<string, unknown>, lib: CompileRowsLib): AddedRowTemplate | null {
  const fromSeed = markerPairs.filter((p) => productionKeys.has(lib.dbKey(lib.dbRowFromPair(p))));
  const among: AddedRowTemplate["among"] = fromSeed.length ? "seed" : "production";
  const candidates = fromSeed.length ? fromSeed : production.filter((r) => r.biomarker_key === d.marker_key).map((r) => lib.pairFromDbRow(r, categoryEsByEn, () => {}));
  if (!candidates.length) return null;
  const [labelEn] = lib.ageStateToLabel(d.age_group, d.physiological_state, candidates, () => {});
  const pair = lib.pickTemplate(candidates, String(d.sex), labelEn);
  return pair ? { pair, among } : null;
}

/**
 * Where an added seed pair differs from the pair the compile writes from its final row with its template row
 * (addedRowTemplate); [] when it holds it. Each entry names the column, the seed's value and the template row's.
 * compile-rows.js pairFromLoopRow rebuilds the pair from the final row twice, with the template row and, as
 * pairMismatches does, with the seed pair itself, and every column of both files is compared exactly (a text as
 * written, a list item by item in order). The rebuild with the seed pair keeps the seed's own value in every column
 * the compile copies from a template; such a column is listed when the template row gives another value. A column the
 * compile writes from the final row is the same in both rebuilds, and where the seed differs from it pairMismatches or
 * finalRowMismatches lists it, so no column is listed twice. markerPairs are the seed pairs of the row's marker, its
 * own first, as pairMismatches takes them.
 */
export function templateMismatches(pair: SeedPair, d: FinalRowFields, template: SeedPair, markerPairs: SeedPair[], lib: CompileRowsLib): string[] {
  const own = lib.pairFromLoopRow(d, pair, markerPairs, () => {});
  const written = lib.pairFromLoopRow(d, template, markerPairs, () => {});
  const out: string[] = [];
  for (const side of ["en", "es"] as const) {
    for (const c of new Set([...Object.keys(written[side]), ...Object.keys(pair[side])])) {
      const seed = canonical(pair[side][c]);
      if (seed === canonical(written[side][c]) || seed !== canonical(own[side][c])) continue;
      out.push(`${c} ${shown(pair[side][c])} vs ${shown(written[side][c])}`);
    }
  }
  return out;
}

export interface TraceInputs {
  rows: Row[];
  /** The rows of the two seed files by index (Row.index), whole: the pairs pairMismatches compares. */
  pairs: { en: RawEn[]; es: RawEs[] };
  /** docs/signoff/tools/lib/compile-rows.js (loadCompileRows). */
  compileRows: CompileRowsLib;
  families: FamiliesDoc;
  decisions: Record<string, { final_rows?: FinalRowFields[] } | null>;
  verifies: Record<string, { row_verdicts?: { row_key?: string; verdict?: string }[] } | null>;
  /** The State column of each seed row, by row index (compiled seeds carry it). */
  states?: Map<number, unknown>;
  /**
   * Production on every column, as D5 reads it (compile-baseline.js buildBaseline rows). A seed row whose database
   * key it does not have is an added row, also held to its template row (addedRowTemplate). G2 always gives it, and is
   * blocked when it cannot; a caller that does not give it knows no row to be added.
   */
  production?: ProductionRow[];
  /** Filled with the counts of the added rows traced to a final row: held to a template row, differing from it, without one. */
  stats?: TraceStats;
}

/** What traceRows counts of the added rows that reach a final row. */
export interface TraceStats {
  added_rows_held_to_template: number;
  added_rows_differing_from_template: number;
  added_rows_without_template: number;
}

/**
 * The trace failures of the seed rows: one per row ('row|<trace key>'), naming every way the row differs from its final
 * row and, for an added row, from its template row; or the missing family, decisions file, final row or verdict.
 */
export function traceRows(t: TraceInputs): Failure[] {
  const failures: Failure[] = [];
  const familyOf = new Map<string, string>();
  for (const [id, f] of Object.entries(t.families.families ?? {})) for (const k of f.keys ?? []) familyOf.set(k, id);
  const pairAt = (i: number): SeedPair => ({ en: t.pairs.en[i] ?? {}, es: t.pairs.es[i] ?? {} });
  const pairsOfMarker = new Map<string, number[]>();
  t.pairs.en.forEach((e, i) => {
    const k = slugify(String(e.Biomarker ?? ""));
    pairsOfMarker.set(k, [...(pairsOfMarker.get(k) ?? []), i]);
  });
  const lib = t.compileRows;
  const productionKeys = t.production ? new Set(t.production.map((p) => lib.dbKey(p))) : null;
  // The Spanish category of each English one, the first the seed gives, as compile.js builds it for pairFromDbRow (line 93).
  const categoryEsByEn: Record<string, unknown> = {};
  t.pairs.en.forEach((e, i) => {
    categoryEsByEn[String(e.Category)] ??= t.pairs.es[i]?.["Categoría"];
  });
  for (const r of t.rows) {
    if (t.families.non_rows && r.biomarker_key in t.families.non_rows) continue;
    const key = rowTraceKey(r, t.states?.get(r.index));
    const fam = familyOf.get(r.biomarker_key);
    if (!fam) {
      failures.push({ key: `row|${key}`, detail: "marker is in no family of families.json" });
      continue;
    }
    const dec = t.decisions[fam];
    if (!dec) {
      failures.push({ key: `row|${key}`, detail: `no decisions/${fam}.json` });
      continue;
    }
    const finals = (dec.final_rows ?? []).filter((d) => d && finalRowKey(d) === key);
    if (!finals.length) {
      failures.push({ key: `row|${key}`, detail: `not among the final_rows of decisions/${fam}.json` });
      continue;
    }
    // The compile keeps the later of two final rows with one key; the seed row must hold that row's bounds, unit,
    // reference basis and reference source, and every other column the compile writes from it.
    const final = finals[finals.length - 1];
    const own = pairAt(r.index);
    const markerPairs = [own, ...(pairsOfMarker.get(r.biomarker_key) ?? []).filter((i) => i !== r.index).map(pairAt)];
    const mismatches = [...finalRowMismatches(r, final), ...pairMismatches(own, final, markerPairs, lib)];
    const parts = mismatches.length ? [`differs from its final row in decisions/${fam}.json: ${mismatches.join("; ")}`] : [];
    // An added row (a database key production does not have) must also hold the columns the compile copies from its
    // template row, which the seed pair cannot be its own template for (runner-verify-r4-repair.json finding 1).
    if (productionKeys && t.production && !productionKeys.has(lib.dbKey(lib.dbRowFromPair(own)))) {
      const tpl = addedRowTemplate(final, markerPairs, productionKeys, t.production, categoryEsByEn, lib);
      if (!tpl) {
        if (t.stats) t.stats.added_rows_without_template++;
        parts.push(`has no template row: the seed holds no row of ${r.biomarker_key} that production has, and production holds none, so the columns the compile copies from a template row are held to nothing`);
      } else {
        if (t.stats) t.stats.added_rows_held_to_template++;
        const off = templateMismatches(own, final, tpl.pair, markerPairs, lib);
        const among = tpl.among === "seed" ? `the seed's rows of ${r.biomarker_key} that production has` : `production's rows of ${r.biomarker_key}, built with compile-rows.js pairFromDbRow`;
        if (off.length) {
          if (t.stats) t.stats.added_rows_differing_from_template++;
          parts.push(`differs from its template row ${lib.dbKey(lib.dbRowFromPair(tpl.pair))} (compile-rows.js pickTemplate among ${among}): ${off.join("; ")}`);
        }
      }
    }
    if (parts.length) {
      failures.push({ key: `row|${key}`, detail: parts.join("; and ") });
      continue;
    }
    const v = (t.verifies[fam]?.row_verdicts ?? []).find((x) => x.row_key === key);
    if (!v || !v.verdict) failures.push({ key: `row|${key}`, detail: `no verifier verdict in verify/${fam}.json` });
  }
  return failures;
}

const G2: Check = {
  id: "G2",
  group: "governance",
  title: "Traceability",
  how: "script",
  run(ctx) {
    const decDir = path.join(ctx.workDir, "decisions");
    const decFiles = fs.existsSync(decDir) ? fs.readdirSync(decDir).filter((f) => f.endsWith(".json")).sort() : [];
    if (!decFiles.length) return blocked("G2", `${rel(ctx, decDir)}/<family>.json (decisions)`);
    const seed = loadSeed(ctx.seedDir);
    if (!seed) return blocked("G2", `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json`);
    const families = ctx.load<FamiliesDoc>(path.join(ctx.workDir, "families.json")) ?? {};
    const decisions: TraceInputs["decisions"] = {};
    const verifies: TraceInputs["verifies"] = {};
    const failures: Failure[] = [];
    const req = createRequire(import.meta.url);
    const validator = req(path.join(ctx.root, "docs/signoff/tools/validate.js")) as { validateFile(kind: string, file: string, opts?: Record<string, unknown>): { errors: string[] } };
    for (const fam of Object.keys(families.families ?? {}).sort()) {
      const dFile = path.join(decDir, `${fam}.json`);
      if (!fs.existsSync(dFile)) continue;
      decisions[fam] = ctx.load(dFile);
      verifies[fam] = ctx.load(path.join(ctx.workDir, "verify", `${fam}.json`));
      for (const [kind, dir] of [["decision", "decisions"], ["verify", "verify"], ["research", "research"]] as const) {
        const file = path.join(ctx.workDir, dir, `${fam}.json`);
        const { errors } = validator.validateFile(kind, file, { workDir: ctx.workDir, families: path.join(ctx.workDir, "families.json") });
        if (errors.length) failures.push({ key: `file|${dir}/${fam}.json`, detail: `${errors.length} validation errors; first: ${errors[0]}` });
      }
    }
    const restrict = Array.isArray(ctx.thresholds.restrict_keys) ? new Set((ctx.thresholds.restrict_keys as unknown[]).map(String)) : null;
    const rows = restrict && restrict.size ? seed.rows.filter((r) => restrict.has(r.biomarker_key)) : seed.rows;
    const states = new Map<number, unknown>(rows.map((r) => [r.index, seed.en[r.index]?.State]));
    const compileRows = loadCompileRows(ctx.root);
    // Production on every column as D5 reads it (data.ts D5): compile-baseline.js buildBaseline of the gate1 snapshot and
    // supabase/migrations under the root. A seed row whose database key it does not have is an added row.
    const tools = loadCompileTools(ctx.root);
    const snapshot = path.resolve(ctx.root, PRODUCTION_SNAPSHOT);
    const production: ProductionRow[] | null = tools && fs.existsSync(snapshot) ? tools.buildBaseline({ snapshot, migrationsDir: path.resolve(ctx.root, "supabase/migrations") }).rows : null;
    const productionKeys = production ? new Set(production.map((p) => compileRows.dbKey(p))) : null;
    const added = productionKeys ? rows.filter((r) => !productionKeys.has(compileRows.dbKey(compileRows.dbRowFromPair({ en: seed.en[r.index] ?? {}, es: seed.es[r.index] ?? {} })))).length : 0;
    const stats: TraceStats = { added_rows_held_to_template: 0, added_rows_differing_from_template: 0, added_rows_without_template: 0 };
    const untraced = traceRows({ rows, pairs: { en: seed.en, es: seed.es }, compileRows, families, decisions, verifies, states, production: production ?? undefined, stats });
    failures.push(...untraced);
    let unknownStates = 0;
    let ledgerItems = 0;
    const ledgerDir = path.join(ctx.workDir, "ledger");
    for (const f of fs.existsSync(ledgerDir) ? fs.readdirSync(ledgerDir).filter((x) => x.endsWith(".json")).sort() : []) {
      const doc = ctx.load<{ issues?: { id?: string; status?: string }[] }>(path.join(ledgerDir, f));
      if (!doc) {
        failures.push({ key: `ledger|${f}`, detail: "not valid JSON" });
        continue;
      }
      for (const it of doc.issues ?? []) {
        ledgerItems++;
        if (!LEDGER_STATES.has(String(it.status))) {
          unknownStates++;
          failures.push({ key: `ledger|${f}|${it.id ?? "?"}`, detail: `unknown state "${it.status}"` });
        }
      }
    }
    const addedPart = production ? `${added} added rows, which production does not have, also held to their template rows` : "added rows not told apart: no production";
    const summary = `${untraced.length} untraced rows of ${rows.length} (${addedPart}); ${unknownStates} ledger items in unknown states of ${ledgerItems}; ${decFiles.length} decisions files`;
    const metrics = { rows: rows.length, added_rows: added, ...stats, untraced_rows: untraced.length, decisions_files: decFiles.length, ledger_items: ledgerItems, unknown_states: unknownStates, production_rows: production ? production.length : 0 };
    // Without production no row can be told to be added, so the rows the pack adds are held to nothing but themselves.
    if (!production && !failures.length) return { id: "G2", status: "blocked", summary, failures: [], blocked_on: `${PRODUCTION_SNAPSHOT} with docs/signoff/tools/lib/compile-baseline.js (production, to tell the rows the pack adds and hold them to their template rows)`, metrics };
    return result("G2", failures, summary, metrics);
  },
};

// ─── G3 determinism ───

const G3: Check = {
  id: "G3",
  group: "governance",
  title: "Determinism",
  how: "script",
  async run(ctx) {
    const { runDsrt } = await import("../lib/runner");
    const opts = { root: ctx.root, seedDir: ctx.seedDir, workDir: ctx.workDir, round: ctx.round, thresholds: ctx.thresholds, skipIds: ["G3"], gitCommit: "g3" };
    const a = sha256String(stableStringify(await runDsrt(opts)));
    const b = sha256String(stableStringify(await runDsrt(opts)));
    const failures = a === b ? [] : [{ key: "G3", detail: `two in-process runs gave different results: ${a.slice(0, 12)} vs ${b.slice(0, 12)}` }];
    return result("G3", failures, a === b ? `two in-process runs gave identical results (sha256 ${a.slice(0, 12)})` : "two in-process runs differ", { run_a: a, run_b: b });
  },
};

// ─── G4-G6 the pack ───

const PACK = "docs/signoff/pack";

export function packFiles(root: string): string[] {
  return listFiles(root, PACK).filter((f) => /\.(md|html|txt|json)$/i.test(f));
}

const G4: Check = {
  id: "G4",
  group: "governance",
  title: "Manifest",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.root, PACK, "manifest.json");
    const doc = ctx.load<{ rules_version?: string; files?: Record<string, string> | { path: string; sha256: string }[] }>(file);
    if (!doc) return blocked("G4", `${PACK}/manifest.json`);
    const entries: [string, string][] = Array.isArray(doc.files) ? doc.files.map((e) => [e.path, e.sha256]) : Object.entries(doc.files ?? {});
    const failures: Failure[] = [];
    if (!doc.rules_version) failures.push({ key: "rules_version", detail: "manifest has no rules_version id" });
    if (!entries.length) failures.push({ key: "files", detail: "manifest lists no files" });
    for (const [p, h] of entries) {
      const abs = path.resolve(ctx.root, p);
      if (!fs.existsSync(abs)) failures.push({ key: `file|${p}`, detail: "listed in the manifest but missing" });
      else if (sha256File(abs) !== h) failures.push({ key: `file|${p}`, detail: "sha256 differs from the manifest" });
    }
    const hashes = new Set(entries.map(([, h]) => h));
    const sheets = packFiles(ctx.root).filter((f) => /signature|firma/i.test(path.basename(f)));
    if (!sheets.length) failures.push({ key: "signature_sheets", detail: "no signature sheets in the pack" });
    for (const s of sheets) {
      const text = fs.readFileSync(path.join(ctx.root, s), "utf8");
      if (![...hashes].some((h) => h && text.includes(h))) failures.push({ key: `sheet|${s}`, detail: "references no manifest hash" });
    }
    return result("G4", failures, `${failures.length} manifest problems over ${entries.length} files and ${sheets.length} signature sheets`, { files: entries.length, signature_sheets: sheets.length });
  },
};

export const COVER_LABELS: { id: string; re: RegExp }[] = [
  { id: "scope_of_signature", re: /scope of (the )?signature|alcance de la firma/i },
  { id: "physician_role", re: /physician'?s role|role of the physician|papel del médico|rol del médico/i },
  { id: "ai_work_product", re: /AI work product|AI-generated|producto de trabajo (generado por|de) IA/i },
];

export function missingCoverLabels(text: string): string[] {
  const missing = COVER_LABELS.filter((l) => !l.re.test(text)).map((l) => l.id);
  if (/\bverdict|veredicto/i.test(text) && !/AI pre-review|pre-revisión por IA/i.test(text)) missing.push("ai_pre_review_label");
  return missing;
}

const G5: Check = {
  id: "G5",
  group: "governance",
  title: "Cover labels",
  how: "script",
  run(ctx) {
    const sheets = packFiles(ctx.root).filter((f) => /\.(md|html|txt)$/i.test(f));
    if (!sheets.length) return blocked("G5", `${PACK}/ (the pack's cover and sheets)`);
    const failures: Failure[] = [];
    for (const s of sheets) {
      const missing = missingCoverLabels(fs.readFileSync(path.join(ctx.root, s), "utf8"));
      if (missing.length) failures.push({ key: s, detail: `missing: ${missing.join(", ")}` });
    }
    return result("G5", failures, `${sheets.length - failures.length} of ${sheets.length} pack sheets carry the scope, role and AI-work-product labels`, { sheets: sheets.length });
  },
};

/** "pass 12, fail 3, blocked 4" style statements of DSRT counts in a text. */
export function statedCounts(text: string): { pass: number; fail: number; blocked: number }[] {
  const out: { pass: number; fail: number; blocked: number }[] = [];
  for (const m of text.matchAll(/pass\w*\s*[:=]?\s*(\d+)\D{1,12}fail\w*\s*[:=]?\s*(\d+)\D{1,12}blocked\s*[:=]?\s*(\d+)/gi)) out.push({ pass: +m[1], fail: +m[2], blocked: +m[3] });
  return out;
}

const G6: Check = {
  id: "G6",
  group: "governance",
  title: "Number consistency",
  how: "script+judge",
  run(ctx) {
    const sheets = packFiles(ctx.root).filter((f) => /\.(md|html|txt)$/i.test(f));
    if (!sheets.length) return blocked("G6", `${PACK}/ (the pack)`);
    const checksDir = path.join(ctx.workDir, "checks");
    const rounds = fs.existsSync(checksDir) ? fs.readdirSync(checksDir).map((f) => f.match(/^round-(\d+)\.json$/)).filter((m): m is RegExpMatchArray => !!m).map((m) => Number(m[1])).sort((a, b) => a - b) : [];
    const latest = rounds.length ? ctx.load<{ counts?: { pass: number; fail: number; blocked: number } }>(path.join(checksDir, `round-${rounds[rounds.length - 1]}.json`)) : null;
    const failures: Failure[] = [];
    if (latest?.counts) {
      for (const s of sheets) {
        for (const c of statedCounts(fs.readFileSync(path.join(ctx.root, s), "utf8"))) {
          if (c.pass !== latest.counts.pass || c.fail !== latest.counts.fail || c.blocked !== latest.counts.blocked) {
            failures.push({ key: `counts|${s}|${c.pass}-${c.fail}-${c.blocked}`, detail: `states pass ${c.pass}, fail ${c.fail}, blocked ${c.blocked}; round-${rounds[rounds.length - 1]}.json has ${latest.counts.pass}, ${latest.counts.fail}, ${latest.counts.blocked}` });
          }
        }
      }
    }
    const judgeDir = path.join(ctx.workDir, "judges", "final");
    const judgeFile = fs.existsSync(judgeDir) ? fs.readdirSync(judgeDir).filter((f) => /^G6.*\.json$/i.test(f)).sort().pop() : undefined;
    if (judgeFile) {
      const doc = ctx.load<{ mismatches?: Failure[] }>(path.join(judgeDir, judgeFile));
      for (const m of doc?.mismatches ?? []) failures.push({ key: `judge|${m.key}`, detail: m.detail });
    }
    if (!failures.length && !judgeFile) return blocked("G6", `${rel(ctx, judgeDir)}/G6-*.json (judge result on statements of the same quantity)`, { sheets: sheets.length });
    return result("G6", failures, `${failures.length} number mismatches across ${sheets.length} pack sheets`, { sheets: sheets.length, judge_file: judgeFile ?? "none" });
  },
};

// ─── G7 cold reader ───

export interface ColdReader {
  answers?: { id: string | number; answer?: string; pages?: (string | number)[]; correct?: boolean }[];
  reading_hours_total?: number;
  reading_hours_max_session?: number;
  sessions?: { hours: number }[];
}

export function judgeColdReader(doc: ColdReader, t: Record<string, unknown>): Failure[] {
  const failures: Failure[] = [];
  const need = Number(t.G7_questions_answered_min ?? 12);
  const totalMax = Number(t.G7_reading_hours_total_max ?? 10);
  const sessionMax = Number(t.G7_reading_hours_per_session_max ?? 3);
  const answers = doc.answers ?? [];
  const good = answers.filter((a) => a.answer && (a.pages ?? []).length && a.correct !== false);
  for (const a of answers) if (!(a.answer && (a.pages ?? []).length && a.correct !== false)) failures.push({ key: `q${a.id}`, detail: !a.answer ? "not answered" : !(a.pages ?? []).length ? "no page reference" : "answer marked incorrect" });
  if (good.length < need) failures.push({ key: "answered", detail: `${good.length} of ${need} questions answered with page references` });
  const total = doc.reading_hours_total ?? (doc.sessions ?? []).reduce((s, x) => s + x.hours, 0);
  const maxSession = doc.reading_hours_max_session ?? Math.max(0, ...(doc.sessions ?? []).map((x) => x.hours));
  if (!(total > 0)) failures.push({ key: "reading_time", detail: "no reading-time estimate" });
  if (total > totalMax) failures.push({ key: "reading_time_total", detail: `${total} h > ${totalMax} h` });
  if (maxSession > sessionMax) failures.push({ key: "reading_time_session", detail: `${maxSession} h in one session > ${sessionMax} h` });
  return failures;
}

const G7: Check = {
  id: "G7",
  group: "governance",
  title: "Cold reader",
  how: "judge",
  run(ctx) {
    const file = path.join(ctx.workDir, "cold-reader.json");
    const doc = ctx.load<ColdReader>(file);
    if (!doc) return blocked("G7", rel(ctx, file));
    const failures = judgeColdReader(doc, ctx.thresholds);
    return result("G7", failures, `${(doc.answers ?? []).length} answers; ${failures.length} problems`, { answers: (doc.answers ?? []).length });
  },
};

export const checks: Check[] = [G1, G2, G3, G4, G5, G6, G7];
