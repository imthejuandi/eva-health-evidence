/**
 * Q. Personas (Q1) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * Runs the synthetic people of scripts/signoff/fixtures/personas.json through the app's own code: the row picker
 * (reference-row.ts pickReferenceRows) on the seed rows, the classifier (zone-classifier.ts classifyZone) with the
 * row's message for each zone, score v2 (longevity-score.ts calculateLongevityScoreV2) and the version 3 adapter
 * (biological-age-v3-adapter.ts bioAgeV3Record, with the persona's conditions and supplements). Pass rules:
 *   1. no healthy persona sees a critical message (critical fields when the rows have them; until then the
 *      classifier's critical_low/critical_high codes, whose messages are the rows' Msg_Critical_* texts);
 *   2. no pregnant or lactating persona sees an optimal category, a score or a biological age;
 *   3. no persona outside the signed age range sees a biological age (20-79, or 20-84 once
 *      docs/signoff/work/v3/ages-80-84.json records passes: true);
 *   4. every healthy persona with more than half its markers non-optimal is a physician question, listed in
 *      docs/signoff/work/personas/physician-questions.json ({"<persona id>": "question"}).
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, Ctx, Failure } from "../types";
import { loadSeed, sortFailures, type Row } from "../lib/seed";
import { pickReferenceRows } from "../../../src/lib/biomarkers/reference-row";
import { classifyZone } from "../../../src/lib/biomarkers/zone-classifier";
import { calculateLongevityScoreV2 } from "../../../src/lib/biomarkers/longevity-score";
import { bioAgeV3Record, type BioAgeV3Record } from "../../../src/lib/biomarkers/biological-age-v3-adapter";
import type { SupplementEntry } from "../../../src/lib/biomarkers/supplements";
import { CODE_FOR_KEY, reviewedRows } from "./score";

type Metrics = Record<string, number | string | boolean>;
type Sex = "male" | "female";

export const PERSONAS_FIXTURE = "scripts/signoff/fixtures/personas.json";

export interface Persona {
  id: string;
  sex: Sex;
  age: number;
  group: string;
  healthy: boolean;
  note: string;
  state: { physiological_state: string; trimester?: number; hormone_therapy?: string; oral_contraception?: boolean };
  context: { fasting: boolean; collection_method: string; lab_source: string; conditions: string[]; medications: string[]; supplements: SupplementEntry[] };
  values: Record<string, number>;
}

export function loadPersonas(root: string): Persona[] | null {
  const file = path.resolve(root, PERSONAS_FIXTURE);
  if (!fs.existsSync(file)) return null;
  return (JSON.parse(fs.readFileSync(file, "utf8")) as { personas: Persona[] }).personas;
}

export interface PersonaRun {
  id: string;
  zones: Record<string, string>;
  missingMessages: string[];
  critical: string[];
  nonOptimalShare: number;
  score: number | null;
  ba: number | null;
  baReason: string | null;
}

const NOW = new Date("2026-11-06T12:00:00Z");

export function runPersona(p: Persona, seedRows: Row[]): PersonaRun {
  const { picked } = pickReferenceRows(seedRows, p.sex, p.age);
  const zones: Record<string, string> = {};
  const missingMessages: string[] = [];
  const critical: string[] = [];
  let classified = 0;
  let nonOptimal = 0;
  for (const [key, value] of Object.entries(p.values).sort(([a], [b]) => a.localeCompare(b))) {
    const r = picked.get(key);
    if (!r) continue;
    const z = classifyZone(value, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high);
    zones[key] = z;
    if (z === "unclassified") continue;
    classified++;
    if (z !== "optimal") nonOptimal++;
    const msg = r.msg[z as keyof Row["msg"]];
    if (!msg?.en || !msg?.es) missingMessages.push(`${key}:${z}`);
    const hasCriticalFields = r.critical_low != null || r.critical_high != null;
    const isCrit = hasCriticalFields ? (r.critical_low != null && value < r.critical_low) || (r.critical_high != null && value > r.critical_high) : z === "critical_low" || z === "critical_high";
    if (isCrit) critical.push(`${key}=${value} (${z})`);
  }
  const inputs = Object.entries(p.values)
    .filter(([k]) => CODE_FOR_KEY[k])
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, value]) => ({ code: CODE_FOR_KEY[k], value }));
  const score = calculateLongevityScoreV2(inputs, p.sex, p.age, reviewedRows(seedRows));
  const units: Record<string, string> = Object.fromEntries(seedRows.map((r) => [r.biomarker_key, r.unit_en]));
  const rec: BioAgeV3Record = bioAgeV3Record({
    values: Object.entries(p.values)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => ({ biomarker_key: k, value: v, unit: units[k] ?? null })),
    drawDate: "2026-11-01",
    otherResults: [],
    dateOfBirth: `${2026 - p.age}-01-15`,
    sex: p.sex,
    conditionKeys: p.context.conditions,
    supplements: p.context.supplements,
    now: NOW,
    labSource: p.context.lab_source,
    collectionMethod: p.context.collection_method,
  });
  return {
    id: p.id,
    zones,
    missingMessages,
    critical,
    nonOptimalShare: classified ? nonOptimal / classified : 0,
    score: score.longevityScore >= 0 ? score.longevityScore : null,
    ba: rec.ba,
    baReason: rec.reason,
  };
}

const Q1: Check = {
  id: "Q1",
  group: "personas",
  title: "Personas",
  how: "script",
  run(ctx: Ctx) {
    const personas = loadPersonas(ctx.root);
    if (!personas) return { id: "Q1", status: "blocked", summary: `blocked: ${PERSONAS_FIXTURE} is missing`, failures: [], blocked_on: PERSONAS_FIXTURE };
    const seed = loadSeed(ctx.seedDir);
    if (!seed) return { id: "Q1", status: "blocked", summary: "blocked: seed files missing", failures: [], blocked_on: "seed files" };
    const min = Number(ctx.thresholds.Q1_personas_min ?? 40);
    const share = Number(ctx.thresholds.Q1_physician_question_non_optimal_share ?? 0.5);
    const b5 = ctx.load<{ passes?: boolean }>(path.join(ctx.workDir, "v3", "ages-80-84.json"));
    const signed: [number, number] = b5?.passes === true ? [20, 84] : ((ctx.thresholds.B5_fallback_age_range as [number, number] | undefined) ?? [20, 79]);
    const questions = ctx.load<Record<string, string>>(path.join(ctx.workDir, "personas", "physician-questions.json")) ?? {};
    const failures: Failure[] = [];
    if (personas.length < min) failures.push({ key: "fixture|size", detail: `${personas.length} personas, at least ${min}` });
    const counts = { healthy_critical: 0, pregnant_shown: 0, out_of_range_ba: 0, physician_questions_missing: 0, missing_messages: 0 };
    for (const p of [...personas].sort((a, b) => a.id.localeCompare(b.id))) {
      const run = runPersona(p, seed.rows);
      counts.missing_messages += run.missingMessages.length;
      if (p.healthy && run.critical.length) {
        counts.healthy_critical++;
        failures.push({ key: `${p.id}|healthy_critical`, detail: `healthy persona sees ${run.critical.length} critical messages: ${run.critical.slice(0, 4).join(", ")}${run.critical.length > 4 ? ", ..." : ""}` });
      }
      if (p.state.physiological_state === "pregnancy" || p.state.physiological_state === "lactation") {
        const optimal = Object.entries(run.zones).filter(([, z]) => z === "optimal").length;
        const shown = [optimal ? `${optimal} optimal categories` : "", run.score != null ? `score ${run.score}` : "", run.ba != null ? `biological age ${run.ba.toFixed(1)}` : ""].filter(Boolean);
        if (shown.length) {
          counts.pregnant_shown++;
          failures.push({ key: `${p.id}|state_shown`, detail: `${p.state.physiological_state} persona sees ${shown.join(", ")}` });
        }
      }
      if ((p.age < signed[0] || p.age > signed[1]) && run.ba != null) {
        counts.out_of_range_ba++;
        failures.push({ key: `${p.id}|age_range`, detail: `age ${p.age} outside the signed range ${signed[0]}-${signed[1]} sees a biological age of ${run.ba.toFixed(1)}` });
      }
      if (p.healthy && run.nonOptimalShare > share && !(questions[p.id] && questions[p.id].trim())) {
        counts.physician_questions_missing++;
        failures.push({ key: `${p.id}|non_optimal`, detail: `healthy persona with ${(run.nonOptimalShare * 100).toFixed(0)}% of markers non-optimal is not a physician question` });
      }
    }
    const critSource = seed.rows.some((r) => r.critical_low != null || r.critical_high != null) ? "critical fields" : "classifier out-of-range codes (no critical fields in the seed)";
    const metrics: Metrics = { personas: personas.length, signed_range: `${signed[0]}-${signed[1]}`, critical_source: critSource, ...counts };
    return {
      id: "Q1",
      status: failures.length ? "fail" : "pass",
      summary: `${personas.length} personas: ${counts.healthy_critical} healthy see a critical message; ${counts.pregnant_shown} pregnant or lactating see an optimal category, score or biological age; ${counts.out_of_range_ba} outside the signed range see a biological age; ${counts.physician_questions_missing} mostly non-optimal healthy personas without a physician question`,
      failures: sortFailures(failures),
      metrics,
    };
  },
};

export const checks: Check[] = [Q1];
