/**
 * G8, AI pre-review, of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * Reads the final cold panel's verdicts, docs/signoff/work/judges/final/*.json (judge.schema.json: one file per
 * lens and shard), and the ledgers, docs/signoff/work/ledger/*.json (ledger.schema.json). Passes when:
 *   - all six lenses J1-J6 returned a verdict;
 *   - no blocking issue of the final panel is confirmed after refutation (a ledger issue raised by a final judge file
 *     or by the cold panel, with status confirmed or open, counts as confirmed; refuted, fixed and closed do not;
 *     a final blocking issue with no ledger entry counts as not yet refuted);
 *   - open physician questions are within the caps: part A (the family ledgers), part B (v3) and part C (score):
 *     G8_open_questions_cap_part_a/b/c.
 * Blocked while docs/signoff/work/judges/final/ holds no judge file.
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, Ctx, Failure } from "../types";
import { sortFailures } from "../lib/seed";

type Metrics = Record<string, number | string | boolean>;
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");

interface JudgeIssue {
  id?: string;
  family: string;
  row_key: string | null;
  check_id: string;
  value_disputed: string;
}
interface JudgeDoc {
  lens: string;
  shard: string;
  blocking?: JudgeIssue[];
}
interface LedgerIssue {
  id: string;
  source: { judge_file: string; lens: string; round: number };
  family: string;
  severity: string;
  status: string;
  summary: string;
}

export const LENSES = ["J1", "J2", "J3", "J4", "J5", "J6"];
const CONFIRMED = new Set(["confirmed", "open"]);

function jsonFiles(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".json"))
    .sort()
    .map((f) => path.join(dir, f));
}

export function partOf(family: string): "a" | "b" | "c" {
  if (family === "v3") return "b";
  if (family === "score" || family === "coherence") return "c";
  return "a";
}

const G8: Check = {
  id: "G8",
  group: "governance",
  title: "AI pre-review",
  how: "judge",
  run(ctx: Ctx) {
    const dir = path.join(ctx.workDir, "judges", "final");
    const files = jsonFiles(dir);
    const judges: { file: string; doc: JudgeDoc }[] = [];
    for (const f of files) {
      const doc = ctx.load<JudgeDoc>(f);
      if (doc && typeof doc.lens === "string") judges.push({ file: rel(ctx, f), doc });
    }
    if (!judges.length) return { id: "G8", status: "blocked", summary: `blocked: ${rel(ctx, dir)}/*.json is missing`, failures: [], blocked_on: `${rel(ctx, dir)}/*.json` };
    const ledgers: LedgerIssue[] = [];
    for (const f of jsonFiles(path.join(ctx.workDir, "ledger"))) {
      const doc = ctx.load<{ issues?: LedgerIssue[] }>(f);
      ledgers.push(...(doc?.issues ?? []));
    }
    const failures: Failure[] = [];
    const lensesSeen = new Set(judges.map((j) => j.doc.lens));
    for (const l of LENSES) if (!lensesSeen.has(l)) failures.push({ key: `lens|${l}`, detail: "no final verdict from this lens" });
    // Blocking issues of the final panel against the ledger.
    const finalFiles = new Set(judges.map((j) => j.file));
    const byId = new Map(ledgers.map((i) => [i.id, i]));
    let confirmed = 0;
    let finalBlocking = 0;
    for (const j of judges) {
      (j.doc.blocking ?? []).forEach((b, n) => {
        finalBlocking++;
        const entry = b.id ? byId.get(b.id) : undefined;
        if (!entry) {
          confirmed++;
          failures.push({ key: `blocking|${j.doc.lens}|${j.doc.shard}|${b.id ?? n}`, detail: `${b.family} ${b.row_key ?? ""} ${b.check_id}: ${b.value_disputed} (not in the ledger, not refuted)` });
        } else if (CONFIRMED.has(entry.status)) {
          confirmed++;
          failures.push({ key: `blocking|${j.doc.lens}|${j.doc.shard}|${b.id}`, detail: `${entry.family} ${entry.summary} (ledger status ${entry.status})` });
        }
      });
    }
    for (const i of ledgers) {
      if (i.severity !== "blocking" || !CONFIRMED.has(i.status)) continue;
      if (!(finalFiles.has(i.source.judge_file) || i.source.lens === "cold_panel")) continue;
      if (failures.some((f) => f.key.endsWith(`|${i.id}`))) continue;
      confirmed++;
      failures.push({ key: `ledger|${i.id}`, detail: `${i.family} ${i.summary} (status ${i.status})` });
    }
    // Physician question caps.
    const caps = { a: Number(ctx.thresholds.G8_open_questions_cap_part_a ?? 20), b: Number(ctx.thresholds.G8_open_questions_cap_part_b ?? 8), c: Number(ctx.thresholds.G8_open_questions_cap_part_c ?? 5) };
    const open = { a: 0, b: 0, c: 0 };
    for (const i of ledgers) if (i.status === "physician_question") open[partOf(i.family)]++;
    for (const p of ["a", "b", "c"] as const) if (open[p] > caps[p]) failures.push({ key: `questions|part_${p}`, detail: `${open[p]} open physician questions, cap ${caps[p]}` });
    const metrics: Metrics = { judge_files: judges.length, lenses: lensesSeen.size, final_blocking: finalBlocking, confirmed_blocking: confirmed, questions_a: open.a, questions_b: open.b, questions_c: open.c, ledger_issues: ledgers.length };
    return { id: "G8", status: failures.length ? "fail" : "pass", summary: `${confirmed} confirmed blocking issues from ${lensesSeen.size} of 6 lenses; open questions A ${open.a}/${caps.a}, B ${open.b}/${caps.b}, C ${open.c}/${caps.c}`, failures: sortFailures(failures), metrics };
  },
};

export const checks: Check[] = [G8];
