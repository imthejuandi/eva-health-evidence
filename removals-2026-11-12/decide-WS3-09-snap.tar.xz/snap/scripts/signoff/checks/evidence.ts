/**
 * E. Evidence (E1-E6) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * Per family of docs/signoff/work/families.json the loop writes research/<family>.json (author),
 * verify/<family>.json (verifier) and decisions/<family>.json (fixer). The checks read them:
 * E1 validates every file that exists with docs/signoff/tools/validate.js, holds every evidence record's quote to
 *    at most 60 words, holds every age, sex or state split of each file's rows to a record linked to it under the
 *    split's name (splitsWithoutRecord; validate.js holds the bounds to theirs; rowSplits: a male or female row is
 *    split by sex when the other sex has a row in the same state, or, for a row in no state, in any state), and asks a
 *    number in the quote of each record that supports a bound or split E1 names (an optimal bound, a reference bound
 *    with a non-laboratory basis, a split the row has: numberScope);
 * E2 runs docs/signoff/tools/quote-check.js --offline against docs/signoff/work/sources-cache;
 * E3 applies the grade rules to the final rows (decisions, else verify) and docs/signoff/work/grade-c-table.json;
 * E4 checks the age-split statements and nadir shifts; E5 reads docs/signoff/work/audit/round-<n>-result.json;
 * E6 compares the compiled rows of the locked decisions and the creatine rule with their values on 2026-11-06.
 * A check is blocked while the files it reads do not exist.
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";
import type { Check, CheckResult, Ctx, Failure } from "../types";
import { loadSeed, sortFailures, type Row } from "../lib/seed";
import { CREATINE_CREATININE_RISE, CREATINE_SATURATING_DOSE_G, creatineCreatinineDivisor } from "../../../src/lib/biomarkers/supplements";

type Metrics = Record<string, number | string | boolean>;
const result = (id: string, failures: Failure[], summary: string, metrics?: Metrics): CheckResult => ({
  id,
  status: failures.length ? "fail" : "pass",
  summary,
  failures: sortFailures(failures),
  ...(metrics ? { metrics } : {}),
});
const blocked = (id: string, on: string, metrics?: Metrics): CheckResult => ({ id, status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on, ...(metrics ? { metrics } : {}) });
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");

// ─── Loop files ───

export interface EvidenceRecord {
  id: string;
  supports?: { row_key: string; bound: string }[];
  identifier?: { type: string; value: string };
  quote?: string;
  year?: number | null;
  band_rule?: string;
  basis_class?: string;
  proposed_grade?: string;
  age_stratified_statement?: string;
  [k: string]: unknown;
}
export interface LoopRow {
  marker_key: string;
  sex: string;
  age_group: string;
  physiological_state: string;
  reference_low: number | null;
  reference_high: number | null;
  reference_basis?: string;
  optimal_low: number | null;
  optimal_high: number | null;
  band_rule?: string;
  grade?: string;
  grade_c_table_entry?: boolean;
  [k: string]: unknown;
}
interface ResearchDoc {
  family?: string;
  rows?: LoopRow[];
  evidence?: EvidenceRecord[];
  age_splits?: { marker_key: string; sex: string; physiological_state: string; split_at: number; nadir_shift_pct: number | null; evidence_above_70: boolean; justification: string }[];
  locked_decision_questions?: { id: string; locked_decision: string; marker_key: string; evidence_ids: string[] }[];
  physician_questions?: { id: string; row_key: string | null; question: string }[];
}
interface VerifyDoc {
  family?: string;
  row_verdicts?: { row_key: string; verdict: string; grade: string }[];
  evidence_verdicts?: { evidence_id: string; verdict: string; grade: string; quote_found: boolean | null }[];
  final_rows?: LoopRow[];
  evidence?: EvidenceRecord[];
  physician_questions?: { id: string; row_key: string | null; question: string }[];
}
interface DecisionDoc {
  family?: string;
  final_rows?: LoopRow[];
  evidence?: EvidenceRecord[];
  physician_questions?: { id: string; row_key: string | null; question: string }[];
}

export interface FamilyFiles {
  family: string;
  research: ResearchDoc | null;
  verify: VerifyDoc | null;
  decision: DecisionDoc | null;
  paths: { research: string; verify: string; decision: string };
}

/** The families to look at: all of families.json, or those holding a key of --families' restriction. */
export function familiesFor(ctx: Ctx): string[] | null {
  const doc = ctx.load<{ families?: Record<string, { keys?: string[] }> }>(path.join(ctx.workDir, "families.json"));
  if (!doc?.families) return null;
  const restrict = ctx.thresholds.restrict_keys;
  const set = Array.isArray(restrict) && restrict.length ? new Set(restrict.map(String)) : null;
  return Object.entries(doc.families)
    .filter(([, f]) => !set || (f.keys ?? []).some((k) => set.has(k)))
    .map(([id]) => id)
    .sort();
}

export function loadFamilyFiles(ctx: Ctx, family: string): FamilyFiles {
  const paths = {
    research: path.join(ctx.workDir, "research", `${family}.json`),
    verify: path.join(ctx.workDir, "verify", `${family}.json`),
    decision: path.join(ctx.workDir, "decisions", `${family}.json`),
  };
  return {
    family,
    research: ctx.load<ResearchDoc>(paths.research),
    verify: ctx.load<VerifyDoc>(paths.verify),
    decision: ctx.load<DecisionDoc>(paths.decision),
    paths,
  };
}

export function loopRowKey(r: Pick<LoopRow, "marker_key" | "sex" | "age_group" | "physiological_state">): string {
  return `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;
}

/** The family's final rows: the fixer's when present, else the verifier's. */
export function finalRows(f: FamilyFiles): { rows: LoopRow[]; from: "decision" | "verify" | null } {
  if (f.decision?.final_rows?.length) return { rows: f.decision.final_rows, from: "decision" };
  if (f.verify?.final_rows?.length) return { rows: f.verify.final_rows, from: "verify" };
  return { rows: [], from: null };
}

export function allEvidence(f: FamilyFiles): Map<string, EvidenceRecord> {
  const m = new Map<string, EvidenceRecord>();
  for (const doc of [f.research, f.verify, f.decision]) for (const e of doc?.evidence ?? []) m.set(e.id, e);
  return m;
}

const wordCount = (s: string) => (s.trim() ? s.trim().split(/\s+/).length : 0);

/** All families of the run with their files, or why the check is blocked. */
function collect(ctx: Ctx, need: "research" | "verify" | "final"): { files: FamilyFiles[]; missing: string[] } | string {
  const families = familiesFor(ctx);
  if (!families) return rel(ctx, path.join(ctx.workDir, "families.json"));
  const files: FamilyFiles[] = [];
  const missing: string[] = [];
  for (const fam of families) {
    const f = loadFamilyFiles(ctx, fam);
    const has = need === "research" ? !!f.research : need === "verify" ? !!f.verify : finalRows(f).from !== null;
    if (has) files.push(f);
    else missing.push(fam);
  }
  return { files, missing };
}

const missingLabel = (ctx: Ctx, dir: string, missing: string[]) =>
  `${rel(ctx, path.join(ctx.workDir, dir))}/<family>.json for ${missing.length} families (${missing.slice(0, 5).join(", ")}${missing.length > 5 ? ", ..." : ""})`;

// ─── E1 record completeness ───

/** The bounds E1 names as needing a record (ACCEPTANCE-TEST.md line 39), by the support's bound name (common.schema.json bound_name). */
const OPTIMAL_BOUNDS = ["optimal_low", "optimal_high"] as const;
const REFERENCE_BOUNDS = ["reference_low", "reference_high"] as const;
/** The reference basis that is the laboratory's own interval: a reference bound on any other basis needs a record (as row-checks.js checkBoundCoverage asks). */
const LABORATORY_BASIS = "echevarne_interval";

/** The splits E1 names ("every age, sex or state split"), by the name a record's supports[] link gives one (common.schema.json bound_name). */
export type SplitName = "age_split" | "sex_split" | "state_split";
export interface RowSplit {
  /** The row's key, marker_key|sex|age_group|physiological_state. */
  key: string;
  split: SplitName;
  /** Why the row is split that way, for a failure detail. */
  why: string;
}

/**
 * The age, sex and state splits of one file's rows (ACCEPTANCE-TEST.md line 39: "every age, sex or state split has a
 * record"). A row is split by age when its marker, sex and state group holds another age band in the same file; by
 * sex when it is a male or female row and its marker has a row of the other sex in the same state in the same file,
 * or, for a row whose physiological_state is none, a row of the other sex in any state (a male none row beside female
 * cycle-phase or postmenopausal rows only gives men a range of their own); by state when its physiological_state is a
 * state other than none. A row that is none of these (an "All Adults" row of a marker that keeps one row, a
 * both-sexes row) is not split, whatever links its records carry.
 */
export function rowSplits(rows: readonly unknown[] | null | undefined): RowSplit[] {
  const list = (Array.isArray(rows) ? rows : []).filter((r): r is LoopRow => !!r && typeof r === "object");
  const bands = new Map<string, Set<string>>();
  const sexes = new Map<string, Set<string>>();
  const anySex = new Map<string, Set<string>>();
  const add = (m: Map<string, Set<string>>, k: string, v: string) => (m.get(k) ?? m.set(k, new Set()).get(k)!).add(v);
  for (const r of list) {
    add(bands, `${r.marker_key}|${r.sex}|${r.physiological_state}`, String(r.age_group));
    add(sexes, `${r.marker_key}|${r.physiological_state}`, String(r.sex));
    add(anySex, String(r.marker_key), String(r.sex));
  }
  const out: RowSplit[] = [];
  const seen = new Set<string>();
  const push = (s: RowSplit) => {
    if (seen.has(`${s.key}#${s.split}`)) return;
    seen.add(`${s.key}#${s.split}`);
    out.push(s);
  };
  for (const r of list) {
    const key = loopRowKey(r);
    const group = `${r.marker_key}|${r.sex}|${r.physiological_state}`;
    const others = [...bands.get(group)!].filter((a) => a !== String(r.age_group)).sort();
    if (others.length) push({ key, split: "age_split", why: `the file's ${group} rows have another age band (${others.join(", ")})` });
    const other = r.sex === "male" ? "female" : r.sex === "female" ? "male" : null;
    if (other && sexes.get(`${r.marker_key}|${r.physiological_state}`)!.has(other)) push({ key, split: "sex_split", why: `the file has a ${other} row of ${r.marker_key} in the same state (${r.physiological_state})` });
    else if (other && r.physiological_state === "none" && anySex.get(String(r.marker_key))!.has(other)) push({ key, split: "sex_split", why: `the file has ${other} rows of ${r.marker_key} only in other states` });
    if (typeof r.physiological_state === "string" && r.physiological_state !== "none") push({ key, split: "state_split", why: `its physiological_state is ${r.physiological_state}` });
  }
  return out;
}

/**
 * The bounds and splits whose records E1 asks a quote containing the number of (ACCEPTANCE-TEST.md line 39: "Every
 * optimal bound, every reference bound with a non-laboratory basis, and every age, sex or state split has a record:
 * identifier, verbatim quote of at most 60 words containing the number, ..."), as "row_key#bound" keys: for each row of
 * the family's files (research rows, the verifier's and the fixer's final rows), each optimal bound it has, each
 * reference bound it has when its reference_basis is not the laboratory interval, and each split of the row
 * (rowSplits: an age, sex or state split the row has in its file). A record supports a row's bound or split through its
 * supports[] links (row_key and bound), the links validate.js counts as a bound's records (row-checks.js
 * checkBoundCoverage). A record none of whose links names one of these, such as one for a class, method,
 * pre-analytical rule, critical limit, action limit or reference change value, or a split link to a row that is not
 * split that way, is outside the rule, as row-checks.js checkEvidence already treats a record for a class, method or
 * pre-analytical rule.
 */
export function numberScope(f: Pick<FamilyFiles, "research" | "verify" | "decision">): Set<string> {
  const scope = new Set<string>();
  for (const rows of [f.research?.rows, f.verify?.final_rows, f.decision?.final_rows]) {
    for (const r of Array.isArray(rows) ? rows : []) {
      if (!r || typeof r !== "object") continue;
      const k = loopRowKey(r);
      for (const b of OPTIMAL_BOUNDS) if (r[b] != null) scope.add(`${k}#${b}`);
      if (r.reference_basis !== LABORATORY_BASIS) for (const b of REFERENCE_BOUNDS) if (r[b] != null) scope.add(`${k}#${b}`);
    }
    for (const s of rowSplits(rows)) scope.add(`${s.key}#${s.split}`);
  }
  return scope;
}

/**
 * The splits of each of the family's files that no record is linked to under the split's name ("every age, sex or
 * state split has a record", ACCEPTANCE-TEST.md line 39), as row-checks.js checkBoundCoverage holds every bound that
 * needs a record to one: a split row needs a record whose supports[] holds {row_key: the row's key, bound: the
 * split's name}. The records a file's rows may be supported by are the ones validate.js gives checkBoundCoverage for
 * that file: the research file's own for its rows, the research and verify files' for the verifier's final rows, and
 * those with the decision file's for the fixer's.
 */
export function splitsWithoutRecord(f: Pick<FamilyFiles, "research" | "verify" | "decision">): { kind: "research" | "verify" | "decision"; split: RowSplit; records: string }[] {
  const evidenceOf = (doc: { evidence?: EvidenceRecord[] } | null) => (Array.isArray(doc?.evidence) ? doc.evidence : []);
  const files: ["research" | "verify" | "decision", unknown, EvidenceRecord[], string][] = [
    ["research", f.research?.rows, evidenceOf(f.research), "the research file's records"],
    ["verify", f.verify?.final_rows, [...evidenceOf(f.research), ...evidenceOf(f.verify)], "the research and verify files' records"],
    ["decision", f.decision?.final_rows, [...evidenceOf(f.research), ...evidenceOf(f.verify), ...evidenceOf(f.decision)], "the research, verify and decision files' records"],
  ];
  const out: { kind: "research" | "verify" | "decision"; split: RowSplit; records: string }[] = [];
  for (const [kind, rows, records, which] of files) {
    if (!Array.isArray(rows)) continue;
    const linked = new Set(records.flatMap((e) => (e && Array.isArray(e.supports) ? e.supports : []).filter((s) => s && typeof s === "object").map((s) => `${s.row_key}#${s.bound}`)));
    for (const s of rowSplits(rows)) if (!linked.has(`${s.key}#${s.split}`)) out.push({ kind, split: s, records: which });
  }
  return out;
}

/** The number of age, sex and state splits of the family's files' rows (rowSplits, per file). */
export function splitCount(f: Pick<FamilyFiles, "research" | "verify" | "decision">): number {
  return [f.research?.rows, f.verify?.final_rows, f.decision?.final_rows].reduce((n, rows) => n + (Array.isArray(rows) ? rowSplits(rows).length : 0), 0);
}

/** The links of a record that name a bound or split of numberScope, as "row_key bound". */
export function scopedSupports(e: EvidenceRecord, scope: Set<string>): string[] {
  return (Array.isArray(e.supports) ? e.supports : []).filter((s) => s && scope.has(`${s.row_key}#${s.bound}`)).map((s) => `${s.row_key} ${s.bound}`);
}

const E1: Check = {
  id: "E1",
  group: "evidence",
  title: "Evidence records complete and schema-valid",
  how: "script",
  run(ctx) {
    const c = collect(ctx, "research");
    if (typeof c === "string") return blocked("E1", c);
    if (!c.files.length) return blocked("E1", missingLabel(ctx, "research", c.missing), { families_missing: c.missing.length });
    const req = createRequire(path.resolve(ctx.root, "docs/signoff/tools/validate.js"));
    const validator = req(path.resolve(ctx.root, "docs/signoff/tools/validate.js")) as {
      validateFile(kind: string, file: string, opts?: { workDir?: string; families?: string }): { errors: string[]; warnings: string[] };
    };
    const maxWords = Number(ctx.thresholds.E1_quote_max_words ?? 60);
    const failures: Failure[] = [];
    let records = 0;
    let filesValidated = 0;
    let inScope = 0;
    let splits = 0;
    let splitsUncovered = 0;
    const outsideWithoutNumber: string[] = [];
    for (const f of c.files) {
      const kinds: [string, string, unknown][] = [
        ["research", f.paths.research, f.research],
        ["verify", f.paths.verify, f.verify],
        ["decision", f.paths.decision, f.decision],
      ];
      for (const [kind, file, doc] of kinds) {
        if (!doc) continue;
        filesValidated++;
        const v = validator.validateFile(kind, file, { workDir: ctx.workDir, families: path.join(ctx.workDir, "families.json") });
        v.errors.forEach((e, i) => failures.push({ key: `${f.family}|${kind}|${String(i).padStart(3, "0")}`, detail: e }));
      }
      // Every age, sex or state split of each file's rows has a record linked to it under the split's name.
      splits += splitCount(f);
      for (const { kind, split, records: which } of splitsWithoutRecord(f)) {
        splitsUncovered++;
        failures.push({ key: `${f.family}|${kind}|${split.key}|${split.split}`, detail: `split by ${split.split.replace(/_split$/, "")} (${split.why}) without a record: none of ${which} has a supports[] link {row_key: "${split.key}", bound: "${split.split}"}, and E1 asks a record of every age, sex or state split` });
      }
      // Every record's quote is at most 60 words; the quote of a record that supports a bound or split E1 names holds a number.
      const scope = numberScope(f);
      for (const e of allEvidence(f).values()) {
        records++;
        const words = wordCount(String(e.quote ?? ""));
        if (words > maxWords) failures.push({ key: `${f.family}|evidence|${e.id}`, detail: `quote has ${words} words (max ${maxWords})` });
        const links = scopedSupports(e, scope);
        if (links.length) inScope++;
        if (/\d/.test(String(e.quote ?? ""))) continue;
        if (links.length) failures.push({ key: `${f.family}|evidence|${e.id}|number`, detail: `quote contains no number; the record supports ${links.join(", ")}, which E1 asks a quote containing the number for` });
        else outsideWithoutNumber.push(`${f.family}|${e.id}`);
      }
    }
    const metrics: Metrics = {
      families_with_research: c.files.length,
      families_missing: c.missing.length,
      files_validated: filesValidated,
      evidence_records: records,
      number_scope_records: inScope,
      outside_scope_without_number: outsideWithoutNumber.length,
      outside_scope_without_number_ids: outsideWithoutNumber.sort().join(","),
      splits,
      splits_without_record: splitsUncovered,
    };
    if (!failures.length && c.missing.length) return blocked("E1", missingLabel(ctx, "research", c.missing), metrics);
    return result("E1", failures, `${failures.length} problems in ${filesValidated} files, ${records} evidence records (${inScope} support a bound or split whose quote must hold the number; ${outsideWithoutNumber.length} others hold none, which E1 does not ask), ${splits} age, sex or state splits (${splitsUncovered} without a record linked under the split's name); ${c.missing.length} families without research`, metrics);
  },
};

// ─── E2 quotes against cached sources ───

interface QuoteReport {
  results: { evidence_id: string; status: string; score: number; identifier: string | null; error: string | null }[];
  summary: { total: number; found: number; weak: number; not_found: number; unopenable: number };
}

export function runQuoteCheck(root: string, file: string, cacheDir: string): QuoteReport | string {
  const tool = path.resolve(root, "docs/signoff/tools/quote-check.js");
  let stdout: string;
  try {
    stdout = execFileSync(process.execPath, [tool, file, "--offline", "--cache-dir", cacheDir], { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], maxBuffer: 64 * 1024 * 1024 });
  } catch (err) {
    const e = err as { stdout?: string; status?: number; message: string };
    if (e.status === 1 && e.stdout) stdout = e.stdout;
    else return `quote-check failed: ${String(e.message).split("\n")[0]}`;
  }
  try {
    return JSON.parse(stdout) as QuoteReport;
  } catch {
    return "quote-check output is not JSON";
  }
}

const E2: Check = {
  id: "E2",
  group: "evidence",
  title: "Quotes confirmed against cached source text",
  how: "script",
  run(ctx) {
    const tool = path.resolve(ctx.root, "docs/signoff/tools/quote-check.js");
    if (!fs.existsSync(tool)) return blocked("E2", "docs/signoff/tools/quote-check.js");
    const cacheDir = path.join(ctx.workDir, "sources-cache");
    if (!fs.existsSync(cacheDir)) return blocked("E2", rel(ctx, cacheDir));
    const c = collect(ctx, "research");
    if (typeof c === "string") return blocked("E2", c);
    if (!c.files.length) return blocked("E2", missingLabel(ctx, "research", c.missing));
    const minShare = Number(ctx.thresholds.E2_quote_found_min_share ?? 0.98);
    const failures: Failure[] = [];
    let total = 0;
    let found = 0;
    let unopenable = 0;
    for (const f of c.files) {
      const grades = new Map((f.verify?.evidence_verdicts ?? []).map((v) => [v.evidence_id, v.grade]));
      const seen = new Set<string>();
      for (const [kind, file, doc] of [["research", f.paths.research, f.research], ["verify", f.paths.verify, f.verify], ["decision", f.paths.decision, f.decision]] as const) {
        if (!doc) continue;
        const rep = runQuoteCheck(ctx.root, file, cacheDir);
        if (typeof rep === "string") {
          failures.push({ key: `${f.family}|${kind}|tool`, detail: rep });
          continue;
        }
        for (const r of rep.results) {
          if (seen.has(r.evidence_id)) continue;
          seen.add(r.evidence_id);
          total++;
          if (r.status === "found") found++;
          else if (r.status === "unopenable") {
            unopenable++;
            const g = grades.get(r.evidence_id);
            if (g !== "D") failures.push({ key: `${f.family}|${r.evidence_id}|unopenable`, detail: `source ${r.identifier ?? "?"} not in the cache or not openable (${r.error ?? "no text"}); verifier grade is ${g ?? "absent"}, must be D` });
          } else failures.push({ key: `${f.family}|${r.evidence_id}|${r.status}`, detail: `quote ${r.status} in ${r.identifier ?? "?"} (score ${r.score})` });
        }
      }
    }
    const share = total ? found / total : 1;
    const metrics: Metrics = { quotes: total, found, unopenable, found_share: Math.round(share * 10000) / 10000, families_checked: c.files.length, families_missing: c.missing.length };
    // The pass rule is on the share; individual misses are listed but the share decides.
    const shareFails = share < minShare;
    const unopenableNotD = failures.filter((x) => x.key.endsWith("|unopenable") || x.key.endsWith("|tool"));
    const status = shareFails || unopenableNotD.length ? "fail" : c.missing.length ? "blocked" : "pass";
    if (status === "blocked") return { ...blocked("E2", missingLabel(ctx, "research", c.missing), metrics), failures: sortFailures(failures) };
    return { id: "E2", status, summary: `${found} of ${total} quotes found (${(share * 100).toFixed(1)}%, need ${minShare * 100}%); ${unopenable} unopenable`, failures: sortFailures(failures), metrics };
  },
};

// ─── E3 grade rules ───

interface GradeCEntry {
  row_key: string;
  bound?: string;
}

export function gradeCEntries(doc: unknown): GradeCEntry[] | null {
  if (Array.isArray(doc)) return doc as GradeCEntry[];
  if (doc && typeof doc === "object") {
    const d = doc as Record<string, unknown>;
    for (const k of ["entries", "rows", "table"]) if (Array.isArray(d[k])) return d[k] as GradeCEntry[];
  }
  return null;
}

/** An optimal bound narrower than the reference interval on that side. */
export function narrowedSides(r: LoopRow): ("low" | "high")[] {
  const out: ("low" | "high")[] = [];
  if (r.optimal_low != null && (r.reference_low == null || r.optimal_low > r.reference_low)) out.push("low");
  if (r.optimal_high != null && (r.reference_high == null || r.optimal_high < r.reference_high)) out.push("high");
  return out;
}

export function gradeRuleFailures(files: FamilyFiles[], table: GradeCEntry[] | null, maxEntries: number): Failure[] {
  const failures: Failure[] = [];
  const tableKeys = new Set((table ?? []).map((e) => e.row_key));
  if (table && table.length > maxEntries) failures.push({ key: "grade_c_table", detail: `${table.length} entries, at most ${maxEntries}` });
  for (const f of files) {
    const { rows } = finalRows(f);
    const verifierGrade = new Map((f.verify?.row_verdicts ?? []).map((v) => [v.row_key, v.grade]));
    for (const r of verifierGrade.size ? (f.verify?.final_rows ?? []) : []) if (r.grade && !verifierGrade.has(loopRowKey(r))) verifierGrade.set(loopRowKey(r), r.grade);
    const ev = allEvidence(f);
    for (const r of rows) {
      const key = loopRowKey(r);
      const g = r.grade;
      const narrowed = narrowedSides(r);
      const hasBand = r.optimal_low != null || r.optimal_high != null;
      if (g === "D" && hasBand) failures.push({ key: `${key}|grade_d`, detail: `grade D but optimal band ${r.optimal_low ?? "-"} to ${r.optimal_high ?? "-"}` });
      if (g === "C" && narrowed.length && !(r.grade_c_table_entry && tableKeys.has(key)))
        failures.push({ key: `${key}|grade_c`, detail: `grade C narrowed ${narrowed.join("+")} bound not in the grade C decision table` });
      if (narrowed.length && g !== "A" && g !== "B" && g !== "C" && g !== "D") failures.push({ key: `${key}|grade_missing`, detail: "narrowed optimal bound without a grade" });
      const vg = verifierGrade.get(key);
      if (g && vg && g !== vg) failures.push({ key: `${key}|grade_author`, detail: `final grade ${g} differs from the verifier's ${vg}` });
      if (g && !vg && f.verify) failures.push({ key: `${key}|grade_author`, detail: `no verifier grade for this row` });
      // Optimal bounds resting only on a laboratory interval or treatment tier when the row has a guideline decision limit.
      if (r.reference_basis === "decision_limit") {
        for (const side of narrowed) {
          const bound = side === "low" ? "optimal_low" : "optimal_high";
          const support = [...ev.values()].filter((e) => (e.supports ?? []).some((s) => s.row_key === key && s.bound === bound));
          if (support.length && support.every((e) => e.basis_class === "laboratory_interval" || e.basis_class === "treatment_tier"))
            failures.push({ key: `${key}|${bound}|basis`, detail: "optimal bound rests only on a laboratory interval or treatment tier where a guideline decision limit exists" });
        }
      }
    }
  }
  return failures;
}

const E3: Check = {
  id: "E3",
  group: "evidence",
  title: "Grade rules",
  how: "script",
  run(ctx) {
    const c = collect(ctx, "final");
    if (typeof c === "string") return blocked("E3", c);
    if (!c.files.length) return blocked("E3", missingLabel(ctx, "verify", c.missing));
    const tableFile = path.join(ctx.workDir, "grade-c-table.json");
    const tableDoc = ctx.load(tableFile);
    const table = tableDoc == null ? null : gradeCEntries(tableDoc);
    const max = Number(ctx.thresholds.E3_grade_c_table_max_entries ?? 20);
    const failures = gradeRuleFailures(c.files, table, max);
    const gradeC = c.files.flatMap((f) => finalRows(f).rows).filter((r) => r.grade === "C" && narrowedSides(r).length).length;
    const metrics: Metrics = { families: c.files.length, families_missing: c.missing.length, grade_c_narrowed_rows: gradeC, grade_c_table_entries: table?.length ?? 0, grade_c_table_present: !!table };
    if (gradeC && !table) return { ...blocked("E3", rel(ctx, tableFile), metrics), failures: sortFailures(failures) };
    if (!failures.length && c.missing.length) return blocked("E3", missingLabel(ctx, "verify", c.missing), metrics);
    return result("E3", failures, `${failures.length} grade rule violations over ${c.files.length} families`, metrics);
  },
};

// ─── E4 age splits ───

const E4: Check = {
  id: "E4",
  group: "evidence",
  title: "Age-split justification",
  how: "script",
  run(ctx) {
    const c = collect(ctx, "research");
    if (typeof c === "string") return blocked("E4", c);
    if (!c.files.length) return blocked("E4", missingLabel(ctx, "research", c.missing));
    const maxShift = Number(ctx.thresholds.E4_nadir_shift_max_share_of_band ?? 0.2) * 100;
    const failures: Failure[] = [];
    let statements = 0;
    let flaggedNo70 = 0;
    for (const f of c.files) {
      const rows = finalRows(f).rows.length ? finalRows(f).rows : f.research?.rows ?? [];
      const ev = allEvidence(f);
      const questions = [...(f.research?.physician_questions ?? []), ...(f.verify?.physician_questions ?? []), ...(f.decision?.physician_questions ?? [])];
      for (const r of rows) {
        if (r.age_group !== "All Adults" || !r.band_rule || r.band_rule === "none") continue;
        const key = loopRowKey(r);
        for (const bound of ["optimal_low", "optimal_high"] as const) {
          if (r[bound] == null) continue;
          const support = [...ev.values()].filter((e) => (e.supports ?? []).some((s) => s.row_key === key && s.bound === bound));
          if (!support.length) continue; // E1 reports bounds with no record
          for (const e of support) {
            const s = String(e.age_stratified_statement ?? "").trim();
            if (s.length < 10 || /^(n\/?a|none|unknown|-)$/i.test(s)) failures.push({ key: `${key}|${bound}|${e.id}`, detail: "outcome-derived All Adults optimum without an age-stratification statement" });
            else statements++;
          }
        }
      }
      for (const s of f.research?.age_splits ?? []) {
        if (!s.evidence_above_70) flaggedNo70++;
        if (s.nadir_shift_pct == null || Math.abs(s.nadir_shift_pct) <= maxShift) continue;
        const split = rows.some((r) => r.marker_key === s.marker_key && (r.sex === s.sex || r.sex === "both") && r.physiological_state === s.physiological_state && r.age_group !== "All Adults");
        const asked = questions.some((q) => (q.row_key ?? "").startsWith(`${s.marker_key}|`));
        if (!split && !asked) failures.push({ key: `${s.marker_key}|${s.sex}|${s.physiological_state}|split`, detail: `nadir shift ${s.nadir_shift_pct}% of the band width (> ${maxShift}%) with no age split and no physician question` });
      }
    }
    const metrics: Metrics = { families: c.files.length, families_missing: c.missing.length, statements, flagged_no_evidence_above_70: flaggedNo70 };
    if (!failures.length && c.missing.length) return blocked("E4", missingLabel(ctx, "research", c.missing), metrics);
    return result("E4", failures, `${failures.length} age-split problems; ${statements} statements; ${flaggedNo70} splits flagged with no evidence above 70`, metrics);
  },
};

// ─── E5 blind re-audit ───

interface AuditItem {
  row_key?: string;
  bound?: string;
  agree?: boolean;
  number_agrees?: boolean;
  grade_agrees?: boolean;
}

const E5: Check = {
  id: "E5",
  group: "evidence",
  title: "Blind re-audit",
  how: "audit",
  run(ctx) {
    const file = path.join(ctx.workDir, "audit", `round-${ctx.round}-result.json`);
    const doc = ctx.load<{ items?: AuditItem[]; results?: AuditItem[] } | AuditItem[]>(file);
    if (!doc) return blocked("E5", rel(ctx, file));
    const items = Array.isArray(doc) ? doc : doc.items ?? doc.results ?? [];
    const minN = Number(ctx.thresholds.E5_sample_min ?? 20);
    const minAgree = Number(ctx.thresholds.E5_agreement_min ?? 0.95);
    const agrees = (i: AuditItem) => (i.agree != null ? !!i.agree : !!i.number_agrees && !!i.grade_agrees);
    const failures: Failure[] = items.filter((i) => !agrees(i)).map((i, n) => ({ key: `${i.row_key ?? `item${n}`}|${i.bound ?? ""}`, detail: "re-auditor disagrees on number or grade" }));
    const share = items.length ? (items.length - failures.length) / items.length : 0;
    const metrics: Metrics = { sampled: items.length, agreement: Math.round(share * 10000) / 10000 };
    if (items.length < minN) failures.push({ key: "sample_size", detail: `${items.length} bounds audited, at least ${minN} needed` });
    const ok = items.length >= minN && share >= minAgree;
    return { id: "E5", status: ok ? "pass" : "fail", summary: `${(share * 100).toFixed(1)}% agreement on ${items.length} bounds (need ${minAgree * 100}% on at least ${minN})`, failures: sortFailures(failures), metrics };
  },
};

// ─── E6 locked decisions ───

/** The locked rows as they stood in supabase/seed-data on 2026-11-06 (round 0). */
export const LOCKED_BASELINE: Record<string, { decision: string; rows: { sex: string; age_group: string; unit: string; normal_low: number | null; normal_high: number | null; optimal_low: number | null; optimal_high: number | null }[] }> = {
  apolipoprotein_b_apob: { decision: "apob", rows: [{ sex: "both", age_group: "All Adults", unit: "mg/dL", normal_low: 0, normal_high: 100, optimal_low: null, optimal_high: 70 }] },
  ldl_cholesterol: { decision: "ldl_c", rows: [{ sex: "both", age_group: "All Adults", unit: "mg/dL", normal_low: 0, normal_high: 100, optimal_low: null, optimal_high: 60 }] },
  non_hdl_cholesterol: { decision: "non_hdl_c", rows: [{ sex: "both", age_group: "All Adults", unit: "mg/dL", normal_low: 0, normal_high: 130, optimal_low: null, optimal_high: 90 }] },
  glucose_fasting: { decision: "fasting_glucose", rows: [{ sex: "both", age_group: "All Adults", unit: "mg/dL", normal_low: 74, normal_high: 99, optimal_low: 74, optimal_high: 90 }] },
  vitamin_d_25_oh: { decision: "vitamin_d", rows: [{ sex: "both", age_group: "All Adults", unit: "ng/mL", normal_low: 30, normal_high: 100, optimal_low: 30, optimal_high: 50 }] },
  homa_ir: { decision: "homa_ir", rows: [{ sex: "both", age_group: "All Adults", unit: "index", normal_low: 0, normal_high: 3.46, optimal_low: null, optimal_high: 1.8 }] },
};
export const CREATINE_BASELINE = { saturating_dose_g: 3, rise_mg_dl: 0.13, divisor_at_3g: 1.13 };

export function lockedDiffs(rows: Row[]): { key: string; decision: string; detail: string }[] {
  const out: { key: string; decision: string; detail: string }[] = [];
  for (const [marker, base] of Object.entries(LOCKED_BASELINE)) {
    const now = rows.filter((r) => r.biomarker_key === marker);
    const fmt = (r: { sex: string; age_group: string; unit: string; normal_low: number | null; normal_high: number | null; optimal_low: number | null; optimal_high: number | null }) =>
      `${r.sex}|${r.age_group}|${r.unit}|${r.normal_low}|${r.normal_high}|${r.optimal_low}|${r.optimal_high}`;
    const a = base.rows.map(fmt).sort();
    const b = [...new Set(now.map((r) => fmt({ sex: r.sex, age_group: r.age_group_en, unit: r.unit_en, normal_low: r.normal_low, normal_high: r.normal_high, optimal_low: r.optimal_low, optimal_high: r.optimal_high })))].sort();
    if (a.join("\n") !== b.join("\n")) out.push({ key: marker, decision: base.decision, detail: `rows changed: was [${a.join("; ")}], now [${b.join("; ") || "absent"}]` });
  }
  const div = creatineCreatinineDivisor(3);
  if (CREATINE_SATURATING_DOSE_G !== CREATINE_BASELINE.saturating_dose_g || CREATINE_CREATININE_RISE !== CREATINE_BASELINE.rise_mg_dl || Math.abs(div - CREATINE_BASELINE.divisor_at_3g) > 1e-12)
    out.push({ key: "creatine_rule", decision: "creatine_rule", detail: `CREATINE_SATURATING_DOSE_G ${CREATINE_SATURATING_DOSE_G}, rise ${CREATINE_CREATININE_RISE}, divisor at 3 g ${div}; locked 3, 0.13, 1.13` });
  return out;
}

const E6: Check = {
  id: "E6",
  group: "evidence",
  title: "Locked decisions unchanged",
  how: "script",
  run(ctx) {
    const seed = loadSeed(ctx.seedDir);
    if (!seed) return blocked("E6", `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json`);
    const diffs = lockedDiffs(seed.rows);
    const ceo = ctx.load<string>(path.join(ctx.workDir, "questions", "ceo-locked.md")) ?? "";
    // A change is not silent when a CEO question records it with grade A or B evidence from 2024 to 2026.
    const yMin = Number(ctx.thresholds.E6_evidence_year_min ?? 2024);
    const yMax = Number(ctx.thresholds.E6_evidence_year_max ?? 2026);
    const backed = new Set<string>();
    for (const fam of familiesFor(ctx) ?? []) {
      const f = loadFamilyFiles(ctx, fam);
      const ev = allEvidence(f);
      const vgrade = new Map((f.verify?.evidence_verdicts ?? []).map((v) => [v.evidence_id, v.grade]));
      for (const q of f.research?.locked_decision_questions ?? []) {
        const ok = q.evidence_ids.some((id) => {
          const e = ev.get(id);
          const g = vgrade.get(id) ?? e?.proposed_grade;
          return !!e && (g === "A" || g === "B") && typeof e.year === "number" && e.year >= yMin && e.year <= yMax;
        });
        if (ok && ceo.includes(q.id)) backed.add(q.locked_decision);
      }
    }
    const failures: Failure[] = diffs.filter((d) => !backed.has(d.decision)).map((d) => ({ key: d.key, detail: `${d.detail}; no CEO question with grade A/B ${yMin}-${yMax} evidence recorded in docs/signoff/work/questions/ceo-locked.md` }));
    return result("E6", failures, `${failures.length} silent changes to locked decisions (${diffs.length} changes, ${diffs.length - failures.length} with a recorded CEO question)`, {
      locked_markers: Object.keys(LOCKED_BASELINE).length,
      changes: diffs.length,
      ceo_questions_file: ceo.length > 0,
    });
  },
};

export const checks: Check[] = [E1, E2, E3, E4, E5, E6];
