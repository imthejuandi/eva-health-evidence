/**
 * P. Pre-analytical and measurement (P1-P3) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * P1 looks in src/lib/biomarkers and src/lib/lab-provider for the inputs the four pre-analytical rules need
 *    (fasting status, draw time, haemolysis, collection method). While any is missing the check fails and names
 *    it; once all exist it runs the fixtures in scripts/signoff/fixtures/preanalytical.json (blocked while absent).
 *    When the loop's final rows exist it also checks the rows of the affected markers carry the rule.
 * P2 reads docs/signoff/work/rcv.json ({markers: {key: {cvi_pct, cva_pct, rcv_pct, placeholder, source,
 *    narrow_band_justification}}} or an array of such objects with marker_key) and lists optimal bands narrower
 *    than the reference change value without a justification.
 * P3 tests the bounded-result rule with the app's own parser (lab-provider/hl7.ts parseHl7Value) and classifier
 *    (bounded-result.ts classifyResultZone, as process-results.ts calls it), on every seed row with an optimal
 *    ceiling, and checks that every app path that classifies a stored or reported result carries its comparator
 *    (boundedWiring). The lowest-reportable-value part is blocked until Echevarne's table arrives
 *    (docs/signoff/work/echevarne/reportable-range.json).
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, Ctx, Failure } from "../types";
import { loadSeed, sortFailures } from "../lib/seed";
import { familiesFor, finalRows, loadFamilyFiles, loopRowKey } from "./evidence";
import { parseHl7Value } from "../../../src/lib/lab-provider/hl7";
import { classifyResultZone } from "../../../src/lib/biomarkers/bounded-result";

type Metrics = Record<string, number | string | boolean>;
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");

/** Source files of the app the pre-analytical rules would live in, sorted. */
function appSources(root: string): { file: string; text: string }[] {
  const out: { file: string; text: string }[] = [];
  for (const dir of ["src/lib/biomarkers", "src/lib/lab-provider"]) {
    const abs = path.resolve(root, dir);
    if (!fs.existsSync(abs)) continue;
    for (const name of fs.readdirSync(abs).sort()) {
      if (!/\.ts$/.test(name) || /\.test\.ts$/.test(name)) continue;
      out.push({ file: `${dir}/${name}`, text: fs.readFileSync(path.join(abs, name), "utf8") });
    }
  }
  return out;
}

/** The input each rule needs, and what in the code would show it is supported. */
export const P1_RULES: { rule: string; needs: string; pattern: RegExp; markers: string[] }[] = [
  { rule: "fasting", needs: "a confirmed-fasting flag on the result, read by classification", pattern: /\b(fasting_confirmed|fastingConfirmed|is_fasting|isFasting|fasting_status|fastingStatus|fasted)\b/, markers: ["glucose_fasting", "insulin_fasting", "homa_ir", "triglycerides"] },
  { rule: "draw_time", needs: "the draw time of the sample, read by classification", pattern: /\b(draw_time|drawTime|collection_time|collectionTime|drawn_at|drawnAt|collected_at|collectedAt)\b/, markers: ["cortisol_morning_8am", "testosterone_total", "iron_serum"] },
  { rule: "haemolysis", needs: "a haemolysis flag or index on the sample", pattern: /\b(haemoly\w*|hemoly\w*|hemolysis_index|hemolysisIndex)\b/i, markers: ["potassium", "ast", "ldh", "total_bilirubin", "iron_serum", "magnesium_serum"] },
  { rule: "capillary", needs: "the collection method (venous or capillary) of the sample", pattern: /\b(collection_method|collectionMethod|specimen_type|specimenType|capillary)\b/i, markers: [] },
];

export function p1Support(root: string): { rule: string; needs: string; found: string[] }[] {
  const src = appSources(root);
  return P1_RULES.map((r) => ({ rule: r.rule, needs: r.needs, found: src.filter((s) => r.pattern.test(s.text)).map((s) => s.file) }));
}

const P1: Check = {
  id: "P1",
  group: "preanalytical",
  title: "Pre-analytical rules",
  how: "script",
  run(ctx) {
    const support = p1Support(ctx.root);
    const failures: Failure[] = [];
    for (const s of support) if (!s.found.length) failures.push({ key: `app|${s.rule}`, detail: `not supported in the app: ${s.needs} (nothing found in src/lib/biomarkers or src/lib/lab-provider)` });
    // Rows of the loop, when compiled.
    let rowsChecked = 0;
    for (const fam of familiesFor(ctx) ?? []) {
      const { rows } = finalRows(loadFamilyFiles(ctx, fam));
      for (const r of rows) {
        for (const rule of P1_RULES) {
          if (!rule.markers.includes(r.marker_key)) continue;
          rowsChecked++;
          const pa = Array.isArray(r.pre_analytical) ? (r.pre_analytical as { rule: string }[]) : [];
          if (!pa.some((p) => p.rule === rule.rule)) failures.push({ key: `row|${loopRowKey(r)}|${rule.rule}`, detail: `row carries no ${rule.rule} rule` });
        }
      }
    }
    const metrics: Metrics = { rules: P1_RULES.length, rules_supported_by_app: support.filter((s) => s.found.length).length, loop_rows_checked: rowsChecked };
    if (failures.length) return { id: "P1", status: "fail", summary: `${support.filter((s) => !s.found.length).length} of ${P1_RULES.length} pre-analytical inputs missing in the app; ${failures.length} problems`, failures: sortFailures(failures), metrics };
    const fixtures = path.resolve(ctx.root, "scripts/signoff/fixtures/preanalytical.json");
    if (!fs.existsSync(fixtures)) return { id: "P1", status: "blocked", summary: "blocked: app support found; rule fixtures scripts/signoff/fixtures/preanalytical.json are missing", failures: [], blocked_on: "scripts/signoff/fixtures/preanalytical.json", metrics };
    return { id: "P1", status: "blocked", summary: "blocked: fixture runner for the app's pre-analytical API not written yet", failures: [], blocked_on: "P1 fixture runner (scripts/signoff/checks/preanalytical.ts) for the app's pre-analytical API", metrics };
  },
};

// ─── P2 reference change values ───

interface RcvEntry {
  marker_key?: string;
  cvi_pct?: number | null;
  cva_pct?: number | null;
  rcv_pct?: number | null;
  placeholder?: boolean;
  source?: string | null;
  narrow_band_justification?: string | null;
}

export function rcvEntries(doc: unknown): Map<string, RcvEntry> {
  const m = new Map<string, RcvEntry>();
  if (Array.isArray(doc)) for (const e of doc as RcvEntry[]) m.set(String(e.marker_key), e);
  else if (doc && typeof doc === "object") {
    const d = doc as Record<string, unknown>;
    const src = (d.markers && typeof d.markers === "object" ? d.markers : d) as Record<string, unknown>;
    if (Array.isArray(src)) for (const e of src as RcvEntry[]) m.set(String(e.marker_key), e);
    else for (const [k, v] of Object.entries(src)) if (!k.startsWith("_") && v && typeof v === "object") m.set(k, v as RcvEntry);
  }
  return m;
}

/** RCV% = 1.96 × √2 × √(CVa² + CVi²) when not given. */
export function rcvPct(e: RcvEntry): number | null {
  if (typeof e.rcv_pct === "number") return e.rcv_pct;
  if (typeof e.cvi_pct === "number" && typeof e.cva_pct === "number") return 1.96 * Math.SQRT2 * Math.sqrt(e.cvi_pct ** 2 + e.cva_pct ** 2);
  return null;
}

const P2: Check = {
  id: "P2",
  group: "preanalytical",
  title: "Reference change values",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "rcv.json");
    const doc = ctx.load(file);
    if (doc == null) return { id: "P2", status: "blocked", summary: `blocked: ${rel(ctx, file)} is missing`, failures: [], blocked_on: rel(ctx, file) };
    const rcv = rcvEntries(doc);
    const seed = loadSeed(ctx.seedDir);
    const failures: Failure[] = [];
    let bands = 0;
    let narrow = 0;
    let placeholders = 0;
    for (const e of rcv.values()) if (e.placeholder) placeholders++;
    for (const r of seed?.rows ?? []) {
      if (r.optimal_low == null || r.optimal_high == null) continue;
      bands++;
      const e = rcv.get(r.biomarker_key);
      const key = `${r.biomarker_key}|${r.sex}|${r.age_group_en}`;
      if (!e) {
        failures.push({ key: `${key}|missing`, detail: "no reference change value entry" });
        continue;
      }
      const pct = rcvPct(e);
      if (pct == null) {
        failures.push({ key: `${key}|rcv`, detail: "entry has no rcv_pct and no CVi/CVa to compute it" });
        continue;
      }
      const mid = (r.optimal_low + r.optimal_high) / 2;
      const widthPct = mid > 0 ? ((r.optimal_high - r.optimal_low) / mid) * 100 : Infinity;
      if (widthPct < pct) {
        narrow++;
        if (!(typeof e.narrow_band_justification === "string" && e.narrow_band_justification.trim()))
          failures.push({ key: `${key}|narrow`, detail: `optimal band ${r.optimal_low}-${r.optimal_high} is ${widthPct.toFixed(1)}% of its midpoint, narrower than the RCV ${pct.toFixed(1)}%, with no justification` });
      }
    }
    return {
      id: "P2",
      status: failures.length ? "fail" : "pass",
      summary: `${failures.filter((f) => f.key.endsWith("|narrow")).length} unjustified narrow bands of ${narrow} narrow; ${bands} two-sided bands; ${placeholders} placeholder RCVs`,
      failures: sortFailures(failures),
      metrics: { rcv_entries: rcv.size, bands, narrow, placeholders },
    };
  },
};

// ─── P3 reportable range and bounded results ───

/**
 * The zone of a bounded result through the function the pipeline classifies every result with
 * (src/lib/biomarkers/bounded-result.ts classifyResultZone, as process-results.ts calls it), from the parser's value
 * and comparator (lab-provider/hl7.ts parseHl7Value). Whether every app path reaches that function with the
 * comparator is boundedWiring's part.
 */
export function appBoundedZone(raw: string, row: { optimal_low: number | null; optimal_high: number | null; normal_low: number | null; normal_high: number | null }): { value: number | null; comparator: string | null; zone: string | null } {
  const parsed = parseHl7Value(raw);
  if (!parsed) return { value: null, comparator: null, zone: null };
  return { value: parsed.value, comparator: parsed.comparator ?? null, zone: classifyResultZone(parsed.value, parsed.comparator, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high) };
}

/** Source files under dir (relative to root), .ts and .tsx, tests left out, sorted. */
function sourcesUnder(root: string, dir: string): { file: string; text: string }[] {
  const out: { file: string; text: string }[] = [];
  const walk = (rel: string) => {
    const abs = path.resolve(root, rel);
    if (!fs.existsSync(abs)) return;
    for (const e of fs.readdirSync(abs, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))) {
      const child = `${rel}/${e.name}`;
      if (e.isDirectory()) walk(child);
      else if (/\.tsx?$/.test(e.name) && !/\.test\.tsx?$/.test(e.name)) out.push({ file: child, text: fs.readFileSync(path.join(abs, e.name), "utf8") });
    }
  };
  walk(dir);
  return out;
}

/**
 * The app paths that classify a stored or reported result without its comparator (ACCEPTANCE-TEST.md P3: "A bounded
 * result such as "<5" resolves to the bound itself and is never classified above optimal"). The rule holds for every
 * way a result reaches classification: upload, manual entry, webhook, edit and reprocessing (decision CEO-15), so no
 * file is exempt.
 *   W1. src/lib/biomarkers/process-results.ts classifies through classifyResultZone with the raw result's comparator
 *       (raw.comparator) as the second argument, and never with classifyZone, which takes no comparator;
 *   W2. no non-test .ts or .tsx file under src/app/api classifies with classifyZone;
 *   W3. every non-test .ts or .tsx file under src/ but process-results.ts that hands results to processLabResults names
 *       the comparator, and reads it with every stored value it reads from biomarker_values (a select list that names
 *       value names comparator, or is *).
 * Each failure names the file, the rule (missing, classifyResultZone, classifyZone, processLabResults, select) and what
 * the file lacks.
 */
export function boundedWiring(root: string): { file: string; rule: string; detail: string }[] {
  const out: { file: string; rule: string; detail: string }[] = [];
  const PIPELINE = "src/lib/biomarkers/process-results.ts";
  const pipeline = path.resolve(root, PIPELINE);
  if (!fs.existsSync(pipeline)) out.push({ file: PIPELINE, rule: "missing", detail: "missing: the pipeline that classifies every result" });
  else {
    const text = fs.readFileSync(pipeline, "utf8");
    if (!/\bclassifyResultZone\(\s*[^,()]+,\s*raw\.comparator\b/.test(text)) out.push({ file: PIPELINE, rule: "classifyResultZone", detail: "does not classify through classifyResultZone with the raw result's comparator (raw.comparator)" });
    if (/\bclassifyZone\(/.test(text)) out.push({ file: PIPELINE, rule: "classifyZone", detail: "calls classifyZone, which ignores a bounded result's comparator" });
  }
  for (const f of sourcesUnder(root, "src")) {
    if (f.file === PIPELINE) continue;
    if (f.file.startsWith("src/app/api/") && /\bclassifyZone\(/.test(f.text)) out.push({ file: f.file, rule: "classifyZone", detail: "classifies with classifyZone, which ignores a bounded result's comparator: classify with classifyResultZone (src/lib/biomarkers/bounded-result.ts) and the result's comparator" });
    if (/\bprocessLabResults\(/.test(f.text)) {
      if (!/\bcomparator\b/.test(f.text)) out.push({ file: f.file, rule: "processLabResults", detail: "hands results to processLabResults without a comparator, so a bounded result is classified as the measured number" });
      // A read of stored values (the value column) must read their comparator too ("*" reads every column).
      for (const m of f.text.matchAll(/\.from\(\s*["']biomarker_values["']\s*\)\s*\.select\(\s*(["'`])([^"'`]*)\1/g)) {
        const cols = m[2].trim();
        if (cols !== "*" && /\bvalue\b/.test(cols) && !/\bcomparator\b/.test(cols) && !out.some((o) => o.file === f.file && o.rule === "select")) out.push({ file: f.file, rule: "select", detail: `reads stored values from biomarker_values for processLabResults without their comparator (select "${cols}")` });
      }
    }
  }
  return out;
}

const fmt = (n: number) => String(Math.round(n * 1000) / 1000);

const P3: Check = {
  id: "P3",
  group: "preanalytical",
  title: "Reportable range and bounded results",
  how: "script",
  run(ctx) {
    const failures: Failure[] = [];
    // The parser resolves a bound to the bound itself.
    const parse = [
      ["<5", 5],
      ["<0,500", 0.5],
      [">8,000", 8],
    ] as const;
    for (const [raw, want] of parse) {
      const p = parseHl7Value(raw);
      if (!p || p.value !== want) failures.push({ key: `parser|${raw}`, detail: `parseHl7Value("${raw}") gives ${p ? p.value : "null"}, expected the bound ${want}` });
    }
    // A "<X" result is never classified above optimal.
    const seed = loadSeed(ctx.seedDir);
    let fixtures = 0;
    const seen = new Set<string>();
    for (const r of seed?.rows ?? []) {
      if (r.optimal_high == null) continue;
      const key = `${r.biomarker_key}|${r.sex}|${r.age_group_en}`;
      if (seen.has(key)) continue;
      seen.add(key);
      // A detection limit above the optimal ceiling, inside the reference interval when there is one.
      const x = r.normal_high != null && r.normal_high > r.optimal_high ? (r.optimal_high + r.normal_high) / 2 : r.optimal_high * 1.5 || 1;
      const raw = `<${fmt(x)}`;
      fixtures++;
      const z = appBoundedZone(raw, r);
      if (z.zone === "above_optimal" || z.zone === "critical_high")
        failures.push({ key: `bounded|${key}`, detail: `"${raw}" ${r.unit_en} is classified ${z.zone} by the app's classifier (src/lib/biomarkers/bounded-result.ts classifyResultZone, as process-results.ts calls it)` });
    }
    // Every app path that classifies a stored or reported result carries its comparator.
    const wiring = boundedWiring(ctx.root);
    for (const w of wiring) failures.push({ key: `bounded|wiring|${w.file}|${w.rule}`, detail: w.detail });
    const loqFile = path.join(ctx.workDir, "echevarne", "reportable-range.json");
    const loq = ctx.load(loqFile);
    const metrics: Metrics = { bounded_fixtures: fixtures, bounded_violations: failures.filter((f) => f.key.startsWith("bounded|") && !f.key.startsWith("bounded|wiring|")).length, bounded_wiring_violations: wiring.length, loq_table_present: loq != null };
    if (loq != null) {
      const m = rcvEntries(loq); // same keyed shape: {markers: {key: {lowest_reportable, unit}}}
      for (const r of seed?.rows ?? []) {
        const e = m.get(r.biomarker_key) as { lowest_reportable?: number } | undefined;
        if (!e || typeof e.lowest_reportable !== "number") continue;
        for (const b of [r.optimal_low, r.optimal_high]) {
          if (b != null && b < e.lowest_reportable) failures.push({ key: `loq|${r.biomarker_key}|${r.sex}|${r.age_group_en}|${b}`, detail: `optimal bound ${b} below the lowest reportable value ${e.lowest_reportable}` });
        }
      }
    }
    if (!failures.length && loq == null) return { id: "P3", status: "blocked", summary: `bounded-result rule holds on ${fixtures} fixtures; blocked: ${rel(ctx, loqFile)} (Echevarne's lowest reportable values) is missing`, failures: [], blocked_on: rel(ctx, loqFile), metrics };
    return {
      id: "P3",
      status: failures.length ? "fail" : "pass",
      summary: `${metrics.bounded_violations} of ${fixtures} bounded-result fixtures classified above optimal; ${wiring.length} app paths that classify or hand on a result without its comparator${loq == null ? `; lowest-reportable part blocked on ${rel(ctx, loqFile)}` : ""}`,
      failures: sortFailures(failures),
      metrics,
    };
  },
};

export const checks: Check[] = [P1, P2, P3];
