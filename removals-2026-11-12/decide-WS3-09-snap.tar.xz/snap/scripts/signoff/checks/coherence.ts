/**
 * K. Coherence (K1) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * The relationships of docs/biomarker-evidence/tools/consistency-audit.js, run as a grid over synthetic people:
 * both sexes, every age from 18 to 100, and for each input marker values on both sides of every limit of the row
 * the app's own picker (src/lib/biomarkers/reference-row.ts) gives that person. Every value is classified with the
 * app's own classifier (src/lib/biomarkers/zone-classifier.ts).
 *
 * Disagreement rules, per relationship and person (no expectation is formed when the inputs pull the derived
 * marker in different directions, or when some inputs are optimal and others are not, because an optimal input
 * can sit anywhere in its band):
 * - every input optimal: the derived marker should be optimal. Out of range is an opposite pair; in range is a
 *   one-step disagreement.
 * - every input outside optimal, all pushing the derived marker the same way: the derived marker on the other
 *   side is an opposite pair when either side is out of range, otherwise one step; the derived marker optimal is
 *   an opposite pair when every input is out of range, otherwise one step. For a single-input relationship
 *   (urea = BUN x 2.14) a level difference on the same side is also a disagreement.
 * - ESC/EAS goal pairings: LDL-C, non-HDL-C and apoB at equivalent goal values (and just above them) should share
 *   a category; positions two or more steps apart on the signed scale are opposite pairs, one step is one step.
 *
 * Disagreements are aggregated into patterns (relationship, sex, input zones, derived zone). Opposite pairs fail.
 * One-step patterns fail unless docs/signoff/work/coherence/accepted-reasons.json gives a reason
 * ({"<pattern key or glob>": "reason"} or [{key, reason}]).
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, CheckResult, Failure } from "../types";
import { byKey, rowsFor, sortFailures, type Row } from "../lib/seed";
import { globToRegExp } from "../lib/ownership";
import { referenceRowFor } from "../../../src/lib/biomarkers/reference-row";
import { classifyZone } from "../../../src/lib/biomarkers/zone-classifier";

type Zone = "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high";

export interface Ctx2 {
  sex: "male" | "female";
  age: number;
}

export interface Relationship {
  id: string;
  title: string;
  /** Input marker keys with the sign of d(derived)/d(input). */
  inputs: { key: string; unit: string; sign: 1 | -1 }[];
  derived: { key: string; unit: string };
  /** The derived value from the input values (in the units listed), or null when undefined. */
  f(values: number[], p: Ctx2): number | null;
  usesAge?: boolean;
}

const MW_TESTOSTERONE = 288.42;
const MW_ALBUMIN = 66430;

/** CKD-EPI 2021 creatinine equation (race-free), creatinine in mg/dL, result in mL/min/1.73m². */
export function ckdEpi2021(creatinineMgDl: number, age: number, sex: "male" | "female"): number {
  const k = sex === "female" ? 0.7 : 0.9;
  const a = sex === "female" ? -0.241 : -0.302;
  const r = creatinineMgDl / k;
  return 142 * Math.min(r, 1) ** a * Math.max(r, 1) ** -1.2 * 0.9938 ** age * (sex === "female" ? 1.012 : 1);
}

/** Vermeulen 1999 free testosterone: total T in ng/mL, SHBG in nmol/L, albumin in g/L; result in ng/dL. */
export function vermeulenFreeT(totalNgMl: number, shbgNmolL: number, albuminGL: number): number {
  const kt = 1e9;
  const ka = 3.6e4;
  const tt = (totalNgMl * 1e-6) / MW_TESTOSTERONE; // ng/mL → g/L (×1e-6) → mol/L
  const shbg = shbgNmolL * 1e-9;
  const n = 1 + ka * (albuminGL / MW_ALBUMIN);
  const a = n * kt;
  const b = n + kt * (shbg - tt);
  const ft = (-b + Math.sqrt(b * b + 4 * a * tt)) / (2 * a);
  return ft * MW_TESTOSTERONE * 1e8; // mol/L → g/L → ng/dL
}

export const RELATIONSHIPS: Relationship[] = [
  { id: "non_hdl", title: "non-HDL = TC − HDL", inputs: [{ key: "total_cholesterol", unit: "mg/dL", sign: 1 }, { key: "hdl_cholesterol", unit: "mg/dL", sign: -1 }], derived: { key: "non_hdl_cholesterol", unit: "mg/dL" }, f: ([tc, hdl]) => tc - hdl },
  { id: "urea_bun", title: "urea = BUN × 2.14", inputs: [{ key: "bun", unit: "mg/dL", sign: 1 }], derived: { key: "urea", unit: "mg/dL" }, f: ([bun]) => bun * 2.14 },
  { id: "egfr_ckd_epi_2021", title: "eGFR by CKD-EPI 2021", inputs: [{ key: "creatinine", unit: "mg/dL", sign: -1 }], derived: { key: "egfr_creatinine_based", unit: "mL/min/1.73m²" }, f: ([cr], p) => ckdEpi2021(cr, p.age, p.sex), usesAge: true },
  { id: "free_t_vermeulen", title: "free testosterone by Vermeulen", inputs: [{ key: "testosterone_total", unit: "ng/mL", sign: 1 }, { key: "shbg", unit: "nmol/L", sign: -1 }, { key: "albumin", unit: "g/L", sign: -1 }], derived: { key: "testosterone_free", unit: "ng/dL" }, f: ([t, s, a]) => vermeulenFreeT(t, s, a) },
  { id: "homa_ir", title: "HOMA-IR = glucose × insulin / 405", inputs: [{ key: "glucose_fasting", unit: "mg/dL", sign: 1 }, { key: "insulin_fasting", unit: "µU/mL", sign: 1 }], derived: { key: "homa_ir", unit: "index" }, f: ([g, i]) => (g * i) / 405 },
  { id: "nlr", title: "NLR = neutrophils / lymphocytes (absolute)", inputs: [{ key: "neutrophils_absolute", unit: "/µL", sign: 1 }, { key: "lymphocytes_absolute", unit: "/µL", sign: -1 }], derived: { key: "nlr", unit: "ratio" }, f: ([n, l]) => (l > 0 ? n / l : null) },
  { id: "total_protein", title: "total protein = albumin + globulin", inputs: [{ key: "albumin", unit: "g/L", sign: 1 }, { key: "globulin", unit: "g/dL", sign: 1 }], derived: { key: "total_protein", unit: "g/L" }, f: ([a, g]) => a + g * 10 },
  { id: "neutrophils_absolute", title: "absolute neutrophils = % × WBC", inputs: [{ key: "neutrophils", unit: "%", sign: 1 }, { key: "white_blood_cell_count", unit: "/µL", sign: 1 }], derived: { key: "neutrophils_absolute", unit: "/µL" }, f: ([p, w]) => (p / 100) * w },
  { id: "lymphocytes_absolute", title: "absolute lymphocytes = % × WBC", inputs: [{ key: "lymphocytes", unit: "%", sign: 1 }, { key: "white_blood_cell_count", unit: "/µL", sign: 1 }], derived: { key: "lymphocytes_absolute", unit: "/µL" }, f: ([p, w]) => (p / 100) * w },
  { id: "tsat", title: "TSAT = iron / TIBC", inputs: [{ key: "iron_serum", unit: "µg/dL", sign: 1 }, { key: "iron_binding_capacity_tibc", unit: "µg/dL", sign: -1 }], derived: { key: "iron_saturation_tsat", unit: "%" }, f: ([fe, tibc]) => (tibc > 0 ? (fe / tibc) * 100 : null) },
  { id: "ag_ratio", title: "albumin/globulin ratio", inputs: [{ key: "albumin", unit: "g/L", sign: 1 }, { key: "globulin", unit: "g/dL", sign: -1 }], derived: { key: "albumin_globulin_ratio", unit: "ratio" }, f: ([a, g]) => (g > 0 ? a / (g * 10) : null) },
  { id: "bun_creatinine", title: "BUN/creatinine ratio", inputs: [{ key: "bun", unit: "mg/dL", sign: 1 }, { key: "creatinine", unit: "mg/dL", sign: -1 }], derived: { key: "bun_creatinine_ratio", unit: "ratio" }, f: ([b, c]) => (c > 0 ? b / c : null) },
];

/** ESC/EAS 2019 goal pairings (mg/dL): LDL-C, non-HDL-C and apoB goals for very high, high and moderate risk. */
export const ESC_EAS_GOALS: { tier: string; values: Record<string, number> }[] = [
  { tier: "very_high", values: { ldl_cholesterol: 55, non_hdl_cholesterol: 85, apolipoprotein_b_apob: 65 } },
  { tier: "high", values: { ldl_cholesterol: 70, non_hdl_cholesterol: 100, apolipoprotein_b_apob: 80 } },
  { tier: "moderate", values: { ldl_cholesterol: 100, non_hdl_cholesterol: 130, apolipoprotein_b_apob: 100 } },
];

const SIDE: Record<Zone, number> = { critical_low: -1, below_optimal: -1, optimal: 0, above_optimal: 1, critical_high: 1 };
const LEVEL: Record<Zone, number> = { critical_low: 2, below_optimal: 1, optimal: 0, above_optimal: 1, critical_high: 2 };
const signed = (z: Zone) => SIDE[z] * LEVEL[z];

export function zoneOf(value: number, r: Row): Zone | null {
  const z = classifyZone(value, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high) as string;
  return z === "unclassified" ? null : (z as Zone);
}

/** Values on both sides of every limit of the row, plus the band middles and the tails; positive, sorted. */
export function gridValues(r: Row): number[] {
  const bounds = [r.critical_low, r.normal_low, r.optimal_low, r.optimal_high, r.normal_high, r.critical_high].filter((b): b is number => b != null && b > 0);
  if (!bounds.length) return [];
  const vals = new Set<number>();
  const q = (x: number) => Number(x.toPrecision(6));
  for (const b of bounds) {
    vals.add(q(b * 0.97));
    vals.add(q(b * 1.03));
  }
  if (r.optimal_low != null && r.optimal_high != null) vals.add(q((r.optimal_low + r.optimal_high) / 2));
  if (r.normal_low != null && r.normal_high != null) vals.add(q((r.normal_low + r.normal_high) / 2));
  vals.add(q(Math.min(...bounds) * 0.75));
  vals.add(q(Math.max(...bounds) * 1.3));
  return [...vals].filter((v) => v > 0).sort((a, b) => a - b);
}

export type Verdict = "opposite" | "one_step" | null;

/** The disagreement rule of the module comment, for one person and one combination of input values. */
export function judge(inputZones: Zone[], signs: number[], derived: Zone): Verdict {
  const implied = inputZones.map((z, i) => signs[i] * SIDE[z]);
  const ds = SIDE[derived];
  const dl = LEVEL[derived];
  if (implied.every((d) => d === 0)) return dl === 2 ? "opposite" : dl === 1 ? "one_step" : null;
  if (implied.some((d) => d === 0)) return null;
  const dir = implied[0];
  if (implied.some((d) => d !== dir)) return null;
  const levels = inputZones.map((z) => LEVEL[z]);
  const minL = Math.min(...levels);
  const maxL = Math.max(...levels);
  if (ds === -dir) return dl === 2 || maxL === 2 ? "opposite" : "one_step";
  if (ds === 0) return minL === 2 ? "opposite" : "one_step";
  if (inputZones.length === 1 && dl !== levels[0]) return "one_step";
  return null;
}

export interface Pattern {
  key: string;
  verdict: "opposite" | "one_step";
  count: number;
  age_min: number;
  age_max: number;
  example: string;
}

export interface CoherenceReport {
  patterns: Pattern[];
  metrics: Record<string, number | string | boolean>;
}

const fmt = (x: number) => String(Number(x.toPrecision(4)));

export function runCoherence(rows: Row[], ageMin = 18, ageMax = 100): CoherenceReport {
  const groups = byKey(rows);
  const patterns = new Map<string, Pattern>();
  const skipped = new Set<string>();
  let evaluations = 0;
  const note = (key: string, verdict: "opposite" | "one_step", age: number, example: string, n = 1) => {
    const p = patterns.get(key);
    if (p) {
      p.count += n;
      p.age_min = Math.min(p.age_min, age);
      p.age_max = Math.max(p.age_max, age);
    } else patterns.set(key, { key, verdict, count: n, age_min: age, age_max: age, example });
  };
  const rowFor = (key: string, sex: string, age: number): Row | null => {
    const list = groups.get(key);
    if (!list) return null;
    const { row, ageMatched } = referenceRowFor(list, sex, age);
    return row && ageMatched ? row : null;
  };

  for (const rel of RELATIONSHIPS) {
    const keys = [...rel.inputs.map((i) => i.key), rel.derived.key];
    const missing = keys.filter((k) => !groups.has(k));
    if (missing.length) {
      skipped.add(`${rel.id}: no rows for ${missing.join(", ")}`);
      continue;
    }
    for (const sex of ["female", "male"] as const) {
      // Rows change only at band edges, so ages with the same rows give the same findings (except eGFR, whose
      // equation depends on age): they are computed once and replayed for each such age.
      const cache = new Map<string, { key: string; verdict: "opposite" | "one_step"; example: string }[]>();
      for (let age = ageMin; age <= ageMax; age++) {
        const inRows = rel.inputs.map((i) => rowFor(i.key, sex, age));
        const outRow = rowFor(rel.derived.key, sex, age);
        if (inRows.some((r) => !r) || !outRow) continue;
        const unitBad = [...rel.inputs.map((i, n) => [i.unit, inRows[n]!.unit_en] as const), [rel.derived.unit, outRow.unit_en] as const].find(([want, got]) => want !== got);
        if (unitBad) {
          skipped.add(`${rel.id}: unit ${unitBad[1]} where ${unitBad[0]} is expected`);
          continue;
        }
        const sig = [...inRows, outRow].map((r) => r!.index).join(",");
        const cached = rel.usesAge ? undefined : cache.get(sig);
        if (cached) {
          for (const c of cached) note(c.key, c.verdict, age, c.example);
          continue;
        }
        const found = new Map<string, { key: string; verdict: "opposite" | "one_step"; example: string }>();
        const grids = inRows.map((r) => gridValues(r!));
        if (grids.some((g) => !g.length)) continue;
        const combos = cartesian(grids);
        for (const vals of combos) {
          const zones = vals.map((v, n) => zoneOf(v, inRows[n]!));
          if (zones.some((z) => !z)) continue;
          const d = rel.f(vals, { sex, age });
          if (d == null || !Number.isFinite(d) || d <= 0) continue;
          const dz = zoneOf(d, outRow);
          if (!dz) continue;
          evaluations++;
          const v = judge(zones as Zone[], rel.inputs.map((i) => i.sign), dz);
          if (!v) continue;
          const key = `${rel.id}|${sex}|${rel.inputs.map((i, n) => `${i.key}:${zones[n]}`).join(",")}->${rel.derived.key}:${dz}`;
          const example = `age ${age}: ${rel.inputs.map((i, n) => `${i.key} ${fmt(vals[n])}`).join(", ")} gives ${rel.derived.key} ${fmt(d)} (${rel.title}; derived row ${outRow.age_group_en} optimal [${outRow.optimal_low ?? ""}, ${outRow.optimal_high ?? ""}], reference [${outRow.normal_low ?? ""}, ${outRow.normal_high ?? ""}])`;
          if (!found.has(key)) found.set(key, { key, verdict: v, example: example.replace(/^age \d+: /, "") });
        }
        const list = [...found.values()];
        if (!rel.usesAge) cache.set(sig, list);
        for (const c of list) note(c.key, c.verdict, age, c.example);
      }
    }
  }

  // ESC/EAS goal pairings: the three lipid targets at the same tier, just below and just above the goal.
  const lipidKeys = Object.keys(ESC_EAS_GOALS[0].values);
  if (lipidKeys.every((k) => groups.has(k))) {
    for (const sex of ["female", "male"] as const) {
      for (let age = ageMin; age <= ageMax; age++) {
        const rs = lipidKeys.map((k) => rowFor(k, sex, age));
        if (rs.some((r) => !r)) continue;
        for (const goal of ESC_EAS_GOALS) {
          for (const factor of [0.98, 1.02]) {
            const zones = lipidKeys.map((k, n) => zoneOf(goal.values[k] * factor, rs[n]!));
            evaluations++;
            for (let a = 0; a < lipidKeys.length; a++) {
              for (let b = a + 1; b < lipidKeys.length; b++) {
                const za = zones[a];
                const zb = zones[b];
                if (!za || !zb) continue;
                const gap = Math.abs(signed(za) - signed(zb));
                if (!gap) continue;
                const side = factor < 1 ? "below" : "above";
                const key = `esc_eas_goals|${sex}|${goal.tier}_${side}|${lipidKeys[a]}:${za},${lipidKeys[b]}:${zb}`;
                note(key, gap >= 2 ? "opposite" : "one_step", age, `${lipidKeys[a]} ${fmt(goal.values[lipidKeys[a]] * factor)} is ${za}, ${lipidKeys[b]} ${fmt(goal.values[lipidKeys[b]] * factor)} is ${zb} (ESC/EAS 2019 ${goal.tier}-risk goals ${side})`);
              }
            }
          }
        }
      }
    }
  } else skipped.add(`esc_eas_goals: no rows for ${lipidKeys.filter((k) => !groups.has(k)).join(", ")}`);

  const list = [...patterns.values()].sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  return {
    patterns: list,
    metrics: {
      relationships: RELATIONSHIPS.length + 1,
      relationships_skipped: skipped.size,
      skipped: [...skipped].sort().join("; "),
      evaluations,
      opposite_patterns: list.filter((p) => p.verdict === "opposite").length,
      one_step_patterns: list.filter((p) => p.verdict === "one_step").length,
    },
  };
}

function cartesian(lists: number[][]): number[][] {
  let out: number[][] = [[]];
  for (const l of lists) out = out.flatMap((prefix) => l.map((v) => [...prefix, v]));
  return out;
}

export function loadAcceptedReasons(file: string): { pattern: RegExp; reason: string }[] {
  if (!fs.existsSync(file)) return [];
  const doc = JSON.parse(fs.readFileSync(file, "utf8")) as Record<string, string> | { key: string; reason: string }[];
  const entries = Array.isArray(doc) ? doc.map((d) => [d.key, d.reason] as const) : Object.entries(doc).filter(([k]) => !k.startsWith("_"));
  return entries.filter(([, r]) => typeof r === "string" && r.trim()).map(([k, r]) => ({ pattern: globToRegExp(k.replace(/\|/g, "\u0001")), reason: r }));
}

export function coherenceFailures(patterns: Pattern[], accepted: { pattern: RegExp; reason: string }[]): { failures: Failure[]; acceptedOneStep: number } {
  const failures: Failure[] = [];
  let acceptedOneStep = 0;
  for (const p of patterns) {
    const detail = `seen at ${p.count} ages from ${p.age_min} to ${p.age_max}; e.g. ${p.example}`;
    if (p.verdict === "opposite") failures.push({ key: `opposite|${p.key}`, detail });
    else if (accepted.some((a) => a.pattern.test(p.key.replace(/\|/g, "\u0001")))) acceptedOneStep++;
    else failures.push({ key: `one_step|${p.key}`, detail: `${detail}; no accepted reason` });
  }
  return { failures: sortFailures(failures), acceptedOneStep };
}

const K1: Check = {
  id: "K1",
  group: "coherence",
  title: "Coherence across derived relationships",
  how: "script",
  run(ctx): CheckResult {
    const data = rowsFor(ctx);
    if (!data) return { id: "K1", status: "blocked", summary: "blocked: seed files missing", failures: [], blocked_on: `${ctx.seedDir}/biomarker-ranges-en.json` };
    const ageMin = Number(ctx.thresholds.K1_grid_age_min ?? 18);
    const ageMax = Number(ctx.thresholds.K1_grid_age_max ?? 100);
    // Relationships need every marker they tie together, so K1 always runs on all rows, even with --families.
    const report = runCoherence(data.seed.rows, ageMin, ageMax);
    // With --families, keep the patterns that involve at least one of the families' markers.
    const restrict = Array.isArray(ctx.thresholds.restrict_keys) ? new Set((ctx.thresholds.restrict_keys as unknown[]).map(String)) : null;
    if (restrict && restrict.size) report.patterns = report.patterns.filter((p) => [...p.key.matchAll(/([a-z0-9_]+):/g)].some((m) => restrict.has(m[1])));
    const accepted = loadAcceptedReasons(path.join(ctx.workDir, "coherence", "accepted-reasons.json"));
    const { failures, acceptedOneStep } = coherenceFailures(report.patterns, accepted);
    const opposite = report.patterns.filter((p) => p.verdict === "opposite").length;
    const oneStep = report.patterns.length - opposite;
    return {
      id: "K1",
      status: failures.length ? "fail" : "pass",
      summary: `${opposite} opposite-category patterns and ${oneStep} one-step patterns (${acceptedOneStep} with an accepted reason) over ${report.metrics.evaluations} evaluations`,
      failures,
      metrics: { ...report.metrics, opposite_patterns: opposite, one_step_patterns: oneStep, one_step_accepted: acceptedOneStep },
    };
  },
};

export const checks: Check[] = [K1];
