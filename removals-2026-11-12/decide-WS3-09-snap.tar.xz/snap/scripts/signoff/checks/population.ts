/**
 * N. Population sense (N1) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * Reads docs/signoff/work/nhanes/distributions.json (NHANES 2015-2018 healthy adults 20-79, produced by another
 * agent with the healthy-adult definition fixed there). Accepted layouts: an array of entries, {entries: [...]}, or
 * {markers: {<key>: [...entries]}}. Each entry names the marker (biomarker_key | marker_key | eva_key | key), sex
 * (male | female), the age band ("20-39", [20, 39] or age_low/age_high) and either
 *   - quantiles: {"p1": x, "p2.5": x, ..., "p99": x} or percentiles: {"1": x, ...} in the EVA unit, from which the
 *     shares below/inside/above each bound of the current seed row (the app's picker at the band's midpoint) are
 *     interpolated, or
 *   - shares: {below_normal, above_normal, optimal} (fractions) already computed on the current rows;
 * plus optional method_offset: {known: true, status: "applied" | "flagged"}.
 * Rules (thresholds.json N1_*): reference limits leave 2% to 15% outside; optimal share below 10% needs a
 * "reached by a minority" label, above 95% a justification; more than 60% non-optimal at 70-79 is a physician
 * question; known method offsets are applied or flagged. Decision-limit rows are reported, not tested on the share.
 * Resolutions: docs/signoff/work/nhanes/n1-resolutions.json {"<key>|<sex>|<band>|<rule>": {kind, text}}, kind one
 * of justification | label | physician_question.
 */
import path from "node:path";
import type { Check, Ctx, Failure } from "../types";
import { loadSeed, sortFailures } from "../lib/seed";
import { seedReviewedRows, pickedFor, type SeedReviewedRow } from "./score";

type Metrics = Record<string, number | string | boolean>;
type Sex = "male" | "female";
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");

export interface DistEntry {
  key: string;
  sex: Sex;
  band: [number, number];
  quantiles: [number, number][] | null; // [probability, value], sorted
  shares: { below_normal: number; above_normal: number; optimal: number } | null;
  method_offset: { known?: boolean; status?: string } | null;
  /** Rows the producer computed `shares` on (the generator's layout); shares are used only while they still match. */
  shares_rows?: { normal_low: number | null; normal_high: number | null; optimal_low: number | null; optimal_high: number | null }[] | null;
  n?: number;
}

function parseBand(e: Record<string, unknown>): [number, number] | null {
  const b = e.age_band ?? e.band;
  if (Array.isArray(b) && b.length === 2) return [Number(b[0]), Number(b[1])];
  if (typeof b === "string") {
    const m = b.match(/(\d+)\D+(\d+)/);
    if (m) return [Number(m[1]), Number(m[2])];
  }
  if (typeof e.age_low === "number" && typeof e.age_high === "number") return [e.age_low, e.age_high];
  return null;
}

function parseQuantiles(e: Record<string, unknown>): [number, number][] | null {
  const q = (e.quantiles ?? e.percentiles) as Record<string, unknown> | undefined;
  if (!q || typeof q !== "object") return null;
  const pts: [number, number][] = [];
  for (const [k, v] of Object.entries(q)) {
    const p = Number(k.replace(/^p/i, "").replace("_", "."));
    if (Number.isFinite(p) && typeof v === "number") pts.push([p / 100, v]);
  }
  return pts.length >= 2 ? pts.sort((a, b) => a[0] - b[0]) : null;
}

/**
 * The generator's layout (ml/biological-age/signoff/nhanes_distributions.py): splits.<split>.markers.<key>.cells
 * ["<sex>|<band>"] = {n, percentiles: {p1, p2_5, ...}, shares_pct, eva_rows, offsets: {<scenario>: {shift_gt_10pp}}}.
 * N1 reads the split of NHANES 2015-2018 (waves 9 and 10) and the four bands of thresholds N1_age_bands.
 */
function generatorEntries(doc: Record<string, unknown>, bands: [number, number][]): DistEntry[] | null {
  const splits = doc.splits as Record<string, { waves?: number[]; markers?: Record<string, { cells?: Record<string, Record<string, unknown>> }> }> | undefined;
  if (!splits) return null;
  const split = Object.values(splits).find((x) => (x.waves ?? []).includes(9) && (x.waves ?? []).includes(10));
  if (!split?.markers) return [];
  const flagged = new Set(((doc.flags as Record<string, { eva_key: string; cell: string; scenario?: string; split?: string }[]> | undefined)?.offset_shift_gt_10pp ?? []).map((f) => `${f.eva_key}|${f.cell}|${f.scenario}`));
  const out: DistEntry[] = [];
  for (const [key, m] of Object.entries(split.markers)) {
    for (const [cell, c] of Object.entries(m.cells ?? {})) {
      const [sex, bandStr] = cell.split("|");
      const bm = bandStr?.match(/^(\d+)-(\d+)$/);
      if (!bm || (sex !== "male" && sex !== "female")) continue;
      const band: [number, number] = [Number(bm[1]), Number(bm[2])];
      if (!bands.some((b) => b[0] === band[0] && b[1] === band[1])) continue;
      const sp = c.shares_pct as Record<string, number> | undefined;
      const offsets = Object.entries((c.offsets as Record<string, { shift_gt_10pp?: boolean }>) ?? {}).filter(([, o]) => o.shift_gt_10pp);
      out.push({
        key,
        sex,
        band,
        quantiles: parseQuantiles({ percentiles: c.percentiles }),
        shares: sp ? { below_normal: (sp.critical_low ?? 0) / 100, above_normal: (sp.critical_high ?? 0) / 100, optimal: (sp.optimal ?? 0) / 100 } : null,
        shares_rows: Array.isArray(c.eva_rows) ? (c.eva_rows as DistEntry["shares_rows"]) : null,
        method_offset: offsets.length ? { known: true, status: offsets.every(([sc]) => flagged.has(`${key}|${cell}|${sc}`)) ? "flagged" : undefined } : null,
        n: typeof c.n === "number" ? c.n : undefined,
      });
    }
  }
  return out.sort((a, b) => `${a.key}|${a.sex}|${a.band[0]}`.localeCompare(`${b.key}|${b.sex}|${b.band[0]}`));
}

export function distEntries(doc: unknown, bands: [number, number][] = [[20, 39], [40, 59], [60, 69], [70, 79]]): DistEntry[] {
  if (doc && typeof doc === "object" && !Array.isArray(doc)) {
    const g = generatorEntries(doc as Record<string, unknown>, bands);
    if (g) return g;
  }
  let raw: Record<string, unknown>[] = [];
  if (Array.isArray(doc)) raw = doc as Record<string, unknown>[];
  else if (doc && typeof doc === "object") {
    const d = doc as Record<string, unknown>;
    if (Array.isArray(d.entries)) raw = d.entries as Record<string, unknown>[];
    else if (d.markers && typeof d.markers === "object")
      for (const [k, v] of Object.entries(d.markers as Record<string, unknown>)) if (Array.isArray(v)) for (const e of v as Record<string, unknown>[]) raw.push({ key: k, ...e });
  }
  const out: DistEntry[] = [];
  for (const e of raw) {
    const key = String(e.biomarker_key ?? e.marker_key ?? e.eva_key ?? e.key ?? "");
    const sex = String(e.sex ?? "").toLowerCase();
    const band = parseBand(e);
    if (!key || (sex !== "male" && sex !== "female") || !band) continue;
    const s = e.shares as Record<string, number> | undefined;
    out.push({
      key,
      sex: sex as Sex,
      band,
      quantiles: parseQuantiles(e),
      shares: s && typeof s.optimal === "number" ? { below_normal: s.below_normal ?? 0, above_normal: s.above_normal ?? 0, optimal: s.optimal } : null,
      method_offset: (e.method_offset as DistEntry["method_offset"]) ?? null,
    });
  }
  return out.sort((a, b) => `${a.key}|${a.sex}|${a.band[0]}`.localeCompare(`${b.key}|${b.sex}|${b.band[0]}`));
}

/** P(X < x) by linear interpolation of the quantile function (0 or 1 beyond the extremes). */
export function cdf(q: [number, number][], x: number): number {
  // Below the lowest quantile given: at most p_min; taken as 0 (beyond the table), p_min at the quantile itself.
  if (x < q[0][1]) return 0;
  if (x === q[0][1]) return q[0][0];
  for (let i = 1; i < q.length; i++) {
    const [p0, v0] = q[i - 1];
    const [p1, v1] = q[i];
    if (x <= v1) return v1 === v0 ? p1 : p0 + ((p1 - p0) * (x - v0)) / (v1 - v0);
  }
  return 1; // beyond the highest quantile given
}

/** Shares of the population below normal, above normal and optimal, for a row. */
export function sharesFor(q: [number, number][], r: SeedReviewedRow): { below_normal: number; above_normal: number; optimal: number } {
  const below = r.normal_low != null ? cdf(q, r.normal_low) : 0;
  const above = r.normal_high != null ? 1 - cdf(q, r.normal_high) : 0;
  // Optimal: the classifier's optimal set is [max(normal_low, optimal_low), min(normal_high, optimal_high)].
  const lo = Math.max(r.normal_low ?? -Infinity, r.optimal_low ?? -Infinity);
  const hi = Math.min(r.normal_high ?? Infinity, r.optimal_high ?? Infinity);
  const optimal = Math.max(0, (hi === Infinity ? 1 : cdf(q, hi)) - (lo === -Infinity ? 0 : cdf(q, lo)));
  return { below_normal: below, above_normal: above, optimal };
}

const N1: Check = {
  id: "N1",
  group: "population",
  title: "Population sense on NHANES",
  how: "script",
  run(ctx) {
    const file = path.join(ctx.workDir, "nhanes", "distributions.json");
    const doc = ctx.load(file);
    if (doc == null) return { id: "N1", status: "blocked", summary: `blocked: ${rel(ctx, file)} is missing`, failures: [], blocked_on: rel(ctx, file) };
    const rows = seedReviewedRows(ctx);
    if (!rows) return { id: "N1", status: "blocked", summary: "blocked: seed files missing", failures: [], blocked_on: `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json` };
    const seed = loadSeed(ctx.seedDir);
    const basis = new Map((seed?.rows ?? []).map((r) => [`${r.biomarker_key}|${r.sex}|${r.age_group_en}`, r.reference_basis]));
    const res = ctx.load<Record<string, { kind?: string; text?: string }>>(path.join(ctx.workDir, "nhanes", "n1-resolutions.json")) ?? {};
    const t = ctx.thresholds;
    const outMin = Number(t.N1_reference_outside_min ?? 0.02);
    const outMax = Number(t.N1_reference_outside_max ?? 0.15);
    const minority = Number(t.N1_minority_label_below ?? 0.1);
    const majority = Number(t.N1_justification_above ?? 0.95);
    const pqAbove = Number(t.N1_physician_question_non_optimal_above ?? 0.6);
    const pqBand = (t.N1_physician_question_age_band as number[] | undefined) ?? [70, 79];
    const failures: Failure[] = [];
    const resolved = (k: string, kinds: string[]) => !!res[k] && kinds.includes(String(res[k].kind)) && !!String(res[k].text ?? "").trim();
    const entries = distEntries(doc, (t.N1_age_bands as [number, number][] | undefined) ?? [[20, 39], [40, 59], [60, 69], [70, 79]]);
    let tested = 0;
    let exact = 0;
    let noRow = 0;
    let decision = 0;
    for (const e of entries) {
      const mid = Math.round((e.band[0] + e.band[1]) / 2);
      const r = pickedFor(rows, e.sex, mid).get(e.key);
      const band = `${e.band[0]}-${e.band[1]}`;
      const base = `${e.key}|${e.sex}|${band}`;
      if (!r) {
        noRow++;
        continue;
      }
      // The producer's exact shares while its rows still equal today's row; else interpolated from the percentiles.
      const same = (e.shares_rows ?? []).length === 1 && ["normal_low", "normal_high", "optimal_low", "optimal_high"].every((f) => (e.shares_rows![0] as Record<string, unknown>)[f] === (r as unknown as Record<string, unknown>)[f]);
      const s = e.shares && (same || !e.quantiles) ? e.shares : e.quantiles ? sharesFor(e.quantiles, r) : null;
      if (same) exact++;
      if (!s) continue;
      tested++;
      const isDecision = basis.get(`${r.biomarker_key}|${r.sex}|${r.age_group_en}`) === "decision_limit";
      const outside = s.below_normal + s.above_normal;
      if (isDecision) decision++;
      else if ((r.normal_low != null || r.normal_high != null) && (outside < outMin || outside > outMax) && !resolved(`${base}|reference_outside`, ["justification"]))
        failures.push({ key: `${base}|reference_outside`, detail: `${(outside * 100).toFixed(1)}% outside the reference limits (rule ${outMin * 100}% to ${outMax * 100}%)` });
      const hasBand = r.optimal_low != null || r.optimal_high != null;
      if (hasBand && s.optimal < minority && !resolved(`${base}|optimal_minority`, ["label", "justification"]))
        failures.push({ key: `${base}|optimal_minority`, detail: `${(s.optimal * 100).toFixed(1)}% optimal: needs the "reached by a minority" label` });
      if (hasBand && s.optimal > majority && !resolved(`${base}|optimal_majority`, ["justification"]))
        failures.push({ key: `${base}|optimal_majority`, detail: `${(s.optimal * 100).toFixed(1)}% optimal: above ${majority * 100}% needs a justification` });
      if (hasBand && e.band[0] >= pqBand[0] && e.band[1] <= pqBand[1] && 1 - s.optimal > pqAbove && !resolved(`${base}|non_optimal_70_79`, ["physician_question"]))
        failures.push({ key: `${base}|non_optimal_70_79`, detail: `${((1 - s.optimal) * 100).toFixed(1)}% non-optimal at ${band}: must be a physician question` });
      if (e.method_offset?.known && e.method_offset.status !== "applied" && e.method_offset.status !== "flagged")
        failures.push({ key: `${base}|method_offset`, detail: "documented method offset neither applied nor flagged" });
    }
    const metrics: Metrics = { entries: entries.length, tested, exact_shares: exact, without_row: noRow, decision_limit_rows: decision, resolutions: Object.keys(res).length };
    if (!tested) return { id: "N1", status: "blocked", summary: `blocked: ${rel(ctx, file)} has no usable entries (${entries.length} parsed)`, failures: [], blocked_on: `${rel(ctx, file)} entries with quantiles or shares`, metrics };
    return { id: "N1", status: failures.length ? "fail" : "pass", summary: `${failures.length} unresolved population rules over ${tested} marker, sex and age-band entries`, failures: sortFailures(failures), metrics };
  },
};

export const checks: Check[] = [N1];
