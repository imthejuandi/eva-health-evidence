/**
 * M. Messages and wording (M1-M5) of docs/signoff/ACCEPTANCE-TEST.md.
 * Zone reachability uses the app's classifier (src/lib/biomarkers/zone-classifier.ts).
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, CheckResult, Failure } from "../types";
import { rowKey, rowsFor, sortFailures, ZONES, type Row, type Zone } from "../lib/seed";
import { extractNumbers, type Lang } from "../lib/format";
import { classifyZone } from "../../../src/lib/biomarkers/zone-classifier";

const result = (id: string, failures: Failure[], summary: string, metrics?: Record<string, number | string | boolean>): CheckResult => ({
  id,
  status: failures.length ? "fail" : "pass",
  summary,
  failures: sortFailures(failures),
  ...(metrics ? { metrics } : {}),
});
const blocked = (id: string, on: string): CheckResult => ({ id, status: "blocked", summary: `blocked: ${on} is missing`, failures: [], blocked_on: on });

/** The zones the classifier can return for some value, given the row's bounds. */
export function reachableZones(r: Pick<Row, "normal_low" | "normal_high" | "optimal_low" | "optimal_high">): Set<Zone> {
  const bounds = [r.normal_low, r.normal_high, r.optimal_low, r.optimal_high].filter((b): b is number => b != null);
  const out = new Set<Zone>();
  if (!bounds.length) return out;
  const lo = Math.min(...bounds);
  const hi = Math.max(...bounds);
  const span = Math.max(hi - lo, Math.abs(hi) * 0.01, 0.01);
  const probes = new Set<number>([lo - span, lo - span * 10, hi + span, hi + span * 10]);
  const sorted = [...new Set(bounds)].sort((a, b) => a - b);
  for (let i = 0; i < sorted.length; i++) {
    const b = sorted[i];
    const eps = Math.max(Math.abs(b) * 1e-6, 1e-9);
    probes.add(b);
    probes.add(b - eps);
    probes.add(b + eps);
    if (i + 1 < sorted.length) probes.add((b + sorted[i + 1]) / 2);
  }
  for (const v of probes) {
    const z = classifyZone(v, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high);
    if (z !== "unclassified") out.add(z);
  }
  return out;
}

export interface ReachabilityReport {
  failures: Failure[];
  deletions: string[];
  metrics: Record<string, number | string>;
}

export function checkReachability(rows: Row[]): ReachabilityReport {
  const failures: Failure[] = [];
  const deletions: string[] = [];
  let reachable = 0;
  for (const r of rows) {
    const k = rowKey(r);
    const zones = reachableZones(r);
    for (const z of ZONES) {
      const m = r.msg[z];
      if (zones.has(z)) {
        reachable++;
        const missing = (["en", "es"] as const).filter((l) => !m[l]);
        if (missing.length) failures.push({ key: `${k}|${z}`, detail: `reachable zone has no ${missing.join(" or ")} message` });
      } else if (m.en || m.es) {
        deletions.push(`${k}|${z}`);
      }
    }
  }
  return { failures, deletions: deletions.sort(), metrics: { rows: rows.length, reachable_zones: reachable, reachable_without_message: failures.length, messages_on_unreachable_zones: deletions.length } };
}

const M1: Check = {
  id: "M1",
  group: "messages",
  title: "A message for every reachable zone",
  how: "script",
  run(ctx) {
    const data = rowsFor(ctx);
    if (!data) return blocked("M1", `${ctx.seedDir}/biomarker-ranges-en.json`);
    const rep = checkReachability(data.rows);
    return result("M1", rep.failures, `${rep.failures.length} reachable zones without a message over ${rep.metrics.reachable_zones}; ${rep.deletions.length} messages on unreachable zones listed for deletion`, { ...rep.metrics, deletions: rep.deletions.join("\n") });
  },
};

// ─── M2 four elements ───

const ELEMENTS: Record<Lang, { id: string; re: RegExp }[]> = {
  en: [
    { id: "meaning", re: /\b(may|can|could|might|reflect|suggest|indicat|mean|linked|associated|sign of|is consistent)/i },
    { id: "benign_causes", re: /\b(infection|dehydrat|exercise|workout|training|fasting|non-fasting|supplement|medication|pregnan|sample|haemolys|hemolys|spurious|benign|harmless|temporar|transient|recent meal|alcohol|stress|time of day|morning|creatine|common|many (healthy )?(adults|people))/i },
    { id: "confirm_repeat", re: /\b(repeat|confirm|re-?test|recheck|second (test|sample|result)|another (test|sample|result)|persist|stays|remains|on two|follow-up test|next test)/i },
    { id: "who_when", re: /\b(doctor|physician|GP|clinician|specialist|medical attention|medical contact|same day|within (a )?(day|days|week|weeks|month|months)|soon|promptly|without delay|today|at your next)/i },
  ],
  es: [
    { id: "meaning", re: /\b(puede|podría|refleja|sugiere|indica|significa|asociad|relacionad|vinculad|señal de|es compatible)/i },
    { id: "benign_causes", re: /\b(infecci|deshidrat|ejercicio|entrenamiento|ayuno|sin ayuno|suplemento|medicamento|medicación|embaraz|muestra|hemóli|hemoli|espuri|benign|inofensiv|temporal|transitori|comida reciente|alcohol|estrés|hora del día|mañana|creatina|frecuente|muchas personas|muchos adultos)/i },
    { id: "confirm_repeat", re: /\b(repet|repít|confirm|segunda (prueba|muestra|analítica)|otra (prueba|muestra|analítica)|persist|se mantiene|sigue|en dos|próxima (prueba|analítica)|nuevo análisis)/i },
    { id: "who_when", re: /\b(médico|medica|profesional sanitario|especialista|atención médica|contacto médico|el mismo día|en (un |una )?(día|días|semana|semanas|mes|meses)|pronto|sin demora|hoy|en tu próxima)/i },
  ],
};

export function missingElements(text: string, lang: Lang): string[] {
  return ELEMENTS[lang].filter((e) => !e.re.test(text)).map((e) => e.id);
}

const M2: Check = {
  id: "M2",
  group: "messages",
  title: "Out-of-range messages carry four elements",
  how: "script+judge",
  run(ctx) {
    const data = rowsFor(ctx);
    if (!data) return blocked("M2", `${ctx.seedDir}/biomarker-ranges-en.json`);
    const failures: Failure[] = [];
    let messages = 0;
    for (const r of data.rows) {
      const zones = reachableZones(r);
      for (const z of ["critical_low", "critical_high"] as const) {
        if (!zones.has(z)) continue;
        for (const lang of ["en", "es"] as const) {
          const text = r.msg[z][lang];
          if (!text) continue;
          messages++;
          const missing = missingElements(text, lang);
          if (missing.length) failures.push({ key: `${rowKey(r)}|${z}|${lang}`, detail: `lacks: ${missing.join(", ")}` });
        }
      }
    }
    return result("M2", failures, `${messages - failures.length} of ${messages} out-of-range messages carry all four elements (script heuristic; meaning is judged)`, { messages, complete: messages - failures.length, judge_pending: true });
  },
};

// ─── M3 lexicon ───

export interface TierRules {
  terms: string[];
  regex: string[];
  allow: string[];
}
export interface Lexicon {
  flags: string;
  /** language → tier ("any" applies to every text, "non_critical" to every text outside the critical tier) → rules */
  langs: Record<string, Record<string, TierRules>>;
}

const strings = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);

/**
 * The banned-term lexicon: the first fenced json block of wording-rules.md (the fence may carry a label, as in
 * "```json banned_terms"). Per language and tier it holds `terms` (whole-word phrases), `regex` (patterns compiled
 * with the document's `flags`) and `allow` (phrases removed from the text before matching). A tier given as a
 * plain list of strings is read as terms. The `required` block is not a tier.
 */
export function parseLexicon(markdown: string): Lexicon | null {
  const m = markdown.match(/```json[^\n]*\n([\s\S]*?)\n```/);
  if (!m) return null;
  let doc: Record<string, unknown>;
  try {
    doc = JSON.parse(m[1]) as Record<string, unknown>;
  } catch {
    return null;
  }
  const src = (doc.banned && typeof doc.banned === "object" ? doc.banned : doc) as Record<string, unknown>;
  const langs: Record<string, Record<string, TierRules>> = {};
  for (const lang of ["en", "es"]) {
    const tiers = src[lang];
    if (!tiers || typeof tiers !== "object") continue;
    for (const [tier, v] of Object.entries(tiers as Record<string, unknown>)) {
      if (tier === "required") continue;
      let rules: TierRules | null = null;
      if (Array.isArray(v)) rules = { terms: strings(v), regex: [], allow: [] };
      else if (v && typeof v === "object") {
        const o = v as Record<string, unknown>;
        if (Array.isArray(o.terms) || Array.isArray(o.regex)) rules = { terms: strings(o.terms), regex: strings(o.regex), allow: strings(o.allow) };
      }
      if (rules) (langs[lang] ??= {})[tier === "all" ? "any" : tier] = rules;
    }
  }
  if (!Object.keys(langs).length) return null;
  return { flags: typeof doc.flags === "string" ? doc.flags : "i", langs };
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** The banned phrases a text contains under the given rules, lower-cased, de-duplicated and sorted. */
export function lexiconHits(text: string, rules: TierRules[], flags = "i"): string[] {
  let t = text;
  for (const a of rules.flatMap((r) => r.allow)) t = t.replace(new RegExp(escapeRe(a), "giu"), " ");
  const hits = new Set<string>();
  for (const term of rules.flatMap((r) => r.terms)) {
    if (new RegExp(`(?<![\\p{L}])${escapeRe(term)}(?![\\p{L}])`, "iu").test(t)) hits.add(term.toLowerCase());
  }
  for (const pattern of rules.flatMap((r) => r.regex)) {
    let re: RegExp;
    try {
      re = new RegExp(pattern, flags.replace(/g/g, ""));
    } catch {
      continue;
    }
    const mm = t.match(re);
    if (mm) hits.add(mm[0].replace(/^[\s.;:!?]+/, "").trim().toLowerCase());
  }
  return [...hits].filter(Boolean).sort();
}

/** String literals in a TS/TSX source: double, single and template quoted, longer than a few words. */
export function stringLiterals(src: string): string[] {
  const out: string[] = [];
  for (const m of src.matchAll(/"((?:[^"\\\n]|\\.){12,})"|'((?:[^'\\\n]|\\.){12,})'|`((?:[^`\\]|\\.){12,})`/g)) out.push((m[1] ?? m[2] ?? m[3]).replace(/\$\{[^}]*\}/g, " "));
  return out;
}

const APP_NOTICE_FILES = ["src/lib/biomarkers/zone-config.ts", "src/components/dashboard/MedicalDisclaimer.tsx"];

const M3: Check = {
  id: "M3",
  group: "messages",
  title: "Wording rules",
  how: "script",
  run(ctx) {
    const rulesFile = path.join(ctx.workDir, "governance", "wording-rules.md");
    const rules = ctx.load<string>(rulesFile);
    if (!rules) return blocked("M3", path.relative(ctx.root, rulesFile));
    const lex = parseLexicon(rules);
    if (!lex) return blocked("M3", `${path.relative(ctx.root, rulesFile)} (a fenced json block of banned terms per language and tier)`);
    const data = rowsFor(ctx);
    if (!data) return blocked("M3", `${ctx.seedDir}/biomarker-ranges-en.json`);
    const failures: Failure[] = [];
    const rulesFor = (lang: string, tiers: string[]): TierRules[] => tiers.map((t) => lex.langs[lang]?.[t]).filter((r): r is TierRules => !!r);
    const nonCritical = ["any", "non_critical"];
    let texts = 0;
    for (const r of data.rows) {
      for (const z of ZONES) {
        for (const lang of ["en", "es"] as const) {
          const text = r.msg[z][lang];
          if (!text) continue;
          texts++;
          // No row carries a critical tier yet: every row message is non-critical wording.
          const hits = lexiconHits(text, rulesFor(lang, nonCritical), lex.flags);
          if (hits.length) failures.push({ key: `row|${rowKey(r)}|${z}|${lang}`, detail: `banned: ${hits.join(", ")}` });
        }
      }
      // The clinical note the app shows with the row (Clinical_Notes / Notas_Clínicas; wording-rules.md scope) is
      // non-critical text too.
      for (const lang of ["en", "es"] as const) {
        const note = lang === "en" ? r.clinical_notes_en : r.clinical_notes_es;
        if (!note) continue;
        texts++;
        const hits = lexiconHits(note, rulesFor(lang, nonCritical), lex.flags);
        if (hits.length) failures.push({ key: `row|${rowKey(r)}|clinical_notes|${lang}`, detail: `banned: ${hits.join(", ")}` });
      }
    }
    const files = [...APP_NOTICE_FILES, ...(fs.existsSync(path.join(ctx.root, "src/lib/email/templates")) ? fs.readdirSync(path.join(ctx.root, "src/lib/email/templates")).filter((f) => f.endsWith(".ts")).sort().map((f) => `src/lib/email/templates/${f}`) : [])];
    for (const f of files) {
      const src = ctx.load<string>(f);
      if (!src) continue;
      stringLiterals(src).forEach((lit, i) => {
        // Identifiers such as the zone codes "critical_low" are not client text (wording-rules.md, notes).
        if (/^[\w.:/-]+$/.test(lit.trim())) return;
        texts++;
        const hits = [...new Set([...lexiconHits(lit, rulesFor("en", nonCritical), lex.flags), ...lexiconHits(lit, rulesFor("es", nonCritical), lex.flags)])].sort();
        if (hits.length) failures.push({ key: `app|${f}|${i}`, detail: `banned: ${hits.join(", ")} in "${lit.slice(0, 80)}"` });
      });
    }
    return result("M3", failures, `${failures.length} banned-wording hits over ${texts} texts (row messages and clinical notes, app notices, emails)`, { texts, files: files.length });
  },
};

// ─── M4 numbers vs bounds ───

/**
 * Every number in a row's messages and in its clinical note (the text the app shows with the row) is one of the row's
 * bounds or is in its explanatory-numbers list, so no client text quotes a number the row does not have.
 */
export function checkMessageNumbers(rows: Row[]): Failure[] {
  const failures: Failure[] = [];
  for (const r of rows) {
    const bounds = new Set([r.normal_low, r.normal_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high, ...r.explanatory_numbers].filter((b): b is number => b != null));
    const texts: [string, "en" | "es", string | null][] = [];
    for (const z of ZONES) for (const lang of ["en", "es"] as const) texts.push([z, lang, r.msg[z][lang]]);
    texts.push(["clinical_notes", "en", r.clinical_notes_en], ["clinical_notes", "es", r.clinical_notes_es]);
    for (const [where, lang, text] of texts) {
      if (!text) continue;
      const nums = extractNumbers(text, lang);
      const bad = nums.filter((n) => ![...bounds].some((b) => Math.abs(b - n) < 1e-9));
      if (bad.length) failures.push({ key: `${rowKey(r)}|${where}|${lang}`, detail: `numbers ${[...new Set(bad)].join(", ")} are neither a bound (${[...bounds].sort((a, b) => a - b).join(", ") || "none"}) nor in the explanatory-numbers list` });
    }
  }
  return failures;
}

const M4: Check = {
  id: "M4",
  group: "messages",
  title: "Numbers in messages equal the row's bounds",
  how: "script",
  run(ctx) {
    const data = rowsFor(ctx);
    if (!data) return blocked("M4", `${ctx.seedDir}/biomarker-ranges-en.json`);
    const failures = checkMessageNumbers(data.rows);
    const withExplanatory = data.rows.filter((r) => r.explanatory_numbers.length).length;
    return result("M4", failures, `${failures.length} messages or clinical notes quote numbers that are not the row's bounds`, { rows: data.rows.length, rows_with_explanatory_numbers: withExplanatory });
  },
};

const M5: Check = {
  id: "M5",
  group: "messages",
  title: "Spanish and English messages mean the same",
  how: "judge",
  run(ctx) {
    const dir = path.join(ctx.workDir, "judges", "final");
    const file = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => /^M5.*\.json$/i.test(f)).sort().pop() : undefined;
    if (!file) return blocked("M5", `${path.relative(ctx.root, dir)}/M5-*.json (judge result)`);
    const doc = ctx.load<{ mismatches?: { key: string; detail: string }[] }>(path.join(dir, file));
    const failures = (doc?.mismatches ?? []).map((m) => ({ key: m.key, detail: m.detail }));
    return result("M5", failures, `${failures.length} EN/ES meaning or tone mismatches (judge file ${file})`, { judge_file: file });
  },
};

export const checks: Check[] = [M1, M2, M3, M4, M5];
