/**
 * X. Consistency between ranges, score and biological age (X1-X2) of docs/signoff/ACCEPTANCE-TEST.md.
 *
 * X1: for each tier (base, plus_hba1c), sex and version 3 marker, on 400 points from the plausibility floor to the
 *     ceiling (src/lib/biomarkers/data/plausibility_bounds.json, converted to the EVA unit; geometric spacing for a
 *     log-transformed marker, linear otherwise), the marker's contribution to the biological age is computed with the
 *     module's own clamp and transform (biological-age-v3.ts __test.clampValue and the tier's linear-form weight;
 *     BA = K + w_age·age + Σ w_j f_j, so the contribution difference is the biological-age difference, verified
 *     against computeBiologicalAgeV3 on sample points). Outside the optimal band (the app's classifier on the
 *     person's row, where the score v2 penalty is above zero), the biological age must not be lower than at the
 *     nearest optimal bound by more than the tolerance, and must not reverse toward the band moving outward.
 *     Violations are grouped into segments; segments listed in docs/signoff/work/v3/consistency-exceptions.json
 *     with accepted_by_judge true are exceptions, capped by X1_max_exceptions.
 * X2: flat segments (outside optimal, the score penalty moves, the biological age does not) must each be named in
 *     docs/signoff/work/v3/display-copy.json (its flat_segments list, or its English and Spanish copy).
 */
import fs from "node:fs";
import path from "node:path";
import type { Check, CheckResult, Ctx, Failure } from "../types";
import { sortFailures } from "../lib/seed";
import { computeBiologicalAgeV3, BA_V3_TIER_MARKERS, __test as V3, type BiologicalAgeV3Tier } from "../../../src/lib/biomarkers/biological-age-v3";
import { classifyZone } from "../../../src/lib/biomarkers/zone-classifier";
import { reviewedPenalty, type ReviewedRow } from "../../../src/lib/biomarkers/longevity-score";
import { pickReferenceRows } from "../../../src/lib/biomarkers/reference-row";
import { seedReviewedRows } from "./score";

type Metrics = Record<string, number | string | boolean>;
type Sex = "male" | "female";
const rel = (ctx: Ctx, p: string) => path.relative(ctx.root, path.resolve(ctx.root, p)).split(path.sep).join("/");

export const TIERS: BiologicalAgeV3Tier[] = ["base", "plus_hba1c"];
export const SEXES: Sex[] = ["female", "male"];

interface MarkerSpec {
  eva_key: string;
  eva_unit: string;
  factor: number;
  transform: "log" | "linear";
  clamp: { lower?: Partial<Record<Sex, number>>; upper?: Partial<Record<Sex, number>> };
}
const MODEL = V3.MODEL as unknown as {
  markers: Record<string, MarkerSpec>;
  tiers: Record<BiologicalAgeV3Tier, { markers: string[]; linear_form: { marker_weights: Record<string, number> } }>;
};
const MODEL_NAME: Record<string, string> = Object.fromEntries(Object.entries(MODEL.markers).map(([m, s]) => [s.eva_key, m]));

/** The marker's contribution to the biological age (years), from its EVA-unit value: w · f(clamp(x · factor)). */
export function v3Contribution(tier: BiologicalAgeV3Tier, sex: Sex, evaKey: string, x: number): number {
  const m = MODEL_NAME[evaKey];
  const spec = MODEL.markers[m];
  const w = MODEL.tiers[tier].linear_form.marker_weights[m];
  const c = (V3.clampValue as unknown as (x: number, spec: MarkerSpec, sex: Sex) => { value: number })(x * spec.factor, spec, sex).value;
  return w * (spec.transform === "log" ? Math.log(c) : c);
}

export const V3_REFERENCE_VALUES: Record<string, number> = { albumin: 44, alp: 70, hs_crp: 1, creatinine: 0.9, bun: 14, ggt: 20, hba1c: 5.2 };
const V3_UNITS: Record<string, string> = Object.fromEntries(Object.values(MODEL.markers).map((s) => [s.eva_key, s.eva_unit]));

/** The module's biological age with one marker replaced (others at reference values), for verification. */
export function moduleBa(tier: BiologicalAgeV3Tier, sex: Sex, evaKey: string, x: number, age = 50): number | null {
  const keys = BA_V3_TIER_MARKERS[tier];
  const inputs = keys.map((k) => ({ code: k, value: k === evaKey ? x : V3_REFERENCE_VALUES[k], unit: V3_UNITS[k] }));
  const out = computeBiologicalAgeV3(inputs, sex, age);
  return out.ba == null || out.tier !== tier ? null : out.ba;
}

/** Plausibility floor and ceiling of the version 3 markers in their EVA units. */
const PLAUSIBILITY_NAMES: Record<string, string> = {
  albumin: "Albúmina",
  creatinine: "Creatinina",
  bun: "BUN (Nitrógeno Ureico en Sangre)",
  alp: "ALP (Fosfatasa Alcalina)",
  ggt: "GGT (Gamma-glutamil Transferasa)",
  hs_crp: "PCR de Alta Sensibilidad (hs-PCR)",
  hba1c: "HbA1c (Hemoglobina Glicosilada)",
};
const UNIT_FACTOR: Record<string, number> = { "g/dL>g/L": 10, "g/L>g/dL": 0.1, "mg/dL>mg/L": 10, "mg/L>mg/dL": 0.1 };

export function plausibilityBounds(root: string): Record<string, [number, number]> | null {
  const file = path.resolve(root, "src/lib/biomarkers/data/plausibility_bounds.json");
  if (!fs.existsSync(file)) return null;
  const doc = JSON.parse(fs.readFileSync(file, "utf8")) as { markers: Record<string, { lower: number; upper: number; unit: string }> };
  const out: Record<string, [number, number]> = {};
  for (const [key, name] of Object.entries(PLAUSIBILITY_NAMES)) {
    const b = doc.markers[name];
    if (!b) continue;
    const f = b.unit === V3_UNITS[key] ? 1 : UNIT_FACTOR[`${b.unit}>${V3_UNITS[key]}`];
    if (f == null) continue;
    out[key] = [b.lower * f, b.upper * f];
  }
  return out;
}

export function scanPoints(evaKey: string, floor: number, ceiling: number, n = 400): number[] {
  const log = MODEL.markers[MODEL_NAME[evaKey]].transform === "log" && floor > 0;
  return Array.from({ length: n }, (_, i) => (log ? floor * Math.pow(ceiling / floor, i / (n - 1)) : floor + ((ceiling - floor) * i) / (n - 1)));
}

export interface Segment {
  tier: BiologicalAgeV3Tier;
  sex: Sex;
  marker: string;
  side: "low" | "high";
  kind: "lower_than_bound" | "reversal" | "flat";
  from: number;
  to: number;
  worst_years: number;
  row: string;
}

const segKey = (s: Pick<Segment, "tier" | "sex" | "marker" | "side" | "kind">) => `${s.marker}|${s.sex}|${s.tier}|${s.side}|${s.kind}`;
const round = (n: number, d = 4) => Math.round(n * 10 ** d) / 10 ** d;

/**
 * The scan for one tier, sex and marker against one reviewed row. Returns violation segments (lower_than_bound,
 * reversal) and flat segments.
 */
export function scanMarker(tier: BiologicalAgeV3Tier, sex: Sex, marker: string, row: ReviewedRow, floor: number, ceiling: number, opts: { points?: number; tolerance?: number } = {}): Segment[] {
  const tol = opts.tolerance ?? 0.05;
  const xs = scanPoints(marker, floor, ceiling, opts.points ?? 400);
  const zone = (v: number) => classifyZone(v, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high);
  const c = (v: number) => v3Contribution(tier, sex, marker, v);
  const rowKey = `${row.biomarker_key}|${row.sex}|${row.age_group_en}`;
  const out: Segment[] = [];
  const opt = xs.filter((v) => zone(v) === "optimal");
  // The nearest optimal bound on each side: the row's bound, else the edge of the optimal points.
  const lowBound = row.optimal_low ?? (opt.length ? Math.min(...opt) : null);
  const highBound = row.optimal_high ?? (opt.length ? Math.max(...opt) : null);
  for (const side of ["low", "high"] as const) {
    const bound = side === "low" ? lowBound : highBound;
    if (bound == null) continue;
    const outward = side === "low" ? xs.filter((v) => v < bound).reverse() : xs.filter((v) => v > bound);
    const cb = c(bound);
    let runMax = cb;
    let prevC = cb;
    let prevPen = reviewedPenalty(bound, row);
    // One open segment per kind; a point that does not violate closes it, so segments are contiguous runs.
    const open: Record<Segment["kind"], Segment | null> = { lower_than_bound: null, reversal: null, flat: null };
    for (const v of outward) {
      const z = zone(v);
      const pen = reviewedPenalty(v, row);
      const cv = c(v);
      const hit: Partial<Record<Segment["kind"], number>> = {};
      if (z !== "optimal" && pen > 0) {
        if (cv < cb - tol) hit.lower_than_bound = cb - cv;
        else if (cv < runMax - tol) hit.reversal = runMax - cv;
        if (Math.abs(cv - prevC) < 1e-12 && Math.abs(pen - prevPen) > 1e-12) hit.flat = 0;
      }
      for (const kind of ["lower_than_bound", "reversal", "flat"] as const) {
        const d = hit[kind];
        if (d === undefined) {
          open[kind] = null;
          continue;
        }
        const seg = open[kind];
        if (seg) {
          seg.to = v;
          seg.worst_years = Math.max(seg.worst_years, d);
        } else {
          const created: Segment = { tier, sex, marker, side, kind, from: v, to: v, worst_years: d, row: rowKey };
          out.push(created);
          open[kind] = created;
        }
      }
      runMax = Math.max(runMax, cv);
      prevC = cv;
      prevPen = pen;
    }
  }
  return out.map((s) => ({ ...s, from: round(Math.min(s.from, s.to)), to: round(Math.max(s.from, s.to)), worst_years: round(s.worst_years) }));
}

/** The person's row for each marker and sex: the rows the app's picker chooses at any age 20 to 84. */
export function rowsForMarker(rows: readonly ReviewedRow[], marker: string, sex: Sex): ReviewedRow[] {
  const own = rows.filter((r) => r.biomarker_key === marker);
  const seen = new Map<string, ReviewedRow>();
  for (let age = 20; age <= 84; age++) {
    const r = pickReferenceRows(own, sex, age).picked.get(marker);
    if (r) seen.set(`${r.sex}|${r.age_group_en}|${r.optimal_low}|${r.optimal_high}|${r.normal_low}|${r.normal_high}`, r);
  }
  return [...seen.values()];
}

export function scanAll(rows: readonly ReviewedRow[], bounds: Record<string, [number, number]>, opts: { points?: number; tolerance?: number } = {}): { segments: Segment[]; missing: string[]; scans: number } {
  const segments: Segment[] = [];
  const missing: string[] = [];
  let scans = 0;
  for (const tier of TIERS)
    for (const sex of SEXES)
      for (const marker of BA_V3_TIER_MARKERS[tier]) {
        const b = bounds[marker];
        const rs = rowsForMarker(rows, marker, sex);
        if (!b || !rs.length) {
          missing.push(`${marker}|${sex}|${tier}|${!b ? "plausibility" : "row"}`);
          continue;
        }
        for (const r of rs) {
          scans++;
          segments.push(...scanMarker(tier, sex, marker, r, b[0], b[1], opts));
        }
      }
  return { segments, missing: [...new Set(missing)].sort(), scans };
}

/** Contribution differences against the module's biological age, on sample points; returns the max mismatch. */
export function verifyAgainstModule(bounds: Record<string, [number, number]>): number {
  let max = 0;
  for (const tier of TIERS)
    for (const sex of SEXES)
      for (const marker of BA_V3_TIER_MARKERS[tier]) {
        const b = bounds[marker];
        if (!b) continue;
        const ref = V3_REFERENCE_VALUES[marker];
        const ba0 = moduleBa(tier, sex, marker, ref);
        if (ba0 == null) continue;
        for (const x of scanPoints(marker, b[0], b[1], 9)) {
          const ba = moduleBa(tier, sex, marker, x);
          if (ba == null) continue;
          max = Math.max(max, Math.abs(ba - ba0 - (v3Contribution(tier, sex, marker, x) - v3Contribution(tier, sex, marker, ref))));
        }
      }
  return max;
}

interface ExceptionEntry {
  marker: string;
  side: "low" | "high";
  sex?: Sex | "both";
  tier?: BiologicalAgeV3Tier | "both";
  accepted_by_judge?: boolean;
  reason?: string;
}

function covers(e: ExceptionEntry, s: Segment): boolean {
  return e.accepted_by_judge === true && e.marker === s.marker && e.side === s.side && (!e.sex || e.sex === "both" || e.sex === s.sex) && (!e.tier || e.tier === "both" || e.tier === s.tier);
}

const X1: Check = {
  id: "X1",
  group: "consistency",
  title: "Biological age never rewards leaving the optimal band",
  how: "script",
  run(ctx) {
    const rows = seedReviewedRows(ctx);
    if (!rows) return { id: "X1", status: "blocked", summary: "blocked: seed files missing", failures: [], blocked_on: `${rel(ctx, ctx.seedDir)}/biomarker-ranges-en.json` };
    const bounds = plausibilityBounds(ctx.root);
    if (!bounds) return { id: "X1", status: "blocked", summary: "blocked: plausibility bounds missing", failures: [], blocked_on: "src/lib/biomarkers/data/plausibility_bounds.json" };
    const tol = Number(ctx.thresholds.X1_tolerance_years ?? 0.05);
    const points = Number(ctx.thresholds.X1_points_per_marker ?? 400);
    const cap = Number(ctx.thresholds.X1_max_exceptions ?? 2);
    const failures: Failure[] = [];
    const formulaMismatch = verifyAgainstModule(bounds);
    if (formulaMismatch > 1e-9) failures.push({ key: "formula", detail: `contribution differs from the module's biological age by ${formulaMismatch} years` });
    const scan = scanAll(rows, bounds, { points, tolerance: tol });
    for (const m of scan.missing) failures.push({ key: `missing|${m}`, detail: "no row or no plausibility bounds to scan" });
    const violations = scan.segments.filter((s) => s.kind !== "flat");
    const exFile = path.join(ctx.workDir, "v3", "consistency-exceptions.json");
    const exDoc = ctx.load<{ exceptions?: ExceptionEntry[] } | ExceptionEntry[]>(exFile);
    const exceptions = exDoc == null ? [] : Array.isArray(exDoc) ? exDoc : exDoc.exceptions ?? [];
    const accepted = exceptions.filter((e) => e.accepted_by_judge === true);
    if (accepted.length > cap) failures.push({ key: "exceptions|cap", detail: `${accepted.length} accepted exceptions, at most ${cap}` });
    let excepted = 0;
    for (const s of violations) {
      if (accepted.some((e) => covers(e, s))) {
        excepted++;
        continue;
      }
      failures.push({ key: segKey(s), detail: `${s.marker} ${s.from} to ${s.to} (${s.side === "low" ? "below" : "above"} the optimal band of ${s.row}): biological age up to ${s.worst_years} years ${s.kind === "reversal" ? "lower than further in, reversing toward the band" : "lower than at the nearest optimal bound"}` });
    }
    const metrics: Metrics = { scans: scan.scans, violation_segments: violations.length, excepted, exceptions_listed: exceptions.length, exceptions_accepted: accepted.length, formula_max_mismatch_years: formulaMismatch, flat_segments: scan.segments.length - violations.length };
    return {
      id: "X1",
      status: failures.length ? "fail" : "pass",
      summary: `${violations.length - excepted} violation segments outside accepted exceptions (${excepted} excepted of ${accepted.length} accepted, cap ${cap}) over ${scan.scans} scans`,
      failures: sortFailures(failures),
      metrics,
    } satisfies CheckResult;
  },
};

const NAMES: Record<string, string[]> = {
  albumin: ["albumin", "albúmina", "albumina"],
  alp: ["alp", "alkaline phosphatase", "fosfatasa alcalina"],
  ggt: ["ggt", "gamma-gt", "gamma-glutamil"],
  creatinine: ["creatinine", "creatinina"],
  bun: ["bun", "urea"],
  hs_crp: ["hs-crp", "crp", "pcr"],
  hba1c: ["hba1c"],
};

const X2: Check = {
  id: "X2",
  group: "consistency",
  title: "Flat segments documented",
  how: "script",
  run(ctx) {
    const rows = seedReviewedRows(ctx);
    const bounds = plausibilityBounds(ctx.root);
    if (!rows || !bounds) return { id: "X2", status: "blocked", summary: "blocked: seed or plausibility bounds missing", failures: [], blocked_on: "seed files or plausibility_bounds.json" };
    const scan = scanAll(rows, bounds, { points: Number(ctx.thresholds.X1_points_per_marker ?? 400), tolerance: Number(ctx.thresholds.X1_tolerance_years ?? 0.05) });
    // One entry per marker and side (tier and sex merged): what the copy must name.
    const flat = new Map<string, { marker: string; side: string; from: number; to: number }>();
    for (const s of scan.segments.filter((x) => x.kind === "flat")) {
      const k = `${s.marker}|${s.side}`;
      const e = flat.get(k);
      if (e) {
        e.from = Math.min(e.from, s.from);
        e.to = Math.max(e.to, s.to);
      } else flat.set(k, { marker: s.marker, side: s.side, from: s.from, to: s.to });
    }
    const list = [...flat.entries()].sort(([a], [b]) => a.localeCompare(b));
    const metrics: Metrics = { flat_segments: list.length, segments: list.map(([k, v]) => `${k}:${v.from}-${v.to}`).join("; ") };
    const file = path.join(ctx.workDir, "v3", "display-copy.json");
    const doc = ctx.load<{ flat_segments?: { marker: string; side: string }[]; en?: unknown; es?: unknown }>(file);
    if (!doc) return { id: "X2", status: "blocked", summary: `blocked: ${rel(ctx, file)} is missing (${list.length} flat segments to document)`, failures: [], blocked_on: rel(ctx, file), metrics };
    const text = (v: unknown): string => (typeof v === "string" ? v : Array.isArray(v) ? v.map(text).join(" ") : v && typeof v === "object" ? Object.values(v).map(text).join(" ") : "");
    const en = text(doc.en).toLowerCase();
    const es = text(doc.es).toLowerCase();
    const failures: Failure[] = [];
    for (const [k, v] of list) {
      const listed = (doc.flat_segments ?? []).some((f) => f.marker === v.marker && f.side === v.side);
      const named = (NAMES[v.marker] ?? [v.marker]).some((n) => en.includes(n)) && (NAMES[v.marker] ?? [v.marker]).some((n) => es.includes(n));
      if (!listed && !named) failures.push({ key: k, detail: `flat segment ${v.marker} ${v.from} to ${v.to} (${v.side}) not documented in the client copy` });
    }
    return { id: "X2", status: failures.length ? "fail" : "pass", summary: `${list.length - failures.length} of ${list.length} flat segments documented`, failures: sortFailures(failures), metrics };
  },
};

export const checks: Check[] = [X1, X2];
