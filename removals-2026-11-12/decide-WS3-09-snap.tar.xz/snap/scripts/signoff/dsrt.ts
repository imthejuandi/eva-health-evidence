/**
 * DSRT runner CLI. `npm run dsrt -- --round 0` writes docs/signoff/work/checks/round-0.json.
 *
 * Flags: --round N (default 0), --seed-dir <dir> (default supabase/seed-data), --work-dir <dir>
 * (default docs/signoff/work), --only D1,D2, --families f01_albumin_proteins,f03_kidney (restricts
 * row-level checks to those families' keys), --out <file>.
 * Output is deterministic: no timestamps; sorted keys; failures sorted by key. Exit code is always 0.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { stableStringify } from "./lib/hash";
import { runDsrt } from "./lib/runner";

function parseArgs(argv: string[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) continue;
    const eq = a.indexOf("=");
    if (eq > 0) out[a.slice(2, eq)] = a.slice(eq + 1);
    else if (i + 1 < argv.length && !argv[i + 1].startsWith("--")) out[a.slice(2)] = argv[++i];
    else out[a.slice(2)] = "true";
  }
  return out;
}

export async function main(argv = process.argv.slice(2)): Promise<void> {
  const args = parseArgs(argv);
  const root = path.resolve(fileURLToPath(import.meta.url), "../../..");
  const round = Number(args.round ?? 0) || 0;
  const list = (s?: string) => (s ? s.split(",").map((x) => x.trim()).filter(Boolean) : []);
  const output = await runDsrt({
    root,
    seedDir: args["seed-dir"],
    workDir: args["work-dir"],
    round,
    only: list(args.only),
    families: list(args.families),
  });
  const outFile = path.resolve(root, args.out ?? path.join(args["work-dir"] ?? "docs/signoff/work", "checks", `round-${round}.json`));
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, stableStringify(output) + "\n");
  for (const r of output.results) {
    const extra = r.status === "blocked" ? (r.blocked_on && !r.summary.includes(r.blocked_on) ? ` (blocked on: ${r.blocked_on})` : "") : r.failures.length ? ` (${r.failures.length} failures)` : "";
    console.log(`${r.id.padEnd(3)} ${r.status.padEnd(7)} ${r.summary}${extra}`);
  }
  console.log(`round ${output.round}: pass ${output.counts.pass}, fail ${output.counts.fail}, blocked ${output.counts.blocked} -> ${path.relative(root, outFile)}`);
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  main().catch((err) => {
    console.error(err);
    process.exitCode = 0;
  });
}
