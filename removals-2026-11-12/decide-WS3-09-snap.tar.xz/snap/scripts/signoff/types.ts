/**
 * Check module contract for the Doctor Sign-off Readiness Test (DSRT).
 * Every module under scripts/signoff/checks/<module>.ts exports `checks: Check[]`.
 * See docs/signoff/ACCEPTANCE-TEST.md for the check ids and pass rules.
 */
export type Status = "pass" | "fail" | "blocked";
export interface Failure {
  key: string;
  detail: string;
}
export interface CheckResult {
  id: string;
  status: Status;
  summary: string;
  failures: Failure[];
  metrics?: Record<string, number | string | boolean>;
  blocked_on?: string;
}
export interface Ctx {
  root: string;
  seedDir: string;
  workDir: string;
  round: number;
  thresholds: Record<string, unknown>;
  load<T = unknown>(relPath: string): T | null;
}
export interface Check {
  id: string;
  group: string;
  title: string;
  how: "script" | "judge" | "audit" | "script+judge";
  run(ctx: Ctx): Promise<CheckResult> | CheckResult;
}
