/**
 * The seed rows as the DSRT reads them: the English and Spanish files paired by index, exactly as
 * src/lib/biomarkers/seed-references.ts builds them, but without the duplicate removal, so the checks
 * see every row the files hold. Extra per-row fields the sign-off compile may add (reference_basis,
 * source, critical limits, explanatory numbers, marker class) are read when present.
 */
import fs from "node:fs";
import path from "node:path";
import type { Ctx } from "../types";

export type Zone = "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high";
export const ZONES: Zone[] = ["critical_low", "below_optimal", "optimal", "above_optimal", "critical_high"];

export interface Row {
  index: number;
  biomarker_key: string;
  name_en: string;
  name_es: string;
  category_en: string;
  unit_en: string;
  unit_es: string;
  sex: string; // male | female | both
  sex_raw_en: string;
  sex_raw_es: string;
  age_group_en: string;
  age_group_es: string;
  normal_low: number | null;
  normal_high: number | null;
  optimal_low: number | null;
  optimal_high: number | null;
  critical_low: number | null;
  critical_high: number | null;
  reference_basis: string | null;
  source: string | null;
  marker_class: string | null;
  explanatory_numbers: number[];
  clinical_notes_en: string | null;
  clinical_notes_es: string | null;
  msg: Record<Zone, { en: string | null; es: string | null }>;
  es_normal_low: number | null;
  es_normal_high: number | null;
  es_optimal_low: number | null;
  es_optimal_high: number | null;
  es_critical_low: number | null;
  es_critical_high: number | null;
  es_present: boolean;
}

export type RawEn = Record<string, unknown>;
export type RawEs = Record<string, unknown>;

export function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

export function normalizeSex(sex: string | null | undefined): string {
  const map: Record<string, string> = { both: "both", ambos: "both", male: "male", masculino: "male", female: "female", femenino: "female" };
  const s = String(sex ?? "").toLowerCase();
  return map[s] ?? s;
}

export function rowKey(r: Pick<Row, "biomarker_key" | "sex" | "age_group_en">): string {
  return `${r.biomarker_key}|${r.sex}|${r.age_group_en}`;
}

const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
const str = (v: unknown): string | null => (typeof v === "string" && v.length ? v : null);

export function buildRows(en: RawEn[], es: RawEs[]): Row[] {
  const rows: Row[] = [];
  for (let i = 0; i < en.length; i++) {
    const e = en[i];
    const s = es[i] ?? {};
    const explanatory = Array.isArray(e.Explanatory_Numbers) ? (e.Explanatory_Numbers as unknown[]).map(num).filter((x): x is number => x != null) : [];
    rows.push({
      index: i,
      biomarker_key: slugify(String(e.Biomarker ?? "")),
      name_en: String(e.Biomarker ?? ""),
      name_es: String(s.Biomarcador ?? ""),
      category_en: String(e.Category ?? ""),
      unit_en: String(e.Unit ?? ""),
      unit_es: String(s.Unidad ?? ""),
      sex: normalizeSex(String(e.Sex ?? "")),
      sex_raw_en: String(e.Sex ?? ""),
      sex_raw_es: String(s.Sexo ?? ""),
      age_group_en: String(e.Age_Group ?? ""),
      age_group_es: String(s.Grupo_Edad ?? ""),
      normal_low: num(e.Normal_Low),
      normal_high: num(e.Normal_High),
      optimal_low: num(e.Optimal_Low),
      optimal_high: num(e.Optimal_High),
      critical_low: num(e.Critical_Low),
      critical_high: num(e.Critical_High),
      reference_basis: str(e.Reference_Basis) ?? str(e.reference_basis),
      // The compile writes the row's reference_source as Reference_Source (docs/signoff/tools/lib/compile-rows.js EXT).
      source: str(e.Reference_Source) ?? str(e.Source) ?? str(e.source),
      marker_class: str(e.Marker_Class) ?? str(e.marker_class),
      explanatory_numbers: explanatory,
      clinical_notes_en: str(e.Clinical_Notes),
      clinical_notes_es: str(s.Notas_Clínicas),
      msg: {
        critical_low: { en: str(e.Msg_Critical_Low), es: str(s.Msg_Crítico_Bajo) },
        below_optimal: { en: str(e.Msg_Below_Optimal), es: str(s.Msg_Debajo_Óptimo) },
        optimal: { en: str(e.Msg_Optimal), es: str(s.Msg_Óptimo) },
        above_optimal: { en: str(e.Msg_Above_Optimal), es: str(s.Msg_Encima_Óptimo) },
        critical_high: { en: str(e.Msg_Critical_High), es: str(s.Msg_Crítico_Alto) },
      },
      es_normal_low: num(s.Normal_Bajo),
      es_normal_high: num(s.Normal_Alto),
      es_optimal_low: num(s["Óptimo_Bajo"]),
      es_optimal_high: num(s["Óptimo_Alto"]),
      es_critical_low: num(s["Crítico_Bajo"]),
      es_critical_high: num(s["Crítico_Alto"]),
      es_present: i < es.length,
    });
  }
  return rows;
}

export interface Seed {
  rows: Row[];
  en: RawEn[];
  es: RawEs[];
  enCount: number;
  esCount: number;
}

export function loadSeed(seedDir: string): Seed | null {
  const enFile = path.join(seedDir, "biomarker-ranges-en.json");
  const esFile = path.join(seedDir, "rangos-biomarcadores-es.json");
  if (!fs.existsSync(enFile) || !fs.existsSync(esFile)) return null;
  const enDoc = JSON.parse(fs.readFileSync(enFile, "utf8")) as { biomarker_ranges: RawEn[] };
  const esDoc = JSON.parse(fs.readFileSync(esFile, "utf8")) as { rangos_biomarcadores: RawEs[] };
  const en = enDoc.biomarker_ranges ?? [];
  const es = esDoc.rangos_biomarcadores ?? [];
  return { rows: buildRows(en, es), en, es, enCount: en.length, esCount: es.length };
}

/** The seed rows a check should look at: all of them, or only the keys of the families named with --families. */
export function rowsFor(ctx: Ctx): { rows: Row[]; seed: Seed } | null {
  const seed = loadSeed(ctx.seedDir);
  if (!seed) return null;
  const restrict = ctx.thresholds.restrict_keys;
  if (Array.isArray(restrict) && restrict.length) {
    const set = new Set(restrict.map(String));
    return { rows: seed.rows.filter((r) => set.has(r.biomarker_key)), seed };
  }
  return { rows: seed.rows, seed };
}

export function byKey(rows: Row[]): Map<string, Row[]> {
  const m = new Map<string, Row[]>();
  for (const r of rows) {
    const list = m.get(r.biomarker_key);
    if (list) list.push(r);
    else m.set(r.biomarker_key, [r]);
  }
  return m;
}

export function sortFailures<T extends { key: string }>(f: T[]): T[] {
  return [...f].sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
}
