/** Number formats per language, and the numbers a client message quotes. */

export type Lang = "en" | "es";

export function formatNumber(n: number, lang: Lang): string {
  const s = String(n);
  return lang === "es" ? s.replace(".", ",") : s;
}

/**
 * Numbers written in a message, read in the language's decimal format. Numbers glued to letters
 * ("B12", "T4", "omega-3", "CKD-EPI 2021") and four-digit years are not quoted bounds and are skipped.
 */
export function extractNumbers(text: string, lang: Lang): number[] {
  const out: number[] = [];
  const re = lang === "es" ? /(?<![\p{L}\d,.-])(\d+(?:\.\d{3})*(?:,\d+)?)(?![\p{L}\d])/gu : /(?<![\p{L}\d,.-])(\d+(?:,\d{3})*(?:\.\d+)?)(?![\p{L}\d])/gu;
  for (const m of text.matchAll(re)) {
    const raw = m[1];
    if (/^(19|20)\d\d$/.test(raw)) continue;
    const norm = lang === "es" ? raw.replace(/\./g, "").replace(",", ".") : raw.replace(/,/g, "");
    const n = Number(norm);
    if (Number.isFinite(n)) out.push(n);
  }
  return out;
}
