import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export function sha256String(s: string): string {
  return createHash("sha256").update(s).digest("hex");
}

export function sha256File(file: string): string {
  return createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

/** JSON with object keys sorted at every level, so the same data always gives the same bytes. */
export function stableStringify(value: unknown, indent = 1): string {
  return JSON.stringify(sortKeys(value), null, indent);
}

export function sortKeys<T>(value: T): T {
  if (Array.isArray(value)) return value.map((v) => sortKeys(v)) as unknown as T;
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const k of Object.keys(value as Record<string, unknown>).sort()) {
      out[k] = sortKeys((value as Record<string, unknown>)[k]);
    }
    return out as T;
  }
  return value;
}

/** Every file under `dir`, recursively, as paths relative to `root`, sorted. */
export function listFiles(root: string, dir: string): string[] {
  const abs = path.resolve(root, dir);
  if (!fs.existsSync(abs)) return [];
  const out: string[] = [];
  const walk = (d: string) => {
    for (const entry of fs.readdirSync(d, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const p = path.join(d, entry.name);
      if (entry.isDirectory()) walk(p);
      else if (entry.isFile()) out.push(path.relative(root, p).split(path.sep).join("/"));
    }
  };
  walk(abs);
  return out.sort();
}

/**
 * The judge prompts G1 holds to round 0 ("judge prompts", ACCEPTANCE-TEST.md line 122): the lens role texts that
 * docs/signoff/LOOP-PROMPT.md section 2.3 freezes ("The lenses, each with a frozen role text in
 * `docs/signoff/work/judges/lenses.json`"); the judge prompt of section 2.3 itself is in LOOP-PROMPT.md, hashed with
 * the test documents, and its {lens_role} is each lens's role_text here. The file was not hashed at round 0, so G1
 * lists it as added until the CEO approves it. It is read at this path under the root, as the other frozen files are
 * and as the loop's judges read it (docs/signoff/workflows/ws1-batch.js), whatever work dir a run is given. A
 * missing file stays in the list with the value "missing", which no approval of a real sha256 matches, so G1 fails on
 * it until the file is restored: a deleted, renamed or moved lens file cannot leave the judge prompts unchecked.
 */
export const JUDGE_PROMPTS_FILE = "docs/signoff/work/judges/lenses.json";

/** The frozen inputs of a DSRT run: seed files, the test documents, thresholds, judge prompts, runner and tools. */
export function inputFiles(root: string, seedDir: string): string[] {
  const rel = (p: string) => path.relative(root, path.resolve(root, p)).split(path.sep).join("/");
  const files = new Set<string>([
    rel(path.join(seedDir, "biomarker-ranges-en.json")),
    rel(path.join(seedDir, "rangos-biomarcadores-es.json")),
    rel(path.join(seedDir, "biomarker-sources.json")),
    "docs/signoff/ACCEPTANCE-TEST.md",
    "docs/signoff/LOOP-PROMPT.md",
    "docs/signoff/thresholds.json",
    "docs/signoff/PLAN.md",
    JUDGE_PROMPTS_FILE,
    ...listFiles(root, "scripts/signoff"),
    ...listFiles(root, "docs/signoff/tools"),
  ]);
  return [...files].filter((f) => f === JUDGE_PROMPTS_FILE || fs.existsSync(path.resolve(root, f))).sort();
}

export function hashInputs(root: string, seedDir: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const f of inputFiles(root, seedDir)) out[f] = fs.existsSync(path.resolve(root, f)) ? sha256File(path.resolve(root, f)) : "missing";
  return out;
}
