/**
 * Ownership helper: which of the files an agent wrote fall outside the paths it owns.
 * Globs: `*` matches within one path segment, `**` matches across segments.
 */
export function globToRegExp(glob: string): RegExp {
  const esc = glob
    .replace(/[.+^${}()|[\]\\]/g, "\\$&")
    .replace(/\*\*/g, "\u0000")
    .replace(/\*/g, "[^/]*")
    .replace(/\u0000/g, ".*");
  return new RegExp(`^${esc}$`);
}

export function outsideOwnership(filesWritten: string[], ownedPaths: string[]): string[] {
  const patterns = ownedPaths.map(globToRegExp);
  return filesWritten.filter((f) => !patterns.some((p) => p.test(f))).sort();
}
