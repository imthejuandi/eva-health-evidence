/**
 * Echevarne's catalogue (docs/vendor/echevarne/catalogo-2026-08-25.tsv) and the code map in
 * src/lib/lab-provider/echevarne.ts, read from the source text because the map is not exported.
 */
import fs from "node:fs";
import path from "node:path";

export interface CatalogueRow {
  code: string;
  description: string;
  unit: string;
  sex: "male" | "female" | "both";
  sex_raw: string;
  condition: string;
  age_low: number | null;
  age_high: number | null;
  age_raw: string;
  low: number | null;
  high: number | null;
  low_raw: string;
  high_raw: string;
  line: number;
}

export const CATALOGUE_PATH = "docs/vendor/echevarne/catalogo-2026-08-25.tsv";
export const CODE_MAP_PATH = "src/lib/lab-provider/echevarne.ts";

/** A catalogue bound: ".55", "<3.01", ">8", "" → number and whether it was written as a one-sided limit. */
export function parseBound(raw: string): { value: number | null; comparator: "<" | ">" | null } {
  const s = (raw ?? "").trim().replace(/,/g, ".");
  if (!s) return { value: null, comparator: null };
  const m = s.match(/^([<>])?\s*(-?\d*\.?\d+)$/);
  if (!m) return { value: null, comparator: null };
  return { value: Number(m[2]), comparator: (m[1] as "<" | ">" | undefined) ?? null };
}

export function parseCatalogue(root: string): CatalogueRow[] | null {
  const file = path.resolve(root, CATALOGUE_PATH);
  if (!fs.existsSync(file)) return null;
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  const out: CatalogueRow[] = [];
  for (let i = 0; i < lines.length; i++) {
    const cols = lines[i].split("\t");
    if (cols.length < 13) continue;
    const code = cols[3].trim();
    if (!/^[A-Z]\d{4}$/.test(code)) continue;
    const sexRaw = cols[8].trim();
    const sex = /^hombre/i.test(sexRaw) ? "male" : /^mujer/i.test(sexRaw) ? "female" : "both";
    const ageRaw = cols[10].trim().replace(/^'|'$/g, "");
    const am = ageRaw.match(/^(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)$/);
    const lo = parseBound(cols[11]);
    const hi = parseBound(cols[12]);
    // "<3.01" in the low column is an upper limit with no floor; ">8" in the low column is a floor.
    let low: number | null = lo.value;
    let high: number | null = hi.value;
    if (lo.comparator === "<") {
      high = lo.value;
      low = null;
    }
    if (hi.comparator === ">") {
      low = hi.value;
      high = null;
    }
    out.push({
      code,
      description: cols[4].trim(),
      unit: cols[7].trim(),
      sex,
      sex_raw: sexRaw,
      condition: cols[9].trim(),
      age_low: am ? Number(am[1]) : null,
      age_high: am ? Number(am[2]) : null,
      age_raw: ageRaw,
      low,
      high,
      low_raw: cols[11].trim(),
      high_raw: cols[12].trim(),
      line: i + 1,
    });
  }
  return out;
}

/** ECH result code → eva biomarker_key, from ECH_CODE_TO_BIOMARKER in the provider source. */
export function loadCodeMap(root: string): Record<string, string> | null {
  const file = path.resolve(root, "src/lib/lab-provider/echevarne.ts");
  if (!fs.existsSync(file)) return null;
  const src = fs.readFileSync(file, "utf8");
  const start = src.indexOf("const ECH_CODE_TO_BIOMARKER");
  if (start < 0) return null;
  const end = src.indexOf("};", start);
  const body = src.slice(start, end);
  const map: Record<string, string> = {};
  for (const m of body.matchAll(/^\s*([A-Z]\d{4}):\s*"([a-z0-9_]+)"/gm)) map[m[1]] = m[2];
  return map;
}

/** Catalogue conditions that name a physiological window → EVA's labelled age groups. */
export const CONDITION_TO_AGE_GROUP: Record<string, string> = {
  "Post-menopausia": "Postmenopausal",
  PicoOvulatorio: "Ovulatory peak",
  FaseLuteínica: "Premenopausal (luteal)",
  FaseFolicular: "Premenopausal (follicular)",
};
