/**
 * The DSRT runner core: loads the check modules that exist, runs the checks in the order of
 * docs/signoff/ACCEPTANCE-TEST.md and builds the deterministic result document. The CLI in
 * scripts/signoff/dsrt.ts wraps it; check G3 calls it twice in-process.
 */
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import type { Check, CheckResult, Ctx } from "../types";
import { hashInputs, sortKeys } from "./hash";

export const MODULES = [
  "data",
  "coverage",
  "messages",
  "coherence",
  "governance",
  "evidence",
  "limits",
  "preanalytical",
  "score",
  "bioage",
  "consistency",
  "population",
  "personas",
  "prereview",
] as const;
export type ModuleName = (typeof MODULES)[number];

const PREFIX_TO_MODULE: Record<string, ModuleName> = {
  D: "data",
  C: "coverage",
  M: "messages",
  K: "coherence",
  G: "governance",
  E: "evidence",
  L: "limits",
  P: "preanalytical",
  S: "score",
  B: "bioage",
  X: "consistency",
  N: "population",
  Q: "personas",
};

export function moduleForId(id: string): ModuleName {
  if (id === "G8") return "prereview";
  return PREFIX_TO_MODULE[id[0]] ?? "data";
}

export interface AcceptanceCheck {
  id: string;
  group: string;
  title: string;
  how: string;
  pass: string;
}

/** The check ids, in document order, parsed from the tables of ACCEPTANCE-TEST.md. */
export function parseAcceptanceTest(markdown: string): AcceptanceCheck[] {
  const out: AcceptanceCheck[] = [];
  let group = "";
  for (const line of markdown.split(/\r?\n/)) {
    const h = line.match(/^## ([A-Z])\. (.+)$/);
    if (h) group = h[2].trim();
    const m = line.match(/^\| ([A-Z]\d+) \| (.+?) \| (.+?) \| (.+?) \|$/);
    if (m) out.push({ id: m[1], group, title: m[2].trim(), how: m[3].trim(), pass: m[4].trim() });
  }
  return out;
}

export interface RunOptions {
  root: string;
  seedDir?: string;
  workDir?: string;
  round?: number;
  only?: string[];
  families?: string[];
  skipIds?: string[];
  thresholds?: Record<string, unknown>;
  gitCommit?: string;
}

export interface RunOutput {
  round: number;
  git_commit: string;
  inputs: Record<string, string>;
  results: CheckResult[];
  counts: { pass: number; fail: number; blocked: number };
}

export function gitCommit(root: string): string {
  try {
    return execFileSync("git", ["rev-parse", "HEAD"], { cwd: root, encoding: "utf8" }).trim();
  } catch {
    return "unknown";
  }
}

export function loadThresholds(root: string): Record<string, unknown> {
  const file = path.resolve(root, "docs/signoff/thresholds.json");
  if (!fs.existsSync(file)) return {};
  return JSON.parse(fs.readFileSync(file, "utf8")) as Record<string, unknown>;
}

export function familyKeys(root: string, workDir: string, families: string[]): string[] {
  const file = path.resolve(workDir, "families.json");
  if (!fs.existsSync(file)) return [];
  const doc = JSON.parse(fs.readFileSync(file, "utf8")) as { families: Record<string, { keys: string[] }> };
  const keys = new Set<string>();
  for (const f of families) for (const k of doc.families?.[f]?.keys ?? []) keys.add(k);
  return [...keys].sort();
}

export function makeCtx(opts: RunOptions): Ctx {
  const root = path.resolve(opts.root);
  const seedDir = path.resolve(root, opts.seedDir ?? "supabase/seed-data");
  const workDir = path.resolve(root, opts.workDir ?? "docs/signoff/work");
  const thresholds: Record<string, unknown> = { ...(opts.thresholds ?? loadThresholds(root)) };
  if (opts.families?.length) thresholds.restrict_keys = familyKeys(root, workDir, opts.families);
  return {
    root,
    seedDir,
    workDir,
    round: opts.round ?? 0,
    thresholds,
    load<T = unknown>(relPath: string): T | null {
      const file = path.isAbsolute(relPath) ? relPath : path.resolve(root, relPath);
      if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return null;
      const text = fs.readFileSync(file, "utf8");
      if (/\.json$/i.test(file)) {
        try {
          return JSON.parse(text) as T;
        } catch {
          return null;
        }
      }
      return text as unknown as T;
    },
  };
}

export async function loadModules(root: string): Promise<Map<ModuleName, Check[]>> {
  const out = new Map<ModuleName, Check[]>();
  for (const name of MODULES) {
    const file = path.resolve(root, `scripts/signoff/checks/${name}.ts`);
    if (!fs.existsSync(file)) continue;
    const mod = (await import(pathToFileURL(file).href)) as { checks?: Check[] };
    if (Array.isArray(mod.checks)) out.set(name, mod.checks);
  }
  return out;
}

function normalizeResult(r: CheckResult): CheckResult {
  const failures = [...r.failures].sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  const out: CheckResult = { id: r.id, status: r.status, summary: r.summary, failures };
  if (r.metrics) out.metrics = sortKeys(r.metrics);
  if (r.blocked_on) out.blocked_on = r.blocked_on;
  if (out.status === "fail" && out.failures.length === 0) out.failures = [{ key: r.id, detail: r.summary }];
  if (out.status === "blocked" && !out.blocked_on) out.blocked_on = r.summary;
  return out;
}

export async function runDsrt(opts: RunOptions): Promise<RunOutput> {
  const ctx = makeCtx(opts);
  const acceptance = parseAcceptanceTest(ctx.load<string>("docs/signoff/ACCEPTANCE-TEST.md") ?? "");
  const modules = await loadModules(ctx.root);
  const byId = new Map<string, Check>();
  for (const checks of modules.values()) for (const c of checks) byId.set(c.id, c);
  const only = opts.only?.length ? new Set(opts.only) : null;
  const skip = new Set(opts.skipIds ?? []);
  const results: CheckResult[] = [];
  const ids = acceptance.length ? acceptance.map((a) => a.id) : [...byId.keys()].sort();
  for (const id of ids) {
    if (only && !only.has(id)) continue;
    if (skip.has(id)) continue;
    const check = byId.get(id);
    if (!check) {
      results.push({ id, status: "blocked", summary: "module not implemented", failures: [], blocked_on: `scripts/signoff/checks/${moduleForId(id)}.ts` });
      continue;
    }
    try {
      results.push(normalizeResult(await check.run(ctx)));
    } catch (err) {
      results.push({ id, status: "fail", summary: `check threw: ${(err as Error).message}`, failures: [{ key: id, detail: String((err as Error).stack ?? err).split("\n").slice(0, 3).join(" | ") }] });
    }
  }
  const counts = { pass: 0, fail: 0, blocked: 0 };
  for (const r of results) counts[r.status]++;
  return {
    round: ctx.round,
    git_commit: opts.gitCommit ?? gitCommit(ctx.root),
    inputs: hashInputs(ctx.root, ctx.seedDir),
    results,
    counts,
  };
}
