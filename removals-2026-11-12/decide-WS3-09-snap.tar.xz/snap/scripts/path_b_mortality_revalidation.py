#!/usr/bin/env python3
"""
Path B mortality re-validation.

Recompute KDM Reference BA for every NHANES subject using Path B parameters
(unwinsorized BUN + Fructosamine), then re-run the Cox PH regression that
gave HR/SD = 1.37 in original training. Confirm new HR/SD, C-stat,
calibration slope before approving the parameter override.

Acceptance criteria (from training spec):
  - HR per SD ≥ 1.02
  - C-statistic ≥ 0.75
  - Calibration slope ∈ [0.9, 1.1]

If Path B values pass, we deploy. If they don't, we abandon Path B and fall
back to either Path A (drop BUN/Fructosamine) or keep Path 0 (current).
"""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter
from lifelines.utils import concordance_index

ROOT = Path("/Users/jdl/Projects/KDM Final Training/training_package_v2_2")
LIBRARY_PATH = ROOT / "output" / "marker_library_v2_2.json"
CLEANED_PATH = ROOT / "output" / "nhanes_continuous_cleaned.parquet"

# Path B overrides (from raw NHANES re-fit without winsorization)
PATH_B_OVERRIDES = {
    "BUN (Nitrógeno Ureico en Sangre)": {
        "k": 0.1344, "q": 7.1314, "s": 5.4758, "r2": 0.1822
    },
    "Fructosamina": {  # log-scale fit (matches library convention)
        "k": 0.0044, "q": 4.0785, "s": 0.2052, "r2": 0.1395
    },
}

BASE_PANEL = [
    "Albúmina", "Creatinina", "BUN (Nitrógeno Ureico en Sangre)", "Ácido Úrico",
    "ALP (Fosfatasa Alcalina)", "GGT (Gamma-glutamil Transferasa)",
    "Colesterol Total", "Colesterol HDL", "Triglicéridos",
    "PCR de Alta Sensibilidad (hs-PCR)", "Ferritina", "Vitamina D (25-OH)",
    "TSH", "Fructosamina",
]
MANDATORY = ["Albúmina", "Creatinina"]
MIN_BASE = 8


def klemera_doubal_ba(values, params, ca, s_ca, use_anchor=True):
    num, denom = 0.0, 0.0
    used = []
    for marker, value in values.items():
        if value is None or not math.isfinite(value):
            continue
        p = params.get(marker)
        if p is None:
            continue
        k, q, s = p["k"], p["q"], p["s"]
        log = p.get("log_transformed", False)
        if s is None or s <= 0:
            continue
        v = math.log(value) if log and value > 0 else value
        if not math.isfinite(v):
            continue
        num += (v - q) * (k / (s ** 2))
        denom += (k / s) ** 2
        used.append(marker)
    if denom == 0 or not used:
        return None
    ba_e = num / denom
    s_ba2 = 1.0 / denom
    if use_anchor:
        s_ca2 = s_ca ** 2
        ba = (ba_e / s_ba2 + ca / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)
    else:
        ba = ba_e
    return {"BA": ba, "BA_E": ba_e, "s_BA": math.sqrt(s_ba2), "n_used": len(used)}


def resolve_params(entry, sex, override=None):
    """Resolve (k, q, s) for one marker. Override applies (k, q, s) from
    PATH_B_OVERRIDES when present; otherwise use library values with
    sex stratification + Spanish recalibration."""
    if override is not None:
        return {"k": override["k"], "q": override["q"], "s": override["s"],
                "log_transformed": entry.get("log_transformed", False)}
    if entry.get("sex_stratified"):
        block = entry.get("kqs_M") if sex == "M" else entry.get("kqs_F")
    else:
        block = entry.get("kqs")
    if not block or block.get("k") is None:
        return None
    k, q, s = block["k"], block["q"], block["s"]
    # Spanish recalibration q swap
    sr = entry.get("spanish_recalibration", {})
    if sr.get("calibration_status", "").startswith("recalibrated"):
        if entry.get("sex_stratified"):
            per_sex = (sr.get("per_sex") or {}).get(sex, {}) or {}
            qs = per_sex.get("q_spain")
            if qs is not None:
                q = qs
        else:
            qs = sr.get("q_spain")
            if qs is not None:
                q = qs
    return {"k": k, "q": q, "s": s,
            "log_transformed": entry.get("log_transformed", False)}


def compute_subject_ba(values, library_markers, sex, ca, s_ca, use_path_b=False):
    """Compute Reference BA for one subject. If use_path_b=True, apply
    Path B overrides for BUN and Fructosamine."""
    # Gate
    base_present = [m for m in BASE_PANEL if m in values and pd.notna(values[m])]
    if len(base_present) < MIN_BASE:
        return None
    for m in MANDATORY:
        if m not in values or pd.isna(values[m]):
            return None

    # Build params for base panel only (Reference BA)
    params = {}
    for marker in base_present:
        entry = library_markers.get(marker)
        if not entry:
            continue
        override = PATH_B_OVERRIDES.get(marker) if use_path_b else None
        p = resolve_params(entry, sex, override=override)
        if p:
            params[marker] = p

    if not params:
        return None
    return klemera_doubal_ba({m: values[m] for m in params}, params, ca, s_ca, use_anchor=True)


def run_cox(label, ba_col, df):
    sub = df.dropna(subset=[ba_col, "age", "follow_up_years", "died"]).copy()
    if len(sub) < 100 or sub["died"].sum() < 100:
        return None
    sub["BA_z"] = (sub[ba_col] - sub[ba_col].mean()) / sub[ba_col].std()
    sub["sex_M"] = (sub["sex"] == "M").astype(int)
    sub["T"] = sub["follow_up_years"]
    sub["E"] = sub["died"].astype(int)
    cph = CoxPHFitter()
    cph.fit(sub[["BA_z", "age", "sex_M", "T", "E"]],
            duration_col="T", event_col="E", show_progress=False)
    hr = float(np.exp(cph.params_["BA_z"]))
    ci = cph.confidence_intervals_.loc["BA_z"].tolist()
    hr_lo, hr_hi = float(np.exp(ci[0])), float(np.exp(ci[1]))
    c_stat = float(concordance_index(sub["T"], -cph.predict_partial_hazard(sub), sub["E"]))

    # Calibration slope (50/50 train/test split, seed 42)
    rng = np.random.default_rng(42)
    idx = np.arange(len(sub))
    rng.shuffle(idx)
    half = len(sub) // 2
    train_idx, test_idx = idx[:half], idx[half:]
    cph_t = CoxPHFitter()
    cph_t.fit(sub.iloc[train_idx][["BA_z", "age", "sex_M", "T", "E"]],
              duration_col="T", event_col="E", show_progress=False)
    lp_test = np.log(cph_t.predict_partial_hazard(sub.iloc[test_idx]).to_numpy())
    check_df = pd.DataFrame({"lp": lp_test, "T": sub.iloc[test_idx]["T"].to_numpy(),
                             "E": sub.iloc[test_idx]["E"].to_numpy()})
    cph_c = CoxPHFitter()
    cph_c.fit(check_df, duration_col="T", event_col="E", show_progress=False)
    cal_slope = float(cph_c.params_["lp"])

    return {
        "label": label,
        "n": int(len(sub)),
        "n_events": int(sub["E"].sum()),
        "hr_per_sd": hr,
        "hr_ci_lower": hr_lo,
        "hr_ci_upper": hr_hi,
        "c_statistic": c_stat,
        "calibration_slope": cal_slope,
    }


def main():
    print("Loading library...")
    library = json.loads(LIBRARY_PATH.read_text())
    library_markers = library["markers"]

    print("Loading cleaned NHANES (long format)...")
    df_long = pd.read_parquet(CLEANED_PATH)
    print(f"  loaded {len(df_long):,} rows")

    # Pivot to wide format: one row per subject, columns per marker
    df_long_use = df_long.copy()
    # Use value_log when present (log-transformed markers), else value_winsorized
    df_long_use["v"] = np.where(df_long_use["value_log"].notna(),
                                 np.exp(df_long_use["value_log"]),  # back to raw for re-log inside KDM
                                 df_long_use["value_winsorized"])

    print("Pivoting to wide...")
    wide = df_long_use.pivot_table(
        index=["SEQN", "cycle", "age", "sex", "follow_up_years", "died"],
        columns="marker_es", values="v", aggfunc="first",
    ).reset_index()
    print(f"  wide shape: {wide.shape}")

    # s_ca per sex (Reference tier, from phase_4_log)
    S_CA_REF = {"M": 24.678, "F": 23.274}

    print("\nComputing BA for each subject — Path 0 (winsorized, current library)...")
    ba_path0 = []
    print("Computing BA for each subject — Path B (BUN+Fructosamine unwinsorized)...")
    ba_pathB = []

    for _, row in wide.iterrows():
        sex = row["sex"]
        ca = row["age"]
        if pd.isna(sex) or pd.isna(ca):
            ba_path0.append(np.nan)
            ba_pathB.append(np.nan)
            continue
        values = {m: row.get(m) for m in library_markers if m in wide.columns}
        s_ca = S_CA_REF.get(sex, 24.0)
        r0 = compute_subject_ba(values, library_markers, sex, ca, s_ca, use_path_b=False)
        rB = compute_subject_ba(values, library_markers, sex, ca, s_ca, use_path_b=True)
        ba_path0.append(r0["BA"] if r0 else np.nan)
        ba_pathB.append(rB["BA"] if rB else np.nan)

    wide["BA_path0"] = ba_path0
    wide["BA_pathB"] = ba_pathB

    n_both = wide.dropna(subset=["BA_path0", "BA_pathB"]).shape[0]
    print(f"\nSubjects with valid BA in both paths: {n_both}")

    # Compare BA distributions
    print(f"\nBA distribution:")
    print(f"  Path 0 (current):   mean={wide['BA_path0'].mean():.2f}, std={wide['BA_path0'].std():.2f}")
    print(f"  Path B:             mean={wide['BA_pathB'].mean():.2f}, std={wide['BA_pathB'].std():.2f}")
    print(f"  Δ(B - 0) per-subject mean: {(wide['BA_pathB'] - wide['BA_path0']).mean():.3f}")

    # Run Cox on each
    print("\nCox PH validation — Path 0 (current library, deployed)")
    r0 = run_cox("Path 0", "BA_path0", wide)
    if r0:
        print(f"  n={r0['n']:,}, events={r0['n_events']:,}")
        print(f"  HR/SD = {r0['hr_per_sd']:.4f} [{r0['hr_ci_lower']:.4f}, {r0['hr_ci_upper']:.4f}]")
        print(f"  C-statistic = {r0['c_statistic']:.4f}")
        print(f"  Calibration slope = {r0['calibration_slope']:.4f}")

    print("\nCox PH validation — Path B (BUN+Fructosamine unwinsorized)")
    rB = run_cox("Path B", "BA_pathB", wide)
    if rB:
        print(f"  n={rB['n']:,}, events={rB['n_events']:,}")
        print(f"  HR/SD = {rB['hr_per_sd']:.4f} [{rB['hr_ci_lower']:.4f}, {rB['hr_ci_upper']:.4f}]")
        print(f"  C-statistic = {rB['c_statistic']:.4f}")
        print(f"  Calibration slope = {rB['calibration_slope']:.4f}")

    # Acceptance verdict
    def passes(r):
        return (r["hr_per_sd"] >= 1.02
                and r["c_statistic"] >= 0.75
                and 0.9 <= r["calibration_slope"] <= 1.1)

    print("\n" + "=" * 70)
    print("VERDICT")
    print("=" * 70)
    if r0 and rB:
        print(f"\nPath 0 (current): {'✓ PASS' if passes(r0) else '✗ FAIL'} validation thresholds")
        print(f"Path B (re-fit):  {'✓ PASS' if passes(rB) else '✗ FAIL'} validation thresholds")
        print(f"\nHR/SD change: {r0['hr_per_sd']:.4f} → {rB['hr_per_sd']:.4f} "
              f"(Δ {rB['hr_per_sd'] - r0['hr_per_sd']:+.4f})")
        print(f"C-stat change: {r0['c_statistic']:.4f} → {rB['c_statistic']:.4f}")
        print(f"Cal slope change: {r0['calibration_slope']:.4f} → {rB['calibration_slope']:.4f}")
        if passes(rB):
            print("\n  → SAFE TO DEPLOY PATH B")
        else:
            print("\n  → PATH B FAILS VALIDATION — DO NOT DEPLOY")
            print("    Fall back to Path 0 (current) or Path A (drop BUN)")


if __name__ == "__main__":
    main()
