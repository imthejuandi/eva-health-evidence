/**
 * The EVA score specification, generated.
 *
 *   npx tsx scripts/score/build-score-spec.ts            writes the generated files
 *   npx tsx scripts/score/build-score-spec.ts --check    writes nothing; exits 1 when a file differs
 *
 * Reads (and nothing else):
 *   docs/signoff/work/score/spec-inputs.json     the rulings the score rests on, each with its id
 *   docs/signoff/work/decisions/<family>.json    the families' decided rows (final_rows)
 *   docs/signoff/work/verify/<family>.json       the verifier's rows: class and grade come from here
 *   docs/signoff/work/governance/marker-classes.json   the governance file whose generated fields it rewrites
 *
 * Writes:
 *   src/lib/biomarkers/data/score-spec.json      what the engine reads (longevity-score.ts)
 *   docs/signoff/work/score/weights.json         the mapping, each scoring marker's weight and grade, every row
 *   docs/signoff/work/governance/marker-classes.json   class, may_be_scored, priority_member, groups, summary
 *   docs/signoff/work/score/specification.md     only the block between the two "generated" marks
 *
 * Rules (rulings D-02, D-06, D-07, D-08 and D-30): a row scores only when the verifier's row for it is class a,
 * carries an optimal band graded A or B, and the decided row has the same class, grade and optimal bounds. A row a
 * fixer changed after the verdict waits for a fresh verdict. A marker's weight follows the worst grade among its
 * rows that score. The generator invents nothing: a class a row with a band graded A or B and no place in
 * spec-inputs.json stops it, and so does a row it would score that tells the client the marker does not count.
 *
 * Deterministic: the same inputs give the same bytes. It reads no clock and no database.
 */
import fs from "node:fs";
import path from "node:path";
import { rowEligibilityKey } from "../../src/lib/biomarkers/longevity-score";

// ─── Inputs ───

export interface FamilyRow {
  marker_key: string;
  sex: string;
  age_group: string;
  physiological_state?: string | null;
  marker_class?: string | null;
  optimal_low?: number | null;
  optimal_high?: number | null;
  grade?: string | null;
  messages?: unknown;
}

export interface FamilyFile {
  family: string;
  /** final_rows of decisions/<family>.json. */
  decided: FamilyRow[];
  /** final_rows of verify/<family>.json; null when the file does not exist. */
  verified: FamilyRow[] | null;
}

interface SpecInputMarker {
  key: string;
  name: string;
  unit: string;
  category: string;
}

interface SpecInputGroup {
  name: string;
  governance_group: string;
  decision: string;
  priority_order: string[];
  reason: string;
}

export interface SpecInputs {
  version: string;
  eligibility: {
    decision: string;
    marker_class: string;
    grades: string[];
    signed_grade_c: string[];
    changed_after_verdict: { decision: string };
    not_counted_sentence: { en: string; es: string };
  };
  mapping: { decision: string; rule: string; weights: Record<string, number>; never_scores: string[]; grade_c_condition: string };
  weight_per_marker: { decision: string; rule: string };
  bonus: { decision: string; rule: string };
  markers: Record<string, SpecInputMarker>;
  conditions: {
    decision: string;
    requires_confirmed_fasting: string[];
    passed_over_on_hba1c_exclusion: string[];
    app_computed_only: string[];
    admitted_when_rows_allow: string[];
  };
  groups: SpecInputGroup[];
  outside_groups: Record<string, { decision: string; reason: string }>;
  never_scored: Record<string, { decision: string; reason: string }>;
  coverage: {
    decision: string;
    min_markers: number;
    min_domains: number;
    domains: Record<string, { description: string; markers: string[]; min_count: number }>;
    in_no_domain: string[];
  };
  curves: { decision: string; grades: { min: number; label: string }[]; penalty_curve: Record<string, number>; score_curve: Record<string, number> };
  caps: { decision: string; out_of_range: { grade: string } };
  confidence: { decision: string; levels: { level: string; min_domains: number }[]; otherwise: string; below_coverage: string };
  population_check: { decision: string; min_age: number; max_age: number; rule: string };
  marker_classes: { version: string; rules_scoring: string };
}

type Json = Record<string, unknown>;

export interface GeneratorInputs {
  spec: SpecInputs;
  families: FamilyFile[];
  /** marker-classes.json as it stands; its generated fields are rewritten. */
  markerClasses: Json;
  /** specification.md as it stands; its generated block is rewritten. */
  specificationMd: string;
}

export const PATHS = {
  specInputs: "docs/signoff/work/score/spec-inputs.json",
  decisions: "docs/signoff/work/decisions",
  verify: "docs/signoff/work/verify",
  markerClasses: "docs/signoff/work/governance/marker-classes.json",
  specification: "docs/signoff/work/score/specification.md",
  scoreSpec: "src/lib/biomarkers/data/score-spec.json",
  weights: "docs/signoff/work/score/weights.json",
} as const;

export const GENERATED_BEGIN = "<!-- generated by scripts/score/build-score-spec.ts: begin (do not edit by hand) -->";
export const GENERATED_END = "<!-- generated by scripts/score/build-score-spec.ts: end -->";

// ─── Row status ───

export type RowStatus = "scores" | "waiting" | "not_scored";

export interface RowReport {
  row: string;
  sex: string;
  age_group: string;
  physiological_state: string;
  source: string;
  verifier_source: string | null;
  class: string | null;
  /** The verifier's grade of the band; null when the verifier has no row. */
  grade: string | null;
  decided_grade: string | null;
  optimal_low: number | null;
  optimal_high: number | null;
  status: RowStatus;
  scores: boolean;
  reason: string;
  /** How the decided row differs from the verifier's row (a change after the verdict); null when it does not. */
  changed_after_verdict: string | null;
}

const bound = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
const stateOf = (r: FamilyRow): string => r.physiological_state ?? "none";
const rowId = (r: FamilyRow): string => `${r.marker_key}|${r.sex}|${r.age_group}|${stateOf(r)}`;
const band = (lo: number | null, hi: number | null): string => `${lo ?? "none"} to ${hi ?? "none"}`;

function fail(message: string): never {
  throw new Error(`build-score-spec: ${message}`);
}

function saysNotCounted(row: FamilyRow, sentence: { en: string; es: string }): boolean {
  const text = JSON.stringify(row.messages ?? null);
  return text.includes(sentence.en) || text.includes(sentence.es);
}

/** Every decided row with its status, in family and row order. */
function reportRows(inp: GeneratorInputs): Map<string, RowReport[]> {
  const { spec } = inp;
  const codeOfKey = new Map(Object.entries(spec.markers).map(([code, m]) => [m.key, code]));
  const byMarker = new Map<string, RowReport[]>();
  const scoringGrades = new Set(spec.eligibility.grades);
  const signedC = new Set(spec.eligibility.signed_grade_c);
  const waitsOnRows = new Set(spec.conditions.admitted_when_rows_allow);

  for (const fam of [...inp.families].sort((a, b) => a.family.localeCompare(b.family))) {
    const verified = new Map<string, { row: FamilyRow; index: number }>();
    (fam.verified ?? []).forEach((row, index) => {
      if (verified.has(rowId(row))) fail(`verify/${fam.family}.json has two rows for ${rowId(row)}`);
      verified.set(rowId(row), { row, index });
    });
    const seen = new Set<string>();
    fam.decided.forEach((row, index) => {
      if (seen.has(rowId(row))) fail(`decisions/${fam.family}.json has two rows for ${rowId(row)}`);
      seen.add(rowId(row));
      const v = verified.get(rowId(row)) ?? null;
      const lo = bound(row.optimal_low);
      const hi = bound(row.optimal_high);
      const cls = v ? (v.row.marker_class ?? null) : null;
      const grade = v ? (v.row.grade ?? null) : null;
      const state = stateOf(row);
      const code = codeOfKey.get(row.marker_key);
      const never = spec.never_scored[row.marker_key];

      let status: RowStatus = "not_scored";
      let reason: string;
      const differences: string[] = [];
      if (v) {
        if ((row.marker_class ?? null) !== cls) differences.push(`class ${row.marker_class ?? "none"}, verifier ${cls ?? "none"}`);
        if ((row.grade ?? null) !== grade) differences.push(`grade ${row.grade ?? "none"}, verifier ${grade ?? "none"}`);
        const vLo = bound(v.row.optimal_low);
        const vHi = bound(v.row.optimal_high);
        if (lo !== vLo || hi !== vHi) differences.push(`optimal ${band(lo, hi)}, verifier ${band(vLo, vHi)}`);
      }

      if (!v) {
        status = "waiting";
        reason = `waiting: the verifier has no row for it (${spec.eligibility.changed_after_verdict.decision})`;
      } else if (cls !== spec.eligibility.marker_class) {
        reason = `class ${cls ?? "none"}: only class ${spec.eligibility.marker_class} scores (${spec.eligibility.decision})`;
      } else if (never) {
        reason = `${never.reason} (${never.decision})`;
      } else if (state !== "none") {
        reason = `a ${state} row: shown on its reference interval, never scored`;
      } else if (differences.length > 0) {
        status = "waiting";
        reason = `waiting for a fresh verifier verdict: changed after the verdict (${differences.join("; ")}) (${spec.eligibility.changed_after_verdict.decision})`;
      } else if (lo === null && hi === null) {
        reason = `no optimal band (${spec.eligibility.decision})`;
      } else if (!scoringGrades.has(grade ?? "") && !(grade === "C" && signedC.has(`${row.marker_key}|${row.sex}|${row.age_group}`))) {
        reason =
          grade === "C"
            ? `grade C: the band is not signed into the score (${spec.eligibility.decision})`
            : `grade ${grade ?? "none"}: does not score (${spec.eligibility.decision})`;
      } else if (!code) {
        fail(
          `${rowId(row)} (decisions/${fam.family}.json final_rows[${index}]) is class ${cls}, grade ${grade}, with an optimal band, ` +
            `and spec-inputs.json gives it neither an engine code nor a never_scored entry: it needs a decision`,
        );
      } else if (saysNotCounted(row, spec.eligibility.not_counted_sentence)) {
        if (!waitsOnRows.has(code)) {
          fail(
            `${rowId(row)} (decisions/${fam.family}.json final_rows[${index}]) would score, and its messages tell the client ` +
              `"${spec.eligibility.not_counted_sentence.en}"`,
          );
        }
        status = "waiting";
        reason = `waiting: the row's messages still say the marker does not count toward the score (${spec.conditions.decision})`;
      } else {
        status = "scores";
        reason = `class ${cls}, band graded ${grade} by the verifier`;
      }

      // State rows share sex and age group with the stateless row, and the seed labels them by state: an eligible
      // one could not be told apart by the engine's row key.
      if (status === "scores" && state !== "none") fail(`${rowId(row)}: a state row cannot score`);

      const list = byMarker.get(row.marker_key) ?? [];
      list.push({
        row: rowId(row),
        sex: row.sex,
        age_group: row.age_group,
        physiological_state: state,
        source: `decisions/${fam.family}.json final_rows[${index}]`,
        verifier_source: v ? `verify/${fam.family}.json final_rows[${v.index}]` : null,
        class: cls,
        grade,
        decided_grade: row.grade ?? null,
        optimal_low: lo,
        optimal_high: hi,
        status,
        scores: status === "scores",
        reason,
        changed_after_verdict: differences.length ? differences.join("; ") : null,
      });
      byMarker.set(row.marker_key, list);
    });
  }
  return byMarker;
}

// ─── Outputs ───

export interface GeneratorOutputs {
  scoreSpec: Json;
  weights: Json;
  markerClasses: Json;
  specificationMd: string;
}

/** A row that waits: it cannot score until a decision or a fresh verdict, or it was changed after the verdict. */
const isWaiting = (r: RowReport): boolean => r.status === "waiting" || r.changed_after_verdict !== null;
const waitingReason = (r: RowReport, spec: SpecInputs): string =>
  r.status === "waiting"
    ? r.reason
    : `changed after the verdict (${r.changed_after_verdict}): a fresh verifier verdict is due (${spec.eligibility.changed_after_verdict.decision}); it does not score in any case: ${r.reason}`;

const GRADE_ORDER = ["A", "B", "C", "D"];
const worstGrade = (grades: string[]): string => [...grades].sort((a, b) => GRADE_ORDER.indexOf(b) - GRADE_ORDER.indexOf(a))[0];

export function generate(inp: GeneratorInputs): GeneratorOutputs {
  const { spec } = inp;
  const rows = reportRows(inp);
  const codes = Object.keys(spec.markers);
  const keyOf = (code: string): string => spec.markers[code]?.key ?? fail(`spec-inputs.json names the code ${code} and does not define it`);

  // Consistency of spec-inputs.json itself.
  const grouped = new Set<string>();
  for (const g of spec.groups)
    for (const c of g.priority_order) {
      keyOf(c);
      if (grouped.has(c)) fail(`${c} is in two groups`);
      grouped.add(c);
    }
  for (const [name, d] of Object.entries(spec.coverage.domains)) for (const c of d.markers) if (!spec.markers[c]) fail(`domain ${name} names ${c}`);
  for (const c of spec.coverage.in_no_domain) {
    keyOf(c);
    if (Object.values(spec.coverage.domains).some((d) => d.markers.includes(c))) fail(`${c} is listed in no domain and in a domain`);
  }
  for (const c of codes) {
    if (spec.never_scored[keyOf(c)]) fail(`${c} has an engine code and a never_scored entry`);
    if (!rows.has(keyOf(c))) fail(`${c}: no decided row for ${keyOf(c)}`);
    if (!spec.coverage.in_no_domain.includes(c) && !Object.values(spec.coverage.domains).some((d) => d.markers.includes(c))) fail(`${c} is in no domain and not listed under in_no_domain`);
  }
  for (const g of [...spec.eligibility.grades, "C"]) if (typeof spec.mapping.weights[g] !== "number") fail(`the mapping has no weight for grade ${g}`);

  // The engine's specification.
  const specMarkers: Json = {};
  const weightsMarkers: Json = {};
  const notScored: Json = {};
  const scoringKeys = new Set<string>();
  for (const code of codes) {
    const m = spec.markers[code];
    const list = rows.get(m.key) as RowReport[];
    const scoring = list.filter((r) => r.scores);
    const grade = scoring.length ? worstGrade(scoring.map((r) => r.grade as string)) : null;
    const weight = grade ? spec.mapping.weights[grade] : null;
    const rowMap: Json = {};
    for (const r of list) {
      if (r.physiological_state !== "none") continue;
      const k = rowEligibilityKey({ sex: r.sex, age_group_en: r.age_group });
      if (k in rowMap) fail(`${m.key}: two rows share the key ${k}`);
      rowMap[k] = { grade: r.grade, eligible: r.scores, optimal_low: r.optimal_low, optimal_high: r.optimal_high, ...(r.scores ? {} : { reason: r.reason }) };
    }
    specMarkers[code] = {
      key: m.key,
      name: m.name,
      unit: m.unit,
      category: m.category,
      weight,
      grade,
      requires_confirmed_fasting: spec.conditions.requires_confirmed_fasting.includes(code),
      passed_over_on_hba1c_exclusion: spec.conditions.passed_over_on_hba1c_exclusion.includes(code),
      rows: rowMap,
    };
    if (scoring.length) scoringKeys.add(m.key);
  }

  const scoreSpec: Json = {
    _doc:
      "GENERATED by scripts/score/build-score-spec.ts from docs/signoff/work/score/spec-inputs.json, the families' decided rows and the verifier's rows. Do not edit by hand: change the inputs and run the generator (--check fails on any difference). src/lib/biomarkers/longevity-score.ts reads the score's markers, weights, row eligibility, groups, coverage, grade table, curves, cap and confidence rule from this file and from nowhere else. A marker scores only through a row listed here as eligible whose optimal bounds equal the bounds the verifier graded; weight null: no row of the marker scores today.",
    version: spec.version,
    markers: specMarkers,
    groups: spec.groups.map((g) => ({ name: g.name, priority_order: g.priority_order })),
    coverage: { domains: spec.coverage.domains, min_markers: spec.coverage.min_markers, min_domains: spec.coverage.min_domains },
    grades: spec.curves.grades,
    penalty_curve: spec.curves.penalty_curve,
    score_curve: spec.curves.score_curve,
    caps: { out_of_range: spec.caps.out_of_range },
    confidence: { levels: spec.confidence.levels, otherwise: spec.confidence.otherwise, below_coverage: spec.confidence.below_coverage },
    population_check: { min_age: spec.population_check.min_age, max_age: spec.population_check.max_age },
  };

  // weights.json: scoring markers under `markers` (weight and grade), everything else decided under `not_scored`.
  const codeOfKey = new Map(codes.map((c) => [spec.markers[c].key, c]));
  const rowOut = (r: RowReport) => ({
    row: r.row,
    source: r.source,
    verifier_source: r.verifier_source,
    class: r.class,
    grade: r.grade,
    ...(r.decided_grade !== r.grade ? { decided_grade: r.decided_grade } : {}),
    optimal_low: r.optimal_low,
    optimal_high: r.optimal_high,
    scores: r.scores,
    status: r.status,
    reason: r.reason,
    ...(r.changed_after_verdict ? { changed_after_verdict: r.changed_after_verdict } : {}),
  });
  for (const key of [...rows.keys()].sort()) {
    const list = rows.get(key) as RowReport[];
    const code = codeOfKey.get(key) ?? null;
    const scoring = list.filter((r) => r.scores);
    if (scoring.length) {
      const grade = worstGrade(scoring.map((r) => r.grade as string));
      weightsMarkers[key] = {
        code,
        weight: spec.mapping.weights[grade],
        grade,
        grade_is: "the worst verifier grade among the marker's rows that score, not the worst grade over all its rows",
        grade_source: scoring.map((r) => `${r.verifier_source} (${r.source})`).join("; "),
        inversion_reason: null,
        rows: list.map(rowOut),
      };
    } else if (list.some((r) => r.class === spec.eligibility.marker_class) || code) {
      notScored[key] = { code, rows: list.map(rowOut) };
    }
  }
  const weights: Json = {
    _doc:
      "GENERATED by scripts/score/build-score-spec.ts; do not edit by hand. `markers` holds the markers that score today, each with its weight and the grade of its rows that score, and every decided row of the marker with its grade and whether it scores. `not_scored` holds the other class a markers and the codes that wait, row by row, with the reason. `waiting` lists the rows a fixer changed after the verifier's verdict, or that otherwise wait for a decision, and so cannot score.",
    version: spec.version,
    mapping: {
      decision: spec.mapping.decision,
      rule: spec.mapping.rule,
      weights: spec.mapping.weights,
      never_scores: spec.mapping.never_scores,
      grade_c_condition: spec.mapping.grade_c_condition,
      weight_per_marker: `${spec.weight_per_marker.rule} (${spec.weight_per_marker.decision})`,
      signed_grade_c: spec.eligibility.signed_grade_c,
    },
    markers: weightsMarkers,
    not_scored: notScored,
    waiting: [...rows.values()]
      .flat()
      .filter(isWaiting)
      .map((r) => ({ row: r.row, source: r.source, reason: waitingReason(r, spec) }))
      .sort((a, b) => a.row.localeCompare(b.row)),
  };

  // marker-classes.json: the generated fields only.
  const mc = JSON.parse(JSON.stringify(inp.markerClasses)) as { version: string; rules: Json; summary: Json; groups?: Json; markers: Record<string, Json> };
  mc.version = spec.marker_classes.version;
  mc.rules = { ...mc.rules, scoring: spec.marker_classes.rules_scoring };
  const groupOfKey = new Map<string, SpecInputGroup>();
  for (const g of spec.groups) for (const c of g.priority_order) groupOfKey.set(keyOf(c), g);
  const classCount: Record<string, number> = {};
  for (const [key, entry] of Object.entries(mc.markers)) {
    const list = rows.get(key);
    if (!list) fail(`marker-classes.json names ${key}, which has no decided row`);
    // A row the verifier has no row for carries no class (and waits); the others must agree.
    const classes = [...new Set(list.map((r) => r.class).filter((c): c is string => c != null))];
    if (classes.length !== 1) fail(`${key}: the verifier's rows give the classes ${classes.join(", ") || "none"}`);
    const cls = classes[0];
    classCount[cls] = (classCount[cls] ?? 0) + 1;
    const next: Json = {};
    for (const [k, v] of Object.entries(entry)) {
      if (k === "class" || k === "score_status") continue;
      next[k] = v;
      if (k === "draft_class") next.class = cls;
    }
    if (!("class" in next)) next.class = cls;
    next.may_be_scored = scoringKeys.has(key);
    const waiting = list.filter((r) => r.status === "waiting");
    next.score_status = scoringKeys.has(key)
      ? `scores${list.some((r) => !r.scores && r.physiological_state === "none") ? " on some rows" : ""}: see docs/signoff/work/score/weights.json`
      : waiting.length
        ? waiting[0].reason
        : list[0].reason;
    if (spec.outside_groups[key]) {
      delete next.redundancy_group;
      delete next.priority_member;
    } else if ("redundancy_group" in next) {
      const g = spec.groups.find((x) => x.governance_group === next.redundancy_group);
      if (g) next.priority_member = keyOf(g.priority_order[0]) === key;
    }
    const g = groupOfKey.get(key);
    if (g && next.redundancy_group !== g.governance_group) fail(`${key}: marker-classes.json puts it in ${String(next.redundancy_group)}, spec-inputs.json in ${g.governance_group}`);
    mc.markers[key] = next;
  }
  for (const key of rows.keys()) if (!mc.markers[key]) fail(`${key} has decided rows and no entry in marker-classes.json`);
  mc.groups = Object.fromEntries(
    spec.groups.map((g) => [
      g.governance_group,
      {
        decision: g.decision,
        priority_order: g.priority_order.map(keyOf),
        members: Object.entries(mc.markers).filter(([, e]) => e.redundancy_group === g.governance_group).map(([k]) => k),
        reason: g.reason,
      },
    ]),
  );
  mc.summary = { ...Object.fromEntries(Object.keys(classCount).sort().map((c) => [c, classCount[c]])), scored_true: scoringKeys.size };
  // Key order: groups after rules-and-classes blocks, where a reader looks for it.
  const ordered: Json = {};
  for (const [k, v] of Object.entries(mc)) {
    if (k === "groups") continue;
    if (k === "markers") ordered.groups = mc.groups;
    ordered[k] = v;
  }

  return { scoreSpec, weights, markerClasses: ordered, specificationMd: withGeneratedBlock(inp.specificationMd, generatedBlock(spec, rows, codes)) };
}

// ─── The generated block of specification.md ───

function generatedBlock(spec: SpecInputs, rows: Map<string, RowReport[]>, codes: string[]): string {
  const groupOf = (code: string) => spec.groups.find((g) => g.priority_order.includes(code));
  const domainOf = (code: string) => Object.entries(spec.coverage.domains).find(([, d]) => d.markers.includes(code))?.[0] ?? "none";
  const rowLabel = (r: RowReport) => `${r.sex}, ${r.age_group}${r.physiological_state !== "none" ? `, ${r.physiological_state}` : ""}`;
  const lines: string[] = [];
  lines.push("| Code | Row key | Group (position) | Domain | Grade | Weight | Rows that score | Rows that do not |");
  lines.push("|---|---|---|---|---|---|---|---|");
  for (const code of codes) {
    const key = spec.markers[code].key;
    const list = rows.get(key) as RowReport[];
    const scoring = list.filter((r) => r.scores);
    const g = groupOf(code);
    const grade = scoring.length ? worstGrade(scoring.map((r) => r.grade as string)) : null;
    lines.push(
      `| ${code} | \`${key}\` | ${g ? `${g.name} (${g.priority_order.indexOf(code) + 1})` : "on its own"} | ${domainOf(code)} | ${grade ?? "none"} | ${grade ? spec.mapping.weights[grade] : "none"} | ` +
        `${scoring.map((r) => `${rowLabel(r)}: ${band(r.optimal_low, r.optimal_high)}`).join("; ") || "none"} | ` +
        `${list.filter((r) => !r.scores).map((r) => `${rowLabel(r)}: ${r.reason}`).join("; ") || "none"} |`,
    );
  }
  lines.push("");
  lines.push("Class a markers with no engine code, and why none of their rows scores:");
  lines.push("");
  lines.push("| Row key | Rows | Reason |");
  lines.push("|---|---|---|");
  const coded = new Set(codes.map((c) => spec.markers[c].key));
  for (const key of [...rows.keys()].sort()) {
    const list = rows.get(key) as RowReport[];
    if (coded.has(key) || !list.some((r) => r.class === spec.eligibility.marker_class)) continue;
    const reasons = [...new Set(list.map((r) => r.reason))];
    lines.push(`| \`${key}\` | ${list.length} | ${reasons.join("; ")} |`);
  }
  const waiting = [...rows.values()].flat().filter(isWaiting).sort((a, b) => a.row.localeCompare(b.row));
  lines.push("");
  lines.push(`Rows that wait (${waiting.length}):`);
  lines.push("");
  for (const r of waiting) lines.push(`- \`${r.row}\` (${r.source}): ${waitingReason(r, spec)}`);
  return lines.join("\n");
}

function withGeneratedBlock(md: string, block: string): string {
  const a = md.indexOf(GENERATED_BEGIN);
  const b = md.indexOf(GENERATED_END);
  if (a < 0 || b < a) fail(`${PATHS.specification} lacks the generated marks`);
  return `${md.slice(0, a + GENERATED_BEGIN.length)}\n\n${block}\n\n${md.slice(b)}`;
}

// ─── Files ───

const readJson = (file: string): Json => JSON.parse(fs.readFileSync(file, "utf8")) as Json;

export function loadInputs(root: string): GeneratorInputs {
  const at = (p: string) => path.resolve(root, p);
  const families: FamilyFile[] = fs
    .readdirSync(at(PATHS.decisions))
    .filter((f) => f.endsWith(".json"))
    .sort()
    .map((f) => {
      const verifyFile = path.join(at(PATHS.verify), f);
      return {
        family: f.replace(/\.json$/, ""),
        decided: (readJson(path.join(at(PATHS.decisions), f)).final_rows ?? []) as FamilyRow[],
        verified: fs.existsSync(verifyFile) ? ((readJson(verifyFile).final_rows ?? []) as FamilyRow[]) : null,
      };
    });
  return {
    spec: readJson(at(PATHS.specInputs)) as unknown as SpecInputs,
    families,
    markerClasses: readJson(at(PATHS.markerClasses)),
    specificationMd: fs.readFileSync(at(PATHS.specification), "utf8"),
  };
}

/** The generated files as text, by path relative to the root. */
export function render(out: GeneratorOutputs): Record<string, string> {
  return {
    [PATHS.scoreSpec]: `${JSON.stringify(out.scoreSpec, null, 2)}\n`,
    [PATHS.weights]: `${JSON.stringify(out.weights, null, 2)}\n`,
    [PATHS.markerClasses]: `${JSON.stringify(out.markerClasses, null, 1)}\n`,
    [PATHS.specification]: out.specificationMd,
  };
}

/** Writes the generated files, or with `check` writes nothing; returns the paths that differ from what is on disk. */
export function run(root: string, check: boolean): string[] {
  const files = render(generate(loadInputs(root)));
  const differing: string[] = [];
  for (const [rel, text] of Object.entries(files)) {
    const file = path.resolve(root, rel);
    const current = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : null;
    if (current === text) continue;
    differing.push(rel);
    if (!check) fs.writeFileSync(file, text);
  }
  return differing;
}

function main(): void {
  const check = process.argv.includes("--check");
  const root = path.resolve(__dirname, "../..");
  const differing = run(root, check);
  if (check && differing.length) {
    console.error(`build-score-spec --check: ${differing.length} file(s) differ from the generator's output:\n${differing.map((f) => `  ${f}`).join("\n")}`);
    process.exit(1);
  }
  console.log(check ? "build-score-spec --check: the generated files are up to date" : `build-score-spec: ${differing.length ? `wrote ${differing.join(", ")}` : "nothing to write"}`);
}

if (require.main === module) main();
