#!/usr/bin/env python3
"""
Build a 5-subject parity fixture for the TS KDM port.

Mirrors `build_lookup.py`'s synthesize_marker_value_at_age + kd_ba flow with
the same s_ca = 10.0 anchor that Phase 8 used, so the TS port can be
asserted to ±0.1y of the Python reference numbers.

Output: src/lib/biomarkers/__tests__/fixtures/kdm-python-parity.json
"""
from __future__ import annotations
import json
import math
import sys
from pathlib import Path

LIB_PATH = Path("/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/marker_library_v2_2.json")
OUT_PATH = Path("/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/__tests__/fixtures/kdm-python-parity.json")


def synthesize(library_markers: dict, marker: str, sex: str, ca: float) -> float | None:
    """Inverse: given (k, q, s) at age ca, return predicted central value.
    With Spanish recalibration applied to q where status==recalibrated_*.
    """
    m = library_markers.get(marker, {})
    if m.get("sex_stratified"):
        kqs = m.get("kqs_M") if sex == "M" else m.get("kqs_F")
    else:
        kqs = m.get("kqs")
    if not kqs or kqs.get("k") is None:
        return None
    k, q = kqs["k"], kqs["q"]
    rc = m.get("spanish_recalibration", {})
    if rc.get("calibration_status", "").startswith("recalibrated"):
        if m.get("sex_stratified"):
            per_sex = (rc.get("per_sex") or {}).get(sex, {}) or {}
            q_spain = per_sex.get("q_spain")
            if q_spain is not None:
                q = q_spain
        else:
            q_spain = rc.get("q_spain")
            if q_spain is not None:
                q = q_spain
    predicted = q + k * ca
    if m.get("log_transformed"):
        return math.exp(predicted)
    return predicted


def kd_ba(values: dict, library_markers: dict, sex: str, ca: float, s_ca: float):
    num = denom = 0.0
    used = []
    for marker, value in values.items():
        if value is None or not math.isfinite(value):
            continue
        m = library_markers.get(marker, {})
        if m.get("sex_stratified"):
            kqs = m.get("kqs_M") if sex == "M" else m.get("kqs_F")
        else:
            kqs = m.get("kqs")
        if not kqs or kqs.get("k") is None or kqs.get("s", 0) <= 0:
            continue
        k, q, s = kqs["k"], kqs["q"], kqs["s"]
        # Spanish recalibration q swap
        rc = m.get("spanish_recalibration", {})
        if rc.get("calibration_status", "").startswith("recalibrated"):
            if m.get("sex_stratified"):
                per_sex = (rc.get("per_sex") or {}).get(sex, {}) or {}
                q_s = per_sex.get("q_spain")
                if q_s is not None:
                    q = q_s
            else:
                q_s = rc.get("q_spain")
                if q_s is not None:
                    q = q_s
        v = math.log(value) if m.get("log_transformed") and value > 0 else value
        if not math.isfinite(v):
            continue
        num += (v - q) * (k / (s ** 2))
        denom += (k / s) ** 2
        used.append(marker)
    if denom == 0 or not used:
        return None
    ba_e = num / denom
    s_ba2 = 1.0 / denom
    s_ca2 = s_ca ** 2
    ba = (ba_e / s_ba2 + ca / s_ca2) / (1.0 / s_ba2 + 1.0 / s_ca2)
    return {"BA": ba, "BA_E": ba_e, "s_BA": math.sqrt(s_ba2),
            "n_used": len(used), "used": used}


def main():
    lib = json.loads(LIB_PATH.read_text())
    markers = lib["markers"]
    base = lib["meta"]["base_panel"]
    # Build a priority list: base panel + remaining trained
    trained = [m for m, e in markers.items()
               if e.get("kdm_contribution") == "trained" and (e.get("kqs") or e.get("kqs_M"))]
    priority = list(base) + [m for m in trained if m not in base]

    # 5 representative test cases — span sex + age + panel size
    cases = [
        {"sex": "M", "ca": 30, "marker_count": 8,  "s_ca": 10.0},
        {"sex": "F", "ca": 45, "marker_count": 14, "s_ca": 10.0},
        {"sex": "M", "ca": 60, "marker_count": 20, "s_ca": 10.0},
        {"sex": "F", "ca": 75, "marker_count": 30, "s_ca": 10.0},
        {"sex": "M", "ca": 50, "marker_count": "all", "s_ca": 10.0},
    ]

    fixture = {"_comment_":
               "5-subject parity fixture mirroring build_lookup.py flow. "
               "Each subject's inputs are synthesized at the chosen CA using "
               "(k, q_spain when recalibrated) + library k; estimator uses "
               "s_ca = 10.0 to match Phase 8 lookup-table conventions. Used by "
               "biological-age-kdm.parity.test.ts to enforce |TS_BA - Python_BA| <= 0.1.",
               "cases": []}

    for c in cases:
        marker_count = c["marker_count"]
        chosen = priority if marker_count == "all" else priority[:marker_count]
        values = {}
        for m in chosen:
            v = synthesize(markers, m, c["sex"], c["ca"])
            if v is not None:
                values[m] = v
        result = kd_ba(values, markers, c["sex"], c["ca"], c["s_ca"])
        if result is None:
            print(f"WARN: no result for {c}", file=sys.stderr)
            continue
        fixture["cases"].append({
            "sex": "male" if c["sex"] == "M" else "female",
            "ca": c["ca"],
            "marker_count": marker_count,
            "s_ca": c["s_ca"],
            "inputs": values,
            "expected_BA": result["BA"],
            "expected_BA_E": result["BA_E"],
            "expected_s_BA": result["s_BA"],
            "expected_n_markers_used": result["n_used"],
        })

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps(fixture, indent=2, ensure_ascii=False))
    print(f"Wrote {OUT_PATH}: {len(fixture['cases'])} cases")
    for case in fixture["cases"]:
        print(f"  {case['sex']} CA={case['ca']} n_markers={case['expected_n_markers_used']}"
              f" → BA={case['expected_BA']:.4f}")


if __name__ == "__main__":
    main()
