/**
 * One-off backfill: recompute every user's rolling-average BA and cache
 * it on `profiles.current_ba*`. Use the same `recomputeAndCacheUserBA`
 * function the lab-upload pipeline will use going forward.
 *
 * Run via:
 *   npx tsx scripts/backfill_rolling_average_ba.ts
 *
 * Requires SUPABASE_SERVICE_ROLE_KEY in env.
 */
import { createClient } from "@supabase/supabase-js";
import { recomputeAndCacheUserBA } from "../src/lib/biomarkers/rolling-average-ba";

async function main() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    throw new Error(
      "Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY",
    );
  }
  const supabase = createClient(url, key);

  // Find all users with at least one ready lab
  const { data: users, error } = await supabase
    .from("lab_results")
    .select("user_id")
    .eq("status", "ready");
  if (error) throw error;

  const uniqueIds = Array.from(
    new Set((users ?? []).map((u: { user_id: string }) => u.user_id)),
  );
  console.log(`Backfilling rolling-average BA for ${uniqueIds.length} users…`);

  for (const userId of uniqueIds) {
    try {
      const result = await recomputeAndCacheUserBA(userId, supabase);
      if (result) {
        console.log(
          `  ✓ ${userId}: BA=${result.ba.toFixed(2)} (${result.method}, ${result.n_labs_averaged} labs, window=${result.window_months ?? "single-lab"})`,
        );
      } else {
        console.log(`  ⊘ ${userId}: no BA (gate failed)`);
      }
    } catch (err) {
      console.error(`  ✗ ${userId}:`, err);
    }
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
