"use client";

/**
 * RevealConstellation — § 05 interactive mockup.
 *
 * The landing-page version of the dashboard constellation. Reuses the
 * same `DashboardCanvas` and `buildNodes` the production dashboard
 * ships, but seeds them with a MOCK biomarker set so visitors can
 * hover / tap the nodes and feel what "your body, read" actually
 * looks like before they sign up. It's the same animation, the same
 * motion physics, the same tooltip surface — just preview data.
 *
 * The mockup represents a "successful" quarterly readout for a
 * 34-year-old whose body age has dropped to 29: mostly jade
 * (optimal) with a couple of gold (attention) markers for visual
 * variety. This ties directly into the triptych reveal (34 | orb |
 * −5) so what the reader sees in the orb is what those two numbers
 * are summarising.
 *
 * Center numerals: the big "29" + "BIO AGE" label sits at the middle
 * of the canvas stage exactly like the dashboard's HeroNumerals, so
 * the same visual grammar carries through from marketing to product.
 *
 * Interaction:
 *  - Desktop hover → transient tooltip floating above the node
 *  - Touch tap → tooltip pins; tap another node to swap, tap the
 *    background to dismiss
 *  - Parallax tilt is only enabled on fine (mouse) input; touch
 *    devices skip parallax so fingers dragging through the canvas
 *    don't disturb the scene — they're trying to scroll the page.
 */

import dynamic from "next/dynamic";
import { useMemo, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import type { BiomarkerValue } from "@/lib/queries/types";
import { ZONE_CONFIG } from "@/lib/biomarkers/zone-config";
import { buildNodes, type NodeDatum } from "@/app/[locale]/(dashboard)/dashboard/dashboard-scene";

// Dynamic client-only import for the Canvas (react-three-fiber has a
// hard dependency on `window`). Mirrors how the dashboard itself
// loads its scene module.
const DashboardCanvas = dynamic(
  () =>
    import("@/app/[locale]/(dashboard)/dashboard/dashboard-scene").then(
      (m) => m.DashboardCanvas,
    ),
  { ssr: false, loading: () => null },
);

const EASE_PREMIUM: [number, number, number, number] = [0.16, 1, 0.3, 1];

// ── Mock biomarker data ───────────────────────────────────────────
// Twenty-six markers across seven categories — a dense, realistic
// quarterly readout with a deliberate zone mix so the constellation
// shows the full range of states the dashboard reports:
//   · 17 optimal (jade)
//   ·  5 above_optimal (gold): LDL-C, Triglycerides, Fasting Glucose,
//                              ALT, Cortisol (AM)
//   ·  3 below_optimal (gold): Vitamin D, Ferritin, Omega-3 Index
//   ·  1 critical_high (terra-red): Lp(a)
// The single critical_high marker is the important narrative beat —
// Lp(a) is a genetic cardiovascular risk factor present in ~20% of
// adults, invisible on a standard GP panel, and untreatable by
// lifestyle alone. It lands as a red dot in the constellation so
// the reader understands the dashboard surfaces dangerous findings
// too, not just a polite all-green reassurance.
// The rest represents the common pattern Eva surfaces: a mostly-
// healthy picture with a handful of attention markers the GP would
// otherwise call "fine". Numbers and units are plausible but
// representative, not drawn from any real lab. Each entry matches
// the shape of BiomarkerValue so `buildNodes` accepts it without
// modification.
const MOCK_BIOMARKERS: BiomarkerValue[] = [
  // ── Cardiovascular ──
  {
    id: "mock-apob",
    lab_result_id: "mock",
    biomarker_key: "apob",
    biomarker_name: "ApoB",
    category: "Cardiovascular",
    value: 72,
    unit: "mg/dL",
    zone: "optimal",
    optimal_low: 50,
    optimal_high: 80,
    normal_low: 40,
    normal_high: 100,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-ldl",
    lab_result_id: "mock",
    biomarker_key: "ldl_c",
    biomarker_name: "LDL-C",
    category: "Cardiovascular",
    value: 112,
    unit: "mg/dL",
    zone: "above_optimal",
    optimal_low: 50,
    optimal_high: 100,
    normal_low: 40,
    normal_high: 130,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-hdl",
    lab_result_id: "mock",
    biomarker_key: "hdl_c",
    biomarker_name: "HDL-C",
    category: "Cardiovascular",
    value: 62,
    unit: "mg/dL",
    zone: "optimal",
    optimal_low: 50,
    optimal_high: 90,
    normal_low: 40,
    normal_high: 100,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Inflammation ──
  {
    id: "mock-crp",
    lab_result_id: "mock",
    biomarker_key: "hs_crp",
    biomarker_name: "hs-CRP",
    category: "Inflammation",
    value: 0.4,
    unit: "mg/L",
    zone: "optimal",
    optimal_low: 0,
    optimal_high: 1,
    normal_low: 0,
    normal_high: 3,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-homocysteine",
    lab_result_id: "mock",
    biomarker_key: "homocysteine",
    biomarker_name: "Homocysteine",
    category: "Inflammation",
    value: 6.2,
    unit: "µmol/L",
    zone: "optimal",
    optimal_low: 4,
    optimal_high: 8,
    normal_low: 4,
    normal_high: 15,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Metabolic ──
  {
    id: "mock-insulin",
    lab_result_id: "mock",
    biomarker_key: "fasting_insulin",
    biomarker_name: "Fasting Insulin",
    category: "Metabolic",
    value: 4.1,
    unit: "µIU/mL",
    zone: "optimal",
    optimal_low: 2,
    optimal_high: 6,
    normal_low: 2,
    normal_high: 25,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-hba1c",
    lab_result_id: "mock",
    biomarker_key: "hba1c",
    biomarker_name: "HbA1c",
    category: "Metabolic",
    value: 5.1,
    unit: "%",
    zone: "optimal",
    optimal_low: 4,
    optimal_high: 5.4,
    normal_low: 4,
    normal_high: 5.7,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-triglycerides",
    lab_result_id: "mock",
    biomarker_key: "triglycerides",
    biomarker_name: "Triglycerides",
    category: "Metabolic",
    value: 128,
    unit: "mg/dL",
    zone: "above_optimal",
    optimal_low: 40,
    optimal_high: 100,
    normal_low: 40,
    normal_high: 150,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-glucose",
    lab_result_id: "mock",
    biomarker_key: "fasting_glucose",
    biomarker_name: "Fasting Glucose",
    category: "Metabolic",
    value: 102,
    unit: "mg/dL",
    zone: "above_optimal",
    optimal_low: 70,
    optimal_high: 90,
    normal_low: 70,
    normal_high: 100,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Hormones ──
  {
    id: "mock-testosterone",
    lab_result_id: "mock",
    biomarker_key: "testosterone",
    biomarker_name: "Testosterone",
    category: "Hormones",
    value: 612,
    unit: "ng/dL",
    zone: "optimal",
    optimal_low: 500,
    optimal_high: 900,
    normal_low: 300,
    normal_high: 1000,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-dheas",
    lab_result_id: "mock",
    biomarker_key: "dhea_s",
    biomarker_name: "DHEA-S",
    category: "Hormones",
    value: 348,
    unit: "µg/dL",
    zone: "optimal",
    optimal_low: 200,
    optimal_high: 450,
    normal_low: 120,
    normal_high: 520,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-tsh",
    lab_result_id: "mock",
    biomarker_key: "tsh",
    biomarker_name: "TSH",
    category: "Hormones",
    value: 1.8,
    unit: "mIU/L",
    zone: "optimal",
    optimal_low: 1,
    optimal_high: 2.5,
    normal_low: 0.4,
    normal_high: 4,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Vitamins & Minerals ──
  {
    id: "mock-vitd",
    lab_result_id: "mock",
    biomarker_key: "vitamin_d",
    biomarker_name: "Vitamin D",
    category: "Vitamins",
    value: 32,
    unit: "ng/mL",
    zone: "below_optimal",
    optimal_low: 40,
    optimal_high: 70,
    normal_low: 20,
    normal_high: 100,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-b12",
    lab_result_id: "mock",
    biomarker_key: "vitamin_b12",
    biomarker_name: "Vitamin B12",
    category: "Vitamins",
    value: 682,
    unit: "pg/mL",
    zone: "optimal",
    optimal_low: 400,
    optimal_high: 900,
    normal_low: 200,
    normal_high: 1100,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-ferritin",
    lab_result_id: "mock",
    biomarker_key: "ferritin",
    biomarker_name: "Ferritin",
    category: "Vitamins",
    value: 42,
    unit: "ng/mL",
    zone: "below_optimal",
    optimal_low: 50,
    optimal_high: 200,
    normal_low: 30,
    normal_high: 400,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-albumin",
    lab_result_id: "mock",
    biomarker_key: "albumin",
    biomarker_name: "Albumin",
    category: "Metabolic",
    value: 4.6,
    unit: "g/dL",
    zone: "optimal",
    optimal_low: 4.2,
    optimal_high: 5,
    normal_low: 3.5,
    normal_high: 5.2,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Liver ──
  {
    id: "mock-alt",
    lab_result_id: "mock",
    biomarker_key: "alt",
    biomarker_name: "ALT",
    category: "Liver",
    value: 42,
    unit: "U/L",
    zone: "above_optimal",
    optimal_low: 10,
    optimal_high: 30,
    normal_low: 7,
    normal_high: 56,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-ast",
    lab_result_id: "mock",
    biomarker_key: "ast",
    biomarker_name: "AST",
    category: "Liver",
    value: 24,
    unit: "U/L",
    zone: "optimal",
    optimal_low: 10,
    optimal_high: 30,
    normal_low: 10,
    normal_high: 40,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-ggt",
    lab_result_id: "mock",
    biomarker_key: "ggt",
    biomarker_name: "GGT",
    category: "Liver",
    value: 18,
    unit: "U/L",
    zone: "optimal",
    optimal_low: 9,
    optimal_high: 25,
    normal_low: 9,
    normal_high: 48,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Cardiovascular (extras) ──
  {
    id: "mock-lpa",
    lab_result_id: "mock",
    biomarker_key: "lp_a",
    biomarker_name: "Lp(a)",
    category: "Cardiovascular",
    value: 182,
    unit: "nmol/L",
    zone: "critical_high",
    optimal_low: 0,
    optimal_high: 75,
    normal_low: 0,
    normal_high: 125,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-total-chol",
    lab_result_id: "mock",
    biomarker_key: "total_cholesterol",
    biomarker_name: "Total Cholesterol",
    category: "Cardiovascular",
    value: 184,
    unit: "mg/dL",
    zone: "optimal",
    optimal_low: 140,
    optimal_high: 200,
    normal_low: 120,
    normal_high: 240,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Hormones (extras) ──
  {
    id: "mock-free-t3",
    lab_result_id: "mock",
    biomarker_key: "free_t3",
    biomarker_name: "Free T3",
    category: "Hormones",
    value: 3.4,
    unit: "pg/mL",
    zone: "optimal",
    optimal_low: 3,
    optimal_high: 4,
    normal_low: 2.3,
    normal_high: 4.2,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-cortisol-am",
    lab_result_id: "mock",
    biomarker_key: "cortisol_am",
    biomarker_name: "Cortisol (AM)",
    category: "Hormones",
    value: 22,
    unit: "µg/dL",
    zone: "above_optimal",
    optimal_low: 8,
    optimal_high: 18,
    normal_low: 5,
    normal_high: 25,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Vitamins & Minerals (extra) ──
  {
    id: "mock-omega3",
    lab_result_id: "mock",
    biomarker_key: "omega_3_index",
    biomarker_name: "Omega-3 Index",
    category: "Vitamins",
    value: 4.2,
    unit: "%",
    zone: "below_optimal",
    optimal_low: 8,
    optimal_high: 12,
    normal_low: 4,
    normal_high: 12,
    interpretation: null,
    created_at: "2026-04-01",
  },
  // ── Kidney ──
  {
    id: "mock-egfr",
    lab_result_id: "mock",
    biomarker_key: "egfr",
    biomarker_name: "eGFR",
    category: "Kidney",
    value: 102,
    unit: "mL/min",
    zone: "optimal",
    optimal_low: 90,
    optimal_high: 130,
    normal_low: 60,
    normal_high: 130,
    interpretation: null,
    created_at: "2026-04-01",
  },
  {
    id: "mock-creatinine",
    lab_result_id: "mock",
    biomarker_key: "creatinine",
    biomarker_name: "Creatinine",
    category: "Kidney",
    value: 0.86,
    unit: "mg/dL",
    zone: "optimal",
    optimal_low: 0.7,
    optimal_high: 1,
    normal_low: 0.6,
    normal_high: 1.3,
    interpretation: null,
    created_at: "2026-04-01",
  },
];

function fmt(n: number | null | undefined): string {
  if (n == null || !Number.isFinite(n)) return "—";
  if (Number.isInteger(n)) return String(n);
  return parseFloat(n.toFixed(2)).toString();
}

interface Props {
  bioAge: number;
  locale: string;
  labels: { bioAge: string; tapHint: string };
}

export function RevealConstellation({ bioAge, locale, labels }: Props) {
  // Hover tooltip (desktop) and pinned tooltip (touch). The pinned
  // one takes precedence when both are set — same logic as the
  // dashboard.
  const [tooltip, setTooltip] = useState<{
    node: NodeDatum;
    x: number;
    y: number;
  } | null>(null);
  const [pinned, setPinned] = useState<{
    node: NodeDatum;
    x: number;
    y: number;
  } | null>(null);
  const visibleTooltip = pinned ?? tooltip;

  // A11Y-003 / PERF-006: under a reduced-motion preference we skip
  // mounting the DashboardCanvas (it runs react-three-fiber's frameloop
  // for the parallax tilt + invalidates on hover/pin) and render a calm
  // static stand-in instead — no continuous motion and no GPU/raycast
  // cost. The center bio-age numerals still carry the narrative beat.
  const reduced = useReducedMotion();

  const nodes = useMemo(() => buildNodes(MOCK_BIOMARKERS), []);

  // Fine-input check: match the dashboard's `isFineInput` derivation
  // via matchMedia. We only need a one-shot snapshot on mount because
  // the marketing page doesn't need to react to input-method changes.
  const [isFineInput] = useState(() => {
    if (typeof window === "undefined" || !window.matchMedia) return true;
    return window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  });

  return (
    <div
      className="relative mx-auto w-full max-w-[560px]"
      style={{ touchAction: "pan-y" }}
    >
      {/* Square stage so the canvas has a fixed aspect. On small
          viewports we cap it to the available width; on lg+ the
          parent grid gives us a generous column. */}
      <div className="relative aspect-square min-h-[320px]">
        {reduced ? (
          // Static stand-in for the constellation orb: three concentric
          // zone rings (optimal / attention / action) in ink at low
          // opacity, echoing the canvas's reference rings. Purely
          // decorative — the bio-age numerals overlay supplies meaning.
          <div
            aria-hidden
            className="absolute inset-0 flex items-center justify-center"
          >
            {[0.62, 0.82, 1].map((scale) => (
              <span
                key={scale}
                className="absolute rounded-full border border-[#1d1b18]/10"
                style={{
                  width: `${scale * 88}%`,
                  height: `${scale * 88}%`,
                }}
              />
            ))}
          </div>
        ) : (
          <DashboardCanvas
            nodes={nodes}
            locale={locale}
            highlightedCategory={null}
            enableParallax={isFineInput}
            onHover={(node, screen) =>
              setTooltip({ node, x: screen.x, y: screen.y })
            }
            onUnhover={() => setTooltip(null)}
            onPin={(node, screen) =>
              setPinned({ node, x: screen.x, y: screen.y })
            }
            onUnpin={() => setPinned(null)}
          />
        )}

        {/* Center numerals — the big "29" bio age sits in the middle
            of the constellation, same composition as the dashboard's
            HeroNumerals. pointer-events-none so it doesn't eat hover
            events from the canvas nodes behind it. */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <motion.div
            initial={reduced ? false : { opacity: 0, scale: 0.94 }}
            whileInView={reduced ? undefined : { opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-10%" }}
            transition={
              reduced
                ? { duration: 0 }
                : { duration: 1.1, delay: 0.4, ease: EASE_PREMIUM }
            }
            className="text-center"
          >
            <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.8px] text-[#3a665e] md:text-[10px]">
              {labels.bioAge}
            </p>
            <p
              className="mt-1 font-[family-name:var(--font-sentient)] text-[92px] font-medium leading-[0.85] tracking-[-3.5px] text-[#3a665e] md:text-[128px] md:tracking-[-5px]"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {bioAge}
            </p>
          </motion.div>
        </div>

        {/* Node tooltip — same surface + positioning logic the
            dashboard uses. On fine input it floats above the cursor;
            on touch it docks to the top of the stage so it never
            overflows the viewport. */}
        {visibleTooltip && (
          <div
            className={
              isFineInput
                ? "pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-xl bg-[#1d1b18]/92 px-3 py-2 font-[family-name:var(--font-manrope)] text-[11px] text-white shadow-[0_20px_40px_-12px_rgba(29,27,24,0.5)] backdrop-blur-md"
                : "absolute left-3 right-3 top-3 z-20 mx-auto max-w-[calc(100%-1.5rem)] rounded-xl bg-[#1d1b18]/95 px-4 py-3 font-[family-name:var(--font-manrope)] text-[12px] text-white shadow-[0_20px_40px_-12px_rgba(29,27,24,0.5)] backdrop-blur-md"
            }
            style={
              isFineInput
                ? {
                    left: visibleTooltip.x,
                    top: visibleTooltip.y - 8,
                    pointerEvents: pinned ? "auto" : "none",
                  }
                : { pointerEvents: "auto" }
            }
            onClick={() => setPinned(null)}
          >
            <div className="flex items-center gap-2">
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ backgroundColor: visibleTooltip.node.color }}
              />
              <span className="truncate font-bold">
                {visibleTooltip.node.name}
              </span>
            </div>
            <div
              className="mt-0.5 font-[family-name:var(--font-dm-mono)] text-[10px] text-white/70"
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              {fmt(visibleTooltip.node.value)}
              {visibleTooltip.node.unit
                ? ` ${visibleTooltip.node.unit}`
                : ""}{" "}
              ·{" "}
              {(locale === "es"
                ? ZONE_CONFIG[visibleTooltip.node.zone].label_es
                : ZONE_CONFIG[visibleTooltip.node.zone].label
              ).toLowerCase()}
            </div>
          </div>
        )}
      </div>

      {/* Tap hint below the stage — tells the reader this is
          interactive. Mono caption so it reads as a museum label. */}
      <p className="mt-4 text-center font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] md:text-[10px]">
        {labels.tapHint}
      </p>
    </div>
  );
}
