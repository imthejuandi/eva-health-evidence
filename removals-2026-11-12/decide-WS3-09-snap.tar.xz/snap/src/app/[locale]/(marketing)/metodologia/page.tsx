"use client";

/**
 * /metodologia — short trust-signal page for the KDM v2.2.2 biological age.
 *
 * This page is the destination of the "¿Cómo se calcula?" link in the
 * dashboard's KDM provenance row (see `dashboard-client.tsx` § VitalsStrip).
 * It's deliberately short and oriented toward non-specialist readers: how
 * the model was tested, against what, with what numbers, its known limits,
 * and where to read more.
 *
 * For the deep methodology (the 10-section "completa" document with full
 * citations), see ./completa/page.tsx.
 */

import { useParams } from "next/navigation";
import {
  ChapterMarker,
  SectionHeadline,
  SubHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
  HandDrawnUnderline,
} from "@/components/marketing/editorial";
import { CTAButton } from "@/components/marketing/CTAButton";

export default function MetodologiaPage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const es = locale === "es";

  const t = es
    ? {
        ch01: "§ 01 · La pregunta",
        ch02: "§ 02 · La evidencia",
        ch03: "§ 03 · El método",
        ch04: "§ 04 · La transparencia",

        heroTitle: "Cómo estimamos tu edad biológica.",
        heroLede:
          "No es una opinión ni un score genérico. Es una estimación evaluada frente a la mortalidad en 18.570 adultos de NHANES, con limitaciones que explicamos abiertamente.",

        // § 02 Trust signals
        sigTitle: "Tres números que importan.",
        sigBody:
          "El algoritmo se evaluó frente a las muertes registradas en NHANES, los mismos datos con los que se construyó.",
        sig1Eye: "HAZARD RATIO",
        sig1Val: "1,39",
        sig1Label: "por desviación estándar",
        sig1Desc:
          "A igual edad y sexo, cada desviación estándar de edad biológica se asocia a un riesgo relativo de mortalidad alrededor de un 39% mayor (versión de referencia, NHANES). La desviación estándar se mide en toda la muestra, con personas de todas las edades. En la versión completa, la cifra es 1,65, en sus propias unidades: las dos cifras no se pueden comparar entre sí. Ese 1,65 se obtuvo en NHANES con todos los marcadores entrenados que tenía cada persona, entre ellos varios que el cálculo de EVA no usa aunque aparezcan en tu analítica (como neutrófilos, monocitos, eosinófilos y basófilos, el recuento absoluto de linfocitos, sodio, potasio, cloruro, HCM, CHCM, VPM, colesterol no HDL, PSA, y plomo y mercurio en sangre) y el filtrado glomerular estimado. La cifra del dashboard usa como mucho 46 marcadores, 12 con el Panel Base, y no se ha evaluado frente a la mortalidad.",
        sig2Eye: "C-STATISTIC",
        sig2Val: "+0,009",
        sig2Label: "sobre la edad y el sexo",
        sig2Desc:
          "La edad y el sexo solos ya dan un C-statistic de 0,77. La versión de referencia, calculada con los marcadores del Panel Base de EVA, lo sube unos 0,009: una ganancia pequeña. Son datos de NHANES de 2007 a 2014, que forman parte de los datos con los que se construyó el modelo.",
        sig3Eye: "POBLACIÓN",
        sig3Val: "18.570",
        sig3Label: "adultos NHANES",
        sig3Desc:
          "Se evaluó frente a la mortalidad en 18.570 adultos de NHANES, con seguimiento hasta 2019. El modelo se construyó con datos del National Health and Nutrition Examination Survey de Estados Unidos (1999-2018). En 9 de sus 14 marcadores de referencia usa valores de estudios españoles.",

        // § 03 Method
        methodTitle: "Klemera-Doubal, ajustado en parte con valores españoles.",
        methodBody:
          "Tu edad biológica se calcula con el método de Klemera-Doubal (2006), un estimador estadístico que combina múltiples biomarcadores en un único número de años. Cada biomarcador pesa más cuanto más claramente cambia con la edad en la población de referencia.",
        methodBody2:
          "Para el mercado español hemos sustituido las medias de 9 de los 14 marcadores de referencia por valores de estudios españoles, sobre todo de la cohorte PESA, de adultos de mediana edad de Madrid. Para tres de esos marcadores, la fuente es el artículo principal de PESA (Fernández-Friera 2015); para otros cuatro, una submuestra de 400 de sus participantes (Mastrangelo 2025). En cuatro de los nueve (creatinina, HDL, ácido úrico y GGT), las medias son distintas para hombres y mujeres; en tres de esos cuatro (creatinina, ácido úrico y GGT) no hemos podido verificar las medias por sexo en las fuentes citadas. Albúmina, BUN, fosfatasa alcalina, ferritina y fructosamina siguen usando las medias de NHANES. La versión completa aplica el mismo ajuste a hasta siete marcadores más, entre ellos la hemoglobina y la testosterona total, también por sexo. Para estas dos tampoco hemos podido verificar las medias por sexo en las fuentes citadas. Las medias por sexo se aplican desde mayo de 2026, tras detectar que no se estaban aplicando. El objetivo es que una persona española con valores típicos para su edad obtenga una edad biológica cercana a su edad real, y no desplazada por las diferencias con la población de Estados Unidos. No sabemos todavía si se cumple, y el ajuste no se ha evaluado frente a la mortalidad en la población española.",
        methodCallout:
          "La edad biológica responde a una pregunta distinta de la del score de longevidad. La primera te dice cómo envejeces frente a la población; la segunda, lo cerca que estás de lo óptimo.",

        // § 04 Transparency
        transTitle: "Lo que el modelo sabe — y lo que no.",
        transKnows: "Lo que el modelo capta:",
        transKnowsItems: [
          "Trayectoria de envejecimiento poblacional de sus 14 marcadores de referencia (riñón, hígado, inflamación, glicación, lípidos, nutrición). El Panel Base de EVA, de 13 pruebas, aporta 10 de ellos. Su fructosamina medida no se usa: el modelo se entrenó con una fructosamina derivada de la HbA1c.",
          "Diferencias entre hombres y mujeres: 16 de los 81 marcadores entrenados se ajustan por separado según el sexo (uno de ellos, el PSA, solo en hombres).",
          "Suplementación de creatina: si declaras tu dosis diaria, ajustamos la creatinina. Los ensayos encontraron una subida media de 0,13 mg/dL, que EVA aplica como un 13% de tu creatinina, entera desde 3 g al día y en proporción a la dosis por debajo; es una estimación de EVA.",
          "De los marcadores de filtración renal entran la creatinina y la urea (BUN); la cistatina C y el filtrado glomerular estimado que imprimen algunos laboratorios se muestran como resultados, pero no entran en el cálculo. Las cifras calculadas antes de que se aplicaran estas reglas de riñón y creatina siguen las reglas anteriores mientras no se recalculen.",
        ],
        transLimits: "Lo que el modelo no captura y sus límites conocidos:",
        // Items 5 to 11 are the known limits of this version. Each is backed
        // by EVA's own files: docs/biomarker-evidence/longevity/base-panel/
        // NUMBERS.md (sections A, C, D and E) and ASSESSMENT.md (F1, F3, F4, F5),
        // docs/biomarker-evidence/longevity/KDM-DIRECTION.md,
        // ml/biological-age/REPORT.md and REPORT-baselines.md (T3, T7),
        // docs/biomarker-evidence/bioage-model-selection/DECISION.md and
        // METHODOLOGY-CLAIMS-FOR-COUNSEL.md; item 11 (creatine), CALIBRATION-AND-CREATINE.md.
        transLimitsItems: [
          "Variaciones agudas (deshidratación, ejercicio reciente, comida pre-analítica).",
          "Composición corporal (masa muscular vs masa grasa) más allá de la suplementación de creatina.",
          "Medicamentos que afectan biomarcadores (estatinas, inhibidores de la ECA, levotiroxina).",
          "Genética, epigenética, telómeros — métodos válidos pero complementarios.",
          "Gran parte del resultado es tu edad cronológica. Con el Panel Base, para un hombre típico de 45 años, la edad cronológica pesa un 78% en la cifra del dashboard y un 60% en la versión de referencia.",
          "La cifra varía entre analíticas aunque nada haya cambiado. EVA lo simuló con el Panel Base para un hombre y una mujer típicos de 45 años. La variación biológica normal entre extracciones separadas por unas semanas da, por sí sola, una desviación estándar de unos 2 años en la cifra del dashboard y de unos 4 en la versión de referencia, sin contar el error del laboratorio. Para que un cambio entre dos resultados se pueda considerar real, con un 95% de confianza, tiene que superar unos 5 años en el dashboard o unos 10 a 12 en la versión de referencia.",
          "Puede dar una edad mayor que la cronológica. En una evaluación interna con datos de NHANES, de adultos de Estados Unidos y con el ajuste español ya aplicado, la versión de referencia calculada con los marcadores del Panel Base dio de media 3,5 años más que la edad cronológica. No se ha medido en personas españolas.",
          "No se ha evaluado frente a la mortalidad en España. Las cifras de mortalidad proceden de NHANES, en Estados Unidos, y de los mismos datos con los que se construyó el modelo.",
          "Algunas mejoras pueden subir la cifra: el modelo solo tiene en cuenta cómo cambia cada marcador con la edad en NHANES. Con el Panel Base, en un hombre típico de 45 años, subir el HDL de 47 a 57 mg/dL o bajar la GGT de 32 a 15 U/L sube la versión de referencia casi 2 años, y la cifra del dashboard algo menos de 1.",
          "La cifra depende de qué pruebas se hicieron. En simulaciones de EVA, la misma persona dio en la versión de referencia entre 3 y 7 años más con solo el Panel Base que con un panel completo, en seis de siete casos.",
          "Si tomas creatina y no indicas tu dosis diaria, la cifra sale más alta: entre 1 y 2 años en la versión de referencia con el Panel Base, en nuestros perfiles de ejemplo, y algo menos con un panel completo. Con la dosis declarada, el ajuste es aproximado: queda corto con 2 g al día tras una fase de carga y se pasa en las primeras semanas si se empieza sin fase de carga.",
        ],

        ctaTitle: "Lee la metodología completa.",
        ctaBody:
          "El documento completo cubre los datos de entrenamiento, el ajuste con valores españoles, el método matemático, la evaluación frente a la mortalidad y nuestras limitaciones, con referencias a literatura primaria.",
        ctaButton: "Ver metodología completa",
      }
    : {
        ch01: "§ 01 · The question",
        ch02: "§ 02 · The evidence",
        ch03: "§ 03 · The method",
        ch04: "§ 04 · Transparency",

        heroTitle: "How we estimate your biological age.",
        heroLede:
          "Not an opinion, and not a generic score. An estimate tested against recorded deaths in 18,570 NHANES adults, with limits we explain openly.",

        sigTitle: "Three numbers that matter.",
        sigBody:
          "The algorithm was tested against recorded deaths in NHANES, the same data it was built on.",
        sig1Eye: "HAZARD RATIO",
        sig1Val: "1.39",
        sig1Label: "per standard deviation",
        sig1Desc:
          "At the same age and sex, each standard deviation of biological age goes with about 39% higher relative mortality risk (Reference version, NHANES). The standard deviation is measured across the whole sample, people of all ages. In the Comprehensive version, the figure is 1.65, in its own units: the two figures cannot be compared. That 1.65 was obtained in NHANES with every trained marker each person had, including several that EVA's calculation does not use even when they appear on your report (such as neutrophils, monocytes, eosinophils and basophils, the absolute lymphocyte count, sodium, potassium, chloride, MCH, MCHC, MPV, non-HDL cholesterol, PSA, and blood lead and mercury) and the estimated GFR. The dashboard figure uses at most 46 markers, 12 with the Base Panel, and has not been tested against mortality.",
        sig2Eye: "C-STATISTIC",
        sig2Val: "+0.009",
        sig2Label: "over age and sex",
        sig2Desc:
          "Age and sex alone already give a C-statistic of 0.77. The Reference version, computed from the markers in EVA's Base Panel, raises it by about 0.009: a small gain. These are NHANES data from 2007 to 2014, which are part of the data the model was built on.",
        sig3Eye: "POPULATION",
        sig3Val: "18,570",
        sig3Label: "NHANES adults",
        sig3Desc:
          "Tested against recorded deaths in 18,570 NHANES adults, with follow-up through 2019. The model was built on the U.S. National Health and Nutrition Examination Survey (1999-2018). For 9 of its 14 reference markers it uses values from Spanish studies.",

        methodTitle: "Klemera-Doubal, partly adjusted with Spanish values.",
        methodBody:
          "Your biological age is calculated with the Klemera-Doubal method (2006), a statistical estimator that combines multiple biomarkers into a single number of years. Each biomarker weighs more the more clearly it changes with age in the reference population.",
        methodBody2:
          "For the Spanish market we replaced the means of 9 of the 14 reference markers with values from Spanish studies, mostly from the PESA cohort of middle-aged adults in Madrid. For three of those markers, the source is the main PESA paper (Fernández-Friera 2015); for four others, a subsample of 400 of its participants (Mastrangelo 2025). For four of the nine (creatinine, HDL, uric acid and GGT), the means differ for men and women; for three of those four (creatinine, uric acid and GGT) we could not verify the per-sex means in the cited sources. Albumin, BUN, alkaline phosphatase, ferritin and fructosamine still use NHANES means. The Comprehensive version applies the same adjustment to up to seven more markers, including hemoglobin and total testosterone, also by sex. For these two, we could not verify the per-sex means in the cited sources either. The per-sex means have been applied since May 2026, after we found they were not being applied. The aim is that a Spanish person with typical values for their age gets a biological age close to their real age, not one shifted by differences from the U.S. population. We do not yet know whether it does, and the adjustment has not been tested against recorded deaths in the Spanish population.",
        methodCallout:
          "Biological age answers a different question than the longevity score. The first tells you how you're aging vs. the population; the second, how close you are to optimal.",

        transTitle: "What the model knows — and what it doesn't.",
        transKnows: "What the model captures:",
        transKnowsItems: [
          "Population aging trajectory of its 14 reference markers (kidney, liver, inflammation, glycation, lipids, nutrition). EVA's 13-test Base Panel supplies 10 of them. Its measured fructosamine is not used: the model was trained on a fructosamine derived from HbA1c.",
          "Sex differences: 16 of the 81 trained markers are fitted separately by sex (one of them, PSA, for men only).",
          "Creatine supplementation: if you declare your daily dose, we adjust creatinine. Trials found an average rise of 0.13 mg/dL, which EVA applies as 13% of your creatinine, in full from 3 g a day and in proportion to the dose below that; this is EVA's estimate.",
          "Of the kidney filtration markers, creatinine and urea (BUN) enter; cystatin C, and the estimated GFR some laboratories print, are shown as results but do not enter the calculation. Figures calculated before these kidney and creatine rules applied follow the earlier rules unless they are recalculated.",
        ],
        transLimits: "What the model doesn't capture, and its known limits:",
        // Items 5 to 11: see the source note on the Spanish list above.
        transLimitsItems: [
          "Acute variations (dehydration, recent exercise, pre-analytical meals).",
          "Body composition (muscle vs fat mass) beyond creatine supplementation.",
          "Medications affecting biomarkers (statins, ACE inhibitors, levothyroxine).",
          "Genetics, epigenetics, telomeres — valid but complementary methods.",
          "A large part of the result is your chronological age. With the Base Panel, for a typical 45-year-old man, chronological age carries 78% of the weight in the dashboard figure and 60% in the Reference version.",
          "The figure varies between lab tests even when nothing has changed. EVA simulated this with the Base Panel for a typical man and woman aged 45. Normal biological variation alone, between draws a few weeks apart, gives a standard deviation of about 2 years in the dashboard figure and about 4 in the Reference version, before any laboratory error. To count as real with 95% confidence, a change between two results has to exceed about 5 years on the dashboard, or about 10 to 12 years in the Reference version.",
          "It can read older than chronological age. In an internal evaluation on NHANES data from U.S. adults, with the Spanish adjustment already applied, the Reference version computed from the Base Panel markers read 3.5 years above chronological age on average. This has not been measured in Spanish people.",
          "It has not been tested against recorded deaths in Spain. The mortality figures come from NHANES, in the United States, and from the same data the model was built on.",
          "Some improvements can raise the figure: the model only takes into account how each marker changes with age in NHANES. With the Base Panel, for a typical 45-year-old man, raising HDL from 47 to 57 mg/dL or lowering GGT from 32 to 15 U/L raises the Reference version by almost 2 years, and the dashboard figure by just under 1.",
          "The figure depends on which tests were done. In EVA's simulations, the same person read 3 to 7 years older in the Reference version with the Base Panel alone than with a full panel, in six of seven cases.",
          "If you take creatine and do not give your daily dose, the figure reads higher: between 1 and 2 years in the Reference version with the Base Panel, in our example profiles, and somewhat less with a full panel. With a declared dose the adjustment is approximate: it falls short at 2 g a day after a loading phase, and overshoots in the first weeks when started without one.",
        ],

        ctaTitle: "Read the full methodology.",
        ctaBody:
          "The full document covers training data, the adjustment with Spanish values, the mathematical method, testing against recorded deaths, and our limitations, with references to primary literature.",
        ctaButton: "Read the full methodology",
      };

  return (
    <main className="relative bg-[#fef8f2] text-[#1d1b18]">
      {/* ═══════════════════════════════════════════════════════════
       * § 01 — Hero: the question
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ChapterMarker>{t.ch01}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">
          {t.heroTitle.split(" ").slice(0, -2).join(" ")}{" "}
          <span className="relative inline-block">
            {t.heroTitle.split(" ").slice(-2).join(" ")}
            <HandDrawnUnderline />
          </span>
        </SectionHeadline>
        <LedeItalic className="mt-8 md:mt-10 max-w-2xl">{t.heroLede}</LedeItalic>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 02 — Trust signals (3 cards)
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ChapterMarker>{t.ch02}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.sigTitle}</SectionHeadline>
        <BodyProse className="mt-6 max-w-2xl">{t.sigBody}</BodyProse>

        <div className="mt-14 md:mt-20 grid grid-cols-1 md:grid-cols-3 gap-px bg-[#1d1b18]/10 border border-[#1d1b18]/10">
          {[
            { eye: t.sig1Eye, val: t.sig1Val, label: t.sig1Label, desc: t.sig1Desc },
            { eye: t.sig2Eye, val: t.sig2Val, label: t.sig2Label, desc: t.sig2Desc },
            { eye: t.sig3Eye, val: t.sig3Val, label: t.sig3Label, desc: t.sig3Desc },
          ].map((s, i) => (
            <div key={i} className="bg-[#fef8f2] p-8 md:p-10">
              <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
                {s.eye}
              </p>
              <p
                className="mt-4 font-[family-name:var(--font-cormorant)] text-[56px] md:text-[72px] font-medium leading-none text-[#3a665e]"
                style={{ fontVariantNumeric: "tabular-nums" }}
              >
                {s.val}
              </p>
              <p className="mt-2 font-[family-name:var(--font-dm-mono)] text-[11px] uppercase tracking-[1.4px] text-[#4c463f]/70">
                {s.label}
              </p>
              <p className="mt-5 text-[15px] leading-relaxed text-[#4c463f]">
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 03 — Method
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="xlarge">
        <ChapterMarker>{t.ch03}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.methodTitle}</SectionHeadline>
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-7">
            <BodyProse>{t.methodBody}</BodyProse>
            <BodyProse className="mt-6">{t.methodBody2}</BodyProse>
          </div>
          <aside className="lg:col-span-5 lg:pl-8 lg:border-l lg:border-[#1d1b18]/10">
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
              {es ? "Importante" : "Important"}
            </p>
            <LedeItalic className="mt-4">{t.methodCallout}</LedeItalic>
          </aside>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * § 04 — Transparency
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream-alt" size="xlarge">
        <ChapterMarker>{t.ch04}</ChapterMarker>
        <SectionHeadline className="mt-6 md:mt-8">{t.transTitle}</SectionHeadline>

        <div className="mt-12 md:mt-16 grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16">
          <div>
            <SubHeadline className="text-[#3a665e]">{t.transKnows}</SubHeadline>
            <ul className="mt-6 space-y-4">
              {t.transKnowsItems.map((item, i) => (
                <li key={i} className="flex gap-4">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#3a665e]/60 mt-1.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[15px] leading-relaxed text-[#4c463f]">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SubHeadline className="text-[#97472c]">{t.transLimits}</SubHeadline>
            <ul className="mt-6 space-y-4">
              {t.transLimitsItems.map((item, i) => (
                <li key={i} className="flex gap-4">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[12px] text-[#97472c]/60 mt-1.5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[15px] leading-relaxed text-[#4c463f]">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </SectionShell>

      {/* ═══════════════════════════════════════════════════════════
       * CTA — link to deep methodology
       * ═══════════════════════════════════════════════════════════ */}
      <SectionShell tone="cream" size="large">
        <div className="text-center max-w-2xl mx-auto">
          <SectionHeadline>{t.ctaTitle}</SectionHeadline>
          <BodyProse className="mt-6">{t.ctaBody}</BodyProse>
          <div className="mt-10">
            <CTAButton
              variant="primary"
              href={`/${locale}/metodologia/completa`}
            >
              {t.ctaButton}
            </CTAButton>
          </div>
        </div>
      </SectionShell>
    </main>
  );
}
