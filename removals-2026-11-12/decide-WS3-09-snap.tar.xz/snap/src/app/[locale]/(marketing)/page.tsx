"use client";

/**
 * Eva Health — Landing page.
 *
 * The production marketing surface at /{locale}. Shader-driven
 * specimen hero, infinite stat marquee, horizontal biomarker
 * specimen plates, sticky method narrative, monumental editorial
 * typography, cinematic pull quotes, and an interactive 3D
 * constellation reveal backed by the same canvas the dashboard
 * ships. Warm earth palette (terra, jade, cream, ink), Sentient +
 * Manrope + DM Mono type stack.
 *
 * Chapter rhythm: § 01 Dispatch → § 02 Shortfall → § 03 Reckoning
 * → § 04 Method → § 05 The reveal → § 06 Communiqué → § 07 Call.
 *
 * See `.impeccable.md` for the full design context.
 */

import { useParams } from "next/navigation";
import Link from "next/link";
import dynamic from "next/dynamic";
import { useRef } from "react";
import type { CSSProperties } from "react";
import {
  motion,
  useReducedMotion,
  useScroll,
  useTransform,
  type Variants,
} from "framer-motion";
import { getMarketingTranslations } from "@/lib/marketing-translations";
import { RangeComparisonBar } from "@/components/marketing/RangeComparisonBar";
import {
  RulerCarousel,
  type CarouselItem,
} from "@/components/ui/ruler-carousel";
import {
  ChapterMarker,
  SectionHeadline,
  SectionShell,
  SubHeadline,
} from "@/components/marketing/editorial";

const HeroSpecimenScene = dynamic(
  () => import("./specimen-scene").then((m) => m.HeroSpecimenScene),
  { ssr: false, loading: () => null },
);

// § 05 The reveal uses the same 3D constellation the production
// dashboard renders, seeded with mock biomarker data so visitors can
// actually interact with the orb — hover nodes, tap to pin tooltips,
// feel what their own readout will look like. Dynamic import keeps
// the R3F bundle out of the hero critical path.
const RevealConstellation = dynamic(
  () =>
    import("./reveal-constellation").then((m) => m.RevealConstellation),
  { ssr: false, loading: () => null },
);

const DISPLAY = "font-[family-name:var(--font-sentient)]";
const MONO = "font-[family-name:var(--font-dm-mono)]";
const BODY = "font-[family-name:var(--font-manrope)]";
const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1];

/* ──────────────────────────────────────────────────────────────────────────
 * getBoldCopy — spreads the shared marketing translations and overrides
 * specific keys with longevity-marketing-rewritten versions scoped to
 * the landing page. The legacy name is kept for low-diff merges.
 *
 * Corrected positioning (3rd rewrite pass):
 *
 * Eva's core product is a QUARTERLY SUBSCRIPTION using an at-home
 * needle-free kit that captures a sample for the 13 Base Panel tests per
 * collection. That base panel is the highest-signal longevity
 * readout you can physically run from a needle-free home sample, and
 * it's enough to compute biological age and the longevity score. A
 * 165+ full panel is available on demand via a clinical blood draw
 * when the customer wants to go deeper.
 *
 * Earlier drafts framed this as "not more markers, the right
 * markers" — which was wrong. More data is always better; the 13
 * aren't "right" vs. a "wrong" list, they're a FOUNDATIONAL LONGEVITY
 * BASELINE constrained by what a needle-free kit can collect. The
 * real unique value isn't the selection — it's the CADENCE. Running
 * a high-signal baseline at home every 3 months produces 52 data
 * points a year on the markers that track ageing. Ageing moves in
 * trendlines, not snapshots; repetition is the signal. The full
 * 165+ panel is there as a complement for customers who want the
 * full picture in one sitting.
 *
 * Every section now leads with "trendlines not snapshots":
 * foundational baseline + quarterly cadence + 165+ as the deeper
 * complement, not a consolation prize.
 * ────────────────────────────────────────────────────────────────────────── */
function getBoldCopy(locale: string) {
  const base = getMarketingTranslations(locale);
  if (locale === "es") {
    return {
      ...base,
      // ─── Hero ───
      heroSub:
        "El 95% de los resultados «normales» esconden una deficiencia. Los encontramos cada 3 meses, en casa: contra rangos de longevidad, no contra promedios enfermos.",

      // ─── § 02 Shortfall ───
      ledeTitle: "«Normal» se construyó con gente enferma.",
      ledeBody1:
        "Los rangos de referencia de laboratorio vienen de promedios poblacionales. Una población media que está cansada, inflamada, resistente a la insulina y envejeciendo más rápido de lo que debería. «Normal» es donde vive esa población, no donde deberías vivir tú.",
      ledeBody2:
        "Óptimo es otra cosa. Es el rango donde tu cuerpo realmente funciona mejor. La distancia entre «normal» y «óptimo» es donde vive el envejecimiento silencioso: años perdidos antes de que nada aparezca como enfermedad.",
      ledeBody3:
        "Una base de longevidad. Leída cada 3 meses. Una y otra vez.",

      // ─── § 03 Reckoning ───
      reckoningTitle: "El envejecimiento se mueve en trayectorias, no en fotos.",
      reckoningSubtitle:
        "Nuestro Panel Base lee 13 pruebas en casa, cada 3 meses, entre ellas ApoB, PCR-hs y fructosamina, además de lípidos, riñón e hígado. Son 52 resultados al año. El panel completo de 165+ está a un clic cuando quieras ir más profundo. Abajo: cinco lecturas reales que tu médico llamaría «bien».",

      // ─── § 04 Method ───
      processTitle: "Cuatro pasos. Cada 3 meses.",
      processSubtitle: "Sin clínica. Sin agujas. Sin adivinanzas.",
      step1Title: "Recoge en casa",
      step1Desc:
        "Kit sin aguja. Sin clínica, sin cita, sin sala de espera.",
      step2Title: "Tu base de longevidad",
      step2Desc:
        "Cada 3 meses, las 13 pruebas del Panel Base: ApoB, PCR-hs, fructosamina, lípidos, riñón e hígado. Repetidas, se vuelven una trayectoria.",
      step3Title: "Leídos contra longevidad",
      step3Desc:
        "Cada marcador contra rangos de longevidad, no promedios poblacionales. Más tu edad biológica y puntuación de longevidad.",
      step4Title: "Tú eliges qué sigue",
      step4Desc:
        "Repite lo que estás mejorando, sumérgete en un panel nuevo, o reserva la extracción completa de 165 marcadores.",

      // ─── § 05 The reveal (was "The specimen") ───
      chapter05: "§ 05 · La revelación",
      specimenTitle: "¿Cuántos años tienes, en realidad?",
      specimenBody:
        "La edad de tu carnet no cambia. La que lleva tu cuerpo sí. EVA la estima cada trimestre y sigue su tendencia.",

      // ─── § 07 Call ───
      callBody:
        "€99 al trimestre. Sin aguja en casa. Una base de longevidad, leída cada 3 meses. Cancela cuando quieras.",
    };
  }
  return {
    ...base,
    // ─── Hero ───
    heroSub:
      "95% of \u201cnormal\u201d lab results hide a deficiency. We find them every 3 months, at home: scored against longevity ranges, not sick averages.",

    // ─── § 02 Shortfall ───
    ledeTitle: "\u201cNormal\u201d was built from sick people.",
    ledeBody1:
      "Lab reference ranges come from population averages. An average population that\u2019s tired, inflamed, insulin-resistant, and ageing faster than it should. \u201cNormal\u201d is where that population lives, not where you should.",
    ledeBody2:
      "Optimal is somewhere else. It\u2019s the range where your body actually runs best. The gap between \u201cnormal\u201d and \u201coptimal\u201d is where silent ageing happens: years lost before anything shows up as disease.",
    ledeBody3:
      "A longevity baseline. Read every 3 months. Again and again.",

    // ─── § 03 Reckoning ───
    reckoningTitle: "Ageing moves in trendlines, not snapshots.",
    reckoningSubtitle:
      "Our Base Panel reads 13 tests at home, every 3 months, including ApoB, hs-CRP and fructosamine, plus lipids, kidney and liver. That is 52 results a year. The full 165+ panel is one click away when you want to go deeper. Below: five real readings your GP would call \u201cfine.\u201d",

    // ─── § 04 Method ───
    processTitle: "Four steps. Every 3 months.",
    processSubtitle: "No clinic. No needles. No guesswork.",
    step1Title: "Collect at home",
    step1Desc:
      "Needle-free kit. No clinic, no appointment, no waiting room.",
    step2Title: "Your longevity baseline",
    step2Desc:
      "Every quarter, the 13 Base Panel tests: ApoB, hs-CRP, fructosamine, lipids, kidney and liver. Repeated, they become a trendline.",
    step3Title: "Scored against longevity",
    step3Desc:
      "Each marker read against longevity ranges, not sick averages. Plus your biological age and longevity score.",
    step4Title: "You pick what\u2019s next",
    step4Desc:
      "Retest what you\u2019re moving, dive into a new panel, or book the full 165-marker blood draw.",

    // ─── § 05 The reveal (was "The specimen") ───
    chapter05: "\u00a7 05 · The reveal",
    specimenTitle: "How old are you, really?",
    specimenBody:
      "The age on your ID is fixed. The one your body keeps isn\u2019t. EVA estimates it every quarter and follows its trend.",

    // ─── § 07 Call ───
    callBody:
      "\u20AC99 a quarter. Needle-free at home. A longevity baseline read every 3 months. Cancel anytime.",
  };
}

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 32, filter: "blur(10px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 1, ease: EASE },
  },
};

/* ──────────────────────────────────────────────────────────────────────────
 * Main component
 * ────────────────────────────────────────────────────────────────────────── */
export default function BoldLandingPreview() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const t = getBoldCopy(locale);

  return (
    // overflow-x-clip (not -hidden) is deliberate here. overflow-x:
    // hidden forces overflow-y to auto, which creates an overflow
    // container that clips the hero section's negative margin-top
    // — the hero then can't bleed up past the layout's pt-[100px].
    // overflow-x: clip prevents horizontal scroll (from e.g. the
    // BenefitRuler's translated carousel track) without clipping
    // vertically, so the hero's -mt-[100px] still lets it reach the
    // top of the viewport. Every other section already has its own
    // overflow-hidden where needed.
    <div className={`w-full overflow-x-clip ${BODY}`}>
      <Hero t={t} locale={locale} />
      <BenefitRuler locale={locale} />
      <Shortfall t={t} />
      <BiomarkerPlates t={t} locale={locale} />
      <StickyMethod t={t} locale={locale} />
      <SpecimenPoster t={t} locale={locale} />
      <FounderCinematic t={t} />
      <FinalCall t={t} locale={locale} />
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * MaskedWords — per-word mask reveal for editorial headlines. Each
 * word sits inside an inline-block clip mask and translates up from
 * 110% y to 0 with a per-word stagger. Reduced motion gives the
 * finished state without animation. Used for the hero headline.
 * ────────────────────────────────────────────────────────────────────────── */
function MaskedWords({
  text,
  startDelay = 0,
  italicClassName,
}: {
  text: string;
  startDelay?: number;
  italicClassName?: string;
}) {
  const reduced = useReducedMotion();
  const words = text.split(" ");
  return (
    <span className={italicClassName}>
      {words.map((word, i) => (
        <span
          key={i}
          className="relative inline-block overflow-hidden pb-[0.08em] align-top leading-[inherit]"
        >
          <motion.span
            className="inline-block"
            initial={reduced ? { y: 0, opacity: 1 } : { y: "115%", opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{
              duration: 1.05,
              delay: startDelay + i * 0.06,
              ease: EASE,
            }}
          >
            {word}
            {i < words.length - 1 && "\u00A0"}
          </motion.span>
        </span>
      ))}
    </span>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * Hero — full-viewport shader specimen with typography overlay.
 * The canvas sits absolutely behind the text. Scroll-linked scale +
 * opacity on the specimen so it melts into the marquee below.
 * ────────────────────────────────────────────────────────────────────────── */
function Hero({
  t,
  locale,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
  locale: string;
}) {
  // Hero subhead — "editorial italic lede" treatment. The whole
  // first sentence (the 95% claim) is lifted into a Sentient
  // medium italic paragraph in ink colour, and the second
  // sentence drops into standard Manrope body copy underneath.
  // No terra in the reading area (the chapter marker above
  // already carries the accent colour, so repeating it on the
  // stat line creates colour collision — especially on mobile
  // where the reader is closer to the glyphs). The italic lede
  // hits hard via typeface + style + size, not colour.
  //
  // Classic magazine move: opening claim in italic serif, body
  // explanation in roman sans — late NYT Magazine leads, Aesop
  // product descriptions, Bloomberg Work Shift layouts all use
  // this exact pattern.
  //
  // Inlined via locale ternary (same pattern SpecimenPoster's
  // labels and the Quarterly Ledger's loopCap use).
  const sub =
    locale === "es"
      ? {
          lede: "El 95% de los resultados «normales» esconden una deficiencia.",
          body: "Los encontramos cada 3 meses, en casa: contra rangos de longevidad, no contra promedios enfermos.",
        }
      : {
          lede: "95% of \u201cnormal\u201d lab results hide a deficiency.",
          body: "We find them every 3 months, at home: scored against longevity ranges, not sick averages.",
        };

  // The hero used to bind a scroll-linked scale (1 → 0.86) and
  // opacity (1 → 0.2) to the shader canvas wrapper via
  // useScroll + useTransform. Driving an R3F canvas + a CSS
  // filter(blur) with continuous scroll-tied style updates made
  // scrolling visibly janky on lower-powered devices because
  // every scroll event triggered a re-layout/re-composite of a
  // GPU-backed layer. Removed in favour of letting the specimen
  // move on its own via its in-canvas physics (simplex-noise
  // displacement, breathing, cursor parallax) while scroll
  // position no longer touches the scene at all.
  return (
    <section
      // -mt-[100px] cancels the marketing layout's pt-[100px] so
      // the hero section bleeds up to the top of the viewport.
      // Without this, the layout's top clearance (which sub-pages
      // rely on) leaves a flat cream "banner" strip above the
      // hero's shader + ambient wash. The overlay's pt-36 md:pt-40
      // below restores the original vertical position of the
      // chapter marker so the visual composition is unchanged.
      className="relative -mt-[100px] min-h-[100dvh] w-full overflow-hidden bg-[#fef8f2]"
    >
      {/* Ambient radial wash so the shader reads as painted, not stuck on */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 42%, rgba(188,236,225,0.4), transparent 55%), radial-gradient(circle at 82% 18%, rgba(217,123,92,0.22), transparent 52%), radial-gradient(circle at 12% 90%, rgba(196,147,50,0.16), transparent 55%)",
        }}
      />

      {/* Shader canvas — absolute behind text, clipped to hero.
          A 0.5px blur softens the specimen so it doesn't compete
          with the headline typography, but the container renders
          at full opacity so the sphere reads as vivid as the
          ambient wash behind it.
           - Mobile: canvas fills the entire hero (w-full h-full).
             The scene reads `size` from useThree and scales the
             specimen group down so the sphere fits with margin.
           - md+: original aspect-square framing so the desktop hero
             still has the full circular composition.
          Plain div (not motion.div) — all the specimen's motion
          now lives inside the shader (simplex-noise displacement,
          breath, cursor parallax). Nothing here reacts to scroll.
          Note on opacity: the previous revision had a Tailwind
          opacity-[0.72] class here that was being silently
          overridden by an inline opacity:1 motion value at
          scroll=0. Removing the scroll bindings exposed the 0.72
          cap and the specimen started rendering dimmer. Dropped
          the class entirely so the full-opacity behaviour that
          was actually being displayed before is preserved. */}
      <div
        style={{ filter: "blur(0.5px)" }}
        className="pointer-events-none absolute inset-0 flex items-center justify-center"
      >
        <div className="h-full w-full md:aspect-square md:h-[105%] md:max-h-[110vh] md:w-auto">
          <HeroSpecimenScene />
        </div>
      </div>

      {/* Bottom fade — guarantees the deck + CTAs area is always
          sitting on a cream background regardless of where the
          shader colour happens to be. This is the contrast fix. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 h-[45%] md:h-[38%]"
        style={{
          background:
            "linear-gradient(to bottom, rgba(254,248,242,0) 0%, rgba(254,248,242,0.5) 30%, rgba(254,248,242,0.88) 70%, rgba(254,248,242,0.98) 100%)",
        }}
      />

      {/* The masthead nameplate row that used to live here ("EVA HEALTH
          · DISPATCH · ISSUE 01 · TODAY") has been removed: the new
          MarketingNav already carries the EVA Health logo, and showing
          the brand twice in vertical succession was duplication.
          Hero now opens directly with the chapter marker. */}

      {/* Typography overlay. pt-36 md:pt-40 pushes the chapter
          marker below the floating nav pill (which at top-of-page
          is rendered as a two-row banner ~90px tall anchored at
          top-4/top-5). Combined with the section's -mt-[100px],
          this reproduces the original visual position of the
          chapter marker (~144–160px from the top of the viewport)
          while letting the hero's shader + ambient wash fill the
          entire top strip. */}
      <div className="relative mx-auto flex min-h-[100dvh] max-w-[1480px] flex-col justify-between px-6 pb-14 pt-36 md:px-12 md:pb-20 md:pt-40">
        <motion.div
          initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ duration: 0.9, ease: EASE }}
        >
          <p
            className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
          >
            {t.chapter01}
          </p>
          <p
            className={`${BODY} mt-3 text-[12px] uppercase tracking-[1.4px] text-[#8a7f76] md:text-[13px]`}
          >
            {t.eyebrow}
          </p>
        </motion.div>

        {/* Word-by-word mask reveal — the one signature motion moment
            of the hero. Each word slides up from behind a clip mask
            with a 60ms stagger so the headline assembles like type
            being set, not a single blur-up. Reduced motion users get
            the finished state without animation. */}
        <h1
          className={`${DISPLAY} my-auto max-w-[14ch] text-[60px] font-medium leading-[0.9] tracking-[-1.2px] text-[#1d1b18] md:text-[148px] md:tracking-[-5px] lg:text-[192px] lg:tracking-[-7px]`}
          style={{ textWrap: "balance" } as CSSProperties}
        >
          <MaskedWords text={t.heroLine1} startDelay={0.25} />
          <br />
          <MaskedWords
            text={t.heroLine2}
            startDelay={0.25 + t.heroLine1.split(" ").length * 0.06}
            italicClassName="italic text-[#3a665e]"
          />
        </h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.35, ease: EASE }}
          className="grid grid-cols-12 gap-6 md:gap-10"
        >
          <div className="col-span-12 md:col-span-7 md:col-start-6">
            {/* Editorial italic lede — Sentient medium italic,
                ink (not terra — avoids mobile colour collision
                with the chapter marker above). Max-w-[40ch]
                keeps it 2–3 lines on mobile so it reads as a
                quoted claim. Tighter leading (1.3) than body
                because italic display glyphs need less breathing
                room between lines. */}
            <p
              className={`${DISPLAY} max-w-[40ch] text-[22px] font-medium italic leading-[1.3] text-[#1d1b18] md:text-[28px] md:leading-[1.28] lg:text-[32px] lg:leading-[1.25]`}
              style={{ textWrap: "balance" } as CSSProperties}
            >
              {sub.lede}
            </p>
            {/* Body continuation — Manrope muted, shorter than
                before because it no longer carries the stat.
                `mt-4 md:mt-5` creates a clean break between the
                italic lede and the body explanation without
                feeling like two unrelated blocks. */}
            <p
              className={`${BODY} mt-4 max-w-[52ch] text-[16px] font-medium leading-[1.7] text-[#4c463f] md:mt-5 md:text-[17px] md:leading-[1.75]`}
              style={{ textWrap: "pretty" } as CSSProperties}
            >
              {sub.body}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3 md:mt-10">
              <Link
                href={`/${locale}/signup`}
                className={`${BODY} group inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-7 py-4 text-[13px] font-bold uppercase tracking-[1.4px] text-[#fef8f2] transition-[transform,box-shadow] duration-300 hover:-translate-y-[1px] active:scale-[0.97]`}
                style={{
                  boxShadow:
                    "0 1px 0 rgba(255,255,255,0.15) inset, 0 30px 60px -22px rgba(29,27,24,0.45)",
                }}
              >
                <span>{t.heroCta}</span>
                <Arrow />
              </Link>
              <Link
                href={`/${locale}/upload`}
                className={`${BODY} group inline-flex items-center gap-3 rounded-full border border-[#1d1b18]/20 bg-white/60 px-7 py-4 text-[13px] font-bold uppercase tracking-[1.4px] text-[#1d1b18] backdrop-blur-md transition-[transform,background,border-color] duration-300 hover:-translate-y-[1px] hover:border-[#1d1b18]/40 hover:bg-white active:scale-[0.97]`}
              >
                <span>{t.heroCtaSecondary}</span>
              </Link>
            </div>
            <p
              className={`${MONO} mt-6 text-[10px] font-semibold uppercase tracking-[1.4px] text-[#6f6557]`}
            >
              {t.heroHelper}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Arrow() {
  return (
    <svg
      className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14M13 5l7 7-7 7" />
    </svg>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * BenefitRuler — the stat banner directly under the hero.
 *
 * Replaces the old `StatMarquee`, a CSS-transform marquee that scrolled
 * the same four claims past on an infinite 42s loop. The claims are
 * unchanged; the presentation is now a RulerCarousel, which frames one
 * claim at a time between two ruler rails with the active label locked
 * to the rails' long centre tick.
 *
 * Why the swap reads better here: a perpetually-sliding banner asks the
 * reader to catch copy in motion, which fights the "serious publication"
 * register the rest of the page sets. The ruler holds each claim still
 * long enough to be read, and the measurement metaphor — ticks, a centre
 * mark, a stepped readout — is the same instrument language the
 * biomarker plates and the range bars already speak.
 *
 * The band opens on the eva wordmark. When it scrolls into frame the
 * ruler sweeps once through all four claims and lands back on the
 * wordmark, then hands the track to the reader — so a passive visitor
 * still sees every claim, and the resting state is the brand rather than
 * whichever claim the sweep happened to stop on. The sweep pauses on
 * hover and focus, is cancelled outright the moment the reader touches
 * the controls, and never runs under prefers-reduced-motion.
 * ────────────────────────────────────────────────────────────────────────── */
function BenefitRuler({ locale }: { locale: string }) {
  // Four anchor claims: price, collection method, cadence on the base
  // panel, and the 165+ full panel as the deeper complement. The third
  // item used to say "the right 15 markers" — we've retired that frame
  // because it implied other markers were wrong. The new frame is
  // cadence: 15 foundational longevity markers, read four times a year,
  // is what turns a number into a trendline. The 165+ panel is
  // available on demand via clinical blood draw for customers who want
  // the full picture in one sitting.
  // The wordmark rests at the ruler's zero position: it's what the
  // reader meets first, and what the sweep returns to. It carries the
  // nav's logo face (Bricolage Grotesque, light, lowercase) instead of
  // Sentient so it reads as the mark rather than as a fifth claim.
  const brand: CarouselItem = {
    id: 0,
    title: "eva health",
    className:
      "font-[family-name:var(--font-logo)] font-light lowercase tracking-[-1px] md:tracking-[-2.5px]",
  };

  const items: CarouselItem[] =
    locale === "es"
      ? [
          brand,
          { id: 1, title: "€99 al trimestre" },
          { id: 2, title: "Sin aguja en casa" },
          { id: 3, title: "13 pruebas, 4× al año" },
          { id: 4, title: "165+ disponibles en panel completo" },
        ]
      : [
          brand,
          { id: 1, title: "€99 per quarter" },
          { id: 2, title: "Needle-free at home" },
          { id: 3, title: "13 tests, 4× a year" },
          { id: 4, title: "165+ available as full panel" },
        ];

  // No border-y on the section on purpose: the two ruler rails are the
  // band's edges. A hairline above and below them reads as a second,
  // competing set of rules.
  return (
    <section className="relative overflow-hidden bg-[#fef8f2] py-8 md:py-12">
      <RulerCarousel
        originalItems={items}
        // 950ms a step: the spring settles in roughly 400ms, leaving
        // each claim still for about half a second before the track
        // moves on. Five steps, so the whole sweep runs just under 5s
        // and finishes back on the wordmark.
        introHoldMs={950}
        // Sentient at the marquee's old display sizes. The carousel
        // scales the whole track down when the longest claim can't fit
        // the viewport, so these are ceilings rather than fixed sizes.
        itemClassName={`${DISPLAY} text-[36px] font-medium tracking-[-0.5px] md:text-[64px] md:tracking-[-1.5px]`}
        counterClassName={`${MONO} tracking-[1.4px]`}
        labels={
          locale === "es"
            ? {
                region: "Lo que incluye Eva",
                previous: "Anterior",
                next: "Siguiente",
              }
            : {
                region: "What Eva includes",
                previous: "Previous",
                next: "Next",
              }
        }
      />
    </section>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * Shortfall — the lede, but bigger and more dramatic than the
 * editorial version. Huge heading crashes in from the left, the
 * body column shifts off-centre, and the stat pull-quote uses a
 * 240px numeral as a structural element rather than a footnote.
 * ────────────────────────────────────────────────────────────────────────── */
function Shortfall({
  t,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
}) {
  return (
    <SectionShell tone="cream-alt" size="xlarge" overflow="visible">
      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-15%" }}
      >
        <ChapterMarker>{t.chapter02}</ChapterMarker>
      </motion.div>

      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-15%" }}
        className="mt-6 md:mt-10"
      >
        <SectionHeadline scale="monumental">{t.ledeTitle}</SectionHeadline>
      </motion.div>

        {/* ─── Desktop body + inline stat ──────────────────────────
            On md+ the big €1.1T pull-quote moves up into the empty
            left columns next to the body copy so Chapter 2's lower
            half doesn't feel sparse. `md:items-end` lands the huge
            numeral at the baseline of the body column, catching the
            reader after they finish the paragraph.
            The 95% statistic (t.stat1Label) was promoted into the
            hero subhead, so this monumental pull-quote carries the
            WHO 2024 figure on the global cost of preventable chronic
            disease — same rhetorical job (quantify what "normal" is
            missing), different angle. */}
        <div className="mt-16 grid grid-cols-12 gap-6 md:mt-24 md:items-end md:gap-12">
          {/* Desktop-only: the €1.1T stat drops into the left 5
              columns. Hidden on mobile; mobile gets its own block
              below with the original border-top separator. */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-10%" }}
            className="hidden md:col-span-5 md:block"
          >
            <p
              className={`${DISPLAY} font-medium leading-[0.82] text-[#97472c] md:text-[140px] md:tracking-[-5px] lg:text-[200px] lg:tracking-[-7px] xl:text-[240px] xl:tracking-[-9px]`}
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              <span className="align-top text-[#8a7f76] md:text-[44px] lg:text-[60px] xl:text-[68px]">
                €
              </span>
              1.1
              <span className="align-top text-[#8a7f76] md:text-[44px] lg:text-[60px] xl:text-[68px]">
                T
              </span>
            </p>
            <p
              className={`${BODY} mt-6 max-w-[30ch] text-[15px] leading-[1.6] text-[#4c463f] lg:text-[16px] xl:text-[18px] xl:leading-[1.65]`}
              style={{ textWrap: "pretty" } as CSSProperties}
            >
              {t.stat2Label}
            </p>
            <p
              className={`${MONO} mt-3 text-[9px] font-semibold uppercase tracking-[1.4px] text-[#8a7f76]`}
            >
              {t.stat2Source}
            </p>
          </motion.div>

          {/* Body copy — full-width on mobile, right 7 cols on
              desktop. Unchanged layout math so the body column still
              starts exactly where the heading's right edge lands. */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-10%" }}
            className="col-span-12 md:col-span-7"
          >
            <div
              className={`${BODY} max-w-[62ch] space-y-5 text-[17px] leading-[1.75] text-[#1d1b18] md:text-[19px] md:leading-[1.8]`}
              style={{ textWrap: "pretty" } as CSSProperties}
            >
              <p
                className="first-letter:float-left first-letter:mr-3 first-letter:mt-[8px] first-letter:font-[family-name:var(--font-sentient)] first-letter:text-[96px] first-letter:font-medium first-letter:leading-[0.8] first-letter:text-[#97472c] md:first-letter:text-[124px]"
              >
                {t.ledeBody1}
              </p>
              <p>{t.ledeBody2}</p>
              <p
                className={`${DISPLAY} text-[26px] font-medium italic leading-[1.4] text-[#1d1b18] md:text-[36px]`}
              >
                {t.ledeBody3}
              </p>
            </div>
          </motion.div>
        </div>

        {/* ─── Mobile-only stat block ──────────────────────────────
            Preserved exactly as it was: structural €1.1T stat with
            a border-top separator, stacked below the body column.
            Hidden on md+ because the desktop layout above already
            carries the stat inline with the body. */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-10%" }}
          className="mt-20 grid grid-cols-12 items-end gap-6 border-t border-[#1d1b18]/15 pt-12 md:hidden"
        >
          <div className="col-span-12">
            <p
              className={`${DISPLAY} text-[130px] font-medium leading-[0.8] tracking-[-3px] text-[#97472c]`}
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              <span className="align-top text-[40px] text-[#8a7f76]">€</span>
              1.1
              <span className="align-top text-[40px] text-[#8a7f76]">T</span>
            </p>
          </div>
          <div className="col-span-12 mt-4">
            <p
              className={`${BODY} text-[16px] leading-[1.65] text-[#4c463f]`}
              style={{ textWrap: "pretty" } as CSSProperties}
            >
              {t.stat2Label}
            </p>
            <p
              className={`${MONO} mt-4 text-[9px] font-semibold uppercase tracking-[1.4px] text-[#8a7f76]`}
            >
              {t.stat2Source}
            </p>
          </div>
        </motion.div>
    </SectionShell>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * BiomarkerPlates — horizontally-scrolling rail of specimen plates.
 * On desktop the rail is tall and snap-scrolls with the trackpad; on
 * mobile it's a touch-scrollable strip. Each plate is a dark-ground
 * composition with its own range bar, pull quote, and plate number.
 * ────────────────────────────────────────────────────────────────────────── */
type Plate = {
  n: string;
  name: string;
  unit: string;
  value: number;
  standardLow: number;
  standardHigh: number;
  optimalLow: number;
  optimalHigh: number;
  standardVerdict: string;
  optimalVerdict: string;
  quote: string;
};

function BiomarkerPlates({
  t,
  locale,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
  locale: string;
}) {
  const plates: Plate[] = [
    {
      n: "P-001",
      name: "Vitamin D (25-OH)",
      unit: "ng/mL",
      value: 28,
      standardLow: 20,
      standardHigh: 100,
      optimalLow: 50,
      optimalHigh: 80,
      standardVerdict: "Normal",
      optimalVerdict: t.diffVitD,
      quote: "Your lab called this \u201cfine.\u201d",
    },
    {
      n: "P-002",
      name: "hs-CRP",
      unit: "mg/L",
      value: 2.1,
      standardLow: 0,
      standardHigh: 3.0,
      optimalLow: 0,
      optimalHigh: 1.0,
      standardVerdict: "Normal",
      optimalVerdict: t.diffCRP,
      quote: "Inflammation hiding in \u201cnormal.\u201d",
    },
    {
      n: "P-003",
      name: "Fasting Insulin",
      unit: "µIU/mL",
      value: 11,
      standardLow: 2,
      standardHigh: 19,
      optimalLow: 2,
      optimalHigh: 5,
      standardVerdict: "Normal",
      optimalVerdict: t.diffVitD,
      quote: "Early whisper of metabolic drift.",
    },
    {
      n: "P-004",
      name: "ApoB",
      unit: "mg/dL",
      value: 98,
      standardLow: 0,
      standardHigh: 130,
      optimalLow: 0,
      optimalHigh: 60,
      standardVerdict: "Normal",
      optimalVerdict: t.diffCRP,
      quote: "Risk your old labs never read.",
    },
    {
      n: "P-005",
      name: "Ferritin",
      unit: "ng/mL",
      value: 320,
      standardLow: 30,
      standardHigh: 400,
      optimalLow: 50,
      optimalHigh: 150,
      standardVerdict: "Normal",
      optimalVerdict: t.diffVitD,
      quote: "Iron rising. A warning in small print.",
    },
  ];

  return (
    <section className="relative overflow-hidden bg-[#1d1b18] py-24 text-[#fef8f2] md:py-36">
      {/* Warm ambient wash */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 78% 22%, rgba(217,123,92,0.22), transparent 55%), radial-gradient(circle at 18% 82%, rgba(58,102,94,0.18), transparent 58%)",
        }}
      />

      <div className="relative mx-auto max-w-[1480px] px-6 md:px-12">
        <motion.p
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-15%" }}
          className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#d97b5c]`}
        >
          {t.chapter03}
        </motion.p>
        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-15%" }}
          className={`${DISPLAY} mt-6 max-w-[18ch] text-[52px] font-medium leading-[0.92] tracking-[-1px] md:mt-10 md:text-[140px] md:tracking-[-4.5px]`}
          style={{ textWrap: "balance" } as CSSProperties}
        >
          {t.reckoningTitle}
        </motion.h2>
        <motion.p
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-10%" }}
          className={`${BODY} mt-8 max-w-[52ch] text-[16px] leading-[1.7] text-[#fef8f2]/65 md:text-[18px]`}
        >
          {t.reckoningSubtitle}
        </motion.p>
      </div>

      {/* Horizontal scroll rail.
          A11Y-011: this is a keyboard-operable scroll container, so it
          carries role="region" + a localized aria-label and is exposed
          in the tab order (tabIndex=0) — keyboard users can focus the
          rail and pan it with the arrow keys, matching the pointer
          drag-to-scroll affordance. */}
      <div
        role="region"
        tabIndex={0}
        aria-label={
          locale === "es" ? "Galería de biomarcadores" : "Biomarker gallery"
        }
        className="relative mt-12 flex gap-6 overflow-x-auto px-6 pb-10 md:mt-20 md:gap-10 md:px-12"
        style={
          {
            scrollSnapType: "x mandatory",
            scrollPaddingInline: "1.5rem",
            scrollbarWidth: "thin",
            scrollbarColor: "rgba(254,248,242,0.18) transparent",
            WebkitOverflowScrolling: "touch",
          } as CSSProperties
        }
      >
        {plates.map((p, i) => (
          <motion.article
            key={p.n}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-5%" }}
            transition={{ duration: 0.9, delay: i * 0.06, ease: EASE }}
            className="shrink-0 snap-start"
            style={{ width: "min(86vw, 560px)" }}
          >
            <div className="flex items-start justify-between">
              <span
                className={`${MONO} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#fef8f2]/45`}
                style={{ fontVariantNumeric: "tabular-nums" }}
              >
                {p.n}
              </span>
              <span
                className={`${MONO} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#d97b5c]`}
              >
                Specimen
              </span>
            </div>
            <h3
              className={`${DISPLAY} mt-5 text-[40px] font-medium leading-[1] tracking-[-0.5px] md:text-[56px] md:tracking-[-1.5px]`}
              style={{ textWrap: "balance" } as CSSProperties}
            >
              {p.name}
            </h3>
            <div className="mt-8">
              <RangeComparisonBar
                biomarkerName={p.name}
                value={p.value}
                unit={p.unit}
                standardRange={{ low: p.standardLow, high: p.standardHigh }}
                optimalRange={{ low: p.optimalLow, high: p.optimalHigh }}
                standardVerdict={p.standardVerdict}
                optimalVerdict={p.optimalVerdict}
              />
            </div>
            <p
              className={`${DISPLAY} mt-8 text-[22px] font-medium italic leading-[1.35] text-[#fef8f2]/80 md:text-[26px]`}
              style={{ textWrap: "balance" } as CSSProperties}
            >
              <span className="text-[#d97b5c]">&ldquo;</span>
              {p.quote}
              <span className="text-[#d97b5c]">&rdquo;</span>
            </p>
          </motion.article>
        ))}
      </div>

      <div className="mx-auto mt-4 flex max-w-[1480px] items-center gap-3 px-6 md:px-12">
        <span
          aria-hidden
          className={`${MONO} text-[9px] font-semibold uppercase tracking-[1.6px] text-[#fef8f2]/45`}
        >
          {locale === "es" ? "← Desliza para ver más →" : "← Drag to scroll →"}
        </span>
      </div>
    </section>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * StickyMethod — § 04 "The Quarterly Ledger".
 *
 * Rebuilt as a two-column ledger (step number | title + body) with a
 * fifth "loop cap" row that makes the quarterly cycle explicit:
 * `↻ · Every 90 days. Again.` A scroll-linked terra progress spine
 * on the far left fills as the reader descends through the ledger,
 * so the visual embodies the "walk through the protocol" motion.
 *
 * Why not the previous sticky-left/scrolling-right layout:
 *  - The old layout had no visual representation of the cycle — the
 *    whole section is called "Four steps. Every 3 months." but
 *    "every 3 months" was nowhere in the composition.
 *  - Uniform 200px step numbers read as decoration; the reader
 *    couldn't feel the structure.
 *  - Sticky left column was inert parallax with no payoff.
 *
 * The ledger format reads as a protocol / museum schedule instead
 * of a FAQ list, which matches the page's "Ageing moves in
 * trendlines, not snapshots" positioning: the method is a ritual,
 * not a funnel.
 *
 * On mobile the left column shrinks (64px vs 140px) and vertical
 * padding relaxes, but the structure is otherwise identical — no
 * separate mobile layout to maintain.
 * ────────────────────────────────────────────────────────────────────────── */
function StickyMethod({
  t,
  locale,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
  locale: string;
}) {
  // A11Y-004: respect the reduced-motion preference for the loop-cap
  // arrow below, which otherwise spins perpetually (repeat: Infinity).
  const reduced = useReducedMotion();
  const ledgerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ledgerRef,
    offset: ["start 75%", "end 25%"],
  });
  // Clamp to [0,1] and drive the progress spine's scaleY directly
  // from scroll position so the terra line fills as the reader
  // descends through the ledger rows.
  const spineProgress = useTransform(scrollYProgress, [0, 1], [0, 1]);

  const steps = [
    { n: 1, title: t.step1Title, body: t.step1Desc },
    { n: 2, title: t.step2Title, body: t.step2Desc },
    { n: 3, title: t.step3Title, body: t.step3Desc },
    { n: 4, title: t.step4Title, body: t.step4Desc },
  ];
  // The loop cap sits outside the shared translation file since
  // it's tied to this specific composition. Same locale-inline
  // pattern the SpecimenPoster (§ 05) uses.
  const loopCap =
    locale === "es" ? "Cada 90 días. Otra vez." : "Every 90 days. Again.";

  return (
    <SectionShell tone="cream" size="standard" overflow="visible">
        {/* ─── Header block ────────────────────────────────────────
            Chapter marker + monumental heading + subtitle. No
            sticky — the reader sees it once at the top and then
            descends through the ledger below. */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-15%" }}
        >
          <ChapterMarker>{t.chapter04}</ChapterMarker>
          <SectionHeadline
            scale="standard"
            maxCh={14}
            className="mt-6 md:mt-10"
          >
            {t.processTitle}
          </SectionHeadline>
          <p
            className={`${BODY} mt-6 max-w-[42ch] text-[16px] leading-[1.7] text-[#4c463f] md:mt-10 md:text-[18px]`}
          >
            {t.processSubtitle}
          </p>
        </motion.div>

        {/* ─── Ledger block ────────────────────────────────────────
            Two-column table: [step marker] [title + body]. A
            hairline terra spine runs down the far left of the
            ledger; a second terra line sits on top of it and scales
            its scaleY from scroll progress so it fills as the
            reader descends. */}
        <div
          ref={ledgerRef}
          className="relative mt-20 md:mt-32"
        >
          {/* Spine — static track */}
          <div
            aria-hidden
            className="pointer-events-none absolute left-0 top-0 bottom-0 w-px bg-[#1d1b18]/12"
          />
          {/* Spine — scroll-linked terra fill */}
          <motion.div
            aria-hidden
            style={{ scaleY: spineProgress }}
            className="pointer-events-none absolute left-0 top-0 bottom-0 w-px origin-top bg-[#97472c]"
          />

          <div className="divide-y divide-[#1d1b18]/12 border-y border-[#1d1b18]/12">
            {steps.map((s, i) => (
              <motion.div
                key={s.n}
                initial={{ opacity: 0, x: 24, filter: "blur(8px)" }}
                whileInView={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                viewport={{ once: true, margin: "-15%" }}
                transition={{ duration: 0.9, delay: i * 0.06, ease: EASE }}
                className="flex items-baseline gap-6 py-10 pl-6 md:gap-12 md:py-16 md:pl-12 lg:gap-20 lg:pl-16"
              >
                {/* Step number — the left column marker. Fixed width
                    so all four numbers share a vertical axis. */}
                <span
                  className={`${DISPLAY} w-[64px] shrink-0 text-[56px] font-medium leading-[0.82] text-[#1d1b18] md:w-[140px] md:text-[120px] lg:text-[140px]`}
                  style={{ fontVariantNumeric: "tabular-nums" }}
                  aria-hidden
                >
                  {String(s.n).padStart(2, "0")}
                </span>

                {/* Content — title + body in the right column */}
                <div className="min-w-0 flex-1">
                  <SubHeadline>{s.title}</SubHeadline>
                  <p
                    className={`${BODY} mt-4 max-w-[56ch] text-[16px] leading-[1.7] text-[#4c463f] md:mt-5 md:text-[18px] md:leading-[1.75]`}
                    style={{ textWrap: "pretty" } as CSSProperties}
                  >
                    {s.body}
                  </p>
                </div>

                {/* Screen-reader label so the step number still
                    reads as "Step N" to assistive tech even though
                    visually it's just the numeral. */}
                <span className="sr-only">
                  {locale === "es" ? `Paso ${s.n}` : `Step ${s.n}`}
                </span>
              </motion.div>
            ))}

            {/* ─── Loop cap row ────────────────────────────────────
                The fifth row makes the quarterly cycle explicit.
                The circular arrow rotates continuously (8s linear)
                so the cycle reads as perpetual motion rather than a
                static icon. Terra color lines it up with the spine. */}
            <motion.div
              initial={{ opacity: 0, x: 24, filter: "blur(8px)" }}
              whileInView={{
                opacity: 1,
                x: 0,
                filter: "blur(0px)",
              }}
              viewport={{ once: true, margin: "-15%" }}
              transition={{ duration: 0.9, delay: 0.28, ease: EASE }}
              className="flex items-center gap-6 py-10 pl-6 md:gap-12 md:py-16 md:pl-12 lg:gap-20 lg:pl-16"
            >
              <span className="flex w-[64px] shrink-0 justify-start md:w-[140px]">
                <motion.svg
                  width="48"
                  height="48"
                  viewBox="0 0 48 48"
                  fill="none"
                  className="md:h-[88px] md:w-[88px] lg:h-[104px] lg:w-[104px]"
                  // A11Y-004: under reduced motion, render the static
                  // icon (no rotation, no infinite repeat) so the arrow
                  // doesn't spin perpetually; otherwise loop the orbit.
                  animate={reduced ? undefined : { rotate: 360 }}
                  transition={
                    reduced
                      ? undefined
                      : {
                          duration: 14,
                          repeat: Infinity,
                          ease: "linear",
                        }
                  }
                  aria-hidden
                >
                  {/* Open circular arrow — broken near the top so
                      the rotation reads as an orbit rather than a
                      solid ring. Two short arrowheads anchor the
                      direction of travel. */}
                  <path
                    d="M24 6 A18 18 0 1 1 5.64 26.4"
                    stroke="#97472c"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  <path
                    d="M19 3 L24 6 L21 11"
                    stroke="#97472c"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </motion.svg>
              </span>

              <p
                className={`${DISPLAY} text-[24px] font-medium italic leading-[1.15] text-[#97472c] md:text-[48px] md:tracking-[-1px] lg:text-[60px] lg:tracking-[-1.6px]`}
                style={{ textWrap: "balance" } as CSSProperties}
              >
                {loopCap}
              </p>
            </motion.div>
          </div>
        </div>
    </SectionShell>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * SpecimenPoster — the bio-age orb presented as a full-bleed museum
 * poster with a museum plate underneath. Monumental serif numeral
 * for the age delta.
 * ────────────────────────────────────────────────────────────────────────── */
/* ──────────────────────────────────────────────────────────────────────────
 * SpecimenPoster — § 05 The reveal.
 *
 * The emotional climax of the page. Visitors leave this section
 * thinking "I want to know my number." Three design moves push that:
 *
 *  1. The headline is a direct conversational question
 *     ("How old are you, really?") — not a feature description.
 *     Centred, deliberately breaking the asymmetric pattern of the
 *     rest of the page so this reads as the climactic moment.
 *
 *  2. The triptych reveal: 34 / orb / −5. Three numbers side-by-side,
 *     each at display scale, each labelled. The reader's eye does
 *     the narrative arc on its own — ID age → body age → the gap.
 *     No museum prose needed. The gallery caption ("Specimen A-001
 *     ...") is gone; the comparison itself does the storytelling.
 *
 *  3. Agency in the body copy: "Eva measures it every quarter — and
 *     watches it move as you change." The bio-age number isn't fixed.
 *     That's the magic.
 *
 * On mobile the triptych stacks (chrono → orb → delta) and the
 * orb is hero-sized. Same emotional arc, scrollable.
 * ────────────────────────────────────────────────────────────────────────── */
function SpecimenPoster({
  t,
  locale,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
  locale: string;
}) {
  // Small mono labels for the triptych + the interactive orb. Inlined
  // here instead of added to the shared marketing-translations file
  // because they're bold-page-only and tied to this specific
  // composition.
  const labels =
    locale === "es"
      ? {
          onYourId: "En tu carnet",
          yearsYounger: "Años más joven",
          bioAge: "Edad biológica",
          tapHint: "Pasa o toca cualquier marcador para ver los detalles",
          titleMain: "¿Cuántos años tienes,",
          titleEmph: "en realidad?",
        }
      : {
          onYourId: "On your ID",
          yearsYounger: "Years younger",
          bioAge: "Biological age",
          tapHint: "Hover or tap any marker to see its reading",
          titleMain: "How old are you,",
          titleEmph: "really?",
        };

  return (
    <section className="relative overflow-hidden bg-[#f8f3ed] py-24 md:py-36">
      {/* Warm ambient wash — slightly more saturated than the previous
          version so the section feels like the climax it is, with a
          jade pull at top-centre that matches the orb's glow palette. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 28%, rgba(188,236,225,0.55), transparent 55%), radial-gradient(circle at 82% 85%, rgba(217,123,92,0.18), transparent 55%), radial-gradient(circle at 18% 78%, rgba(196,147,50,0.10), transparent 55%)",
        }}
      />

      <div className="relative mx-auto max-w-[1400px] px-5 md:px-12">
        {/* Chapter marker */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-15%" }}
        >
          <ChapterMarker align="center">{t.chapter05}</ChapterMarker>
        </motion.div>

        {/* Centered headline + body — deliberately breaking the
            asymmetric pattern of every other section. This is the
            climactic moment, so the composition centres. */}
        {/* Headline split into two lines:
             · titleMain ("How old are you,") — Sentient medium, ink
             · titleEmph ("really?") — italic Sentient, terra, with
               a hand-drawn underline SVG that draws itself in after
               the word lands.
            Forcing an explicit line break (block on the first span,
            inline-block on the second) keeps the headline at 2 lines
            across every breakpoint instead of letting textWrap
            balance wrap it to one-word-per-line at 148px. */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-10%" }}
          className="mx-auto mt-8 text-center md:mt-12"
        >
          <h2
            className={`${DISPLAY} font-medium leading-[0.92] text-[#1d1b18]`}
          >
            <span className="block text-[44px] tracking-[-0.8px] md:text-[92px] md:tracking-[-3px] lg:text-[112px] lg:tracking-[-4px]">
              {labels.titleMain}
            </span>
            <span className="relative mt-1 inline-block text-[52px] italic tracking-[-0.8px] text-[#97472c] md:mt-2 md:text-[108px] md:tracking-[-3.2px] lg:text-[132px] lg:tracking-[-4.4px]">
              {labels.titleEmph}
              {/* Hand-drawn underline — SVG quadratic curve with a
                  slight wobble so it reads as a pen stroke rather
                  than a ruler line. Animates in with a pathLength
                  reveal after the word itself lands. */}
              <motion.svg
                aria-hidden
                viewBox="0 0 300 14"
                preserveAspectRatio="none"
                className="pointer-events-none absolute -bottom-[6px] left-0 h-[10px] w-full md:-bottom-[10px] md:h-[14px]"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true, margin: "-10%" }}
                transition={{ duration: 0.3, delay: 0.6, ease: EASE }}
              >
                <motion.path
                  d="M4 9 Q 70 2, 150 7 T 296 5"
                  fill="none"
                  stroke="#97472c"
                  strokeWidth="3"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  viewport={{ once: true, margin: "-10%" }}
                  transition={{ duration: 1.1, delay: 0.6, ease: EASE }}
                />
              </motion.svg>
            </span>
          </h2>
        </motion.div>

        <motion.p
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-10%" }}
          className={`${BODY} mx-auto mt-8 max-w-[52ch] text-center text-[16px] font-medium leading-[1.7] text-[#2a2319] md:mt-10 md:text-[19px] md:leading-[1.75]`}
          style={{ textWrap: "pretty" } as CSSProperties}
        >
          {t.specimenBody}
        </motion.p>

        {/* Triptych reveal: chrono / orb / delta.
             - Stacks vertically on < lg so the orb has room to breathe
               on mobile and tablets at hero (320px) size.
             - On lg+ the orb column is twice the width of each flank
               (1fr / 2fr / 1fr) so the constellation reads as the
               dominant element and the two supporting numerals sit
               as editorial annotations rather than competing for
               visual weight. Their typography is lighter too —
               roughly half the previous scale — so the reader's eye
               lands on the bio age first. */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-5%" }}
          className="mt-16 grid grid-cols-1 items-center gap-12 md:mt-24 md:gap-16 lg:grid-cols-[minmax(0,1fr)_minmax(0,2fr)_minmax(0,1fr)] lg:gap-10"
        >
          {/* Chrono — left on lg+, top on mobile */}
          <div className="text-center lg:text-right">
            <p
              className={`${DISPLAY} text-[64px] font-medium leading-[0.9] tracking-[-1.5px] text-[#8a7f76] md:text-[84px] md:tracking-[-2px] lg:text-[96px] lg:tracking-[-2.5px]`}
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              34
            </p>
            <p
              className={`${MONO} mt-2 text-[9px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] md:mt-3 md:text-[10px]`}
            >
              {labels.onYourId}
            </p>
          </div>

          {/* Orb — the same 3D constellation the dashboard ships,
              seeded with mock biomarker data so visitors can actually
              hover / tap the nodes. Centre on lg+, middle on mobile.
              The scene is lazy-loaded via next/dynamic so R3F stays
              out of the hero critical path. */}
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-10%" }}
            transition={{ duration: 1.1, delay: 0.15, ease: EASE }}
            className="flex justify-center"
          >
            <RevealConstellation
              bioAge={29}
              locale={locale}
              labels={{
                bioAge: labels.bioAge,
                tapHint: labels.tapHint,
              }}
            />
          </motion.div>

          {/* Delta — right on lg+, bottom on mobile */}
          <div className="text-center lg:text-left">
            <p
              className={`${DISPLAY} text-[64px] font-medium leading-[0.9] tracking-[-1.5px] text-[#3a665e] md:text-[84px] md:tracking-[-2px] lg:text-[96px] lg:tracking-[-2.5px]`}
              style={{ fontVariantNumeric: "tabular-nums" }}
            >
              −5
            </p>
            <p
              className={`${MONO} mt-2 text-[9px] font-semibold uppercase tracking-[1.6px] text-[#3a665e] md:mt-3 md:text-[10px]`}
            >
              {labels.yearsYounger}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * FounderCinematic — oversized italic pull quote. No portrait, no
 * card. The quote itself is the design.
 * ────────────────────────────────────────────────────────────────────────── */
function FounderCinematic({
  t,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
}) {
  return (
    <section className="relative bg-[#fef8f2] py-24 md:py-40">
      <div className="mx-auto max-w-[1480px] px-6 md:px-12">
        <motion.p
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-15%" }}
          className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
        >
          {t.chapter06}
        </motion.p>
        <motion.blockquote
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-10%" }}
          className={`${DISPLAY} mt-10 max-w-[22ch] text-[40px] font-medium italic leading-[1.2] text-[#1d1b18] md:mt-14 md:text-[96px] md:leading-[1.15] md:tracking-[-2.5px]`}
          style={{ textWrap: "balance" } as CSSProperties}
        >
          <span className="text-[#97472c]">&ldquo;</span>
          {t.founderQuote}
          <span className="text-[#97472c]">&rdquo;</span>
        </motion.blockquote>
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-5%" }}
          className="mt-12 flex flex-wrap items-baseline gap-x-8 gap-y-2 border-t border-[#1d1b18]/15 pt-6 md:mt-16"
        >
          <p
            className={`${DISPLAY} text-[22px] font-medium text-[#1d1b18] md:text-[28px]`}
          >
            {t.founderName}
          </p>
          <p
            className={`${MONO} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]`}
          >
            {t.founderTitle}
          </p>
        </motion.div>
      </div>
    </section>
  );
}
/* ──────────────────────────────────────────────────────────────────────────
 * FinalCall — closing dark band with a 240px headline and two CTAs.
 * Warm ambient glow behind the text. The primary CTA is inverted
 * cream on terra instead of cream on ink, to give the closing
 * chapter its own colour voice.
 * ────────────────────────────────────────────────────────────────────────── */
function FinalCall({
  t,
  locale,
}: {
  t: ReturnType<typeof getMarketingTranslations>;
  locale: string;
}) {
  return (
    <section className="relative overflow-hidden bg-[#1d1b18] py-28 text-[#fef8f2] md:py-48">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 28%, rgba(217,123,92,0.38), transparent 55%), radial-gradient(circle at 80% 80%, rgba(58,102,94,0.28), transparent 55%), radial-gradient(circle at 15% 75%, rgba(196,147,50,0.18), transparent 55%)",
        }}
      />
      <div className="relative mx-auto max-w-[1480px] px-6 md:px-12">
        <motion.p
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-15%" }}
          className={`${MONO} text-[10px] font-semibold uppercase tracking-[2px] text-[#d97b5c]`}
        >
          {t.chapter07}
        </motion.p>

        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-10%" }}
          className={`${DISPLAY} mt-10 max-w-[12ch] text-[72px] font-medium leading-[0.88] tracking-[-1.5px] text-[#fef8f2] md:mt-16 md:text-[208px] md:tracking-[-7px] lg:text-[240px] lg:tracking-[-9px]`}
          style={{ textWrap: "balance" } as CSSProperties}
        >
          {t.callTitle}
        </motion.h2>

        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-5%" }}
          className="mt-12 grid grid-cols-12 gap-6 md:mt-20 md:gap-12"
        >
          <div className="col-span-12 md:col-span-6 md:col-start-7">
            <p
              className={`${BODY} max-w-[48ch] text-[16px] leading-[1.7] text-[#fef8f2]/70 md:text-[18px] md:leading-[1.75]`}
              style={{ textWrap: "pretty" } as CSSProperties}
            >
              {t.callBody}
            </p>
            <div className="mt-10 flex flex-wrap items-center gap-3 md:mt-12">
              <Link
                href={`/${locale}/signup`}
                className={`${BODY} group inline-flex items-center gap-3 rounded-full bg-[#d97b5c] px-7 py-4 text-[13px] font-bold uppercase tracking-[1.4px] text-[#1d1b18] transition-[transform,box-shadow] duration-300 hover:-translate-y-[1px] hover:bg-[#f09572] active:scale-[0.97]`}
                style={{
                  boxShadow:
                    "0 1px 0 rgba(255,255,255,0.4) inset, 0 30px 60px -18px rgba(217,123,92,0.55)",
                }}
              >
                <span>{t.heroCta}</span>
                <Arrow />
              </Link>
              <Link
                href={`/${locale}/upload`}
                className={`${BODY} group inline-flex items-center gap-3 rounded-full border border-[#fef8f2]/25 px-7 py-4 text-[13px] font-bold uppercase tracking-[1.4px] text-[#fef8f2] transition-[transform,background,border-color] duration-300 hover:-translate-y-[1px] hover:border-[#fef8f2]/45 hover:bg-[#fef8f2]/5 active:scale-[0.97]`}
              >
                <span>{t.uploadCta}</span>
              </Link>
            </div>
            <p
              className={`${MONO} mt-6 text-[10px] font-medium uppercase tracking-[1.4px] text-[#fef8f2]/45`}
            >
              {t.heroHelper}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export type { CSSProperties };
