"use client";

/**
 * /science — two-part editorial composition, 8 chapters + 1 interlude.
 *
 * PART I — THE SCIENCE (§ 01–04)
 * § 01     Three questions    (cream     xlarge)   opener
 * § 02     What normal hides  (cream-alt large)    Pillar I — ranges
 * § II½    Mirror & Map       (dark      xlarge)   cinematic interlude
 *                                                  foreshadowing §03 + §04
 * § 03     Biological age     (cream     standard) Pillar II — KDM
 * § 04     Longevity score    (cream-alt large)    Pillar III — score
 *
 * PART II — HOW WE DO IT (§ 05–07)
 * § 05 The data layer     (cream   standard) biomarker map + derived metrics
 * § 06 The signal         (cream-alt large)  wearables
 * § 07 The loop           (cream   standard) quarterly cadence + EVA AI
 *
 * § 08 The invitation     (cream   xlarge)   CTA close
 */

import { useState } from "react";
import { useParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ScrollReveal } from "@/components/marketing/ScrollReveal";
import { CTAButton } from "@/components/marketing/CTAButton";
import { BiologicalAgeOrb } from "@/components/shared/BiologicalAgeOrb";
import { EvaChatDemo } from "@/components/marketing/EvaChatDemo";
import { InteractiveHsCrpFigure } from "@/components/marketing/InteractiveHsCrpFigure";
import { LongevityScoreOrb } from "@/components/marketing/LongevityScoreOrb";
import { MirrorMapInterlude } from "@/components/marketing/MirrorMapInterlude";
import { ScrollProgressBar } from "@/components/marketing/ScrollProgressBar";
import { SeismographStrip, type TraceEntry } from "@/components/marketing/SeismographStrip";
import {
  ChapterMarker,
  SectionHeadline,
  LedeItalic,
  BodyProse,
  SectionShell,
  HandDrawnUnderline,
} from "@/components/marketing/editorial";

/* ─── biomarker categories ─── */
const categories = [
  { id: "cardiovascular", name: "Heart & Cardiovascular", name_es: "Corazón y Cardiovascular", count: 28, base: ["Total Cholesterol", "HDL", "Triglycerides", "ApoB", "hs-CRP"], specialty: ["LDL", "Lp(a)", "sdLDL", "Ox-LDL", "Homocysteine", "Fibrinogen"] },
  { id: "hormones", name: "Hormones", name_es: "Hormonas", count: 18, base: [] as string[], specialty: ["Testosterone", "Cortisol", "DHEA-S", "Estradiol", "Progesterone", "SHBG", "FSH", "LH"] },
  { id: "thyroid", name: "Thyroid", name_es: "Tiroides", count: 12, base: [] as string[], specialty: ["TSH", "Free T3", "Free T4", "Anti-TPO", "Anti-Tg", "Reverse T3"] },
  { id: "nutrients", name: "Nutrient Optimisation", name_es: "Optimización Nutricional", count: 24, base: [] as string[], specialty: ["Ferritin", "Vitamin D", "B12", "Folate", "Zinc", "Magnesium", "Iron", "Selenium", "Copper"] },
  { id: "metabolic", name: "Metabolic Health", name_es: "Salud Metabólica", count: 14, base: ["Fructosamine", "Uric Acid"], specialty: ["Fasting Glucose", "HbA1c", "Fasting Insulin", "C-Peptide"] },
  { id: "liver", name: "Liver & Hepatic", name_es: "Hígado y Hepático", count: 10, base: ["ALT", "GGT", "Albumin", "ALP"], specialty: ["AST", "Bilirubin"] },
  { id: "kidney", name: "Kidney Function", name_es: "Función Renal", count: 8, base: ["Creatinine", "BUN", "Uric Acid"], specialty: ["eGFR", "Cystatin C"] },
  { id: "iron", name: "Iron & Blood", name_es: "Hierro y Sangre", count: 12, base: [] as string[], specialty: ["Ferritin", "CBC", "Serum Iron", "TIBC", "Transferrin Sat.", "Reticulocytes"] },
  { id: "immune", name: "Immune System", name_es: "Sistema Inmune", count: 10, base: ["hs-CRP"], specialty: ["IL-6", "TNF-a", "WBC Differential", "IgA", "IgG"] },
  { id: "inflammation", name: "Inflammation", name_es: "Inflamación", count: 8, base: ["hs-CRP"], specialty: ["Homocysteine", "Fibrinogen", "ESR", "Ferritin (inflammatory)"] },
  { id: "electrolytes", name: "Electrolytes & Minerals", name_es: "Electrolitos y Minerales", count: 7, base: [] as string[], specialty: ["Sodium", "Potassium", "Calcium", "Phosphorus", "Magnesium"] },
  { id: "lipids", name: "Advanced Lipids", name_es: "Lípidos Avanzados", count: 9, base: ["Total Cholesterol", "HDL", "ApoB"], specialty: ["LDL", "ApoA1", "Lp(a)", "sdLDL", "LDL-P"] },
  { id: "bone", name: "Bone Health", name_es: "Salud Ósea", count: 5, base: ["ALP"], specialty: ["Calcium", "Vitamin D", "PTH", "Osteocalcin"] },
  { id: "oxidative", name: "Oxidative Stress", name_es: "Estrés Oxidativo", count: 4, base: [] as string[], specialty: ["Glutathione", "MDA", "8-OHdG", "CoQ10"] },
  { id: "aging", name: "Aging & Longevity", name_es: "Envejecimiento y Longevidad", count: 6, base: [] as string[], specialty: ["IGF-1", "GlycanAge markers", "NAD+", "Telomere length"] },
];

/* ─── derived metrics ─── */
const metrics = [
  { name: "HOMA-IR", what: "Insulin resistance risk", what_es: "Riesgo de resistencia a la insulina", formula: "Fasting Insulin × Fasting Glucose / 405", optimal: "≤ 1.8" },
  { name: "TG/HDL Ratio", what: "Metabolic health proxy", what_es: "Indicador de salud metabólica", formula: "Triglycerides / HDL", optimal: "≤ 1.5" },
  { name: "AST/ALT (De Ritis)", what: "Liver function assessment", what_es: "Evaluación de función hepática", formula: "AST / ALT", optimal: "0.8 – 1.2" },
  { name: "Omega-3 Index", what: "Cardiovascular protection", what_es: "Protección cardiovascular", formula: "EPA + DHA / Total fatty acids", optimal: "≥ 8%" },
  { name: "NLR", what: "Systemic inflammation", what_es: "Inflamación sistémica", formula: "Neutrophils / Lymphocytes", optimal: "0.8 – 2.0" },
  { name: "Free Androgen Index", what: "Hormonal balance", what_es: "Equilibrio hormonal", formula: "Total Testosterone / SHBG × 100", optimal: "Sex-specific" },
  { name: "Non-HDL Cholesterol", what: "Atherogenic particle estimate", what_es: "Estimación de partículas aterogénicas", formula: "Total Cholesterol − HDL", optimal: "≤ 90 mg/dL" },
];

/* ─── biological age — KDM 3-step ledger ─── */
const bioAgeSteps = [
  {
    num: "01",
    name_en: "Measure", name_es: "Medir",
    body_en: "A set of blood markers that change with age across the population. With the EVA Base Panel they cover kidney, liver, lipids and inflammation.",
    body_es: "Un conjunto de marcadores de sangre que cambian con la edad en la población. Con el Panel Base de EVA cubren el riñón, el hígado, los lípidos y la inflamación.",
  },
  {
    num: "02",
    name_en: "Compare", name_es: "Comparar",
    body_en: "Using the Klemera-Doubal method, each of your values is compared with how that marker changes with age across thousands of NHANES adults. Markers that track age most reliably carry the most weight. Noisier ones count for less.",
    body_es: "Con el método Klemera-Doubal, cada uno de tus valores se compara con cómo cambia ese marcador con la edad en miles de adultos de NHANES. Los marcadores más fiables para estimar la edad tienen más peso. Los que varían más cuentan menos.",
  },
  {
    num: "03",
    name_en: "Estimate", name_es: "Estimar",
    body_en: "The method reads your whole biomarker pattern, finds the age it most closely resembles, and blends it with your chronological age. That number is your biological age.",
    body_es: "El método lee tu patrón completo de biomarcadores, encuentra la edad a la que más se parece y la combina con tu edad cronológica. Ese número es tu edad biológica.",
  },
];

/* ─── longevity score 3-step ledger ─── */
const longevitySteps = [
  {
    num: "01",
    name_en: "Your optimal", name_es: "Tu óptimo",
    body_en: "For every biomarker, a target tailored to your sex and age group. Not a population average, but the value linked to the best long-term health outcomes in the research.",
    body_es: "Para cada biomarcador, un objetivo adaptado a tu sexo y grupo de edad. No un promedio poblacional, sino el valor vinculado a los mejores resultados de salud a largo plazo en la investigación.",
  },
  {
    num: "02",
    name_en: "Ranked by evidence", name_es: "Ponderado por evidencia",
    body_en: "Not every biomarker matters equally for longevity. Each is weighted by how strongly it is linked to long-term health. The markers backed by the most research move your score the most.",
    body_es: "No todos los biomarcadores importan igual para la longevidad. Cada uno se pondera según la fuerza de su vínculo con la salud a largo plazo. Los marcadores respaldados por más investigación mueven más tu puntuación.",
  },
  {
    num: "03",
    name_en: "Score + map", name_es: "Puntuación + mapa",
    body_en: "The gaps between your values and your optimal targets become a single score from 0 to 100, plus a clear priority list. What moves your health most, first.",
    body_es: "Las diferencias entre tus valores y tus objetivos óptimos se convierten en una sola puntuación de 0 a 100, más una lista clara de prioridades. Lo que más mueve tu salud, primero.",
  },
];

/* ─── helper: integer → Roman numeral (1–39) ─── */
function toRoman(n: number): string {
  const map: [number, string][] = [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]];
  let result = "";
  let remaining = n;
  for (const [value, glyph] of map) {
    while (remaining >= value) {
      result += glyph;
      remaining -= value;
    }
  }
  return result;
}

/* ─── quarterly loop steps ─── */
const loopSteps = [
  {
    num: "01",
    label_en: "Test",
    label_es: "Analizar",
    desc_en: "A quarterly blood draw captures your current panel: the same markers measured the same way, every three months.",
    desc_es: "Una extracción trimestral captura tu panel actual: los mismos marcadores medidos de la misma forma, cada tres meses.",
  },
  {
    num: "02",
    label_en: "Score",
    label_es: "Puntuar",
    desc_en: "Results are read against age- and sex-matched optimal ranges. Your biological age and longevity score update immediately.",
    desc_es: "Los resultados se comparan con rangos óptimos ajustados a tu edad y sexo. Tu edad biológica y puntuación de longevidad se actualizan al instante.",
  },
  {
    num: "03",
    label_en: "Optimise",
    label_es: "Optimizar",
    desc_en: "EVA surfaces the highest-impact gap and suggests a targeted action. One change at a time, backed by the evidence behind each marker.",
    desc_es: "EVA destaca la brecha de mayor impacto y sugiere una acción dirigida. Un cambio a la vez, respaldado por la evidencia detrás de cada marcador.",
  },
  {
    num: "04",
    label_en: "Retest",
    label_es: "Reanalizar",
    desc_en: "Three months later you test again. The score moves. The trajectory becomes data, not guesswork.",
    desc_es: "Tres meses después vuelves a analizar. La puntuación se mueve. La trayectoria se vuelve dato, no conjetura.",
  },
];

export default function SciencePage() {
  const params = useParams();
  const locale = (params.locale as string) ?? "es";
  const [openCat, setOpenCat] = useState<string | null>(null);
  const [openMetric, setOpenMetric] = useState<string | null>(null);
  const [pinnedLoopStep, setPinnedLoopStep] = useState<number | null>(null);
  const [hoveredLoopStep, setHoveredLoopStep] = useState<number | null>(null);
  const activeLoopStep = pinnedLoopStep ?? hoveredLoopStep;

  const t = locale === "es"
    ? {
        /* ─ chapter markers ─ */
        ch01: "§ 01 · La ciencia", ch02: "§ 02 · Lo que oculta lo normal",
        ch03: "§ 03 · Edad biológica", ch04: "§ 04 · La puntuación de longevidad",
        ch05: "§ 05 · La capa de datos", ch06: "§ 06 · La señal",
        ch07: "§ 07 · El ciclo", ch08: "§ 08 · La invitación",
        /* ─ § 01 opener ─ */
        pageTitle: "Tres preguntas que todo análisis debería responder.",
        pageBody: "Los análisis de sangre estándar responden a una de ellas \u2014 mal. EVA fue construida para responder a las tres.",
        question1: "\u00bfEs este resultado realmente saludable, o solo promedio?",
        question2: "\u00bfCómo envejezco frente a otras personas de mi edad?",
        question3: "\u00bfCuán cerca estoy de mi mejor versión posible?",
        question1Chapter: "\u00a7 II \u00b7 Rangos",
        question2Chapter: "\u00a7 III \u00b7 Envejecimiento",
        question3Chapter: "\u00a7 IV \u00b7 Óptimo",
        foundingNote: "Esta página es nuestra respuesta a las tres.",
        pressMark: "EVA Health \u00b7 MMXXV",
        /* ─ § 02 pillar I ─ */
        rangesTitle: "'Lo normal' se construyó promediando personas enfermas.",
        rangesLede: "Los rangos de referencia se construyen a partir del promedio de la población general. Esa población incluye a personas prediabéticas, con inflamación crónica o metabolismo deteriorado. 'Normal' es simplemente el promedio estadístico de quien entró al laboratorio, no una definición de salud.",
        statNumber: "33%",
        statLabel: "de los adultos con diabetes en Europa no saben que la tienen.",
        statSource: "Atlas de Diabetes de la FID, 2024",
        rangesBody: "La distancia entre 'normal' y 'óptimo' es donde se esconde la mayor parte del deterioro silencioso. La figura lee el mismo valor de dos maneras: una contra los rangos clínicos estándar, otra contra los rangos de longevidad de EVA. La diferencia suele aparecer años antes de cualquier síntoma.",
        stdLabel: "Clínico Normal", optLabel: "Óptimo EVA",
        figLabel: "FIG. I",
        figCaption: "Un biomarcador, dos lecturas. El ejemplo es hs-CRP (proteína C reactiva, un marcador de inflamación).",
        figSubCaption: "Arrastra el marcador \u2014 o desplaza, o usa las flechas \u2014 para ver cómo cambia el estado según el valor.",
        hscrpName: "hs-CRP",
        hscrpUnit: "mg/L",
        hscrpDragHint: "Arrastra \u00b7 Desplaza \u00b7 Teclas de flecha",
        hscrpValueLabel: "Tu valor",
        hscrpStatusLabel: "Estado",
        hscrpStatusOptimal: "Óptimo",
        hscrpStatusAboveOpt: "Por encima del óptimo",
        hscrpStatusElevated: "Elevado",
        hscrpInterpOptimal: "Por debajo del umbral donde la inflamación leve empieza a erosionar la salud a largo plazo.",
        hscrpInterpAboveOpt: "Dentro del rango clínico estándar, pero por encima del nivel que la investigación en longevidad asocia con los mejores resultados.",
        hscrpInterpElevated: "Fuera del rango clínico normal. Suele reflejar inflamación continua por dieta, sueño, estrés, o enfermedad metabólica temprana.",
        /* ─ § 03 pillar II ─ */
        bioAgeTitle: "La edad es un número. El envejecimiento es un proceso. Estimamos en qué punto estás.",
        bioAgeLede: "Tu fecha de nacimiento te dice cuánto tiempo has vivido. Tus biomarcadores permiten estimar cómo envejece tu cuerpo frente a la población. Las dos cifras no tienen por qué coincidir.",
        bioAgeHowLabel: "Cómo funciona el método Klemera-Doubal",
        bioAgeCred: "El método Klemera-Doubal fue publicado en 2006 y es uno de los métodos más usados y citados para estimar la edad biológica a partir de análisis de sangre.",
        bioAgeTransition: "Esto te dice cómo envejeces comparado con tus iguales. No te dice lo cerca que estás de tu mejor versión posible.",
        notebookLabel: "ENTRY · II",
        labNotesLabel: "Notas de laboratorio · I.II.III",
        annotationsLabel: "Claves",
        annotationA: "a. Tu edad biológica",
        annotationB: "b. Años más joven que tu edad real",
        annotationC: "c. Tu posición entre iguales de tu edad",
        /* ─ § 04 pillar III ─ */
        longevityTitle: "Dos puntuaciones. Un espejo. Un mapa.",
        longevityLede: "Saber que eres biológicamente más joven que tus iguales es reconfortante. Saber exactamente qué cambio movería más tu salud es algo distinto. Para eso sirve la puntuación de longevidad.",
        longevityHowLabel: "Cómo funciona la puntuación de longevidad",
        contrastLine1: "La edad biológica te compara con la población de referencia.",
        contrastLine2: "La puntuación de longevidad te compara con tu mejor versión posible.",
        contrastLine3: "La primera es un espejo. La segunda es un mapa.",
        mirrorWord: "ESPEJO", mapWord: "MAPA",
        interludeEyebrow: "Entre capítulos \u00b7 \u00a7 II \u00bd",
        interludeNext: "\u00a7 III \u00b7 Edad biol\u00f3gica",
        stratLabel: "Por qué los objetivos son personales",
        stratFacts: ["24 grupos de edad desde los 18 hasta más de 100", "Objetivos óptimos separados para hombres y mujeres", "Revisados trimestralmente contra nueva investigación revisada por pares en longevidad"],
        longevityScoreLabel: "Puntuación de Longevidad",
        instrumentLabel: "INSTRUMENT · III",
        observationLabel: "Lectura actual",
        instrumentName: "EVA Longevity Score · Mk III",
        calibrationLabel: "Calibración · \u03b1 \u03b2 \u03b3",
        fieldNotesLabel: "Notas de calibración",
        /* ─ § 05 data layer ─ */
        catalogueLabel: "CATALOGUE · IV",
        dataEyebrow: "↳ La ciencia, en la práctica",
        dataTitle: "165+ biomarcadores. 15 categorías. 7 métricas derivadas.",
        dataBody: "Esto es lo que leen los algoritmos. Cada resultado se verifica contra el rango que es óptimo para tu edad y sexo, y luego se incorpora a tu puntuación de longevidad. Tu edad biológica usa solo los marcadores que admite su modelo, y no usa la fructosamina medida.",
        biomarkerMapLabel: "El mapa de biomarcadores",
        derivedMetricsLabel: "Métricas derivadas",
        baseTag: "Panel Base", specialtyTag: "Especializado",
        formulaLabel: "Fórmula", optimalLabel: "Rango Óptimo",
        /* ─ § 06 signal ─ */
        signalTitle: "Tu wearable llena los huecos entre extracciones.",
        signalBody: "Los paneles de sangre se hacen trimestralmente. Entre ellos, tu wearable proporciona una señal continua. Cuando tu HRV cae la semana después de una extracción, EVA lo conecta con tu resultado de cortisol. El contexto cambia lo que significan los números.",
        traceLabel: "TRACE \u00b7 V",
        traceHrvLabel: "HRV",
        traceHrvDesc: "Estrés y recuperación",
        traceSleepLabel: "SUEÑO",
        traceSleepDesc: "Restauración y equilibrio hormonal",
        traceHeartLabel: "RC EN REPOSO",
        traceHeartDesc: "Salud cardiovascular basal",
        traceRecoveryLabel: "RECUPERACIÓN",
        traceRecoveryDesc: "Preparación y carga inflamatoria",
        /* ─ § 07 loop ─ */
        loopTitle: "Analiza. Interpreta. Actúa. Repite.",
        loopBody: "La salud no mejora con una sola instantánea. El ciclo trimestral es donde la ciencia se compone. Cada panel se basa en el anterior, cada puntuación sigue tu trayectoria, y EVA AI destaca qué cambió, y por qué.",
        evaAiLabel: "EVA AI, tu intérprete",
        evaAiBody: "EVA AI ve tu panel completo, las tendencias de tu wearable y el historial de tus resultados. No da consejos genéricos. Hace la pregunta correcta sobre tu patrón específico.",
        dispatchLabel: "DISPATCH \u00b7 VI",
        quarterlyHeader: "Cadencia trimestral",
        stampsLabel: "Estampillas \u2014 pulsa para explorar",
        chatTitle: "EVA AI",
        chatSubtitle: "En línea \u00b7 lee tu panel completo",
        chatUserLabel: "T\u00fa",
        chatEvaLabel: "EVA",
        chatReferencedLabel: "Referenciado en tu panel",
        chatRef1: "Marcador de inflamaci\u00f3n",
        chatRef2: "Perfil de colesterol",
        chatInputPlaceholder: "Pregunta sobre tus resultados\u2026",
        chatInputSend: "Enviar",
        aiUserMsg: "Mi edad biológica bajó 3 años. ¿Qué la movió?",
        aiEvaMsg: "Un cambio de 3 años entre dos analíticas cabe dentro de la variación normal, así que todavía no indica un cambio real. Tu marcador de inflamación bajó al cuartil más bajo para tu grupo de edad: si se mantiene en la próxima analítica, es una buena señal. Tu patrón de colesterol es tu mayor oportunidad restante. Ajustarlo movería tu puntuación de longevidad de 82 a alrededor de 89.",
        /* ─ § 08 invitation ─ */
        ctaTitle: "Comienza tu camino.",
        ctaBody: "Sube tus análisis existentes gratis o suscríbete para rangos óptimos, edad biológica y puntuación de longevidad seguidos cada trimestre.",
        ctaButton: "Comienza Tu Camino",
        invitationLabel: "N\u00b0 VIII",
        invitationHeader: "Una invitaci\u00f3n",
        invitationClosing: "Con atenci\u00f3n y cuidado, EVA Health.",
      }
    : {
        /* ─ chapter markers ─ */
        ch01: "§ 01 · The science", ch02: "§ 02 · What normal hides",
        ch03: "§ 03 · Biological age", ch04: "§ 04 · The longevity score",
        ch05: "§ 05 · The data layer", ch06: "§ 06 · The signal",
        ch07: "§ 07 · The loop", ch08: "§ 08 · The invitation",
        /* ─ § 01 opener ─ */
        pageTitle: "Three questions every lab result should answer.",
        pageBody: "Standard blood tests answer one of them \u2014 badly. EVA was built to answer all three.",
        question1: "Is this result truly healthy, or only average?",
        question2: "How am I aging compared with people my age?",
        question3: "How close am I to my best possible self?",
        question1Chapter: "\u00a7 II \u00b7 Ranges",
        question2Chapter: "\u00a7 III \u00b7 Aging",
        question3Chapter: "\u00a7 IV \u00b7 Optimal",
        foundingNote: "This page is our answer to all three.",
        pressMark: "EVA Health \u00b7 MMXXV",
        /* ─ § 02 pillar I ─ */
        rangesTitle: "'Normal' was built by averaging sick people.",
        rangesLede: "Reference ranges are built from the average of the general population. That population includes people who are prediabetic, chronically inflamed, or metabolically unwell. 'Normal' is simply a statistical average of whoever walked into the lab, not a definition of health.",
        statNumber: "33%",
        statLabel: "of adults with diabetes in Europe don't know they have it.",
        statSource: "IDF Diabetes Atlas, 2024",
        rangesBody: "The distance between 'normal' and 'optimal' is where most silent decline hides. The figure reads the same value two ways: once against standard clinical ranges, once against EVA's longevity ranges. The gap usually appears years before any symptom.",
        stdLabel: "Clinic Normal", optLabel: "EVA Optimal",
        figLabel: "FIG. I",
        figCaption: "One biomarker, two readings. The example is hs-CRP (C-reactive protein, an inflammation marker).",
        figSubCaption: "Drag the marker \u2014 or scroll, or use the arrow keys \u2014 to watch the status change with the value.",
        hscrpName: "hs-CRP",
        hscrpUnit: "mg/L",
        hscrpDragHint: "Drag \u00b7 Scroll \u00b7 Arrow keys",
        hscrpValueLabel: "Your value",
        hscrpStatusLabel: "Status",
        hscrpStatusOptimal: "Optimal",
        hscrpStatusAboveOpt: "Above optimal",
        hscrpStatusElevated: "Elevated",
        hscrpInterpOptimal: "Below the threshold where low-grade inflammation starts eroding long-term health.",
        hscrpInterpAboveOpt: "Inside the standard clinical range, but above the level longevity research associates with the best long-term outcomes.",
        hscrpInterpElevated: "Outside standard clinical normal. Often reflects ongoing inflammation from diet, sleep, stress, or early metabolic disease.",
        /* ─ § 03 pillar II ─ */
        bioAgeTitle: "Age is a number. Aging is a process. We estimate where you stand.",
        bioAgeLede: "Your birthday tells you how long you have been alive. Your biomarkers give an estimate of how your body is aging compared with the population. The two numbers need not match.",
        bioAgeHowLabel: "How the Klemera-Doubal method works",
        bioAgeCred: "The Klemera-Doubal method was published in 2006 and is one of the most widely used and cited ways to estimate biological age from blood tests.",
        bioAgeTransition: "This tells you how you are aging compared to your peers. It does not tell you how close you are to your best possible self.",
        notebookLabel: "ENTRY · II",
        labNotesLabel: "Lab notes · I.II.III",
        annotationsLabel: "Key",
        annotationA: "a. Your biological age",
        annotationB: "b. Years younger than your chronological age",
        annotationC: "c. Where you sit in your age cohort",
        /* ─ § 04 pillar III ─ */
        longevityTitle: "Two scores. One mirror. One map.",
        longevityLede: "Knowing you are biologically younger than your peers is reassuring. Knowing exactly which change would move your health the most is something else entirely. That is what the longevity score is for.",
        longevityHowLabel: "How the longevity score works",
        contrastLine1: "Biological age compares you with a reference population.",
        contrastLine2: "Longevity score compares you to your optimal self.",
        contrastLine3: "The first is a mirror. The second is a map.",
        mirrorWord: "MIRROR", mapWord: "MAP",
        interludeEyebrow: "Between chapters \u00b7 \u00a7 II \u00bd",
        interludeNext: "\u00a7 III \u00b7 Biological age",
        stratLabel: "Why targets are personal",
        stratFacts: ["24 age groups spanning 18 to 100+", "Separate optimal targets for males and females", "Reviewed quarterly against new peer-reviewed longevity research"],
        longevityScoreLabel: "Longevity Score",
        instrumentLabel: "INSTRUMENT · III",
        observationLabel: "Current reading",
        instrumentName: "EVA Longevity Score · Mk III",
        calibrationLabel: "Calibration · \u03b1 \u03b2 \u03b3",
        fieldNotesLabel: "Calibration notes",
        /* ─ § 05 data layer ─ */
        catalogueLabel: "CATALOGUE · IV",
        dataEyebrow: "↳ The science, in practice",
        dataTitle: "165+ biomarkers. 15 categories. 7 derived metrics.",
        dataBody: "This is what the algorithms read. Every result is checked against the range that is optimal for your age and sex, then folded into your longevity score. Your biological age uses only the markers its model accepts, and it does not use measured fructosamine.",
        biomarkerMapLabel: "The biomarker map",
        derivedMetricsLabel: "Derived metrics",
        baseTag: "Base Panel", specialtyTag: "Specialty",
        formulaLabel: "Formula", optimalLabel: "Optimal Range",
        /* ─ § 06 signal ─ */
        signalTitle: "Your wearable fills the gaps between draws.",
        signalBody: "Blood panels run quarterly. Between them, your wearable provides a continuous signal. When your HRV drops the week after a draw, EVA connects it to your cortisol result. Context changes what the numbers mean.",
        traceLabel: "TRACE \u00b7 V",
        traceHrvLabel: "HRV",
        traceHrvDesc: "Stress and recovery",
        traceSleepLabel: "SLEEP",
        traceSleepDesc: "Restoration and hormonal balance",
        traceHeartLabel: "RESTING HR",
        traceHeartDesc: "Baseline cardiovascular health",
        traceRecoveryLabel: "RECOVERY",
        traceRecoveryDesc: "Readiness and inflammatory load",
        /* ─ § 07 loop ─ */
        loopTitle: "Test. Interpret. Act. Repeat.",
        loopBody: "Health does not improve from a single snapshot. The quarterly loop is where the science compounds. Each panel builds on the last, each score tracks your trajectory, and EVA AI surfaces what changed, and why.",
        evaAiLabel: "EVA AI, your context-aware interpreter",
        evaAiBody: "EVA AI sees your full panel, your wearable trends, and your result history. It does not give generic advice. It asks the right question about your specific pattern.",
        dispatchLabel: "DISPATCH \u00b7 VI",
        quarterlyHeader: "Quarterly cadence",
        stampsLabel: "Postmarks \u2014 tap to explore",
        chatTitle: "EVA AI",
        chatSubtitle: "Online \u00b7 reads your full panel",
        chatUserLabel: "You",
        chatEvaLabel: "EVA",
        chatReferencedLabel: "Referenced in your panel",
        chatRef1: "Inflammation marker",
        chatRef2: "Cholesterol profile",
        chatInputPlaceholder: "Ask about your results\u2026",
        chatInputSend: "Send",
        aiUserMsg: "My biological age dropped 3 years. What moved it?",
        aiEvaMsg: "A 3-year change between two lab tests is within normal variation, so it does not yet show a real change. Your inflammation marker dropped into the lowest quartile for your age group: if it holds on your next test, that is a good sign. Your cholesterol pattern is your biggest remaining opportunity. Tightening it would move your longevity score from 82 to around 89.",
        /* ─ § 08 invitation ─ */
        ctaTitle: "Start your journey.",
        ctaBody: "Upload existing labs for free, or subscribe for optimal ranges, biological age, and longevity score tracked every quarter.",
        ctaButton: "Start Your Journey",
        invitationLabel: "N\u00b0 VIII",
        invitationHeader: "An invitation",
        invitationClosing: "With care and attention, EVA Health.",
      };

  const ctaWords = t.ctaTitle.split(" ");
  const ctaLastWord = ctaWords.pop() ?? "";
  const ctaLeadWords = ctaWords.join(" ");

  return (
    <div className="relative antialiased [font-feature-settings:'liga','calt','kern']" style={{ textRendering: "optimizeLegibility" }}>
      {/* Scroll progress bar */}
      <ScrollProgressBar />

      {/* Film grain */}
      <div aria-hidden className="pointer-events-none fixed inset-0 z-[1] opacity-[0.05] mix-blend-multiply" style={{ backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='eva-grain-s'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/></filter><rect width='100%25' height='100%25' filter='url(%23eva-grain-s)'/></svg>")`, backgroundSize: "220px 220px" }} />

      {/* ─── § 01 · THE FRONTISPIECE (Table of Contents) ─────── */}
      <div id="ch-01" className="scroll-mt-10">
      <SectionShell tone="cream" size="xlarge">
        {/* Top-line: chapter marker + press mark */}
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch01}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.pressMark}
            </span>
          </ScrollReveal>
        </div>

        {/* Typographic rule that draws in */}
        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        {/* Monumental title */}
        <ScrollReveal delay={0.15} className="mt-16 md:mt-24">
          <SectionHeadline scale="monumental" maxCh={18}>{t.pageTitle}</SectionHeadline>
        </ScrollReveal>

        {/* Setup — tight, two-sentence turn */}
        <div className="mt-14 grid grid-cols-12 gap-y-6 md:mt-20 md:gap-12">
          <ScrollReveal delay={0.22} className="col-span-12 md:col-span-7 md:col-start-6">
            <BodyProse maxCh={54}>{t.pageBody}</BodyProse>
          </ScrollReveal>
        </div>

        {/* ─── Editorial contents: three questions, each an anchor ─── */}
        <nav aria-label="Page contents" className="mx-auto mt-20 max-w-[900px] md:mt-32">
          <ul className="border-t border-[#1d1b18]/15">
            {(
              [
                { roman: "I", question: t.question1, chapter: t.question1Chapter, href: "#ch-02", accent: "#97472c" },
                { roman: "II", question: t.question2, chapter: t.question2Chapter, href: "#ch-03", accent: "#3a665e" },
                { roman: "III", question: t.question3, chapter: t.question3Chapter, href: "#ch-04", accent: "#c49332" },
              ] as const
            ).map((item, i) => (
              <motion.li
                key={item.roman}
                className="border-b border-[#1d1b18]/15"
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.75, delay: 0.35 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              >
                <a
                  href={item.href}
                  onClick={(e) => {
                    e.preventDefault();
                    const target = document.querySelector(item.href);
                    if (!(target instanceof HTMLElement)) return;
                    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                    target.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
                    history.replaceState(null, "", item.href);
                  }}
                  className="group grid grid-cols-[auto_1fr] items-baseline gap-5 py-7 transition-colors duration-300 hover:bg-[#1d1b18]/[0.025] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#97472c]/55 focus-visible:ring-offset-4 focus-visible:ring-offset-[#fef8f2] md:grid-cols-[auto_1fr_auto] md:gap-10 md:py-10 md:pr-4"
                >
                  {/* Roman numeral — large italic Sentient, subtle parallax on hover */}
                  <motion.span
                    className="font-[family-name:var(--font-sentient)] italic leading-none text-[#97472c]"
                    style={{ fontSize: "clamp(34px, 5vw, 58px)" }}
                  >
                    {item.roman}
                  </motion.span>

                  {/* The question */}
                  <p
                    className="font-[family-name:var(--font-sentient)] italic leading-[1.2] text-[#1d1b18]"
                    style={{ fontSize: "clamp(20px, 2.8vw, 30px)" }}
                  >
                    {item.question}
                  </p>

                  {/* Chapter pointer + arrow — desktop only, hidden on mobile */}
                  <div className="hidden items-baseline gap-3 md:flex">
                    <span
                      className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] transition-colors duration-300"
                      style={{ color: item.accent }}
                    >
                      {item.chapter}
                    </span>
                    <motion.span
                      aria-hidden
                      className="inline-block font-[family-name:var(--font-sentient)] leading-none transition-transform duration-300 group-hover:translate-x-1.5"
                      style={{ color: item.accent, fontSize: "20px" }}
                    >
                      →
                    </motion.span>
                  </div>

                  {/* Mobile pointer — below question, full width of content column */}
                  <div className="col-start-2 flex items-baseline gap-2 md:hidden">
                    <span
                      className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px]"
                      style={{ color: item.accent }}
                    >
                      {item.chapter}
                    </span>
                    <span aria-hidden className="font-[family-name:var(--font-sentient)] leading-none" style={{ color: item.accent, fontSize: "16px" }}>
                      →
                    </span>
                  </div>
                </a>
              </motion.li>
            ))}
          </ul>
        </nav>

        {/* Bottom marginalia — right-aligned signature */}
        <div className="mt-20 flex justify-end md:mt-28">
          <ScrollReveal delay={0.75}>
            <div className="max-w-[340px] text-right">
              <p
                className="font-[family-name:var(--font-sentient)] italic leading-[1.4] text-[#4c463f]"
                style={{ fontSize: "15px" }}
              >
                {t.foundingNote}
              </p>
            </div>
          </ScrollReveal>
        </div>

        {/* Ornamental flourish */}
        <ScrollReveal delay={0.9} className="mt-14 flex justify-center md:mt-20">
          <span
            className="font-[family-name:var(--font-sentient)] leading-none text-[#97472c]/45"
            style={{ fontSize: "32px" }}
            aria-hidden
          >
            ∾
          </span>
        </ScrollReveal>
      </SectionShell>
      </div>

      {/* ─── § 02 · THE SPECIMEN PLATE ───────────────────────── */}
      <div id="ch-02" className="scroll-mt-10">
      <SectionShell tone="cream-alt" size="large">
        {/* Top-line: chapter + figure number */}
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch02}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.figLabel}
            </span>
          </ScrollReveal>
        </div>

        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        <ScrollReveal delay={0.1} className="mt-10 md:mt-16">
          <SectionHeadline scale="standard" maxCh={20}>{t.rangesTitle}</SectionHeadline>
        </ScrollReveal>

        <ScrollReveal delay={0.15} className="mt-8 md:mt-12">
          <LedeItalic maxCh={54}>{t.rangesLede}</LedeItalic>
        </ScrollReveal>

        {/* ─── The specimen plate: framed figure with corner marks ─── */}
        <ScrollReveal delay={0.2} className="mt-16 md:mt-24">
          <div className="relative mx-auto max-w-[900px]">
            {/* Frame with subtle paper tint */}
            <div
              className="relative px-6 py-10 md:px-14 md:py-16"
              style={{
                border: "1px solid rgba(29,27,24,0.14)",
                backgroundColor: "rgba(254,248,242,0.45)",
              }}
            >
              {/* Corner registration marks */}
              <span className="absolute left-[6px] top-[6px] h-[10px] w-[10px] border-l border-t border-[#97472c]/60" aria-hidden />
              <span className="absolute right-[6px] top-[6px] h-[10px] w-[10px] border-r border-t border-[#97472c]/60" aria-hidden />
              <span className="absolute bottom-[6px] left-[6px] h-[10px] w-[10px] border-b border-l border-[#97472c]/60" aria-hidden />
              <span className="absolute bottom-[6px] right-[6px] h-[10px] w-[10px] border-b border-r border-[#97472c]/60" aria-hidden />

              <InteractiveHsCrpFigure
                clinicLabel={t.stdLabel}
                optimalLabel={t.optLabel}
                biomarkerName={t.hscrpName}
                unit={t.hscrpUnit}
                dragHint={t.hscrpDragHint}
                valueLabel={t.hscrpValueLabel}
                statusLabel={t.hscrpStatusLabel}
                statusOptimal={t.hscrpStatusOptimal}
                statusAboveOpt={t.hscrpStatusAboveOpt}
                statusElevated={t.hscrpStatusElevated}
                interpOptimal={t.hscrpInterpOptimal}
                interpAboveOpt={t.hscrpInterpAboveOpt}
                interpElevated={t.hscrpInterpElevated}
              />
            </div>

            {/* Caption */}
            <div className="mt-6 flex flex-col items-center text-center md:mt-8">
              <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
                {t.figLabel}
              </p>
              <p className="mt-2 font-[family-name:var(--font-manrope)] text-[14px] font-semibold text-[#1d1b18]">
                {t.figCaption}
              </p>
              <p className="mt-1.5 max-w-[520px] font-[family-name:var(--font-sentient)] italic leading-[1.55] text-[#4c463f]" style={{ fontSize: "14px" }}>
                {t.figSubCaption}
              </p>
            </div>
          </div>
        </ScrollReveal>

        {/* ─── Two-column exegesis: body prose left, stat margin-note right ─── */}
        <div className="mt-14 grid grid-cols-12 gap-y-8 md:mt-20 md:gap-16">
          <ScrollReveal delay={0.1} className="col-span-12 md:col-span-7">
            <BodyProse maxCh={54}>{t.rangesBody}</BodyProse>
          </ScrollReveal>

          {/* Margin-note stat */}
          <ScrollReveal delay={0.22} className="col-span-12 md:col-span-4 md:col-start-9">
            <div className="border-l-[2px] border-[#97472c]/25 pl-5 md:pl-6">
              <span
                className="block font-[family-name:var(--font-dm-mono)] font-bold leading-none text-[#97472c] [font-feature-settings:'tnum']"
                style={{ fontSize: "clamp(52px, 7vw, 72px)" }}
              >
                {t.statNumber}
              </span>
              <p className="mt-3 font-[family-name:var(--font-manrope)] leading-[1.45] text-[#1d1b18]" style={{ fontSize: "14px" }}>
                {t.statLabel}
              </p>
              <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]">
                {t.statSource}
              </p>
            </div>
          </ScrollReveal>
        </div>
      </SectionShell>
      </div>

      {/* ─── INTERLUDE §II½: mirror & map (dark chapter break) ─── */}
      <div id="ch-interlude" className="scroll-mt-10">
      <SectionShell tone="dark" size="xlarge">
        <MirrorMapInterlude
          setupLine1={t.contrastLine1}
          setupLine2={t.contrastLine2}
          landingLine={t.contrastLine3}
          leftWord={t.mirrorWord}
          rightWord={t.mapWord}
          eyebrowLabel={t.interludeEyebrow}
          nextChapterLabel={t.interludeNext}
        />
      </SectionShell>
      </div>

      {/* ─── § 03 · THE FIELD NOTEBOOK ───────────────────────── */}
      <div id="ch-03" className="scroll-mt-10">
      <SectionShell tone="cream" size="standard">
        {/* Top-line: chapter + notebook entry label */}
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch03}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.notebookLabel}
            </span>
          </ScrollReveal>
        </div>

        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        <ScrollReveal delay={0.1} className="mt-10 md:mt-16">
          <SectionHeadline scale="standard" maxCh={22} className="leading-[1.05]">{t.bioAgeTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.15} className="mt-10 md:mt-14">
          <LedeItalic maxCh={52}>{t.bioAgeLede}</LedeItalic>
        </ScrollReveal>

        {/* ─── Notebook composition: specimen orb + key (left) | lab notes (right) ─── */}
        <div className="mt-16 grid grid-cols-12 gap-y-12 md:mt-24 md:gap-16">
          {/* LEFT: orb as specimen with annotations */}
          <ScrollReveal delay={0.1} className="col-span-12 md:col-span-5">
            <div className="flex flex-col items-center">
              {/* Orb — hero size on mobile to fit narrow viewports */}
              <div className="md:hidden">
                <BiologicalAgeOrb bioAge={29} realAge={34} size="hero" />
              </div>
              <div className="hidden md:block">
                <BiologicalAgeOrb bioAge={29} realAge={34} size="large" />
              </div>

              {/* Annotation key */}
              <div className="mt-10 w-full max-w-[360px]">
                <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
                  {t.annotationsLabel}
                </p>
                <div className="mt-3 space-y-1.5 border-t border-[#1d1b18]/12 pt-3">
                  {[t.annotationA, t.annotationB, t.annotationC].map((a, i) => (
                    <p
                      key={i}
                      className="font-[family-name:var(--font-sentient)] italic leading-[1.5] text-[#4c463f]"
                      style={{ fontSize: "14px" }}
                    >
                      {a}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* RIGHT: lab notes — step ledger + transition + credibility */}
          <ScrollReveal delay={0.2} className="col-span-12 md:col-span-7">
            <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
              {t.labNotesLabel}
            </p>

            {/* Step ledger, notebook-styled */}
            <div className="mt-6 space-y-0">
              {bioAgeSteps.map((step, i) => (
                <div
                  key={step.num}
                  className="grid grid-cols-12 gap-x-4 border-t border-[#1d1b18]/12 py-6 last:border-b md:gap-x-6"
                  style={i === bioAgeSteps.length - 1 ? { borderBottom: "1px solid rgba(29,27,24,0.12)" } : undefined}
                >
                  <div className="col-span-2">
                    <span className="font-[family-name:var(--font-dm-mono)] text-[11px] font-bold text-[#97472c] [font-feature-settings:'tnum']">
                      {step.num}
                    </span>
                  </div>
                  <div className="col-span-10">
                    <p className="font-[family-name:var(--font-sentient)] italic leading-none text-[#1d1b18]" style={{ fontSize: "20px" }}>
                      {locale === "es" ? step.name_es : step.name_en}
                    </p>
                    <p className="mt-2 font-[family-name:var(--font-manrope)] text-[13.5px] leading-[1.6] text-[#4c463f]">
                      {locale === "es" ? step.body_es : step.body_en}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Transition — the emotional peak of this section */}
            <p
              className="mt-10 font-[family-name:var(--font-sentient)] italic leading-[1.2] text-[#1d1b18]"
              style={{ fontSize: "clamp(19px, 2.6vw, 28px)" }}
            >
              {t.bioAgeTransition}
            </p>

            {/* Credibility — muted footnote */}
            <BodyProse size="compact" tone="muted" className="mt-8" maxCh={56}>
              {t.bioAgeCred}
            </BodyProse>
          </ScrollReveal>
        </div>
      </SectionShell>
      </div>

      {/* ─── § 04 · THE NAVIGATIONAL INSTRUMENT ──────────────── */}
      <div id="ch-04" className="scroll-mt-10">
      <SectionShell tone="cream-alt" size="large">
        {/* Top-line */}
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch04}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.instrumentLabel}
            </span>
          </ScrollReveal>
        </div>

        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        <ScrollReveal delay={0.1} className="mt-10 md:mt-16">
          {/* § 04 title — three sentence beats, with mirror/map tied back
              to the interlude's terra/gold color coding. Explicit block
              lines with controlled gaps so the sentences read as a
              deliberate triptych rather than a single paragraph. */}
          <h2
            className="font-[family-name:var(--font-sentient)] font-medium text-[#1d1b18] tracking-[-1px] md:tracking-[-3.5px]"
            style={{ maxWidth: "20ch", textWrap: "balance" as const }}
          >
            {locale === "es" ? (
              <>
                <span className="block text-[52px] leading-[1] md:text-[112px]">Dos puntuaciones.</span>
                <span className="mt-4 block text-[52px] leading-[1] md:mt-6 md:text-[112px]">
                  Un <span className="text-[#97472c]">espejo</span>.
                </span>
                <span className="mt-4 block text-[52px] leading-[1] md:mt-6 md:text-[112px]">
                  Un <span className="text-[#c49332]">mapa</span>.
                </span>
              </>
            ) : (
              <>
                <span className="block text-[52px] leading-[1] md:text-[112px]">Two scores.</span>
                <span className="mt-4 block text-[52px] leading-[1] md:mt-6 md:text-[112px]">
                  One <span className="text-[#97472c]">mirror</span>.
                </span>
                <span className="mt-4 block text-[52px] leading-[1] md:mt-6 md:text-[112px]">
                  One <span className="text-[#c49332]">map</span>.
                </span>
              </>
            )}
          </h2>
        </ScrollReveal>
        <ScrollReveal delay={0.15} className="mt-12 md:mt-16">
          <LedeItalic maxCh={54}>{t.longevityLede}</LedeItalic>
        </ScrollReveal>

        <div className="mt-16 grid grid-cols-12 gap-y-12 md:mt-24 md:gap-16">
          {/* LEFT: instrument case with orb */}
          <ScrollReveal delay={0.1} className="col-span-12 md:col-span-5">
            <div className="flex flex-col items-center">
              {/* Instrument case — subtle gold-tinted outline with tick marks.
                  On mobile the frame is dropped entirely so the hero orb
                  (320px + 384px ring extent) doesn't overflow narrow
                  viewports. The nameplate below still carries the
                  "instrument" semantics. */}
              <div className="relative md:border md:border-[#c49332]/25 md:px-10 md:py-10">
                {/* Corner ticks (gold) — md+ only, paired with the frame */}
                <span className="absolute left-[4px] top-[4px] hidden h-[10px] w-[10px] border-l border-t border-[#c49332]/70 md:block" aria-hidden />
                <span className="absolute right-[4px] top-[4px] hidden h-[10px] w-[10px] border-r border-t border-[#c49332]/70 md:block" aria-hidden />
                <span className="absolute bottom-[4px] left-[4px] hidden h-[10px] w-[10px] border-b border-l border-[#c49332]/70 md:block" aria-hidden />
                <span className="absolute bottom-[4px] right-[4px] hidden h-[10px] w-[10px] border-b border-r border-[#c49332]/70 md:block" aria-hidden />

                {/* Hero size on mobile so the outer score ring doesn't
                    overflow narrow viewports; large on md+ */}
                <div className="md:hidden">
                  <LongevityScoreOrb
                    score={82}
                    bioAge={29}
                    realAge={34}
                    size="hero"
                    scoreLabel={t.longevityScoreLabel}
                  />
                </div>
                <div className="hidden md:block">
                  <LongevityScoreOrb
                    score={82}
                    bioAge={29}
                    realAge={34}
                    size="large"
                    scoreLabel={t.longevityScoreLabel}
                  />
                </div>
              </div>

              {/* Instrument nameplate. Extra top margin clears the
                  LongevityScoreOrb's SVG ring overflow: the ring
                  extends ~24px (hero) / ~28px (large) below its own
                  wrapper via overflow:visible, so a generous gap here
                  keeps the "CURRENT READING" text from being crossed
                  by the arc. */}
              <div className="mt-12 flex flex-col items-center md:mt-14">
                <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#c49332]">
                  {t.observationLabel}
                </p>
                <p className="mt-1.5 font-[family-name:var(--font-sentient)] italic text-[#4c463f]" style={{ fontSize: "14px" }}>
                  {t.instrumentName}
                </p>
              </div>
            </div>
          </ScrollReveal>

          {/* RIGHT: calibration (step ledger) + field notes (strat facts) */}
          <ScrollReveal delay={0.2} className="col-span-12 md:col-span-7">
            <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#c49332]">
              {t.calibrationLabel}
            </p>

            {/* Step ledger — greek-letter nomenclature to differ from § 03 */}
            <div className="mt-6 space-y-0">
              {longevitySteps.map((step, i) => {
                const greek = ["α", "β", "γ"][i];
                return (
                  <div
                    key={step.num}
                    className="grid grid-cols-12 gap-x-4 border-t border-[#1d1b18]/12 py-6 md:gap-x-6"
                    style={i === longevitySteps.length - 1 ? { borderBottom: "1px solid rgba(29,27,24,0.12)" } : undefined}
                  >
                    <div className="col-span-2">
                      <span
                        className="font-[family-name:var(--font-sentient)] italic leading-none text-[#c49332]"
                        style={{ fontSize: "28px" }}
                      >
                        {greek}
                      </span>
                    </div>
                    <div className="col-span-10">
                      <p className="font-[family-name:var(--font-sentient)] italic leading-none text-[#1d1b18]" style={{ fontSize: "20px" }}>
                        {locale === "es" ? step.name_es : step.name_en}
                      </p>
                      <p className="mt-2 font-[family-name:var(--font-manrope)] text-[13.5px] leading-[1.6] text-[#4c463f]">
                        {locale === "es" ? step.body_es : step.body_en}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Field notes — stratification facts as calibration notes */}
            <div className="mt-10">
              <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
                {t.fieldNotesLabel}
              </p>
              <ul className="mt-4 space-y-2.5">
                {t.stratFacts.map((fact, i) => (
                  <li key={i} className="flex items-baseline gap-3">
                    <span className="shrink-0 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold text-[#c49332] [font-feature-settings:'tnum']" aria-hidden>
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="font-[family-name:var(--font-manrope)] text-[14px] leading-[1.6] text-[#2a2319]">{fact}</span>
                  </li>
                ))}
              </ul>
            </div>
          </ScrollReveal>
        </div>
      </SectionShell>
      </div>

      {/* ─── § 05 · THE TAXONOMIC CATALOG ────────────────────── */}
      <div id="ch-05" className="scroll-mt-10">
      <SectionShell tone="cream" size="standard">
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch05}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.catalogueLabel}
            </span>
          </ScrollReveal>
        </div>

        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        <ScrollReveal delay={0.1} className="mt-10 md:mt-16">
          <SectionHeadline scale="standard" maxCh={22} className="leading-[1.05]">{t.dataTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.15} className="mt-10 md:mt-14">
          <BodyProse maxCh={56}>{t.dataBody}</BodyProse>
        </ScrollReveal>

        {/* Catalogue of biomarkers */}
        <ScrollReveal delay={0.18} className="mt-14 md:mt-20">
          <div className="flex items-baseline justify-between border-b border-[#1d1b18]/25 pb-3">
            <p className="font-[family-name:var(--font-sentient)] italic text-[#1d1b18]" style={{ fontSize: "22px" }}>
              {t.biomarkerMapLabel}
            </p>
            <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76] [font-feature-settings:'tnum']">
              I · XV
            </span>
          </div>
        </ScrollReveal>
        <div className="divide-y divide-[#1d1b18]/12">
          {categories.map((cat, i) => {
            const isOpen = openCat === cat.id;
            return (
              <div key={cat.id}>
                <button onClick={() => setOpenCat(isOpen ? null : cat.id)} className="group grid w-full grid-cols-[40px_1fr_auto_auto] items-baseline gap-4 py-6 text-left transition-colors duration-300 hover:bg-[#1d1b18]/[0.025] md:grid-cols-[64px_1fr_auto_auto] md:gap-8 md:py-8 md:[&>span:first-child]:transition-transform md:[&>span:first-child]:duration-300 md:hover:[&>span:first-child]:translate-x-0.5">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[11px] font-bold text-[#97472c] [font-feature-settings:'tnum']">
                    {toRoman(i + 1)}
                  </span>
                  <p className="min-w-0 font-[family-name:var(--font-sentient)] italic leading-none text-[#1d1b18]" style={{ fontSize: "clamp(18px, 2.2vw, 24px)" }}>
                    {locale === "es" ? cat.name_es : cat.name}
                  </p>
                  <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] [font-feature-settings:'tnum']">
                    n. {cat.count}
                  </span>
                  <motion.span animate={{ rotate: isOpen ? 45 : 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="shrink-0 font-[family-name:var(--font-sentient)] text-[20px] font-medium text-[#8a7f76]">+</motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}>
                      <div className="pb-6 pl-[56px] md:pb-8 md:pl-[72px]">
                        {cat.base.length > 0 && (
                          <div className="mb-4">
                            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#3a665e]">{t.baseTag}</span>
                            <p className="mt-2 font-[family-name:var(--font-manrope)] text-[14px] text-[#4c463f]">{cat.base.join(" · ")}</p>
                          </div>
                        )}
                        <div>
                          <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#c49332]">{t.specialtyTag}</span>
                          <p className="mt-2 font-[family-name:var(--font-manrope)] text-[14px] text-[#4c463f]">{cat.specialty.join(" · ")}</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
          <div className="border-t border-[#1d1b18]/12" />
        </div>

        {/* Sub-catalogue: derived metrics */}
        <ScrollReveal className="mt-14 md:mt-20">
          <div className="flex items-baseline justify-between border-b border-[#1d1b18]/25 pb-3">
            <p className="font-[family-name:var(--font-sentient)] italic text-[#1d1b18]" style={{ fontSize: "22px" }}>
              {t.derivedMetricsLabel}
            </p>
            <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76] [font-feature-settings:'tnum']">
              1 · 7
            </span>
          </div>
        </ScrollReveal>
        <div className="divide-y divide-[#1d1b18]/12">
          {metrics.map((m, i) => {
            const isOpen = openMetric === m.name;
            return (
              <div key={m.name}>
                <button onClick={() => setOpenMetric(isOpen ? null : m.name)} className="group grid w-full grid-cols-[40px_1fr_auto] items-baseline gap-4 py-6 text-left transition-colors duration-300 hover:bg-[#1d1b18]/[0.025] md:grid-cols-[64px_1fr_auto] md:gap-8 md:py-7 md:[&>span:first-child]:transition-transform md:[&>span:first-child]:duration-300 md:hover:[&>span:first-child]:translate-x-0.5">
                  <span className="font-[family-name:var(--font-dm-mono)] text-[11px] font-bold text-[#c49332] [font-feature-settings:'tnum']">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div>
                    <p className="font-[family-name:var(--font-sentient)] italic leading-none text-[#1d1b18]" style={{ fontSize: "clamp(18px, 2.2vw, 24px)" }}>
                      {m.name}
                    </p>
                    <p className="mt-1.5 font-[family-name:var(--font-manrope)] text-[13px] text-[#4c463f]">{locale === "es" ? m.what_es : m.what}</p>
                  </div>
                  <motion.span animate={{ rotate: isOpen ? 45 : 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="shrink-0 font-[family-name:var(--font-sentient)] text-[20px] font-medium text-[#8a7f76]">+</motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}>
                      <div className="pb-6 pl-[56px] md:pb-8 md:pl-[72px]">
                        <div className="flex items-baseline justify-between gap-4">
                          <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#8a7f76]">{t.formulaLabel}</span>
                          <span className="font-[family-name:var(--font-dm-mono)] text-[11px] text-[#4c463f] [font-feature-settings:'tnum']">{m.formula}</span>
                        </div>
                        <div className="mt-3 flex items-baseline justify-between gap-4">
                          <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2px] text-[#8a7f76]">{t.optimalLabel}</span>
                          <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#3a665e] [font-feature-settings:'tnum']">{m.optimal}</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
          <div className="border-t border-[#1d1b18]/12" />
        </div>
      </SectionShell>
      </div>

      {/* ─── § 06 · THE SEISMOGRAPH STRIP ────────────────────── */}
      <div id="ch-06" className="scroll-mt-10">
      <SectionShell tone="cream-alt" size="large">
        {/* Top-line */}
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch06}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.traceLabel}
            </span>
          </ScrollReveal>
        </div>

        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        <ScrollReveal delay={0.1} className="mt-10 md:mt-16">
          <SectionHeadline scale="standard" maxCh={22}>{t.signalTitle}</SectionHeadline>
        </ScrollReveal>

        <ScrollReveal delay={0.15} className="mt-8 md:mt-12">
          <BodyProse maxCh={54}>{t.signalBody}</BodyProse>
        </ScrollReveal>

        {/* Seismograph — continuous monitoring trace */}
        <ScrollReveal delay={0.2} className="mt-14 md:mt-20">
          <SeismographStrip
            traces={[
              { kind: "hrv",      label: t.traceHrvLabel,      descriptor: t.traceHrvDesc,      color: "#97472c" },
              { kind: "sleep",    label: t.traceSleepLabel,    descriptor: t.traceSleepDesc,    color: "#3a665e" },
              { kind: "heart",    label: t.traceHeartLabel,    descriptor: t.traceHeartDesc,    color: "#1d1b18" },
              { kind: "recovery", label: t.traceRecoveryLabel, descriptor: t.traceRecoveryDesc, color: "#c49332" },
            ] as TraceEntry[]}
          />
        </ScrollReveal>
      </SectionShell>
      </div>

      {/* ─── § 07 · THE CORRESPONDENCE ───────────────────────── */}
      <div id="ch-07" className="scroll-mt-10">
      <SectionShell tone="cream" size="standard">
        <div className="flex items-baseline justify-between gap-6">
          <ScrollReveal><ChapterMarker>{t.ch07}</ChapterMarker></ScrollReveal>
          <ScrollReveal>
            <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#8a7f76]">
              {t.dispatchLabel}
            </span>
          </ScrollReveal>
        </div>

        <motion.div
          className="mt-5 h-px origin-left bg-[#1d1b18]/15"
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />

        <ScrollReveal delay={0.1} className="mt-10 md:mt-16">
          <SectionHeadline scale="standard" maxCh={20} className="leading-[1.05]">{t.loopTitle}</SectionHeadline>
        </ScrollReveal>
        <ScrollReveal delay={0.15} className="mt-10 md:mt-14">
          <BodyProse maxCh={56}>{t.loopBody}</BodyProse>
        </ScrollReveal>

        {/* ─── Postmarks: quarterly loop as four stamps ─── */}
        <ScrollReveal delay={0.2} className="mt-14 md:mt-20">
          <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[2.4px] text-[#97472c]">
            {t.stampsLabel}
          </p>
        </ScrollReveal>
        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
          {loopSteps.map((step, i) => {
            const roman = ["I", "II", "III", "IV"][i];
            const isActive = activeLoopStep === i;
            const isPinned = pinnedLoopStep === i;
            return (
              <ScrollReveal key={step.num} delay={0.26 + i * 0.08}>
                <motion.button
                  type="button"
                  onClick={() => setPinnedLoopStep(isPinned ? null : i)}
                  onMouseEnter={() => setHoveredLoopStep(i)}
                  onMouseLeave={() => setHoveredLoopStep(null)}
                  onFocus={() => setHoveredLoopStep(i)}
                  onBlur={() => setHoveredLoopStep(null)}
                  aria-expanded={isPinned}
                  aria-label={locale === "es" ? step.label_es : step.label_en}
                  className="relative block w-full cursor-pointer px-5 py-6 text-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#97472c]/60 focus-visible:ring-offset-2 focus-visible:ring-offset-[#fef8f2] md:px-6 md:py-8"
                  style={{
                    border: isActive ? "1px double rgba(151,71,44,0.7)" : "1px double rgba(151,71,44,0.35)",
                    backgroundColor: isActive ? "rgba(254,248,242,0.95)" : "rgba(254,248,242,0.55)",
                  }}
                  whileHover={{
                    y: -3,
                    rotate: i % 2 === 0 ? -0.6 : 0.6,
                    boxShadow: "0 12px 28px -14px rgba(151,71,44,0.32)",
                  }}
                  animate={
                    isActive
                      ? { y: -3, rotate: i % 2 === 0 ? -0.6 : 0.6, boxShadow: "0 12px 28px -14px rgba(151,71,44,0.32)" }
                      : { y: 0, rotate: 0, boxShadow: "0 0 0 -14px rgba(151,71,44,0)" }
                  }
                  transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                >
                  {/* Perforation corner marks */}
                  <span className="absolute left-[4px] top-[4px] h-[3px] w-[3px] rounded-full bg-[#97472c]/55" aria-hidden />
                  <span className="absolute right-[4px] top-[4px] h-[3px] w-[3px] rounded-full bg-[#97472c]/55" aria-hidden />
                  <span className="absolute bottom-[4px] left-[4px] h-[3px] w-[3px] rounded-full bg-[#97472c]/55" aria-hidden />
                  <span className="absolute bottom-[4px] right-[4px] h-[3px] w-[3px] rounded-full bg-[#97472c]/55" aria-hidden />
                  <div>
                    <p
                      className="font-[family-name:var(--font-sentient)] italic leading-none text-[#97472c]"
                      style={{ fontSize: "28px" }}
                    >
                      {roman}
                    </p>
                    <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#1d1b18]">
                      {locale === "es" ? step.label_es : step.label_en}
                    </p>
                  </div>
                </motion.button>
              </ScrollReveal>
            );
          })}
        </div>

        {/* Description reveal: fixed-height panel below the grid, no layout shift */}
        <div className="mt-5 min-h-[128px] md:mt-6 md:min-h-[96px]">
          <AnimatePresence mode="wait">
            {activeLoopStep !== null && (
              <motion.div
                key={activeLoopStep}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                className="grid grid-cols-[auto_1fr] items-baseline gap-4 border-t border-[#97472c]/25 pt-5 md:gap-6"
              >
                <span
                  className="font-[family-name:var(--font-sentient)] italic leading-none text-[#97472c]"
                  style={{ fontSize: "22px" }}
                  aria-hidden
                >
                  {["I", "II", "III", "IV"][activeLoopStep]}
                </span>
                <div>
                  <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#1d1b18]">
                    {locale === "es" ? loopSteps[activeLoopStep].label_es : loopSteps[activeLoopStep].label_en}
                  </p>
                  <p className="mt-2 font-[family-name:var(--font-manrope)] leading-[1.6] text-[#2a2319]" style={{ fontSize: "14.5px" }}>
                    {locale === "es" ? loopSteps[activeLoopStep].desc_es : loopSteps[activeLoopStep].desc_en}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ─── Product preview: EVA AI chat (animated demo) ─── */}
        <div className="mt-20 md:mt-28">
          <EvaChatDemo
            title={t.chatTitle}
            subtitle={t.chatSubtitle}
            userLabel={t.chatUserLabel}
            evaLabel={t.chatEvaLabel}
            userMessage={t.aiUserMsg}
            evaMessage={t.aiEvaMsg}
            referencedLabel={t.chatReferencedLabel}
            ref1={t.chatRef1}
            ref2={t.chatRef2}
            inputPlaceholder={t.chatInputPlaceholder}
            sendLabel={t.chatInputSend}
          />
        </div>
      </SectionShell>
      </div>

      {/* ─── § 08 · THE INVITATION CARD ──────────────────────── */}
      <div id="ch-08" className="scroll-mt-10">
      <SectionShell tone="cream" size="xlarge">
        <div className="mx-auto max-w-[640px] text-center">
          {/* Top ornament: N° VIII pressmark */}
          <ScrollReveal>
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[3px] text-[#97472c]">
              {t.invitationLabel}
            </p>
          </ScrollReveal>

          {/* Thin rule that draws in */}
          <motion.div
            className="mx-auto mt-6 h-px w-24 origin-center bg-[#1d1b18]/30"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Invitation header — small italic */}
          <ScrollReveal delay={0.1} className="mt-6">
            <p className="font-[family-name:var(--font-sentient)] italic text-[#4c463f]" style={{ fontSize: "18px" }}>
              {t.invitationHeader}
            </p>
          </ScrollReveal>

          {/* Main headline — keep the hand-drawn underline solitary here */}
          <ScrollReveal delay={0.18} className="mt-8 md:mt-10">
            <SectionHeadline scale="grand" maxCh={16} balance={false} className="mx-auto">
              {ctaLeadWords}{" "}
              <span className="relative inline-block whitespace-nowrap">
                {ctaLastWord}
                <HandDrawnUnderline offset="md" />
              </span>
            </SectionHeadline>
          </ScrollReveal>

          {/* Lede */}
          <ScrollReveal delay={0.28} className="mt-10 md:mt-14">
            <LedeItalic maxCh={44} className="mx-auto">{t.ctaBody}</LedeItalic>
          </ScrollReveal>

          {/* CTA button */}
          <ScrollReveal delay={0.36} className="mt-10 md:mt-14">
            <CTAButton href={`/${locale}/signup`}>{t.ctaButton}</CTAButton>
          </ScrollReveal>

          {/* Bottom rule */}
          <motion.div
            className="mx-auto mt-16 h-px w-24 origin-center bg-[#1d1b18]/30 md:mt-20"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Sign-off */}
          <ScrollReveal delay={0.5} className="mt-6">
            <p className="font-[family-name:var(--font-sentient)] italic text-[#8a7f76]" style={{ fontSize: "13px" }}>
              {t.invitationClosing}
            </p>
          </ScrollReveal>
        </div>
      </SectionShell>
      </div>
    </div>
  );
}
