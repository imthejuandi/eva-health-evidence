import type { MatrixColumn, MatrixGroup } from "@/components/marketing/pricing-v2/ComparisonMatrix";
import type { FAQCategory } from "@/components/marketing/pricing-v2/FAQTabs";
import type { BiomarkerCategory } from "@/components/marketing/pricing-v2/BiomarkerGrid";

export type Locale = "en" | "es";

export interface PricingCopy {
  hero: {
    eyebrow: string;
    headline: string;
    highlightWord: string;
    subhead: string;
  };
  mostPopular: string;
  trustItems: { icon: "shield" | "lock" | "beaker"; label: string }[];
  plans: {
    free: PlanCopy;
    quarterly: PlanCopy;
    full: PlanCopy;
  };
  /**
   * Annual-billing variant of the quarterly plan (same product, yearly
   * price). Rendered as a secondary CTA inside the quarterly card. Price is
   * provisional (finance pending) — €396/year = 4 quarters, so NO savings
   * claim in the copy. Single place to edit when the final price lands.
   */
  annualOffer: { label: string };
  howItWorks: {
    eyebrow: string;
    headline: string;
    steps: { number: string; title: string; body: string; duration: string }[];
  };
  specimen: {
    eyebrow: string;
    headline: string;
    kicker: string;
    meta: { subject: string; cycle: string; specimen: string; received: string };
    rows: {
      code: string;
      name: string;
      value: string;
      unit: string;
      position: number;
      zoneMid: number;
      zoneWidth: number;
      status: "optimal" | "watch";
    }[];
    pullQuote: { kicker: string; body: string; attribution: string };
    signature: string;
  };
  comparison: {
    eyebrow: string;
    headline: string;
    columns: [MatrixColumn, MatrixColumn, MatrixColumn];
    groups: MatrixGroup[];
  };
  biomarkers: {
    eyebrow: string;
    headline: string;
    kicker: string;
    close: string;
    detects: string;
    range: string;
    matters: string;
    categories: Record<BiomarkerCategory, string>;
  };
  specialty: {
    eyebrow: string;
    headline: string;
    kicker: string;
    included: string;
    quote: string;
    addonSuffix: string;
    biomarkers: string;
    formEmailLabel: string;
    formEmailPlaceholder: string;
    formSubmit: string;
    formSuccess: string;
    formError: string;
  };
  social: {
    eyebrow: string;
    headline: string;
    stat: { value: string; label: string };
    testimonials: { quote: string; name: string; role: string; rating?: number }[];
    pressLabel: string;
    pressLogos: string[];
  };
  founders: {
    eyebrow: string;
    quote: string;
    attribution: string;
    role: string;
    aboutLabel: string;
    cmoName: string;
    cmoRole: string;
    cmoNote: string;
  };
  cancel: {
    eyebrow: string;
    headline: string;
    promises: { icon: "cancel" | "lock" | "sparkles"; title: string; body: string }[];
    cta: string;
  };
  faq: { eyebrow: string; headline: string; categories: FAQCategory[] };
  final: {
    eyebrow: string;
    headline: string;
    subhead: string;
    escapeHatch: string;
  };
  sticky: { cta: string; dismiss: string };
}

interface PlanCopy {
  eyebrow: string;
  name: string;
  price: string;
  priceSuffix?: string;
  tagline: string;
  features: string[];
  cta: string;
  footnote?: string;
}

const EN: PricingCopy = {
  hero: {
    eyebrow: "Pricing · 2026",
    headline: "Pick the plan that starts your clarity",
    highlightWord: "clarity",
    subhead:
      "Three ways to know what's actually happening in your body: from free reinterpretation of labs you already have, to quarterly at-home testing, to a complete lab workup.",
  },
  mostPopular: "Most popular",
  trustItems: [
    { icon: "shield", label: "Cancel anytime" },
    { icon: "lock", label: "Your data, your ownership" },
    { icon: "beaker", label: "Tested in Madrid" },
  ],
  plans: {
    free: {
      eyebrow: "Rx-00 · Free",
      name: "Upload your labs",
      price: "€0",
      priceSuffix: "forever",
      tagline: "Turn any provider's results into actionable insight, against longevity-optimized ranges.",
      features: [
        "Upload labs from any provider",
        "Reinterpretation against optimal ranges",
        "Biological Age estimate (if applicable)",
        "No subscription. No card.",
      ],
      cta: "Upload your labs",
      footnote: "No credit card required",
    },
    quarterly: {
      eyebrow: "Rx-01 · Quarterly",
      name: "EVA Quarterly",
      price: "€99",
      priceSuffix: "/quarter",
      tagline: "A new data point every quarter, the fastest way to see what's trending in your health.",
      features: [
        "13 core biomarkers, needle-free at-home kit",
        "Biological Age and trend tracking",
        "AI health assistant + narrative summaries",
        "Wearable integration",
        "Switch to a specialty panel any quarter",
      ],
      cta: "Start my quarter",
      footnote: "Cancel anytime. No commitment.",
    },
    // (annualOffer lives at the top level of the copy object, below)
    full: {
      eyebrow: "Rx-02 · Full panel",
      name: "Full Lab Panel",
      price: "€499",
      priceSuffix: "one-time",
      tagline: "The complete picture: 40+ biomarkers via a traditional blood draw at a partner lab.",
      features: [
        "40+ biomarkers across all categories",
        "Clinical blood draw at partner lab",
        "Full EVA reinterpretation and report",
        "Optional: add a quarterly subscription later",
      ],
      cta: "Book the full panel",
      footnote: "Single payment",
    },
  },
  annualOffer: { label: "Prefer one payment? €396/year, billed annually" },
  howItWorks: {
    eyebrow: "How it works",
    headline: "From doorstep to clarity in under a week.",
    steps: [
      {
        number: "01",
        duration: "2 min",
        title: "Order your kit",
        body: "Pick a plan; we ship a needle-free collection kit to your door in Madrid or anywhere in Spain.",
      },
      {
        number: "02",
        duration: "5 min",
        title: "Test at home",
        body: "Collect a small blood sample with the painless kit. Drop it at the nearest carrier point.",
      },
      {
        number: "03",
        duration: "72 hrs",
        title: "Read your report",
        body: "Receive 13 biomarkers reinterpreted against longevity ranges, plus your Biological Age and AI-guided next steps.",
      },
    ],
  },
  specimen: {
    eyebrow: "§ 03 · Specimen report",
    headline: "Your quarter, typeset.",
    kicker:
      "Every marker read against longevity-optimized ranges, not population averages. The mint band is the optimal zone. The dot is you.",
    meta: {
      subject: "M. Álvarez · 38y",
      cycle: "Q2 · 2026",
      specimen: "Rx-018-204",
      received: "04 · 18 · 2026",
    },
    rows: [
      {
        code: "ApoB",
        name: "Apolipoprotein B",
        value: "74",
        unit: "mg/dL",
        position: 52,
        zoneMid: 42,
        zoneWidth: 50,
        status: "optimal",
      },
      {
        code: "hs-CRP",
        name: "hs-CRP",
        value: "0.6",
        unit: "mg/L",
        position: 22,
        zoneMid: 20,
        zoneWidth: 30,
        status: "optimal",
      },
      {
        code: "GGT",
        name: "Gamma-glutamyl transferase",
        value: "16",
        unit: "U/L",
        position: 24,
        zoneMid: 22,
        zoneWidth: 30,
        status: "optimal",
      },
      {
        code: "ALT",
        name: "Alanine aminotransferase",
        value: "19",
        unit: "U/L",
        position: 30,
        zoneMid: 32,
        zoneWidth: 36,
        status: "optimal",
      },
      {
        code: "UA",
        name: "Uric acid",
        value: "4.6",
        unit: "mg/dL",
        position: 44,
        zoneMid: 45,
        zoneWidth: 34,
        status: "optimal",
      },
      {
        code: "Alb",
        name: "Albumin",
        value: "41",
        unit: "g/L",
        position: 56,
        zoneMid: 74,
        zoneWidth: 30,
        status: "watch",
      },
    ],
    pullQuote: {
      kicker: "§ EVA · Reading",
      body: "Your hs-CRP dropped 28% after you adjusted sleep. Hold the routine through Q2 and retest triglycerides next cycle.",
      attribution: "EVA · Quarterly narrative",
    },
    signature: "EVA · Quarterly Report · §",
  },
  comparison: {
    eyebrow: "Compare · Everything side by side",
    headline: "One honest table. No footnotes.",
    columns: [
      { id: "free", name: "Upload", price: "€0", priceSuffix: "forever" },
      { id: "quarterly", name: "Quarterly", price: "€99", priceSuffix: "/quarter", highlight: true },
      { id: "full", name: "Full Lab", price: "€499", priceSuffix: "one-time" },
    ],
    groups: [
      {
        title: "Testing",
        rows: [
          { label: "Reinterpretation against optimal ranges", cells: [true, true, true] },
          { label: "At-home collection kit (needle-free)", cells: [false, true, false] },
          { label: "Clinical blood draw at partner lab", cells: [false, false, true] },
          { label: "Biomarkers analyzed", cells: ["Uploaded", "13", "40+"] },
          { label: "Testing cadence", cells: ["Your own", "Quarterly", "One-time"] },
        ],
      },
      {
        title: "Insight",
        rows: [
          { label: "Biological Age calculation", cells: [false, true, true] },
          { label: "AI health assistant (EVA AI)", cells: [false, true, true] },
          { label: "Narrative health summaries", cells: [false, true, true] },
          { label: "Trend tracking across quarters", cells: [false, true, false] },
          { label: "Wearable integration", cells: [false, true, true] },
        ],
      },
      {
        title: "Flexibility",
        rows: [
          { label: "Switch to a specialty panel", cells: [false, true, false] },
          { label: "Add specialty panels (quote-based)", cells: [false, true, true] },
          { label: "Cancel anytime", cells: ["—", true, "—"] },
          { label: "Data export and ownership", cells: [true, true, true] },
        ],
      },
    ],
  },
  biomarkers: {
    eyebrow: "§ 05 · What we measure",
    headline: "Fifteen markers, chosen for what they reveal about aging.",
    kicker:
      "Each marker below is read against longevity-optimized ranges, not the population averages your GP uses. Tap a tile to see what it detects, its optimal range, and why it matters.",
    close: "Close",
    detects: "What it detects",
    range: "Optimal range",
    matters: "Why it matters",
    categories: {
      metabolic: "Metabolic",
      cardio: "Cardiovascular",
      nutrient: "Nutrient",
    },
  },
  specialty: {
    eyebrow: "§ 06 · Specialty panels",
    headline: "Go deeper on a specific system.",
    kicker:
      "Any quarter, swap your base panel for a deeper look at hormones, heart, thyroid, nutrients, inflammation, or liver. Some panels are included; some are add-ons; some are quote-based while we finalize lab partnerships.",
    included: "Included",
    quote: "Request a quote",
    addonSuffix: "/quarter",
    biomarkers: "biomarkers",
    formEmailLabel: "Email",
    formEmailPlaceholder: "you@email.com",
    formSubmit: "Send",
    formSuccess: "Got it. We'll reach out within 24 hours.",
    formError: "Please enter a valid email.",
  },
  social: {
    eyebrow: "Proof",
    headline: "Members are seeing what 'normal' missed.",
    // No fabricated social proof until real, verifiable data exists. The
    // SocialProof component hides each block (and the whole section) when empty.
    stat: { value: "", label: "" },
    testimonials: [],
    pressLabel: "",
    pressLogos: [],
  },
  founders: {
    eyebrow: "Why EVA exists",
    quote:
      "EVA is the service I wished I had when I started my own preventative care journey: one that doesn't just hand you data, but teaches you what it means and what to do about it.",
    attribution: "Juan Diego Lago",
    role: "Founder & CEO",
    aboutLabel: "Read the full story",
    // No Chief Medical Officer has been appointed. Do not present a fictional
    // one or claim medical-leadership review. FoundersBlock hides the CMO card
    // while these are empty.
    cmoName: "",
    cmoRole: "",
    cmoNote: "",
  },
  cancel: {
    eyebrow: "Our promise",
    headline: "A subscription that asks nothing from you beyond the truth.",
    promises: [
      {
        icon: "cancel",
        title: "Cancel anytime",
        body: "No contracts, no lock-in. Pause or cancel in one click; your history stays accessible.",
      },
      {
        icon: "lock",
        title: "Your data, your ownership",
        body: "Export everything at any time. We don't sell your data. Ever.",
      },
      {
        icon: "sparkles",
        title: "No hidden costs",
        body: "€99 is €99. Kits, shipping, AI, app access, and reinterpretation are all included.",
      },
    ],
    cta: "Start my quarter",
  },
  faq: {
    eyebrow: "Questions",
    headline: "Everything people ask before subscribing.",
    categories: [
      {
        id: "pricing",
        label: "Pricing",
        items: [
          {
            question: "Why €99/quarter and not €49/month?",
            answer:
              "Meaningful biomarker change happens on a 90-day horizon, not a 30-day one. Quarterly matches biology and keeps each cycle focused on one concrete health question.",
          },
          {
            question: "What's included in the €99?",
            answer:
              "13-biomarker panel, needle-free kit, shipping both ways, Biological Age, AI health assistant, narrative summaries, wearable integration, trend tracking, and full platform access.",
          },
          {
            question: "Can I pause my subscription?",
            answer:
              "Yes. Pause for a quarter, skip a cycle, or cancel outright, all in one click from the dashboard.",
          },
        ],
      },
      {
        id: "testing",
        label: "Testing",
        items: [
          {
            question: "Is the at-home kit really needle-free?",
            answer:
              "Yes. The 500µL collection device uses a micro-array that feels like a soft pressure: no syringe, no venous draw. Most members complete collection in under five minutes.",
          },
          {
            question: "Where do I drop off my sample?",
            answer:
              "Any major carrier point in Spain. The kit includes a prepaid, temperature-stable envelope.",
          },
          {
            question: "What if a result is outside the range?",
            answer:
              "Any biomarker in the Below Range or Above Range zones triggers an immediate flag with a clear recommendation to seek medical attention.",
          },
        ],
      },
      {
        id: "results",
        label: "Results",
        items: [
          {
            question: "When do I get my results?",
            answer:
              "Results are available in your dashboard within 72 hours of the lab receiving your sample, typically 5–7 days after you drop it off.",
          },
          {
            question: "What's the difference between the base panel and a specialty panel?",
            answer:
              "The base panel gives a general snapshot across metabolic, cardiovascular, and nutritional health. Specialty panels go deeper into one system: hormones, thyroid, inflammation, etc.",
          },
        ],
      },
      {
        id: "data",
        label: "Data & Privacy",
        items: [
          {
            question: "Who owns my data?",
            answer:
              "You do. You can export, delete, or share your data at any time. EVA does not sell, share, or use your data for advertising.",
          },
          {
            question: "Where is my data stored?",
            answer:
              "EU-based infrastructure under GDPR. Health data is encrypted at rest and in transit.",
          },
          {
            question: "Can I upload my labs without a subscription?",
            answer:
              "Yes. Free lab upload is permanent and unlimited, no subscription required.",
          },
        ],
      },
    ],
  },
  final: {
    eyebrow: "Begin",
    headline: "Three doors. All of them lead to clarity.",
    subhead:
      "Not ready to subscribe? Start by uploading an old lab result. We'll reinterpret it free, forever.",
    escapeHatch: "Upload an old lab result instead",
  },
  sticky: { cta: "Get started", dismiss: "Dismiss" },
};

const ES: PricingCopy = {
  hero: {
    eyebrow: "Precios · 2026",
    headline: "Elige el plan que empieza tu claridad",
    highlightWord: "claridad",
    subhead:
      "Tres formas de saber qué está pasando realmente en tu cuerpo: desde la reinterpretación gratuita de analíticas que ya tienes, hasta pruebas trimestrales en casa, hasta un análisis completo de laboratorio.",
  },
  mostPopular: "Más popular",
  trustItems: [
    { icon: "shield", label: "Cancela cuando quieras" },
    { icon: "lock", label: "Tus datos, tu propiedad" },
    { icon: "beaker", label: "Testado en Madrid" },
  ],
  plans: {
    free: {
      eyebrow: "Rx-00 · Gratis",
      name: "Sube tus analíticas",
      price: "€0",
      priceSuffix: "para siempre",
      tagline: "Convierte los resultados de cualquier proveedor en información accionable, contra rangos optimizados para longevidad.",
      features: [
        "Sube analíticas de cualquier proveedor",
        "Reinterpretación contra rangos óptimos",
        "Estimación de Edad Biológica (si aplica)",
        "Sin suscripción. Sin tarjeta.",
      ],
      cta: "Sube tus analíticas",
      footnote: "Sin tarjeta de crédito",
    },
    quarterly: {
      eyebrow: "Rx-01 · Trimestral",
      name: "EVA Trimestral",
      price: "€99",
      priceSuffix: "/trimestre",
      tagline: "Un nuevo punto de datos cada trimestre, la forma más rápida de ver qué tendencia sigue tu salud.",
      features: [
        "13 biomarcadores esenciales, kit sin aguja",
        "Edad Biológica y seguimiento de tendencias",
        "Asistente de salud con IA + resúmenes narrativos",
        "Integración con wearables",
        "Cambia a un panel especializado cada trimestre",
      ],
      cta: "Empezar mi trimestre",
      footnote: "Cancela cuando quieras. Sin compromiso.",
    },
    full: {
      eyebrow: "Rx-02 · Panel completo",
      name: "Panel Completo",
      price: "€499",
      priceSuffix: "pago único",
      tagline: "La imagen completa: 40+ biomarcadores vía extracción de sangre tradicional en laboratorio asociado.",
      features: [
        "40+ biomarcadores en todas las categorías",
        "Extracción clínica en laboratorio asociado",
        "Reinterpretación e informe EVA completos",
        "Opcional: añadir suscripción trimestral después",
      ],
      cta: "Reservar panel completo",
      footnote: "Pago único",
    },
  },
  annualOffer: { label: "¿Prefieres un solo pago? 396 €/año, facturado anualmente" },
  howItWorks: {
    eyebrow: "Cómo funciona",
    headline: "De la puerta a la claridad en menos de una semana.",
    steps: [
      {
        number: "01",
        duration: "2 min",
        title: "Pide tu kit",
        body: "Elige un plan; enviamos un kit de recolección sin aguja a Madrid o a cualquier punto de España.",
      },
      {
        number: "02",
        duration: "5 min",
        title: "Analízate en casa",
        body: "Recolecta una pequeña muestra de sangre con el kit indoloro. Déjala en el punto de mensajería más cercano.",
      },
      {
        number: "03",
        duration: "72 hrs",
        title: "Lee tu informe",
        body: "Recibe 13 biomarcadores reinterpretados contra rangos de longevidad, además de tu Edad Biológica y próximos pasos guiados por IA.",
      },
    ],
  },
  specimen: {
    eyebrow: "§ 03 · Informe especimen",
    headline: "Tu trimestre, tipografiado.",
    kicker:
      "Cada marcador se lee contra rangos optimizados para longevidad, no contra promedios poblacionales. La banda mint es la zona óptima. El punto eres tú.",
    meta: {
      subject: "M. Álvarez · 38a",
      cycle: "Q2 · 2026",
      specimen: "Rx-018-204",
      received: "18 · 04 · 2026",
    },
    rows: [
      {
        code: "ApoB",
        name: "Apolipoproteína B",
        value: "74",
        unit: "mg/dL",
        position: 52,
        zoneMid: 42,
        zoneWidth: 50,
        status: "optimal",
      },
      {
        code: "hs-PCR",
        name: "PCR Ultrasensible",
        value: "0,6",
        unit: "mg/L",
        position: 22,
        zoneMid: 20,
        zoneWidth: 30,
        status: "optimal",
      },
      {
        code: "GGT",
        name: "Gamma-glutamil transferasa",
        value: "16",
        unit: "U/L",
        position: 24,
        zoneMid: 22,
        zoneWidth: 30,
        status: "optimal",
      },
      {
        code: "ALT",
        name: "Alanina aminotransferasa",
        value: "19",
        unit: "U/L",
        position: 30,
        zoneMid: 32,
        zoneWidth: 36,
        status: "optimal",
      },
      {
        code: "UA",
        name: "Ácido úrico",
        value: "4,6",
        unit: "mg/dL",
        position: 44,
        zoneMid: 45,
        zoneWidth: 34,
        status: "optimal",
      },
      {
        code: "Alb",
        name: "Albúmina",
        value: "41",
        unit: "g/L",
        position: 56,
        zoneMid: 74,
        zoneWidth: 30,
        status: "watch",
      },
    ],
    pullQuote: {
      kicker: "§ EVA · Lectura",
      body: "Tu hs-PCR bajó un 28% tras ajustar el sueño. Mantén la rutina en Q2 y volvamos a medir triglicéridos el próximo ciclo.",
      attribution: "EVA · Narrativa trimestral",
    },
    signature: "EVA · Informe trimestral · §",
  },
  comparison: {
    eyebrow: "Compara · Todo lado a lado",
    headline: "Una tabla honesta. Sin letra pequeña.",
    columns: [
      { id: "free", name: "Subida", price: "€0", priceSuffix: "para siempre" },
      { id: "quarterly", name: "Trimestral", price: "€99", priceSuffix: "/trimestre", highlight: true },
      { id: "full", name: "Lab Completo", price: "€499", priceSuffix: "pago único" },
    ],
    groups: [
      {
        title: "Pruebas",
        rows: [
          { label: "Reinterpretación contra rangos óptimos", cells: [true, true, true] },
          { label: "Kit de recolección en casa (sin aguja)", cells: [false, true, false] },
          { label: "Extracción clínica en laboratorio asociado", cells: [false, false, true] },
          { label: "Biomarcadores analizados", cells: ["Los tuyos", "13", "40+"] },
          { label: "Cadencia de pruebas", cells: ["La tuya", "Trimestral", "Única"] },
        ],
      },
      {
        title: "Interpretación",
        rows: [
          { label: "Cálculo de Edad Biológica", cells: [false, true, true] },
          { label: "Asistente de salud con IA (EVA AI)", cells: [false, true, true] },
          { label: "Resúmenes narrativos de salud", cells: [false, true, true] },
          { label: "Seguimiento de tendencias por trimestre", cells: [false, true, false] },
          { label: "Integración con wearables", cells: [false, true, true] },
        ],
      },
      {
        title: "Flexibilidad",
        rows: [
          { label: "Cambiar a un panel especializado", cells: [false, true, false] },
          { label: "Añadir paneles especializados (con presupuesto)", cells: [false, true, true] },
          { label: "Cancelar cuando quieras", cells: ["—", true, "—"] },
          { label: "Exportar y poseer tus datos", cells: [true, true, true] },
        ],
      },
    ],
  },
  biomarkers: {
    eyebrow: "§ 05 · Qué medimos",
    headline: "Quince marcadores, elegidos por lo que revelan sobre el envejecimiento.",
    kicker:
      "Cada marcador se lee contra rangos optimizados para longevidad, no contra los promedios poblacionales de tu médico. Pulsa cualquier tarjeta para ver qué detecta, su rango óptimo y por qué importa.",
    close: "Cerrar",
    detects: "Qué detecta",
    range: "Rango óptimo",
    matters: "Por qué importa",
    categories: {
      metabolic: "Metabólico",
      cardio: "Cardiovascular",
      nutrient: "Nutricional",
    },
  },
  specialty: {
    eyebrow: "§ 06 · Paneles especializados",
    headline: "Profundiza en un sistema específico.",
    kicker:
      "Cada trimestre puedes cambiar tu panel base por una mirada más profunda: hormonas, corazón, tiroides, nutrientes, inflamación o hígado. Algunos están incluidos; otros son complementos; otros requieren presupuesto mientras finalizamos acuerdos.",
    included: "Incluido",
    quote: "Solicitar presupuesto",
    addonSuffix: "/trimestre",
    biomarkers: "biomarcadores",
    formEmailLabel: "Email",
    formEmailPlaceholder: "tu@email.com",
    formSubmit: "Enviar",
    formSuccess: "Recibido. Te contactaremos en 24 horas.",
    formError: "Por favor introduce un email válido.",
  },
  social: {
    eyebrow: "Prueba",
    headline: "Los miembros ven lo que 'normal' no veía.",
    // Sin pruebas sociales inventadas hasta tener datos reales y verificables.
    stat: { value: "", label: "" },
    testimonials: [],
    pressLabel: "",
    pressLogos: [],
  },
  founders: {
    eyebrow: "Por qué existe EVA",
    quote:
      "EVA es el servicio que hubiera querido cuando empecé mi propio camino de salud preventiva: uno que no solo te entrega datos, sino que te enseña qué significan y qué hacer con ellos.",
    attribution: "Juan Diego Lago",
    role: "Fundador y CEO",
    aboutLabel: "Lee la historia completa",
    // Aún no hay Director/a Médico/a nombrado: no mostrar uno ficticio ni
    // afirmar revisión por liderazgo médico.
    cmoName: "",
    cmoRole: "",
    cmoNote: "",
  },
  cancel: {
    eyebrow: "Nuestra promesa",
    headline: "Una suscripción que no te pide nada más que la verdad.",
    promises: [
      {
        icon: "cancel",
        title: "Cancela cuando quieras",
        body: "Sin contratos, sin compromiso. Pausa o cancela con un clic; tu historial sigue accesible.",
      },
      {
        icon: "lock",
        title: "Tus datos, tu propiedad",
        body: "Exporta todo cuando quieras. No vendemos tus datos. Nunca.",
      },
      {
        icon: "sparkles",
        title: "Sin costes ocultos",
        body: "€99 son €99. Kits, envío, IA, acceso a la app y reinterpretación están incluidos.",
      },
    ],
    cta: "Empezar mi trimestre",
  },
  faq: {
    eyebrow: "Preguntas",
    headline: "Todo lo que preguntan antes de suscribirse.",
    categories: [
      {
        id: "pricing",
        label: "Precios",
        items: [
          {
            question: "¿Por qué €99/trimestre y no €49/mes?",
            answer:
              "Los cambios significativos en biomarcadores ocurren en ventanas de 90 días, no de 30. Lo trimestral encaja con la biología y mantiene cada ciclo centrado en una pregunta concreta de salud.",
          },
          {
            question: "¿Qué incluyen los €99?",
            answer:
              "Panel de 13 biomarcadores, kit sin aguja, envío en ambas direcciones, Edad Biológica, asistente de salud con IA, resúmenes narrativos, integración con wearables, seguimiento de tendencias y acceso completo a la plataforma.",
          },
          {
            question: "¿Puedo pausar mi suscripción?",
            answer:
              "Sí. Pausa un trimestre, salta un ciclo o cancela directamente, todo con un clic desde el panel.",
          },
        ],
      },
      {
        id: "testing",
        label: "Pruebas",
        items: [
          {
            question: "¿Realmente el kit en casa no tiene aguja?",
            answer:
              "Sí. El dispositivo de recolección de 500µL usa un micro-array que se siente como una presión suave: sin jeringa, sin extracción venosa. La mayoría completa la recolección en menos de cinco minutos.",
          },
          {
            question: "¿Dónde dejo mi muestra?",
            answer:
              "En cualquier punto de mensajería importante de España. El kit incluye un sobre prepagado y estable en temperatura.",
          },
          {
            question: "¿Y si un resultado sale fuera del rango?",
            answer:
              "Cualquier biomarcador en zonas Por Debajo del Rango o Por Encima del Rango activa una alerta inmediata con recomendación clara de buscar atención médica.",
          },
        ],
      },
      {
        id: "results",
        label: "Resultados",
        items: [
          {
            question: "¿Cuándo recibo mis resultados?",
            answer:
              "Los resultados están disponibles en tu panel dentro de 72 horas de que el laboratorio reciba la muestra, típicamente 5–7 días después de dejarla en mensajería.",
          },
          {
            question: "¿Diferencia entre panel base y especializado?",
            answer:
              "El panel base da una visión general de salud metabólica, cardiovascular y nutricional. Los especializados profundizan en un sistema: hormonas, tiroides, inflamación, etc.",
          },
        ],
      },
      {
        id: "data",
        label: "Datos y privacidad",
        items: [
          {
            question: "¿Quién posee mis datos?",
            answer:
              "Tú. Puedes exportar, eliminar o compartir tus datos cuando quieras. EVA no los vende, comparte ni usa para publicidad.",
          },
          {
            question: "¿Dónde se guardan mis datos?",
            answer:
              "En infraestructura europea bajo GDPR. Los datos de salud están cifrados en reposo y en tránsito.",
          },
          {
            question: "¿Puedo subir mis analíticas sin suscripción?",
            answer:
              "Sí. La subida gratuita es permanente e ilimitada, sin suscripción necesaria.",
          },
        ],
      },
    ],
  },
  final: {
    eyebrow: "Empieza",
    headline: "Tres puertas. Todas llevan a la claridad.",
    subhead:
      "¿Aún no quieres suscribirte? Empieza subiendo una analítica antigua. La reinterpretaremos gratis, para siempre.",
    escapeHatch: "Subir una analítica antigua",
  },
  sticky: { cta: "Empezar", dismiss: "Cerrar" },
};

export function getCopy(locale: Locale): PricingCopy {
  return locale === "es" ? ES : EN;
}
