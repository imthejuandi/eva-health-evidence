import { createClient } from "@/lib/supabase/server";
import { shownAsValueOnly } from "@/lib/biomarkers/lab-reported";
import { redirect } from "next/navigation";
import { ManageLabsClient } from "./manage-client";

interface ManageLabsPageProps {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ lab?: string }>;
}

export default async function ManageLabsPage({
  params,
  searchParams,
}: ManageLabsPageProps) {
  const { locale } = await params;
  const { lab: labParam } = await searchParams;

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect(`/${locale}/login`);

  // All lab_results for this user, newest first
  const { data: allLabs } = await supabase
    .from("lab_results")
    .select("id, collection_date, source, status, created_at")
    .eq("user_id", user.id)
    .order("collection_date", { ascending: false })
    .order("created_at", { ascending: false });

  const labs = allLabs ?? [];
  // Pick the lab to show: either the one in the query string or the newest
  const selectedLabId = labParam && labs.some((l) => l.id === labParam)
    ? labParam
    : labs[0]?.id ?? null;

  // Load biomarker_values for the selected lab
  const { data: biomarkers } = selectedLabId
    ? await supabase
        .from("biomarker_values")
        .select("id, biomarker_key, biomarker_name, value, unit, zone, created_at")
        .eq("lab_result_id", selectedLabId)
        .order("biomarker_name", { ascending: true })
    : { data: [] };

  return (
    <ManageLabsClient
      locale={locale}
      labs={labs}
      selectedLabId={selectedLabId}
      biomarkers={(biomarkers ?? []).map(shownAsValueOnly)}
    />
  );
}
