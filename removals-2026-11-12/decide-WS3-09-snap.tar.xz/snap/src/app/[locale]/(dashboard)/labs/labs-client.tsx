"use client";

import { useState, useMemo } from "react";
import { PendingResultsNotice, type PendingLab } from "@/components/dashboard/PendingResultsNotice";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  DashboardChrome,
  ScrollSnapCarousel,
  EditorialMasthead,
  PrimaryPill,
  GhostLink,
  MedicalDisclaimer,
  OutOfRangeNotice,
} from "@/components/dashboard";
import { fadeUp, staggerTight } from "@/lib/dashboard-motion";
import {
  FONT_CLASS,
  BIOMARKER_CATEGORY_COLORS,
  ACTION_CATEGORY_COLORS,
} from "@/lib/dashboard-tokens";
import {
  yearRoman,
  formatDayMonth,
  fmtMeasured,
  formatCategoryLabel,
} from "@/lib/dashboard-format";
import type { Profile, LabResult, BiomarkerValue, ActionStep } from "@/lib/queries/types";
import { KDM_REFERENCE_BA_METHOD } from "@/lib/biomarkers/bio-age-method";

interface LabHistoryItem {
  id: string;
  collection_date: string;
  source: string;
  status: string;
  biological_age: number | null;
  longevity_score: number | null;
}

interface LabsClientProps {
  locale: string;
  profile: Profile | null;
  latestLab: LabResult | null;
  biomarkers: BiomarkerValue[];
  actionSteps: ActionStep[];
  allLabs: LabHistoryItem[];
  /** Results waiting for the patient's per-draw context (bridge or webhook). */
  pendingLabs?: PendingLab[];
}

type FilterTab = "all" | "optimal" | "attention" | "action";

function calculateAge(dob: string): number {
  const birth = new Date(dob);
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

interface CategoryMeta {
  en: string;
  es: string;
  lede_en: string;
  lede_es: string;
}

const CATEGORY_META: Record<string, CategoryMeta> = {
  cardiovascular: {
    en: "Cardiovascular",
    es: "Cardiovascular",
    lede_en: "How your heart and vessels are holding up.",
    lede_es: "Como estan aguantando tu corazon y tus vasos.",
  },
  metabolic: {
    en: "Metabolic",
    es: "Metabolico",
    lede_en: "Sugar, lipids, and how you fuel a day.",
    lede_es: "Azucar, lipidos y como te alimentas durante el dia.",
  },
  hormonal: {
    en: "Hormonal",
    es: "Hormonal",
    lede_en: "The chemistry that governs mood, energy, drive.",
    lede_es: "La quimica que gobierna humor, energia e impulso.",
  },
  thyroid: {
    en: "Thyroid",
    es: "Tiroides",
    lede_en: "The metabolic thermostat.",
    lede_es: "El termostato metabolico.",
  },
  inflammatory: {
    en: "Inflammatory",
    es: "Inflamatorio",
    lede_en: "Background fire — the silent erosion.",
    lede_es: "Fuego de fondo — la erosion silenciosa.",
  },
  nutrition: {
    en: "Nutrition",
    es: "Nutricion",
    lede_en: "Vitamins, minerals, the building blocks.",
    lede_es: "Vitaminas, minerales, los ladrillos.",
  },
  liver: {
    en: "Liver",
    es: "Higado",
    lede_en: "The body's quiet refinery.",
    lede_es: "La refineria silenciosa del cuerpo.",
  },
  kidney: {
    en: "Kidney",
    es: "Rinon",
    lede_en: "How well you filter and balance.",
    lede_es: "Como filtras y mantienes el equilibrio.",
  },
  immune: {
    en: "Immune",
    es: "Inmune",
    lede_en: "Your defence in numbers.",
    lede_es: "Tu defensa en numeros.",
  },
};

function categoryLabel(category: string, locale: string): string {
  const meta = CATEGORY_META[category];
  if (meta) return locale === "es" ? meta.es : meta.en;
  return category.charAt(0).toUpperCase() + category.slice(1).replace(/_/g, " ");
}

function categoryLede(category: string, locale: string): string | null {
  const meta = CATEGORY_META[category];
  if (!meta) return null;
  return locale === "es" ? meta.lede_es : meta.lede_en;
}

function categoryAccent(category: string): string {
  return BIOMARKER_CATEGORY_COLORS[category] ?? "#3a665e";
}

function zoneAccent(zone: string): { stroke: string; tone: string; label: { en: string; es: string } } {
  if (zone === "optimal")
    return { stroke: "#3a665e", tone: "rgba(58,102,94,0.12)", label: { en: "Optimal", es: "Optimo" } };
  if (zone === "below_optimal" || zone === "above_optimal")
    return { stroke: "#c49332", tone: "rgba(196,147,50,0.14)", label: { en: "Attention", es: "Atencion" } };
  if (zone === "critical_low" || zone === "critical_high")
    return { stroke: "#b04040", tone: "rgba(176,64,64,0.14)", label: { en: "Out of range", es: "Fuera de rango" } };
  return { stroke: "#8a7f76", tone: "rgba(138,127,118,0.10)", label: { en: "—", es: "—" } };
}

/* ──────────────────────────────────────────────────────────────────────
 * EditorialZoneBar — replaces ZoneSummaryTiles. A single horizontal
 * proportion bar split into three zone-coloured segments, with
 * monumental serif numerals above and mono labels beneath. Reads as a
 * seismograph, not three identical boxes.
 * ────────────────────────────────────────────────────────────────────── */
function EditorialZoneBar({
  optimal,
  attention,
  action,
  locale,
}: {
  optimal: number;
  attention: number;
  action: number;
  locale: string;
}) {
  const total = Math.max(optimal + attention + action, 1);
  const pct = (n: number) => Math.max((n / total) * 100, n > 0 ? 6 : 0);
  const segments = [
    {
      n: optimal,
      pct: pct(optimal),
      stroke: "#3a665e",
      label: locale === "es" ? "Optimo" : "Optimal",
    },
    {
      n: attention,
      pct: pct(attention),
      stroke: "#c49332",
      label: locale === "es" ? "Atencion" : "Attention",
    },
    {
      n: action,
      pct: pct(action),
      stroke: "#b04040",
      label: locale === "es" ? "Fuera de rango" : "Out of range",
    },
  ];

  return (
    <div>
      <div className="flex items-end justify-between gap-4">
        {segments.map((s) => (
          <div key={s.label} className="min-w-0 flex-1">
            <p
              className={`${FONT_CLASS.cormorant} text-[44px] font-medium leading-none tabular-nums tracking-[-1px] md:text-[64px] md:tracking-[-2px]`}
              style={{ color: s.stroke }}
            >
              {s.n}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-4 flex h-[2px] w-full overflow-hidden md:mt-5">
        {segments.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.0, delay: 0.1 + i * 0.12, ease: [0.16, 1, 0.3, 1] }}
            style={{
              width: `${s.pct}%`,
              backgroundColor: s.stroke,
              transformOrigin: "left",
            }}
          />
        ))}
      </div>

      <div className="mt-3 flex items-start justify-between gap-4">
        {segments.map((s) => (
          <p
            key={s.label}
            className={`min-w-0 flex-1 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
          >
            {s.label}
          </p>
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * BroadsheetRow — replaces the bordered-card BiomarkerRow with a plain
 * baseline-rule row. A vertical zone-coloured bar slides in from the
 * left on hover; the value sits in tabular DM Mono on the right with
 * an animated underline. No card chrome, no chevron.
 * ────────────────────────────────────────────────────────────────────── */
function BroadsheetRow({
  name,
  value,
  unit,
  comparator,
  zone,
  index,
  locale,
  onClick,
}: {
  name: string;
  value: number;
  unit: string;
  /** "<" / ">" for a bounded value as the lab reported it. */
  comparator?: string | null;
  zone: string;
  index: number;
  locale: string;
  onClick?: () => void;
}) {
  const z = zoneAccent(zone);
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        animationDelay: `${index * 30}ms`,
        animation: "labRowIn 0.5s cubic-bezier(0.16,1,0.3,1) both",
      }}
      className="group relative flex w-full items-baseline gap-4 border-b border-[#1d1b18]/10 py-4 text-left transition-colors duration-300 hover:bg-[rgba(151,71,44,0.025)]"
    >
      {/* Zone bar — vertical, animates in on hover */}
      <span
        aria-hidden
        className="absolute left-0 top-1/2 h-[60%] w-[2px] origin-center -translate-y-1/2 scale-y-50 opacity-0 transition-all duration-300 group-hover:scale-y-100 group-hover:opacity-100"
        style={{ backgroundColor: z.stroke }}
      />

      {/* Name + zone label */}
      <div className="min-w-0 flex-1">
        <p
          className={`truncate ${FONT_CLASS.cormorant} text-[19px] font-medium leading-tight text-[#1d1b18] md:text-[22px]`}
        >
          {name}
        </p>
        <p
          className={`mt-1 ${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.8px]`}
          style={{ color: z.stroke }}
        >
          {locale === "es" ? z.label.es : z.label.en}
        </p>
      </div>

      {/* Value + unit, tabular */}
      <div className="shrink-0 text-right">
        <span
          className={`${FONT_CLASS.dmMono} text-[18px] font-medium tabular-nums text-[#1d1b18] md:text-[22px]`}
        >
          {fmtMeasured(value, comparator)}
        </span>
        <span
          className={`ml-1.5 ${FONT_CLASS.dmMono} text-[10px] tracking-[1.2px] text-[#8a7f76]`}
        >
          {unit}
        </span>
        {/* Underline — slides in on hover */}
        <span
          aria-hidden
          className="mt-1 block h-[1px] origin-right scale-x-0 bg-[#97472c] transition-transform duration-300 group-hover:origin-left group-hover:scale-x-100"
        />
      </div>

      <style jsx>{`
        @keyframes labRowIn {
          from { opacity: 0; transform: translateY(6px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </button>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * BroadsheetBioAge — replaces the green double-bezel orb. Treats the
 * biological age reading as a magazine cover stat: monumental italic
 * Cormorant numeral, italic "years" hung at the bottom-right of the
 * decimal, hairline-divided comparison strip below carrying the
 * chronological age and the delta.
 * ────────────────────────────────────────────────────────────────────── */
function BroadsheetBioAge({
  bioAge,
  realAge,
  bioAgeMethod,
  locale,
}: {
  bioAge: number;
  realAge: number;
  /** lab_results.bio_age_method: the creatine note describes the rules of KDM_REFERENCE_BA_METHOD figures only. */
  bioAgeMethod: string | null;
  locale: string;
}) {
  const diff = Math.round((realAge - bioAge) * 10) / 10;
  const positive = diff > 0;
  const accent = positive ? "#3a665e" : diff < 0 ? "#97472c" : "#1d1b18";
  const whole = Math.floor(bioAge);
  const dec = Math.round((bioAge - whole) * 10);

  const t =
    locale === "es"
      ? {
          kicker: "§ Edad biológica estimada",
          years: "años",
          chrono: "Edad cronológica",
          younger: "más joven",
          older: "mayor",
          matched: "iguales",
          yr: "años",
          creatineNote:
            "¿Tomas creatina? Indica tu dosis diaria en gramos al confirmar el contexto de tu próxima analítica y ajustaremos su creatinina. En ensayos con adultos sanos, la creatina sube la creatinina en sangre sin cambiar el filtrado renal medido. Si la tomas y no indicas tu dosis diaria, la cifra sale más alta. Esta cifra usa el contexto guardado con esta analítica o, si no lo hay, el que tenías cuando se registró.",
        }
      : {
          kicker: "§ Estimated biological age",
          years: "years",
          chrono: "Chronological",
          younger: "younger",
          older: "older",
          matched: "matched",
          yr: "yr",
          creatineNote:
            "Taking creatine? Give your daily dose in grams when you confirm the context of your next lab, and we will adjust its creatinine. In trials in healthy adults, creatine raised blood creatinine without changing measured kidney filtration. If you take it and do not give your daily dose, the figure reads higher. This figure uses the context saved with this lab or, if there is none, the one you had when it was entered.",
        };

  return (
    <div className="relative">
      <p
        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
      >
        {t.kicker}
      </p>

      <div className="relative mt-4">
        <p
          className={`${FONT_CLASS.cormorant} font-medium leading-[0.82] tabular-nums text-[112px] tracking-[-4px] md:text-[156px] md:tracking-[-6px]`}
          style={{ color: accent }}
        >
          {whole}
          {dec > 0 && (
            <span style={{ color: accent, opacity: 0.4 }}>.{dec}</span>
          )}
        </p>
        <span
          className={`absolute -bottom-1 left-full ml-2 ${FONT_CLASS.cormorant} text-[18px] italic md:bottom-3 md:text-[22px]`}
          style={{ color: accent, opacity: 0.7 }}
        >
          {t.years}
        </span>
      </div>

      <div className="mt-7 flex items-baseline gap-3 border-t border-[#1d1b18]/15 pt-4">
        <span
          className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.8px] text-[#8a7f76]`}
        >
          {t.chrono}
        </span>
        <span
          className={`${FONT_CLASS.cormorant} text-[26px] font-medium leading-none tabular-nums text-[#1d1b18]`}
        >
          {realAge}
        </span>
        <span aria-hidden className="ml-auto h-px w-6 bg-[#1d1b18]/20" />
        <span
          className={`${FONT_CLASS.cormorant} text-[16px] italic md:text-[18px]`}
          style={{ color: accent }}
        >
          {Math.abs(diff)} {t.yr}{" "}
          {diff === 0 ? t.matched : positive ? t.younger : t.older}
        </span>
      </div>

      {bioAgeMethod === KDM_REFERENCE_BA_METHOD && (
        <p className={`mt-4 max-w-[46ch] ${FONT_CLASS.manrope} text-[12px] leading-[1.6] text-[#8a7f76]`}>
          {t.creatineNote}
        </p>
      )}
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * BroadsheetActionCard — replaces the global ActionStepCard inside Labs.
 * Strips the bordered, shadowed, pill-tagged "card" entirely. What is
 * left: a hairline top rule, a serif chapter numeral hung in the
 * gutter at low opacity, a category kicker (mono, hairline lead-in),
 * a serif Cormorant title, body prose, and (when complete) a hairline
 * strip footer with a mono "Done" mark.
 * ────────────────────────────────────────────────────────────────────── */
function BroadsheetActionCard({
  priority,
  category,
  title,
  description,
  status,
  locale,
}: {
  priority: number;
  category: string;
  title: string;
  description: string;
  status: string;
  locale: string;
}) {
  const isCompleted = status === "completed";
  const accent = ACTION_CATEGORY_COLORS[category] ?? "#8a7f76";
  const num = String(priority).padStart(2, "0");
  const doneLabel = locale === "es" ? "Hecho" : "Done";

  return (
    <article
      className={`group relative flex h-full flex-col overflow-hidden border-t border-[#1d1b18]/20 pt-6 transition-all duration-300 md:pt-8 ${
        isCompleted ? "opacity-55" : ""
      }`}
    >
      {/* Hanging serif numeral — chapter glyph */}
      <span
        aria-hidden
        className={`pointer-events-none absolute -top-3 right-0 select-none ${FONT_CLASS.cormorant} text-[110px] font-medium italic leading-[0.78] tabular-nums text-[#1d1b18]/[0.06] transition-opacity duration-300 group-hover:text-[#1d1b18]/[0.10] md:-top-4 md:text-[160px]`}
      >
        {num}
      </span>

      {/* Top: category kicker with hairline lead */}
      <div className="relative flex items-center gap-3">
        <span
          aria-hidden
          className="h-px w-6"
          style={{ backgroundColor: accent, opacity: 0.55 }}
        />
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px]`}
          style={{ color: accent }}
        >
          {category}
        </p>
      </div>

      {/* Title — serif */}
      <h3
        className={`relative mt-5 ${FONT_CLASS.cormorant} text-[26px] font-medium leading-[1.05] tracking-[-0.4px] text-[#1d1b18] md:text-[30px] md:leading-[1.04] ${
          isCompleted ? "line-through decoration-[#3a665e]/40 decoration-1" : ""
        }`}
        style={{ textWrap: "balance" } as React.CSSProperties}
      >
        {title}
      </h3>

      {/* Description */}
      <p
        className={`relative mt-4 ${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#4c463f] md:text-[15px]`}
        style={{ textWrap: "pretty" } as React.CSSProperties}
      >
        {description}
      </p>

      {/* Footer — hairline + completion mark */}
      <div className="relative mt-auto flex items-center gap-3 pt-6">
        <span aria-hidden className="h-px flex-1 bg-[#1d1b18]/12" />
        {isCompleted ? (
          <span
            className={`flex items-center gap-1.5 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#3a665e]`}
          >
            <svg
              aria-hidden
              className="h-3 w-3"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={2}
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4.5 12.75l6 6 9-13.5"
              />
            </svg>
            {doneLabel}
          </span>
        ) : (
          <span
            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]`}
          >
            № {num}
          </span>
        )}
      </div>
    </article>
  );
}

export function LabsClient({
  locale,
  profile,
  latestLab,
  biomarkers,
  actionSteps,
  allLabs, pendingLabs = [],
}: LabsClientProps) {
  const router = useRouter();
  const [filter, setFilter] = useState<FilterTab>("all");
  const [search, setSearch] = useState("");

  const t =
    locale === "es"
      ? {
          title: "Mis analisis",
          emptyKickerLeft: "§ Despacho · Pendiente",
          emptyBlueprintTitle: "Despacho preliminar",
          emptyKickerRight: "§ II — Empezar",
          emptyTitle: "Tu historia de salud empieza",
          emptyTitleAccent: "aqui.",
          emptyMsg:
            "Sube analisis existentes o pide tu primer kit EVA. Vamos a interpretar cada biomarcador contra los rangos optimos de longevidad y a contarte que esta dentro y que no.",
          upload: "Subir analisis",
          book: "Pedir kit",
          manage: "Archivo",
          all: "Todos",
          optimal: "Optimo",
          attention: "Atencion",
          action: "Fuera de rango",
          search: "Buscar biomarcador",
          actionStepsTitle: "Pasos de accion",
          lsLabel: "Longevity Score",
          history: "Historial",
          drawn: "Extraido",
          noResults: "Ningun biomarcador coincide con tu filtro.",
          kickerDispatch: "§ I — Ultimo despacho",
          dispatchTitle: "Tu ultima",
          dispatchAccent: "lectura.",
          kickerActions: "§ II — Que toca ahora",
          actionsTitle: "Pasos para",
          actionsAccent: "esta semana.",
          kickerPanel: "§ III — El panel",
          panelTitle: "Por categoria, en",
          panelAccent: "estratos.",
          panelSubtitle: "Pulsa cualquier marcador para abrir su pagina dedicada",
          biomarkerCount: "marcadores",
          observations: "Observaciones",
          footerTitle: "Vuelve cada trimestre.",
          footerAccent: "La biologia premia la constancia.",
          backToLabs: "Volver",
        }
      : {
          title: "My labs",
          emptyKickerLeft: "§ Dispatch · Pending",
          emptyBlueprintTitle: "Preliminary dispatch",
          emptyKickerRight: "§ II — Begin",
          emptyTitle: "Your health story starts",
          emptyTitleAccent: "here.",
          emptyMsg:
            "Upload existing lab results or order your first EVA kit. We'll interpret every biomarker against longevity-optimal ranges and tell you what's in range and what isn't.",
          upload: "Upload labs",
          book: "Order kit",
          manage: "Archive",
          all: "All",
          optimal: "Optimal",
          attention: "Attention",
          action: "Out of range",
          search: "Search biomarker",
          actionStepsTitle: "Action steps",
          lsLabel: "Longevity Score",
          history: "History",
          drawn: "Drawn",
          noResults: "No biomarkers match your filter.",
          kickerDispatch: "§ I — Latest dispatch",
          dispatchTitle: "Your latest",
          dispatchAccent: "reading.",
          kickerActions: "§ II — What to do",
          actionsTitle: "Steps for",
          actionsAccent: "this week.",
          kickerPanel: "§ III — The panel",
          panelTitle: "By category, in",
          panelAccent: "strata.",
          panelSubtitle: "Tap any marker for its dedicated page",
          biomarkerCount: "markers",
          observations: "Observations",
          footerTitle: "Come back each quarter.",
          footerAccent: "Biology rewards consistency.",
          backToLabs: "Back",
        };

  const filtered = useMemo(() => {
    let list = biomarkers;
    if (filter === "optimal") list = list.filter((b) => b.zone === "optimal");
    else if (filter === "attention")
      list = list.filter(
        (b) => b.zone === "below_optimal" || b.zone === "above_optimal",
      );
    else if (filter === "action")
      list = list.filter(
        (b) => b.zone === "critical_low" || b.zone === "critical_high",
      );
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (b) =>
          b.biomarker_name?.toLowerCase().includes(q) ||
          b.biomarker_key.toLowerCase().includes(q),
      );
    }
    return list;
  }, [biomarkers, filter, search]);

  const grouped = useMemo(() => {
    const map = new Map<string, BiomarkerValue[]>();
    for (const b of filtered) {
      const key = b.category && b.category !== "uncategorized" ? b.category : "other";
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(b);
    }
    const order = Array.from(map.keys()).sort((a, b) => {
      if (a === "other") return 1;
      if (b === "other") return -1;
      return categoryLabel(a, "en").localeCompare(categoryLabel(b, "en"));
    });
    return order.map((cat) => ({ category: cat, items: map.get(cat)! }));
  }, [filtered]);

  const optimalCount = biomarkers.filter((b) => b.zone === "optimal").length;
  const attentionCount = biomarkers.filter(
    (b) => b.zone === "below_optimal" || b.zone === "above_optimal",
  ).length;
  const actionCount = biomarkers.filter(
    (b) => b.zone === "critical_low" || b.zone === "critical_high",
  ).length;

  if (!latestLab) {
    return (
      <DashboardChrome>
        <div className="px-5 py-12 md:px-10 md:py-20">
          <div className="mx-auto max-w-[1200px]">
            <EditorialMasthead issue={locale === "es" ? "Lecturas trimestrales" : "Quarterly readings"} withQuarter />
            <PendingResultsNotice locale={locale} pending={pendingLabs} />
            <motion.div variants={fadeUp} className="mt-16">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
              >
                {t.kickerDispatch}
              </p>
              <h1
                className={`mt-3 max-w-[14ch] ${FONT_CLASS.cormorant} text-[44px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[88px] md:tracking-[-2px]`}
              >
                {t.dispatchTitle}{" "}
                <span className="italic text-[#97472c]">{t.dispatchAccent}</span>
              </h1>
            </motion.div>
            {/* Editorial empty dispatch — a "preliminary" blueprint
                of what the user's first reading will look like, paired
                with a copy block and the two real entry CTAs. */}
            <motion.div
              variants={fadeUp}
              className="mt-14 grid gap-10 md:mt-16 md:grid-cols-12 md:gap-12"
            >
              {/* Left — hairline blueprint card (double-bezel) */}
              <div className="md:col-span-7">
                <div
                  className="rounded-[28px] p-1.5"
                  style={{
                    backgroundColor: "rgba(254,248,242,0.45)",
                    boxShadow: "inset 0 0 0 1px rgba(29,27,24,0.07)",
                  }}
                >
                  <div
                    className="rounded-[22px] bg-[#fef8f2] p-7 md:p-9"
                    style={{ boxShadow: "inset 0 1px 0 0 rgba(255,255,255,0.7)" }}
                  >
                    <p
                      className={`${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[2px] text-[#97472c]/55`}
                    >
                      {t.emptyKickerLeft}
                    </p>
                    <h3
                      className={`mt-3 ${FONT_CLASS.cormorant} text-[28px] font-medium leading-[1.05] tracking-[-0.4px] text-[#1d1b18] md:text-[36px]`}
                    >
                      {t.emptyBlueprintTitle}
                    </h3>

                    <ul className="mt-7 divide-y divide-[#1d1b18]/[0.07]">
                      {[1, 2, 3, 4, 5].map((i) => {
                        const widths = ["52%", "68%", "44%", "76%", "60%"];
                        return (
                          <li
                            key={i}
                            className="flex items-center justify-between gap-5 py-3.5"
                          >
                            <div className="flex flex-1 items-center gap-4">
                              <span
                                className={`${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.6px] text-[#1d1b18]/30 tabular-nums`}
                              >
                                {String(i).padStart(2, "0")}
                              </span>
                              <span
                                aria-hidden
                                className="block h-[6px] rounded-full bg-[#1d1b18]/[0.06]"
                                style={{ width: widths[i - 1] }}
                              />
                            </div>
                            <span
                              className={`${FONT_CLASS.dmMono} text-[12px] tabular-nums text-[#1d1b18]/30`}
                            >
                              —
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Right — copy + CTAs */}
              <div className="flex flex-col justify-center md:col-span-5">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
                >
                  {t.emptyKickerRight}
                </p>
                <h3
                  className={`mt-4 ${FONT_CLASS.cormorant} text-[36px] font-medium leading-[1.0] tracking-[-0.5px] text-[#1d1b18] md:text-[48px]`}
                  style={{ textWrap: "balance" } as React.CSSProperties}
                >
                  {t.emptyTitle}{" "}
                  <span className="italic text-[#97472c]">{t.emptyTitleAccent}</span>
                </h3>
                <p
                  className={`mt-5 max-w-[40ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#4c463f] md:text-[15px]`}
                  style={{ textWrap: "pretty" } as React.CSSProperties}
                >
                  {t.emptyMsg}
                </p>
                <div className="mt-8 flex flex-wrap items-center gap-5">
                  <PrimaryPill href={`/${locale}/upload`}>{t.upload}</PrimaryPill>
                  <GhostLink href={`/${locale}/book`}>{t.book}</GhostLink>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </DashboardChrome>
    );
  }

  const realAge = profile?.date_of_birth ? calculateAge(profile.date_of_birth) : null;
  const summaryRaw =
    locale === "es"
      ? latestLab.summary_narrative_es ?? latestLab.summary_narrative
      : latestLab.summary_narrative;
  // Split the narrative into paragraphs on blank lines, mirroring the
  // home dashboard's treatment. Falls back gracefully if the AI ever
  // returns a single block (legacy data) — that block becomes one
  // paragraph and still renders with the drop cap.
  const summaryParagraphs = (summaryRaw ?? "")
    .replace(/[ \t]+/g, " ")
    .trim()
    .split(/\n\s*\n/g)
    .map((p) => p.trim())
    .filter(Boolean);
  const drawn = formatDayMonth(latestLab.collection_date, locale);

  const tabs: { key: FilterTab; label: string; count: number }[] = [
    { key: "all", label: t.all, count: biomarkers.length },
    { key: "optimal", label: t.optimal, count: optimalCount },
    { key: "attention", label: t.attention, count: attentionCount },
    { key: "action", label: t.action, count: actionCount },
  ];

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1200px]">
          {/* ── Masthead ── */}
          <motion.div variants={fadeUp}>
            <EditorialMasthead issue={locale === "es" ? "Lecturas trimestrales" : "Quarterly readings"} date={latestLab.collection_date} withQuarter />
          </motion.div>
          <PendingResultsNotice locale={locale} pending={pendingLabs} />

          {/* ── § I — Latest dispatch ── */}
          <motion.section variants={fadeUp} className="relative mt-10 md:mt-16">
            <div className="grid gap-10 md:grid-cols-12 md:gap-10">
              {/* Left rail — kicker + date */}
              <div className="md:col-span-3 md:pt-2">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                >
                  {t.kickerDispatch}
                </p>

                <div className="mt-6 flex items-baseline gap-3">
                  <span
                    className={`${FONT_CLASS.cormorant} text-[64px] font-medium leading-none tabular-nums tracking-[-2px] text-[#1d1b18] md:text-[88px] md:tracking-[-3px]`}
                  >
                    {drawn.day}
                  </span>
                  <div className="min-w-0">
                    <p
                      className={`${FONT_CLASS.cormorant} text-[20px] font-medium italic leading-tight text-[#97472c] md:text-[24px]`}
                    >
                      {drawn.month}
                    </p>
                    <p
                      className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                    >
                      {yearRoman(drawn.year)} <span className="text-[#1d1b18]/40">·</span>{" "}
                      {latestLab.source === "eva_kit" ? "EVA kit" : t.upload}
                    </p>
                  </div>
                </div>

                <p
                  className={`mt-4 ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                >
                  {biomarkers.length} {t.biomarkerCount}
                </p>
              </div>

              {/* Centre — title + summary with drop cap */}
              <div className="md:col-span-5">
                <h1
                  className={`${FONT_CLASS.cormorant} text-[56px] font-medium leading-[0.92] tracking-[-1px] text-[#1d1b18] md:text-[88px] md:tracking-[-2.5px]`}
                  style={{ textWrap: "balance" } as React.CSSProperties}
                >
                  {t.dispatchTitle}{" "}
                  <span className="italic text-[#97472c]">{t.dispatchAccent}</span>
                </h1>

                {summaryParagraphs.length > 0 && (
                  <div className="mt-8 space-y-5">
                    {summaryParagraphs.map((para, i) => {
                      const proseClass = `${FONT_CLASS.manrope} text-[16px] leading-[1.7] text-[#1d1b18]/85 md:text-[17px]`;
                      const wrap = { textWrap: "pretty" } as React.CSSProperties;
                      if (i === 0) {
                        // First paragraph carries the drop cap. The wrapping
                        // div uses display:flow-root so the float is fully
                        // contained — subsequent paragraphs read clean.
                        return (
                          <div
                            key={i}
                            style={{ display: "flow-root" } as React.CSSProperties}
                          >
                            <p className={proseClass} style={wrap}>
                              <span
                                aria-hidden
                                className={`float-left mr-3 mt-1 ${FONT_CLASS.cormorant} text-[68px] font-medium italic leading-[0.85] text-[#97472c] md:mr-4 md:text-[96px]`}
                              >
                                {para.charAt(0)}
                              </span>
                              {para.slice(1)}
                            </p>
                          </div>
                        );
                      }
                      return (
                        <p key={i} className={proseClass} style={wrap}>
                          {para}
                        </p>
                      );
                    })}
                  </div>
                )}

                {/* Out-of-range notice — surfaced at the point of use when
                    any biomarker sits outside the reference interval.
                    Reuses the already-computed out-of-range count
                    (actionCount = critical_low + critical_high, the stored
                    out-of-range codes); does not recompute zones. */}
                {actionCount > 0 && (
                  <div className="mt-8">
                    <OutOfRangeNotice locale={locale} count={actionCount} />
                  </div>
                )}

                {latestLab.longevity_score != null && (
                  <div className="mt-8 flex items-baseline gap-4 border-t border-[#1d1b18]/10 pt-6">
                    <span
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]`}
                    >
                      {t.lsLabel}
                    </span>
                    <span
                      className={`${FONT_CLASS.cormorant} text-[40px] font-medium leading-none tabular-nums text-[#3a665e] md:text-[52px]`}
                    >
                      {latestLab.longevity_score}
                      <span className="text-[#8a7f76]/60">/100</span>
                    </span>
                  </div>
                )}
              </div>

              {/* Right — bio age as broadsheet cover stat */}
              {latestLab.biological_age != null && realAge != null && (
                <div className="md:col-span-4 md:pt-2">
                  <BroadsheetBioAge
                    bioAge={latestLab.biological_age}
                    realAge={realAge}
                    bioAgeMethod={latestLab.bio_age_method}
                    locale={locale}
                  />
                </div>
              )}
            </div>

            {/* Zone proportion bar — replaces ZoneSummaryTiles */}
            <div className="mt-12 md:mt-20">
              <EditorialZoneBar
                optimal={optimalCount}
                attention={attentionCount}
                action={actionCount}
                locale={locale}
              />
            </div>

            {/* Point-of-use medical disclaimer (CLAIM-006 / AI-001) —
                quiet sign-off beneath the AI-generated reading. */}
            <MedicalDisclaimer
              locale={locale}
              className="mt-10 border-t border-[#1d1b18]/10 pt-6 md:mt-12"
            />
          </motion.section>

          {/* ── Hairline rule ── */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />

          {/* ── § II — Action steps ── */}
          {actionSteps.length > 0 && (
            <>
              <motion.section variants={fadeUp}>
                <div className="grid gap-6 md:grid-cols-12 md:items-end md:gap-10">
                  <div className="md:col-span-7 md:pt-2">
                    <p
                      className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                    >
                      {t.kickerActions}
                    </p>
                    <h2
                      className={`mt-4 ${FONT_CLASS.cormorant} text-[40px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[56px] md:tracking-[-1px]`}
                      style={{ textWrap: "balance" } as React.CSSProperties}
                    >
                      {t.actionsTitle}{" "}
                      <span className="italic text-[#97472c]">{t.actionsAccent}</span>
                    </h2>
                  </div>
                  <div className="md:col-span-5 md:pb-2">
                    <p
                      className={`${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#4c463f]`}
                    >
                      {locale === "es"
                        ? `Una receta a la vez. Desliza para ver las ${actionSteps.length}.`
                        : `One prescription at a time. Swipe through the ${actionSteps.length}.`}
                    </p>
                  </div>
                </div>

                <div className="mt-10 md:mt-14">
                  <ScrollSnapCarousel
                    count={actionSteps.length}
                    itemWidthClass="w-[88%] md:w-[44%]"
                    gapClass="gap-6 md:gap-10"
                    showCounter
                    showDots
                    showArrows
                    arial={(i) =>
                      locale === "es"
                        ? `Ir al paso ${i + 1}`
                        : `Go to step ${i + 1}`
                    }
                    renderItem={(i) => {
                      const step = actionSteps[i];
                      return (
                        <BroadsheetActionCard
                          priority={i + 1}
                          category={formatCategoryLabel(step.category, locale)}
                          title={
                            locale === "es"
                              ? ((step as unknown as Record<string, unknown>).title_es as string) ?? step.title
                              : step.title
                          }
                          description={
                            locale === "es"
                              ? ((step as unknown as Record<string, unknown>).description_es as string) ?? step.description
                              : step.description
                          }
                          status={step.status}
                          locale={locale}
                        />
                      );
                    }}
                  />
                </div>
              </motion.section>

              <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
            </>
          )}

          {/* ── § III — The panel (broadsheet) ── */}
          <motion.section variants={fadeUp}>
            <div className="grid gap-6 md:grid-cols-12 md:gap-10">
              <div className="md:col-span-5 md:pt-2">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
                >
                  {t.kickerPanel}
                </p>
                <h2
                  className={`mt-4 ${FONT_CLASS.cormorant} text-[44px] font-medium leading-[0.92] tracking-[-1px] text-[#1d1b18] md:text-[72px] md:tracking-[-2px]`}
                  style={{ textWrap: "balance" } as React.CSSProperties}
                >
                  {t.panelTitle}{" "}
                  <span className="italic text-[#97472c]">{t.panelAccent}</span>
                </h2>
              </div>
              <div className="md:col-span-7 md:flex md:items-end md:pb-2">
                <p
                  className={`max-w-[40ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#4c463f]`}
                >
                  {t.panelSubtitle}
                </p>
              </div>
            </div>

            {/* Editorial filter / search bar */}
            <div className="mt-10 flex flex-col gap-5 border-y border-[#1d1b18]/15 py-4 md:mt-14 md:flex-row md:items-center md:justify-between md:gap-8">
              <div
                role="tablist"
                aria-label={t.history}
                className="flex shrink-0 gap-6 overflow-x-auto md:gap-8"
              >
                {tabs.map((tab) => {
                  const active = filter === tab.key;
                  return (
                    <button
                      key={tab.key}
                      role="tab"
                      aria-selected={active}
                      onClick={() => setFilter(tab.key)}
                      className={`group relative whitespace-nowrap py-1 transition-colors ${
                        active ? "text-[#97472c]" : "text-[#8a7f76] hover:text-[#1d1b18]"
                      }`}
                    >
                      <span
                        className={`${FONT_CLASS.cormorant} text-[20px] font-medium leading-none tracking-[-0.3px] md:text-[24px] ${
                          active ? "italic" : ""
                        }`}
                      >
                        {tab.label}
                      </span>
                      <span
                        className={`ml-2 ${FONT_CLASS.dmMono} text-[11px] tabular-nums ${
                          active ? "text-[#97472c]/70" : "text-[#8a7f76]/80"
                        }`}
                      >
                        {String(tab.count).padStart(2, "0")}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="flex flex-col gap-3 md:flex-row md:items-center md:gap-5">
                <label className="group relative flex items-center gap-2 border-b border-[#1d1b18]/15 py-1 transition-colors focus-within:border-[#97472c]">
                  <svg
                    aria-hidden
                    className="h-3.5 w-3.5 text-[#8a7f76] transition-colors group-focus-within:text-[#97472c]"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M21 21l-4.34-4.34m0 0A7.5 7.5 0 105.66 5.66a7.5 7.5 0 0011 11z"
                    />
                  </svg>
                  <input
                    type="text"
                    placeholder={t.search}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className={`w-full bg-transparent ${FONT_CLASS.manrope} text-[13px] italic text-[#1d1b18] outline-none placeholder:not-italic placeholder:text-[#8a7f76] md:w-[180px]`}
                  />
                </label>

                {allLabs.length > 1 && (
                  <select
                    aria-label={t.history}
                    className={`border-b border-[#1d1b18]/15 bg-transparent py-1 ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#4c463f] outline-none transition-colors hover:text-[#1d1b18] focus:border-[#97472c]`}
                    defaultValue={latestLab.id}
                    onChange={(e) => {
                      router.push(`/${locale}/labs?result=${e.target.value}`);
                    }}
                  >
                    {allLabs.map((lab) => {
                      const d = formatDayMonth(lab.collection_date, locale);
                      return (
                        <option key={lab.id} value={lab.id}>
                          {d.day} {d.month} {d.year}
                          {lab.source === "eva_kit" ? " · EVA" : ""}
                        </option>
                      );
                    })}
                  </select>
                )}
              </div>
            </div>

            {/* Broadsheet groups — alternating sides, hanging serif numerals */}
            <motion.div
              variants={staggerTight}
              initial="hidden"
              animate="show"
              key={`${filter}-${search}`}
              className="mt-10 md:mt-16"
            >
              {grouped.length === 0 && (
                <p
                  className={`py-16 text-center ${FONT_CLASS.cormorant} text-[24px] italic text-[#8a7f76] md:text-[28px]`}
                >
                  {t.noResults}
                </p>
              )}

              {grouped.map((group, gi) => {
                const label = categoryLabel(group.category, locale);
                const lede = categoryLede(group.category, locale);
                const accent = categoryAccent(group.category);
                const num = String(gi + 1).padStart(2, "0");
                const isOdd = gi % 2 === 1;

                return (
                  <div key={group.category}>

                    <motion.div
                      variants={fadeUp}
                      className={`grid gap-6 md:gap-12 ${
                        isOdd
                          ? "md:grid-cols-[1fr_280px]"
                          : "md:grid-cols-[280px_1fr]"
                      } ${gi > 0 ? "mt-14 md:mt-20" : ""}`}
                    >
                      {/* Rail — alternates side via grid order */}
                      <div className={`${isOdd ? "md:order-2" : "md:order-1"} relative`}>
                        <span
                          aria-hidden
                          className={`pointer-events-none absolute -top-4 ${
                            isOdd ? "right-0 md:-right-2" : "-left-2 md:-left-4"
                          } select-none ${FONT_CLASS.cormorant} text-[120px] font-medium italic leading-[0.8] tabular-nums text-[#1d1b18]/[0.05] md:text-[180px]`}
                        >
                          {num}
                        </span>

                        <div className="relative">
                          <p
                            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px]`}
                            style={{ color: accent }}
                          >
                            § {num}
                          </p>
                          <h3
                            className={`mt-2 ${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.92] tracking-[-0.5px] text-[#1d1b18] md:text-[48px]`}
                            style={{ textWrap: "balance" } as React.CSSProperties}
                          >
                            <span className="italic" style={{ color: accent }}>
                              {label}
                            </span>
                          </h3>
                          {lede && (
                            <p
                              className={`mt-4 max-w-[28ch] ${FONT_CLASS.manrope} text-[13px] leading-[1.6] text-[#4c463f]`}
                            >
                              {lede}
                            </p>
                          )}
                          <div className="mt-5 flex items-center gap-3">
                            <span aria-hidden className="h-px w-6" style={{ backgroundColor: accent, opacity: 0.5 }} />
                            <p
                              className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                            >
                              {String(group.items.length).padStart(2, "0")}{" "}
                              {t.biomarkerCount}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Rows */}
                      <div className={`${isOdd ? "md:order-1" : "md:order-2"}`}>
                        <div className="border-t border-[#1d1b18]/10">
                          {group.items.map((b, i) => (
                            <BroadsheetRow
                              key={b.id}
                              name={b.biomarker_name ?? b.biomarker_key.replace(/_/g, " ")}
                              value={b.value}
                              unit={b.unit}
                              comparator={b.comparator}
                              zone={b.zone}
                              index={i}
                              locale={locale}
                              onClick={() =>
                                router.push(`/${locale}/biomarker/${b.biomarker_key}`)
                              }
                            />
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  </div>
                );
              })}
            </motion.div>
          </motion.section>

          {/* ── Observations that came with the result (free text, as written) ── */}
          {Array.isArray(latestLab.lab_notes) && latestLab.lab_notes.length > 0 && (
            <motion.section variants={fadeUp} className="mt-14 md:mt-20">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px]`}
              >
                {t.observations}
              </p>
              <div className="mt-5 max-w-[68ch] space-y-3 border-t border-[#1d1b18]/10 pt-5">
                {latestLab.lab_notes.map((n, i) => (
                  <p
                    key={`${n.code}-${i}`}
                    className={`${FONT_CLASS.manrope} whitespace-pre-line text-[14px] leading-[1.7] text-[#4c463f]`}
                  >
                    {n.text}
                  </p>
                ))}
              </div>
            </motion.section>
          )}

          {/* ── Footer ── */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-8 md:grid-cols-12 md:items-end md:gap-10"
          >
            <div className="md:col-span-7">
              <h2
                className={`${FONT_CLASS.cormorant} text-[36px] font-medium leading-[1.05] tracking-[-0.5px] text-[#1d1b18] md:text-[52px] md:tracking-[-1px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.footerTitle}{" "}
                <span className="italic text-[#97472c]">{t.footerAccent}</span>
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-3 md:col-span-5 md:justify-end">
              <Link
                href={`/${locale}/labs/manage`}
                className={`${FONT_CLASS.manrope} text-[13px] font-medium text-[#4c463f] underline decoration-[#1d1b18]/20 underline-offset-[6px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/60`}
              >
                {t.manage}
              </Link>
              <Link
                href={`/${locale}/upload`}
                className={`${FONT_CLASS.manrope} text-[13px] font-medium text-[#4c463f] underline decoration-[#1d1b18]/20 underline-offset-[6px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/60`}
              >
                {t.upload}
              </Link>
              <Link
                href={`/${locale}/book`}
                className={`group inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-6 py-3 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0`}
              >
                {t.book}
                <span
                  aria-hidden
                  className="flex h-6 w-6 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
                >
                  <svg
                    className="h-3 w-3"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={2}
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                  </svg>
                </span>
              </Link>
            </div>
          </motion.section>
        </div>
      </div>
    </DashboardChrome>
  );
}
