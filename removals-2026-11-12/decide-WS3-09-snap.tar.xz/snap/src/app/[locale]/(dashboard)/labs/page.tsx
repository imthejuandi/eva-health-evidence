import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { getUserProfile, getLatestLabResult, getBiomarkerValues, getActionSteps } from "@/lib/queries";
import { LabsClient } from "./labs-client";
import { isBioAgeKdmVisible, labForDisplay, profileForDisplay } from "@/lib/biomarkers/bio-age-flags";

interface LabsPageProps {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ result?: string }>;
}

export default async function LabsPage({ params, searchParams }: LabsPageProps) {
  const { locale } = await params;
  const { result: requestedLabId } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/${locale}/login`);

  const [profile, newestLab, actionSteps] = await Promise.all([
    getUserProfile(user.id),
    getLatestLabResult(user.id),
    getActionSteps(user.id),
  ]);

  // The history <select> navigates to /labs?result=<id>. Honor it (own,
  // ready labs only) — previously the param was ignored and selecting an
  // older lab was a silent no-op.
  let latestLab = newestLab;
  if (requestedLabId && requestedLabId !== newestLab?.id) {
    const { data: requestedLab } = await supabase
      .from("lab_results")
      .select("*")
      .eq("id", requestedLabId)
      .eq("user_id", user.id)
      .eq("status", "ready")
      .maybeSingle();
    if (requestedLab) latestLab = requestedLab;
  }

  const biomarkers = latestLab ? await getBiomarkerValues(latestLab.id) : [];

  // Fetch all lab results for the history selector
  const { data: allLabs } = await supabase
    .from("lab_results")
    .select("id, collection_date, source, status, biological_age, longevity_score")
    .eq("user_id", user.id)
    .eq("status", "ready")
    .order("collection_date", { ascending: false });


  // Results that arrived (bridge or webhook) but still wait for the patient's
  // context — invisible otherwise, since every list below is "ready" only.
  const { data: pendingLabs } = await supabase
    .from("lab_results")
    .select("id, collection_date, created_at")
    .eq("user_id", user.id)
    .eq("status", "pending_context")
    .order("created_at", { ascending: false });

  // BIO_AGE_KDM_VISIBLE off (the default, bio-age-flags.ts): the old KDM figure is removed on the server from the
  // shown lab, the profile and every history row, so it never reaches the browser. Values stay stored as they are.
  const kdmVisible = isBioAgeKdmVisible();

  return (
    <LabsClient
      locale={locale}
      pendingLabs={pendingLabs ?? []}
      profile={profileForDisplay(profile, kdmVisible)}
      latestLab={labForDisplay(latestLab, kdmVisible)}
      biomarkers={biomarkers}
      actionSteps={actionSteps}
      allLabs={(allLabs ?? []).map((lab) => labForDisplay(lab, kdmVisible))}
    />
  );
}
