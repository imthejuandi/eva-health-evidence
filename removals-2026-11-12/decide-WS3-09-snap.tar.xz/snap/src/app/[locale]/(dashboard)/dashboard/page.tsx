import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import {
  getUserProfile,
  getLatestLabResult,
  getBiomarkerValues,
  getWearableData,
  getActionSteps,
  getBookedTests,
} from "@/lib/queries";
import { DashboardClient } from "./dashboard-client";
import { createAdminClient } from "@/lib/supabase/admin";
import type { LabResult, Profile } from "@/lib/queries/types";
import { isBioAgeV3Visible, labForDisplay, profileForDisplay } from "@/lib/biomarkers/bio-age-flags";
import { buildBioAgeV3View, type BioAgeV3View } from "@/lib/biomarkers/bio-age-v3-display";
import { completedYearsAt, type BioAgeV3Stored } from "@/lib/biomarkers/biological-age-v3-adapter";
import { BIO_AGE_V3_SHADOW_TABLE } from "@/lib/biomarkers/process-results";

/**
 * The version 3 card's content for the latest result, or null. Called only when BIO_AGE_V3_VISIBLE is true
 * (bio-age-flags.ts, false by default). The record lives in bio_age_v3_shadow, readable by the service role only;
 * the rows are filtered on the signed-in user's id, and only the formatted strings reach the browser. Any failure
 * shows no card rather than breaking the dashboard.
 */
async function loadBioAgeV3View(
  userId: string,
  profile: Profile | null,
  latestLab: LabResult | null,
  locale: string,
): Promise<BioAgeV3View | null> {
  if (!latestLab) return null;
  try {
    const admin = createAdminClient();
    if (!admin) return null;
    const supabase = await createClient();
    const [{ data: labs }, { data: rows }] = await Promise.all([
      supabase
        .from("lab_results")
        .select("id, collection_date")
        .eq("user_id", userId)
        .eq("status", "ready")
        .order("collection_date", { ascending: false }),
      admin.from(BIO_AGE_V3_SHADOW_TABLE).select("lab_result_id, record").eq("user_id", userId),
    ]);
    const records = new Map<string, BioAgeV3Stored>(
      (rows ?? []).map((r: { lab_result_id: string; record: BioAgeV3Stored }) => [r.lab_result_id, r.record]),
    );
    const record = records.get(latestLab.id);
    if (!record) return null;
    // The previous result: the next older ready lab that has a record.
    const ordered = (labs ?? []) as { id: string; collection_date: string | null }[];
    const at = ordered.findIndex((l) => l.id === latestLab.id);
    const prevLab = at >= 0 ? ordered.slice(at + 1).find((l) => records.has(l.id)) : undefined;
    // The age the model used: completed years at the draw, local calendar date, as the adapter reads it.
    const d = /^(\d{4})-(\d{2})-(\d{2})/.exec(latestLab.collection_date ?? "");
    const drawn = d ? new Date(Number(d[1]), Number(d[2]) - 1, Number(d[3])) : new Date();
    const age = completedYearsAt(profile?.date_of_birth, drawn);
    return buildBioAgeV3View({
      record,
      chronologicalAge: Number.isFinite(age) ? age : null,
      locale,
      previous: prevLab ? { record: records.get(prevLab.id) as BioAgeV3Stored, drawDate: prevLab.collection_date } : null,
    });
  } catch (err) {
    console.error("[dashboard] biological age v3 card not built:", err);
    return null;
  }
}

interface DashboardPageProps {
  params: Promise<{ locale: string }>;
}

export default async function DashboardPage({ params }: DashboardPageProps) {
  const { locale } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect(`/${locale}/login`);

  const [profile, latestLab, wearable, actionSteps, bookedTests] =
    await Promise.all([
      getUserProfile(user.id),
      getLatestLabResult(user.id),
      // 14 days — gives the wearable trend deltas enough history to
      // compute a meaningful delta (compares the last value against
      // the first-half average).
      getWearableData(user.id, 14),
      getActionSteps(user.id),
      getBookedTests(user.id),
    ]);

  const biomarkers = latestLab ? await getBiomarkerValues(latestLab.id) : [];

  // Results that arrived (bridge or webhook) but still wait for the patient's
  // context — invisible otherwise, since the dashboard reads "ready" only.
  const { data: pendingLabs } = await supabase
    .from("lab_results")
    .select("id, collection_date, created_at")
    .eq("user_id", user.id)
    .eq("status", "pending_context")
    .order("created_at", { ascending: false });

  // BIO_AGE_KDM_VISIBLE off (the default): the old KDM figure is removed from the rows before they reach the client,
  // the profile's cached figure and the lab's stored fallback alike. Values stay stored as they are.
  const bioAgeV3View = isBioAgeV3Visible() ? await loadBioAgeV3View(user.id, profile, latestLab, locale) : null;

  return (
    <DashboardClient
      locale={locale}
      pendingLabs={pendingLabs ?? []}
      profile={profileForDisplay(profile)}
      latestLab={labForDisplay(latestLab)}
      bioAgeV3View={bioAgeV3View}
      biomarkers={biomarkers}
      wearable={wearable}
      actionSteps={actionSteps}
      bookedTests={bookedTests}
    />
  );
}
