"use client";

/**
 * MERGED DIRECTION — Constellation 3D hero × Broadsheet biomarker strata
 *
 * Pulls the 3D constellation hero from Direction B and combines it with
 * the category-by-category biomarker treatment from Direction C. Applies
 * five usability adjustments the user asked for after reviewing the
 * original three drafts:
 *
 *  1. The 3D scene no longer drifts — parallax only, always facing the
 *     viewer (see `./merged-scene.tsx`).
 *  2. "Your Vitals" is compressed from a wall of huge figures into a
 *     single-row data strip.
 *  3. Each biomarker track has a hover tooltip showing optimal and
 *     normal ranges plus the user's value.
 *  4. The biomarker section has category selector tabs.
 *  5. All displayed numbers pass through `fmt()` which clamps to 2
 *     decimal places.
 */

import dynamic from "next/dynamic";
import { PendingResultsNotice, type PendingLab } from "@/components/dashboard/PendingResultsNotice";
import { BiologicalAgeV3Card } from "@/components/dashboard/BiologicalAgeV3Card";
import type { BioAgeV3View } from "@/lib/biomarkers/bio-age-v3-display";
import Link from "next/link";
import {
  useMemo,
  useState,
  useSyncExternalStore,
  type CSSProperties,
} from "react";
import { motion, useReducedMotion } from "framer-motion";
import type {
  Profile,
  LabResult,
  BiomarkerValue,
  WearableData,
  ActionStep,
  BookedTest,
} from "@/lib/queries/types";
import {
  buildOrbLayout,
  type NodeDatum,
  type WedgeDatum,
} from "./dashboard-scene";
import { EASE_OUT_EXPO, fadeUp, stagger } from "@/lib/dashboard-motion";
import { fmt, ZONE_COLORS as ZONE_COLOR_M } from "@/lib/dashboard-tokens";
import {
  formatCategoryLabel,
  formatLongevityGrade,
  fmtMeasured,
} from "@/lib/dashboard-format";
import {
  AmbientMesh,
  GrainOverlay,
  MedicalDisclaimer,
  OutOfRangeNotice,
} from "@/components/dashboard";

const DashboardCanvas = dynamic(
  () => import("./dashboard-scene").then((m) => m.DashboardCanvas),
  { ssr: false, loading: () => null },
);

interface Props {
  locale: string;
  profile: Profile | null;
  latestLab: LabResult | null;
  biomarkers: BiomarkerValue[];
  wearable: WearableData[];
  actionSteps: ActionStep[];
  bookedTests: BookedTest[];
  /** Results waiting for the patient's per-draw context (bridge or webhook). */
  pendingLabs?: PendingLab[];
  /**
   * The version 3 card, built on the server only when BIO_AGE_V3_VISIBLE is true (bio-age-flags.ts); null hides it.
   * The old KDM figure arrives already removed from `profile` and `latestLab` when BIO_AGE_KDM_VISIBLE is false.
   */
  bioAgeV3View?: BioAgeV3View | null;
}

/* ──────────────────────────────────────────────────────────────────────────
 * useIsFineInput — detect pointer hardware with matchMedia so we can
 * branch behaviour on whether the primary input is a mouse/pen (fine)
 * or a touchscreen (coarse). Used to:
 *  - disable 3D scene parallax on touch (fingers dragging across the
 *    canvas should scroll the page, not tilt the scene)
 *  - swap copy ("Hover to explore" ↔ "Tap to explore")
 *
 * Implemented with useSyncExternalStore so the value is always
 * hydration-safe and stays in sync if the user switches input methods.
 * ────────────────────────────────────────────────────────────────────────── */
function useIsFineInput(): boolean {
  return useSyncExternalStore(
    (callback) => {
      if (typeof window === "undefined" || !window.matchMedia) return () => {};
      const mq = window.matchMedia("(hover: hover) and (pointer: fine)");
      mq.addEventListener("change", callback);
      return () => mq.removeEventListener("change", callback);
    },
    () => {
      if (typeof window === "undefined" || !window.matchMedia) return true;
      return window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    },
    // Server snapshot — assume fine input so the default dense copy
    // renders during SSR. Client snapshot corrects after hydration.
    () => true,
  );
}

function calculateAge(dob: string): number {
  const birth = new Date(dob);
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

function hourGreetingEn() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}
function hourGreetingEs() {
  const h = new Date().getHours();
  if (h < 12) return "Buenos días";
  if (h < 20) return "Buenas tardes";
  return "Buenas noches";
}

function useCopy(locale: string) {
  return useMemo(
    () =>
      locale === "es"
        ? {
            greeting: hourGreetingEs(),
            scroll: "Desliza",
            findings: "§ 01 — Hallazgos",
            drawn: "Lectura tomada",
            optimalShort: "óptimo",
            vitals: "§ 02 — Tus constantes",
            biomarkers: "§ 03 — Por categoría",
            wearable: "§ 04 — El cuerpo en movimiento",
            actions: "§ 05 — Pasos a seguir",
            nextTest: "§ 06 — Próximo test",
            bio: "Edad biológica",
            chrono: "Edad cronológica",
            longevity: "Longevidad",
            years: "años",
            younger: "años más joven",
            older: "años mayor",
            optimal: "óptimo",
            attention: "atención",
            action: "fuera de rango",
            strengths: "Fortalezas",
            needs: "Necesita atención",
            all: "Todas",
            category: "Categoría",
            categoriesLabel: "Categorías",
            markers: "marcadores",
            categories: "categorías",
            noMarkersInCategory: "Sin marcadores en esta categoría",
            biomarkersHeadingLead: "Una lectura por",
            biomarkersHeadingAccent: "estrato.",
            wearableHeadingLead: "El cuerpo,",
            wearableHeadingAccent: "en movimiento.",
            actionsHeadingLead: "Lo que",
            actionsHeadingAccent: "viene ahora.",
            readingTheMap: "Leyendo el mapa",
            distance: "Distancia",
            distanceHint: "Más cerca del centro = más sano",
            ring: "Anillo",
            ringHint: "Uno por categoría",
            colour: "Color",
            colourHint: "Jade óptimo · oro atención · tierra fuera de rango",
            targets: "Aborda",
            value: "Valor",
            optimalRange: "Óptimo",
            normalRange: "Normal",
            zone: "Zona",
            readMap: "Pasa el ratón para explorar",
            readMapTouch: "Toca para explorar",
            hrv: "VFC",
            restingHr: "FC reposo",
            sleep: "Sueño",
            respRate: "Frec. resp.",
            ms: "ms",
            bpm: "lpm",
            hrs: "h",
            brpm: "rpm",
            nothingScheduled: "Nada programado",
            bookNow: "Reservar ahora",
            // KDM v2.2 provenance copy
            kdmCalibration: "Estimación ajustada en parte a valores españoles",
            kdmCreatine:
              "¿Tomas creatina? Indica tu dosis diaria en gramos al confirmar el contexto de tu próxima analítica y ajustaremos su creatinina. En ensayos con adultos sanos, la creatina sube la creatinina en sangre sin cambiar el filtrado renal medido. Si la tomas y no indicas tu dosis diaria, la cifra sale más alta. Tus analíticas anteriores conservan el contexto con el que se calcularon.",
            kdmMarkersUsed: "marcadores",
            kdmComprehensiveLabel: "Edad biológica completa",
            kdmHowCalculated: "¿Cómo se calcula?",
            kdmAveragedLabs: (n: number, w: number | null) =>
              n === 1
                ? "Basado en tu última analítica"
                : w
                  ? `Promedio de ${n} analíticas (últimos ${w} meses)`
                  : `Promedio de ${n} analíticas`,
            isEs: true,
          }
        : {
            greeting: hourGreetingEn(),
            scroll: "Scroll",
            findings: "§ 01 — Findings",
            drawn: "Reading drawn",
            optimalShort: "optimal",
            vitals: "§ 02 — Your vitals",
            biomarkers: "§ 03 — By category",
            wearable: "§ 04 — The body in motion",
            actions: "§ 05 — What comes next",
            nextTest: "§ 06 — Next test",
            bio: "Biological age",
            chrono: "Chronological age",
            longevity: "Longevity",
            years: "years",
            younger: "years younger",
            older: "years older",
            optimal: "optimal",
            attention: "attention",
            action: "out of range",
            strengths: "Strengths",
            needs: "Needs attention",
            all: "All",
            category: "Category",
            categoriesLabel: "Categories",
            markers: "markers",
            categories: "categories",
            noMarkersInCategory: "No markers in this category",
            biomarkersHeadingLead: "A reading by",
            biomarkersHeadingAccent: "stratum.",
            wearableHeadingLead: "The body,",
            wearableHeadingAccent: "in motion.",
            actionsHeadingLead: "What comes",
            actionsHeadingAccent: "next.",
            readingTheMap: "Reading the map",
            distance: "Distance",
            distanceHint: "Closer to centre = healthier",
            ring: "Ring",
            ringHint: "One per category",
            colour: "Colour",
            colourHint: "Jade optimal · gold attention · terra out of range",
            targets: "Targets",
            value: "Value",
            optimalRange: "Optimal",
            normalRange: "Normal",
            zone: "Zone",
            readMap: "Hover to explore",
            readMapTouch: "Tap a node to explore",
            hrv: "HRV",
            restingHr: "Resting HR",
            sleep: "Sleep",
            respRate: "Resp. rate",
            ms: "ms",
            bpm: "bpm",
            hrs: "h",
            brpm: "brpm",
            nothingScheduled: "Nothing scheduled",
            bookNow: "Book now",
            // KDM v2.2 provenance copy
            kdmCalibration: "An estimate, partly adjusted to Spanish values",
            kdmCreatine:
              "Taking creatine? Give your daily dose in grams when you confirm the context of your next lab, and we will adjust its creatinine. In trials in healthy adults, creatine raised blood creatinine without changing measured kidney filtration. If you take it and do not give your daily dose, the figure reads higher. Your earlier labs keep the context they were calculated with.",
            kdmMarkersUsed: "markers",
            kdmComprehensiveLabel: "Comprehensive biological age",
            kdmHowCalculated: "How is this calculated?",
            kdmAveragedLabs: (n: number, w: number | null) =>
              n === 1
                ? "Based on your most recent lab"
                : w
                  ? `Averaged across ${n} labs (last ${w} months)`
                  : `Averaged across ${n} labs`,
            isEs: false,
          },
    [locale],
  );
}

type CopyT = ReturnType<typeof useCopy>;

/* ──────────────────────────────────────────────────────────────────────────
 * Main component
 * ────────────────────────────────────────────────────────────────────────── */
export function DashboardClient({
  locale,
  profile,
  latestLab,
  biomarkers,
  wearable,
  actionSteps,
  bookedTests,
  pendingLabs = [],
  bioAgeV3View = null,
}: Props) {
  const t = useCopy(locale);
  const reduced = useReducedMotion();
  const isFineInput = useIsFineInput();
  const firstName = profile?.full_name?.split(" ")[0] ?? "";

  const chronoAge = profile?.date_of_birth
    ? calculateAge(profile.date_of_birth)
    : null;
  // Single user-facing BA: the rolling-average value cached on the profile,
  // which is computed by averaging biomarkers across the user's recent
  // labs and running KDM once. Falls back to the latest lab's biological_age
  // for legacy users whose profile cache hasn't been populated yet (will
  // happen automatically on their next lab upload).
  const bioAge =
    profile?.current_ba ?? latestLab?.biological_age ?? null;
  const longevityScore = latestLab?.longevity_score ?? null;
  const longevityGrade = formatLongevityGrade(latestLab?.longevity_grade, locale);
  const delta =
    bioAge != null && chronoAge != null ? chronoAge - bioAge : null;

  const orbLayout = useMemo(() => buildOrbLayout(biomarkers), [biomarkers]);
  const nodes = orbLayout.nodes;
  const wedges = orbLayout.wedges;

  const optimalCount = biomarkers.filter((b) => b.zone === "optimal").length;
  const attentionCount = biomarkers.filter((b) =>
    ["below_optimal", "above_optimal"].includes(b.zone),
  ).length;
  const actionCount = biomarkers.filter((b) =>
    ["critical_low", "critical_high"].includes(b.zone),
  ).length;

  const nextTest = bookedTests.find((b) =>
    ["scheduled", "kit_sent"].includes(b.status),
  );

  // Category selection lives here so the hero can highlight the selected
  // ring at the same time as the biomarker section filters. Filters out
  // empty / "uncategorized" buckets — those are biomarkers whose
  // reference range lookup didn't resolve a panel_category, and they'd
  // otherwise surface as an "uncategorized" tab in the BiomarkerSection
  // (and the hero left rail) that the user can't act on. The orb
  // already drops these rows in buildOrbLayout; this keeps the tab
  // list in sync.
  const categoryNames = useMemo(() => {
    return Array.from(
      new Set(
        biomarkers
          .map((b) => b.category)
          .filter((c) => !!c && c !== "uncategorized"),
      ),
    ).sort();
  }, [biomarkers]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // overflow-x-clip (not -hidden) on the wrapper: `overflow-x: hidden`
  // silently promotes overflow-y to `auto` per spec, turning this into
  // a nested scroll container. On iOS Safari that competes with body
  // scroll and produces "stuck" scroll-up gestures. `clip` visually
  // clips horizontal bleed (the -mx-5 carousels) without creating a
  // scroll context.
  return (
    <div className="relative min-h-screen overflow-x-clip bg-[#fef8f2] text-[#1d1b18]">
      <AmbientMesh />
      <GrainOverlay />

      <motion.div
        variants={stagger}
        initial="hidden"
        animate="show"
        className="relative z-[2]"
      >
        {pendingLabs.length > 0 && (
          <div className="px-5 pt-6 md:px-10">
            <div className="mx-auto max-w-[1200px]">
              <PendingResultsNotice locale={locale} pending={pendingLabs} />
            </div>
          </div>
        )}
        <ConstellationHero
          t={t}
          locale={locale}
          firstName={firstName}
          nodes={nodes}
          wedges={wedges}
          reduced={!!reduced}
          isFineInput={isFineInput}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          categories={categoryNames}
          longevityScore={longevityScore}
          longevityGrade={longevityGrade}
          bioAge={bioAge}
          chronoAge={chronoAge}
          delta={delta}
          optimalCount={optimalCount}
          attentionCount={attentionCount}
          actionCount={actionCount}
          biomarkers={biomarkers}
        />

        <VitalsStrip
          t={t}
          locale={locale}
          bioAge={bioAge}
          chronoAge={chronoAge}
          longevityScore={longevityScore}
          longevityGrade={longevityGrade}
          delta={delta}
          optimal={optimalCount}
          attention={attentionCount}
          action={actionCount}
          total={biomarkers.length}
          // When the rolling-average cache is populated, prefer its
          // provenance fields. Falls back to the latest single-lab fields
          // for users without a cached value yet.
          bioAgeMethod={
            profile?.current_ba != null
              ? `KDM_v2.2.3_${profile.current_ba_method ?? "Reference"}`
              : (latestLab?.bio_age_method ?? null)
          }
          bioAgeNMarkers={
            profile?.current_ba_n_markers_used ??
            latestLab?.bio_age_n_markers ??
            null
          }
          biologicalAgeComprehensive={
            // Only show the comprehensive supplementary line when the
            // displayed BA itself is Reference (i.e., we're showing both
            // tiers). Now that we always prefer Comprehensive, this is
            // usually null.
            profile?.current_ba_method === "Reference"
              ? (latestLab?.biological_age_comprehensive ?? null)
              : null
          }
          nLabsAveraged={profile?.current_ba_n_labs_averaged ?? null}
          windowMonths={profile?.current_ba_window_months ?? null}
        />

        {bioAgeV3View && (
          <div className="px-5 pt-6 md:px-10">
            <div className="mx-auto max-w-[1200px]">
              <BiologicalAgeV3Card view={bioAgeV3View} />
            </div>
          </div>
        )}

        <FindingsBand t={t} latestLab={latestLab} biomarkers={biomarkers} />

        <BiomarkerSection
          t={t}
          locale={locale}
          biomarkers={biomarkers}
          categories={categoryNames}
          selected={selectedCategory}
          onSelect={setSelectedCategory}
        />

        <WearableRibbon t={t} wearable={wearable} />

        <ActionStepsCarousel
          t={t}
          locale={locale}
          actionSteps={actionSteps}
          biomarkers={biomarkers}
        />

        <NextTestFooter t={t} locale={locale} nextTest={nextTest} />
      </motion.div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * ConstellationHero — full-viewport 3-column layout matching the
 * original Direction B constellation: category legend rail on the left,
 * canvas with dense numerical centre in the middle, reading-key rail on
 * the right. The left rail is interactive — clicking a category
 * highlights the matching nodes in the 3D scene.
 * ────────────────────────────────────────────────────────────────────────── */
function ConstellationHero({
  t,
  locale,
  firstName,
  nodes,
  wedges,
  reduced,
  isFineInput,
  selectedCategory,
  onSelectCategory,
  categories,
  longevityScore,
  longevityGrade,
  bioAge,
  chronoAge,
  delta,
  optimalCount,
  attentionCount,
  actionCount,
  biomarkers,
}: {
  t: CopyT;
  locale: string;
  firstName: string;
  nodes: NodeDatum[];
  wedges: WedgeDatum[];
  reduced: boolean;
  isFineInput: boolean;
  selectedCategory: string | null;
  onSelectCategory: (cat: string | null) => void;
  categories: string[];
  longevityScore: number | null;
  longevityGrade: string | null;
  bioAge: number | null;
  chronoAge: number | null;
  delta: number | null;
  optimalCount: number;
  attentionCount: number;
  actionCount: number;
  biomarkers: BiomarkerValue[];
}) {
  // Hover state for desktop — transient, only visible while the
  // cursor is over the node.
  const [tooltip, setTooltip] = useState<{
    node: NodeDatum;
    x: number;
    y: number;
  } | null>(null);
  // Pinned state for touch — persists after tap until the user taps
  // another node or taps the canvas background. Pinned takes
  // precedence when both are set.
  const [pinned, setPinned] = useState<{
    node: NodeDatum;
    x: number;
    y: number;
  } | null>(null);

  const visibleTooltip = pinned ?? tooltip;

  // Per-category optimal ratios for the left rail's mini bars.
  const categoryStats = useMemo(() => {
    const map = new Map<string, { count: number; optimal: number }>();
    for (const b of biomarkers) {
      const entry = map.get(b.category) ?? { count: 0, optimal: 0 };
      entry.count += 1;
      if (b.zone === "optimal") entry.optimal += 1;
      map.set(b.category, entry);
    }
    return categories.map((name) => ({
      name,
      count: map.get(name)?.count ?? 0,
      optimal: map.get(name)?.optimal ?? 0,
    }));
  }, [biomarkers, categories]);

  const hasData = nodes.length > 0;

  return (
    <section className="relative overflow-clip">
      {/* Ambient radial wash behind the canvas */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 50% 55%, rgba(188,236,225,0.32), transparent 55%), radial-gradient(circle at 85% 15%, rgba(217,123,92,0.18), transparent 50%), radial-gradient(circle at 12% 85%, rgba(196,147,50,0.14), transparent 50%)",
        }}
      />

      <div className="relative mx-auto flex min-h-[78dvh] max-w-[1400px] flex-col px-5 py-6 md:min-h-[100dvh] md:px-10 md:py-14">
        {/* Top strip — greeting */}
        <motion.div
          variants={fadeUp}
          className="flex flex-wrap items-center justify-end gap-4"
        >
          <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
            {t.greeting}
            {firstName ? `, ${firstName}` : ""}
          </span>
        </motion.div>

        {/* Main hero grid — legend rail | canvas | zone legend rail */}
        <div className="relative mt-6 grid flex-1 grid-cols-1 md:grid-cols-[220px_1fr_220px] md:gap-8">
          {/* ─── LEFT: category legend ─── */}
          <HeroLegend
            t={t}
            locale={locale}
            categoryStats={categoryStats}
            selectedCategory={selectedCategory}
            onSelectCategory={onSelectCategory}
            optimalCount={optimalCount}
            attentionCount={attentionCount}
            actionCount={actionCount}
          />

          {/* ─── CENTRE: canvas stage ─── */}
          {/* Desktop canvas is generous (760px tall) so the orb has
              real pixel real-estate for the centre numerals + three
              rings of dots. Mobile stays compact (380px). */}
          <div
            className="relative min-h-[380px] md:min-h-[760px]"
            // pan-y lets vertical scroll gestures pass through the
            // canvas on touch devices, so the page still scrolls
            // cleanly when you drag across the constellation.
            style={{ touchAction: "pan-y" }}
          >
            {!hasData ? (
              <EmptyConstellation />
            ) : reduced ? (
              <StaticConstellation nodes={nodes} />
            ) : (
              <DashboardCanvas
                nodes={nodes}
                wedges={wedges}
                locale={locale}
                highlightedCategory={selectedCategory}
                enableParallax={isFineInput}
                // Hover handlers are dropped on touch so R3F's events
                // manager doesn't raycast the scene on every
                // pointermove. Without that, the page rubber-banded on
                // the first one or two swipes inside the orb area.
                // Tap-to-pin (onClick) is unaffected.
                enableHover={isFineInput}
                // Hide the perimeter category labels on touch / mobile.
                // The label ring eats the leader space the orb could
                // otherwise grow into, and crowds the longevity numeral
                // overlay sitting at the orb's centre. The category
                // sidebar stays available below the hero on mobile.
                showLabels={isFineInput}
                onHover={(node, screen) =>
                  setTooltip({ node, x: screen.x, y: screen.y })
                }
                onUnhover={() => setTooltip(null)}
                onPin={(node, screen) =>
                  setPinned({ node, x: screen.x, y: screen.y })
                }
                onUnpin={() => setPinned(null)}
              />
            )}

            {/* 3D tooltip — shows pinned selection (touch taps) if
                present, otherwise the transient hover state.
                On desktop (fine input) it floats above the tapped node.
                On touch it docks to the top of the canvas stage with a
                max-width clamp so it never overflows the viewport even
                when a node at the edge of the constellation is tapped. */}
            {visibleTooltip && (
              <div
                className={
                  isFineInput
                    ? "absolute z-10 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-xl bg-[#1d1b18]/92 px-3 py-2 font-[family-name:var(--font-manrope)] text-[11px] text-white shadow-[0_20px_40px_-12px_rgba(29,27,24,0.5)] backdrop-blur-md"
                    : "absolute left-3 right-3 top-3 z-10 mx-auto max-w-[calc(100%-1.5rem)] rounded-xl bg-[#1d1b18]/95 px-4 py-3 font-[family-name:var(--font-manrope)] text-[12px] text-white shadow-[0_20px_40px_-12px_rgba(29,27,24,0.5)] backdrop-blur-md"
                }
                style={
                  isFineInput
                    ? {
                        left: visibleTooltip.x,
                        top: visibleTooltip.y - 8,
                        // The pinned tooltip is interactive (users can
                        // tap it to dismiss); hover is pass-through.
                        pointerEvents: pinned ? "auto" : "none",
                      }
                    : {
                        // On touch the tooltip is always interactive —
                        // tapping it dismisses.
                        pointerEvents: "auto",
                      }
                }
                onClick={() => setPinned(null)}
              >
                <div className="flex items-center gap-2">
                  <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: visibleTooltip.node.color }}
                  />
                  <span className="truncate font-bold">
                    {visibleTooltip.node.name}
                  </span>
                </div>
                <div
                  className="mt-0.5 font-[family-name:var(--font-dm-mono)] text-[10px] text-white/70"
                  style={{ fontVariantNumeric: "tabular-nums" }}
                >
                  {fmt(visibleTooltip.node.value)}
                  {visibleTooltip.node.unit
                    ? ` ${visibleTooltip.node.unit}`
                    : ""}{" "}
                  · {visibleTooltip.node.zone.replace("_", " ")}
                </div>
              </div>
            )}

            {/* Dense numerical centre — longevity + bio age + chrono age.
                Matches the original Direction B sizing (120-180px) so the
                constellation anchors visually instead of feeling small. */}
            <HeroNumerals
              t={t}
              longevityScore={longevityScore}
              longevityGrade={longevityGrade}
            />
          </div>

          {/* ─── RIGHT: reading-key rail ─── */}
          <HeroZoneLegend t={t} />
        </div>

        {/* Bottom hint row */}
        <motion.div
          variants={fadeUp}
          className="mt-6 flex items-center justify-between md:mt-8"
        >
          <span className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
            {isFineInput ? t.readMap : t.readMapTouch}
          </span>
          <ScrollCue label={t.scroll} />
        </motion.div>
      </div>
    </section>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * HeroLegend — left rail. Clickable category rows + zone counters.
 * Clicking a category toggles selectedCategory on the parent, which in
 * turn highlights the matching ring in the 3D scene.
 * ────────────────────────────────────────────────────────────────────────── */
function HeroLegend({
  t,
  locale,
  categoryStats,
  selectedCategory,
  onSelectCategory,
  optimalCount,
  attentionCount,
  actionCount,
}: {
  t: CopyT;
  locale: string;
  categoryStats: { name: string; count: number; optimal: number }[];
  selectedCategory: string | null;
  onSelectCategory: (cat: string | null) => void;
  optimalCount: number;
  attentionCount: number;
  actionCount: number;
}) {
  return (
    <motion.aside variants={fadeUp} className="hidden self-center md:block">
      {/* Section label with hairline rule, mirroring the editorial
          chapter-marker pattern from the investors deck. */}
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className="inline-block h-px w-6 bg-[#1d1b18]/25"
        />
        <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]">
          {t.categoriesLabel}
        </p>
      </div>
      <ul className="mt-4 space-y-1">
        {categoryStats.map((c) => {
          const pct = c.count > 0 ? (c.optimal / c.count) * 100 : 0;
          const active = selectedCategory === c.name;
          return (
            <li key={c.name}>
              <button
                type="button"
                onClick={() => onSelectCategory(active ? null : c.name)}
                aria-pressed={active}
                className="group block w-full rounded-xl px-2.5 py-2 text-left transition-colors duration-200 hover:bg-[rgba(29,27,24,0.035)]"
                style={
                  active
                    ? {
                        background: "rgba(151,71,44,0.08)",
                        boxShadow:
                          "0 1px 0 rgba(255,255,255,0.7) inset, 0 0 0 1px rgba(151,71,44,0.15) inset",
                      }
                    : undefined
                }
              >
                <div className="flex items-baseline justify-between gap-3">
                  <span className="flex items-baseline gap-2">
                    {active && (
                      <span
                        aria-hidden
                        className="h-1.5 w-1.5 shrink-0 rounded-full"
                        style={{
                          backgroundColor: "#97472c",
                          boxShadow: "0 0 6px #97472c",
                        }}
                      />
                    )}
                    <span
                      className={`font-[family-name:var(--font-manrope)] text-[12px] transition-colors ${
                        active
                          ? "font-extrabold text-[#97472c]"
                          : "font-bold text-[#1d1b18] group-hover:text-[#1d1b18]"
                      }`}
                    >
                      {formatCategoryLabel(c.name, locale)}
                    </span>
                  </span>
                  <span
                    className="font-[family-name:var(--font-dm-mono)] text-[10px] tabular-nums"
                    style={{
                      color: active ? "#97472c" : "#8a7f76",
                      fontVariantNumeric: "tabular-nums",
                    }}
                  >
                    {c.optimal}/{c.count}
                  </span>
                </div>
                <div className="mt-1.5 h-[2px] w-full rounded-full bg-[rgba(29,27,24,0.05)]">
                  <motion.div
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: pct / 100 }}
                    transition={{
                      duration: 1.2,
                      delay: 0.6,
                      ease: EASE_OUT_EXPO,
                    }}
                    style={{ transformOrigin: "left center" }}
                    className={`h-full rounded-full ${
                      active ? "bg-[#97472c]" : "bg-[#3a665e]"
                    }`}
                  />
                </div>
              </button>
            </li>
          );
        })}
      </ul>

      <div className="mt-8 space-y-1.5">
        <HeroLegendRow label={t.optimal} count={optimalCount} color="#3a665e" />
        <HeroLegendRow label={t.attention} count={attentionCount} color="#c49332" />
        <HeroLegendRow label={t.action} count={actionCount} color="#b04040" />
      </div>
    </motion.aside>
  );
}

function HeroLegendRow({
  label,
  count,
  color,
}: {
  label: string;
  count: number;
  color: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{ backgroundColor: color, boxShadow: `0 0 8px ${color}` }}
      />
      <span className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.4px] text-[#8a7f76]">
        {label}
      </span>
      <span
        className="ml-auto font-[family-name:var(--font-dm-mono)] text-[11px] font-bold"
        style={{ color, fontVariantNumeric: "tabular-nums" }}
      >
        {String(count).padStart(2, "0")}
      </span>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * HeroNumerals — centre overlay sitting on top of the canvas. The orb
 * is now reserved for ONE statement: the longevity score. Bio age,
 * chrono age, and the delta are surfaced in the VitalsStrip section
 * directly below the hero, so duplicating them here just crowded the
 * inner ring of biomarker dots.
 * ────────────────────────────────────────────────────────────────────────── */
function HeroNumerals({
  t,
  longevityScore,
  longevityGrade,
}: {
  t: CopyT;
  longevityScore: number | null;
  longevityGrade: string | null;
}) {
  if (longevityScore == null) return null;
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.1, delay: 0.6, ease: EASE_OUT_EXPO }}
        className="text-center"
      >
        <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]">
          {t.longevity}
        </p>
        <p
          className="mt-1 font-[family-name:var(--font-cormorant)] text-[88px] font-medium leading-[0.85] tracking-[-4px] text-[#97472c] md:text-[200px] md:tracking-[-7px]"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {fmt(longevityScore)}
          {longevityGrade && (
            <span className="ml-2 align-top text-[20px] text-[#8a7f76] md:text-[36px]">
              {longevityGrade}
            </span>
          )}
        </p>
      </motion.div>
    </div>
  );
}

function HeroZoneLegend({ t }: { t: CopyT }) {
  return (
    <motion.aside
      variants={fadeUp}
      className="hidden self-center md:block md:justify-self-end"
    >
      <p className="text-right font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]">
        {t.readingTheMap}
      </p>
      <ul className="mt-3 space-y-3 text-right">
        <li>
          <span className="block font-[family-name:var(--font-manrope)] text-[12px] font-bold text-[#1d1b18]">
            {t.distance}
          </span>
          <span className="font-[family-name:var(--font-jakarta)] text-[11px] leading-snug text-[#8a7f76]">
            {t.distanceHint}
          </span>
        </li>
        <li>
          <span className="block font-[family-name:var(--font-manrope)] text-[12px] font-bold text-[#1d1b18]">
            {t.ring}
          </span>
          <span className="font-[family-name:var(--font-jakarta)] text-[11px] leading-snug text-[#8a7f76]">
            {t.ringHint}
          </span>
        </li>
        <li>
          <span className="block font-[family-name:var(--font-manrope)] text-[12px] font-bold text-[#1d1b18]">
            {t.colour}
          </span>
          <span className="font-[family-name:var(--font-jakarta)] text-[11px] leading-snug text-[#8a7f76]">
            {t.colourHint}
          </span>
        </li>
      </ul>
    </motion.aside>
  );
}

function ScrollCue({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
      <span>{label}</span>
      <motion.span
        aria-hidden
        className="inline-block h-6 w-[1px] origin-top bg-[#8a7f76]"
        animate={{ scaleY: [0.2, 1, 0.2], opacity: [0.3, 1, 0.3] }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: [0.45, 0, 0.55, 1],
        }}
      />
    </div>
  );
}

function StaticConstellation({ nodes }: { nodes: NodeDatum[] }) {
  const viewBox = 8;
  return (
    <svg
      viewBox={`${-viewBox / 2} ${-viewBox / 2} ${viewBox} ${viewBox}`}
      className="absolute inset-0 h-full w-full"
    >
      {nodes.map((n) => (
        <circle
          key={n.id}
          cx={n.position[0]}
          cy={-n.position[1]}
          r={0.09}
          fill={n.color}
        />
      ))}
    </svg>
  );
}

function EmptyConstellation() {
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="max-w-xs text-center">
        <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
          No data yet
        </p>
        <p className="mt-2 font-[family-name:var(--font-cormorant)] text-[26px] font-medium leading-tight text-[#1d1b18]">
          Upload labs to light up your constellation.
        </p>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * VitalsStrip — compact single-row "data tape" replacing the wall of
 * huge figures. Each cell is the same size; labels are small-caps
 * monospace, values are mid-size serif. Divided by hairline rules.
 * ────────────────────────────────────────────────────────────────────────── */
function VitalsStrip({
  t,
  locale,
  bioAge,
  chronoAge,
  longevityScore,
  longevityGrade,
  delta,
  optimal,
  attention,
  action,
  total,
  bioAgeMethod,
  bioAgeNMarkers,
  biologicalAgeComprehensive,
  nLabsAveraged,
  windowMonths,
}: {
  t: CopyT;
  locale: string;
  bioAge: number | null;
  chronoAge: number | null;
  longevityScore: number | null;
  longevityGrade: string | null;
  delta: number | null;
  optimal: number;
  attention: number;
  action: number;
  total: number;
  /** Provenance for the bioAge value. "KDM_v2.2.3_Comprehensive" / _Reference, or legacy "KDM_v2.2*_ReferenceBA". */
  bioAgeMethod: string | null;
  /** Count of markers contributing to the joint estimator (rolling-average or single-lab). */
  bioAgeNMarkers: number | null;
  /** Comprehensive BA companion (rendered only when current BA is Reference). */
  biologicalAgeComprehensive: number | null;
  /** How many labs were averaged into the displayed BA (1 = single-lab fallback). */
  nLabsAveraged: number | null;
  /** 6 or 12 (window) or null (single-lab). */
  windowMonths: number | null;
}) {
  const isKdm = bioAgeMethod?.startsWith("KDM_v2.2") ?? false;
  const cells: Array<{
    label: string;
    value: string;
    sub?: string;
    color: string;
  }> = [];

  if (longevityScore != null) {
    cells.push({
      label: t.longevity,
      value: `${fmt(longevityScore)}${longevityGrade ? " " + longevityGrade : ""}`,
      sub: "/100",
      color: "#97472c",
    });
  }
  if (bioAge != null) {
    cells.push({
      label: t.bio,
      value: fmt(bioAge),
      sub: t.years,
      color: "#3a665e",
    });
  }
  if (chronoAge != null) {
    cells.push({
      label: t.chrono,
      value: fmt(chronoAge),
      sub: t.years,
      color: "#1d1b18",
    });
  }
  if (delta != null && bioAge != null && chronoAge != null) {
    cells.push({
      label: delta >= 0 ? t.younger : t.older,
      value: (delta > 0 ? "−" : delta < 0 ? "+" : "") + fmt(Math.abs(delta)),
      sub: t.years,
      color: delta >= 0 ? "#3a665e" : "#b04040",
    });
  }
  if (total > 0) {
    cells.push({
      label: t.optimal,
      value: fmt(optimal),
      sub: `/${total}`,
      color: "#3a665e",
    });
    cells.push({
      label: t.attention,
      value: fmt(attention),
      sub: `/${total}`,
      color: "#c49332",
    });
    cells.push({
      label: t.action,
      value: fmt(action),
      sub: `/${total}`,
      color: "#b04040",
    });
  }

  if (cells.length === 0) return null;

  return (
    <motion.section
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-10%" }}
      className="relative border-y border-[#1d1b18]/10 py-6 md:py-10"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]">
          {t.vitals}
        </p>
        {/* On mobile, cells are a 2-column grid with hairline dividers on
            both axes so they read as a data table, not a floating group. */}
        <div className="mt-4 grid grid-cols-2 md:mt-5 md:grid-cols-4 lg:grid-cols-7">
          {cells.map((c, i) => {
            // Dividers: every cell (except the leftmost in its row) gets
            // a left border; every cell (except the first row) gets a
            // top border on mobile. Desktop uses the original left-only.
            const isMobileFirstCol = i % 2 === 0;
            const isMobileFirstRow = i < 2;
            return (
              <div
                key={`${c.label}-${i}`}
                className={`relative px-3 py-3 md:px-6 md:py-0 ${
                  isMobileFirstCol ? "" : "border-l border-[#1d1b18]/10"
                } ${
                  isMobileFirstRow ? "" : "border-t border-[#1d1b18]/10"
                } md:border-t-0 ${
                  i === 0 ? "md:border-l-0" : "md:border-l md:border-[#1d1b18]/10"
                }`}
              >
                <p
                  className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.4px]"
                  style={{ color: c.color, opacity: 0.8 }}
                >
                  {c.label}
                </p>
                <p
                  className="mt-1 font-[family-name:var(--font-cormorant)] text-[34px] font-medium leading-none md:text-[52px]"
                  style={{ color: c.color, fontVariantNumeric: "tabular-nums" }}
                >
                  {c.value}
                  {c.sub && (
                    <span className="ml-1 text-[11px] font-medium text-[#8a7f76] md:text-[12px]">
                      {c.sub}
                    </span>
                  )}
                </p>
              </div>
            );
          })}
        </div>

        {/* KDM v2.2 provenance row: Spanish-means badge + comprehensive BA + methodology link.
            Only rendered when bio_age_method is KDM (pre-migration legacy rows skip). */}
        {isKdm && bioAge != null && (
          <div className="mt-5 flex flex-col gap-2 border-t border-[#1d1b18]/10 pt-4 text-[12px] text-[#4c463f]/80 md:flex-row md:items-center md:justify-between md:text-[13px]">
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
              {nLabsAveraged != null && (
                <>
                  <span className="font-medium text-[#1d1b18]">
                    {t.kdmAveragedLabs(nLabsAveraged, windowMonths)}
                  </span>
                  <span className="text-[#4c463f]/40">·</span>
                </>
              )}
              <span className="font-medium text-[#3a665e]">
                {t.kdmCalibration}
              </span>
              {bioAgeNMarkers != null && (
                <>
                  <span className="text-[#4c463f]/40">·</span>
                  <span className="font-[family-name:var(--font-dm-mono)] tabular-nums">
                    {bioAgeNMarkers} {t.kdmMarkersUsed}
                  </span>
                </>
              )}
              {biologicalAgeComprehensive != null && (
                <>
                  <span className="text-[#4c463f]/40">·</span>
                  <span>
                    {t.kdmComprehensiveLabel}:{" "}
                    <span className="font-[family-name:var(--font-dm-mono)] font-medium tabular-nums">
                      {fmt(biologicalAgeComprehensive)} {t.years}
                    </span>
                  </span>
                </>
              )}
            </div>
            <a
              href={`/${locale}/metodologia`}
              className="font-medium text-[#3a665e] underline decoration-[#3a665e]/30 underline-offset-2 transition-colors hover:text-[#97472c]"
            >
              {t.kdmHowCalculated}
            </a>
          </div>
        )}
        {isKdm && bioAge != null && (
          <p className="mt-2 max-w-[80ch] text-[12px] leading-[1.6] text-[#8a7f76]">{t.kdmCreatine}</p>
        )}
      </div>
    </motion.section>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * FindingsBand — narrative pull quote + collapsible strength / needs
 * lists derived from the user's actual biomarker zones.
 *
 * Strengths are biomarkers in the OPTIMAL zone. "Needs attention" is
 * everything else (below_optimal, above_optimal, critical_low,
 * critical_high). Both lists are collapsed by default and toggle open
 * on click — they can be long and were previously taking over the
 * section.
 * ────────────────────────────────────────────────────────────────────────── */
function FindingsBand({
  t,
  latestLab,
  biomarkers,
}: {
  t: CopyT;
  latestLab: LabResult | null;
  biomarkers: BiomarkerValue[];
}) {
  // The "% optimal" stamp on the seal is computed against the
  // categorised population only — biomarkers we couldn't resolve
  // a reference range for (zone "unclassified") or that have no
  // panel category mapping shouldn't drag the percentage down,
  // since we have no defensible "should be optimal" expectation
  // for them. Same filter buildOrbLayout applies on the orb so the
  // two surfaces stay in agreement.
  const categorized = useMemo(
    () =>
      biomarkers.filter(
        (b) =>
          b.zone !== "unclassified" &&
          !!b.category &&
          b.category !== "uncategorized",
      ),
    [biomarkers],
  );
  const optimalCount = categorized.filter((b) => b.zone === "optimal").length;
  const categorizedTotal = categorized.length;

  // Out-of-range count: the stored codes critical_low / critical_high mean
  // outside the reference interval, not a critical value. Reuses the
  // existing zone classification on each biomarker — no recomputation.
  // Counted against the full panel (not just `categorized`) so an
  // out-of-range marker is never dropped for lacking a panel category.
  const locale = t.isEs ? "es" : "en";
  const outOfRangeCount = biomarkers.filter(
    (b) => b.zone === "critical_low" || b.zone === "critical_high",
  ).length;

  if (!latestLab) return null;
  // Locale-aware summary: a Spanish profile reads summary_narrative_es,
  // falling back to the English column only if the ES rendering is
  // missing (legacy labs generated before bilingual summaries).
  const summaryText = t.isEs
    ? latestLab.summary_narrative_es ?? latestLab.summary_narrative ?? ""
    : latestLab.summary_narrative ?? "";
  if (!summaryText) return null;

  // Reading citation — uppercase, abbreviated for the seal's curved
  // bottom arc. Falls back to the lab's collection_date, then to
  // created_at if the user didn't enter a draw date.
  const dateStr = latestLab.collection_date ?? latestLab.created_at;
  const sealDate = dateStr
    ? new Date(dateStr)
        .toLocaleDateString(t.isEs ? "es-ES" : "en-GB", {
          day: "numeric",
          month: "short",
          year: "numeric",
        })
        .toUpperCase()
    : null;

  const optimalPct =
    categorizedTotal > 0
      ? Math.round((optimalCount / categorizedTotal) * 100)
      : 0;

  // Plain narrative paragraphs (no special lede typesetting — the
  // section's identity comes from the dark accent panel surrounding
  // it, not from how the text is set).
  const paragraphs = summaryText
    .replace(/[ \t]+/g, " ")
    .trim()
    .split(/\n\s*\n/g)
    .map((p) => p.trim())
    .filter(Boolean);

  return (
    <motion.section
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-15%" }}
      className="relative isolate overflow-clip py-20 md:py-32"
      style={{
        // Full-bleed dark terra-deep panel that breaks out of the
        // dashboard's max-width container. Uses negative viewport
        // math so the background reaches the screen edges regardless
        // of the parent's centering.
        marginLeft: "calc(50% - 50vw)",
        marginRight: "calc(50% - 50vw)",
        width: "100vw",
        backgroundColor: "#5a2716",
        // Subtle radial warmth from the upper-left so the panel
        // reads as a hand-printed page, not a flat block of fill.
        backgroundImage:
          "radial-gradient(ellipse 80% 60% at 18% 22%, rgba(196,147,50,0.18), transparent 60%), radial-gradient(ellipse 90% 70% at 82% 92%, rgba(217,123,92,0.16), transparent 65%)",
      }}
    >
      {/* Decorative grain overlay — a noise-tinted layer to give the
          dark panel some materiality. Scoped to this section only. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.05] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
          backgroundRepeat: "repeat",
          backgroundSize: "256px 256px",
        }}
      />

      {/* Two faint hairline rules — one at the very top, one at the
          very bottom of the panel — in a warm gold tint, like the
          edges of a hot-foil-stamped page. */}
      <span
        aria-hidden
        className="absolute inset-x-0 top-0 z-10 h-px"
        style={{ backgroundColor: "rgba(196,147,50,0.28)" }}
      />
      <span
        aria-hidden
        className="absolute inset-x-0 bottom-0 z-10 h-px"
        style={{ backgroundColor: "rgba(196,147,50,0.28)" }}
      />

      <div className="relative z-20 mx-auto max-w-[1400px] px-5 md:px-10">
        {/* ─── Top strip — kicker only. The draw date used to live
                here too, but it now lives inside the Reading Seal's
                bottom arc, so we removed the duplicate. */}
        <header className="flex items-center gap-3">
          <span
            aria-hidden
            className="inline-block h-px w-10 md:w-14"
            style={{ backgroundColor: "rgba(196,147,50,0.55)" }}
          />
          <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2.4px] text-[#c49332] md:text-[11px] md:tracking-[2.6px]">
            {t.findings}
          </p>
        </header>

        {/* ─── Centerpiece composition ───
            Big asymmetric layout: a circular "READING SEAL" that
            anchors the visual identity, paired with the AI narrative
            in cream serif body type. The seal carries the verdict
            number (NN% optimal) at large scale; the narrative
            explains it. */}
        <div className="mt-14 grid grid-cols-1 items-start gap-12 md:mt-24 md:grid-cols-12 md:gap-16">
          {/* Reading seal — circular stamp-style mark.
              Mobile: small, top of column.
              Desktop: large, right column, slightly rotated for the
              hand-stamped feel. */}
          <div className="md:order-2 md:col-span-5 md:col-start-8">
            <ReadingSeal
              date={sealDate}
              percent={optimalPct}
              optimalShort={t.optimalShort}
              drawnLabel={t.drawn}
            />
          </div>

          {/* Narrative — cream serif body. The dark surrounding
              panel does the work of making this section feel
              important; the text just needs to be set comfortably
              and readably. */}
          <div className="md:order-1 md:col-span-7">
            <div
              className="space-y-5 font-[family-name:var(--font-cormorant)] text-[20px] font-medium leading-[1.45] text-[#fdedd6] md:text-[24px] md:leading-[1.45]"
              style={{ textWrap: "pretty" } as CSSProperties}
            >
              {paragraphs.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
            {/* Signature flourish — gold hairline rule + signature
                ink. Magazine-style sign-off. */}
            <div className="mt-10 flex items-center gap-3">
              <span
                aria-hidden
                className="inline-block h-px w-12 md:w-20"
                style={{ backgroundColor: "rgba(196,147,50,0.55)" }}
              />
              <p className="font-[family-name:var(--font-dm-mono)] text-[10px] uppercase tracking-[2.2px] text-[#c49332]">
                — EVA
              </p>
            </div>

            {/* Out-of-range notice — at the point of use, beneath the AI
                verdict, when any marker is outside the reference
                interval. tone="dark" gives it an opaque cream surface so
                it stays legible on the dark band. */}
            {outOfRangeCount > 0 && (
              <OutOfRangeNotice
                locale={locale}
                count={outOfRangeCount}
                tone="dark"
                className="mt-8"
              />
            )}

            {/* Point-of-use medical disclaimer (CLAIM-006 / AI-001) —
                dark-tone variant for the terra-deep band. */}
            <MedicalDisclaimer
              locale={locale}
              tone="dark"
              className="mt-8 border-t border-[rgba(253,237,214,0.18)] pt-6"
            />
          </div>
        </div>
      </div>
    </motion.section>
  );
}

/** ReadingSeal — the verdict mark.
 *
 * A circular stamp-style element that visually anchors the Verdict
 * Panel. Inside an outer hairline ring sit:
 *   - top arc text: "EVA · A LONGEVITY READING"
 *   - centre: the optimal percentage in big Cormorant numerals (gold)
 *   - bottom arc text: "READING NO. NN"
 *
 * The arc text is rendered with SVG textPath so the type curves
 * around the seal's perimeter — the move that makes it feel like an
 * actual stamp rather than a CSS badge. The whole element is rotated
 * a degree or two for the hand-applied feel. */
function ReadingSeal({
  date,
  drawnLabel,
  percent,
  optimalShort,
}: {
  /** Pre-formatted, uppercase. e.g. "12 DEC 2026". null hides the
   * bottom arc entirely. */
  date: string | null;
  /** Locale-aware "DRAWN" / "TOMADA" label preceding the date. */
  drawnLabel: string;
  percent: number;
  optimalShort: string;
}) {
  return (
    <div
      className="relative mx-auto aspect-square w-[220px] md:ml-auto md:mr-0 md:w-[300px] lg:w-[340px]"
      style={{
        // Slight rotation for the hand-stamped look. Pulled in by
        // the parent grid; on mobile it stays centred.
        transform: "rotate(-3deg)",
      }}
    >
      <svg
        viewBox="0 0 200 200"
        className="absolute inset-0 h-full w-full"
        aria-hidden
      >
        <defs>
          {/* Two paths used by the textPath elements: top arc reads
              left-to-right, bottom arc reads left-to-right (so it
              appears upright on the bottom of the seal). */}
          <path
            id="seal-arc-top"
            d="M 30 100 A 70 70 0 0 1 170 100"
          />
          <path
            id="seal-arc-bottom"
            d="M 32 108 A 68 68 0 0 0 168 108"
          />
        </defs>

        {/* Outer hairline ring */}
        <circle
          cx="100"
          cy="100"
          r="94"
          fill="none"
          stroke="rgba(196,147,50,0.5)"
          strokeWidth="0.5"
        />
        {/* Inner hairline ring */}
        <circle
          cx="100"
          cy="100"
          r="78"
          fill="none"
          stroke="rgba(196,147,50,0.4)"
          strokeWidth="0.4"
        />

        {/* Top arc text — brand + reading marker */}
        <text
          fill="#c49332"
          style={{
            fontFamily: "var(--font-dm-mono)",
            fontSize: "7px",
            letterSpacing: "0.22em",
            textTransform: "uppercase",
            fontWeight: 600,
          }}
        >
          <textPath href="#seal-arc-top" startOffset="50%" textAnchor="middle">
            EVA · A LONGEVITY READING
          </textPath>
        </text>

        {/* Bottom arc text — reading number */}
        {/* Bottom arc — the actual draw date in DRAWN-DD-MMM-YYYY
            form. Hides if no date is available so we never invent
            information. */}
        {date && (
          <text
            fill="#c49332"
            style={{
              fontFamily: "var(--font-dm-mono)",
              fontSize: "6.5px",
              letterSpacing: "0.26em",
              textTransform: "uppercase",
              fontWeight: 600,
            }}
          >
            <textPath
              href="#seal-arc-bottom"
              startOffset="50%"
              textAnchor="middle"
            >
              {`${drawnLabel} · ${date}`}
            </textPath>
          </text>
        )}

        {/* Two small ornament dots flanking the percentage */}
        <circle cx="44" cy="100" r="1.6" fill="rgba(196,147,50,0.6)" />
        <circle cx="156" cy="100" r="1.6" fill="rgba(196,147,50,0.6)" />

        {/* The percentage — big Cormorant numeral in gold */}
        <text
          x="100"
          y="106"
          textAnchor="middle"
          fill="#c49332"
          style={{
            fontFamily: "var(--font-cormorant)",
            fontSize: "44px",
            fontWeight: 500,
            letterSpacing: "-0.04em",
            fontVariantNumeric: "tabular-nums",
          }}
        >
          {percent}
          <tspan
            dx="2"
            style={{
              fontFamily: "var(--font-dm-mono)",
              fontSize: "12px",
              fontWeight: 600,
              letterSpacing: "0.04em",
            }}
          >
            %
          </tspan>
        </text>

        {/* "OPTIMAL" caption between numeral and bottom arc */}
        <text
          x="100"
          y="125"
          textAnchor="middle"
          fill="#fdedd6"
          opacity="0.7"
          style={{
            fontFamily: "var(--font-dm-mono)",
            fontSize: "5.5px",
            letterSpacing: "0.32em",
            textTransform: "uppercase",
            fontWeight: 600,
          }}
        >
          {optimalShort}
        </text>
      </svg>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * BiomarkerSection — category tabs at the top + filtered strata below.
 * Each marker is a horizontal rule track with a hover tooltip showing
 * the optimal and normal ranges plus the user's value.
 * ────────────────────────────────────────────────────────────────────────── */

function BiomarkerSection({
  t,
  locale,
  biomarkers,
  categories,
  selected,
  onSelect,
}: {
  t: CopyT;
  locale: string;
  biomarkers: BiomarkerValue[];
  categories: string[];
  selected: string | null;
  onSelect: (cat: string | null) => void;
}) {
  // Single-selection pinned tooltip. Lifted from BiomarkerTrack so that
  // tapping a new track closes the previously-open tooltip — users were
  // able to open multiple tooltips simultaneously before.
  const [pinnedBiomarkerId, setPinnedBiomarkerId] = useState<string | null>(
    null,
  );
  const togglePin = (id: string) => {
    setPinnedBiomarkerId((prev) => (prev === id ? null : id));
  };

  // The section now shows ONE category at a time. If the parent's
  // selection is null we fall back to the first category so the user
  // always sees something — and so the category list isn't a wall of
  // every marker stacked together. The hero left-rail still controls
  // `selected` and stays in sync with whichever tab is active here.
  const displayCategory = selected ?? categories[0] ?? null;

  const items = useMemo(() => {
    if (!displayCategory) return [];
    return biomarkers
      .filter((b) => b.category === displayCategory)
      .slice()
      .sort((a, b) => a.biomarker_key.localeCompare(b.biomarker_key));
  }, [biomarkers, displayCategory]);

  const countByCategory = useMemo(() => {
    const m = new Map<string, number>();
    for (const b of biomarkers) {
      m.set(b.category, (m.get(b.category) ?? 0) + 1);
    }
    return m;
  }, [biomarkers]);

  if (biomarkers.length === 0) return null;

  return (
    <motion.section
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-15%" }}
      className="relative border-t border-[#1d1b18]/10 py-14 md:py-28"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]">
          {t.biomarkers}
        </p>
        <h2 className="mt-2 max-w-[16ch] font-[family-name:var(--font-cormorant)] text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:mt-3 md:text-[72px] md:tracking-[-1px]">
          {t.biomarkersHeadingLead}{" "}
          <span className="italic text-[#3a665e]">{t.biomarkersHeadingAccent}</span>
        </h2>

        {/* ─── Category tabs ─── */}
        {/* Container is a hairline-framed strip with a calibration
            label on the left, like a section index in a periodical.
            On narrow screens it scrolls horizontally; on desktop it
            wraps to multiple rows so every category is visible. */}
        <div className="mt-8 md:mt-10">
          <div className="flex items-center gap-3 pb-2">
            <span
              aria-hidden
              className="inline-block h-px w-6 bg-[#1d1b18]/25"
            />
            <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76] md:text-[10px]">
              {t.category}
            </p>
          </div>
          <div
            className="-mx-5 flex items-center gap-1.5 overflow-x-auto rounded-2xl px-5 py-2 md:mx-0 md:flex-wrap md:gap-2 md:overflow-visible md:px-3 md:py-2.5"
            style={{
              scrollbarWidth: "none",
              WebkitOverflowScrolling: "touch",
              backgroundColor: "rgba(254,248,242,0.55)",
              boxShadow:
                "0 1px 0 rgba(255,255,255,0.85) inset, 0 1px 0 rgba(29,27,24,0.04) inset",
            }}
          >
            {categories.map((cat) => (
              <FilterTab
                key={cat}
                label={formatCategoryLabel(cat, locale)}
                count={countByCategory.get(cat) ?? 0}
                active={displayCategory === cat}
                onClick={() => onSelect(cat)}
              />
            ))}
          </div>
        </div>

        {/* ─── Single category strata ─── */}
        {displayCategory && items.length > 0 ? (
          <div className="mt-12 md:mt-16">
            <BiomarkerStratum
              t={t}
              locale={locale}
              category={displayCategory}
              items={items}
              pinnedId={pinnedBiomarkerId}
              onPinToggle={togglePin}
            />
          </div>
        ) : (
          <div className="mt-12 rounded-2xl border border-[#1d1b18]/10 bg-white/60 p-10 text-center">
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
              {t.noMarkersInCategory}
            </p>
          </div>
        )}
      </div>
    </motion.section>
  );
}

/* Editorial filter tab — pill button with the same calibrated terra
 * fill on active that the mobile dock uses, plus a soft warm shadow.
 * Inactive tabs sit on a near-transparent warm tint with no border so
 * the row reads as a single calm strip rather than a row of generic
 * outline pills. */
function FilterTab({
  label,
  count,
  active,
  onClick,
}: {
  label: string;
  count: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`group inline-flex shrink-0 items-center gap-2 rounded-full px-3.5 py-2 text-[11px] font-bold uppercase tracking-[1.4px] transition-[transform,background,box-shadow,color] duration-200 active:scale-[0.97] md:px-4 md:py-2.5 md:text-[12px]`}
      style={
        active
          ? {
              background: "linear-gradient(180deg, #97472c, #7a3a23)",
              color: "#fef8f2",
              boxShadow:
                "0 1px 0 rgba(255,220,200,0.25) inset, 0 6px 14px -6px rgba(151,71,44,0.5)",
            }
          : {
              background: "rgba(29,27,24,0.04)",
              color: "#4c463f",
            }
      }
    >
      {active && (
        <span
          aria-hidden
          className="h-1 w-1 rounded-full"
          style={{
            backgroundColor: "rgba(254,248,242,0.65)",
            boxShadow: "0 0 6px rgba(254,248,242,0.5)",
          }}
        />
      )}
      <span className="font-[family-name:var(--font-manrope)] capitalize">
        {label}
      </span>
      <span
        className="font-[family-name:var(--font-dm-mono)] text-[9.5px] font-semibold md:text-[10px]"
        style={{
          color: active ? "rgba(254,248,242,0.7)" : "#8a7f76",
          fontVariantNumeric: "tabular-nums",
        }}
      >
        {String(count).padStart(2, "0")}
      </span>
    </button>
  );
}

function BiomarkerStratum({
  t,
  locale,
  category,
  items,
  pinnedId,
  onPinToggle,
}: {
  t: CopyT;
  locale: string;
  category: string;
  items: BiomarkerValue[];
  pinnedId: string | null;
  onPinToggle: (id: string) => void;
}) {
  return (
    <div className="grid grid-cols-12 gap-6 border-t border-[#1d1b18]/10 pt-8">
      <div className="col-span-12 md:col-span-3">
        <p className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px] text-[#97472c]">
          {t.category}
        </p>
        <h3 className="mt-2 font-[family-name:var(--font-cormorant)] text-[40px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[56px]">
          {formatCategoryLabel(category, locale)}
        </h3>
        <p
          className="mt-2 font-[family-name:var(--font-dm-mono)] text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {String(items.length).padStart(2, "0")} {t.markers}
        </p>
      </div>

      <div className="col-span-12 space-y-3 md:col-span-9">
        {items.map((b) => (
          <BiomarkerTrack
            key={b.id}
            t={t}
            biomarker={b}
            isPinned={pinnedId === b.id}
            onPinToggle={onPinToggle}
          />
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * BiomarkerTrack — the hoverable rule track.
 *
 * The visible range is [lo, hi] derived from normal_low/high, optimal_low/high,
 * or a ±50% fallback around the value. The optimal range is drawn as a
 * soft band inside that; the current value is pinned on top.
 *
 * Hover: the whole row lights up with a subtle background + a tooltip
 * appears showing optimal range, normal range, current value, and zone.
 * ────────────────────────────────────────────────────────────────────────── */
function BiomarkerTrack({
  t,
  biomarker,
  isPinned,
  onPinToggle,
}: {
  t: CopyT;
  biomarker: BiomarkerValue;
  isPinned: boolean;
  onPinToggle: (id: string) => void;
}) {
  const color = ZONE_COLOR_M[biomarker.zone] ?? "#8a7f76";
  // `hovered` is the transient desktop hover state. The pinned state
  // lives in the parent BiomarkerSection so only one tooltip can be
  // open at a time. The tooltip is visible if either is true.
  const [hovered, setHovered] = useState(false);
  const showTooltip = hovered || isPinned;

  // Visible range.
  const lo =
    biomarker.normal_low ??
    biomarker.optimal_low ??
    biomarker.value * 0.5;
  const hi =
    biomarker.normal_high ??
    biomarker.optimal_high ??
    biomarker.value * 1.5;
  const optLo = biomarker.optimal_low ?? lo;
  const optHi = biomarker.optimal_high ?? hi;
  const span = hi - lo || 1;

  const clampedValue = Math.max(lo, Math.min(hi, biomarker.value));
  const valuePct = ((clampedValue - lo) / span) * 100;
  const optLoPct = ((optLo - lo) / span) * 100;
  const optHiPct = ((optHi - lo) / span) * 100;

  const zoneLabel = zoneLabelText(biomarker.zone, t.isEs);

  // Build the tooltip range strings with 2-decimal formatting.
  const hasOptimal =
    biomarker.optimal_low != null && biomarker.optimal_high != null;
  const hasNormal =
    biomarker.normal_low != null && biomarker.normal_high != null;

  return (
    <div
      className={`group relative -mx-3 cursor-pointer rounded-xl px-3 py-3 transition-colors duration-200 hover:bg-[rgba(29,27,24,0.03)] ${
        isPinned ? "bg-[rgba(29,27,24,0.04)]" : ""
      }`}
      // Pointer events cover mouse + pen. Hover state is transient —
      // good for desktop. Tap toggles the pinned state at the parent
      // so only one tooltip is ever open at a time.
      onPointerEnter={(e) => {
        if (e.pointerType === "mouse" || e.pointerType === "pen") {
          setHovered(true);
        }
      }}
      onPointerLeave={() => setHovered(false)}
      onClick={() => onPinToggle(biomarker.id)}
      onFocus={() => setHovered(true)}
      onBlur={() => setHovered(false)}
      tabIndex={0}
      role="button"
      aria-pressed={isPinned}
    >
      <div className="grid grid-cols-12 items-center gap-4">
        {/* Name */}
        <div className="col-span-12 md:col-span-4">
          <p className="font-[family-name:var(--font-manrope)] text-[14px] font-bold text-[#1d1b18]">
            {biomarker.biomarker_name}
          </p>
        </div>

        {/* Track */}
        <div className="col-span-9 md:col-span-6">
          <div className="relative h-[22px] w-full">
            {/* Base rule */}
            <div className="absolute inset-x-0 top-1/2 h-[1px] -translate-y-1/2 bg-[#1d1b18]/15" />
            {/* Tick marks at lo and hi */}
            <div className="absolute left-0 top-1/2 h-[10px] w-[1px] -translate-y-1/2 bg-[#1d1b18]/25" />
            <div className="absolute right-0 top-1/2 h-[10px] w-[1px] -translate-y-1/2 bg-[#1d1b18]/25" />
            {/* Optimal band */}
            <div
              className="absolute top-1/2 h-[12px] -translate-y-1/2 rounded-full transition-[height] duration-200 group-hover:h-[14px]"
              style={{
                left: `${optLoPct}%`,
                width: `${Math.max(2, optHiPct - optLoPct)}%`,
                background:
                  "linear-gradient(90deg, rgba(58,102,94,0.22), rgba(58,102,94,0.36))",
              }}
            />
            {/* Value pin */}
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-10%" }}
              transition={{ duration: 0.6, ease: EASE_OUT_EXPO }}
              className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${valuePct}%` }}
            >
              <span
                className="block h-[22px] w-[3px] rounded-full transition-[height,box-shadow] duration-200 group-hover:h-[26px]"
                style={{
                  backgroundColor: color,
                  boxShadow: `0 0 10px ${color}`,
                }}
              />
            </motion.div>
          </div>
        </div>

        {/* Value */}
        <div className="col-span-3 md:col-span-2 text-right">
          <p
            className="font-[family-name:var(--font-dm-mono)] text-[13px] font-bold"
            style={{ color, fontVariantNumeric: "tabular-nums" }}
          >
            {fmtMeasured(biomarker.value, biomarker.comparator)}
            {biomarker.unit && (
              <span className="ml-1 text-[10px] text-[#8a7f76]">
                {biomarker.unit}
              </span>
            )}
          </p>
        </div>
      </div>

      {/* Tooltip — shows full ranges. On mobile, pinned to the track's
          row width so it never overflows the viewport; on desktop it's
          a 280px card anchored near the value end of the track. */}
      {showTooltip && (
        <motion.div
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.16, ease: EASE_OUT_EXPO }}
          role="tooltip"
          className="pointer-events-none absolute left-3 right-3 top-full z-20 mt-2 rounded-2xl bg-[#1d1b18] p-4 font-[family-name:var(--font-jakarta)] text-[12px] text-white shadow-[0_20px_40px_-12px_rgba(29,27,24,0.5)] md:left-[calc(33%+1rem)] md:right-auto md:w-[280px]"
        >
          <div className="flex items-center gap-2">
            <span
              className="h-1.5 w-1.5 rounded-full"
              style={{ backgroundColor: color, boxShadow: `0 0 6px ${color}` }}
            />
            <p className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-white">
              {biomarker.biomarker_name}
            </p>
          </div>
          <dl className="mt-3 space-y-1.5 text-white/90">
            <TooltipRow label={t.value}>
              <span
                className="font-bold"
                style={{ color, fontVariantNumeric: "tabular-nums" }}
              >
                {fmtMeasured(biomarker.value, biomarker.comparator)}
                {biomarker.unit ? ` ${biomarker.unit}` : ""}
              </span>
            </TooltipRow>
            {hasOptimal && (
              <TooltipRow label={t.optimalRange}>
                <span
                  style={{ fontVariantNumeric: "tabular-nums" }}
                  className="text-[#bcece1]"
                >
                  {fmt(biomarker.optimal_low)} – {fmt(biomarker.optimal_high)}
                  {biomarker.unit ? ` ${biomarker.unit}` : ""}
                </span>
              </TooltipRow>
            )}
            {hasNormal && (
              <TooltipRow label={t.normalRange}>
                <span
                  style={{ fontVariantNumeric: "tabular-nums" }}
                  className="text-white/70"
                >
                  {fmt(biomarker.normal_low)} – {fmt(biomarker.normal_high)}
                  {biomarker.unit ? ` ${biomarker.unit}` : ""}
                </span>
              </TooltipRow>
            )}
            <TooltipRow label={t.zone}>
              <span
                className="font-bold uppercase tracking-[1px]"
                style={{ color }}
              >
                {zoneLabel}
              </span>
            </TooltipRow>
          </dl>
        </motion.div>
      )}
    </div>
  );
}

function TooltipRow({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.4px] text-white/50">
        {label}
      </dt>
      <dd className="text-right text-[12px]">{children}</dd>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * WearableRibbon — liquid blob tiles with fmt() applied to every number.
 * ────────────────────────────────────────────────────────────────────────── */
function WearableRibbon({
  t,
  wearable,
}: {
  t: CopyT;
  wearable: WearableData[];
}) {
  if (wearable.length === 0) return null;
  const latest = wearable[wearable.length - 1];
  const tiles = [
    { label: t.hrv, value: latest.hrv_ms, unit: t.ms, color: "#3a665e" },
    {
      label: t.restingHr,
      value: latest.resting_hr_bpm,
      unit: t.bpm,
      color: "#97472c",
    },
    {
      label: t.sleep,
      value: latest.sleep_hours,
      unit: t.hrs,
      color: "#c49332",
    },
    {
      label: t.respRate,
      value: latest.respiratory_rate,
      unit: t.brpm,
      color: "#3a665e",
    },
  ];

  return (
    <motion.section
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-15%" }}
      className="relative border-t border-[#1d1b18]/10 py-14 md:py-28"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]">
          {t.wearable}
        </p>
        <h2 className="mt-2 max-w-[16ch] font-[family-name:var(--font-cormorant)] text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:mt-3 md:text-[64px] md:tracking-[-1px]">
          {t.wearableHeadingLead}{" "}
          <span className="italic text-[#3a665e]">{t.wearableHeadingAccent}</span>
        </h2>
        <div className="mt-8 grid grid-cols-2 gap-3 md:mt-10 md:grid-cols-4 md:gap-6">
          {tiles.map((tile, i) => (
            <BlobTile key={tile.label} {...tile} index={i} />
          ))}
        </div>
      </div>
    </motion.section>
  );
}

function BlobTile({
  label,
  value,
  unit,
  color,
  index,
}: {
  label: string;
  value: number | null;
  unit: string;
  color: string;
  index: number;
}) {
  // Static seed per tile. We previously animated this via rAF to give
  // each blob a subtle wobble, but every seed change triggers an
  // `feTurbulence` recompute, which is one of the heaviest SVG filter
  // operations. Doing that 60×/s × 4 tiles was a measurable scroll
  // hit, so we now bake in a fixed seed per tile.
  const baseSeed = (index * 37) % 1000;

  const id = `merged-blob-${label.replace(/[^a-z]/gi, "")}-${index}`;

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 280, damping: 24 }}
      className="group relative aspect-[5/6] overflow-hidden rounded-[28px]"
      style={{
        background:
          "linear-gradient(170deg, rgba(255,255,255,0.9), rgba(254,248,242,0.7))",
        boxShadow:
          "0 1px 0 rgba(255,255,255,0.9) inset, 0 40px 80px -32px rgba(151,71,44,0.18), 0 12px 28px -14px rgba(58,102,94,0.14)",
      }}
    >
      <svg
        className="absolute inset-0 h-full w-full"
        viewBox="0 0 200 240"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden
      >
        <defs>
          <filter id={id} x="-50%" y="-50%" width="200%" height="200%">
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.012 0.018"
              numOctaves="2"
              seed={baseSeed}
            />
            <feDisplacementMap in="SourceGraphic" scale="24" />
          </filter>
          <radialGradient id={`${id}-g`} cx="50%" cy="55%" r="60%">
            <stop offset="0%" stopColor={color} stopOpacity="0.9" />
            <stop offset="55%" stopColor={color} stopOpacity="0.4" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </radialGradient>
        </defs>
        <g filter={`url(#${id})`}>
          <ellipse cx="100" cy="150" rx="100" ry="90" fill={`url(#${id}-g)`} />
        </g>
      </svg>
      <div className="relative flex h-full flex-col justify-between p-4 md:p-5">
        <div className="flex items-center gap-2">
          <span
            className="h-1.5 w-1.5 rounded-full"
            style={{ backgroundColor: color, boxShadow: `0 0 10px ${color}` }}
          />
          <span
            className="font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.6px]"
            style={{ color }}
          >
            {label}
          </span>
        </div>
        <div>
          <p
            className="font-[family-name:var(--font-cormorant)] text-[56px] font-medium leading-[0.85] tracking-[-1px] text-[#1d1b18] md:text-[88px] md:tracking-[-2px]"
            style={{ fontVariantNumeric: "tabular-nums" }}
          >
            {fmt(value)}
          </p>
          <p className="mt-1 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76]">
            {unit}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
 * ActionStepsCarousel — declassified medical blueprint grid.
 *
 * Each recommendation renders as a Field Card: editorial title +
 * monospace telemetry + corner registration marks, framed by hairline
 * borders. All cards visible at once in a 1/2/3-column responsive
 * grid (no carousel — the user wanted efficiency over the swipe).
 *
 * The aesthetic mash-up: Swiss Industrial Print structure (rigid
 * grids, 90° corners, mono telemetry) softened by the project's warm
 * cream substrate and editorial Cormorant titles. Reads as a future
 * doctor's field manual — half magazine column, half instrument
 * readout.
 * ────────────────────────────────────────────────────────────────────────── */
function ActionStepsCarousel({
  t,
  locale,
  actionSteps,
  biomarkers,
}: {
  t: CopyT;
  locale: string;
  actionSteps: ActionStep[];
  biomarkers: BiomarkerValue[];
}) {
  const biomarkerByKey = useMemo(() => {
    const m = new Map<string, BiomarkerValue>();
    for (const b of biomarkers) m.set(b.biomarker_key, b);
    return m;
  }, [biomarkers]);

  if (actionSteps.length === 0) return null;
  const total = actionSteps.length;

  return (
    <motion.section
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-15%" }}
      className="relative border-t border-[#1d1b18]/10 py-14 md:py-24"
    >
      <div className="mx-auto max-w-[1400px] px-5 md:px-10">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c] md:text-[11px] md:tracking-[2.4px]">
              {t.actions}
            </p>
            <h2 className="mt-2 max-w-[16ch] font-[family-name:var(--font-cormorant)] text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:mt-3 md:text-[64px] md:tracking-[-1px]">
              {t.actionsHeadingLead}{" "}
              <span className="italic text-[#97472c]">{t.actionsHeadingAccent}</span>
            </h2>
          </div>

          <p
            className="shrink-0 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.6px] text-[#97472c] md:text-[11px]"
            style={{ fontVariantNumeric: "tabular-nums" }}
          >
            [ {String(total).padStart(2, "0")} DIRECTIVES ]
          </p>
        </div>

        {/* Single-row horizontal carousel. Native CSS scroll-snap
            handles both mobile (touch swipe) and desktop (trackpad /
            shift-wheel scroll) without any pointer-capture JS — vertical
            page scroll passes through cleanly.

            Card basis is sized so a sliver of the next card peeks at
            the right edge as a scroll affordance: ~88% on mobile (one
            card + peek), ~50% on tablet (two cards), ~33% on xl
            (three cards). Negative margin + scroll-padding bleed the
            row to the viewport edge so cards visually flow off-screen
            instead of clipping at a hard rule. */}
        <div
          className="action-steps-scroll -mx-5 mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-px-5 px-5 pb-3 pt-1 md:-mx-10 md:mt-14 md:gap-5 md:scroll-px-10 md:px-10"
          style={{
            scrollbarWidth: "none",
            WebkitOverflowScrolling: "touch",
          }}
        >
          {actionSteps.map((step, i) => (
            <div
              key={step.id}
              className="flex shrink-0 snap-start basis-[88%] sm:basis-[60%] md:basis-[calc(50%-10px)] xl:basis-[calc(33.333%-14px)]"
            >
              <FieldCard
                t={t}
                locale={locale}
                step={step}
                index={i}
                total={total}
                biomarkerByKey={biomarkerByKey}
              />
            </div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}

/**
 * FieldCard — a single recommendation rendered as a declassified
 * medical blueprint sheet:
 *
 *   ┌─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┐
 *   ┘ [ RX·CRD·03 ] · CARDIOVASCULAR · 03 TGT  [ P1 ] └
 *   ────────────────────────────────────────────────────
 *     Fold lower-intensity zone-2
 *     cardio into your week.
 *
 *     150 minutes per week of zone-2 cardio drives...
 *   ────────────────────────────────────────────────────
 *     ─── TARGETS / READOUT
 *     ▸ APO B            ●  128 mg/dL    ABOVE
 *     ▸ HDL              ●   62 mg/dL    OPT
 *     ▸ TRIG             ●  142 mg/dL    ABOVE
 *   ┌─                                                ─┐
 *   ┘ UNIT-03/05                          C-RX-CRD-03 └
 *
 * Movie-direction details: L-shaped registration marks at all four
 * corners (terra-coloured tick marks like film crop marks); double
 * monospace spec lines top + bottom; editorial Cormorant title in
 * the middle; per-target instrument readouts. 90° corners only —
 * no border-radius, no soft shadow.
 */
function FieldCard({
  t,
  locale,
  step,
  index,
  total,
  biomarkerByKey,
}: {
  t: CopyT;
  locale: string;
  step: ActionStep;
  index: number;
  total: number;
  biomarkerByKey: Map<string, BiomarkerValue>;
}) {
  const targets = (step.related_biomarker_keys ?? [])
    .map((k) => biomarkerByKey.get(k))
    .filter((b): b is BiomarkerValue => !!b);

  const categoryCode = step.category.slice(0, 3).toUpperCase();
  const sequenceCode = String(index + 1).padStart(2, "0");
  const priorityCode = String(step.priority ?? 1);
  const serial = `RX·${categoryCode}·${sequenceCode}`;

  // Locale-aware action copy — a Spanish profile reads the *_es
  // columns, falling back to English only when an ES rendering is
  // missing (legacy steps generated before bilingual action steps).
  const title = t.isEs ? step.title_es ?? step.title : step.title;
  const description = t.isEs
    ? step.description_es ?? step.description
    : step.description;

  return (
    <article
      className="field-card relative flex w-full flex-col bg-[#fdedd6]"
      style={{
        boxShadow: "0 0 0 1px rgba(29,27,24,0.18) inset",
      }}
    >
      {/* Four L-shaped registration marks at the corners — like film
          crop marks. Subtle terra ink, sit just outside the card's
          hairline border so they read as registration not decoration. */}
      <CornerMark position="tl" />
      <CornerMark position="tr" />
      <CornerMark position="bl" />
      <CornerMark position="br" />

      {/* TOP SPEC LINE — telemetry header */}
      <header className="border-b border-[#1d1b18]/15 px-4 py-2.5 md:px-5">
        <p className="flex flex-wrap items-center gap-x-2 gap-y-1 font-[family-name:var(--font-dm-mono)] text-[9px] font-semibold uppercase tracking-[1.4px] text-[#1d1b18] md:text-[10px] md:tracking-[1.6px]">
          <span className="text-[#97472c]">[ {serial} ]</span>
          <span className="text-[#1d1b18]/35">·</span>
          <span className="truncate">{formatCategoryLabel(step.category, locale)}</span>
          <span className="text-[#1d1b18]/35">·</span>
          <span style={{ fontVariantNumeric: "tabular-nums" }}>
            {String(targets.length).padStart(2, "0")} TGT
          </span>
          <span className="ml-auto whitespace-nowrap text-[#97472c]">
            [ P{priorityCode} ]
          </span>
        </p>
      </header>

      {/* TITLE + DESCRIPTION — editorial body */}
      <div className="flex-1 px-4 py-5 md:px-5 md:py-6">
        <h3
          className="font-[family-name:var(--font-cormorant)] text-[24px] font-medium leading-[1.05] tracking-[-0.4px] text-[#1d1b18] md:text-[28px] md:leading-[1.05]"
          style={{ textWrap: "balance" } as CSSProperties}
        >
          {title}
        </h3>
        {description && (
          <p
            className="mt-3 font-[family-name:var(--font-jakarta)] text-[12.5px] leading-[1.55] text-[#4c463f] md:text-[13px] md:leading-[1.6]"
            style={{ textWrap: "pretty" } as CSSProperties}
          >
            {description}
          </p>
        )}
      </div>

      {/* TARGETS READOUT — instrument readings, one per row */}
      {targets.length > 0 && (
        <div className="border-t border-[#1d1b18]/15 px-4 py-3 md:px-5">
          <p className="mb-2 flex items-center gap-2 font-[family-name:var(--font-dm-mono)] text-[8.5px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76] md:text-[9px] md:tracking-[2px]">
            <span aria-hidden className="text-[#97472c]">───</span>
            <span>{t.targets} / Readout</span>
          </p>
          <ul>
            {targets.map((b) => {
              const tone = zoneTone(b.zone);
              const label = zoneShort(b.zone, t.isEs);
              return (
                <li
                  key={b.id}
                  className="grid grid-cols-[10px_1fr_auto_auto] items-center gap-x-2 py-0.5 font-[family-name:var(--font-dm-mono)] text-[10px] tracking-[0.04em] text-[#1d1b18]"
                  style={{ fontVariantNumeric: "tabular-nums" }}
                >
                  <span aria-hidden className="text-[#97472c]">▸</span>
                  <span className="truncate text-[10px] font-bold uppercase tracking-[0.06em]">
                    {b.biomarker_name}
                  </span>
                  <span
                    aria-hidden
                    className="text-[10px]"
                    style={{ color: tone }}
                  >
                    ●
                  </span>
                  <span
                    className="ml-1 whitespace-nowrap text-right text-[9.5px] font-semibold uppercase tracking-[0.08em]"
                    style={{ color: tone }}
                  >
                    {label}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {/* BOTTOM SPEC LINE — unit fraction + serial */}
      <footer className="border-t border-[#1d1b18]/15 px-4 py-2 md:px-5">
        <p
          className="flex items-center justify-between gap-2 font-[family-name:var(--font-dm-mono)] text-[8.5px] font-semibold uppercase tracking-[1.6px] text-[#1d1b18]/55 md:text-[9px] md:tracking-[1.8px]"
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          <span>
            UNIT-{sequenceCode}/{String(total).padStart(2, "0")}
          </span>
          <span className="text-[#97472c]">{`C·${serial}`}</span>
        </p>
      </footer>
    </article>
  );
}

/** L-shaped registration tick mark for the corners of a Field Card.
 * Tiny SVG so the lines are crisp at any DPR. */
function CornerMark({
  position,
}: {
  position: "tl" | "tr" | "bl" | "br";
}) {
  const isTop = position === "tl" || position === "tr";
  const isLeft = position === "tl" || position === "bl";
  return (
    <svg
      aria-hidden
      width="10"
      height="10"
      viewBox="0 0 10 10"
      className="pointer-events-none absolute"
      style={{
        ...(isTop ? { top: -1 } : { bottom: -1 }),
        ...(isLeft ? { left: -1 } : { right: -1 }),
      }}
    >
      <path
        d={
          isTop && isLeft
            ? "M0 0 L0 8 M0 0 L8 0"
            : isTop && !isLeft
              ? "M10 0 L10 8 M10 0 L2 0"
              : !isTop && isLeft
                ? "M0 10 L0 2 M0 10 L8 10"
                : "M10 10 L10 2 M10 10 L2 10"
        }
        stroke="#97472c"
        strokeWidth="1"
        fill="none"
      />
    </svg>
  );
}

/** Zone color helper — same palette as the orb's nodes. */
function zoneTone(zone: BiomarkerValue["zone"]): string {
  if (zone === "optimal") return "#3a665e";
  if (zone === "critical_low" || zone === "critical_high") return "#b04040";
  if (zone === "unclassified") return "#8a7f76";
  return "#c49332";
}

/** Compact zone label used in the targets readout. Mono-friendly,
 * fits in a small fixed-width column. */
function zoneShort(zone: BiomarkerValue["zone"], isEs: boolean): string {
  if (zone === "optimal") return isEs ? "ÓPT" : "OPT";
  if (zone === "below_optimal") return isEs ? "BAJO" : "BELOW";
  if (zone === "above_optimal") return isEs ? "ALTO" : "ABOVE";
  if (zone === "critical_low") return isEs ? "<RANGO" : "<RANGE";
  if (zone === "critical_high") return isEs ? ">RANGO" : ">RANGE";
  return "—";
}

/** Full zone label for the biomarker tooltip, in the user's language. */
function zoneLabelText(zone: BiomarkerValue["zone"], isEs: boolean): string {
  const labels: Record<BiomarkerValue["zone"], [string, string]> = {
    optimal: ["optimal", "óptimo"],
    below_optimal: ["below optimal", "por debajo del óptimo"],
    above_optimal: ["above optimal", "por encima del óptimo"],
    critical_low: ["below range", "por debajo del rango"],
    critical_high: ["above range", "por encima del rango"],
    unclassified: ["unclassified", "sin clasificar"],
  };
  const pair = labels[zone];
  return pair ? pair[isEs ? 1 : 0] : zone;
}

/* ──────────────────────────────────────────────────────────────────────────
 * NextTestFooter — dark band from Direction C.
 * ────────────────────────────────────────────────────────────────────────── */
function NextTestFooter({
  t,
  locale,
  nextTest,
}: {
  t: CopyT;
  locale: string;
  nextTest: BookedTest | undefined;
}) {
  return (
    <motion.section
      variants={fadeUp}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-15%" }}
      className="relative overflow-clip bg-[#1d1b18] py-14 text-white md:py-28"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at 80% 20%, rgba(217,123,92,0.25), transparent 50%), radial-gradient(circle at 10% 85%, rgba(58,102,94,0.2), transparent 55%)",
        }}
      />
      <div className="relative mx-auto grid max-w-[1400px] grid-cols-1 gap-6 px-5 md:grid-cols-12 md:items-end md:gap-10 md:px-10">
        <div className="md:col-span-7">
          <p className="font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[2px] text-[#d97b5c] md:text-[11px] md:tracking-[2.4px]">
            {t.nextTest}
          </p>
          <h2 className="mt-2 font-[family-name:var(--font-cormorant)] text-[48px] font-medium leading-[0.92] tracking-[-1px] md:mt-3 md:text-[104px] md:tracking-[-1.5px]">
            {nextTest ? (
              nextTest.scheduled_date ? (
                new Date(nextTest.scheduled_date).toLocaleDateString(
                  locale === "es" ? "es-ES" : "en-GB",
                  { day: "numeric", month: "long" },
                )
              ) : (
                nextTest.panel_type
              )
            ) : (
              <span className="italic text-[#d97b5c]">{t.nothingScheduled}</span>
            )}
          </h2>
          {nextTest?.scheduled_date && (
            <p className="mt-3 font-[family-name:var(--font-dm-mono)] text-[11px] uppercase tracking-[1.6px] text-white/60">
              {new Date(nextTest.scheduled_date).getFullYear()} ·{" "}
              {nextTest.panel_type}
            </p>
          )}
        </div>
        <div className="flex flex-col items-start gap-4 md:col-span-5 md:items-end">
          <Link
            href={`/${locale}/book`}
            className="group inline-flex items-center gap-3 rounded-full border border-white/20 bg-white/5 px-6 py-3 backdrop-blur transition-[background,border-color,transform] duration-200 hover:bg-white/10 active:scale-[0.97]"
          >
            <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold uppercase tracking-[1.2px]">
              {t.bookNow}
            </span>
            <svg
              className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M5 12h14M13 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </motion.section>
  );
}
