"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { DashboardChrome, EditorialMasthead } from "@/components/dashboard";
import { fadeUp } from "@/lib/dashboard-motion";
import {
  FONT_CLASS,
  BIOMARKER_CATEGORY_COLORS,
} from "@/lib/dashboard-tokens";
import {
  yearRoman,
  quarterRoman,
  formatDayMonth,
  fmtValue,
  fmtMeasured,
} from "@/lib/dashboard-format";
import type { WearableData } from "@/lib/queries/types";

/** Same unit modulo case, spacing and the usual glyph variants (µ/μ, ×, ³). */
function sameUnit(a: string, b: string): boolean {
  const n = (u: string) =>
    u.toLowerCase().replace(/\s+/g, "").replace(/[µμ]/g, "u").replace(/×/g, "x").replace(/³/g, "3").replace(/⁶/g, "6").replace(/ui(?=\/|$)/g, "iu");
  return n(a) === n(b);
}

interface HistoricalValue {
  id: string;
  biomarker_key: string;
  biomarker_name: string | null;
  value: number;
  unit: string;
  zone: string;
  optimal_low: number | null;
  optimal_high: number | null;
  normal_low: number | null;
  normal_high: number | null;
  /** What the lab printed before any rescale/conversion (rows since 2026-09-17). */
  reported_value?: number | null;
  reported_unit?: string | null;
  /** "<" / ">" when the lab reported a bound rather than an exact figure. */
  comparator?: "<" | ">" | null;
  interpretation: string | null;
  interpretation_es: string | null;
  lab_results: {
    collection_date: string;
    source: string;
  };
}

interface Reference {
  name_en: string;
  name_es: string;
  optimal_low: number | null;
  optimal_high: number | null;
  normal_low: number | null;
  normal_high: number | null;
  clinical_notes_en: string | null;
  clinical_notes_es: string | null;
  is_genetic: boolean;
  is_base_panel: boolean;
  panel_category: string;
}

interface BiomarkerDetailClientProps {
  locale: string;
  biomarkerKey: string;
  latest: HistoricalValue | null;
  historicalValues: HistoricalValue[];
  reference: Reference | null;
  wearable: WearableData[];
}

function zoneAccent(zone: string): {
  stroke: string;
  tint: string;
  label: { en: string; es: string };
  italic: { en: string; es: string };
} {
  if (zone === "optimal")
    return {
      stroke: "#3a665e",
      tint: "rgba(58,102,94,0.08)",
      label: { en: "Optimal", es: "Optimo" },
      italic: { en: "in optimal range", es: "en rango optimo" },
    };
  if (zone === "below_optimal")
    return {
      stroke: "#c49332",
      tint: "rgba(196,147,50,0.10)",
      label: { en: "Attention", es: "Atencion" },
      italic: { en: "trending low", es: "tendiendo bajo" },
    };
  if (zone === "above_optimal")
    return {
      stroke: "#c49332",
      tint: "rgba(196,147,50,0.10)",
      label: { en: "Attention", es: "Atencion" },
      italic: { en: "trending high", es: "tendiendo alto" },
    };
  if (zone === "critical_low")
    return {
      stroke: "#b04040",
      tint: "rgba(176,64,64,0.08)",
      label: { en: "Out of range", es: "Fuera de rango" },
      italic: { en: "below the range", es: "por debajo del rango" },
    };
  if (zone === "critical_high")
    return {
      stroke: "#b04040",
      tint: "rgba(176,64,64,0.08)",
      label: { en: "Out of range", es: "Fuera de rango" },
      italic: { en: "above the range", es: "por encima del rango" },
    };
  return {
    stroke: "#8a7f76",
    tint: "rgba(138,127,118,0.08)",
    label: { en: "—", es: "—" },
    italic: { en: "unclassified", es: "sin clasificar" },
  };
}

function categoryAccent(category: string | undefined): string {
  if (!category) return "#3a665e";
  return BIOMARKER_CATEGORY_COLORS[category] ?? "#3a665e";
}

function categoryDisplay(category: string | undefined, locale: string): string {
  if (!category) return locale === "es" ? "Sin categoria" : "Unfiled";
  const map: Record<string, { en: string; es: string }> = {
    cardiovascular: { en: "Cardiovascular", es: "Cardiovascular" },
    metabolic: { en: "Metabolic", es: "Metabolico" },
    hormonal: { en: "Hormonal", es: "Hormonal" },
    thyroid: { en: "Thyroid", es: "Tiroides" },
    inflammatory: { en: "Inflammatory", es: "Inflamatorio" },
    nutrition: { en: "Nutrition", es: "Nutricion" },
    liver: { en: "Liver", es: "Higado" },
    kidney: { en: "Kidney", es: "Rinon" },
    immune: { en: "Immune", es: "Inmune" },
  };
  const entry = map[category];
  if (!entry)
    return category.charAt(0).toUpperCase() + category.slice(1).replace(/_/g, " ");
  return locale === "es" ? entry.es : entry.en;
}

function paragraphsOf(text: string | null | undefined): string[] {
  if (!text) return [];
  return text
    .replace(/[ \t]+/g, " ")
    .trim()
    .split(/\n\s*\n/g)
    .map((p) => p.trim())
    .filter(Boolean);
}

/* Inline MonographMasthead removed — page now uses the shared
 * EditorialMasthead with a custom volSuffix that carries the
 * "Chapter <category>" caption. */

/* ──────────────────────────────────────────────────────────────────────
 * EditorialRangeBar — replaces the bordered RangeBar card. A single
 * hairline horizontal scale with a jade-tinted optimal band, mono
 * range labels, and a tabular value pin labeled with the current
 * reading.
 * ────────────────────────────────────────────────────────────────────── */
function EditorialRangeBar({
  value,
  optimalLow,
  optimalHigh,
  normalLow,
  normalHigh,
  unit,
  zone,
  locale,
}: {
  value: number;
  optimalLow: number | null;
  optimalHigh: number | null;
  normalLow: number | null;
  normalHigh: number | null;
  unit: string;
  zone: string;
  locale: string;
}) {
  const z = zoneAccent(zone);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const all = [value];
  if (optimalLow != null) all.push(optimalLow);
  if (optimalHigh != null) all.push(optimalHigh);
  if (normalLow != null) all.push(normalLow);
  if (normalHigh != null) all.push(normalHigh);
  const dataMin = Math.min(...all);
  const dataMax = Math.max(...all);
  const pad = (dataMax - dataMin) * 0.15 || dataMax * 0.2 || 10;
  const lo = dataMin - pad;
  const hi = dataMax + pad;
  const span = hi - lo || 1;
  const pct = (v: number) =>
    Math.max(0, Math.min(100, ((v - lo) / span) * 100));

  const valuePct = pct(value);
  const oLowPct = optimalLow != null ? pct(optimalLow) : null;
  const oHighPct = optimalHigh != null ? pct(optimalHigh) : null;
  const nLowPct = normalLow != null ? pct(normalLow) : null;
  const nHighPct = normalHigh != null ? pct(normalHigh) : null;

  // Stratified zone bands. Brand-palette fills only — terra-red, gold
  // and jade at varying opacity over cream so each zone is visibly
  // its brand colour but soft enough that the value pin and the
  // EVA OPTIMAL watermark read cleanly on top. Optimal carries the
  // strongest tint plus a 2px solid jade frame so the chamber is
  // unmistakable from any zone state.
  const FILL: Record<"critical" | "attention" | "optimal", string> = {
    critical: "rgba(176,64,64,0.12)",
    attention: "rgba(196,147,50,0.20)",
    optimal: "rgba(58,102,94,0.32)",
  };

  const FILL_HOVER: Record<"critical" | "attention" | "optimal", string> = {
    critical: "rgba(176,64,64,0.22)",
    attention: "rgba(196,147,50,0.32)",
    optimal: "rgba(58,102,94,0.42)",
  };

  const SOLID = {
    critical: "#b04040",
    attention: "#c49332",
    optimal: "#3a665e",
  };

  const oLow = oLowPct ?? null;
  const oHigh = oHighPct ?? null;
  const nLow = nLowPct ?? oLow ?? null;
  const nHigh = nHighPct ?? oHigh ?? null;

  // Effective optimal frame edges — for one-sided ranges (e.g. vitamin D
  // with only optimal_low set, or LDL with only optimal_high), the
  // missing edge defaults to the bar boundary so the jade chamber still
  // renders.
  const oFrameLeft = oLow ?? 0;
  const oFrameRight = oHigh ?? 100;

  const lblCritical = locale === "es" ? "Fuera de rango" : "Out of range";
  const lblAttention = locale === "es" ? "Atencion" : "Attention";
  const lblOptimal = locale === "es" ? "EVA optimo" : "EVA optimal";

  // Optimal-range label handles one-sided cases.
  const optimalRangeLabel =
    optimalLow != null && optimalHigh != null
      ? `${fmtValue(optimalLow)}–${fmtValue(optimalHigh)}`
      : optimalLow != null
        ? `≥ ${fmtValue(optimalLow)}`
        : optimalHigh != null
          ? `≤ ${fmtValue(optimalHigh)}`
          : "";

  type ZoneCell = {
    kind: "critical" | "attention" | "optimal";
    label: string;
    range: string;
    left: number;
    width: number;
  };

  const zones: ZoneCell[] = [];

  // Critical low — only when normal_low is set.
  if (nLow != null && normalLow != null) {
    zones.push({
      kind: "critical",
      label: lblCritical,
      range: `< ${fmtValue(normalLow)}`,
      left: 0,
      width: nLow,
    });
  }

  // Attention low — only when normal_low AND optimal_low are both set.
  if (
    nLow != null &&
    oLow != null &&
    normalLow != null &&
    optimalLow != null &&
    optimalLow > normalLow
  ) {
    zones.push({
      kind: "attention",
      label: lblAttention,
      range: `${fmtValue(normalLow)}–${fmtValue(optimalLow)}`,
      left: nLow,
      width: Math.max(0, oLow - nLow),
    });
  }

  // Optimal — render whenever AT LEAST ONE optimal bound exists.
  // Critically: the previous version required both bounds, which
  // hid the optimal band entirely for one-sided markers. Now we
  // always render it when optimal data exists, with the missing
  // edge running to the bar boundary.
  if (optimalLow != null || optimalHigh != null) {
    zones.push({
      kind: "optimal",
      label: lblOptimal,
      range: optimalRangeLabel,
      left: oFrameLeft,
      width: Math.max(0, oFrameRight - oFrameLeft),
    });
  }

  // Attention high — only when optimal_high AND normal_high are both set.
  if (
    oHigh != null &&
    nHigh != null &&
    optimalHigh != null &&
    normalHigh != null &&
    normalHigh > optimalHigh
  ) {
    zones.push({
      kind: "attention",
      label: lblAttention,
      range: `${fmtValue(optimalHigh)}–${fmtValue(normalHigh)}`,
      left: oHigh,
      width: Math.max(0, nHigh - oHigh),
    });
  }

  // Critical high — only when normal_high is set.
  if (nHigh != null && normalHigh != null) {
    zones.push({
      kind: "critical",
      label: lblCritical,
      range: `> ${fmtValue(normalHigh)}`,
      left: nHigh,
      width: Math.max(0, 100 - nHigh),
    });
  }
  const visibleZones = zones.filter((z) => z.width > 0);

  // Boundary tick positions for the numerical labels under the bar.
  const boundaries: { value: number; pct: number }[] = [];
  if (normalLow != null) boundaries.push({ value: normalLow, pct: pct(normalLow) });
  if (optimalLow != null) boundaries.push({ value: optimalLow, pct: pct(optimalLow) });
  if (optimalHigh != null) boundaries.push({ value: optimalHigh, pct: pct(optimalHigh) });
  if (normalHigh != null) boundaries.push({ value: normalHigh, pct: pct(normalHigh) });
  const seen = new Set<number>();
  const uniqueBoundaries = boundaries.filter((b) => {
    if (seen.has(b.value)) return false;
    seen.add(b.value);
    return true;
  });

  return (
    <div className="w-full">
      {/* The bar: stratified zones + jade optimal frame + value pin.
          The wrapper is a `group` so the optimal band can pulse on
          hover and the zones can intensify in response to mouse
          position. */}
      <div className="group relative h-20">
        {/* Tooltip rail above the bar */}
        <div className="pointer-events-none absolute inset-x-0 -top-1 h-8">
          {hoveredIndex !== null && visibleZones[hoveredIndex] && (
            <div
              className={`absolute -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-full px-3 py-1 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.4px] text-[#fef8f2] shadow-[0_8px_20px_-6px_rgba(29,27,24,0.35)]`}
              style={{
                left: `${visibleZones[hoveredIndex].left + visibleZones[hoveredIndex].width / 2}%`,
                backgroundColor: SOLID[visibleZones[hoveredIndex].kind],
              }}
            >
              {visibleZones[hoveredIndex].label}{" "}
              <span className="font-medium normal-case tracking-normal text-[#fef8f2]/85">
                · {visibleZones[hoveredIndex].range}
                {unit && ` ${unit}`}
              </span>
            </div>
          )}
        </div>

        {/* Stratified, hover-aware zone bands */}
        {visibleZones.map((z, i) => {
          const isHover = hoveredIndex === i;
          return (
            <div
              key={i}
              role="presentation"
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
              className="absolute top-1/2 h-12 -translate-y-1/2 cursor-help transition-[background-color] duration-200 ease-out"
              style={{
                left: `${z.left}%`,
                width: `${z.width}%`,
                backgroundColor: isHover ? FILL_HOVER[z.kind] : FILL[z.kind],
              }}
            />
          );
        })}

        {/* Solid jade frame on the optimal chamber (rendered last so
            it sits on top of the band tints). Renders whenever AT
            LEAST ONE optimal bound is set — for one-sided ranges the
            missing edge runs to the bar boundary. The pulse
            animation kicks in when the bar is hovered. */}
        {(optimalLow != null || optimalHigh != null) && (
          <div
            aria-hidden
            className="pointer-events-none absolute top-1/2 h-12 -translate-y-1/2 rounded-[3px] transition-shadow duration-300 group-hover:[animation:rangePulse_1.8s_ease-in-out_infinite]"
            style={{
              left: `${oFrameLeft}%`,
              width: `${Math.max(0, oFrameRight - oFrameLeft)}%`,
              boxShadow:
                "inset 0 0 0 2px #3a665e, 0 0 0 0 rgba(58,102,94,0.0)",
            }}
          >
            {/* Inline EVA OPTIMAL watermark inside the band */}
            <div className="absolute inset-0 flex items-center justify-center">
              <span
                className={`${FONT_CLASS.dmMono} text-[10px] font-bold uppercase tracking-[2.4px] text-[#3a665e] md:text-[11px]`}
                style={{ textShadow: "0 1px 0 rgba(254,248,242,0.6)" }}
              >
                {locale === "es" ? "EVA OPTIMO" : "EVA OPTIMAL"}
              </span>
            </div>
          </div>
        )}

        {/* Boundary tick lines */}
        {uniqueBoundaries.map((b) => (
          <span
            key={`tick-${b.value}`}
            aria-hidden
            className="pointer-events-none absolute top-1/2 h-14 w-px -translate-y-1/2 bg-[#1d1b18]/25"
            style={{ left: `${b.pct}%` }}
          />
        ))}

        {/* Value pin */}
        <div
          className="pointer-events-none absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${valuePct}%` }}
        >
          <div className="flex flex-col items-center">
            <span
              className={`${FONT_CLASS.dmMono} -mt-1 mb-1 whitespace-nowrap rounded-full bg-[#fef8f2] px-2.5 py-0.5 text-[12px] font-semibold tabular-nums`}
              style={{
                color: z.stroke,
                boxShadow: `inset 0 0 0 1.5px ${z.stroke}, 0 4px 12px rgba(29,27,24,0.10)`,
              }}
            >
              {fmtValue(value)}
              {unit && (
                <span className="ml-1 text-[9px] tracking-[1px] text-[#8a7f76]">
                  {unit}
                </span>
              )}
            </span>
            <span
              aria-hidden
              className="block h-5 w-[2px]"
              style={{ backgroundColor: z.stroke }}
            />
            <span
              aria-hidden
              className="-mt-[2px] block h-3 w-3 rotate-45 border-[2px] border-[#fef8f2]"
              style={{ backgroundColor: z.stroke }}
            />
          </div>
        </div>

        {/* Local keyframes for the optimal pulse */}
        <style jsx>{`
          @keyframes rangePulse {
            0%,
            100% {
              box-shadow:
                inset 0 0 0 2px #3a665e,
                0 0 0 0 rgba(58, 102, 94, 0.45);
            }
            50% {
              box-shadow:
                inset 0 0 0 2px #3a665e,
                0 0 0 6px rgba(58, 102, 94, 0);
            }
          }
        `}</style>
      </div>

      {/* Boundary number labels — pinned under each zone transition */}
      {uniqueBoundaries.length > 0 && (
        <div className="relative mt-2 h-4">
          {uniqueBoundaries.map((b) => (
            <span
              key={`lbl-${b.value}`}
              className={`absolute -translate-x-1/2 ${FONT_CLASS.dmMono} text-[10px] tabular-nums text-[#1d1b18]/70`}
              style={{ left: `${b.pct}%` }}
            >
              {fmtValue(b.value)}
            </span>
          ))}
        </div>
      )}

      {/* Color legend — one cell per zone, with label and numerical
          range. Wraps on mobile and stretches into a single row on
          desktop. */}
      <div className="mt-7 flex flex-wrap gap-x-5 gap-y-4 border-t border-[#1d1b18]/10 pt-5">
        {visibleZones.map((cell, i) => (
          <div
            key={i}
            className="flex min-w-[120px] flex-1 items-start gap-2.5"
          >
            <span
              aria-hidden
              className="mt-[3px] inline-block h-2.5 w-2.5 shrink-0 rounded-[1px]"
              style={{ backgroundColor: SOLID[cell.kind] }}
            />
            <div className="min-w-0">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px]`}
                style={{ color: SOLID[cell.kind] }}
              >
                {cell.label}
              </p>
              <p
                className={`mt-0.5 ${FONT_CLASS.dmMono} text-[11px] tabular-nums text-[#1d1b18] ${
                  cell.kind === "optimal" ? "font-semibold" : "font-medium"
                }`}
              >
                {cell.range}
                {unit && (
                  <span className="ml-1 text-[9px] tracking-[1px] text-[#8a7f76]">
                    {unit}
                  </span>
                )}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * MonographTrend — custom SVG sparkline timeline. Replaces recharts
 * with a hand-set magazine plate: jade optimal band, dashed hairline
 * band edges, terra connecting line, tabular DM Mono value labels
 * above each dot, mono date labels beneath.
 * ────────────────────────────────────────────────────────────────────── */
function MonographTrend({
  data,
  optimalLow,
  optimalHigh,
  unit,
  locale,
}: {
  data: { date: string; value: number; source: string }[];
  optimalLow: number | null;
  optimalHigh: number | null;
  unit: string;
  locale: string;
}) {
  if (data.length < 2) return null;
  const sorted = [...data].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
  );

  const W = 800;
  const H = 280;
  const padL = 60; // room for Y-axis threshold values
  const padR = 110; // room for "EVA OPTIMAL" label
  const padT = 50;
  const padB = 60;

  const allY = [...sorted.map((d) => d.value)];
  if (optimalLow != null) allY.push(optimalLow);
  if (optimalHigh != null) allY.push(optimalHigh);
  const yMinData = Math.min(...allY);
  const yMaxData = Math.max(...allY);
  const yPad = (yMaxData - yMinData) * 0.2 || yMaxData * 0.2 || 1;
  const yLow = yMinData - yPad;
  const yHigh = yMaxData + yPad;
  const ySpan = yHigh - yLow || 1;

  const px = (i: number) =>
    sorted.length === 1
      ? W / 2
      : padL + (i / (sorted.length - 1)) * (W - padL - padR);
  const py = (v: number) =>
    padT + (1 - (v - yLow) / ySpan) * (H - padT - padB);

  const path = sorted
    .map(
      (d, i) =>
        `${i === 0 ? "M" : "L"} ${px(i).toFixed(2)} ${py(d.value).toFixed(2)}`,
    )
    .join(" ");

  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="w-full"
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label={locale === "es" ? "Historial de lecturas" : "Reading history"}
    >
      {/* Optimal band */}
      {optimalLow != null && optimalHigh != null && (
        <>
          <rect
            x={padL}
            y={py(optimalHigh)}
            width={W - padL - padR}
            height={Math.max(0, py(optimalLow) - py(optimalHigh))}
            fill="rgba(58,102,94,0.08)"
          />
          <line
            x1={padL}
            y1={py(optimalHigh)}
            x2={W - padR}
            y2={py(optimalHigh)}
            stroke="rgba(58,102,94,0.35)"
            strokeWidth="1"
            strokeDasharray="6 6"
          />
          <line
            x1={padL}
            y1={py(optimalLow)}
            x2={W - padR}
            y2={py(optimalLow)}
            stroke="rgba(58,102,94,0.35)"
            strokeWidth="1"
            strokeDasharray="6 6"
          />
          {/* Threshold values pinned to the left axis at the band edges */}
          <text
            x={padL - 10}
            y={py(optimalHigh) + 4}
            textAnchor="end"
            fontFamily="var(--font-dm-mono)"
            fontSize="12"
            fill="#3a665e"
            fontWeight="600"
          >
            {fmtValue(optimalHigh)}
          </text>
          <text
            x={padL - 10}
            y={py(optimalLow) + 4}
            textAnchor="end"
            fontFamily="var(--font-dm-mono)"
            fontSize="12"
            fill="#3a665e"
            fontWeight="600"
          >
            {fmtValue(optimalLow)}
          </text>
          {/* Right-edge caption */}
          <text
            x={W - padR + 10}
            y={py(optimalHigh) + 4}
            fontFamily="var(--font-dm-mono)"
            fontSize="11"
            fill="#3a665e"
            fontWeight="600"
            letterSpacing="2"
          >
            {(locale === "es" ? "EVA OPTIMO" : "EVA OPTIMAL").toUpperCase()}
          </text>
          <text
            x={W - padR + 10}
            y={py(optimalHigh) + 22}
            fontFamily="var(--font-dm-mono)"
            fontSize="10"
            fill="#3a665e"
            fillOpacity="0.7"
          >
            {fmtValue(optimalLow)}–{fmtValue(optimalHigh)} {unit}
          </text>
        </>
      )}

      {/* Bottom hairline */}
      <line
        x1={padL}
        y1={H - padB}
        x2={W - padR}
        y2={H - padB}
        stroke="rgba(29,27,24,0.20)"
        strokeWidth="1"
      />

      {/* Connecting line */}
      <path
        d={path}
        stroke="#97472c"
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Dots + labels */}
      {sorted.map((d, i) => {
        const x = px(i);
        const y = py(d.value);
        const isLatest = i === sorted.length - 1;
        const isEva = d.source === "eva_kit" || d.source === "eva";
        const dt = new Date(d.date);
        const dateStr = dt
          .toLocaleDateString(locale === "es" ? "es-ES" : "en-GB", {
            day: "2-digit",
            month: "short",
          })
          .toUpperCase();
        return (
          <g key={`${d.date}-${i}`}>
            <circle
              cx={x}
              cy={y}
              r={isLatest ? 7 : 5}
              fill={isLatest ? "#97472c" : "#1d1b18"}
              stroke="#fef8f2"
              strokeWidth={isLatest ? 3 : 2}
            />
            <text
              x={x}
              y={y - 16}
              textAnchor="middle"
              fontFamily="var(--font-dm-mono)"
              fontSize={isLatest ? "16" : "13"}
              fill={isLatest ? "#97472c" : "#1d1b18"}
              fontWeight={isLatest ? "600" : "500"}
            >
              {fmtValue(d.value)}
            </text>
            <text
              x={x}
              y={H - padB + 22}
              textAnchor="middle"
              fontFamily="var(--font-dm-mono)"
              fontSize="10"
              fill={isLatest ? "#97472c" : "#8a7f76"}
              fontWeight={isLatest ? "600" : "500"}
              letterSpacing="1.4"
            >
              {dateStr}
            </text>
            {isEva && (
              <text
                x={x}
                y={H - padB + 38}
                textAnchor="middle"
                fontFamily="var(--font-dm-mono)"
                fontSize="9"
                fill="#97472c"
                fontWeight="600"
                letterSpacing="2"
              >
                EVA
              </text>
            )}
            <text
              x={x}
              y={y + 22}
              textAnchor="middle"
              fontFamily="var(--font-dm-mono)"
              fontSize="9"
              fill="#8a7f76"
              letterSpacing="1.2"
            >
              {unit}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

/* ──────────────────────────────────────────────────────────────────────
 * EditorialProseBlock — section header + drop-cap'd paragraph stack.
 * Used by "What this measures" and "What this reading shows".
 * ────────────────────────────────────────────────────────────────────── */
function EditorialProseBlock({
  kicker,
  title,
  accent,
  paragraphs,
}: {
  kicker: string;
  title: string;
  accent: string;
  paragraphs: string[];
}) {
  if (paragraphs.length === 0) return null;
  return (
    <motion.section variants={fadeUp} className="grid gap-6 md:grid-cols-12 md:gap-10">
      <div className="md:col-span-4 md:pt-2">
        <p
          className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
        >
          {kicker}
        </p>
        <h2
          className={`mt-4 ${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[48px] md:tracking-[-1px]`}
          style={{ textWrap: "balance" } as React.CSSProperties}
        >
          {title}{" "}
          <span className="italic text-[#97472c]">{accent}</span>
        </h2>
      </div>
      <div className="md:col-span-8 md:pt-2">
        <div className="space-y-5">
          {paragraphs.map((para, i) => {
            const proseClass = `${FONT_CLASS.manrope} text-[16px] leading-[1.7] text-[#1d1b18]/85 md:text-[17px]`;
            const wrap = { textWrap: "pretty" } as React.CSSProperties;
            if (i === 0) {
              return (
                <div
                  key={i}
                  style={{ display: "flow-root" } as React.CSSProperties}
                >
                  <p className={proseClass} style={wrap}>
                    <span
                      aria-hidden
                      className={`float-left mr-3 mt-1 ${FONT_CLASS.cormorant} text-[60px] font-medium italic leading-[0.85] md:mr-4 md:text-[84px]`}
                      style={{ color: "#97472c" }}
                    >
                      {para.charAt(0)}
                    </span>
                    {para.slice(1)}
                  </p>
                </div>
              );
            }
            return (
              <p key={i} className={proseClass} style={wrap}>
                {para}
              </p>
            );
          })}
        </div>
      </div>
    </motion.section>
  );
}

export function BiomarkerDetailClient({
  locale,
  biomarkerKey,
  latest,
  historicalValues,
  reference,
  wearable,
}: BiomarkerDetailClientProps) {
  const router = useRouter();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>("");
  const [editUnit, setEditUnit] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  function startEdit(v: HistoricalValue) {
    setEditingId(v.id);
    setEditValue(String(v.value));
    setEditUnit(v.unit ?? "");
    setEditError(null);
  }

  function cancelEdit() {
    setEditingId(null);
    setEditError(null);
  }

  async function saveEdit() {
    if (!editingId) return;
    const parsed = parseFloat(editValue.replace(",", "."));
    if (!Number.isFinite(parsed)) {
      setEditError(locale === "es" ? "Valor invalido" : "Invalid value");
      return;
    }
    setSaving(true);
    setEditError(null);
    try {
      const res = await fetch(`/api/biomarker-values/${editingId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ value: parsed, unit: editUnit || undefined }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Save failed (${res.status})`);
      }
      setEditingId(null);
      router.refresh();
    } catch (e) {
      setEditError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const t =
    locale === "es"
      ? {
          back: "Volver al panel",
          kickerSpecimen: "§ Ficha de marcador",
          kickerWhatMeans: "§ Que mide",
          kickerInterpretation: "§ Que dice tu lectura",
          kickerHistory: "§ Historial",
          kickerFieldNotes: "§ Notas de campo",
          kickerRefs: "§ Referencias cruzadas",
          kickerWearable: "§ Conexion wearable",
          kickerNextTest: "§ Proximo test",
          kickerGenetic: "§ Marcador genetico",
          measuresTitle: "El significado",
          measuresAccent: "clinico.",
          interpretationTitle: "Tu lectura,",
          interpretationAccent: "interpretada.",
          historyTitle: "La",
          historyAccent: "evolucion.",
          fieldNotesTitle: "Notas de",
          fieldNotesAccent: "campo.",
          fieldNotesHint:
            "Corrige el valor o la unidad si la extraccion fue incorrecta. La zona se recalcula al guardar.",
          refsTitle: "Referencias",
          refsAccent: "cruzadas.",
          edit: "Editar",
          save: "Guardar",
          cancel: "Cancelar",
          saving: "Guardando...",
          noData: "No se encontraron datos para este marcador.",
          singleReading:
            "Solo tienes una lectura para este marcador. Sube otra para ver tu evolucion.",
          wearableActive:
            "Tus datos de wearable se estan analizando para encontrar correlaciones con este marcador.",
          wearableEmpty:
            "Conecta tu wearable para ver como tus biometricas se correlacionan con este marcador.",
          connectCta: "Conectar Apple Health",
          nextTestTitle: "Vuelve a leer",
          nextTestAccent: "en tres meses.",
          nextTestBody:
            "El protocolo trimestral mantiene la lectura comparable y captura cualquier cambio relevante.",
          nextTestCta: "Reservar el siguiente kit",
          geneticTitle: "Lectura unica,",
          geneticAccent: "para siempre.",
          geneticBody:
            "Es un marcador genetico. El valor no cambia con el tiempo: una sola lectura es suficiente.",
          source: "Origen",
          drawn: "Extraido",
        }
      : {
          back: "Back to dashboard",
          kickerSpecimen: "§ Specimen file",
          kickerWhatMeans: "§ What it measures",
          kickerInterpretation: "§ Your reading, read",
          kickerHistory: "§ History",
          kickerFieldNotes: "§ Field notes",
          kickerRefs: "§ Cross-references",
          kickerWearable: "§ Wearable",
          kickerNextTest: "§ Next reading",
          kickerGenetic: "§ Genetic marker",
          measuresTitle: "The clinical",
          measuresAccent: "meaning.",
          interpretationTitle: "Your reading,",
          interpretationAccent: "interpreted.",
          historyTitle: "The",
          historyAccent: "trajectory.",
          fieldNotesTitle: "Field",
          fieldNotesAccent: "notes.",
          fieldNotesHint:
            "Correct the value or unit if the extraction was wrong. The zone recalculates on save.",
          refsTitle: "Cross",
          refsAccent: "references.",
          edit: "Edit",
          save: "Save",
          cancel: "Cancel",
          saving: "Saving...",
          noData: "We have no readings for this marker yet.",
          singleReading:
            "Only one reading on file for this marker. Upload another to see the trajectory.",
          wearableActive:
            "Your wearable data is being analysed for correlations with this marker.",
          wearableEmpty:
            "Connect your wearable to see how your biometrics align with this marker.",
          connectCta: "Connect Apple Health",
          nextTestTitle: "Re-read",
          nextTestAccent: "in three months.",
          nextTestBody:
            "The quarterly protocol keeps the reading comparable and catches any meaningful change.",
          nextTestCta: "Book your next kit",
          geneticTitle: "One reading,",
          geneticAccent: "for life.",
          geneticBody:
            "This is a genetic marker. The value doesn't drift with time. One reading is enough.",
          source: "Source",
          drawn: "Drawn",
        };

  const displayName =
    locale === "es"
      ? reference?.name_es ?? biomarkerKey.replace(/_/g, " ")
      : reference?.name_en ?? biomarkerKey.replace(/_/g, " ");

  const interpretationParas = paragraphsOf(
    locale === "es"
      ? latest?.interpretation_es ?? latest?.interpretation
      : latest?.interpretation,
  );

  const clinicalParas = paragraphsOf(
    locale === "es"
      ? reference?.clinical_notes_es
      : reference?.clinical_notes_en,
  );

  const accent = categoryAccent(reference?.panel_category);
  const isGenetic = reference?.is_genetic ?? false;
  const hasWearable = wearable.length > 0;

  const sortedHistory = useMemo(
    () =>
      [...historicalValues].sort((a, b) =>
        (b.lab_results.collection_date ?? "").localeCompare(
          a.lab_results.collection_date ?? "",
        ),
      ),
    [historicalValues],
  );

  /* ── No-data fallback ── */
  if (!latest) {
    return (
      <DashboardChrome>
        <div className="px-5 py-10 md:px-10 md:py-16">
          <div className="mx-auto max-w-[1200px]">
            <motion.div variants={fadeUp}>
              <EditorialMasthead
                issue={locale === "es" ? "Ficha de marcador" : "Specimen file"}
                volSuffix={
                  <>
                    {locale === "es" ? "Capitulo" : "Chapter"}{" "}
                    <span className="text-[#1d1b18]">·</span>
                  </>
                }
              />
            </motion.div>
            <motion.div variants={fadeUp} className="mt-12">
              <Link
                href={`/${locale}/labs`}
                className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
              >
                <span aria-hidden>←</span>
                {t.back}
              </Link>
              <p
                className={`mt-12 ${FONT_CLASS.cormorant} text-[28px] italic leading-[1.2] text-[#8a7f76] md:text-[36px]`}
              >
                {t.noData}
              </p>
            </motion.div>
          </div>
        </div>
      </DashboardChrome>
    );
  }

  const z = zoneAccent(latest.zone);
  const drawn = formatDayMonth(latest.lab_results.collection_date, locale);

  const chartData = historicalValues.map((v) => ({
    date: v.lab_results.collection_date,
    value: v.value,
    source: v.lab_results.source,
  }));

  return (
    <DashboardChrome>
      <div className="px-5 py-8 md:px-10 md:py-14">
        <div className="mx-auto max-w-[1200px]">
          {/* ── Masthead ── */}
          <motion.div variants={fadeUp}>
            <EditorialMasthead
              issue={locale === "es" ? "Ficha de marcador" : "Specimen file"}
              volSuffix={
                <>
                  {locale === "es" ? "Capitulo" : "Chapter"}{" "}
                  <span className="text-[#1d1b18]">
                    {categoryDisplay(reference?.panel_category, locale)}
                  </span>
                </>
              }
            />
          </motion.div>

          {/* ── Compact back link ── */}
          <motion.div variants={fadeUp} className="mt-8">
            <Link
              href={`/${locale}/labs`}
              className={`inline-flex items-center gap-2 ${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] transition-colors hover:text-[#1d1b18]`}
            >
              <span aria-hidden>←</span>
              {t.back}
            </Link>
          </motion.div>

          {/* ── § Specimen file — hero ── */}
          <motion.section
            variants={fadeUp}
            className="relative mt-10 md:mt-14"
          >
            <div className="grid gap-8 md:grid-cols-12 md:gap-10">
              <div className="md:col-span-7">
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px]`}
                  style={{ color: accent }}
                >
                  {t.kickerSpecimen}{" "}
                  <span className="text-[#1d1b18]/60">
                    · {categoryDisplay(reference?.panel_category, locale)}
                  </span>
                </p>
                <h1
                  className={`mt-4 ${FONT_CLASS.cormorant} text-[56px] font-medium leading-[0.92] tracking-[-1.5px] text-[#1d1b18] md:text-[112px] md:tracking-[-4px]`}
                  style={{ textWrap: "balance" } as React.CSSProperties}
                >
                  {displayName}
                </h1>
                <p
                  className={`mt-4 ${FONT_CLASS.cormorant} text-[20px] italic leading-tight md:text-[26px]`}
                  style={{ color: z.stroke }}
                >
                  {locale === "es" ? z.italic.es : z.italic.en}
                </p>
              </div>

              <div className="md:col-span-5 md:pt-2">
                {/* Monumental value */}
                <p
                  className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#8a7f76]`}
                >
                  {t.drawn} {drawn.day} {drawn.month}{" "}
                  {yearRoman(drawn.year)} ·{" "}
                  Q{quarterRoman(new Date(latest.lab_results.collection_date))}
                </p>
                <div className="relative mt-4">
                  <p
                    className={`${FONT_CLASS.cormorant} font-medium leading-[0.82] tabular-nums text-[120px] tracking-[-4px] md:text-[180px] md:tracking-[-8px]`}
                    style={{ color: z.stroke }}
                  >
                    {fmtMeasured(latest.value, latest.comparator)}
                  </p>
                  <span
                    className={`absolute -bottom-1 left-full ml-2 ${FONT_CLASS.dmMono} text-[14px] tracking-[1.6px] md:bottom-3 md:text-[16px]`}
                    style={{ color: z.stroke, opacity: 0.7 }}
                  >
                    {latest.unit}
                  </span>
                </div>
                {latest.reported_value != null &&
                  latest.reported_unit &&
                  !sameUnit(latest.reported_unit, latest.unit) && (
                    // The lab's own number, kept for audit: only shown when it
                    // was rescaled or converted into eva's canonical unit.
                    <p className={`${FONT_CLASS.dmMono} mt-3 text-[11px] tracking-[0.4px] text-[#8a7f76]`}>
                      {locale === "es" ? "Tu laboratorio informó" : "Your lab reported"}{" "}
                      {fmtValue(latest.reported_value)} {latest.reported_unit}
                    </p>
                  )}
                <div className="mt-6 flex items-center gap-3">
                  <span
                    aria-hidden
                    className="h-px w-8"
                    style={{ backgroundColor: z.stroke, opacity: 0.6 }}
                  />
                  <p
                    className={`${FONT_CLASS.dmMono} text-[11px] font-semibold uppercase tracking-[2px]`}
                    style={{ color: z.stroke }}
                  >
                    {locale === "es" ? z.label.es : z.label.en}
                  </p>
                  {latest.lab_results.source === "eva_kit" && (
                    <span
                      className={`ml-auto ${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.8px] text-[#97472c]`}
                    >
                      EVA kit
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Range bar — full width below */}
            <div className="mt-12 border-t border-[#1d1b18]/15 pt-10 md:mt-16">
              <EditorialRangeBar
                value={latest.value}
                optimalLow={latest.optimal_low}
                optimalHigh={latest.optimal_high}
                normalLow={latest.normal_low}
                normalHigh={latest.normal_high}
                unit={latest.unit}
                zone={latest.zone}
                locale={locale}
              />
            </div>
          </motion.section>

          {/* ── § What this measures (clinical reference) ── */}
          {clinicalParas.length > 0 && (
            <>
              <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
              <EditorialProseBlock
                kicker={t.kickerWhatMeans}
                title={t.measuresTitle}
                accent={t.measuresAccent}
                paragraphs={clinicalParas}
              />
            </>
          )}

          {/* ── § Your reading, interpreted ── */}
          {interpretationParas.length > 0 && (
            <>
              <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
              <EditorialProseBlock
                kicker={t.kickerInterpretation}
                title={t.interpretationTitle}
                accent={t.interpretationAccent}
                paragraphs={interpretationParas}
              />
            </>
          )}

          {/* ── § History (trend) ── */}
          {chartData.length > 0 && (
            <>
              <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
              <motion.section
                variants={fadeUp}
                className="grid gap-6 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-4 md:pt-2">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
                  >
                    {t.kickerHistory}
                  </p>
                  <h2
                    className={`mt-4 ${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[48px] md:tracking-[-1px]`}
                    style={{ textWrap: "balance" } as React.CSSProperties}
                  >
                    {t.historyTitle}{" "}
                    <span className="italic text-[#97472c]">{t.historyAccent}</span>
                  </h2>
                </div>
                <div className="md:col-span-8 md:pt-2">
                  {chartData.length >= 2 ? (
                    <div className="-mx-2 md:mx-0">
                      <MonographTrend
                        data={chartData}
                        optimalLow={latest.optimal_low}
                        optimalHigh={latest.optimal_high}
                        unit={latest.unit}
                        locale={locale}
                      />
                    </div>
                  ) : (
                    <p
                      className={`${FONT_CLASS.cormorant} text-[22px] italic leading-[1.3] text-[#8a7f76] md:text-[26px]`}
                    >
                      {t.singleReading}
                    </p>
                  )}
                </div>
              </motion.section>
            </>
          )}

          {/* ── § Field notes (editable history) ── */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
              >
                {t.kickerFieldNotes}
              </p>
              <h2
                className={`mt-4 ${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[48px] md:tracking-[-1px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.fieldNotesTitle}{" "}
                <span className="italic text-[#97472c]">{t.fieldNotesAccent}</span>
              </h2>
              <p
                className={`mt-4 max-w-[28ch] ${FONT_CLASS.manrope} text-[13px] italic leading-[1.6] text-[#8a7f76]`}
              >
                {t.fieldNotesHint}
              </p>
            </div>
            <div className="md:col-span-8 md:pt-2">
              <ul className="border-t border-[#1d1b18]/15">
                {sortedHistory.map((v) => {
                  const vZone = zoneAccent(v.zone);
                  const dt = formatDayMonth(
                    v.lab_results.collection_date,
                    locale,
                  );
                  const isEditing = editingId === v.id;
                  return (
                    <li
                      key={v.id}
                      className="flex flex-col gap-3 border-b border-[#1d1b18]/10 py-4 md:flex-row md:items-center md:justify-between"
                    >
                      <div className="flex items-baseline gap-4">
                        <span
                          className={`${FONT_CLASS.cormorant} text-[26px] font-medium leading-none tabular-nums tracking-[-0.5px] text-[#1d1b18] md:text-[30px]`}
                        >
                          {dt.day}
                        </span>
                        <div>
                          <p
                            className={`${FONT_CLASS.cormorant} text-[16px] italic leading-tight text-[#97472c] md:text-[18px]`}
                          >
                            {dt.month}
                          </p>
                          <p
                            className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.6px] text-[#8a7f76]`}
                          >
                            {yearRoman(dt.year)}
                            {v.lab_results.source === "eva_kit" && (
                              <span className="ml-2 text-[#97472c]">· EVA</span>
                            )}
                          </p>
                        </div>
                      </div>

                      {isEditing ? (
                        <div className="flex flex-wrap items-center gap-3">
                          <input
                            type="text"
                            inputMode="decimal"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            autoFocus
                            className={`w-20 border-b border-[#1d1b18]/30 bg-transparent py-1 text-right ${FONT_CLASS.dmMono} text-[16px] tabular-nums text-[#1d1b18] outline-none focus:border-[#97472c]`}
                          />
                          <input
                            type="text"
                            value={editUnit}
                            onChange={(e) => setEditUnit(e.target.value)}
                            placeholder={latest.unit}
                            className={`w-20 border-b border-[#1d1b18]/15 bg-transparent py-1 ${FONT_CLASS.dmMono} text-[11px] uppercase tracking-[1.2px] text-[#8a7f76] outline-none focus:border-[#97472c]`}
                          />
                          <button
                            type="button"
                            onClick={saveEdit}
                            disabled={saving}
                            className={`${FONT_CLASS.manrope} text-[11px] font-semibold uppercase tracking-[1.4px] text-[#97472c] underline decoration-[#97472c]/30 underline-offset-[5px] transition-colors hover:decoration-[#97472c] disabled:opacity-60`}
                          >
                            {saving ? t.saving : t.save}
                          </button>
                          <button
                            type="button"
                            onClick={cancelEdit}
                            disabled={saving}
                            className={`${FONT_CLASS.manrope} text-[11px] font-medium uppercase tracking-[1.4px] text-[#8a7f76] transition-colors hover:text-[#1d1b18] disabled:opacity-60`}
                          >
                            {t.cancel}
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-baseline gap-4">
                          <span
                            className={`${FONT_CLASS.dmMono} text-[18px] font-medium tabular-nums md:text-[22px]`}
                            style={{ color: vZone.stroke }}
                          >
                            {fmtValue(v.value)}
                          </span>
                          <span
                            className={`${FONT_CLASS.dmMono} text-[10px] uppercase tracking-[1.2px] text-[#8a7f76]`}
                          >
                            {v.unit}
                          </span>
                          <button
                            type="button"
                            onClick={() => startEdit(v)}
                            className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.6px] text-[#8a7f76] underline decoration-[#1d1b18]/15 underline-offset-[5px] transition-colors hover:text-[#1d1b18] hover:decoration-[#1d1b18]/45`}
                          >
                            {t.edit}
                          </button>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
              {editError && (
                <p
                  className={`mt-3 ${FONT_CLASS.manrope} text-[12px] italic text-[#b04040]`}
                >
                  {editError}
                </p>
              )}
            </div>
          </motion.section>

          {/* ── § Cross-references ── */}
          <div aria-hidden className="my-14 h-px w-full bg-[#1d1b18]/10 md:my-20" />
          <motion.section
            variants={fadeUp}
            className="grid gap-6 md:grid-cols-12 md:gap-10"
          >
            <div className="md:col-span-4 md:pt-2">
              <p
                className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#97472c]`}
              >
                {t.kickerRefs}
              </p>
              <h2
                className={`mt-4 ${FONT_CLASS.cormorant} text-[36px] font-medium leading-[0.95] tracking-[-0.5px] text-[#1d1b18] md:text-[48px] md:tracking-[-1px]`}
                style={{ textWrap: "balance" } as React.CSSProperties}
              >
                {t.refsTitle}{" "}
                <span className="italic text-[#97472c]">{t.refsAccent}</span>
              </h2>
            </div>
            <div className="md:col-span-8 md:pt-2">
              <div className="grid gap-8 md:grid-cols-2 md:gap-10">
                {/* Wearable column */}
                <div className="border-t border-[#1d1b18]/15 pt-6">
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px] text-[#3a665e]`}
                  >
                    {t.kickerWearable}
                  </p>
                  <p
                    className={`mt-3 ${FONT_CLASS.cormorant} text-[24px] italic leading-[1.2] text-[#1d1b18] md:text-[28px]`}
                    style={{ textWrap: "balance" } as React.CSSProperties}
                  >
                    {hasWearable ? t.wearableActive : t.wearableEmpty}
                  </p>
                  {!hasWearable && (
                    <Link
                      href={`/${locale}/profile`}
                      className={`mt-5 inline-flex items-center gap-2 ${FONT_CLASS.manrope} text-[13px] font-medium text-[#3a665e] underline decoration-[#3a665e]/30 underline-offset-[6px] transition-colors hover:decoration-[#3a665e]`}
                    >
                      {t.connectCta}
                      <span aria-hidden>→</span>
                    </Link>
                  )}
                </div>

                {/* Next test / genetic column */}
                <div
                  className="border-t pt-6"
                  style={{
                    borderColor: isGenetic
                      ? "rgba(196,147,50,0.45)"
                      : "rgba(151,71,44,0.30)",
                  }}
                >
                  <p
                    className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[1.8px]`}
                    style={{ color: isGenetic ? "#c49332" : "#97472c" }}
                  >
                    {isGenetic ? t.kickerGenetic : t.kickerNextTest}
                  </p>
                  {isGenetic ? (
                    <>
                      <p
                        className={`mt-3 ${FONT_CLASS.cormorant} text-[24px] leading-[1.15] text-[#1d1b18] md:text-[28px]`}
                        style={{ textWrap: "balance" } as React.CSSProperties}
                      >
                        {t.geneticTitle}{" "}
                        <span className="italic text-[#c49332]">
                          {t.geneticAccent}
                        </span>
                      </p>
                      <p
                        className={`mt-4 max-w-[36ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#4c463f]`}
                      >
                        {t.geneticBody}
                      </p>
                    </>
                  ) : (
                    <>
                      <p
                        className={`mt-3 ${FONT_CLASS.cormorant} text-[24px] leading-[1.15] text-[#1d1b18] md:text-[28px]`}
                        style={{ textWrap: "balance" } as React.CSSProperties}
                      >
                        {t.nextTestTitle}{" "}
                        <span className="italic text-[#97472c]">
                          {t.nextTestAccent}
                        </span>
                      </p>
                      <p
                        className={`mt-4 max-w-[36ch] ${FONT_CLASS.manrope} text-[14px] leading-[1.65] text-[#4c463f]`}
                      >
                        {t.nextTestBody}
                      </p>
                      <Link
                        href={`/${locale}/book`}
                        className={`group mt-5 inline-flex items-center gap-3 rounded-full bg-[#1d1b18] px-5 py-2.5 ${FONT_CLASS.manrope} text-[13px] font-semibold text-[#fef8f2] shadow-[0_18px_50px_-12px_rgba(151,71,44,0.45)] transition-transform hover:-translate-y-0.5 active:translate-y-0`}
                      >
                        {t.nextTestCta}
                        <span
                          aria-hidden
                          className="flex h-5 w-5 items-center justify-center rounded-full bg-[#fef8f2]/15 transition-transform group-hover:translate-x-0.5"
                        >
                          <svg
                            className="h-3 w-3"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth={2}
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"
                            />
                          </svg>
                        </span>
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </div>
          </motion.section>

          <div className="h-12 md:h-20" />
        </div>
      </div>
    </DashboardChrome>
  );
}
