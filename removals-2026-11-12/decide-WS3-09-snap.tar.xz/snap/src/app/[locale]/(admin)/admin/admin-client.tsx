"use client";

import { useState } from "react";
import { formatBridgeSummary, ago, type BridgePassSummary } from "@/lib/lab-bridge/summary";
import { panels } from "@/config/panels";

interface User { id: string; full_name: string | null; email: string | null; }
interface Booking {
  id: string; user_id: string; panel_type: string; status: string;
  scheduled_date: string | null; created_at: string;
  profiles: { full_name: string | null; email: string | null } | null;
}
interface LabResultRow {
  id: string; user_id: string; source: string; status: string;
  collection_date: string | null; biological_age: number | null;
  longevity_score: number | null; created_at: string;
  profiles: { full_name: string | null; email: string | null } | null;
}
export interface FulfillmentCycle {
  id: string; user_id: string; seq: number; panel_type: string; status: string;
  due_date: string; placer_order_number: string | null; kit_label_code: string | null;
  dhl_tracking_out: string | null; extraction_confirmed_at: string | null;
  oml_sent_at: string | null; oml_ack: string | null;
  created_at: string; updated_at: string;
  profiles: {
    full_name: string | null; email: string | null; phone: string | null;
    address_line1: string | null; address_line2: string | null;
    address_city: string | null; address_postal_code: string | null;
    address_province: string | null;
    /** Identity document (PID.3) — required by the lab; Ship is blocked without it. */
    id_document_type: string | null; id_document_number: string | null;
  } | null;
}

export interface BridgeRunRow {
  id: string;
  started_at: string;
  trigger: string;
  processing_id: string;
  ok: boolean;
  error: string | null;
  summary: string;
}

interface AdminClientProps {
  locale: string;
  cycles: FulfillmentCycle[];
  /** Last passes of the bridge (newest first), persisted so the cron's work is visible too. */
  bridgeRuns?: BridgeRunRow[];
  bookings: Booking[];
  labResults: LabResultRow[];
  users: User[];
}

type Tab = "fulfillment" | "bookings" | "enter" | "log";

const CYCLE_STATUS_STYLE: Record<string, string> = {
  awaiting_fulfillment: "bg-[rgba(196,147,50,0.10)] text-[#c49332]",
  kit_assigned: "bg-[rgba(58,102,94,0.08)] text-[#3a665e]",
  shipped: "bg-[rgba(58,102,94,0.12)] text-[#3a665e]",
  activated: "bg-[rgba(151,71,44,0.08)] text-[#97472c]",
  order_sent: "bg-[rgba(151,71,44,0.10)] text-[#97472c]",
  order_accepted: "bg-[rgba(151,71,44,0.12)] text-[#97472c]",
  results_partial: "bg-[rgba(58,102,94,0.08)] text-[#3a665e]",
  results_final: "bg-[rgba(58,102,94,0.12)] text-[#3a665e]",
  error: "bg-[rgba(176,64,64,0.12)] text-[#b04040]",
};

// The Base Panel (2026-09-22): the 13 tests Echevarne runs on one serum tube,
// in the lab's units — the same list as ECH_PANEL_ORDER_CODES.base.
const BASE_BIOMARKERS = [
  { key: "albumin", name: "Albumin", unit: "g/L" },
  { key: "alp", name: "ALP", unit: "U/L" },
  { key: "hs_crp", name: "hs-CRP", unit: "mg/L" },
  { key: "creatinine", name: "Creatinine", unit: "mg/dL" },
  { key: "bun", name: "BUN", unit: "mg/dL" },
  { key: "uric_acid", name: "Uric Acid", unit: "mg/dL" },
  { key: "total_cholesterol", name: "Total Cholesterol", unit: "mg/dL" },
  { key: "hdl_cholesterol", name: "HDL Cholesterol", unit: "mg/dL" },
  { key: "triglycerides", name: "Triglycerides", unit: "mg/dL" },
  { key: "apolipoprotein_b_apob", name: "ApoB", unit: "mg/dL" },
  { key: "alt", name: "ALT", unit: "U/L" },
  { key: "ggt", name: "GGT", unit: "U/L" },
  { key: "fructosamine", name: "Fructosamine", unit: "µmol/L" },
];

const STATUSES = ["scheduled", "kit_sent", "sample_received", "processing", "completed"];

const inputClass = "rounded-[10px] border border-[#e7e2dc] bg-white px-3 py-2 font-[family-name:var(--font-inter)] text-[13px] text-[#1d1b18] outline-none focus:border-[#97472c]";

export function AdminClient({ locale, cycles, bookings, labResults, users, bridgeRuns = [] }: AdminClientProps) {
  const [tab, setTab] = useState<Tab>("fulfillment");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [userSearch, setUserSearch] = useState("");
  const [biomarkerValues, setBiomarkerValues] = useState<Record<string, string>>({});
  // "<" or ">" for a result the report printed as a bound ("<5"); absent for a measured value.
  const [biomarkerSigns, setBiomarkerSigns] = useState<Record<string, "<" | ">" | "≤" | "≥">>({});
  const [skipped, setSkipped] = useState<Set<string>>(new Set());
  const [submitting, setSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState<string | null>(null);
  // Fulfillment inputs, keyed by cycle id (scan field + tracking field).
  const [labelInputs, setLabelInputs] = useState<Record<string, string>>({});
  const [trackingInputs, setTrackingInputs] = useState<Record<string, string>>({});
  const [cycleBusy, setCycleBusy] = useState<string | null>(null);
  const [cycleError, setCycleError] = useState<string | null>(null);
  // Lab bridge — manual pass (same code as the cron). Summary shown inline.
  const [bridgeBusy, setBridgeBusy] = useState(false);
  const [bridgeResult, setBridgeResult] = useState<string | null>(null);
  // Replay of an archived ORU (lab_messages id) — no SFTP, no ACK.
  const [replayId, setReplayId] = useState("");
  const [replayForce, setReplayForce] = useState(false);
  async function runBridge() {
    setBridgeBusy(true);
    setBridgeResult(null);
    try {
      const res = await fetch("/api/admin/lab-bridge", { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setBridgeResult(`Bridge error: ${data.error ?? res.status}`);
        return;
      }
      const s = data as BridgePassSummary;
      setBridgeResult(formatBridgeSummary({ ...s, otherEnvironment: s.otherEnvironment ?? [] }));
      // The pass is persisted in lab_bridge_runs; reloading shows it in the history below.
      setTimeout(() => window.location.reload(), 1500);
    } catch {
      setBridgeResult("Network error");
    } finally {
      setBridgeBusy(false);
    }
  }
  // Recompute Longevity Score / biological age / zone counts for every lab
  // result from its stored values (after a scoring or unit change).
  const [recalcBusy, setRecalcBusy] = useState(false);
  const [recalcResult, setRecalcResult] = useState<string | null>(null);
  async function recalcAll() {
    if (!window.confirm("Recompute Longevity Score, biological age and zone counts for EVERY lab result from its stored values? Scores shown to users will change.")) return;
    setRecalcBusy(true);
    setRecalcResult(null);
    try {
      const res = await fetch("/api/admin/recalc-metrics", { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setRecalcResult(`Recalc error: ${data.error ?? res.status}`);
        return;
      }
      setRecalcResult(`Recomputed ${data.ok}/${data.total} lab results${data.failed?.length ? `; failed: ${data.failed.map((f: { id: string }) => f.id).join(", ")}` : ""}`);
    } catch {
      setRecalcResult("Network error");
    } finally {
      setRecalcBusy(false);
    }
  }
  async function replayOru() {
    const id = replayId.trim();
    if (!id) return;
    setBridgeBusy(true);
    setBridgeResult(null);
    try {
      const res = await fetch("/api/admin/lab-bridge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "replay", labMessageId: id, force: replayForce }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setBridgeResult(`Replay refused (${data.code ?? res.status}): ${data.error ?? ""}`);
        return;
      }
      setBridgeResult(`Replayed ${data.messageControlId}: ${data.processed} biomarkers recorded on lab result ${data.labResultId} (cycle ${data.cycleId})`);
      setReplayId("");
      setReplayForce(false);
    } catch {
      setBridgeResult("Network error");
    } finally {
      setBridgeBusy(false);
    }
  }

  async function cycleAction(
    cycleId: string,
    action: "assign_kit" | "ship" | "reopen" | "cancel" | "complete",
    extra: Record<string, string | undefined> = {},
  ) {
    setCycleBusy(cycleId);
    setCycleError(null);
    try {
      const res = await fetch("/api/admin/cycles", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cycleId, action, ...extra }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setCycleError(data.error ?? `Action failed (${res.status})`);
        setCycleBusy(null);
        return;
      }
      window.location.reload();
    } catch {
      setCycleError("Network error");
      setCycleBusy(null);
    }
  }

  const filteredUsers = userSearch.length >= 2
    ? users.filter((u) => u.full_name?.toLowerCase().includes(userSearch.toLowerCase()) || u.email?.toLowerCase().includes(userSearch.toLowerCase()))
    : [];

  async function updateBookingStatus(bookingId: string, status: string) {
    await fetch("/api/admin/bookings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bookingId, status }),
    });
    window.location.reload();
  }

  async function handleSubmitResults() {
    if (!selectedUser) return;
    setSubmitting(true);
    setSubmitResult(null);

    // Each entry carries the row's key and the sign printed before the value, so a bound is classified as a bound.
    // The value goes as typed: the server reads it as the report prints it ("5,4", "<5") and sets aside, naming it,
    // a result it cannot read or one printed with "≤" or "≥", which is not entered under another sign (D-24).
    const entries = BASE_BIOMARKERS
      .filter((b) => !skipped.has(b.key) && biomarkerValues[b.key])
      .map((b) => ({
        name: b.name,
        value: biomarkerValues[b.key],
        unit: b.unit,
        biomarkerKey: b.key,
        ...(biomarkerSigns[b.key] ? { comparator: biomarkerSigns[b.key] } : {}),
      }));

    if (entries.length === 0) { setSubmitting(false); return; }

    try {
      const res = await fetch("/api/admin/enter-results", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: selectedUser.id, biomarkers: entries, locale }),
      });
      const data = await res.json();
      if (res.ok) {
        // Results that were not used are named with their reason, in the administrator's language (the sentences
        // of wording-rules.md section 7, as the server renders them).
        const notUsed = typeof data.setAsideMessage === "string" && data.setAsideMessage ? `\n\n${data.setAsideMessage}` : "";
        setSubmitResult(
          data.nothingUsable
            ? `Nothing saved.${notUsed}`
            : `Success: ${data.processed} biomarkers processed. Bio Age: ${data.biologicalAge?.biologicalAge ?? "N/A"}${notUsed}`,
        );
        setBiomarkerValues({});
        setBiomarkerSigns({});
        setSkipped(new Set());
      } else {
        setSubmitResult(`Error: ${data.error}`);
      }
    } catch { setSubmitResult("Error: submission failed"); }
    setSubmitting(false);
  }

  async function handleReprocess(labResultId: string) {
    await fetch("/api/admin/reprocess", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ labResultId }),
    });
    window.location.reload();
  }

  const thClass = "px-4 py-3 font-[family-name:var(--font-dm-mono)] text-[10px] font-medium uppercase tracking-[1px] text-[#8a7f76] text-left";
  const tdClass = "px-4 py-3 font-[family-name:var(--font-inter)] text-[13px] text-[#1d1b18]";

  return (
    <div className="px-6 py-8">
      {/* Tabs */}
      <div className="flex gap-2 border-b border-[#e7e2dc] pb-3">
        {([["fulfillment", "Fulfillment"], ["bookings", "Legacy Bookings"], ["enter", "Enter Results"], ["log", "Processing Log"]] as const).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`rounded-t-[10px] px-5 py-2.5 font-[family-name:var(--font-manrope)] text-[13px] font-bold transition-all ${
              tab === key ? "bg-white text-[#97472c] shadow-sm" : "text-[#8a7f76] hover:text-[#4c463f]"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* ─── Tab 0: Fulfillment (test_cycles state machine, F5) ─── */}
      {tab === "fulfillment" && (
        <div className="mt-6 space-y-6">
          {cycleError && (
            <div className="rounded-[12px] border border-[rgba(176,64,64,0.3)] bg-[rgba(176,64,64,0.06)] px-4 py-3 font-[family-name:var(--font-inter)] text-[13px] text-[#b04040]">
              {cycleError}
            </div>
          )}

          {/* Lab bridge: one pass against Echevarne's mailbox (upload queued orders, fetch ACKs/results). */}
          <div className="flex flex-wrap items-center gap-3 rounded-[16px] border border-[#e7e2dc] bg-white px-4 py-3">
            <div className="min-w-0 flex-1">
              <h3 className="font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[1.5px] text-[#1d1b18]">Lab bridge · Echevarne SFTP</h3>
              <p className="mt-0.5 font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">Uploads queued orders, collects ACKs and results, answers every result with an ACK. Runs the same code the scheduled cron will run.</p>
              {bridgeResult && <p className="mt-1 break-words font-[family-name:var(--font-dm-mono)] text-[11px] text-[#4c463f]">{bridgeResult}</p>}
              {bridgeRuns.length > 0 && (
                <div className="mt-2 space-y-1">
                  {bridgeRuns.map((r, i) => (
                    <p
                      key={r.id}
                      className={`break-words font-[family-name:var(--font-dm-mono)] text-[11px] ${i === 0 ? "text-[#1d1b18]" : "text-[#8a7f76]"}`}
                    >
                      <span className={r.ok ? "text-[#4f7a5a]" : "text-[#b04040]"}>{r.ok ? "●" : "✕"}</span>{" "}
                      <span className="uppercase tracking-[1px]">{i === 0 ? "last pass" : ago(r.started_at)}</span>
                      {i === 0 && <span> · {ago(r.started_at)}</span>} · {r.trigger} · {r.summary}
                    </p>
                  ))}
                </div>
              )}
            </div>
            <div className="flex flex-col items-end gap-2">
              <button
                disabled={bridgeBusy}
                onClick={runBridge}
                className="rounded-[8px] bg-[#1d1b18] px-4 py-1.5 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-white disabled:opacity-40"
              >
                {bridgeBusy ? "Running…" : "Run bridge pass"}
              </button>
              {/* Replay: re-record a result from its archived HL7 (lab_messages id), e.g. after a failed recording or a deleted result. */}
              <div className="flex items-center gap-1.5">
                <input
                  value={replayId}
                  onChange={(e) => setReplayId(e.target.value)}
                  placeholder="lab_messages id (ORU)"
                  className={`${inputClass} w-[220px] py-1 text-[11px]`}
                />
                <label className="flex items-center gap-1 font-[family-name:var(--font-inter)] text-[10px] text-[#8a7f76]" title="Record a new result even if the cycle already has one (the existing one is kept)">
                  <input type="checkbox" checked={replayForce} onChange={(e) => setReplayForce(e.target.checked)} /> force
                </label>
                <button
                  disabled={bridgeBusy || !replayId.trim()}
                  onClick={replayOru}
                  className="rounded-[8px] border border-[#e7e2dc] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#4c463f] hover:border-[#97472c] hover:text-[#97472c] disabled:opacity-40"
                >
                  Replay ORU
                </button>
              </div>
            </div>
          </div>

          {/* Maintenance: recompute stored scores after a scoring/unit change. */}
          <div className="flex flex-wrap items-center gap-3 rounded-[16px] border border-[#e7e2dc] bg-white px-4 py-3">
            <div className="min-w-0 flex-1">
              <h3 className="font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[1.5px] text-[#1d1b18]">Scores · recompute</h3>
              <p className="mt-0.5 font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">Recomputes Longevity Score, biological age and zone counts for every lab result from its stored values. Run once after a change in ranges, units or scoring.</p>
              {recalcResult && <p className="mt-1 break-words font-[family-name:var(--font-dm-mono)] text-[11px] text-[#4c463f]">{recalcResult}</p>}
            </div>
            <button
              disabled={recalcBusy}
              onClick={recalcAll}
              className="rounded-[8px] border border-[#e7e2dc] px-4 py-1.5 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#4c463f] hover:border-[#97472c] hover:text-[#97472c] disabled:opacity-40"
            >
              {recalcBusy ? "Recomputing…" : "Recompute all scores"}
            </button>
          </div>

          {/* Attention: error cycles first, loudly */}
          {cycles.some((c) => c.status === "error") && (
            <div className="rounded-[16px] border border-[rgba(176,64,64,0.3)] bg-[rgba(176,64,64,0.04)] p-4">
              <h3 className="font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[1.5px] text-[#b04040]">Needs attention</h3>
              <div className="mt-3 space-y-2">
                {cycles.filter((c) => c.status === "error").map((c) => (
                  <div key={c.id} className="flex flex-wrap items-center gap-3 rounded-[12px] bg-white px-4 py-2.5">
                    <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#1d1b18]">{c.profiles?.full_name ?? "—"}</span>
                    <span className="font-[family-name:var(--font-inter)] text-[12px] text-[#8a7f76]">#{c.seq} · {c.placer_order_number ?? "no placer"}</span>
                    <span className="ml-auto flex gap-2">
                      <button disabled={cycleBusy === c.id} onClick={() => cycleAction(c.id, "reopen")} className="rounded-[8px] border border-[#e7e2dc] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#4c463f] hover:border-[#97472c] hover:text-[#97472c] disabled:opacity-50">Reopen</button>
                      <button disabled={cycleBusy === c.id} onClick={() => cycleAction(c.id, "cancel")} className="rounded-[8px] border border-[rgba(176,64,64,0.4)] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#b04040] hover:bg-[rgba(176,64,64,0.06)] disabled:opacity-50">Cancel</button>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="overflow-x-auto rounded-[16px] border border-[#e7e2dc] bg-white">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#e7e2dc] bg-[#f8f3ed]">
                  <th className={thClass}>User / Ship to</th>
                  <th className={thClass}>Cycle</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>Kit label (scan)</th>
                  <th className={thClass}>DHL tracking</th>
                  <th className={thClass}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {cycles.length === 0 && (
                  <tr><td colSpan={6} className="px-4 py-8 text-center font-[family-name:var(--font-inter)] text-[13px] text-[#8a7f76]">No open cycles — the daily scheduler creates them when a paid user is due a kit</td></tr>
                )}
                {cycles.map((c) => {
                  const p = c.profiles;
                  const address = [p?.address_line1, p?.address_line2, p?.address_postal_code, p?.address_city, p?.address_province]
                    .filter(Boolean)
                    .join(", ");
                  // The lab requires a categorized identity document on every
                  // order; the initial OML goes out at ship, so Ship is gated.
                  const hasIdDocument = Boolean(p?.id_document_type && p?.id_document_number);
                  return (
                    <tr key={c.id} className="border-b border-[#f8f3ed] align-top hover:bg-[#faf7f3]">
                      <td className={tdClass}>
                        <div className="font-bold">{p?.full_name ?? "—"}</div>
                        <div className="text-[11px] text-[#8a7f76]">{p?.email ?? "—"}{p?.phone ? ` · ${p.phone}` : ""}</div>
                        <div className="mt-1 max-w-[240px] text-[11px] text-[#8a7f76]">{address || "⚠️ no shipping address"}</div>
                        <div className="mt-1 text-[11px]">
                          {hasIdDocument ? (
                            <span className="font-[family-name:var(--font-dm-mono)] text-[#3a665e]">{p?.id_document_type} · {p?.id_document_number}</span>
                          ) : (
                            <span className="rounded-full bg-[rgba(176,64,64,0.08)] px-2 py-0.5 text-[10px] font-bold text-[#b04040]" title="The lab rejects orders without an identity document. The patient must add it under Profile → Shipping.">⚠️ no ID document — cannot ship</span>
                          )}
                        </div>
                      </td>
                      <td className={tdClass}>
                        <div>#{c.seq} · <span className="rounded-full bg-[rgba(58,102,94,0.08)] px-2 py-0.5 text-[11px] font-medium text-[#3a665e]">{panels[c.panel_type]?.name ?? c.panel_type}</span></div>
                        <div className="mt-1 text-[11px] text-[#8a7f76]">due {c.due_date}</div>
                        {c.placer_order_number && <div className="mt-0.5 font-[family-name:var(--font-dm-mono)] text-[10px] text-[#8a7f76]">{c.placer_order_number}</div>}
                        {(c.oml_sent_at || c.oml_ack) && (
                          <div className="mt-0.5 font-[family-name:var(--font-dm-mono)] text-[10px] text-[#8a7f76]">
                            OML {c.oml_sent_at ? `sent ${c.oml_sent_at.slice(0, 16).replace("T", " ")}` : "queued"}{c.oml_ack ? ` · ACK ${c.oml_ack}` : ""}
                          </div>
                        )}
                        {c.extraction_confirmed_at && (
                          <div className="mt-0.5 font-[family-name:var(--font-dm-mono)] text-[10px] text-[#3a665e]">extraction {c.extraction_confirmed_at.slice(0, 16).replace("T", " ")}</div>
                        )}
                      </td>
                      <td className={tdClass}>
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${CYCLE_STATUS_STYLE[c.status] ?? "bg-[#f8f3ed] text-[#8a7f76]"}`}>
                          {c.status.replace(/_/g, " ")}
                        </span>
                      </td>
                      <td className={tdClass}>
                        {c.status === "awaiting_fulfillment" ? (
                          <form
                            onSubmit={(e) => {
                              e.preventDefault();
                              const code = (labelInputs[c.id] ?? "").trim();
                              if (code) cycleAction(c.id, "assign_kit", { kitLabelCode: code });
                            }}
                          >
                            {/* Barcode/QR scanners type + Enter → submit assigns. */}
                            <input
                              value={labelInputs[c.id] ?? ""}
                              onChange={(e) => setLabelInputs({ ...labelInputs, [c.id]: e.target.value })}
                              placeholder="Scan sticker…"
                              disabled={cycleBusy === c.id}
                              className={`${inputClass} w-36 !py-1.5 !text-[12px]`}
                            />
                          </form>
                        ) : (
                          <span className="font-[family-name:var(--font-dm-mono)] text-[11px]">{c.kit_label_code ?? "—"}</span>
                        )}
                      </td>
                      <td className={tdClass}>
                        {c.status === "kit_assigned" ? (
                          <form
                            onSubmit={(e) => {
                              e.preventDefault();
                              const tn = (trackingInputs[c.id] ?? "").trim();
                              if (tn) cycleAction(c.id, "ship", { trackingNumber: tn });
                            }}
                          >
                            <input
                              value={trackingInputs[c.id] ?? ""}
                              onChange={(e) => setTrackingInputs({ ...trackingInputs, [c.id]: e.target.value })}
                              placeholder="Paste DHL tracking…"
                              disabled={cycleBusy === c.id}
                              className={`${inputClass} w-40 !py-1.5 !text-[12px]`}
                            />
                          </form>
                        ) : c.dhl_tracking_out ? (
                          <a
                            href={`https://www.dhl.com/es-es/home/tracking.html?tracking-id=${encodeURIComponent(c.dhl_tracking_out)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-[family-name:var(--font-dm-mono)] text-[11px] text-[#97472c] underline"
                          >
                            {c.dhl_tracking_out}
                          </a>
                        ) : (
                          <span className="text-[11px] text-[#8a7f76]">—</span>
                        )}
                      </td>
                      <td className={tdClass}>
                        <div className="flex flex-wrap gap-1.5">
                          {c.status === "awaiting_fulfillment" && (
                            <button
                              disabled={cycleBusy === c.id || !(labelInputs[c.id] ?? "").trim()}
                              onClick={() => cycleAction(c.id, "assign_kit", { kitLabelCode: (labelInputs[c.id] ?? "").trim() })}
                              className="rounded-[8px] bg-[#3a665e] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-white disabled:opacity-40"
                            >
                              Assign kit
                            </button>
                          )}
                          {c.status === "kit_assigned" && (
                            <>
                              <button
                                disabled={cycleBusy === c.id || !hasIdDocument || !(trackingInputs[c.id] ?? "").trim()}
                                title={hasIdDocument ? undefined : "Blocked: patient has no identity document on file (lab requirement)"}
                                onClick={() => cycleAction(c.id, "ship", { trackingNumber: (trackingInputs[c.id] ?? "").trim() })}
                                className="rounded-[8px] bg-gradient-to-br from-[#97472c] to-[#d97b5c] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-white disabled:opacity-40"
                              >
                                Ship
                              </button>
                              <button disabled={cycleBusy === c.id} onClick={() => cycleAction(c.id, "reopen")} className="rounded-[8px] border border-[#e7e2dc] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#4c463f] hover:border-[#97472c] hover:text-[#97472c] disabled:opacity-50">Undo</button>
                            </>
                          )}
                          {["awaiting_fulfillment", "kit_assigned", "shipped"].includes(c.status) && (
                            <button disabled={cycleBusy === c.id} onClick={() => cycleAction(c.id, "cancel")} className="rounded-[8px] border border-[rgba(176,64,64,0.4)] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#b04040] hover:bg-[rgba(176,64,64,0.06)] disabled:opacity-50">Cancel</button>
                          )}
                          {c.status === "results_final" && (
                            <button
                              disabled={cycleBusy === c.id}
                              title="Closes automatically when the interpretation is ready; use this for a result the patient will never open."
                              onClick={() => cycleAction(c.id, "complete")}
                              className="rounded-[8px] border border-[#e7e2dc] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#4c463f] hover:border-[#97472c] hover:text-[#97472c] disabled:opacity-50"
                            >
                              Mark completed
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">
            Statuses from <span className="font-[family-name:var(--font-dm-mono)]">activated</span> onward are driven by the patient, the lab bridge and the results pipeline — this desk only assigns, ships, reopens and cancels.
          </p>
        </div>
      )}

      {/* ─── Tab 1: Pending Bookings (legacy booked_tests flow) ─── */}
      {tab === "bookings" && (
        <div className="mt-6 overflow-x-auto rounded-[16px] border border-[#e7e2dc] bg-white">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#e7e2dc] bg-[#f8f3ed]">
                <th className={thClass}>User</th>
                <th className={thClass}>Email</th>
                <th className={thClass}>Panel</th>
                <th className={thClass}>Date</th>
                <th className={thClass}>Status</th>
              </tr>
            </thead>
            <tbody>
              {bookings.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-8 text-center font-[family-name:var(--font-inter)] text-[13px] text-[#8a7f76]">No pending bookings</td></tr>
              )}
              {bookings.map((b) => (
                <tr key={b.id} className="border-b border-[#f8f3ed] hover:bg-[#faf7f3]">
                  <td className={tdClass}>{b.profiles?.full_name ?? "—"}</td>
                  <td className={`${tdClass} text-[#8a7f76]`}>{b.profiles?.email ?? "—"}</td>
                  <td className={tdClass}>
                    <span className="rounded-full bg-[rgba(58,102,94,0.08)] px-2 py-0.5 text-[11px] font-medium text-[#3a665e]">
                      {panels[b.panel_type]?.name ?? b.panel_type}
                    </span>
                  </td>
                  <td className={`${tdClass} text-[#8a7f76]`}>{b.scheduled_date ?? "—"}</td>
                  <td className={tdClass}>
                    <select
                      value={b.status}
                      onChange={(e) => updateBookingStatus(b.id, e.target.value)}
                      className={`${inputClass} !py-1.5 !text-[11px]`}
                    >
                      {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ")}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ─── Tab 2: Enter Results ─── */}
      {tab === "enter" && (
        <div className="mt-6 max-w-2xl">
          {/* User search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search user by name or email..."
              value={userSearch}
              onChange={(e) => { setUserSearch(e.target.value); setSelectedUser(null); }}
              className={`${inputClass} w-full`}
            />
            {filteredUsers.length > 0 && !selectedUser && (
              <div className="absolute left-0 right-0 top-full z-10 mt-1 max-h-48 overflow-y-auto rounded-[12px] border border-[#e7e2dc] bg-white shadow-lg">
                {filteredUsers.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => { setSelectedUser(u); setUserSearch(u.full_name ?? u.email ?? ""); }}
                    className="flex w-full items-center gap-2 px-4 py-2.5 text-left hover:bg-[#f8f3ed]"
                  >
                    <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#1d1b18]">{u.full_name ?? "No name"}</span>
                    <span className="font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">{u.email}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {selectedUser && (
            <div className="mt-4 rounded-[12px] bg-[rgba(58,102,94,0.06)] px-4 py-2">
              <span className="font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#3a665e]">
                {selectedUser.full_name} ({selectedUser.email})
              </span>
            </div>
          )}

          {/* Biomarker form */}
          {selectedUser && (
            <div className="mt-6">
              <h3 className="font-[family-name:var(--font-dm-mono)] text-[11px] font-semibold uppercase tracking-[1.5px] text-[#8a7f76]">Base Panel Biomarkers</h3>
              <div className="mt-4 space-y-2">
                {BASE_BIOMARKERS.map((b) => (
                  <div key={b.key} className={`flex items-center gap-3 rounded-[12px] border border-[#e7e2dc] px-4 py-2.5 ${skipped.has(b.key) ? "opacity-40" : ""}`}>
                    <span className="w-40 shrink-0 font-[family-name:var(--font-manrope)] text-[13px] font-bold text-[#1d1b18]">{b.name}</span>
                    {/* The sign printed before the value: "<5" is below 5. A result printed with "≤" or "≥" is
                        entered with the sign that applies; only "<" and ">" can be stored. */}
                    <select
                      aria-label={`${b.name} sign`}
                      title="Sign printed before the value"
                      value={biomarkerSigns[b.key] ?? ""}
                      onChange={(e) => {
                        const next = { ...biomarkerSigns };
                        const sign = e.target.value;
                        if (sign === "<" || sign === ">" || sign === "≤" || sign === "≥") next[b.key] = sign;
                        else delete next[b.key];
                        setBiomarkerSigns(next);
                      }}
                      disabled={skipped.has(b.key)}
                      className={`${inputClass} w-14`}
                    >
                      <option value="">=</option>
                      <option value="<">&lt;</option>
                      <option value=">">&gt;</option>
                      {/* As printed: a result with one of these is set aside and named, never entered under "<" or ">". */}
                      <option value="≤">≤</option>
                      <option value="≥">≥</option>
                    </select>
                    <input
                      type="number"
                      step="any"
                      placeholder="Value"
                      value={biomarkerValues[b.key] ?? ""}
                      onChange={(e) => setBiomarkerValues({ ...biomarkerValues, [b.key]: e.target.value })}
                      disabled={skipped.has(b.key)}
                      className={`${inputClass} w-24`}
                    />
                    <span className="w-16 shrink-0 font-[family-name:var(--font-inter)] text-[11px] text-[#8a7f76]">{b.unit}</span>
                    <label className="flex items-center gap-1.5 text-[11px] text-[#8a7f76]">
                      <input
                        type="checkbox"
                        checked={skipped.has(b.key)}
                        onChange={(e) => {
                          const next = new Set(skipped);
                          e.target.checked ? next.add(b.key) : next.delete(b.key);
                          setSkipped(next);
                        }}
                        className="h-3.5 w-3.5 rounded border-[#e7e2dc]"
                      />
                      Skip
                    </label>
                  </div>
                ))}
              </div>

              <button
                onClick={handleSubmitResults}
                disabled={submitting}
                className="mt-6 rounded-[100px] bg-gradient-to-br from-[#97472c] to-[#d97b5c] px-8 py-3 font-[family-name:var(--font-manrope)] text-[14px] font-bold text-white shadow-[0_12px_40px_rgba(151,71,44,0.2)] transition-all hover:-translate-y-0.5 disabled:opacity-60"
              >
                {submitting ? "Processing..." : "Submit Results"}
              </button>

              {submitResult && (
                <p className={`mt-4 whitespace-pre-line font-[family-name:var(--font-inter)] text-[14px] ${submitResult.startsWith("Success") ? "text-[#3a665e]" : "text-[#b04040]"}`}>
                  {submitResult}
                </p>
              )}
            </div>
          )}
        </div>
      )}

      {/* ─── Tab 3: Processing Log ─── */}
      {tab === "log" && (
        <div className="mt-6 overflow-x-auto rounded-[16px] border border-[#e7e2dc] bg-white">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#e7e2dc] bg-[#f8f3ed]">
                <th className={thClass}>User</th>
                <th className={thClass}>Source</th>
                <th className={thClass}>Date</th>
                <th className={thClass}>Bio Age</th>
                <th className={thClass}>LS</th>
                <th className={thClass}>Status</th>
                <th className={thClass}>Action</th>
              </tr>
            </thead>
            <tbody>
              {labResults.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-8 text-center font-[family-name:var(--font-inter)] text-[13px] text-[#8a7f76]">No lab results</td></tr>
              )}
              {labResults.map((r) => (
                <tr key={r.id} className="border-b border-[#f8f3ed] hover:bg-[#faf7f3]">
                  <td className={tdClass}>{r.profiles?.full_name ?? "—"}</td>
                  <td className={tdClass}>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${r.source === "eva_kit" ? "bg-[rgba(151,71,44,0.08)] text-[#97472c]" : "bg-[rgba(58,102,94,0.08)] text-[#3a665e]"}`}>
                      {r.source}
                    </span>
                  </td>
                  <td className={`${tdClass} text-[#8a7f76]`}>{r.collection_date ?? "—"}</td>
                  <td className={tdClass}>{r.biological_age ?? "—"}</td>
                  <td className={tdClass}>{r.longevity_score ?? "—"}</td>
                  <td className={tdClass}>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${r.status === "ready" ? "bg-[rgba(58,102,94,0.10)] text-[#3a665e]" : r.status === "error" ? "bg-[rgba(176,64,64,0.10)] text-[#b04040]" : "bg-[rgba(196,147,50,0.10)] text-[#c49332]"}`}>
                      {r.status}
                    </span>
                  </td>
                  <td className={tdClass}>
                    {(r.status === "error" || r.status === "processing") && (
                      <button
                        onClick={() => handleReprocess(r.id)}
                        className="rounded-[8px] border border-[#e7e2dc] px-3 py-1 font-[family-name:var(--font-manrope)] text-[11px] font-bold text-[#4c463f] hover:border-[#97472c] hover:text-[#97472c]"
                      >
                        Reprocess
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
