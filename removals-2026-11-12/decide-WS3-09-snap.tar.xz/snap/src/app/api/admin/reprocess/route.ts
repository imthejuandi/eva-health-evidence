import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getBiomarkerValues, getWearableData } from "@/lib/queries";
import { recomputeLabMetrics, type ProcessedBiomarker } from "@/lib/biomarkers/process-results";
import { opsAlert } from "@/lib/ops-alert";
import { labNoteTexts } from "@/lib/lab-results/notes";

const BodySchema = z.object({
  labResultId: z.string().uuid(),
});

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    // Admin acts on another user's rows → service-role client (authz enforced above).
    const supabase = createAdminClient();
    if (!supabase) return NextResponse.json({ error: "Server misconfigured" }, { status: 503 });

    const parsed = BodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }
    const { labResultId } = parsed.data;

    // Get lab result
    const { data: labResult } = await supabase
      .from("lab_results")
      .select("id, user_id, lab_notes")
      .eq("id", labResultId)
      .single();

    if (!labResult) return NextResponse.json({ error: "Not found" }, { status: 404 });

    // Re-run summary generation
    await supabase.from("lab_results").update({ status: "processing" }).eq("id", labResultId);

    const [profile, biomarkers, wearable] = await Promise.all([
      getUserProfile(labResult.user_id, supabase),
      getBiomarkerValues(labResultId, supabase),
      getWearableData(labResult.user_id, 30, supabase),
    ]);

    if (profile && biomarkers.length > 0) {
      const processed: ProcessedBiomarker[] = biomarkers.map((b) => ({
        biomarkerKey: b.biomarker_key,
        name: b.biomarker_name ?? b.biomarker_key,
        value: b.value,
        unit: b.unit,
        zone: b.zone as ProcessedBiomarker["zone"],
        zoneLabel: b.zone,
        zoneLabel_es: b.zone,
        optimalLow: b.optimal_low,
        optimalHigh: b.optimal_high,
        matchConfidence: "exact",
      }));

      await generateSummary(labResult.user_id, labResultId, processed, wearable.length > 0 ? wearable : null, profile, supabase, {
        labNotes: labNoteTexts((labResult as { lab_notes?: unknown }).lab_notes),
      });
    }

    const { error: readyError } = await supabase.from("lab_results").update({ status: "ready" }).eq("id", labResultId);
    // The lab's figures are recomputed under the context recorded on it (a client may have confirmed one that never
    // reached them, e.g. a confirmation left in processing), and the dashboard's rolling average, which reads only
    // ready labs, is refreshed with it (recomputeLabMetrics does both). Best-effort.
    if (!readyError) {
      await recomputeLabMetrics(labResult.user_id, labResultId, supabase).catch((err) =>
        opsAlert("admin.reprocess", "lab ready but its metrics could not be recomputed", {
          labId: labResultId,
          error: err instanceof Error ? err.message : String(err),
        }),
      );
    }

    await logAdminAction({
      actor: admin,
      action: "reprocess",
      targetUserId: labResult.user_id,
      targetId: labResultId,
    });

    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("[admin/reprocess]", e);
    return NextResponse.json({ error: "Reprocess failed" }, { status: 500 });
  }
}
