import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireAdmin, logAdminAction } from "@/lib/auth/require-admin";
import { processLabResults } from "@/lib/biomarkers/process-results";
import { recomputeAndCacheUserBA } from "@/lib/biomarkers/rolling-average-ba";
import { getCurrentVersion } from "@/lib/patient-context";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { logSetAside, screenSubmittedResults, setAsideFromProcessing } from "@/lib/lab-results/screen-results";
import { setAsideText, type SetAsideResult } from "@/lib/lab-results/set-aside";

const BodySchema = z.object({
  userId: z.string().uuid(),
  biomarkers: z
    .array(
      z.object({
        name: z.string(),
        // The number, or the text as the report prints it ("5,4", "<5", "≤5"), read by readReportedValue.
        value: z.union([z.number(), z.string()]).nullable(),
        unit: z.string(),
        biomarkerKey: z.string(),
        // The sign printed before the value, when it is given beside it. "<" and ">" are stored with the bound. A
        // result printed with "≤" or "≥" is not entered under another sign or as a plain number: it is set aside and
        // named to the administrator, as a result with no readable number is (decision D-24).
        comparator: z.string().nullable().optional(),
      }),
    )
    .min(1),
  locale: z.string().default("en"),
});

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    if (!admin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    // Admin acts on another user's rows → use the service-role client (authz is
    // already enforced above) so RLS doesn't block the cross-user writes.
    const supabase = createAdminClient();
    if (!supabase) return NextResponse.json({ error: "Server misconfigured" }, { status: 503 });

    const parsed = BodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }
    const { userId, biomarkers, locale } = parsed.data;

    // Results that cannot be used are set aside before anything is stored; the rest is processed. When none can be
    // used, no lab is created and the answer names each result.
    const screened = screenSubmittedResults(biomarkers);
    const setAside: SetAsideResult[] = [...screened.setAside];
    const nothingUsable = async (labId: string | null) => {
      logSetAside("admin/enter-results", { labResultId: labId, userId }, setAside);
      await logAdminAction({
        actor: admin,
        action: "enter_results",
        targetUserId: userId,
        targetId: labId ?? undefined,
        detail: { processed: 0, setAside: setAside.map((i) => ({ name: i.name, reason: i.reason, printed: i.printed })) },
      });
      return NextResponse.json({
        labResultId: null,
        processed: 0,
        biologicalAge: null,
        nothingUsable: true,
        setAside,
        setAsideMessage: setAsideText(setAside, locale, true),
      });
    };
    if (screened.usable.length === 0) return nothingUsable(null);

    // 1. Create lab_results record, with the client's current patient context
    //    recorded on it, as the upload gate does: the biological age reads its
    //    creatine dose (patient-context/lab-context.ts).
    const context = await getCurrentVersion(userId, supabase);
    const { data: labResult, error: labErr } = await supabase.from("lab_results").insert({
      user_id: userId,
      source: "lab_partner",
      panel_type: "base",
      status: "processing",
      patient_context_version_id: context?.id ?? null,
      collection_date: new Date().toISOString().split("T")[0],
      strengths: [],
      needs_attention: [],
    }).select("id").single();

    if (labErr || !labResult) {
      return NextResponse.json({ error: "Failed to create lab result" }, { status: 500 });
    }

    // 2. Process through pipeline, with the marker the form's row names (its key, exactly as the webhook passes a
    //    mapped code, so the display name is not matched again) and a bound's comparator, so the pipeline classifies
    //    it as a bound (bounded-result.ts classifyResultZone), never as the measured number.
    const result = await processLabResults(
      userId,
      labResult.id,
      screened.usable.map(({ entry: b, value, comparator }) => ({
        name: b.name,
        value,
        unit: b.unit,
        ...(comparator ? { comparator } : {}),
        ...(b.biomarkerKey ? { biomarkerKey: b.biomarkerKey, matchConfidence: "exact" as const } : {}),
      })),
      supabase,
    );

    // A result processing refused (a unit the canonical-unit gate cannot bring to the marker's unit) is set aside
    // too. When nothing was stored, the empty lab is removed: no summary, no "ready", no email.
    setAside.push(...setAsideFromProcessing(result.unmatched));
    if (result.processed.length === 0) {
      const { error: deleteError } = await supabase.from("lab_results").delete().eq("id", labResult.id);
      if (deleteError) console.error("[admin/enter-results] failed to remove the empty lab:", deleteError);
      return nothingUsable(labResult.id);
    }
    logSetAside("admin/enter-results", { labResultId: labResult.id, userId }, setAside);

    // 3. Generate AI summary
    const profile = await getUserProfile(userId, supabase);
    const wearable = await getWearableData(userId, 30, supabase);
    if (profile) {
      await generateSummary(userId, labResult.id, result.processed, wearable.length > 0 ? wearable : null, profile, supabase);
    }

    // 4. Update status to ready, then refresh the dashboard's rolling average,
    //    which reads only ready labs (processing cached it without this one).
    const { error: readyError } = await supabase.from("lab_results").update({ status: "ready" }).eq("id", labResult.id);
    if (!readyError) {
      await recomputeAndCacheUserBA(userId, supabase).catch((err) =>
        console.error("[admin/enter-results] recomputeAndCacheUserBA failed:", err),
      );
    }

    // 5. Send results-ready email
    if (profile) {
      const targetEmail = profile.email ?? "";
      const firstName = profile.full_name?.split(" ")[0] ?? "";
      sendEmail(targetEmail, "results-ready", {
        firstName,
        biomarkerCount: result.processed.length,
        biologicalAge: result.biologicalAge?.biologicalAge ?? null,
        baDelta: result.biologicalAge?.delta ?? null,
        longevityScore: result.biologicalAge?.longevityScore ?? null,
        locale: profile.locale ?? locale,
      }, profile.locale ?? locale).catch(() => {});
    }

    await logAdminAction({
      actor: admin,
      action: "enter_results",
      targetUserId: userId,
      targetId: labResult.id,
      detail: {
        processed: result.processed.length,
        ...(setAside.length ? { setAside: setAside.map((i) => ({ name: i.name, reason: i.reason, printed: i.printed })) } : {}),
      },
    });

    return NextResponse.json({
      labResultId: labResult.id,
      processed: result.processed.length,
      biologicalAge: result.biologicalAge,
      // Each result that was not used, with its reason; the message is the same in the administrator's language.
      setAside,
      setAsideMessage: setAsideText(setAside, locale, false),
    });
  } catch (e) {
    console.error("[admin/enter-results]", e);
    return NextResponse.json({ error: "Processing failed" }, { status: 500 });
  }
}
