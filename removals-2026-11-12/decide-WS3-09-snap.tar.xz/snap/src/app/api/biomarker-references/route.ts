import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { calculateAge } from "@/lib/biomarkers/zone-classifier";
import { pickReferenceRows } from "@/lib/biomarkers/reference-row";

/**
 * GET /api/biomarker-references
 *
 * Returns the list of canonical biomarkers the signed-in user can pick
 * from when manually mapping an extracted-but-unrecognized row in the
 * upload review step. The list is narrowed by the user's sex and age
 * so they never see a male-only marker as a female user (and vice
 * versa). Multiple age-group rows for the same key collapse into one
 * entry — the picker only needs the key, display name and canonical
 * unit, not the range itself.
 *
 * Response shape: { references: Array<{ biomarker_key, name_en, name_es, unit_en, panel_category }> }
 */
export async function GET() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("date_of_birth, sex")
    .eq("id", user.id)
    .single();

  if (profileError || !profile) {
    return NextResponse.json({ error: "Profile not found" }, { status: 404 });
  }
  if (!profile.date_of_birth || !profile.sex) {
    return NextResponse.json(
      { error: "Please complete your profile (date of birth and sex)." },
      { status: 400 }
    );
  }

  const age = calculateAge(profile.date_of_birth);
  if (isNaN(age)) {
    return NextResponse.json(
      { error: "Invalid date_of_birth on profile." },
      { status: 400 }
    );
  }

  const sex = profile.sex.toLowerCase();

  const { data: rows, error: refsError } = await supabase
    .from("biomarker_references")
    .select("biomarker_key, name_en, name_es, unit_en, sex, age_group_en, panel_category")
    .in("sex", [sex, "both"]);

  if (refsError) {
    return NextResponse.json({ error: refsError.message }, { status: 500 });
  }

  // Collapse to one row per biomarker_key: the row processing would read for
  // this user's sex and age (reference-row.ts). A key with no row for the age
  // still appears, through its fallback row.
  const references = Array.from(pickReferenceRows(rows ?? [], sex, age).picked.values())
    .map((r) => ({
      biomarker_key: r.biomarker_key,
      name_en: r.name_en,
      name_es: r.name_es,
      unit_en: r.unit_en,
      panel_category: r.panel_category,
    }))
    .sort((a, b) => a.name_en.localeCompare(b.name_en));

  return NextResponse.json({ references });
}
