import { randomUUID, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { opsAlert } from "@/lib/ops-alert";
import { resolvePendingLab } from "@/lib/lab-results/auto-resolve";

/**
 * 72-hour fallback for bridge- and webhook-arrived labs the user never opened.
 *
 * If a lab has been sitting in pending_context for more than 72 hours,
 * we resolve it on the user's behalf using their last-saved durable
 * context (or an empty snapshot if they've never filled it in) and
 * transient.skipped = true. The frontend marks the resulting
 * interpretation with a banner ("Generated without per-draw context —
 * tap to refine") so the user can still come back and regenerate.
 *
 * Triggered by Vercel Cron (configured in vercel.json) once daily at
 * 03:00 UTC. With a 72h pending threshold, a daily run resolves any
 * stuck lab within ≤24h of crossing it — acceptable since the cron is
 * the fallback for the (rare) case where the user never opens the
 * "context-needed" email. Every read and write goes through the
 * service-role client — there is no user session here, so the cookie-bound
 * client would see nothing under RLS (that was audit finding F09: each lab
 * crossed the threshold straight into 'error').
 *
 * A lab that fails stays in pending_context and is retried tomorrow: the
 * patient can still open it, and the failure is alerted, never buried.
 *
 * Authentication: Vercel Cron sends a request with the
 * Authorization: Bearer <CRON_SECRET> header. We reject anything else.
 */

export const maxDuration = 120;

const FALLBACK_AFTER_HOURS = 72;

export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret) {
    console.error("[cron.auto-resolve] CRON_SECRET missing — refusing to run");
    return NextResponse.json({ error: "Not configured" }, { status: 503 });
  }
  // Constant-time compare to avoid a timing oracle on the cron secret.
  const provided = Buffer.from(req.headers.get("authorization") ?? "");
  const expected = Buffer.from(`Bearer ${secret}`);
  if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: "Admin client unavailable" }, { status: 503 });
  }

  const threshold = new Date(
    Date.now() - FALLBACK_AFTER_HOURS * 3600_000,
  ).toISOString();

  const { data: labs, error } = await admin
    .from("lab_results")
    .select("id, user_id, created_at")
    .eq("status", "pending_context")
    .lt("created_at", threshold)
    .limit(20); // cap per run so a backlog doesn't blow the function budget

  if (error) {
    console.error("[cron.auto-resolve] query failed:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  const results: Array<{ id: string; ok: boolean; reason?: string }> = [];
  for (const lab of labs ?? []) {
    // This run's claim on the lab, stamped by resolvePendingLab, so a failure releases only this claim.
    const claim = randomUUID();
    try {
      const resolved = await resolvePendingLab(admin, lab.id, lab.user_id, undefined, claim);
      // A lab the client (or another run) claimed while this run was starting is theirs to finish.
      results.push(resolved.skipped ? { id: lab.id, ok: true, reason: "claimed elsewhere" } : { id: lab.id, ok: true });
    } catch (err) {
      const reason = err instanceof Error ? err.message : "unknown";
      results.push({ id: lab.id, ok: false, reason });
      // Back to where the patient can still act on it; never 'error'. Only this run's claim: a lab the client or
      // another run holds stays theirs. The alert says which happened.
      const { data: released, error: releaseError } = await admin
        .from("lab_results")
        .update({ status: "pending_context" })
        .eq("id", lab.id)
        .eq("status", "processing")
        .eq("transient_context->>claim", claim)
        .select("id");
      const back = !releaseError && (released?.length ?? 0) > 0;
      opsAlert(
        "cron.auto-resolve",
        back
          ? "lab could not be auto-resolved — left pending for the next run"
          : "lab could not be auto-resolved — not released: the client or another run holds it, or the release failed",
        { labId: lab.id, error: reason, ...(releaseError ? { releaseError: releaseError.message } : {}) },
      );
    }
  }

  const failures = results.filter((r) => !r.ok).length;

  // OPS-010 — structured failure/backlog signal. With Sentry disabled today
  // (OPS-001) the only sink is Vercel logs, so emit a single greppable line a
  // log-drain/monitor can alert on: any per-lab failure, OR a backlog of labs
  // still stuck past the threshold (cron not keeping up / silently mis-firing).
  const { count: backlog } = await admin
    .from("lab_results")
    .select("id", { count: "exact", head: true })
    .eq("status", "pending_context")
    .lt("created_at", threshold);

  if (failures > 0 || (backlog ?? 0) > 0) {
    console.error(
      `[cron.auto-resolve][ALERT] failures=${failures} processed=${results.length} backlog_pending_over_threshold=${backlog ?? "unknown"}`,
    );
  } else {
    // Heartbeat for a dead-man's-switch monitor: a healthy run with nothing
    // stuck. An external cron health check should alert if this line is ABSENT
    // for >24h, which catches a cron that silently stopped firing.
    console.log(`[cron.auto-resolve][OK] processed=${results.length} backlog=0`);
  }

  return NextResponse.json({
    threshold_hours: FALLBACK_AFTER_HOURS,
    processed: results.length,
    failures,
    backlog: backlog ?? null,
    results,
  });
}
