import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { processLabResults, type RawBiomarker } from "@/lib/biomarkers/process-results";
import { loadLabState, type LabState } from "@/lib/patient-context/physiological-state";
import { CREATININE_KEYS } from "@/lib/biomarkers/creatinine-plausibility";
import { recomputeAndCacheUserBA } from "@/lib/biomarkers/rolling-average-ba";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";

/**
 * Reprocess an existing lab result through the current classification +
 * conversion pipeline.
 *
 * Delete strategy: uses the admin (service-role) client if
 * SUPABASE_SERVICE_ROLE_KEY is configured. Otherwise falls back to the
 * user client, which only works if the DELETE RLS policies from migration
 * 20260410000000_add_delete_policies.sql have been applied. Either path
 * unblocks reprocessing. After each delete we VERIFY by re-counting rows,
 * so silent RLS rejections produce a clear error with both fix options
 * instead of silently doubling data.
 */

const BodySchema = z.object({
  labResultId: z.string().uuid(),
});

/**
 * Missing-config error message pointing to both possible remedies.
 */
const MISSING_DELETE_RIGHTS_ERROR =
  "Could not delete existing biomarker rows — this usually means DELETE " +
  "RLS policies are missing on biomarker_values/action_steps/lab_results. " +
  "Fix options: (A) set SUPABASE_SERVICE_ROLE_KEY in Vercel env vars, OR " +
  "(B) apply migration 20260410000000_add_delete_policies.sql in the " +
  "Supabase SQL editor.";

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const admin = createAdminClient();
  // Prefer admin client for writes (bypasses RLS). Fall back to the user
  // client which only works if the DELETE policies migration was applied.
  const writer = admin ?? supabase;

  let labResultId: string | null = null;

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const parseResult = BodySchema.safeParse(await req.json().catch(() => null));
    if (!parseResult.success) {
      return NextResponse.json(
        { error: "Invalid request body", details: parseResult.error.issues },
        { status: 400 }
      );
    }
    labResultId = parseResult.data.labResultId;

    // 1. Verify the lab_result belongs to the current user (use user client
    //    so RLS still enforces ownership — admin client bypasses it).
    const { data: labResult, error: labError } = await supabase
      .from("lab_results")
      .select("id, user_id, collection_date")
      .eq("id", labResultId)
      .eq("user_id", user.id)
      .single();

    if (labError || !labResult) {
      return NextResponse.json({ error: "Lab result not found" }, { status: 404 });
    }

    // 1a. Dedupe lab_results for the same date — if the user has multiple
    //     lab_results on the same collection_date (from pre-fix uploads),
    //     keep THIS one and absorb all their biomarker_values into it,
    //     then delete the others. Enforces "one lab per date" on old data.
    if (labResult.collection_date) {
      const { data: sameDateLabs } = await supabase
        .from("lab_results")
        .select("id")
        .eq("user_id", user.id)
        .eq("collection_date", labResult.collection_date)
        .neq("id", labResultId);

      if (sameDateLabs && sameDateLabs.length > 0) {
        console.log(
          `[reprocess] Found ${sameDateLabs.length} duplicate lab_results for date ` +
            `${labResult.collection_date}. Consolidating into ${labResultId}.`,
        );
        const otherIds = sameDateLabs.map((l) => l.id);
        // Move their biomarker_values into the primary lab_result so we
        // don't lose data, THEN delete the duplicate lab_results.
        // The biomarker_values are re-inserted fresh by processLabResults
        // later anyway, so we just need the raw data to survive the move.
        // Simpler: re-point biomarker_values to the primary lab_result.
        const { error: repointError } = await writer
          .from("biomarker_values")
          .update({ lab_result_id: labResultId })
          .in("lab_result_id", otherIds);

        if (repointError) {
          console.error("[reprocess] Failed to repoint duplicate biomarker_values:", repointError);
        }

        // Delete the duplicate lab_results (cascade would catch any stragglers)
        const { error: deleteDupesError } = await writer
          .from("lab_results")
          .delete()
          .in("id", otherIds);

        if (deleteDupesError) {
          console.error("[reprocess] Failed to delete duplicate lab_results:", deleteDupesError);
        }
      }
    }

    // 2. Load ALL existing biomarker_values rows for this lab_result — some
    //    may be duplicates from a previous failed reprocess (pre-RLS-fix).
    const { data: existingValues, error: fetchError } = await supabase
      .from("biomarker_values")
      .select("id, biomarker_key, biomarker_name, value, unit, comparator, created_at")
      .eq("lab_result_id", labResultId)
      .order("created_at", { ascending: true });

    if (fetchError) {
      console.error("[reprocess] Failed to fetch biomarker_values:", fetchError);
      return NextResponse.json({ error: "Failed to load biomarkers" }, { status: 500 });
    }

    if (!existingValues || existingValues.length === 0) {
      return NextResponse.json(
        { error: "No biomarkers found for this lab result" },
        { status: 400 }
      );
    }

    // 3. Deduplicate by (biomarker_key + normalized unit) — keep the FIRST
    //    row per combo (oldest created_at, most likely to have the original
    //    raw value before any previous reprocess touched it).
    //
    //    Why include the unit: CBC differentials and other biomarkers can
    //    legitimately appear twice on the same lab in different forms
    //    (e.g. Lymphocytes "%" and "x10³/µL"). The remap step distinguishes
    //    them by unit, so dedup'ing on biomarker_key alone would silently
    //    drop one of the two and break the absolute-form classification.
    const { normalizeUnit } = await import("@/lib/biomarkers/canonical-units");
    const seen = new Set<string>();
    const dedupedInput: typeof existingValues = [];
    for (const row of existingValues) {
      const baseKey = row.biomarker_key ?? row.biomarker_name ?? "";
      const unitKey = normalizeUnit(row.unit);
      // Creatinine rows that disagree are both kept, so processing's per-lab rule withholds the figure
      // (creatinine-plausibility.ts) rather than this step deleting one of them; exact copies still collapse.
      const key = CREATININE_KEYS.has(baseKey) ? `${baseKey}|${unitKey}|${Number(row.value)}` : `${baseKey}|${unitKey}`;
      if (seen.has(key)) continue;
      seen.add(key);
      dedupedInput.push(row);
    }

    console.log(
      `[reprocess] lab_result=${labResultId}: ${existingValues.length} existing rows, ` +
        `${dedupedInput.length} unique biomarkers after dedup`,
    );

    // 3b. The lab's patient context (its supplements, for the creatine adjustment, and its physiological state), read
    //     before anything is changed: processing would otherwise read it after the delete below, and a failed read
    //     there would leave the lab with no values to reprocess. A failed read here changes nothing.
    let labState: LabState;
    try {
      labState = await loadLabState(supabase, user.id, labResultId);
    } catch (err) {
      console.error("[reprocess] Failed to read the lab's context:", err);
      return NextResponse.json({ error: "Failed to load the lab's context" }, { status: 500 });
    }

    // 4. Set status to processing
    await writer
      .from("lab_results")
      .update({ status: "processing" })
      .eq("id", labResultId);

    // 5. Delete ALL existing biomarker_values for this lab_result. Uses
    //    the admin client if available (bypassing RLS), otherwise falls
    //    back to the user client — which only works if the DELETE RLS
    //    policies migration has been applied. Because Supabase silently
    //    reports success on RLS-rejected DELETEs, we verify by re-counting
    //    rows and surface a clear error if any remain.
    const { error: deleteValuesError } = await writer
      .from("biomarker_values")
      .delete()
      .eq("lab_result_id", labResultId);

    if (deleteValuesError) {
      throw new Error(`Failed to clear biomarker_values: ${deleteValuesError.message}`);
    }

    // 5a. Verify the delete actually removed rows — RLS silently swallows
    //     DELETE rejections, so we have to count manually.
    const { count: remainingValues, error: countError } = await supabase
      .from("biomarker_values")
      .select("id", { count: "exact", head: true })
      .eq("lab_result_id", labResultId);

    if (countError) {
      console.error("[reprocess] Failed to verify biomarker_values delete:", countError);
    } else if ((remainingValues ?? 0) > 0) {
      console.error(
        `[reprocess] DELETE silently rejected: ${remainingValues} biomarker_values rows ` +
          `still exist for lab_result=${labResultId}. Admin=${admin ? "yes" : "no"}.`,
      );
      throw new Error(MISSING_DELETE_RIGHTS_ERROR);
    }

    // 6. Clear action_steps too so generateSummary can re-insert them cleanly
    const { error: deleteStepsError } = await writer
      .from("action_steps")
      .delete()
      .eq("lab_result_id", labResultId);

    if (deleteStepsError) {
      console.error("[reprocess] Failed to clear action_steps (non-fatal):", deleteStepsError);
    }

    // 7. Build RawBiomarker[] from the DEDUPED rows. Pass biomarkerKey so
    //    the pipeline uses the user's original match (no re-matching).
    //    A bounded result ("<0,500") keeps its comparator, so the pipeline classifies it as a bound
    //    (bounded-result.ts classifyResultZone), never as the measured number.
    const rawBiomarkers: RawBiomarker[] = dedupedInput.map((v) => ({
      name: v.biomarker_name ?? v.biomarker_key,
      value: v.value,
      unit: v.unit ?? "",
      ...(v.comparator === "<" || v.comparator === ">" ? { comparator: v.comparator as "<" | ">" } : {}),
      biomarkerKey: v.biomarker_key ?? undefined,
    }));

    // 8. Run the new pipeline. This re-applies unit conversion + zone
    //    classification + biological age + counts, inserting fresh rows.
    const result = await processLabResults(user.id, labResultId, rawBiomarkers, undefined, { labState });

    // 9. Re-generate summary (non-fatal on error — zones + counts are
    //    already in place)
    try {
      const [profile, wearable] = await Promise.all([
        getUserProfile(user.id),
        getWearableData(user.id, 30),
      ]);
      if (profile && result.processed.length > 0) {
        await generateSummary(
          user.id,
          labResultId,
          result.processed,
          wearable.length > 0 ? wearable : null,
          profile,
        );
      }
    } catch (summaryErr) {
      console.error("[reprocess] Summary regeneration failed (non-fatal):", summaryErr);
    }

    // 10. Mark ready, then refresh the dashboard's rolling average, which
    //     reads only ready labs (processing cached it without this one).
    const { error: readyError } = await writer
      .from("lab_results")
      .update({ status: "ready" })
      .eq("id", labResultId);
    if (!readyError) {
      await recomputeAndCacheUserBA(user.id, writer).catch((err) =>
        console.error("[reprocess] recomputeAndCacheUserBA failed:", err),
      );
    }

    return NextResponse.json({
      success: true,
      labResultId,
      inputRows: existingValues.length,
      dedupedInputRows: dedupedInput.length,
      processed: result.processed.length,
      unmatched: result.unmatched.length,
      biologicalAge: result.biologicalAge,
      // Diagnostic: if refMapSize is 0, biomarker_references is not seeded.
      // missingRefKeys lists up to 20 biomarkers whose keys weren't found
      // in the reference table — useful for spotting seed/matcher mismatches.
      refMapSize: result.refMapSize,
      missingRefKeys: result.missingRefKeys,
    });
  } catch (e) {
    console.error("[reprocess] Error:", e);

    // Revert status to error so the UI doesn't hang in "processing"
    if (labResultId) {
      try {
        await writer
          .from("lab_results")
          .update({ status: "error" })
          .eq("id", labResultId);
      } catch {
        /* ignore */
      }
    }

    const message = e instanceof Error ? e.message : "Reprocess failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
