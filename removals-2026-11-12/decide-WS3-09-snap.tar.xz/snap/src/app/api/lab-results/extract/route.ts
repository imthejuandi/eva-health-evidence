import { NextRequest, NextResponse } from "next/server";
import { isLabReportedValueOnly } from "@/lib/biomarkers/lab-reported";
import { createClient } from "@/lib/supabase/server";
import { GoogleGenAI, Type } from "@google/genai";
import { matchBiomarkerName } from "@/lib/biomarkers/name-matcher";
import { remapToSeedKey } from "@/lib/biomarkers/key-aliases";
import { convertBiomarker } from "@/lib/biomarkers/unit-conversions";
import { getCanonicalUnit, validateCanonicalUnit } from "@/lib/biomarkers/canonical-units";
import { ZONE_CONFIG, calculateAge } from "@/lib/biomarkers/zone-classifier";
import type { Zone } from "@/lib/biomarkers/zone-classifier";
import { classifyResultZone } from "@/lib/biomarkers/bounded-result";
import { pickReferenceRows } from "@/lib/biomarkers/reference-row";
import { getPrompt } from "@/lib/ai/prompts";
import { logSetAside, readExtractedItems, type ExtractedResult } from "@/lib/lab-results/screen-results";
import type { SetAsideResult } from "@/lib/lab-results/set-aside";

/**
 * Tolerant date parser for whatever Gemini returns. Accepts ISO,
 * European DD/MM/YYYY, US MM/DD/YYYY (only when unambiguous), and a few
 * spelled-out formats. Returns YYYY-MM-DD or null.
 */
function normalizeExtractedDate(raw: unknown): string | null {
  if (!raw || typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;

  // ISO YYYY-MM-DD (preferred, since the prompt asks for it)
  const iso = trimmed.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) {
    const y = Number(iso[1]);
    const m = Number(iso[2]);
    const d = Number(iso[3]);
    if (m >= 1 && m <= 12 && d >= 1 && d <= 31) {
      return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    }
  }

  // European DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
  const eu = trimmed.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
  if (eu) {
    const a = Number(eu[1]);
    const b = Number(eu[2]);
    const y = Number(eu[3]);
    let day: number, month: number;
    if (a > 12) { day = a; month = b; }
    else if (b > 12) { day = b; month = a; }
    else { day = a; month = b; } // default European
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return `${y}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    }
  }

  // Last resort: let Date parse it and reformat
  const fallback = new Date(trimmed);
  if (!isNaN(fallback.getTime())) {
    const y = fallback.getFullYear();
    const m = fallback.getMonth() + 1;
    const d = fallback.getDate();
    if (y >= 1900 && y <= 2100) {
      return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    }
  }

  return null;
}

export async function POST(req: NextRequest) {
  try {
    // Validate env var before doing anything
    const geminiKey = process.env.GEMINI_API_KEY;
    if (!geminiKey) {
      console.error("[extract] GEMINI_API_KEY not set");
      return NextResponse.json({ error: "Server misconfigured: AI service unavailable" }, { status: 503 });
    }

    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user profile for zone classification + locale-aware matched name
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("date_of_birth, sex, subscription_status, total_uploads_used, locale")
      .eq("id", user.id)
      .single();

    if (profileError || !profile) {
      console.error("[extract] Failed to load profile:", profileError);
      return NextResponse.json({ error: "Profile not found. Please complete onboarding." }, { status: 404 });
    }

    // Require DOB and sex for zone classification and biological age
    if (!profile.date_of_birth || !profile.sex) {
      return NextResponse.json(
        { error: "Please complete your profile (date of birth and sex) before uploading lab results." },
        { status: 400 }
      );
    }

    // Check upload limit for free users
    const isSubscriber = profile.subscription_status === "active";
    const totalUsed = profile.total_uploads_used ?? 0;
    if (!isSubscriber && totalUsed >= 5) {
      return NextResponse.json({ error: "Upload limit reached" }, { status: 403 });
    }

    // Parse multipart form data
    const formData = await req.formData();
    const files = formData.getAll("files") as File[];

    if (files.length === 0) {
      return NextResponse.json({ error: "No files provided" }, { status: 400 });
    }

    // SEC-009 — bound file count, per-file + aggregate byte size, and content
    // type BEFORE buffering anything into memory or forwarding to Storage/Gemini.
    const MAX_FILES = 10;
    const MAX_FILE_BYTES = 15 * 1024 * 1024; // 15 MB per file
    const MAX_TOTAL_BYTES = 40 * 1024 * 1024; // 40 MB per request
    const ALLOWED_TYPES = new Set([
      "application/pdf",
      "image/png",
      "image/jpeg",
      "image/jpg",
      "image/webp",
      "image/heic",
      "image/heif",
    ]);
    const ALLOWED_EXTS = new Set(["pdf", "png", "jpg", "jpeg", "webp", "heic", "heif"]);

    if (files.length > MAX_FILES) {
      return NextResponse.json(
        { error: `Too many files. Upload at most ${MAX_FILES} at once.` },
        { status: 400 },
      );
    }
    let totalBytes = 0;
    for (const file of files) {
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
      const typeOk =
        ALLOWED_TYPES.has(file.type) ||
        ((!file.type || file.type === "application/octet-stream") &&
          ALLOWED_EXTS.has(ext));
      if (!typeOk) {
        return NextResponse.json(
          { error: "Unsupported file type. Upload PDF, PNG, JPEG, WEBP, or HEIC." },
          { status: 415 },
        );
      }
      if (file.size > MAX_FILE_BYTES) {
        return NextResponse.json(
          { error: `Each file must be under ${MAX_FILE_BYTES / (1024 * 1024)} MB.` },
          { status: 413 },
        );
      }
      totalBytes += file.size;
    }
    if (totalBytes > MAX_TOTAL_BYTES) {
      return NextResponse.json(
        { error: `Total upload must be under ${MAX_TOTAL_BYTES / (1024 * 1024)} MB.` },
        { status: 413 },
      );
    }

    // Always create a new lab_result row for every upload. We used to
    // reuse any same-day row to "consolidate duplicates", but that
    // quietly wiped the previous upload's biomarker_values when a user
    // legitimately uploaded two different labs on the same day. Users
    // can always delete unwanted rows from /labs/manage.
    const collectionDate = new Date().toISOString().split("T")[0];

    const { data: labResult, error: labError } = await supabase
      .from("lab_results")
      .insert({
        user_id: user.id,
        source: "upload",
        collection_date: collectionDate,
        strengths: [],
        needs_attention: [],
      })
      .select("id")
      .single();

    if (labError || !labResult) {
      console.error("[extract] Failed to create lab_result:", labError);
      return NextResponse.json({ error: "Failed to create lab result" }, { status: 500 });
    }

    const labResultId: string = labResult.id;
    const timestamp = Date.now();

    // Store files in Supabase Storage and extract biomarkers. A result the report prints as a bound ("<5") keeps its
    // comparator, and `value` is the bound itself; one printed with "≤" or "≥" has no comparator and carries the
    // printed sign in signToReview: the review shows it as set aside, and it is not stored (decision D-24). A named
    // result with no readable number is set aside too, and named to the client at review.
    const allExtracted: ExtractedResult[] = [];
    const unreadable: SetAsideResult[] = [];

    // First valid YYYY-MM-DD collection date Gemini returns across all files.
    // If multiple files are uploaded together (e.g. front + back of one
    // report), we only take the first; the user can correct it at confirm.
    let extractedCollectionDate: string | null = null;

    const genai = new GoogleGenAI({ apiKey: geminiKey });
    const extractionPrompt = await getPrompt("lab_extraction");

    // Collect per-file failure reasons so we can surface them to the user
    // if NOTHING extracts. Previously the 422 error was always generic.
    const fileErrors: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const buffer = Buffer.from(await file.arrayBuffer());
      const ext = file.name.split(".").pop()?.toLowerCase() ?? "bin";
      const storagePath = `${user.id}/${timestamp}/${i}.${ext}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from("lab-uploads")
        .upload(storagePath, buffer, { contentType: file.type });

      if (uploadError) {
        console.error(`[extract] Storage upload failed for ${file.name}:`, uploadError);
        // Continue — the AI extraction can still succeed even if storage fails
      }

      // Gemini accepts PDFs and images via inlineData
      const base64 = buffer.toString("base64");
      const mimeType = file.type || (ext === "pdf" ? "application/pdf" : "image/jpeg");

      try {
        console.log(`[extract] Calling Gemini for ${file.name} (${buffer.length} bytes, ${mimeType})`);

        const response = await genai.models.generateContent({
          model: extractionPrompt.model,
          contents: [
            {
              role: "user",
              parts: [
                { inlineData: { mimeType, data: base64 } },
                { text: extractionPrompt.content },
              ],
            },
          ],
          config: {
            ...(extractionPrompt.temperature != null && { temperature: extractionPrompt.temperature }),
            /* Max output for Gemini 2.5 Flash is 65,536. Large lab reports
               with 30-50 biomarkers easily exceed 8K in the JSON response. */
            ...(extractionPrompt.maxOutputTokens != null && { maxOutputTokens: extractionPrompt.maxOutputTokens }),
            /* Disable "thinking" mode. For pure structured extraction we
               don't need internal reasoning — and thinking tokens count
               against the output budget, which was truncating responses
               before any JSON was written. */
            ...(extractionPrompt.thinkingBudget != null && { thinkingConfig: { thinkingBudget: extractionPrompt.thinkingBudget } }),
            ...(extractionPrompt.responseMimeType && { responseMimeType: extractionPrompt.responseMimeType }),
            /* Object response so we can return both the collection date
               and the biomarkers array in one Gemini call. The schema
               stays in code because it is structured TypeScript, not
               human-edited prompt text. */
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                collection_date: { type: Type.STRING, nullable: true },
                biomarkers: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      value: { type: Type.NUMBER },
                      // The sign the report prints before a bounded value ("<5", ">8,000"), with the bound itself
                      // in value. The extraction prompt is a database row (src/lib/ai/prompts.ts); this description
                      // asks for the sign until the prompt text is reviewed.
                      comparator: {
                        type: Type.STRING,
                        format: "enum",
                        enum: ["<", ">", "≤", "≥"],
                        nullable: true,
                        description:
                          "The sign printed directly before the result when the report gives it as a limit, for example \"<\" for \"<5\" or \">\" for \">8,000\"; value is then the number after the sign. Null when the result is printed without a sign.",
                      },
                      unit: { type: Type.STRING },
                      reference_range: { type: Type.STRING },
                      flag: { type: Type.STRING, nullable: true },
                    },
                    required: ["name", "value", "unit"],
                  },
                },
              },
              required: ["biomarkers"],
            },
          },
        });

        // Deep diagnostics: finishReason, promptFeedback, candidate count.
        // If Gemini blocks for safety the response will have 0 candidates
        // or a non-STOP finishReason, and response.text will be empty.
        const candidates = response.candidates ?? [];
        const firstCandidate = candidates[0];
        const finishReason = firstCandidate?.finishReason;
        const promptFeedback = response.promptFeedback;
        console.log(`[extract] Gemini response meta for ${file.name}:`, {
          candidateCount: candidates.length,
          finishReason,
          blockReason: promptFeedback?.blockReason,
          safetyRatings: promptFeedback?.safetyRatings?.map((r) => ({
            category: r.category,
            probability: r.probability,
          })),
        });

        if (promptFeedback?.blockReason) {
          const reason = `Gemini blocked the prompt: ${promptFeedback.blockReason}`;
          console.error(`[extract] ${reason} for ${file.name}`);
          fileErrors.push(`${file.name}: ${reason}`);
          continue;
        }

        if (finishReason && finishReason !== "STOP") {
          const reason = `Gemini finishReason=${finishReason} (not STOP). Likely truncated by token limit or safety.`;
          console.error(`[extract] ${reason} for ${file.name}`);
          fileErrors.push(`${file.name}: ${reason}`);
          continue;
        }

        const responseText = response.text ?? "";
        console.log(`[extract] Gemini raw response for ${file.name} (first 1000 chars):`, responseText.slice(0, 1000));

        if (!responseText) {
          const reason = "Gemini returned an empty response";
          console.error(`[extract] ${reason} for ${file.name}. Full response keys:`, Object.keys(response));
          fileErrors.push(`${file.name}: ${reason}`);
          continue;
        }

        // Parse flexibly: try array first, fall back to common object-wrapper shapes
        let parsed: unknown;
        try {
          parsed = JSON.parse(responseText);
        } catch (parseErr) {
          // Sometimes Gemini wraps JSON in markdown fences despite the mime type
          const match = responseText.match(/\[[\s\S]*\]/);
          if (match) {
            try { parsed = JSON.parse(match[0]); } catch { parsed = null; }
          }
          if (!parsed) {
            console.error(`[extract] JSON parse failed for ${file.name}:`, parseErr);
            console.error(`[extract] Response was:`, responseText.slice(0, 1000));
            fileErrors.push(`${file.name}: could not parse AI response as JSON`);
            continue;
          }
        }

        // Accept the new object shape (collection_date + biomarkers) OR a
        // bare array (legacy fallback in case the schema is ignored).
        let items: unknown[] = [];
        if (Array.isArray(parsed)) {
          items = parsed;
        } else if (parsed && typeof parsed === "object") {
          const obj = parsed as Record<string, unknown>;
          // Capture the first valid collection_date we see across files
          if (!extractedCollectionDate) {
            const normalized = normalizeExtractedDate(obj.collection_date);
            if (normalized) {
              extractedCollectionDate = normalized;
              console.log(
                `[extract] Got collection_date from ${file.name}: ${normalized}`,
              );
            }
          }
          for (const key of ["biomarkers", "results", "data", "items"]) {
            if (Array.isArray(obj[key])) {
              items = obj[key] as unknown[];
              break;
            }
          }
          if (items.length === 0) {
            // Last resort: look for the first array-valued property
            for (const v of Object.values(obj)) {
              if (Array.isArray(v)) { items = v; break; }
            }
          }
        }

        if (items.length === 0) {
          const shape = Array.isArray(parsed)
            ? "empty array"
            : `object with keys: ${Object.keys(parsed ?? {}).join(", ") || "(none)"}`;
          console.error(`[extract] No biomarkers in parsed Gemini response for ${file.name}. Shape: ${shape}`);
          fileErrors.push(`${file.name}: AI returned no biomarkers (${shape})`);
          continue;
        }

        console.log(`[extract] Parsed ${items.length} items from ${file.name}`);

        const read = readExtractedItems(items);
        allExtracted.push(...read.extracted);
        unreadable.push(...read.setAside);
        if (read.unnamed > 0) console.warn(`[extract] ${read.unnamed} item(s) of ${file.name} had no name and could not be listed`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`[extract] AI extraction failed for ${file.name}:`, err);
        fileErrors.push(`${file.name}: ${message}`);
        // Continue with other files
      }
    }

    if (allExtracted.length === 0) {
      // Clean up the empty lab_result record so the user doesn't see orphans
      await supabase.from("lab_results").delete().eq("id", labResultId);

      // Every result that was read is set aside (none had a readable number): the client is told which, with the
      // reason, in the upload screen's language (wording-rules.md section 7), instead of a generic failure.
      if (unreadable.length > 0) {
        logSetAside("upload-extract", { userId: user.id }, unreadable);
        return NextResponse.json(
          { error: "No result in the report could be used", code: "nothing_usable", setAside: unreadable },
          { status: 422 },
        );
      }

      // Surface the actual per-file failure reasons instead of a generic message
      const detail = fileErrors.length > 0
        ? ` Details: ${fileErrors.join(" | ")}`
        : "";
      return NextResponse.json(
        {
          error: `Could not extract any biomarkers from the provided files. Please check the file quality and try again.${detail}`,
          fileErrors,
        },
        { status: 422 }
      );
    }

    // Run name matcher and zone classifier on extracted biomarkers
    const age = calculateAge(profile.date_of_birth);
    if (isNaN(age)) {
      return NextResponse.json(
        { error: `Invalid date_of_birth format "${profile.date_of_birth}". Please update your profile (use YYYY-MM-DD or pick from the date picker).` },
        { status: 400 }
      );
    }
    const sex = profile.sex;

    // Fetch ALL reference ranges for this sex (across age groups) and filter
    // in code. Resilient to age_group_en format variations in the seed.
    // We also load name_en / name_es here so the matchedName returned to
    // the client is always in the user's profile language — auto-matched
    // rows used to show a title-cased slug ("Apolipoprotein B Apob"),
    // which read as English regardless of profile.locale. Now both
    // auto-matched and manually-picked rows render the same way.
    const refMap = new Map<
      string,
      {
        optimal_low: number | null;
        optimal_high: number | null;
        normal_low: number | null;
        normal_high: number | null;
        name_en: string;
        name_es: string;
      }
    >();
    const { data: refs, error: refsError } = await supabase
      .from("biomarker_references")
      .select("biomarker_key, sex, age_group_en, optimal_low, optimal_high, normal_low, normal_high, name_en, name_es")
      .in("sex", [sex.toLowerCase(), "both"]);

    if (refsError) {
      console.error("[extract] Failed to load biomarker references:", refsError);
    } else if (refs) {
      // The same row per marker that processing will classify against
      // (reference-row.ts), so the preview shows the category the user gets.
      for (const [key, picked] of pickReferenceRows(refs, sex, age).picked) {
        refMap.set(key, {
          optimal_low: picked.optimal_low,
          optimal_high: picked.optimal_high,
          normal_low: picked.normal_low,
          normal_high: picked.normal_high,
          name_en: picked.name_en,
          name_es: picked.name_es,
        });
      }
    }

    const profileLocale = profile.locale === "es" ? "es" : "en";

    const extractedBiomarkers = allExtracted.map((raw) => {
      const match = matchBiomarkerName(raw.name);
      // The matcher emits canonical biomarker_references keys directly.
      // remapToSeedKey only still applies the CBC %/absolute split,
      // which depends on the reported unit ("# Neutrophils" → the
      // absolute-count row). We then REQUIRE the resolved key to have a
      // reference row for this user's sex+age — if it doesn't, the row
      // is treated as unmatched (matchedKey=null) so it can't be
      // auto-confirmed and the /confirm allow-list can never reject the
      // whole upload. No substring guessing: that was the mechanism
      // that resolved "pH" → luteinizing_hormone_lh.
      const seedKey = match.biomarkerKey
        ? remapToSeedKey(match.biomarkerKey, raw.unit)
        : null;
      const ref = seedKey ? refMap.get(seedKey) : undefined;
      const resolvedKey: string | null = ref ? seedKey : null;
      const matchConfidence = resolvedKey ? match.confidence : "none";

      // Apply the same unit conversion the confirm pipeline (process-results)
      // will run, so the review preview shows the value/unit/zone the user
      // will actually get stored — not the raw on-paper number. This is what
      // makes a Spanish "Linfocitos 2340 /µL" preview as 2.34 ×10³/µL in the
      // optimal band rather than a raw 2340 flagged critically high.
      const conv = seedKey
        ? convertBiomarker(seedKey, raw.value, raw.unit, {
            normalHigh: ref?.normal_high ?? null,
          })
        : { value: raw.value, unit: raw.unit, converted: false };
      const effectiveValue = conv.value;
      const effectiveUnit = conv.unit;

      // The canonical-unit gate processing applies (process-results.ts): a
      // value that convertBiomarker could not bring to the seed's unit is
      // refused there as unit_mismatch and never stored. Lp(a) in nmol/L is
      // the common case, as no fixed factor links it to mg/dL (check D4). The
      // preview shows such a value as reported, with no category and no
      // plausibility flag, since both would compare it with a range written
      // in another unit. A missing unit counts as the seed's, as in processing.
      const canonicalUnit = seedKey ? getCanonicalUnit(seedKey) : null;
      const unitRefused =
        seedKey !== null &&
        canonicalUnit !== null &&
        !validateCanonicalUnit(seedKey, effectiveUnit || canonicalUnit).ok;

      // The zone processing will store: a bound ("<5") is placed only where every value it allows has one zone
      // (bounded-result.ts classifyResultZone), never as the measured number. Every unit conversion above increases
      // with the value, so the comparator holds for the converted bound. A result printed "≤5" or "≥5" is
      // not stored, and one refused by the unit gate is not either: both are set aside, so neither gets a zone.
      const printedSign = raw.signToReview;
      // A laboratory's own eGFR is stored as a value only (lab-reported.ts), so the preview gives it no category.
      const zone: Zone | null = ref && !unitRefused && !printedSign
        ? isLabReportedValueOnly(seedKey)
          ? "unclassified"
          : classifyResultZone(effectiveValue, raw.comparator, ref.optimal_low, ref.optimal_high, ref.normal_low, ref.normal_high)
        : null;
      const zoneConf = zone ? ZONE_CONFIG[zone] : null;

      // Rule 1 (additional B) — plausibility guard. Gemini occasionally
      // OCRs "1.05" as "105" for things like creatinine. If we have a
      // reference normal range and the value is more than 10× the
      // range-width above normal_high or below normal_low, flag it for
      // explicit user confirmation. We don't reject — extreme values
      // are sometimes real — but we make the user tap a warning chip
      // before the row can be saved.
      let implausible = false;
      if (ref && !unitRefused && ref.normal_low != null && ref.normal_high != null) {
        const rangeWidth = ref.normal_high - ref.normal_low;
        if (rangeWidth > 0) {
          const aboveHigh = (effectiveValue - ref.normal_high) / rangeWidth;
          const belowLow = (ref.normal_low - effectiveValue) / rangeWidth;
          if (aboveHigh > 10 || belowLow > 10) {
            implausible = true;
          }
        }
      }

      // Localized display name from the seed in the user's profile
      // language, so a Spanish profile never sees an English title for
      // an auto-matched row. When the row didn't resolve to a seed key
      // matchedName stays null — the review UI then shows the raw lab
      // name (which is already in the report's language) rather than a
      // title-cased English slug like "Folate".
      const matchedName = ref
        ? profileLocale === "es"
          ? ref.name_es
          : ref.name_en
        : null;

      return {
        name: raw.name,
        value: effectiveValue,
        // "<" or ">" for a bound, with the bound in value; the review shows it and the client can correct it.
        comparator: raw.comparator,
        // "≤" or "≥" as printed: the result is set aside, and the review says so. It is not stored under another sign.
        signToReview: raw.signToReview,
        // True when processing will refuse the unit: the review shows the result as set aside, with the unit
        // EVA's ranges use.
        unitRefused,
        expectedUnit: unitRefused ? canonicalUnit : null,
        unit: effectiveUnit,
        referenceRange: raw.referenceRange,
        flag: raw.flag,
        matchedKey: resolvedKey,
        matchedName,
        matchConfidence,
        zone,
        zoneLabel: zoneConf?.label ?? null,
        zoneColor: zoneConf?.color ?? null,
        implausible,
      };
    });

    // If Gemini gave us a real collection date from the PDF, stamp it onto
    // the lab_result row right now so the dashboard already shows the
    // correct date. The user can still override it in the review step.
    if (extractedCollectionDate && extractedCollectionDate !== collectionDate) {
      const { error: dateUpdateError } = await supabase
        .from("lab_results")
        .update({ collection_date: extractedCollectionDate })
        .eq("id", labResultId);
      if (dateUpdateError) {
        console.error("[extract] Failed to stamp extracted collection_date:", dateUpdateError);
      }
    }

    // The upload counter is incremented ONLY at confirm time (one upload flow
    // = one credit). Incrementing here as well double-charged free users
    // (2 of their 5 credits per upload).

    logSetAside("upload-extract", { labResultId, userId: user.id }, unreadable);

    return NextResponse.json({
      extractedBiomarkers,
      // Results read from the report that have no readable number: named at review, with the reason.
      setAside: unreadable,
      unmatchedCount: extractedBiomarkers.filter((b) => !b.matchedKey).length,
      labResultId,
      // null when Gemini couldn't find a date in the PDF — the client
      // falls back to the existing default (today) for the picker.
      collectionDate: extractedCollectionDate,
    });
  } catch (e) {
    console.error("[extract] Unhandled error:", e);
    return NextResponse.json({ error: "Extraction failed" }, { status: 500 });
  }
}
