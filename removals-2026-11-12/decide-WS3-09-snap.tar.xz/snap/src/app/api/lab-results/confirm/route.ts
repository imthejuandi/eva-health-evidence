import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { processLabResults } from "@/lib/biomarkers/process-results";
import { recomputeAndCacheUserBA } from "@/lib/biomarkers/rolling-average-ba";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { snapshotToLab } from "@/lib/patient-context";
import { TransientContextSchema } from "@/lib/patient-context/schema";
import { logSetAside, screenSubmittedResults, setAsideFromProcessing } from "@/lib/lab-results/screen-results";
import type { SetAsideResult } from "@/lib/lab-results/set-aside";

// ─── Zod schema for request body ───
const ConfirmBodySchema = z.object({
  labResultId: z.string().uuid({ message: "labResultId must be a UUID" }),
  biomarkers: z
    .array(
      z.object({
        name: z.string().min(1),
        // The number, or the text as the report prints it, read by readReportedValue.
        value: z.union([z.number(), z.string()]).nullable(),
        // The sign printed before the value: "<" or ">" for a bound ("<5"), stored with it. A result the report
        // prints with "≤" or "≥" arrives with that sign and is set aside here, with a result that has no readable
        // number: neither is stored under another sign or as a plain number, and the rest of the report is
        // processed (decision D-24). The review cannot turn one sign into another.
        comparator: z.string().nullable().optional(),
        unit: z.string(),
        // Empty only for a result that is set aside before it is matched; a result that goes to processing with
        // no key fails the reference-list check below.
        biomarkerKey: z.string(),
        // Rule 1: how the row resolved to its canonical key. exact/alias
        // are auto-accepted at extract; fuzzy must have been confirmed
        // in the review UI; user is a manual selection from the
        // reference list. The server validates the value is one of these.
        matchConfidence: z.enum(["exact", "alias", "fuzzy", "user"]),
      })
    )
    .min(1, { message: "At least one biomarker is required" }),
  // Optional: override the auto-set collection date. Required to be
  // YYYY-MM-DD so it slots straight into the lab_results date column.
  collectionDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "collectionDate must be YYYY-MM-DD")
    .optional(),
  // Rule 4: the upload UI's context gate hands the chosen
  // patient_context_versions id + per-draw transient block down here
  // so /confirm can snapshot them onto lab_results before the AI
  // pipeline runs. Both are required from the upload flow; we accept
  // them as optional in the schema to keep the legacy admin
  // enter-results path compiling, but reject the request below if
  // they're missing.
  contextVersionId: z.string().uuid().optional(),
  transientContext: TransientContextSchema.optional(),
});

/** The status of a lab as extraction leaves it: the lab_results.status column's default (extract/route.ts sets none). */
const EXTRACTED_STATUS = "processing";

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  let labResultId: string | null = null;

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Validate request body with Zod
    const rawBody = await req.json().catch(() => null);
    const parseResult = ConfirmBodySchema.safeParse(rawBody);
    if (!parseResult.success) {
      return NextResponse.json(
        { error: "Invalid request body", details: parseResult.error.issues },
        { status: 400 }
      );
    }
    const {
      labResultId: lrId,
      biomarkers,
      collectionDate,
      contextVersionId,
      transientContext,
    } = parseResult.data;
    labResultId = lrId;

    // 1. Get profile and verify upload limit
    const profile = await getUserProfile(user.id);
    if (!profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    }

    // Require DOB and sex before processing
    if (!profile.date_of_birth || !profile.sex) {
      return NextResponse.json(
        { error: "Please complete your profile (date of birth and sex) before confirming lab results." },
        { status: 400 }
      );
    }

    const isSubscriber = profile.subscription_status === "active";
    const totalUsed = ((profile as unknown as Record<string, unknown>).total_uploads_used as number) ?? 0;
    if (!isSubscriber && totalUsed >= 5) {
      return NextResponse.json({ error: "Upload limit reached" }, { status: 403 });
    }

    // Verify lab_result belongs to user
    const { data: labResult, error: labError } = await supabase
      .from("lab_results")
      .select("id, user_id, status")
      .eq("id", labResultId)
      .eq("user_id", user.id)
      .single();

    if (labError || !labResult) {
      return NextResponse.json({ error: "Lab result not found" }, { status: 404 });
    }

    // Rule 1: every submitted biomarker_key MUST exist in
    // biomarker_references. The Zod schema enforces non-empty strings;
    // this enforces "matches a canonical key we actually have ranges
    // for". A row without a reference can't be zone-classified or
    // interpreted, so we reject the whole request — making the failure
    // mode obvious to the client rather than silently dropping rows.
    //
    // Before that, the results that cannot be used are set aside (decision D-24): each is named in the answer and
    // logged, and only the others go on. When none can be used the report ends here: nothing is stored, the lab
    // created at extraction is removed, and the answer is a 200 that names every result, not an error.
    //
    // The request names the lab, so only an empty one is removed: a lab still in the status extraction left it in
    // ("processing", the column's default) that holds no stored value. Any other lab the client owns (a ready one, one
    // with values) is left as it was, and so is the lab when the check cannot be made; the answer is the same.
    const screened = screenSubmittedResults(biomarkers);
    const setAside: SetAsideResult[] = [...screened.setAside];
    const statusBefore: unknown = (labResult as { status?: unknown }).status;
    let statusChanged = false;
    const removeIfEmpty = async () => {
      if (statusBefore !== EXTRACTED_STATUS) {
        console.warn(`[confirm] Lab ${lrId} not removed: its status is ${JSON.stringify(statusBefore)}, not the one extraction leaves`);
        if (statusChanged && typeof statusBefore === "string") {
          const { error: restoreError } = await supabase.from("lab_results").update({ status: statusBefore }).eq("id", lrId);
          if (restoreError) console.error("[confirm] Failed to restore the lab's status:", restoreError);
        }
        return;
      }
      const { data: stored, error: storedError } = await supabase
        .from("biomarker_values")
        .select("id")
        .eq("lab_result_id", lrId)
        .limit(1);
      if (storedError || !Array.isArray(stored)) {
        console.error(`[confirm] Lab ${lrId} not removed: its stored values could not be checked:`, storedError);
        return;
      }
      if (stored.length > 0) {
        console.warn(`[confirm] Lab ${lrId} not removed: it holds stored values`);
        return;
      }
      const { error: deleteError } = await supabase.from("lab_results").delete().eq("id", lrId);
      if (deleteError) console.error("[confirm] Failed to remove the empty lab:", deleteError);
    };
    const nothingUsable = async () => {
      logSetAside("upload-confirm", { labResultId: lrId, userId: user.id }, setAside);
      await removeIfEmpty();
      return NextResponse.json({
        labResultId: null,
        processed: 0,
        unmatched: 0,
        biologicalAge: null,
        calculatedMetrics: 0,
        nothingUsable: true,
        setAside,
      });
    };
    if (screened.usable.length === 0) return nothingUsable();

    const submittedKeys = Array.from(new Set(screened.usable.map((u) => u.entry.biomarkerKey)));
    const { data: knownRefs, error: refLookupError } = await supabase
      .from("biomarker_references")
      .select("biomarker_key")
      .in("biomarker_key", submittedKeys);
    if (refLookupError) {
      console.error("[confirm] biomarker_references lookup failed:", refLookupError);
      return NextResponse.json(
        { error: "Failed to validate biomarker keys" },
        { status: 500 }
      );
    }
    const knownSet = new Set((knownRefs ?? []).map((r) => r.biomarker_key));
    const unknownKeys = submittedKeys.filter((k) => !knownSet.has(k));
    if (unknownKeys.length > 0) {
      return NextResponse.json(
        {
          error: "One or more biomarker keys are not in the reference list",
          unknownKeys,
        },
        { status: 422 }
      );
    }

    // 2. Update status to processing. Also stamp the user-confirmed
    //    collection_date if supplied, so historical trends reflect the
    //    actual date the sample was drawn rather than today's upload date.
    const updatePayload: Record<string, string> = {
      status: "processing",
      source: "user_upload",
      panel_type: "uploaded",
    };
    if (collectionDate) {
      updatePayload.collection_date = collectionDate;
    }
    const { error: statusError } = await supabase
      .from("lab_results")
      .update(updatePayload)
      .eq("id", labResultId);

    if (statusError) {
      console.error("[confirm] Failed to set processing status:", statusError);
      // Non-fatal, continue
    } else {
      statusChanged = true;
    }

    // Rule 4: snapshot the user's chosen patient_context_versions row +
    // the per-draw transient block onto the lab BEFORE the pipeline
    // runs. The AI prompt (Rule 2, separate PR) reads them from
    // lab_results.patient_context_version_id, and so does the biological
    // age, whose creatine adjustment takes the dose from that version
    // (processLabResults → loadLabState): a version declared at this
    // gate is newer than the lab, so it reaches the figures only once it is
    // recorded on the lab.
    if (contextVersionId) {
      // Verify the version belongs to the caller. RLS prevents another
      // user's id from leaking through, but an explicit 404 is clearer.
      const { data: version, error: versionError } = await supabase
        .from("patient_context_versions")
        .select("id")
        .eq("id", contextVersionId)
        .eq("user_id", user.id)
        .maybeSingle();
      if (versionError || !version) {
        return NextResponse.json(
          { error: "Patient context version not found" },
          { status: 404 },
        );
      }
      try {
        await snapshotToLab(labResultId, contextVersionId, transientContext ?? {});
      } catch (snapErr) {
        console.error("[confirm] Failed to snapshot context:", snapErr);
        return NextResponse.json(
          { error: "Failed to save patient context" },
          { status: 500 },
        );
      }
    }

    // 3. Process biomarkers — pass biomarkerKey + matchConfidence so the
    //    user's manual selection is respected and the audit trail records
    //    how confident the match was. A bound keeps its comparator, so the
    //    pipeline classifies it as a bound (bounded-result.ts
    //    classifyResultZone), never as the measured number.
    const result = await processLabResults(
      user.id,
      labResultId,
      screened.usable.map(({ entry: b, value, comparator }) => ({
        name: b.name,
        value,
        unit: b.unit,
        ...(comparator ? { comparator } : {}),
        biomarkerKey: b.biomarkerKey,
        matchConfidence: b.matchConfidence,
      }))
    );

    // A result the canonical-unit gate refused (Lp(a) in nmol/L) is set aside too. When nothing was stored, the
    // report ends as above: no summary, no "ready", no upload counted, no email, and no error.
    setAside.push(...setAsideFromProcessing(result.unmatched));
    if (result.processed.length === 0) return nothingUsable();
    logSetAside("upload-confirm", { labResultId, userId: user.id }, setAside);

    // 4. Generate AI summary + action steps
    const wearable = await getWearableData(user.id, 30);
    await generateSummary(
      user.id,
      labResultId,
      result.processed,
      wearable.length > 0 ? wearable : null,
      profile,
    );

    // 5. Update status to ready
    const { error: readyError } = await supabase
      .from("lab_results")
      .update({ status: "ready" })
      .eq("id", labResultId);

    if (readyError) {
      console.error("[confirm] Failed to set ready status:", readyError);
    } else {
      // 5b. The dashboard's rolling average reads only ready labs: processing
      //     cached it without this one, so it is refreshed now. Best-effort.
      await recomputeAndCacheUserBA(user.id, supabase).catch((err) =>
        console.error("[confirm] recomputeAndCacheUserBA failed:", err),
      );
    }

    // 6. Increment upload count
    const { error: counterError } = await supabase
      .from("profiles")
      .update({ total_uploads_used: totalUsed + 1 })
      .eq("id", user.id);

    if (counterError) {
      console.error("[confirm] Failed to increment upload counter:", counterError);
    }

    // 7. Send results-ready email (fire-and-forget)
    const firstName = profile.full_name?.split(" ")[0] ?? "";
    const locale = profile.locale ?? "en";
    sendEmail(
      user.email ?? "",
      "results-ready",
      {
        firstName,
        biomarkerCount: result.processed.length,
        biologicalAge: result.biologicalAge?.biologicalAge ?? null,
        baDelta: result.biologicalAge?.delta ?? null,
        longevityScore: result.biologicalAge?.longevityScore ?? null,
        locale,
      },
      locale
    ).catch((err) => {
      console.error("[confirm] Email send failed:", err);
    });

    // 8. Return result
    return NextResponse.json({
      labResultId,
      processed: result.processed.length,
      unmatched: result.unmatched.length,
      biologicalAge: result.biologicalAge,
      calculatedMetrics: result.calculatedMetrics.length,
      // Each result that was not used, with its reason code: the upload screen shows the sentence of
      // wording-rules.md section 7 for it, in the client's language.
      setAside,
    });
  } catch (e) {
    console.error("[confirm] Error:", e);

    // Revert status to "error" so the UI can distinguish failure from in-progress
    if (labResultId) {
      const { error: revertError } = await supabase
        .from("lab_results")
        .update({ status: "error" })
        .eq("id", labResultId);

      if (revertError) {
        console.error("[confirm] Failed to revert status to error:", revertError);
      }
    }

    const message = e instanceof Error ? e.message : "Failed to process";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
