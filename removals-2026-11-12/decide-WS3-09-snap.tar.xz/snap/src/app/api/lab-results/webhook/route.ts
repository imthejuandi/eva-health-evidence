import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { getProvider } from "@/lib/lab-provider";
import { processLabResults } from "@/lib/biomarkers/process-results";
import { getUserProfile } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { logSetAside, setAsideFromProcessing } from "@/lib/lab-results/screen-results";
import { setAsideSentence, type SetAsideResult } from "@/lib/lab-results/set-aside";

/** A set-aside result as the sender gets it back: its name, the reason code, and the reason in both languages. */
function forSender(items: SetAsideResult[]) {
  return items.map((i) => ({
    name: i.name,
    reason: i.reason,
    printed: i.printed,
    message: { en: setAsideSentence(i, "en"), es: setAsideSentence(i, "es") },
  }));
}

/** The answer when no result of the payload could be used: nothing is stored, and each result is named. */
function nothingUsable(setAside: SetAsideResult[]) {
  return NextResponse.json(
    { error: "No result in the payload could be used", status: "nothing_usable", processed: 0, setAside: forSender(setAside) },
    { status: 422 },
  );
}

/**
 * Lab partner webhook.
 *
 * Rule 4 changes this from a one-shot
 *
 *   "ingest → process → AI-interpret → email"
 *
 * pipeline to a two-step gate:
 *
 *   1. Now: ingest the panel, insert biomarker_values + zone classify
 *      (no AI), set status = pending_context, email the user a deep
 *      link to /labs/[id]/context.
 *
 *   2. Later, when the user lands on /labs/[id]/context and confirms
 *      or updates their durable context: POST
 *      /api/lab-results/[id]/context flips status to processing, runs
 *      generateSummary, transitions to ready, and sends the original
 *      "results-ready" email.
 *
 * This guarantees the AI interpretation always reads context that the
 * user has affirmatively confirmed for this draw — no silent "we used
 * the context from 4 months ago" because they never visited the app.
 *
 * A separate 72-hour cron auto-resolves pending_context labs the user
 * never returned to, using their last-saved durable context with
 * transient.skipped = true and a banner on the result.
 *
 * SEC-019 (fixed): an inbound webhook carries no user session, so every
 * write here MUST use the service-role client — and that client must be
 * threaded into processLabResults/getUserProfile, whose fallback is the
 * cookie-bound anon client that RLS would silently block.
 *
 * Order-based providers (Echevarne, spec v2.8) identify the result by
 * placer order number, not by an eva user id embedded in the message.
 * Matching a placer to a user requires the test_cycles table (carril C
 * of the plan); until it lands, only userId-bearing providers (manual)
 * can be ingested here and order-based payloads get a clear 501.
 *
 * A result that cannot be used (printed with "≤" or "≥", no readable number,
 * a unit the canonical-unit gate refuses, a name matched to no marker) is set
 * aside, logged and returned with its reason, and the rest of the payload is
 * processed (decision D-24). Only a payload with no usable result at all is
 * answered 422, naming each result, and leaves no lab behind.
 */
export async function POST(req: NextRequest) {
  try {
    const providerName = req.headers.get("x-provider") ?? req.headers.get("x-lab-provider");
    if (!providerName) {
      return NextResponse.json({ error: "Missing X-Provider header" }, { status: 400 });
    }

    let provider;
    try {
      provider = getProvider(providerName);
    } catch {
      return NextResponse.json({ error: `Unknown provider: ${providerName}` }, { status: 400 });
    }

    // SEC-008 — verification is mandatory for every provider. A request that
    // cannot be verified (bad/missing signature or unset secret) is rejected;
    // we never trust the client-named provider + payload on their own.
    const body = await req.text();
    const headers: Record<string, string> = {};
    req.headers.forEach((v, k) => { headers[k] = v; });

    if (!provider.verifyWebhook(headers, body)) {
      return NextResponse.json({ error: "Invalid webhook signature" }, { status: 401 });
    }

    // HL7 payloads are raw pipe-delimited text — JSON.parse would throw on
    // them. Only JSON-format providers go through JSON.parse.
    let payload: unknown = body;
    if ((provider.payloadFormat ?? "json") === "json") {
      try {
        payload = JSON.parse(body);
      } catch {
        return NextResponse.json({ error: "Invalid JSON payload" }, { status: 400 });
      }
    }

    let labProviderResult;
    try {
      labProviderResult = provider.parseResults(payload);
    } catch (e) {
      console.error(`[lab-webhook] ${providerName} payload failed to parse:`, e);
      return NextResponse.json({ error: "Unparseable payload" }, { status: 422 });
    }

    const supabase = createAdminClient();
    if (!supabase) {
      // Without the service role every insert below is RLS-blocked; better a
      // loud 503 (provider retries) than silent data loss.
      console.error("[lab-webhook] SUPABASE_SERVICE_ROLE_KEY not configured");
      return NextResponse.json({ error: "Ingestion not configured" }, { status: 503 });
    }

    const userId = labProviderResult.userId;
    if (!userId) {
      // Order-based result (placer order number instead of a user id).
      console.error(
        `[lab-webhook] ${providerName} result has no userId ` +
          `(placer=${labProviderResult.placerOrderNumber ?? "?"}). ` +
          "Cycle matching requires test_cycles (pending, carril C).",
      );
      return NextResponse.json(
        { error: "Order-based matching not yet available" },
        { status: 501 },
      );
    }

    // Results the provider set aside while reading the payload (decision D-24). With nothing left to process, no lab
    // is created.
    const setAside: SetAsideResult[] = [...(labProviderResult.setAside ?? [])];
    if (labProviderResult.biomarkers.length === 0) {
      logSetAside(`lab-webhook:${providerName}`, { userId }, setAside);
      return nothingUsable(setAside);
    }

    // Create lab_results in pending_context. Biomarker values land in
    // the same call below; the AI interpretation waits for the user.
    // (Raw-payload archival moves to the lab_messages table — F2.)
    const { data: labResult, error: labInsertError } = await supabase
      .from("lab_results")
      .insert({
        user_id: userId,
        source: providerName,
        panel_type: "lab_partner",
        status: "pending_context",
        collection_date: labProviderResult.collectionDate,
        strengths: [],
        needs_attention: [],
      })
      .select("id")
      .single();

    if (labInsertError || !labResult) {
      console.error("[lab-webhook] lab_results insert failed:", labInsertError);
      return NextResponse.json({ error: "Failed to create lab result" }, { status: 500 });
    }

    // Resolve provider codes to eva keys and process. Resolved keys are passed
    // as biomarkerKey (exact) so processLabResults doesn't re-run fuzzy name
    // matching on an already-mapped code; unmapped codes fall through with the
    // raw name so they are skipped + logged rather than crashing.
    // A bounded result ("<0,500") keeps its comparator, so the pipeline classifies it as a bound
    // (bounded-result.ts classifyResultZone), never as the measured number.
    const mappedBiomarkers = labProviderResult.biomarkers.map((b) => {
      const key = provider.mapBiomarkerName(b.biomarker_key, b.loincCode);
      const comparator = b.comparator ? { comparator: b.comparator } : {};
      return key
        ? { name: key, biomarkerKey: key, matchConfidence: "exact" as const, value: b.value, unit: b.unit, ...comparator }
        : { name: b.biomarker_key, value: b.value, unit: b.unit, ...comparator };
    });

    const result = await processLabResults(userId, labResult.id, mappedBiomarkers, supabase);

    // What processing did not store joins the results set aside at reading: each is logged for operations and
    // returned to the sender. When nothing was stored, the empty lab is removed and the client is not emailed.
    setAside.push(...setAsideFromProcessing(result.unmatched));
    logSetAside(`lab-webhook:${providerName}`, { labResultId: labResult.id, userId }, setAside);
    if (result.processed.length === 0) {
      const { error: deleteError } = await supabase.from("lab_results").delete().eq("id", labResult.id);
      if (deleteError) console.error("[lab-webhook] failed to remove the empty lab:", deleteError);
      return nothingUsable(setAside);
    }

    // Email the user. The deep link sends them straight to the
    // context-gate screen for this lab. No "results ready" mail goes
    // out until the AI interpretation has actually been generated.
    const profile = await getUserProfile(userId, supabase);
    if (profile?.email) {
      const firstName = profile.full_name?.split(" ")[0] ?? "";
      const locale = profile.locale ?? "en";
      const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://evahealth.es";
      const contextUrl = `${appUrl}/${locale}/labs/${labResult.id}/context`;
      sendEmail(
        profile.email,
        "context-needed",
        {
          firstName,
          biomarkerCount: result.processed.length,
          contextUrl,
          locale,
        },
        locale,
      ).catch((err) => {
        console.error("[lab-webhook] context-needed email failed:", err);
      });
    }

    return NextResponse.json({
      labResultId: labResult.id,
      status: "pending_context",
      processed: result.processed.length,
      setAside: forSender(setAside),
    });
  } catch (e) {
    console.error("[lab-webhook]", e);
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 });
  }
}
