import { NextRequest, NextResponse } from "next/server";
import { shownAsValueOnly } from "@/lib/biomarkers/lab-reported";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { completeCycleForLabResult } from "@/lib/cycles/close-cycle";
import { labNoteTexts } from "@/lib/lab-results/notes";
import { recomputeLabMetrics } from "@/lib/biomarkers/process-results";
import { TransientContextSchema } from "@/lib/patient-context/schema";
import { generateSummary } from "@/lib/ai/generate-summary";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { opsAlert } from "@/lib/ops-alert";

/**
 * POST /api/lab-results/[id]/context
 *
 * Confirm the context of a lab from EVA's laboratory that is waiting
 * for it (pending_context): claim the lab and stamp the
 * patient_context_versions row + per-draw transient context in one write
 * ("processing", only if it is still pending: the 72-hour cron claims it
 * the same way, so only one of them resolves it), run the AI pipeline,
 * mark it "ready", recompute its metrics under the context just
 * confirmed, and send the results-ready email. If anything fails, the lab
 * goes back to pending_context, where the client or the cron can try
 * again.
 *
 * A lab in any other status is refused (409): its figures were computed
 * under the context it already has, and a new one would not reach them.
 * The upload flow never calls this route; /confirm stamps its context.
 *
 * Body: { contextVersionId: uuid, transientContext: TransientContext }
 */

// Up to 120 seconds, as the 72-hour cron has: the AI summary runs inside this request. The AI step has no deadline of
// its own, so a request the platform stops after the claim still leaves the lab in "processing", which only a
// reprocess from /admin moves (audit item F37).
export const maxDuration = 120;

const BodySchema = z.object({
  contextVersionId: z.string().uuid(),
  transientContext: TransientContextSchema,
});

export async function POST(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> },
) {
  const { id: labResultId } = await ctx.params;
  if (!/^[0-9a-fA-F-]{36}$/.test(labResultId)) {
    return NextResponse.json({ error: "Invalid lab id" }, { status: 400 });
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const parsed = BodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid body", details: parsed.error.issues },
      { status: 400 },
    );
  }
  const { contextVersionId, transientContext } = parsed.data;

  // Lab must exist and belong to the caller.
  const { data: lab, error: labError } = await supabase
    .from("lab_results")
    .select("id, user_id, status, collection_date, lab_notes")
    .eq("id", labResultId)
    .eq("user_id", user.id)
    .single();
  if (labError || !lab) {
    return NextResponse.json({ error: "Lab not found" }, { status: 404 });
  }

  // Version must exist and belong to the caller. RLS enforces this too,
  // but a clearer 404 here saves the client a guess.
  const { data: version, error: versionError } = await supabase
    .from("patient_context_versions")
    .select("id, user_id")
    .eq("id", contextVersionId)
    .eq("user_id", user.id)
    .maybeSingle();
  if (versionError || !version) {
    return NextResponse.json(
      { error: "Patient context version not found" },
      { status: 404 },
    );
  }

  const notWaiting = NextResponse.json(
    { error: "This lab is no longer waiting for its context. Reload the page to see it.", status: lab.status },
    { status: 409 },
  );
  if (lab.status !== "pending_context") return notWaiting;

  // Claim the lab and stamp its context in one write: pending_context → processing, only if it is still pending.
  const { data: claimed, error: toProcessingError } = await supabase
    .from("lab_results")
    .update({ status: "processing", patient_context_version_id: contextVersionId, transient_context: transientContext })
    .eq("id", labResultId)
    .eq("status", "pending_context")
    .select("id");
  if (toProcessingError) {
    console.error("[lab.context.POST] transition to processing failed:", toProcessingError);
    return NextResponse.json(
      { error: "Failed to start processing" },
      { status: 500 },
    );
  }
  if (!claimed || claimed.length === 0) return notWaiting;

  // Back to pending_context after a failure, so the client or the cron can try again. The alert says whether the lab
  // really went back: if not, it stays in processing until reprocessed from /admin.
  const release = async (scope: string, err: unknown) => {
    const { data: released, error: releaseError } = await supabase
      .from("lab_results")
      .update({ status: "pending_context" })
      .eq("id", labResultId)
      .eq("status", "processing")
      .select("id");
    const back = !releaseError && (released?.length ?? 0) > 0;
    opsAlert(
      "lab.context.POST",
      back ? `${scope} failed — lab back to pending_context` : `${scope} failed — lab left in processing: reprocess it from /admin`,
      {
        labId: labResultId,
        error: err instanceof Error ? err.message : String(err),
        ...(releaseError ? { releaseError: releaseError.message } : {}),
      },
    );
  };

  try {
    const profile = await getUserProfile(user.id);
    if (!profile) {
      throw new Error("Profile not found");
    }
    // Webhook flow: biomarker_values were already inserted by the
    // webhook handler when the lab arrived. processLabResults is
    // idempotent enough only if biomarker rows aren't re-inserted —
    // we skip it here and go straight to the AI step. (For webhook
    // labs we re-derive the processed biomarker list from the rows.)
    const { data: bvRows, error: bvError } = await supabase
      .from("biomarker_values")
      .select("biomarker_key, biomarker_name, value, unit, zone, optimal_low, optimal_high")
      .eq("lab_result_id", labResultId);
    if (bvError) throw new Error(`Failed to load biomarker_values: ${bvError.message}`);
    if (!bvRows || bvRows.length === 0) {
      throw new Error("No biomarker values to interpret on this lab");
    }

    // A laboratory's own eGFR goes to the interpretation as a value only: no category, no interval (lab-reported.ts).
    const processed = bvRows.map(shownAsValueOnly).map((b) => ({
      biomarkerKey: b.biomarker_key,
      name: b.biomarker_name ?? b.biomarker_key,
      value: b.value as number,
      unit: b.unit ?? "",
      zone: (b.zone ?? "unclassified") as
        | "critical_low"
        | "below_optimal"
        | "optimal"
        | "above_optimal"
        | "critical_high"
        | "unclassified",
      zoneLabel: "",
      zoneLabel_es: "",
      optimalLow: (b.optimal_low ?? null) as number | null,
      optimalHigh: (b.optimal_high ?? null) as number | null,
      matchConfidence: "exact" as const,
    }));

    const wearable = await getWearableData(user.id, 30);
    await generateSummary(
      user.id,
      labResultId,
      processed,
      wearable.length > 0 ? wearable : null,
      profile,
      undefined,
      { labNotes: labNoteTexts((lab as { lab_notes?: unknown }).lab_notes) },
    );

    // A lab that cannot be marked ready is a failure like any other: it goes back to pending_context and no email
    // says its results are ready.
    const { error: readyError } = await supabase
      .from("lab_results")
      .update({ status: "ready" })
      .eq("id", labResultId);
    if (readyError) throw new Error(`set ready failed: ${readyError.message}`);

    // The lab was processed on arrival, before this context existed: its
    // biological age (both KDM figures and version 3) is recomputed under
    // the context just confirmed, whose creatine dose adjusts creatinine,
    // and the dashboard's rolling average now includes it (it reads only
    // ready labs). Best-effort: if it fails, the lab keeps its figures from
    // arrival, and the dashboard is refreshed with the lab in it anyway.
    await recomputeLabMetrics(user.id, labResultId, supabase).catch((err) =>
      opsAlert("lab.context.POST", "lab ready but its metrics could not be recomputed", {
        labId: labResultId,
        error: err instanceof Error ? err.message : String(err),
      }),
    );
    // The cycle that produced this result is done (results_final →
    // completed). The patient's session cannot write test_cycles (RLS
    // grants SELECT only), so this goes through the service-role client;
    // the bridge pass and the daily scheduler sweep any miss.
    const admin = createAdminClient();
    if (admin) {
      await completeCycleForLabResult(admin, labResultId).catch((err) =>
        console.error("[lab.context.POST] cycle completion failed:", err),
      );
    }

    // Now (and only now) tell the user their results are ready.
    const firstName = profile.full_name?.split(" ")[0] ?? "";
    const locale = profile.locale ?? "en";
    sendEmail(
      user.email ?? "",
      "results-ready",
      {
        firstName,
        biomarkerCount: processed.length,
        biologicalAge: null,
        baDelta: null,
        longevityScore: null,
        locale,
      },
      locale,
    ).catch((err) => console.error("[lab.context.POST] email failed:", err));

    return NextResponse.json({ ok: true, ran_pipeline: true });
  } catch (err) {
    console.error("[lab.context.POST] pipeline failed:", err);
    await release("pipeline", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Pipeline failed" },
      { status: 500 },
    );
  }
}

