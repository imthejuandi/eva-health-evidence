import { NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { GoogleGenAI } from "@google/genai";
import { getUserProfile, getLatestLabResult, getBiomarkerValues, getWearableData, getActionSteps } from "@/lib/queries";
import { calculateAge } from "@/lib/biomarkers/zone-classifier";
import { hasPaidAccess } from "@/lib/stripe/helpers";
import { getPrompt } from "@/lib/ai/prompts";
import { chatBioAgeLine } from "@/lib/biomarkers/bio-age-flags";

async function buildEvaContext(userId: string): Promise<string> {
  const [profile, latestLab, wearable, actionSteps] = await Promise.all([
    getUserProfile(userId),
    getLatestLabResult(userId),
    getWearableData(userId, 30),
    getActionSteps(userId),
  ]);

  const biomarkers = latestLab ? await getBiomarkerValues(latestLab.id) : [];

  const sections: string[] = [];

  // User profile
  if (profile) {
    const age = profile.date_of_birth ? calculateAge(profile.date_of_birth) : "unknown";
    sections.push(`## USER PROFILE
Name: ${profile.full_name ?? "Unknown"}
Age: ${age}
Sex: ${profile.sex ?? "unknown"}
Health Knowledge: ${profile.health_knowledge ?? "beginner"}
Preferred Language: ${profile.locale ?? "en"}
Subscription: ${profile.subscription_status}`);
  }

  // Latest results
  if (latestLab) {
    const bioList = biomarkers
      .map((b) => `  - ${b.biomarker_name ?? b.biomarker_key}: ${b.value} ${b.unit} [${b.zone}] (optimal: ${b.optimal_low ?? "n/a"} to ${b.optimal_high ?? "n/a"})`)
      .join("\n");

    sections.push(`## LATEST LAB RESULTS (${latestLab.collection_date})
${chatBioAgeLine(latestLab.biological_age) /* BIO_AGE_KDM_VISIBLE off (default): no figure */}
Longevity Score: ${latestLab.longevity_score ?? "not calculated"}/100
Summary: ${latestLab.summary_narrative ?? "none"}

Biomarkers:
${bioList}`);
  } else {
    sections.push("## LATEST LAB RESULTS\nNo lab results uploaded yet.");
  }

  // Wearable data
  if (wearable.length > 0) {
    const avg = (arr: (number | null)[]) => {
      const valid = arr.filter((v): v is number => v != null);
      return valid.length > 0 ? Math.round((valid.reduce((a, b) => a + b, 0) / valid.length) * 10) / 10 : "no data";
    };
    sections.push(`## WEARABLE DATA (30-day averages)
HRV: ${avg(wearable.map((w) => w.hrv_ms))} ms
Resting HR: ${avg(wearable.map((w) => w.resting_hr_bpm))} bpm
Sleep: ${avg(wearable.map((w) => w.sleep_hours))} hours
Respiratory Rate: ${avg(wearable.map((w) => w.respiratory_rate))} brpm
Steps: ${avg(wearable.map((w) => w.steps))}
Days of data: ${wearable.length}`);
  } else {
    sections.push("## WEARABLE DATA\nNo wearable data connected.");
  }

  // Action steps
  if (actionSteps.length > 0) {
    const stepList = actionSteps
      .map((s, i) => `  ${i + 1}. [${s.category}] ${s.title}: ${s.description}`)
      .join("\n");
    sections.push(`## ACTIVE ACTION STEPS\n${stepList}`);
  }

  return sections.join("\n\n");
}

export async function POST(req: NextRequest) {
  const geminiKey = process.env.GEMINI_API_KEY;
  if (!geminiKey) {
    return new Response(JSON.stringify({ error: "Server misconfigured: AI service unavailable" }), { status: 503 });
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
  }

  // EVA AI chat is a paid-only feature. Active quarterly subscribers
  // and Full Panel buyers qualify. Free users get 402 Payment Required;
  // the client surfaces a paywall with a Subscribe CTA.
  const { data: paidProfile } = await supabase
    .from("profiles")
    .select("subscription_status, subscription_period_end, full_panel_purchased_at")
    .eq("id", user.id)
    .single();
  if (!hasPaidAccess(paidProfile)) {
    return new Response(
      JSON.stringify({ error: "Subscription required", code: "paid_only" }),
      { status: 402 },
    );
  }

  const { message } = await req.json() as { message: string };
  if (!message?.trim()) {
    return new Response(JSON.stringify({ error: "Empty message" }), { status: 400 });
  }

  // Save user message
  const { error: userMsgError } = await supabase.from("chat_messages").insert({
    user_id: user.id,
    role: "user",
    content: message,
  });

  if (userMsgError) {
    console.error("[chat] Failed to save user message:", userMsgError);
    return new Response(JSON.stringify({ error: "Failed to save message" }), { status: 500 });
  }

  // Fetch last 10 messages for conversation history
  const { data: history } = await supabase
    .from("chat_messages")
    .select("role, content")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(10);

  // Convert to Gemini format: "user" | "model" (not "assistant")
  const contents = (history ?? [])
    .reverse()
    .map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));

  // Build context + load prompt config from DB
  const [context, prompt] = await Promise.all([
    buildEvaContext(user.id),
    getPrompt("eva_chat_system"),
  ]);

  // Stream response from Gemini
  const genai = new GoogleGenAI({ apiKey: geminiKey });

  const encoder = new TextEncoder();
  let fullResponse = "";

  const readable = new ReadableStream({
    async start(controller) {
      try {
        const stream = await genai.models.generateContentStream({
          model: prompt.model,
          contents,
          config: {
            systemInstruction: `${prompt.content}\n\n---\n\n${context}`,
            ...(prompt.temperature != null && { temperature: prompt.temperature }),
            ...(prompt.maxOutputTokens != null && { maxOutputTokens: prompt.maxOutputTokens }),
            ...(prompt.thinkingBudget != null && { thinkingConfig: { thinkingBudget: prompt.thinkingBudget } }),
          },
        });

        for await (const chunk of stream) {
          const text = chunk.text ?? "";
          if (text) {
            fullResponse += text;
            controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text })}\n\n`));
          }
        }

        // Save assistant message after streaming completes
        const { error: saveError } = await supabase.from("chat_messages").insert({
          user_id: user.id,
          role: "assistant",
          content: fullResponse,
        });

        if (saveError) {
          console.error("[chat] Failed to save assistant message:", saveError);
        }

        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      } catch (e) {
        console.error("[chat] Stream error:", e);
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: "Stream failed" })}\n\n`));
        controller.close();
      }
    },
  });

  return new Response(readable, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
