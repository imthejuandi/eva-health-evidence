import { NextRequest, NextResponse } from "next/server";
import { isLabReportedValueOnly } from "@/lib/biomarkers/lab-reported";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { calculateAge } from "@/lib/biomarkers/zone-classifier";
import { classifyResultZone } from "@/lib/biomarkers/bounded-result";
import { convertBiomarker } from "@/lib/biomarkers/unit-conversions";
import { remapToSeedKey } from "@/lib/biomarkers/key-aliases";
import { referenceRowFor } from "@/lib/biomarkers/reference-row";
import { getCanonicalUnit, validateCanonicalUnit } from "@/lib/biomarkers/canonical-units";
import { regenerateMasterForLab } from "@/lib/ai/regenerate-master";
import { getUserProfile } from "@/lib/queries";

// AI regen runs synchronously — master Gemini call + per-biomarker DB
// writes + tier rephrase + per-biomarker DB writes. On a 40-biomarker
// panel that comfortably exceeds Vercel's default 10s function budget,
// which used to kill the previous `after()` regen mid-flight (the
// "edit didn't reinterpret" bug). 60s leaves headroom; if a panel ever
// needs more, the right answer is to chunk the Gemini calls, not raise
// this further.
export const maxDuration = 60;

/**
 * PATCH /api/biomarker-values/[id]
 *
 * Manually correct a single historical biomarker value. The user chose
 * which row to edit, so we don't touch any siblings. Flow:
 *   1. Verify the row exists and belongs to the user (RLS handles this).
 *   2. Apply unit conversion to the new value/unit (same pipeline as
 *      processLabResults) so the stored value is in the canonical unit.
 *   3. Re-fetch the reference range for the row's biomarker_key + user's
 *      sex + age-at-collection and re-classify the zone.
 *   4. Update the row in place. RLS allows the user to update their own
 *      biomarker_values, so no admin client needed.
 *   5. Synchronously regenerate the master AI interpretation + tier
 *      rephrase so the dashboard refresh after this response shows the
 *      coherent post-edit narrative. The previous fire-and-forget
 *      `after()` approach lost the race against the client's
 *      router.refresh(): the dashboard re-rendered against the stale
 *      summary while Gemini was still mid-call, and the user never
 *      saw the new interpretation.
 *
 * Body: { value: number, unit?: string, comparator?: "<" | ">" | null }
 *
 * A result the laboratory reported as a bound ("<0,500") is stored as the bound with its comparator. The edit keeps
 * the stored comparator unless the body sets one ("<" or ">") or clears it (null, a measured value), and the zone is
 * that of the result with its comparator (bounded-result.ts classifyResultZone), never of the bound as a measured
 * number.
 */

const BodySchema = z.object({
  value: z.number().finite(),
  unit: z.string().optional(),
  comparator: z.enum(["<", ">"]).nullable().optional(),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;

  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const parsed = BodySchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }
    const { value: newValue, unit: maybeUnit, comparator: maybeComparator } = parsed.data;

    // 1. Load the existing row (RLS enforces ownership via lab_results join)
    const { data: row, error: rowError } = await supabase
      .from("biomarker_values")
      .select("*, lab_results!inner(user_id, collection_date)")
      .eq("id", id)
      .single();

    if (rowError || !row) {
      return NextResponse.json({ error: "Biomarker value not found" }, { status: 404 });
    }
    if (row.lab_results.user_id !== user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // 2. Load the user profile for sex + age at collection time
    const { data: profile } = await supabase
      .from("profiles")
      .select("date_of_birth, sex")
      .eq("id", user.id)
      .single();

    if (!profile?.date_of_birth || !profile?.sex) {
      return NextResponse.json(
        { error: "Profile incomplete: date_of_birth and sex are required" },
        { status: 400 },
      );
    }

    const age = calculateAge(profile.date_of_birth);
    if (!Number.isFinite(age)) {
      return NextResponse.json({ error: "Invalid date_of_birth" }, { status: 400 });
    }
    const sex = (profile.sex as string).toLowerCase();

    // 3. Apply unit conversion and key remap (same as processLabResults).
    //    The row's biomarker_key is already in seed-slug form from the last
    //    pipeline run, but we remap again in case the CBC %/absolute choice
    //    changes with a new unit.
    const effectiveUnit = maybeUnit ?? row.unit;
    const remappedKey = remapToSeedKey(row.biomarker_key, effectiveUnit);
    const conv = convertBiomarker(remappedKey, newValue, effectiveUnit);

    // 3a. Canonical unit gate. Reject the edit if the supplied unit can't
    //     be matched to the seed's canonical unit for this biomarker.
    //     Same logic as the upload pipeline — keeps manual edits from
    //     introducing wrong-unit data.
    const canonical = getCanonicalUnit(remappedKey);
    if (canonical !== null) {
      const validation = validateCanonicalUnit(remappedKey, conv.unit);
      if (!validation.ok) {
        return NextResponse.json(
          {
            error:
              `Unit "${effectiveUnit}" is not compatible with this biomarker. ` +
              `Expected "${canonical}". Please supply a value in the canonical ` +
              `unit or one we know how to convert.`,
            expectedUnit: canonical,
            suppliedUnit: effectiveUnit,
          },
          { status: 400 },
        );
      }
    }

    // 4. Fetch references for the remapped key and pick the row that matches
    //    this user's sex + age (the rule processLabResults uses, reference-row.ts).
    const { data: refs } = await supabase
      .from("biomarker_references")
      .select("biomarker_key, sex, age_group_en, optimal_low, optimal_high, normal_low, normal_high")
      .eq("biomarker_key", remappedKey)
      .in("sex", [sex, "both"]);

    let ref:
      | {
          optimal_low: number | null;
          optimal_high: number | null;
          normal_low: number | null;
          normal_high: number | null;
        }
      | null = null;

    // A laboratory's own eGFR stays a value only when it is corrected: no category and no interval from the eGFR
    // rows, which describe the eGFR EVA computes (lab-reported.ts).
    if (refs && refs.length > 0 && !isLabReportedValueOnly(remappedKey)) {
      const picked = referenceRowFor(refs, sex, age).row;
      if (picked) {
        ref = {
          optimal_low: picked.optimal_low,
          optimal_high: picked.optimal_high,
          normal_low: picked.normal_low,
          normal_high: picked.normal_high,
        };
      }
    }

    // The comparator the stored row carries, unless the body sets or clears it.
    const storedComparator: "<" | ">" | null = row.comparator === "<" || row.comparator === ">" ? row.comparator : null;
    const comparator = maybeComparator === undefined ? storedComparator : maybeComparator;
    const zone = ref
      ? classifyResultZone(conv.value, comparator, ref.optimal_low, ref.optimal_high, ref.normal_low, ref.normal_high)
      : "unclassified";

    // 5. Update the row
    const { data: updated, error: updateError } = await supabase
      .from("biomarker_values")
      .update({
        biomarker_key: remappedKey,
        value: conv.value,
        unit: conv.unit,
        comparator,
        zone,
        optimal_low: ref?.optimal_low ?? null,
        optimal_high: ref?.optimal_high ?? null,
        normal_low: ref?.normal_low ?? null,
        normal_high: ref?.normal_high ?? null,
      })
      .eq("id", id)
      .select()
      .single();

    if (updateError) {
      return NextResponse.json(
        { error: `Update failed: ${updateError.message}` },
        { status: 500 },
      );
    }

    // Synchronously regenerate the master AI interpretation + tier
    // rephrase for the parent lab. Sharing the helper with
    // /api/lab-results/regenerate-summary keeps the two regen paths
    // in lockstep. The caller (detail-client / manage-client) does a
    // router.refresh() on the PATCH response, so by the time the
    // dashboard re-renders the new narrative + zone counts are
    // already persisted.
    const fullProfile = await getUserProfile(user.id);
    const regen = fullProfile
      ? await regenerateMasterForLab(row.lab_result_id, user.id, {
          force: true,
          profile: fullProfile,
          supabase,
        }).catch((err) => {
          // Don't fail the edit just because the AI step had a hiccup —
          // the value update itself already succeeded above. Surface
          // the failure to the client so the UI can decide whether to
          // nudge the user to retry the interpretation.
          console.error(
            `[biomarker-values PATCH] regen failed for lab=${row.lab_result_id}:`,
            err,
          );
          return null;
        })
      : null;

    return NextResponse.json({
      success: true,
      value: updated,
      converted: conv.converted,
      conversionNote: conv.note ?? null,
      regenerated: regen?.ok === true,
    });
  } catch (e) {
    console.error("[biomarker-values PATCH] Error:", e);
    const message = e instanceof Error ? e.message : "Update failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
