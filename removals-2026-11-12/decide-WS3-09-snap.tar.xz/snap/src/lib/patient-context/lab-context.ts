/**
 * The patient context a lab result is read under, one rule for every biological age figure: processing
 * (process-results.ts), the dashboard's rolling average (rolling-average-ba.ts) and version 3
 * (biological-age-v3-adapter.ts).
 *
 *   1. The version recorded with the lab (`lab_results.patient_context_version_id`).
 *   2. Else, or when that version no longer exists, the client's latest version created on or before the lab was:
 *      results entered before contexts existed, or read before the client confirmed one.
 *
 * So a context declared later never changes an earlier result. No server imports: the callers pass their client.
 */
import type { SupabaseClient } from "@supabase/supabase-js";

/** What the rule needs of a lab result. */
export interface LabContextRef {
  patient_context_version_id?: string | null;
  created_at?: string | null;
}

/** What the rule needs of a context version. */
export interface ContextVersionRef {
  id: string;
  version_number: number;
  created_at: string;
}

/**
 * The version a lab result reads, among the client's versions (in any order); null when none applies. A lab
 * without a creation time takes the latest version.
 */
export function contextVersionForLab<V extends ContextVersionRef>(lab: LabContextRef, versions: readonly V[]): V | null {
  const recordedId = lab.patient_context_version_id;
  const recorded = recordedId ? versions.find((v) => v.id === recordedId) : undefined;
  if (recorded) return recorded;
  const cutoff = lab.created_at ? Date.parse(lab.created_at) : NaN;
  let latest: V | null = null;
  for (const v of versions) {
    if (Number.isFinite(cutoff) && !(Date.parse(v.created_at) <= cutoff)) continue;
    if (!latest || v.version_number > latest.version_number) latest = v;
  }
  return latest;
}

/**
 * Reads the version a lab result reads (`contextVersionForLab`), with the given columns; null when none applies.
 * Throws on a database error: a context that could not be read is never replaced by another.
 */
export async function loadLabContext<T>(
  supabase: SupabaseClient,
  userId: string,
  lab: LabContextRef,
  columns: string,
): Promise<T | null> {
  const recordedId = lab.patient_context_version_id;
  if (recordedId) {
    const { data, error } = await supabase
      .from("patient_context_versions")
      .select(columns)
      .eq("id", recordedId)
      .eq("user_id", userId)
      .maybeSingle();
    if (error) throw new Error(`reading the patient context recorded with the lab failed: ${error.message}`);
    if (data) return data as T;
  }
  let query = supabase.from("patient_context_versions").select(columns).eq("user_id", userId);
  if (lab.created_at) query = query.lte("created_at", lab.created_at);
  const { data, error } = await query.order("version_number", { ascending: false }).limit(1).maybeSingle();
  if (error) throw new Error(`reading the patient context in force at the lab failed: ${error.message}`);
  return (data as T | null) ?? null;
}
