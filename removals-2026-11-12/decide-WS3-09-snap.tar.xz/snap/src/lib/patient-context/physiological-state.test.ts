/**
 * The physiological state a lab result is read under (physiological-state.ts): one case per row of the table in
 * docs/signoff/work/governance/state-rules.md section 1 ("Fields the rules read"), resolved from contexts written with
 * the keys of options.ts; then the read (loadLabState) on a scripted database (fake-supabase), no network.
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import {
  EARLIER_VERSION_COLUMNS,
  LAB_STATE_CONTEXT_COLUMNS,
  LAB_STATE_LAB_COLUMNS,
  TIE_ORDER,
  UNKNOWN_STATE,
  loadLabState,
  resolveState,
  type ContextVersionColumns,
  type PhysiologicalState,
} from "./physiological-state";
import {
  CONTRACEPTION_OPTIONS,
  HRT_OPTIONS,
  MENOPAUSE_STATUSES,
  MENSTRUAL_REGULARITIES,
  TRT_OPTIONS,
  emptySnapshot,
  type DurableContextSnapshot,
  type MedicationKey,
} from "./options";

/** A context version: the empty snapshot of options.ts with the given sections. */
const version = (patch: Partial<DurableContextSnapshot> & { version_number?: number } = {}): ContextVersionColumns => ({
  ...emptySnapshot(),
  ...patch,
});
const meds = (...keys: MedicationKey[]) => keys.map((key) => ({ key }));
const stateOf = (patch: Partial<DurableContextSnapshot> & { version_number?: number } = {}, transient?: unknown) =>
  resolveState({ version: version(patch), transient });
/** The state is the unknown one but for these fields. */
const only = (changes: Partial<PhysiologicalState>): PhysiologicalState => ({ ...UNKNOWN_STATE, ...changes });

describe("state-rules.md section 1: one case per row of the table", () => {
  it("conditions.keys contains pregnancy_current: pregnancy, one state with nothing else set (no gestational week)", () => {
    expect(stateOf({ conditions: { keys: ["pregnancy_current"] } })).toEqual(only({ pregnancy: true }));
    expect(stateOf({ conditions: { keys: ["diabetes_t2", "pregnancy_current"] } })).toEqual(only({ pregnancy: true }));
    expect(stateOf({ conditions: { keys: ["diabetes_t2", "ckd"] } })).toEqual(UNKNOWN_STATE);
  });

  it("conditions.keys contains lactating: lactation", () => {
    expect(stateOf({ conditions: { keys: ["lactating"] } })).toEqual(only({ lactation: true }));
    expect(stateOf({ conditions: { keys: ["pregnancy_current", "lactating"] } })).toEqual(only({ pregnancy: true, lactation: true }));
  });

  it("sex_specific.menopause_status peri, post or absent: the status, absent being unknown", () => {
    for (const status of MENOPAUSE_STATUSES) {
      expect(stateOf({ sex_specific: { menopause_status: status } }), status).toEqual(only({ menopause: status }));
    }
    expect(stateOf({ sex_specific: {} }).menopause).toBeNull();
    // Not an option of options.ts: unknown, never a status.
    expect(stateOf({ sex_specific: { menopause_status: "postmenopausal" as never } }).menopause).toBeNull();
  });

  it("sex_specific.hrt none, oral or transdermal: the hormone therapy; only oral sets the oral-oestrogen flag", () => {
    for (const hrt of HRT_OPTIONS) {
      expect(stateOf({ sex_specific: { hrt } }), hrt).toEqual(only({ hormoneTherapy: hrt, oralOestrogen: hrt === "oral" }));
    }
  });

  describe("medications hrt_oral and hrt_transdermal: the same state as sex_specific.hrt", () => {
    it("alone, or agreeing with sex_specific.hrt: that route, no disagreement", () => {
      expect(stateOf({ medications: meds("hrt_oral") })).toEqual(only({ hormoneTherapy: "oral", oralOestrogen: true }));
      expect(stateOf({ medications: meds("hrt_transdermal") })).toEqual(only({ hormoneTherapy: "transdermal" }));
      expect(stateOf({ medications: meds("hrt_oral"), sex_specific: { hrt: "oral" } })).toEqual(only({ hormoneTherapy: "oral", oralOestrogen: true }));
      expect(stateOf({ medications: meds("hrt_transdermal"), sex_specific: { hrt: "transdermal" } }).disagreements).toEqual([]);
    });

    it("on disagreement the most recent statement wins, and the disagreement is kept for the question", () => {
      // Oral HRT added to the medications in version 2, while the answer has said "none" since version 1.
      const started = resolveState({
        version: version({ version_number: 2, sex_specific: { hrt: "none" }, medications: meds("hrt_oral") }),
        earlier: [version({ version_number: 1, sex_specific: { hrt: "none" } })],
      });
      expect(started).toEqual(
        only({
          hormoneTherapy: "oral",
          oralOestrogen: true,
          disagreements: [
            {
              therapy: "hormone_therapy",
              statements: [
                { source: "sex_specific.hrt", value: "none", since: 1 },
                { source: "medications.hrt_oral", value: "oral", since: 2 },
              ],
              used: "oral",
              decidedBy: "most_recent",
            },
          ],
        }),
      );

      // The answer changed to "none" in version 3; the oral HRT medication has been listed since version 1.
      const stopped = resolveState({
        version: version({ version_number: 3, sex_specific: { hrt: "none" }, medications: meds("hrt_oral") }),
        earlier: [
          version({ version_number: 1, sex_specific: { hrt: "oral" }, medications: meds("hrt_oral") }),
          version({ version_number: 2, sex_specific: { hrt: "oral" }, medications: meds("hrt_oral") }),
        ],
      });
      expect(stopped.hormoneTherapy).toBe("none");
      expect(stopped.oralOestrogen).toBe(false);
      expect(stopped.disagreements[0]).toMatchObject({ used: "none", decidedBy: "most_recent" });
      expect(stopped.disagreements[0].statements.map((s) => s.since)).toEqual([3, 1]);

      // Switched to transdermal in the medications (version 2): the older oral answer loses.
      const switched = resolveState({
        version: version({ version_number: 2, sex_specific: { hrt: "oral" }, medications: meds("hrt_transdermal") }),
        earlier: [version({ version_number: 1, sex_specific: { hrt: "oral" }, medications: meds("hrt_oral") })],
      });
      expect(switched).toMatchObject({ hormoneTherapy: "transdermal", oralOestrogen: false });
    });

    it("statements made in the same version have no most recent one: the tie order decides, and says so", () => {
      expect(TIE_ORDER.hormone_therapy).toEqual(["oral", "transdermal", "none"]);
      // No earlier version (a first context), or one that already said both.
      const first = stateOf({ version_number: 1, sex_specific: { hrt: "none" }, medications: meds("hrt_oral") });
      const together = resolveState({
        version: version({ version_number: 2, sex_specific: { hrt: "transdermal" }, medications: meds("hrt_oral") }),
        earlier: [version({ version_number: 1, sex_specific: { hrt: "transdermal" }, medications: meds("hrt_oral") })],
      });
      for (const s of [first, together]) {
        expect(s).toMatchObject({ hormoneTherapy: "oral", oralOestrogen: true });
        expect(s.disagreements).toHaveLength(1);
        expect(s.disagreements[0]).toMatchObject({ therapy: "hormone_therapy", used: "oral", decidedBy: "tie" });
      }
      // Both medications listed, no answer: the same.
      expect(stateOf({ medications: meds("hrt_transdermal", "hrt_oral") }).disagreements[0]).toMatchObject({ used: "oral", decidedBy: "tie" });
      expect(stateOf({ sex_specific: { hrt: "none" }, medications: meds("hrt_transdermal") }).hormoneTherapy).toBe("transdermal");
      // A version without a number cannot be dated: the statements count as made together.
      expect(
        resolveState({
          version: version({ sex_specific: { hrt: "none" }, medications: meds("hrt_oral") }),
          earlier: [version({ version_number: 1, sex_specific: { hrt: "none" } })],
        }).disagreements[0].statements.map((s) => s.since),
      ).toEqual([null, null]);
    });
  });

  it("sex_specific.contraception: recorded as given; only oral sets the oral-oestrogen flag", () => {
    for (const contraception of CONTRACEPTION_OPTIONS) {
      const oral = contraception === "oral";
      expect(stateOf({ sex_specific: { contraception } }), contraception).toEqual(
        only({ contraception, oralContraception: oral, oralOestrogen: oral }),
      );
    }
  });

  it("medications oral_contraceptive: the same state as contraception = oral", () => {
    expect(stateOf({ medications: meds("oral_contraceptive") })).toEqual(only({ oralContraception: true, oralOestrogen: true }));
    expect(stateOf({ medications: meds("oral_contraceptive"), sex_specific: { contraception: "oral" } })).toEqual(
      stateOf({ sex_specific: { contraception: "oral" } }),
    );
  });

  it("sex_specific.trt and the trt_* medications: the testosterone therapy, with no oral-oestrogen flag", () => {
    for (const trt of TRT_OPTIONS) {
      expect(stateOf({ sex_specific: { trt } }), trt).toEqual(only({ testosteroneTherapy: trt }));
    }
    expect(stateOf({ medications: meds("trt_injectable") })).toEqual(only({ testosteroneTherapy: "injectable" }));
    expect(stateOf({ medications: meds("trt_topical"), sex_specific: { trt: "topical" } })).toEqual(only({ testosteroneTherapy: "topical" }));
    // Recorded two ways: the same rule as hormone therapy (the most recent, else the tie order).
    expect(TIE_ORDER.testosterone_therapy).toEqual(["injectable", "topical", "none"]);
    const tie = stateOf({ sex_specific: { trt: "none" }, medications: meds("trt_injectable") });
    expect(tie.testosteroneTherapy).toBe("injectable");
    expect(tie.disagreements[0]).toMatchObject({ therapy: "testosterone_therapy", used: "injectable", decidedBy: "tie" });
    const stopped = resolveState({
      version: version({ version_number: 2, sex_specific: { trt: "none" }, medications: meds("trt_topical") }),
      earlier: [version({ version_number: 1, sex_specific: { trt: "topical" }, medications: meds("trt_topical") })],
    });
    expect(stopped.testosteroneTherapy).toBe("none");
  });

  it("sex_specific.menstrual_regularity: recorded; absent with no menopause recorded does not change the menopause state", () => {
    for (const regularity of MENSTRUAL_REGULARITIES) {
      expect(stateOf({ sex_specific: { menstrual_regularity: regularity } }), regularity).toEqual(only({ menstrualRegularity: regularity }));
    }
    expect(stateOf({ sex_specific: { menstrual_regularity: "absent" } }).menopause).toBeNull();
    expect(stateOf({ sex_specific: { menstrual_regularity: "absent", menopause_status: "post" } })).toEqual(
      only({ menstrualRegularity: "absent", menopause: "post" }),
    );
  });

  it("transient.cycle_day: the day of the cycle, or null; a value the context form would refuse is null", () => {
    expect(stateOf({}, { cycle_day: 22 })).toEqual(only({ cycleDay: 22 }));
    expect(stateOf({}, { cycle_day: 1 }).cycleDay).toBe(1);
    for (const day of [null, undefined, 0, 46, 2.5, "22", -3]) {
      expect(stateOf({}, { cycle_day: day }).cycleDay, String(day)).toBeNull();
    }
    expect(stateOf({}, null).cycleDay).toBeNull();
    expect(stateOf({}, { skipped: true }).cycleDay).toBeNull();
  });

  it("transient draw_time, fasted, currently_ill and last_workout: pre-analytical, not physiological states", () => {
    const transient = { fasted: "not_fasted", draw_time: "evening", currently_ill: true, last_workout: "hard_under_24h", sleep_quality: "poor" };
    expect(stateOf({}, transient)).toEqual(UNKNOWN_STATE);
    expect(stateOf({ sex_specific: { hrt: "oral" } }, transient)).toEqual(stateOf({ sex_specific: { hrt: "oral" } }));
  });

  it("supplements[].key = biotin: the biotin flag; other supplements do not set it", () => {
    expect(stateOf({ supplements: [{ key: "biotin", dose: "10 mg" }] })).toEqual(only({ biotin: true }));
    expect(stateOf({ supplements: [{ key: "creatine", dose: "5 g" }, { key: "vitamin_d" }] })).toEqual(UNKNOWN_STATE);
  });
});

describe("the keys read are those of options.ts", () => {
  it("the persona fixture's keys and fields set nothing", () => {
    const fixtureStyle = {
      conditions: { keys: ["chronic_kidney_disease", "hypothyroidism"] },
      medications: [{ key: "oral_estradiol" }, { key: "transdermal_estradiol" }, { key: "combined_oral_contraceptive" }, { key: "statin" }],
      supplements: [],
      sex_specific: { menopause_status: "postmenopausal", hormone_therapy: "oral", oral_contraception: true },
    };
    expect(resolveState({ version: fixtureStyle, transient: { physiological_state: "pregnancy", trimester: 2 } })).toEqual(UNKNOWN_STATE);
  });
});

describe("missing context: an unknown state, never pregnant", () => {
  it("no version, an empty one, or sections that are not what options.ts stores", () => {
    expect(resolveState({})).toEqual(UNKNOWN_STATE);
    expect(resolveState({ version: null, transient: null })).toEqual(UNKNOWN_STATE);
    expect(resolveState({ version: emptySnapshot() })).toEqual(UNKNOWN_STATE);
    expect(resolveState({ version: { conditions: null, medications: "hrt_oral", supplements: {}, sex_specific: [] } })).toEqual(UNKNOWN_STATE);
    expect(resolveState({ version: { conditions: { keys: "pregnancy_current" } } }).pregnancy).toBe(false);
    expect(resolveState({ version: { conditions: ["pregnancy_current"] } }).pregnancy).toBe(false);
  });

  it("the unknown state cannot be changed by whoever reads it", () => {
    expect(Object.isFrozen(UNKNOWN_STATE)).toBe(true);
    expect(Object.isFrozen(UNKNOWN_STATE.disagreements)).toBe(true);
  });
});

// ─── loadLabState ───

const LAB = { patient_context_version_id: "ctx-7", created_at: "2026-05-12T10:00:00Z", transient_context: { cycle_day: 22, fasted: "twelve_plus" } };
const RECORDED = {
  version_number: 7,
  supplements: [{ key: "creatine", dose: "5 g" }, { key: "biotin" }],
  medications: [{ key: "oral_contraceptive" }],
  conditions: { keys: ["lactating"] },
  sex_specific: { menstrual_regularity: "regular", contraception: "oral" },
};
const IN_FORCE = { version_number: 6, supplements: [{ key: "creatine", dose: "10 g" }], medications: [], conditions: { keys: [] }, sex_specific: { menopause_status: "peri" } };

type Script = {
  lab?: Record<string, unknown> | null;
  recorded?: Record<string, unknown> | null;
  inForce?: Record<string, unknown> | null;
  earlier?: Record<string, unknown>[];
  failOn?: "lab_results" | "recorded" | "in_force" | "earlier";
};

function database(script: Script) {
  const respond = (c: FakeCall): FakeResponse => {
    const which =
      c.table === "lab_results"
        ? "lab_results"
        : argsOf(c, "eq", "id")
          ? "recorded"
          : argsOf(c, "lt", "version_number")
            ? "earlier"
            : "in_force";
    if (script.failOn === which) return { error: { message: "connection reset" } };
    if (which === "lab_results") return { data: script.lab ?? null };
    if (which === "recorded") return { data: script.recorded ?? null };
    if (which === "earlier") return { data: script.earlier ?? [] };
    return { data: script.inForce ?? null };
  };
  // project: rows are trimmed to the columns asked for, so a column the state reads but the select omits is missed.
  return fakeSupabase(respond, { project: true });
}

describe("loadLabState: the lab's context read once, with its supplements", () => {
  afterEach(() => vi.restoreAllMocks());

  it("reads the lab by id and owner, then the version recorded with it, and resolves the state with the lab's cycle day", async () => {
    const { client, calls } = database({ lab: LAB, recorded: RECORDED, inForce: IN_FORCE });
    const out = await loadLabState(client, "u1", "lab-1");
    expect(out.supplements).toEqual(RECORDED.supplements);
    expect(out.state).toEqual(
      only({ lactation: true, menstrualRegularity: "regular", contraception: "oral", oralContraception: true, oralOestrogen: true, cycleDay: 22, biotin: true }),
    );
    expect(out.state).toEqual(resolveState({ version: RECORDED, transient: LAB.transient_context }));

    const [lab, recorded] = calls;
    expect(lab.table).toBe("lab_results");
    expect(argsOf(lab, "select")).toEqual([LAB_STATE_LAB_COLUMNS]);
    expect(argsOf(lab, "eq", "id")).toEqual(["id", "lab-1"]);
    expect(argsOf(lab, "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(recorded.table).toBe("patient_context_versions");
    expect(argsOf(recorded, "select")).toEqual([LAB_STATE_CONTEXT_COLUMNS]);
    expect(argsOf(recorded, "eq", "id")).toEqual(["id", "ctx-7"]);
    expect(argsOf(recorded, "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(calls).toHaveLength(2);
  });

  it("without a recorded version, or with one that is gone: the latest created on or before the lab", async () => {
    for (const recordedId of [null, "gone"]) {
      const { client, calls } = database({ lab: { ...LAB, patient_context_version_id: recordedId }, inForce: IN_FORCE });
      const out = await loadLabState(client, "u1", "lab-1");
      expect(out.supplements, String(recordedId)).toEqual(IN_FORCE.supplements);
      expect(out.state, String(recordedId)).toEqual(only({ menopause: "peri", cycleDay: 22 }));
      const read = calls[calls.length - 1];
      expect(argsOf(read, "select")).toEqual([LAB_STATE_CONTEXT_COLUMNS]);
      expect(argsOf(read, "eq", "user_id")).toEqual(["user_id", "u1"]);
      expect(argsOf(read, "lte", "created_at")).toEqual(["created_at", LAB.created_at]);
      expect(argsOf(read, "order")).toEqual(["version_number", { ascending: false }]);
    }
  });

  it("missing context gives no supplements and the unknown state, never pregnant", async () => {
    const noLab = database({ lab: null, inForce: { ...IN_FORCE, conditions: { keys: ["pregnancy_current"] } } });
    expect(await loadLabState(noLab.client, "u1", "lab-1")).toEqual({ supplements: null, state: UNKNOWN_STATE });
    expect(noLab.calls).toHaveLength(1);

    const noVersion = database({ lab: { patient_context_version_id: null, created_at: "2025-10-03T10:00:00Z", transient_context: null } });
    expect(await loadLabState(noVersion.client, "u1", "lab-1")).toEqual({ supplements: null, state: UNKNOWN_STATE });

    // The lab's own answers still count without a context version.
    const answersOnly = database({ lab: { ...LAB, patient_context_version_id: null } });
    expect(await loadLabState(answersOnly.client, "u1", "lab-1")).toEqual({ supplements: null, state: only({ cycleDay: 22 }) });
  });

  it.each(["lab_results", "recorded", "in_force", "earlier"] as const)(
    "a failed read (%s) throws: no state is made up from another context",
    async (failOn) => {
      vi.spyOn(console, "warn").mockImplementation(() => {});
      const disagreeing = { ...RECORDED, sex_specific: { hrt: "none" }, medications: meds("hrt_oral") };
      const { client } = database({ lab: LAB, recorded: failOn === "in_force" ? null : disagreeing, inForce: IN_FORCE, earlier: [], failOn });
      await expect(loadLabState(client, "u1", "lab-1")).rejects.toThrow(/connection reset/);
    },
  );

  it("a therapy recorded two ways: the earlier versions are read, the most recent statement wins, and it is logged", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const recorded = { ...RECORDED, version_number: 3, sex_specific: { hrt: "none" }, medications: meds("hrt_oral"), conditions: { keys: [] } };
    const earlier = [
      { version_number: 2, sex_specific: { hrt: "none" }, medications: meds("hrt_oral") },
      { version_number: 1, sex_specific: { hrt: "oral" }, medications: meds("hrt_oral") },
    ];
    const { client, calls } = database({ lab: LAB, recorded, earlier });
    const { state } = await loadLabState(client, "u1", "lab-1");

    expect(state).toMatchObject({ hormoneTherapy: "none", oralOestrogen: false });
    expect(state.disagreements).toEqual([
      {
        therapy: "hormone_therapy",
        statements: [
          { source: "sex_specific.hrt", value: "none", since: 2 },
          { source: "medications.hrt_oral", value: "oral", since: 1 },
        ],
        used: "none",
        decidedBy: "most_recent",
      },
    ]);
    const read = calls[2];
    expect(read.table).toBe("patient_context_versions");
    expect(argsOf(read, "select")).toEqual([EARLIER_VERSION_COLUMNS]);
    expect(argsOf(read, "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(argsOf(read, "lt", "version_number")).toEqual(["version_number", 3]);
    expect(argsOf(read, "order")).toEqual(["version_number", { ascending: false }]);
    expect(ops(read)).not.toContain("insert");
    expect(calls).toHaveLength(3);

    expect(warn).toHaveBeenCalledTimes(1);
    const logged = String(warn.mock.calls[0][0]);
    expect(logged).toContain("lab lab-1");
    expect(logged).toContain("sex_specific.hrt = none since version 2");
    expect(logged).toContain("medications.hrt_oral = oral since version 1");
    expect(logged).toContain("using none");
  });

  it("no disagreement: no earlier version is read and nothing is logged", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const { client, calls } = database({ lab: LAB, recorded: { ...RECORDED, sex_specific: { hrt: "oral" }, medications: meds("hrt_oral") } });
    expect((await loadLabState(client, "u1", "lab-1")).state.hormoneTherapy).toBe("oral");
    expect(calls).toHaveLength(2);
    expect(warn).not.toHaveBeenCalled();
  });
});
