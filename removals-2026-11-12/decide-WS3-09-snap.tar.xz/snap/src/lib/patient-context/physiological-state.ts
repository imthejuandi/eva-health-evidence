/**
 * The physiological state a lab result is read under: the fields of docs/signoff/work/governance/state-rules.md
 * section 1 ("Fields the rules read"), resolved from the patient context version the lab reads (lab-context.ts) and
 * from the lab's own per-draw answers (lab_results.transient_context). The keys are those of options.ts.
 *
 *   - Pregnancy and lactation: conditions.keys contains pregnancy_current, or lactating. Pregnancy is one state: the
 *     app records no gestational week (section 1, trimester).
 *   - Menopause: sex_specific.menopause_status. Absent is unknown, never a status (section 3).
 *   - Menopausal hormone therapy: sex_specific.hrt and the hrt_oral and hrt_transdermal medications (section 4).
 *     Testosterone therapy: sex_specific.trt and the trt_injectable and trt_topical medications (section 4.4).
 *   - Oral contraception: contraception = oral, or the oral_contraceptive medication. With hormone therapy by mouth it
 *     sets the oral-oestrogen flag of section 4.2; no other method sets it (section 4.3).
 *   - The menstrual regularity (it supports section 3 and changes no row), the cycle day (section 5) and the biotin
 *     supplement (P1).
 *   - The pre-analytical answers (fasting, draw time, illness, last workout) are not physiological states: they are
 *     not read here.
 *
 * When the two places a therapy is recorded say different things, the most recent statement wins and the disagreement
 * is kept on the state, so it can be logged and asked (section 1). A context version is one snapshot with one date,
 * so recency comes from the client's earlier versions: a statement dates from the oldest version of the unbroken run
 * of versions that make it, up to the lab's. Statements made in the same version have no most recent one; TIE_ORDER
 * then decides, provisionally, as state-rules.md does not cover that case.
 *
 * resolveState is pure. loadLabState reads the lab's context once, through loadLabContext, with the supplements the
 * biological age's creatine adjustment reads, and returns both; the earlier versions are read only to settle a
 * disagreement. Nothing here decides what a state does to a row, a category or the score.
 */
import type { SupabaseClient } from "@supabase/supabase-js";
import type { SupplementEntry } from "@/lib/biomarkers/supplements";
import { loadLabContext, type LabContextRef } from "./lab-context";
import {
  CONTRACEPTION_OPTIONS,
  HRT_OPTIONS,
  MENOPAUSE_STATUSES,
  MENSTRUAL_REGULARITIES,
  TRT_OPTIONS,
  type ConditionKey,
  type ContraceptionOption,
  type HrtOption,
  type MedicationKey,
  type MenopauseStatus,
  type MenstrualRegularity,
  type SupplementKey,
  type TrtOption,
} from "./options";
import { TransientContextSchema } from "./schema";

// ─── The state ───

export type TherapyName = "hormone_therapy" | "testosterone_therapy";

/** One place a therapy is recorded in the lab's context version, and the route it states there. */
export interface TherapyStatement {
  /** "sex_specific.hrt" or "sex_specific.trt", or "medications." and a medication key, such as "medications.hrt_oral". */
  source: string;
  /** The route, an option of options.ts (HRT_OPTIONS, TRT_OPTIONS). */
  value: string;
  /** The version it dates from: the oldest of the unbroken run of versions making it, up to the lab's; null when the
   * versions carry no number. */
  since: number | null;
}

/** A therapy whose statements disagree, and the value the state uses. */
export interface TherapyDisagreement {
  therapy: TherapyName;
  statements: readonly TherapyStatement[];
  used: string;
  /** "most_recent": the most recent statements agree. "tie": they were made in the same version (TIE_ORDER). */
  decidedBy: "most_recent" | "tie";
}

export interface PhysiologicalState {
  /** conditions.keys contains pregnancy_current (state-rules.md section 2). */
  pregnancy: boolean;
  /** conditions.keys contains lactating (section 2.4). */
  lactation: boolean;
  /** sex_specific.menopause_status (section 3); null when none is recorded. */
  menopause: MenopauseStatus | null;
  /** sex_specific.menstrual_regularity; null when not recorded. */
  menstrualRegularity: MenstrualRegularity | null;
  /** Menopausal hormone therapy (section 4), from sex_specific.hrt and the hrt_* medications; null when neither states it. */
  hormoneTherapy: HrtOption | null;
  /** sex_specific.contraception as recorded (section 4.3); null when not recorded. */
  contraception: ContraceptionOption | null;
  /** contraception = oral, or the oral_contraceptive medication. */
  oralContraception: boolean;
  /** The oral-oestrogen flag (section 4.2): hormone therapy by mouth, or oral contraception. */
  oralOestrogen: boolean;
  /** Testosterone therapy (section 4.4), from sex_specific.trt and the trt_* medications; null when neither states it. */
  testosteroneTherapy: TrtOption | null;
  /** transient_context.cycle_day: the day of the cycle at the draw (section 5); null when not given. */
  cycleDay: number | null;
  /** The biotin supplement: immunoassay interference for TSH and free T4 (P1). */
  biotin: boolean;
  /** The therapies recorded two different ways, each with the value used (logged by loadLabState). */
  disagreements: readonly TherapyDisagreement[];
}

/** The state of a lab with no context: nothing declared, nothing recorded. Never pregnant. */
export const UNKNOWN_STATE: PhysiologicalState = Object.freeze({
  pregnancy: false,
  lactation: false,
  menopause: null,
  menstrualRegularity: null,
  hormoneTherapy: null,
  contraception: null,
  oralContraception: false,
  oralOestrogen: false,
  testosteroneTherapy: null,
  cycleDay: null,
  biotin: false,
  disagreements: Object.freeze([]),
});

// ─── The fields (state-rules.md section 1) ───

const PREGNANCY = "pregnancy_current" satisfies ConditionKey;
const LACTATION = "lactating" satisfies ConditionKey;
const ORAL_CONTRACEPTIVE = "oral_contraceptive" satisfies MedicationKey;
const BIOTIN = "biotin" satisfies SupplementKey;

/** A therapy recorded in two places: a sex_specific answer, and medication keys that each name a route. */
interface Therapy<V extends string> {
  name: TherapyName;
  field: "hrt" | "trt";
  options: readonly V[];
  medications: Readonly<Partial<Record<MedicationKey, Exclude<V, "none">>>>;
}

const HORMONE_THERAPY: Therapy<HrtOption> = {
  name: "hormone_therapy",
  field: "hrt",
  options: HRT_OPTIONS,
  medications: { hrt_oral: "oral", hrt_transdermal: "transdermal" },
};

const TESTOSTERONE_THERAPY: Therapy<TrtOption> = {
  name: "testosterone_therapy",
  field: "trt",
  options: TRT_OPTIONS,
  medications: { trt_injectable: "injectable", trt_topical: "topical" },
};

/**
 * When the most recent statements of a therapy were made in the same version and disagree, the first value of this
 * order they name is used. Provisional: state-rules.md gives no rule for it. A stated therapy comes before "none", and
 * oral before transdermal because oral oestrogen moves more rows (state-rules.md 4.1 and 4.2), so a tie keeps the
 * notes on every row the therapy may have moved rather than read a value it may have raised as a finding. Injectable
 * before topical only makes the result one value: section 4.4 treats both alike.
 */
export const TIE_ORDER: { readonly hormone_therapy: readonly HrtOption[]; readonly testosterone_therapy: readonly TrtOption[] } = {
  hormone_therapy: ["oral", "transdermal", "none"],
  testosterone_therapy: ["injectable", "topical", "none"],
};

// ─── Resolving ───

/** The columns of a patient_context_versions row the state reads (jsonb, read as stored). */
export interface ContextVersionColumns {
  version_number?: number | null;
  medications?: unknown;
  supplements?: unknown;
  conditions?: unknown;
  sex_specific?: unknown;
}

/** What resolveState reads. */
export interface StateContext {
  /** The context version the lab reads (lab-context.ts); null or absent when there is none. */
  version?: ContextVersionColumns | null;
  /** lab_results.transient_context: the lab's per-draw answers. */
  transient?: unknown;
  /** The client's versions before `version`, in any order: only the recency of a disagreement's statements reads them.
   * Without them, disagreeing statements count as made in the same version. */
  earlier?: readonly ContextVersionColumns[];
}

type Row = Record<string, unknown>;
const asRow = (value: unknown): Row => (value && typeof value === "object" && !Array.isArray(value) ? (value as Row) : {});

/** The keys of a jsonb list of { key } items (medications, supplements). */
function itemKeys(list: unknown): Set<string> {
  const keys = new Set<string>();
  if (Array.isArray(list)) {
    for (const item of list) {
      const key = asRow(item).key;
      if (typeof key === "string") keys.add(key);
    }
  }
  return keys;
}

/** The value when it is one of the options, else null: absent, or not an option of options.ts. */
function oneOf<V extends string>(options: readonly V[], value: unknown): V | null {
  return typeof value === "string" && (options as readonly string[]).includes(value) ? (value as V) : null;
}

const versionNumber = (version: ContextVersionColumns | null | undefined): number | null =>
  typeof version?.version_number === "number" && Number.isFinite(version.version_number) ? version.version_number : null;

/** The statements of a therapy in one version: its sex_specific answer, then each medication that names a route. */
function statementsOf<V extends string>(therapy: Therapy<V>, version: ContextVersionColumns | null | undefined): { source: string; value: V }[] {
  const out: { source: string; value: V }[] = [];
  const answer = oneOf(therapy.options, asRow(version?.sex_specific)[therapy.field]);
  if (answer !== null) out.push({ source: `sex_specific.${therapy.field}`, value: answer });
  const medications = itemKeys(version?.medications);
  for (const [key, route] of Object.entries(therapy.medications) as [string, V | undefined][]) {
    if (route !== undefined && medications.has(key)) out.push({ source: `medications.${key}`, value: route });
  }
  return out;
}

/** A therapy's value in the lab's version: null when nothing states it; on disagreement, the most recent statement. */
function resolveTherapy<V extends string>(
  therapy: Therapy<V>,
  version: ContextVersionColumns | null | undefined,
  earlier: readonly ContextVersionColumns[] | undefined,
): { value: V | null; disagreement: TherapyDisagreement | null } {
  const current = statementsOf(therapy, version);
  if (current.length === 0) return { value: null, disagreement: null };
  if (current.every((s) => s.value === current[0].value)) return { value: current[0].value, disagreement: null };

  const number = versionNumber(version);
  const history =
    number === null
      ? []
      : (earlier ?? [])
          .filter((e) => {
            const n = versionNumber(e);
            return n !== null && n < number;
          })
          .sort((a, b) => (versionNumber(b) as number) - (versionNumber(a) as number));
  const statements: TherapyStatement[] = current.map((s) => {
    let since = number;
    for (const e of history) {
      if (!statementsOf(therapy, e).some((x) => x.source === s.source && x.value === s.value)) break;
      since = versionNumber(e);
    }
    return { source: s.source, value: s.value, since };
  });
  const recency = (s: TherapyStatement) => s.since ?? Number.NEGATIVE_INFINITY;
  const newest = Math.max(...statements.map(recency));
  const latest = new Set(statements.filter((s) => recency(s) === newest).map((s) => s.value as V));
  const order = TIE_ORDER[therapy.name] as readonly V[];
  const used = latest.size === 1 ? [...latest][0] : (order.find((v) => latest.has(v)) ?? [...latest][0]);
  return {
    value: used,
    disagreement: { therapy: therapy.name, statements, used, decidedBy: latest.size === 1 ? "most_recent" : "tie" },
  };
}

/** transient_context.cycle_day when it is a cycle day the context form accepts (TransientContextSchema), else null. */
function cycleDayOf(transient: unknown): number | null {
  const parsed = TransientContextSchema.shape.cycle_day.safeParse(asRow(transient).cycle_day);
  return parsed.success && typeof parsed.data === "number" ? parsed.data : null;
}

/**
 * The physiological state of state-rules.md section 1, from the lab's context version and per-draw answers. Pure:
 * nothing is logged here (loadLabState logs the disagreements).
 */
export function resolveState(context: StateContext): PhysiologicalState {
  const version = context.version ?? null;
  const conditions = asRow(version?.conditions).keys;
  const conditionKeys = new Set(Array.isArray(conditions) ? conditions.filter((k): k is string => typeof k === "string") : []);
  const medications = itemKeys(version?.medications);
  const sexSpecific = asRow(version?.sex_specific);

  const hormone = resolveTherapy(HORMONE_THERAPY, version, context.earlier);
  const testosterone = resolveTherapy(TESTOSTERONE_THERAPY, version, context.earlier);
  const contraception = oneOf(CONTRACEPTION_OPTIONS, sexSpecific.contraception);
  const oralContraception = contraception === "oral" || medications.has(ORAL_CONTRACEPTIVE);

  return {
    pregnancy: conditionKeys.has(PREGNANCY),
    lactation: conditionKeys.has(LACTATION),
    menopause: oneOf(MENOPAUSE_STATUSES, sexSpecific.menopause_status),
    menstrualRegularity: oneOf(MENSTRUAL_REGULARITIES, sexSpecific.menstrual_regularity),
    hormoneTherapy: hormone.value,
    contraception,
    oralContraception,
    oralOestrogen: hormone.value === "oral" || oralContraception,
    testosteroneTherapy: testosterone.value,
    cycleDay: cycleDayOf(context.transient),
    biotin: itemKeys(version?.supplements).has(BIOTIN),
    disagreements: [hormone.disagreement, testosterone.disagreement].filter((d): d is TherapyDisagreement => d !== null),
  };
}

// ─── Reading ───

/** What loadLabState reads of the lab result: what loadLabContext needs, the per-draw answers, and the draw date. */
export const LAB_STATE_LAB_COLUMNS = "patient_context_version_id, created_at, transient_context, collection_date";

/** What it reads of the context version: its number (for a disagreement), the supplements and the fields of section 1. */
export const LAB_STATE_CONTEXT_COLUMNS = "version_number, supplements, medications, conditions, sex_specific";

/** What it reads of the client's earlier versions, only to settle a disagreement. */
export const EARLIER_VERSION_COLUMNS = "version_number, medications, sex_specific";

/** A lab's patient context as processing reads it: the supplements and the physiological state. */
export interface LabState {
  /** The context's supplements (the creatine adjustment of the biological age); null when there are none. */
  supplements: SupplementEntry[] | null;
  state: PhysiologicalState;
  /**
   * The lab's draw date (lab_results.collection_date), present only when the lab has one: the age at the draw is
   * computed from it (the eGFR the app computes, biomarkers/egfr.ts).
   */
  collectionDate?: string;
}

/**
 * The supplements and physiological state of the patient context a lab result is read under (lab-context.ts): the
 * version recorded with it, else the client's latest version created on or before it, read once, with the lab's
 * per-draw answers. No lab, or no context and no answers: no supplements and the unknown state. The client's earlier
 * versions are read only when a therapy is recorded two different ways, to find the most recent statement; each such
 * disagreement is logged. Throws on a database error, as processing does for its other reads, so nothing is computed
 * from a context that could not be read.
 */
export async function loadLabState(supabase: SupabaseClient, userId: string, labResultId: string): Promise<LabState> {
  const { data: lab, error } = await supabase
    .from("lab_results")
    .select(LAB_STATE_LAB_COLUMNS)
    .eq("id", labResultId)
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw new Error(`loadLabState: reading the lab result failed: ${error.message}`);
  if (!lab) return { supplements: null, state: UNKNOWN_STATE };
  const ref = lab as LabContextRef & { transient_context?: unknown; collection_date?: unknown };
  const drawn = typeof ref.collection_date === "string" && ref.collection_date ? { collectionDate: ref.collection_date } : {};

  const version = await loadLabContext<ContextVersionColumns>(supabase, userId, ref, LAB_STATE_CONTEXT_COLUMNS);
  let state = resolveState({ version, transient: ref.transient_context });
  const number = versionNumber(version);
  if (state.disagreements.length > 0 && number !== null) {
    const { data: earlier, error: earlierError } = await supabase
      .from("patient_context_versions")
      .select(EARLIER_VERSION_COLUMNS)
      .eq("user_id", userId)
      .lt("version_number", number)
      .order("version_number", { ascending: false });
    if (earlierError) throw new Error(`loadLabState: reading the earlier context versions failed: ${earlierError.message}`);
    state = resolveState({ version, transient: ref.transient_context, earlier: (earlier ?? []) as ContextVersionColumns[] });
  }
  for (const d of state.disagreements) {
    const said = d.statements.map((s) => `${s.source} = ${s.value}${s.since === null ? "" : ` since version ${s.since}`}`).join(", ");
    console.warn(
      `[physiological-state] lab ${labResultId}: ${d.therapy} is recorded two ways (${said}); using ${d.used}, ` +
        `${d.decidedBy === "most_recent" ? "the most recent statement" : "stated together, by TIE_ORDER"}. A question for the client.`,
    );
  }

  const supplements = version?.supplements;
  return { supplements: Array.isArray(supplements) ? (supplements as SupplementEntry[]) : null, state, ...drawn };
}
