export interface ContextNeededData {
  firstName: string;
  biomarkerCount: number;
  locale: string;
  /** Deep link to /labs/[id]/context for the lab waiting on context. */
  contextUrl: string;
}

/**
 * Sent when a lab-partner webhook lands a lab in pending_context. The
 * user's biomarkers are already in the system but the AI
 * interpretation hasn't run yet — it's waiting on context confirmation.
 */
export function renderContextNeeded(
  data: ContextNeededData,
  locale: string,
): string {
  if (locale === "es") {
    return `
      <h1>Tus resultados llegaron, ${data.firstName}</h1>
      <p>Hemos recibido tu analitica con ${data.biomarkerCount} biomarcadores. Antes de generar tu interpretacion, confirma que tu contexto sigue al dia (medicacion, suplementos, ultimo entrenamiento).</p>

      <div style="margin: 20px 0;">
        <span class="stat">${data.biomarkerCount} biomarcadores analizados</span>
      </div>

      <hr class="divider">

      <p>Esto nos asegura que tu interpretacion tenga en cuenta lo que es real para ti. Toma 30 segundos.</p>

      <a href="${data.contextUrl}" class="cta">Confirmar contexto y ver resultados</a>
    `;
  }

  return `
    <h1>Your results just arrived, ${data.firstName}</h1>
    <p>We received your panel with ${data.biomarkerCount} biomarkers. Before we generate your interpretation, confirm that your context (medications, supplements, recent workouts) is still current.</p>

    <div style="margin: 20px 0;">
      <span class="stat">${data.biomarkerCount} biomarkers analyzed</span>
    </div>

    <hr class="divider">

    <p>This makes sure your interpretation accounts for what's actually true for you. Takes about 30 seconds.</p>

    <a href="${data.contextUrl}" class="cta">Confirm context and see results</a>
  `;
}
