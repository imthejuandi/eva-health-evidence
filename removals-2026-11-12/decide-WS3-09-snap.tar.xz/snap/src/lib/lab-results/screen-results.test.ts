/**
 * Where results are set aside on the server (decision D-24, WS3-27): a result printed with "≤" or "≥" never goes on
 * as a plain number or under "<" or ">", a result with no readable number is named instead of dropped, and what
 * processing refuses is named with its reason. Run on the functions the routes call.
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import { readReportedValue } from "@/lib/biomarkers/bounded-result";
import { logSetAside, readExtractedItems, screenSubmittedResults, setAsideFromProcessing } from "./screen-results";
import { printedResult } from "./set-aside";

afterEach(() => vi.restoreAllMocks());

describe("screenSubmittedResults", () => {
  it('a "≤" or "≥" result, by its text or by the sign beside it, is set aside whatever form the sign takes', () => {
    const forms: Array<[unknown, unknown, "≤" | "≥"]> = [
      ["≤5", null, "≤"], ["<=5", undefined, "≤"], ["=<5", null, "≤"], ["⩽ 5", null, "≤"], [5, "≤", "≤"], [5, "<=", "≤"], ["5", "⩽", "≤"],
      ["≥5", null, "≥"], [">=5", null, "≥"], ["=>5", null, "≥"], ["⩾5", null, "≥"], [5, "≥", "≥"], [5, ">=", "≥"], ["≥5", "≥", "≥"],
      // A "<" in the text with "≤" beside it is still a "≤" result: the less strict sign is not dropped.
      ["<5", "≤", "≤"], [">5", "≥", "≥"],
    ];
    for (const [value, comparator, sign] of forms) {
      const { usable, setAside } = screenSubmittedResults([{ name: "hs-CRP", value, comparator, unit: "mg/L" }]);
      expect(usable, JSON.stringify([value, comparator])).toEqual([]);
      expect(setAside).toEqual([expect.objectContaining({ name: "hs-CRP", reason: "sign_not_storable", sign })]);
    }
  });

  it('"<" and ">" bounds and measured values go on, read as the report prints them; the entry comes back with each', () => {
    const entries = [
      { name: "a", value: "<0,5", unit: "mg/L", key: 1 },
      { name: "b", value: 8, comparator: ">", unit: "ng/mL", key: 2 },
      { name: "c", value: "5,4", comparator: "", unit: "%", key: 3 },
      { name: "d", value: 44, comparator: "=", unit: "g/L", key: 4 },
    ];
    const { usable, setAside } = screenSubmittedResults(entries);
    expect(setAside).toEqual([]);
    expect(usable.map((u) => [u.entry.key, u.value, u.comparator])).toEqual([[1, 0.5, "<"], [2, 8, ">"], [3, 5.4, null], [4, 44, null]]);
  });

  it("no number, a comparator that is not a sign, or signs that point opposite ways: set aside as unreadable, with what was given", () => {
    const { usable, setAside } = screenSubmittedResults([
      { name: "a", value: "pendiente", unit: "mg/L" },
      { name: "b", value: null, unit: "U/L" },
      { name: "c", value: Number.NaN, unit: "U/L" },
      { name: "d", value: 5, comparator: "~", unit: "mg/L" },
      { name: "e", value: "<5", comparator: ">", unit: "mg/L" },
      { name: "f", value: "1.234,5", unit: "ng/mL" },
      { name: "ok", value: 1, unit: "x" },
    ]);
    expect(usable.map((u) => u.entry.name)).toEqual(["ok"]);
    expect(setAside.map((s) => [s.name, s.reason, s.printed])).toEqual([
      ["a", "value_unreadable", "pendiente mg/L"],
      ["b", "value_unreadable", "U/L"],
      ["c", "value_unreadable", "U/L"],
      ["d", "value_unreadable", "~5 mg/L"],
      ["e", "value_unreadable", "<5 mg/L"],
      ["f", "value_unreadable", "1.234,5 ng/mL"],
    ]);
  });
});

describe("a comparator that names a member every object inherits is not a sign", () => {
  const INHERITED = ["constructor", "toString", "valueOf", "hasOwnProperty", "__proto__", "isPrototypeOf", "toLocaleString", " constructor "];

  it("readReportedValue reads no result from it, beside a number or beside printed text", () => {
    for (const comparator of INHERITED) {
      expect(readReportedValue(5, comparator), comparator).toBeNull();
      expect(readReportedValue("5,4", comparator), comparator).toBeNull();
      expect(readReportedValue("<5", comparator), comparator).toBeNull();
    }
  });

  it("screenSubmittedResults sets the result aside as unreadable and never calls it usable", () => {
    for (const comparator of INHERITED) {
      const { usable, setAside } = screenSubmittedResults([{ name: "x", value: 5, comparator, unit: "mg/L" }]);
      expect(usable, comparator).toEqual([]);
      expect(setAside, comparator).toEqual([{ name: "x", reason: "value_unreadable", printed: `${comparator.trim()}5 mg/L` }]);
    }
  });

  it("readExtractedItems sets it aside the same way", () => {
    const read = readExtractedItems(INHERITED.map((comparator) => ({ name: comparator, value: 5, comparator, unit: "mg/L" })));
    expect(read.extracted).toEqual([]);
    expect(read.setAside.map((s) => s.reason)).toEqual(INHERITED.map(() => "value_unreadable"));
  });

  it("printedResult never prints a function or an object for it", () => {
    for (const comparator of INHERITED) {
      const printed = printedResult(5, comparator, "mg/L");
      expect(printed, comparator).toBe(`${comparator.trim()}5 mg/L`);
      expect(printed).not.toMatch(/function|native code|\[object/);
    }
  });
});

describe("readExtractedItems (the upload's extraction)", () => {
  it("a named result with no readable number is set aside and named, not dropped; the others are read", () => {
    const { extracted, setAside, unnamed } = readExtractedItems([
      { name: "Glucosa", value: 92, unit: "mg/dL", reference_range: "70-99", flag: null },
      { name: "PCR", value: 5, comparator: "<", unit: "mg/L" },
      { name: "eGFR", value: 90, comparator: "≥", unit: "mL/min/1.73m²" },
      { name: "Ferritina", value: "ver comentario", unit: "ng/mL" },
      { name: "Vitamina D", unit: "ng/mL" },
      { value: 3 },
      null,
      "text",
    ]);
    expect(extracted).toEqual([
      { name: "Glucosa", value: 92, comparator: null, signToReview: null, unit: "mg/dL", referenceRange: "70-99", flag: null },
      { name: "PCR", value: 5, comparator: "<", signToReview: null, unit: "mg/L", referenceRange: "", flag: null },
      // Printed with "≥": kept for the review, with no comparator, so it is shown as set aside there.
      { name: "eGFR", value: 90, comparator: null, signToReview: "≥", unit: "mL/min/1.73m²", referenceRange: "", flag: null },
    ]);
    expect(setAside).toEqual([
      { name: "Ferritina", reason: "value_unreadable", printed: "ver comentario ng/mL" },
      { name: "Vitamina D", reason: "value_unreadable", printed: "ng/mL" },
    ]);
    expect(unnamed).toBe(3);
  });
});

describe("setAsideFromProcessing", () => {
  it("a refused unit is named with both units and the result as reported; an unmatched name with its own reason", () => {
    expect(setAsideFromProcessing([
      { name: "Lipoproteína (a)", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" },
      { name: "Lp(a)", value: 10, unit: "nmol/L", comparator: "<", reason: "unit_mismatch", expectedUnit: "mg/dL" },
      { name: "mystery", value: 1, unit: "x", reason: "unmatched" },
    ])).toEqual([
      { name: "Lipoproteína (a)", reason: "unit_not_convertible", printed: "75 nmol/L", unit: "nmol/L", expectedUnit: "mg/dL" },
      { name: "Lp(a)", reason: "unit_not_convertible", printed: "<10 nmol/L", unit: "nmol/L", expectedUnit: "mg/dL" },
      { name: "mystery", reason: "marker_not_recognised", printed: "1 x" },
    ]);
  });
});

describe("logSetAside (the record for operations)", () => {
  it("writes one line with the source, the lab and each result; nothing when nothing was set aside", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    logSetAside("upload-confirm", { labResultId: "lab-1", userId: "u1" }, []);
    expect(warn).not.toHaveBeenCalled();
    logSetAside("upload-confirm", { labResultId: "lab-1", userId: "u1" }, [{ name: "PCR", reason: "sign_not_storable", printed: "≤5 mg/L", sign: "≤" }]);
    expect(warn).toHaveBeenCalledTimes(1);
    expect(warn.mock.calls[0][0]).toBe("[set-aside] upload-confirm: 1 result(s) not used");
    expect(JSON.parse(String(warn.mock.calls[0][1]))).toEqual({
      source: "upload-confirm",
      labResultId: "lab-1",
      userId: "u1",
      results: [{ name: "PCR", reason: "sign_not_storable", printed: "≤5 mg/L" }],
    });
  });
});
