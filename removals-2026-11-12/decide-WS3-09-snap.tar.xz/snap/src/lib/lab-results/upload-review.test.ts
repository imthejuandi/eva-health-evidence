/**
 * The upload review's rules for a row (decision D-24, WS3-27): the sign selector cannot turn a printed "≤" into "<" or
 * "≥" into ">", nor into a plain number; a set-aside row is shown with its reason, does not wait for a choice of
 * sign, and is sent to the server with its printed sign, where it is set aside and named.
 */
import { describe, expect, it } from "vitest";
import { chooseRowSign, rowNeedsAction, rowReady, rowSetAside, rowsToConfirm, signChoices, type ReviewRow } from "./upload-review";
import { screenSubmittedResults } from "./screen-results";
import { setAsideSentence } from "./set-aside";

const row = (over: Partial<ReviewRow> = {}): ReviewRow => ({
  name: "PCR ultrasensible",
  value: 5,
  comparator: null,
  signToReview: null,
  signFromReport: false,
  unit: "mg/L",
  unitRefused: false,
  expectedUnit: null,
  matchedKey: "hs_crp",
  matchConfidence: "exact",
  confirmed: true,
  skip: false,
  implausible: false,
  ...over,
});
const printedAtMost = row({ signToReview: "≤", signFromReport: true });
const printedAtLeast = row({ signToReview: "≥", signFromReport: true });

describe("the sign selector", () => {
  it('offers no other sign for a result the report prints with "≤" or "≥"', () => {
    expect(signChoices(printedAtMost)).toEqual(["≤"]);
    expect(signChoices(printedAtLeast)).toEqual(["≥"]);
  });

  it('no choice stores "≤" as "<", "≥" as ">", or either as a plain number: the row stays as printed', () => {
    for (const printed of [printedAtMost, printedAtLeast]) {
      for (const sign of ["<", ">", "", "=", "≤", "≥", "x"]) {
        const after = chooseRowSign(printed, sign);
        expect(after.signToReview, sign).toBe(printed.signToReview);
        expect(after.comparator, sign).toBeNull();
        expect(rowSetAside(after)?.reason).toBe("sign_not_storable");
      }
    }
  });

  it('on any other row the client corrects the sign to what the report prints; "≤" or "≥" sets the row aside, and can be undone', () => {
    const measured = row();
    expect(signChoices(measured)).toEqual(["", "<", ">", "≤", "≥"]);
    expect(chooseRowSign(measured, "<")).toMatchObject({ comparator: "<", signToReview: null });
    expect(chooseRowSign(row({ comparator: "<" }), "")).toMatchObject({ comparator: null, signToReview: null });
    const aside = chooseRowSign(row({ comparator: "<" }), "≤");
    expect(aside).toMatchObject({ comparator: null, signToReview: "≤", signFromReport: false });
    expect(rowSetAside(aside)).toEqual({ name: "PCR ultrasensible", reason: "sign_not_storable", printed: "≤5 mg/L", sign: "≤" });
    // The client chose it, so the client can take it back; a sign read from the report cannot be.
    expect(chooseRowSign(aside, "<")).toMatchObject({ comparator: "<", signToReview: null });
    expect(chooseRowSign(measured, "~")).toBe(measured);
  });
});

describe("which rows are set aside, ready, or waiting", () => {
  it("a set-aside row is never ready; a \"≤\" or \"≥\" row waits for nothing, matched or not", () => {
    for (const r of [printedAtMost, row({ signToReview: "≥", signFromReport: true, matchedKey: null, matchConfidence: "none", confirmed: false })]) {
      expect(rowReady(r)).toBe(false);
      expect(rowNeedsAction(r)).toBe(false);
      expect(rowSetAside(r)?.reason).toBe("sign_not_storable");
    }
  });

  it("a refused unit sets the matched row aside, naming both units; an approximate match is still confirmed first", () => {
    const lpa = row({ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", unitRefused: true, expectedUnit: "mg/dL", matchedKey: "lipoprotein_a" });
    expect(rowSetAside(lpa)).toEqual({ name: "Lipoproteína (a)", reason: "unit_not_convertible", printed: "75 nmol/L", unit: "nmol/L", expectedUnit: "mg/dL" });
    expect(setAsideSentence(rowSetAside(lpa)!, "es")).toContain("en nmol/L");
    expect(rowReady(lpa)).toBe(false);
    expect(rowNeedsAction(lpa)).toBe(false);
    expect(rowNeedsAction({ ...lpa, matchConfidence: "fuzzy", confirmed: false })).toBe(true);
    // Unmatched: the unit was judged for no marker, so the row is an ordinary unmatched row.
    expect(rowSetAside({ ...lpa, matchedKey: null })).toBeNull();
  });

  it("the ordinary rules are unchanged: unmatched, unconfirmed and implausible rows wait; skipped rows do not", () => {
    expect(rowReady(row())).toBe(true);
    expect(rowNeedsAction(row())).toBe(false);
    for (const waiting of [row({ matchedKey: null }), row({ confirmed: false }), row({ implausible: true })]) {
      expect(rowReady(waiting)).toBe(false);
      expect(rowNeedsAction(waiting)).toBe(true);
      expect(rowNeedsAction({ ...waiting, skip: true })).toBe(false);
    }
    expect(rowReady(row({ skip: true }))).toBe(false);
  });
});

describe("what is sent to confirm", () => {
  const rows = [
    row({ name: "Albúmina", value: 4.4, unit: "g/dL", matchedKey: "albumin" }),
    row({ name: "PCR", comparator: "<" }),
    printedAtMost,
    row({ name: "eGFR", value: 90, unit: "mL/min/1.73m²", signToReview: "≥", signFromReport: true, matchedKey: null, matchConfidence: "none", confirmed: false }),
    row({ name: "Lp(a)", value: 75, unit: "nmol/L", unitRefused: true, expectedUnit: "mg/dL", matchedKey: "lipoprotein_a" }),
    row({ name: "skipped", signToReview: "≤", signFromReport: true, skip: true }),
    row({ name: "waiting", confirmed: false }),
  ];

  it("ready rows and set-aside rows go, a \"≤\" or \"≥\" row with its printed sign; skipped and waiting rows do not", () => {
    expect(rowsToConfirm(rows)).toEqual([
      { name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
      { name: "PCR", value: 5, comparator: "<", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
      { name: "PCR ultrasensible", value: 5, comparator: "≤", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
      { name: "eGFR", value: 90, comparator: "≥", unit: "mL/min/1.73m²", biomarkerKey: "", matchConfidence: "user" },
      { name: "Lp(a)", value: 75, unit: "nmol/L", biomarkerKey: "lipoprotein_a", matchConfidence: "exact" },
    ]);
  });

  it("the server's screen sets aside exactly the \"≤\" and \"≥\" rows of that payload, and passes the others on", () => {
    const { usable, setAside } = screenSubmittedResults(rowsToConfirm(rows));
    expect(usable.map((u) => [u.entry.name, u.value, u.comparator])).toEqual([["Albúmina", 4.4, null], ["PCR", 5, "<"], ["Lp(a)", 75, null]]);
    expect(setAside.map((s) => [s.name, s.reason, s.sign])).toEqual([
      ["PCR ultrasensible", "sign_not_storable", "≤"],
      ["eGFR", "sign_not_storable", "≥"],
    ]);
  });
});
