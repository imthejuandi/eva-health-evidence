/**
 * A result EVA does not use, named with its reason (decision D-24): it is set aside, never dropped silently and never
 * stored under another sign or as a plain number, and the rest of the report is processed. Three reasons reach a
 * client or an administrator, and a fourth the lab webhook's sender:
 *   - sign_not_storable: the report prints the result with "≤" or "≥". Until the sign-off migration the stored
 *     comparator is "<" or ">" only (bounded-result.ts StoredComparator), and "≥X" read as ">X" would misplace a
 *     value that sits exactly on a limit;
 *   - unit_not_convertible: the canonical-unit gate of processing refused the unit (process-results.ts
 *     unit_mismatch), such as Lp(a) in nmol/L, which no fixed factor links to mg/dL;
 *   - value_unreadable: no number could be read in the result (bounded-result.ts readReportedValue);
 *   - marker_not_recognised: processing matched the name to no marker (the lab webhook; an upload settles this at
 *     review, where the client picks the marker or skips the row).
 *
 * The sentences are not written here: they come from wording-rules.md section 7 through the generated module
 * (decision D-37, scripts/wording/set-aside-copy.ts). This file has no server import, so the upload review and the
 * administrator's form render the same sentences as the routes return.
 */
import { SET_ASIDE_COPY } from "./set-aside-copy.generated";

export type SetAsideReason = keyof typeof SET_ASIDE_COPY.en.reasons;
export type SetAsideLocale = "en" | "es";

export interface SetAsideResult {
  /** The result's name as it was submitted: the report's name, or the marker's key from a sender. */
  name: string;
  reason: SetAsideReason;
  /** The result as it was given, for the person to recognise it: "≤5 mg/L". */
  printed: string;
  /** The printed sign, for sign_not_storable. */
  sign?: "≤" | "≥";
  /** The reported unit and the unit of EVA's ranges, for unit_not_convertible. */
  unit?: string;
  expectedUnit?: string | null;
}

export const SET_ASIDE_REASONS = Object.keys(SET_ASIDE_COPY.en.reasons) as SetAsideReason[];

/** Spanish for "es" and its regional forms, English otherwise, as the rest of the app falls back. */
export function setAsideLocale(locale: unknown): SetAsideLocale {
  return typeof locale === "string" && locale.toLowerCase().startsWith("es") ? "es" : "en";
}

/** A map, not a plain object: the text looked up is a sender's, and "constructor" or "toString" is not a sign. */
const SIGN_AS_PRINTED: ReadonlyMap<string, string> = new Map([
  ["<=", "≤"],
  ["=<", "≤"],
  ["⩽", "≤"],
  [">=", "≥"],
  ["=>", "≥"],
  ["⩾", "≥"],
  ["=", ""],
]);

/**
 * The result as it was given, for the person to recognise it: the sign, the value and the unit ("≤5 mg/L"). A sign
 * given beside the value is shown before it, in its printed form, unless the value's own text already starts with
 * one. Long free text is cut.
 */
export function printedResult(value: unknown, comparator?: unknown, unit?: unknown): string {
  const text = (v: unknown) => (typeof v === "string" ? v.trim() : typeof v === "number" && Number.isFinite(v) ? String(v) : "");
  const shownValue = text(value);
  const beside = text(comparator);
  const sign = /^[<>≤≥⩽⩾=]/.test(shownValue) ? "" : (SIGN_AS_PRINTED.get(beside) ?? beside);
  const whole = [`${sign}${shownValue}`, text(unit)].filter(Boolean).join(" ");
  return whole.length > 60 ? `${whole.slice(0, 59)}…` : whole;
}

/** The reason's sentence for one result, in the given language, from wording-rules.md section 7. */
export function setAsideSentence(item: SetAsideResult, locale: unknown): string {
  const template: string = SET_ASIDE_COPY[setAsideLocale(locale)].reasons[item.reason];
  const values: Record<string, string> = {
    sign: item.sign ?? "",
    unit: item.unit ?? "",
    expected_unit: item.expectedUnit ?? "",
  };
  return template.replace(/\{([a-z_]+)\}/g, (_, key: string) => (Object.hasOwn(values, key) ? values[key] : ""));
}

/** The short tag shown beside a set-aside row at review ("Not used"). */
export function setAsideTag(locale: unknown): string {
  return SET_ASIDE_COPY[setAsideLocale(locale)].tag;
}

export interface SetAsideNotice {
  heading: string;
  /** Whether the rest of the report was saved, or nothing was. */
  intro: string;
  items: Array<{ name: string; printed: string; reason: SetAsideReason; sentence: string }>;
}

/**
 * What the submitter is shown: a heading, whether the rest was saved (`nothingSaved` false) or nothing was, and each
 * result with its sentence. Null when no result was set aside.
 */
export function setAsideNotice(items: SetAsideResult[], locale: unknown, nothingSaved: boolean): SetAsideNotice | null {
  if (items.length === 0) return null;
  const copy = SET_ASIDE_COPY[setAsideLocale(locale)];
  return {
    heading: copy.heading,
    intro: nothingSaved ? copy.intro_all : copy.intro_some,
    items: items.map((item) => ({ name: item.name, printed: item.printed, reason: item.reason, sentence: setAsideSentence(item, locale) })),
  };
}

/** The same notice as plain text, one result per line: the administrator's form and the webhook's log. */
export function setAsideText(items: SetAsideResult[], locale: unknown, nothingSaved: boolean): string {
  const notice = setAsideNotice(items, locale, nothingSaved);
  if (!notice) return "";
  return [
    `${notice.heading}. ${notice.intro}`,
    ...notice.items.map((i) => `- ${i.name}${i.printed ? ` (${i.printed})` : ""}: ${i.sentence}`),
  ].join("\n");
}
