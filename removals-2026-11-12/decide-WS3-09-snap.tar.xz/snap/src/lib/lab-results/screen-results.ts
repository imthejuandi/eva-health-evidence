/**
 * Where a submitted result is set aside (decision D-24, set-aside.ts), on the server: before processing, a result
 * printed with "≤" or "≥" and a result with no readable number; after processing, a result the canonical-unit gate
 * refused and a name matched to no marker. Every route that takes results uses these, so each one names what it set
 * aside to whoever submitted it and writes it to the log for operations, and processes the rest.
 */
import { readReportedValue, type StoredComparator } from "@/lib/biomarkers/bounded-result";
import type { UnmatchedBiomarker } from "@/lib/biomarkers/process-results";
import { printedResult, type SetAsideResult } from "./set-aside";

/** A result as a route receives it: the number or the printed text, and the sign beside it, if any. */
export interface SubmittedResult {
  name: string;
  value: unknown;
  comparator?: unknown;
  unit?: unknown;
}

/** A result that can go to processing: a number, with "<" or ">" when it is a bound. */
export interface UsableResult<T> {
  entry: T;
  value: number;
  comparator: StoredComparator | null;
}

/**
 * Splits submitted results into those processing can take and those set aside. A result printed with "≤" or "≥", by
 * the sign in its text or the sign beside it, is set aside whatever else is said about it: it is never passed on as a
 * plain number or under "<" or ">". A result readReportedValue cannot read (no number, a comparator that is not a
 * sign, a sign that contradicts the text) is set aside as unreadable.
 */
export function screenSubmittedResults<T extends SubmittedResult>(entries: readonly T[]): { usable: UsableResult<T>[]; setAside: SetAsideResult[] } {
  const usable: UsableResult<T>[] = [];
  const setAside: SetAsideResult[] = [];
  for (const entry of entries) {
    const reported = readReportedValue(entry.value, entry.comparator);
    const printed = printedResult(entry.value, entry.comparator, entry.unit);
    if (!reported) {
      setAside.push({ name: entry.name, reason: "value_unreadable", printed });
    } else if (reported.review) {
      setAside.push({ name: entry.name, reason: "sign_not_storable", printed, sign: reported.review });
    } else {
      usable.push({ entry, value: reported.value, comparator: reported.comparator });
    }
  }
  return { usable, setAside };
}

/** The results processing did not store (process-results.ts `unmatched`), as set-aside results with their reason. */
export function setAsideFromProcessing(unmatched: readonly UnmatchedBiomarker[]): SetAsideResult[] {
  return unmatched.map((u) => {
    const printed = printedResult(u.value, u.comparator, u.unit);
    return u.reason === "unit_mismatch"
      ? { name: u.name, reason: "unit_not_convertible" as const, printed, unit: u.unit, expectedUnit: u.expectedUnit ?? null }
      : { name: u.name, reason: "marker_not_recognised" as const, printed };
  });
}

/**
 * The record for operations: one log line per submission that set results aside, with where it came from, the lab
 * and each result's name, reason and printed form. Nothing is logged when nothing was set aside.
 */
export function logSetAside(source: string, context: { labResultId?: string | null; userId?: string | null }, items: readonly SetAsideResult[]): void {
  if (items.length === 0) return;
  console.warn(
    `[set-aside] ${source}: ${items.length} result(s) not used`,
    JSON.stringify({
      source,
      labResultId: context.labResultId ?? null,
      userId: context.userId ?? null,
      results: items.map((i) => ({ name: i.name, reason: i.reason, printed: i.printed })),
    }),
  );
}

/** A result read from an uploaded report, before it is matched to a marker. */
export interface ExtractedResult {
  name: string;
  /** The number: the bound itself when the result is a bound. */
  value: number;
  comparator: StoredComparator | null;
  /** "≤" or "≥" as printed: the result is shown at review as set aside, and is not stored (decision D-24). */
  signToReview: "≤" | "≥" | null;
  unit: string;
  referenceRange: string;
  flag: string | null;
}

/**
 * The results the extraction returned for one file, read with readReportedValue: a number with the sign beside it, or
 * the printed text ("5,4", "<5"). A named result with no readable number is not dropped: it is set aside as
 * unreadable, so the review names it to the client. An item with no name cannot be named and is only counted.
 */
export function readExtractedItems(items: readonly unknown[]): { extracted: ExtractedResult[]; setAside: SetAsideResult[]; unnamed: number } {
  const extracted: ExtractedResult[] = [];
  const setAside: SetAsideResult[] = [];
  let unnamed = 0;
  for (const raw of items) {
    const entry = (raw && typeof raw === "object" ? raw : {}) as {
      name?: unknown;
      value?: unknown;
      comparator?: unknown;
      unit?: unknown;
      reference_range?: unknown;
      flag?: unknown;
    };
    if (typeof entry.name !== "string" || !entry.name.trim()) {
      unnamed++;
      continue;
    }
    const unit = typeof entry.unit === "string" ? entry.unit : "";
    const reported = readReportedValue(entry.value, entry.comparator);
    if (!reported) {
      setAside.push({ name: entry.name, reason: "value_unreadable", printed: printedResult(entry.value, entry.comparator, unit) });
      continue;
    }
    extracted.push({
      name: entry.name,
      value: reported.value,
      comparator: reported.comparator,
      signToReview: reported.review,
      unit,
      referenceRange: typeof entry.reference_range === "string" ? entry.reference_range : "",
      flag: typeof entry.flag === "string" ? entry.flag : null,
    });
  }
  return { extracted, setAside, unnamed };
}
