import { describe, it, expect, vi } from "vitest";
import { fakeSupabase, ops, argsOf } from "@/lib/testing/fake-supabase";
import { resolvePendingLab, type AutoResolveDeps } from "./auto-resolve";

// Under the cron there is no session: every helper must receive the
// service-role client, and nothing may reach for the cookie-bound one.
vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("RLS client must not be created under the cron");
  },
}));

function deps(overrides: Partial<AutoResolveDeps> = {}): AutoResolveDeps {
  return {
    getCurrentVersion: vi.fn(async () => ({ id: "v7" })) as unknown as AutoResolveDeps["getCurrentVersion"],
    createNewVersion: vi.fn(async () => ({ id: "v-new" })) as unknown as AutoResolveDeps["createNewVersion"],
    getUserProfile: vi.fn(async () => ({ id: "u1", email: "p@example.test", full_name: "Ana Prueba", locale: "es" })) as unknown as AutoResolveDeps["getUserProfile"],
    getWearableData: vi.fn(async () => []) as unknown as AutoResolveDeps["getWearableData"],
    generateSummary: vi.fn(async () => undefined) as unknown as AutoResolveDeps["generateSummary"],
    sendEmail: vi.fn(async () => undefined) as unknown as AutoResolveDeps["sendEmail"],
    completeCycleForLabResult: vi.fn(async () => ["c4"]) as unknown as AutoResolveDeps["completeCycleForLabResult"],
    recomputeLabMetrics: vi.fn(async () => undefined),
    ...overrides,
  };
}

const bv = [{ biomarker_key: "glucose_fasting", biomarker_name: "Glucosa", value: 90, unit: "mg/dL", zone: "optimal", optimal_low: 70, optimal_high: 99 }];

/**
 * A scripted database holding one lab in `status` (pending_context unless given) and its biomarker values. A
 * conditional update (.eq("status", ...)) changes the lab only when it is in that status, as Postgres would.
 */
function labDb(values: unknown[], status = "pending_context") {
  const lab = { status };
  return {
    lab,
    ...fakeSupabase((c) => {
      if (c.table === "biomarker_values") return { data: values };
      if (c.table === "lab_results" && ops(c).startsWith("update")) {
        const onlyIf = argsOf(c, "eq", "status")?.[1];
        if (onlyIf !== undefined && onlyIf !== lab.status) return { data: ops(c).includes("select") ? [] : null };
        Object.assign(lab, argsOf(c, "update")?.[0] as object);
        return { data: ops(c).includes("select") ? [{ id: "lab-1" }] : null };
      }
      return { data: null };
    }),
  };
}

describe("resolvePendingLab — the 72-hour fallback acts with the service-role client", () => {
  it("stamps the last context version, runs the pipeline with the admin client, marks ready, closes the cycle and emails", async () => {
    const { client, calls } = labDb(bv);
    let callsBeforeRecompute = -1;
    const d = deps({
      recomputeLabMetrics: vi.fn(async () => {
        callsBeforeRecompute = calls.length;
      }),
    });
    const r = await resolvePendingLab(client, "lab-1", "u1", d);
    expect(r).toEqual({ biomarkerCount: 1, cyclesClosed: ["c4"] });

    expect(d.getCurrentVersion).toHaveBeenCalledWith("u1", client);
    expect(d.createNewVersion).not.toHaveBeenCalled();
    expect(d.getUserProfile).toHaveBeenCalledWith("u1", client);
    expect(d.getWearableData).toHaveBeenCalledWith("u1", 30, client);
    expect(vi.mocked(d.generateSummary).mock.calls[0][5]).toBe(client);
    expect(d.completeCycleForLabResult).toHaveBeenCalledWith(client, "lab-1");
    expect(vi.mocked(d.sendEmail).mock.calls[0].slice(0, 2)).toEqual(["p@example.test", "results-ready"]);
    // The lab's metrics are recomputed under the stamped context, with the admin client, once it is ready.
    expect(d.recomputeLabMetrics).toHaveBeenCalledWith("u1", "lab-1", client);
    const readyAt = calls.findIndex((c) => c.table === "lab_results" && (argsOf(c, "update")?.[0] as { status?: string } | undefined)?.status === "ready");
    expect(readyAt).toBeGreaterThan(-1);
    expect(callsBeforeRecompute).toBeGreaterThan(readyAt);

    const updates = calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update")).map((c) => argsOf(c, "update")?.[0]);
    expect(updates[0]).toMatchObject({ patient_context_version_id: "v7", status: "processing", transient_context: { skipped: true, auto_resolved: true } });
    expect(updates[1]).toEqual({ status: "ready" });
  });

  it("a context that cannot be read leaves the lab pending: nothing is stamped or recomputed", async () => {
    const { client, calls } = labDb(bv);
    const d = deps({
      getCurrentVersion: vi.fn(async () => {
        throw new Error("Failed to load patient context: connection reset");
      }) as unknown as AutoResolveDeps["getCurrentVersion"],
    });
    await expect(resolvePendingLab(client, "lab-1", "u1", d)).rejects.toThrow(/connection reset/);
    expect(d.createNewVersion).not.toHaveBeenCalled();
    expect(calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update"))).toHaveLength(0);
    expect(d.recomputeLabMetrics).not.toHaveBeenCalled();
    expect(d.sendEmail).not.toHaveBeenCalled();
  });

  it("stamps the latest version, as the patient's answer that their context is still correct would, even when an older one was in force at arrival", async () => {
    const { client, calls } = fakeSupabase((c) => {
      if (c.table === "biomarker_values") return { data: bv };
      if (c.table === "lab_results" && ops(c).startsWith("update")) return { data: ops(c).includes("select") ? [{ id: "lab-1" }] : null };
      if (c.table === "lab_results" && argsOf(c, "select")?.[0] === "created_at") return { data: { created_at: "2026-10-01T08:00:00Z" } };
      if (c.table === "patient_context_versions") return { data: { id: "v-arrival" } };
      return { data: null };
    });
    const d = deps({ getCurrentVersion: vi.fn(async () => ({ id: "v-later" })) as unknown as AutoResolveDeps["getCurrentVersion"] });
    await resolvePendingLab(client, "lab-1", "u1", d);
    expect(d.getCurrentVersion).toHaveBeenCalledWith("u1", client);
    const stamp = calls.find((c) => c.table === "lab_results" && ops(c).startsWith("update"))!;
    expect(argsOf(stamp, "update")?.[0]).toMatchObject({ patient_context_version_id: "v-later" });
  });

  it("a lab the client claimed first is left to it: nothing is stamped, run, reset or emailed", async () => {
    const { client, calls, lab } = labDb(bv, "processing");
    const d = deps();
    const r = await resolvePendingLab(client, "lab-1", "u1", d);
    expect(r).toEqual({ biomarkerCount: 0, cyclesClosed: [], skipped: true });
    expect(lab.status).toBe("processing");
    const stamp = calls.find((c) => c.table === "lab_results" && ops(c).startsWith("update"))!;
    expect(argsOf(stamp, "eq", "status")).toEqual(["status", "pending_context"]);
    expect(calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update"))).toHaveLength(1);
    expect(d.generateSummary).not.toHaveBeenCalled();
    expect(d.recomputeLabMetrics).not.toHaveBeenCalled();
    expect(d.sendEmail).not.toHaveBeenCalled();
  });

  it("with no saved context it mints an empty version through the admin client", async () => {
    const { client } = labDb(bv);
    const d = deps({ getCurrentVersion: vi.fn(async () => null) as unknown as AutoResolveDeps["getCurrentVersion"] });
    await resolvePendingLab(client, "lab-1", "u1", d);
    expect(vi.mocked(d.createNewVersion).mock.calls[0][0]).toBe("u1");
    expect(vi.mocked(d.createNewVersion).mock.calls[0][2]).toBe(client);
  });

  it("a lab with no biomarker values is not marked ready and no email goes out", async () => {
    const { client, calls } = labDb([]);
    const d = deps();
    await expect(resolvePendingLab(client, "lab-1", "u1", d)).rejects.toThrow(/no biomarker_values/);
    expect(calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update")).map((c) => argsOf(c, "update")?.[0])).not.toContainEqual({ status: "ready" });
    expect(d.sendEmail).not.toHaveBeenCalled();
  });

  it("a recompute that fails does not undo a ready lab: it is reported, and the patient is still told", async () => {
    const { client, calls } = labDb(bv);
    const d = deps({ recomputeLabMetrics: vi.fn(async () => { throw new Error("connection reset"); }) });
    const r = await resolvePendingLab(client, "lab-1", "u1", d);
    expect(r).toEqual({ biomarkerCount: 1, cyclesClosed: ["c4"] });
    expect(calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update")).map((c) => argsOf(c, "update")?.[0])).toContainEqual({ status: "ready" });
    expect(d.sendEmail).toHaveBeenCalled();
  });

  it("a lab with no biomarker values is not recomputed", async () => {
    const { client } = labDb([]);
    const d = deps();
    await expect(resolvePendingLab(client, "lab-1", "u1", d)).rejects.toThrow(/no biomarker_values/);
    expect(d.recomputeLabMetrics).not.toHaveBeenCalled();
  });

  it("a cycle that cannot be closed does not undo a ready lab", async () => {
    const { client } = labDb(bv);
    const d = deps({ completeCycleForLabResult: vi.fn(async () => { throw new Error("boom"); }) as unknown as AutoResolveDeps["completeCycleForLabResult"] });
    const r = await resolvePendingLab(client, "lab-1", "u1", d);
    expect(r.cyclesClosed).toEqual([]);
    expect(d.sendEmail).toHaveBeenCalled();
  });
});
