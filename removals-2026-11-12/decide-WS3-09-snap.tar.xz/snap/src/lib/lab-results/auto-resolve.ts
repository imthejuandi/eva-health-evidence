/**
 * Resolve one lab that sat in pending_context past the 72-hour threshold, on
 * the patient's behalf: stamp their last durable context (or an empty one),
 * run the interpretation, mark the lab ready, recompute its metrics under the
 * stamped context, close its cycle and tell them.
 *
 * Runs under the cron with NO user session, so every helper receives the
 * service-role client explicitly. Before 2026-09-22 the helpers fell back to
 * the cookie-bound client, auth.uid() was NULL, RLS returned nothing and every
 * lab crossed the threshold into 'error' — invisible to the patient and
 * without an email (audit finding F09). Dependencies are injectable so the
 * flow is unit-tested without Gemini, Resend or a database.
 */
import { randomUUID } from "node:crypto";
import { shownAsValueOnly } from "@/lib/biomarkers/lab-reported";
import type { SupabaseClient } from "@supabase/supabase-js";
import { createNewVersion, getCurrentVersion } from "@/lib/patient-context";
import { emptySnapshot } from "@/lib/patient-context/options";
import { generateSummary } from "@/lib/ai/generate-summary";
import { recomputeLabMetrics } from "@/lib/biomarkers/process-results";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { completeCycleForLabResult } from "@/lib/cycles/close-cycle";
import { opsAlert } from "@/lib/ops-alert";
import { labNoteTexts } from "./notes";

export interface AutoResolveDeps {
  getCurrentVersion: typeof getCurrentVersion;
  createNewVersion: typeof createNewVersion;
  getUserProfile: typeof getUserProfile;
  getWearableData: typeof getWearableData;
  generateSummary: typeof generateSummary;
  sendEmail: typeof sendEmail;
  completeCycleForLabResult: typeof completeCycleForLabResult;
  recomputeLabMetrics: (userId: string, labResultId: string, client: SupabaseClient) => Promise<void>;
}

const defaultDeps: AutoResolveDeps = {
  getCurrentVersion,
  createNewVersion,
  getUserProfile,
  getWearableData,
  generateSummary,
  sendEmail,
  completeCycleForLabResult,
  recomputeLabMetrics: (userId, labResultId, client) => recomputeLabMetrics(userId, labResultId, client as never),
};

type Zone = "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high" | "unclassified";

export async function resolvePendingLab(
  admin: SupabaseClient,
  labId: string,
  userId: string,
  deps: AutoResolveDeps = defaultDeps,
  /** Stamped with the claim (transient_context.claim), so the caller can release exactly this claim after a failure. */
  claim: string = randomUUID(),
): Promise<{ biomarkerCount: number; cyclesClosed: string[]; skipped?: true }> {
  // Find or create a context version for this user: the latest, which is
  // what the patient stamps by answering that their context is still correct,
  // so a lab resolved here gets the figure it would have had on that answer.
  // We deliberately do NOT mint a new empty version when one already exists:
  // the last saved version gives the AI more context than nothing. A failed
  // read throws: the lab stays pending for the next run, rather than being
  // stamped, and its biological age recomputed, under an empty context.
  let versionId: string;
  const current = await deps.getCurrentVersion(userId, admin);
  if (current) {
    versionId = current.id;
  } else {
    const created = await deps.createNewVersion(userId, emptySnapshot(), admin);
    versionId = created.id;
  }

  // Claim the lab and stamp the version + skipped transient in one write, only if it is still pending: a client
  // confirming its context claims it the same way (POST /api/lab-results/[id]/context). A lab claimed first by the
  // client, or by another run, is left to it: nothing here runs, and the cron's reset after a failure releases only
  // this claim (transient_context.claim), never the client's or another run's.
  const { data: claimed, error: stampError } = await admin
    .from("lab_results")
    .update({
      patient_context_version_id: versionId,
      transient_context: { skipped: true, auto_resolved: true, claim },
      status: "processing",
    })
    .eq("id", labId)
    .eq("status", "pending_context")
    .select("id");
  if (stampError) throw new Error(`stamp failed: ${stampError.message}`);
  if (!claimed || claimed.length === 0) return { biomarkerCount: 0, cyclesClosed: [], skipped: true };

  // Pull biomarker_values to feed the AI.
  const { data: bvRows, error: bvError } = await admin
    .from("biomarker_values")
    .select("biomarker_key, biomarker_name, value, unit, zone, optimal_low, optimal_high")
    .eq("lab_result_id", labId);
  if (bvError) throw new Error(`load biomarker_values: ${bvError.message}`);
  if (!bvRows || bvRows.length === 0) {
    throw new Error("no biomarker_values to interpret");
  }
  // A laboratory's own eGFR goes to the interpretation as a value only: no category, no interval (lab-reported.ts).
  const processed = (bvRows as Array<Record<string, unknown> & { biomarker_key: string }>).map(shownAsValueOnly).map((b) => ({
    biomarkerKey: String(b.biomarker_key),
    name: String(b.biomarker_name ?? b.biomarker_key),
    value: b.value as number,
    unit: String(b.unit ?? ""),
    zone: ((b.zone as string | null) ?? "unclassified") as Zone,
    zoneLabel: "",
    zoneLabel_es: "",
    optimalLow: (b.optimal_low ?? null) as number | null,
    optimalHigh: (b.optimal_high ?? null) as number | null,
    matchConfidence: "exact" as const,
  }));

  const profile = await deps.getUserProfile(userId, admin);
  if (!profile) throw new Error("profile not found");
  const wearable = await deps.getWearableData(userId, 30, admin);
  const { data: labRow } = await admin.from("lab_results").select("lab_notes").eq("id", labId).maybeSingle();

  await deps.generateSummary(
    userId,
    labId,
    processed,
    wearable.length > 0 ? wearable : null,
    profile,
    admin,
    { labNotes: labNoteTexts((labRow as { lab_notes?: unknown } | null)?.lab_notes) },
  );

  const { error: readyError } = await admin
    .from("lab_results")
    .update({ status: "ready" })
    .eq("id", labId);
  if (readyError) throw new Error(`set ready failed: ${readyError.message}`);

  // The lab was processed on arrival, under the context in force then; the
  // version stamped here may be a later one. Its biological age is recomputed
  // under it (creatine dose included), and the dashboard's rolling average,
  // which reads only ready labs, now includes it. Never fatal.
  await deps.recomputeLabMetrics(userId, labId, admin).catch((e) => {
    opsAlert("cron.auto-resolve", "lab ready but its metrics could not be recomputed", { labId, error: e instanceof Error ? e.message : String(e) });
  });

  // The interpretation is ready: the cycle that produced this result is done.
  const cyclesClosed = await deps.completeCycleForLabResult(admin, labId).catch((e) => {
    opsAlert("cron.auto-resolve", "lab ready but its cycle could not be closed", { labId, error: e instanceof Error ? e.message : String(e) });
    return [] as string[];
  });

  // Tell the user. The email still uses results-ready because the
  // interpretation IS ready — the dashboard banner clarifies that
  // they can refine context to regenerate.
  if (profile.email) {
    const firstName = profile.full_name?.split(" ")[0] ?? "";
    const locale = profile.locale ?? "en";
    deps
      .sendEmail(
        profile.email,
        "results-ready",
        {
          firstName,
          biomarkerCount: processed.length,
          biologicalAge: null,
          baDelta: null,
          longevityScore: null,
          locale,
        },
        locale,
      )
      .catch((err) => console.error("[cron.auto-resolve] email failed:", err));
  }

  return { biomarkerCount: processed.length, cyclesClosed };
}
