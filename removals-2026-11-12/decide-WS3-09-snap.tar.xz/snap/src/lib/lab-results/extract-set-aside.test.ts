/**
 * The upload's extraction names what it sets aside (decision D-24, WS3-27): a result with no readable number is
 * returned for the review instead of being dropped; a result printed with "≤" or "≥" and one whose unit processing
 * will refuse (Lp(a) in nmol/L) come back marked, with no category; and a report in which no result has a readable
 * number ends in an answer that names each one, with no lab left behind. The extraction model, the prompt and the
 * database are stubbed; the reference rows are the reviewed fixture.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall } from "@/lib/testing/fake-supabase";
import { reviewedRows } from "@/lib/biomarkers/__tests__/fixtures/reviewed-rows";

const state = vi.hoisted(() => ({ user: null as unknown, reply: "" }));

vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.user }));
vi.mock("@/lib/ai/prompts", () => ({ getPrompt: async () => ({ model: "stub", content: "extract" }) }));
vi.mock("@google/genai", () => ({
  Type: { OBJECT: "OBJECT", ARRAY: "ARRAY", STRING: "STRING", NUMBER: "NUMBER" },
  GoogleGenAI: class {
    models = { generateContent: async () => ({ candidates: [{ finishReason: "STOP" }], text: state.reply }) };
  },
}));

import { POST as extract } from "@/app/api/lab-results/extract/route";

const ROWS = reviewedRows();

function client() {
  const respond = (c: FakeCall) => {
    if (c.table === "profiles") {
      return { data: { date_of_birth: `${new Date().getFullYear() - 45}-01-01`, sex: "male", subscription_status: "active", total_uploads_used: 0, locale: "es" } };
    }
    if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-1" } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    return { data: null };
  };
  const fake = fakeSupabase(respond);
  return Object.assign(fake.client, {
    calls: fake.calls,
    auth: { getUser: async () => ({ data: { user: { id: "u1" } } }) },
    storage: { from: () => ({ upload: async () => ({ error: null }) }) },
  });
}

function upload(biomarkers: unknown[]) {
  state.reply = JSON.stringify({ collection_date: "2026-11-02", biomarkers });
  const form = new FormData();
  form.append("files", new File(["%PDF-1.4"], "informe.pdf", { type: "application/pdf" }));
  return extract(new NextRequest("http://localhost/api/lab-results/extract", { method: "POST", body: form }));
}

describe("the upload's extraction names what it sets aside", () => {
  let user: ReturnType<typeof client>;
  beforeEach(() => {
    vi.stubEnv("GEMINI_API_KEY", "stub");
    user = client();
    state.user = user;
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  it("an unreadable value is returned as set aside; a \"≥\" result and an Lp(a) in nmol/L come back marked, with no category", async () => {
    const res = await upload([
      { name: "Apolipoproteína B", value: 90, unit: "mg/dL" },
      { name: "Lipoproteína (a)", value: 75, unit: "nmol/L" },
      { name: "Apolipoproteína B", value: 90, comparator: "≥", unit: "mg/dL" },
      { name: "Ferritina", value: "ver comentario", unit: "ng/mL" },
    ]);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.setAside).toEqual([{ name: "Ferritina", reason: "value_unreadable", printed: "ver comentario ng/mL" }]);
    const [apob, lpa, atLeast] = body.extractedBiomarkers;
    expect(body.extractedBiomarkers).toHaveLength(3);
    expect(apob).toMatchObject({ matchedKey: "apolipoprotein_b_apob", signToReview: null, unitRefused: false, expectedUnit: null });
    expect(apob.zone).not.toBeNull();
    expect(lpa).toMatchObject({ value: 75, unit: "nmol/L", unitRefused: true, expectedUnit: "mg/dL", zone: null, implausible: false });
    expect(lpa.matchedKey).not.toBeNull();
    // Printed "≥": no comparator, the printed sign kept, and no category, since the result is not used.
    expect(atLeast).toMatchObject({ value: 90, comparator: null, signToReview: "≥", zone: null, zoneLabel: null });
  });

  it("a report in which no result has a readable number: 422 that names each one, and the empty lab is removed", async () => {
    const res = await upload([
      { name: "Ferritina", value: "ver comentario", unit: "ng/mL" },
      { name: "Glucosa", unit: "mg/dL" },
    ]);
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(body.code).toBe("nothing_usable");
    expect(body.setAside).toEqual([
      { name: "Ferritina", reason: "value_unreadable", printed: "ver comentario ng/mL" },
      { name: "Glucosa", reason: "value_unreadable", printed: "mg/dL" },
    ]);
    expect(user.calls.some((c) => c.table === "lab_results" && ops(c).startsWith("delete"))).toBe(true);
  });
});
