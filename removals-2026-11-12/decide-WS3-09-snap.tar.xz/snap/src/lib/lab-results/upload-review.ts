/**
 * The upload review's rules for a row, apart from the screen that draws them, so they can be tested: which rows are
 * set aside (decision D-24), which still wait for the client, what the sign selector may do, and what is sent to
 * /api/lab-results/confirm.
 *
 * The sign selector never turns a printed "≤" into "<" or "≥" into ">", nor into a plain number. A result the
 * extraction read with "≤" or "≥" keeps that sign and is locked: it is shown as set aside, with the reason, and sent
 * with its printed sign so the server names it and logs it. On any other row the client can correct the sign to what
 * the report prints, including to "≤" or "≥", which sets the row aside in the same way.
 */
import { printedResult, type SetAsideResult } from "./set-aside";

export interface ReviewRow {
  name: string;
  value: number;
  /** "<" or ">" for a bound that can be stored. */
  comparator: "<" | ">" | null;
  /** "≤" or "≥": the result is set aside. */
  signToReview: "≤" | "≥" | null;
  /** True when the extraction read the "≤" or "≥" from the report: the sign cannot be changed at review. */
  signFromReport: boolean;
  unit: string;
  /** True when processing will refuse the unit for the matched marker; cleared when the client picks another marker. */
  unitRefused: boolean;
  expectedUnit: string | null;
  matchedKey: string | null;
  matchConfidence: "exact" | "alias" | "fuzzy" | "user" | "none";
  confirmed: boolean;
  skip: boolean;
  implausible: boolean;
}

export type ReviewSign = "" | "<" | ">" | "≤" | "≥";

/** The reason a row is set aside at review, or null when it is not. */
export function rowSetAside(row: ReviewRow): SetAsideResult | null {
  if (row.signToReview) {
    return {
      name: row.name,
      reason: "sign_not_storable",
      printed: printedResult(row.value, row.signToReview, row.unit),
      sign: row.signToReview,
    };
  }
  if (row.unitRefused && row.matchedKey) {
    return {
      name: row.name,
      reason: "unit_not_convertible",
      printed: printedResult(row.value, row.comparator, row.unit),
      unit: row.unit,
      expectedUnit: row.expectedUnit,
    };
  }
  return null;
}

/** A row that will be saved: matched, confirmed, plausible, not skipped and not set aside. */
export function rowReady(row: ReviewRow): boolean {
  return !row.skip && !!row.matchedKey && row.confirmed && !row.implausible && !rowSetAside(row);
}

/**
 * A row that still waits for the client and blocks the save: unmatched, unconfirmed or implausible. A result printed
 * with "≤" or "≥" waits for nothing: it is not used whatever marker it is. A result with a refused unit is refused
 * for the marker it is matched to, so an approximate match is still confirmed first.
 */
export function rowNeedsAction(row: ReviewRow): boolean {
  if (row.skip || row.signToReview) return false;
  return !row.matchedKey || !row.confirmed || row.implausible;
}

/** The signs the selector offers for a row: the printed sign alone when it came from the report as "≤" or "≥". */
export function signChoices(row: ReviewRow): ReviewSign[] {
  if (row.signFromReport && row.signToReview) return [row.signToReview];
  return ["", "<", ">", "≤", "≥"];
}

/** The row after the client chooses a sign. A choice the selector does not offer for the row changes nothing. */
export function chooseRowSign<T extends ReviewRow>(row: T, sign: string): T {
  if (!(signChoices(row) as string[]).includes(sign)) return row;
  if (sign === "≤" || sign === "≥") return { ...row, comparator: null, signToReview: sign };
  return { ...row, comparator: sign === "<" || sign === ">" ? sign : null, signToReview: null };
}

export interface ConfirmRow {
  name: string;
  value: number;
  comparator?: string;
  unit: string;
  biomarkerKey: string;
  matchConfidence: "exact" | "alias" | "fuzzy" | "user";
}

/**
 * The rows sent to confirm: every ready row, and every set-aside row the client did not skip, a "≤" or "≥" result
 * with its printed sign, so the server sets it aside itself, names it in its answer and logs it. Rows that wait for
 * the client are not sent (the save is blocked while any does).
 */
export function rowsToConfirm(rows: readonly ReviewRow[]): ConfirmRow[] {
  return rows
    .filter((row) => !row.skip && !rowNeedsAction(row))
    .map((row) => {
      const sign = row.signToReview ?? row.comparator;
      return {
        name: row.name,
        value: row.value,
        ...(sign ? { comparator: sign } : {}),
        unit: row.unit,
        biomarkerKey: row.matchedKey ?? "",
        matchConfidence: row.matchConfidence === "none" ? "user" : row.matchConfidence,
      };
    });
}
