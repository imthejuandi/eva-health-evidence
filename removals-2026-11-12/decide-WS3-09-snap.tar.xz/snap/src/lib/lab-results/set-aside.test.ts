/**
 * The sentences for a result EVA does not use (decisions D-24 and D-37, WS3-27): written once in wording-rules.md
 * section 7, in the Spanish of Part I and the English of Part II, and rendered from there by reason code. These tests
 * hold the generated module to the document (the generator's --check), hold every sentence to the document's own
 * banned-terms block with check M3's functions, and render each reason in both languages.
 */
import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { SET_ASIDE_COPY } from "./set-aside-copy.generated";
import {
  printedResult,
  SET_ASIDE_REASONS,
  setAsideLocale,
  setAsideNotice,
  setAsideSentence,
  setAsideTag,
  setAsideText,
  type SetAsideResult,
} from "./set-aside";
import { buildSetAsideCopyModule, MODULE_FILE, readSetAsideCopy, RULES_FILE } from "../../../scripts/wording/set-aside-copy";
import { lexiconHits, parseLexicon } from "../../../scripts/signoff/checks/messages";

const ROOT = path.resolve(__dirname, "../../..");
const RULES = fs.readFileSync(path.join(ROOT, RULES_FILE), "utf8");
const LANGS = ["en", "es"] as const;

const EXAMPLES: Record<string, SetAsideResult> = {
  sign_not_storable: { name: "PCR ultrasensible", reason: "sign_not_storable", printed: "≤5 mg/L", sign: "≤" },
  unit_not_convertible: { name: "Lipoproteína (a)", reason: "unit_not_convertible", printed: "75 nmol/L", unit: "nmol/L", expectedUnit: "mg/dL" },
  value_unreadable: { name: "Ferritina", reason: "value_unreadable", printed: "pendiente ng/mL" },
  marker_not_recognised: { name: "mystery", reason: "marker_not_recognised", printed: "1 x" },
};

describe("the set-aside sentences come from wording-rules.md section 7", () => {
  it("the generated module is exactly what the generator builds from the document (--check)", () => {
    expect(fs.readFileSync(path.join(ROOT, MODULE_FILE), "utf8")).toBe(buildSetAsideCopyModule(RULES));
  });

  it("each language's table sits in section 7 of its own part: Spanish in Part I, English in Part II", () => {
    const section = (heading: string, next: string) => RULES.slice(RULES.indexOf(heading), RULES.indexOf(next));
    const es = section("### 7. Puntuación EVA", "### 8. Edad biológica");
    const en = section("### 7. EVA score", "### 8. Biological age");
    for (const [text, copy] of [[es, SET_ASIDE_COPY.es], [en, SET_ASIDE_COPY.en]] as const) {
      for (const sentence of [copy.heading, copy.tag, copy.intro_some, copy.intro_all, ...Object.values(copy.reasons)]) {
        expect(text).toContain(`| ${sentence} |`);
      }
    }
  });

  it("the generator refuses a table that lacks a code, repeats one, or uses the wrong placeholders", () => {
    const line = "| `set_aside.reason.value_unreadable` | EVA could not read a number in this result as it appears in the report, so it does not use it. |";
    expect(RULES).toContain(line);
    expect(() => readSetAsideCopy(RULES.replace(line, ""))).toThrow(/en table lacks set_aside\.reason\.value_unreadable/);
    expect(() => readSetAsideCopy(RULES.replace(line, `${line}\n${line}`))).toThrow(/appears twice/);
    expect(() => readSetAsideCopy(RULES.replace("con el signo «{sign}»", "con ese signo"))).toThrow(/set_aside\.reason\.sign_not_storable \(es\) must use the placeholders \{sign\}/);
  });

  it("a changed sentence in the document changes the module, so the --check fails until it is regenerated", () => {
    const changed = RULES.replace("| `set_aside.tag` | No se usa |", "| `set_aside.tag` | No usado |");
    expect(changed).not.toBe(RULES);
    expect(buildSetAsideCopyModule(changed)).not.toBe(buildSetAsideCopyModule(RULES));
    expect(buildSetAsideCopyModule(changed)).toContain('tag: "No usado"');
  });

  it("no sentence carries a banned term of the document's own block (check M3's rules: any tier and non-critical tier)", () => {
    const lexicon = parseLexicon(RULES);
    expect(lexicon).not.toBeNull();
    for (const lang of LANGS) {
      const rules = ["any", "non_critical"].map((tier) => lexicon!.langs[lang][tier]);
      expect(rules.every(Boolean)).toBe(true);
      const copy = SET_ASIDE_COPY[lang];
      const rendered = Object.values(EXAMPLES).map((e) => setAsideSentence(e, lang));
      for (const text of [copy.heading, copy.tag, copy.intro_some, copy.intro_all, ...rendered]) {
        expect(lexiconHits(text, rules, lexicon!.flags), text).toEqual([]);
      }
    }
  });
});

describe("rendering a set-aside result by its reason code", () => {
  it("every reason has an example here, and renders in both languages with no placeholder left", () => {
    expect(Object.keys(EXAMPLES).sort()).toEqual([...SET_ASIDE_REASONS].sort());
    for (const lang of LANGS) {
      for (const example of Object.values(EXAMPLES)) {
        const sentence = setAsideSentence(example, lang);
        expect(sentence).not.toMatch(/[{}]/);
        expect(sentence.length).toBeGreaterThan(20);
      }
    }
    expect(setAsideSentence(EXAMPLES.sign_not_storable, "es")).toBe(
      "El informe da este resultado con el signo «≤». EVA todavía no puede guardar un resultado con ese signo y no lo cambia por otro, así que no usa este resultado.",
    );
    expect(setAsideSentence(EXAMPLES.unit_not_convertible, "en")).toBe(
      "The report gives this result in nmol/L. EVA's ranges for this marker are in mg/dL and EVA has no conversion between the two units, so it does not use this result.",
    );
  });

  it("Spanish for es and its regional forms, English for anything else", () => {
    expect(["es", "es-ES", "ES"].map(setAsideLocale)).toEqual(["es", "es", "es"]);
    expect(["en", "fr", "", null, undefined].map(setAsideLocale)).toEqual(["en", "en", "en", "en", "en"]);
    expect(setAsideTag("es")).toBe(SET_ASIDE_COPY.es.tag);
  });

  it("the notice says whether the rest was saved or nothing was, and names each result with what was printed", () => {
    const items = [EXAMPLES.sign_not_storable, EXAMPLES.unit_not_convertible];
    const some = setAsideNotice(items, "es", false)!;
    expect(some.heading).toBe(SET_ASIDE_COPY.es.heading);
    expect(some.intro).toBe(SET_ASIDE_COPY.es.intro_some);
    expect(some.items.map((i) => [i.name, i.printed])).toEqual([["PCR ultrasensible", "≤5 mg/L"], ["Lipoproteína (a)", "75 nmol/L"]]);
    expect(some.items[1].sentence).toBe(setAsideSentence(items[1], "es"));
    expect(setAsideNotice(items, "en", true)!.intro).toBe(SET_ASIDE_COPY.en.intro_all);
    expect(setAsideNotice([], "en", false)).toBeNull();
    expect(setAsideText([], "en", true)).toBe("");
    expect(setAsideText(items, "en", true).split("\n")).toEqual([
      `${SET_ASIDE_COPY.en.heading}. ${SET_ASIDE_COPY.en.intro_all}`,
      `- PCR ultrasensible (≤5 mg/L): ${setAsideSentence(items[0], "en")}`,
      `- Lipoproteína (a) (75 nmol/L): ${setAsideSentence(items[1], "en")}`,
    ]);
  });

  it("a result is shown as it was given: the sign beside a number in its printed form, text as written", () => {
    expect(printedResult(5, "≤", "mg/L")).toBe("≤5 mg/L");
    expect(printedResult(5, ">=", "mg/L")).toBe("≥5 mg/L");
    expect(printedResult("≥ 5,0", "≥", "mg/L")).toBe("≥ 5,0 mg/L");
    expect(printedResult(5.4, null, "%")).toBe("5.4 %");
    expect(printedResult(5.4, "=", "")).toBe("5.4");
    expect(printedResult("pendiente", undefined, undefined)).toBe("pendiente");
    expect(printedResult(null, null, "U/L")).toBe("U/L");
    expect(printedResult("x".repeat(200), null, "")).toHaveLength(60);
  });
});
