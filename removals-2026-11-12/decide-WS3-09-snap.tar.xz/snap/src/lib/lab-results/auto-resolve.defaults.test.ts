/**
 * The 72-hour cron calls resolvePendingLab with its default dependencies (src/app/api/cron/auto-resolve-pending-context
 * route). Those must recompute the lab's metrics with process-results' recomputeLabMetrics, the admin client and the
 * lab's own ids, after the lab is ready. The AI summary, the email and the cycle closing are stubbed.
 */
import { describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops } from "@/lib/testing/fake-supabase";

const state = vi.hoisted(() => ({ order: [] as string[] }));

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("RLS client must not be created under the cron");
  },
}));
vi.mock("@/lib/biomarkers/process-results", () => ({
  recomputeLabMetrics: vi.fn(async () => {
    state.order.push("recompute");
  }),
}));
vi.mock("@/lib/ai/generate-summary", () => ({ generateSummary: vi.fn(async () => undefined) }));
vi.mock("@/lib/queries", () => ({
  getUserProfile: vi.fn(async () => ({ id: "u1", email: "p@example.test", full_name: "Ana Prueba", locale: "es" })),
  getWearableData: vi.fn(async () => []),
}));
vi.mock("@/lib/email/send", () => ({ sendEmail: vi.fn(async () => undefined) }));
vi.mock("@/lib/cycles/close-cycle", () => ({ completeCycleForLabResult: vi.fn(async () => []) }));
vi.mock("@/lib/patient-context", () => ({
  getCurrentVersion: vi.fn(async () => ({ id: "v7" })),
  createNewVersion: vi.fn(async () => ({ id: "v-new" })),
}));

import { resolvePendingLab } from "./auto-resolve";
import { recomputeLabMetrics } from "@/lib/biomarkers/process-results";

describe("resolvePendingLab with its default dependencies", () => {
  it("recomputes the lab with process-results' recomputeLabMetrics, the admin client, after the lab is ready", async () => {
    const bv = [{ biomarker_key: "albumin", biomarker_name: "Albúmina", value: 4.4, unit: "g/dL", zone: "optimal", optimal_low: 3.5, optimal_high: 5 }];
    const { client } = fakeSupabase((c) => {
      if (c.table === "lab_results" && ops(c).startsWith("update") && (argsOf(c, "update")?.[0] as { status?: string }).status === "ready") {
        state.order.push("ready");
      }
      // The claim: the lab is still pending.
      if (c.table === "lab_results" && ops(c).startsWith("update") && ops(c).includes("select")) return { data: [{ id: "lab-1" }] };
      return c.table === "biomarker_values" ? { data: bv } : { data: null };
    });
    await resolvePendingLab(client, "lab-1", "u1");
    expect(recomputeLabMetrics).toHaveBeenCalledWith("u1", "lab-1", client);
    expect(state.order).toEqual(["ready", "recompute"]);
  });
});
