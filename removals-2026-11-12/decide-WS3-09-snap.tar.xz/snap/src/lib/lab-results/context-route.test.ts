/**
 * POST /api/lab-results/[id]/context on a lab from EVA's laboratory (pending_context). The lab was processed on
 * arrival under the context in force then; the client now confirms a context that declares creatine 5 g/day. Once
 * the lab is ready, its biological age (both KDM figures and version 3) is recomputed under the confirmed context,
 * and the dashboard's rolling average, which reads only ready labs, includes it.
 *
 * The route and recomputeLabMetrics run for real on a scripted database (fake-supabase) that keeps the lab's status
 * and recorded context; the AI summary, the email and the cycle closing are stubbed.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { computeComprehensiveBA, computeReferenceBA, KDM_REFERENCE_BA_METHOD } from "@/lib/biomarkers/biological-age-kdm";
import { calculateAge } from "@/lib/biomarkers/zone-classifier";
import { getCanonicalUnit } from "@/lib/biomarkers/canonical-units";
import { LAB_STATE_LAB_COLUMNS } from "@/lib/patient-context/physiological-state";

const state = vi.hoisted(() => ({
  client: null as unknown,
  adminCalls: [] as Array<{ table: string; ops: { op: string; args: unknown[] }[] }>,
}));

vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.client }));
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return {
    createAdminClient: () =>
      fakeSupabase((c) => {
        state.adminCalls.push(c);
        return { data: null };
      }).client,
  };
});
vi.mock("@/lib/ai/generate-summary", () => ({ generateSummary: vi.fn(async () => undefined) }));
vi.mock("@/lib/queries", () => ({
  getUserProfile: vi.fn(async () => ({ id: "u1", full_name: "Ana Prueba", locale: "es" })),
  getWearableData: vi.fn(async () => []),
}));
vi.mock("@/lib/email/send", () => ({ sendEmail: vi.fn(async () => undefined) }));
vi.mock("@/lib/cycles/close-cycle", () => ({ completeCycleForLabResult: vi.fn(async () => []) }));
vi.mock("@/lib/ops-alert", () => ({ opsAlert: vi.fn() }));

import { POST } from "@/app/api/lab-results/[id]/context/route";
import { generateSummary } from "@/lib/ai/generate-summary";
import { sendEmail } from "@/lib/email/send";
import { opsAlert } from "@/lib/ops-alert";

const LAB = "11111111-1111-4111-8111-111111111111";
const V1 = "22222222-2222-4222-8222-222222222221";
const V2 = "22222222-2222-4222-8222-222222222222";
const DOB = "1981-03-15";
const TODAY = new Date().toISOString().slice(0, 10);
const ARRIVED = `${TODAY}T08:00:00Z`;

// The Base Panel of the typical man (docs/biomarker-evidence/longevity/base-panel/panels.json), creatinine raised 13%
// by creatine.
const VALUES: Record<string, number> = {
  albumin: 44, creatinine: 1.13, bun: 15, uric_acid: 6, alp: 72, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47,
  triglycerides: 140, hs_crp: 1.8, apolipoprotein_b_apob: 105, alt: 30, fructosamine: 200,
};
const VERSIONS = [
  { id: V1, version_number: 1, created_at: "2026-01-05T09:00:00Z", supplements: [], conditions: { keys: [] } },
  { id: V2, version_number: 2, created_at: `${TODAY}T09:00:00Z`, supplements: [{ key: "creatine", dose: "5 g" }], conditions: { keys: [] } },
];

function database(options: { failContextRead?: boolean; failReady?: boolean; failRelease?: boolean; releaseMatchesNothing?: boolean } = {}) {
  const lab = { status: "pending_context", patient_context_version_id: null as string | null };
  const valueRows = Object.entries(VALUES).map(([biomarker_key, value]) => ({
    lab_result_id: LAB, biomarker_key, biomarker_name: biomarker_key, value, unit: getCanonicalUnit(biomarker_key),
    zone: "optimal", optimal_low: null, optimal_high: null, comparator: null, normal_low: null,
  }));
  const respond = (c: FakeCall): FakeResponse => {
    const select = String(argsOf(c, "select")?.[0] ?? "");
    const op = ops(c);
    if (c.table === "lab_results" && op.startsWith("update")) {
      if (options.failReady && (argsOf(c, "update")?.[0] as { status?: string }).status === "ready") {
        return { error: { message: "connection reset" } };
      }
      if (options.failRelease && (argsOf(c, "update")?.[0] as { status?: string }).status === "pending_context") {
        return { error: { message: "connection reset" } };
      }
      // The lab left processing before the release (no error, no row changed).
      if (options.releaseMatchesNothing && (argsOf(c, "update")?.[0] as { status?: string }).status === "pending_context") {
        return { data: op.includes("select") ? [] : null };
      }
      // A conditional update (.eq("status", ...)) changes the row only when the lab is in that status.
      const onlyIf = argsOf(c, "eq", "status")?.[1];
      if (onlyIf !== undefined && onlyIf !== lab.status) return { data: op.includes("select") ? [] : null };
      Object.assign(lab, argsOf(c, "update")?.[0] as object);
      return { data: op.includes("select") ? [{ id: LAB }] : null };
    }
    if (c.table === "lab_results" && select === LAB_STATE_LAB_COLUMNS && options.failContextRead) {
      return { error: { message: "connection reset" } };
    }
    if (c.table === "lab_results") {
      const row = { id: LAB, user_id: "u1", collection_date: TODAY, created_at: ARRIVED, source: "echevarne", lab_notes: [], ...lab };
      if (select === "id, collection_date, created_at") return { data: [] }; // version 3: no other result
      if (argsOf(c, "eq", "status")) {
        const ready = lab.status === "ready" ? [row] : [];
        return { data: op.endsWith("maybeSingle") ? (ready[0] ?? null) : ready };
      }
      return { data: row };
    }
    if (c.table === "patient_context_versions") {
      const id = argsOf(c, "eq", "id")?.[1];
      if (id) return { data: VERSIONS.find((v) => v.id === id) ?? null };
      const cutoff = argsOf(c, "lte", "created_at")?.[1] as string | undefined;
      const inForce = VERSIONS.filter((v) => !cutoff || v.created_at <= cutoff);
      return { data: op.endsWith("maybeSingle") ? (inForce[inForce.length - 1] ?? null) : inForce };
    }
    if (c.table === "biomarker_values") return { data: valueRows };
    if (c.table === "profiles" && op.startsWith("select")) return { data: { date_of_birth: DOB, sex: "male" } };
    return { data: null };
  };
  const { client, calls } = fakeSupabase(respond);
  return { client: Object.assign(client, { auth: { getUser: async () => ({ data: { user: { id: "u1", email: "u1@example.test" } } }) } }), calls, lab };
}

const confirm = () =>
  POST(
    new NextRequest(`http://localhost/api/lab-results/${LAB}/context`, {
      method: "POST",
      body: JSON.stringify({ contextVersionId: V2, transientContext: {} }),
    }),
    { params: Promise.resolve({ id: LAB }) },
  );

const asInputs = (values: Record<string, number>) => Object.entries(values).map(([code, value]) => ({ code, value }));
const CREATINE_5G = { supplements: [{ key: "creatine", dose: "5 g" }] };

describe("confirming the context of a lab from EVA's laboratory", () => {
  let db: ReturnType<typeof database>;
  beforeEach(() => {
    db = database();
    state.client = db.client;
    state.adminCalls = [];
    vi.mocked(sendEmail).mockClear();
    vi.mocked(opsAlert).mockClear();
  });

  it("recomputes the lab's biological age under the confirmed context, once the lab is ready", async () => {
    const res = await confirm();
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true, ran_pipeline: true });
    expect(db.lab).toMatchObject({ status: "ready", patient_context_version_id: V2 });

    const labUpdates = db.calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update"));
    // One write claims the lab and stamps its context, only if it is still pending.
    expect(argsOf(labUpdates[0], "update")?.[0]).toEqual({ status: "processing", patient_context_version_id: V2, transient_context: {} });
    expect(argsOf(labUpdates[0], "eq", "status")).toEqual(["status", "pending_context"]);
    const readyAt = db.calls.findIndex((c) => (argsOf(c, "update")?.[0] as { status?: string } | undefined)?.status === "ready");
    const metrics = labUpdates.find((c) => "biological_age" in (argsOf(c, "update")?.[0] as object));
    expect(metrics, "recomputeLabMetrics stored the biological age").toBeDefined();
    expect(db.calls.indexOf(metrics!)).toBeGreaterThan(readyAt);

    // The confirmed 5 g/day: creatinine 1.13 reads as 1.00.
    const age = calculateAge(DOB);
    const stored = argsOf(metrics!, "update")?.[0] as Record<string, unknown>;
    const reference = computeReferenceBA(asInputs(VALUES), "male", age, CREATINE_5G)!;
    expect(stored.biological_age).toBe(reference.BA);
    expect(stored.bio_age_method).toBe(KDM_REFERENCE_BA_METHOD);
    expect(stored.biological_age_comprehensive).toBe(computeComprehensiveBA(asInputs(VALUES), "male", age, CREATINE_5G)!.BA);
    expect(reference.BA).toBeLessThan(computeReferenceBA(asInputs(VALUES), "male", age, { supplements: [] })!.BA);

    // Version 3 under the same context.
    const shadow = state.adminCalls.find((c) => c.table === "bio_age_v3_shadow");
    const record = (argsOf(shadow!, "upsert")?.[0] as { record: Record<string, unknown> }).record;
    expect(record).toMatchObject({ creatine_g_per_day: 5, creatinine_divisor: expect.closeTo(1.13, 10) });

    // The dashboard's rolling average now includes this lab, its creatinine adjusted for 5 g/day.
    const cache = db.calls.filter((c) => c.table === "profiles" && ops(c).startsWith("update")).pop()!;
    const cached = argsOf(cache, "update")?.[0] as Record<string, unknown>;
    const adjusted = asInputs({ ...VALUES, creatinine: 1.13 / 1.13 });
    expect(cached.current_ba).toBe(Number(computeComprehensiveBA(adjusted, "male", age, { supplements: null })!.BA.toFixed(2)));
    expect(cached.current_ba_n_labs_averaged).toBe(1);
  });

  it("a recompute that fails on a read keeps the lab ready, and the dashboard still includes the lab", async () => {
    db = database({ failContextRead: true });
    state.client = db.client;
    const quiet = vi.spyOn(console, "error").mockImplementation(() => {});
    const res = await confirm();
    expect(res.status).toBe(200);
    expect(db.lab.status).toBe("ready");
    // No figure is stored from a context that could not be read...
    expect(db.calls.some((c) => c.table === "lab_results" && "biological_age" in ((argsOf(c, "update")?.[0] as object) ?? {}))).toBe(false);
    // ...and the dashboard cache is refreshed with the lab in it.
    const cache = db.calls.filter((c) => c.table === "profiles" && ops(c).startsWith("update")).pop();
    expect(cache, "profiles.current_ba refreshed").toBeDefined();
    expect((argsOf(cache!, "update")?.[0] as Record<string, unknown>).current_ba_n_labs_averaged).toBe(1);
    quiet.mockRestore();
  });

  it.each(["ready", "processing", "error"])("a lab in %s is refused: no new context is stamped on figures computed under another", async (status) => {
    db.lab.status = status;
    const res = await confirm();
    expect(res.status).toBe(409);
    expect(db.lab).toMatchObject({ status, patient_context_version_id: null });
    expect(db.calls.some((c) => c.table === "lab_results" && ops(c).startsWith("update"))).toBe(false);
    expect(state.adminCalls.some((c) => c.table === "bio_age_v3_shadow")).toBe(false);
  });

  it("a lab the cron claims first is refused, and nothing is stamped", async () => {
    // The lab reads as pending, then the cron takes it before the claim.
    const read = db.calls.length;
    const original = db.client.from.bind(db.client);
    db.client.from = ((table: string) => {
      if (table === "lab_results" && db.calls.length > read + 1) db.lab.status = "processing";
      return original(table);
    }) as typeof db.client.from;
    const res = await confirm();
    expect(res.status).toBe(409);
    expect(db.lab.patient_context_version_id).toBeNull();
  });

  it("a lab that cannot be marked ready goes back to pending_context: no recompute, and no email says it is ready", async () => {
    db = database({ failReady: true });
    state.client = db.client;
    const quiet = vi.spyOn(console, "error").mockImplementation(() => {});
    const res = await confirm();
    expect(res.status).toBe(500);
    expect(db.lab.status).toBe("pending_context");
    expect(db.calls.some((c) => c.table === "lab_results" && "biological_age" in ((argsOf(c, "update")?.[0] as object) ?? {}))).toBe(false);
    expect(sendEmail).not.toHaveBeenCalled();
    quiet.mockRestore();
  });

  it("the alert says whether a failed lab really went back to pending_context", async () => {
    const quiet = vi.spyOn(console, "error").mockImplementation(() => {});
    db = database({ failReady: true });
    state.client = db.client;
    await confirm();
    expect(db.lab.status).toBe("pending_context");
    expect(vi.mocked(opsAlert).mock.calls.at(-1)?.[1]).toMatch(/back to pending_context/);

    db = database({ failReady: true, failRelease: true });
    state.client = db.client;
    await confirm();
    expect(db.lab.status).toBe("processing");
    expect(vi.mocked(opsAlert).mock.calls.at(-1)?.[1]).toMatch(/left in processing: reprocess it from \/admin/);
    expect(vi.mocked(opsAlert).mock.calls.at(-1)?.[2]).toMatchObject({ releaseError: "connection reset" });

    db = database({ failReady: true, releaseMatchesNothing: true });
    state.client = db.client;
    await confirm();
    expect(vi.mocked(opsAlert).mock.calls.at(-1)?.[1]).toMatch(/left in processing/);
    quiet.mockRestore();
  });

  it("a pipeline that fails puts the lab back to pending_context, where the client or the cron can retry", async () => {
    vi.mocked(generateSummary).mockRejectedValueOnce(new Error("503 from the model"));
    const quiet = vi.spyOn(console, "error").mockImplementation(() => {});
    const res = await confirm();
    expect(res.status).toBe(500);
    expect(db.lab.status).toBe("pending_context");
    quiet.mockRestore();
  });
});
