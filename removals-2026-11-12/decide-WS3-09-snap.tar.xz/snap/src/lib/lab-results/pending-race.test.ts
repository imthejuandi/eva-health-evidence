/**
 * A lab from EVA's laboratory waiting for its context can be resolved by the client (POST /api/lab-results/[id]/context)
 * or, after 72 hours, by the cron (GET /api/cron/auto-resolve-pending-context). Only one of them may resolve it. Both
 * routes and resolvePendingLab run for real on one scripted database (fake-supabase) shared by the client's session
 * and the cron's service-role client; the AI summary, the email, the cycle closing and the metric recompute are
 * stubbed.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";

const state = vi.hoisted(() => ({ server: null as unknown, admin: null as unknown }));
vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.server }));
vi.mock("@/lib/supabase/admin", () => ({ createAdminClient: () => state.admin }));
vi.mock("@/lib/patient-context", async (importOriginal) => ({
  ...(await importOriginal<object>()),
  getCurrentVersion: vi.fn(),
  createNewVersion: vi.fn(async () => ({ id: "v-new" })),
}));
vi.mock("@/lib/ai/generate-summary", () => ({ generateSummary: vi.fn() }));
vi.mock("@/lib/queries", () => ({
  getUserProfile: vi.fn(async () => ({ id: "u1", email: "u1@example.test", full_name: "Ana Prueba", locale: "es" })),
  getWearableData: vi.fn(async () => []),
}));
vi.mock("@/lib/email/send", () => ({ sendEmail: vi.fn(async () => undefined) }));
vi.mock("@/lib/cycles/close-cycle", () => ({ completeCycleForLabResult: vi.fn(async () => []) }));
vi.mock("@/lib/biomarkers/process-results", () => ({ recomputeLabMetrics: vi.fn(async () => undefined) }));
vi.mock("@/lib/ops-alert", () => ({ opsAlert: vi.fn() }));

import { POST as confirm } from "@/app/api/lab-results/[id]/context/route";
import { GET as cron } from "@/app/api/cron/auto-resolve-pending-context/route";
import { getCurrentVersion } from "@/lib/patient-context";
import { generateSummary } from "@/lib/ai/generate-summary";
import { sendEmail } from "@/lib/email/send";
import { opsAlert } from "@/lib/ops-alert";

const LAB = "11111111-1111-4111-8111-111111111111";
const V2 = "22222222-2222-4222-8222-222222222222";

/** One lab in pending_context. Conditional updates (.eq on status, or on a transient_context->>key) apply only when they hold. */
function database(options: { noValues?: boolean } = {}) {
  const lab: Record<string, unknown> = {
    id: LAB, user_id: "u1", status: "pending_context", patient_context_version_id: null, transient_context: null,
    created_at: "2026-10-20T08:00:00Z", collection_date: "2026-10-19", lab_notes: [],
  };
  const history: string[] = [];
  const respondAs = (actor: "client" | "cron") => (c: FakeCall): FakeResponse => {
    const op = ops(c);
    if (c.table === "lab_results" && op.startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      const onlyIfStatus = argsOf(c, "eq", "status")?.[1];
      const transientFilters = c.ops.filter((o) => o.op === "eq" && String(o.args[0]).startsWith("transient_context->>"));
      const transient = (lab.transient_context ?? {}) as Record<string, unknown>;
      const transientHolds = transientFilters.every((o) => String(transient[String(o.args[0]).slice("transient_context->>".length)] ?? "") === o.args[1]);
      if ((onlyIfStatus !== undefined && onlyIfStatus !== lab.status) || !transientHolds) {
        return { data: op.includes("select") ? [] : null };
      }
      Object.assign(lab, update);
      if (update.status) history.push(`${actor}: ${update.status}`);
      return { data: op.includes("select") ? [{ id: LAB }] : null };
    }
    if (c.table === "lab_results" && op.startsWith("select")) {
      const status = argsOf(c, "eq", "status")?.[1];
      if (argsOf(c, "select")?.[0] === "id") return { count: lab.status === "pending_context" ? 1 : 0 }; // the cron's backlog
      if (status !== undefined) return { data: lab.status === status ? [{ ...lab }] : [] }; // the cron's list
      return { data: { ...lab } };
    }
    if (c.table === "patient_context_versions") return { data: actor === "client" ? { id: V2, user_id: "u1" } : null };
    if (c.table === "biomarker_values") {
      return {
        data: options.noValues
          ? []
          : [{ biomarker_key: "albumin", biomarker_name: "Albúmina", value: 44, unit: "g/L", zone: "optimal", optimal_low: 40, optimal_high: 50 }],
      };
    }
    return { data: null };
  };
  const server = fakeSupabase(respondAs("client")).client;
  Object.assign(server, { auth: { getUser: async () => ({ data: { user: { id: "u1", email: "u1@example.test" } } }) } });
  state.server = server;
  state.admin = fakeSupabase(respondAs("cron")).client;
  return { lab, history };
}

function deferred<T>() {
  let resolve!: (v: T) => void;
  let reject!: (e: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

const confirmRequest = () =>
  [
    new NextRequest(`http://localhost/api/lab-results/${LAB}/context`, {
      method: "POST",
      body: JSON.stringify({ contextVersionId: V2, transientContext: {} }),
    }),
    { params: Promise.resolve({ id: LAB }) },
  ] as const;
const cronRequest = () =>
  new NextRequest("http://localhost/api/cron/auto-resolve-pending-context", { headers: { authorization: "Bearer s3cret" } });

describe("the client and the 72-hour cron never both resolve one lab", () => {
  beforeEach(() => {
    process.env.CRON_SECRET = "s3cret";
    vi.mocked(generateSummary).mockReset();
    vi.mocked(getCurrentVersion).mockReset();
    vi.mocked(sendEmail).mockClear();
    vi.mocked(opsAlert).mockClear();
    vi.spyOn(console, "error").mockImplementation(() => {});
    vi.spyOn(console, "log").mockImplementation(() => {});
  });
  afterEach(() => vi.restoreAllMocks());

  it("a cron run that fails before its claim leaves the client's claim alone: one AI run, one email", async () => {
    const db = database();
    const firstAi = deferred<void>();
    vi.mocked(generateSummary).mockImplementationOnce(() => firstAi.promise).mockImplementation(async () => undefined);
    const versionRead = deferred<{ id: string }>();
    vi.mocked(getCurrentVersion).mockImplementation(() => versionRead.promise as never);

    // The cron lists the lab while it is pending; the client then claims it and waits on its AI step.
    const cronRun = cron(cronRequest());
    await vi.waitFor(() => expect(getCurrentVersion).toHaveBeenCalled());
    const first = confirm(...confirmRequest());
    await vi.waitFor(() => expect(generateSummary).toHaveBeenCalledTimes(1));
    // The cron's read fails before its own claim: its reset must not release the client's lab.
    versionRead.reject(new Error("Failed to load patient context: connection reset"));
    const cronBody = await (await cronRun).json();
    expect(cronBody.results).toEqual([expect.objectContaining({ id: LAB, ok: false })]);
    expect(db.lab.status).toBe("processing");
    expect((await confirm(...confirmRequest())).status).toBe(409);

    firstAi.resolve();
    expect((await first).status).toBe(200);
    expect(db.lab).toMatchObject({ status: "ready", patient_context_version_id: V2 });
    expect(generateSummary).toHaveBeenCalledTimes(1);
    expect(sendEmail).toHaveBeenCalledTimes(1);
    expect(db.history).toEqual(["client: processing", "client: ready"]);
  });

  it("of two overlapping cron runs, one that fails before its claim leaves the other run's claim alone", async () => {
    const db = database();
    const runBRead = deferred<{ id: string }>();
    const runAAi = deferred<void>();
    vi.mocked(getCurrentVersion)
      .mockImplementationOnce(() => runBRead.promise as never)
      .mockImplementation(async () => ({ id: "v-latest" }) as never);
    vi.mocked(generateSummary).mockImplementationOnce(() => runAAi.promise);

    // Run B lists the lab and waits on its context read; run A lists it too, claims it and waits on its AI step.
    const runB = cron(cronRequest());
    await vi.waitFor(() => expect(getCurrentVersion).toHaveBeenCalledTimes(1));
    const runA = cron(cronRequest());
    await vi.waitFor(() => expect(generateSummary).toHaveBeenCalledTimes(1));
    runBRead.reject(new Error("Failed to load patient context: connection reset"));
    expect((await (await runB).json()).results).toEqual([expect.objectContaining({ id: LAB, ok: false })]);
    expect(db.lab.status).toBe("processing");
    expect(vi.mocked(opsAlert).mock.calls.at(-1)?.[1]).toMatch(/not released/);
    expect((await confirm(...confirmRequest())).status).toBe(409);

    runAAi.resolve();
    expect((await (await runA).json()).results).toEqual([{ id: LAB, ok: true }]);
    expect(db.lab.status).toBe("ready");
    expect(generateSummary).toHaveBeenCalledTimes(1);
    expect(sendEmail).toHaveBeenCalledTimes(1);
  });

  it("a cron run that fails after its own claim puts the lab back to pending_context", async () => {
    const db = database({ noValues: true });
    vi.mocked(getCurrentVersion).mockResolvedValue({ id: "v-latest" } as never);
    const cronBody = await (await cron(cronRequest())).json();
    expect(cronBody.results).toEqual([expect.objectContaining({ id: LAB, ok: false })]);
    expect(db.lab.status).toBe("pending_context");
    expect(db.history).toEqual(["cron: processing", "cron: pending_context"]);
    expect(vi.mocked(opsAlert).mock.calls.at(-1)?.[1]).toMatch(/left pending for the next run/);
    expect(sendEmail).not.toHaveBeenCalled();
  });

  it("a lab the client claimed while the cron was starting is reported as theirs, not as a failure", async () => {
    const db = database();
    const firstAi = deferred<void>();
    vi.mocked(generateSummary).mockImplementationOnce(() => firstAi.promise);
    const versionRead = deferred<{ id: string }>();
    vi.mocked(getCurrentVersion).mockImplementation(() => versionRead.promise as never);

    const cronRun = cron(cronRequest());
    await vi.waitFor(() => expect(getCurrentVersion).toHaveBeenCalled());
    const first = confirm(...confirmRequest());
    await vi.waitFor(() => expect(generateSummary).toHaveBeenCalledTimes(1));
    versionRead.resolve({ id: "v-latest" });
    const cronBody = await (await cronRun).json();
    expect(cronBody.results).toEqual([{ id: LAB, ok: true, reason: "claimed elsewhere" }]);
    firstAi.resolve();
    expect((await first).status).toBe(200);
    expect(db.lab).toMatchObject({ status: "ready", patient_context_version_id: V2 });
    expect(sendEmail).toHaveBeenCalledTimes(1);
  });
});
