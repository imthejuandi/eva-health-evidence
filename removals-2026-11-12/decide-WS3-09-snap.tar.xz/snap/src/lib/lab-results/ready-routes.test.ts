/**
 * The routes that mark a lab ready refresh the dashboard's rolling average afterwards, because it reads only ready
 * labs and processing cached it without this one: upload confirm, client reprocess, admin reprocess and admin
 * enter-results. Admin enter-results also records the client's current patient context on the lab, as the upload
 * gate does. Upload confirm and admin enter-results hand processing each result's key and a bound's comparator
 * (known issue C-06), and set aside, naming it, a result that cannot be used: one printed with "≤" or "≥", one with no
 * readable number, one whose unit processing refuses; the rest is processed, and a report with nothing usable ends in
 * a 200 that names every result, never in an 'error' status (decision D-24, WS3-27). The pipeline, the AI summary and the email are stubbed;
 * the database is scripted (fake-supabase).
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall } from "@/lib/testing/fake-supabase";

const state = vi.hoisted(() => ({
  user: null as unknown,
  admin: null as unknown,
  /** What happened, in order: "ready" when a lab_results update sets it, "cache:<userId>" when the cache is refreshed. */
  events: [] as string[],
  readyError: false,
  deleted: false,
  /** The lab's stored biomarker_values, when a test sets them. */
  values: null as null | Array<Record<string, unknown>>,
  /** The named lab's status and stored values as upload confirm's empty-lab check reads them. */
  labStatus: "processing" as string,
  storedValues: 0,
  storedCheckFails: false,
}));

vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.user }));
vi.mock("@/lib/supabase/admin", () => ({ createAdminClient: () => state.admin }));
vi.mock("@/lib/auth/require-admin", () => ({
  requireAdmin: async () => ({ id: "admin-1" }),
  logAdminAction: vi.fn(async () => undefined),
}));
vi.mock("@/lib/patient-context/physiological-state", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/patient-context/physiological-state")>();
  return { ...actual, loadLabState: vi.fn(async () => ({ supplements: [{ key: "creatine", dose: "5 g" }], state: actual.UNKNOWN_STATE })) };
});
vi.mock("@/lib/biomarkers/process-results", () => ({
  // The real one recomputes the lab's figures, then refreshes the dashboard (rolling-average-ba).
  recomputeLabMetrics: vi.fn(async (userId: string, labId: string) => {
    state.events.push(`recompute:${userId}:${labId}`);
  }),
  processLabResults: vi.fn(async () => ({
    processed: [{ biomarkerKey: "albumin", name: "Albúmina", value: 4.4, unit: "g/dL", zone: "optimal" }],
    biologicalAge: null,
    calculatedMetrics: [],
    unmatched: [],
    refMapSize: 1,
    missingRefKeys: [],
  })),
}));
vi.mock("@/lib/biomarkers/rolling-average-ba", () => ({
  recomputeAndCacheUserBA: vi.fn(async (userId: string) => {
    state.events.push(`cache:${userId}`);
    return null;
  }),
}));
vi.mock("@/lib/ai/generate-summary", () => ({ generateSummary: vi.fn(async () => undefined) }));
vi.mock("@/lib/queries", () => ({
  getUserProfile: vi.fn(async () => ({
    id: "u1", full_name: "Ana Prueba", email: "u1@example.test", locale: "es", date_of_birth: "1981-03-15", sex: "male",
    subscription_status: "active",
  })),
  getWearableData: vi.fn(async () => []),
  getBiomarkerValues: vi.fn(async () => [
    { biomarker_key: "albumin", biomarker_name: "Albúmina", value: 4.4, unit: "g/dL", zone: "optimal", optimal_low: 3.5, optimal_high: 5 },
  ]),
}));
vi.mock("@/lib/email/send", () => ({ sendEmail: vi.fn(async () => undefined) }));
vi.mock("@/lib/patient-context", () => ({
  snapshotToLab: vi.fn(async () => undefined),
  getCurrentVersion: vi.fn(async () => ({ id: "33333333-3333-4333-8333-333333333333" })),
}));

import { POST as confirm } from "@/app/api/lab-results/confirm/route";
import { POST as reprocess } from "@/app/api/lab-results/reprocess/route";
import { POST as adminReprocess } from "@/app/api/admin/reprocess/route";
import { POST as adminEnterResults } from "@/app/api/admin/enter-results/route";
import { DELETE as deleteLab, PATCH as patchLab } from "@/app/api/lab-results/[id]/route";
import { recomputeAndCacheUserBA } from "@/lib/biomarkers/rolling-average-ba";
import { getCurrentVersion, snapshotToLab } from "@/lib/patient-context";
import { processLabResults, recomputeLabMetrics } from "@/lib/biomarkers/process-results";
import { loadLabState, UNKNOWN_STATE } from "@/lib/patient-context/physiological-state";
import { sendEmail } from "@/lib/email/send";
import { generateSummary } from "@/lib/ai/generate-summary";
import { logAdminAction } from "@/lib/auth/require-admin";
import { SET_ASIDE_COPY } from "./set-aside-copy.generated";

const LAB = "11111111-1111-4111-8111-111111111111";
const CLIENT = "22222222-2222-4222-8222-222222222222";
const VERSION = "33333333-3333-4333-8333-333333333333";

/** A scripted client: records a "ready" event for each update that sets it, and answers the routes' reads. */
function client(name: string) {
  const respond = (c: FakeCall) => {
    const op = ops(c);
    if (c.table === "lab_results" && op.startsWith("delete")) {
      state.deleted = true;
      state.events.push("deleted");
      return { data: null };
    }
    if (c.table === "lab_results" && op.startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as { status?: string; collection_date?: string };
      if (update.collection_date) state.events.push("dated");
      if (update.status === "ready") {
        if (state.readyError) return { error: { message: "connection reset" } };
        state.events.push("ready");
      }
      return { data: null };
    }
    if (c.table === "lab_results" && op.startsWith("insert")) return { data: { id: LAB } };
    if (c.table === "lab_results") return { data: state.deleted ? null : { id: LAB, user_id: CLIENT, status: state.labStatus, collection_date: null, lab_notes: [] } };
    if (c.table === "biomarker_references") {
      // The confirm route's allow-list finds every key it asks about.
      const [column, keys] = (argsOf(c, "in") ?? []) as [string?, string[]?];
      return { data: column === "biomarker_key" && keys ? keys.map((biomarker_key) => ({ biomarker_key })) : [{ biomarker_key: "albumin" }] };
    }
    if (c.table === "patient_context_versions") return { data: { id: VERSION } };
    // Upload confirm asks whether the lab holds any stored value before it removes an empty lab.
    if (c.table === "biomarker_values" && op === "select.eq.limit") {
      state.events.push("values-checked");
      if (state.storedCheckFails) return { data: null, error: { message: "connection reset" } };
      return { data: Array.from({ length: Math.min(state.storedValues, 1) }, (_, i) => ({ id: `bv-${i}` })) };
    }
    if (c.table === "biomarker_values" && op.startsWith("select")) {
      return { data: state.values ?? [{ id: "bv-1", biomarker_key: "albumin", biomarker_name: "Albúmina", value: 4.4, unit: "g/dL", created_at: "2026-10-01" }] };
    }
    return { data: null };
  };
  const fake = fakeSupabase(respond);
  return Object.assign(fake.client, {
    name,
    calls: fake.calls,
    auth: { getUser: async () => ({ data: { user: { id: CLIENT, email: "u1@example.test" } } }) },
  });
}

const post = (url: string, body: unknown) => new NextRequest(`http://localhost${url}`, { method: "POST", body: JSON.stringify(body) });

describe("a lab marked ready refreshes the dashboard's rolling average", () => {
  let user: ReturnType<typeof client>;
  let admin: ReturnType<typeof client>;
  beforeEach(() => {
    user = client("user");
    admin = client("admin");
    state.user = user;
    state.admin = admin;
    state.events = [];
    state.readyError = false;
    state.deleted = false;
    state.values = null;
    state.labStatus = "processing";
    state.storedValues = 0;
    state.storedCheckFails = false;
    vi.mocked(recomputeAndCacheUserBA).mockClear();
    vi.spyOn(console, "log").mockImplementation(() => {});
  });

  it("upload confirm: after the lab is ready, with the client's own session", async () => {
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [{ name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" }],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    expect(state.events).toEqual(["ready", `cache:${CLIENT}`]);
    expect(vi.mocked(recomputeAndCacheUserBA).mock.calls[0][1]).toBe(user);
    // The context is recorded before processing, which reads its creatine dose for the biological age.
    expect(snapshotToLab).toHaveBeenCalledWith(LAB, VERSION, {});
    expect(vi.mocked(snapshotToLab).mock.invocationCallOrder[0]).toBeLessThan(vi.mocked(processLabResults).mock.invocationCallOrder.at(-1)!);
  });

  it("upload confirm: the context is recorded before processing starts, not merely called first", async () => {
    const steps: string[] = [];
    vi.mocked(snapshotToLab).mockImplementationOnce(async () => {
      await new Promise((r) => setTimeout(r, 0));
      steps.push("context recorded");
    });
    const processing = vi.mocked(processLabResults).getMockImplementation()!;
    vi.mocked(processLabResults).mockImplementationOnce(async (...args) => {
      steps.push("processing started");
      return processing(...args);
    });
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [{ name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" }],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    expect(snapshotToLab).toHaveBeenCalledWith(LAB, VERSION, {});
    expect(steps).toEqual(["context recorded", "processing started"]);
  });

  it("upload confirm: a ready update that fails refreshes nothing", async () => {
    state.readyError = true;
    vi.spyOn(console, "error").mockImplementation(() => {});
    await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [{ name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" }],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(recomputeAndCacheUserBA).not.toHaveBeenCalled();
  });

  it("client reprocess: after the lab is ready, with the client that wrote it", async () => {
    const res = await reprocess(post("/api/lab-results/reprocess", { labResultId: LAB }));
    expect(res.status).toBe(200);
    expect(state.events).toEqual(["ready", `cache:${CLIENT}`]);
    expect(vi.mocked(recomputeAndCacheUserBA).mock.calls[0][1]).toBe(admin);
  });

  it("client reprocess reads the lab's context before deleting its values, and passes it to processing", async () => {
    vi.mocked(processLabResults).mockClear();
    const res = await reprocess(post("/api/lab-results/reprocess", { labResultId: LAB }));
    expect(res.status).toBe(200);
    expect(vi.mocked(loadLabState).mock.calls.at(-1)?.slice(1)).toEqual([CLIENT, LAB]);
    expect(vi.mocked(processLabResults).mock.calls[0][4]).toEqual({
      labState: { supplements: [{ key: "creatine", dose: "5 g" }], state: UNKNOWN_STATE },
    });
    expect(admin.calls.some((c) => c.table === "biomarker_values" && ops(c).startsWith("delete"))).toBe(true);
    expect(vi.mocked(loadLabState).mock.invocationCallOrder.at(-1)!).toBeLessThan(vi.mocked(processLabResults).mock.invocationCallOrder[0]);
  });

  it("client reprocess keeps two creatinine rows that disagree, so processing withholds the figure; exact copies collapse", async () => {
    const at = "2026-10-01T08:00:00Z";
    state.values = [
      { id: "bv-1", biomarker_key: "creatinine", biomarker_name: "Creatinina", value: 0.9, unit: "mg/dL", created_at: at },
      { id: "bv-2", biomarker_key: "creatinine", biomarker_name: "Creatinina", value: 1.4, unit: "mg/dL", created_at: at },
      { id: "bv-3", biomarker_key: "creatinine", biomarker_name: "Creatinina", value: 0.9, unit: "mg/dL", created_at: at },
      { id: "bv-4", biomarker_key: "albumin", biomarker_name: "Albúmina", value: 4.4, unit: "g/dL", created_at: at },
      { id: "bv-5", biomarker_key: "albumin", biomarker_name: "Albúmina", value: 4.5, unit: "g/dL", created_at: at },
    ];
    vi.mocked(processLabResults).mockClear();
    const res = await reprocess(post("/api/lab-results/reprocess", { labResultId: LAB }));
    expect(res.status).toBe(200);
    const given = vi.mocked(processLabResults).mock.calls[0][2] as Array<{ biomarkerKey?: string; value: number }>;
    expect(given.filter((b) => b.biomarkerKey === "creatinine").map((b) => b.value)).toEqual([0.9, 1.4]);
    expect(given.filter((b) => b.biomarkerKey === "albumin").map((b) => b.value)).toEqual([4.4]);
  });

  it("client reprocess with a context that cannot be read changes nothing: no status, no delete", async () => {
    vi.mocked(loadLabState).mockRejectedValueOnce(new Error("loadLabState: connection reset"));
    const quiet = vi.spyOn(console, "error").mockImplementation(() => {});
    const res = await reprocess(post("/api/lab-results/reprocess", { labResultId: LAB }));
    expect(res.status).toBe(500);
    for (const c of [...user.calls, ...admin.calls]) {
      expect(ops(c).startsWith("delete") || (c.table === "lab_results" && ops(c).startsWith("update")), `${c.table}.${ops(c)}`).toBe(false);
    }
    quiet.mockRestore();
  });

  it("admin reprocess: after the lab is ready, its figures are recomputed for the lab's owner, with the admin client", async () => {
    const res = await adminReprocess(post("/api/admin/reprocess", { labResultId: LAB }));
    expect(res.status).toBe(200);
    expect(state.events).toEqual(["ready", `recompute:${CLIENT}:${LAB}`]);
    expect(vi.mocked(recomputeLabMetrics).mock.calls.at(-1)?.[2]).toBe(admin);
  });

  it("admin enter-results: the lab records the client's current context, and the cache follows the ready lab", async () => {
    const res = await adminEnterResults(post("/api/admin/enter-results", {
      userId: CLIENT,
      biomarkers: [{ name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin" }],
    }));
    expect(res.status).toBe(200);
    expect(getCurrentVersion).toHaveBeenCalledWith(CLIENT, admin);
    const insert = admin.calls.find((c) => c.table === "lab_results" && ops(c).startsWith("insert"))!;
    expect(argsOf(insert, "insert")?.[0]).toMatchObject({ user_id: CLIENT, patient_context_version_id: VERSION, status: "processing" });
    expect(state.events).toEqual(["ready", `cache:${CLIENT}`]);
    expect(vi.mocked(recomputeAndCacheUserBA).mock.calls[0][1]).toBe(admin);
  });

  // Known issue C-06, decision CEO-15: a bound such as "<5" reaches processing with its comparator on every path.
  it("upload confirm passes each result's comparator and key to processing; a measured result carries none", async () => {
    vi.mocked(processLabResults).mockClear();
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [
        { name: "PCR ultrasensible", value: 5, comparator: "<", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
        { name: "Ferritina", value: 8, comparator: ">", unit: "ng/mL", biomarkerKey: "ferritin", matchConfidence: "user" },
        { name: "Albúmina", value: 4.4, comparator: null, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
      ],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    const [userId, labId, given] = vi.mocked(processLabResults).mock.calls[0];
    expect([userId, labId]).toEqual([CLIENT, LAB]);
    expect(given).toEqual([
      { name: "PCR ultrasensible", value: 5, comparator: "<", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
      { name: "Ferritina", value: 8, comparator: ">", unit: "ng/mL", biomarkerKey: "ferritin", matchConfidence: "user" },
      { name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
    ]);
  });

  it("admin enter-results passes the form's key and each result's comparator to processing", async () => {
    vi.mocked(processLabResults).mockClear();
    const res = await adminEnterResults(post("/api/admin/enter-results", {
      userId: CLIENT,
      biomarkers: [
        { name: "hs-CRP", value: 5, unit: "mg/L", biomarkerKey: "hs_crp", comparator: "<" },
        // The form's "Fructosamine", which the name matcher does not resolve, is processed under its key.
        { name: "Fructosamine", value: 190, unit: "µmol/L", biomarkerKey: "fructosamine" },
      ],
    }));
    expect(res.status).toBe(200);
    const [userId, labId, given, client] = vi.mocked(processLabResults).mock.calls[0];
    expect([userId, labId, client]).toEqual([CLIENT, LAB, admin]);
    expect(given).toEqual([
      { name: "hs-CRP", value: 5, unit: "mg/L", comparator: "<", biomarkerKey: "hs_crp", matchConfidence: "exact" },
      { name: "Fructosamine", value: 190, unit: "µmol/L", biomarkerKey: "fructosamine", matchConfidence: "exact" },
    ]);
  });

  // Decision D-24 (WS3-27): a result that cannot be used is set aside and named; the rest of the report is processed.
  const SIGNED = [
    { comparator: "≤", value: 5, sign: "≤" },
    { comparator: "≥", value: 5, sign: "≥" },
    { comparator: "<=", value: 5, sign: "≤" },
    { comparator: null, value: "≥5", sign: "≥" },
  ] as const;

  it('upload confirm: a "≤" or "≥" result is never passed on as a number or under another sign; it is named and the rest is saved', async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const { comparator, value, sign } of SIGNED) {
      vi.mocked(processLabResults).mockClear();
      state.events = [];
      const res = await confirm(post("/api/lab-results/confirm", {
        labResultId: LAB,
        biomarkers: [
          { name: "PCR ultrasensible", value, comparator, unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
          { name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
        ],
        contextVersionId: VERSION,
        transientContext: {},
      }));
      expect(res.status, sign).toBe(200);
      const [, , given] = vi.mocked(processLabResults).mock.calls[0];
      expect(given).toEqual([{ name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" }]);
      const body = await res.json();
      expect(body.setAside).toEqual([{ name: "PCR ultrasensible", reason: "sign_not_storable", printed: `${sign}5 mg/L`, sign }]);
      expect(body.nothingUsable).toBeUndefined();
      expect(state.events).toContain("ready");
    }
    // Operations: the lab and the result are in the log.
    const logged = warn.mock.calls.find((c) => String(c[0]).startsWith("[set-aside] upload-confirm"));
    expect(JSON.parse(String(logged?.[1]))).toMatchObject({ labResultId: LAB, userId: CLIENT, results: [{ name: "PCR ultrasensible", reason: "sign_not_storable" }] });
  });

  it("upload confirm: a value with no readable number is set aside, and printed text is read as the report prints it", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(processLabResults).mockClear();
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [
        { name: "Ferritina", value: "pendiente", unit: "ng/mL", biomarkerKey: "ferritin", matchConfidence: "exact" },
        { name: "ALT", value: null, unit: "U/L", biomarkerKey: "alt", matchConfidence: "exact" },
        { name: "PCR", value: 5, comparator: "~", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
        { name: "HbA1c", value: "5,4", unit: "%", biomarkerKey: "hba1c", matchConfidence: "exact" },
        { name: "TSH", value: "<0,5", unit: "mUI/L", biomarkerKey: "tsh", matchConfidence: "exact" },
      ],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    expect(vi.mocked(processLabResults).mock.calls[0][2]).toEqual([
      { name: "HbA1c", value: 5.4, unit: "%", biomarkerKey: "hba1c", matchConfidence: "exact" },
      { name: "TSH", value: 0.5, comparator: "<", unit: "mUI/L", biomarkerKey: "tsh", matchConfidence: "exact" },
    ]);
    expect((await res.json()).setAside.map((i: { name: string; reason: string }) => [i.name, i.reason])).toEqual([
      ["Ferritina", "value_unreadable"],
      ["ALT", "value_unreadable"],
      ["PCR", "value_unreadable"],
    ]);
  });

  it("upload confirm: a result the unit gate refuses is named with both units; the rest is saved", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(processLabResults).mockResolvedValueOnce({
      processed: [{ biomarkerKey: "albumin", name: "Albúmina", value: 4.4, unit: "g/dL", zone: "optimal" }],
      biologicalAge: null,
      calculatedMetrics: [],
      unmatched: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" }],
      refMapSize: 1,
      missingRefKeys: [],
    } as never);
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [
        { name: "Lipoproteína (a)", value: 75, unit: "nmol/L", biomarkerKey: "lipoprotein_a", matchConfidence: "exact" },
        { name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
      ],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    expect((await res.json()).setAside).toEqual([
      { name: "Lipoproteína (a)", reason: "unit_not_convertible", printed: "75 nmol/L", unit: "nmol/L", expectedUnit: "mg/dL" },
    ]);
    expect(state.events).toContain("ready");
  });

  it("upload confirm: a report whose every result is set aside ends in a 200 that names them: nothing processed, no 'error' status, no upload counted, no email", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(processLabResults).mockClear();
    vi.mocked(sendEmail).mockClear();
    vi.mocked(generateSummary).mockClear();
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [
        { name: "PCR ultrasensible", value: 5, comparator: "≤", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" },
        { name: "Ferritina", value: "ilegible", unit: "ng/mL", biomarkerKey: "", matchConfidence: "user" },
      ],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({ labResultId: null, processed: 0, nothingUsable: true });
    expect(body.setAside.map((i: { name: string; reason: string }) => [i.name, i.reason])).toEqual([
      ["PCR ultrasensible", "sign_not_storable"],
      ["Ferritina", "value_unreadable"],
    ]);
    expect(processLabResults).not.toHaveBeenCalled();
    // The empty lab is removed; it is never marked "error" or "ready", and the upload is not counted.
    expect(state.events).toEqual(["values-checked", "deleted"]);
    const updates = user.calls.filter((c) => ops(c).startsWith("update"));
    expect(updates).toEqual([]);
    expect(sendEmail).not.toHaveBeenCalled();
    expect(generateSummary).not.toHaveBeenCalled();
  });

  it("upload confirm: a standalone Lp(a) in nmol/L, refused by processing, ends the same way: 200, named, no 'error' status", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(sendEmail).mockClear();
    vi.mocked(processLabResults).mockResolvedValueOnce({
      processed: [],
      biologicalAge: null,
      calculatedMetrics: [],
      unmatched: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" }],
      refMapSize: 1,
      missingRefKeys: [],
    } as never);
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", biomarkerKey: "lipoprotein_a", matchConfidence: "exact" }],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.nothingUsable).toBe(true);
    expect(body.setAside).toEqual([expect.objectContaining({ name: "Lipoproteína (a)", reason: "unit_not_convertible", unit: "nmol/L", expectedUnit: "mg/dL" })]);
    expect(state.events).toEqual(["values-checked", "deleted"]);
    const statuses = user.calls.filter((c) => ops(c).startsWith("update")).map((c) => (argsOf(c, "update")?.[0] as { status?: string }).status);
    expect(statuses).not.toContain("error");
    expect(statuses).not.toContain("ready");
    expect(user.calls.some((c) => c.table === "profiles" && ops(c).startsWith("update"))).toBe(false);
    expect(sendEmail).not.toHaveBeenCalled();
  });

  // The request names the lab: only an empty one, still as extraction left it, is removed.
  const NOTHING_USABLE = {
    labResultId: LAB,
    biomarkers: [{ name: "PCR ultrasensible", value: 5, comparator: "≤", unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" }],
    contextVersionId: VERSION,
    transientContext: {},
  };
  const labWrites = () => user.calls.filter((c) => c.table === "lab_results" && /^(delete|update)/.test(ops(c))).map(ops);

  it("upload confirm with nothing usable: a lab that holds stored values is not deleted, and the answer still names each result", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    warn.mockClear();
    state.storedValues = 3;
    const res = await confirm(post("/api/lab-results/confirm", NOTHING_USABLE));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({ labResultId: null, processed: 0, nothingUsable: true });
    expect(body.setAside).toEqual([{ name: "PCR ultrasensible", reason: "sign_not_storable", printed: "≤5 mg/L", sign: "≤" }]);
    expect(state.deleted).toBe(false);
    expect(labWrites()).toEqual([]);
    const check = user.calls.find((c) => c.table === "biomarker_values")!;
    expect(argsOf(check, "eq")).toEqual(["lab_result_id", LAB]);
    expect(warn.mock.calls.some((c) => String(c[0]).includes(`Lab ${LAB} not removed`))).toBe(true);
    expect(warn.mock.calls.some((c) => String(c[0]).startsWith("[set-aside] upload-confirm"))).toBe(true);
  });

  it("upload confirm with nothing usable: a ready lab, or one waiting for its context, is not deleted whatever it holds", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    warn.mockClear();
    for (const status of ["ready", "pending_context", "error"]) {
      state.labStatus = status;
      state.events = [];
      const res = await confirm(post("/api/lab-results/confirm", NOTHING_USABLE));
      expect(res.status, status).toBe(200);
      expect(await res.json()).toMatchObject({ nothingUsable: true, setAside: [{ name: "PCR ultrasensible" }] });
      expect(state.events, status).toEqual([]);
      expect(labWrites(), status).toEqual([]);
    }
    expect(warn.mock.calls.filter((c) => String(c[0]).includes(`Lab ${LAB} not removed`))).toHaveLength(3);
  });

  it("upload confirm with nothing usable: when the stored values cannot be checked, the lab is not deleted", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    const error = vi.spyOn(console, "error").mockImplementation(() => {});
    error.mockClear();
    state.storedCheckFails = true;
    const res = await confirm(post("/api/lab-results/confirm", NOTHING_USABLE));
    expect(res.status).toBe(200);
    expect(await res.json()).toMatchObject({ nothingUsable: true, setAside: [{ name: "PCR ultrasensible", reason: "sign_not_storable" }] });
    expect(state.events).toEqual(["values-checked"]);
    expect(labWrites()).toEqual([]);
    expect(error.mock.calls.some((c) => String(c[0]).includes("could not be checked"))).toBe(true);
  });

  it("upload confirm, everything refused by processing: a ready lab with values is kept and gets its status back", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    state.labStatus = "ready";
    state.storedValues = 3;
    vi.mocked(processLabResults).mockResolvedValueOnce({
      processed: [],
      biologicalAge: null,
      calculatedMetrics: [],
      unmatched: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" }],
      refMapSize: 1,
      missingRefKeys: [],
    } as never);
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", biomarkerKey: "lipoprotein_a", matchConfidence: "exact" }],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(res.status).toBe(200);
    expect(await res.json()).toMatchObject({ nothingUsable: true, setAside: [{ name: "Lipoproteína (a)", reason: "unit_not_convertible" }] });
    expect(state.deleted).toBe(false);
    const statuses = user.calls.filter((c) => c.table === "lab_results" && ops(c).startsWith("update")).map((c) => (argsOf(c, "update")?.[0] as { status?: string }).status);
    expect(statuses).toEqual(["processing", "ready"]);
  });

  it("upload confirm, everything refused by processing: a fresh lab in which values were stored after all is kept", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    state.storedValues = 1;
    vi.mocked(processLabResults).mockResolvedValueOnce({
      processed: [],
      biologicalAge: null,
      calculatedMetrics: [],
      unmatched: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" }],
      refMapSize: 1,
      missingRefKeys: [],
    } as never);
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L", biomarkerKey: "lipoprotein_a", matchConfidence: "exact" }],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect((await res.json()).nothingUsable).toBe(true);
    expect(state.deleted).toBe(false);
    expect(state.events).toEqual(["values-checked"]);
  });

  // A comparator that is a member every object inherits is not a sign: the result is set aside, never a plain number.
  const INHERITED = ["constructor", "toString", "valueOf", "hasOwnProperty", "__proto__"];

  it("upload confirm: a comparator such as \"constructor\" or \"__proto__\" passes nothing to processing; the result is named", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const comparator of INHERITED) {
      vi.mocked(processLabResults).mockClear();
      state.deleted = false;
      const res = await confirm(post("/api/lab-results/confirm", {
        labResultId: LAB,
        biomarkers: [{ name: "PCR ultrasensible", value: 5, comparator, unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" }],
        contextVersionId: VERSION,
        transientContext: {},
      }));
      expect(res.status, comparator).toBe(200);
      expect(processLabResults, comparator).not.toHaveBeenCalled();
      const body = await res.json();
      expect(body.nothingUsable, comparator).toBe(true);
      expect(body.setAside).toEqual([{ name: "PCR ultrasensible", reason: "value_unreadable", printed: `${comparator}5 mg/L` }]);
    }
    // Beside a usable result, only the usable one goes on.
    vi.mocked(processLabResults).mockClear();
    state.deleted = false;
    const res = await confirm(post("/api/lab-results/confirm", {
      labResultId: LAB,
      biomarkers: [
        ...INHERITED.map((comparator) => ({ name: `PCR ${comparator}`, value: 5, comparator, unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact" })),
        { name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
      ],
      contextVersionId: VERSION,
      transientContext: {},
    }));
    expect(vi.mocked(processLabResults).mock.calls[0][2]).toEqual([{ name: "Albúmina", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" }]);
    expect((await res.json()).setAside.map((i: { name: string; reason: string }) => [i.name, i.reason])).toEqual(
      INHERITED.map((comparator) => [`PCR ${comparator}`, "value_unreadable"]),
    );
  });

  it("admin enter-results: a comparator such as \"constructor\" or \"__proto__\" passes nothing to processing; the result is named", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const comparator of INHERITED) {
      vi.mocked(processLabResults).mockClear();
      const res = await adminEnterResults(post("/api/admin/enter-results", {
        userId: CLIENT,
        biomarkers: [{ name: "hs-CRP", value: 5, unit: "mg/L", biomarkerKey: "hs_crp", comparator }],
      }));
      expect(res.status, comparator).toBe(200);
      expect(processLabResults, comparator).not.toHaveBeenCalled();
      const body = await res.json();
      expect(body.nothingUsable, comparator).toBe(true);
      expect(body.setAside).toEqual([{ name: "hs-CRP", reason: "value_unreadable", printed: `${comparator}5 mg/L` }]);
      expect(body.setAsideMessage).toContain(`hs-CRP (${comparator}5 mg/L)`);
      expect(admin.calls.some((c) => c.table === "lab_results" && ops(c).startsWith("insert")), comparator).toBe(false);
    }
    vi.mocked(processLabResults).mockClear();
    const res = await adminEnterResults(post("/api/admin/enter-results", {
      userId: CLIENT,
      biomarkers: [
        { name: "hs-CRP", value: 5, unit: "mg/L", biomarkerKey: "hs_crp", comparator: "constructor" },
        { name: "Albumin", value: 4.4, unit: "g/dL", biomarkerKey: "albumin" },
      ],
    }));
    expect(vi.mocked(processLabResults).mock.calls[0][2]).toEqual([{ name: "Albumin", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" }]);
    expect((await res.json()).setAside).toEqual([{ name: "hs-CRP", reason: "value_unreadable", printed: "constructor5 mg/L" }]);
  });

  it('admin enter-results: a "≤" or "≥" result is set aside and named in the administrator\'s language; the rest is entered', async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const { comparator, value, sign } of SIGNED) {
      for (const locale of ["en", "es"] as const) {
        vi.mocked(processLabResults).mockClear();
        const res = await adminEnterResults(post("/api/admin/enter-results", {
          userId: CLIENT,
          locale,
          biomarkers: [
            { name: "hs-CRP", value, unit: "mg/L", biomarkerKey: "hs_crp", comparator },
            { name: "Albumin", value: "4,4", unit: "g/dL", biomarkerKey: "albumin" },
            { name: "ALT", value: "", unit: "U/L", biomarkerKey: "alt" },
          ],
        }));
        expect(res.status, sign).toBe(200);
        expect(vi.mocked(processLabResults).mock.calls[0][2]).toEqual([
          { name: "Albumin", value: 4.4, unit: "g/dL", biomarkerKey: "albumin", matchConfidence: "exact" },
        ]);
        const body = await res.json();
        expect(body.setAside.map((i: { name: string; reason: string }) => [i.name, i.reason])).toEqual([
          ["hs-CRP", "sign_not_storable"],
          ["ALT", "value_unreadable"],
        ]);
        const copy = SET_ASIDE_COPY[locale];
        expect(body.setAsideMessage).toContain(copy.heading);
        expect(body.setAsideMessage).toContain(copy.intro_some);
        expect(body.setAsideMessage).toContain(`hs-CRP (${sign}5 mg/L): ${copy.reasons.sign_not_storable.replace("{sign}", sign)}`);
        expect(body.setAsideMessage).toContain(`ALT (U/L): ${copy.reasons.value_unreadable}`);
      }
    }
  });

  it("admin enter-results: when no result can be used, no lab is created and the answer says nothing was saved", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(processLabResults).mockClear();
    vi.mocked(sendEmail).mockClear();
    const res = await adminEnterResults(post("/api/admin/enter-results", {
      userId: CLIENT,
      locale: "es",
      biomarkers: [{ name: "hs-CRP", value: 5, unit: "mg/L", biomarkerKey: "hs_crp", comparator: "≥" }],
    }));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({ labResultId: null, processed: 0, nothingUsable: true });
    expect(body.setAsideMessage).toContain(SET_ASIDE_COPY.es.intro_all);
    expect(processLabResults).not.toHaveBeenCalled();
    expect(admin.calls.some((c) => c.table === "lab_results" && ops(c).startsWith("insert"))).toBe(false);
    expect(state.events).toEqual([]);
    expect(sendEmail).not.toHaveBeenCalled();
    // The audit trail names what was set aside.
    expect(vi.mocked(logAdminAction).mock.calls.at(-1)?.[0]).toMatchObject({
      action: "enter_results",
      detail: { processed: 0, setAside: [{ name: "hs-CRP", reason: "sign_not_storable", printed: "≥5 mg/L" }] },
    });
  });

  it("a lab's date changed, or a lab deleted: the dashboard's average is refreshed afterwards", async () => {
    const params = { params: Promise.resolve({ id: LAB }) };
    const patch = new NextRequest(`http://localhost/api/lab-results/${LAB}`, { method: "PATCH", body: JSON.stringify({ collectionDate: "2026-09-01" }) });
    expect((await patchLab(patch, params)).status).toBe(200);
    expect(state.events).toEqual(["dated", `cache:${CLIENT}`]);
    expect(vi.mocked(recomputeAndCacheUserBA).mock.calls[0][1]).toBe(user);

    state.events = [];
    const del = new NextRequest(`http://localhost/api/lab-results/${LAB}`, { method: "DELETE" });
    expect((await deleteLab(del, { params: Promise.resolve({ id: LAB }) })).status).toBe(200);
    expect(state.events).toEqual(["deleted", `cache:${CLIENT}`]);
    expect(vi.mocked(recomputeAndCacheUserBA).mock.calls[1][1]).toBe(admin);
  });
});
