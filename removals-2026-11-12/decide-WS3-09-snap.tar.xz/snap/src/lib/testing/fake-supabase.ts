/**
 * A chainable stand-in for supabase-js for unit tests: every builder method
 * records itself and returns the builder; awaiting it hands the recorded call
 * to `respond`, which the test uses to script the database. Lets the code
 * that touches real tables (bridge store, cycle closing, cron resolvers) be
 * tested without a database.
 */
import type { SupabaseClient } from "@supabase/supabase-js";

export type FakeCall = { table: string; ops: { op: string; args: unknown[] }[] };
export type FakeResponse = { data?: unknown; error?: unknown; count?: number | null };

const METHODS = ["insert", "select", "update", "upsert", "delete", "eq", "neq", "in", "is", "or", "not", "lt", "gt", "gte", "lte", "order", "limit", "range", "single", "maybeSingle"];

/**
 * Options: `project` trims each returned row to the columns its `select` named, as PostgREST does, so a test fails
 * when the code stops asking for a column it reads. Selects with "*" or embedded resources are returned as scripted.
 */
export function fakeSupabase(respond: (call: FakeCall) => FakeResponse, options: { project?: boolean } = {}) {
  const calls: FakeCall[] = [];
  const client = {
    from(table: string) {
      const call: FakeCall = { table, ops: [] };
      calls.push(call);
      const builder: Record<string, unknown> = {};
      for (const m of METHODS) {
        builder[m] = (...args: unknown[]) => {
          call.ops.push({ op: m, args });
          return builder;
        };
      }
      builder.then = (resolve: (v: unknown) => void, reject?: (e: unknown) => void) => {
        try {
          const response = { data: null, error: null, count: null, ...respond(call) };
          resolve(options.project ? { ...response, data: project(response.data, call) } : response);
        } catch (e) {
          reject?.(e);
        }
      };
      return builder;
    },
  };
  return { client: client as unknown as SupabaseClient, calls };
}

/** The scripted rows trimmed to the columns the call's `select` named (see `fakeSupabase` options). */
function project(data: unknown, call: FakeCall): unknown {
  const columns = call.ops.find((o) => o.op === "select")?.args[0];
  if (typeof columns !== "string" || /[*(]/.test(columns)) return data;
  const keep = columns.split(",").map((c) => c.trim()).filter(Boolean);
  const trim = (row: unknown) =>
    row && typeof row === "object" ? Object.fromEntries(keep.filter((k) => k in row).map((k) => [k, (row as Record<string, unknown>)[k]])) : row;
  return Array.isArray(data) ? data.map(trim) : trim(data);
}

/** "insert.select.single" — the builder chain of a recorded call. */
export const ops = (c: FakeCall): string => c.ops.map((o) => o.op).join(".");

/** The arguments of the first `op` in a recorded call, if any. */
export const argsOf = (c: FakeCall, op: string, matchFirstArg?: unknown): unknown[] | undefined =>
  c.ops.find((o) => o.op === op && (matchFirstArg === undefined || o.args[0] === matchFirstArg))?.args;
