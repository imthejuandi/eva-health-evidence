/**
 * Unit tests of the DSRT runner (scripts/signoff/dsrt.ts, scripts/signoff/lib/) and of the data, coverage,
 * messages, coherence and governance check modules, on small in-memory fixtures.
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createRequire } from "node:module";
import { afterAll, describe, expect, it } from "vitest";
import { buildRows, loadSeed, type RawEn, type RawEs, type Row } from "../../../scripts/signoff/lib/seed";
import { makeCtx, moduleForId, parseAcceptanceTest, runDsrt } from "../../../scripts/signoff/lib/runner";
import { hashInputs, inputFiles, JUDGE_PROMPTS_FILE, sha256File, stableStringify } from "../../../scripts/signoff/lib/hash";
import { extractNumbers } from "../../../scripts/signoff/lib/format";
import { outsideOwnership } from "../../../scripts/signoff/lib/ownership";
import {
  applyForwardMigration,
  applyForwardMigrationColumns,
  applyMigrationBounds,
  changesFromCompile,
  changesFromDiff,
  checkChangeList,
  checkDifferencesListed,
  checkEveryColumn,
  checkLabConcordance,
  checkParity,
  checkRowIntegrity,
  checkSeedNumbers,
  checkSourceOfTruth,
  checks as dataChecks,
  untranslatedFailures,
  isStated,
  loadCompileTools,
  loadDocumentedChanges,
  PRODUCTION_SNAPSHOT,
  parseForwardMigration,
  productionDatabaseRows,
  productionDisagreements,
  RECONCILIATION_DIR,
  reconciliationSet,
  SIGNOFF_ADD_COLUMNS,
  retirementGaps,
  retiringDecision,
  seedDatabaseRows,
  splitSqlList,
  splitSqlStatements,
  sqlLiteral,
  sqlSplitHazards,
  unitKey,
  type DbRow,
  type DocumentedChanges,
  type ForwardMigration,
  type MigrationOp,
  type RetirementDecision,
  type RetirementLookup,
} from "../../../scripts/signoff/checks/data";
import { checkCoverage } from "../../../scripts/signoff/checks/coverage";
import { checkMessageNumbers, checkReachability, checks as messageChecks, lexiconHits, parseLexicon } from "../../../scripts/signoff/checks/messages";
import { ckdEpi2021, judge, runCoherence, coherenceFailures, vermeulenFreeT } from "../../../scripts/signoff/checks/coherence";
import {
  addedRowTemplate,
  checks as govChecks,
  compileIdempotency,
  COMPILE_REPORT,
  diffFrozen,
  firstDifference,
  finalRowKey,
  judgeColdReader,
  loadCompileRows,
  missingCoverLabels,
  finalRowMismatches,
  ownershipViolations,
  pairMismatches,
  readCompileRun,
  readRoundRecord,
  roundChangesFile,
  rowTraceKey,
  templateMismatches,
  traceRows,
  unapproved,
  type FinalRowFields,
  type SeedPair,
  type TraceStats,
} from "../../../scripts/signoff/checks/governance";
import type { CatalogueRow } from "../../../scripts/signoff/lib/echevarne";

// Every temporary folder these tests create, and the compile and runner calls they make, lives under one root that
// is removed after this file's tests: os.tmpdir() reads TMPDIR on each call, and spawned processes inherit it.
// Before this, every run left its fixtures in the system's temporary folder (about 100 MB a run).
const TMP_ROOT = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-core-test-"));
const TMPDIR_BEFORE = process.env.TMPDIR;
process.env.TMPDIR = TMP_ROOT;
afterAll(() => {
  if (TMPDIR_BEFORE === undefined) delete process.env.TMPDIR;
  else process.env.TMPDIR = TMPDIR_BEFORE;
  fs.rmSync(TMP_ROOT, { recursive: true, force: true });
});

const ROOT = path.resolve(__dirname, "../../..");

interface Spec {
  name: string;
  sex?: string;
  age?: string;
  unit?: string;
  nl?: number | null;
  nh?: number | null;
  ol?: number | null;
  oh?: number | null;
  /** Critical limits, written in both files as the compile writes them (Critical_Low / Crítico_Bajo, …) when given. */
  cl?: number | null;
  ch?: number | null;
  /** Reference_Basis and Reference_Source (Base_Referencia and Fuente_Referencia in Spanish), written when given. */
  rb?: string | null;
  rs?: string | null;
  /** The State column (Estado in Spanish) the compile writes for a row compiled from a final row, written when given. */
  st?: string;
  msgs?: Partial<Record<"cl" | "bo" | "o" | "ao" | "ch", string>>;
}

const ALL_MSGS = { cl: "Low.", bo: "Lowish.", o: "Fine.", ao: "Highish.", ch: "High." };

function raw(specs: Spec[]): { en: RawEn[]; es: RawEs[] } {
  const en: RawEn[] = [];
  const es: RawEs[] = [];
  for (const s of specs) {
    const m = s.msgs ?? ALL_MSGS;
    const sex = s.sex ?? "Both";
    en.push({
      Biomarker: s.name,
      Category: "Test",
      Unit: s.unit ?? "mg/dL",
      Sex: sex,
      Age_Group: s.age ?? "All Adults",
      Normal_Low: s.nl ?? null,
      Normal_High: s.nh ?? null,
      Optimal_Low: s.ol ?? null,
      Optimal_High: s.oh ?? null,
      Msg_Critical_Low: m.cl ?? null,
      Msg_Below_Optimal: m.bo ?? null,
      Msg_Optimal: m.o ?? null,
      Msg_Above_Optimal: m.ao ?? null,
      Msg_Critical_High: m.ch ?? null,
      ...(s.cl !== undefined ? { Critical_Low: s.cl } : {}),
      ...(s.ch !== undefined ? { Critical_High: s.ch } : {}),
      ...(s.rb !== undefined ? { Reference_Basis: s.rb } : {}),
      ...(s.rs !== undefined ? { Reference_Source: s.rs } : {}),
      ...(s.st !== undefined ? { State: s.st } : {}),
    });
    es.push({
      Biomarcador: s.name,
      Unidad: s.unit ?? "mg/dL",
      Sexo: { Both: "Ambos", Male: "Masculino", Female: "Femenino" }[sex] ?? sex,
      // The label the compile and the seeder write for All Adults (compile-rows.js ageEs).
      Grupo_Edad: s.age ?? "Todos los Adultos",
      Normal_Bajo: s.nl ?? null,
      Normal_Alto: s.nh ?? null,
      Óptimo_Bajo: s.ol ?? null,
      Óptimo_Alto: s.oh ?? null,
      Msg_Crítico_Bajo: m.cl ?? null,
      Msg_Debajo_Óptimo: m.bo ?? null,
      Msg_Óptimo: m.o ?? null,
      Msg_Encima_Óptimo: m.ao ?? null,
      Msg_Crítico_Alto: m.ch ?? null,
      ...(s.cl !== undefined ? { Crítico_Bajo: s.cl } : {}),
      ...(s.ch !== undefined ? { Crítico_Alto: s.ch } : {}),
      ...(s.rb !== undefined ? { Base_Referencia: s.rb } : {}),
      ...(s.rs !== undefined ? { Fuente_Referencia: s.rs } : {}),
      ...(s.st !== undefined ? { Estado: s.st } : {}),
    });
  }
  return { en, es };
}

const rows = (specs: Spec[]): Row[] => {
  const { en, es } = raw(specs);
  return buildRows(en, es);
};

// The compile's own SQL writer (docs/signoff/tools/lib/compile-sql.js), so D5 is tested on the format the loop produces.
const toolRequire = createRequire(path.join(ROOT, "package.json"));
const compileSql = toolRequire(path.join(ROOT, "docs/signoff/tools/lib/compile-sql.js")) as {
  buildSql(changes: { row_key: string; op: string }[], compiled: Map<string, Record<string, unknown>>, base: Map<string, Record<string, unknown>>, meta: { name: string; baselineNote: string }): { forward: string };
};
const compileRows = toolRequire(path.join(ROOT, "docs/signoff/tools/lib/compile-rows.js")) as {
  DB_COLS: string[];
  DB_EXT_COLS: string[];
  dbRowFromPair(p: { en: RawEn; es: RawEs }): DbRow;
  pairFromDbRow(r: DbRow, categoryEsByEn: Record<string, string>, warn: (m: string) => void): { en: RawEn; es: RawEs };
  STATE_LABEL: Record<string, [string, string]>;
  ageStateToLabel(ageGroup: string, state: string, markerPairs: { en: RawEn; es: RawEs }[], warn: (m: string) => void): [string, string];
};
type DbLike = { biomarker_key: string; sex: string; age_group_en: string } & Record<string, unknown>;

/** The forward migration compile-sql.js writes for these written rows and deleted rows against these production rows. */
function forwardSql(written: DbLike[], deleted: DbLike[] = [], base: DbLike[] = []): string {
  const cols = [...compileRows.DB_COLS, ...compileRows.DB_EXT_COLS];
  const full = (r: DbLike) => Object.fromEntries(cols.map((c) => [c, r[c] ?? null]));
  const key = (r: DbLike) => `${r.biomarker_key}|${r.sex}|${r.age_group_en}`;
  const baseByKey = new Map(base.map((r) => [key(r), full(r)]));
  const changes = [...written.map((r) => ({ row_key: key(r), op: baseByKey.has(key(r)) ? "modify" : "add" })), ...deleted.map((r) => ({ row_key: key(r), op: "remove" }))];
  return compileSql.buildSql(changes, new Map(written.map((r) => [key(r), full(r)])), baseByKey, { name: "test", baselineNote: "test" }).forward;
}

function tmpSeed(specs: Spec[]): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-seed-"));
  const { en, es } = raw(specs);
  fs.writeFileSync(path.join(dir, "biomarker-ranges-en.json"), JSON.stringify({ biomarker_ranges: en }));
  fs.writeFileSync(path.join(dir, "rangos-biomarcadores-es.json"), JSON.stringify({ rangos_biomarcadores: es }));
  return dir;
}

describe("runner", () => {
  it("parses every check id of ACCEPTANCE-TEST.md in document order", () => {
    const ids = parseAcceptanceTest(fs.readFileSync(path.join(ROOT, "docs/signoff/ACCEPTANCE-TEST.md"), "utf8")).map((c) => c.id);
    expect(ids.slice(0, 6)).toEqual(["D1", "D2", "D3", "D4", "D5", "D6"]);
    expect(ids).toContain("K1");
    expect(ids[ids.length - 1]).toBe("G8");
    expect(new Set(ids).size).toBe(ids.length);
    expect(moduleForId("G8")).toBe("prereview");
    expect(moduleForId("G3")).toBe("governance");
    expect(moduleForId("X1")).toBe("consistency");
  });

  it("reports the checks of missing modules as blocked and is deterministic", async () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-root-"));
    fs.mkdirSync(path.join(root, "docs/signoff"), { recursive: true });
    fs.writeFileSync(path.join(root, "docs/signoff/ACCEPTANCE-TEST.md"), "## D. Data\n\n| Id | Check | How | Pass |\n|---|---|---|---|\n| D1 | Rows | script | 0 |\n| E1 | Evidence | script | 100% |\n");
    const a = await runDsrt({ root, gitCommit: "abc" });
    const b = await runDsrt({ root, gitCommit: "abc" });
    expect(a.results.map((r) => [r.id, r.status, r.summary])).toEqual([
      ["D1", "blocked", "module not implemented"],
      ["E1", "blocked", "module not implemented"],
    ]);
    expect(a.results[1].blocked_on).toBe("scripts/signoff/checks/evidence.ts");
    expect(a.counts).toEqual({ pass: 0, fail: 0, blocked: 2 });
    expect(stableStringify(a)).toBe(stableStringify(b));
    // The lens file is listed even where it is missing, as "missing", so that G1 cannot lose the judge prompts.
    expect(Object.keys(a.inputs)).toEqual(["docs/signoff/ACCEPTANCE-TEST.md", JUDGE_PROMPTS_FILE]);
    expect(a.inputs[JUDGE_PROMPTS_FILE]).toBe("missing");
  });

  it("stableStringify sorts keys at every level", () => {
    expect(stableStringify({ b: 1, a: { d: 2, c: [{ z: 1, y: 2 }] } }, 0)).toBe('{"a":{"c":[{"y":2,"z":1}],"d":2},"b":1}');
  });
});

describe("data (D1)", () => {
  it("fails a duplicate key", () => {
    const rs = rows([
      { name: "Calcium", nl: 8.5, nh: 10.5, ol: 9, oh: 10 },
      { name: "Calcium", nl: 8.6, nh: 10.3, ol: 9, oh: 10 },
    ]);
    const { failures } = checkRowIntegrity(rs);
    expect(failures.map((f) => f.key)).toContain("calcium|both|All Adults|duplicate");
  });

  it("fails bad ordering and the Biological Age pseudo-row through the check itself", async () => {
    const seedDir = tmpSeed([
      { name: "Glucose (Fasting)", nl: 70, nh: 99, ol: 100, oh: 90 },
      { name: "Biological Age", unit: "years", nl: null, nh: null },
    ]);
    const ctx = makeCtx({ root: ROOT, seedDir, thresholds: {} });
    const d1 = dataChecks.find((c) => c.id === "D1")!;
    const r = await d1.run(ctx);
    expect(r.status).toBe("fail");
    expect(r.failures.some((f) => f.key.startsWith("glucose_fasting|both|All Adults|ordering"))).toBe(true);
    expect(r.failures.some((f) => f.key === "biological_age|both|All Adults|non_analyte")).toBe(true);
  });

  it("D6 is blocked until the reconciliation directory exists", async () => {
    const ctx = makeCtx({ root: ROOT, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    const r = await dataChecks.find((c) => c.id === "D6")!.run(ctx);
    expect(r.status).toBe("blocked");
    expect(r.blocked_on).toMatch(/reconciliation/);
  });

  it("D6 and D5 read each part of the reconciliation set through reconciliationSet, which G1 uses too: the first entry, in sorted order, whose name matches the part", async () => {
    const workDir = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-"));
    const dir = path.join(workDir, RECONCILIATION_DIR);
    expect(reconciliationSet(dir)).toEqual({ entries: [], picked: { diff: undefined, forward: undefined, rollback: undefined, readers: undefined } });
    fs.mkdirSync(dir);
    for (const f of ["diff.json", "a-diff.json", "forward.sql", "forward-0.sql", "rollback.sql", "reader-results.json", "reasons.json", "README.md"]) fs.writeFileSync(path.join(dir, f), "{}");
    expect(reconciliationSet(dir)).toEqual({
      entries: ["README.md", "a-diff.json", "diff.json", "forward-0.sql", "forward.sql", "reader-results.json", "reasons.json", "rollback.sql"],
      picked: { diff: "a-diff.json", forward: "forward-0.sql", rollback: "rollback.sql", readers: "reader-results.json" },
    });
    // D6 reads the diff picked: a row without a reason in a-diff.json fails; diff.json, sorted after it, is not read.
    fs.writeFileSync(path.join(dir, "a-diff.json"), JSON.stringify({ rows: [{ key: "x|both|All Adults", reason: null, source: null }] }));
    fs.writeFileSync(path.join(dir, "diff.json"), JSON.stringify({ rows: [{ key: "y|both|All Adults", reason: null, source: null }] }));
    fs.writeFileSync(path.join(dir, "reader-results.json"), JSON.stringify({ passed: true, failed: 0 }));
    const r = await dataChecks.find((c) => c.id === "D6")!.run(makeCtx({ root: ROOT, workDir, thresholds: {} }));
    expect(r.failures.map((f) => f.key)).toEqual(["x|both|All Adults|unexplained"]);
    expect(r.metrics).toEqual({ files: 8 });
    // D5 reads the same diff and forward migration when no changes.json is next to the seed.
    const doc = loadDocumentedChanges(makeCtx({ root: ROOT, seedDir: tmpSeed([]), workDir, thresholds: {} }))!;
    expect(doc.kind).toBe("reconciliation diff");
    expect(doc.file).toBe(path.relative(ROOT, path.join(dir, "a-diff.json")).split(path.sep).join("/"));
    expect(doc.migration!.file).toBe(path.relative(ROOT, path.join(dir, "forward-0.sql")).split(path.sep).join("/"));
  });
});

describe("data (D2, D3)", () => {
  it("treats the Spanish translation of a qualitative unit as the same unit, including two-word units", () => {
    expect(unitKey("Grupo Sanguíneo")).toBe(unitKey("Blood Type"));
    expect(unitKey("Patrón A o B")).toBe(unitKey("Pattern A or B"));
    expect(unitKey("Título")).toBe(unitKey("Titer"));
    expect(unitKey("µUI/mL")).toBe(unitKey("µIU/mL"));
    expect(unitKey("mg/dL")).not.toBe(unitKey("mmol/L"));
    const rs = rows([{ name: "ABO Group and Rh Factor", unit: "Blood Type" }, { name: "LDL Pattern", unit: "Pattern A or B" }]);
    rs[0].unit_es = "Grupo Sanguíneo";
    rs[1].unit_es = "Patrón A o B";
    for (const r of rs) r.age_group_es = "Todos los Adultos";
    expect(checkParity(rs, 2, 2)).toEqual([]);
    rs[1].unit_es = "mg/dL";
    expect(checkParity(rs, 2, 2).map((f) => f.key)).toEqual(["ldl_pattern|both|All Adults|unit"]);
  });

  it("D2 accepts the Spanish label the compile writes for every physiological state, with or without an age band, and still fails a wrong one", () => {
    const states = Object.keys(compileRows.STATE_LABEL);
    expect(states).toEqual(expect.arrayContaining(["premenopausal", "perimenopausal", "hormone_therapy", "oral_contraception", "pregnancy", "lactation"]));
    const labels: [string, string][] = [];
    for (const st of states) {
      labels.push(compileRows.ageStateToLabel("All Adults", st, [], () => {}));
      labels.push(compileRows.ageStateToLabel("60+", st, [], () => {}));
      labels.push(compileRows.ageStateToLabel("40-59", st, [], () => {}));
    }
    expect(labels).toContainEqual(["Pregnancy", "Embarazo"]);
    expect(labels).toContainEqual(["Postmenopausal 60+", "Posmenopáusica 60+"]);
    const rs = rows(labels.map(([en]) => ({ name: "Ferritin", sex: "Female", age: en, unit: "ng/mL" })));
    rs.forEach((r, i) => (r.age_group_es = labels[i][1]));
    expect(checkParity(rs, rs.length, rs.length)).toEqual([]);
    // A wrong or untranslated Spanish label still fails, and so does a band that differs or an unknown state.
    const wrong = rows([
      { name: "Ferritin", sex: "Female", age: "Pregnancy", unit: "ng/mL" },
      { name: "Ferritin", sex: "Female", age: "Lactation", unit: "ng/mL" },
      { name: "Ferritin", sex: "Female", age: "Postmenopausal 60+", unit: "ng/mL" },
      { name: "Ferritin", sex: "Female", age: "Breastfeeding 60+", unit: "ng/mL" },
      { name: "Ferritin", sex: "Female", age: "All Adults 60+", unit: "ng/mL" },
    ]);
    ["Lactancia", "Lactation", "Posmenopáusica 50-59", "Lactancia 60+", "Todos los Adultos 60+"].forEach((es, i) => (wrong[i].age_group_es = es));
    expect(checkParity(wrong, 5, 5).map((f) => f.detail)).toEqual([
      'EN "Pregnancy" vs ES "Lactancia" (expected "Embarazo")',
      'EN "Lactation" vs ES "Lactation" (expected "Lactancia")',
      'EN "Postmenopausal 60+" vs ES "Posmenopáusica 50-59" (expected "Posmenopáusica 60+")',
      'EN "Breastfeeding 60+" vs ES "Lactancia 60+" (expected "Breastfeeding 60+")',
      'EN "All Adults 60+" vs ES "Todos los Adultos 60+" (expected "All Adults 60+")',
    ]);
  });

  it("D2 treats alelos as the Spanish spelling of the ApoE genotype's unit, alleles", () => {
    expect(unitKey("alelos")).toBe(unitKey("alleles"));
    expect(unitKey("alelos")).not.toBe(unitKey("copies"));
    const rs = rows([{ name: "ApoE Genotype", unit: "alleles" }]);
    rs[0].age_group_es = "Todos los Adultos";
    rs[0].unit_es = "alelos";
    expect(checkParity(rs, 1, 1)).toEqual([]);
    rs[0].unit_es = "copias";
    expect(checkParity(rs, 1, 1).map((f) => f.key)).toEqual(["apoe_genotype|both|All Adults|unit"]);
  });

  it("D2 fails each Spanish column the compile left in English, and a compile output without its report", async () => {
    const entry = { family: "f04_inflammation", source: "decisions", row_key: "hs_crp|both|All Adults|none", seed_key: "hs_crp|both|All Adults", field: "Nota_Método", from_field: "method_note", spanish_field: "method_note_es" };
    expect(untranslatedFailures({ untranslated: [entry] }, true)).toEqual([{ key: "hs_crp|both|All Adults|untranslated|Nota_Método", detail: "Nota_Método carries the English text of method_note: the row has no method_note_es" }]);
    expect(untranslatedFailures({ untranslated: [] }, true)).toEqual([]);
    expect(untranslatedFailures(null, false)).toEqual([]);
    expect(untranslatedFailures(null, true).map((f) => f.key)).toEqual(["_untranslated"]);
    expect(untranslatedFailures({}, true).map((f) => f.key)).toEqual(["_untranslated"]);
    const seedDir = tmpSeed([{ name: "hs-CRP", nl: null, nh: 3, ol: null, oh: 1 }]);
    const es = JSON.parse(fs.readFileSync(path.join(seedDir, "rangos-biomarcadores-es.json"), "utf8"));
    es.rangos_biomarcadores[0].Grupo_Edad = "Todos los Adultos";
    fs.writeFileSync(path.join(seedDir, "rangos-biomarcadores-es.json"), JSON.stringify(es));
    const d2 = dataChecks.find((c) => c.id === "D2")!;
    const run = () => d2.run(makeCtx({ root: ROOT, seedDir, thresholds: {} }));
    expect((await run()).status).toBe("pass");
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: [] }));
    expect((await run()).failures.map((f) => f.key)).toEqual(["_untranslated"]);
    fs.writeFileSync(path.join(seedDir, "compile-report.json"), JSON.stringify({ untranslated: [entry] }));
    const r = await run();
    expect(r.failures.map((f) => f.key)).toEqual(["hs_crp|both|All Adults|untranslated|Nota_Método"]);
    expect(r.metrics?.untranslated).toBe(1);
  });

  it("D2 reads the method note, reference source and none-because reason from both files, so English in the Spanish file fails whatever the report lists", async () => {
    // Two rows, so the check must read each row's own columns; the copied texts sit on the second row only.
    const seedDir = tmpSeed([
      { name: "hs-CRP", nl: null, nh: 3, ol: null, oh: 1 },
      { name: "Ferritin", nl: 30, nh: 300, ol: 50, oh: 150 },
    ]);
    const enFile = path.join(seedDir, "biomarker-ranges-en.json");
    const esFile = path.join(seedDir, "rangos-biomarcadores-es.json");
    const write = (i: number, enRow: Record<string, unknown>, esRow: Record<string, unknown>) => {
      const en = JSON.parse(fs.readFileSync(enFile, "utf8"));
      const es = JSON.parse(fs.readFileSync(esFile, "utf8"));
      Object.assign(en.biomarker_ranges[i], enRow);
      Object.assign(es.rangos_biomarcadores[i], esRow);
      for (const r of es.rangos_biomarcadores) r.Grupo_Edad = "Todos los Adultos";
      fs.writeFileSync(enFile, JSON.stringify(en));
      fs.writeFileSync(esFile, JSON.stringify(es));
    };
    const english = { Method_Note: "High-sensitivity immunoassay; repeat after an infection.", Reference_Source: "Pearson et al., Circulation 2003", Critical_None_Reason: "No single value needs same-day action." };
    const spanish = { Nota_Método: "Inmunoensayo de alta sensibilidad; repetir tras una infección.", Fuente_Referencia: "Pearson y col., Circulation 2003", Motivo_Sin_Crítico: "Ningún valor aislado exige actuar en el día." };
    const d2 = dataChecks.find((c) => c.id === "D2")!;
    const run = () => d2.run(makeCtx({ root: ROOT, seedDir, thresholds: {} }));
    const keys = async () => (await run()).failures.map((f) => f.key).sort();
    // Spanish text in every column of both rows: nothing to report.
    write(0, english, spanish);
    write(1, english, spanish);
    expect(await keys()).toEqual([]);
    // The second row stated its English texts as its Spanish fields, which the compile writes as given and lists
    // nowhere: as given, in capitals with outer spaces, and with a doubled inner space. The first row's none-because
    // reason is empty in both files, which says nothing. A directory with neither changes.json nor
    // compile-report.json, as the compile's --write-seed leaves it.
    write(0, { Critical_None_Reason: "" }, { Motivo_Sin_Crítico: "" });
    write(1, english, { Nota_Método: english.Method_Note, Fuente_Referencia: `  ${english.Reference_Source.toUpperCase()} `, Motivo_Sin_Crítico: english.Critical_None_Reason.replace(" ", "  ") });
    const copied = ["ferritin|both|All Adults|untranslated|Fuente_Referencia", "ferritin|both|All Adults|untranslated|Motivo_Sin_Crítico", "ferritin|both|All Adults|untranslated|Nota_Método"];
    expect(await keys()).toEqual(copied);
    // The same files in a compile output whose report lists nothing, or whose list was emptied by hand.
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: [] }));
    fs.writeFileSync(path.join(seedDir, "compile-report.json"), JSON.stringify({ untranslated: [] }));
    expect(await keys()).toEqual(copied);
    // A column the report names too is counted once, with the report's explanation.
    const entry = { seed_key: "ferritin|both|All Adults", field: "Nota_Método", from_field: "method_note", spanish_field: "method_note_es" };
    fs.writeFileSync(path.join(seedDir, "compile-report.json"), JSON.stringify({ untranslated: [entry] }));
    const r = await run();
    expect(r.failures.map((f) => f.key).sort()).toEqual(copied);
    expect(r.metrics?.untranslated).toBe(3);
    expect(r.failures.find((f) => f.key.endsWith("|Nota_Método"))?.detail).toContain("the row has no method_note_es");
  });

  it("D2 compares the six bounds, the critical limits the compile writes in both files included", () => {
    const en: RawEn[] = [{ Biomarker: "Potassium", Unit: "mmol/L", Sex: "Both", Age_Group: "All Adults", Normal_Low: 3.5, Normal_High: 5.1, Critical_Low: 2.5, Critical_High: 6.5 }];
    const es: RawEs[] = [{ Biomarcador: "Potasio", Unidad: "mmol/L", Sexo: "Ambos", Grupo_Edad: "Todos los Adultos", Normal_Bajo: 3.5, Normal_Alto: 5.1, Crítico_Bajo: 2.5, Crítico_Alto: 6.0 }];
    const rs = buildRows(en, es);
    expect(rs[0].es_critical_low).toBe(2.5);
    expect(checkParity(rs, 1, 1)).toEqual([{ key: "potassium|both|All Adults|critical_high", detail: "EN 6.5 vs ES 6" }]);
  });

  it("D3 exempts a decision-limit row that records its source in Reference_Source, the column the compile writes", () => {
    const en: RawEn[] = [{ Biomarker: "hs-CRP", Unit: "mg/L", Sex: "Both", Age_Group: "All Adults", Normal_Low: null, Normal_High: 3, Reference_Basis: "decision_limit", Reference_Source: "f04-E01 (CDC/AHA 2003)" }];
    const es: RawEs[] = [{ Biomarcador: "PCR ultrasensible", Unidad: "mg/L", Sexo: "Ambos", Grupo_Edad: "Todos los Adultos", Normal_Bajo: null, Normal_Alto: 3 }];
    const cat: CatalogueRow[] = [{ code: "B0851", description: "PCR", unit: "mg/L", sex: "both", sex_raw: "", condition: "", age_low: 0, age_high: 999, age_raw: "0-999", low: null, high: 3.01, low_raw: "", high_raw: "<3.01", line: 308 }];
    const withSource = buildRows(en, es);
    expect(withSource[0].source).toBe("f04-E01 (CDC/AHA 2003)");
    const rep = checkLabConcordance(withSource, cat, { B0851: "hs_crp" });
    expect(rep.failures).toEqual([]);
    expect(rep.metrics.exempt_rows).toBe(1);
    // Without its source the row is compared with the catalogue: 3 is not 3.01.
    const noSource = buildRows([{ ...en[0], Reference_Source: null }], es);
    expect(checkLabConcordance(noSource, cat, { B0851: "hs_crp" }).failures.map((f) => f.key)).toEqual(["hs_crp|both|All Adults|bounds"]);
  });
});

describe("data (D5 one source of truth)", () => {
  // A production row; the snapshot has no critical-limit columns, so production's critical limits are null.
  const prodRow = (key: string, age: string, nl: number | null, nh: number | null, ol: number | null, oh: number | null, unit = "g/L") => ({ biomarker_key: key, sex: "both", age_group_en: age, unit_en: unit, normal_low: nl, normal_high: nh, optimal_low: ol, optimal_high: oh, critical_low: null as number | null, critical_high: null as number | null });
  const K = "albumin|both|All Adults";
  // compile.js changes.json entries: database key, op, field, from, to, reason, evidence_ids, reason_source.
  const change = (row_key: string, op: string, field: string, from: unknown, to: unknown, extra: Record<string, unknown> = {}) => ({ row_key, loop_row_key: null, family: "f01_x", source: "decisions", op, field, from, to, direction: "neutral", reason: "Echevarne prints 32-48 g/L (catalogue line 23).", evidence_ids: ["F01-E10"], reason_source: "decision", ...extra });
  // The forward migration as the compile writes it (compile-sql.js), read as D5 reads it.
  const mig = (written: DbLike[], deleted: DbLike[] = [], base: DbLike[] = [], file = "compiled/migration.sql") => parseForwardMigration(forwardSql(written, deleted, base), file);
  const documented = (changes: unknown[], migration: ForwardMigration | null = null): DocumentedChanges => ({ file: "compiled/changes.json", kind: "changes.json", changes: changesFromCompile({ changes, production_only: [] })!, migration });
  // Seed: albumin 32-48, optimal floor 41, no ceiling. Production: 35-48, optimal 42-48.
  const seed = rows([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null }]);
  const prod = [prodRow("albumin", "All Adults", 35, 48, 42, 48)];
  const allThree = [change(K, "modify", "normal_low", 35, 32), change(K, "modify", "optimal_low", 42, 41), change(K, "modify", "optimal_high", 48, null)];
  // The compile's migration for this seed writes albumin as the seed holds it.
  const albuminMig = () => mig([{ ...prodRow("albumin", "All Adults", 32, 48, 41, null), name_en: "Albumin", explanatory_numbers: [2, 4], tested_2x_year: true }], [], prod);
  const unlisted = "(no forward migration was written with compiled/changes.json, so no value is documented)";

  // Production's albumin row on every column (compile-baseline.js buildBaseline, what D5 reads), and a seed pair built
  // from it (compile-rows.js pairFromDbRow) that holds the given bounds and critical limits in both files: a seed equal
  // to production on every other column, as the compile's seed is for a row whose other columns the pack keeps.
  const baselineLib = toolRequire(path.join(ROOT, "docs/signoff/tools/lib/compile-baseline.js")) as { buildBaseline(): { rows: DbRow[] } };
  let baselineAlbumin: DbRow | null = null;
  const prodAlbumin = (): DbRow => (baselineAlbumin ??= baselineLib.buildBaseline().rows.find((r) => r.biomarker_key === "albumin" && r.sex === "both" && r.age_group_en === "All Adults")!);
  type Bounds = { nl: number | null; nh: number | null; ol: number | null; oh: number | null; cl?: number | null; ch?: number | null };
  const albuminPair = (b: Bounds): { en: RawEn; es: RawEs } => {
    const { en, es } = compileRows.pairFromDbRow(prodAlbumin(), {}, () => {});
    Object.assign(en, { Normal_Low: b.nl, Normal_High: b.nh, Optimal_Low: b.ol, Optimal_High: b.oh, Critical_Low: b.cl ?? null, Critical_High: b.ch ?? null });
    Object.assign(es, { Normal_Bajo: b.nl, Normal_Alto: b.nh, Óptimo_Bajo: b.ol, Óptimo_Alto: b.oh, Crítico_Bajo: b.cl ?? null, Crítico_Alto: b.ch ?? null });
    return { en, es };
  };
  const pairSeedDir = (...pairs: { en: RawEn; es: RawEs }[]): string => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-seed-"));
    fs.writeFileSync(path.join(dir, "biomarker-ranges-en.json"), JSON.stringify({ biomarker_ranges: pairs.map((p) => p.en) }));
    fs.writeFileSync(path.join(dir, "rangos-biomarcadores-es.json"), JSON.stringify({ rangos_biomarcadores: pairs.map((p) => p.es) }));
    return dir;
  };
  // The decided albumin: 32-48 g/L, optimal floor 41, no ceiling.
  const ALBUMIN_DECIDED: Bounds = { nl: 32, nh: 48, ol: 41, oh: null };

  it("counts every difference as unexplained when no documented change list exists", () => {
    const { failures, metrics } = checkSourceOfTruth(seed, prod);
    expect(failures.map((f) => f.key)).toEqual([`${K}|bounds`]);
    expect(failures[0].detail).toMatch(/^normal_low seed 32 vs production 35 \(no documented change list/);
    expect(metrics.explained_by_documented_changes).toBe(0);
  });

  it("explains a difference only when the change list states it and the forward migration writes the seed's value", () => {
    const { failures, metrics } = checkSourceOfTruth(seed, prod, { documented: documented(allThree, albuminMig()) });
    expect(failures).toEqual([]);
    expect(metrics.explained_by_documented_changes).toBe(3);
    expect(metrics.documented_changes_file).toBe("compiled/changes.json");
    expect(metrics.documented_migration_file).toBe("compiled/migration.sql");
    // The reason's document stands as the source when the change cites no evidence ids, as in compile.js's diff.json.
    const noIds = allThree.map((c) => ({ ...c, evidence_ids: [] }));
    expect(checkSourceOfTruth(seed, prod, { documented: documented(noIds, albuminMig()) }).failures).toEqual([]);
    // Without the forward migration no value is documented, so nothing is explained.
    const bare = checkSourceOfTruth(seed, prod, { documented: documented(allThree) });
    expect(bare.failures.map((f) => f.detail)).toEqual([["normal_low seed 32 vs production 35", "optimal_low seed 41 vs production 42", "optimal_high seed null vs production 48"].map((t) => `${t} ${unlisted}`).join("; ")]);
    expect(bare.metrics.explained_by_documented_changes).toBe(0);
  });

  it("keeps an undocumented field failing and names only that field", () => {
    const { failures } = checkSourceOfTruth(seed, prod, { documented: documented(allThree.slice(0, 2), albuminMig()) });
    expect(failures.map((f) => f.key)).toEqual([`${K}|bounds`]);
    expect(failures[0].detail).toBe("optimal_high seed null vs production 48 (not documented in compiled/changes.json)");
  });

  it("counts placeholder reasons, placeholder words that begin a text and missing sources as missing", () => {
    const placeholders = [null, "", "unexplained", "**unexplained**", "Unexplained: no decision change matches", "TODO", "TODO: add the reason", "Reason: TODO", "TBD - pending physician", "FIXME later", "n/a", "N/A (see decision)", "none", "None yet", "unknown source", "Missing", "pending", "-", "- see decision", "?", "x", "Replace with the reason for the difference.", "Not applicable", "TBC", "Reason TBC", "To be confirmed", "To be determined by the physician"];
    for (const reason of placeholders) {
      const { failures } = checkSourceOfTruth(seed, prod, { documented: documented([...allThree.slice(0, 2), change(K, "modify", "optimal_high", 48, null, { reason })], albuminMig()) });
      expect(failures.map((f) => f.detail)).toEqual([`optimal_high seed null vs production 48 (documented in compiled/changes.json without a reason)`]);
    }
    const noSource = change(K, "modify", "optimal_high", 48, null, { evidence_ids: [], reason_source: null });
    expect(checkSourceOfTruth(seed, prod, { documented: documented([...allThree.slice(0, 2), noSource], albuminMig()) }).failures[0].detail).toMatch(/optimal_high .* without a source\)$/);
    for (const t of ["Echevarne prints 32-48 g/L.", "F01-E10, F01-E11", "decision", "decision+verify", "-5% shift at age 60 (f03-E04)", "Na+ falls with water excess (f18-E02)", "Nonetheless the band is kept"]) expect(isStated(t)).toBe(true);
    for (const t of [undefined, null, 3, "  ", "unexplained", "(unexplained)", "TBD.", "unknown", "?", "NA", "n.a.", "x", "."]) expect(isStated(t)).toBe(false);
  });

  it("does not let a documented change explain a different difference", () => {
    const stale = [allThree[0], allThree[1], change(K, "modify", "optimal_high", 50, null)];
    const { failures } = checkSourceOfTruth(seed, prod, { documented: documented(stale, albuminMig()) });
    expect(failures[0].detail).toBe("optimal_high seed null vs production 48 (documented in compiled/changes.json as 50 → null, not this difference)");
  });

  it("checks each difference against the value the forward migration writes, so a seed edited after the compile fails", () => {
    // The seed's albumin floor edited to 30 after the compile documented 35 -> 32.
    const edited = rows([{ name: "Albumin", unit: "g/L", nl: 30, nh: 48, ol: 41, oh: null }]);
    const a = checkSourceOfTruth(edited, prod, { documented: documented(allThree, albuminMig()) });
    expect(a.failures.map((f) => f.detail)).toEqual(["normal_low seed 30 vs production 35 (documented in compiled/changes.json as 35 → 32, not this difference; the forward migration compiled/migration.sql writes normal_low 32)"]);
    // The change list edited too: the forward migration still documents 32.
    const listed30 = [change(K, "modify", "normal_low", 35, 30), ...allThree.slice(1)];
    expect(checkSourceOfTruth(edited, prod, { documented: documented(listed30, albuminMig()) }).failures.map((f) => f.detail)).toEqual(["normal_low seed 30 vs production 35 (the forward migration compiled/migration.sql writes normal_low 32)"]);
    // A unit is compared the same way.
    const unitSeed = rows([{ name: "Albumin", unit: "g/dL", nl: 32, nh: 48, ol: 41, oh: null }]);
    const unitList = [...allThree, change(K, "modify", "unit_en", "g/L", "g/dL")];
    expect(checkSourceOfTruth(unitSeed, prod, { documented: documented(unitList, albuminMig()) }).failures[0].detail).toBe('unit seed "g/dL" vs production "g/L" (the forward migration compiled/migration.sql writes unit_en "g/L")');
  });

  it("fails a documented change the seed does not carry, and a forward migration it cannot read", () => {
    // The seed holds production's albumin row while the migration writes the decision's values.
    const kept = rows([{ name: "Albumin", unit: "g/L", nl: 35, nh: 48, ol: 42, oh: 48 }]);
    const r = checkSourceOfTruth(kept, prod, { documented: documented(allThree, albuminMig()) });
    expect(r.failures).toEqual([{ key: `${K}|documented_migration`, detail: "the seed keeps production's normal_low 35, optimal_low 42, optimal_high 48; the forward migration compiled/migration.sql writes normal_low 32, optimal_low 41, optimal_high null" }]);
    expect(r.metrics.documented_changes_not_in_seed).toBe(1);
    // A row the migration deletes while the seed keeps it, and a row it adds that the seed lacks.
    const nlr = prodRow("nlr", "18-59", 0.8, 3.5, 0.8, 2, "ratio");
    const m = mig([nlr], [prod[0]], prod);
    expect(checkSourceOfTruth(kept, prod, { documented: documented([], m) }).failures.map((f) => `${f.key} :: ${f.detail}`).sort()).toEqual([
      `${K}|documented_migration :: the forward migration compiled/migration.sql deletes this row; the seed keeps it`,
      "nlr|both|18-59|documented_migration :: the forward migration compiled/migration.sql adds this row; the seed does not hold it",
    ]);
    // A statement on the table that D5 cannot read: no value is taken from the file, and the file is named.
    const extra = parseForwardMigration(`${forwardSql([{ ...prodRow("albumin", "All Adults", 32, 48, 41, null) }], [], prod)}\nupdate public.biomarker_references set normal_low = 30 where biomarker_key = 'albumin';\n`, "compiled/migration.sql");
    expect(extra.unreadable).toHaveLength(1);
    const u = checkSourceOfTruth(seed, prod, { documented: documented(allThree, extra) });
    expect(u.failures.map((f) => f.key).sort()).toEqual([`${K}|bounds`, "migration|compiled/migration.sql|unreadable"]);
    expect(u.failures.find((f) => f.key === `${K}|bounds`)!.detail).toMatch(/^normal_low seed 32 vs production 35 \(the forward migration compiled\/migration\.sql has statements D5 cannot read, so no value is documented\)/);
  });

  it("explains added and removed rows only when documented and written by the forward migration with the seed's values", () => {
    const egfr = (age: string, nl: number, ol: number | null) => prodRow("egfr_creatinine_based", age, nl, null, ol, null, "mL/min/1.73m²");
    const s = rows([
      { name: "Albumin", unit: "g/L", nl: 35, nh: 48, ol: 42, oh: 48 },
      { name: "eGFR (Creatinine-based)", unit: "mL/min/1.73m²", age: "40-84", nl: 60, nh: null, ol: 90, oh: null },
    ]);
    const p = [prodRow("albumin", "All Adults", 35, 48, 42, 48), egfr("40-59", 60, 90)];
    const m = mig([egfr("40-84", 60, 90)], [egfr("40-59", 60, 90)], p);
    // The removal carries the decision's own record of it (decision CEO-11): a reason a person wrote.
    const REMOVED = { reason: "Merged into the 40-84 row: Echevarne prints one eGFR interval from 40 (catalogue line 212).", evidence_ids: [] };
    const rowsList = [change("egfr_creatinine_based|both|40-84", "add", "row", null, "row added"), change("egfr_creatinine_based|both|40-59", "remove", "row", "row present", null, REMOVED)];
    expect(checkSourceOfTruth(s, p, { documented: documented(rowsList, m) }).failures).toEqual([]);
    expect(checkSourceOfTruth(s, p, { documented: documented([], m) }).failures.map((f) => f.key).sort()).toEqual(["egfr_creatinine_based|both|40-59|row_only_in_production", "egfr_creatinine_based|both|40-84|row_only_in_seed"]);
    // The compile's former stock sentence for a removed row is no reason: the removal fails with the migration's delete
    // in place, as does a removal with no reason at all.
    for (const extra of [{ reason: "not in the family's decision final_rows", evidence_ids: [] }, { reason: null, evidence_ids: [], reason_source: null }]) {
      const stock = [rowsList[0], change("egfr_creatinine_based|both|40-59", "remove", "row", "row present", null, extra)];
      const f = checkSourceOfTruth(s, p, { documented: documented(stock, m) }).failures;
      expect(f.map((x) => x.key)).toEqual(["egfr_creatinine_based|both|40-59|row_only_in_production"]);
      expect(f[0].detail).toMatch(/^production row \(key, sex, age group\) has no seed counterpart; /);
    }
    // The added row edited after the compile: the migration documents 60 and 90.
    const edited = rows([
      { name: "Albumin", unit: "g/L", nl: 35, nh: 48, ol: 42, oh: 48 },
      { name: "eGFR (Creatinine-based)", unit: "mL/min/1.73m²", age: "40-84", nl: 45, nh: null, ol: 50, oh: null },
    ]);
    expect(checkSourceOfTruth(edited, p, { documented: documented(rowsList, m) }).failures).toEqual([
      { key: "egfr_creatinine_based|both|40-84|row_only_in_seed", detail: "row (key, sex, age group) has no production counterpart; the forward migration compiled/migration.sql writes normal_low 60 (seed 45), optimal_low 90 (seed 50)" },
    ]);
    // A migration that neither adds the new row nor deletes the old one documents neither.
    const none = checkSourceOfTruth(s, p, { documented: documented(rowsList, mig([], [], p)) });
    expect(none.failures.map((f) => f.detail).sort()).toEqual([
      "production row (key, sex, age group) has no seed counterpart; the forward migration compiled/migration.sql does not delete this row",
      "row (key, sex, age group) has no production counterpart; the forward migration compiled/migration.sql does not add this row",
    ]);
  });

  it("compares the critical limits as it compares the four bounds: listed with a reason and source, and written by the forward migration", () => {
    // Production has no critical-limit column (null). The seed holds albumin as decided, with a critical floor of 15 g/L.
    const critSeed = rows([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null, cl: 15 }]);
    const critChange = change(K, "modify", "critical_low", null, 15, { reason: "Versus production: critical limit as its own field (critical-limits draft).", evidence_ids: ["F01-E20"] });
    const written = (cl: number | null, ch: number | null = null) => mig([{ ...prodRow("albumin", "All Adults", 32, 48, 41, null), critical_low: cl, critical_high: ch }], [], prod);
    const ok = checkSourceOfTruth(critSeed, prod, { documented: documented([...allThree, critChange], written(15)) });
    expect(ok.failures).toEqual([]);
    expect(ok.metrics.explained_by_documented_changes).toBe(4);
    expect(ok.metrics.compared_fields).toBe("normal_low,normal_high,optimal_low,optimal_high,critical_low,critical_high,unit_en");
    // The forward migration writes another critical limit than the seed holds.
    expect(checkSourceOfTruth(critSeed, prod, { documented: documented([...allThree, critChange], written(20)) }).failures).toEqual([
      { key: `${K}|bounds`, detail: "critical_low seed 15 vs production null (the forward migration compiled/migration.sql writes critical_low 20)" },
    ]);
    // The change list must list the difference with a stated reason and source, and from/to equal to production's and the seed's values.
    const detail = (list: unknown[]) => checkSourceOfTruth(critSeed, prod, { documented: documented(list, written(15)) }).failures.map((f) => f.detail);
    expect(detail(allThree)).toEqual(["critical_low seed 15 vs production null (not documented in compiled/changes.json)"]);
    expect(detail([...allThree, { ...critChange, reason: "TBD" }])).toEqual(["critical_low seed 15 vs production null (documented in compiled/changes.json without a reason)"]);
    expect(detail([...allThree, { ...critChange, evidence_ids: [], reason_source: null }])).toEqual(["critical_low seed 15 vs production null (documented in compiled/changes.json without a source)"]);
    expect(detail([...allThree, { ...critChange, to: 20 }])).toEqual(["critical_low seed 15 vs production null (documented in compiled/changes.json as null → 20, not this difference)"]);
    // A critical limit the forward migration writes that the seed does not carry.
    expect(checkSourceOfTruth(seed, prod, { documented: documented(allThree, written(null, 150)) }).failures).toEqual([
      { key: `${K}|documented_migration`, detail: "the seed keeps production's critical_high null; the forward migration compiled/migration.sql writes critical_high 150" },
    ]);
    // Without a forward migration a critical limit is no more explained than a bound.
    expect(checkSourceOfTruth(critSeed, prod, { documented: documented([...allThree, critChange]) }).failures[0].detail).toMatch(/; critical_low seed 15 vs production null \(no forward migration was written with compiled\/changes\.json, so no value is documented\)$/);
    // A row the migration adds is compared on its critical limits too.
    const nlrSeed = rows([{ name: "Albumin", unit: "g/L", nl: 35, nh: 48, ol: 42, oh: 48 }, { name: "NLR", unit: "ratio", age: "60+", nl: 0.8, nh: 3.9, ch: 10 }]);
    const nlr = (ch: number | null) => ({ ...prodRow("nlr", "60+", 0.8, 3.9, null, null, "ratio"), critical_high: ch });
    const added = [change("nlr|both|60+", "add", "row", null, "row added")];
    expect(checkSourceOfTruth(nlrSeed, prod, { documented: documented(added, mig([nlr(10)], [], prod)) }).failures).toEqual([]);
    expect(checkSourceOfTruth(nlrSeed, prod, { documented: documented(added, mig([nlr(null)], [], prod)) }).failures).toEqual([
      { key: "nlr|only_in_seed", detail: "marker exists in the seed but not in production plus the applied migrations: nlr|both|60+ the forward migration compiled/migration.sql writes critical_high null (seed 10)" },
    ]);
  });

  it("fails through the check a forward migration that writes another critical limit than the seed, and a Spanish critical limit that differs", async () => {
    const pair = albuminPair({ ...ALBUMIN_DECIDED, cl: 15 });
    const seedDir = pairSeedDir(pair);
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    const critChange = change(K, "modify", "critical_low", null, 15, { reason: "Versus production: critical limit as its own field (critical-limits draft).", evidence_ids: ["F01-E20"] });
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: [...allThree, critChange], production_only: [] }));
    // The compile's migration writes the seed's database row on every column (compile-rows.js dbRowFromPair).
    const writeMigration = (cl: number) => fs.writeFileSync(path.join(seedDir, "migration.sql"), forwardSql([{ ...(compileRows.dbRowFromPair(pair) as DbLike), critical_low: cl }], [], prod));
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const albumin = async () => (await d5.run(ctx)).failures.filter((f) => /^(es\|)?albumin\|/.test(f.key)).map((f) => `${f.key} :: ${f.detail}`);
    writeMigration(15);
    expect(await albumin()).toEqual([]);
    writeMigration(20);
    const off = await albumin();
    expect(off).toHaveLength(2);
    expect(off[0]).toMatch(/^albumin\|both\|All Adults\|bounds :: critical_low seed 15 vs production null \(the forward migration .*migration\.sql writes critical_low 20\)$/);
    // The change list's critical floor of 15 is not what the migration writes either.
    expect(off[1]).toMatch(/^albumin\|both\|All Adults\|change_list :: .*changes\.json lists changes the forward migration does not make: critical_low to 15 \(the forward migration .*migration\.sql writes critical_low 20\)$/);
    // The Spanish file's critical limit is held to the English one (D2's six bounds).
    writeMigration(15);
    const esFile = path.join(seedDir, "rangos-biomarcadores-es.json");
    const es = JSON.parse(fs.readFileSync(esFile, "utf8"));
    es.rangos_biomarcadores[0]["Crítico_Bajo"] = 14;
    fs.writeFileSync(esFile, JSON.stringify(es));
    expect(await albumin()).toEqual(["es|albumin|both|All Adults|critical_low :: Spanish seed differs from English: EN 15 vs ES 14"]);
  });

  // A forward migration in the compile's statement shape (ALTER, INSERT … VALUES … ON CONFLICT … DO UPDATE SET c = excluded.c)
  // writing albumin with the given column names and values, edited by hand rather than written by compile-sql.js.
  const handMigration = (cols: string[], vals: string[], set: string[]) => `alter table public.biomarker_references
  add column if not exists critical_low numeric,
  add column if not exists critical_high numeric;
insert into public.biomarker_references (biomarker_key, sex, age_group_en, ${cols.join(", ")})
values
  ('albumin', 'both', 'All Adults', ${vals.join(", ")})
on conflict (biomarker_key, sex, age_group_en) do update set
${set.map((c) => `  ${c} = excluded.${c}`).join(",\n")};`;
  const BOUNDS_UNIT = ["unit_en", "normal_low", "normal_high", "optimal_low", "optimal_high"];
  const CRIT = ["critical_low", "critical_high"];
  // The same statements as handMigration writes, apart, so a test can move the upsert: albumin as decided (32-48 g/L,
  // optimal floor 41, no ceiling) with critical_low written as cl.
  const CRIT_ALTER = "alter table public.biomarker_references\n  add column if not exists critical_low numeric,\n  add column if not exists critical_high numeric;";
  const critUpsert = (cl: string) =>
    `insert into public.biomarker_references (biomarker_key, sex, age_group_en, ${[...BOUNDS_UNIT, ...CRIT].join(", ")})\n  values ('albumin', 'both', 'All Adults', 'g/L', 32, 48, 41, null, ${cl}, null)\n  on conflict (biomarker_key, sex, age_group_en) do update set\n${[...BOUNDS_UNIT, ...CRIT].map((c) => `    ${c} = excluded.${c}`).join(",\n")};`;
  // A critical floor of 15 g/L documented as a change from production's null, with a stated reason and source.
  const critChange15 = () => change(K, "modify", "critical_low", null, 15, { reason: "Versus production: critical limit as its own field (critical-limits draft).", evidence_ids: ["F01-E20"] });
  // An UPDATE that writes albumin back to production's values (35-48 g/L, optimal 42-48, no critical floor).
  const UPDATE_BACK = "update public.biomarker_references set normal_low = 35, optimal_low = 42, optimal_high = 48, critical_low = null where biomarker_key = 'albumin' and sex = 'both' and age_group_en = 'All Adults';";

  it("lists as unreadable an INSERT that quotes a bound or critical limit, quotes a column name, or sets a column its list leaves out, so a critical limit the seed does not hold cannot pass", () => {
    // The seed holds albumin as decided and no critical limit; the change list documents the three bound changes.
    const crit = (col: string, val: string) => handMigration([...BOUNDS_UNIT, col, "critical_high"], ["'g/L'", "32", "48", "41", "null", val, "null"], [...BOUNDS_UNIT, ...CRIT]);
    const run = (sql: string, s = seed) => checkSourceOfTruth(s, prod, { documented: documented(allThree, parseForwardMigration(sql, "compiled/migration.sql")) });
    // Written as a number, the critical limit the seed does not carry fails.
    expect(run(crit("critical_low", "15")).failures).toEqual([{ key: `${K}|documented_migration`, detail: "the seed keeps production's critical_low null; the forward migration compiled/migration.sql writes critical_low 15" }]);
    // PostgreSQL coerces '15' to 15 and takes "critical_low" as the column critical_low. D5 reads neither form, so the
    // file is unreadable: no value is taken from it and none of the seed's bound differences is explained.
    const unexplained = (sql: string, s = seed, open = ["normal_low seed 32 vs production 35", "optimal_low seed 41 vs production 42", "optimal_high seed null vs production 48"]) => {
      const r = run(sql, s);
      expect(r.failures.map((f) => f.key).sort()).toEqual([`${K}|bounds`, "migration|compiled/migration.sql|unreadable"]);
      expect(r.failures.find((f) => f.key === `${K}|bounds`)!.detail).toBe(open.map((t) => `${t} (the forward migration compiled/migration.sql has statements D5 cannot read, so no value is documented)`).join("; "));
      expect(r.metrics.explained_by_documented_changes).toBe(0);
      return parseForwardMigration(sql, "compiled/migration.sql").unreadable;
    };
    expect(unexplained(crit("critical_low", "'15'"))).toEqual([expect.stringMatching(/^statement 2 \(critical_low is a quoted text, not a finite number or null\): insert into public\.biomarker_references/)]);
    expect(unexplained(crit('"critical_low"', "15"))).toEqual([
      "file (a double-quoted name at line 4): PostgreSQL or psql may read the file otherwise than D5 does",
      expect.stringMatching(/^statement 2 \(the column-list entry "critical_low" is not an unquoted name\): /),
    ]);
    // A critical limit beyond the range of a double is not taken as null.
    expect(unexplained(crit("critical_low", "1e400"))).toEqual([expect.stringMatching(/^statement 2 \(critical_low is a number beyond the range of a double, not a finite number or null\)/)]);
    // A bound: the documented removal of optimal_high (48 -> null) is not explained by a migration that keeps '48'.
    const bound = (oh: string) => handMigration(BOUNDS_UNIT, ["'g/L'", "32", "48", "41", oh], BOUNDS_UNIT);
    expect(run(bound("null")).failures).toEqual([]);
    expect(run(bound("48")).failures).toEqual([{ key: `${K}|bounds`, detail: "optimal_high seed null vs production 48 (the forward migration compiled/migration.sql writes optimal_high 48)" }]);
    expect(unexplained(bound("'48'"))).toEqual([expect.stringMatching(/^statement 2 \(optimal_high is a quoted text, not a finite number or null\)/)]);
    // DO UPDATE SET optimal_high with optimal_high left out of the column list: PostgreSQL writes the excluded row's
    // optimal_high, the column's default (null; supabase/migrations/20260403000000_full_schema.sql declares none), so
    // the documented removal 48 -> null is applied. A seed that keeps production's 48 does not carry it; production's 48
    // was read before, which passed that seed.
    const setOnly = handMigration(BOUNDS_UNIT.slice(0, 4), ["'g/L'", "32", "48", "41"], BOUNDS_UNIT);
    const keeps48 = rows([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: 48 }]);
    expect(unexplained(setOnly, keeps48, ["normal_low seed 32 vs production 35", "optimal_low seed 41 vs production 42"])).toEqual([
      expect.stringMatching(/^statement 2 \(DO UPDATE SET names optimal_high, which the column list leaves out: PostgreSQL would write its default\)/),
    ]);
    // The same for a critical limit.
    expect(unexplained(handMigration(BOUNDS_UNIT, ["'g/L'", "32", "48", "41", "null"], [...BOUNDS_UNIT, "critical_low"]))).toEqual([expect.stringMatching(/DO UPDATE SET names critical_low, which the column list leaves out/)]);
    // The compile's form of the same pack (compile-sql.js, every column listed and set) stays readable and explains all three.
    expect(run(forwardSql([{ ...prodRow("albumin", "All Adults", 32, 48, 41, null), critical_low: null }], [], prod)).metrics.explained_by_documented_changes).toBe(3);
  });

  it("fails through the check a forward migration that writes a quoted critical limit the seed does not hold", async () => {
    // The hand-edited migration writes only the bounds, unit and critical limits: the other columns keep production's
    // values, which this seed holds (albuminPair).
    const seedDir = pairSeedDir(albuminPair(ALBUMIN_DECIDED));
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: allThree, production_only: [] }));
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const albumin = async (col: string, val: string) => {
      fs.writeFileSync(path.join(seedDir, "migration.sql"), handMigration([...BOUNDS_UNIT, col, "critical_high"], ["'g/L'", "32", "48", "41", "null", val, "null"], [...BOUNDS_UNIT, ...CRIT]));
      const r = await d5.run(ctx);
      return r.failures
        .filter((f) => /^albumin\||^migration\|/.test(f.key))
        .map((f) => f.key.replace(/^migration\|.*\|unreadable$/, "migration|unreadable"))
        .sort();
    };
    expect(await albumin("critical_low", "null")).toEqual([]);
    expect(await albumin("critical_low", "15")).toEqual([`${K}|documented_migration`]);
    // A file D5 cannot read documents no value and makes no listed change.
    expect(await albumin("critical_low", "'15'")).toEqual([`${K}|bounds`, `${K}|change_list`, "migration|unreadable"]);
    expect(await albumin('"critical_low"', "15")).toEqual([`${K}|bounds`, `${K}|change_list`, "migration|unreadable"]);
  });

  it("retires a production-only marker only with every row removed and an explicit record in a valid decisions file", () => {
    const s = rows([{ name: "Albumin", unit: "g/L", nl: 35, nh: 48, ol: 42, oh: 48 }]);
    const copper = prodRow("copper_serum", "All Adults", 70, 140, null, null, "µg/dL");
    const p = [prodRow("albumin", "All Adults", 35, 48, 42, 48), copper];
    const m = mig([], [copper], p);
    // The decision's record of the removal, and the removal entry compile.js writes from it for a production row the
    // decision does not carry (decision CEO-11: the record's reason, the decision's changes as its source).
    const record = { row_key: "copper_serum|both|All Adults|none", field: "row", from: "row present", to: null, direction: "neutral", reason: "Not on the laboratory's panel; retired (f25-D01).", evidence_ids: [] };
    const removal = change("copper_serum|both|All Adults", "remove", "row", "row present", null, { reason: record.reason, evidence_ids: [], reason_from: "decision.changes", documented_source: "decisions/f25_x.json changes" });
    const generated = documented([removal], m);
    const lookup =
      (doc: RetirementDecision | null, errors: string[]): RetirementLookup =>
      (marker, productionRows) => {
        const gaps = retirementGaps(marker, productionRows, "decisions/f25_x.json", doc, errors);
        return { file: gaps.length ? null : "decisions/f25_x.json", gaps };
      };
    const detailOf = (retiredBy?: RetirementLookup, doc = generated) => checkSourceOfTruth(s, p, { documented: doc, retiredBy }).failures.map((f) => `${f.key} :: ${f.detail}`);
    expect(detailOf()).toEqual(["copper_serum|only_in_production :: marker exists in production but not in the seed; it must enter the seed or be retired by a recorded decision: no recorded decision retires it (no decisions file was read)"]);
    // A decisions file that leaves the marker out says nothing about it, and the frozen validator rejects it.
    const omitting = detailOf(lookup({ final_rows: [{ marker_key: "zinc_serum" }], changes: [] }, ["final_rows: family key 'copper_serum' has no row"]));
    expect(omitting).toEqual([
      "copper_serum|only_in_production :: marker exists in production but not in the seed; it must enter the seed or be retired by a recorded decision: no recorded decision retires it (decisions/f25_x.json does not validate (1 errors; first: final_rows: family key 'copper_serum' has no row); no changes[] entry of decisions/f25_x.json retires copper_serum|both|All Adults|none (field \"row\", to null, a stated reason))",
    ]);
    // The explicit record in a file that validates retires the marker, with the removal documented and deleted.
    const valid = { final_rows: [{ marker_key: "zinc_serum" }], changes: [record] };
    expect(detailOf(lookup(valid, []))).toEqual([]);
    // Each condition is needed: a valid file, the record's reason, to null, no final row of the marker, the removal in the change list and the migration.
    expect(detailOf(lookup(valid, ["schema /changes/0 must have required property 'direction'"]))[0]).toMatch(/decisions\/f25_x\.json does not validate/);
    expect(detailOf(lookup({ ...valid, changes: [{ ...record, reason: "TODO" }] }, []))[0]).toMatch(/no changes\[\] entry of decisions\/f25_x\.json retires copper_serum\|both\|All Adults\|none/);
    expect(detailOf(lookup({ ...valid, changes: [{ ...record, to: "row removed" }] }, []))[0]).toMatch(/no changes\[\] entry/);
    expect(detailOf(lookup({ ...valid, final_rows: [{ marker_key: "copper_serum" }] }, []))[0]).toMatch(/decisions\/f25_x\.json keeps final rows of copper_serum/);
    expect(detailOf(lookup(valid, []), documented([], m))[0]).toMatch(/: copper_serum\|both\|All Adults not documented in compiled\/changes\.json$/);
    expect(detailOf(lookup(valid, []), documented([removal], mig([], [], p)))[0]).toMatch(/: copper_serum\|both\|All Adults the forward migration compiled\/migration\.sql does not delete this row$/);
  });

  it("asks docs/signoff/tools/validate.js whether a decisions file holds a valid retirement, and the frozen validator refuses one that leaves a family key out", () => {
    const work = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-retire-"));
    const W = path.join(ROOT, "docs/signoff/work");
    const families = JSON.parse(fs.readFileSync(path.join(W, "families.json"), "utf8"));
    families.families.f04_inflammation.keys.push("selenium_serum");
    fs.writeFileSync(path.join(work, "families.json"), JSON.stringify(families));
    for (const dir of ["research", "verify", "decisions"]) {
      fs.mkdirSync(path.join(work, dir));
      fs.copyFileSync(path.join(W, dir, "f04_inflammation.json"), path.join(work, dir, "f04_inflammation.json"));
    }
    const decFile = path.join(work, "decisions", "f04_inflammation.json");
    const dec = JSON.parse(fs.readFileSync(decFile, "utf8"));
    dec.changes.push({ row_key: "selenium_serum|both|All Adults|none", field: "row", from: "row present", to: null, direction: "neutral", reason: "Retired: not on the laboratory's panel.", evidence_ids: [] });
    fs.writeFileSync(decFile, JSON.stringify(dec));
    const ctx = makeCtx({ root: ROOT, workDir: work, thresholds: {} });
    const selenium = [prodRow("selenium_serum", "All Adults", 70, 150, null, null, "µg/L")];
    const validator = toolRequire(path.join(ROOT, "docs/signoff/tools/validate.js")) as { validateFile(kind: string, file: string, opts?: Record<string, unknown>): { errors: string[] } };
    expect(validator.validateFile("decision", decFile, { workDir: work, families: path.join(work, "families.json") }).errors).toContain("final_rows: family key 'selenium_serum' has no row");
    const real = retiringDecision(ctx)("selenium_serum", selenium);
    expect(real.file).toBeNull();
    expect(real.gaps).toHaveLength(1);
    expect(real.gaps[0]).toMatch(/decisions\/f04_inflammation\.json does not validate \(\d+ errors; first: /);
    // With a validator that finds nothing wrong the same record would retire the marker: the refusal is the validator's.
    expect(retiringDecision(ctx, () => [])("selenium_serum", selenium)).toEqual({ file: path.relative(ROOT, decFile).split(path.sep).join("/"), gaps: [] });
    expect(retiringDecision(ctx, () => [])("not_a_family_key", selenium).gaps[0]).toMatch(/^not_a_family_key is in no family of /);
    expect(retiringDecision(ctx, () => [])("ferritin", selenium).gaps[0]).toMatch(/^no .*decisions\/f14_iron\.json$/);
  });

  it("explains a marker only in the seed only when each row is added with the documented values", () => {
    const s = rows([{ name: "NLR", unit: "ratio", age: "18-59", nl: 0.8, nh: 3.5 }, { name: "NLR", unit: "ratio", age: "60+", nl: 0.8, nh: 3.9 }]);
    const nlr = (age: string, nh: number) => prodRow("nlr", age, 0.8, nh, null, null, "ratio");
    const m = mig([nlr("18-59", 3.5), nlr("60+", 3.9)]);
    const one = documented([change("nlr|both|18-59", "add", "row", null, "row added")], m);
    const r = checkSourceOfTruth(s, [], { documented: one });
    expect(r.failures.map((f) => f.key)).toEqual(["nlr|only_in_seed"]);
    expect(r.failures[0].detail).toMatch(/nlr\|both\|60\+ not documented in compiled\/changes\.json$/);
    const both = [change("nlr|both|18-59", "add", "row", null, "row added"), change("nlr|both|60+", "add", "row", null, "row added")];
    expect(checkSourceOfTruth(s, [], { documented: documented(both, m) }).failures).toEqual([]);
    const other = checkSourceOfTruth(s, [], { documented: documented(both, mig([nlr("18-59", 3.5), nlr("60+", 4.2)])) });
    expect(other.failures[0].detail).toMatch(/nlr\|both\|60\+ the forward migration compiled\/migration\.sql writes normal_high 4\.2 \(seed 3\.9\)$/);
  });

  it("reads the reconciliation diff and takes its values from the forward migration in the same folder", () => {
    const diffRow = { key: K, family: "f01_x", ops: ["modify"], fields: ["normal_low", "optimal_high", "optimal_low"], directions: ["loosen"], reason: "Echevarne prints 32-48 g/L.", unexplained_fields: ["optimal_high"], source: "F01-E10", evidence_ids: ["F01-E10"] };
    const changes = changesFromDiff({ rows: [diffRow] })!;
    expect(changes.map((c) => `${c.op}:${c.field}:${c.reason ? "reason" : "none"}`)).toEqual(["modify:normal_low:reason", "modify:optimal_high:none", "modify:optimal_low:reason"]);
    const forward = mig([{ ...prodRow("albumin", "All Adults", 32, 48, 41, null) }], [], prod, "reconciliation/forward.sql");
    const diffDoc = (rowsList: unknown[], migration: ForwardMigration | null = forward): DocumentedChanges => ({ file: "reconciliation/diff.json", kind: "reconciliation diff", changes: changesFromDiff({ rows: rowsList })!, migration });
    expect(checkSourceOfTruth(seed, prod, { documented: diffDoc([diffRow]) }).failures[0].detail).toBe("optimal_high seed null vs production 48 (documented in reconciliation/diff.json without a reason)");
    const explainedRow = { ...diffRow, unexplained_fields: [] };
    expect(checkSourceOfTruth(seed, prod, { documented: diffDoc([explainedRow]) }).failures).toEqual([]);
    expect(checkSourceOfTruth(seed, prod, { documented: diffDoc([{ ...explainedRow, source: "unexplained" }]) }).failures[0].detail).toMatch(/without a source\)$/);
    // A listed field whose seed value differs from the value the forward migration documents.
    const edited = rows([{ name: "Albumin", unit: "g/L", nl: 30, nh: 48, ol: 41, oh: null }]);
    expect(checkSourceOfTruth(edited, prod, { documented: diffDoc([explainedRow]) }).failures.map((f) => f.detail)).toEqual(["normal_low seed 30 vs production 35 (the forward migration reconciliation/forward.sql writes normal_low 32)"]);
    // The diff lists fields but no values: without a forward migration nothing is explained.
    const bare = checkSourceOfTruth(seed, prod, { documented: diffDoc([explainedRow], null) });
    expect(bare.metrics.explained_by_documented_changes).toBe(0);
    expect(bare.failures[0].detail).toMatch(/^normal_low seed 32 vs production 35 \(no forward migration was written with reconciliation\/diff\.json, so no value is documented\)/);
    const added = changesFromDiff({ rows: [{ key: "nlr|both|60+", ops: ["add"], fields: ["row"], reason: "r", source: "s" }] })!;
    expect(added).toEqual([{ row_key: "nlr|both|60+", op: "add", field: "row", reason: "r", source: "s", values: null }]);
    // A row that lists its fields one by one (changes[]: field, op, from, to, reason, source) gives each field its own
    // reason, source and values: a field keeps its reason when another field of the row has none.
    const perField = {
      ...diffRow,
      reason: null,
      changes: [
        { field: "normal_low", op: "modify", from: 35, to: 32, reason: "Echevarne prints 32-48 g/L.", source: "F01-E10" },
        { field: "optimal_high", op: "modify", from: 48, to: null, reason: null, source: null },
        { field: "optimal_low", op: "modify", from: 42, to: 41, reason: "Grade B floor.", source: "F01-E01" },
      ],
    };
    expect(changesFromDiff({ rows: [perField] })!.map((c) => `${c.field}:${c.reason ? "reason" : "none"}:${JSON.stringify(c.values)}`)).toEqual(['normal_low:reason:{"from":35,"to":32}', 'optimal_high:none:{"from":48,"to":null}', 'optimal_low:reason:{"from":42,"to":41}']);
    expect(checkSourceOfTruth(seed, prod, { documented: diffDoc([perField]) }).failures.map((f) => f.detail)).toEqual(["optimal_high seed null vs production 48 (documented in reconciliation/diff.json without a reason)"]);
    const staleValues = { ...perField, unexplained_fields: [], changes: perField.changes.map((c) => ({ ...c, reason: "Stated reason.", source: "F01-E10", ...(c.field === "normal_low" ? { to: 33 } : {}) })) };
    expect(checkSourceOfTruth(seed, prod, { documented: diffDoc([staleValues]) }).failures.map((f) => f.detail)).toEqual(["normal_low seed 32 vs production 35 (documented in reconciliation/diff.json as 35 → 33, not this difference)"]);
    // changes.json: the documented_source an entry carries is its source.
    expect(changesFromCompile({ changes: [change(K, "modify", "normal_low", 35, 32, { evidence_ids: [], reason_source: "row", documented_source: "Echevarne catalogue B0020" })] })![0].source).toBe("Echevarne catalogue B0020");
    expect(changesFromCompile({ changes: [change(K, "modify", "normal_low", 35, 32, { evidence_ids: [], reason_source: "decision", documented_source: null })] })![0].source).toBe("decision");
  });

  it("reads the compile's forward migration: upserts with arrays and quoted text, deletes, and nothing else", () => {
    const x = { ...prodRow("x", "18-59", 0.8, 3.5, 0.8, 2, "ratio"), name_en: "X; it's -- not a comment", explanatory_numbers: [1.5, 2], tested_2x_year: true, critical_high: 1e-7 };
    const y = prodRow("y", "All Adults", 1, 2, null, null);
    const z = prodRow("z", "All Adults", 5, 6, null, null);
    const sql = forwardSql([x], [y], [y]);
    const m = parseForwardMigration(sql, "f.sql");
    expect(m.unreadable).toEqual([]);
    expect(m.ops.map((o) => o.kind)).toEqual(["upsert", "delete"]);
    const up = m.ops[0] as Extract<MigrationOp, { kind: "upsert" }>;
    expect(up.rows).toHaveLength(1);
    expect(up.rows[0]).toMatchObject({ biomarker_key: "x", name_en: "X; it's -- not a comment", explanatory_numbers: [1.5, 2], tested_2x_year: true, normal_low: 0.8, optimal_high: 2, critical_high: 1e-7, unit_en: "ratio" });
    expect(up.update).toEqual(expect.arrayContaining(["normal_low", "normal_high", "optimal_low", "optimal_high", "unit_en"]));
    expect(m.ops[1]).toEqual({ kind: "delete", keys: ["y|both|All Adults"] });
    const after = applyForwardMigration([y, z], m);
    expect([...after.keys()].sort()).toEqual(["x|both|18-59", "z|both|All Adults"]);
    // The critical limits are documented values too: x is written with critical_high 1e-7.
    expect(after.get("x|both|18-59")).toEqual({ ...prodRow("x", "18-59", 0.8, 3.5, 0.8, 2, "ratio"), critical_high: 1e-7 });
    // An upsert that sets only some columns on conflict changes only those columns of an existing row.
    const partial = parseForwardMigration("insert into public.biomarker_references (biomarker_key, sex, age_group_en, unit_en, normal_low, normal_high) values ('z', 'both', 'All Adults', 'g/L', 7, 8) on conflict (biomarker_key, sex, age_group_en) do update set normal_low = excluded.normal_low;", "p.sql");
    expect(applyForwardMigration([z], partial).get("z|both|All Adults")).toEqual({ ...z, normal_low: 7 });
    // Statements D5 does not read are listed, never skipped.
    const unread = [
      "update public.biomarker_references set normal_low = 30 where biomarker_key = 'x';",
      "insert into public.biomarker_references (biomarker_key, sex, age_group_en, normal_low) values ('x', 'both', '18-59', 30);",
      "insert into public.biomarker_references (biomarker_key, sex, age_group_en, normal_low) values ('x', 'both', '18-59', now()) on conflict (biomarker_key, sex, age_group_en) do nothing;",
      "delete from public.biomarker_references r using (values ('x', 'both', '18-59')) as v(biomarker_key, sex, age_group_en) where r.biomarker_key = v.biomarker_key;",
      "alter table public.biomarker_references drop column normal_low;",
      "alter table public.biomarker_references add column if not exists normal_low numeric;",
      // A critical-limit column is added only empty: a default would write a value into every production row.
      "alter table public.biomarker_references add column if not exists critical_low numeric default 20;",
      "alter table public.biomarker_references add column critical_high numeric not null default 100;",
      // Production has no critical-limit column, so a statement cannot write one the file has not added.
      "insert into public.biomarker_references (biomarker_key, sex, age_group_en, critical_low) values ('x', 'both', '18-59', 20) on conflict (biomarker_key, sex, age_group_en) do update set critical_low = excluded.critical_low;",
    ];
    for (const st of unread) expect(parseForwardMigration(st, "u.sql").unreadable).toHaveLength(1);
    expect(parseForwardMigration("alter table public.biomarker_references add column if not exists critical_low numeric, add column if not exists explanatory_numbers numeric[];", "a.sql")).toEqual({ file: "a.sql", ops: [], unreadable: [] });
    // An added column carries nothing after its type: no default, constraint, foreign key, generated expression or collation.
    for (const clause of [
      "add column if not exists marker_class text default 'a'",
      "add column marker_class text not null",
      "add column marker_class text check (marker_class <> '')",
      "add column marker_class text collate \"C\"",
      "add column marker_class text generated always as ('a') stored",
      "add column marker_class integer",
      "add column if not exists signoff_parent uuid references public.biomarker_references (id) on delete cascade",
    ]) expect(parseForwardMigration(`alter table public.biomarker_references ${clause};`, "x.sql").unreadable.length).toBeGreaterThan(0);
    // Added first, written after: readable.
    const addThenWrite = parseForwardMigration(
      "alter table public.biomarker_references add column if not exists critical_low numeric; insert into public.biomarker_references (biomarker_key, sex, age_group_en, critical_low) values ('x', 'both', '18-59', 20) on conflict (biomarker_key, sex, age_group_en) do update set critical_low = excluded.critical_low;",
      "c.sql",
    );
    expect(addThenWrite.unreadable).toEqual([]);
    expect(applyForwardMigration([x], addThenWrite).get("x|both|18-59")!.critical_low).toBe(20);
    expect(sqlLiteral("array[2, 4]::numeric[]")).toEqual([2, 4]);
    expect(sqlLiteral("'a''b'")).toBe("a'b");
    for (const raw of ["'a' || 'b'", "now()", "array[now()]"]) expect(sqlLiteral(raw)).toBeUndefined();
    expect(splitSqlList("1, array[2, 3], 'a,b', (4, 5)")).toEqual(["1", "array[2, 3]", "'a,b'", "(4, 5)"]);
  });

  it("accepts in an ALTER exactly the columns and types the compile adds (compile-rows.js DB_EXT_TYPES)", () => {
    const { DB_EXT_TYPES } = toolRequire("./docs/signoff/tools/lib/compile-rows.js") as { DB_EXT_TYPES: Record<string, string> };
    expect({ ...SIGNOFF_ADD_COLUMNS }).toEqual(DB_EXT_TYPES);
  });

  it("explains nothing from a file whose added column is a cascading foreign key, wherever the cascade points", () => {
    const tmp = prodRow("signoff_tmp", "All Adults", 1, 2, null, null);
    const albumin = { ...prodRow("albumin", "All Adults", 32, 48, 41, null) };
    const egfr = prodRow("egfr_creatinine_based", "40-59", 60, null, 75, 105, "mL/min/1.73m²");
    const fk = "alter table public.biomarker_references add column if not exists signoff_parent uuid references public.biomarker_references (id) on delete cascade;";
    // F1: the row points at a temporary row the file adds and deletes; F2: at a production row the file deletes as documented.
    for (const [deleted, base] of [[[tmp], [tmp]], [[egfr], [egfr]]] as const) {
      const sql = `${fk}\n${forwardSql([albumin, ...(deleted[0] === tmp ? [tmp] : [])], [...deleted], [...base])}`;
      const m = parseForwardMigration(sql, "fk.sql");
      expect(m.unreadable.length).toBeGreaterThan(0);
      expect(m.unreadable[0]).toMatch(/foreign key/);
    }
    // A default on an added column is refused the same way.
    const withDefault = parseForwardMigration(`alter table public.biomarker_references add column if not exists method_note text default 'x';\n${forwardSql([albumin])}`, "d.sql");
    expect(withDefault.unreadable).toHaveLength(1);
  });

  it("reads unquoted names, typed literals and listed SET columns, and lists as unreadable a form it would misread or a place where PostgreSQL may split or undo the file otherwise", () => {
    const z = prodRow("z", "All Adults", 5, 6, null, null);
    const ins = (cols: string, vals: string, tail = "do update set normal_low = excluded.normal_low") => `insert into public.biomarker_references (${cols}) values ${vals} on conflict (biomarker_key, sex, age_group_en) ${tail};`;
    const OK = ins("biomarker_key, sex, age_group_en, unit_en, normal_low", "('z', 'both', 'All Adults', 'g/L', 7)");
    const read = (sql: string) => {
      const m = parseForwardMigration(sql, "r.sql");
      expect(m.unreadable).toEqual([]);
      return applyForwardMigration([z], m).get("z|both|All Adults");
    };
    expect(read(OK)).toEqual({ ...z, normal_low: 7 });
    // PostgreSQL folds an unquoted name to lower case: NORMAL_LOW and EXCLUDED.Normal_Low are normal_low.
    expect(read(ins("BIOMARKER_KEY, Sex, age_group_en, NORMAL_LOW", "('z', 'both', 'All Adults', 7)", "do update set Normal_Low = EXCLUDED.normal_low"))).toEqual({ ...z, normal_low: 7 });
    // Double quotes, dollar signs, comment marks and semicolons inside a quoted text or a -- comment are text.
    expect(read(`-- a "note" with $1 and /* marks */\n${ins("biomarker_key, sex, age_group_en, unit_en, normal_low", "('z', 'both', 'All Adults', 'g/L; \"x\" $2 /* y */ -- z', 7)")}`)).toEqual({ ...z, normal_low: 7 });
    expect(parseForwardMigration(forwardSql([{ ...prodRow("x", "18-59", 1, 2, null, null), name_en: `A "quoted" name; $5 /* not a comment */ -- not a comment` }]), "t.sql").unreadable).toEqual([]);
    const ADD = "alter table public.biomarker_references add column if not exists critical_low numeric, add column if not exists critical_high numeric;\n";
    const cases: [string, string, RegExp][] = [
      // Values that PostgreSQL coerces to the column's type, and values D5 cannot hold.
      ["a quoted bound", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', '7')"), /^statement 1 \(normal_low is a quoted text, not a finite number or null\): /],
      ["a quoted critical limit", ADD + ins("biomarker_key, sex, age_group_en, critical_low", "('z', 'both', 'All Adults', '15')", "do update set critical_low = excluded.critical_low"), /^statement 2 \(critical_low is a quoted text, not a finite number or null\): /],
      ["a boolean bound", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', true)"), /\(normal_low is a boolean, not a finite number or null\)/],
      ["an array critical limit", ADD + ins("biomarker_key, sex, age_group_en, critical_high", "('z', 'both', 'All Adults', array[1])", "do nothing"), /\(critical_high is an array, not a finite number or null\)/],
      ["a bound beyond a double", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', 1e400)"), /\(normal_low is a number beyond the range of a double, not a finite number or null\)/],
      ["a number as the unit", ins("biomarker_key, sex, age_group_en, unit_en", "('z', 'both', 'All Adults', 1.50)", "do update set unit_en = excluded.unit_en"), /\(unit_en is a number, not a quoted text or null\)/],
      ["a number as a key", ins("biomarker_key, sex, age_group_en, normal_low", "(5, 'both', 'All Adults', 7)"), /\(biomarker_key is a number, not a quoted text\)/],
      ["a null key", ins("biomarker_key, sex, age_group_en, normal_low", "('z', null, 'All Adults', 7)"), /\(sex is null, not a quoted text\)/],
      // Column names: PostgreSQL would read a double-quoted or qualified name otherwise than as written here.
      ["a double-quoted column", ins('biomarker_key, sex, age_group_en, "normal_low"', "('z', 'both', 'All Adults', 7)"), /^statement 1 \(the column-list entry "normal_low" is not an unquoted name\): /],
      ["a qualified column", ins("biomarker_key, sex, age_group_en, t.normal_low", "('z', 'both', 'All Adults', 7)"), /\(the column-list entry t\.normal_low is not an unquoted name\)/],
      ["a column named twice", ins("biomarker_key, sex, age_group_en, normal_low, normal_low", "('z', 'both', 'All Adults', 7, 8)"), /\(the column list names a column twice\)/],
      // DO UPDATE SET: a column the list leaves out gets the excluded row's default; a column set twice is an error.
      ["a SET column not in the list", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', 7)", "do update set normal_low = excluded.normal_low, optimal_high = excluded.optimal_high"), /\(DO UPDATE SET names optimal_high, which the column list leaves out: PostgreSQL would write its default\)/],
      ["a SET column named twice", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', 7)", "do update set normal_low = excluded.normal_low, normal_low = excluded.normal_low"), /\(DO UPDATE SET names a column twice\)/],
      ["a key proposed twice under DO UPDATE", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', 7), ('z', 'both', 'All Adults', 8)"), /\(the statement proposes z\|both\|All Adults twice\)/],
      ["a key proposed twice under DO NOTHING", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', 7), ('z', 'both', 'All Adults', 8)", "do nothing"), /\(the statement proposes z\|both\|All Adults twice\)/],
      ["a trailing comma in VALUES", ins("biomarker_key, sex, age_group_en, normal_low", "('z', 'both', 'All Adults', 7),"), /\(not VALUES \(…\), … ON CONFLICT/],
      ["an unqualified table", "insert into biomarker_references (biomarker_key, sex, age_group_en, normal_low) values ('z', 'both', 'All Adults', 7) on conflict (biomarker_key, sex, age_group_en) do update set normal_low = excluded.normal_low;", /\(a statement on biomarker_references that is not one of the three forms D5 reads\)/],
      // PostgreSQL runs no statement inside a block comment or a dollar-quoted text, nor one a double-quoted name or an escape hides.
      ["an INSERT inside a block comment", `/* kept for reference;\n${OK}\n*/`, /^file \(a block comment at line 1\): PostgreSQL or psql may read the file otherwise than D5 does$/],
      ["an INSERT inside a dollar-quoted text", `select $$;\n${OK}\n$$;`, /^file \(a dollar sign \(dollar-quoted text\) at line 1\)/],
      ["an INSERT inside a double-quoted name", `select 1 as "a;\n${OK}\n";`, /^file \(a double-quoted name at line 1\)/],
      ["an INSERT inside an E'' text", `select E'\\';\n${OK}\n--';`, /^file \(a backslash at line 1\)/],
      // Writes that a later statement undoes or holds back.
      ["a trailing ROLLBACK", `${OK}\nrollback;`, /^statement 2 \(leaves the writes before it unapplied\): rollback$/],
      ["an ABORT", `${OK}\nabort;`, /^statement 2 \(leaves the writes before it unapplied\)/],
      ["a PREPARE TRANSACTION", `${OK}\nprepare transaction 'x';`, /^statement 2 \(leaves the writes before it unapplied\)/],
      // DELETE: an alias PostgreSQL rejects, columns that are not distinct unquoted names, an unqualified table.
      ["a DELETE whose VALUES alias is the table's", "delete from public.biomarker_references v using (values ('z', 'both', 'All Adults')) as v(biomarker_key, sex, age_group_en) where v.biomarker_key = v.biomarker_key and v.sex = v.sex and v.age_group_en = v.age_group_en;", /\(the VALUES alias is the table's alias, or its columns are not distinct unquoted names\)/],
      ["a DELETE with a VALUES column named twice", "delete from public.biomarker_references r using (values ('z', 'z', 'both', 'All Adults')) as v(biomarker_key, biomarker_key, sex, age_group_en) where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;", /\(the VALUES alias is the table's alias, or its columns are not distinct unquoted names\)/],
      ["an unqualified DELETE", "delete from biomarker_references r using (values ('z', 'both', 'All Adults')) as v(biomarker_key, sex, age_group_en) where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;", /\(a statement on biomarker_references that is not one of the three forms D5 reads\)/],
    ];
    for (const [label, sql, why] of cases) {
      const m = parseForwardMigration(sql, "u.sql");
      expect(m.unreadable.some((u) => why.test(u)), `${label}: ${JSON.stringify(m.unreadable)}`).toBe(true);
    }
    // Through D5: an unreadable file documents no value, whatever it would write.
    const blockComment = parseForwardMigration(`/* kept for reference;\n${ins("biomarker_key, sex, age_group_en, unit_en, normal_low, normal_high, optimal_low, optimal_high", "('albumin', 'both', 'All Adults', 'g/L', 32, 48, 41, null)", "do update set normal_low = excluded.normal_low, optimal_low = excluded.optimal_low, optimal_high = excluded.optimal_high")}\n*/`, "compiled/migration.sql");
    expect(blockComment.ops).toHaveLength(1);
    expect(checkSourceOfTruth(seed, prod, { documented: documented(allThree, blockComment) }).failures.map((f) => f.key).sort()).toEqual([`${K}|bounds`, "migration|compiled/migration.sql|unreadable"]);
    // The places sqlSplitHazards finds, each kind once at its first line; none inside quoted text or -- comments.
    expect(sqlSplitHazards("select 1; -- a \"quoted\" $note /* here\nselect 'it''s \"x\" $1 /* y */';")).toEqual([]);
    expect(sqlSplitHazards("select 1;\n/* a */ select \"b\", $$c$$;\nselect 'd\\e', $$f$$;")).toEqual(["a block comment at line 2", "a double-quoted name at line 2", "a dollar sign (dollar-quoted text) at line 2", "a backslash at line 3"]);
    // The compile's own forward migrations of the pilot batch stay readable.
    for (const batch of ["B01-r3", "B01-c1"]) {
      const file = path.join(ROOT, "docs/signoff/work/compiled", batch, "migration.sql");
      const m = parseForwardMigration(fs.readFileSync(file, "utf8"), batch);
      expect(m.unreadable).toEqual([]);
      expect(m.ops.map((o) => o.kind)).toEqual(["upsert", "delete"]);
    }
  });

  it("takes values only from a file whose every statement is a form it reads or a bare BEGIN, START TRANSACTION or COMMIT: an upsert in a BEGIN ATOMIC function or procedure body and a DELETE in a rule's action list are unreadable", () => {
    // The fourth review's pack: albumin's three bound changes and critical_low null -> 15 documented; the seed holds
    // albumin as decided with a critical floor of 15 g/L.
    const critSeed = rows([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null, cl: 15 }]);
    const list = [...allThree, critChange15()];
    const run = (sql: string) => checkSourceOfTruth(critSeed, prod, { documented: documented(list, parseForwardMigration(sql, "compiled/migration.sql")) });
    const NONE = "(the forward migration compiled/migration.sql has statements D5 cannot read, so no value is documented)";
    const unexplained = (sql: string) => {
      const r = run(sql);
      expect(r.failures.map((f) => f.key).sort()).toEqual([`${K}|bounds`, "migration|compiled/migration.sql|unreadable"]);
      expect(r.failures.find((f) => f.key === `${K}|bounds`)!.detail).toBe(["normal_low seed 32 vs production 35", "optimal_low seed 41 vs production 42", "optimal_high seed null vs production 48", "critical_low seed 15 vs production null"].map((t) => `${t} ${NONE}`).join("; "));
      expect(r.metrics.explained_by_documented_changes).toBe(0);
      return parseForwardMigration(sql, "compiled/migration.sql");
    };
    // Control: the upsert at the top level is read and explains the four differences, also inside a transaction.
    const top = run(`${CRIT_ALTER}\n${critUpsert("15")}\n`);
    expect(top.failures).toEqual([]);
    expect(top.metrics.explained_by_documented_changes).toBe(4);
    for (const [open, close] of [["begin", "commit"], ["BEGIN WORK", "COMMIT WORK"], ["start transaction", "commit transaction"]]) {
      const r = run(`${open};\n${CRIT_ALTER}\n${critUpsert("15")}\n${close};\n`);
      expect(r.failures, open).toEqual([]);
      expect(r.metrics.explained_by_documented_changes).toBe(4);
    }
    // A LANGUAGE SQL function or procedure body written BEGIN ATOMIC … END is part of the CREATE statement: PostgreSQL
    // defines it when it applies the file and runs it only when the routine is called, so the upsert in it writes
    // nothing to albumin. The splitter still cuts the body at its semicolons and hands the upsert to the reader.
    const body = (head: string, cl = "15") => `${head}\nbegin atomic\n  select 1;\n  ${critUpsert(cl)}\nend;\n`;
    const createWhy = /^statement \d+ \(a CREATE FUNCTION, PROCEDURE or RULE: PostgreSQL runs the statements of its body or action list when the routine is called or the rule's event occurs, not when it applies the file\): /;
    const END = "statement 4 (not one of the three forms D5 reads, nor a bare BEGIN, START TRANSACTION or COMMIT): end";
    for (const head of ["create function public.signoff_albumin_reference() returns void language sql", "create procedure public.signoff_albumin_reference() language sql"]) {
      const m = unexplained(`${CRIT_ALTER}\n${body(head)}`);
      expect(m.ops.map((o) => o.kind)).toEqual(["upsert"]);
      expect(m.unreadable).toEqual(["file (a semicolon between BEGIN ATOMIC and END at line 6): PostgreSQL or psql may read the file otherwise than D5 does", expect.stringMatching(createWhy), END]);
      expect(m.unreadable[1]).toBe(`statement 2 (a CREATE FUNCTION, PROCEDURE or RULE: PostgreSQL runs the statements of its body or action list when the routine is called or the rule's event occurs, not when it applies the file): ${head} begin atomic select 1`);
    }
    // The top-level upsert writes critical_low null, which the seed (15) does not hold; a body writes 15. PostgreSQL
    // writes null, so the body's 15 explains nothing.
    const mixed = unexplained(`${CRIT_ALTER}\n${critUpsert("null")}\n${body("create or replace function public.signoff_albumin_reference() returns void language sql")}`);
    expect(mixed.ops.map((o) => o.kind)).toEqual(["upsert", "upsert"]);
    expect(mixed.unreadable[0]).toBe("file (a semicolon between BEGIN ATOMIC and END at line 16): PostgreSQL or psql may read the file otherwise than D5 does");
    // A rule's action list DO ALSO ( command ; command … ) runs when the rule's event occurs on its table, not when
    // PostgreSQL applies the file: the DELETE in it removes no row. The pack: the seed and the change list remove
    // eGFR's 40-59 row.
    const egfr = (age: string) => prodRow("egfr_creatinine_based", age, 90, null, null, null, "mL/min/1.73m²");
    const egfrProd = [egfr("18-39"), egfr("40-59")];
    const egfrSeed = rows([{ name: "eGFR (Creatinine-based)", unit: "mL/min/1.73m²", age: "18-39", nl: 90, nh: null, ol: null, oh: null }]);
    const removal = [change("egfr_creatinine_based|both|40-59", "remove", "row", "row present", null, { reason: "Merged into the 40-84 row: Echevarne prints one eGFR interval from 40 (catalogue line 212).", evidence_ids: [] })];
    const runEgfr = (sql: string) => checkSourceOfTruth(egfrSeed, egfrProd, { documented: documented(removal, parseForwardMigration(sql, "compiled/migration.sql")) });
    const DEL = "delete from public.biomarker_references r\n using (values ('egfr_creatinine_based', 'both', '40-59')) as v(biomarker_key, sex, age_group_en)\n where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en";
    const delTop = runEgfr(`${DEL};\n`);
    expect(delTop.failures).toEqual([]);
    expect(delTop.metrics.explained_by_documented_changes).toBe(1);
    const ruleFile = `create rule signoff_keep as on insert to public.lab_results do also (\n  select 1;\n  ${DEL};\n  select 2\n);\n`;
    const rule = parseForwardMigration(ruleFile, "compiled/migration.sql");
    expect(rule.ops).toEqual([{ kind: "delete", keys: ["egfr_creatinine_based|both|40-59"] }]);
    expect(rule.unreadable).toEqual([
      "file (a semicolon inside parentheses at line 2): PostgreSQL or psql may read the file otherwise than D5 does",
      expect.stringMatching(/^statement 1 \(a CREATE FUNCTION, PROCEDURE or RULE: .*\): create rule signoff_keep as on insert to public\.lab_results do also \( select 1$/),
      "statement 3 (not one of the three forms D5 reads, nor a bare BEGIN, START TRANSACTION or COMMIT): select 2 )",
    ]);
    const ruleRun = runEgfr(ruleFile);
    expect(ruleRun.failures.map((f) => f.key).sort()).toEqual(["egfr_creatinine_based|both|40-59|row_only_in_production", "migration|compiled/migration.sql|unreadable"]);
    expect(ruleRun.failures[1].detail).toBe(`production row (key, sex, age group) has no seed counterpart; ${NONE.slice(1, -1)}`);
    expect(ruleRun.metrics.explained_by_documented_changes).toBe(0);
    // A transaction the file opens and does not commit: the writes after BEGIN wait for a COMMIT the file does not give.
    expect(unexplained(`begin;\n${CRIT_ALTER}\n${critUpsert("15")}\n`).unreadable).toEqual(["statement 1 (opens a transaction that no later COMMIT of the file closes, so the file does not commit the writes after it): begin"]);
    expect(unexplained(`begin;\n${CRIT_ALTER}\ncommit;\nstart transaction;\n${critUpsert("15")}\n`).unreadable).toEqual([expect.stringMatching(/^statement 4 \(opens a transaction that no later COMMIT of the file closes, .*\): start transaction$/)]);
    // A COMMIT outside a transaction, and a BEGIN inside one, change no write (each gives a warning).
    expect(run(`commit;\nbegin;\nbegin transaction;\n${CRIT_ALTER}\n${critUpsert("15")}\ncommit;\n`).failures).toEqual([]);
    // Every other statement is unreadable, whether or not it names biomarker_references.
    const others: [string, RegExp][] = [
      ["select 1;", /^statement 1 \(not one of the three forms D5 reads, nor a bare BEGIN, START TRANSACTION or COMMIT\): select 1$/],
      ["call public.signoff_reference_rows();", /^statement 1 \(not one of the three forms .*\): call public\.signoff_reference_rows\(\)$/],
      ["do 'begin perform 1; end';", /^statement 1 \(not one of the three forms .*\): do 'begin perform 1; end'$/],
      ["update public.lab_results set reviewed = true;", /^statement 1 \(not one of the three forms .*\): update public\.lab_results/],
      ["set search_path = public;", /^statement 1 \(not one of the three forms .*\): set search_path = public$/],
      ["create trigger signoff_t after insert on public.lab_results for each row execute function public.f();", /^statement 1 \(not one of the three forms .*\): create trigger/],
      ["create or replace function public.f() returns void language sql as 'select 1';", createWhy],
      ["create or replace rule r as on update to public.lab_results do also notify lab_results;", createWhy],
      // END is PostgreSQL's COMMIT, and closes a BEGIN ATOMIC body: not read. Transaction modes and AND CHAIN are not read.
      ["end;", /^statement 1 \(not one of the three forms .*\): end$/],
      ["begin read only;", /^statement 1 \(not one of the three forms .*\): begin read only$/],
      ["commit and chain;", /^statement 1 \(not one of the three forms .*\): commit and chain$/],
      // In psql the lines after COPY … FROM STDIN are its data, not statements.
      ["copy public.lab_results from stdin;", /^statement 1 \(not one of the three forms .*\): copy public\.lab_results from stdin$/],
      ["with x as (select 1) delete from public.biomarker_references;", /^statement 1 \(a statement on biomarker_references that is not one of the three forms D5 reads\)/],
    ];
    for (const [stmt, why] of others) {
      const m = unexplained(`${stmt}\n${CRIT_ALTER}\n${critUpsert("15")}\n`);
      expect(m.unreadable.some((u) => why.test(u)), `${stmt}: ${JSON.stringify(m.unreadable)}`).toBe(true);
    }
    // sqlSplitHazards finds a semicolon inside parentheses and one between BEGIN ATOMIC and its END, counting each CASE's
    // own END; key words are found across white space and -- comments, in any case.
    expect(sqlSplitHazards("create rule r as on insert to t do also (\n  select 1;\n  select 2\n);")).toEqual(["a semicolon inside parentheses at line 2"]);
    expect(sqlSplitHazards("create procedure p() language sql\nbegin atomic\n  select case when true then 1 end;\n  select 2;\nend;")).toEqual(["a semicolon between BEGIN ATOMIC and END at line 3"]);
    expect(sqlSplitHazards("create function f() returns int language sql\nBEGIN -- the body\n  ATOMIC\n  select 1;\nEND;")).toEqual(["a semicolon between BEGIN ATOMIC and END at line 4"]);
    // A no-break space (U+00A0) is kept in the word, so x, the no-break space and end make one word, which does not close
    // the body; the no-break space is also listed as a character beyond ASCII outside quoted texts and comments.
    expect(sqlSplitHazards("create function f() returns int language sql begin atomic select 1 as x\u00a0end; select 2; end;")).toEqual([
      "a character beyond ASCII outside quoted texts and comments at line 1",
      "a semicolon between BEGIN ATOMIC and END at line 1",
    ]);
    // None: balanced parentheses, semicolons and parentheses in quoted text, CASE … END outside a body, a body closed by
    // its END, BEGIN alone, and names that hold the key words.
    expect(sqlSplitHazards("create function f() returns void language sql begin atomic end;\nselect (1); select 'a;(b'; select case when true then 1 end; begin; commit;\nselect begin_atomic, atomic_end from t;")).toEqual([]);
    // Every forward migration the compile wrote stays readable.
    const compiled: string[] = [];
    const walk = (dir: string) => {
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) walk(p);
        else if (e.name === "migration.sql") compiled.push(p);
      }
    };
    walk(path.join(ROOT, "docs/signoff/work/compiled"));
    expect(compiled.length).toBeGreaterThan(0);
    for (const file of compiled) expect(parseForwardMigration(fs.readFileSync(file, "utf8"), file).unreadable, file).toEqual([]);
  });

  it("ends a -- comment at a carriage return as PostgreSQL does, and lists any control character but a line feed or tab, and a character beyond ASCII or a colon outside quoted texts and comments: what a carriage return hides explains nothing", () => {
    // PostgreSQL 16 ends a -- comment at a line feed or a carriage return (scan.l and psqlscan.l: newline [\n\r],
    // comment ("--"{non_newline}*)), and psql hands its lexer each line with any carriage return in it. D5 used to end a
    // comment only at a line feed, so the text after '-- x' and a carriage return was a comment to D5 and SQL to
    // PostgreSQL. The fourth review's pack: albumin's three bound changes and critical_low null -> 15 documented; the
    // seed holds albumin as decided with a critical floor of 15 g/L.
    const critSeed = rows([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null, cl: 15 }]);
    const list = [...allThree, critChange15()];
    const run = (sql: string) => checkSourceOfTruth(critSeed, prod, { documented: documented(list, parseForwardMigration(sql, "compiled/migration.sql")) });
    const NONE = "(the forward migration compiled/migration.sql has statements D5 cannot read, so no value is documented)";
    const unexplained = (sql: string) => {
      const r = run(sql);
      expect(r.failures.map((f) => f.key).sort()).toEqual([`${K}|bounds`, "migration|compiled/migration.sql|unreadable"]);
      expect(r.failures.find((f) => f.key === `${K}|bounds`)!.detail).toBe(["normal_low seed 32 vs production 35", "optimal_low seed 41 vs production 42", "optimal_high seed null vs production 48", "critical_low seed 15 vs production null"].map((t) => `${t} ${NONE}`).join("; "));
      expect(r.metrics.explained_by_documented_changes).toBe(0);
      return parseForwardMigration(sql, "compiled/migration.sql").unreadable;
    };
    const lineOf = (sql: string, text: string) => sql.slice(0, sql.indexOf(text)).split("\n").length;
    const place = (what: string) => `file (${what}): PostgreSQL or psql may read the file otherwise than D5 does`;
    const cr = (sql: string) => place(`a carriage return at line ${lineOf(sql, "\r")}`);
    const DECIDED = `${CRIT_ALTER}\n${critUpsert("15")}\n`;
    // Control: the decided upsert is read and explains the four differences.
    expect(run(DECIDED).failures).toEqual([]);
    expect(run(DECIDED).metrics.explained_by_documented_changes).toBe(4);

    // An UPDATE back to production's values after '-- x' and a carriage return, which PostgreSQL runs after the upsert:
    // D5 now cuts it out as a statement of its own, which it does not read, and lists the carriage return.
    const update = `${DECIDED}-- x\r${UPDATE_BACK}\n`;
    expect(unexplained(update)).toEqual([cr(update), expect.stringMatching(/^statement 3 \(a statement on biomarker_references that is not one of the three forms D5 reads\): update public\.biomarker_references /)]);
    // '-- x', a carriage return and '/*' before the upsert and '-- */' after it: PostgreSQL reads the upsert as a block comment.
    const block = `${CRIT_ALTER}\n-- x\r/*\n${critUpsert("15")}\n-- */\n`;
    expect(unexplained(block)).toEqual([cr(block), place(`a block comment at line ${lineOf(block, "/*")}`), expect.stringMatching(/^statement 2 \(a statement on biomarker_references that is not one of the three forms D5 reads\): \/\* insert into /)]);

    // Round 3's three cases, with the CREATE line and the line that closes the body or the action list each after '-- x'
    // and a carriage return. To PostgreSQL each is round 3's file: the body runs when the routine is called, the action
    // list when the rule's event occurs, neither when the file is applied.
    const createWhy = /^statement 2 \(a CREATE FUNCTION, PROCEDURE or RULE: PostgreSQL runs the statements of its body or action list when the routine is called or the rule's event occurs, not when it applies the file\): /;
    for (const head of ["create function public.signoff_albumin_reference() returns void language sql", "create procedure public.signoff_albumin_reference() language sql"]) {
      const sql = `${CRIT_ALTER}\n-- x\r${head} begin atomic select 1;\n${critUpsert("15")}\n-- x\rend;\n`;
      expect(unexplained(sql)).toEqual([
        cr(sql),
        place(`a semicolon between BEGIN ATOMIC and END at line ${lineOf(sql, "select 1;")}`),
        expect.stringMatching(createWhy),
        "statement 4 (not one of the three forms D5 reads, nor a bare BEGIN, START TRANSACTION or COMMIT): end",
      ]);
    }
    const egfr = (age: string) => prodRow("egfr_creatinine_based", age, 90, null, null, null, "mL/min/1.73m²");
    const egfrSeed = rows([{ name: "eGFR (Creatinine-based)", unit: "mL/min/1.73m²", age: "18-39", nl: 90, nh: null, ol: null, oh: null }]);
    const removal = [change("egfr_creatinine_based|both|40-59", "remove", "row", "row present", null, { reason: "Merged into the 40-84 row: Echevarne prints one eGFR interval from 40 (catalogue line 212).", evidence_ids: [] })];
    const runEgfr = (sql: string) => checkSourceOfTruth(egfrSeed, [egfr("18-39"), egfr("40-59")], { documented: documented(removal, parseForwardMigration(sql, "compiled/migration.sql")) });
    const DEL = "delete from public.biomarker_references r using (values ('egfr_creatinine_based', 'both', '40-59')) as v(biomarker_key, sex, age_group_en) where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;";
    expect(runEgfr(`${DEL}\n`).metrics.explained_by_documented_changes).toBe(1);
    const rule = `-- x\rcreate rule signoff_keep as on insert to public.lab_results do also (select 1;\n${DEL}\n-- x\rselect 2);\n`;
    const ruleRun = runEgfr(rule);
    expect(ruleRun.failures.map((f) => f.key).sort()).toEqual(["egfr_creatinine_based|both|40-59|row_only_in_production", "migration|compiled/migration.sql|unreadable"]);
    expect(ruleRun.metrics.explained_by_documented_changes).toBe(0);
    expect(parseForwardMigration(rule, "compiled/migration.sql").unreadable.slice(0, 2)).toEqual([cr(rule), place("a semicolon inside parentheses at line 1")]);

    // A key literal continued across a comment that ends at a carriage return: 'albumin' -- key CR '_v2', then a line feed
    // before the rest of the row, is the one literal 'albumin_v2' to PostgreSQL (scan.l quotecontinue), so it adds a row
    // and leaves albumin as in production; a reader that ended the comment at the line feed saw only 'albumin'. D5 lists
    // the carriage return and reads no value from two quoted texts; across a line feed it reads none either.
    const continued = (nl: string) => `${CRIT_ALTER}\n${critUpsert("15").replace("('albumin', ", `('albumin' -- key${nl}'_v2'\n    , `)}\n`;
    expect(unexplained(continued("\r"))).toEqual([cr(continued("\r")), expect.stringMatching(/^statement 2 \(a value is not a literal D5 reads\): /)]);
    expect(unexplained(continued("\n"))).toEqual([expect.stringMatching(/^statement 2 \(a value is not a literal D5 reads\): /)]);

    // The splitter and the place finder end a -- comment at a carriage return, and only the place finder lists it.
    expect(splitSqlStatements("-- a\rselect 1; -- b\r\nselect 2").map((s) => s.trim())).toEqual(["select 1", "select 2"]);
    expect(sqlSplitHazards("select 1; -- a\r/* b */ select 2;")).toEqual(["a carriage return at line 1", "a block comment at line 1"]);
    expect(sqlSplitHazards("select 1; -- a /* b */\nselect 2;")).toEqual([]);
    // Every control character other than a line feed or a tab is listed, in quoted texts and comments too: psql reads no
    // more of a line after a NUL (mainloop.c passes strlen(line) to the lexer), and a vertical tab is white space to D5's
    // patterns but not to PostgreSQL (scan.l space [ \t\n\r\f]).
    expect(sqlSplitHazards("select 'a\u0000b';\n-- c\u0000 d\nselect\u000b1;\fselect 2;\u007f")).toEqual(["a control character (U+0000) at line 1", "a control character (U+000B) at line 3", "a control character (U+000C) at line 3", "a control character (U+007F) at line 3"]);
    expect(sqlSplitHazards("select 'a\rb';")).toEqual(["a carriage return at line 1"]);
    expect(sqlSplitHazards("select\t1;\nselect 2;\n")).toEqual([]);
    // A file with CR LF line endings: D5 reads the same statements, and refuses the file for its carriage returns.
    const crlf = fs.readFileSync(path.join(ROOT, "docs/signoff/work/compiled/B01-r3/migration.sql"), "utf8").replace(/\n/g, "\r\n");
    const crlfRead = parseForwardMigration(crlf, "crlf.sql");
    expect(crlfRead.unreadable).toEqual([place("a carriage return at line 1")]);
    expect(crlfRead.ops.map((o) => o.kind)).toEqual(["upsert", "delete"]);

    // A character beyond ASCII outside quoted texts and comments: PostgreSQL reads it as a letter of a name (scan.l
    // ident_cont), while \s in D5's patterns matches a no-break space, so 'commit<U+00A0>work' would be read as COMMIT
    // WORK. Inside quoted texts and comments it is text. The Kelvin sign, which lower-cases to k, is listed too.
    const nbsp = `begin;\n${DECIDED}commit work;\n`;
    expect(unexplained(nbsp)).toEqual([place(`a character beyond ASCII outside quoted texts and comments at line ${lineOf(nbsp, "commit")}`)]);
    expect(sqlSplitHazards("select Key;")).toEqual(["a character beyond ASCII outside quoted texts and comments at line 1"]);
    expect(sqlSplitHazards("select 'Albúmina'; -- Albúmina · nota\n")).toEqual([]);

    // A colon outside quoted texts and comments other than the two of a :: cast: psql puts a variable's value there
    // (psqlscan.l :{variable_char}+, :'…', :"…"), a value that comes from outside the file and may hold statements.
    expect(sqlSplitHazards("select :x, 1:::y;")).toEqual(["a colon outside a :: cast (psql variable) at line 1"]);
    expect(sqlSplitHazards("select array[2, 4]::numeric[], 'a:b'; -- c:d\n")).toEqual([]);
    const alterWith = (clause: string) => `alter table public.biomarker_references add column if not exists critical_low numeric, add column if not exists critical_high numeric, add column if not exists method_note text ${clause};\n${critUpsert("15")}\n`;
    // An added column takes no default (it would write a value into every production row), so the file explains nothing;
    // with a psql variable in the default, the colon is listed as well.
    expect(run(alterWith("default 'none'")).failures.map((f) => f.key)).toContain("migration|compiled/migration.sql|unreadable");
    expect(sqlSplitHazards(alterWith("default :note"))).toEqual(["a colon outside a :: cast (psql variable) at line 1"]);
  });

  it("fails through the check a forward migration whose values sit in a BEGIN ATOMIC body, or that holds a rule", async () => {
    const seedDir = pairSeedDir(albuminPair({ ...ALBUMIN_DECIDED, cl: 15 }));
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: [...allThree, critChange15()], production_only: [] }));
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const albumin = async (sql: string) => {
      fs.writeFileSync(path.join(seedDir, "migration.sql"), sql);
      const r = await d5.run(ctx);
      return r.failures
        .filter((f) => /^albumin\||^migration\|/.test(f.key))
        .map((f) => f.key.replace(/^migration\|.*\|unreadable$/, "migration|unreadable"))
        .sort();
    };
    const body = (head: string) => `${head}\nbegin atomic\n  select 1;\n  ${critUpsert("15")}\nend;\n`;
    // An unreadable file explains no difference and makes no listed change.
    const FAILS = [`${K}|bounds`, `${K}|change_list`, "migration|unreadable"];
    expect(await albumin(`${CRIT_ALTER}\n${critUpsert("15")}\n`)).toEqual([]);
    expect(await albumin(`begin;\n${CRIT_ALTER}\n${critUpsert("15")}\ncommit;\n`)).toEqual([]);
    expect(await albumin(`${CRIT_ALTER}\n${body("create function public.signoff_albumin_reference() returns void language sql")}`)).toEqual(FAILS);
    expect(await albumin(`${CRIT_ALTER}\n${body("create procedure public.signoff_albumin_reference() language sql")}`)).toEqual(FAILS);
    // The decided values at the top level, and a rule whose action list deletes a row production does not have (read as
    // a top-level DELETE it changes nothing): the file is unreadable, so albumin's differences are not explained.
    const ruleDelete = "create rule signoff_keep as on insert to public.lab_results do also (\n  select 1;\n  delete from public.biomarker_references r using (values ('albumin', 'both', '18-39')) as v(biomarker_key, sex, age_group_en) where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;\n  select 2\n);\n";
    expect(await albumin(`${CRIT_ALTER}\n${critUpsert("15")}\n${ruleDelete}`)).toEqual(FAILS);
    expect(await albumin(`begin;\n${CRIT_ALTER}\n${critUpsert("15")}\n`)).toEqual(FAILS);
  });

  it("fails through the check a forward migration that puts a write, or the end of a comment, body or rule, after a carriage return", async () => {
    const seedDir = pairSeedDir(albuminPair({ ...ALBUMIN_DECIDED, cl: 15 }));
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: [...allThree, critChange15()], production_only: [] }));
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const albumin = async (sql: string) => {
      fs.writeFileSync(path.join(seedDir, "migration.sql"), sql);
      const r = await d5.run(ctx);
      return r.failures
        .filter((f) => /^albumin\||^migration\|/.test(f.key))
        .map((f) => f.key.replace(/^migration\|.*\|unreadable$/, "migration|unreadable"))
        .sort();
    };
    const DECIDED = `${CRIT_ALTER}\n${critUpsert("15")}\n`;
    const FAILS = [`${K}|bounds`, `${K}|change_list`, "migration|unreadable"];
    expect(await albumin(DECIDED)).toEqual([]);
    // Each behind '-- x' and a carriage return: an UPDATE back to production's values after the decided upsert; a block
    // comment around the upsert; the upsert in a procedure body whose CREATE line and END line follow a carriage return;
    // and, after the decided upsert, a rule whose action list deletes a row production does not have, its CREATE line and
    // closing line after a carriage return (read as a top-level DELETE it changes nothing).
    expect(await albumin(`${DECIDED}-- x\r${UPDATE_BACK}\n`)).toEqual(FAILS);
    expect(await albumin(`${CRIT_ALTER}\n-- x\r/*\n${critUpsert("15")}\n-- */\n`)).toEqual(FAILS);
    expect(await albumin(`${CRIT_ALTER}\n-- x\rcreate procedure public.signoff_albumin_reference() language sql begin atomic select 1;\n${critUpsert("15")}\n-- x\rend;\n`)).toEqual(FAILS);
    const delete1839 = "delete from public.biomarker_references r using (values ('albumin', 'both', '18-39')) as v(biomarker_key, sex, age_group_en) where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;";
    expect(await albumin(`${DECIDED}-- x\rcreate rule signoff_keep as on insert to public.lab_results do also (select 1;\n${delete1839}\n-- x\rselect 2);\n`)).toEqual(FAILS);
    // The decided file with CR LF line endings is refused too: stricter than PostgreSQL, and the compile writes line feeds only.
    expect(await albumin(DECIDED.replace(/\n/g, "\r\n"))).toEqual(FAILS);
  });

  it("uses the changes.json next to the seed with its migration.sql, else the reconciliation diff with its forward migration, through the check", async () => {
    const seedDir = tmpSeed([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null }]);
    const workDir = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-"));
    const ctx = makeCtx({ root: ROOT, seedDir, workDir, thresholds: {} });
    const relOf = (p: string) => path.relative(ROOT, p).split(path.sep).join("/");
    expect(loadDocumentedChanges(ctx)).toBeNull();
    const albumin = { ...prodRow("albumin", "All Adults", 32, 48, 41, null) };
    fs.mkdirSync(path.join(workDir, "reconciliation"));
    fs.writeFileSync(path.join(workDir, "reconciliation", "diff.json"), JSON.stringify({ rows: [{ key: K, ops: ["modify"], fields: ["normal_low"], reason: "r", unexplained_fields: [], source: "F01-E10" }] }));
    expect(loadDocumentedChanges(ctx)!.migration).toBeNull();
    fs.writeFileSync(path.join(workDir, "reconciliation", "forward.sql"), forwardSql([albumin], [], prod));
    const fromDiff = loadDocumentedChanges(ctx)!;
    expect([fromDiff.kind, fromDiff.migration!.file]).toEqual(["reconciliation diff", relOf(path.join(workDir, "reconciliation", "forward.sql"))]);
    // The production snapshot plus the applied migrations hold albumin 35-48, optimal 42-48 g/L.
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: [...allThree.slice(0, 2), change(K, "modify", "optimal_high", 48, null, { reason: null })], production_only: [] }));
    fs.writeFileSync(path.join(seedDir, "migration.sql"), forwardSql([albumin], [], prod));
    const doc = loadDocumentedChanges(ctx)!;
    expect([doc.kind, doc.file, doc.migration!.file]).toEqual(["changes.json", relOf(path.join(seedDir, "changes.json")), relOf(path.join(seedDir, "migration.sql"))]);
    const r = await dataChecks.find((c) => c.id === "D5")!.run(ctx);
    expect(r.status).toBe("fail");
    expect(r.failures.find((f) => f.key === `${K}|bounds`)!.detail).toMatch(/^optimal_high seed null vs production 48 \(documented in .*changes\.json without a reason\)$/);
    expect(r.metrics!.explained_by_documented_changes).toBe(2);
    expect(r.failures.some((f) => f.key.startsWith("es|"))).toBe(false);
  });

  // ─── Every column and the change list (round 4) ───

  const COLS = [...compileRows.DB_COLS, ...compileRows.DB_EXT_COLS];
  const prodDb = () => productionDatabaseRows([prodAlbumin()], COLS);
  const seedDbOf = (...pairs: { en: RawEn; es: RawEs }[]) => seedDatabaseRows(pairs.map((p) => p.en), pairs.map((p) => p.es), compileRows.dbRowFromPair);
  /** The forward migration compile-sql.js writes for these database rows, against production's albumin row. */
  const migOf = (written: DbRow[], deleted: DbLike[] = [], file = "compiled/migration.sql") => mig(written as DbLike[], deleted, [prodAlbumin() as DbLike], file);
  const shown = (v: unknown) => (v == null ? "null" : typeof v === "string" ? JSON.stringify(v) : String(v));
  // A clinical note, one message, marker_class and unit_es written otherwise than the seed holds them.
  const MIGRATION_EDITS: [string, unknown][] = [
    ["clinical_notes_en", "Low albumin means you have liver disease. Take 40 mg of furosemide daily."],
    ["msg_critical_low_en", "Your albumin is below 30 g/L: this is an emergency, seek immediate care."],
    ["marker_class", "e"],
    ["unit_es", "mg/dL"],
  ];

  it("reads the compile's libraries and applies a forward migration on every column, with the table's defaults for a column an INSERT leaves out", () => {
    const tools = loadCompileTools(ROOT)!;
    expect(tools.columns).toEqual(COLS);
    expect(loadCompileTools(fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-root-")))).toBeNull();
    // A new row takes false for the three boolean columns (full_schema.sql "boolean default false") and null elsewhere.
    const insertNew = parseForwardMigration("insert into public.biomarker_references (biomarker_key, sex, age_group_en, name_en, unit_en) values ('x', 'both', 'All Adults', 'X', 'g/L') on conflict (biomarker_key, sex, age_group_en) do nothing;", "n.sql");
    const added = applyForwardMigrationColumns(new Map(), insertNew, COLS);
    expect(added.rows.get("x|both|All Adults")).toMatchObject({ name_en: "X", tested_2x_year: false, is_base_panel: false, is_genetic: false, msg_optimal_en: null, marker_class: null });
    expect([...added.written.get("x|both|All Adults")!].sort()).toEqual(["age_group_en", "biomarker_key", "name_en", "sex", "unit_en"]);
    // DO NOTHING on an existing row writes nothing; DO UPDATE SET writes its columns only; a DELETE removes the row.
    const nothing = applyForwardMigrationColumns(prodDb(), parseForwardMigration("insert into public.biomarker_references (biomarker_key, sex, age_group_en, normal_low) values ('albumin', 'both', 'All Adults', 30) on conflict (biomarker_key, sex, age_group_en) do nothing;", "n.sql"), COLS);
    expect([nothing.rows.get(K)!.normal_low, nothing.written.has(K)]).toEqual([35, false]);
    const partial = applyForwardMigrationColumns(prodDb(), parseForwardMigration(handMigration(BOUNDS_UNIT, ["'g/L'", "32", "48", "41", "null"], ["normal_low"]), "p.sql"), COLS);
    expect([partial.rows.get(K)!.normal_low, partial.rows.get(K)!.optimal_low, [...partial.written.get(K)!]]).toEqual([32, 42, ["normal_low"]]);
    const removed = applyForwardMigrationColumns(prodDb(), migOf([], [prodAlbumin() as DbLike]), COLS);
    expect([removed.rows.has(K), removed.deleted.has(K)]).toEqual([false, true]);
  });

  it("holds the seed to production plus the forward migration on every other column: a migration's clinical note, message, marker_class or unit_es that differs from the seed fails, and so does a seed message that differs from the migration", () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const row = compileRows.dbRowFromPair(pair);
    const run = (written: DbRow[], s = seedDbOf(pair), m: ForwardMigration | null = migOf(written)) => checkEveryColumn(s, prodDb(), documented(allThree, m), COLS);
    // The compile's own migration writes the seed's database row: nothing differs.
    const own = run([row]);
    expect(own.failures).toEqual([]);
    expect(own.metrics).toMatchObject({ every_column_rows: 1, column_differences: 0 });
    expect(String(own.metrics.every_column_fields).split(",")).toEqual(COLS.filter((c) => !["biomarker_key", "sex", "age_group_en", "normal_low", "normal_high", "optimal_low", "optimal_high", "critical_low", "critical_high"].includes(c)));
    for (const [c, v] of MIGRATION_EDITS) {
      expect(run([{ ...row, [c]: v }]).failures).toEqual([{ key: `${K}|columns`, detail: `${c} seed ${shown(row[c])} vs production plus the forward migration compiled/migration.sql ${shown(v)}` }]);
    }
    // The seed's message edited after the compile (in either file), the migration as the compile wrote it.
    const enEdited = { en: { ...pair.en, Msg_Below_Optimal: "Your albumin is below 38 g/L." }, es: pair.es };
    expect(run([row], seedDbOf(enEdited)).failures).toEqual([{ key: `${K}|columns`, detail: `msg_below_optimal_en seed "Your albumin is below 38 g/L." vs production plus the forward migration compiled/migration.sql ${shown(row.msg_below_optimal_en)}` }]);
    const esEdited = { en: pair.en, es: { ...pair.es, Msg_Debajo_Óptimo: "Tu albúmina está por debajo de 38 g/L." } };
    expect(run([row], seedDbOf(esEdited)).failures.map((f) => f.detail)).toEqual([`msg_below_optimal_es seed "Tu albúmina está por debajo de 38 g/L." vs production plus the forward migration compiled/migration.sql ${shown(row.msg_below_optimal_es)}`]);
    // A column the migration does not write keeps production's value, and the seed must hold it.
    const boundsOnly = parseForwardMigration(handMigration(BOUNDS_UNIT, ["'g/L'", "32", "48", "41", "null"], BOUNDS_UNIT), "compiled/migration.sql");
    expect(run([], seedDbOf(pair), boundsOnly).failures).toEqual([]);
    expect(run([], seedDbOf(enEdited), boundsOnly).failures.map((f) => f.detail)).toEqual([`msg_below_optimal_en seed "Your albumin is below 38 g/L." vs production plus the forward migration compiled/migration.sql ${shown(prodAlbumin().msg_below_optimal_en)}`]);
    // No forward migration D5 can read: the seed is held to production alone.
    expect(run([], seedDbOf(enEdited), null).failures.map((f) => f.detail)).toEqual([`msg_below_optimal_en seed "Your albumin is below 38 g/L." vs production ${shown(prodAlbumin().msg_below_optimal_en)} ${unlisted}`]);
    // The unit as written: the same unit spelled otherwise fails here; another unit is checkSourceOfTruth's (with its reason rule).
    expect(run([{ ...row, unit_en: "G/L" }]).failures.map((f) => f.detail)).toEqual(['unit_en seed "g/L" vs production plus the forward migration compiled/migration.sql "G/L"']);
    expect(run([{ ...row, unit_en: "mg/dL" }]).failures).toEqual([]);
    expect(checkSourceOfTruth(rows([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null }]), prod, { documented: documented(allThree, migOf([{ ...row, unit_en: "mg/dL" }])) }).failures.map((f) => f.key)).toEqual([`${K}|documented_migration`]);
    // The bounds and critical limits are checkSourceOfTruth's: not compared twice.
    expect(run([{ ...row, normal_low: 30 }]).failures).toEqual([]);
  });

  it("fails through the check a migration whose clinical note, message, marker_class or unit_es differs from the seed, and a seed message that differs from the migration", async () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const seedDir = pairSeedDir(pair);
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: allThree, production_only: [] }));
    const row = compileRows.dbRowFromPair(pair);
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const albumin = async (written: DbRow) => {
      fs.writeFileSync(path.join(seedDir, "migration.sql"), forwardSql([written as DbLike], [], prod));
      const r = await d5.run(ctx);
      return r.failures.filter((f) => /^albumin\|/.test(f.key)).map((f) => f.key);
    };
    expect(await albumin(row)).toEqual([]);
    for (const [c, v] of MIGRATION_EDITS) expect(await albumin({ ...row, [c]: v })).toEqual([`${K}|columns`]);
    // The English seed's message edited after the compile; the migration as the compile wrote it. The edit is also a
    // difference from production that the change list does not record (checkDifferencesListed).
    fs.writeFileSync(path.join(seedDir, "biomarker-ranges-en.json"), JSON.stringify({ biomarker_ranges: [{ ...pair.en, Msg_Below_Optimal: "Your albumin is below 38 g/L." }] }));
    expect(await albumin(row)).toEqual([`${K}|columns`, `${K}|not_listed`]);
    const r = await d5.run(ctx);
    expect(r.metrics).toMatchObject({ every_column_rows: 1, column_differences: 1, rows_with_column_differences: 1, listed_changes: 3, listed_changes_not_made: 0, differences_from_production: 1, differences_not_listed: 1 });
    expect(r.summary).toMatch(/, 1 of 1 rows that differ on the other columns, 1 of 1 differences from production on the other columns that the change list does not record, 0 of 3 listed changes the forward migration does not make, 0 seed rows with a bound or critical limit that is not a number, 0 production baseline problems; /);
  });

  it("holds every listed change to what the forward migration does: a listed added row neither file holds fails, and so does a listed field both leave at production's value", () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const row = compileRows.dbRowFromPair(pair);
    const check = (changes: unknown[], m: ForwardMigration | null = migOf([row])) => checkChangeList(documented(changes, m), prodDb(), COLS);
    const head = "compiled/changes.json lists changes the forward migration does not make: ";
    expect(check(allThree).failures).toEqual([]);
    expect(check(allThree).metrics).toEqual({ listed_changes: 3, listed_changes_not_made: 0, rows_with_listed_changes_not_made: 0 });
    // A decided new row listed as added, in neither the seed nor the migration.
    const added = change("egfr_creatinine_based|both|85+", "add", "row", null, "row added");
    expect(check([...allThree, added]).failures).toEqual([{ key: "egfr_creatinine_based|both|85+|change_list", detail: `${head}row added (the forward migration compiled/migration.sql does not add this row)` }]);
    // A decided message listed as changed, left at production's text in both.
    const text = "Your albumin is in the optimal band, from 41 g/L up to the top of the laboratory interval.";
    const msg = change(K, "modify", "msg_optimal_en", prodAlbumin().msg_optimal_en, text);
    expect(check([...allThree, msg]).failures).toEqual([{ key: `${K}|change_list`, detail: `${head}msg_optimal_en to ${JSON.stringify(text)} (the forward migration compiled/migration.sql writes msg_optimal_en ${shown(row.msg_optimal_en)})` }]);
    expect(check([...allThree, msg], migOf([{ ...row, msg_optimal_en: text }])).failures).toEqual([]);
    // A decided bound listed as changed, left at production's value in both.
    expect(check(allThree, migOf([{ ...row, normal_low: 35 }])).failures).toEqual([{ key: `${K}|change_list`, detail: `${head}normal_low to 32 (the forward migration compiled/migration.sql writes normal_low 35)` }]);
    // Bounds and the unit by value (sameValue); every other column exactly.
    expect(check([change(K, "modify", "normal_low", 35, "32")]).failures).toEqual([]);
    expect(check([change(K, "modify", "unit_en", "g/L", "G/L")]).failures).toEqual([]);
    expect(check([change(K, "modify", "unit_es", "g/L", "G/L")]).failures.map((f) => f.detail)).toEqual([`${head}unit_es to "G/L" (the forward migration compiled/migration.sql writes unit_es "g/L")`]);
    // A listed removal the migration does not make, and one it makes.
    const removal = change(K, "remove", "row", "row present", null);
    expect(check([removal]).failures.map((f) => f.detail)).toEqual([`${head}row removed (the forward migration compiled/migration.sql does not delete this row)`]);
    expect(check([removal], migOf([], [prodAlbumin() as DbLike])).failures).toEqual([]);
    // A field the migration does not write keeps production's value, whatever the list says.
    const setOnly = parseForwardMigration(handMigration(BOUNDS_UNIT, ["'g/L'", "32", "48", "41", "null"], BOUNDS_UNIT.filter((c) => c !== "optimal_high")), "compiled/migration.sql");
    expect(check(allThree, setOnly).failures.map((f) => f.detail)).toEqual([`${head}optimal_high to null (the forward migration compiled/migration.sql does not write optimal_high, which stays 48)`]);
    // An op the rule does not know, and a field that is no column.
    expect(check([change(K, "update", "normal_low", 35, 32)]).failures.map((f) => f.detail)).toEqual([`${head}normal_low to 32 (op "update" of field normal_low is not modify)`]);
    expect(check([change(K, "modify", "normal_lo", 35, 32)]).failures.map((f) => f.detail)).toEqual([`${head}normal_lo to 32 (normal_lo is not a column of public.biomarker_references or a sign-off column)`]);
    // No forward migration, or one D5 cannot read: no listed change is shown to be made.
    expect(check(allThree, null).failures).toEqual([{ key: `${K}|change_list`, detail: `${head}${["normal_low to 32", "optimal_low to 41", "optimal_high to null"].map((t) => `${t} ${unlisted}`).join("; ")}` }]);
    // No change list: nothing to hold to the migration.
    expect(checkChangeList(null, prodDb(), COLS)).toEqual({ failures: [], metrics: { listed_changes: 0, listed_changes_not_made: 0, rows_with_listed_changes_not_made: 0 } });
  });

  it("fails through the check a listed added row missing from both the seed and the migration, and a listed field both leave at production's value", async () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const seedDir = pairSeedDir(pair);
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    fs.writeFileSync(path.join(seedDir, "migration.sql"), forwardSql([compileRows.dbRowFromPair(pair) as DbLike], [], prod));
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const run = async (changes: unknown[]) => {
      fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes, production_only: [] }));
      const r = await d5.run(ctx);
      // Albumin's failures and every change-list failure (the seed holds albumin only, so production's other markers fail as only in production).
      return { keys: r.failures.filter((f) => f.key.startsWith("albumin|") || f.key.endsWith("|change_list")).map((f) => f.key), metrics: r.metrics! };
    };
    expect((await run(allThree)).keys).toEqual([]);
    // The decided eGFR row for ages 85 and over, listed as added; neither file holds it.
    const added = await run([...allThree, change("egfr_creatinine_based|both|85+", "add", "row", null, "row added")]);
    expect(added.keys).toEqual(["egfr_creatinine_based|both|85+|change_list"]);
    expect(added.metrics).toMatchObject({ listed_changes: 4, listed_changes_not_made: 1 });
    // A decided message listed as changed; the seed and the migration both keep production's text.
    const msg = change(K, "modify", "msg_optimal_en", prodAlbumin().msg_optimal_en, "Your albumin is in the optimal band, from 41 g/L.");
    expect((await run([...allThree, msg])).keys).toEqual([`${K}|change_list`]);
  });

  it("holds the reconciliation diff's listed rows to the forward migration: each row written or deleted as its op says", () => {
    const row = compileRows.dbRowFromPair(albuminPair(ALBUMIN_DECIDED));
    const nlr = prodRow("nlr", "60+", 0.8, 3.9, null, null, "ratio");
    const diffDoc = (rowsList: unknown[], m: ForwardMigration | null): DocumentedChanges => ({ file: "reconciliation/diff.json", kind: "reconciliation diff", changes: changesFromDiff({ rows: rowsList })!, migration: m });
    const forward = (written: DbRow[], deleted: DbLike[] = []) => migOf(written, deleted, "reconciliation/forward.sql");
    const check = (rowsList: unknown[], m: ForwardMigration | null) => checkChangeList(diffDoc(rowsList, m), prodDb(), COLS).failures.map((f) => `${f.key} :: ${f.detail}`).sort();
    const head = "reconciliation/diff.json lists changes the forward migration does not make: ";
    const modified = { key: K, ops: ["modify"], fields: ["normal_low", "optimal_low", "optimal_high", "msg_optimal_en"], reason: "r", unexplained_fields: [], source: "s" };
    expect(check([modified], forward([row]))).toEqual([]);
    // The listed row not written: each listed field stays production's.
    expect(check([modified], forward([]))).toEqual([`${K}|change_list :: ${head}${["normal_low", "optimal_low", "optimal_high", "msg_optimal_en"].map((f) => `${f} (the forward migration reconciliation/forward.sql does not write ${f}, which stays ${shown(prodAlbumin()[f])})`).join("; ")}`]);
    // A listed added row and a listed removed row, made and not made.
    const add = { key: "nlr|both|60+", ops: ["add"], fields: ["row"], reason: "r", source: "s" };
    const remove = { key: K, ops: ["remove"], fields: ["row"], reason: "r", source: "s" };
    expect(check([add, remove], forward([nlr], [prodAlbumin() as DbLike]))).toEqual([]);
    expect(check([add, remove], forward([]))).toEqual([
      `${K}|change_list :: ${head}row removed (the forward migration reconciliation/forward.sql does not delete this row)`,
      `nlr|both|60+|change_list :: ${head}row added (the forward migration reconciliation/forward.sql does not add this row)`,
    ]);
  });

  // ─── Every difference from production against the change list (round 4 repair) ───

  const HARM_NOTE = "Low albumin means you have liver disease. Take 40 mg of furosemide daily.";
  const UNLISTED = "differences from production that the change list does not record: ";
  /** A listed change of the kind compile.js writes for a column that is not a bound or the unit: no reason, no evidence. */
  const bare = (field: string, from: unknown, to: unknown, extra: Record<string, unknown> = {}) => change(K, "modify", field, from, to, { reason: null, evidence_ids: [], reason_source: null, ...extra });
  const withEn = (pair: { en: RawEn; es: RawEs }, en: RawEn) => ({ en: { ...pair.en, ...en }, es: pair.es });

  it("holds every difference from production on the other columns to the change list: a note or tested_2x_year changed in both the seed and the migration with no listed change fails, and so does a listed message change removed from the list", () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const p = prodAlbumin();
    // The migration as the compile writes it for the seed being checked: the seed and the migration hold the same change.
    const check = (seedPair: { en: RawEn; es: RawEs }, changes: unknown[]) => checkDifferencesListed(seedDbOf(seedPair), prodDb(), documented(changes, migOf([compileRows.dbRowFromPair(seedPair)])), COLS);
    const details = (seedPair: { en: RawEn; es: RawEs }, changes: unknown[]) => check(seedPair, changes).failures.map((f) => f.detail);
    // albuminPair holds production's row on every column but the bounds, which are checkSourceOfTruth's: nothing to record.
    expect(check(pair, allThree)).toEqual({ failures: [], metrics: { listed_difference_rows: 1, differences_from_production: 0, differences_not_listed: 0, rows_with_differences_not_listed: 0 } });
    // (1) The review's note in the English seed and in the migration, and no listed change: it fails, named with both values.
    const note = withEn(pair, { Clinical_Notes: HARM_NOTE });
    expect(check(note, allThree)).toEqual({
      failures: [{ key: `${K}|not_listed`, detail: `${UNLISTED}clinical_notes_en seed ${JSON.stringify(HARM_NOTE)} vs production ${shown(p.clinical_notes_en)} (not listed in compiled/changes.json)` }],
      metrics: { listed_difference_rows: 1, differences_from_production: 1, differences_not_listed: 1, rows_with_differences_not_listed: 1 },
    });
    // Listed as compile.js lists it, from production's text to the seed's, with no reason: recorded.
    expect(details(note, [...allThree, bare("clinical_notes_en", p.clinical_notes_en, HARM_NOTE)])).toEqual([]);
    // The Spanish note the same.
    const nota = "Una albúmina baja significa que tienes una enfermedad hepática. Toma 40 mg de furosemida al día.";
    const noteEs = { en: pair.en, es: { ...pair.es, Notas_Clínicas: nota } };
    expect(details(noteEs, allThree)).toEqual([`${UNLISTED}clinical_notes_es seed ${JSON.stringify(nota)} vs production ${shown(p.clinical_notes_es)} (not listed in compiled/changes.json)`]);
    expect(details(noteEs, [...allThree, bare("clinical_notes_es", p.clinical_notes_es, nota)])).toEqual([]);
    // (2) tested_2x_year: production tests albumin twice a year; the seed and the migration say no.
    expect(p.tested_2x_year).toBe(true);
    const tested = withEn(pair, { Tested_2x_Year: "No" });
    expect(details(tested, allThree)).toEqual([`${UNLISTED}tested_2x_year seed false vs production true (not listed in compiled/changes.json)`]);
    expect(details(tested, [...allThree, bare("tested_2x_year", true, false)])).toEqual([]);
    // (3) A decided message change removed from the list while the seed and the migration keep it.
    const text = "Your albumin is in the optimal band, from 41 g/L up to the top of the laboratory interval.";
    const msg = withEn(pair, { Msg_Optimal: text });
    const msgChange = bare("msg_optimal_en", p.msg_optimal_en, text);
    expect(details(msg, [...allThree, msgChange])).toEqual([]);
    const msgOff = (why: string) => [`${UNLISTED}msg_optimal_en seed ${JSON.stringify(text)} vs production ${shown(p.msg_optimal_en)} (${why})`];
    expect(details(msg, allThree)).toEqual(msgOff("not listed in compiled/changes.json"));
    // A listed change records the difference only as op modify, "to" the seed's value and "from" production's, each exactly.
    expect(details(msg, [...allThree, { ...msgChange, to: `${text} ` }])).toEqual(msgOff(`listed in compiled/changes.json as ${shown(p.msg_optimal_en)} → ${JSON.stringify(`${text} `)}, not this difference`));
    expect(details(msg, [...allThree, { ...msgChange, from: "Albumin is fine." }])).toEqual(msgOff(`listed in compiled/changes.json as "Albumin is fine." → ${JSON.stringify(text)}, not this difference`));
    expect(details(msg, [...allThree, { ...msgChange, op: "add" }])).toEqual(msgOff('listed in compiled/changes.json with op "add", not modify'));
    // Another row's change or another field's does not record it.
    expect(details(msg, [...allThree, { ...msgChange, row_key: "albumin|both|18-39" }, { ...msgChange, field: "msg_optimal_es" }])).toEqual(msgOff("not listed in compiled/changes.json"));
    // Several differences of one row fail once, each named.
    const both = withEn(pair, { Clinical_Notes: HARM_NOTE, Tested_2x_Year: "No" });
    expect(check(both, allThree).failures.map((f) => f.key)).toEqual([`${K}|not_listed`]);
    expect(check(both, allThree).metrics).toMatchObject({ differences_from_production: 2, differences_not_listed: 2 });
    // A list in order: explanatory numbers listed as [41, 48] do not record a seed's [48, 41].
    const numbers = withEn(pair, { Explanatory_Numbers: [48, 41] });
    expect(details(numbers, [...allThree, bare("explanatory_numbers", null, [41, 48])])).toEqual([`${UNLISTED}explanatory_numbers seed [48,41] vs production null (listed in compiled/changes.json as null → [41,48], not this difference)`]);
    expect(details(numbers, [...allThree, bare("explanatory_numbers", null, [48, 41])])).toEqual([]);
    // Without a documented change list no difference is recorded.
    expect(checkDifferencesListed(seedDbOf(note), prodDb(), null, COLS).failures.map((f) => f.detail)).toEqual([`${UNLISTED}clinical_notes_en seed ${JSON.stringify(HARM_NOTE)} vs production ${shown(p.clinical_notes_en)} (no documented change list (changes.json next to the seed, or the reconciliation diff))`]);
    // The four bounds and the two critical limits are checkSourceOfTruth's, which also asks a stated reason and source.
    expect(details(albuminPair({ ...ALBUMIN_DECIDED, nl: 30, cl: 15 }), [])).toEqual([]);
    // The unit: spelled otherwise it is judged here, as written; another unit is checkSourceOfTruth's.
    const spelled = withEn(pair, { Unit: "G/L" });
    expect(details(spelled, allThree)).toEqual([`${UNLISTED}unit_en seed "G/L" vs production "g/L" (not listed in compiled/changes.json)`]);
    expect(details(spelled, [...allThree, bare("unit_en", "g/L", "G/L")])).toEqual([]);
    expect(details(spelled, [...allThree, bare("unit_en", "g/L", "g/l")])).toEqual([`${UNLISTED}unit_en seed "G/L" vs production "g/L" (listed in compiled/changes.json as "g/L" → "g/l", not this difference)`]);
    expect(details(withEn(pair, { Unit: "mg/dL" }), allThree)).toEqual([]);
    // The last of duplicate keys is the one compared, as the seeder keeps it; a row production does not have is checkSourceOfTruth's.
    const lastOf = (...pairs: { en: RawEn; es: RawEs }[]) => checkDifferencesListed(seedDbOf(...pairs), prodDb(), documented(allThree, migOf([compileRows.dbRowFromPair(pairs[pairs.length - 1])])), COLS).failures.map((f) => f.key);
    expect(lastOf(note, pair)).toEqual([]);
    expect(lastOf(pair, note)).toEqual([`${K}|not_listed`]);
    expect(check(withEn(pair, { Biomarker: "Albumin Index", Clinical_Notes: HARM_NOTE }), allThree)).toEqual({ failures: [], metrics: { listed_difference_rows: 0, differences_from_production: 0, differences_not_listed: 0, rows_with_differences_not_listed: 0 } });
  });

  it("holds a difference from production to the reconciliation diff: the field listed for the row, and the values of a row that lists changes[]", () => {
    const note = withEn(albuminPair(ALBUMIN_DECIDED), { Clinical_Notes: HARM_NOTE });
    const p = prodAlbumin();
    const diffDoc = (rowsList: unknown[]): DocumentedChanges => ({ file: "reconciliation/diff.json", kind: "reconciliation diff", changes: changesFromDiff({ rows: rowsList })!, migration: migOf([compileRows.dbRowFromPair(note)], [], "reconciliation/forward.sql") });
    const check = (rowsList: unknown[]) => checkDifferencesListed(seedDbOf(note), prodDb(), diffDoc(rowsList), COLS).failures.map((f) => f.detail);
    const bounds = ["normal_low", "optimal_low", "optimal_high"];
    const off = (why: string) => [`${UNLISTED}clinical_notes_en seed ${JSON.stringify(HARM_NOTE)} vs production ${shown(p.clinical_notes_en)} (${why})`];
    // A row that lists its fields without values: the field listed for the row records the difference.
    expect(check([{ key: K, ops: ["modify"], fields: [...bounds, "clinical_notes_en"], reason: "r", unexplained_fields: [], source: "s" }])).toEqual([]);
    expect(check([{ key: K, ops: ["modify"], fields: bounds, reason: "r", unexplained_fields: [], source: "s" }])).toEqual(off("not listed in reconciliation/diff.json"));
    expect(check([])).toEqual(off("not listed in reconciliation/diff.json"));
    // A row that lists changes[], as compile.js writes the diff, is held to their values.
    const entry = (to: unknown) => ({ key: K, ops: ["modify"], fields: [...bounds, "clinical_notes_en"], reason: "r", unexplained_fields: [], source: "s", changes: [{ field: "clinical_notes_en", op: "modify", from: p.clinical_notes_en, to, reason: null, source: null }] });
    expect(check([entry(HARM_NOTE)])).toEqual([]);
    expect(check([entry("Another note.")])).toEqual(off(`listed in reconciliation/diff.json as ${shown(p.clinical_notes_en)} → "Another note.", not this difference`));
  });

  it("fails through the check a clinical note or tested_2x_year changed in both the seed and the migration with no listed change, and a listed message change removed from changes.json while the seed and the migration keep it", async () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const seedDir = pairSeedDir(pair);
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    const d5 = dataChecks.find((c) => c.id === "D5")!;
    const p = prodAlbumin();
    const run = async (seedPair: { en: RawEn; es: RawEs }, changes: unknown[]) => {
      fs.writeFileSync(path.join(seedDir, "biomarker-ranges-en.json"), JSON.stringify({ biomarker_ranges: [seedPair.en] }));
      fs.writeFileSync(path.join(seedDir, "rangos-biomarcadores-es.json"), JSON.stringify({ rangos_biomarcadores: [seedPair.es] }));
      // The compile's migration for this seed (compile-sql.js, the seed's database row on every column): both files hold the change.
      fs.writeFileSync(path.join(seedDir, "migration.sql"), forwardSql([compileRows.dbRowFromPair(seedPair) as DbLike], [], prod));
      fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes, production_only: [] }));
      const r = await d5.run(ctx);
      return { keys: r.failures.filter((f) => f.key.startsWith("albumin|")).map((f) => f.key), metrics: r.metrics!, detail: r.failures.find((f) => f.key === `${K}|not_listed`)?.detail };
    };
    expect((await run(pair, allThree)).keys).toEqual([]);
    // (1) The review's both-notes copy.
    const note = withEn(pair, { Clinical_Notes: HARM_NOTE });
    const notes = await run(note, allThree);
    expect(notes.keys).toEqual([`${K}|not_listed`]);
    expect(notes.detail).toBe(`${UNLISTED}clinical_notes_en seed ${JSON.stringify(HARM_NOTE)} vs production ${shown(p.clinical_notes_en)} (not listed in ${path.relative(ROOT, path.join(seedDir, "changes.json")).split(path.sep).join("/")})`);
    expect(notes.metrics).toMatchObject({ differences_from_production: 1, differences_not_listed: 1, rows_with_differences_not_listed: 1, column_differences: 0, listed_changes_not_made: 0 });
    expect((await run(note, [...allThree, bare("clinical_notes_en", p.clinical_notes_en, HARM_NOTE)])).keys).toEqual([]);
    // (2) The review's both-tested copy.
    const tested = withEn(pair, { Tested_2x_Year: "No" });
    expect((await run(tested, allThree)).keys).toEqual([`${K}|not_listed`]);
    expect((await run(tested, [...allThree, bare("tested_2x_year", true, false)])).keys).toEqual([]);
    // (3) The review's drop-listed-msg copy: the decided message in the seed and the migration, its listed change removed.
    const text = "Your albumin is in the optimal band, from 41 g/L up to the top of the laboratory interval.";
    const msg = withEn(pair, { Msg_Optimal: text });
    expect((await run(msg, [...allThree, bare("msg_optimal_en", p.msg_optimal_en, text)])).keys).toEqual([]);
    expect((await run(msg, allThree)).keys).toEqual([`${K}|not_listed`]);
  });

  it("fails a bound or critical limit of the English seed that is not a number or null: the checks read it as no value, the seeder and dbRowFromPair as the number", async () => {
    const pair = albuminPair(ALBUMIN_DECIDED);
    const check = (en: RawEn) => checkSeedNumbers([en], buildRows([en], [pair.es]));
    expect(check(pair.en)).toEqual([]);
    expect(check({ ...pair.en, Critical_Low: undefined, Normal_Low: -0.5 })).toEqual([]);
    // The decided ceiling is none (production 48, listed 48 -> null); the text "48" reads as no value to the checks and as 48 to the database.
    const text = { ...pair.en, Optimal_High: "48" };
    expect(buildRows([text], [pair.es])[0].optimal_high).toBeNull();
    expect(compileRows.dbRowFromPair({ en: text, es: pair.es }).optimal_high).toBe(48);
    expect(check(text)).toEqual([{ key: `${K}|not_a_number`, detail: 'bound or critical limit in the English seed that is not a number or null: Optimal_High "48" (file index 0). The checks read it as no value (scripts/signoff/lib/seed.ts); the seeder passes it to the database as written (src/lib/biomarkers/seed-references.ts)' }]);
    // Any other value that is not a finite number, each named; one failure per row.
    expect(check({ ...pair.en, Normal_Low: true, Normal_High: "", Critical_High: [48] }).map((f) => f.detail)).toEqual([
      'bound or critical limit in the English seed that is not a number or null: Normal_Low true (file index 0); Normal_High "" (file index 0); Critical_High [48] (file index 0). The checks read it as no value (scripts/signoff/lib/seed.ts); the seeder passes it to the database as written (src/lib/biomarkers/seed-references.ts)',
    ]);
    // Through the check: with the decided list and migration, the text "48" fails D5 and nothing else of albumin does.
    const seedDir = pairSeedDir({ en: text, es: pair.es });
    fs.writeFileSync(path.join(seedDir, "changes.json"), JSON.stringify({ changes: allThree, production_only: [] }));
    fs.writeFileSync(path.join(seedDir, "migration.sql"), forwardSql([compileRows.dbRowFromPair(pair) as DbLike], [], prod));
    const ctx = makeCtx({ root: ROOT, seedDir, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    const r = await dataChecks.find((c) => c.id === "D5")!.run(ctx);
    expect(r.failures.filter((f) => f.key.startsWith("albumin|")).map((f) => f.key)).toEqual([`${K}|not_a_number`]);
    expect(r.metrics).toMatchObject({ rows_with_bounds_not_numbers: 1, explained_by_documented_changes: 3 });
  });

  it("records every difference from production and finds no column difference or listed change the migration does not make in the compile's own output (compiled/B01-r3 and B01-r4), whose two eGFR removals carry the compile's former stock sentence and fail (decision CEO-11): 21 D5 failures, 31 and 33 explained differences", async () => {
    // An empty work directory: no decisions file retires a production-only marker, as for the 18 such markers today.
    const expected: [string, number, number, number][] = [
      ["B01-r3", 31, 240, 205],
      ["B01-r4", 33, 272, 235],
    ];
    for (const [compile, explained, listedChanges, differences] of expected) {
      const ctx = makeCtx({ root: ROOT, seedDir: path.join(ROOT, "docs/signoff/work/compiled", compile), workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
      const r = await dataChecks.find((c) => c.id === "D5")!.run(ctx);
      expect(r.metrics).toMatchObject({ explained_by_documented_changes: explained, every_column_rows: 171, column_differences: 0, listed_changes: listedChanges, listed_changes_not_made: 0, listed_difference_rows: 169, differences_from_production: differences, differences_not_listed: 0, rows_with_bounds_not_numbers: 0, production_baseline_rows: 203, production_baseline_problems: 0 });
      expect(r.failures).toHaveLength(21);
      expect(r.failures.filter((f) => !f.key.endsWith("|only_in_production")).map((f) => f.key)).toEqual(["bun_creatinine_ratio|both|All Adults|bounds", "egfr_creatinine_based|both|40-59|row_only_in_production", "egfr_creatinine_based|both|60+|row_only_in_production"]);
    }
  });

  it("fails where the production it replays from the applied migration files and compile-baseline.js buildBaseline differ", () => {
    const base = productionDatabaseRows([prodAlbumin()], COLS);
    expect(productionDisagreements([prodRow("albumin", "All Adults", 35, 48, 42, 48)], base)).toEqual([]);
    expect(productionDisagreements([prodRow("albumin", "All Adults", 34, 48, 42, 48)], base)).toEqual([{ key: `production|${K}|baseline`, detail: "normal_low 34 in the replayed migration files vs 35 in compile-baseline.js buildBaseline" }]);
    expect(productionDisagreements([prodRow("albumin", "All Adults", 35, 48, 42, 48), prodRow("nlr", "60+", 0.8, 3.9, null, null, "ratio")], base).map((f) => f.key)).toEqual(["production|nlr|both|60+|baseline"]);
    expect(productionDisagreements([], base).map((f) => f.key)).toEqual([`production|${K}|baseline`]);
  });

  it("splits SQL on semicolons outside quoted text, so the NLR insert is replayed", () => {
    const sql = "-- header; a comment\ninsert into public.biomarker_references (biomarker_key, sex, age_group_en, unit_en, normal_low, normal_high, optimal_low, optimal_high, clinical_notes_en) values ('x', 'both', '18-59', 'ratio', 0.8, 3.5, 0.8, 2, 'One; it''s -- not a comment') on conflict (biomarker_key, sex, age_group_en) do nothing;\n-- trailer";
    expect(splitSqlStatements(sql)).toHaveLength(1);
    expect(applyMigrationBounds([], sql).rows).toEqual([{ biomarker_key: "x", sex: "both", age_group_en: "18-59", unit_en: "ratio", normal_low: 0.8, normal_high: 3.5, optimal_low: 0.8, optimal_high: 2, critical_low: null, critical_high: null }]);
    const nlr = fs.readFileSync(path.join(ROOT, "supabase/migrations/20260925012000_nlr_row.sql"), "utf8");
    const out = applyMigrationBounds([], nlr);
    expect(out.applied).toBe(2);
    expect(out.rows.map((r) => `${r.biomarker_key}|${r.sex}|${r.age_group_en}|${r.normal_low}-${r.normal_high}|${r.optimal_low}-${r.optimal_high}`)).toEqual(["nlr|both|18-59|0.8-3.5|0.8-2", "nlr|both|60+|0.8-3.9|0.8-2"]);
  });
});

describe("coverage (C1)", () => {
  it("fails a gap in the age grid", () => {
    const rs = rows([
      { name: "NLR", age: "18-39", nl: 0.8, nh: 3.5, ol: 1, oh: 2 },
      { name: "NLR", age: "60+", nl: 0.8, nh: 3.5, ol: 1, oh: 2.5 },
    ]);
    const { failures, metrics } = checkCoverage(rs, 18, 120);
    expect(failures.map((f) => f.key)).toEqual(expect.arrayContaining(["nlr|female|gap", "nlr|male|gap"]));
    expect(failures.find((f) => f.key === "nlr|male|gap")!.detail).toMatch(/40 to 59/);
    expect(metrics.gap_markers).toBe(1);
  });

  it("passes full coverage and flags a both row that overlaps a sex row", () => {
    expect(checkCoverage(rows([{ name: "Albumin", nl: 35, nh: 50 }]), 18, 120).failures).toEqual([]);
    const overlap = checkCoverage(rows([{ name: "Ferritin", nl: 30, nh: 300 }, { name: "Ferritin", sex: "Female", nl: 15, nh: 150 }]), 18, 120);
    expect(overlap.failures.some((f) => f.key.endsWith("both_overlaps_sex"))).toBe(true);
  });
});

describe("messages (M1, M3, M4)", () => {
  it("lists a message on an unreachable zone for deletion without failing", () => {
    // No lower limits: critical_low and below_optimal cannot be returned by the classifier.
    const rs = rows([{ name: "hs-CRP", nl: null, nh: 3, ol: null, oh: 1 }]);
    const rep = checkReachability(rs);
    expect(rep.failures).toEqual([]);
    expect(rep.deletions).toEqual(["hs_crp|both|All Adults|below_optimal", "hs_crp|both|All Adults|critical_low"]);
  });

  it("fails a reachable zone without a message", () => {
    const rs = rows([{ name: "Sodium", nl: 135, nh: 145, ol: 138, oh: 142, msgs: { cl: "Low.", bo: "Lowish.", o: "Fine.", ao: "Highish." } }]);
    expect(checkReachability(rs).failures.map((f) => f.key)).toEqual(["sodium|both|All Adults|critical_high"]);
  });

  it("parses a labelled lexicon fence and honours the allow list", () => {
    const md = 'Text\n\n```json banned_terms\n{"flags":"i","en":{"any":{"terms":["mortality"],"regex":["\\\\bdiagnos\\\\w*"],"allow":["is not a diagnosis"]},"non_critical":{"terms":["urgent"],"regex":[],"allow":[]},"required":{"x":"y"}}}\n```\n';
    const lex = parseLexicon(md)!;
    expect(Object.keys(lex.langs.en).sort()).toEqual(["any", "non_critical"]);
    const tiers = [lex.langs.en.any, lex.langs.en.non_critical];
    expect(lexiconHits("This result is not a diagnosis.", tiers, lex.flags)).toEqual([]);
    expect(lexiconHits("Mortality is urgent; we diagnose it.", tiers, lex.flags)).toEqual(["diagnose", "mortality", "urgent"]);
  });

  it("reads numbers in each language's decimal format", () => {
    expect(extractNumbers("between 4.5 and 1,200 mg/dL, vitamin B12", "en")).toEqual([4.5, 1200]);
    expect(extractNumbers("entre 4,5 y 1.200 mg/dL", "es")).toEqual([4.5, 1200]);
    const rs = rows([{ name: "Potassium", nl: 3.5, nh: 5.1, ol: 4, oh: 4.5, msgs: { ao: "Above 4.5 but below 5.1.", ch: "Above 5.2." } }]);
    rs[0].msg.above_optimal.es = "Por encima de 4,5.";
    const keys = checkMessageNumbers(rs).map((f) => f.key);
    expect(keys).toEqual(["potassium|both|All Adults|critical_high|en", "potassium|both|All Adults|critical_high|es"]);
  });

  it("M4 holds the numbers of a clinical note to the row's bounds and its explanatory numbers, in each language's format", () => {
    const rs = rows([{ name: "BUN", nl: 6, nh: 24, ol: 10, oh: 20 }]);
    rs[0].clinical_notes_en = "Keep it between 10 and 20; urea is BUN x 2.14.";
    rs[0].clinical_notes_es = "Mantenlo entre 10 y 20; la urea es el BUN x 2,14.";
    expect(checkMessageNumbers(rs).map((f) => [f.key, f.detail])).toEqual([
      ["bun|both|All Adults|clinical_notes|en", "numbers 2.14 are neither a bound (6, 10, 20, 24) nor in the explanatory-numbers list"],
      ["bun|both|All Adults|clinical_notes|es", "numbers 2.14 are neither a bound (6, 10, 20, 24) nor in the explanatory-numbers list"],
    ]);
    rs[0].explanatory_numbers = [2.14];
    expect(checkMessageNumbers(rs)).toEqual([]);
    rs[0].clinical_notes_es = "Mantenlo entre 10 y 21.";
    expect(checkMessageNumbers(rs).map((f) => f.key)).toEqual(["bun|both|All Adults|clinical_notes|es"]);
  });

  it("M3 applies the wording rules to the clinical notes the app shows, in both languages", async () => {
    const seedDir = tmpSeed([{ name: "Urea", nl: 10, nh: 50, ol: 15, oh: 40 }, { name: "Albumin", nl: 3.5, nh: 5, ol: 4.2, oh: 5 }]);
    const en = JSON.parse(fs.readFileSync(path.join(seedDir, "biomarker-ranges-en.json"), "utf8"));
    const es = JSON.parse(fs.readFileSync(path.join(seedDir, "rangos-biomarcadores-es.json"), "utf8"));
    en.biomarker_ranges[0].Clinical_Notes = "High urea is linked to higher mortality.";
    es.rangos_biomarcadores[0].Notas_Clínicas = "Una urea alta se asocia a mayor mortalidad; acude a urgencias.";
    en.biomarker_ranges[1].Clinical_Notes = "The main protein in blood.";
    es.rangos_biomarcadores[1].Notas_Clínicas = "La principal proteína de la sangre.";
    fs.writeFileSync(path.join(seedDir, "biomarker-ranges-en.json"), JSON.stringify(en));
    fs.writeFileSync(path.join(seedDir, "rangos-biomarcadores-es.json"), JSON.stringify(es));
    const r = await messageChecks.find((c) => c.id === "M3")!.run(makeCtx({ root: ROOT, seedDir, thresholds: {} }));
    expect(r.failures.filter((f) => f.key.includes("|clinical_notes|")).map((f) => [f.key, f.detail])).toEqual([
      ["row|urea|both|All Adults|clinical_notes|en", "banned: mortality"],
      ["row|urea|both|All Adults|clinical_notes|es", "banned: mortalidad, urgencias"],
    ]);
  });
});

describe("coherence (K1)", () => {
  it("judges disagreements by direction and level", () => {
    expect(judge(["optimal"], [1], "critical_high")).toBe("opposite");
    expect(judge(["optimal", "optimal"], [1, -1], "above_optimal")).toBe("one_step");
    expect(judge(["critical_high"], [1], "optimal")).toBe("opposite");
    expect(judge(["critical_high"], [1], "critical_high")).toBeNull();
    expect(judge(["above_optimal", "optimal"], [1, 1], "critical_low")).toBeNull();
    expect(judge(["above_optimal", "above_optimal"], [1, -1], "optimal")).toBeNull();
  });

  it("fails an opposite pair: BUN optimal while urea = BUN x 2.14 is out of range", () => {
    const rs = rows([
      { name: "BUN", nl: 6, nh: 24, ol: 10, oh: 20 },
      { name: "Urea", nl: 10, nh: 35, ol: 15, oh: 30 },
    ]);
    const rep = runCoherence(rs, 18, 100);
    const { failures } = coherenceFailures(rep.patterns, []);
    expect(failures.map((f) => f.key)).toContain("opposite|urea_bun|female|bun:optimal->urea:critical_high");
    expect(rep.metrics.relationships_skipped).toBeGreaterThan(0);
  });

  it("passes consistent rows and accepts one-step patterns with a reason", () => {
    const rs = rows([
      { name: "BUN", nl: 7, nh: 20, ol: 10, oh: 16 },
      { name: "Urea", nl: 14.98, nh: 42.8, ol: 21.4, oh: 34.24 },
    ]);
    const rep = runCoherence(rs, 18, 100);
    expect(rep.patterns.filter((p) => p.verdict === "opposite")).toEqual([]);
    const accepted = coherenceFailures(rep.patterns, [{ pattern: /^urea_bun/, reason: "rounding" }]);
    expect(accepted.failures).toEqual([]);
  });

  it("implements CKD-EPI 2021 and Vermeulen", () => {
    expect(ckdEpi2021(1.0, 50, "male")).toBeCloseTo(91.7, 0);
    expect(ckdEpi2021(0.7, 40, "female")).toBeCloseTo(112.4, 0);
    // Total T 5 ng/mL (17.3 nmol/L), SHBG 30 nmol/L, albumin 43 g/L: about 2% free, near 10 ng/dL.
    const ft = vermeulenFreeT(5, 30, 43);
    expect(ft).toBeGreaterThan(8);
    expect(ft).toBeLessThan(13);
  });
});

/** G1's compile part when the seed directory, supabase/seed-data under the root, is not a compile output. */
const SEED_NOT_COMPILED = "supabase/seed-data/compile-report.json (a compile output as the seed directory, for the idempotency check)";
const COMPILE_NOT_RERUN = "compile not rerun (supabase/seed-data holds no compile-report.json, so it is not a compile output)";

describe("governance (G1-G7)", () => {
  it("G1 at round 0 takes the frozen files as the baseline, is blocked on the compile part when the seed is not a compile output, and detects unapproved frozen changes", async () => {
    // Round 0 with today's seed: the frozen part is the baseline, and supabase/seed-data is no compile output to rerun.
    const ctx = makeCtx({ root: ROOT, round: 0, thresholds: {} });
    const r = await govChecks.find((c) => c.id === "G1")!.run(ctx);
    expect(r.status).toBe("blocked");
    expect(r.blocked_on).toBe(SEED_NOT_COMPILED);
    expect(r.summary).toMatch(/^round 0 is the baseline: \d+ frozen files hashed; compile not rerun \(supabase\/seed-data holds no compile-report\.json, so it is not a compile output\)$/);
    expect(r.metrics).toMatchObject({ baseline: "this run", compile_output: false, compile_rerun: false });
    const changes = diffFrozen({ "a.md": "1", "b.md": "2" }, { "a.md": "1", "b.md": "3", "c.md": "4" });
    expect(changes.map((c) => `${c.kind}:${c.file}`)).toEqual(["changed:b.md", "added:c.md"]);
    expect(unapproved(changes, [{ file: "b.md", sha256: "3", commit: "deadbeef", approved_by: "CEO" }]).map((c) => c.file)).toEqual(["c.md"]);
  });

  it("checks fixer diffs against the ownership map", () => {
    expect(outsideOwnership(["docs/signoff/work/judges/r1/J1-f01.json", "src/x.ts"], ["docs/signoff/work/judges/*/*f01*.json"])).toEqual(["src/x.ts"]);
    const f = ownershipViolations({ f01: ["docs/signoff/work/research/f01.json", "PLAN.md"], ghost: ["x"] }, { f01: ["docs/signoff/work/research/f01.json"] });
    expect(f.map((x) => x.key).sort()).toEqual(["ownership|f01|PLAN.md", "ownership|ghost|x"]);
  });

  /**
   * A G1 fixture: a root without the frozen inputs but the lens file, approved at its hash (so the frozen part finds no
   * unapproved change and the ownership part decides the result), two families and their owned paths. Its seed
   * directory, supabase/seed-data under the fixture root, is no compile output, so the compile part is blocked
   * throughout.
   */
  function g1Fixture() {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-g1-"));
    const workDir = path.join(root, "work");
    const checksDir = path.join(workDir, "checks");
    fs.mkdirSync(checksDir, { recursive: true });
    fs.mkdirSync(path.join(root, "docs/signoff/work/judges"), { recursive: true });
    fs.copyFileSync(path.join(ROOT, JUDGE_PROMPTS_FILE), path.join(root, JUDGE_PROMPTS_FILE));
    fs.mkdirSync(path.join(workDir, "governance"), { recursive: true });
    fs.writeFileSync(path.join(workDir, "governance", "approved-changes.json"), JSON.stringify([{ file: JUDGE_PROMPTS_FILE, sha256: sha256File(path.join(root, JUDGE_PROMPTS_FILE)), commit: "abc1234", approved_by: "CEO" }]));
    const owned = (f: string) => [`docs/signoff/work/decisions/${f}.json`, `docs/signoff/work/ledger/${f}.json`];
    fs.writeFileSync(path.join(workDir, "families.json"), JSON.stringify({ families: { f01_x: { owned_paths: owned("f01_x") }, f03_y: { owned_paths: owned("f03_y") } } }));
    fs.writeFileSync(path.join(checksDir, "round-0.json"), JSON.stringify({ inputs: {} }));
    const ctx = makeCtx({ root, workDir, round: 3, thresholds: {} });
    return { root, checksDir, owned, run: async () => govChecks.find((c) => c.id === "G1")!.run(ctx) };
  }

  it("G1 judges ownership only from the round's complete record: a family record that leaves out an out-of-scope edit does not count", async () => {
    const { checksDir, owned, run } = g1Fixture();
    // The round changed two family files and an app file. The loop's family record holds only the changed paths that
    // contain the family id (ws1-batch.js check step 2), so the app file is missing from it.
    const familyRecord = { f01_x: ["docs/signoff/work/decisions/f01_x.json"], f03_y: owned("f03_y") };
    fs.writeFileSync(path.join(checksDir, "B01-r3-changes.json"), JSON.stringify(familyRecord));
    const without = await run();
    expect(without.status).toBe("blocked");
    expect(without.blocked_on).toBe(`work/checks/round-3-changes.json (the round's changed files per agent, for the ownership check); ${SEED_NOT_COMPILED}`);
    expect(without.metrics!.ownership_checked).toBe(false);
    // The complete record names the app file with the agent that changed it: one out-of-scope edit.
    fs.writeFileSync(roundChangesFile(checksDir, 3), JSON.stringify({ ...familyRecord, f01_x: [...familyRecord.f01_x, "src/lib/biomarkers/zone-classifier.ts"] }));
    const complete = await run();
    expect(complete.status).toBe("fail");
    expect(complete.failures).toEqual([{ key: "ownership|f01_x|src/lib/biomarkers/zone-classifier.ts", detail: "outside f01_x's owned paths" }]);
    expect(complete.summary).toBe(`0 frozen files changed without approval; 1 out-of-scope edits; ${COMPILE_NOT_RERUN}`);
    expect(complete.metrics!.ownership_checked).toBe(true);
    // A complete record whose paths all lie inside their agents' owned paths passes the ownership part, which leaves G1
    // blocked on the compile part alone; an agent with no entry fails.
    fs.writeFileSync(roundChangesFile(checksDir, 3), JSON.stringify(familyRecord));
    const inside = await run();
    expect(inside.status).toBe("blocked");
    expect(inside.blocked_on).toBe(SEED_NOT_COMPILED);
    expect(inside.summary).toBe(`0 frozen files changed without approval; 0 out-of-scope edits; ${COMPILE_NOT_RERUN}`);
    fs.writeFileSync(roundChangesFile(checksDir, 3), JSON.stringify({ ...familyRecord, orchestrator: ["docs/signoff/work/checks/B01-r3.json"] }));
    expect((await run()).failures.map((f) => f.key)).toEqual(["ownership|orchestrator|docs/signoff/work/checks/B01-r3.json"]);
  });

  it("G1 fails on a round record it cannot read, does not read the batch records, and never reports an unchecked ownership as 0 out-of-scope edits", async () => {
    const { root, checksDir, run } = g1Fixture();
    // An unreadable batch record is not read at all.
    fs.writeFileSync(path.join(checksDir, "B02-r3-changes.json"), "{ not json");
    expect((await run()).status).toBe("blocked");
    fs.writeFileSync(roundChangesFile(checksDir, 3), "{ not json");
    const r = await run();
    expect(r.status).toBe("fail");
    expect(r.failures).toEqual([{ key: "ownership|record|round-3-changes.json", detail: "work/checks/round-3-changes.json is not a JSON object of path lists; the round's edits were not checked against the ownership map" }]);
    expect(r.summary).toBe(`0 frozen files changed without approval; ownership not checked (unreadable work/checks/round-3-changes.json); ${COMPILE_NOT_RERUN}`);
    expect(r.metrics!.ownership_checked).toBe(false);
    for (const doc of [[], { f01_x: "docs/signoff/work/decisions/f01_x.json" }, { f01_x: [1] }, null, "x"]) {
      fs.writeFileSync(roundChangesFile(checksDir, 3), JSON.stringify(doc));
      expect(readRoundRecord(roundChangesFile(checksDir, 3))).toEqual({ changes: null, unreadable: true });
    }
    expect(readRoundRecord(roundChangesFile(checksDir, 2))).toEqual({ changes: null, unreadable: false });
    // A frozen file changed and no round record: G1 fails on the frozen file and says the ownership was not checked.
    fs.rmSync(roundChangesFile(checksDir, 3));
    fs.mkdirSync(path.join(root, "scripts/signoff"), { recursive: true });
    fs.writeFileSync(path.join(root, "scripts/signoff/x.ts"), "export {};\n");
    const frozen = await run();
    expect(frozen.status).toBe("fail");
    expect(frozen.failures.map((f) => f.key)).toEqual(["frozen|scripts/signoff/x.ts"]);
    expect(frozen.summary).toBe(`1 frozen files changed without approval; ownership not checked (no work/checks/round-3-changes.json); ${COMPILE_NOT_RERUN}`);
    expect(frozen.metrics!.ownership_checked).toBe(false);
  });

  // traceRows' seed inputs: the rows and the two files' rows they are read from, with the compile's row library. The
  // fixture rows carry the State column the compile writes for a row compiled from a final row ("none").
  const compileRowsLib = loadCompileRows(ROOT);
  const traceSeed = (specs: Spec[]) => {
    const { en, es } = raw(specs);
    return { rows: buildRows(en, es), pairs: { en, es }, compileRows: compileRowsLib };
  };
  const compiledSpecs = (specs: Spec[]): Spec[] => specs.map((s) => ({ st: "none", ...s }));

  it("G2 traces a row to its family's decision final row by the row's fields, with a verifier verdict", () => {
    const families = { non_rows: { biological_age: "pseudo-row" }, families: { f01_x: { keys: ["albumin", "total_protein"] }, f02_y: { keys: ["alp"] } } };
    const seed = traceSeed(compiledSpecs([{ name: "Albumin" }, { name: "Total Protein" }, { name: "Biological Age" }]));
    // common.schema.json final rows carry no row_key; their key is marker_key|sex|age_group|physiological_state.
    // The seed rows hold the unit mg/dL and no bounds; so do their final rows.
    const final = (marker_key: string) => ({ marker_key, sex: "both", age_group: "All Adults", physiological_state: "none", unit: "mg/dL", reference_low: null, reference_high: null, optimal_low: null, optimal_high: null, critical_low: null, critical_high: null, grade: "B" });
    const verdicts = { f01_x: { row_verdicts: [{ row_key: "albumin|both|All Adults|none", verdict: "corrected" }, { row_key: "total_protein|both|All Adults|none", verdict: "confirmed" }] } };
    expect(traceRows({ ...seed, families, decisions: { f01_x: { final_rows: [final("albumin"), final("total_protein")] } }, verifies: verdicts })).toEqual([]);
    // A row_key field on a final row is not what the row is matched on.
    const keyOnly: FinalRowFields & { row_key: string } = { row_key: "total_protein|both|All Adults|none" };
    const f = traceRows({ ...seed, families, decisions: { f01_x: { final_rows: [final("albumin"), keyOnly] } }, verifies: verdicts });
    expect(f).toEqual([{ key: "row|total_protein|both|All Adults|none", detail: "not among the final_rows of decisions/f01_x.json" }]);
    // Every other requirement stays: a decisions file and a verifier verdict.
    expect(traceRows({ ...seed, families, decisions: {}, verifies: verdicts }).map((x) => x.detail)).toEqual(["no decisions/f01_x.json", "no decisions/f01_x.json"]);
    const noVerdict = traceRows({ ...seed, families, decisions: { f01_x: { final_rows: [final("albumin"), final("total_protein")] } }, verifies: { f01_x: { row_verdicts: verdicts.f01_x.row_verdicts.slice(0, 1) } } });
    expect(noVerdict).toEqual([{ key: "row|total_protein|both|All Adults|none", detail: "no verifier verdict in verify/f01_x.json" }]);
    expect(traceRows({ ...traceSeed([{ name: "Ferritin" }]), families, decisions: {}, verifies: {} })[0].detail).toBe("marker is in no family of families.json");
  });

  it("G2 traces a row only when it holds its final row's six bounds and unit", () => {
    const families = { families: { f01_x: { keys: ["albumin"] } } };
    const verifies = { f01_x: { row_verdicts: [{ row_key: "albumin|both|All Adults|none", verdict: "corrected" }] } };
    const decided = { marker_key: "albumin", sex: "both", age_group: "All Adults", physiological_state: "none", unit: "g/L", reference_low: 32, reference_high: 48, optimal_low: 41, optimal_high: null, critical_low: null, critical_high: null, grade: "B" };
    const trace = (specs: Spec[], finals: FinalRowFields[]) => traceRows({ ...traceSeed(compiledSpecs(specs)), families, decisions: { f01_x: { final_rows: finals } }, verifies });
    expect(trace([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null }], [decided])).toEqual([]);
    // Today's production values under the decision's key do not trace to the decision, in either file.
    expect(trace([{ name: "Albumin", unit: "g/L", nl: 35, nh: 48, ol: 42, oh: 48 }], [decided])).toEqual([
      {
        key: "row|albumin|both|All Adults|none",
        detail: "differs from its final row in decisions/f01_x.json: Normal_Low 35 vs reference_low 32; Optimal_Low 42 vs optimal_low 41; Optimal_High 48 vs optimal_high null; Normal_Bajo 35 vs reference_low 32; Óptimo_Bajo 42 vs optimal_low 41; Óptimo_Alto 48 vs optimal_high null",
      },
    ]);
    expect(trace([{ name: "Albumin", unit: "g/dL", nl: 32, nh: 48, ol: 41, oh: null }], [decided])[0].detail).toBe('differs from its final row in decisions/f01_x.json: Unit "g/dL" vs unit "g/L"; Unidad "g/dL" vs unit_es, else unit "g/L"');
    // The compile keeps the later of two final rows with one key.
    expect(trace([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null }], [{ ...decided, reference_low: 30 }, decided])).toEqual([]);
    expect(trace([{ name: "Albumin", unit: "g/L", nl: 32, nh: 48, ol: 41, oh: null }], [decided, { ...decided, reference_low: 30 }])[0].detail).toMatch(/Normal_Low 32 vs reference_low 30; Normal_Bajo 32 vs reference_low 30$/);
    // The critical limits the compile writes (Critical_Low / Critical_High) are compared too.
    const seedRow = { unit_en: "g/L", normal_low: 32, normal_high: 48, optimal_low: 41, optimal_high: null, critical_low: 20, critical_high: null, reference_basis: null, source: null };
    expect(finalRowMismatches(seedRow, { ...decided, critical_low: 20 })).toEqual([]);
    expect(finalRowMismatches(seedRow, { ...decided, critical_low: 15 })).toEqual(["Critical_Low 20 vs critical_low 15"]);
    expect(finalRowMismatches(seedRow, { ...decided, critical_low: 20, unit: undefined })).toEqual(['Unit "g/L" vs unit null']);
  });

  it("G2 traces a row only when it holds its final row's reference basis and source, the columns D3 and N1 read", () => {
    const families = { families: { f03_x: { keys: ["bun"] } } };
    const verifies = { f03_x: { row_verdicts: [{ row_key: "bun|both|All Adults|none", verdict: "confirmed" }] } };
    const source = "Echevarne B0110, catalogue 2026-09";
    const decided = { marker_key: "bun", sex: "both", age_group: "All Adults", physiological_state: "none", unit: "mg/dL", reference_low: 7, reference_high: 20, optimal_low: null, optimal_high: 20, critical_low: null, critical_high: 100, reference_basis: "echevarne_interval", reference_source: source };
    const bun: Spec = { name: "BUN", nl: 7, nh: 20, ol: null, oh: 20, cl: null, ch: 100, rb: "echevarne_interval", rs: source };
    const traceRaw = (seed: { en: RawEn[]; es: RawEs[] }) => traceRows({ rows: buildRows(seed.en, seed.es), pairs: seed, compileRows: compileRowsLib, families, decisions: { f03_x: { final_rows: [decided] } }, verifies });
    const trace = (specs: Spec[]) => traceRaw(raw(compiledSpecs(specs)));
    expect(trace([bun])).toEqual([]);
    // Key, bounds and unit match its final row; the basis does not, in either file.
    expect(trace([{ ...bun, rb: "decision_limit" }])).toEqual([
      { key: "row|bun|both|All Adults|none", detail: 'differs from its final row in decisions/f03_x.json: Reference_Basis "decision_limit" vs reference_basis "echevarne_interval"; Base_Referencia "decision_limit" vs reference_basis "echevarne_interval"' },
    ]);
    expect(trace([{ ...bun, rs: "f03-E01" }])[0].detail).toBe(`differs from its final row in decisions/f03_x.json: Reference_Source "f03-E01" vs reference_source "${source}"; Fuente_Referencia "f03-E01" vs reference_source_es, else reference_source "${source}"`);
    expect(trace([{ ...bun, rb: undefined, rs: undefined }])[0].detail).toBe(
      `differs from its final row in decisions/f03_x.json: Reference_Basis null vs reference_basis "echevarne_interval"; Reference_Source null vs reference_source "${source}"; Base_Referencia null vs reference_basis "echevarne_interval"; Fuente_Referencia null vs reference_source_es, else reference_source "${source}"`,
    );
    // Where Reference_Basis is empty the checks read reference_basis (seed.ts), so G2 compares that.
    const fallback = raw(compiledSpecs([bun]));
    fallback.en[0] = { ...fallback.en[0], Reference_Basis: "", reference_basis: "decision_limit" };
    expect(traceRaw(fallback)[0].detail).toBe('differs from its final row in decisions/f03_x.json: Reference_Basis "decision_limit" vs reference_basis "echevarne_interval"');
    // What the comparison protects: D3 compares the row with the catalogue only while its basis is the decision's.
    const cat: CatalogueRow[] = [{ code: "B0110", description: "BUN", unit: "mg/dL", sex: "both", sex_raw: "", condition: "", age_low: 0, age_high: 999, age_raw: "0-999", low: 8, high: 23, low_raw: "8", high_raw: "23", line: 1 }];
    expect(checkLabConcordance(rows([bun]), cat, { B0110: "bun" }).failures.map((f) => f.key)).toEqual(["bun|both|All Adults|bounds"]);
    expect(checkLabConcordance(rows([{ ...bun, rb: "decision_limit" }]), cat, { B0110: "bun" }).metrics.exempt_rows).toBe(1);
  });

  it("G2 traces a row only when it holds the messages of both files, Explanatory_Numbers in order and every other column the compile writes from its final row", () => {
    const families = { families: { f01_x: { keys: ["albumin"] } } };
    const verifies = { f01_x: { row_verdicts: [{ row_key: "albumin|both|All Adults|none", verdict: "corrected" }] } };
    // A final row with its messages in both languages, explanatory numbers and notes (common.schema.json row).
    const decided = {
      marker_key: "albumin",
      sex: "both",
      age_group: "All Adults",
      physiological_state: "none",
      unit: "g/L",
      reference_low: 32,
      reference_high: 48,
      optimal_low: 41,
      optimal_high: null,
      critical_low: null,
      critical_high: null,
      reference_basis: "echevarne_interval",
      reference_source: "Echevarne B0010",
      marker_class: "a",
      explanatory_numbers: [2, 4, 41],
      clinical_notes_en: "Made by the liver.",
      clinical_notes_es: "La produce el hígado.",
      messages: {
        en: { below_range: "Below 32 g/L.", below_optimal: "Between 32 and 41 g/L.", optimal: "From 41 g/L.", above_range: "Above 48 g/L." },
        es: { below_range: "Por debajo de 32 g/L.", below_optimal: "Entre 32 y 41 g/L.", optimal: "Desde 41 g/L.", above_range: "Por encima de 48 g/L." },
      },
    };
    // The pair the compile writes from it (compile-rows.js pairFromLoopRow, a template row giving the category and name) traces.
    const template = raw([{ name: "Albumin", unit: "g/L" }]);
    const compiled = compileRowsLib.pairFromLoopRow(decided, { en: template.en[0], es: template.es[0] }, [], () => {});
    const detail = (pair: SeedPair) => traceRows({ rows: buildRows([pair.en], [pair.es]), pairs: { en: [pair.en], es: [pair.es] }, compileRows: compileRowsLib, families, decisions: { f01_x: { final_rows: [decided] } }, verifies }).map((f) => f.detail);
    const differs = (what: string) => [`differs from its final row in decisions/f01_x.json: ${what}`];
    expect(detail(compiled)).toEqual([]);
    expect(pairMismatches(compiled, decided, [compiled], compileRowsLib)).toEqual([]);
    // A message in either file.
    expect(detail({ en: { ...compiled.en, Msg_Below_Optimal: "Your albumin is below 38 g/L." }, es: compiled.es })).toEqual(differs('Msg_Below_Optimal "Your albumin is below 38 g/L." vs messages.en.below_optimal "Between 32 and 41 g/L."'));
    expect(detail({ en: compiled.en, es: { ...compiled.es, Msg_Óptimo: "Óptima." } })).toEqual(differs('Msg_Óptimo "Óptima." vs messages.es.optimal or in_range "Desde 41 g/L."'));
    // A message on a zone the final row gives none: the compile writes none.
    expect(detail({ en: { ...compiled.en, Msg_Above_Optimal: "Above optimal." }, es: compiled.es })).toEqual(differs('Msg_Above_Optimal "Above optimal." vs messages.en.above_optimal null'));
    // Explanatory_Numbers, the list M4 accepts a message's numbers from: in order, and with a number added.
    expect(detail({ en: { ...compiled.en, Explanatory_Numbers: [41, 4, 2] }, es: compiled.es })).toEqual(differs("Explanatory_Numbers [41,4,2] vs explanatory_numbers [2,4,41]"));
    expect(detail({ en: { ...compiled.en, Explanatory_Numbers: [2, 4, 41, 38] }, es: compiled.es })).toEqual(differs("Explanatory_Numbers [2,4,41,38] vs explanatory_numbers [2,4,41]"));
    // A message and its explanatory number edited together, as a hand edit that M4 alone would pass.
    expect(detail({ en: { ...compiled.en, Msg_Below_Optimal: "Your albumin is below 38 g/L.", Explanatory_Numbers: [2, 4, 41, 38] }, es: compiled.es })).toEqual(
      differs('Msg_Below_Optimal "Your albumin is below 38 g/L." vs messages.en.below_optimal "Between 32 and 41 g/L."; Explanatory_Numbers [2,4,41,38] vs explanatory_numbers [2,4,41]'),
    );
    // The other columns the compile writes from the final row: a sign-off column, a note and the Spanish label.
    expect(detail({ en: { ...compiled.en, Marker_Class: "e" }, es: compiled.es })).toEqual(differs('Marker_Class "e" vs marker_class "a"'));
    expect(detail({ en: { ...compiled.en, Clinical_Notes: "Low albumin means liver disease." }, es: compiled.es })).toEqual(differs('Clinical_Notes "Low albumin means liver disease." vs clinical_notes_en "Made by the liver."'));
    expect(detail({ en: compiled.en, es: { ...compiled.es, Grupo_Edad: "Embarazo" } })).toEqual(differs('Grupo_Edad "Embarazo" vs age_group and physiological_state "Todos los Adultos"'));
    // A final row without messages or notes: the compile keeps the template's, so the seed's own are not compared.
    const bare: FinalRowFields = Object.fromEntries(Object.entries(decided).filter(([k]) => !["messages", "clinical_notes_en", "clinical_notes_es"].includes(k)));
    expect(pairMismatches({ en: { ...compiled.en, Msg_Below_Optimal: "Any text." }, es: compiled.es }, bare, [], compileRowsLib)).toEqual([]);
  });

  it("G2 builds a seed row's trace key the way the compile labels state rows", () => {
    const r = (age_group_en: string, sex = "female") => ({ biomarker_key: "x", sex, age_group_en });
    expect(rowTraceKey(r("40-84", "both"))).toBe("x|both|40-84|none");
    expect(rowTraceKey(r("Pregnancy"))).toBe("x|female|All Adults|pregnancy");
    expect(rowTraceKey(r("Lactation"))).toBe("x|female|All Adults|lactation");
    expect(rowTraceKey(r("Premenopausal (follicular)"))).toBe("x|female|All Adults|follicular");
    expect(rowTraceKey(r("Ovulatory peak"))).toBe("x|female|All Adults|ovulatory");
    expect(rowTraceKey(r("On Hormone Therapy"))).toBe("x|female|All Adults|hormone_therapy");
    expect(rowTraceKey(r("On Oral Contraception"))).toBe("x|female|All Adults|oral_contraception");
    // compile-rows.js ageStateToLabel appends the band to the state label for a banded state row.
    expect(rowTraceKey(r("Pregnancy 18-39"))).toBe(finalRowKey({ marker_key: "x", sex: "female", age_group: "18-39", physiological_state: "pregnancy" }));
    // The State column the compile writes wins over the label.
    expect(rowTraceKey(r("Pregnant (any trimester)"))).toBe("x|female|Pregnant (any trimester)|none");
    expect(rowTraceKey(r("Pregnant (any trimester)"), "pregnancy")).toBe("x|female|All Adults|pregnancy");
    expect(rowTraceKey(r("18-39", "both"), "none")).toBe("x|both|18-39|none");
    expect(rowTraceKey(r("Postmenopausal"), "not_a_state")).toBe("x|female|All Adults|postmenopausal");
  });

  it("blocks G2 and G4-G7 when their inputs do not exist", async () => {
    const ctx = makeCtx({ root: ROOT, workDir: fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-work-")), thresholds: {} });
    for (const id of ["G2", "G7"]) expect((await govChecks.find((c) => c.id === id)!.run(ctx)).status).toBe("blocked");
  });

  it("judges cold-reader answers and cover labels", () => {
    const answers = Array.from({ length: 12 }, (_, i) => ({ id: i + 1, answer: "yes", pages: [3] }));
    expect(judgeColdReader({ answers, reading_hours_total: 8, reading_hours_max_session: 2.5 }, {})).toEqual([]);
    const bad = judgeColdReader({ answers: answers.slice(0, 11), sessions: [{ hours: 4 }, { hours: 7 }] }, {});
    expect(bad.map((f) => f.key).sort()).toEqual(["answered", "reading_time_session", "reading_time_total"]);
    expect(missingCoverLabels("Scope of signature. The physician's role. AI work product.")).toEqual([]);
    expect(missingCoverLabels("Scope of signature. Physician's role. AI work product. Judge verdict: fine.")).toEqual(["ai_pre_review_label"]);
  });
});

describe("G1: the compile is idempotent and the judge prompts are frozen; G2: added rows held to their template rows", () => {
  const COMPILE_TOOL = path.join(ROOT, "docs/signoff/tools/compile.js");
  const lib = loadCompileRows(ROOT);
  const { lit } = toolRequire(path.join(ROOT, "docs/signoff/tools/lib/compile-sql.js")) as { lit(v: unknown, col: string): string };
  const production = loadCompileTools(ROOT)!.buildBaseline({ snapshot: path.join(ROOT, PRODUCTION_SNAPSHOT), migrationsDir: path.join(ROOT, "supabase/migrations") }).rows;
  const B01 = ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"];
  const FAMILY = "f01_albumin_proteins";
  /** The files compile.js writes into --out-dir besides compile-report.json, and into --reconciliation-dir. */
  const OUTPUTS = ["CHANGES.md", "biomarker-ranges-en.json", "biomarker-sources.json", "changes.json", "migration.sql", "rangos-biomarcadores-es.json", "rollback.sql"];
  const RECONCILIATION = ["reconciliation/diff.json", "reconciliation/forward.sql", "reconciliation/rollback.sql"];
  const tmp = (name: string) => fs.mkdtempSync(path.join(os.tmpdir(), `dsrt-${name}-`));
  const copyOf = (dir: string) => {
    const to = tmp("g1-copy");
    fs.cpSync(dir, to, { recursive: true });
    return to;
  };
  const ctxFor = (seedDir: string, workDir: string, round = 3) => makeCtx({ root: ROOT, seedDir, workDir, round, thresholds: {} });
  const idempotency = (seedDir: string, workDir: string) => compileIdempotency(ctxFor(seedDir, workDir));
  const keysOf = (f: { key: string }[]) => f.map((x) => x.key);

  /** docs/signoff/tools/compile.js under ROOT, run as the loop runs it (docs/signoff/workflows/ws1-batch.js), with the reconciliation files in the output folder when asked. */
  const compileInto = (workDir: string, outDir: string, families: string[], reconciliation = false) =>
    execFileSync(process.execPath, [COMPILE_TOOL, "--out-dir", outDir, "--work-dir", workDir, "--families", families.join(","), ...(reconciliation ? ["--reconciliation-dir", path.join(outDir, "reconciliation")] : [])], { cwd: ROOT, stdio: "pipe" });

  const messages = {
    en: { below_range: "Below the reference range.", below_optimal: "Below the optimal band.", optimal: "In the optimal band.", above_range: "Above the reference range." },
    es: { below_range: "Por debajo del intervalo de referencia.", below_optimal: "Por debajo de la banda óptima.", optimal: "En la banda óptima.", above_range: "Por encima del intervalo de referencia." },
  };
  const finalRow = (over: Record<string, unknown>): Record<string, unknown> => ({
    marker_key: "albumin",
    sex: "both",
    age_group: "All Adults",
    physiological_state: "none",
    unit: "g/L",
    marker_class: "a",
    reference_low: 35,
    reference_high: 48,
    reference_basis: "echevarne_interval",
    reference_source: "Echevarne B0010, catalogue 2026-09",
    optimal_low: 42,
    optimal_high: 48,
    band_rule: "nadir_ci",
    critical_low: null,
    critical_high: null,
    critical_none_reason: "none, because no same-day limit applies in this range",
    messages,
    explanatory_numbers: [],
    grade: "B",
    ...over,
  });
  const loopKey = (r: Record<string, unknown>) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state}`;

  /**
   * A work dir with today's families.json and a decision for f01_albumin_proteins, each row with a verifier verdict:
   * albumin for all adults (a row production has) and in pregnancy (a row production does not have, whose template is
   * the seed's albumin row), and total protein split at 60 into two rows production does not have, without messages
   * of their own: the decision keeps no total protein row production has, so their template is production's row.
   * Globulin and the albumin/globulin ratio are retired, and the decision records each production row it removes.
   * Every final row states its marker's clinical note as today's
   * seed has it, in both languages, which is the note its template gives: the compile stops on a row without one.
   */
  function fixtureWork(): string {
    const dir = tmp("g1-work");
    fs.copyFileSync(path.join(ROOT, "docs/signoff/work/families.json"), path.join(dir, "families.json"));
    const pregnancy = {
      en: { below_range: "Below the pregnancy range.", in_range: "Within the pregnancy range.", above_range: "Above the pregnancy range." },
      es: { below_range: "Por debajo del intervalo del embarazo.", in_range: "Dentro del intervalo del embarazo.", above_range: "Por encima del intervalo del embarazo." },
    };
    const totalProtein = (age_group: string, reference_low: number, reference_high: number) =>
      finalRow({ marker_key: "total_protein", marker_class: "e", age_group, reference_low, reference_high, optimal_low: null, optimal_high: null, band_rule: "none", grade: "D", messages: { en: {}, es: {} } });
    const seedEn = (JSON.parse(fs.readFileSync(path.join(ROOT, "supabase/seed-data/biomarker-ranges-en.json"), "utf8")) as { biomarker_ranges: Record<string, unknown>[] }).biomarker_ranges;
    const seedEs = (JSON.parse(fs.readFileSync(path.join(ROOT, "supabase/seed-data/rangos-biomarcadores-es.json"), "utf8")) as { rangos_biomarcadores: Record<string, unknown>[] }).rangos_biomarcadores;
    const notesOf = (name: string) => {
      const i = seedEn.findIndex((r) => r.Biomarker === name);
      return { clinical_notes_en: (seedEn[i].Clinical_Notes as string | null) ?? null, clinical_notes_es: (seedEs[i]["Notas_Clínicas"] as string | null) ?? null };
    };
    const finals = [
      finalRow({ ...notesOf("Albumin") }),
      finalRow({ sex: "female", physiological_state: "pregnancy", reference_low: 29, reference_high: 45, optimal_low: null, optimal_high: null, band_rule: "none", messages: pregnancy, ...notesOf("Albumin") }),
      { ...totalProtein("18-59", 57, 82), ...notesOf("Total Protein") },
      { ...totalProtein("60+", 55, 80), ...notesOf("Total Protein") },
    ];
    // The decision's own record of each production row it removes (decision CEO-11): globulin and the
    // albumin/globulin ratio, retired, and total protein for all adults, split at 60.
    const removed = (row_key: string, reason: string) => ({ row_key, field: "row", from: "row present", to: null, direction: "neutral", reason, evidence_ids: [] });
    const changes = [
      removed("albumin_globulin_ratio|both|All Adults|none", "Retired: derived from albumin and globulin, and no outcome evidence supports a band of its own."),
      removed("globulin|both|All Adults|none", "Retired: computed as total protein minus albumin, which the panel reports."),
      removed("total_protein|both|All Adults|none", "Split at 60 into two age rows."),
    ];
    for (const [dir2, doc] of [
      ["decisions", { schema_version: "1", family: FAMILY, final_rows: finals, changes, evidence: [] }],
      ["verify", { schema_version: "1", family: FAMILY, row_verdicts: finals.map((r) => ({ row_key: loopKey(r), verdict: "confirmed", grade: "B" })) }],
    ] as const) {
      fs.mkdirSync(path.join(dir, dir2), { recursive: true });
      fs.writeFileSync(path.join(dir, dir2, `${FAMILY}.json`), JSON.stringify(doc, null, 2));
    }
    return dir;
  }

  /** The fixture compiled into a seed directory, as the loop compiles a batch, with the reconciliation files there when asked. */
  function fixtureCompile(reconciliation = false): { work: string; seed: string } {
    const work = fixtureWork();
    const seed = tmp("g1-seed");
    compileInto(work, seed, [FAMILY], reconciliation);
    return { work, seed };
  }

  /** traceRows over the rows of `families` in a compile output, with the work dir's decisions and verdicts and production, as G2 reads them. */
  function trace(seedDir: string, workDir: string, families: string[], stats?: TraceStats) {
    const seed = loadSeed(seedDir)!;
    const fam = JSON.parse(fs.readFileSync(path.join(workDir, "families.json"), "utf8")) as { families: Record<string, { keys: string[] }> };
    const keys = new Set(families.flatMap((f) => fam.families[f].keys));
    const rows = seed.rows.filter((r) => keys.has(r.biomarker_key));
    const read = (dir: string, f: string) => JSON.parse(fs.readFileSync(path.join(workDir, dir, `${f}.json`), "utf8"));
    return traceRows({
      rows,
      pairs: { en: seed.en, es: seed.es },
      compileRows: lib,
      families: fam,
      decisions: Object.fromEntries(families.map((f) => [f, read("decisions", f)])),
      verifies: Object.fromEntries(families.map((f) => [f, read("verify", f)])),
      states: new Map(rows.map((r) => [r.index, seed.en[r.index]?.State])),
      production,
      stats,
    });
  }

  /** Set columns of the seed row with database key `key` in a compile output, written as compile.js writes the seed files (two-space JSON, no trailing newline). */
  function editSeed(dir: string, key: string, en: Record<string, unknown>, es: Record<string, unknown> = {}) {
    const enFile = path.join(dir, "biomarker-ranges-en.json");
    const esFile = path.join(dir, "rangos-biomarcadores-es.json");
    const enDoc = JSON.parse(fs.readFileSync(enFile, "utf8")) as { biomarker_ranges: RawEn[] };
    const esDoc = JSON.parse(fs.readFileSync(esFile, "utf8")) as { rangos_biomarcadores: RawEs[] };
    const i = enDoc.biomarker_ranges.findIndex((e) => lib.dbKey(lib.dbRowFromPair({ en: e, es: {} })) === key);
    expect(i).toBeGreaterThanOrEqual(0);
    Object.assign(enDoc.biomarker_ranges[i], en);
    Object.assign(esDoc.rangos_biomarcadores[i], es);
    if (Object.keys(en).length) fs.writeFileSync(enFile, JSON.stringify(enDoc, null, 2));
    if (Object.keys(es).length) fs.writeFileSync(esFile, JSON.stringify(esDoc, null, 2));
  }

  /** Set columns of the upsert tuple of `key` in a compile output's migration.sql (or another forward migration of the folder, such as the reconciliation set's forward.sql), each value written as compile-sql.js lit() writes it. */
  function editMigration(dir: string, key: string, values: Record<string, unknown>, name = "migration.sql") {
    const file = path.join(dir, name);
    const lines = fs.readFileSync(file, "utf8").split("\n");
    const head = lines.findIndex((l) => l.startsWith("insert into public.biomarker_references ("));
    const cols = lines[head].slice(lines[head].indexOf("(") + 1, lines[head].indexOf(")")).split(",").map((c) => c.trim());
    let hits = 0;
    for (let i = head + 2; i < lines.length && lines[i].startsWith("  ("); i++) {
      const comma = lines[i].endsWith("),");
      const raw = splitSqlList(lines[i].replace(/^ {2}\(/, "").replace(/\),?$/, ""));
      const rec = Object.fromEntries(cols.map((c, n) => [c, sqlLiteral(raw[n])]));
      if (`${rec.biomarker_key}|${rec.sex}|${rec.age_group_en}` !== key) continue;
      for (const [c, v] of Object.entries(values)) {
        expect(cols).toContain(c);
        raw[cols.indexOf(c)] = lit(v, c);
      }
      lines[i] = `  (${raw.join(", ")})${comma ? "," : ""}`;
      hits++;
    }
    expect(hits).toBe(1);
    fs.writeFileSync(file, lines.join("\n"));
  }

  it("G1 hashes the judge prompts of docs/signoff/work/judges/lenses.json, which round 0 did not, and lists the file as added until the CEO approves it", async () => {
    // The lens role texts LOOP-PROMPT.md section 2.3 freezes are a hashed input, read under the root.
    expect(JUDGE_PROMPTS_FILE).toBe("docs/signoff/work/judges/lenses.json");
    const seedDir = path.join(ROOT, "supabase/seed-data");
    expect(inputFiles(ROOT, seedDir)).toContain(JUDGE_PROMPTS_FILE);
    expect(hashInputs(ROOT, seedDir)[JUDGE_PROMPTS_FILE]).toBe(sha256File(path.join(ROOT, JUDGE_PROMPTS_FILE)));
    // The round-0 baseline does not hold it.
    const round0 = JSON.parse(fs.readFileSync(path.join(ROOT, "docs/signoff/work/checks/round-0.json"), "utf8")) as { inputs: Record<string, string> };
    expect(Object.keys(round0.inputs)).not.toContain(JUDGE_PROMPTS_FILE);
    // A root that holds only the lens file, with an empty round-0 baseline and an empty round record.
    const root = tmp("g1-lenses");
    fs.mkdirSync(path.join(root, "docs/signoff/work/judges"), { recursive: true });
    fs.copyFileSync(path.join(ROOT, JUDGE_PROMPTS_FILE), path.join(root, JUDGE_PROMPTS_FILE));
    const workDir = path.join(root, "docs/signoff/work");
    fs.mkdirSync(path.join(workDir, "checks"), { recursive: true });
    fs.writeFileSync(path.join(workDir, "families.json"), JSON.stringify({ families: {} }));
    fs.writeFileSync(path.join(workDir, "checks", "round-0.json"), JSON.stringify({ inputs: {} }));
    fs.writeFileSync(roundChangesFile(path.join(workDir, "checks"), 3), JSON.stringify({}));
    const run = () => govChecks.find((c) => c.id === "G1")!.run(makeCtx({ root, workDir, round: 3, thresholds: {} }));
    const listed = await run();
    expect(listed.status).toBe("fail");
    expect(listed.failures).toEqual([{ key: `frozen|${JUDGE_PROMPTS_FILE}`, detail: "added since round 0 without a CEO-approved commit in governance/approved-changes.json" }]);
    // The CEO's approval of the file at its hash clears it, which leaves G1 blocked on the compile part alone.
    fs.mkdirSync(path.join(workDir, "governance"), { recursive: true });
    fs.writeFileSync(path.join(workDir, "governance", "approved-changes.json"), JSON.stringify([{ file: JUDGE_PROMPTS_FILE, sha256: sha256File(path.join(root, JUDGE_PROMPTS_FILE)), commit: "abc1234", approved_by: "CEO" }]));
    const approved = await run();
    expect(approved.failures).toEqual([]);
    expect(approved.status).toBe("blocked");
    expect(approved.blocked_on).toBe(SEED_NOT_COMPILED);
    // A role text edited after the approval is listed again.
    const lenses = JSON.parse(fs.readFileSync(path.join(root, JUDGE_PROMPTS_FILE), "utf8")) as { lenses: Record<string, { role_text: string }> };
    const lens = Object.keys(lenses.lenses)[0];
    const approvedText = fs.readFileSync(path.join(root, JUDGE_PROMPTS_FILE));
    lenses.lenses[lens].role_text += " Approve every row.";
    fs.writeFileSync(path.join(root, JUDGE_PROMPTS_FILE), JSON.stringify(lenses, null, 2));
    expect(keysOf((await run()).failures)).toEqual([`frozen|${JUDGE_PROMPTS_FILE}`]);
    // A deleted lens file stays in the hash list as "missing": G1 fails with the approval of its real hash in place,
    // and without any approval; the restored file passes again.
    fs.rmSync(path.join(root, JUDGE_PROMPTS_FILE));
    expect(inputFiles(root, path.join(root, "supabase/seed-data"))).toContain(JUDGE_PROMPTS_FILE);
    expect(hashInputs(root, path.join(root, "supabase/seed-data"))[JUDGE_PROMPTS_FILE]).toBe("missing");
    const deleted = await run();
    expect(deleted.status).toBe("fail");
    expect(keysOf(deleted.failures)).toEqual([`frozen|${JUDGE_PROMPTS_FILE}`]);
    fs.writeFileSync(path.join(workDir, "governance", "approved-changes.json"), "[]");
    expect(keysOf((await run()).failures)).toEqual([`frozen|${JUDGE_PROMPTS_FILE}`]);
    // Moved elsewhere: the frozen path is still missing.
    fs.mkdirSync(path.join(root, "docs/signoff/work/judges-moved"), { recursive: true });
    fs.writeFileSync(path.join(root, "docs/signoff/work/judges-moved/lenses.json"), approvedText);
    expect(keysOf((await run()).failures)).toEqual([`frozen|${JUDGE_PROMPTS_FILE}`]);
    fs.writeFileSync(path.join(root, JUDGE_PROMPTS_FILE), approvedText);
    fs.writeFileSync(path.join(workDir, "governance", "approved-changes.json"), JSON.stringify([{ file: JUDGE_PROMPTS_FILE, sha256: sha256File(path.join(root, JUDGE_PROMPTS_FILE)), commit: "abc1234", approved_by: "CEO" }]));
    expect((await run()).failures).toEqual([]);
  });

  it("G1 reruns the compile of a compile output and passes when every file the compile writes is the seed directory's, byte for byte, the reconciliation files included", async () => {
    const { work, seed } = fixtureCompile(true);
    const r = idempotency(seed, work);
    expect(r.failures).toEqual([]);
    expect(r.blockedOn).toBeNull();
    expect(r.summary).toBe("compile rerun: 0 of 10 output files differ");
    expect(r.metrics).toEqual({ compile_output: true, compile_rerun: true, compile_files_compared: 10, compile_files_differing: 0, compile_files_not_comparable: 0, compile_inputs_differing: 0, compile_reconciliation_set_files: 0 });
    // Deterministic, so G3 can hash it; through G1 at round 0, where the frozen part is the baseline, G1 passes.
    expect(stableStringify(idempotency(seed, work))).toBe(stableStringify(r));
    const g1 = await govChecks.find((c) => c.id === "G1")!.run(ctxFor(seed, work, 0));
    expect(g1.status).toBe("pass");
    expect(g1.summary).toMatch(/^round 0 is the baseline: \d+ frozen files hashed; compile rerun: 0 of 10 output files differ$/);
    // What compile-report.json records about the run is what the rerun was given.
    const report = JSON.parse(fs.readFileSync(path.join(seed, COMPILE_REPORT), "utf8"));
    expect(readCompileRun(report).run).toMatchObject({ families: [FAMILY], migrationName: "signoff_ranges", writeSeed: false });
  });

  it("G1 fails each file the compile writes that is edited after the compile, naming it, and one missing from the seed directory", () => {
    const { work, seed } = fixtureCompile(true);
    for (const f of [...OUTPUTS, ...RECONCILIATION]) {
      const copy = copyOf(seed);
      fs.appendFileSync(path.join(copy, f), " ");
      const r = idempotency(copy, work);
      expect(keysOf(r.failures), f).toEqual([`compile|${f}`]);
      expect(r.failures[0].detail).toMatch(/^differs from what docs\/signoff\/tools\/compile\.js writes when run again with what compile-report\.json records \(--families f01_albumin_proteins, --migration-name signoff_ranges, --work-dir [^)]+\): first difference at line \d+, column \d+: /);
      expect(r.summary).toBe("compile rerun: 1 of 10 output files differ");
    }
    const copy = copyOf(seed);
    fs.rmSync(path.join(copy, "CHANGES.md"));
    const missing = idempotency(copy, work);
    expect(keysOf(missing.failures)).toEqual(["compile|CHANGES.md"]);
    expect(missing.failures[0].detail).toMatch(/, missing from /);
    // The first difference names the line and column with an excerpt of each side.
    expect(firstDifference("a\nbcd\n", "a\nbXd\n")).toBe('first difference at line 2, column 2: the seed directory\'s file has "bcd", the compile writes "bXd"');
    expect(firstDifference("a", "a\nb")).toBe("the compile writes 1 more lines from line 2");
    expect(firstDifference("a\nb", "a")).toBe("the seed directory's file has 1 more lines from line 2");
  });

  it("G1 and G2 catch a hand edit of a row the pack adds, made in the seed and in the migration with the change list untouched, that D5 does not see", async () => {
    const { work, seed } = fixtureCompile();
    // The compile's own output: nothing to find. Of its three added rows, one is held to the seed's albumin row and two
    // to production's total protein row (the decision keeps no total protein row production has).
    const stats: TraceStats = { added_rows_held_to_template: 0, added_rows_differing_from_template: 0, added_rows_without_template: 0 };
    expect(trace(seed, work, [FAMILY], stats)).toEqual([]);
    expect(stats).toEqual({ added_rows_held_to_template: 3, added_rows_differing_from_template: 0, added_rows_without_template: 0 });
    expect(idempotency(seed, work).failures).toEqual([]);
    const d5 = async (dir: string) => keysOf((await dataChecks.find((c) => c.id === "D5")!.run(ctxFor(dir, work))).failures);
    const d5Before = await d5(seed);
    const ALB = "albumin|female|Pregnancy";
    const TP = "total_protein|both|60+";
    const fromSeed = "differs from its template row albumin|both|All Adults (compile-rows.js pickTemplate among the seed's rows of albumin that production has)";
    const fromProduction = "differs from its template row total_protein|both|All Adults (compile-rows.js pickTemplate among production's rows of total_protein, built with compile-rows.js pairFromDbRow)";
    // The final rows state their notes (the compile stops on a row without them), so G2 holds a note to the final row.
    const fromFinalRow = `differs from its final row in decisions/${FAMILY}.json`;
    const cases: { name: string; key: string; en?: Record<string, unknown>; es?: Record<string, unknown>; sql: Record<string, unknown>; files: string[]; detail: RegExp; head?: string }[] = [
      { name: "tested twice a year", key: ALB, en: { Tested_2x_Year: "No" }, sql: { tested_2x_year: false }, files: ["biomarker-ranges-en.json", "migration.sql"], detail: /^Tested_2x_Year "No" vs "Yes"$/ },
      { name: "English note", key: ALB, en: { Clinical_Notes: "Low albumin in pregnancy means liver disease." }, sql: { clinical_notes_en: "Low albumin in pregnancy means liver disease." }, files: ["biomarker-ranges-en.json", "migration.sql"], detail: /^Clinical_Notes "Low albumin in pregnancy means liver disease\." vs clinical_notes_en "/, head: fromFinalRow },
      { name: "Spanish note", key: ALB, es: { Notas_Clínicas: "La albúmina baja significa enfermedad hepática." }, sql: { clinical_notes_es: "La albúmina baja significa enfermedad hepática." }, files: ["migration.sql", "rangos-biomarcadores-es.json"], detail: /^Notas_Clínicas "La albúmina baja significa enfermedad hepática\." vs clinical_notes_es "/, head: fromFinalRow },
      { name: "Spanish name", key: ALB, es: { Biomarcador: "Albúmina sérica" }, sql: { name_es: "Albúmina sérica" }, files: ["migration.sql", "rangos-biomarcadores-es.json"], detail: /^Biomarcador "Albúmina sérica" vs "Albúmina"$/ },
      { name: "category", key: TP, en: { Category: "Heart" }, sql: { panel_category: "cardiovascular" }, files: ["biomarker-ranges-en.json", "migration.sql"], detail: /^Category "Heart" vs "Liver"$/ },
      { name: "message kept from the template", key: TP, en: { Msg_Optimal: "Your protein is perfect." }, sql: { msg_optimal_en: "Your protein is perfect." }, files: ["biomarker-ranges-en.json", "migration.sql"], detail: /^Msg_Optimal "Your protein is perfect\." vs / },
    ];
    for (const c of cases) {
      const copy = copyOf(seed);
      editSeed(copy, c.key, c.en ?? {}, c.es ?? {});
      editMigration(copy, c.key, c.sql);
      // G1: the two files edited after the compile.
      expect(keysOf(idempotency(copy, work).failures), c.name).toEqual(c.files.map((f) => `compile|${f}`));
      // G2: the column the compile copies from the template row, with the seed's value and the template row's.
      const f = trace(copy, work, [FAMILY]);
      expect(f, c.name).toHaveLength(1);
      const head = c.head ?? (c.key === ALB ? fromSeed : fromProduction);
      expect(f[0].key).toBe(c.key === ALB ? "row|albumin|female|All Adults|pregnancy" : "row|total_protein|both|60+|none");
      expect(f[0].detail.startsWith(`${head}: `), c.name).toBe(true);
      expect(f[0].detail.slice(head.length + 2), c.name).toMatch(c.detail);
      // D5 holds an added row's other columns to the migration alone, which the same edit changed.
      expect(await d5(copy), c.name).toEqual(d5Before);
    }
  });

  it("G1 compares the reconciliation files the seed directory holds, and is blocked on diff.json when the run's work dir is not the folder the compile read", () => {
    const { work, seed } = fixtureCompile(true);
    // diff.json names the decision file of the rows it removes by its path.
    expect(fs.readFileSync(path.join(seed, "reconciliation/diff.json"), "utf8")).toContain(`/decisions/${FAMILY}.json`);
    const moved = copyOf(work);
    const r = idempotency(seed, moved);
    expect(r.failures).toEqual([]);
    expect(r.blockedOn).toMatch(/\/reconciliation\/diff\.json run again from the work dir it names \(.+, as compile-report\.json records it\): it names each family's source file by its path, and this run reads them from /);
    expect(r.metrics).toMatchObject({ compile_files_compared: 10, compile_files_differing: 0, compile_files_not_comparable: 1, compile_inputs_differing: 0 });
    // Any other difference in diff.json fails, from either work dir.
    const copy = copyOf(seed);
    fs.appendFileSync(path.join(copy, "reconciliation/diff.json"), " ");
    expect(keysOf(idempotency(copy, moved).failures)).toEqual(["compile|reconciliation/diff.json"]);
    expect(idempotency(copy, moved).blockedOn).toBeNull();
    // Without a reconciliation folder only the output folder's files are compared.
    const bare = copyOf(seed);
    fs.rmSync(path.join(bare, "reconciliation"), { recursive: true });
    expect(idempotency(bare, moved)).toMatchObject({ failures: [], blockedOn: null, metrics: { compile_files_compared: 7 } });
  });

  /**
   * The fixture compiled as docs/signoff/work/reconciliation/README.md builds the reconciliation set: the seed directory
   * and, in the same run, the set in the work dir's reconciliation folder, where D6 reads it, with the reader-test
   * step's result beside it.
   */
  function fixtureCompileWithSet(): { work: string; seed: string; set: string } {
    const work = fixtureWork();
    const seed = tmp("g1-seed-set");
    const set = path.join(work, "reconciliation");
    execFileSync(process.execPath, [COMPILE_TOOL, "--out-dir", seed, "--work-dir", work, "--families", FAMILY, "--reconciliation-dir", set], { cwd: ROOT, stdio: "pipe" });
    fs.writeFileSync(path.join(set, "reader-results.json"), JSON.stringify({ passed: true, failed: 0 }));
    return { work, seed, set };
  }
  /** A reconciliation diff with a reason and a source written by hand into every row the compile left without one (the review's diff-reasons copy). */
  const fillReasons = (from: string, to: string) => {
    const d = JSON.parse(fs.readFileSync(from, "utf8")) as { rows: { reason: string | null; source: string | null; unexplained_fields: string[] }[] };
    const filled = d.rows.filter((r) => !r.reason || !r.source);
    for (const r of filled) Object.assign(r, { reason: r.reason || "Seed text kept.", source: r.source || "seed", unexplained_fields: [] });
    fs.writeFileSync(to, JSON.stringify(d, null, 2) + "\n");
    return filled.length;
  };
  const d6Keys = async (seedDir: string, workDir: string) => keysOf((await dataChecks.find((c) => c.id === "D6")!.run(ctxFor(seedDir, workDir))).failures);

  it("G1 holds the reconciliation set D6 reads in the work dir to the rerun: reasons filled into diff.json by hand, an edited forward.sql tuple, an edited rollback.sql and a hand-made diff file D6 reads first each fail; with none of the three there is nothing to compare", async () => {
    const { work, seed, set } = fixtureCompileWithSet();
    const setShown = path.relative(ROOT, set).split(path.sep).join("/");
    const control = idempotency(seed, work);
    expect(control.failures).toEqual([]);
    expect(control.blockedOn).toBeNull();
    expect(control.summary).toBe(`compile rerun: 0 of 10 output files differ (3 of them the reconciliation set D6 reads, in ${setShown})`);
    expect(control.metrics).toMatchObject({ compile_files_compared: 10, compile_files_differing: 0, compile_reconciliation_set_files: 3 });
    // The compile leaves rows of the set's diff without a reason, which D6 fails.
    const d6Control = await d6Keys(seed, work);
    const unexplained = d6Control.filter((k) => k.endsWith("|unexplained"));
    expect(unexplained.length).toBeGreaterThan(0);
    const pristine = new Map(fs.readdirSync(set).map((f) => [f, fs.readFileSync(path.join(set, f))]));
    const reset = () => {
      fs.rmSync(set, { recursive: true, force: true });
      fs.mkdirSync(set);
      for (const [f, b] of pristine) fs.writeFileSync(path.join(set, f), b);
    };
    const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
    // What the compile was run with, as a detail names it.
    const RUN = `${esc("docs/signoff/tools/compile.js run again with what compile-report.json records (--families f01_albumin_proteins, --migration-name signoff_ranges, --work-dir ")}[^)]+\\)`;
    const DIFF_READ = "D6 reads it as the reconciliation diff, and D5 as the change list when no changes.json is next to the seed";
    const FORWARD_READ = "D6 reads it as the forward migration, and D5 as the documented migration when no changes.json is next to the seed";
    const differs = (readAs: string) => new RegExp(`^${esc(`${readAs}; it differs from what docs/signoff/tools/compile.js writes when run again with what compile-report.json records (`)}[^)]+\\): first difference at line \\d+, column \\d+: the work dir's file has `);
    const cases: { name: string; edit: () => void; key: string; detail: RegExp; d6Passes?: boolean }[] = [
      { name: "reasons filled into diff.json by hand", edit: () => expect(fillReasons(path.join(set, "diff.json"), path.join(set, "diff.json"))).toBe(unexplained.length), key: "compile|work-dir/reconciliation/diff.json", detail: differs(DIFF_READ), d6Passes: true },
      { name: "forward.sql tuple edited", edit: () => editMigration(set, "albumin|both|All Adults", { normal_low: 25 }, "forward.sql"), key: "compile|work-dir/reconciliation/forward.sql", detail: differs(FORWARD_READ) },
      { name: "rollback.sql edited", edit: () => fs.appendFileSync(path.join(set, "rollback.sql"), "-- kept\n"), key: "compile|work-dir/reconciliation/rollback.sql", detail: differs("D6 reads it as the rollback") },
      {
        name: "a hand-made diff file sorted before diff.json",
        edit: () => fillReasons(path.join(set, "diff.json"), path.join(set, "diff-a.json")),
        key: "compile|work-dir/reconciliation/diff-a.json",
        detail: new RegExp(`^${esc(`${DIFF_READ} (the first entry of ${setShown}, in sorted order, whose name matches /diff.*\\.json$/i), and `)}${RUN}${esc(" writes diff.json there, not diff-a.json")}$`),
        d6Passes: true,
      },
      { name: "a hand-made forward migration sorted before forward.sql", edit: () => fs.writeFileSync(path.join(set, "forward-0.sql"), pristine.get("forward.sql")!), key: "compile|work-dir/reconciliation/forward-0.sql", detail: new RegExp(`^${esc(`${FORWARD_READ} (the first entry of ${setShown}, in sorted order, whose name matches /forward.*\\.sql$/i), and `)}${RUN}${esc(" writes forward.sql there, not forward-0.sql")}$`) },
      {
        name: "rollback.sql missing",
        edit: () => fs.rmSync(path.join(set, "rollback.sql")),
        key: "compile|work-dir/reconciliation/rollback.sql",
        detail: new RegExp(`^${esc(`D6 finds no rollback file in ${setShown} (no entry whose name matches /rollback.*\\.sql$/i), which holds diff.json and forward.sql of the reconciliation set: `)}${RUN}${esc(" writes rollback.sql with them")}$`),
      },
      {
        name: "a folder in diff.json's place",
        edit: () => {
          fs.rmSync(path.join(set, "diff.json"));
          fs.mkdirSync(path.join(set, "diff.json"));
        },
        key: "compile|work-dir/reconciliation/diff.json",
        detail: new RegExp(`^${esc(`${DIFF_READ}, and it is not a file`)}$`),
        d6Passes: true,
      },
      {
        name: "a file in the folder's place",
        edit: () => {
          fs.rmSync(set, { recursive: true });
          fs.writeFileSync(set, "");
        },
        key: "compile|work-dir/reconciliation",
        detail: new RegExp(`^${esc(`D6 reads the reconciliation set from ${setShown}, which is not a folder`)}$`),
      },
    ];
    for (const c of cases) {
      reset();
      c.edit();
      const r = idempotency(seed, work);
      expect(keysOf(r.failures), c.name).toEqual([c.key]);
      expect(r.failures[0].detail, c.name).toMatch(c.detail);
      expect(r.blockedOn, c.name).toBeNull();
      // D6 itself no longer fails the rows the compile left unexplained where the hand-made diff gives them a reason.
      if (c.d6Passes) expect((await d6Keys(seed, work)).filter((k) => k.endsWith("|unexplained")), c.name).toEqual([]);
    }
    // A set that is not this seed directory's compile: the decision changed and the seed directory was compiled again
    // without the set. The seed directory's files are the rerun's; the set's diff and forward migration are not.
    reset();
    const later = copyOf(work);
    const decFile = path.join(later, "decisions", `${FAMILY}.json`);
    const dec = JSON.parse(fs.readFileSync(decFile, "utf8"));
    dec.final_rows[0].optimal_low = 41;
    fs.writeFileSync(decFile, JSON.stringify(dec, null, 2));
    const laterSeed = tmp("g1-seed-later");
    compileInto(later, laterSeed, [FAMILY]);
    const stale = idempotency(laterSeed, later);
    expect(keysOf(stale.failures)).toEqual(expect.arrayContaining(["compile|work-dir/reconciliation/diff.json", "compile|work-dir/reconciliation/forward.sql"]));
    expect(keysOf(stale.failures).every((k) => k.startsWith("compile|work-dir/reconciliation/"))).toBe(true);
    // diff.json keeps the not-comparable rule: the work dir moved after the compile, with its set, leaves diff.json
    // comparable only from the folder it names, and the part blocked on it; forward.sql and rollback.sql are equal.
    const moved = copyOf(work);
    const fromMoved = idempotency(seed, moved);
    expect(fromMoved.failures).toEqual([]);
    expect(fromMoved.blockedOn).toMatch(/\/reconciliation\/diff\.json run again from the work dir it names \(.+, as compile-report\.json records it\): it names each family's source file by its path, and this run reads them from /);
    expect(fromMoved.metrics).toMatchObject({ compile_files_compared: 10, compile_files_differing: 0, compile_files_not_comparable: 1, compile_reconciliation_set_files: 3 });
    // A folder that holds none of the three files the compile writes there holds no set: nothing to compare.
    for (const f of ["diff.json", "forward.sql", "rollback.sql"]) fs.rmSync(path.join(set, f));
    fs.writeFileSync(path.join(set, "reasons.template.json"), "{}");
    const none = idempotency(seed, work);
    expect(none).toMatchObject({ failures: [], blockedOn: null, summary: "compile rerun: 0 of 7 output files differ", metrics: { compile_files_compared: 7, compile_reconciliation_set_files: 0 } });
  }, 60_000);

  it("G1's compile part is blocked when the seed directory is not a compile output or its compile wrote over the seed it read, and fails on a report that records no run, a rerun that does not complete, or other inputs than the recorded ones", () => {
    // Not a compile output: blocked, never passed.
    const plain = tmpSeed([{ name: "Albumin" }]);
    const work = fixtureWork();
    const notCompiled = idempotency(plain, work);
    expect(notCompiled.failures).toEqual([]);
    expect(notCompiled.blockedOn).toMatch(/\/compile-report\.json \(a compile output as the seed directory, for the idempotency check\)$/);
    expect(notCompiled.summary).toMatch(/^compile not rerun \(.+ holds no compile-report\.json, so it is not a compile output\)$/);
    const { seed } = fixtureCompile();
    const withReport = (edit: (doc: Record<string, unknown>) => void) => {
      const copy = copyOf(seed);
      const doc = JSON.parse(fs.readFileSync(path.join(copy, COMPILE_REPORT), "utf8"));
      edit(doc);
      fs.writeFileSync(path.join(copy, COMPILE_REPORT), JSON.stringify(doc, null, 2));
      return idempotency(copy, work);
    };
    // A compile run with --write-seed wrote its seed files over the seed it read: blocked; the rerun never writes the seed.
    const wroteSeed = withReport((d) => ((d.options as Record<string, unknown>).write_seed = true));
    expect(wroteSeed.failures).toEqual([]);
    expect(wroteSeed.blockedOn).toMatch(/records --write-seed/);
    // A report that is no record of a run fails, and nothing is run with what it holds.
    for (const [edit, problem] of [
      [(d: Record<string, unknown>) => ((d.options as Record<string, unknown>).families = []), "options.families is neither null nor a list of family ids"],
      [(d: Record<string, unknown>) => ((d.options as Record<string, unknown>).families = ["--write-seed"]), "options.families is neither null nor a list of family ids"],
      [(d: Record<string, unknown>) => ((d.options as Record<string, unknown>).migration_name = "x; drop table"), "options.migration_name is not a migration name"],
      [(d: Record<string, unknown>) => delete d.options, "it has no options object"],
    ] as const) {
      const r = withReport(edit);
      expect(keysOf(r.failures)).toEqual(["compile|report"]);
      expect(r.failures[0].detail).toContain(`(${problem})`);
    }
    const garbled = copyOf(seed);
    fs.writeFileSync(path.join(garbled, COMPILE_REPORT), "{ not json");
    expect(idempotency(garbled, work).failures[0].detail).toContain("(it is not a JSON object)");
    // A rerun that does not complete fails: here the work dir's families.json lacks the family the report records.
    const noFamily = copyOf(work);
    const fam = JSON.parse(fs.readFileSync(path.join(noFamily, "families.json"), "utf8"));
    delete fam.families[FAMILY];
    fs.writeFileSync(path.join(noFamily, "families.json"), JSON.stringify(fam));
    const broken = idempotency(seed, noFamily);
    expect(keysOf(broken.failures)).toEqual(["compile|run"]);
    expect(broken.failures[0].detail).toMatch(/: exit 2, compile\.js: unknown family f01_albumin_proteins$/);
    // The work dir's decision changed after the compile: the recorded input fails, and so does every file it changes.
    const changed = copyOf(work);
    const decFile = path.join(changed, "decisions", `${FAMILY}.json`);
    const dec = JSON.parse(fs.readFileSync(decFile, "utf8"));
    dec.final_rows[0].optimal_low = 41;
    fs.writeFileSync(decFile, JSON.stringify(dec, null, 2));
    const other = idempotency(seed, changed);
    expect(keysOf(other.failures)).toContain(`compile|input|${FAMILY}`);
    expect(other.failures.find((f) => f.key === `compile|input|${FAMILY}`)!.detail).toMatch(/^compile-report\.json records source decisions .+ sha256 [0-9a-f]{64}; the compile run again on the work dir .+ reads source decisions .+ sha256 [0-9a-f]{64}: the seed directory is not the compile of these inputs$/);
    expect(keysOf(other.failures)).toEqual(expect.arrayContaining(["compile|biomarker-ranges-en.json", "compile|migration.sql", "compile|changes.json"]));
  });

  it("G2 holds an added row to the template row pickTemplate picks among the seed's rows of its marker that production has, else among production's, and finds no template for a marker neither has", () => {
    // Seed pairs with the columns the compile copies from a template: names in both languages, category, tested twice a year, notes.
    const pairOf = (s: Spec, nameEs: string): SeedPair => {
      const { en, es } = raw([s]);
      return { en: { ...en[0], Category: "Liver", Tested_2x_Year: "Yes", Clinical_Notes: "Made by the liver." }, es: { ...es[0], Biomarcador: nameEs, Categoría: "Hígado", Analizado_2x_Año: "Sí", Notas_Clínicas: "La produce el hígado." } };
    };
    const albumin = pairOf({ name: "Albumin", unit: "g/L", st: "none" }, "Albúmina");
    const pregnancy = pairOf({ name: "Albumin", unit: "g/L", sex: "Female", age: "Pregnancy", st: "pregnancy" }, "Albúmina");
    const keys = new Set(production.map((r) => lib.dbKey(r)));
    expect(keys.has(lib.dbKey(lib.dbRowFromPair(albumin)))).toBe(true);
    expect(keys.has(lib.dbKey(lib.dbRowFromPair(pregnancy)))).toBe(false);
    const final = { marker_key: "albumin", sex: "female", age_group: "All Adults", physiological_state: "pregnancy", unit: "g/L" };
    // Among the seed's rows of the marker that production has; the added row itself is never its own template.
    expect(addedRowTemplate(final, [pregnancy, albumin], keys, production, {}, lib)).toEqual({ pair: albumin, among: "seed" });
    // Without one, among production's rows of the marker, as compile.js builds a marker the seed lacks.
    const fromProduction = addedRowTemplate(final, [pregnancy], keys, production, { Liver: "Hígado" }, lib)!;
    expect(fromProduction.among).toBe("production");
    expect(lib.dbKey(lib.dbRowFromPair(fromProduction.pair))).toBe("albumin|both|All Adults");
    expect(addedRowTemplate({ ...final, marker_key: "no_such_marker" }, [], keys, production, {}, lib)).toBeNull();
    // Only the columns the compile copies from the template are compared with it; a column written from the final row
    // that the seed does not hold is left to pairMismatches, so it is not listed twice.
    expect(templateMismatches(pregnancy, final, albumin, [pregnancy, albumin], lib)).toEqual([]);
    const edited: SeedPair = { en: { ...pregnancy.en, Tested_2x_Year: "No", Unit: "g/dL" }, es: { ...pregnancy.es, Biomarcador: "Albúmina sérica" } };
    expect(templateMismatches(edited, final, albumin, [edited, albumin], lib)).toEqual(['Tested_2x_Year "No" vs "Yes"', 'Biomarcador "Albúmina sérica" vs "Albúmina"']);
    expect(pairMismatches(edited, final, [edited, albumin], lib)).toEqual([]);
    // Through traceRows. The pregnancy row traces; with Tested_2x_Year edited it differs from its template row; a caller
    // without production holds no row to a template; the albumin row, which production has, is not held to one (D5
    // holds it to production and the change list).
    const families = { families: { f01_x: { keys: ["albumin"] } } };
    const both = { marker_key: "albumin", sex: "both", age_group: "All Adults", physiological_state: "none", unit: "g/L" };
    const verifies = { f01_x: { row_verdicts: [final, both].map((d) => ({ row_key: loopKey(d), verdict: "confirmed" })) } };
    const run = (pairs: SeedPair[], finals: FinalRowFields[], withProduction: boolean) =>
      traceRows({ rows: buildRows(pairs.map((p) => p.en), pairs.map((p) => p.es)), pairs: { en: pairs.map((p) => p.en), es: pairs.map((p) => p.es) }, compileRows: lib, families, decisions: { f01_x: { final_rows: finals } }, verifies, ...(withProduction ? { production } : {}) });
    const pregnancyNo: SeedPair = { en: { ...pregnancy.en, Tested_2x_Year: "No" }, es: pregnancy.es };
    expect(run([albumin, pregnancy], [final, both], true)).toEqual([]);
    expect(run([albumin, pregnancyNo], [final, both], true)).toEqual([
      { key: "row|albumin|female|All Adults|pregnancy", detail: `differs from its template row albumin|both|All Adults (compile-rows.js pickTemplate among the seed's rows of albumin that production has): Tested_2x_Year "No" vs "Yes"` },
    ]);
    expect(run([albumin, pregnancyNo], [final, both], false)).toEqual([]);
    expect(run([{ en: { ...albumin.en, Tested_2x_Year: "No" }, es: albumin.es }], [both], true)).toEqual([]);
    // An added row of a marker neither the seed nor production has is held to nothing: it fails.
    const ghost = pairOf({ name: "Ghost Marker", unit: "g/L", st: "none" }, "Marcador Fantasma");
    expect(
      traceRows({ rows: buildRows([ghost.en], [ghost.es]), pairs: { en: [ghost.en], es: [ghost.es] }, compileRows: lib, families: { families: { f01_x: { keys: ["ghost_marker"] } } }, decisions: { f01_x: { final_rows: [{ marker_key: "ghost_marker", sex: "both", age_group: "All Adults", physiological_state: "none", unit: "g/L" }] } }, verifies: {}, production }).map((f) => f.detail),
    ).toEqual(["has no template row: the seed holds no row of ghost_marker that production has, and production holds none, so the columns the compile copies from a template row are held to nothing"]);
  });

  it("blocks G2 when production cannot be built, as no row can be told to be added", async () => {
    const root = tmp("g2-noprod");
    fs.cpSync(path.join(ROOT, "docs/signoff/tools"), path.join(root, "docs/signoff/tools"), { recursive: true });
    const workDir = path.join(root, "work");
    fs.mkdirSync(path.join(workDir, "decisions"), { recursive: true });
    fs.writeFileSync(path.join(workDir, "families.json"), JSON.stringify({ families: {} }));
    fs.writeFileSync(path.join(workDir, "decisions", "f00_none.json"), "{}");
    const r = await govChecks.find((c) => c.id === "G2")!.run(makeCtx({ root, seedDir: tmpSeed([]), workDir, thresholds: {} }));
    expect(r.status).toBe("blocked");
    expect(r.blocked_on).toBe(`${PRODUCTION_SNAPSHOT} with docs/signoff/tools/lib/compile-baseline.js (production, to tell the rows the pack adds and hold them to their template rows)`);
    expect(r.metrics).toMatchObject({ added_rows: 0, production_rows: 0 });
  });

  /**
   * docs/signoff/work as committed in `commit`, for the B01 families: the files the compile and G2 read (families.json,
   * and each family's decisions, verify and research files), or null when the clone does not hold that commit.
   */
  function workAt(commit: string): string | null {
    const dir = tmp(`work-${commit}`);
    for (const f of ["families.json", ...["decisions", "verify", "research"].flatMap((d) => B01.map((fam) => `${d}/${fam}.json`))]) {
      let body: Buffer;
      try {
        body = execFileSync("git", ["show", `${commit}:docs/signoff/work/${f}`], { cwd: ROOT, stdio: ["ignore", "pipe", "ignore"], maxBuffer: 256 * 1024 * 1024 });
      } catch {
        return null;
      }
      fs.mkdirSync(path.dirname(path.join(dir, f)), { recursive: true });
      fs.writeFileSync(path.join(dir, f), body);
    }
    return dir;
  }
  // The decisions compiled/B01-r3 (0bebb15) and compiled/B01-r4 (15f04bb) were compiled from; a shallow clone lacks them.
  const W3 = workAt("0bebb15");
  const W4 = workAt("15f04bb");

  it.skipIf(!W3 || !W4)("on the B01 compiles: today's compile of the B01-r4 decisions is its own compile output; compiled/B01-r4 differs from it only in the change reasons and the summaries (decisions CEO-2, CEO-6, CEO-11 and CEO-13); the B01-r3 decisions, whose rows state no notes, no longer compile; G2 holds the two added rows to their template rows with no difference", async () => {
    const compiled = (c: string) => path.join(ROOT, "docs/signoff/work/compiled", c);
    // The work copies hold the decisions compile-report.json records.
    for (const [c, w] of [["B01-r3", W3!], ["B01-r4", W4!]] as const) {
      const report = JSON.parse(fs.readFileSync(path.join(compiled(c), COMPILE_REPORT), "utf8")) as { families: Record<string, { source_sha256: string | null }> };
      for (const f of B01) expect(sha256File(path.join(w, "decisions", `${f}.json`)), `${c} ${f}`).toBe(report.families[f].source_sha256);
    }
    // A compile of the B01-r4 decisions today is its own compile output.
    const today = tmp("g1-r4-today");
    compileInto(W4!, today, B01);
    expect(idempotency(today, W4!)).toMatchObject({ failures: [], blockedOn: null, summary: "compile rerun: 0 of 7 output files differ" });
    // compiled/B01-r4 is the same decisions compiled before decisions CEO-6 (a verifier's verdict documents a field only
    // on a row unchanged since the verdict), CEO-11 (a removed row needs the decision's own record) and CEO-2 and CEO-13
    // (no earlier caveat or review verdict on a recompiled summary): today's compile writes other change reasons, 122
    // changes without a reason where compiled/B01-r4 has 63, in changes.json and CHANGES.md, and other summaries in
    // biomarker-sources.json; the seed rows and the migration are the same.
    const r4 = idempotency(compiled("B01-r4"), W4!);
    expect(keysOf(r4.failures)).toEqual(["compile|CHANGES.md", "compile|biomarker-sources.json", "compile|changes.json"]);
    expect(r4.failures.find((f) => f.key === "compile|changes.json")!.detail).toMatch(/unexplained.{0,4}: 63,.*unexplained.{0,4}: 122,/);
    expect(r4.metrics).toMatchObject({ compile_inputs_differing: 0, compile_files_compared: 7, compile_files_differing: 3 });
    // compiled/B01-r3 is the 0bebb15 decisions, whose rows state no clinical notes: today's compile stops on them
    // (exit 1, a note not reviewed against its row), so G1 cannot rerun it.
    const r3 = idempotency(compiled("B01-r3"), W3!);
    expect(keysOf(r3.failures)).toEqual(["compile|run"]);
    expect(r3.failures[0].detail).toMatch(/: exit 1, compile\.js: note not reviewed against the row: /);
    // G2: the two added eGFR rows (40-84 and 85+) are held to the seed's 18-39 row with no difference.
    for (const [dir, w] of [[compiled("B01-r3"), W3!], [compiled("B01-r4"), W4!], [today, W4!]] as const) {
      const stats: TraceStats = { added_rows_held_to_template: 0, added_rows_differing_from_template: 0, added_rows_without_template: 0 };
      expect(trace(dir, w, B01, stats)).toEqual([]);
      expect(stats).toEqual({ added_rows_held_to_template: 2, added_rows_differing_from_template: 0, added_rows_without_template: 0 });
    }
    // The review's added-tested copy of the B01-r4 compile (egfr 85+ Tested_2x_Year and tested_2x_year): G1 and G2 fail it.
    const copy = copyOf(today);
    editSeed(copy, "egfr_creatinine_based|both|85+", { Tested_2x_Year: "No" });
    editMigration(copy, "egfr_creatinine_based|both|85+", { tested_2x_year: false });
    expect(keysOf(idempotency(copy, W4!).failures)).toEqual(["compile|biomarker-ranges-en.json", "compile|migration.sql"]);
    expect(trace(copy, W4!, B01)).toEqual([
      { key: "row|egfr_creatinine_based|both|85+|none", detail: `differs from its template row egfr_creatinine_based|both|18-39 (compile-rows.js pickTemplate among the seed's rows of egfr_creatinine_based that production has): Tested_2x_Year "No" vs "Yes"` },
    ]);
    // Through the G2 check with every B01 family: 0 untraced rows of 15, 2 of them added.
    const g2 = await govChecks.find((c) => c.id === "G2")!.run(makeCtx({ root: ROOT, seedDir: compiled("B01-r4"), workDir: W4!, families: B01, thresholds: undefined }));
    expect(g2.status).toBe("pass");
    expect(g2.metrics).toMatchObject({ rows: 15, added_rows: 2, added_rows_held_to_template: 2, added_rows_differing_from_template: 0, untraced_rows: 0 });
  });

  it.skipIf(!W4)("on today's compile of the 15f04bb decisions: the reconciliation folder as committed holds no set, so 0 of 7 files differ; the set compiled into the work dir as its README says is held to the compile, and the review's hand edits of it fail G1", async () => {
    // The B01-r4 decisions compiled with today's tools (compiled/B01-r4 predates decision CEO-6; see the test above).
    const r4 = tmp("g1-b01-r4-today");
    compileInto(W4!, r4, B01);
    // The work dir's reconciliation folder as committed: README.md and reasons.template.json, no set.
    const work = copyOf(W4!);
    fs.mkdirSync(path.join(work, "reconciliation"));
    for (const f of ["README.md", "reasons.template.json"]) fs.writeFileSync(path.join(work, "reconciliation", f), execFileSync("git", ["show", `15f04bb:docs/signoff/work/reconciliation/${f}`], { cwd: ROOT }));
    expect(idempotency(r4, work)).toMatchObject({ failures: [], blockedOn: null, summary: "compile rerun: 0 of 7 output files differ", metrics: { compile_reconciliation_set_files: 0 } });
    // The set compiled as the README says, with the B01 families compiled/B01-r4 records: the compile output equals
    // compiled/B01-r4's files, and the set is held to the rerun with no difference.
    const set = path.join(work, "reconciliation");
    const out = tmp("g1-b01-set");
    execFileSync(process.execPath, [COMPILE_TOOL, "--out-dir", out, "--work-dir", work, "--families", B01.join(","), "--reconciliation-dir", set], { cwd: ROOT, stdio: "pipe" });
    fs.writeFileSync(path.join(set, "reader-results.json"), JSON.stringify({ passed: true, failed: 0 }));
    for (const f of OUTPUTS) expect(fs.readFileSync(path.join(out, f)).equals(fs.readFileSync(path.join(r4, f))), f).toBe(true);
    const control = idempotency(r4, work);
    expect(control).toMatchObject({ failures: [], blockedOn: null, metrics: { compile_files_compared: 10, compile_reconciliation_set_files: 3 } });
    const d6Before = (await d6Keys(r4, work)).filter((k) => k.endsWith("|unexplained"));
    // 16 of the 18 changed rows lack a reason for some field: 10 as before decision CEO-6; albumin, fibrinogen, globulin
    // and total protein, whose fields the verifier's verdict documented although the decision changed the row after it;
    // and the two eGFR rows the decision removes without a record of its own (CEO-11).
    expect(d6Before).toHaveLength(16);
    const pristine = new Map(["diff.json", "forward.sql", "rollback.sql"].map((f) => [f, fs.readFileSync(path.join(set, f))]));
    const reset = () => {
      for (const [f, b] of pristine) fs.writeFileSync(path.join(set, f), b);
      fs.rmSync(path.join(set, "diff-a.json"), { force: true });
    };
    // The review's copies: reasons filled into diff.json by hand (D6 then passes those rows), forward.sql's albumin
    // tuple with normal_low 25 and its eGFR 85+ tuple with a harmful English note, rollback.sql edited, and a
    // hand-made diff file read before the compile's.
    const harmful = "A low eGFR means you have kidney disease. Take 40 mg of furosemide daily.";
    const copies: [string, () => void, string][] = [
      ["diff-reasons", () => expect(fillReasons(path.join(set, "diff.json"), path.join(set, "diff.json"))).toBe(16), "diff.json"],
      ["forward-bound", () => editMigration(set, "albumin|both|All Adults", { normal_low: 25 }, "forward.sql"), "forward.sql"],
      ["forward-notes", () => editMigration(set, "egfr_creatinine_based|both|85+", { clinical_notes_en: harmful }, "forward.sql"), "forward.sql"],
      ["rollback-edit", () => fs.writeFileSync(path.join(set, "rollback.sql"), fs.readFileSync(path.join(set, "rollback.sql"), "utf8").replace("-- 4. Sign-off columns", "-- 4. Sign-off columns (kept)")), "rollback.sql"],
      ["diff-first", () => fillReasons(path.join(set, "diff.json"), path.join(set, "diff-a.json")), "diff-a.json"],
    ];
    for (const [name, edit, file] of copies) {
      reset();
      edit();
      expect(keysOf(idempotency(r4, work).failures), name).toEqual([`compile|work-dir/reconciliation/${file}`]);
    }
    reset();
    fillReasons(path.join(set, "diff.json"), path.join(set, "diff.json"));
    expect((await d6Keys(r4, work)).filter((k) => k.endsWith("|unexplained"))).toEqual([]);
  }, 60_000);
});
