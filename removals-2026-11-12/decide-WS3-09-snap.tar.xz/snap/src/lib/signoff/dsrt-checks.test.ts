/**
 * Unit tests of the DSRT check modules for evidence to pre-review (scripts/signoff/checks/: consistency X1, score S5,
 * bioage B1, personas Q1, and helpers of evidence, limits, preanalytical and population), on small fixtures.
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { afterAll, describe, expect, it } from "vitest";
import { scanMarker, v3Contribution, moduleBa, plausibilityBounds } from "../../../scripts/signoff/checks/consistency";
import { penaltyShape, optimalPanel, doubleCounted, mulberry32, type SeedReviewedRow } from "../../../scripts/signoff/checks/score";
import { checks as bioChecks, GAP_PROBES, readArtifactLock, lockFailures, LOCKED_FILE_SHA256, LOCKED_MODEL_SHA256, probe, probeOutcome } from "../../../scripts/signoff/checks/bioage";
import { makeCtx } from "../../../scripts/signoff/lib/runner";
import { loadPersonas, runPersona } from "../../../scripts/signoff/checks/personas";
import { criticalFromReference, criticalEntryProblems } from "../../../scripts/signoff/checks/limits";
import { appBoundedZone, boundedWiring, checks as preanalyticalChecks, rcvPct } from "../../../scripts/signoff/checks/preanalytical";
import { checks as evidenceChecks, lockedDiffs, loopRowKey, narrowedSides, numberScope, rowSplits, scopedSupports, splitCount, splitsWithoutRecord, type EvidenceRecord, type LoopRow } from "../../../scripts/signoff/checks/evidence";
import { cdf, sharesFor } from "../../../scripts/signoff/checks/population";
import { calculateLongevityScoreV2, reviewedPenalty } from "../biomarkers/longevity-score";
import { loadSeed } from "../../../scripts/signoff/lib/seed";
import { signedRows } from "../biomarkers/__tests__/fixtures/reviewed-rows";

// Every temporary folder these tests create, and the compile and runner calls they make, lives under one root that
// is removed after this file's tests: os.tmpdir() reads TMPDIR on each call, and spawned processes inherit it.
// Before this, every run left its fixtures in the system's temporary folder (about 100 MB a run).
const TMP_ROOT = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-checks-test-"));
const TMPDIR_BEFORE = process.env.TMPDIR;
process.env.TMPDIR = TMP_ROOT;
afterAll(() => {
  if (TMPDIR_BEFORE === undefined) delete process.env.TMPDIR;
  else process.env.TMPDIR = TMPDIR_BEFORE;
  fs.rmSync(TMP_ROOT, { recursive: true, force: true });
});

const ROOT = path.resolve(__dirname, "../../..");

const row = (key: string, nl: number | null, nh: number | null, ol: number | null, oh: number | null, sex = "both"): SeedReviewedRow => ({
  biomarker_key: key,
  sex,
  age_group_en: "All Adults",
  normal_low: nl,
  normal_high: nh,
  optimal_low: ol,
  optimal_high: oh,
  critical_low: null,
  critical_high: null,
  unit: "",
});

describe("X1 consistency scan", () => {
  it("flags albumin above an optimal ceiling of 48 g/L: biological age lower at 49 g/L than at 48", () => {
    const albumin = row("albumin", 35, 52, 42, 48);
    for (const tier of ["base", "plus_hba1c"] as const) {
      for (const sex of ["male", "female"] as const) {
        const segs = scanMarker(tier, sex, "albumin", albumin, 15, 60, { points: 400, tolerance: 0.05 });
        const high = segs.find((s) => s.side === "high" && s.kind === "lower_than_bound");
        expect(high).toBeDefined();
        expect(high!.from).toBeLessThanOrEqual(49);
        expect(high!.to).toBeGreaterThanOrEqual(49);
        // At 49 the module itself gives a lower biological age than at 48.
        expect(moduleBa(tier, sex, "albumin", 49)!).toBeLessThan(moduleBa(tier, sex, "albumin", 48)! - 0.05);
      }
    }
  });

  it("does not flag albumin when the optimal ceiling is the model's clamp (50 g/L)", () => {
    const segs = scanMarker("base", "male", "albumin", row("albumin", 35, 52, 42, 50), 15, 60);
    expect(segs.filter((s) => s.kind !== "flat")).toEqual([]);
    // Above 50 the biological age is flat while the score penalty rises: a flat segment (X2).
    expect(segs.some((s) => s.kind === "flat" && s.side === "high")).toBe(true);
  });

  it("flags GGT below an optimal floor of 5 U/L", () => {
    const segs = scanMarker("base", "female", "ggt", row("ggt", 0, 38, 5, 20, "female"), 3, 1000);
    const low = segs.find((s) => s.side === "low" && s.kind === "lower_than_bound");
    expect(low).toBeDefined();
    expect(low!.from).toBeCloseTo(3, 6);
    expect(low!.to).toBeLessThan(5);
  });

  it("contribution differences equal the module's biological-age differences", () => {
    for (const x of [20, 40, 47, 52]) {
      const d = moduleBa("base", "male", "albumin", x)! - moduleBa("base", "male", "albumin", 44)!;
      expect(d).toBeCloseTo(v3Contribution("base", "male", "albumin", x) - v3Contribution("base", "male", "albumin", 44), 9);
    }
  });

  it("reads plausibility bounds in EVA units (albumin g/dL -> g/L)", () => {
    const b = plausibilityBounds(ROOT)!;
    expect(b.albumin).toEqual([15, 60]);
    expect(b.ggt).toEqual([3, 1000]);
  });
});

describe("S5 score properties", () => {
  it("penalty is zero inside optimal and never decreases away from it on 200 points", () => {
    const rows = [row("albumin", 35, 48, 42, 48), row("hs_crp", 0, 3, null, 0.5), row("vitamin_d_25_oh", 30, 100, 30, 50), row("egfr_creatinine_based", 60, null, 90, null), row("alt", 0, 41, 7, 30)];
    for (const r of rows) expect(penaltyShape(r, 200)).toEqual([]);
    expect(reviewedPenalty(45, rows[0])).toBe(0);
    expect(reviewedPenalty(40, rows[0])).toBeGreaterThan(0);
  });

  it("scores 100 when every scored marker is optimal on the rows the score runs on", () => {
    // The seed with the families' decided rows for the scoring markers: a marker scores only through a graded band.
    const rows = signedRows().map((r) => ({ ...row(r.biomarker_key, r.normal_low, r.normal_high, r.optimal_low, r.optimal_high, r.sex), age_group_en: r.age_group_en }));
    for (const sex of ["female", "male"] as const) {
      const panel = optimalPanel(rows, sex, 45);
      expect(panel.length).toBe(17); // one value per code of the specification
      const r = calculateLongevityScoreV2(panel, sex, 45, rows);
      expect(r.markersScored).toBe(sex === "male" ? 12 : 11);
      expect(r.longevityScore).toBe(100);
    }
    // On the seed as it stands, before the sign-off compile, too few graded bands exist for a score.
    const seed = loadSeed(path.join(ROOT, "supabase/seed-data"))!;
    const today = seed.rows.map((r) => ({ ...row(r.biomarker_key, r.normal_low, r.normal_high, r.optimal_low, r.optimal_high, r.sex), age_group_en: r.age_group_en }));
    expect(calculateLongevityScoreV2(optimalPanel(today, "female", 45), "female", 45, today).markersScored).toBeLessThan(12);
  });

  it("lists acceptance-test redundancy groups scored twice", () => {
    expect(doubleCounted(["ast", "alt", "apolipoprotein_b_apob"])).toEqual([{ group: "liver_enzymes", members: ["ast", "alt"] }]);
  });

  it("random panels are reproducible", () => {
    const a = mulberry32(7);
    const b = mulberry32(7);
    expect([a(), a(), a()]).toEqual([b(), b(), b()]);
  });
});

describe("B1 artifact lock", () => {
  it("matches the locked hashes and holds two sealed runs", () => {
    const lock = readArtifactLock(ROOT);
    expect(lock.file_sha256).toBe(LOCKED_FILE_SHA256);
    expect(lock.model_sha256).toBe(LOCKED_MODEL_SHA256);
    expect(lock.ts_source_file_sha256).toBe(LOCKED_FILE_SHA256);
    expect(lock.ts_source_model_sha256).toBe(LOCKED_MODEL_SHA256);
    expect(lock.runs_started).toEqual([1, 2]);
    expect(lockFailures(lock)).toEqual([]);
  });

  it("reports a changed hash", () => {
    const lock = { ...readArtifactLock(ROOT), file_sha256: "0".repeat(64) };
    expect(lockFailures(lock).map((f) => f.key)).toEqual(["model-v3.json|file_sha256"]);
  });
});

describe("B2 probes", () => {
  it("pregnancy and lactation are refused; a venous Echevarne draw without them is not", () => {
    expect(probe({ conditionKeys: ["pregnancy_current"] }).reason).toBe("pregnancy");
    expect(probe({ conditionKeys: ["lactating"], collection_method: "venous" }).reason).toBe("lactation");
    expect(probe({ collection_method: "venous" }).ba).not.toBeNull();
  });

  it("each probe declares a venous draw unless the collection method is its rule, and gives its own rule's outcome", () => {
    for (const p of GAP_PROBES) {
      const rec = probe(p.input);
      expect({ id: p.id, ...probeOutcome(rec, p.expect, p.reason) }).toMatchObject({ id: p.id, ok: true });
      if (p.id === "capillary") {
        expect(rec.reason).toBe("collection_method");
        continue;
      }
      expect(p.input.collection_method).toBe("venous");
      expect(rec.reasons.map((r) => r.code)).not.toContain("collection_method");
      if (p.expect === "refuse") expect(rec.reason).toBe(p.reason);
    }
    // hs-CRP 30 mg/L gives a provisional figure (B2: "hs-CRP 10 to 50 mg/L provisional").
    expect(probe(GAP_PROBES.find((p) => p.id === "hs_crp_30")!.input)).toMatchObject({ provisional: true, reason: null });
  });

  it("does not count a refusal for another reason: without the venous draw the numeric probes are refused for the collection method, and fail", () => {
    for (const id of ["albumin_0", "albumin_4_3", "creatinine_2_0", "hs_crp_60", "hs_crp_30", "unit_mismatch", "age_82", "pregnancy", "lactation", "sex_missing"]) {
      const p = GAP_PROBES.find((x) => x.id === id)!;
      const noMethod = { ...p.input, collection_method: undefined };
      const rec = probe(noMethod);
      expect(rec.reasons.map((r) => r.code)).toContain("collection_method");
      // A probe whose own rule comes before the collection method in the rules' order is still refused for it first.
      const ownFirst = ["age_82", "pregnancy", "lactation", "sex_missing"].includes(id);
      expect({ id, ok: probeOutcome(rec, p.expect, p.reason).ok }).toEqual({ id, ok: ownFirst });
    }
    // A refusal is not a provisional figure, and a figure is not a refusal.
    expect(probeOutcome(probe({ values: { hs_crp: 30 } }), "provisional").ok).toBe(false);
    expect(probeOutcome(probe({ values: { albumin: 0 }, collection_method: "venous" }), "refuse", "kidney").ok).toBe(false);
    expect(probeOutcome(probe({ collection_method: "venous" }), "refuse", "implausible_value").ok).toBe(false);
  });

  it("B5's fallback probe of age 80 declares a venous draw and must be refused for its age", async () => {
    const work = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-b5-"));
    fs.mkdirSync(path.join(work, "v3"));
    // Ages 80 to 84 whose criteria fail: the signed range must be 20 to 79, and the module must refuse 80 for its age.
    const write = (signed: number[]) => fs.writeFileSync(path.join(work, "v3", "ages-80-84.json"), JSON.stringify({ band_mean_diff_years: { male: 3, female: 3 }, hr_per_sd_lower95: 0.9, deaths: 50, validation_only: true, signed_range: signed }));
    const b5 = bioChecks.find((c) => c.id === "B5")!;
    const ctx = makeCtx({ root: ROOT, workDir: work, thresholds: {} });
    write([20, 79]);
    expect((await b5.run(ctx)).status).toBe("pass");
    write([20, 84]);
    const r = await b5.run(ctx);
    expect(r.status).toBe("fail");
    expect(r.failures.find((f) => f.key === "fallback")!.detail).toMatch(/\(module refuses 80 for its age: true, reason age_outside_signed_range\)$/);
    // The record the fallback reads: the age rule alone holds on a venous draw.
    expect(probe({ age: 80, collection_method: "venous" }).reasons.map((x) => x.code)).toEqual(["age_outside_signed_range"]);
    // Without the venous draw any age is refused, for the collection method, so "no figure at 80" would not show the
    // age rule: at 79, inside the signed range, the draw without a method gets no figure and the venous draw gets one.
    expect(probe({ age: 79 }).reason).toBe("collection_method");
    expect(probe({ age: 79, collection_method: "venous" }).ba).not.toBeNull();
  });
});

describe("Q1 personas fixture", () => {
  const personas = loadPersonas(ROOT)!;

  it("holds at least 40 personas with the groups the acceptance test lists", () => {
    expect(personas.length).toBeGreaterThanOrEqual(40);
    const ids = new Set(personas.map((p) => p.id));
    for (const id of ["pregnancy_t1", "pregnancy_t2", "pregnancy_t3", "lactation", "perimenopause", "postmenopause_oral_ht", "postmenopause_transdermal_ht", "oral_contraception", "duffy_null", "gilbert", "thalassaemia_trait", "endurance_athlete_male", "vegetarian_female", "statin_male", "levothyroxine", "ckd_g3a", "acute_infection", "creatine_user"])
      expect(ids.has(id)).toBe(true);
    for (const sex of ["male", "female"]) for (const age of [25, 35, 45, 55, 65, 75, 85]) expect(ids.has(`healthy_${sex}_${age}`)).toBe(true);
    for (const p of personas) {
      expect(p.note.length).toBeGreaterThan(10);
      expect(p.state.physiological_state).toBeTruthy();
      expect(typeof p.context.fasting).toBe("boolean");
      expect(Object.keys(p.values).length).toBeGreaterThan(20);
    }
    expect(personas.find((p) => p.id === "acute_infection")!.values.hs_crp).toBe(40);
  });

  it("runs a persona through picker, classifier, score and version 3", () => {
    const seed = loadSeed(path.join(ROOT, "supabase/seed-data"))!;
    const run = runPersona(personas.find((p) => p.id === "healthy_male_45")!, seed.rows);
    expect(run.score).not.toBeNull();
    expect(run.ba).not.toBeNull();
    expect(Object.keys(run.zones).length).toBeGreaterThan(20);
    const preg = runPersona(personas.find((p) => p.id === "pregnancy_t2")!, seed.rows);
    expect(preg.ba).toBeNull();
  });
});

describe("helpers", () => {
  it("L1 finds critical codes derived from reference limits", () => {
    const src = 'if (normalLow != null && value < normalLow) return "critical_low";\nif (x) return "optimal";';
    expect(criticalFromReference(src)).toEqual([{ line: 1, text: 'if (normalLow != null && value < normalLow) return "critical_low";' }]);
    expect(criticalEntryProblems({ none_because: "none, because no panic value exists", sources: [{ id: "x" }], alternatives: [] })).toEqual([]);
  });

  it("P3 classifies a bounded result with the app's own rule (bounded-result.ts)", () => {
    const row = { normal_low: 0, normal_high: 10, optimal_low: null, optimal_high: 3 };
    // "<5" may be optimal (up to 3) or above optimal, so it cannot be placed; "<2" can only be optimal.
    expect(appBoundedZone("<5", row)).toEqual({ value: 5, comparator: "<", zone: "unclassified" });
    expect(appBoundedZone("<2", row)).toEqual({ value: 2, comparator: "<", zone: "optimal" });
    // ">12" is above the range whatever its true value; a plain value is placed as classifyZone places it.
    expect(appBoundedZone(">12", row)).toEqual({ value: 12, comparator: ">", zone: "critical_high" });
    expect(appBoundedZone("5", row)).toEqual({ value: 5, comparator: null, zone: "above_optimal" });
    expect(rcvPct({ cvi_pct: 5, cva_pct: 3 })).toBeCloseTo(1.96 * Math.SQRT2 * Math.sqrt(34), 9);
  });

  it("P3 names every app path that classifies a stored or reported result without its comparator, with no exempt path (decision CEO-15)", async () => {
    // Today's app: every path carries the comparator: the pipeline, the edit and reprocess routes, the webhook and the
    // lab bridge, the upload (its preview and confirm routes) and the administrator's manual entry (known issue C-06).
    // P3 is then left blocked on Echevarne's lowest reportable values only.
    expect(boundedWiring(ROOT)).toEqual([]);
    const p3 = await preanalyticalChecks.find((c) => c.id === "P3")!.run(makeCtx({ root: ROOT, seedDir: path.join(ROOT, "supabase/seed-data"), thresholds: {} }));
    expect(p3.status).toBe("blocked");
    expect(p3.failures).toEqual([]);
    expect(p3.blocked_on).toBe("docs/signoff/work/echevarne/reportable-range.json");
    expect(p3.metrics).toMatchObject({ bounded_violations: 0, bounded_wiring_violations: 0, loq_table_present: false });
    expect(p3.summary).toMatch(/^bounded-result rule holds on \d+ fixtures; blocked: docs\/signoff\/work\/echevarne\/reportable-range\.json /);
    // A root with each kind of path.
    const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-p3-wiring-"));
    const put = (file: string, text: string) => {
      fs.mkdirSync(path.dirname(path.join(root, file)), { recursive: true });
      fs.writeFileSync(path.join(root, file), text);
    };
    // No pipeline at all.
    expect(boundedWiring(root).map((w) => `${w.file} ${w.rule}`)).toEqual(["src/lib/biomarkers/process-results.ts missing"]);
    put("src/lib/biomarkers/process-results.ts", "const zone = classifyResultZone(effectiveValue, raw.comparator, a, b, c, d);\nexport async function processLabResults() {}");
    // An edit route that classifies the number alone; a reprocess route that reads stored values without their
    // comparator and passes none; a webhook that drops the provider's comparator; an upload preview that classifies
    // the number; a helper outside the routes that hands results on without one; a lab bridge that deletes stored values
    // and passes the comparator; a test file.
    put("src/app/api/values/[id]/route.ts", "const zone = classifyZone(conv.value, o1, o2, n1, n2);");
    put("src/app/api/reprocess/route.ts", 'const { data } = await s.from("biomarker_values")\n  .select("id, biomarker_key, value, unit");\nawait processLabResults(u, id, data.map((v) => ({ name: v.biomarker_key, value: v.value, unit: v.unit })));');
    put("src/app/api/webhook/route.ts", "await processLabResults(u, id, list.map((b) => ({ name: b.key, value: b.value, unit: b.unit })));");
    put("src/app/api/lab-results/extract/route.ts", "const zone = classifyZone(effectiveValue, o1, o2, n1, n2);");
    put("src/lib/imports/batch.ts", "await processLabResults(u, id, rows);");
    put("src/lib/lab-bridge/store.ts", 'await s.from("biomarker_values").delete().eq("lab_result_id", id);\nawait processLabResults(u, id, list.map((b) => ({ name: b.key, value: b.value, unit: b.unit, ...(b.comparator ? { comparator: b.comparator } : {}) })));');
    put("src/app/api/values/[id]/route.test.ts", "const zone = classifyZone(1, 2, 3, 4, 5);");
    expect(boundedWiring(root).map((w) => `${w.file} ${w.rule}`)).toEqual([
      "src/app/api/lab-results/extract/route.ts classifyZone",
      "src/app/api/reprocess/route.ts processLabResults",
      "src/app/api/reprocess/route.ts select",
      "src/app/api/values/[id]/route.ts classifyZone",
      "src/app/api/webhook/route.ts processLabResults",
      "src/lib/imports/batch.ts processLabResults",
    ]);
    // Repaired: the reprocess route selects the comparator and passes it, the edit route classifies with it, the
    // webhook and the helper pass it on, the preview classifies with it; a read of every column ("*") holds it.
    put("src/app/api/reprocess/route.ts", 'const { data } = await s.from("biomarker_values")\n  .select("id, biomarker_key, value, unit, comparator");\nawait processLabResults(u, id, data.map((v) => ({ name: v.biomarker_key, value: v.value, unit: v.unit, comparator: v.comparator })));');
    put("src/app/api/values/[id]/route.ts", 'const { data: row } = await s.from("biomarker_values").select("*").eq("id", id).single();\nconst zone = classifyResultZone(conv.value, row.comparator, o1, o2, n1, n2);');
    put("src/app/api/webhook/route.ts", "await processLabResults(u, id, list.map((b) => ({ name: b.key, value: b.value, unit: b.unit, comparator: b.comparator })));");
    put("src/app/api/lab-results/extract/route.ts", "const zone = classifyResultZone(effectiveValue, raw.comparator, o1, o2, n1, n2);");
    put("src/lib/imports/batch.ts", "await processLabResults(u, id, rows.map((r) => ({ ...r, comparator: r.comparator })));");
    expect(boundedWiring(root)).toEqual([]);
    // The pipeline that classifies with the classifier without a comparator fails twice.
    put("src/lib/biomarkers/process-results.ts", "const zone = classifyZone(effectiveValue, a, b, c, d);");
    expect(boundedWiring(root).map((w) => `${w.file} ${w.rule}`)).toEqual(["src/lib/biomarkers/process-results.ts classifyResultZone", "src/lib/biomarkers/process-results.ts classifyZone"]);
  });

  it("E6 sees no change on today's seed and E3 finds narrowed sides", () => {
    const seed = loadSeed(path.join(ROOT, "supabase/seed-data"))!;
    expect(lockedDiffs(seed.rows)).toEqual([]);
    expect(narrowedSides({ marker_key: "x", sex: "both", age_group: "All Adults", physiological_state: "none", reference_low: 35, reference_high: 50, optimal_low: 40, optimal_high: 50 })).toEqual(["low"]);
  });

  it("N1 interpolates shares from percentiles", () => {
    const q: [number, number][] = [[0.01, 1], [0.5, 5], [0.99, 9]];
    expect(cdf(q, 5)).toBeCloseTo(0.5, 9);
    expect(cdf(q, 0)).toBe(0);
    expect(cdf(q, 10)).toBe(1);
    const s = sharesFor(q, row("m", 2, 8, 4, 6));
    expect(s.below_normal).toBeCloseTo(0.01 + 0.49 * 0.25, 9);
    expect(s.optimal).toBeCloseTo(0.49 * 0.5, 9);
  });
});

describe("E1 asks the number of the records its specification names", () => {
  const row = (over: Partial<LoopRow>): LoopRow => ({ marker_key: "x", sex: "both", age_group: "All Adults", physiological_state: "none", reference_low: 1, reference_high: 5, reference_basis: "echevarne_interval", optimal_low: 2, optimal_high: null, ...over });
  const record = (id: string, supports: [string, string][], quote = "The marker was measured in every participant."): EvidenceRecord => ({ id, supports: supports.map(([row_key, bound]) => ({ row_key, bound })), quote });
  const X = "x|both|All Adults|none";
  const Y = "y|both|All Adults|none";
  const Z = "z|female|All Adults|pregnancy";

  it("scopes the number to an optimal bound a row has, a reference bound a row has on a non-laboratory basis, and a split the row has, through the records' supports[] links", () => {
    // x: an optimal floor and a laboratory interval; y: a decision limit as its upper reference bound; z, only in the
    // fixer's final rows: a pregnancy row with an optimal ceiling. x and y, both sexes for all adults with no state,
    // are not split; z is split by state.
    const scope = numberScope({ research: { rows: [row({}), row({ marker_key: "y", reference_basis: "decision_limit", reference_low: null, optimal_low: null })] }, verify: null, decision: { final_rows: [row({ marker_key: "z", sex: "female", physiological_state: "pregnancy", optimal_low: null, optimal_high: 4 })] } });
    expect([...scope].sort()).toEqual([`${X}#optimal_low`, `${Y}#reference_high`, `${Z}#optimal_high`, `${Z}#state_split`]);
    expect(scopedSupports(record("E1", [[X, "pre_analytical"], [X, "optimal_low"], [Y, "reference_low"]]), scope)).toEqual([`${X} optimal_low`]);
    expect(scopedSupports(record("E2", [[X, "reference_low"], [X, "class"], [X, "method"], [X, "critical_low"], [X, "action_limit"], [X, "rcv"], [X, "optimal_high"]]), scope)).toEqual([]);
    expect(scopedSupports({ id: "E3" }, scope)).toEqual([]);
    // A split link counts only on a row split that way: x is not split; z is split by state, not by age or sex.
    expect(scopedSupports(record("E4", [[X, "age_split"], [X, "sex_split"], [X, "state_split"], [Z, "age_split"], [Z, "sex_split"]]), scope)).toEqual([]);
    expect(scopedSupports(record("E5", [[Z, "state_split"]]), scope)).toEqual([`${Z} state_split`]);
  });

  it("through the check: fails a record in scope whose quote holds no number, passes one outside it, and keeps the 60-word rule and validation for every record", async () => {
    const work = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-e1-"));
    fs.writeFileSync(path.join(work, "families.json"), JSON.stringify({ families: { f99_x: { keys: ["x", "y", "z"] } } }));
    const long = Array.from({ length: 61 }, () => "word").join(" ");
    const evidence = [
      record("E-OPT", [[X, "optimal_low"]]),
      record("E-NUM", [[X, "optimal_low"]], "Mortality was lowest at 42 g/L."),
      record("E-REF-DL", [[Y, "reference_high"]]),
      record("E-REF-LAB", [[X, "reference_low"]]),
      record("E-SPLIT", [[X, "age_split"]]),
      record("E-MIX", [[X, "pre_analytical"], [X, "optimal_low"]]),
      record("E-PRE", [[X, "pre_analytical"]]),
      record("E-CLASS", [[X, "class"]]),
      record("E-METHOD", [[X, "method"]]),
      record("E-CRIT", [[X, "critical_low"]]),
      record("E-ACTION", [[X, "action_limit"]]),
      record("E-RCV", [[X, "rcv"]]),
      record("E-NOBOUND", [[X, "optimal_high"]]),
      record("E-LONG", [[X, "method"]], long),
    ];
    for (const [dir, doc] of [
      ["research", { family: "f99_x", rows: [row({}), row({ marker_key: "y", reference_basis: "decision_limit", reference_low: null, optimal_low: null })], evidence }],
      ["decisions", { family: "f99_x", final_rows: [row({ marker_key: "z", sex: "female", physiological_state: "pregnancy", optimal_low: null, optimal_high: 4 })], evidence: [record("E-DEC", [[Z, "optimal_high"]])] }],
    ] as const) {
      fs.mkdirSync(path.join(work, dir), { recursive: true });
      fs.writeFileSync(path.join(work, dir, "f99_x.json"), JSON.stringify(doc));
    }
    const r = await evidenceChecks.find((c) => c.id === "E1")!.run(makeCtx({ root: ROOT, workDir: work, thresholds: {} }));
    expect(r.status).toBe("fail");
    // The fixture files are not schema-valid: those failures stay, keyed by file kind.
    expect(r.failures.some((f) => f.key.startsWith("f99_x|research|"))).toBe(true);
    const evidenceFailures = r.failures.filter((f) => f.key.includes("|evidence|"));
    // E-SPLIT's only link is an age split of x, which is not split: outside the rule (line 39 names splits).
    expect(evidenceFailures.map((f) => f.key)).toEqual(["f99_x|evidence|E-DEC|number", "f99_x|evidence|E-LONG", "f99_x|evidence|E-MIX|number", "f99_x|evidence|E-OPT|number", "f99_x|evidence|E-REF-DL|number"]);
    expect(evidenceFailures.find((f) => f.key === "f99_x|evidence|E-MIX|number")!.detail).toBe(`quote contains no number; the record supports ${X} optimal_low, which E1 asks a quote containing the number for`);
    expect(evidenceFailures.find((f) => f.key === "f99_x|evidence|E-LONG")!.detail).toBe("quote has 61 words (max 60)");
    // z, the fixer's pregnancy row, is split by state and no record is linked to it as state_split.
    expect(r.failures.filter((f) => f.key.endsWith("_split"))).toEqual([
      { key: `f99_x|decision|${Z}|state_split`, detail: `split by state (its physiological_state is pregnancy) without a record: none of the research, verify and decision files' records has a supports[] link {row_key: "${Z}", bound: "state_split"}, and E1 asks a record of every age, sex or state split` },
    ]);
    expect(r.metrics).toMatchObject({
      evidence_records: 15,
      number_scope_records: 5,
      outside_scope_without_number: 10,
      outside_scope_without_number_ids: "f99_x|E-ACTION,f99_x|E-CLASS,f99_x|E-CRIT,f99_x|E-LONG,f99_x|E-METHOD,f99_x|E-NOBOUND,f99_x|E-PRE,f99_x|E-RCV,f99_x|E-REF-LAB,f99_x|E-SPLIT",
      splits: 1,
      splits_without_record: 1,
    });
  });

  it("finds the age, sex and state splits of a file's rows: another age band in the marker, sex and state; the other sex in the marker and state; a state other than none", () => {
    const r = (marker_key: string, sex: string, age_group: string, physiological_state = "none") => row({ marker_key, sex, age_group, physiological_state });
    const rows = [
      r("egfr", "both", "18-39"),
      r("egfr", "both", "40+"),
      r("creatinine", "male", "All Adults"),
      r("creatinine", "female", "All Adults"),
      r("creatinine", "female", "All Adults", "pregnancy"),
      r("psa", "male", "All Adults"),
      r("albumin", "both", "All Adults"),
      r("ferritin", "female", "18-49"),
      r("ferritin", "female", "50+"),
      r("ferritin", "male", "All Adults"),
    ];
    expect(rowSplits(rows).map((s) => `${s.key} ${s.split}`)).toEqual([
      "egfr|both|18-39|none age_split",
      "egfr|both|40+|none age_split",
      "creatinine|male|All Adults|none sex_split",
      "creatinine|female|All Adults|none sex_split",
      // The pregnancy row is split by state only: no male row of creatinine is in that state.
      "creatinine|female|All Adults|pregnancy state_split",
      "ferritin|female|18-49|none age_split",
      "ferritin|female|18-49|none sex_split",
      "ferritin|female|50+|none age_split",
      "ferritin|female|50+|none sex_split",
      "ferritin|male|All Adults|none sex_split",
    ]);
    expect(rowSplits(rows)[0].why).toBe("the file's egfr|both|none rows have another age band (40+)");
    // PSA has male rows only and albumin one row for both sexes: neither is split. Splits are a file's own: a row is
    // not split by the bands of another file.
    expect(rowSplits([r("egfr", "both", "All Adults")])).toEqual([]);
    expect(rowSplits(null)).toEqual([]);
    // Each file's splits are counted; the same row in two files is two splits.
    expect(splitCount({ research: { rows: rows.slice(0, 2) }, verify: { final_rows: rows.slice(0, 2) }, decision: null })).toBe(4);
  });

  it("holds every split of each file to a record linked to it under the split's name, from the records validate.js gives that file, and asks the number only of the records linked to a split row under its split's name", async () => {
    const F = "egfr|both|18-39|none";
    const G = "egfr|both|40+|none";
    const P = "albumin|female|All Adults|pregnancy";
    const A = "albumin|both|All Adults|none";
    const split = (marker_key: string, age_group: string, sex = "both", physiological_state = "none") => row({ marker_key, sex, age_group, physiological_state, optimal_low: null, reference_basis: "echevarne_interval" });
    const rows = [split("egfr", "18-39"), split("egfr", "40+"), split("albumin", "All Adults", "female", "pregnancy"), split("albumin", "All Adults")];
    const files = (research: EvidenceRecord[], verify: EvidenceRecord[] = []) => ({ research: { rows, evidence: research }, verify: { final_rows: rows, evidence: verify }, decision: null });
    const missing = (f: ReturnType<typeof files>) => splitsWithoutRecord(f).map((m) => `${m.kind} ${m.split.key} ${m.split.split}`);
    const numbered = (id: string, supports: [string, string][]) => record(id, supports, "Values were 12% lower in the third trimester.");
    // Every split with a record under its name: nothing missing.
    expect(missing(files([numbered("E-AGE", [[F, "age_split"], [G, "age_split"]]), numbered("E-STATE", [[P, "state_split"]])]))).toEqual([]);
    // A split whose only record is linked under another name, and a split with no record, are missing in both files.
    expect(missing(files([numbered("E-AGE", [[F, "age_split"], [G, "age_split"]]), numbered("E-PRE", [[P, "pre_analytical"]])]))).toEqual([`research ${P} state_split`, `verify ${P} state_split`]);
    expect(missing(files([numbered("E-AGE", [[F, "age_split"]])]))).toEqual([`research ${G} age_split`, `research ${P} state_split`, `verify ${G} age_split`, `verify ${P} state_split`]);
    // A record the verifier adds counts for its final rows, not for the research rows (as validate.js gives checkBoundCoverage).
    expect(missing(files([numbered("E-AGE", [[F, "age_split"], [G, "age_split"]])], [numbered("V-STATE", [[P, "state_split"]])]))).toEqual([`research ${P} state_split`]);
    // Through the check, on files validate.js accepts in shape: a split record on a split row without a number fails;
    // an age_split link without a number on a row that is not split (albumin for all adults) passes.
    const work = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-e1-splits-"));
    fs.writeFileSync(path.join(work, "families.json"), JSON.stringify({ families: { f99_x: { keys: ["egfr", "albumin"] } } }));
    fs.mkdirSync(path.join(work, "research"));
    const write = (evidence: EvidenceRecord[]) => fs.writeFileSync(path.join(work, "research", "f99_x.json"), JSON.stringify({ family: "f99_x", rows, evidence }));
    const e1 = async () => {
      const r = await evidenceChecks.find((c) => c.id === "E1")!.run(makeCtx({ root: ROOT, workDir: work, thresholds: {} }));
      return r.failures.filter((f) => f.key.includes("|evidence|") || f.key.endsWith("_split")).map((f) => f.key);
    };
    write([numbered("E-AGE", [[F, "age_split"], [G, "age_split"]]), record("E-STATE", [[P, "state_split"]]), record("E-NOT-SPLIT", [[A, "age_split"]])]);
    expect(await e1()).toEqual(["f99_x|evidence|E-STATE|number"]);
    // The same record relinked under pre_analytical leaves the pregnancy row without a split record: E1 still fails.
    write([numbered("E-AGE", [[F, "age_split"], [G, "age_split"]]), record("E-STATE", [[P, "pre_analytical"]]), record("E-NOT-SPLIT", [[A, "age_split"]])]);
    expect(await e1()).toEqual([`f99_x|research|${P}|state_split`]);
    // With no record at all for the age split, both eGFR rows fail.
    write([numbered("E-STATE", [[P, "state_split"]])]);
    expect(await e1()).toEqual([`f99_x|research|${F}|age_split`, `f99_x|research|${G}|age_split`]);
  });

  it("splits by sex a male or female row in no state whose marker has rows of the other sex only in other states (the production layout of estradiol, FSH and LH), and holds it to a record with a number", async () => {
    const r = (marker_key: string, sex: string, physiological_state: string, age_group = "All Adults") => row({ marker_key, sex, age_group, physiological_state, optimal_low: null, reference_basis: "echevarne_interval" });
    // Men in no state; women only in cycle phases and after menopause.
    const rows = [r("estradiol", "male", "none"), r("estradiol", "female", "follicular"), r("estradiol", "female", "luteal"), r("estradiol", "female", "postmenopausal")];
    expect(rowSplits(rows).map((s) => `${s.key} ${s.split}`)).toEqual([
      "estradiol|male|All Adults|none sex_split",
      "estradiol|female|All Adults|follicular state_split",
      "estradiol|female|All Adults|luteal state_split",
      "estradiol|female|All Adults|postmenopausal state_split",
    ]);
    expect(rowSplits(rows)[0].why).toBe("the file has female rows of estradiol only in other states");
    // A state row keeps the same-state rule: a male row in no state does not split the women's state rows by sex, and a
    // both-sexes row is never split by sex.
    expect(rowSplits([r("psa", "male", "none"), r("psa", "both", "pregnancy")]).map((s) => s.split)).toEqual(["state_split"]);
    // Through the check: no record fails, a record without a number fails, a record with a number passes.
    const M = "estradiol|male|All Adults|none";
    const states = rows.slice(1).map((x) => [loopRowKey(x as LoopRow), "state_split"] as [string, string]);
    const work = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-e1-sex-states-"));
    fs.writeFileSync(path.join(work, "families.json"), JSON.stringify({ families: { f99_x: { keys: ["estradiol"] } } }));
    fs.mkdirSync(path.join(work, "research"));
    const write = (evidence: EvidenceRecord[]) => fs.writeFileSync(path.join(work, "research", "f99_x.json"), JSON.stringify({ family: "f99_x", rows, evidence }));
    const e1 = async () => {
      const res = await evidenceChecks.find((c) => c.id === "E1")!.run(makeCtx({ root: ROOT, workDir: work, thresholds: {} }));
      return res.failures.filter((f) => f.key.includes("|evidence|") || f.key.endsWith("_split")).map((f) => f.key);
    };
    const numberedStates = record("E-STATES", states, "Estradiol was 30 to 400 pg/mL across the cycle and below 30 pg/mL after menopause.");
    write([numberedStates]);
    expect(await e1()).toEqual([`f99_x|research|${M}|sex_split`]);
    write([numberedStates, record("E-MEN", [[M, "sex_split"]])]);
    expect(await e1()).toEqual(["f99_x|evidence|E-MEN|number"]);
    write([numberedStates, record("E-MEN", [[M, "sex_split"]], "In men, estradiol was 10 to 40 pg/mL.")]);
    expect(await e1()).toEqual([]);
  });

  /** docs/signoff/work as committed in `commit`, for the B01 families' research, verify and decisions files, or null when the clone lacks that commit. */
  function workAt(commit: string): string | null {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), `dsrt-e1-${commit}-`));
    for (const f of ["families.json", ...["decisions", "verify", "research"].flatMap((d) => ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"].map((fam) => `${d}/${fam}.json`))]) {
      let body: Buffer;
      try {
        body = execFileSync("git", ["show", `${commit}:docs/signoff/work/${f}`], { cwd: ROOT, stdio: ["ignore", "pipe", "ignore"], maxBuffer: 256 * 1024 * 1024 });
      } catch {
        return null;
      }
      fs.mkdirSync(path.dirname(path.join(dir, f)), { recursive: true });
      fs.writeFileSync(path.join(dir, f), body);
    }
    return dir;
  }
  // B01 before the evidence repair of 8 November (15f04bb, the round-4 decisions) and after it (cf7c4c8).
  const BEFORE = workAt("15f04bb");
  const AFTER = workAt("cf7c4c8");

  it.skipIf(!BEFORE || !AFTER)("on B01: the records E1 failed for a quote without a number that support only a class, method, pre-analytical rule or action limit now pass; those for a split or a decision limit still fail", async () => {
    const e1 = (work: string) => evidenceChecks.find((c) => c.id === "E1")!.run(makeCtx({ root: ROOT, workDir: work, families: ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"] }));
    const before = await e1(BEFORE!);
    expect(before.failures.map((f) => f.key)).toEqual(["f01_albumin_proteins|evidence|F01-E16|number", "f01_albumin_proteins|evidence|F01-E19|number"]);
    expect(before.metrics).toMatchObject({ outside_scope_without_number: 6, outside_scope_without_number_ids: "f01_albumin_proteins|F01-E24,f01_albumin_proteins|F01-E44,f01_albumin_proteins|F01-V01,f03_kidney|f03-D04,f03_kidney|f03-E36,f04_inflammation|f04-V01" });
    // After the repair: the six records the repair listed as outside the scope pass, and f04-E01, whose quote became
    // the title of a record without an abstract, supports the decision limit of hs-CRP: it fails.
    const after = await e1(AFTER!);
    expect(after.failures.map((f) => f.key)).toEqual(["f01_albumin_proteins|evidence|F01-E16|number", "f01_albumin_proteins|evidence|F01-E19|number", "f04_inflammation|evidence|f04-E01|number"]);
    expect(after.failures.find((f) => f.key.includes("f04-E01"))!.detail).toBe("quote contains no number; the record supports hs_crp|both|All Adults|none reference_high, which E1 asks a quote containing the number for");
    expect(after.metrics).toMatchObject({ outside_scope_without_number: 6, outside_scope_without_number_ids: "f01_albumin_proteins|F01-E24,f03_kidney|f03-D04,f03_kidney|f03-E36,f04_inflammation|f04-E03,f04_inflammation|f04-E04,f04_inflammation|f04-V01" });
    // Every split of every B01 file has a record linked under its name: 27 splits (f01 research and verify 4 state
    // splits each, f03 research, verify and decision 2 sex and 3 age splits each, f04 research and verify 2 state splits).
    for (const r of [before, after]) expect(r.metrics).toMatchObject({ splits: 27, splits_without_record: 0 });
  });

  it.skipIf(!BEFORE)("on B01 (15f04bb): a split left with no record under its name fails, whichever name its records are relinked under; relinking F01-E16 and F01-E19 alone leaves each state split a record holding a number", async () => {
    const e1 = async (work: string) => {
      const r = await evidenceChecks.find((c) => c.id === "E1")!.run(makeCtx({ root: ROOT, workDir: work, families: ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"] }));
      return r.failures.map((f) => f.key);
    };
    type Doc = { evidence: { id: string; quote: string; supports: { row_key: string; bound: string }[] }[] };
    /** A copy of the 15f04bb files with every link of `ids` (every record when null) under one of the names `from` relinked under `to`, in the files given. */
    const relinked = (files: string[], ids: string[] | null, from: string[], to: string) => {
      const work = fs.mkdtempSync(path.join(os.tmpdir(), "dsrt-e1-relink-"));
      fs.cpSync(BEFORE!, work, { recursive: true });
      for (const f of files) {
        const doc = JSON.parse(fs.readFileSync(path.join(work, f), "utf8")) as Doc;
        for (const e of doc.evidence ?? []) if (!ids || ids.includes(e.id)) for (const s of e.supports) if (from.includes(s.bound)) s.bound = to;
        fs.writeFileSync(path.join(work, f), JSON.stringify(doc, null, 2));
      }
      return work;
    };
    const F01 = "research/f01_albumin_proteins.json";
    const STATE_ROWS = ["albumin|female|All Adults|lactation", "albumin|female|All Adults|pregnancy", "total_protein|female|All Adults|lactation", "total_protein|female|All Adults|pregnancy"];
    // The review's copy: F01-E16 and F01-E19, whose quotes hold no number, relinked under pre_analytical as F01-E24 is
    // linked to the same rows. Each of the four state splits keeps a record linked as state_split whose quote holds a
    // number (albumin in pregnancy F01-E15 and F01-E17, total protein in pregnancy F01-E15, both in lactation F01-E18), so
    // every split has its record; F01-E16 and F01-E19 are then records for a pre-analytical rule, as F01-E24 is, which
    // line 39 does not name.
    const review = relinked([F01], ["F01-E16", "F01-E19"], ["state_split"], "pre_analytical");
    const doc = JSON.parse(fs.readFileSync(path.join(review, F01), "utf8")) as Doc;
    const records = (row: string) => doc.evidence.filter((e) => e.supports.some((s) => s.row_key === row && s.bound === "state_split")).map((e) => `${e.id}${/\d/.test(e.quote) ? "" : " (no number)"}`);
    expect(Object.fromEntries(STATE_ROWS.map((k) => [k, records(k)]))).toEqual({
      "albumin|female|All Adults|lactation": ["F01-E18"],
      "albumin|female|All Adults|pregnancy": ["F01-E15", "F01-E17"],
      "total_protein|female|All Adults|lactation": ["F01-E18"],
      "total_protein|female|All Adults|pregnancy": ["F01-E15"],
    });
    expect(await e1(review)).toEqual([]);
    // Every state_split link of the f01 research file relinked under pre_analytical: the four state rows of the
    // research and verify files are left with no record under their split's name.
    expect(await e1(relinked([F01], null, ["state_split"], "pre_analytical"))).toEqual(STATE_ROWS.flatMap((k) => [`f01_albumin_proteins|research|${k}|state_split`]).concat(STATE_ROWS.map((k) => `f01_albumin_proteins|verify|${k}|state_split`)));
    // f04-E14, the only record of hs-CRP in lactation, relinked under pre_analytical: that split fails in both files.
    expect(await e1(relinked(["research/f04_inflammation.json"], ["f04-E14"], ["state_split"], "pre_analytical"))).toEqual([
      "f01_albumin_proteins|evidence|F01-E16|number",
      "f01_albumin_proteins|evidence|F01-E19|number",
      "f04_inflammation|research|hs_crp|female|All Adults|lactation|state_split",
      "f04_inflammation|verify|hs_crp|female|All Adults|lactation|state_split",
    ]);
    // The review's nosplit copy: every split link of the nine files (70) relinked as method. Every split fails.
    const all = ["research", "verify", "decisions"].flatMap((d) => ["f01_albumin_proteins", "f03_kidney", "f04_inflammation"].map((f) => `${d}/${f}.json`));
    const nosplit = await e1(relinked(all, null, ["age_split", "sex_split", "state_split"], "method"));
    expect(nosplit).toHaveLength(27);
    expect(nosplit.every((k) => /\|(age|sex|state)_split$/.test(k))).toBe(true);
  }, 60_000);
});
