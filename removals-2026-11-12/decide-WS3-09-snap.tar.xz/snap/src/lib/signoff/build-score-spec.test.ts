/**
 * The generator of the score specification (scripts/score/build-score-spec.ts).
 *
 *  - Its output is what is on disk, byte for byte (what --check verifies).
 *  - Every scored code maps to a key whose marker-classes.json class is "a" with may_be_scored true, and has a
 *    weights.json entry whose grade is the verifier's.
 *  - The eligible rows are found, with the graded bounds, among the rows a compile of the decided families writes.
 *  - It fails closed: a row changed after the verdict waits, grades C and D do not score, and a row it would score
 *    with no decision on its place, or with a message saying it does not count, stops it.
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { afterAll, describe, expect, it } from "vitest";
import { generate, loadInputs, render, run, PATHS, type FamilyRow, type GeneratorInputs } from "../../../scripts/score/build-score-spec";
import { calculateLongevityScoreV2, rowEligibilityKey, SCORE_SPEC, type ScoreSpec } from "../biomarkers/longevity-score";
import { loadSeed } from "../../../scripts/signoff/lib/seed";
import { reviewedRows as seedRowsOf, optimalPanel } from "../../../scripts/signoff/checks/score";

const ROOT = path.resolve(__dirname, "../../..");
const INPUTS = loadInputs(ROOT);
const OUT = generate(INPUTS);
const readJson = (rel: string) => JSON.parse(fs.readFileSync(path.join(ROOT, rel), "utf8"));
const tmp: string[] = [];
afterAll(() => tmp.forEach((d) => fs.rmSync(d, { recursive: true, force: true })));

type Weights = {
  mapping: { weights: Record<string, number>; decision: string };
  markers: Record<string, { code: string; weight: number; grade: string; inversion_reason: string | null; rows: { row: string; grade: string | null; scores: boolean; status: string; reason: string }[] }>;
  not_scored: Record<string, { code: string | null; rows: { row: string; scores: boolean; reason: string }[] }>;
  waiting: { row: string; reason: string }[];
};
const WEIGHTS = OUT.weights as unknown as Weights;
const SPEC = OUT.scoreSpec as unknown as ScoreSpec;

/** The inputs with a change applied to a deep copy of the decided and verified rows. */
function inputsWith(change: (rows: { decided: FamilyRow[]; verified: FamilyRow[] }, family: string) => void): GeneratorInputs {
  const copy: GeneratorInputs = structuredClone(INPUTS);
  for (const f of copy.families) change({ decided: f.decided, verified: f.verified ?? [] }, f.family);
  return copy;
}
const find = (rows: FamilyRow[], key: string, sex: string) => rows.find((r) => r.marker_key === key && r.sex === sex && (r.physiological_state ?? "none") === "none");
const specOf = (inp: GeneratorInputs) => generate(inp).scoreSpec as unknown as ScoreSpec;

describe("the generated files", () => {
  it("are what the generator writes, byte for byte, and --check passes", () => {
    for (const [rel, text] of Object.entries(render(OUT))) expect(fs.readFileSync(path.join(ROOT, rel), "utf8") === text, rel).toBe(true);
    expect(run(ROOT, true)).toEqual([]);
    expect(SCORE_SPEC).toEqual(OUT.scoreSpec);
  });

  it("is deterministic: the same inputs give the same bytes, whatever the order the families are read in", () => {
    const again = render(generate({ ...loadInputs(ROOT), families: [...loadInputs(ROOT).families].reverse() }));
    expect(again).toEqual(render(OUT));
  });

  it("--check reports a file that differs and writes nothing", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "score-spec-"));
    tmp.push(dir);
    for (const rel of [PATHS.specInputs, PATHS.markerClasses, PATHS.specification, PATHS.scoreSpec, PATHS.weights]) {
      fs.mkdirSync(path.dirname(path.join(dir, rel)), { recursive: true });
      fs.copyFileSync(path.join(ROOT, rel), path.join(dir, rel));
    }
    for (const d of [PATHS.decisions, PATHS.verify]) fs.cpSync(path.join(ROOT, d), path.join(dir, d), { recursive: true });
    expect(run(dir, true)).toEqual([]);
    const weights = path.join(dir, PATHS.weights);
    const edited = fs.readFileSync(weights, "utf8").replace('"A": 3', '"A": 4');
    fs.writeFileSync(weights, edited);
    expect(run(dir, true)).toEqual([PATHS.weights]);
    expect(fs.readFileSync(weights, "utf8")).toBe(edited);
    expect(run(dir, false)).toEqual([PATHS.weights]); // a write repairs it
    expect(run(dir, true)).toEqual([]);
  });
});

describe("the scored set follows the classes, the verifier's grades and the mapping", () => {
  const classes = readJson(PATHS.markerClasses) as { markers: Record<string, { class: string; may_be_scored: boolean; redundancy_group?: string; priority_member?: boolean }>; groups: Record<string, { priority_order: string[] }> };

  it("every scored code maps to a class a key with may_be_scored true and a weights.json entry at the verifier's grade", () => {
    const scoring = Object.entries(SPEC.markers).filter(([, m]) => m.weight != null);
    expect(scoring.map(([code]) => code).sort()).toEqual(["ALBUMIN", "ALP", "ALT", "APOB", "GGT", "GLUCOSE", "HBA1C", "HDL_C", "HGB", "HSCRP", "LDL_C", "NON_HDL", "TG", "URIC_ACID", "VITD", "WBC"]);
    for (const [code, m] of scoring) {
      expect(classes.markers[m.key], code).toMatchObject({ class: "a", may_be_scored: true });
      const w = WEIGHTS.markers[m.key];
      expect(w, code).toMatchObject({ code, weight: m.weight, grade: m.grade, inversion_reason: null });
      expect(w.weight).toBe(WEIGHTS.mapping.weights[w.grade]);
      // The grade is the verifier's, row by row.
      for (const [key, entry] of Object.entries(m.rows).filter(([, e]) => e.eligible)) {
        const [sex, ageGroup] = key.split("|");
        const verified = INPUTS.families.flatMap((f) => f.verified ?? []).find((r) => r.marker_key === m.key && r.sex === sex && r.age_group === ageGroup && (r.physiological_state ?? "none") === "none")!;
        expect([verified.marker_class, verified.grade, verified.optimal_low ?? null, verified.optimal_high ?? null], `${code} ${key}`).toEqual(["a", entry.grade, entry.optimal_low, entry.optimal_high]);
        expect(["A", "B"]).toContain(entry.grade);
      }
    }
    // Only markers that score are in `markers`; no class b to e key is anywhere near the score.
    expect(Object.keys(WEIGHTS.markers).sort()).toEqual(scoring.map(([, m]) => m.key).sort());
    for (const [key, m] of Object.entries(classes.markers)) if (m.class !== "a") expect(m.may_be_scored, key).toBe(false);
    expect(Object.entries(classes.markers).filter(([, m]) => m.may_be_scored).map(([k]) => k).sort()).toEqual(Object.keys(WEIGHTS.markers).sort());
  });

  it("the mapping is A 3, B 2, C 1 under ruling D-07, and only apoB and LDL-C are grade A", () => {
    expect(WEIGHTS.mapping).toMatchObject({ decision: "D-07", weights: { A: 3, B: 2, C: 1 }, never_scores: ["D"], signed_grade_c: [] });
    expect(Object.entries(WEIGHTS.markers).filter(([, w]) => w.weight === 3).map(([k]) => k)).toEqual(["apolipoprotein_b_apob", "ldl_cholesterol"]);
    expect(Object.values(WEIGHTS.markers).every((w) => w.weight === 2 || w.weight === 3)).toBe(true);
  });

  it("weights.json lists every row of each marker with its grade and whether it scores, and the rows that wait", () => {
    expect(WEIGHTS.markers.alt.rows.map((r) => [r.row, r.grade, r.scores])).toEqual([["alt|male|All Adults|none", "B", true], ["alt|female|All Adults|none", "C", false]]);
    expect(WEIGHTS.markers.alp.rows.find((r) => r.row === "alp|male|18-18|none")).toMatchObject({ grade: "D", scores: false });
    expect(WEIGHTS.markers.hemoglobin.rows.filter((r) => !r.scores).map((r) => r.row)).toEqual(["hemoglobin|female|All Adults|pregnancy", "hemoglobin|female|All Adults|lactation"]);
    // Changed after the verdict (ruling D-30): the women's white cell floor and the eGFR ceiling at 18 to 39.
    const waiting = Object.fromEntries(WEIGHTS.waiting.map((w) => [w.row, w.reason]));
    expect(waiting["white_blood_cell_count|female|All Adults|none"]).toMatch(/optimal 4100 to 6000, verifier 3800 to 6000.*D-30/);
    expect(waiting["egfr_creatinine_based|both|18-39|none"]).toMatch(/optimal 90 to 110, verifier 90 to none.*D-30/);
    expect(waiting["egfr_creatinine_based|both|40-84|none"]).toMatch(/does not count toward the score/);
    expect(WEIGHTS.markers.white_blood_cell_count.rows.map((r) => r.scores)).toEqual([true, false]);
    // No kidney marker scores; total cholesterol, cystatin C and creatinine never do.
    expect(WEIGHTS.not_scored.egfr_creatinine_based.code).toBe("EGFR");
    for (const key of ["total_cholesterol", "cystatin_c", "creatinine", "homa_ir", "nlr", "bun", "urea", "fructosamine", "insulin_fasting", "ldl_particle_number"]) {
      expect(WEIGHTS.not_scored[key]?.rows.every((r) => !r.scores), key).toBe(true);
      expect(key in WEIGHTS.markers, key).toBe(false);
    }
    // Every decided class a row is listed once.
    const listed = [...Object.values(WEIGHTS.markers), ...Object.values(WEIGHTS.not_scored)].flatMap((m) => m.rows.map((r) => r.row));
    const classA = INPUTS.families.flatMap((f) => f.decided.filter((r) => r.marker_class === "a").map((r) => `${r.marker_key}|${r.sex}|${r.age_group}|${r.physiological_state ?? "none"}`));
    expect(new Set(listed).size).toBe(listed.length);
    expect(classA.filter((r) => !listed.includes(r))).toEqual([]);
  });

  it("marker-classes.json: class from the verifier, the groups and orders of ruling D-06, ALP outside the liver group", () => {
    expect(classes.markers.hemoglobin).toMatchObject({ class: "a", may_be_scored: true, redundancy_group: "red_cell_mass", priority_member: true });
    expect(classes.markers.ast).toMatchObject({ class: "e", may_be_scored: false });
    expect(classes.markers.alp.redundancy_group).toBeUndefined();
    expect(classes.markers.hba1c.priority_member).toBe(true);
    expect(classes.markers.glucose_fasting).toMatchObject({ may_be_scored: true, priority_member: false });
    expect(classes.groups.atherogenic_lipids.priority_order).toEqual(["apolipoprotein_b_apob", "non_hdl_cholesterol", "ldl_cholesterol"]);
    expect(classes.groups.glycation.priority_order).toEqual(["hba1c", "glucose_fasting"]);
    expect(classes.groups.liver_enzymes.priority_order).toEqual(["alt", "ggt"]);
    expect(classes.groups.kidney_filtration.priority_order).toEqual(["egfr_creatinine_based"]);
    for (const [key, m] of Object.entries(classes.markers)) {
      const verified = INPUTS.families.flatMap((f) => f.verified ?? []).filter((r) => r.marker_key === key);
      expect(new Set(verified.map((r) => r.marker_class)), key).toEqual(new Set([m.class]));
    }
  });
});

describe("the eligibility keys and bounds are those of the compiled rows", () => {
  it("on a compile of the 30 decided families every eligible row is picked and scores; all optimal gives 100", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "score-compile-"));
    tmp.push(dir);
    execFileSync(process.execPath, [path.join(ROOT, "docs/signoff/tools/compile.js"), "--out-dir", dir], { cwd: ROOT, stdio: "pipe" });
    const rows = seedRowsOf(loadSeed(dir)!.rows);
    for (const [code, m] of Object.entries(SPEC.markers)) {
      for (const [key, entry] of Object.entries(m.rows).filter(([, e]) => e.eligible)) {
        const row = rows.find((r) => r.biomarker_key === m.key && rowEligibilityKey(r) === key);
        expect(row, `${code} ${key}`).toBeDefined();
        expect([row!.optimal_low, row!.optimal_high], `${code} ${key}`).toEqual([entry.optimal_low, entry.optimal_high]);
      }
    }
    const scoredAnywhere = new Set<string>();
    for (const sex of ["male", "female"] as const) {
      for (const age of [19, 30, 50, 70, 88]) {
        const r = calculateLongevityScoreV2(optimalPanel(rows, sex, age), sex, age, rows, { confirmedFasting: true });
        expect(r.longevityScore, `${sex} ${age}`).toBe(100);
        [...r.markerScores, ...r.suppressedMarkers].forEach((s) => scoredAnywhere.add(s.code));
      }
    }
    expect([...scoredAnywhere].sort()).toEqual(Object.entries(SPEC.markers).filter(([, m]) => m.weight != null).map(([c]) => c).sort());
  }, 60_000);
});

describe("the generator fails closed", () => {
  it("a decided row whose optimal bound differs from the verifier's waits, and its marker falls out for that row", () => {
    const spec = specOf(inputsWith(({ decided }) => { const r = find(decided, "albumin", "both"); if (r) r.optimal_low = 40; }));
    expect(spec.markers.ALBUMIN).toMatchObject({ weight: null, grade: null });
    expect(spec.markers.ALBUMIN.rows["both|All Adults"]).toMatchObject({ eligible: false });
    expect(spec.markers.ALBUMIN.rows["both|All Adults"].reason).toMatch(/waiting for a fresh verifier verdict.*optimal 40 to none, verifier 41 to none/);
  });

  it("the grade is the verifier's: an author's B on a band the verifier graded C does not score, and the row waits", () => {
    const authorB = specOf(inputsWith(({ decided }) => { const r = find(decided, "alt", "female"); if (r) r.grade = "B"; }));
    expect(authorB.markers.ALT.rows["female|All Adults"]).toMatchObject({ grade: "C", eligible: false });
    expect(authorB.markers.ALT.rows["female|All Adults"].reason).toMatch(/grade B, verifier C/);
    // Graded B by the verifier too, it scores.
    const both = specOf(inputsWith(({ decided, verified }) => { for (const rows of [decided, verified]) { const r = find(rows, "alt", "female"); if (r) r.grade = "B"; } }));
    expect(both.markers.ALT.rows["female|All Adults"]).toMatchObject({ grade: "B", eligible: true });
  });

  it("no verifier row, a band graded D, and a row without a band do not score", () => {
    // Without the verifier's rows a marker has no class: the generator stops rather than take the author's.
    expect(() => generate({ ...INPUTS, families: INPUTS.families.map((f) => (f.family === "f04_inflammation" ? { ...f, verified: null } : f)) })).toThrow(/hs_crp: the verifier's rows give the classes none/);
    // One row the verifier never saw waits, and does not score.
    const unseen = specOf(inputsWith(({ verified }) => { const i = verified.findIndex((r) => r.marker_key === "ggt" && r.sex === "male"); if (i >= 0) verified.splice(i, 1); }));
    expect(unseen.markers.GGT.rows["male|All Adults"]).toMatchObject({ eligible: false, grade: null });
    expect(unseen.markers.GGT.rows["female|All Adults"]).toMatchObject({ eligible: true });
    const gradeD = specOf(inputsWith(({ decided, verified }) => { for (const rows of [decided, verified]) { const r = find(rows, "hs_crp", "both"); if (r) r.grade = "D"; } }));
    expect(gradeD.markers.HSCRP.rows["both|All Adults"]).toMatchObject({ eligible: false, grade: "D" });
    const noBand = specOf(inputsWith(({ decided, verified }) => { for (const rows of [decided, verified]) { const r = find(rows, "hs_crp", "both"); if (r) { r.optimal_low = null; r.optimal_high = null; } } }));
    expect(noBand.markers.HSCRP.rows["both|All Adults"].reason).toMatch(/no optimal band/);
  });

  it("the weight follows the worst grade among the rows that score", () => {
    const worst = generate(inputsWith(({ decided, verified }) => { for (const rows of [decided, verified]) { const r = find(rows, "hdl_cholesterol", "male"); if (r) r.grade = "A"; } }));
    // Men's row A, women's row B: the marker is B, weight 2.
    expect((worst.scoreSpec as unknown as ScoreSpec).markers.HDL_C).toMatchObject({ grade: "B", weight: 2 });
    const bothA = specOf(inputsWith(({ decided, verified }) => { for (const rows of [decided, verified]) for (const sex of ["male", "female"]) { const r = find(rows, "hdl_cholesterol", sex); if (r) r.grade = "A"; } }));
    expect(bothA.markers.HDL_C).toMatchObject({ grade: "A", weight: 3 });
  });

  it("stops on a class a band graded B with no decision on its place in the score", () => {
    const graded = inputsWith(({ decided, verified }) => { for (const rows of [decided, verified]) { const r = find(rows, "homa_ir", "both"); if (r) r.grade = "B"; } });
    expect(() => generate(graded)).toThrow(/homa_ir\|both\|All Adults\|none.*needs a decision/);
  });

  it("stops on a row it would score whose messages say the marker does not count; the kidney slot waits instead", () => {
    const told = inputsWith(({ decided }) => { const r = find(decided, "albumin", "both"); if (r) r.messages = { en: { optimal: "Fine. This marker does not count toward the score." } }; });
    expect(() => generate(told)).toThrow(/albumin\|both\|All Adults\|none.*does not count toward the score/);
    expect(SPEC.markers.EGFR.rows["both|40-84"]).toMatchObject({ eligible: false, grade: "B" });
    // Once family f03's rows stop saying so, and the changed row has its fresh verdict, the computed eGFR is admitted.
    const admitted = specOf(inputsWith(({ decided, verified }) => {
      for (const r of decided.filter((x) => x.marker_key === "egfr_creatinine_based")) r.messages = {};
      const v = verified.find((x) => x.marker_key === "egfr_creatinine_based" && x.age_group === "18-39");
      if (v) v.optimal_high = 110;
    }));
    expect(admitted.markers.EGFR).toMatchObject({ weight: 2, grade: "B" });
    expect(Object.entries(admitted.markers.EGFR.rows).filter(([, e]) => e.eligible).map(([k]) => k)).toEqual(["both|18-39", "both|40-84"]);
  });
});
