import { describe, it, expect } from "vitest";
import { formatLongevityGrade } from "./dashboard-format";

describe("formatLongevityGrade — stored grade to display label", () => {
  it("localises every grade the longevity score returns", () => {
    const grades: Array<[string, string, string]> = [
      ["Elite", "Elite", "Élite"],
      ["Excellent", "Excellent", "Excelente"],
      ["Very Good", "Very Good", "Muy bueno"],
      ["Good", "Good", "Bueno"],
      ["Average", "Average", "Medio"],
      ["Below Average", "Below Average", "Por debajo de la media"],
      ["Poor", "Poor", "Bajo"],
      ["Needs attention", "Needs attention", "Requiere atención"],
    ];
    for (const [stored, en, es] of grades) {
      expect(formatLongevityGrade(stored, "en")).toBe(en);
      expect(formatLongevityGrade(stored, "es")).toBe(es);
    }
  });

  it("shows the legacy 'Critical' grade as 'Needs attention'", () => {
    expect(formatLongevityGrade("Critical", "en")).toBe("Needs attention");
    expect(formatLongevityGrade("Critical", "es")).toBe("Requiere atención");
  });

  it("ignores case and extra spaces in the stored value", () => {
    expect(formatLongevityGrade("Needs Attention", "en")).toBe("Needs attention");
    expect(formatLongevityGrade(" critical ", "es")).toBe("Requiere atención");
    expect(formatLongevityGrade("very  good", "es")).toBe("Muy bueno");
  });

  it("returns null when there is no grade, so the UI keeps hiding it", () => {
    expect(formatLongevityGrade(null, "en")).toBeNull();
    expect(formatLongevityGrade(undefined, "es")).toBeNull();
    expect(formatLongevityGrade("", "en")).toBeNull();
  });

  it("falls back to the stored text for a grade it does not know", () => {
    expect(formatLongevityGrade("Legendary", "es")).toBe("Legendary");
  });
});
