import { GoogleGenAI } from "@google/genai";
import { createClient } from "@/lib/supabase/server";
import { type SupabaseClient } from "@supabase/supabase-js";
import type { ProcessedBiomarker } from "@/lib/biomarkers/process-results";
import type { WearableData, Profile } from "@/lib/queries/types";
import { calculateAge } from "@/lib/biomarkers/zone-classifier";
import { DB_KEY_TO_ENGINE_CODE } from "@/lib/biomarkers/name-matcher";
import { BIOMARKER_TIER } from "./ranking-tiers";
import { getPrompt } from "@/lib/ai/prompts";

/**
 * Master interpretation generator.
 *
 * Produces the OPTIMIZER-tier authoritative clinical interpretation of
 * a user's lab panel. This is the single source of truth that all
 * other tiers (beginner, familiar) are rephrased FROM. The clinical
 * findings, values, priority order, urgency and recommended actions
 * established here are the same content every reader will eventually
 * receive, regardless of their literacy tier. Only wording changes
 * downstream.
 *
 * Writes to the *_master columns and (re-)inserts action_steps with
 * master_* fields populated. Active columns (the dashboard's view)
 * are NOT touched here — apply-tier owns those.
 */

export interface MasterInterpretation {
  summary: string;
  summary_es: string;
  interpretations: Array<{
    biomarker_key: string;
    text: string;
    text_es: string;
    tone: "positive" | "caution" | "action" | "neutral";
  }>;
  action_steps: Array<{
    priority: number;
    category: string;
    title: string;
    title_es: string;
    description: string;
    description_es: string;
    related_biomarker_keys: string[];
  }>;
}

function buildWearableContext(data: WearableData[] | null): string {
  if (!data || data.length === 0) return "No wearable data available.";
  const avg = (arr: (number | null)[]) => {
    const valid = arr.filter((v): v is number => v != null);
    if (valid.length === 0) return null;
    return Math.round((valid.reduce((a, b) => a + b, 0) / valid.length) * 10) / 10;
  };
  const hrvAvg = avg(data.map((d) => d.hrv_ms));
  const hrAvg = avg(data.map((d) => d.resting_hr_bpm));
  const sleepAvg = avg(data.map((d) => d.sleep_hours));
  const respAvg = avg(data.map((d) => d.respiratory_rate));
  const parts: string[] = [];
  if (hrvAvg != null) parts.push(`HRV: ${hrvAvg}ms`);
  if (hrAvg != null) parts.push(`Resting HR: ${hrAvg}bpm`);
  if (sleepAvg != null) parts.push(`Sleep: ${sleepAvg}h`);
  if (respAvg != null) parts.push(`Resp Rate: ${respAvg}brpm`);
  return parts.length > 0
    ? `30-day wearable averages: ${parts.join(", ")}`
    : "No wearable data available.";
}

function buildBiomarkerContext(biomarkers: ProcessedBiomarker[]): string {
  return biomarkers
    .map(
      (b) =>
        `${b.biomarkerKey}: ${b.value} ${b.unit} [zone: ${b.zone}] (optimal: ${b.optimalLow ?? "n/a"} to ${b.optimalHigh ?? "n/a"})`,
    )
    .join("\n");
}

type ServerClient = Awaited<ReturnType<typeof createClient>>;

/**
 * Priority tier of a stored biomarker_key, via its engine code
 * (ranking-tiers.ts). It only orders the evolution context. It is not
 * the score's weighting: the score reads its weights from the generated
 * specification, and work package WS3-10 moves this ranking onto them.
 */
function tierOf(biomarkerKey: string): number | null {
  const code = DB_KEY_TO_ENGINE_CODE[biomarkerKey];
  return code ? BIOMARKER_TIER[code] ?? null : null;
}

/**
 * Build a biomarker-evolution block: for every marker in the current
 * panel the user has also measured before, the prior values in
 * chronological order. This lets the interpretation describe how the
 * user is trending instead of reading each panel in isolation.
 *
 * Each line is tagged with its EVA longevity tier ([T1]..[T4]) and the
 * block is ordered highest-tier-first, so the model leads the
 * evolution narrative with the markers the Longevity Score engine
 * itself weights most heavily.
 */
async function buildEvolutionContext(
  supabase: ServerClient,
  userId: string,
  currentLabId: string,
  current: ProcessedBiomarker[],
): Promise<string> {
  // Most recent prior panels — capped so the prompt stays bounded.
  const { data: priorLabs } = await supabase
    .from("lab_results")
    .select("id, collection_date")
    .eq("user_id", userId)
    .eq("status", "ready")
    .neq("id", currentLabId)
    .order("collection_date", { ascending: false })
    .limit(6);
  if (!priorLabs || priorLabs.length === 0) {
    return "No prior panels on file — this is the user's first lab with EVA.";
  }

  const dateById = new Map(priorLabs.map((l) => [l.id, l.collection_date]));
  const { data: priorValues } = await supabase
    .from("biomarker_values")
    .select("biomarker_key, value, lab_result_id")
    .in(
      "lab_result_id",
      priorLabs.map((l) => l.id),
    );
  if (!priorValues || priorValues.length === 0) {
    return "No prior biomarker values on file.";
  }

  // Group prior values per biomarker, oldest → newest.
  const history = new Map<string, Array<{ date: string; value: number }>>();
  for (const v of priorValues) {
    const arr = history.get(v.biomarker_key) ?? [];
    arr.push({ date: dateById.get(v.lab_result_id) ?? "", value: v.value });
    history.set(v.biomarker_key, arr);
  }
  for (const arr of history.values()) {
    arr.sort((a, b) => a.date.localeCompare(b.date));
  }

  const ranked: Array<{ tier: number; line: string }> = [];
  for (const b of current) {
    const past = history.get(b.biomarkerKey);
    if (!past || past.length === 0) continue;
    const series = past.map((p) => `${p.value} (${p.date})`).join(" → ");
    const tier = tierOf(b.biomarkerKey);
    const tag = tier ? ` [T${tier}]` : "";
    ranked.push({
      tier: tier ?? 9,
      line: `${b.biomarkerKey}${tag}: ${series} → ${b.value} (current)`,
    });
  }
  if (ranked.length === 0) {
    return "No biomarkers in this panel overlap with prior panels.";
  }
  // Highest longevity tier first.
  ranked.sort((a, b) => a.tier - b.tier);
  return ranked.map((r) => r.line).join("\n");
}

/**
 * Generate the master (optimizer-tier) interpretation for a lab and
 * persist it to the *_master columns plus a fresh action_steps batch.
 * Existing action_steps for this lab are deleted first so legacy labs
 * (uploaded before the master architecture) get cleanly backfilled.
 */
/**
 * The lab's own free-text observations (OBX TX), verbatim and in the lab's
 * language. They can invalidate a number (lipemic serum, interference) or
 * add a recommendation, so the interpretation must weigh them.
 */
function buildLabNotesContext(labNotes?: string[]): string {
  const notes = (labNotes ?? []).map((n) => n.trim()).filter(Boolean);
  if (notes.length === 0) return "";
  return `
Observations sent by the laboratory with this report (verbatim; an interference or sample-quality note may invalidate a value — say so instead of interpreting that value):
${notes.map((n) => `- ${n}`).join("\n")}
`;
}

export async function generateMasterInterpretation(
  userId: string,
  labResultId: string,
  processedBiomarkers: ProcessedBiomarker[],
  wearableData: WearableData[] | null,
  profile: Profile,
  client?: SupabaseClient,
  labNotes?: string[],
): Promise<MasterInterpretation> {
  const geminiKey = process.env.GEMINI_API_KEY;
  if (!geminiKey) throw new Error("GEMINI_API_KEY not set");
  if (processedBiomarkers.length === 0) {
    throw new Error("Cannot generate master interpretation: no processed biomarkers");
  }

  const supabase = client ?? (await createClient());
  const genai = new GoogleGenAI({ apiKey: geminiKey });
  const masterPrompt = await getPrompt("master_interpretation");
  const age = profile.date_of_birth ? calculateAge(profile.date_of_birth) : "unknown";

  const evolutionContext = await buildEvolutionContext(
    supabase,
    userId,
    labResultId,
    processedBiomarkers,
  );

  const userPrompt = `User: Age ${age}, Sex ${profile.sex ?? "unknown"}

Biomarker Results (current panel):
${buildBiomarkerContext(processedBiomarkers)}

${buildWearableContext(wearableData)}
${buildLabNotesContext(labNotes)}
Biomarker history from the user's prior panels (oldest → newest → current):
${evolutionContext}

Each history line is tagged with its EVA longevity tier: [T1] is the
highest-weighted aging driver (atherogenic lipids/ApoB, glycemic control,
inflammation, kidney function), [T2] high, down to [T4] lowest — the same
weighting EVA's Longevity Score engine applies. If prior history is present
above, the summary MUST describe how the user's biomarkers have evolved —
name which are improving, worsening, or holding steady, and read the current
panel against that trajectory rather than in isolation. Lead the evolution
narrative with the [T1] and [T2] markers.

Generate the master (optimizer-tier) clinical interpretation JSON.`;

  const response = await genai.models.generateContent({
    model: masterPrompt.model,
    contents: [{ role: "user", parts: [{ text: userPrompt }] }],
    config: {
      systemInstruction: masterPrompt.content,
      ...(masterPrompt.temperature != null && { temperature: masterPrompt.temperature }),
      ...(masterPrompt.maxOutputTokens != null && { maxOutputTokens: masterPrompt.maxOutputTokens }),
      ...(masterPrompt.thinkingBudget != null && { thinkingConfig: { thinkingBudget: masterPrompt.thinkingBudget } }),
      ...(masterPrompt.responseMimeType && { responseMimeType: masterPrompt.responseMimeType }),
    },
  });

  const responseText = response.text ?? "";
  if (!responseText) throw new Error("Empty response from Gemini");

  let parsed: MasterInterpretation;
  try {
    parsed = JSON.parse(responseText);
  } catch (err) {
    console.error("[generate-master] Failed to parse JSON:", responseText.slice(0, 200));
    throw new Error(`Invalid JSON from Gemini: ${err instanceof Error ? err.message : "unknown"}`);
  }
  if (!parsed.summary || !Array.isArray(parsed.interpretations) || !Array.isArray(parsed.action_steps)) {
    throw new Error("Master response missing required fields");
  }

  const strengths = processedBiomarkers
    .filter((b) => b.zone === "optimal")
    .map((b) => b.biomarkerKey);
  const needsAttention = processedBiomarkers
    .filter((b) => b.zone !== "optimal" && b.zone !== "unclassified")
    .map((b) => b.biomarkerKey);

  const { error: labError } = await supabase
    .from("lab_results")
    .update({
      summary_narrative_master: parsed.summary,
      summary_narrative_master_es: parsed.summary_es,
      strengths,
      needs_attention: needsAttention,
    })
    .eq("id", labResultId);
  if (labError) throw new Error(`Failed to save master lab summary: ${labError.message}`);

  const interpretationErrors: string[] = [];
  for (const interp of parsed.interpretations) {
    const { error } = await supabase
      .from("biomarker_values")
      .update({
        interpretation_master: interp.text,
        interpretation_master_es: interp.text_es,
      })
      .eq("lab_result_id", labResultId)
      .eq("biomarker_key", interp.biomarker_key);
    if (error) interpretationErrors.push(`${interp.biomarker_key}: ${error.message}`);
  }
  if (interpretationErrors.length > 0) {
    console.error("[generate-master] Some master interpretations failed to save:", interpretationErrors);
  }

  // Fresh insert of action_steps with master fields populated. We delete
  // first so legacy rows (from before the master architecture) get a
  // clean replacement instead of accumulating duplicates.
  const { error: deleteStepsError } = await supabase
    .from("action_steps")
    .delete()
    .eq("lab_result_id", labResultId);
  if (deleteStepsError) {
    console.error("[generate-master] Failed to clear action_steps before insert:", deleteStepsError);
  }

  if (parsed.action_steps.length > 0) {
    const steps = parsed.action_steps.map((step) => ({
      user_id: userId,
      lab_result_id: labResultId,
      priority: step.priority,
      category: step.category,
      title_master: step.title,
      title_master_es: step.title_es,
      description_master: step.description,
      description_master_es: step.description_es,
      // Seed the active fields with the master so optimizer-tier users see
      // content immediately without an extra round-trip. apply-tier will
      // overwrite these for beginner/familiar.
      title: step.title,
      title_es: step.title_es,
      description: step.description,
      description_es: step.description_es,
      related_biomarker_keys: step.related_biomarker_keys,
      status: "pending",
    }));

    const { error: stepsError } = await supabase.from("action_steps").insert(steps);
    if (stepsError) throw new Error(`Failed to save master action_steps: ${stepsError.message}`);
  }

  return parsed;
}
