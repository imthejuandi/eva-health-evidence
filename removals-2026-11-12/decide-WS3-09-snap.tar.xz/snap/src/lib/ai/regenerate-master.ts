import type { SupabaseClient } from "@supabase/supabase-js";
import { shownAsValueOnly } from "@/lib/biomarkers/lab-reported";
import { createClient } from "@/lib/supabase/server";
import { getUserProfile, getWearableData } from "@/lib/queries";
import { generateMasterInterpretation } from "./generate-master-interpretation";
import { applyTier } from "./apply-tier";
import { recomputeLabMetrics, type ProcessedBiomarker } from "@/lib/biomarkers/process-results";
import type { Profile } from "@/lib/queries/types";

/**
 * Regenerate the master interpretation for a lab from the biomarker_values
 * currently in the database, then materialize it into the active columns
 * at the user's literacy tier.
 *
 * Used by two routes that share the same flow:
 *   - /api/lab-results/regenerate-summary (manual tier change / legacy
 *     backfill — short-circuits when the master already exists)
 *   - /api/biomarker-values/[id] PATCH (manual value edit — always
 *     regenerates because the values just changed)
 *
 * When `force: true` is set (the edit path), we ALSO call
 * recomputeLabMetrics so the dashboard's headline numbers — zone
 * counts, KDM biological age (Reference + Comprehensive), longevity
 * score, and the user's rolling-average BA on profile.current_ba* —
 * stay coherent with the regenerated narrative. A meaningful change in
 * a single biomarker (e.g. correcting a misread Lp(a) or HbA1c) can
 * shift the BA by years; recomputing here keeps the headline and the
 * prose pointing at the same panel.
 */
export interface RegenerateMasterOpts {
  /** If true, always regenerate even when the master already exists.
   * Defaults to false (the regenerate-summary lazy-backfill path). */
  force?: boolean;
  /** Optional pre-loaded profile to avoid a duplicate round trip. */
  profile?: Profile;
  /** Optional pre-opened supabase client to reuse the caller's session. */
  supabase?: SupabaseClient;
}

export type RegenerateMasterResult =
  | { ok: true; tier: string; labResultId: string }
  | { ok: false; reason: "profile_missing" | "no_biomarkers" | "master_missing_after_regen" };

export async function regenerateMasterForLab(
  labResultId: string,
  userId: string,
  opts: RegenerateMasterOpts = {},
): Promise<RegenerateMasterResult> {
  const supabase = opts.supabase ?? (await createClient());
  const profile = opts.profile ?? (await getUserProfile(userId));
  if (!profile) {
    return { ok: false, reason: "profile_missing" };
  }
  const tier = profile.health_knowledge ?? "beginner";

  const { data: lab } = await supabase
    .from("lab_results")
    .select("id, summary_narrative_master")
    .eq("id", labResultId)
    .eq("user_id", userId)
    .maybeSingle();

  const needsMaster = opts.force === true || !lab?.summary_narrative_master;

  if (needsMaster) {
    const { data: values, error: valuesError } = await supabase
      .from("biomarker_values")
      .select(
        "biomarker_key, biomarker_name, value, unit, zone, optimal_low, optimal_high",
      )
      .eq("lab_result_id", labResultId);
    if (valuesError) {
      throw new Error(
        `Failed to load biomarker_values for regen: ${valuesError.message}`,
      );
    }
    if (!values || values.length === 0) {
      return { ok: false, reason: "no_biomarkers" };
    }

    // A laboratory's own eGFR goes to the interpretation as a value only: no category, no interval (lab-reported.ts).
    const processed: ProcessedBiomarker[] = values.map(shownAsValueOnly).map((v) => ({
      biomarkerKey: v.biomarker_key,
      name: v.biomarker_name ?? v.biomarker_key,
      value: Number(v.value),
      unit: v.unit ?? "",
      zone: (v.zone ?? "unclassified") as ProcessedBiomarker["zone"],
      zoneLabel: "",
      zoneLabel_es: "",
      optimalLow: v.optimal_low != null ? Number(v.optimal_low) : null,
      optimalHigh: v.optimal_high != null ? Number(v.optimal_high) : null,
      matchConfidence: "exact",
    }));

    // Recompute every lab-level metric the dashboard reads — zone
    // counts, KDM biological age (Reference + Comprehensive),
    // longevity score, and the user's rolling-average BA cached on
    // profile.current_ba*. Without this, a manual edit that flips a
    // biomarker's zone (e.g. correcting Lp(a) from 30 to 130) updates
    // the row + the AI narrative but leaves the headline "X needs
    // attention" tile and the biological-age number stuck on the
    // pre-edit panel. A meaningful biomarker change can shift the BA
    // by years; the dashboard headline and the narrative must agree.
    await recomputeLabMetrics(userId, labResultId, supabase);

    const wearable = await getWearableData(userId, 30);
    await generateMasterInterpretation(
      userId,
      labResultId,
      processed,
      wearable.length > 0 ? wearable : null,
      profile,
    );
  }

  const tierApplied = await applyTier(labResultId, tier);
  if (!tierApplied) {
    return { ok: false, reason: "master_missing_after_regen" };
  }

  return { ok: true, tier, labResultId };
}
