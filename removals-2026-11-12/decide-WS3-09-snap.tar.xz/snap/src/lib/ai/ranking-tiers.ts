/**
 * The order in which the AI summary's evolution context lists markers (generate-master-interpretation.ts), keyed by
 * engine code: 1 first, 4 last. It is the priority table the first score used and is kept here only to order that
 * context. The score does not read it: its weights come from the generated specification
 * (src/lib/biomarkers/data/score-spec.json). Work package WS3-10 replaces this table with the specification's
 * weights and marks the other markers "not scored"; the AI text stays hidden until the prompt review.
 */
export const BIOMARKER_TIER: Readonly<Record<string, 1 | 2 | 3 | 4>> = {
  APOB: 1, EGFR: 1, GLUCOSE: 1, HBA1C: 1, HOMA_IR: 1, HSCRP: 1, INSULIN: 1, LDL_C: 1,
  ALBUMIN: 2, ALT: 2, ESTRADIOL: 2, FRUCTOSAMINE: 2, HDL_C: 2, LPA: 2, RDW: 2, TESTOSTERONE: 2, TG: 2, VITD: 2,
  AST: 3, FERRITIN: 3, GGT: 3, HGB: 3, LYMPH_ABS: 3, LYMPH_PCT: 3, NLR: 3, SHBG: 3, TSAT: 3, TSH: 3, URIC_ACID: 3, WBC: 3,
  ALP: 4, B12: 4, BILIRUBIN: 4, CREATININE: 4, FOLATE: 4, FT3: 4, FT4: 4, MAGNESIUM: 4, MCV: 4, PLT: 4, ZINC: 4,
};
