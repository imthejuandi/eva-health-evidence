import { timingSafeEqual } from "node:crypto";
import { screenSubmittedResults } from "@/lib/lab-results/screen-results";
import { printedResult } from "@/lib/lab-results/set-aside";
import { type LabProvider } from "./interface";
import { type LabProviderResult } from "./types";

// SEC-008 — the manual/internal webhook must present a shared secret as
// `Authorization: Bearer <LAB_WEBHOOK_SECRET>`. Fails closed when the secret
// is unset so an unconfigured deployment rejects rather than accepts.
function bearerMatches(headers: Record<string, string>): boolean {
  const secret = process.env.LAB_WEBHOOK_SECRET;
  if (!secret) return false;
  const auth = headers["authorization"] ?? "";
  const match = /^Bearer\s+(.+)$/i.exec(auth);
  if (!match) return false;
  const provided = Buffer.from(match[1]);
  const expected = Buffer.from(secret);
  return provided.length === expected.length && timingSafeEqual(provided, expected);
}

interface ManualFormEntry {
  biomarker_key: string;
  /** The number, or the text the laboratory printed: "5,4", or a bound such as "<5" or ">8,000". */
  value: number | string;
  unit: string;
  /** "<" or ">" when the result is a bound and `value` is the bound itself. */
  comparator?: string | null;
}

interface ManualFormPayload {
  userId: string;
  collectionDate: string;
  results: ManualFormEntry[];
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

export const ManualProvider: LabProvider = {
  name: "manual",

  // A bounded result keeps its comparator, from a "<5" printed as the value or from the comparator given beside it, so
  // the webhook hands it to processing as a bound (bounded-result.ts readReportedValue). A result printed with "≤" or
  // "≥", which cannot be stored with its sign, or with no readable number, is set aside with its reason and the rest
  // of the payload is read (decision D-24, lab-results/screen-results.ts): the webhook logs and returns those results.
  // Only a payload with no list of results is refused.
  parseResults(payload: unknown): LabProviderResult {
    const data = payload as ManualFormPayload;
    if (!data || typeof data !== "object" || !Array.isArray(data.results)) {
      throw new Error("manual: the payload has no list of results");
    }
    const entries = data.results.map((r: Partial<ManualFormEntry> | null, i) => ({
      name: typeof r?.biomarker_key === "string" && r.biomarker_key ? r.biomarker_key : `result ${i + 1}`,
      key: typeof r?.biomarker_key === "string" ? r.biomarker_key : "",
      value: r?.value,
      comparator: r?.comparator,
      unit: typeof r?.unit === "string" ? r.unit : "",
    }));
    const { usable, setAside } = screenSubmittedResults(entries.filter((e) => e.key));
    // A result with no marker key cannot be matched to anything: it is named by its position.
    const unnamed = entries.filter((e) => !e.key).map((e) => ({
      name: e.name,
      reason: "marker_not_recognised" as const,
      printed: printedResult(e.value, e.comparator, e.unit),
    }));
    return {
      providerReference: `manual-${Date.now()}`,
      userId: data.userId,
      biomarkers: usable.map((u) => ({
        biomarker_key: u.entry.key,
        value: u.value,
        unit: u.entry.unit,
        ...(u.comparator ? { comparator: u.comparator } : {}),
      })),
      setAside: [...setAside, ...unnamed],
      collectionDate: data.collectionDate,
      rawPayload: payload,
    };
  },

  mapBiomarkerName(providerName: string): string {
    return slugify(providerName);
  },

  verifyWebhook(headers: Record<string, string>, _body: string): boolean {
    return bearerMatches(headers);
  },
};
