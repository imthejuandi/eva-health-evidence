/**
 * The manual lab provider keeps a bounded result's comparator (known issue C-06, decision CEO-15): a "<5" printed as
 * the value, or a value with "<" beside it, reaches processing as the bound 5 with "<", through the webhook, its only
 * live sender. A result printed with "≤" or "≥", which cannot be stored with its sign, is set aside and named, as a
 * result with no number is, and the rest of the payload is processed (decision D-24, WS3-27): the webhook logs and
 * returns what was set aside, and answers 422 only when nothing could be used. Processing, the database and the
 * email are stubbed around the webhook.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { fakeSupabase, ops } from "@/lib/testing/fake-supabase";
import { ManualProvider } from "./manual";

const state = vi.hoisted(() => ({ admin: null as unknown }));

vi.mock("@/lib/supabase/admin", () => ({ createAdminClient: () => state.admin }));
vi.mock("@/lib/biomarkers/process-results", () => ({
  // Stores every result it is given, unless a test scripts otherwise.
  processLabResults: vi.fn(async (_user: string, _lab: string, given: Array<{ biomarkerKey?: string }>) => ({
    processed: given.map((g) => ({ biomarkerKey: g.biomarkerKey })),
    biologicalAge: null,
    calculatedMetrics: [],
    unmatched: [],
    refMapSize: 0,
    missingRefKeys: [],
  })),
}));
vi.mock("@/lib/queries", () => ({ getUserProfile: vi.fn(async () => null) }));
vi.mock("@/lib/email/send", () => ({ sendEmail: vi.fn(async () => undefined) }));

import { POST as webhook } from "@/app/api/lab-results/webhook/route";
import { processLabResults } from "@/lib/biomarkers/process-results";
import { getUserProfile } from "@/lib/queries";
import { sendEmail } from "@/lib/email/send";
import { SET_ASIDE_COPY } from "@/lib/lab-results/set-aside-copy.generated";

const USER = "22222222-2222-4222-8222-222222222222";
const payload = (results: Array<Record<string, unknown>>) => ({ userId: USER, collectionDate: "2026-11-02", results });
const parsed = (results: Array<Record<string, unknown>>) => ManualProvider.parseResults(payload(results)).biomarkers;

describe("ManualProvider.parseResults keeps a bound's comparator", () => {
  it('"<5" printed as the value keeps its sign, and the value is the bound', () => {
    expect(parsed([{ biomarker_key: "hs_crp", value: "<5", unit: "mg/L" }])).toEqual([
      { biomarker_key: "hs_crp", value: 5, unit: "mg/L", comparator: "<" },
    ]);
  });

  it("a value with its comparator beside it keeps the comparator", () => {
    expect(parsed([
      { biomarker_key: "hs_crp", value: 5, unit: "mg/L", comparator: "<" },
      { biomarker_key: "egfr_creatinine_based", value: 90, unit: "mL/min/1.73m²", comparator: ">" },
    ])).toEqual([
      { biomarker_key: "hs_crp", value: 5, unit: "mg/L", comparator: "<" },
      { biomarker_key: "egfr_creatinine_based", value: 90, unit: "mL/min/1.73m²", comparator: ">" },
    ]);
  });

  it("reads the laboratory's printed forms as the HL7 parser does: a decimal comma, a space after the sign", () => {
    expect(parsed([
      { biomarker_key: "hs_crp", value: "< 0,500", unit: "mg/L" },
      { biomarker_key: "ferritin", value: ">8,000", unit: "ng/mL" },
      { biomarker_key: "hba1c", value: "5,4", unit: "%" },
    ])).toEqual([
      { biomarker_key: "hs_crp", value: 0.5, unit: "mg/L", comparator: "<" },
      { biomarker_key: "ferritin", value: 8, unit: "ng/mL", comparator: ">" },
      { biomarker_key: "hba1c", value: 5.4, unit: "%" },
    ]);
  });

  it("a measured value carries no comparator, as before, with or without a null one beside it", () => {
    const measured = parsed([{ biomarker_key: "albumin", value: 44, unit: "g/L" }, { biomarker_key: "alt", value: 30, unit: "U/L", comparator: null }]);
    expect(measured).toEqual([{ biomarker_key: "albumin", value: 44, unit: "g/L" }, { biomarker_key: "alt", value: 30, unit: "U/L" }]);
    for (const b of measured) expect(b).not.toHaveProperty("comparator");
  });

  it('"≤" and "≥" cannot be stored with their sign: the result is set aside and named, the rest is read (D-24)', () => {
    for (const [result, sign] of [
      [{ biomarker_key: "hs_crp", value: "≤5", unit: "mg/L" }, "≤"],
      [{ biomarker_key: "hs_crp", value: "<=5", unit: "mg/L" }, "≤"],
      [{ biomarker_key: "hs_crp", value: 5, unit: "mg/L", comparator: "≥" }, "≥"],
      [{ biomarker_key: "hs_crp", value: 5, unit: "mg/L", comparator: ">=" }, "≥"],
    ] as const) {
      const read = ManualProvider.parseResults(payload([{ biomarker_key: "albumin", value: 44, unit: "g/L" }, result]));
      // Never handed on as a plain 5, nor as "<5" or ">5".
      expect(read.biomarkers).toEqual([{ biomarker_key: "albumin", value: 44, unit: "g/L" }]);
      expect(read.setAside).toHaveLength(1);
      expect(read.setAside?.[0]).toMatchObject({ name: "hs_crp", reason: "sign_not_storable", sign });
    }
  });

  it("a value with no number, a comparator that is not a sign, or a sign that contradicts the text is set aside as unreadable", () => {
    for (const result of [
      { biomarker_key: "hs_crp", value: "pending", unit: "mg/L" },
      { biomarker_key: "hs_crp", value: null, unit: "mg/L" },
      { biomarker_key: "hs_crp", value: 5, unit: "mg/L", comparator: "~" },
      { biomarker_key: "hs_crp", value: "<5", unit: "mg/L", comparator: ">" },
    ]) {
      const read = ManualProvider.parseResults(payload([result, { biomarker_key: "albumin", value: 44, unit: "g/L" }]));
      expect(read.biomarkers).toEqual([{ biomarker_key: "albumin", value: 44, unit: "g/L" }]);
      expect(read.setAside).toEqual([expect.objectContaining({ name: "hs_crp", reason: "value_unreadable" })]);
    }
  });

  it("a result with no marker key is named by its position; a payload with no list of results is still refused", () => {
    const read = ManualProvider.parseResults(payload([{ value: 5, unit: "mg/L" }, { biomarker_key: "albumin", value: 44, unit: "g/L" }]));
    expect(read.biomarkers).toHaveLength(1);
    expect(read.setAside).toEqual([{ name: "result 1", reason: "marker_not_recognised", printed: "5 mg/L" }]);
    expect(() => ManualProvider.parseResults({ userId: USER, collectionDate: "2026-11-02" })).toThrow(/no list of results/);
    expect(() => ManualProvider.parseResults(null)).toThrow(/no list of results/);
  });
});

describe("the webhook hands the manual provider's comparator to processing", () => {
  let admin: ReturnType<typeof fakeSupabase>;
  beforeEach(() => {
    vi.stubEnv("LAB_WEBHOOK_SECRET", "s3cret");
    admin = fakeSupabase((c) => (c.table === "lab_results" && ops(c).startsWith("insert") ? { data: { id: "lab-1" } } : { data: null }));
    state.admin = admin.client;
    vi.mocked(processLabResults).mockClear();
    vi.mocked(sendEmail).mockClear();
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  const post = (body: unknown) =>
    webhook(new NextRequest("http://localhost/api/lab-results/webhook", {
      method: "POST",
      headers: { "x-provider": "manual", authorization: "Bearer s3cret" },
      body: JSON.stringify(body),
    }));

  it('"<5" reaches processing as the bound 5 with "<"; a measured value without one', async () => {
    const res = await post(payload([
      { biomarker_key: "hs_crp", value: "<5", unit: "mg/L" },
      { biomarker_key: "albumin", value: 44, unit: "g/L" },
    ]));
    expect(res.status).toBe(200);
    const [, , given] = vi.mocked(processLabResults).mock.calls[0];
    expect(given).toEqual([
      { name: "hs_crp", biomarkerKey: "hs_crp", matchConfidence: "exact", value: 5, unit: "mg/L", comparator: "<" },
      { name: "albumin", biomarkerKey: "albumin", matchConfidence: "exact", value: 44, unit: "g/L" },
    ]);
  });

  it('a payload with a "≤" result and an unreadable one: the rest is processed, and the answer and the log name both', async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const res = await post(payload([
      { biomarker_key: "albumin", value: 44, unit: "g/L" },
      { biomarker_key: "hs_crp", value: "≤5", unit: "mg/L" },
      { biomarker_key: "ferritin", value: "pending", unit: "ng/mL" },
    ]));
    expect(res.status).toBe(200);
    const [, , given] = vi.mocked(processLabResults).mock.calls[0];
    expect(given).toEqual([{ name: "albumin", biomarkerKey: "albumin", matchConfidence: "exact", value: 44, unit: "g/L" }]);
    const body = await res.json();
    expect(body.processed).toBe(1);
    expect(body.setAside).toEqual([
      {
        name: "hs_crp",
        reason: "sign_not_storable",
        printed: "≤5 mg/L",
        message: { en: SET_ASIDE_COPY.en.reasons.sign_not_storable.replace("{sign}", "≤"), es: SET_ASIDE_COPY.es.reasons.sign_not_storable.replace("{sign}", "≤") },
      },
      {
        name: "ferritin",
        reason: "value_unreadable",
        printed: "pending ng/mL",
        message: { en: SET_ASIDE_COPY.en.reasons.value_unreadable, es: SET_ASIDE_COPY.es.reasons.value_unreadable },
      },
    ]);
    // Operations: one log line naming the lab and each result.
    const logged = warn.mock.calls.find((c) => String(c[0]).startsWith("[set-aside] lab-webhook:manual"));
    expect(JSON.parse(String(logged?.[1]))).toMatchObject({
      labResultId: "lab-1",
      userId: USER,
      results: [{ name: "hs_crp", reason: "sign_not_storable" }, { name: "ferritin", reason: "value_unreadable" }],
    });
  });

  it("what processing refuses (a unit, an unknown name) is returned with the results set aside at reading", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(processLabResults).mockResolvedValueOnce({
      processed: [{ biomarkerKey: "albumin" }],
      unmatched: [
        { name: "lipoprotein_a", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" },
        { name: "mystery", value: 1, unit: "x", reason: "unmatched" },
      ],
    } as never);
    const res = await post(payload([
      { biomarker_key: "albumin", value: 44, unit: "g/L" },
      { biomarker_key: "lipoprotein_a", value: 75, unit: "nmol/L" },
      { biomarker_key: "mystery", value: 1, unit: "x" },
    ]));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.setAside.map((i: { name: string; reason: string }) => [i.name, i.reason])).toEqual([
      ["lipoprotein_a", "unit_not_convertible"],
      ["mystery", "marker_not_recognised"],
    ]);
    expect(body.setAside[0].message.es).toContain("nmol/L");
    expect(body.setAside[0].message.es).toContain("mg/dL");
  });

  it("a payload of which nothing can be used: 422 naming each result, no lab created, nothing processed, no email", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    const res = await post(payload([{ biomarker_key: "hs_crp", value: "≥5", unit: "mg/L" }, { biomarker_key: "alt", value: "n/a", unit: "U/L" }]));
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(body.status).toBe("nothing_usable");
    expect(body.setAside.map((i: { name: string; reason: string }) => [i.name, i.reason])).toEqual([
      ["hs_crp", "sign_not_storable"],
      ["alt", "value_unreadable"],
    ]);
    expect(processLabResults).not.toHaveBeenCalled();
    expect(admin.calls.some((c) => ops(c).startsWith("insert"))).toBe(false);
    expect(sendEmail).not.toHaveBeenCalled();
  });

  it("when processing stores nothing (every unit refused), the empty lab is removed and the client is not emailed", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.mocked(getUserProfile).mockResolvedValueOnce({ email: "u@example.test", full_name: "Ana", locale: "es" } as never);
    vi.mocked(processLabResults).mockResolvedValueOnce({
      processed: [],
      unmatched: [{ name: "lipoprotein_a", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" }],
    } as never);
    const res = await post(payload([{ biomarker_key: "lipoprotein_a", value: 75, unit: "nmol/L" }]));
    expect(res.status).toBe(422);
    expect((await res.json()).setAside).toEqual([expect.objectContaining({ name: "lipoprotein_a", reason: "unit_not_convertible" })]);
    expect(admin.calls.some((c) => c.table === "lab_results" && ops(c).startsWith("delete"))).toBe(true);
    expect(sendEmail).not.toHaveBeenCalled();
  });
});
