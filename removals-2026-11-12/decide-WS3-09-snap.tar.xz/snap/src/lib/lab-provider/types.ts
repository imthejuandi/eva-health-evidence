import type { SetAsideResult } from "@/lib/lab-results/set-aside";

/** One analyte reading as parsed from the provider payload. */
export interface BiomarkerResult {
  /** Raw provider analyte code (e.g. Echevarne OBX-3.1) or an eva key for the manual provider. */
  biomarker_key: string;
  value: number;
  unit: string;
  /** Present when the provider sent a bounded value like "<0,500" / ">8,000" (OBX-5). */
  comparator?: "<" | ">";
  /** LOINC code when the provider supplies one (Echevarne OBX-3.4, "si se dispone"). */
  loincCode?: string;
  /** Per-result status (OBX-11): F final, P preliminary/partial, C corrected. */
  status?: "final" | "preliminary" | "corrected";
}

/** Free-text observation rows (OBX type TX): conclusions, valoraciones, microbiology. */
export interface LabTextNote {
  code: string;
  text: string;
}

export interface LabProviderResult {
  /** Stable per-result reference from the lab (Echevarne: filler order number, ORC.3.1). */
  providerReference: string;
  /**
   * Direct eva-user linkage. Only providers that carry our user id in the
   * payload set this (manual). Order-based providers (Echevarne) identify the
   * cycle via placerOrderNumber instead and leave this unset.
   */
  userId?: string;
  /** eva's petition number echoed back by the lab (ORC.2.1) — the matching key for order-based flows. */
  placerOrderNumber?: string;
  /** Sample sticker / "label de Trak" (SPM.2.1.1) — cross-check against the cycle's kit_label_code. */
  kitLabelCode?: string;
  /** HL7 MSH-10 — unique message id, used for lab_messages dedupe and ACK MSA-2. */
  messageControlId?: string;
  /** Order-level status (Echevarne ORC.5): A = partial, CM = final. */
  orderStatus?: "partial" | "final";
  biomarkers: BiomarkerResult[];
  /**
   * Results of the payload the provider could not hand on (a sign that cannot be stored, no readable number), each
   * with its reason: the webhook logs and returns them and processes `biomarkers` (decision D-24).
   */
  setAside?: SetAsideResult[];
  /** OBX TX rows worth keeping (conclusions, micro results). */
  textNotes?: LabTextNote[];
  /** Base64 of the encapsulated report PDF (OBX type ED, INPDF), when present. */
  reportPdfBase64?: string;
  /** Calendar date of specimen collection (YYYY-MM-DD). */
  collectionDate: string;
  /** Full collection timestamp when the payload carries one (ORC.27.1 / SPM.18). */
  collectionDateTime?: string;
  rawPayload: unknown;
}
