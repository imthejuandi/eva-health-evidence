/**
 * Display flags for the biological age (server side only).
 *
 * Two flags, read from the server environment at request time (never NEXT_PUBLIC_, so they are not inlined into the
 * browser bundle and a change takes effect on the next request, without a rebuild):
 *
 * - BIO_AGE_KDM_VISIBLE: the old KDM v2.2 figure (lab_results.biological_age*, profiles.current_ba*). When false, the
 *   figure appears nowhere a client can see it: the dashboard (including its fallback to the stored lab figure), the
 *   lab page and its history selector, the results-ready email and the AI chat context. It is still computed and
 *   stored exactly as before (process-results.ts, rolling-average-ba.ts); only display and sending change.
 * - BIO_AGE_V3_VISIBLE: the version 3 card (src/components/dashboard/BiologicalAgeV3Card.tsx), formatted by
 *   bio-age-v3-display.ts from the bio_age_v3_shadow record. When false, nothing of version 3 reaches the client.
 *
 * Both are false by default. The default implements the CEO decision the plan recommends (docs/signoff/PLAN.md
 * section 10, decision 4: "Interim biological age: none shown until version 3 is released"; wording-rules.md
 * section 8). The CEO can flip either flag by setting the variable to "true" (or "1") in the server environment;
 * any other value, or none, is false. Turning BIO_AGE_V3_VISIBLE on is the release of version 3 and needs the
 * physician's signature on the pack first.
 */
import type { Profile } from "@/lib/queries/types";

export const BIO_AGE_KDM_VISIBLE_ENV = "BIO_AGE_KDM_VISIBLE";
export const BIO_AGE_V3_VISIBLE_ENV = "BIO_AGE_V3_VISIBLE";

type Env = Readonly<Record<string, string | undefined>>;

/** "true" or "1" (any case, surrounding spaces ignored) is on; anything else, including unset, is off. */
export function flagOn(raw: string | undefined | null): boolean {
  if (raw == null) return false;
  const v = raw.trim().toLowerCase();
  return v === "true" || v === "1";
}

/** Whether the old KDM biological age may be shown or sent. Default false. */
export function isBioAgeKdmVisible(env: Env = process.env): boolean {
  return flagOn(env[BIO_AGE_KDM_VISIBLE_ENV]);
}

/** Whether the version 3 card may be shown. Default false. */
export function isBioAgeV3Visible(env: Env = process.env): boolean {
  return flagOn(env[BIO_AGE_V3_VISIBLE_ENV]);
}

// ─── Removing the old figure before it leaves the server ───
//
// The dashboard and lab pages are server components that hand whole rows to client components. Hiding the figure
// only in the client would still ship it in the page payload, so the server pages pass the rows through these
// helpers first. With the flag on, the rows are returned unchanged.

/** The lab_results fields that carry the old KDM figure or its provenance. */
export const KDM_LAB_FIELDS = [
  "biological_age",
  "biological_age_comprehensive",
  "bio_age_method",
  "bio_age_n_markers",
  "bio_age_applied_spanish_calibration",
] as const;

/** The profiles fields that carry the cached rolling-average KDM figure. */
export const KDM_PROFILE_FIELDS = [
  "current_ba",
  "current_ba_method",
  "current_ba_n_labs_averaged",
  "current_ba_window_months",
  "current_ba_n_markers_used",
  "current_ba_computed_at",
] as const;

function withNulls<T extends object>(row: T, fields: readonly string[]): T {
  const out: Record<string, unknown> = { ...(row as Record<string, unknown>) };
  for (const f of fields) if (f in out) out[f] = null;
  return out as T;
}

/** A lab row (or a partial one, such as a history item) without the KDM figure when the flag is off. */
export function labForDisplay<T extends object | null>(lab: T, visible: boolean = isBioAgeKdmVisible()): T {
  if (lab == null || visible) return lab;
  return withNulls(lab as object, KDM_LAB_FIELDS) as T;
}

/** The profile without the cached KDM figure when the flag is off. */
export function profileForDisplay(profile: Profile | null, visible: boolean = isBioAgeKdmVisible()): Profile | null {
  if (profile == null || visible) return profile;
  return withNulls(profile, KDM_PROFILE_FIELDS);
}

/**
 * The line of the AI chat context about the biological age. With the flag off, the model is told there is none to
 * discuss, so it neither repeats a stored figure nor makes one up.
 */
export function chatBioAgeLine(biologicalAge: number | null | undefined, visible: boolean = isBioAgeKdmVisible()): string {
  if (!visible) return "Biological Age: not available to this client. Do not state, estimate or discuss a biological age figure.";
  return `Biological Age: ${biologicalAge ?? "not calculated"}`;
}
