/**
 * The Longevity Score engine scores stored values, and stored values are in
 * eva's canonical units (Echevarne's since 2026-09-17). These tests pin the
 * engine registry to those units — the 2026-09-21 audit found four markers
 * still in the old units (every hemogram and albumin scored critical) and the
 * neutrophil percentage fed in as if it were the NLR ratio. The score is
 * calculateLongevityScoreV2 on the reviewed rows, the only score: the last
 * block checks that the first score and the switch between the two are gone.
 */
import { describe, it, expect } from "vitest";
import { calculateLongevityScoreV2, SCORE_SPEC } from "./longevity-score";
import { signedRows } from "./__tests__/fixtures/reviewed-rows";
import { DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
import { getCanonicalUnit, unitsMatch } from "./canonical-units";
import { buildEngineInputs } from "./engine-inputs";
import { ECH_PANEL_ORDER_CODES } from "@/lib/lab-bridge/panel-codes";
import { EchevarneProvider } from "@/lib/lab-provider/echevarne";

const ROWS = signedRows();

/**
 * Registry unit per engine code, read through a probe value's MarkerScore on the reviewed rows, for the first
 * sex the score scores the code in (testosterone: men; estradiol: women). Null when it scores it in neither.
 */
function registryUnit(code: string): string | null {
  const probe = [
    { code: "APOB", value: 70 }, { code: "HBA1C", value: 5.2 }, { code: "GLUCOSE", value: 85 },
    { code: "HSCRP", value: 0.5 }, { code: "ALT", value: 20 }, { code: "RDW", value: 12 },
    { code: "HGB", value: 15 }, { code: "HDL_C", value: 55 }, { code: "TG", value: 80 },
    { code: "CREATININE", value: 0.9 }, { code: "ALBUMIN", value: 45 },
  ];
  if (!probe.some((p) => p.code === code)) probe.push({ code, value: 1 });
  for (const sex of ["male", "female"] as const) {
    const r = calculateLongevityScoreV2(probe, sex, 40, ROWS);
    const m = [...r.markerScores, ...r.suppressedMarkers].find((s) => s.code === code);
    if (m) return m.unit;
  }
  return null;
}

describe("Longevity Score registry — every scored marker is in eva's canonical unit", () => {
  const cases = Object.entries(DB_KEY_TO_ENGINE_CODE)
    .map(([key, code]) => ({ key, code, canonical: getCanonicalUnit(key) }))
    .filter((c) => c.canonical !== null);

  it("covers the mapped keys that exist in the seed", () => {
    expect(cases.length).toBeGreaterThan(30);
  });

  it("probes every one of them whose code the score specification names", () => {
    const named = cases.filter((c) => c.code in SCORE_SPEC.markers);
    expect(named.length).toBeGreaterThanOrEqual(16);
    expect(named.filter((c) => registryUnit(c.code) === null).map((c) => c.key)).toEqual([]);
    // A code the specification does not name is not read by the score.
    expect(cases.filter((c) => !(c.code in SCORE_SPEC.markers) && registryUnit(c.code) !== null).map((c) => c.key)).toEqual([]);
  });

  for (const c of cases) {
    it(`${c.key} → ${c.code}: registry unit matches the seed's ${c.canonical}`, () => {
      const unit = registryUnit(c.code);
      if (unit === null) return; // not scored (named by the test above): nothing to compare
      if (unit === "" && c.canonical === "ratio") return; // unitless ratios
      expect(unitsMatch(unit, c.canonical), `${c.code} registry '${unit}' vs seed '${c.canonical}'`).toBe(true);
    });
  }
});

describe("Longevity Score inputs — stored values reach the engine as the score reads them", () => {
  const healthy = [
    { biomarkerKey: "apolipoprotein_b_apob", value: 70 },
    { biomarkerKey: "hdl_cholesterol", value: 60 },
    { biomarkerKey: "triglycerides", value: 70 },
    { biomarkerKey: "hs_crp", value: 0.4 },
    { biomarkerKey: "alt", value: 18 },
    { biomarkerKey: "albumin", value: 45 }, // g/L
    { biomarkerKey: "creatinine", value: 0.9 },
    { biomarkerKey: "white_blood_cell_count", value: 5500 }, // raw cells/µL
    { biomarkerKey: "platelet_count", value: 250000 }, // raw cells/µL
    { biomarkerKey: "rdw", value: 12.5 },
    { biomarkerKey: "hemoglobin", value: 15 },
    { biomarkerKey: "hba1c", value: 5.0 },
    { biomarkerKey: "testosterone_total", value: 7.0 }, // ng/mL
    { biomarkerKey: "neutrophils", value: 58 }, // %
    { biomarkerKey: "lymphocytes", value: 32 }, // %
  ];

  it("NLR is the computed neutrophil/lymphocyte ratio, never the neutrophil percentage", () => {
    const inputs = buildEngineInputs(healthy);
    const nlr = inputs.find((i) => i.code === "NLR");
    expect(nlr?.value).toBeCloseTo(58 / 32, 2);
    expect(inputs.filter((i) => i.code === "NLR")).toHaveLength(1);
  });

  it("HOMA-IR reaches the engine from insulin_fasting + glucose_fasting", () => {
    const inputs = buildEngineInputs([{ biomarkerKey: "insulin_fasting", value: 5 }, { biomarkerKey: "glucose_fasting", value: 90 }]);
    expect(inputs.find((i) => i.code === "HOMA_IR")?.value).toBeCloseTo(1.11, 1);
  });

  it("folate, stored as folate_vitamin_b9, reaches the engine (C5)", () => {
    // The score reads it wherever folate has a reviewed row (longevity-score.reviewed.test.ts); the seed has none.
    const inputs = buildEngineInputs([...healthy, { biomarkerKey: "folate_vitamin_b9", value: 7.3 }]);
    expect(inputs).toContainEqual({ code: "FOLATE", value: 7.3 });
  });
});

describe("Longevity Score — the Base Panel (2026-09-22) under the coverage rule of score 2.0 (ruling D-04)", () => {
  it("the 13 ordered tests alone cover 3 of the 5 domains and give no score; with HbA1c they give one with nothing to spare", () => {
    // Order code → result code(s) → DB key → engine code, exactly as an ORU would arrive.
    const resultCodes: Record<string, string> = { ALBS: "B0020", FAL: "B0202", PCUL: "B0851", CR1: "B0003", BUN: "B0150", AU1: "B0025", COL: "B0001", HDLC: "B0017", TRIG: "B0004", APOB: "B0839", GPT: "B0005", GGT: "B0007", FRUC: "B0158" };
    const values: Record<string, number> = { albumin: 45, alp: 70, hs_crp: 0.5, creatinine: 0.9, bun: 14, uric_acid: 5, total_cholesterol: 180, hdl_cholesterol: 60, triglycerides: 70, apolipoprotein_b_apob: 70, alt: 18, ggt: 20, fructosamine: 190 };
    const rows = ECH_PANEL_ORDER_CODES.base.map((t) => {
      const key = EchevarneProvider.mapBiomarkerName(resultCodes[t.code]);
      expect(key, `${t.code} → ${resultCodes[t.code]} must map to a biomarker`).toBeTruthy();
      return { biomarkerKey: key!, value: values[key!] };
    });
    const inputs = buildEngineInputs(rows);
    const r = calculateLongevityScoreV2(inputs, "female", 42, ROWS);
    // No glycaemia marker that scores (fructosamine does not) and no blood count.
    expect(r.validation).toMatchObject({ valid: false, totalMarkers: 8, domainsCovered: 3, missingDomains: ["glycaemia", "blood_count"] });
    expect(r.markerScores).toEqual([]);
    expect(r.longevityScore).toBe(-1);
    const withHba1c = calculateLongevityScoreV2(buildEngineInputs([...rows, { biomarkerKey: "hba1c", value: 5.2 }]), "female", 42, ROWS);
    expect(withHba1c.validation).toMatchObject({ valid: true, totalMarkers: 9, domainsCovered: 4, missingDomains: ["blood_count"] });
    expect(withHba1c.markerScores.map((m) => m.code).sort()).toEqual(["ALBUMIN", "ALP", "APOB", "GGT", "HBA1C", "HDL_C", "HSCRP", "TG", "URIC_ACID"]);
    expect(withHba1c.longevityScore).toBe(100);
  });
});

describe("One score engine — the first score and the switch between the two are gone", () => {
  const GONE = ["calculateLongevityScore", "scoreLongevity", "longevityScoreVersion", "calculate"];

  it("longevity-score, biological-age and the biomarkers index export none of their entry points", async () => {
    const modules: Record<string, Record<string, unknown>> = {
      "longevity-score": await import("./longevity-score"),
      "biological-age": await import("./biological-age"),
      index: await import("./index"),
    };
    for (const [name, exports] of Object.entries(modules)) expect(GONE.filter((n) => n in exports), name).toEqual([]);
    // What remains is the one score, the same function wherever it is read from.
    expect(modules["longevity-score"].calculateLongevityScoreV2).toBeTypeOf("function");
    expect(modules["biological-age"].calculateLongevityScoreV2).toBe(modules["longevity-score"].calculateLongevityScoreV2);
    // The AI summary's ordering table is its own (src/lib/ai/ranking-tiers.ts): the score exports no tier.
    for (const [name, exports] of Object.entries(modules)) expect("BIOMARKER_TIER" in exports, name).toBe(false);
    const tiers = (await import("@/lib/ai/ranking-tiers")).BIOMARKER_TIER as Record<string, number>;
    expect([tiers.LYMPH_PCT, tiers.LYMPH_ABS, tiers.APOB]).toEqual([3, 3, 1]);
  });
});
