/**
 * processLabResults takes the lab's patient context (its supplements and physiological state) from its caller when
 * given (options.labState): reprocess and the lab bridge read it before deleting the lab's values (loadLabState), so a
 * read here, after the delete, cannot fail and leave the lab with none. Given or not, the creatine adjustment uses its
 * supplements. Not given, processLabResults and recomputeLabMetrics each read the lab's context once. Scripted
 * database (fake-supabase), no network.
 */
import { beforeAll, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { getCanonicalUnit } from "./canonical-units";
import { computeReferenceBA } from "./biological-age-kdm";
import { processLabResults, recomputeLabMetrics } from "./process-results";
import { LAB_STATE_CONTEXT_COLUMNS, LAB_STATE_LAB_COLUMNS, UNKNOWN_STATE } from "@/lib/patient-context/physiological-state";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});

const ROWS = reviewedRows();
const AGE = 45;
// The typical man's Base Panel, creatinine raised 13% by creatine, with HbA1c.
const VALUES: Record<string, number> = {
  albumin: 44, creatinine: 1.13, bun: 15, uric_acid: 6, alp: 72, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47,
  triglycerides: 140, hs_crp: 1.8, apolipoprotein_b_apob: 105, alt: 30, hba1c: 5.5,
};
const CREATINE_5G = [{ key: "creatine", dose: "5 g" }];
const asInputs = (values: Record<string, number>) => Object.entries(values).map(([code, value]) => ({ code, value }));
const raw = (values: Record<string, number>) =>
  Object.entries(values).map(([key, value]) => ({ name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const }));

/** The lab's recorded context declares creatine 5 g, or reading it fails. */
function database(contextRead: "fails" | "creatine") {
  const dob = `${new Date().getFullYear() - AGE}-01-01`;
  const updates: Array<Record<string, unknown>> = [];
  const respond = (c: FakeCall): FakeResponse => {
    const select = String(argsOf(c, "select")?.[0] ?? "");
    if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { date_of_birth: dob, sex: "male" } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "lab_results" && select === LAB_STATE_LAB_COLUMNS) {
      return contextRead === "fails"
        ? { error: { message: "connection reset" } }
        : { data: { patient_context_version_id: "v2", created_at: "2026-10-01T08:00:00Z" } };
    }
    if (c.table === "patient_context_versions") return { data: { id: "v2", supplements: CREATINE_5G } };
    // This lab's stored values (recomputeLabMetrics).
    if (c.table === "biomarker_values" && ops(c).startsWith("select")) {
      return { data: Object.entries(VALUES).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal", comparator: null })) };
    }
    if (c.table === "lab_results" && ops(c).startsWith("select")) return { data: [] }; // the dashboard: no ready lab
    if (c.table === "lab_results" && ops(c).startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      if ("optimal_count" in update) updates.push(update);
    }
    return { data: null };
  };
  const { client, calls } = fakeSupabase(respond);
  return { client, calls, updates };
}

// Processing's own read of the lab's context (loadLabState): the lab, then its context version. Version 3, in shadow,
// reads "conditions, supplements" itself, and the dashboard's rolling average reads every version.
const labReads = (calls: FakeCall[]) => calls.filter((c) => c.table === "lab_results" && argsOf(c, "select")?.[0] === LAB_STATE_LAB_COLUMNS).length;
const versionReads = (calls: FakeCall[]) =>
  calls.filter((c) => c.table === "patient_context_versions" && argsOf(c, "select")?.[0] === LAB_STATE_CONTEXT_COLUMNS).length;
const contextReads = (calls: FakeCall[]) => labReads(calls) + versionReads(calls);
const given = (supplements: typeof CREATINE_5G | null) => ({ labState: { supplements, state: UNKNOWN_STATE } });

describe("processLabResults with the lab's context given by its caller", () => {
  let adjusted: number;
  let unadjusted: number;
  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
    adjusted = computeReferenceBA(asInputs(VALUES), "male", AGE, { supplements: CREATINE_5G })!.BA;
    unadjusted = computeReferenceBA(asInputs(VALUES), "male", AGE, { supplements: null })!.BA;
    expect(adjusted).not.toBe(unadjusted);
  });

  it("given creatine 5 g: no read of its own, so a read that would fail does not stop it, and the figure is adjusted", async () => {
    const db = database("fails");
    await processLabResults("u1", "lab-1", raw(VALUES), db.client, given(CREATINE_5G));
    expect(contextReads(db.calls)).toBe(0);
    expect(db.updates[0].biological_age).toBe(adjusted);
  });

  it("given none (null) while the recorded context declares creatine: no read, no adjustment", async () => {
    const db = database("creatine");
    await processLabResults("u1", "lab-1", raw(VALUES), db.client, given(null));
    expect(contextReads(db.calls)).toBe(0);
    expect(db.updates[0].biological_age).toBe(unadjusted);
  });

  it("not given: the recorded context is read once and applied", async () => {
    const db = database("creatine");
    await processLabResults("u1", "lab-1", raw(VALUES), db.client);
    expect([labReads(db.calls), versionReads(db.calls)]).toEqual([1, 1]);
    expect(db.updates[0].biological_age).toBe(adjusted);
  });

  it("recomputeLabMetrics reads the recorded context once too, and applies it", async () => {
    const db = database("creatine");
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    expect([labReads(db.calls), versionReads(db.calls)]).toEqual([1, 1]);
    expect(db.updates[0].biological_age).toBe(adjusted);
  });

  it("recomputeLabMetrics with a context that cannot be read stores nothing", async () => {
    const db = database("fails");
    await expect(recomputeLabMetrics("u1", "lab-1", db.client as never)).rejects.toThrow(/connection reset/);
    expect(db.updates).toEqual([]);
  });
});
