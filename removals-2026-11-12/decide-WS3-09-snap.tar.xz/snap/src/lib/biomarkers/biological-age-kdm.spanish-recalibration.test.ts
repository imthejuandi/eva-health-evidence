/**
 * Spanish recalibration of log-transformed markers (fix of 2026-09-25).
 *
 * The recalibration moves each marker's baseline q by the ratio of the Spanish
 * to the NHANES population mean, on the clinical scale:
 * slope = mean_spain / mean_NHANES. For a linear marker q_spain = slope × q_NHANES.
 * For a log-transformed marker q is a log, so the same move adds ln(slope);
 * the library had slope × q_NHANES for both. Patched by
 * `scripts/fix_log_scale_q_spain.py`, which keeps the previous value in
 * `q_spain_log_fix.previous_q_spain`.
 *
 * Run: `npx vitest run src/lib/biomarkers/biological-age-kdm.spanish-recalibration.test.ts`
 */
import { describe, expect, it } from "vitest";
import {
  applyLifestyleAdjustments,
  computeComprehensiveBA,
  computeReferenceBA,
  deriveFructosamineIfMissing,
  klemeraDoubalBa,
  passesKdmGate,
  resolveKdmParams,
  resolveSCa,
  type SCaTier,
  type Sex,
} from "./biological-age-kdm";
import { kdmInputsFromBiomarkerValues } from "./kdm-adapter";
import library from "./data/marker_library_v2_2.json";

interface Block {
  slope: number;
  intercept: number;
  q_NHANES: number;
  q_spain: number;
  mean_NHANES?: number;
  mean_spain?: number;
  q_spain_log_fix?: { date: string; previous_q_spain: number; rule: string };
}
interface Entry {
  log_transformed?: boolean;
  sex_stratified?: boolean;
  kqs?: { k: number; q: number } | null;
  kqs_M?: { k: number; q: number } | null;
  kqs_F?: { k: number; q: number } | null;
  spanish_recalibration?: (Partial<Block> & { calibration_status?: string; per_sex?: Partial<Record<"M" | "F", Block | null>> | null }) | null;
}
interface Recalibrated {
  marker: string;
  sex: "M" | "F" | "pooled";
  log: boolean;
  block: Block;
  kqs: { k: number; q: number };
}

const MARKERS = (library as unknown as { markers: Record<string, Entry> }).markers;

/** Every recalibrated block that holds a q_spain (pooled, or one per sex). */
const BLOCKS: Recalibrated[] = Object.entries(MARKERS).flatMap(([marker, e]) => {
  const sr = e.spanish_recalibration;
  if (!sr?.calibration_status?.startsWith("recalibrated_")) return [];
  const pick = (sex: Recalibrated["sex"], block: Block | null | undefined, kqs: Entry["kqs"]): Recalibrated[] =>
    block && typeof block.q_spain === "number" && kqs ? [{ marker, sex, log: !!e.log_transformed, block, kqs }] : [];
  return e.sex_stratified
    ? [...pick("M", sr.per_sex?.M, e.kqs_M), ...pick("F", sr.per_sex?.F, e.kqs_F)]
    : pick("pooled", sr as Block, e.kqs);
});
const LOG = BLOCKS.filter((b) => b.log);
const LINEAR = BLOCKS.filter((b) => !b.log);
const label = (b: Recalibrated) => `${b.marker} [${b.sex}]`;

describe("Spanish recalibration — the method, on every recalibrated block", () => {
  it("covers 23 recalibrated blocks, 8 of them log-transformed", () => {
    expect(BLOCKS).toHaveLength(23);
    expect(LOG.map(label).sort()).toEqual([
      "GGT (Gamma-glutamil Transferasa) [F]",
      "GGT (Gamma-glutamil Transferasa) [M]",
      "Insulina (Ayunas) [pooled]",
      "PCR de Alta Sensibilidad (hs-PCR) [pooled]",
      "TSH [pooled]",
      "Testosterona Total [F]",
      "Testosterona Total [M]",
      "Triglicéridos [pooled]",
    ]);
  });

  it("q_NHANES is the library's own q; slope is mean_spain / mean_NHANES where the means are stored", () => {
    for (const b of BLOCKS) {
      expect(b.block.q_NHANES, label(b)).toBe(b.kqs.q);
      if (b.block.mean_spain !== undefined && b.block.mean_NHANES !== undefined) {
        expect(b.block.slope, label(b)).toBeCloseTo(b.block.mean_spain / b.block.mean_NHANES, 12);
      }
    }
  });

  it("linear markers: q_spain = slope × q_NHANES + intercept, as deployed (the method, reproduced)", () => {
    expect(LINEAR).toHaveLength(15);
    for (const b of LINEAR) {
      const { slope, intercept, q_NHANES, q_spain } = b.block;
      expect(Math.abs(slope * q_NHANES + intercept - q_spain), label(b)).toBeLessThanOrEqual(1e-12 * Math.max(1, Math.abs(q_spain)));
      expect(b.block.q_spain_log_fix, label(b)).toBeUndefined();
    }
  });

  it("log-transformed markers: q_spain = q_NHANES + ln(slope)", () => {
    for (const b of LOG) {
      const { slope, q_NHANES, q_spain } = b.block;
      expect(Math.abs(b.block.intercept), label(b)).toBeLessThan(1e-12);
      expect(q_spain, label(b)).toBeCloseTo(q_NHANES + Math.log(slope), 12);
    }
  });

  it("log-transformed markers keep the previous value, which was slope × q_NHANES + intercept", () => {
    for (const b of LOG) {
      const { slope, intercept, q_NHANES, q_spain_log_fix } = b.block;
      expect(q_spain_log_fix?.date, label(b)).toBe("2026-09-25");
      expect(q_spain_log_fix!.previous_q_spain, label(b)).toBeCloseTo(slope * q_NHANES + intercept, 12);
    }
    const tg = LOG.find((b) => b.marker === "Triglicéridos")!.block;
    expect(tg.q_spain_log_fix!.previous_q_spain).toBeCloseTo(3.3802, 4);
    expect(tg.q_spain).toBeCloseTo(4.2461, 4);
  });

  it("the Spanish typical level is the NHANES one times slope, at any age (the previous values were not)", () => {
    for (const b of LOG) {
      const { slope, q_NHANES, q_spain, q_spain_log_fix } = b.block;
      for (const age of [30, 50, 70]) {
        const nhanes = Math.exp(q_NHANES + b.kqs.k * age);
        expect(Math.exp(q_spain + b.kqs.k * age) / nhanes, label(b)).toBeCloseTo(slope, 12);
        const previous = Math.exp(q_spain_log_fix!.previous_q_spain + b.kqs.k * age) / nhanes;
        expect(Math.abs(previous - slope), label(b)).toBeGreaterThan(0.01);
      }
    }
    // Triglycerides at 50: NHANES typical 107 mg/dL; Spanish typical 80 (×0.744), previously 33.
    const tg = LOG.find((b) => b.marker === "Triglicéridos")!;
    expect(Math.exp(tg.block.q_spain + tg.kqs.k * 50)).toBeCloseTo(0.744 * Math.exp(tg.block.q_NHANES + tg.kqs.k * 50), 0);
    expect(Math.exp(tg.block.q_spain_log_fix!.previous_q_spain + tg.kqs.k * 50)).toBeLessThan(35);
  });
});

describe("Spanish recalibration — effect on the BA", () => {
  // The typical man and woman of scripts/kdm_explain_panels.ts (DB keys, engine units).
  const PANELS: Record<Sex, Record<string, number>> = {
    male: {
      albumin: 44, creatinine: 1.0, bun: 15, uric_acid: 6.0, alp: 72, ggt: 32, total_cholesterol: 205,
      hdl_cholesterol: 47, triglycerides: 140, hs_crp: 1.8, ferritin: 180, vitamin_d_25_oh: 24, tsh: 1.9, hba1c: 5.5,
      apolipoprotein_b_apob: 105, ldl_cholesterol: 130, glucose_fasting: 96, alt: 30, ast: 25, total_bilirubin: 0.7,
      hemoglobin: 15.2, hematocrit: 45, mcv: 90, rdw: 13.2, platelet_count: 240000, white_blood_cell_count: 6800,
      lymphocytes: 30, red_blood_cell_count: 5000000, egfr_creatinine_based: 95, vitamin_b12: 450, shbg: 35,
      testosterone_total: 4.8,
    },
    female: {
      albumin: 43, creatinine: 0.75, bun: 13, uric_acid: 4.5, alp: 65, ggt: 18, total_cholesterol: 200,
      hdl_cholesterol: 60, triglycerides: 95, hs_crp: 1.5, ferritin: 60, vitamin_d_25_oh: 24, tsh: 2.1, hba1c: 5.4,
      apolipoprotein_b_apob: 90, ldl_cholesterol: 121, glucose_fasting: 90, alt: 18, ast: 20, total_bilirubin: 0.5,
      hemoglobin: 13.4, hematocrit: 40, mcv: 89, rdw: 13.4, platelet_count: 260000, white_blood_cell_count: 6500,
      lymphocytes: 31, red_blood_cell_count: 4500000, egfr_creatinine_based: 100, vitamin_b12: 480, shbg: 60,
      testosterone_total: 0.3,
    },
  };
  const values = (sex: Sex) => Object.entries(PANELS[sex]).map(([code, value]) => ({ code, value }));
  const previousQ = (marker: string, sex: Sex) =>
    LOG.find((b) => b.marker === marker && (b.sex === "pooled" || b.sex === (sex === "male" ? "M" : "F")))?.block
      .q_spain_log_fix?.previous_q_spain;

  /** The BA with the previous log-scale Spanish q, rebuilt from the model's parts. */
  function previousBA(sex: Sex, age: number, tier: SCaTier): number {
    const adapted = kdmInputsFromBiomarkerValues(values(sex)).inputs;
    const inputs = applyLifestyleAdjustments(deriveFructosamineIfMissing(adapted), null);
    expect(passesKdmGate(inputs)).toBe(true);
    const { params, applied } = resolveKdmParams(inputs, sex, tier === "reference");
    for (const m of applied) {
      const q = previousQ(m, sex);
      if (q !== undefined) params[m] = { ...params[m], q };
    }
    return klemeraDoubalBa(inputs, params, age, true, resolveSCa(tier), sex)!.BA;
  }

  it("the estimator uses the corrected q for every log-transformed marker", () => {
    for (const sex of ["male", "female"] as Sex[]) {
      const inputs = Object.fromEntries(LOG.map((b) => [b.marker, 1]));
      const { params, applied } = resolveKdmParams(inputs, sex, false);
      for (const b of LOG.filter((x) => x.sex === "pooled" || x.sex === (sex === "male" ? "M" : "F"))) {
        expect(applied, label(b)).toContain(b.marker);
        expect(params[b.marker].q, label(b)).toBe(b.block.q_spain);
      }
    }
  });

  it("typical man and woman of 45: Reference BA 1.6 and 0.65 years lower than with the previous values", () => {
    const man = computeReferenceBA(values("male"), "male", 45)!.BA;
    const woman = computeReferenceBA(values("female"), "female", 45)!.BA;
    expect(previousBA("male", 45, "reference") - man).toBeCloseTo(1.62, 1);
    expect(previousBA("female", 45, "reference") - woman).toBeCloseTo(0.65, 1);
  });

  // The panels' laboratory eGFR no longer enters (30 October 2026, creatinine only), so each remaining marker,
  // total testosterone included, weighs more: the woman's change was 2.11 years with it.
  it("typical man and woman of 45: Comprehensive BA 0.16 higher and 2.7 years lower (total testosterone)", () => {
    const man = computeComprehensiveBA(values("male"), "male", 45)!.BA;
    const woman = computeComprehensiveBA(values("female"), "female", 45)!.BA;
    expect(previousBA("male", 45, "comprehensive") - man).toBeCloseTo(-0.16, 1);
    expect(previousBA("female", 45, "comprehensive") - woman).toBeCloseTo(2.7, 1);
  });
});
