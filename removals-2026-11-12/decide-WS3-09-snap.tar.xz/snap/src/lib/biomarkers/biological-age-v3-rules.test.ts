/**
 * The refusal and gating rules of biological age version 3 (`./biological-age-v3-rules.ts`, values in
 * `./data/ba_v3_rules.json`): the configuration itself (every value flagged for the physician, with a source; the
 * bounds pinned to their origins), the pure rule function, and every fixture of docs/signoff/work/v3/refusals.json run
 * through the adapter (`bioAgeV3Record`), the way acceptance check B2 runs them (scripts/signoff/checks/bioage.ts).
 */
import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { BA_V3_AGE_RANGE, BA_V3_EVA_UNITS, BA_V3_TIER_MARKERS, computeBiologicalAgeV3 } from "./biological-age-v3";
import {
  BA_V3_RULES,
  BA_V3_RULE_ORDER,
  BA_V3_SIGNED_AGE_RANGE,
  collectionMethodOf,
  evaluateBioAgeV3Rules,
  type BioAgeV3RuleInput,
  type BioAgeV3RuleMarker,
} from "./biological-age-v3-rules";
import {
  LACTATION_CONDITION,
  PREGNANCY_CONDITION,
  assembleBioAgeV3Inputs,
  bioAgeV3Record,
  resolvedValueOf,
  type BioAgeV3Record,
  type BioAgeV3Sources,
  type BioAgeV3ValueRow,
} from "./biological-age-v3-adapter";
import { CREATININE_PLAUSIBLE_MG_DL } from "./creatinine-plausibility";
import plausibilityBounds from "./data/plausibility_bounds.json";
import RULES_RAW from "./data/ba_v3_rules.json";
import { CONDITION_KEYS } from "@/lib/patient-context/options";

// ─── The fixtures' input format (scripts/signoff/checks/bioage.ts, ProbeInput and probeSources) ───

interface ProbeInput {
  values?: Record<string, number | string>;
  units?: Record<string, string>;
  comparators?: Record<string, "<" | ">">;
  age?: number;
  sex?: string | null;
  conditionKeys?: string[];
  collection_method?: string;
  labSource?: string | null;
}

interface Fixture {
  id: string;
  rule: string;
  rules_entry: string;
  input: ProbeInput;
  before: string;
  expect_reason: string | null;
  expect_provisional?: boolean;
  expect_bounded?: { key: string; comparator: "<" | ">"; value: number };
}

const NOW = new Date("2026-11-06T12:00:00Z");
const DRAW = "2026-11-01";
const HEALTHY_BASE: Record<string, number> = { albumin: 44, alp: 70, hs_crp: 1, creatinine: 0.9, bun: 14, ggt: 20 };
const EVA_UNITS: Record<string, string> = { albumin: "g/L", alp: "U/L", hs_crp: "mg/L", creatinine: "mg/dL", bun: "mg/dL", ggt: "U/L", hba1c: "%" };

/** The sources acceptance check B2 builds for a fixture (bioage.ts probeSources). */
function probeSources(p: ProbeInput): BioAgeV3Sources {
  const values: BioAgeV3ValueRow[] = Object.entries({ ...HEALTHY_BASE, ...(p.values ?? {}) })
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => ({ biomarker_key: k, value: v, unit: p.units?.[k] ?? EVA_UNITS[k] ?? null, comparator: p.comparators?.[k] ?? null }));
  return {
    values,
    drawDate: DRAW,
    otherResults: [],
    dateOfBirth: `${2026 - (p.age ?? 50)}-01-15`,
    sex: p.sex === undefined ? "male" : p.sex,
    conditionKeys: p.conditionKeys ?? [],
    supplements: null,
    now: NOW,
    labSource: p.labSource === undefined ? "echevarne" : p.labSource,
    ...(p.collection_method ? { collectionMethod: p.collection_method } : {}),
  };
}

const probe = (p: ProbeInput): BioAgeV3Record => bioAgeV3Record(probeSources(p));
const VENOUS: ProbeInput = { collection_method: "venous" };

const FIXTURE_FILE = path.resolve(__dirname, "../../../docs/signoff/work/v3/refusals.json");
const FIXTURES = (JSON.parse(fs.readFileSync(FIXTURE_FILE, "utf8")) as { fixtures: Fixture[] }).fixtures;

// ─── The configuration ───

/** Every object in the rules file that carries a clinical value: it must be flagged and sourced. */
function flaggedEntries(node: unknown, at: string, out: Array<{ at: string; entry: Record<string, unknown> }> = []) {
  if (node === null || typeof node !== "object" || Array.isArray(node)) return out;
  const o = node as Record<string, unknown>;
  if ("pending_physician_confirmation" in o) out.push({ at, entry: o });
  for (const [k, v] of Object.entries(o)) flaggedEntries(v, `${at}.${k}`, out);
  return out;
}

describe("ba_v3_rules.json: values for the physician, each flagged and sourced", () => {
  it("every rule and value is pending physician confirmation and names its source", () => {
    const entries = flaggedEntries(RULES_RAW, "rules");
    expect(entries.length).toBeGreaterThanOrEqual(20);
    for (const { at, entry } of entries) {
      expect(entry.pending_physician_confirmation, at).toBe(true);
      if (at.split(".").length <= 3 || "value" in entry || "lower" in entry || "male" in entry) {
        expect(typeof entry.source === "string" && entry.source.length > 10, `${at} source`).toBe(true);
      }
    }
    // The rules every reason code comes from are each flagged.
    for (const at of [
      "rules.plausibility.markers.albumin", "rules.kidney", "rules.albumin_low", "rules.hs_crp.provisional_above",
      "rules.hs_crp.refuse_above", "rules.liver_enzymes", "rules.states.pregnancy", "rules.states.lactation", "rules.age",
      "rules.sex", "rules.collection_method",
    ]) {
      expect(entries.some((e) => e.at === at), at).toBe(true);
    }
  });

  it("plausibility covers the six Base markers and HbA1c, in the model's units", () => {
    expect(Object.keys(BA_V3_RULES.plausibility.markers).sort()).toEqual([...BA_V3_TIER_MARKERS.plus_hba1c].sort());
    for (const [key, b] of Object.entries(BA_V3_RULES.plausibility.markers)) {
      expect(b.unit, key).toBe(BA_V3_EVA_UNITS[key]);
      expect(b.lower, key).toBeLessThan(b.upper);
    }
  });

  it("plausibility bounds are plausibility_bounds.json's (Tietz), albumin lowered to 10 g/L so 4.3 g/L is refused", () => {
    const name: Record<string, string> = {
      alp: "ALP (Fosfatasa Alcalina)",
      hs_crp: "PCR de Alta Sensibilidad (hs-PCR)",
      creatinine: "Creatinina",
      bun: "BUN (Nitrógeno Ureico en Sangre)",
      ggt: "GGT (Gamma-glutamil Transferasa)",
      hba1c: "HbA1c (Hemoglobina Glicosilada)",
    };
    const markers = (plausibilityBounds as unknown as { markers: Record<string, { lower: number; upper: number }> }).markers;
    for (const [key, n] of Object.entries(name)) {
      expect(BA_V3_RULES.plausibility.markers[key].lower, key).toBe(markers[n].lower);
      expect(BA_V3_RULES.plausibility.markers[key].upper, key).toBe(markers[n].upper);
    }
    // Albumin: 1.5 to 6.0 g/dL in the bounds file; the ceiling is the same 60 g/L, the floor 10 g/L.
    expect(markers["Albúmina"].upper * 10).toBe(BA_V3_RULES.plausibility.markers.albumin.upper);
    expect(BA_V3_RULES.plausibility.markers.albumin).toMatchObject({ lower: 10, upper: 60, unit: "g/L" });
  });

  it("creatinine's bounds equal the lab page's rule (creatinine-plausibility.ts)", () => {
    expect(BA_V3_RULES.plausibility.markers.creatinine).toMatchObject(CREATININE_PLAUSIBLE_MG_DL);
  });

  it("the signed age range is 20 to 79 and lies within the model's 20 to 84", () => {
    expect(BA_V3_SIGNED_AGE_RANGE).toEqual({ min: 20, max: 79 });
    expect(BA_V3_SIGNED_AGE_RANGE.min).toBeGreaterThanOrEqual(BA_V3_AGE_RANGE.min);
    expect(BA_V3_SIGNED_AGE_RANGE.max).toBeLessThanOrEqual(BA_V3_AGE_RANGE.max);
  });

  it("the condition keys exist in the patient context form, and match the adapter's", () => {
    const keys = new Set<string>(CONDITION_KEYS as readonly string[]);
    for (const k of [
      ...BA_V3_RULES.states.pregnancy.condition_keys,
      ...BA_V3_RULES.states.lactation.condition_keys,
      ...BA_V3_RULES.kidney.declared_kidney_disease.condition_keys,
    ]) {
      expect(keys.has(k), k).toBe(true);
    }
    expect(BA_V3_RULES.states.pregnancy.condition_keys).toContain(PREGNANCY_CONDITION);
    expect(BA_V3_RULES.states.lactation.condition_keys).toContain(LACTATION_CONDITION);
  });

  it("the evaluation order in the file is the one the code applies", () => {
    const order = (RULES_RAW as { meta: { evaluation_order: string[] } }).meta.evaluation_order.filter((c) => !c.includes(" "));
    expect(order).toEqual([...BA_V3_RULE_ORDER]);
  });
});

// ─── The pure function ───

const m = (key: string, value: number, more: Partial<BioAgeV3RuleMarker> = {}): BioAgeV3RuleMarker => ({
  key,
  value,
  unit: EVA_UNITS[key],
  comparator: null,
  normal_high: null,
  ...more,
});
const HEALTHY_MARKERS = Object.entries(HEALTHY_BASE).map(([k, v]) => m(k, v));

function input(over: Partial<BioAgeV3RuleInput> = {}, markers: BioAgeV3RuleMarker[] = []): BioAgeV3RuleInput {
  const keys = new Set(markers.map((x) => x.key));
  return {
    markers: [...HEALTHY_MARKERS.filter((x) => !keys.has(x.key)), ...markers],
    sex: "male",
    age: 50,
    context: { conditions: [] },
    collection: { method: "venous", fromEvaLaboratory: true },
    ...over,
  };
}
const codes = (i: BioAgeV3RuleInput) => evaluateBioAgeV3Rules(i).reasons.map((r) => r.code);

describe("evaluateBioAgeV3Rules", () => {
  it("a healthy venous draw at EVA's laboratory is eligible, not provisional", () => {
    expect(evaluateBioAgeV3Rules(input())).toEqual({ eligible: true, reasons: [], provisional: false, collection_method: "venous" });
  });

  it("plausibility: inclusive bounds; the bound itself is judged (hs-CRP '<0.05' is a real result)", () => {
    for (const [key, b] of Object.entries(BA_V3_RULES.plausibility.markers)) {
      expect(codes(input({}, [m(key, b.lower)])), `${key} at ${b.lower}`).not.toContain("implausible_value");
      expect(codes(input({}, [m(key, b.upper)])), `${key} at ${b.upper}`).not.toContain("implausible_value");
      expect(codes(input({}, [m(key, b.lower * 0.99)])), `${key} below`).toContain("implausible_value");
      expect(codes(input({}, [m(key, b.upper * 1.01)])), `${key} above`).toContain("implausible_value");
    }
    expect(codes(input({}, [m("hs_crp", 0.05, { comparator: "<" })]))).toEqual([]);
  });

  it("a marker in another unit, or not a number, is left to the model", () => {
    expect(codes(input({}, [m("albumin", 4.3, { unit: "g/dL" })]))).toEqual([]);
    expect(codes(input({}, [m("albumin", NaN)]))).toEqual([]);
  });

  it("kidney: creatinine above the row's own upper limit, else the sex fallback; at the limit is not above", () => {
    expect(codes(input({}, [m("creatinine", 1.2, { normal_high: 1.1 })]))).toEqual(["kidney"]);
    expect(codes(input({}, [m("creatinine", 1.2, { normal_high: 1.2 })]))).toEqual([]);
    expect(codes(input({}, [m("creatinine", 1.3)]))).toEqual([]);
    expect(codes(input({}, [m("creatinine", 1.31)]))).toEqual(["kidney"]);
    expect(codes(input({ sex: "female" }, [m("creatinine", 1.02)]))).toEqual([]);
    expect(codes(input({ sex: "Female" }, [m("creatinine", 1.03)]))).toEqual(["kidney"]);
    expect(codes(input({}, [m("creatinine", 1.3, { comparator: ">" })]))).toEqual(["kidney"]);
    expect(codes(input({}, [m("creatinine", 1.3, { comparator: "<" })]))).toEqual([]);
    expect(codes(input({ context: { conditions: ["ckd"] } }))).toEqual(["kidney"]);
    // An implausible creatinine is reported as implausible, not as kidney.
    expect(codes(input({}, [m("creatinine", 88.4)]))).toEqual(["implausible_value"]);
  });

  it("albumin below 30 g/L; 30 is not below; a '<30' bound is", () => {
    expect(codes(input({}, [m("albumin", 29.9)]))).toEqual(["albumin_low"]);
    expect(codes(input({}, [m("albumin", 30)]))).toEqual([]);
    expect(codes(input({}, [m("albumin", 30, { comparator: "<" })]))).toEqual(["albumin_low"]);
    expect(codes(input({}, [m("albumin", 4.3)]))).toEqual(["implausible_value", "albumin_low"]);
  });

  it("hs-CRP: above 10 provisional, above 50 refused; a '>' bound at a limit counts as above", () => {
    expect(evaluateBioAgeV3Rules(input({}, [m("hs_crp", 10)]))).toMatchObject({ eligible: true, provisional: false });
    expect(evaluateBioAgeV3Rules(input({}, [m("hs_crp", 10, { comparator: ">" })]))).toMatchObject({ eligible: true, provisional: true });
    expect(evaluateBioAgeV3Rules(input({}, [m("hs_crp", 10.1)]))).toMatchObject({ eligible: true, provisional: true });
    expect(evaluateBioAgeV3Rules(input({}, [m("hs_crp", 50)]))).toMatchObject({ eligible: true, provisional: true });
    expect(codes(input({}, [m("hs_crp", 50.1)]))).toEqual(["crp_above_limit"]);
    expect(codes(input({}, [m("hs_crp", 50, { comparator: ">" })]))).toEqual(["crp_above_limit"]);
  });

  it("ALP and GGT above the multiple of the upper limit (row's own, else the sex fallback)", () => {
    const k = BA_V3_RULES.liver_enzymes.multiple_of_upper_reference_limit;
    expect(k).toBe(3);
    expect(codes(input({}, [m("alp", 3 * 129)]))).toEqual([]);
    expect(codes(input({}, [m("alp", 3 * 129 + 1)]))).toEqual(["alp_above_limit"]);
    expect(codes(input({}, [m("alp", 301, { normal_high: 100 })]))).toEqual(["alp_above_limit"]);
    expect(codes(input({ sex: "female" }, [m("ggt", 3 * 38)]))).toEqual([]);
    expect(codes(input({ sex: "female" }, [m("ggt", 3 * 38 + 1)]))).toEqual(["ggt_above_limit"]);
    expect(codes(input({}, [m("ggt", 219, { comparator: ">" })]))).toEqual(["ggt_above_limit"]);
  });

  it("states, sex, age and collection method", () => {
    expect(codes(input({ context: { conditions: [PREGNANCY_CONDITION] } }))).toEqual(["pregnancy"]);
    expect(codes(input({ context: { conditions: [], pregnant: true } }))).toEqual(["pregnancy"]);
    expect(codes(input({ context: { conditions: [LACTATION_CONDITION] } }))).toEqual(["lactation"]);
    expect(codes(input({ context: { conditions: [], lactating: true } }))).toEqual(["lactation"]);
    for (const sex of [null, undefined, "", "f", "other"]) expect(codes(input({ sex })), String(sex)).toEqual(["sex_unknown"]);
    expect(codes(input({ age: NaN }))).toEqual(["age_unknown"]);
    for (const age of [19, 80, 82, 84, 85]) expect(codes(input({ age })), String(age)).toEqual(["age_outside_signed_range"]);
    for (const age of [20, 79]) expect(codes(input({ age })), String(age)).toEqual([]);
    for (const method of [null, undefined, "", "  ", "capillary", "unknown", "dried blood spot"]) {
      expect(codes(input({ collection: { method, fromEvaLaboratory: true } })), String(method)).toEqual(["collection_method"]);
    }
    expect(codes(input({ collection: { method: " Venous ", fromEvaLaboratory: true } }))).toEqual([]);
    expect(codes(input({ collection: { method: "venous", fromEvaLaboratory: false } }))).toEqual(["collection_method"]);
    expect(collectionMethodOf(undefined)).toBe("unknown");
  });

  it("every rule that holds is listed, in the configured order; the input is not modified", () => {
    const i = input(
      { sex: null, age: 82, context: { conditions: ["ckd", LACTATION_CONDITION, PREGNANCY_CONDITION] }, collection: { method: null, fromEvaLaboratory: false } },
      [m("albumin", 25), m("hs_crp", 60), m("alp", 2000), m("ggt", 500)],
    );
    const copy = JSON.parse(JSON.stringify(i));
    const out = evaluateBioAgeV3Rules(i);
    expect(out.eligible).toBe(false);
    expect(out.reasons.map((r) => r.code)).toEqual([
      "pregnancy", "lactation", "sex_unknown", "age_outside_signed_range", "collection_method", "implausible_value", "kidney",
      "albumin_low", "crp_above_limit",
      // GGT 500 is above 3 x 73 only with a sex; without one there is no fallback limit (sex_unknown already refuses).
    ]);
    expect(out.reasons.find((r) => r.code === "implausible_value")).toMatchObject({ marker: "alp" });
    expect(JSON.parse(JSON.stringify(i))).toEqual(copy);
    for (const r of out.reasons) expect(r.detail.length).toBeGreaterThan(5);
  });
});

// ─── Bounded results in the adapter ───

describe("bounded results: the bound itself, never half of it", () => {
  it("resolvedValueOf: stored comparator with its bound, or a value that still carries its prefix", () => {
    expect(resolvedValueOf({ value: 5, comparator: "<" })).toEqual({ value: 5, comparator: "<" });
    expect(resolvedValueOf({ value: "5", comparator: "<" })).toEqual({ value: 5, comparator: "<" });
    expect(resolvedValueOf({ value: "<5", comparator: null })).toEqual({ value: 5, comparator: "<" });
    expect(resolvedValueOf({ value: "< 0,500", comparator: null })).toEqual({ value: 0.5, comparator: "<" });
    expect(resolvedValueOf({ value: ">8.0" })).toEqual({ value: 8, comparator: ">" });
    expect(resolvedValueOf({ value: 4.2, comparator: null })).toEqual({ value: 4.2, comparator: null });
    expect(resolvedValueOf({ value: "<", comparator: null }).value).toBeNaN();
  });

  it("GGT '<5' resolves to 5: the module reads 5, the record lists the bound, and the figure is the one for 5", () => {
    const s = probeSources({ ...VENOUS, values: { ggt: "<5" } });
    expect(assembleBioAgeV3Inputs(s).inputs.find((i) => i.code === "ggt")).toEqual({ code: "ggt", value: 5, unit: "U/L" });
    const record = bioAgeV3Record(s);
    expect(record.bounded_markers).toEqual([{ key: "ggt", comparator: "<", value: 5 }]);
    const at5 = computeBiologicalAgeV3(
      Object.entries({ ...HEALTHY_BASE, ggt: 5 }).map(([code, value]) => ({ code, value, unit: EVA_UNITS[code] })),
      "male",
      50,
    );
    expect(record.ba).toBe(at5.ba);
    const atHalf = computeBiologicalAgeV3(
      Object.entries({ ...HEALTHY_BASE, ggt: 2.5 }).map(([code, value]) => ({ code, value, unit: EVA_UNITS[code] })),
      "male",
      50,
    );
    expect(record.ba).not.toBe(atHalf.ba);
  });
});

// ─── The fixtures, through the adapter ───

describe("docs/signoff/work/v3/refusals.json: every fixture through the adapter", () => {
  it("covers every reason code, with passing controls", () => {
    const reasons = new Set(FIXTURES.map((f) => f.expect_reason));
    for (const code of BA_V3_RULE_ORDER.filter((c) => c !== "age_unknown")) expect(reasons.has(code), code).toBe(true);
    expect(reasons.has("unit_mismatch")).toBe(true);
    expect(FIXTURES.filter((f) => f.expect_reason === null).length).toBeGreaterThanOrEqual(10);
    expect(new Set(FIXTURES.map((f) => f.id)).size).toBe(FIXTURES.length);
  });

  it.each(FIXTURES.map((f) => [f.id, f] as const))("%s", (_id, f) => {
    const record = probe(f.input);
    expect(record.reason).toBe(f.expect_reason);
    if (f.expect_reason === null) {
      expect(record.ba).toEqual(expect.any(Number));
      expect(record.reasons).toEqual([]);
      expect(record.provisional).toBe(f.expect_provisional ?? false);
    } else {
      expect(record.ba).toBeNull();
      expect(record.tier).toBeNull();
      expect(record.reasons[0].code).toBe(f.expect_reason);
    }
    if (f.expect_bounded) expect(record.bounded_markers).toContainEqual(f.expect_bounded);
  });

  it("each refusal rule had a fixture that gave a figure before the change (B2's pass rule)", () => {
    const gaveBefore = new Set(FIXTURES.filter((f) => f.expect_reason !== null && f.before.startsWith("ba ")).map((f) => f.expect_reason));
    for (const code of [
      "implausible_value", "kidney", "albumin_low", "crp_above_limit", "alp_above_limit", "ggt_above_limit", "lactation",
      "age_outside_signed_range", "collection_method",
    ]) {
      expect(gaveBefore.has(code), code).toBe(true);
    }
  });
});

describe("the cases the sign-off names", () => {
  const refused = (p: ProbeInput, code: string) => {
    const r = probe({ ...VENOUS, ...p });
    expect(r.ba).toBeNull();
    expect(r.reasons.map((x) => x.code)).toContain(code);
    return r;
  };

  it("albumin 0 g/L and 4.3 g/L: refused", () => {
    expect(refused({ values: { albumin: 0 } }, "implausible_value").reason).toBe("implausible_value");
    const r = refused({ values: { albumin: 4.3 } }, "implausible_value");
    expect(r.reasons.map((x) => x.code)).toEqual(["implausible_value", "albumin_low"]);
  });

  it("creatinine 2.0 mg/dL in a man: refused, kidney", () => {
    expect(refused({ values: { creatinine: 2.0 } }, "kidney").reason).toBe("kidney");
  });

  it("creatinine above the limit in a creatine user: still refused (the measured value is judged)", () => {
    const s = { ...probeSources({ ...VENOUS, values: { creatinine: 1.4 } }), supplements: [{ key: "creatine", dose: "5 g" }] };
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, reason: "kidney", creatine_g_per_day: 5 });
  });

  it("the person's own creatinine row's upper limit is used when stored", () => {
    const s = probeSources({ ...VENOUS, values: { creatinine: 1.2 } });
    const withLimit = { ...s, values: s.values.map((r) => (r.biomarker_key === "creatinine" ? { ...r, normal_high: 1.1 } : r)) };
    expect(bioAgeV3Record(s).ba).toEqual(expect.any(Number));
    expect(bioAgeV3Record(withLimit)).toMatchObject({ ba: null, reason: "kidney" });
  });

  it("hs-CRP 60 mg/L: refused", () => {
    expect(refused({ values: { hs_crp: 60 } }, "crp_above_limit").reason).toBe("crp_above_limit");
  });

  it("age 82: refused", () => {
    expect(refused({ age: 82 }, "age_outside_signed_range").reason).toBe("age_outside_signed_range");
  });

  it("pregnancy and lactation: refused, nothing else recorded", () => {
    const p = refused({ sex: "female", conditionKeys: [PREGNANCY_CONDITION] }, "pregnancy");
    expect(p).toMatchObject({ reason: "pregnancy", hba1c_source: null, bounded_markers: [] });
    expect(refused({ sex: "female", conditionKeys: [LACTATION_CONDITION] }, "lactation").reason).toBe("lactation");
  });

  it("collection method unknown: refused", () => {
    const r = probe({});
    expect(r).toMatchObject({ ba: null, reason: "collection_method", collection_method: "unknown" });
    expect(probe({ collection_method: "capillary", labSource: "home_kit" })).toMatchObject({ ba: null, reason: "collection_method" });
  });

  it("GGT '<5' resolves to 5", () => {
    const r = probe({ ...VENOUS, values: { ggt: "<5" } });
    expect(r.ba).toEqual(expect.any(Number));
    expect(r.bounded_markers).toEqual([{ key: "ggt", comparator: "<", value: 5 }]);
  });

  it("hs-CRP 30 mg/L: a provisional figure", () => {
    expect(probe({ ...VENOUS, values: { hs_crp: 30 } })).toMatchObject({ ba: expect.any(Number), provisional: true, crp_capped: true });
  });
});
