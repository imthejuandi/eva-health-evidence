/**
 * Biological age v3 in shadow mode: from the app's stored values for one lab result (and the client's other recent
 * results) to the inputs of the frozen model (`computeBiologicalAgeV3`, `./biological-age-v3.ts`), and the record
 * stored for it in `bio_age_v3_shadow`.
 *
 * SHADOW MODE. Whenever processing computes the live biological age (KDM v2.2, `processLabResults` and
 * `recomputeLabMetrics` in `./process-results.ts`), it then computes version 3 with this adapter and upserts the
 * record into `bio_age_v3_shadow` (one row per lab result; migration 20261001090000_bio_age_v3_shadow.sql) with the
 * service-role client. Only the service role can read that table: nothing displays, emails or returns the record,
 * and no client can read it. It feeds the side-by-side comparison of the two methods before any switch
 * (ml/biological-age/PROPOSAL.md, condition 4). process-results loads this module lazily, after the KDM values are
 * written, and catches every failure, so version 3 can never change them or stop a result from being processed.
 *
 * --- Refusal and gating rules --- (biological-age-v3-rules.ts; every value in data/ba_v3_rules.json, pending
 *   physician confirmation; acceptance check B2, fixtures docs/signoff/work/v3/refusals.json)
 *   Before the module is run, `evaluateBioAgeV3Rules` reads what the module would receive (creatinine as measured,
 *   before the creatine divisor; bounds resolved), the upper reference limit stored with each row (`normal_high`),
 *   sex, age at the draw, the patient context (the context this result is read under: its snapshot, else the latest
 *   version created on or before it; patient-context/lab-context.ts) and the collection method. Any rule that holds
 *   gives no figure: `ba` null, every rule that holds listed in `reasons` ({ code, marker?, detail }) and the first in
 *   `reason`. The rules: declared pregnancy or lactation; sex not male or female; age unknown or outside the signed
 *   range (20 to 79); a collection method other than venous at EVA's laboratory (the app records no method yet, so
 *   `collectionMethod` is null, "unknown", which counts as not venous: no result is eligible until it is recorded);
 *   a value outside its plausibility range (all six Base markers and HbA1c); creatinine above the row's upper
 *   reference limit or declared chronic kidney disease (`kidney`); albumin below 30 g/L; hs-CRP above 50 mg/L; ALP
 *   or GGT above 3 x the upper reference limit. hs-CRP above 10 mg/L makes a figure `provisional`. Then the model's
 *   own refusals (unit_mismatch, duplicate_marker, missing_markers, invalid_value), listed the same way. During
 *   pregnancy or lactation nothing else is recorded (no HbA1c source, no bounds).
 *   - Base markers (albumin, ALP, hs-CRP, creatinine, BUN, GGT) come from this lab result only.
 *   - Creatine. Creatinine is divided by the declared creatine dose's divisor (supplements.ts,
 *     `creatineCreatinineDivisor`: 1 + 0.13 x min(g/day, 3) / 3, EVA's ratio form of the pooled trial rise; KDM
 *     v2.2 applies the same rule), before the module takes its logarithm and applies its bounds. The dose is read
 *     from the same context as pregnancy. No dose, or one that cannot be read as grams a day: unchanged. Recorded
 *     as `creatine_g_per_day` and `creatinine_divisor`.
 *   - Creatinine plausibility. Creatinine in mg/dL outside 0.2 to 15 mg/dL (creatinine-plausibility.ts) is a unit
 *     or extraction error: no creatinine row of the result is given to the module, so no biological age, `reason`
 *     "implausible_value". The same result listed twice is given once; two creatinine values that are not the same
 *     result are both given, and the module refuses them (`duplicate_marker`).
 *   - Units. Each value is labelled with the app's canonical unit for its key (canonical-units.getCanonicalUnit),
 *     the unit processing stores every value in (its canonical-unit gate; a row stored without a unit is in it
 *     too). The module accepts a marker only in its EVA unit, and today the canonical unit is that unit for all
 *     seven markers (pinned by the adapter tests), so none is converted. A row whose own unit is another one is
 *     passed with that unit and the module refuses it (`unit_mismatch`): nothing is converted by guess.
 *   - BUN. When this result has no `bun` row and has `urea` in mg/dL, BUN = urea x UREA_TO_BUN_FACTOR (0.4665,
 *     kdm-adapter.ts, the factor KDM v2.2 uses). Urea in another unit is not converted.
 *   - HbA1c, source. This result's HbA1c; else that of the client's other result drawn closest to this draw
 *     (`collection_date`), before or after it, within 90 days, among results that are `ready` or
 *     `pending_context`; at equal distance, the one stored last. Without a draw date on this result, only its own
 *     HbA1c can be used.
 *   - HbA1c, units. % as stored; mmol/mol converted with the IFCC-NGSP master equation exactly as
 *     docs/biomarker-evidence/research/hba1c.json quotes it: % = mmol/mol / 10.929 + 2.15. Any other unit: not
 *     used (`unit_not_convertible`).
 *   - HbA1c exclusions (docs/biomarker-evidence/longevity/base-panel/ASSESSMENT.md, "Fructosamine or HbA1c"). The
 *     HbA1c found is not used, and the module falls back to the Base tier, when recent results (this one and the
 *     client's other results drawn within 90 days of it) show anaemia (haemoglobin below the reference lower limit
 *     stored with it), iron deficiency (ferritin below its stored lower limit) or eGFR below 30 (the stored
 *     `egfr_creatinine_based`, lab-reported and assumed CKD-EPI 2021; the app computes no eGFR, so this is checked
 *     only where the laboratory reports eGFR). The first that holds is recorded, in that order. The app records no
 *     haemoglobin variant and no transfusion, so those two exclusions cannot be applied. (Pregnancy, the
 *     assessment's fifth, stops the whole computation: see above.)
 *   - Bounded results ("<0.5"). Stored with `comparator`, `value` being the bound (lab-provider/hl7.ts
 *     parseHl7Value; process-results stores the bound and its comparator); a value that still carries its prefix
 *     ("<5") is read the same way. The bound itself is used, never half of it, and every value given to the module
 *     that was a bound is listed in `bounded_markers`. In the exclusions and the rules a "<" bound at a lower limit
 *     counts as below it, a ">" bound at an upper limit as above it.
 *   - hs-CRP above 10 mg/L. The module caps it and sets `crpCapped`; the record is then `provisional`.
 *   - Age: completed years at the draw (`collection_date`), with zone-classifier.calculateAge's arithmetic; when
 *     the result has no draw date, completed years when computed (the age KDM v2.2 uses). Sex: `profiles.sex` as
 *     stored; the module reads "male" or "female" in any case and refuses anything else (no default sex).
 *   - Laboratory. PROPOSAL.md: "Base Panel tests from another laboratory ... do not enter the age". A result not
 *     analysed at EVA's laboratory gives no figure (the collection-method rule above). `lab_source` is this result's
 *     `lab_results.source` as stored (null when the row cannot be read), and `base_from_eva_laboratory` is true only
 *     when that source is one of EVA_LABORATORY_SOURCES (compared exactly, as the writers store them). Which sources
 *     mean EVA's own laboratory (Echevarne), from the code that writes them:
 *       - "echevarne": src/lib/lab-bridge/store.ts `recordResults` inserts it (panel_type "lab_partner") for the ORU
 *         Echevarne returns, over the SFTP bridge, for the order (OML) EVA placed for the client's kit
 *         (src/lib/lab-bridge/sync.ts, src/lib/lab-provider/echevarne.ts). /api/lab-results/webhook would also write
 *         the provider's name, but answers an Echevarne result with 501 before inserting anything.
 *       - "lab_partner": /api/admin/enter-results inserts it (panel_type "base") from the admin form whose fields are
 *         "the 13 tests Echevarne runs on one serum tube, in the lab's units" (admin-client.tsx BASE_BIOMARKERS).
 *     Not EVA's laboratory: "upload" (/api/lab-results/extract) and "user_upload" (/api/lab-results/confirm, and the
 *     column default), the client's own uploads from any laboratory; "manual" (/api/lab-results/webhook with
 *     X-Provider manual), a JSON form whose payload names no laboratory. The UI also labels "eva_kit" and "eva" as
 *     EVA's (SourceTag.tsx, TrendChart.tsx, labs-client.tsx, detail-client.tsx, manage-client.tsx, admin-client.tsx),
 *     but no code writes either (docs/audit/2026-09-21-auditoria-final-integracion-echevarne.md, F34), so nothing
 *     shows which laboratory measured such a row: they are not counted.
 *
 * The rules are pure functions of the sources (`bioAgeV3Record`); `loadBioAgeV3Sources` reads them from the
 * database and is the only I/O here.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import {
  BA_V3_MODEL_SHA256,
  BA_V3_TIER_MARKERS,
  computeBiologicalAgeV3,
  type BiologicalAgeV3Clamp,
  type BiologicalAgeV3NullReason,
  type BiologicalAgeV3Tier,
  type BiomarkerV3Input,
} from "./biological-age-v3";
import { getCanonicalUnit, normalizeUnit } from "./canonical-units";
import { glycationExclusion, numberOf, resolvedValueOf, HBA1C_EGFR_LIMIT, type GlycationExclusion } from "./glycation-exclusion";

export { HBA1C_EGFR_LIMIT, resolvedValueOf };
import { UREA_TO_BUN_FACTOR } from "./kdm-adapter";
import { isPlausibleCreatinineMgDl, labCreatinineReadable } from "./creatinine-plausibility";
import { creatineCreatinineDivisor, creatineDoseGramsPerDay, type SupplementEntry } from "./supplements";
import { loadLabContext, type LabContextRef } from "@/lib/patient-context/lab-context";
import { parseDateOfBirth } from "./zone-classifier";
import {
  BA_V3_RULES_VERSION,
  evaluateBioAgeV3Rules,
  type BioAgeV3RuleCode,
  type BioAgeV3RuleMarker,
} from "./biological-age-v3-rules";

// ─── Constants ───

/** Version of these rules, stored in every record. Bump it whenever a rule here changes a record. */
export const BIO_AGE_V3_ADAPTER_VERSION = "1.3.0"; // 1.1.0: lab_source and base_from_eva_laboratory; 1.2.0: creatine, creatinine plausibility; 1.3.0: refusal and gating rules (biological-age-v3-rules.ts), reasons, collection method, bounds in the value

/** lab_results.source values written for EVA's own laboratory, Echevarne (the header's "Laboratory" rule). */
export const EVA_LABORATORY_SOURCES: readonly string[] = ["echevarne", "lab_partner"];

/** HbA1c, haemoglobin, ferritin and eGFR from another result count when drawn within this many days of this draw. */
export const HBA1C_WINDOW_DAYS = 90;


/** Statuses of another result whose values count: processed, whether or not the client has confirmed the context. */
export const OTHER_RESULT_STATUSES: readonly string[] = ["ready", "pending_context"];

/** The keys read from the client's other results: HbA1c, and what its exclusions need. */
export const OTHER_RESULT_KEYS: readonly string[] = ["hba1c", "hemoglobin", "ferritin", "egfr_creatinine_based", "egfr"];

/** patient_context_versions.conditions key for a current pregnancy (patient-context/options.ts): no version 3. */
export const PREGNANCY_CONDITION = "pregnancy_current";

/** patient_context_versions.conditions key for lactation (patient-context/options.ts): no version 3. */
export const LACTATION_CONDITION = "lactating";

const BASE_KEYS: ReadonlySet<string> = new Set(BA_V3_TIER_MARKERS.base);

/** The mass unit UREA_TO_BUN_FACTOR maps urea from, and BUN to. */
const UREA_BUN_UNIT = "mg/dL";

/** The unit of creatinine's plausible range (creatinine-plausibility.ts). */
const CREATININE_UNIT = "mg/dL";

// ─── Public types ───

export type HbA1cSource = "same_draw" | "other_result";

/** Why the HbA1c found was not given to the module. */
export type HbA1cExclusion = GlycationExclusion | "unit_not_convertible";

/**
 * Why there is no biological age: a refusal rule's code (biological-age-v3-rules.ts: pregnancy, lactation,
 * sex_unknown, age_unknown, age_outside_signed_range, collection_method, implausible_value, kidney, albumin_low,
 * crp_above_limit, alp_above_limit, ggt_above_limit), else the module's reason.
 */
export type BioAgeV3Reason = BiologicalAgeV3NullReason | BioAgeV3RuleCode;

/** One reason in `reasons`: its code, the marker behind it when there is one, and what was found. */
export interface BioAgeV3ReasonEntry {
  code: BioAgeV3Reason;
  marker?: string;
  detail: string;
}

/** One biomarker_values row, stored or about to be stored. */
export interface BioAgeV3ValueRow {
  biomarker_key: string;
  value: number | string | null;
  unit?: string | null;
  /** "<" or ">" when the lab reported a bound; `value` is then the bound. */
  comparator?: string | null;
  /** The reference lower limit stored with the row, in the row's unit. */
  normal_low?: number | string | null;
  /** The reference upper limit stored with the row (the person's row for their sex and age), in the row's unit. */
  normal_high?: number | string | null;
}

/** Another lab result of the same client. */
export interface BioAgeV3OtherResult {
  id: string;
  /** lab_results.collection_date (YYYY-MM-DD); null when unknown. */
  collection_date: string | null;
  created_at?: string | null;
  values: readonly BioAgeV3ValueRow[];
}

/** Everything the rules read, for one lab result. */
export interface BioAgeV3Sources {
  /** This result's rows. */
  values: readonly BioAgeV3ValueRow[];
  /** This result's draw date (lab_results.collection_date, YYYY-MM-DD); null when unknown. */
  drawDate: string | null;
  /** The client's other results; only those drawn within HBA1C_WINDOW_DAYS of this draw are read. */
  otherResults: readonly BioAgeV3OtherResult[];
  dateOfBirth: string | null | undefined;
  sex: string | null | undefined;
  /** patient_context_versions.conditions.keys. */
  conditionKeys: readonly string[];
  /** patient_context_versions.supplements of the same context version; the creatine dose adjusts creatinine. */
  supplements?: readonly SupplementEntry[] | null;
  /** When the record is computed: `computed_at`, and the age reference without a draw date. */
  now: Date;
  /** This result's lab_results.source as stored; null or absent when it could not be read. */
  labSource?: string | null;
  /**
   * How this result's sample was collected ("venous", "capillary"). The app records no collection method yet:
   * null or absent is "unknown", which counts as not venous (no figure).
   */
  collectionMethod?: string | null;
}

/** A value given to the module that was a bound ("<0.5"), under the key the module received it as. */
export interface BioAgeV3Bound {
  key: string;
  comparator: "<" | ">";
  value: number;
}

/** What the module receives for one lab result, and how the adapter chose it. */
export interface BioAgeV3Assembly {
  inputs: BiomarkerV3Input[];
  sex: string | null | undefined;
  /** Completed years at the draw (NaN when the date of birth cannot be read). */
  age: number;
  hba1cSource: HbA1cSource | null;
  hba1cExcludedReason: HbA1cExclusion | null;
  boundedMarkers: BioAgeV3Bound[];
  /** The declared creatine dose, g/day; null when none. */
  creatineGramsPerDay: number | null;
  /** What creatinine was divided by (1 without a dose). */
  creatinineDivisor: number;
  /** Keys withheld from the module as implausible (creatinine outside 0.2 to 15 mg/dL). */
  implausibleMarkers: string[];
  /**
   * What the refusal rules read: every Base row of this result (creatinine as measured, before the creatine divisor,
   * withheld rows included), BUN from urea, and the HbA1c given to the module; bounds resolved, with the rows'
   * upper reference limits.
   */
  ruleMarkers: BioAgeV3RuleMarker[];
}

/** The record stored in bio_age_v3_shadow.record, one per lab result. */
export interface BioAgeV3Record {
  /** model_sha256 of the frozen artifact the module computes. */
  model_sha256: string;
  adapter_version: string;
  /** ISO timestamp. */
  computed_at: string;
  /** null when there is no biological age. */
  tier: BiologicalAgeV3Tier | null;
  /** Biological age in years; null when there is none (`reason` says why). */
  ba: number | null;
  /** The 95% interval, years. */
  interval_low: number | null;
  interval_high: number | null;
  /** EVA keys of the tier's markers, in the model's order. */
  markers_used: string[];
  /** Markers whose value the model replaced by a credit-limit bound. */
  clamps_applied: BiologicalAgeV3Clamp[];
  /** hs-CRP was above 10 mg/L and was capped at 10. */
  crp_capped: boolean;
  /**
   * The number is not to be relied on as it stands: hs-CRP was above the provisional limit (10 mg/L) and capped (a
   * retest in two weeks is suggested).
   */
  provisional: boolean;
  /**
   * Where the HbA1c considered came from: this result, or the other result drawn closest to it within 90 days.
   * null when none was found (or during pregnancy, when nothing is computed). It entered the model when `tier` is
   * "plus_hba1c"; `hba1c_excluded_reason` says why not.
   */
  hba1c_source: HbA1cSource | null;
  hba1c_excluded_reason: HbA1cExclusion | null;
  /** Why there is no biological age (the first of `reasons`); null when there is one. */
  reason: BioAgeV3Reason | null;
  /** Every reason there is no biological age, in the rules' order; empty when there is one. */
  reasons: BioAgeV3ReasonEntry[];
  /** Version of the refusal rules applied (data/ba_v3_rules.json meta.version). */
  rules_version: string;
  /** How the sample was collected, as read ("unknown" when not recorded). */
  collection_method: string;
  /** Values given to the module that were bounds ("<0.5"): the bound was used. */
  bounded_markers: BioAgeV3Bound[];
  /** This result's lab_results.source as stored; null when it could not be read. */
  lab_source: string | null;
  /**
   * The Base Panel comes from EVA's own laboratory (lab_source is one of EVA_LABORATORY_SOURCES). Under PROPOSAL.md's
   * rule only then would the biological age be shown; version 3 is computed either way.
   */
  base_from_eva_laboratory: boolean;
  /** The creatine dose declared in the patient context read, g/day; null when none. */
  creatine_g_per_day: number | null;
  /** What creatinine was divided by before the module read it (1 without a dose). */
  creatinine_divisor: number;
}

/** Stored when computing version 3 failed in any way (process-results logs the error). */
export interface BioAgeV3ErrorRecord {
  reason: "error";
}

export type BioAgeV3Stored = BioAgeV3Record | BioAgeV3ErrorRecord;

// ─── Values, units and dates ───


/**
 * The unit a stored value is in: the app's canonical unit for its key when the row's own unit is that unit (up to
 * notation, canonical-units.normalizeUnit) or empty, as processing stores every value; otherwise the row's own
 * unit, which the module refuses for a model marker.
 */
function unitOf(key: string, unit: string | null | undefined): string {
  const canonical = getCanonicalUnit(key) ?? "";
  const own = typeof unit === "string" ? unit.trim() : "";
  if (own === "" || normalizeUnit(own) === normalizeUnit(canonical)) return canonical;
  return own;
}

/**
 * HbA1c from IFCC (mmol/mol) to NGSP (%): the IFCC-NGSP master equation, as
 * docs/biomarker-evidence/research/hba1c.json quotes it, "% = mmol/mol / 10.929 + 2.15".
 */
export function hba1cPercentFromMmolPerMol(mmolPerMol: number): number {
  return mmolPerMol / 10.929 + 2.15;
}

/** "YYYY-MM-DD" (a Postgres date, or the start of a timestamp) as [year, month, day]; null when not a real date. */
function isoDateParts(s: unknown): [number, number, number] | null {
  if (typeof s !== "string") return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s.trim());
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const t = new Date(Date.UTC(y, mo - 1, d));
  if (t.getUTCFullYear() !== y || t.getUTCMonth() !== mo - 1 || t.getUTCDate() !== d) return null;
  return [y, mo, d];
}

/** Calendar day number of a date, for differences in whole days. */
function dayNumber([y, mo, d]: [number, number, number]): number {
  return Date.UTC(y, mo - 1, d) / 86_400_000;
}

/** `date` ("YYYY-MM-DD") moved by `days` calendar days, as "YYYY-MM-DD". */
export function shiftIsoDate(date: string, days: number): string {
  const parts = isoDateParts(date);
  if (!parts) throw new Error(`not a date: ${date}`);
  return new Date((dayNumber(parts) + days) * 86_400_000).toISOString().slice(0, 10);
}

/**
 * Completed years at `asOf`: zone-classifier.calculateAge's arithmetic and date-of-birth parsing, at any date
 * (calculateAge is this at the current time). NaN when the date of birth cannot be read.
 */
export function completedYearsAt(dateOfBirth: string | null | undefined, asOf: Date): number {
  if (typeof dateOfBirth !== "string") return NaN;
  const birth = parseDateOfBirth(dateOfBirth);
  if (!birth || isNaN(asOf.getTime())) return NaN;
  let age = asOf.getFullYear() - birth.getFullYear();
  const m = asOf.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && asOf.getDate() < birth.getDate())) age--;
  return age;
}

// ─── The rules ───

/** A Base marker row, labelled with its unit; a wrong unit is left for the module to refuse. */
function baseInput(row: BioAgeV3ValueRow): BiomarkerV3Input {
  return { code: row.biomarker_key, value: resolvedValueOf(row).value, unit: unitOf(row.biomarker_key, row.unit) };
}

/** BUN from a urea row in mg/dL; null for urea in any other unit. */
function bunFromUrea(row: BioAgeV3ValueRow): BiomarkerV3Input | null {
  if (normalizeUnit(unitOf("urea", row.unit)) !== normalizeUnit(UREA_BUN_UNIT)) return null;
  return { code: "bun", value: resolvedValueOf(row).value * UREA_TO_BUN_FACTOR, unit: UREA_BUN_UNIT };
}

/** An HbA1c row in %: as stored, or converted from mmol/mol; null for any other unit. */
function hba1cInput(row: BioAgeV3ValueRow): BiomarkerV3Input | null {
  const unit = unitOf("hba1c", row.unit);
  const value = resolvedValueOf(row).value;
  if (normalizeUnit(unit) === "%") return { code: "hba1c", value, unit };
  if (normalizeUnit(unit) === "mmol/mol") return { code: "hba1c", value: hba1cPercentFromMmolPerMol(value), unit: "%" };
  return null;
}

/** The client's other results drawn within HBA1C_WINDOW_DAYS of the draw, the closest to it first. */
function recentOtherResults(
  others: readonly BioAgeV3OtherResult[],
  drawDate: string | null,
): BioAgeV3OtherResult[] {
  const draw = isoDateParts(drawDate);
  if (!draw) return [];
  const drawDay = dayNumber(draw);
  const dated = others.flatMap((o) => {
    const parts = isoDateParts(o.collection_date);
    if (!parts || Math.abs(dayNumber(parts) - drawDay) > HBA1C_WINDOW_DAYS) return [];
    return [{ o, day: dayNumber(parts) }];
  });
  // Closest draw first, before or after; at equal distance the one stored last, then the id, so the choice never
  // depends on read order.
  dated.sort(
    (a, b) =>
      Math.abs(a.day - drawDay) - Math.abs(b.day - drawDay) ||
      (b.o.created_at ?? "").localeCompare(a.o.created_at ?? "") ||
      b.o.id.localeCompare(a.o.id),
  );
  return dated.map((d) => d.o);
}

/**
 * What the module receives for one lab result, by the rules in the header (pregnancy aside: bioAgeV3Record stops
 * before this). Pure; the sources are not modified.
 */
export function assembleBioAgeV3Inputs(s: BioAgeV3Sources): BioAgeV3Assembly {
  const inputs: BiomarkerV3Input[] = [];
  const boundedMarkers: BioAgeV3Bound[] = [];
  const ruleMarkers: BioAgeV3RuleMarker[] = [];
  const give = (input: BiomarkerV3Input, row: BioAgeV3ValueRow) => {
    inputs.push(input);
    const comparator = resolvedValueOf(row).comparator;
    if (comparator !== null) boundedMarkers.push({ key: input.code, comparator, value: input.value });
  };
  /** What the rules read for a value: the measured value (or the one given), its bound and the row's upper limit. */
  const judge = (input: BiomarkerV3Input, row: BioAgeV3ValueRow, ownLimits = true) => {
    const high = numberOf(row.normal_high);
    ruleMarkers.push({
      key: input.code,
      value: input.value,
      unit: input.unit,
      comparator: resolvedValueOf(row).comparator,
      normal_high: ownLimits && Number.isFinite(high) ? high : null,
    });
  };

  // Base markers: this result only. Every row is passed; the module refuses a marker given twice with two values.
  // Creatinine in mg/dL follows the lab page's per-lab rule (creatinine-plausibility.ts): when any value is outside
  // its plausible range, every creatinine row of the result is withheld, since the plausible one may be the wrong
  // one; the same result listed twice (labCreatinineReadable, a print in mg/dL and µmol/L included) is given once, the
  // last row, which is the one the lab page reads (kdm-adapter.ts); rows that disagree are all given, and the module
  // refuses them (duplicate_marker). Creatinine given is divided by the declared creatine dose's divisor first.
  const creatineGramsPerDay = creatineDoseGramsPerDay(s.supplements ?? null);
  const creatinineDivisor = creatineCreatinineDivisor(creatineGramsPerDay);
  const implausibleMarkers: string[] = [];
  const isMgDlCreatinine = (row: BioAgeV3ValueRow) =>
    row.biomarker_key === "creatinine" && normalizeUnit(baseInput(row).unit) === normalizeUnit(CREATININE_UNIT);
  const mgDlCreatinine = s.values.filter(isMgDlCreatinine);
  const creatinineImplausible = mgDlCreatinine.some((row) => !isPlausibleCreatinineMgDl(baseInput(row).value));
  if (creatinineImplausible) implausibleMarkers.push("creatinine");
  const creatinineOnce =
    !creatinineImplausible && mgDlCreatinine.length > 1 && labCreatinineReadable(mgDlCreatinine.map((row) => baseInput(row).value))
      ? mgDlCreatinine[mgDlCreatinine.length - 1]
      : null;
  for (const row of s.values) {
    if (!BASE_KEYS.has(row.biomarker_key)) continue;
    const input = baseInput(row);
    judge(input, row); // every Base row, creatinine as measured, withheld rows included
    if (row.biomarker_key !== "creatinine") {
      give(input, row);
    } else if (!creatinineImplausible && (creatinineOnce === null || row === creatinineOnce || !isMgDlCreatinine(row))) {
      give({ ...input, value: input.value / creatinineDivisor }, row);
    }
  }
  if (!s.values.some((r) => r.biomarker_key === "bun")) {
    for (const row of s.values) {
      if (row.biomarker_key !== "urea") continue;
      const bun = bunFromUrea(row);
      if (bun !== null) {
        give(bun, row);
        judge(bun, row, false); // the urea row's limits are not BUN's
      }
    }
  }

  // HbA1c: this result's, else that of the other result drawn closest to it within the window.
  const recent = recentOtherResults(s.otherResults, s.drawDate);
  let hba1cSource: HbA1cSource | null = null;
  let hba1cRows: readonly BioAgeV3ValueRow[] = s.values.filter((r) => r.biomarker_key === "hba1c");
  if (hba1cRows.length > 0) {
    hba1cSource = "same_draw";
  } else {
    const other = recent.find((o) => o.values.some((r) => r.biomarker_key === "hba1c"));
    if (other) {
      hba1cSource = "other_result";
      hba1cRows = other.values.filter((r) => r.biomarker_key === "hba1c");
    }
  }
  let hba1cExcludedReason: HbA1cExclusion | null = null;
  if (hba1cSource !== null) {
    const hba1c = hba1cRows.map((row) => ({ row, input: hba1cInput(row) }));
    hba1cExcludedReason = hba1c.some((h) => h.input === null)
      ? "unit_not_convertible"
      : glycationExclusion([...s.values, ...recent.flatMap((o) => o.values)]);
    if (hba1cExcludedReason === null) {
      for (const h of hba1c) {
        give(h.input as BiomarkerV3Input, h.row);
        judge(h.input as BiomarkerV3Input, h.row, false);
      }
    }
  }

  // Age in completed years at the draw (local calendar date, as parseDateOfBirth reads the birth date).
  const draw = isoDateParts(s.drawDate);
  const asOf = draw ? new Date(draw[0], draw[1] - 1, draw[2]) : s.now;

  return {
    inputs,
    sex: s.sex,
    age: completedYearsAt(s.dateOfBirth, asOf),
    hba1cSource,
    hba1cExcludedReason,
    boundedMarkers,
    creatineGramsPerDay,
    creatinineDivisor,
    implausibleMarkers,
    ruleMarkers,
  };
}

/** The laboratory this result comes from, and whether it is EVA's own (the header's "Laboratory" rule). */
export function laboratoryOf(labSource: unknown): { lab_source: string | null; base_from_eva_laboratory: boolean } {
  const source = typeof labSource === "string" ? labSource : null;
  return { lab_source: source, base_from_eva_laboratory: source !== null && EVA_LABORATORY_SOURCES.includes(source) };
}

/** The record stored in bio_age_v3_shadow for one lab result: the refusal rules first, then the module. Pure. */
export function bioAgeV3Record(s: BioAgeV3Sources): BioAgeV3Record {
  const identity = {
    model_sha256: BA_V3_MODEL_SHA256,
    adapter_version: BIO_AGE_V3_ADAPTER_VERSION,
    computed_at: s.now.toISOString(),
  };
  // Recorded on every record, a result or not.
  const laboratory = laboratoryOf(s.labSource);
  const creatineGramsPerDay = creatineDoseGramsPerDay(s.supplements ?? null);
  const creatine = {
    creatine_g_per_day: creatineGramsPerDay,
    creatinine_divisor: creatineCreatinineDivisor(creatineGramsPerDay),
  };
  const noResult = {
    tier: null,
    ba: null,
    interval_low: null,
    interval_high: null,
    markers_used: [],
    clamps_applied: [],
    crp_capped: false,
    provisional: false,
  };

  const a = assembleBioAgeV3Inputs(s);
  const rules = evaluateBioAgeV3Rules({
    markers: a.ruleMarkers,
    sex: a.sex,
    age: a.age,
    context: { conditions: s.conditionKeys },
    collection: { method: s.collectionMethod, fromEvaLaboratory: laboratory.base_from_eva_laboratory },
  });
  const gating = { rules_version: BA_V3_RULES_VERSION, collection_method: rules.collection_method };
  const hba1c = { hba1c_source: a.hba1cSource, hba1c_excluded_reason: a.hba1cExcludedReason };

  if (!rules.eligible) {
    // During pregnancy or lactation nothing else is recorded: the model was not validated there.
    const state = rules.reasons.some((r) => r.code === "pregnancy" || r.code === "lactation");
    return {
      ...identity,
      ...noResult,
      ...(state ? { hba1c_source: null, hba1c_excluded_reason: null } : hba1c),
      reason: rules.reasons[0].code,
      reasons: rules.reasons,
      ...gating,
      bounded_markers: state ? [] : a.boundedMarkers,
      ...laboratory,
      ...creatine,
    };
  }

  const outcome = computeBiologicalAgeV3(a.inputs, a.sex, a.age);
  if (outcome.ba === null) {
    const ageUnknown = outcome.reason === "age_outside_validated_range" && !Number.isFinite(a.age);
    const implausible =
      outcome.reason === "missing_markers" && outcome.markers.some((k) => a.implausibleMarkers.includes(k));
    const reason: BioAgeV3Reason = ageUnknown ? "age_unknown" : implausible ? "implausible_value" : outcome.reason;
    return {
      ...identity,
      ...noResult,
      ...hba1c,
      reason,
      reasons: [moduleReason(reason, outcome.markers)],
      ...gating,
      bounded_markers: a.boundedMarkers,
      ...laboratory,
      ...creatine,
    };
  }
  return {
    ...identity,
    tier: outcome.tier,
    ba: outcome.ba,
    interval_low: outcome.interval[0],
    interval_high: outcome.interval[1],
    markers_used: outcome.markersUsed,
    clamps_applied: outcome.clampsApplied,
    crp_capped: outcome.crpCapped,
    provisional: outcome.crpCapped || rules.provisional,
    ...hba1c,
    reason: null,
    reasons: [],
    ...gating,
    bounded_markers: a.boundedMarkers,
    ...laboratory,
    ...creatine,
  };
}

/** A module refusal as a `reasons` entry. */
function moduleReason(code: BioAgeV3Reason, markers: readonly string[]): BioAgeV3ReasonEntry {
  const keys = [...new Set(markers)];
  const detail = `version 3 module: ${code}${keys.length > 0 ? ` (${keys.join(", ")})` : ""}`;
  return keys.length === 1 ? { code, marker: keys[0], detail } : { code, detail };
}

// ─── Reading the sources ───

export interface BioAgeV3ShadowArgs {
  userId: string;
  labResultId: string;
  /** This result's rows when the caller holds them (processLabResults); null to read them (recomputeLabMetrics). */
  values: readonly BioAgeV3ValueRow[] | null;
  /** profiles.date_of_birth and profiles.sex, as the caller read them. */
  profile: { date_of_birth?: string | null; sex?: string | null } | null | undefined;
  now: Date;
}

/** Awaits a query; throws on a database error, so the caller stores { reason: "error" }. */
async function read<T>(query: PromiseLike<{ data: unknown; error: unknown }>, what: string): Promise<T | null> {
  const { data, error } = await query;
  if (error) {
    const message = error instanceof Error ? error.message : (error as { message?: string }).message;
    throw new Error(`biological age v3: reading ${what} failed: ${message ?? String(error)}`);
  }
  return (data ?? null) as T | null;
}

/** The client's other results drawn within HBA1C_WINDOW_DAYS of `drawDate`, with their rows of OTHER_RESULT_KEYS. */
async function loadOtherResults(
  supabase: SupabaseClient,
  userId: string,
  labResultId: string,
  drawDate: string,
): Promise<BioAgeV3OtherResult[]> {
  const labs =
    (await read<Array<{ id: string; collection_date: string | null; created_at: string | null }>>(
      supabase
        .from("lab_results")
        .select("id, collection_date, created_at")
        .eq("user_id", userId)
        .neq("id", labResultId)
        .in("status", [...OTHER_RESULT_STATUSES])
        .gte("collection_date", shiftIsoDate(drawDate, -HBA1C_WINDOW_DAYS))
        .lte("collection_date", shiftIsoDate(drawDate, HBA1C_WINDOW_DAYS)),
      "the client's other lab results",
    )) ?? [];
  if (labs.length === 0) return [];

  const rows =
    (await read<Array<BioAgeV3ValueRow & { lab_result_id: string }>>(
      supabase
        .from("biomarker_values")
        .select("lab_result_id, biomarker_key, value, unit, comparator, normal_low")
        .in("lab_result_id", labs.map((l) => l.id))
        .in("biomarker_key", [...OTHER_RESULT_KEYS]),
      "the other lab results' values",
    )) ?? [];
  return labs.map((l) => ({
    id: l.id,
    collection_date: l.collection_date,
    created_at: l.created_at,
    values: rows.filter((r) => r.lab_result_id === l.id),
  }));
}

/**
 * Condition keys and supplements of the patient context this result is read under (patient-context/lab-context.ts):
 * the snapshot taken for it, else the client's latest context version created on or before it.
 */
async function loadContext(
  supabase: SupabaseClient,
  userId: string,
  lab: LabContextRef,
): Promise<{ conditionKeys: string[]; supplements: SupplementEntry[] | null }> {
  type ContextRow = { conditions?: { keys?: unknown } | null; supplements?: unknown };
  let row: ContextRow | null;
  try {
    row = await loadLabContext<ContextRow>(supabase, userId, lab, "conditions, supplements");
  } catch (err) {
    throw new Error(`biological age v3: ${err instanceof Error ? err.message : String(err)}`);
  }
  const keys = row?.conditions?.keys;
  return {
    conditionKeys: Array.isArray(keys) ? keys.filter((k): k is string => typeof k === "string") : [],
    supplements: Array.isArray(row?.supplements) ? (row.supplements as SupplementEntry[]) : null,
  };
}

/** Reads the sources of one lab result's record. Read-only; throws on a database error. */
export async function loadBioAgeV3Sources(supabase: SupabaseClient, args: BioAgeV3ShadowArgs): Promise<BioAgeV3Sources> {
  const lab = await read<{
    collection_date: string | null;
    created_at?: string | null;
    patient_context_version_id: string | null;
    source?: string | null;
  }>(
    supabase
      .from("lab_results")
      .select("collection_date, created_at, patient_context_version_id, source")
      .eq("id", args.labResultId)
      .eq("user_id", args.userId)
      .maybeSingle(),
    "the lab result",
  );
  const drawDate = isoDateParts(lab?.collection_date) ? (lab?.collection_date as string).slice(0, 10) : null;

  const values =
    args.values ??
    (await read<BioAgeV3ValueRow[]>(
      supabase
        .from("biomarker_values")
        .select("biomarker_key, value, unit, comparator, normal_low, normal_high")
        .eq("lab_result_id", args.labResultId),
      "the lab result's values",
    )) ??
    [];
  const otherResults = drawDate ? await loadOtherResults(supabase, args.userId, args.labResultId, drawDate) : [];
  const { conditionKeys, supplements } = await loadContext(supabase, args.userId, {
    patient_context_version_id: lab?.patient_context_version_id ?? null,
    created_at: lab?.created_at ?? null,
  });

  return {
    values,
    drawDate,
    otherResults,
    dateOfBirth: args.profile?.date_of_birth ?? null,
    sex: args.profile?.sex ?? null,
    conditionKeys,
    supplements,
    now: args.now,
    labSource: typeof lab?.source === "string" ? lab.source : null,
    // The app records no collection method yet (no column on lab_results or kit orders): unknown, not venous.
    collectionMethod: null,
  };
}

/** Reads the sources and computes the record of one lab result. Throws on a database error. */
export async function computeBioAgeV3Shadow(supabase: SupabaseClient, args: BioAgeV3ShadowArgs): Promise<BioAgeV3Record> {
  return bioAgeV3Record(await loadBioAgeV3Sources(supabase, args));
}
