/**
 * Measured fructosamine in the KDM biological age (fix of 2026-09-25).
 *
 * The model's "Fructosamina" was fitted on values derived from HbA1c
 * (19.97 × HbA1c − 39.4, about 70 µmol/L). The Base Panel measures it on an
 * enzymatic assay (reference 122–236 µmol/L). Before the fix a measured value
 * was used as is, and won over the derived one: a 45-year-old man at
 * 190 µmol/L got a biological age of 81.7 instead of 51.1.
 *
 * Run: `npx vitest run src/lib/biomarkers/biological-age-kdm.fructosamine.test.ts`
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import { explainBiologicalAge } from "./biological-age-explain";
import {
  applyLifestyleAdjustments,
  BASE_PANEL,
  computeComprehensiveBA,
  computeReferenceBA,
  DEFAULT_FRUCTOSAMINE_POLICY,
  FRUCTOSAMINE_KDM_KEY,
  HBA1C_KDM_KEY,
  klemeraDoubalBa,
  passesKdmGate,
  resolveKdmParams,
  resolveSCa,
  type KdmReferenceBAResult,
  type SCaTier,
  type Sex,
} from "./biological-age-kdm";
import { kdmInputsFromBiomarkerValues } from "./kdm-adapter";
import type { BiomarkerInput } from "./longevity-score";

const TIERS: SCaTier[] = ["reference", "comprehensive"];
const SEXES: Sex[] = ["male", "female"];
const AGES = [35, 50, 65];
const MEASURED = [122, 150, 170, 190, 210, 230, 236, 260]; // µmol/L, across the reference range 122–236
const compute = (tier: SCaTier) => (tier === "reference" ? computeReferenceBA : computeComprehensiveBA);

// The Base Panel's twelve other tests (DB keys, engine units): the typical man and
// woman of scripts/kdm_explain_panels.ts. The thirteenth test is fructosamine.
const BASE_PANEL_TESTS: Record<Sex, Record<string, number>> = {
  male: {
    albumin: 44, alp: 72, hs_crp: 1.8, creatinine: 1.0, bun: 15, uric_acid: 6.0, total_cholesterol: 205,
    hdl_cholesterol: 47, triglycerides: 140, apolipoprotein_b_apob: 105, alt: 30, ggt: 32,
  },
  female: {
    albumin: 43, alp: 65, hs_crp: 1.5, creatinine: 0.75, bun: 13, uric_acid: 4.5, total_cholesterol: 200,
    hdl_cholesterol: 60, triglycerides: 95, apolipoprotein_b_apob: 90, alt: 18, ggt: 18,
  },
};
const panel = (sex: Sex, extra: Record<string, number> = {}): BiomarkerInput[] =>
  Object.entries({ ...BASE_PANEL_TESTS[sex], ...extra }).map(([code, value]) => ({ code, value }));

/** Fructosamine at its training-typical value for the age: on the model's own line, exp(q + k·CA). */
function typicalFructosamine(sex: Sex, age: number): number {
  const p = resolveKdmParams({ [FRUCTOSAMINE_KDM_KEY]: 1 }, sex, true).params[FRUCTOSAMINE_KDM_KEY];
  return Math.exp(p.q + p.k * age);
}

/** The BA of the panel with fructosamine at its training-typical value, fed to the model as is. */
const typicalBA = (tier: SCaTier, sex: Sex, age: number) =>
  compute(tier)(panel(sex, { fructosamine: typicalFructosamine(sex, age) }), sex, age, null, { fructosamine: "as_measured" });

/** The pipeline before 2026-09-25, rebuilt from its parts: a measured value is used as is. */
function legacyBA(values: BiomarkerInput[], sex: Sex, age: number, tier: SCaTier): KdmReferenceBAResult {
  const adapted = kdmInputsFromBiomarkerValues(values).inputs;
  const hba1c = adapted[HBA1C_KDM_KEY];
  const filled =
    FRUCTOSAMINE_KDM_KEY in adapted || !Number.isFinite(hba1c)
      ? adapted
      : { ...adapted, [FRUCTOSAMINE_KDM_KEY]: 19.97 * hba1c - 39.4 };
  const inputs = applyLifestyleAdjustments(filled, null);
  if (!passesKdmGate(inputs)) return null;
  const { params, applied } = resolveKdmParams(inputs, sex, tier === "reference");
  const r = klemeraDoubalBa(inputs, params, age, true, resolveSCa(tier), sex);
  return r && { ...r, applied_spanish_recalibration_markers: applied.filter((m) => r.used_markers.includes(m)) };
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("measured fructosamine — default policy: HbA1c only", () => {
  it("is the default", () => {
    expect(DEFAULT_FRUCTOSAMINE_POLICY).toBe("hba1c_only");
  });

  for (const tier of TIERS) {
    it(`122–260 µmol/L: BA within 2 years of the panel with fructosamine at its training-typical value — ${tier}`, () => {
      for (const sex of SEXES) {
        for (const age of AGES) {
          const typical = typicalBA(tier, sex, age)!;
          const without = compute(tier)(panel(sex), sex, age)!;
          for (const f of MEASURED) {
            const ba = compute(tier)(panel(sex, { fructosamine: f }), sex, age)!;
            expect(Math.abs(ba.BA - typical.BA)).toBeLessThanOrEqual(2);
            // The measured value is set aside: same result as the panel without it.
            expect(ba).toEqual(without);
            expect(ba.used_markers).not.toContain(FRUCTOSAMINE_KDM_KEY);
          }
        }
      }
    });
  }

  it("a measured value no longer wins over HbA1c: the value derived from HbA1c is used", () => {
    for (const tier of TIERS) {
      const both = compute(tier)(panel("male", { fructosamine: 190, hba1c: 5.5 }), "male", 45)!;
      const hba1cOnly = compute(tier)(panel("male", { hba1c: 5.5 }), "male", 45)!;
      expect(both).toEqual(hba1cOnly);
      expect(both.used_markers).toContain(FRUCTOSAMINE_KDM_KEY);
    }
  });

  it("the explanation library decomposes the same inputs", () => {
    const e = explainBiologicalAge(panel("male", { fructosamine: 190, hba1c: 5.5 }), "male", 45, {})!;
    expect(e.check.ok).toBe(true);
    const fructosamine = e.contributions.find((c) => c.marker === FRUCTOSAMINE_KDM_KEY)!;
    expect(fructosamine.modelValue).toBeCloseTo(19.97 * 5.5 - 39.4, 10);
  });
});

describe("measured fructosamine — the fix disabled (\"as_measured\", before 2026-09-25)", () => {
  it("reproduces the old pipeline exactly", () => {
    for (const tier of TIERS) {
      for (const sex of SEXES) {
        for (const age of AGES) {
          const extras: Record<string, number>[] = [
            { fructosamine: 122 }, { fructosamine: 190 }, { fructosamine: 260 }, { fructosamine: 190, hba1c: 5.5 }, { hba1c: 5.5 },
          ];
          for (const extra of extras) {
            const values = panel(sex, extra);
            const old = compute(tier)(values, sex, age, null, { fructosamine: "as_measured" });
            expect(old).not.toBeNull();
            expect(old).toEqual(legacyBA(values, sex, age, tier));
          }
        }
      }
    }
  });

  it("the old error: 190 µmol/L, inside the reference range, read as more than 20 years of aging", () => {
    for (const sex of SEXES) {
      for (const age of AGES) {
        const old = computeReferenceBA(panel(sex, { fructosamine: 190 }), sex, age, null, { fructosamine: "as_measured" })!;
        expect(old.used_markers).toContain(FRUCTOSAMINE_KDM_KEY);
        expect(old.BA - typicalBA("reference", sex, age)!.BA).toBeGreaterThan(20);
      }
    }
  });
});

describe("measured fructosamine — the gate", () => {
  // Exactly 8 base-panel markers, one of them a measured fructosamine; no HbA1c.
  const THIN: BiomarkerInput[] = [
    { code: "albumin", value: 44 },
    { code: "creatinine", value: 1.0 },
    { code: "bun", value: 15 },
    { code: "uric_acid", value: 6.0 },
    { code: "total_cholesterol", value: 205 },
    { code: "hdl_cholesterol", value: 47 },
    { code: "triglycerides", value: 140 },
    { code: "fructosamine", value: 190 },
  ];

  it("the Base Panel keeps its BA: 10 of the 14 base markers remain", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const tier of TIERS) {
      const ba = compute(tier)(panel("male", { fructosamine: 190 }), "male", 45)!;
      expect(ba).not.toBeNull();
      expect(ba.used_markers.filter((m) => BASE_PANEL.includes(m))).toHaveLength(10);
    }
    expect(warn).not.toHaveBeenCalled();
  });

  it("a panel that needed the measured value for the gate loses its BA, and the code says why", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const tier of TIERS) {
      expect(compute(tier)(THIN, "male", 45, null, { fructosamine: "as_measured" })).not.toBeNull();
      expect(compute(tier)(THIN, "male", 45)).toBeNull();
    }
    expect(warn).toHaveBeenCalledTimes(2);
    for (const [tier, [message]] of TIERS.map((t, i) => [t, warn.mock.calls[i]] as const)) {
      expect(message).toContain(`${tier} BA not computed`);
      expect(message).toContain("measured fructosamine is not used");
      expect(message).toContain("7 of the 8 base-panel markers");
    }
  });

  it("with HbA1c the derived value takes its place and the BA stays", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    for (const tier of TIERS) {
      const ba = compute(tier)([...THIN, { code: "hba1c", value: 5.5 }], "male", 45)!;
      expect(ba).not.toBeNull();
      expect(ba.used_markers).toContain(FRUCTOSAMINE_KDM_KEY);
    }
    expect(warn).not.toHaveBeenCalled();
  });

  it("no warning when the gate fails anyway", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const seven = THIN.filter((v) => v.code !== "bun");
    for (const tier of TIERS) {
      expect(compute(tier)(seven, "male", 45, null, { fructosamine: "as_measured" })).toBeNull();
      expect(compute(tier)(seven, "male", 45)).toBeNull();
    }
    expect(warn).not.toHaveBeenCalled();
  });
});
