/**
 * Server-side biomarker_references seeder.
 *
 * Inlines the committed JSON data so it can run inside a Next.js API route
 * on Vercel without a terminal — useful as a one-shot bootstrap when the
 * table is empty. Idempotent: uses upsert on (biomarker_key, sex, age_group_en).
 *
 * IMPORTANT: requires the admin (service-role) Supabase client, because
 * biomarker_references has an "Anyone can read" policy but no insert policy
 * for regular users.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
// Next.js bundles these JSON imports into the serverless function.
import enDataRaw from "../../../supabase/seed-data/biomarker-ranges-en.json";
import esDataRaw from "../../../supabase/seed-data/rangos-biomarcadores-es.json";

interface EnRow {
  Category: string;
  Biomarker: string;
  Unit: string;
  Sex: string;
  Age_Group: string;
  Normal_Low: number | null;
  Normal_High: number | null;
  Optimal_Low: number | null;
  Optimal_High: number | null;
  Tested_2x_Year: string;
  Clinical_Notes: string | null;
  Msg_Critical_Low: string | null;
  Msg_Below_Optimal: string | null;
  Msg_Optimal: string | null;
  Msg_Above_Optimal: string | null;
  Msg_Critical_High: string | null;
}

interface EsRow {
  Categoría: string;
  Biomarcador: string;
  Unidad: string;
  Sexo: string;
  Grupo_Edad: string;
  Normal_Bajo: number | null;
  Normal_Alto: number | null;
  Óptimo_Bajo: number | null;
  Óptimo_Alto: number | null;
  Analizado_2x_Año: string;
  Notas_Clínicas: string | null;
  Msg_Crítico_Bajo: string | null;
  Msg_Debajo_Óptimo: string | null;
  Msg_Óptimo: string | null;
  Msg_Encima_Óptimo: string | null;
  Msg_Crítico_Alto: string | null;
}

const enData = (enDataRaw as { biomarker_ranges: EnRow[] }).biomarker_ranges;
const esData = (esDataRaw as { rangos_biomarcadores: EsRow[] }).rangos_biomarcadores;

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

function normalizeSex(sex: string): string {
  const map: Record<string, string> = {
    Both: "both",
    Ambos: "both",
    Male: "male",
    Masculino: "male",
    Female: "female",
    Femenino: "female",
  };
  return map[sex] ?? sex.toLowerCase();
}

function mapCategory(category: string): string {
  const map: Record<string, string> = {
    Heart: "cardiovascular",
    Thyroid: "thyroid",
    Autoimmunity: "autoimmunity",
    "Immune Regulation": "immune",
    "Female Health": "hormonal",
    "Male Health": "hormonal",
    Metabolic: "metabolic",
    "Environmental Toxins": "environmental",
    "Biological Age": "biological_age",
    Nutrients: "nutrients",
    "Stress & Aging": "stress_aging",
    Liver: "liver",
    Blood: "blood",
    Kidneys: "kidneys",
    Pancreas: "pancreas",
  };
  return map[category] ?? slugify(category);
}

/**
 * The Base Panel — 13 tests, fixed by the founder on 2026-09-22 (mirrors
 * ECH_PANEL_ORDER_CODES.base in src/lib/lab-bridge/panel-codes.ts and the
 * KDM v2.2 base panel). Seed names, EN.
 */
const BASE_PANEL_NAMES = new Set([
  "Albumin",
  "ALP",
  "hs-CRP",
  "Creatinine",
  "BUN",
  "Uric Acid",
  "Total Cholesterol",
  "HDL Cholesterol",
  "Triglycerides",
  "Apolipoprotein B (ApoB)",
  "ALT",
  "GGT",
  "Fructosamine",
]);

const GENETIC_BIOMARKERS = new Set(["Lipoprotein(a)"]);

export interface SeedRow {
  biomarker_key: string;
  name_en: string;
  name_es: string;
  unit_en: string;
  unit_es: string;
  sex: string;
  age_group_en: string;
  age_group_es: string;
  normal_low: number | null;
  normal_high: number | null;
  optimal_low: number | null;
  optimal_high: number | null;
  tested_2x_year: boolean;
  panel_category: string;
  is_base_panel: boolean;
  is_genetic: boolean;
  clinical_notes_en: string | null;
  clinical_notes_es: string | null;
  msg_critical_low_en: string | null;
  msg_critical_low_es: string | null;
  msg_below_optimal_en: string | null;
  msg_below_optimal_es: string | null;
  msg_optimal_en: string | null;
  msg_optimal_es: string | null;
  msg_above_optimal_en: string | null;
  msg_above_optimal_es: string | null;
  msg_critical_high_en: string | null;
  msg_critical_high_es: string | null;
}

function buildRows(): SeedRow[] {
  if (enData.length !== esData.length) {
    throw new Error(
      `Seed row count mismatch: EN=${enData.length} ES=${esData.length}`,
    );
  }
  const rows: SeedRow[] = [];
  for (let i = 0; i < enData.length; i++) {
    const en = enData[i];
    const es = esData[i];
    rows.push({
      biomarker_key: slugify(en.Biomarker),
      name_en: en.Biomarker,
      name_es: es.Biomarcador,
      unit_en: en.Unit,
      unit_es: es.Unidad,
      sex: normalizeSex(en.Sex),
      age_group_en: en.Age_Group,
      age_group_es: es.Grupo_Edad,
      normal_low: en.Normal_Low,
      normal_high: en.Normal_High,
      optimal_low: en.Optimal_Low,
      optimal_high: en.Optimal_High,
      tested_2x_year: en.Tested_2x_Year === "Yes",
      panel_category: mapCategory(en.Category),
      is_base_panel: BASE_PANEL_NAMES.has(en.Biomarker),
      is_genetic: GENETIC_BIOMARKERS.has(en.Biomarker),
      clinical_notes_en: en.Clinical_Notes,
      clinical_notes_es: es.Notas_Clínicas,
      msg_critical_low_en: en.Msg_Critical_Low,
      msg_critical_low_es: es.Msg_Crítico_Bajo,
      msg_below_optimal_en: en.Msg_Below_Optimal,
      msg_below_optimal_es: es.Msg_Debajo_Óptimo,
      msg_optimal_en: en.Msg_Optimal,
      msg_optimal_es: es.Msg_Óptimo,
      msg_above_optimal_en: en.Msg_Above_Optimal,
      msg_above_optimal_es: es.Msg_Encima_Óptimo,
      msg_critical_high_en: en.Msg_Critical_High,
      msg_critical_high_es: es.Msg_Crítico_Alto,
    });
  }
  return rows;
}

/**
 * Deduplicate rows by (biomarker_key, sex, age_group_en). Postgres rejects
 * an upsert batch containing two rows with the same conflict key ("ON
 * CONFLICT DO UPDATE command cannot affect row a second time"), and the
 * source JSON has a handful of true duplicates (hs-CRP, DHEA-S, PSA Free,
 * Calcium Serum). We keep the LAST occurrence — matches upsert semantics
 * if we were applying them one at a time.
 */
function dedupeByConflictKey(rows: SeedRow[]): SeedRow[] {
  const map = new Map<string, SeedRow>();
  for (const row of rows) {
    const key = `${row.biomarker_key}|${row.sex}|${row.age_group_en}`;
    map.set(key, row);
  }
  return Array.from(map.values());
}

/**
 * The rows the seeder would write, without writing them (duplicates keep
 * the last occurrence). For tests and reports that need the reviewed rows.
 */
export function seedReferenceRows(): SeedRow[] {
  return dedupeByConflictKey(buildRows());
}

/**
 * Upsert all biomarker_references rows via the admin client.
 * Returns the number of rows inserted/updated.
 * Idempotent — safe to call repeatedly.
 */
export async function seedBiomarkerReferences(
  admin: SupabaseClient,
): Promise<{ inserted: number; dedupedFrom: number }> {
  const rawRows = buildRows();
  const rows = dedupeByConflictKey(rawRows);
  const BATCH_SIZE = 50;
  let inserted = 0;

  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const { error } = await admin
      .from("biomarker_references")
      .upsert(batch, { onConflict: "biomarker_key,sex,age_group_en" });
    if (error) {
      throw new Error(
        `Seed batch ${i / BATCH_SIZE} failed: ${error.message}. First row: ${JSON.stringify(
          batch[0],
        )}`,
      );
    }
    inserted += batch.length;
  }

  return { inserted, dedupedFrom: rawRows.length };
}
