/**
 * Processing and recomputing store the one score, calculateLongevityScoreV2, on the reference rows the database
 * holds: processLabResults on the rows it loaded to classify the results (read once), recomputeLabMetrics on the
 * rows it loads for the user's sex. Two sets of rows that score the same panel differently show that the stored
 * score follows the rows.
 *
 * Values that give no score store none: longevity_score and longevity_grade are written as null, never as 0, so a
 * score stored by an earlier run is cleared, and the upload and admin routes email no score. Reference rows the
 * recompute cannot read clear it too: no score is left standing on a failed read. Scripted database (fake-supabase), no network; around the
 * routes, the AI summary and the email sender are stubbed.
 */
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import type { SupabaseClient } from "@supabase/supabase-js";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { POST as confirm } from "@/app/api/lab-results/confirm/route";
import { POST as enterResults } from "@/app/api/admin/enter-results/route";
import { sendEmail } from "@/lib/email/send";
import { renderResultsReady, type ResultsReadyData } from "@/lib/email/templates/results-ready";
import { computeReferenceBA } from "./biological-age-kdm";
import { classifyResultZone } from "./bounded-result";
import { getCanonicalUnit } from "./canonical-units";
import { buildEngineInputs } from "./engine-inputs";
import { calculateLongevityScoreV2, OUT_OF_RANGE_CAP, type ReviewedRow } from "./longevity-score";
import { LAB_STATE_LAB_COLUMNS, resolveState, UNKNOWN_STATE } from "@/lib/patient-context/physiological-state";
import { processLabResults, recomputeLabMetrics } from "./process-results";
import { pickReferenceRows } from "./reference-row";
import { signedRows } from "./__tests__/fixtures/reviewed-rows";

// The client a route test hands the routes (createClient, and createAdminClient for the admin route); the
// processing tests pass their own.
const route = vi.hoisted(() => ({ client: null as unknown }));

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    if (!route.client) throw new Error("the tests pass their own client");
    return route.client;
  },
}));

// processLabResults upserts the biological age v3 shadow record with the service-role client: a scripted one here,
// so the test never reaches a real database (process-results.bio-age-v3.test.ts covers that write).
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => route.client ?? fakeSupabase(() => ({ data: null })).client };
});

// What the two routes need around processing, stubbed: the admin check, the profile, the AI summary, the patient
// context and the sender. Processing and the email template are the real ones.
vi.mock("@/lib/auth/require-admin", () => ({ requireAdmin: async () => ({ id: "admin-1" }), logAdminAction: async () => undefined }));
vi.mock("@/lib/queries", () => ({
  getUserProfile: async () => ({
    id: "22222222-2222-4222-8222-222222222222", full_name: "Ana Prueba", email: "u1@example.test", locale: "es",
    date_of_birth: "1981-01-01", sex: "male", subscription_status: "active",
  }),
  getWearableData: async () => [],
}));
vi.mock("@/lib/ai/generate-summary", () => ({ generateSummary: async () => undefined }));
vi.mock("@/lib/patient-context", () => ({ snapshotToLab: async () => undefined, getCurrentVersion: async () => null }));
vi.mock("@/lib/email/send", () => ({ sendEmail: vi.fn(async () => undefined) }));

const SEED = signedRows();
// The same rows with vitamin D's reference floor moved from 30 to 20 ng/mL: this panel's 24 ng/mL is then in
// range instead of out of range, so the two sets of rows give it different scores.
const SHIFTED = SEED.map((r) => (r.biomarker_key === "vitamin_d_25_oh" ? { ...r, normal_low: 20 } : r));
const AGE = 45;
// A typical 45-year-old man, in the units results are stored in.
const VALUES: Record<string, number> = {
  apolipoprotein_b_apob: 105, ldl_cholesterol: 130, hdl_cholesterol: 47, triglycerides: 140, hs_crp: 1.8,
  glucose_fasting: 96, hba1c: 5.5, insulin_fasting: 9, alt: 30, ast: 25, ggt: 32, albumin: 44, creatinine: 1.0,
  egfr_creatinine_based: 95, uric_acid: 6.0, alp: 72, total_bilirubin: 0.7, hemoglobin: 15.2, rdw: 13.2, mcv: 90,
  platelet_count: 240000, white_blood_cell_count: 6800, neutrophils: 60, lymphocytes: 30, lymphocytes_absolute: 2040,
  vitamin_d_25_oh: 24, vitamin_b12: 450, ferritin: 180, tsh: 1.9, shbg: 35, testosterone_total: 4.8,
};
const INPUTS = buildEngineInputs(Object.entries(VALUES).map(([biomarkerKey, value]) => ({ biomarkerKey, value })));

function database(rows: typeof SEED) {
  const dob = `${new Date().getFullYear() - AGE}-01-01`;
  const scoreUpdates: Array<Record<string, unknown>> = [];
  const respond = (c: FakeCall): FakeResponse => {
    if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { date_of_birth: dob, sex: "male" } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: rows.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "biomarker_values" && ops(c).startsWith("select")) {
      return { data: Object.entries(VALUES).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal" })) };
    }
    if (c.table === "lab_results" && ops(c).startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      if ("optimal_count" in update) scoreUpdates.push(update);
    }
    return { data: null };
  };
  const { client, calls } = fakeSupabase(respond);
  const referenceReads = () => calls.filter((c) => c.table === "biomarker_references").length;
  return { client, scoreUpdates, referenceReads };
}

const rawOf = (values: Record<string, number>) =>
  Object.entries(values).map(([key, value]) => ({
    name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const,
  }));
const raw = rawOf(VALUES);

beforeAll(() => {
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
});

describe("the premise", () => {
  it("the two sets of rows give this panel different scores, or the tests below prove nothing", () => {
    const [seed, shifted] = [SEED, SHIFTED].map((rows) => calculateLongevityScoreV2(INPUTS, "male", AGE, rows));
    expect([seed.validation.valid, shifted.validation.valid]).toEqual([true, true]);
    expect(seed.longevityScore).not.toBe(shifted.longevityScore);
    expect([seed, shifted].map((r) => r.markerScores.find((m) => m.code === "VITD")?.zone)).toEqual(["critical_low", "below_optimal"]);
  });
});

describe.each([
  ["the seed's rows", SEED],
  ["the rows with vitamin D's reference floor at 20 ng/mL", SHIFTED],
])("processing and recomputing store the score on %s", (_label, rows) => {
  const expected = calculateLongevityScoreV2(INPUTS, "male", AGE, rows);

  it("processLabResults: the score on the rows it classified with, read once", async () => {
    const db = database(rows);
    const result = await processLabResults("u1", "lab-1", raw, db.client);
    expect(result.fullBioAgeResult).toEqual(expected);
    expect(db.scoreUpdates[0]).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
    expect(db.referenceReads()).toBe(1); // the rows loaded for classification, not a second read
    // Vitamin D is scored in the zone it was classified and stored in.
    const stored = result.processed.find((p) => p.biomarkerKey === "vitamin_d_25_oh")?.zone;
    expect(expected.markerScores.find((m) => m.code === "VITD")?.zone).toBe(stored);
  });

  it("recomputeLabMetrics: the score on the rows it loads for the user's sex", async () => {
    const db = database(rows);
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    expect(db.scoreUpdates[0]).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
    expect(db.referenceReads()).toBe(1);
  });
});

// ─── No score: null, never 0 ───

const LAB = "11111111-1111-4111-8111-111111111111";
const USER = "22222222-2222-4222-8222-222222222222";
// What the lab's row holds from an earlier run, before each test processes or recomputes it.
const EARLIER = { longevity_score: 72, longevity_grade: "Very Good" };
// The Base Panel with HbA1c: KDM gives a biological age, but its 6 scoring markers cover 3 of the 5 domains (no
// inflammation, no blood count), so there is no score.
const BA_ONLY: Record<string, number> = {
  albumin: 44, creatinine: 1.0, bun: 15, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47, triglycerides: 140,
  fructosamine: 190, apolipoprotein_b_apob: 105, alt: 30, hba1c: 5.5,
};
// The same without HbA1c: measured fructosamine is set aside, so neither a biological age nor a score.
const NEITHER: Record<string, number> = {
  albumin: 44, creatinine: 1.0, bun: 15, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47, triglycerides: 140,
  fructosamine: 190, apolipoprotein_b_apob: 105, alt: 30,
};
// Fewer than 8 markers: the engine's coverage rule gives no score (processing has no gate of its own).
const FEW: Record<string, number> = { albumin: 44, creatinine: 1.0, hdl_cholesterol: 47, triglycerides: 140, alt: 30 };
// The Base Panel with HbA1c, hs-CRP and uric acid: eight scoring markers and a fourth domain, so the panel is scored.
const SCORED: Record<string, number> = { ...BA_ONLY, hs_crp: 1.8, uric_acid: 6.0 };

const scoreOf = (values: Record<string, number>) =>
  calculateLongevityScoreV2(buildEngineInputs(Object.entries(values).map(([biomarkerKey, value]) => ({ biomarkerKey, value }))), "male", AGE, SEED);
const baOf = (values: Record<string, number>) =>
  computeReferenceBA(Object.entries(values).map(([code, value]) => ({ code, value })), "male", AGE, { supplements: null });

type StoredValue = { biomarker_key: string; value: number; zone: string; comparator: "<" | ">" | null };

/**
 * One lab as the database holds it: the score of an earlier run (EARLIER), the given values as the recompute reads
 * them, and every update applied to the row. `rowsFail` makes the reference rows unreadable.
 */
function storedLab(
  values: Record<string, number>,
  options: { rowsFail?: boolean; rows?: readonly ReviewedRow[]; version?: Record<string, unknown> } = {},
) {
  const dob = `${new Date().getFullYear() - AGE}-01-01`;
  const lab: Record<string, unknown> = { id: LAB, user_id: USER, ...EARLIER };
  const figureUpdates: Array<Record<string, unknown>> = [];
  const stored: StoredValue[] = Object.entries(values).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal", comparator: null }));
  const respond = (c: FakeCall): FakeResponse => {
    const op = ops(c);
    if (c.table === "profiles" && op.startsWith("select")) return { data: { date_of_birth: dob, sex: "male" } };
    if (c.table === "biomarker_references") {
      const [column, list] = argsOf(c, "in") as [string, string[]];
      // The confirm route checks the keys it was sent; processing and the recompute read the rows for the user's sex.
      if (column === "biomarker_key") return { data: list.map((biomarker_key) => ({ biomarker_key })) };
      if (options.rowsFail) return { error: { message: "connection reset" } };
      return { data: (options.rows ?? SEED).filter((r) => list.includes(r.sex ?? "")) };
    }
    // The lab's patient context (loadLabState): the version recorded with the lab, when the test gives one.
    if (c.table === "lab_results" && argsOf(c, "select")?.[0] === LAB_STATE_LAB_COLUMNS) {
      return { data: options.version ? { patient_context_version_id: "ctx-1", created_at: null, transient_context: null } : null };
    }
    if (c.table === "patient_context_versions") return { data: options.version ?? null };
    if (c.table === "biomarker_values" && op.startsWith("select")) return { data: stored };
    if (c.table === "lab_results" && op.startsWith("insert")) return { data: { id: LAB } };
    if (c.table === "lab_results" && op.startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      Object.assign(lab, update);
      if ("optimal_count" in update) figureUpdates.push(update);
      return { data: null };
    }
    // The confirm route's ownership check; every other read of the lab (its context, the rolling average) finds none.
    if (c.table === "lab_results" && argsOf(c, "select")?.[0] === "id, user_id, status") return { data: { id: LAB, user_id: USER, status: "processing" } };
    return { data: null };
  };
  const { client, calls } = fakeSupabase(respond);
  /** How many times the reference rows were read for the person's sex (not the confirm route's key check). */
  const rowReads = () => calls.filter((c) => c.table === "biomarker_references" && (argsOf(c, "in") as [string, string[]])[0] === "sex").length;
  /** A value edit as the edit route stores it: the new value, its comparator and its zone. */
  const edit = (key: string, change: Omit<StoredValue, "biomarker_key">) => Object.assign(stored.find((v) => v.biomarker_key === key)!, change);
  return { client, lab, figureUpdates, edit, rowReads };
}

describe("values that give no score store null, never 0, and clear the score stored before", () => {
  beforeAll(() => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    // The premises, on the functions processing calls.
    expect(baOf(BA_ONLY)).not.toBeNull();
    expect(scoreOf(BA_ONLY).longevityScore).toBe(-1);
    expect(baOf(NEITHER)).toBeNull();
    expect(scoreOf(NEITHER).longevityScore).toBe(-1);
    expect(scoreOf(SCORED).longevityScore).toBeGreaterThan(0);
  });

  it.each([
    ["a biological age but no score", BA_ONLY],
    ["neither a biological age nor a score", NEITHER],
    ["fewer than 8 markers", FEW],
  ])("a reprocess (processLabResults) whose values give %s clears the stored score", async (_label, values) => {
    const db = storedLab(values);
    const result = await processLabResults(USER, LAB, rawOf(values), db.client);
    expect(db.figureUpdates).toHaveLength(1);
    expect(db.figureUpdates[0]).toHaveProperty("longevity_score", null);
    expect(db.figureUpdates[0]).toHaveProperty("longevity_grade", null);
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
    // What the routes email and return: no score, beside the biological age when there is one.
    expect(result.biologicalAge?.longevityScore ?? null).toBeNull();
    expect(result.biologicalAge?.lsGrade ?? null).toBeNull();
    expect(result.biologicalAge?.biologicalAge ?? null).toBe(baOf(values)?.BA ?? null);
  });

  it("recomputeLabMetrics: a value edit that breaks the gate clears the stored score", async () => {
    const db = storedLab(SCORED);
    // Before the edit the panel is scored, and the recompute stores its score over the earlier one.
    const before = scoreOf(SCORED);
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.lab).toMatchObject({ longevity_score: before.longevityScore, longevity_grade: before.lsGrade });

    // The edit: hs-CRP becomes "<5", stored with the zone the edit route gives it (classifyResultZone on its row). That
    // bound cannot be placed, so the score leaves hs-CRP out and 3 of the 5 domains remain.
    const crp = pickReferenceRows(SEED, "male", AGE).picked.get("hs_crp")!;
    const zone = classifyResultZone(5, "<", crp.optimal_low, crp.optimal_high, crp.normal_low, crp.normal_high);
    expect(zone).toBe("unclassified");
    db.edit("hs_crp", { value: 5, comparator: "<", zone });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.figureUpdates).toHaveLength(2);
    expect(db.figureUpdates[1]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });

  it("recomputeLabMetrics: fewer than 8 markers clears the stored score too", async () => {
    const db = storedLab(FEW);
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });

  it.each([
    ["a panel the rows would score", SCORED],
    ["a panel too small to score", FEW],
  ])("recomputeLabMetrics: reference rows that cannot be read clear the stored score (%s)", async (_label, values) => {
    const db = storedLab(values, { rowsFail: true });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    // The counts and the biological age are still written; the score is cleared, never left from the earlier run.
    expect(db.figureUpdates).toHaveLength(1);
    expect(db.figureUpdates[0]).toHaveProperty("biological_age", baOf(values)?.BA ?? null);
    expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });

  it("recomputeLabMetrics: once the rows can be read again, the score is stored again", async () => {
    const db = storedLab(SCORED, { rowsFail: true });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.lab).toMatchObject({ longevity_score: null });
    const readable = storedLab(SCORED);
    Object.assign(readable.lab, { longevity_score: null, longevity_grade: null });
    await recomputeLabMetrics(USER, LAB, readable.client as never);
    expect(readable.lab).toMatchObject({ longevity_score: scoreOf(SCORED).longevityScore, longevity_grade: scoreOf(SCORED).lsGrade });
  });
});

describe("the engine alone decides whether a panel is scored: it counts the markers that actually score", () => {
  // Eight score inputs over four domains, of which LDL-C is replaced by apoB: seven markers score.
  const SEVEN_SCORE: Record<string, number> = {
    apolipoprotein_b_apob: 105, ldl_cholesterol: 130, hdl_cholesterol: 47, triglycerides: 140, hba1c: 5.5, hs_crp: 1.8, alt: 30, albumin: 44,
  };
  // With uric acid an eighth marker scores (GGT would not do: ALT takes the liver group's place).
  const EIGHT_SCORE: Record<string, number> = { ...SEVEN_SCORE, uric_acid: 6.0 };
  const inputsOf = (values: Record<string, number>) => buildEngineInputs(Object.entries(values).map(([biomarkerKey, value]) => ({ biomarkerKey, value })));

  beforeAll(() => {
    expect(inputsOf(SEVEN_SCORE)).toHaveLength(8);
    expect(scoreOf(SEVEN_SCORE)).toMatchObject({ longevityScore: -1, validation: { totalMarkers: 7, domainsCovered: 4 } });
    expect(scoreOf(EIGHT_SCORE)).toMatchObject({ markersScored: 8, validation: { valid: true, totalMarkers: 8 } });
  });

  it("eight inputs of which seven score: processLabResults and recomputeLabMetrics store no score and clear the earlier one", async () => {
    const db = storedLab(SEVEN_SCORE);
    const result = await processLabResults(USER, LAB, rawOf(SEVEN_SCORE), db.client);
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(result.biologicalAge?.longevityScore ?? null).toBeNull();
    expect(result.scoreWithheld).toBeNull();
    const again = storedLab(SEVEN_SCORE);
    await recomputeLabMetrics(USER, LAB, again.client as never);
    expect(again.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });

  it("with an eighth marker that scores, both store the engine's score", async () => {
    const expected = scoreOf(EIGHT_SCORE);
    const db = storedLab(EIGHT_SCORE);
    const result = await processLabResults(USER, LAB, rawOf(EIGHT_SCORE), db.client);
    expect(db.lab).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
    expect(result.fullBioAgeResult?.markersScored).toBe(8);
    const again = storedLab(EIGHT_SCORE);
    await recomputeLabMetrics(USER, LAB, again.client as never);
    expect(again.lab).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
  });

  it("recomputeLabMetrics reads the reference rows whatever the number of values, so the critical tier covers every stored value", async () => {
    const db = storedLab(FEW);
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.rowReads()).toBe(1);
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });
});

describe("recomputeLabMetrics: a declared state that withholds the score clears it without the reference rows", () => {
  const pregnant = { version_number: 1, supplements: [], medications: [], conditions: { keys: ["pregnancy_current"] }, sex_specific: {} };
  const lactating = { ...pregnant, conditions: { keys: ["lactating"] } };

  beforeAll(() => { vi.spyOn(console, "error").mockImplementation(() => {}); });

  it.each([
    ["pregnancy", pregnant],
    ["lactation", lactating],
  ])("%s declared and the rows unreadable: the earlier score is cleared, and the rows are not read", async (_state, version) => {
    const db = storedLab(SCORED, { version, rowsFail: true });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.figureUpdates).toHaveLength(1);
    expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
    // The rows are not needed to withhold it, and are not read.
    expect(db.rowReads()).toBe(0);
  });

  it("no declared state and the rows unreadable: the read is attempted, and the stored score is cleared as well", async () => {
    const db = storedLab(SCORED, { rowsFail: true });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.rowReads()).toBe(1);
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });
});

// ─── Withheld scores, state exclusions and score inputs (docs/signoff/work/score/specification.md) ───

// A woman's context versions as the patient context stores them (options.ts keys).
const version = (fields: Record<string, unknown>) => ({ version_number: 1, supplements: [], medications: [], conditions: { keys: [] }, sex_specific: {}, ...fields });
const PREGNANT = version({ conditions: { keys: ["pregnancy_current"] } });
const LACTATING = version({ conditions: { keys: ["lactating"] } });
const ON_THE_PILL = version({ sex_specific: { contraception: "oral" } });
const stateOf = (v: Record<string, unknown>) => ({ supplements: null, state: resolveState({ version: v, transient: null }) });

describe("declared pregnancy or lactation: no score is stored", () => {
  beforeAll(() => {
    expect(scoreOf(SCORED).longevityScore).toBeGreaterThan(0); // the values alone give a score
    expect(stateOf(PREGNANT).state.pregnancy).toBe(true);
    expect(stateOf(LACTATING).state.lactation).toBe(true);
  });

  it.each([
    ["pregnancy", PREGNANT],
    ["lactation", LACTATING],
  ] as const)("processLabResults with %s in the lab's context: longevity_score null, the earlier score cleared, the reason returned", async (reason, v) => {
    // Once with the state the caller read, once with the state processing reads itself from the lab's context.
    for (const options of [{ labState: stateOf(v) }, undefined]) {
      const db = storedLab(SCORED, { version: v });
      const result = await processLabResults(USER, LAB, rawOf(SCORED), db.client, options);
      expect(db.figureUpdates).toHaveLength(1);
      expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
      expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
      expect(result.scoreWithheld).toBe(reason);
      expect(result.fullBioAgeResult).toBeNull();
      expect(result.biologicalAge?.longevityScore ?? null).toBeNull();
    }
  });

  it.each([
    ["pregnancy", PREGNANT],
    ["lactation", LACTATING],
  ] as const)("recomputeLabMetrics with %s in the lab's context: longevity_score null, the earlier score cleared", async (_reason, v) => {
    const db = storedLab(SCORED, { version: v });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.figureUpdates).toHaveLength(1);
    expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
  });

  it("the reason is returned for a panel too small to score as well; without a declared state nothing is withheld", async () => {
    const few = await processLabResults(USER, LAB, rawOf(FEW), storedLab(FEW).client, { labState: stateOf(PREGNANT) });
    expect(few.scoreWithheld).toBe("pregnancy");
    const plain = storedLab(SCORED);
    const result = await processLabResults(USER, LAB, rawOf(SCORED), plain.client, { labState: { supplements: null, state: UNKNOWN_STATE } });
    expect(result.scoreWithheld).toBeNull();
    expect(plain.lab).toMatchObject({ longevity_score: scoreOf(SCORED).longevityScore });
    // The gate failing is not a withholding.
    expect((await processLabResults(USER, LAB, rawOf(BA_ONLY), storedLab(BA_ONLY).client)).scoreWithheld).toBeNull();
  });
});

describe("a value in the critical tier: no score is stored, whether or not the value scores", () => {
  // The seed's rows with the critical fields of the draft critical-limits table on potassium (2.8 and 6.0 mEq/L),
  // a marker the score never reads, as the rows will carry them once the sign-off columns exist.
  const WITH_CRITICAL: ReviewedRow[] = SEED.map((r) => (r.biomarker_key === "potassium" ? { ...r, critical_low: 2.8, critical_high: 6 } : r));
  const panelWith = (potassium: number) => ({ ...SCORED, potassium });

  beforeAll(() => {
    // Potassium is not a score input: the panel scores the same with it, at any value, on either set of rows.
    const inputs = (values: Record<string, number>) => buildEngineInputs(Object.entries(values).map(([biomarkerKey, value]) => ({ biomarkerKey, value })));
    expect(inputs(panelWith(6.4))).toEqual(inputs(SCORED));
    expect(calculateLongevityScoreV2(inputs(panelWith(6.4)), "male", AGE, WITH_CRITICAL).withheld).toBeNull();
  });

  it.each([6.4, 6, 2.8, 2.1])("processLabResults: potassium %s mEq/L withholds the score and clears the earlier one", async (potassium) => {
    const db = storedLab(panelWith(potassium), { rows: WITH_CRITICAL });
    const result = await processLabResults(USER, LAB, rawOf(panelWith(potassium)), db.client);
    expect(result.processed.find((p) => p.biomarkerKey === "potassium")?.value).toBe(potassium);
    expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(result.scoreWithheld).toBe("critical_value");
    expect(result.fullBioAgeResult).toBeNull();
  });

  it("processLabResults: a bound already beyond the limit ('>6.5') withholds; one that only might be ('<3.0') does not", async () => {
    const bounded = (value: number, comparator: "<" | ">") =>
      rawOf(panelWith(value)).map((r) => (r.biomarkerKey === "potassium" ? { ...r, comparator } : r));
    const beyond = await processLabResults(USER, LAB, bounded(6.5, ">"), storedLab(SCORED, { rows: WITH_CRITICAL }).client);
    expect(beyond.scoreWithheld).toBe("critical_value");
    const maybe = await processLabResults(USER, LAB, bounded(3, "<"), storedLab(SCORED, { rows: WITH_CRITICAL }).client);
    expect(maybe.scoreWithheld).toBeNull();
    expect(maybe.biologicalAge?.longevityScore).toBe(scoreOf(SCORED).longevityScore);
  });

  it("recomputeLabMetrics: a stored potassium of 6.4 mEq/L withholds the score; edited back to 4.4 the score returns", async () => {
    const db = storedLab(panelWith(6.4), { rows: WITH_CRITICAL });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.figureUpdates[0]).toMatchObject({ longevity_score: null, longevity_grade: null });
    expect(db.lab).toMatchObject({ longevity_score: null, longevity_grade: null });
    db.edit("potassium", { value: 4.4, comparator: null, zone: "optimal" });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    const expected = scoreOf(SCORED);
    expect(db.lab).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
  });

  it("the control: inside the limits, and on rows without critical fields at any value, the score is stored", async () => {
    const expected = scoreOf(SCORED);
    for (const [potassium, rows] of [[4.4, WITH_CRITICAL], [5.9, WITH_CRITICAL], [6.4, SEED], [2.1, SEED]] as const) {
      const db = storedLab(panelWith(potassium), { rows });
      const result = await processLabResults(USER, LAB, rawOf(panelWith(potassium)), db.client);
      expect(result.scoreWithheld, `potassium ${potassium}`).toBeNull();
      expect(db.lab, `potassium ${potassium}`).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
      const again = storedLab(panelWith(potassium), { rows });
      await recomputeLabMetrics(USER, LAB, again.client as never);
      expect(again.lab, `potassium ${potassium}`).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
    }
  });
});

describe("oral oestrogen in the lab's context: hs-CRP is not scored", () => {
  // The scored panel with a blood count, so four domains remain covered without hs-CRP; hs-CRP at 8 mg/L.
  const PANEL: Record<string, number> = { ...SCORED, hemoglobin: 15.2, hs_crp: 8 };
  const inputs = buildEngineInputs(Object.entries(PANEL).map(([biomarkerKey, value]) => ({ biomarkerKey, value })));
  const declared = calculateLongevityScoreV2(inputs, "male", AGE, SEED, { oralOestrogen: true });
  const not = calculateLongevityScoreV2(inputs, "male", AGE, SEED);

  it("the premise: hs-CRP costs this panel points, and holds it below the top grade, unless oral oestrogen is declared", () => {
    expect(stateOf(ON_THE_PILL).state.oralOestrogen).toBe(true);
    expect(not.markerScores.find((m) => m.code === "HSCRP")).toMatchObject({ zone: "critical_high" });
    expect(not.longevityScore).toBeLessThanOrEqual(OUT_OF_RANGE_CAP.level);
    expect(declared.longevityScore).toBeGreaterThan(not.longevityScore);
    expect(declared.markerScores.some((m) => m.code === "HSCRP")).toBe(false);
  });

  it("processLabResults and recomputeLabMetrics store the score without hs-CRP", async () => {
    const db = storedLab(PANEL, { version: ON_THE_PILL });
    const result = await processLabResults(USER, LAB, rawOf(PANEL), db.client);
    expect(result.fullBioAgeResult).toEqual(declared);
    expect(result.fullBioAgeResult?.markerScores.some((m) => m.code === "HSCRP")).toBe(false);
    expect(result.fullBioAgeResult?.excludedMarkers).toEqual([{ code: "HSCRP", reason: "oral_oestrogen" }]);
    expect(db.lab).toMatchObject({ longevity_score: declared.longevityScore, longevity_grade: declared.lsGrade });
    // hs-CRP is still stored and classified against its interval.
    expect(result.processed.find((p) => p.biomarkerKey === "hs_crp")).toMatchObject({ value: 8, zone: "critical_high" });

    const again = storedLab(PANEL, { version: ON_THE_PILL });
    await recomputeLabMetrics(USER, LAB, again.client as never);
    expect(again.lab).toMatchObject({ longevity_score: declared.longevityScore, longevity_grade: declared.lsGrade });
  });
});

describe("only a result placed in a category is a score input", () => {
  // The scored panel with a blood count and a uric acid of 9.5 mg/dL, out of range on its row.
  const PANEL: Record<string, number> = { ...SCORED, hemoglobin: 15.2, uric_acid: 9.5 };
  const { uric_acid: _uricAcid, ...WITHOUT } = PANEL;
  void _uricAcid;

  it("recomputeLabMetrics: a uric acid stored unclassified is not scored; classified, it is", async () => {
    const [withUricAcid, without] = [scoreOf(PANEL), scoreOf(WITHOUT)];
    expect(withUricAcid.markerScores.find((m) => m.code === "URIC_ACID")).toMatchObject({ zone: "critical_high" });
    expect(withUricAcid.longevityScore).toBeLessThan(without.longevityScore);

    const db = storedLab(PANEL);
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.lab).toMatchObject({ longevity_score: withUricAcid.longevityScore });
    // A rule leaves the result without a category (no comparator: not a bound): the score no longer reads it.
    db.edit("uric_acid", { value: 9.5, comparator: null, zone: "unclassified" });
    await recomputeLabMetrics(USER, LAB, db.client as never);
    expect(db.lab).toMatchObject({ longevity_score: without.longevityScore, longevity_grade: without.lsGrade });
  });

  it("processLabResults: a uric acid its row gives no category is stored unclassified and is not an engine input", async () => {
    // The uric acid row with no bounds: the result is a value only.
    const rows = SEED.map((r) => (r.biomarker_key === "uric_acid" ? { ...r, optimal_low: null, optimal_high: null, normal_low: null, normal_high: null } : r));
    const db = storedLab(PANEL, { rows });
    const result = await processLabResults(USER, LAB, rawOf(PANEL), db.client);
    expect(result.processed.find((p) => p.biomarkerKey === "uric_acid")?.zone).toBe("unclassified");
    const scored = result.fullBioAgeResult!;
    expect(scored.markerScores.some((m) => m.code === "URIC_ACID")).toBe(false);
    expect(scored.markersMeasured).toBe(scoreOf(WITHOUT).markersMeasured); // uric acid never reached the engine
    expect(scored.longevityScore).toBe(scoreOf(WITHOUT).longevityScore);
  });

  it("a value-only result is not an input itself and still feeds the ratio computed from it: the white-cell percentages give the NLR", () => {
    const rows = [
      { biomarkerKey: "neutrophils", value: 60, valueOnly: true }, { biomarkerKey: "lymphocytes", value: 30, valueOnly: true },
      { biomarkerKey: "uric_acid", value: 9.5, valueOnly: true }, { biomarkerKey: "hba1c", value: 5.5 },
    ];
    expect(Object.fromEntries(buildEngineInputs(rows).map((i) => [i.code, i.value]))).toEqual({ HBA1C: 5.5, NLR: 2 });
  });
});

// The admin form sends display names with its rows' keys, and the route passes the key on, so processing does not
// match the names: the form's "Fructosamine", which the name matcher does not resolve, is processed too. The admin
// route is sent the values these names cover, which here is every value of the panels.
const ADMIN_NAMES: Record<string, string> = {
  albumin: "Albumin", creatinine: "Creatinine", bun: "BUN", ggt: "GGT", total_cholesterol: "Total Cholesterol",
  hdl_cholesterol: "HDL Cholesterol", triglycerides: "Triglycerides", apolipoprotein_b_apob: "ApoB", alt: "ALT",
  hba1c: "HbA1c", hs_crp: "hs-CRP", fructosamine: "Fructosamine", uric_acid: "Uric Acid",
};
const forAdmin = (values: Record<string, number>) => Object.fromEntries(Object.entries(values).filter(([key]) => key in ADMIN_NAMES));
const post = (url: string, body: unknown) => new NextRequest(`http://localhost${url}`, { method: "POST", body: JSON.stringify(body) });
const sendConfirm = (values: Record<string, number>) => confirm(post("/api/lab-results/confirm", { labResultId: LAB, biomarkers: rawOf(values) }));
const sendAdmin = (values: Record<string, number>) =>
  enterResults(post("/api/admin/enter-results", {
    userId: USER,
    biomarkers: Object.entries(forAdmin(values)).map(([key, value]) => ({
      name: ADMIN_NAMES[key], value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key,
    })),
  }));

/** The routes' client: the scripted lab, signed in as its owner. */
const signedIn = (client: SupabaseClient) =>
  Object.assign(client, { auth: { getUser: async () => ({ data: { user: { id: USER, email: "u1@example.test" } } }) } });

/** The data of the one results-ready email sent. */
function emailed(): ResultsReadyData {
  expect(sendEmail).toHaveBeenCalledTimes(1);
  const [to, template, data] = vi.mocked(sendEmail).mock.calls[0];
  expect([to, template]).toEqual(["u1@example.test", "results-ready"]);
  return data as ResultsReadyData;
}

describe.each([
  ["upload confirm", sendConfirm, (values: Record<string, number>) => values],
  ["admin enter-results", sendAdmin, forAdmin],
])("%s: the stored score and the results email follow the values", (_name, send, processed) => {
  beforeAll(() => {
    vi.spyOn(console, "error").mockImplementation(() => {});
    // The premise for the values this route processes: a biological age, no score.
    expect(baOf(processed(BA_ONLY))).not.toBeNull();
    expect(scoreOf(processed(BA_ONLY)).longevityScore).toBe(-1);
  });
  afterEach(() => {
    route.client = null;
    vi.mocked(sendEmail).mockClear();
  });

  it("the score gate fails while a KDM figure exists: longevity_score and longevity_grade are stored null, and the email data is null", async () => {
    const db = storedLab(BA_ONLY);
    route.client = signedIn(db.client);
    const res = await send(BA_ONLY);
    expect(res.status).toBe(200);
    // The biological age is stored; the score and grade are null, not 0 and "", and not the earlier run's.
    const ba = baOf(processed(BA_ONLY))!.BA;
    expect(db.lab).toMatchObject({ biological_age: ba, longevity_score: null, longevity_grade: null });
    // The email carries the KDM figure and no score, so neither language prints one.
    const data = emailed();
    expect(data).toMatchObject({ biologicalAge: ba, longevityScore: null });
    for (const locale of ["es", "en"]) expect(renderResultsReady(data, locale)).not.toMatch(/Longevity Score/);
    // The route's response carries no score either.
    const body = await res.json();
    expect(body.biologicalAge).toMatchObject({ biologicalAge: ba, longevityScore: null, lsGrade: null });
  });

  it("the control: a panel that gives a score stores it and emails it", async () => {
    const db = storedLab(SCORED);
    route.client = signedIn(db.client);
    const res = await send(SCORED);
    expect(res.status).toBe(200);
    const expected = scoreOf(processed(SCORED));
    expect(expected.longevityScore).toBeGreaterThan(0);
    expect(db.lab).toMatchObject({ longevity_score: expected.longevityScore, longevity_grade: expected.lsGrade });
    const data = emailed();
    expect(data.longevityScore).toBe(expected.longevityScore);
    expect(renderResultsReady(data, "en")).toContain(`Longevity Score: ${expected.longevityScore}/100`);
  });
});
