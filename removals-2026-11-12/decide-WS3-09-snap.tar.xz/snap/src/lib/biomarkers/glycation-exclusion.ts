/**
 * The HbA1c exclusion: when an HbA1c is not a reliable reading of glycaemia. One implementation, read by the
 * biological age (biological-age-v3-adapter.ts, which gives no HbA1c to the model then) and by the score
 * (process-results.ts, which tells the engine to pass HbA1c over: ruling D-06). Moved here unchanged from the
 * adapter, so that processing reads it without loading the biological age model.
 *
 * The rule, in order: haemoglobin below its own lower reference limit (anaemia); ferritin below its own lower limit
 * (iron deficiency); an eGFR below HBA1C_EGFR_LIMIT. The limits are the ones stored with each row.
 */
import { getCanonicalUnit, normalizeUnit } from "./canonical-units";

/** A stored result as the rule reads it (a biomarker_values row, stored or about to be stored). */
export interface GlycationRow {
  biomarker_key: string;
  value: number | string | null;
  unit?: string | null;
  /** "<" or ">" when the lab reported a bound; `value` is then the bound. */
  comparator?: string | null;
  /** The reference lower limit stored with the row, in the row's unit. */
  normal_low?: number | string | null;
}

export type GlycationExclusion = "anaemia" | "iron_deficiency" | "egfr_below_30";

/** eGFR (mL/min/1.73 m²) below which HbA1c is not used. */
export const HBA1C_EGFR_LIMIT = 30;

/** The seed key, and the key legacy rows may carry (key-aliases.ts remaps `egfr` to it). */
const EGFR_KEYS: ReadonlySet<string> = new Set(["egfr_creatinine_based", "egfr"]);

/** A finite number from a numeric column (supabase may return a string); NaN when there is none. */
export function numberOf(v: unknown): number {
  if (typeof v === "number") return v;
  if (typeof v === "string" && v.trim() !== "") return Number(v);
  return NaN;
}

function comparatorOf(v: unknown): "<" | ">" | null {
  return v === "<" || v === ">" ? v : null;
}

/**
 * A row's value and bound: the stored comparator with the value (the bound), or a value that still carries its prefix
 * ("<5", "> 8", "<0,500") read as that bound. The bound itself, never half of it. A row with a comparator column and
 * a prefixed value takes the column's comparator.
 */
export function resolvedValueOf(row: Pick<GlycationRow, "value" | "comparator">): { value: number; comparator: "<" | ">" | null } {
  const stored = comparatorOf(row.comparator);
  if (typeof row.value === "string") {
    const m = /^\s*([<>])\s*(.+)$/.exec(row.value);
    if (m) {
      const text = m[2].trim();
      const value = numberOf(text.includes(".") ? text : text.replace(",", "."));
      return { value, comparator: stored ?? (m[1] as "<" | ">") };
    }
  }
  return { value: numberOf(row.value), comparator: stored };
}

/** The value is below `limit`; a "<" bound at the limit is below it. False when either is not a number. */
function isBelow(row: GlycationRow, limit: number): boolean {
  const { value, comparator } = resolvedValueOf(row);
  if (!Number.isFinite(value) || !Number.isFinite(limit)) return false;
  return comparator === "<" ? value <= limit : value < limit;
}

/** Below the reference lower limit stored with the row (none stored: cannot tell, so not below). */
function isBelowOwnLowerLimit(row: GlycationRow): boolean {
  return isBelow(row, numberOf(row.normal_low));
}

/** An eGFR row in the app's eGFR unit (or stored without a unit). */
function isEgfrRow(row: GlycationRow): boolean {
  if (!EGFR_KEYS.has(row.biomarker_key)) return false;
  const unit = normalizeUnit(row.unit);
  return unit === "" || unit === normalizeUnit(getCanonicalUnit("egfr_creatinine_based"));
}

/** The first glycation exclusion that holds, in the assessment's order; null when none does. */
export function glycationExclusion(rows: readonly GlycationRow[]): GlycationExclusion | null {
  if (rows.some((r) => r.biomarker_key === "hemoglobin" && isBelowOwnLowerLimit(r))) return "anaemia";
  if (rows.some((r) => r.biomarker_key === "ferritin" && isBelowOwnLowerLimit(r))) return "iron_deficiency";
  if (rows.some((r) => isEgfrRow(r) && isBelow(r, HBA1C_EGFR_LIMIT))) return "egfr_below_30";
  return null;
}
