/**
 * The zone of a result that may be a bound (bounded-result.ts), and its use by processing: every result is classified
 * with it, the bound stays the stored value, a bound the app could not place is not scored, and a metric computed from
 * a bound is never classified as measured. How a reported result is read for storage (readReportedValue).
 * Scripted database (fake-supabase), no network.
 */
import { beforeAll, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { classifyResultZone, isBoundComparator, isUnplacedBound, LOWEST_POSSIBLE_VALUE, readReportedValue, type BoundComparator } from "./bounded-result";
import { getCanonicalUnit } from "./canonical-units";
import { processLabResults, recomputeLabMetrics, type RawBiomarker } from "./process-results";
import { classifyZone, type Zone } from "./zone-classifier";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));

// The biological age v3 shadow record is written with the service-role client: a scripted one, never a database.
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});

type Row = { oL: number | null; oH: number | null; nL: number | null; nH: number | null };
const zone = (value: number, comparator: BoundComparator | null | undefined, r: Row): Zone =>
  classifyResultZone(value, comparator, r.oL, r.oH, r.nL, r.nH);

// The rows the examples use, as supabase/seed-data and the B01 round-3 compile hold them.
const HS_CRP: Row = { oL: null, oH: 0.5, nL: 0, nH: 3 }; // seed: reference floor 0, no optimal floor
const HS_CRP_COMPILED: Row = { oL: null, oH: 0.5, nL: null, nH: 3 }; // B01 round 3: no floor at all
const FULL: Row = { oL: 20, oH: 30, nL: 10, nH: 40 }; // every bound
const FLOOR_ONLY: Row = { oL: 90, oH: null, nL: 75, nH: null }; // eGFR 18-39 in the seed
const EGFR_COMPILED: Row = { oL: 90, oH: 110, nL: 60, nH: null }; // eGFR 18-39 in the B01 round-3 compile
const CEILING_ONLY: Row = { oL: null, oH: 0.5, nL: null, nH: null }; // an optimal ceiling and nothing else
const SHARED_FLOOR: Row = { oL: 10, oH: 16, nL: 10, nH: 25 }; // BUN in the B01 round-3 compile
const POINT_BAND: Row = { oL: 5, oH: 5, nL: null, nH: null }; // a one-value optimal band
const NO_BOUNDS: Row = { oL: null, oH: null, nL: null, nH: null }; // e.g. free PSA, read only as a ratio

describe("classifyResultZone: a result without a comparator", () => {
  it("is classified exactly as classifyZone classifies its value", () => {
    const rows = [HS_CRP, HS_CRP_COMPILED, FULL, FLOOR_ONLY, EGFR_COMPILED, CEILING_ONLY, SHARED_FLOOR, POINT_BAND, NO_BOUNDS];
    const values = [-1, 0, 0.2, 0.5, 0.75, 3, 4, 5, 9, 10, 15, 16, 20, 25, 30, 35, 40, 41, 75, 90, 105, 110, 200, NaN, Infinity];
    let n = 0;
    for (const r of rows) {
      for (const v of values) {
        const want = classifyZone(v, r.oL, r.oH, r.nL, r.nH);
        expect(zone(v, null, r)).toBe(want);
        expect(zone(v, undefined, r)).toBe(want);
        n++;
      }
    }
    expect(n).toBe(rows.length * values.length);
  });
});

describe("classifyResultZone: the examples of the rule", () => {
  it('hs-CRP "<0.2" with an optimal ceiling of 0.5 and no floor is optimal, with or without a reference floor of 0', () => {
    expect(zone(0.2, "<", HS_CRP)).toBe("optimal");
    expect(zone(0.2, "<", HS_CRP_COMPILED)).toBe("optimal");
  });

  it('hs-CRP "<1.75" is unclassified, never above optimal (classifyZone puts 1.75 above optimal)', () => {
    expect(classifyZone(1.75, HS_CRP.oL, HS_CRP.oH, HS_CRP.nL, HS_CRP.nH)).toBe("above_optimal");
    expect(zone(1.75, "<", HS_CRP)).toBe("unclassified");
    expect(zone(1.75, "<", HS_CRP_COMPILED)).toBe("unclassified");
  });

  it('"<5" for a marker whose reference floor is 10 keeps the low zone classifyZone gives 5', () => {
    expect(zone(5, "<", FULL)).toBe("critical_low");
    expect(zone(5, "<", FULL)).toBe(classifyZone(5, FULL.oL, FULL.oH, FULL.nL, FULL.nH));
  });
});

describe("classifyResultZone: each comparator", () => {
  it('"<X": the zone of every value from 0 up to X, when they share one', () => {
    expect(zone(9, "<", FULL)).toBe("critical_low");
    expect(zone(12, "<", FULL)).toBe("unclassified"); // below the range or below optimal
    expect(zone(35, "<", FULL)).toBe("unclassified");
    expect(zone(60, "<", FLOOR_ONLY)).toBe("critical_low");
    expect(zone(80, "<", FLOOR_ONLY)).toBe("unclassified");
    expect(zone(0.4, "<", CEILING_ONLY)).toBe("optimal");
    expect(zone(0.6, "<", CEILING_ONLY)).toBe("unclassified");
  });

  it('"<=X" also allows X itself', () => {
    expect(zone(0.5, "<=", HS_CRP)).toBe("optimal"); // 0.5 itself is optimal
    expect(zone(9, "<=", FULL)).toBe("critical_low");
    expect(zone(10, "<=", FULL)).toBe("unclassified"); // 10 is in the range, everything below it is not
  });

  it('">X": the zone of every value above X, with no upper limit, when they share one', () => {
    expect(zone(45, ">", FULL)).toBe("critical_high");
    expect(zone(35, ">", FULL)).toBe("unclassified"); // above optimal or above the range
    expect(zone(95, ">", FLOOR_ONLY)).toBe("optimal"); // no ceiling: every value above 95 is optimal
    expect(zone(80, ">", FLOOR_ONLY)).toBe("unclassified");
    expect(zone(0.7, ">", CEILING_ONLY)).toBe("above_optimal"); // no reference ceiling: above optimal, whatever the value
    expect(zone(0.4, ">", CEILING_ONLY)).toBe("unclassified");
    expect(zone(90, ">", EGFR_COMPILED)).toBe("unclassified"); // "eGFR >90" may be optimal or above a ceiling of 110
    expect(zone(110, ">", EGFR_COMPILED)).toBe("above_optimal");
  });

  it('">=X" also allows X itself', () => {
    expect(zone(41, ">=", FULL)).toBe("critical_high");
    expect(zone(40, ">=", FULL)).toBe("unclassified"); // 40 is in the range, everything above it is not
    expect(zone(0.5, ">=", CEILING_ONLY)).toBe("unclassified"); // 0.5 is optimal, above it is not
  });
});

describe("classifyResultZone: a bound exactly at a threshold", () => {
  it("each threshold belongs to the side classifyZone puts it on", () => {
    // Reference floor 10: values below it are below the range, 10 itself is not.
    expect(zone(10, "<", FULL)).toBe("critical_low");
    expect(zone(10, "<=", FULL)).toBe("unclassified");
    // Reference ceiling 40: values above it are above the range, 40 itself is not.
    expect(zone(40, ">", FULL)).toBe("critical_high");
    expect(zone(40, ">=", FULL)).toBe("unclassified");
    // Optimal ceiling 0.5 (no optimal floor, reference floor 0): every value from 0 to 0.5 is optimal.
    expect(zone(0.5, "<", HS_CRP)).toBe("optimal");
    expect(zone(0.5, "<=", HS_CRP)).toBe("optimal");
    // Optimal floor 90 (eGFR): 90 and everything above it is optimal when there is no ceiling.
    expect(zone(90, ">", FLOOR_ONLY)).toBe("optimal");
    expect(zone(90, ">=", FLOOR_ONLY)).toBe("optimal");
    expect(zone(75, "<", FLOOR_ONLY)).toBe("critical_low");
    expect(zone(75, "<=", FLOOR_ONLY)).toBe("unclassified");
  });

  it("an optimal floor equal to the reference floor, and a one-value optimal band", () => {
    expect(zone(10, "<", SHARED_FLOOR)).toBe("critical_low");
    expect(zone(10, "<=", SHARED_FLOOR)).toBe("unclassified"); // 10 is optimal
    expect(zone(25, ">", SHARED_FLOOR)).toBe("critical_high");
    expect(zone(5, "<", POINT_BAND)).toBe("below_optimal");
    expect(zone(5, "<=", POINT_BAND)).toBe("unclassified"); // 5 itself is optimal
    expect(zone(5, ">", POINT_BAND)).toBe("above_optimal");
    expect(zone(5, ">=", POINT_BAND)).toBe("unclassified");
  });
});

describe("classifyResultZone: rows with and without floors and ceilings, and null bounds", () => {
  it("a row with no bounds cannot place any result", () => {
    for (const c of ["<", "<=", ">", ">=", null] as const) expect(zone(5, c, NO_BOUNDS)).toBe("unclassified");
  });

  it("a reference floor only, or a reference ceiling only", () => {
    const refFloor: Row = { oL: null, oH: null, nL: 10, nH: null };
    expect(zone(5, "<", refFloor)).toBe("critical_low");
    expect(zone(10, ">=", refFloor)).toBe("optimal"); // nothing above the floor limits it
    expect(zone(12, "<", refFloor)).toBe("unclassified");
    const refCeiling: Row = { oL: null, oH: null, nL: null, nH: 40 };
    expect(zone(30, "<", refCeiling)).toBe("optimal");
    expect(zone(40, ">", refCeiling)).toBe("critical_high");
    expect(zone(30, ">", refCeiling)).toBe("unclassified");
  });

  it("an optimal floor only, or an optimal band with no reference limits", () => {
    const optFloor: Row = { oL: 205, oH: null, nL: null, nH: null };
    expect(zone(200, "<", optFloor)).toBe("below_optimal");
    expect(zone(210, ">", optFloor)).toBe("optimal");
    expect(zone(210, "<", optFloor)).toBe("unclassified");
    const band: Row = { oL: 20, oH: 30, nL: null, nH: null };
    expect(zone(20, "<", band)).toBe("below_optimal");
    expect(zone(30, ">", band)).toBe("above_optimal");
    expect(zone(25, "<", band)).toBe("unclassified");
  });
});

describe("classifyResultZone: values no result can have", () => {
  it('"<0" and below allow no value; "<=0" allows only 0', () => {
    expect(LOWEST_POSSIBLE_VALUE).toBe(0);
    expect(zone(0, "<", HS_CRP)).toBe("unclassified");
    expect(zone(-1, "<", HS_CRP)).toBe("unclassified");
    expect(zone(0, "<=", HS_CRP)).toBe(classifyZone(0, HS_CRP.oL, HS_CRP.oH, HS_CRP.nL, HS_CRP.nH));
    expect(zone(0, "<=", FULL)).toBe("critical_low");
  });

  it('">X" below 0 allows every value from 0 up', () => {
    expect(zone(-5, ">", FLOOR_ONLY)).toBe("unclassified");
    expect(zone(-5, ">", NO_BOUNDS)).toBe("unclassified");
    expect(zone(-5, ">=", { oL: null, oH: null, nL: 0, nH: null })).toBe("optimal");
  });

  it("a bound that is not a finite number, or an unknown comparator, cannot be placed", () => {
    expect(zone(NaN, "<", HS_CRP)).toBe("unclassified");
    expect(zone(Infinity, ">", FULL)).toBe("unclassified");
    expect(zone(-Infinity, "<", FULL)).toBe("unclassified");
    expect(zone(0.2, "=" as unknown as BoundComparator, HS_CRP)).toBe("unclassified");
    expect(isBoundComparator("<")).toBe(true);
    expect(isBoundComparator("=")).toBe(false);
    expect(isBoundComparator(null)).toBe(false);
  });
});

describe("classifyResultZone against a brute-force reading of the rule", () => {
  // Every row is built from these bounds, each of the four taken independently (so bounds coincide, cross and go
  // missing). They are multiples of 5 and the grid steps by 0.25 up to 50, so it holds every bound, values strictly
  // between any two of them and values between a bound and any bound value tried; past 40 nothing changes, and 1000
  // stands for "far above".
  const BOUNDS = [null, 0, 5, 10, 20, 30, 40] as const;
  const GRID = [...Array.from({ length: 201 }, (_, i) => i * 0.25), 1000];
  const BOUND_VALUES = [0, 0.5, 2.5, 5, 7.5, 10, 11, 15, 20, 25, 30, 35, 40, 45, 60];
  const COMPARATORS = ["<", "<=", ">", ">="] as const;
  function* rows(): Generator<Row> {
    for (const oL of BOUNDS) for (const oH of BOUNDS) for (const nL of BOUNDS) for (const nH of BOUNDS) yield { oL, oH, nL, nH };
  }
  const allows = (v: number, x: number, c: BoundComparator) =>
    c === "<" ? v < x : c === "<=" ? v <= x : c === ">" ? v > x : v >= x;
  /** The one zone of every grid value the bound allows, else "unclassified" (also when it allows none). */
  const oracle = (gridZones: Zone[], x: number, c: BoundComparator): Zone => {
    let first: Zone | null = null;
    for (let i = 0; i < GRID.length; i++) {
      if (!allows(GRID[i], x, c)) continue;
      if (first === null) first = gridZones[i];
      else if (gridZones[i] !== first) return "unclassified";
    }
    return first ?? "unclassified";
  };

  it("agrees on every row built from the bounds, every comparator and every bound value", () => {
    let checked = 0;
    for (const r of rows()) {
      const gridZones = GRID.map((v) => classifyZone(v, r.oL, r.oH, r.nL, r.nH));
      for (const x of BOUND_VALUES) {
        for (const c of COMPARATORS) {
          const got = zone(x, c, r);
          const want = oracle(gridZones, x, c);
          if (got !== want) throw new Error(`${c}${x} on ${JSON.stringify(r)}: ${got}, brute force ${want}`);
          checked++;
        }
      }
    }
    expect(checked).toBe(BOUNDS.length ** 4 * BOUND_VALUES.length * COMPARATORS.length);
  });

  it('a "<" bound is never above optimal or above the range, and a ">" bound never below, on rows without negative bounds', () => {
    const wrong: string[] = [];
    for (const r of rows()) {
      for (const x of BOUND_VALUES) {
        for (const c of ["<", "<="] as const) if (["above_optimal", "critical_high"].includes(zone(x, c, r))) wrong.push(`${c}${x} ${JSON.stringify(r)}`);
        for (const c of [">", ">="] as const) if (["below_optimal", "critical_low"].includes(zone(x, c, r))) wrong.push(`${c}${x} ${JSON.stringify(r)}`);
      }
    }
    expect(wrong).toEqual([]);
  });
});

describe("isUnplacedBound", () => {
  it("is a result with a comparator that the app left unclassified, and nothing else", () => {
    expect(isUnplacedBound({ comparator: "<", zone: "unclassified" })).toBe(true);
    expect(isUnplacedBound({ comparator: ">", zone: "unclassified" })).toBe(true);
    expect(isUnplacedBound({ comparator: "<", zone: "optimal" })).toBe(false);
    expect(isUnplacedBound({ comparator: null, zone: "unclassified" })).toBe(false); // no reference row: not a bound
    expect(isUnplacedBound({ zone: "unclassified" })).toBe(false);
  });
});

// ─── Reading a reported result (the upload, the administrator's entry, the manual lab provider) ───

describe("readReportedValue", () => {
  it('a printed "<5" or ">8,000" keeps its sign, and the value is the bound, read as lab-provider/hl7.ts parseHl7Value reads it', () => {
    expect(readReportedValue("<5")).toEqual({ value: 5, comparator: "<", review: null });
    expect(readReportedValue("< 0,500")).toEqual({ value: 0.5, comparator: "<", review: null });
    expect(readReportedValue(">8,000")).toEqual({ value: 8, comparator: ">", review: null });
    expect(readReportedValue("5,4")).toEqual({ value: 5.4, comparator: null, review: null });
  });

  it("a number with the sign beside it keeps the sign; a number alone, or with no sign, is measured", () => {
    expect(readReportedValue(5, "<")).toEqual({ value: 5, comparator: "<", review: null });
    expect(readReportedValue(90, ">")).toEqual({ value: 90, comparator: ">", review: null });
    for (const none of [undefined, null, "", "="]) expect(readReportedValue(44, none)).toEqual({ value: 44, comparator: null, review: null });
    // The text and the sign beside it may both say it.
    expect(readReportedValue("<5", "<")).toEqual({ value: 5, comparator: "<", review: null });
  });

  it('"≤" and "≥", however written, are not stored as a sign: no comparator, and the printed sign to review (D-24)', () => {
    for (const [value, comparator, review] of [
      ["≤5", null, "≤"], ["<=5", null, "≤"], ["⩽ 5", null, "≤"], [5, "≤", "≤"], [5, "<=", "≤"], ["<5", "≤", "≤"],
      ["≥5", null, "≥"], [">= 5", null, "≥"], [5, "≥", "≥"], [5, "=>", "≥"],
    ] as const) {
      expect(readReportedValue(value, comparator), `${value} ${comparator}`).toEqual({ value: 5, comparator: null, review });
    }
  });

  it("no number, a comparator that is not a sign, or a text and a sign pointing opposite ways: nothing is read", () => {
    for (const [value, comparator] of [
      ["pending", null], ["", null], [null, null], [undefined, null], [Number.NaN, null], [Infinity, "<"],
      [5, "~"], [5, 1], ["<5", ">"], ["≤5", ">"], [">5", "<="],
    ] as const) {
      expect(readReportedValue(value, comparator), `${String(value)} ${String(comparator)}`).toBeNull();
    }
  });
});

// ─── Processing ───

const ROWS = reviewedRows();
const AGE = 45;
// A typical 45-year-old man, in the units results are stored in (process-results.score.test.ts).
const VALUES: Record<string, number> = {
  apolipoprotein_b_apob: 105, ldl_cholesterol: 130, hdl_cholesterol: 47, triglycerides: 140, hs_crp: 1.8,
  glucose_fasting: 96, hba1c: 5.5, insulin_fasting: 9, alt: 30, ast: 25, ggt: 32, albumin: 44, creatinine: 1.0,
  egfr_creatinine_based: 95, uric_acid: 6.0, alp: 72, total_bilirubin: 0.7, hemoglobin: 15.2, rdw: 13.2, mcv: 90,
  platelet_count: 240000, white_blood_cell_count: 6800, lymphocytes_absolute: 2040,
  vitamin_d_25_oh: 24, vitamin_b12: 450, ferritin: 180, tsh: 1.9, shbg: 35, testosterone_total: 4.8,
};

function database(stored: Array<Record<string, unknown>> = []) {
  const dob = `${new Date().getFullYear() - AGE}-01-01`;
  const inserted: Array<Record<string, unknown>> = [];
  const scoreUpdates: Array<Record<string, unknown>> = [];
  const respond = (c: FakeCall): FakeResponse => {
    if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { date_of_birth: dob, sex: "male" } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "biomarker_values" && ops(c).startsWith("insert")) inserted.push(...(argsOf(c, "insert")?.[0] as Array<Record<string, unknown>>));
    if (c.table === "biomarker_values" && ops(c).startsWith("select")) return { data: stored };
    if (c.table === "lab_results" && ops(c).startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      if ("optimal_count" in update) scoreUpdates.push(update);
    }
    return { data: null };
  };
  // `project`: rows come back with the columns the code selected, so the recompute must ask for the comparator.
  const { client } = fakeSupabase(respond, { project: true });
  return { client, inserted, scoreUpdates };
}

const plain = (key: string, value: number): RawBiomarker => ({
  name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact",
});
const panel = (hsCrp: RawBiomarker | null): RawBiomarker[] => [
  ...Object.entries(VALUES).filter(([k]) => k !== "hs_crp").map(([k, v]) => plain(k, v)),
  ...(hsCrp ? [hsCrp] : []),
];

async function processed(raw: RawBiomarker[]) {
  const db = database();
  const result = await processLabResults("u1", "lab-1", raw, db.client);
  return { result, inserted: db.inserted, scoreUpdate: db.scoreUpdates[0] };
}

describe("processLabResults classifies every result with classifyResultZone", () => {
  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  it("stores the bound itself with its comparator, and places it only where every value it allows has one zone", async () => {
    const { result, inserted } = await processed([
      { ...plain("hs_crp", 0.2), comparator: "<" },
      // 5 mmol/L is 30.03 mg/dL: below it lie values below the range, below optimal and optimal.
      { name: "urea", value: 5, unit: "mmol/L", comparator: "<", biomarkerKey: "urea", matchConfidence: "exact" },
      { ...plain("egfr_creatinine_based", 90), comparator: ">" },
      plain("albumin", 44),
    ]);
    const row = (key: string) => inserted.find((r) => r.biomarker_key === key)!;
    expect(row("hs_crp")).toMatchObject({ value: 0.2, reported_value: 0.2, comparator: "<", zone: "optimal" });
    expect(row("urea")).toMatchObject({ value: 5 * 6.006, reported_value: 5, comparator: "<", zone: "unclassified" });
    // A laboratory's own eGFR keeps its bound and its sign and is a value only: no category (lab-reported.ts).
    expect(row("egfr_creatinine_based")).toMatchObject({ value: 90, comparator: ">", zone: "unclassified", optimal_low: null, normal_low: null });
    expect(row("albumin")).toMatchObject({ value: 44, comparator: null });
    for (const p of result.processed) expect(p.zone).toBe(row(p.biomarkerKey).zone);
    expect(result.processed.find((p) => p.biomarkerKey === "urea")).toMatchObject({ zoneLabel: "Unclassified", zoneLabel_es: "Sin Clasificar" });
  });

  it("classifies a result without a comparator exactly as classifyZone does, on the row it stores", async () => {
    const { inserted } = await processed(panel(plain("hs_crp", 1.8)));
    expect(inserted.length).toBe(Object.keys(VALUES).length);
    for (const r of inserted) {
      expect(r.comparator).toBeNull();
      expect(r.zone).toBe(classifyZone(r.value as number, r.optimal_low as number | null, r.optimal_high as number | null, r.normal_low as number | null, r.normal_high as number | null));
    }
  });

  it("a bound it could not place is not scored, and one it placed is", async () => {
    const without = await processed(panel(null));
    const unplaced = await processed(panel({ ...plain("hs_crp", 1.75), comparator: "<" }));
    const measured = await processed(panel(plain("hs_crp", 1.75)));
    const placed = await processed(panel({ ...plain("hs_crp", 0.2), comparator: "<" }));
    const measuredLow = await processed(panel(plain("hs_crp", 0.2)));

    expect(unplaced.inserted.find((r) => r.biomarker_key === "hs_crp")).toMatchObject({ value: 1.75, comparator: "<", zone: "unclassified" });
    expect(measured.inserted.find((r) => r.biomarker_key === "hs_crp")).toMatchObject({ zone: "above_optimal" });
    // Scoring 1.75 would change the score, so leaving it out is what keeps "<1.75" out of it.
    expect(measured.result.fullBioAgeResult).not.toEqual(without.result.fullBioAgeResult);
    expect(unplaced.result.fullBioAgeResult).toEqual(without.result.fullBioAgeResult);
    expect(unplaced.scoreUpdate).toMatchObject({ longevity_score: without.scoreUpdate.longevity_score, attention_count: without.scoreUpdate.attention_count });
    // A placed bound is scored as its bound.
    expect(placed.result.fullBioAgeResult).toEqual(measuredLow.result.fullBioAgeResult);
    // The biological age still reads the bound (biological-age-v3-adapter.ts states the same rule for version 3).
    expect(unplaced.result.kdmBiologicalAge).toEqual(measured.result.kdmBiologicalAge);
  });

  it("hands each result's comparator to the derived metrics: a HOMA-IR from a bounded insulin is never classified as measured", async () => {
    const homa = (r: Awaited<ReturnType<typeof processed>>) => r.result.calculatedMetrics.find((m) => m.metricKey === "homa_ir");
    // Measured, insulin 9 with glucose 96 gives 2.13, above the 1.8 ceiling of the homa_ir row.
    const measured = await processed(panel(plain("hs_crp", 1.8)));
    expect(homa(measured)).toMatchObject({ value: 2.13, comparator: null, zone: "above_optimal" });
    // "<9" allows every HOMA-IR from 0 up to 2.13, optimal or above: it cannot be placed.
    const raw = panel(plain("hs_crp", 1.8)).map((b) => (b.biomarkerKey === "insulin_fasting" ? { ...b, comparator: "<" as const } : b));
    const bounded = await processed(raw);
    expect(homa(bounded)).toMatchObject({ value: 2.13, comparator: "<", zone: "unclassified" });
  });
});

describe("recomputeLabMetrics leaves a bound the app could not place out of the score", () => {
  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  const storedPanel = (hsCrp: Record<string, unknown> | null) => [
    ...Object.entries(VALUES)
      .filter(([k]) => k !== "hs_crp")
      .map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal", comparator: null })),
    ...(hsCrp ? [{ biomarker_key: "hs_crp", ...hsCrp }] : []),
  ];
  async function recomputed(stored: Array<Record<string, unknown>>) {
    const db = database(stored);
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    return db.scoreUpdates[0];
  }

  it("as processing does", async () => {
    const without = await recomputed(storedPanel(null));
    const unplaced = await recomputed(storedPanel({ value: 2.5, zone: "unclassified", comparator: "<" }));
    const measured = await recomputed(storedPanel({ value: 2.5, zone: "above_optimal", comparator: null }));
    expect(measured.longevity_score).not.toBe(without.longevity_score);
    expect(unplaced.longevity_score).toBe(without.longevity_score);
    expect(unplaced.biological_age).toBe(measured.biological_age);
  });
});
