export type Zone =
  | "critical_low"
  | "below_optimal"
  | "optimal"
  | "above_optimal"
  | "critical_high"
  | "unclassified";

// critical_low / critical_high are stored codes and stay as they are. They mean
// "outside the reference range", not a laboratory critical (panic) value, so
// their labels say "range", never "critical".
export const ZONE_CONFIG: Record<
  Zone,
  { color: string; bg: string; label: string; label_es: string; tone: string }
> = {
  critical_low: { color: "#b04040", bg: "rgba(176,64,64,0.10)", label: "Below Range", label_es: "Por Debajo del Rango", tone: "action" },
  below_optimal: { color: "#c49332", bg: "rgba(196,147,50,0.12)", label: "Below Optimal", label_es: "Por Debajo del Optimo", tone: "caution" },
  optimal: { color: "#3a665e", bg: "rgba(58,102,94,0.10)", label: "Optimal", label_es: "Optimo", tone: "positive" },
  above_optimal: { color: "#c49332", bg: "rgba(196,147,50,0.12)", label: "Above Optimal", label_es: "Por Encima del Optimo", tone: "caution" },
  critical_high: { color: "#b04040", bg: "rgba(176,64,64,0.10)", label: "Above Range", label_es: "Por Encima del Rango", tone: "action" },
  unclassified: { color: "#8a7f76", bg: "rgba(138,127,118,0.10)", label: "Unclassified", label_es: "Sin Clasificar", tone: "neutral" },
};
