/**
 * Unit tests for supplements.ts — supplement dose parsing + the creatine adjustment of creatinine.
 */
import { describe, it, expect } from "vitest";
import {
  parseSupplementDose,
  resolveSupplementDose,
  creatineDoseGramsPerDay,
  readCreatineDose,
  creatineCreatinineDivisor,
  creatineAdjustedCreatinine,
  CREATINE_CREATININE_RISE,
  CREATINE_SATURATING_DOSE_G,
} from "./supplements";

describe("parseSupplementDose", () => {
  it("parses compact unit (10g)", () => {
    expect(parseSupplementDose("10g")).toEqual({ value: 10, unit: "g" });
  });

  it("parses spaced unit (10 g)", () => {
    expect(parseSupplementDose("10 g")).toEqual({ value: 10, unit: "g" });
  });

  it("parses long unit (10grams)", () => {
    expect(parseSupplementDose("10grams")).toEqual({ value: 10, unit: "g" });
  });

  it("returns null-unit when only a number is given", () => {
    expect(parseSupplementDose("5000")).toEqual({ value: 5000, unit: null });
  });

  it("parses micrograms variants", () => {
    expect(parseSupplementDose("1000 mcg")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("1000 ug")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("1000 µg")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("1000micrograms")).toEqual({ value: 1000, unit: "mcg" });
  });

  it("strips trailing /day suffix", () => {
    expect(parseSupplementDose("1000mcg/day")).toEqual({ value: 1000, unit: "mcg" });
  });

  it("handles decimals", () => {
    expect(parseSupplementDose("2.5 g")).toEqual({ value: 2.5, unit: "g" });
  });

  it("handles surrounding whitespace", () => {
    expect(parseSupplementDose("  2.5 g  ")).toEqual({ value: 2.5, unit: "g" });
  });

  it("normalizes mg variants", () => {
    expect(parseSupplementDose("400 milligrams")).toEqual({ value: 400, unit: "mg" });
    expect(parseSupplementDose("400mg")).toEqual({ value: 400, unit: "mg" });
  });

  it("normalizes IU variants", () => {
    expect(parseSupplementDose("5000 units")).toEqual({ value: 5000, unit: "iu" });
    expect(parseSupplementDose("5000IU")).toEqual({ value: 5000, unit: "iu" });
  });

  it("returns null when no numeric content", () => {
    expect(parseSupplementDose("daily")).toBeNull();
    expect(parseSupplementDose("")).toBeNull();
    expect(parseSupplementDose(null)).toBeNull();
    expect(parseSupplementDose(undefined)).toBeNull();
  });
});

describe("resolveSupplementDose", () => {
  it("uses parsed unit when present", () => {
    expect(resolveSupplementDose("creatine", "10g")).toEqual({ value: 10, unit: "g" });
  });

  it("applies default unit when none specified", () => {
    expect(resolveSupplementDose("creatine", "5")).toEqual({ value: 5, unit: "g" });
    expect(resolveSupplementDose("vitamin_d", "5000")).toEqual({ value: 5000, unit: "iu" });
    expect(resolveSupplementDose("b12", "1000")).toEqual({ value: 1000, unit: "mcg" });
  });

  it("returns null when dose can't be parsed", () => {
    expect(resolveSupplementDose("creatine", "daily")).toBeNull();
    expect(resolveSupplementDose("creatine", null)).toBeNull();
  });

  it("leaves unit null when supplement has no default", () => {
    expect(resolveSupplementDose("rare_unknown_supplement", "10")).toEqual({
      value: 10,
      unit: null,
    });
  });
});

describe("parseSupplementDose, Spanish spellings and separators", () => {
  it("reads Spanish unit words", () => {
    expect(parseSupplementDose("5 gramos")).toEqual({ value: 5, unit: "g" });
    expect(parseSupplementDose("5 gr")).toEqual({ value: 5, unit: "g" });
    expect(parseSupplementDose("5grs")).toEqual({ value: 5, unit: "g" });
    expect(parseSupplementDose("500 miligramos")).toEqual({ value: 500, unit: "mg" });
    expect(parseSupplementDose("1000 microgramos")).toEqual({ value: 1000, unit: "mcg" });
    expect(parseSupplementDose("4000 UI")).toEqual({ value: 4000, unit: "iu" });
  });

  it("reads a decimal comma", () => {
    expect(parseSupplementDose("2,5 g")).toEqual({ value: 2.5, unit: "g" });
    expect(parseSupplementDose("0,5 g/día")).toEqual({ value: 0.5, unit: "g" });
  });

  it("reads groups of three digits as a thousands separator", () => {
    expect(parseSupplementDose("5.000 mg")).toEqual({ value: 5000, unit: "mg" });
    expect(parseSupplementDose("5,000 mg")).toEqual({ value: 5000, unit: "mg" });
    expect(parseSupplementDose("10.000 UI")).toEqual({ value: 10000, unit: "iu" });
    expect(parseSupplementDose("0.500 g")).toEqual({ value: 0.5, unit: "g" });
  });

  it("keeps a unit word it does not know, so the caller can refuse it", () => {
    expect(parseSupplementDose("1 scoop")).toEqual({ value: 1, unit: "scoop" });
    expect(parseSupplementDose("2 cápsulas")).toEqual({ value: 2, unit: "cápsulas" });
  });
});

describe("creatineDoseGramsPerDay", () => {
  it("is null without creatine, or without a usable dose", () => {
    expect(creatineDoseGramsPerDay(null)).toBeNull();
    expect(creatineDoseGramsPerDay(undefined)).toBeNull();
    expect(creatineDoseGramsPerDay([])).toBeNull();
    expect(creatineDoseGramsPerDay([{ key: "vitamin_d", dose: "5000" }])).toBeNull();
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: null }])).toBeNull();
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: "daily" }])).toBeNull();
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: "0 g" }])).toBeNull();
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: "1 scoop" }])).toBeNull();
  });

  it("reads grams, milligrams and Spanish spellings", () => {
    const dose = (d: string) => creatineDoseGramsPerDay([{ key: "creatine", dose: d }]);
    expect(dose("5g")).toBe(5);
    expect(dose("5 g/día")).toBe(5);
    expect(dose("5 gramos")).toBe(5);
    expect(dose("5 gr")).toBe(5);
    expect(dose("2,5 g")).toBe(2.5);
    expect(dose("5000 mg")).toBe(5);
    expect(dose("5.000 mg")).toBe(5);
  });

  it("reads a dose without a unit as grams below 100, else as milligrams; more than 50 g a day is not read", () => {
    const dose = (d: string) => creatineDoseGramsPerDay([{ key: "creatine", dose: d }]);
    expect(dose("5")).toBe(5);
    expect(dose("50")).toBe(50);
    expect(dose("51")).toBeNull();
    expect(dose("99")).toBeNull();
    expect(dose("100")).toBeCloseTo(0.1, 10);
    expect(dose("500")).toBeCloseTo(0.5, 10);
    expect(dose("750")).toBeCloseTo(0.75, 10);
    expect(dose("5000")).toBe(5);
  });

  it("reads the production case (10 g/day among other supplements)", () => {
    const supplements = [
      { key: "b12", dose: "1000" },
      { key: "creatine", dose: "10g" },
      { key: "vitamin_d", dose: "5000" },
    ];
    expect(creatineDoseGramsPerDay(supplements)).toBe(10);
  });
});

describe("readCreatineDose, the forms clients write", () => {
  const cases: [string, number | null][] = [
    // Unit spellings, and a bare number with a daily qualifier.
    ["5 gm", 5], ["5 gms", 5], ["5 grms", 5], ["5 mgs", null], ["5000 mg", 5], ["creatina 5g", 5],
    ["5 al día", 5], ["5/día", 5], ["5 diarios", 5], ["5 daily", 5], ["1,5", 1.5],
    // Ranges read their lower end.
    ["3 a 5 g", 3], ["entre 3 y 5 g", 3], ["3 o 5 g", 3], ["3-5 g", 3],
    // Products and servings with a mass.
    ["2 x 5 g", 10], ["2x5g", 10], ["5 g x 2", 10], ["2 tomas de 2,5 g", 5], ["2 cápsulas de 750 mg", 1.5],
    ["1 cacito de 5 g", 5], ["1 medida de 5 g", 5], ["1 cucharadita (5 g)", 5], ["1 scoop (5 g)", 5],
    // A count of servings with a bracketed amount: each, or the total? The form asks.
    ["2 cacitos (10 g)", null], ["2 cápsulas (750 mg)", null], ["2 scoops = 10 g", 10], ["5 g (2 cápsulas)", 5],
    // A day's total split into intakes is the total.
    ["5 g en 2 tomas", 5], ["2 g divididos en 2 tomas", 2], ["1,5 g en dos tomas al día", 1.5],
    // Separators: three decimals in grams are decimals; space groups are thousands; a leading mark is 0.x.
    ["1,250 g", 1.25], ["1.500 g", 1.5], ["2,500 g", 2.5], ["0.500 g", 0.5], ["5.000 mg", 5],
    ["2 500 mg", 2.5], ["2\u00a0500 mg", 2.5], ["2\u202f500 mg", 2.5], ["1 500 mg", 1.5], [".5 g", 0.5], [",5 g", 0.5],
    // Servings: "x" as well as "de", number words, a range of servings reads its lower end.
    ["4 cápsulas x 750 mg", 3], ["2-3 cápsulas de 750 mg", 1.5], ["2 o 3 cápsulas de 750 mg", 1.5],
    ["una cucharadita de 5 g", 5], ["media cucharadita de 5 g", 2.5],
    // How often: some days a week, every other day, a weekly amount, more than once a day.
    ["3 días a la semana, 5 g", (5 * 3) / 7], ["4 días/semana 5 g", (5 * 4) / 7], ["5 g tres días a la semana", (5 * 3) / 7],
    ["5 g, 3 por semana", (5 * 3) / 7], ["5 g three times a week", (5 * 3) / 7], ["5 g 3x/week", (5 * 3) / 7],
    ["5 g x 3 días a la semana", (5 * 3) / 7], ["5 g cada dos días", 2.5], ["5 g en días alternos", 2.5],
    ["5 g a la semana", 5 / 7], ["5 g/semana", 5 / 7], ["35 g a la semana", 5], ["5 g semanales", 5 / 7],
    ["2,5 g 2 veces al día", 5], ["2,5 g dos veces al día", 5], ["2.5 g twice a day", 5], ["5 g, 2x/día", 10],
    ["5 g x 2 veces al día", 10], ["1 cacito (5 g) 2 veces al día", 10], ["2 tomas al día de 2,5 g", 5],
    ["2 tomas de 2,5 g al día", 5], ["5 g, 3 días a la semana, 2 veces al día", (10 * 3) / 7],
    // A duration changes nothing, and is never a multiplier.
    ["5 g al día durante 2 semanas", 5], ["2,5 g x 30 días", 2.5], ["5 g x 4 semanas", 5], ["5 g desde hace 2 meses", 5],
    // Ranges with a unit at both ends; "y" joins two doses when each has its unit.
    ["3 g a 5 g", 3], ["entre 3 g y 5 g", 3], ["3 y 5 g", 3], ["5 g los días de entreno (3 por semana)", (5 * 3) / 7],
    // Two amounts that are neither a range nor a product: unreadable.
    ["1 g mañana y 1 g noche", null], ["1 g y 1 g", null], ["20 g durante 5 días y luego 5 g", null], ["5 g (5000 mg)", null],
    ["2 cápsulas de 750 mg y 1 g por la noche", null],
    // Not readable as grams a day: the context form asks for grams then.
    ["0,3 g/kg/día", null], ["0,1 g/kg", null], ["1/2 g", null], ["3/5 g", null], ["1 scoop", null],
    ["2 cápsulas", null], ["daily", null], ["", null],
    // Two ways of saying how often that disagree: every day, or three days a week?
    ["5 g al día (entreno 3 días a la semana)", null], ["5 g al día en días alternos", null], ["8 días a la semana 5 g", null],
    ["0 g", 0],
    // Third review. Singular and abbreviated durations change nothing.
    ["5 g durante una semana", 5], ["5 g desde hace una semana", 5], ["5g, started a week ago", 5], ["5 g for a week", 5],
    ["1,5 g x 30d", 1.5], ["1 g x 3 sem", 1],
    // A count before "semanales" or "weekly"; "x" for "por"; "sem"; every N days or hours; times daily.
    ["5 g, 3 días semanales", (5 * 3) / 7], ["5 g 3x weekly", (5 * 3) / 7], ["5 g 3 d/semana", (5 * 3) / 7],
    ["5 g twice weekly", (5 * 2) / 7], ["5 g 1 vez x semana", 5 / 7], ["5 g 3 días x semana", (5 * 3) / 7],
    ["5 g x semana", 5 / 7], ["5 g/sem", 5 / 7], ["1 g 2 veces x día", 2], ["5 g cada 3 días", 5 / 3],
    ["5 g every 2 days", 2.5], ["5 g every third day", 5 / 3], ["5 g día sí, día no", 2.5], ["1 g cada 12 horas", 2],
    ["1g c/8h", 3], ["1 g 3 veces diarias", 3], ["1 g 3 times daily", 3], ["1,5 g mañana y noche", 3], ["2.5g bid", 5],
    ["1 g en desayuno, comida y cena", 3], ["5 g, una vez al día", 5],
    // A range of frequencies reads its lower end, as amounts do.
    ["5 g, 2-3 veces por semana", (5 * 2) / 7], ["1 g 2-3 veces al día", 2], ["1 g, 1 o 2 veces al día", 1],
    // Servings: more words, "each", juxtaposed, "N de", a count before a mass and a serving word.
    ["4 gominolas de 1 g", 4], ["4 capsulas 750mg", 3], ["2 cápsulas (750 mg cada una)", 1.5], ["4 gummies (1g each)", 4],
    ["2 de 750 mg", 1.5], ["4 diarias de 750mg", 3], ["2 500mg capsules", 1], ["half a 5g scoop", 2.5],
    ["2 comprimidos masticables de 1,5 g", 3], ["4 gominolas, 1 g", null], ["2,5 g por toma, 2 tomas", null],
    // Informal decimal marks and halves.
    ["2'5 g", 2.5], ["0'75 g", 0.75], ["1´5 gr", 1.5], ["2 gramos y medio", 2.5], ["1⁄2 g", null],
    // Asked, not guessed: per kilogram, two doses, no count of days, stopped, a unit slip, no period.
    ["0,3 g/kilo", null], ["0,1 g x kg", null], ["0.3 g kg-1 día-1", null], ["1,5 g por la mañana y 1,5 por la noche", null],
    ["2,5 g + 2,5", null], ["5 g los lunes", null], ["5 g los días de entreno", null], ["5 g una semana sí y otra no", null],
    ["ya no tomo (antes 5 g)", null], ["5g (stopped 1 month ago)", null], ["5 mg", null], ["1,5g 2x", null],
    ["1,5 g, dos veces", null],
    // Fourth review. A duration followed by a per-week phrase is a frequency; hedged, past and ranged durations.
    ["5 g durante 3 días a la semana", 15 / 7], ["5 g for 3 days a week", 15 / 7], ["llevo 4 días a la semana tomando 5 g", 20 / 7],
    ["5 g for about a week", 5], ["5 g desde hace casi un mes", 5], ["5 g al día los últimos 3 meses", 5],
    ["5 g/día desde la semana pasada", 5], ["5 g daily for the last 2 weeks", 5], ["durante 2-3 semanas 5 g", 5],
    ["1 g x 2-3 semanas", 1], ["5 g (1ª semana)", 5], ["5 g al día durante 2 semanas", 5],
    // Intervals of weeks or months, irregular intake, a negated day word, a week word left unread: the form asks.
    ["5 g cada 2 semanas", null], ["5 g every 2 weeks", null], ["5 g cada mes", null], ["5 g quincenal", null],
    ["5 g fortnightly", null], ["5 g cada quince días", null], ["5 g a veces", null], ["5 g cuando entreno", null],
    ["5 g when I train", null], ["5 g en ciclos", null], ["5 g, no todos los días", null], ["5 g not every day", null],
    ["5 g durante la semana", null], ["5 g 8 semanas sí, 4 no", null], ["5 g 8 weeks on, 4 off", null],
    ["5 g los lun, mié y vie", null], ["5 g toda la semana", 5], ["5 g cada semana", 5 / 7],
    // "once or twice" (Spanish "once" is eleven, not a count), "thrice".
    ["1 g once or twice a day", 1], ["5 g once or twice a week", 5 / 7], ["1 g thrice daily", 3], ["5 g thrice weekly", 15 / 7],
    ["5 g once a day", 5], ["5 g once a week", 5 / 7],
    // Times of day in one list: one intake each, unless the day's total is split; a count of times must agree.
    ["2,5 g por la mañana y por la noche", 5], ["1 g mañana, tarde y noche", 3], ["2,5 g am y pm", 5],
    ["2,5 g morning and evening", 5], ["5 g repartidos entre mañana y noche", 5], ["5 g en 2 tomas, mañana y noche", 5],
    ["2,5 g dos veces al día, mañana y noche", 5], ["1 g dos veces al día: mañana, tarde y noche", null],
    ["2 g repartidos entre desayuno y cena", 2], ["5 g en 2 tomas, desayuno y cena", 5],
    ["1 cápsula mañana, tarde y noche (750 mg)", 2.25], ["5 g por la mañana", 5], ["5 g each morning", 5],
    // Per unit of body weight, in more spellings; a container's size is not one.
    ["0,3 g/kilo/día", null], ["0,1 g/kilogramo", null], ["0.1 g/lb", null], ["0,3 g kg−1", null], ["0,3 g kg⁻¹", null],
    ["0,3 g * kg", null], ["0.3 g·kg⁻¹·d⁻¹", null], ["5 g (bote de 1 kilo)", 5],
    // Stopped, in more forms; "ya no hago carga" and "antes de entrenar" are not.
    ["tomaba 5 g", null], ["5 g, la he dejado", null], ["solía tomar 5 g", null], ["5 g (suspendida)", null],
    ["was taking 5 g", null], ["5 g, on hold", null], ["previously 5 g", null], ["ya no hago carga, 5 g", 5],
    ["5 g antes de entrenar", 5], ["5 g antes del gym", 5],
    // A count is never cut out of another number; "each" with no count read; a digit before the amount; zero.
    ["750mg each, 4 al día", null], ["5 g cada una", null], ["0 5 g", null], ["2:5 g", null], ["2, 5 g", null], ["0,0 g", 0],
    // More apostrophes; "y medio" after a decimal is unclear; "tres cuartos de".
    ["2′5 g", 2.5], ["2ʼ5 g", 2.5], ["2＇5 g", 2.5], ["2,5 g y medio", null], ["2 g y media", 2.5],
    ["1 cacito y medio (7,5 g)", 7.5], ["tres cuartos de cacito de 4 g", 3],
    // More every-other-day and days-a-week wording.
    ["5 g día por medio", 2.5], ["5 g interdiario", 2.5], ["5 g 3 v/sem", 15 / 7], ["5 g 3 días de cada semana", 15 / 7],
    ["5 g semanalmente", 5 / 7], ["Creapure 100% 5 g", 5], ["5 g 1 hora antes de entrenar", 5],
    // Fifth review.
    // Stopped, in more unambiguous forms; current doses that mention a pause or no loading are read.
    ["estaba tomando 5 g", null], ["estuve tomando 5 g hasta agosto", null], ["5 g, llevo un mes sin tomarla", null],
    ["5 g hasta hace un mes", null], ["5 g until 2 weeks ago", null], ["5 g until last month", null], ["5 g, la he parado", null],
    ["5 g (parada)", null], ["5 g en ayunas, sin tomar nada más", 5], ["5 g, en descanso también", 5], ["5 g desde hace 2 meses", 5],
    ["5 g, ahora no hago carga", 5], ["5 g, actualmente no hago fase de carga", 5], ["5 g, ahora no", null],
    // Times of day joined by "o", or by a slash, are one intake; plurals and "al/a/de" are read in lists.
    ["1 g mañana, tarde o noche", 1], ["1 g por la mañana, por la tarde o por la noche", 1], ["1 g in the morning, afternoon or evening", 1],
    ["2 g mañana/tarde", 2], ["1 g am/pm", 1], ["1 g mañana, tarde y noche", 3],
    ["2,5 g por las mañanas y por las noches", 5], ["2.5 g mornings and evenings", 5], ["2,5 g por la mañana y al mediodía", 5],
    ["2,5 g de mañana y de noche", 5],
    // Meals joined by "o" are one intake.
    ["1,5 g con la comida o la cena", 1.5], ["1 g en desayuno, comida o cena", 1], ["1 g with breakfast or lunch", 1],
    // A count of intakes written both as a count and as a list is one count; servings with a mass stay each time.
    ["2 tomas de 1 g, mañana y noche", 2], ["2 tomas de 1 g (desayuno y cena)", 2], ["1 g x2 (mañana y noche)", 2],
    ["1 g x 2, mañana y noche", 2], ["2 x 1 g con desayuno y cena", 2], ["3 tomas de 0,5 g: mañana, tarde y noche", 1.5],
    ["1 g x 3: mañana, tarde y noche", 3], ["2 cápsulas de 750 mg mañana y noche", 3], ["2,5 g dos veces al día, mañana y noche", 5],
    // Schedules without a count of days, in more spellings; irregular intake asks whatever else is said.
    ["5 g on Mondays and Thursdays", null], ["5 g Saturdays", null], ["5 g Tues/Thurs", null], ["5 g M-F", null], ["5 g MWF", null],
    ["3 g de L a V", null], ["5 g LMXJV", null], ["5 g días laborables", null], ["5 g si me acuerdo", null],
    ["5 g siempre que me acuerdo", null], ["5 g if I remember", null], ["5 g most days", null], ["5 g el fin de semana", null],
    ["5 g, 3 días a la semana, a veces 4", null],
    // A duration before "semanales", "semanalmente" or "weekly" is a frequency.
    ["5 g durante 3 días semanales", 15 / 7], ["5 g for 3 days weekly", 15 / 7], ["llevo 3 días semanales tomando 5 g", 15 / 7],
    ["5 g durante 3 días semanalmente", 15 / 7], ["5 g durante 3 semanas", 5], ["5 g for 2 weeks", 5],
    // Before and after training: two intakes on training days, which are not counted.
    ["2,5 g antes y después de entrenar", null], ["1,5 g antes y después del entreno", null], ["2.5 g before and after training", null],
    ["1,5 g pre y post entreno", null],
    // Clear daily doses that must be read.
    ["5 g todos los días de la semana", 5], ["5 g cada día de la semana", 5], ["5 g every day of the week", 5],
    ["5 g/día, empecé esta semana", 5], ["5 g daily, started this week", 5], ["5 g/día desde esta semana", 5],
    ["5 g al día, no hago ciclos", 5], ["5 g/día, sin ciclo", 5], ["5 g daily, no cycling", 5], ["5 g/day, I don't cycle it", 5],
    ["desde 2024, 5 g al día", 5], ["2024: 5 g/día", 5], ["a las 9, 1 g", 1], ["8:00 1 g", 1],
    ["1. 5 g al día", null], ["5 g en ciclos", null], ["5 g cycling", null],
    // Every other day, "v" for veces, half an hour.
    ["2 g día de por medio", 1], ["5 g día por medio", 2.5], ["1 g 2 v/día", 2], ["1 g 2 v. al día", 2],
    ["2 g y media hora antes de entrenar", 2], ["2 g y media", 2.5],
    // Ranges in either order read their lower end; a clock time is never an amount; more than 50 g a day asks.
    ["5 a 3 g", 3], ["5-3 g", 3], ["desde 2023 - 1,5 g/día", 1.5], ["a las 8 - 2 g", 2], ["3 g a las 8 - 2 g a las 20", null],
    ["a las 9 750 mg", 0.75], ["60 g", null], ["50 g", 50], ["bote de 300 g, 1 cacito al día", null],
    // Halves and pairs.
    ["2 y ½ g", 2.5], ["1 g un par de veces al día", 2], ["1 g a couple of times a day", 2],
    // Sixth review.
    // "a las" before a count is not a clock time; several clock times with no count of times a day ask.
    ["pasé a las 4 cápsulas de 750 mg al día", 3], ["bajé a las 2 cápsulas de 750 mg al día", 1.5], ["llegué a las 4 gominolas de 1 g", 4],
    ["a las 2 tomas de 1 g al día", 2], ["5 g diarios (analítica a las 3 semanas de empezar)", 5], ["5 g al día; a las 2 semanas me hice la analítica", 5],
    ["a las 9 1 g, a las 14 1 y a las 21 1", null], ["a las 7: 1,5 g. A las 19: 1,5", null], ["a las 8 2,5 g y a las 20 2,5", null],
    ["a las 9 y a las 21, 1,5 g cada vez", null], ["a las 8 y a las 20, 2,5 g", null], ["5 g a las 9", 5], ["a las 9, 1 g", 1],
    // An "o" pair next to times joined by "y": the count is unclear, it asks; an "o" list alone is one intake.
    ["1 g por la mañana o al mediodía y por la noche", null], ["1 g por la mañana y por la tarde o por la noche", null],
    ["1 g morning and afternoon or night", null], ["2 g mañana y noche, o mediodía y noche", null],
    ["2,5 g mañana y noche (mañana o mediodía según el día)", null], ["1 g con el desayuno o la comida, y con la cena", null],
    ["1 g mañana o tarde y noche", null], ["1 g mañana, tarde o noche", 1], ["1,5 g con la comida o la cena", 1.5],
    ["1 g in the morning, afternoon or evening", 1],
    // "esta semana" is a duration only next to a start.
    ["2 g, una vez esta semana", null], ["2 g, 3 días esta semana", null], ["2 g, esta semana solo un día", null],
    ["2 g, 3 days this week", null], ["5 g twice this week", null], ["5 g/día, esta semana no", null], ["5 g, empiezo esta semana", null],
    ["5 g, empezaré esta semana", null], ["5 g/día, empecé esta semana", 5], ["5 g daily, started this week", 5],
    ["5 g/día desde esta semana", 5], ["5 g al día (esta semana empecé)", 5],
    // An "x" count of servings with a mass of their own stays each time.
    ["2 x 750 mg cápsulas, mañana y noche", 3], ["750 mg x 2 cápsulas mañana y noche", 3], ["2x750mg caps mañana y noche", 3],
    ["3 x 500 mg cápsulas mañana, tarde y noche", 4.5], ["2 x 1 g comprimidos, mañana y noche", 4], ["1 g x2 (mañana y noche)", 2],
    // "a veces" and the like followed by a timing describe when; irregular intake without one asks.
    ["5 g 3 días a la semana, a veces con la comida", 15 / 7], ["5 g 3 veces por semana, no siempre los mismos días", 15 / 7],
    ["5 g 3 días a la semana, algunos días por la mañana", 15 / 7], ["5 g en días alternos, a veces por la mañana y a veces por la noche", 2.5],
    ["35 g a la semana, a veces repartidos", 5], ["5 g/día, siempre que puedo en ayunas", 5], ["5 g diarios, siempre que puedo con el desayuno", 5],
    ["5 g al día, la mayoría de los días por la mañana", 5], ["5 g daily, most days with breakfast", 5], ["5 g 3x/semana, nunca hago ciclos", 15 / 7],
    ["5 g 3 días a la semana, sin descanso ni ciclos", 15 / 7], ["5 g, 3 días a la semana, a veces 4", null], ["5 g si me acuerdo", null],
    ["5 g en ciclos", null], ["1.5g, most days en ayunas", null], ["5 g a veces", null],
    // A negated stop, or past phrasing next to a current dose, is a current dose.
    ["5 g al día, nunca he parado", 5], ["5 g (no la he parado nunca)", 5], ["5 g al día, no he parado de tomarla desde 2022", 5],
    ["5 g diarios, sin haber parado en 2 años", 5], ["Carga hasta hace 2 semanas, ahora 5 g", 5], ["5 g, hasta hace un mes en ayunas, ahora con comida", 5],
    ["5 g, lo estaba tomando por la noche y ahora por la mañana", 5], ["5 g, estuve tomando creapure y ahora otra marca", 5],
    ["5 g daily, loading until 2 weeks ago", null], ["5 g hasta hace un mes", null], ["estaba tomando 5 g", null], ["5 g, la he parado", null],
    ["5 g (parada)", null], ["5 g, ahora no", null],
    // "de la semana" after a daily word, unless the week is limited.
    ["2 g todos los días de la semana que entreno", null], ["2 g cada día de la semana que entreno", null], ["2 g every day of the week I train", null],
    ["2 g todos los días de la semana, salvo los que descanso", null], ["2 g todos los días de la semana de entreno", null],
    ["2 g todos los días de la semana laboral", null], ["2 g todos los días de la semana menos uno", null], ["2 g every day of the week but one", null],
    ["2 g x días de la semana", null], ["5 g todos los días de la semana", 5], ["5 g cada día de la semana", 5], ["5 g every day of the week", 5],
    // "un par de veces" before a lapse is not a frequency.
    ["5 g al día, un par de veces se me ha olvidado", 5], ["5 g, un par de veces me la he saltado", 5], ["1 g un par de veces al día", 2],
  ];
  it.each(cases)("%j reads %s g/day", (dose, expected) => {
    const g = readCreatineDose(dose);
    if (expected === null) expect(g).toBeNull();
    else expect(g).toBeCloseTo(expected, 10);
  });

  it("does not read a text longer than the context form stores", () => {
    expect(readCreatineDose(`5 g${" ".repeat(117)}`)).toBe(5);
    expect(readCreatineDose(`5 g${" ".repeat(118)}`)).toBeNull();
  });

  it("is what the biological age uses", () => {
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: "3 a 5 g" }])).toBe(3);
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: "0,3 g/kg/día" }])).toBeNull();
    expect(creatineDoseGramsPerDay([{ key: "creatine", dose: "0 g" }])).toBeNull();
  });
});

describe("creatineCreatinineDivisor", () => {
  it("is 1 without a dose", () => {
    expect(creatineCreatinineDivisor(null)).toBe(1);
    expect(creatineCreatinineDivisor(undefined)).toBe(1);
    expect(creatineCreatinineDivisor(0)).toBe(1);
    expect(creatineCreatinineDivisor(-5)).toBe(1);
    expect(creatineCreatinineDivisor(NaN)).toBe(1);
  });

  it("grows with the dose up to 3 g/day, then stays at the pooled trial rise", () => {
    expect(CREATINE_CREATININE_RISE).toBe(0.13);
    expect(CREATINE_SATURATING_DOSE_G).toBe(3);
    expect(creatineCreatinineDivisor(1)).toBeCloseTo(1 + 0.13 / 3, 10);
    expect(creatineCreatinineDivisor(1.5)).toBeCloseTo(1.065, 10);
    expect(creatineCreatinineDivisor(3)).toBeCloseTo(1.13, 10);
    expect(creatineCreatinineDivisor(5)).toBeCloseTo(1.13, 10);
    expect(creatineCreatinineDivisor(20)).toBeCloseTo(1.13, 10);
    expect(creatineCreatinineDivisor(Infinity)).toBe(1);
  });
});

describe("creatineAdjustedCreatinine", () => {
  it("leaves creatinine unchanged without a declared dose", () => {
    expect(creatineAdjustedCreatinine(1.1, null)).toBe(1.1);
    expect(creatineAdjustedCreatinine(1.1, [{ key: "creatine", dose: null }])).toBe(1.1);
  });

  it("removes the pooled 13% rise from 3 g/day, in proportion to the person's creatinine", () => {
    const supplements = [{ key: "creatine", dose: "5 g" }];
    expect(creatineAdjustedCreatinine(1.13, supplements)).toBeCloseTo(1.0, 10);
    expect(creatineAdjustedCreatinine(0.791, supplements)).toBeCloseTo(0.7, 10);
    // Any unit: a ratio, not a fixed amount.
    expect(creatineAdjustedCreatinine(99.89, supplements)).toBeCloseTo(88.4, 2);
  });
});
