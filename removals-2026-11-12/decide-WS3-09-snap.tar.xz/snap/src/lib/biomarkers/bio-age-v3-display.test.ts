/**
 * Biological age display: the version 3 formatting rules (bio-age-v3-display.ts, display-copy.json), the version 3
 * card, the two display flags (bio-age-flags.ts), and the old KDM figure hidden when BIO_AGE_KDM_VISIBLE is off:
 * server-side row stripping (dashboard and lab pages), the results-ready email and the AI chat context.
 */
import fs from "node:fs";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import {
  BIO_AGE_V3_DISPLAY,
  RELIABLE_CHANGE_YEARS,
  buildBioAgeV3View,
  changeKind,
  copyFor,
  directionOf,
  flatSegmentTexts,
  refusalReasons,
  wholeYearsFigure,
} from "./bio-age-v3-display";
import type { BioAgeV3Record, BioAgeV3Stored } from "./biological-age-v3-adapter";
import {
  KDM_LAB_FIELDS,
  KDM_PROFILE_FIELDS,
  chatBioAgeLine,
  flagOn,
  isBioAgeKdmVisible,
  isBioAgeV3Visible,
  labForDisplay,
  profileForDisplay,
} from "./bio-age-flags";
import { renderResultsReady, type ResultsReadyData } from "@/lib/email/templates/results-ready";
import { BiologicalAgeV3Card } from "@/components/dashboard/BiologicalAgeV3Card";
import type { LabResult, Profile } from "@/lib/queries/types";

const ROOT = path.resolve(__dirname, "../../..");

/** A stored record with a figure; only the fields the display reads matter. */
function rec(over: Partial<BioAgeV3Record> = {}): BioAgeV3Record {
  return {
    model_sha256: "x",
    adapter_version: "x",
    computed_at: "2026-11-01T00:00:00Z",
    tier: "base",
    ba: 46.6,
    interval_low: 43.2,
    interval_high: 49.9,
    markers_used: [],
    clamps_applied: [],
    crp_capped: false,
    provisional: false,
    hba1c_source: null,
    hba1c_excluded_reason: null,
    reason: null,
    reasons: [],
    rules_version: "x",
    collection_method: "venous",
    bounded_markers: [],
    lab_source: "eva_kit",
    base_from_eva_laboratory: true,
    creatine_g_per_day: null,
    creatinine_divisor: 1,
    ...over,
  } as BioAgeV3Record;
}

function refused(codes: string[]): BioAgeV3Record {
  return rec({
    tier: null,
    ba: null,
    interval_low: null,
    interval_high: null,
    reason: codes[0] as BioAgeV3Record["reason"],
    reasons: codes.map((code) => ({ code, detail: "" })) as BioAgeV3Record["reasons"],
  });
}

/** Every string a view carries, joined, to scan for placeholders and forbidden words. */
function viewText(v: ReturnType<typeof buildBioAgeV3View>): string {
  return Object.values(v)
    .flatMap((x) => (Array.isArray(x) ? x : [x]))
    .filter((x): x is string => typeof x === "string")
    .join("\n");
}

// B6's list (scripts/signoff/checks/bioage.ts) plus wording-rules.md section 8 and 3.1.
const FORBIDDEN =
  /\b(validated|validado|validada|predicts?|predice|predicción|prediction|mortality|mortalidad|death|muerte|prognosis|pronóstico|survival|supervivencia|risk|riesgo)\b/i;

// ─── Formatting rules ───

describe("whole years and the 95% range", () => {
  it("rounds the age to the nearest year and the range outward", () => {
    expect(wholeYearsFigure(46.6, 43.2, 49.9)).toEqual({ ba: 47, low: 43, high: 50 });
    expect(wholeYearsFigure(46.4, 43.9, 49.1)).toEqual({ ba: 46, low: 43, high: 50 });
  });

  it("always shows the range with the figure, in both languages", () => {
    const en = buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "en" });
    expect(en.kind).toBe("figure");
    expect(en.figure).toBe("Estimated biological age: 47 years (95% range: 43 to 50)");
    const es = buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "es" });
    expect(es.figure).toBe("Edad biológica estimada: 47 años (intervalo del 95 %: 43 a 50)");
  });

  it("never shows a figure without its range: a record missing it is shown as not calculated", () => {
    const v = buildBioAgeV3View({ record: rec({ interval_high: null }), chronologicalAge: 47, locale: "en" });
    expect(v.kind).toBe("refused");
    expect(v.figure).toBeNull();
    expect(v.refusalReasons).toEqual([copyFor("en").refusal.reasons.error]);
  });
});

describe("younger or older only when the range excludes the age", () => {
  it("judges on the range shown", () => {
    expect(directionOf(55, { low: 43, high: 50 })).toBe("younger");
    expect(directionOf(51, { low: 43, high: 50 })).toBe("younger");
    expect(directionOf(50, { low: 43, high: 50 })).toBe("indistinct");
    expect(directionOf(43, { low: 43, high: 50 })).toBe("indistinct");
    expect(directionOf(42, { low: 43, high: 50 })).toBe("older");
  });

  it("uses the outward-rounded range, so the words never contradict the numbers", () => {
    // Computed range 43.2-49.9 excludes 50 by 0.1 years; the range shown (43 to 50) includes it.
    const v = buildBioAgeV3View({ record: rec(), chronologicalAge: 50, locale: "en" });
    expect(v.direction).toBe("indistinct");
    expect(v.directionText).toBe("Not distinguishable from your age (50): your age is inside the 95% range.");
  });

  it("says younger and older in both languages with the age", () => {
    const y = buildBioAgeV3View({ record: rec(), chronologicalAge: 58, locale: "en" });
    expect(y.directionText).toBe("Younger than your age (58): the whole 95% range is below it.");
    const o = buildBioAgeV3View({ record: rec(), chronologicalAge: 38, locale: "es" });
    expect(o.directionText).toBe("Mayor que tu edad (38): todo el intervalo del 95 % queda por encima.");
  });

  it("gives no direction when the age is unknown", () => {
    const v = buildBioAgeV3View({ record: rec(), chronologicalAge: null, locale: "en" });
    expect(v.direction).toBeNull();
    expect(v.directionText).toBeNull();
    expect(v.figure).not.toBeNull();
  });
});

describe("change between two results", () => {
  it("reads the reliable-change threshold from the copy file, about 4.3 years as in MODEL-CARD.md section 14", () => {
    expect(RELIABLE_CHANGE_YEARS).toBe(4.3);
    const card = fs.readFileSync(path.join(ROOT, "ml/biological-age/MODEL-CARD.md"), "utf8");
    // Section 14's table: "| Base | 1.54 / 1.55 y; 4.3 / 4.3 y (limits 3.0 and 8.5: pass) | ...".
    const baseRows = card.split("\n").filter((l) => /^\| Base \|/.test(l));
    expect(baseRows.some((l) => /; 4\.3 \/ 4\.3 y/.test(l))).toBe(true);
  });

  it("calls a change real only strictly above the threshold", () => {
    expect(changeKind(rec({ ba: 44.3 }), rec({ ba: 40 }))?.kind).toBe("no_change");
    expect(changeKind(rec({ ba: 44.4 }), rec({ ba: 40 }))?.kind).toBe("real_higher");
    expect(changeKind(rec({ ba: 40 }), rec({ ba: 44.4 }))?.kind).toBe("real_lower");
    expect(changeKind(rec({ ba: 41 }), rec({ ba: 44 }))?.kind).toBe("no_change");
  });

  it("does not compare different tiers or a provisional result", () => {
    expect(changeKind(rec({ ba: 30 }), rec({ ba: 45, tier: "plus_hba1c" }))?.kind).toBe("not_compared_tier");
    expect(changeKind(rec({ ba: 30, provisional: true }), rec({ ba: 45 }))?.kind).toBe("not_compared_provisional");
    expect(changeKind(rec({ ba: 30 }), rec({ ba: 45, provisional: true }))?.kind).toBe("not_compared_provisional");
    expect(changeKind(rec(), refused(["kidney"]))).toBeNull();
  });

  it("writes the sentence with the earlier date, one decimal and the threshold", () => {
    const real = buildBioAgeV3View({
      record: rec({ ba: 40 }),
      chronologicalAge: 47,
      locale: "en",
      previous: { record: rec({ ba: 45.2 }), drawDate: "2026-05-14" },
    });
    expect(real.changeKind).toBe("real_lower");
    expect(real.changeText).toBe(
      "Since your result of 14/05/2026: 5.2 years lower. That is more than the 4.3 years two tests can differ through measurement variation alone, so it is a real change.",
    );
    const none = buildBioAgeV3View({
      record: rec({ ba: 43 }),
      chronologicalAge: 47,
      locale: "es",
      previous: { record: rec({ ba: 45.2 }), drawDate: "2026-05-14" },
    });
    expect(none.changeKind).toBe("no_change");
    expect(none.changeText).toContain("sin cambio apreciable");
    expect(none.changeText).toContain("(2,2 años)");
    expect(none.changeText).toContain("los 4,3 años");
  });

  it("makes no comparison without a dated earlier result", () => {
    const v = buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "en", previous: { record: rec({ ba: 30 }), drawDate: null } });
    expect(v.changeText).toBeNull();
  });
});

describe("provisional result (hs-CRP above 10 mg/L)", () => {
  it("carries the provisional marker and the retest suggestion", () => {
    const v = buildBioAgeV3View({ record: rec({ provisional: true, crp_capped: true }), chronologicalAge: 47, locale: "en" });
    expect(v.provisionalText).toContain("Provisional");
    expect(v.provisionalText).toContain("10 mg/L");
    expect(v.provisionalText).toContain("two weeks");
    expect(BIO_AGE_V3_DISPLAY.rules.provisional_crp_above_mg_l).toBe(10);
  });

  it("has no marker otherwise", () => {
    expect(buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "en" }).provisionalText).toBeNull();
  });
});

describe("refusals in plain words", () => {
  it("gives every reason, in order, without the figure", () => {
    const v = buildBioAgeV3View({ record: refused(["kidney", "albumin_low"]), chronologicalAge: 47, locale: "en" });
    expect(v.kind).toBe("refused");
    expect(v.figure).toBeNull();
    expect(v.refusalHeading).toBe("We did not calculate your biological age for this result.");
    expect(v.refusalReasons).toEqual([copyFor("en").refusal.reasons.kidney, copyFor("en").refusal.reasons.albumin_low]);
  });

  it("says a shared sentence once", () => {
    const r = refusalReasons(refused(["age_outside_signed_range", "age_outside_validated_range"]), "es");
    expect(r).toEqual(["Tu edad está fuera del rango de edades que cubre el modelo."]);
  });

  it("shows the error record and an unknown code with the generic sentence", () => {
    const err: BioAgeV3Stored = { reason: "error" };
    expect(buildBioAgeV3View({ record: err, chronologicalAge: 47, locale: "en" }).refusalReasons).toEqual([
      copyFor("en").refusal.reasons.error,
    ]);
    expect(refusalReasons(refused(["something_new"]), "en")).toEqual([copyFor("en").refusal.reasons.error]);
  });

  it("has a sentence in both languages for every reason code the adapter can store", () => {
    const codes = [
      // BiologicalAgeV3NullReason (biological-age-v3.ts)
      "sex_unknown", "age_outside_validated_range", "unit_mismatch", "duplicate_marker", "missing_markers", "invalid_value",
      // BioAgeV3RuleCode (biological-age-v3-rules.ts)
      "pregnancy", "lactation", "age_unknown", "age_outside_signed_range", "collection_method", "implausible_value",
      "kidney", "albumin_low", "crp_above_limit", "alp_above_limit", "ggt_above_limit",
      // BioAgeV3ErrorRecord
      "error",
    ];
    for (const lang of ["en", "es"] as const) {
      const reasons = BIO_AGE_V3_DISPLAY[lang].refusal.reasons;
      for (const c of codes) expect(reasons[c], `${lang} ${c}`).toMatch(/\S/);
    }
  });
});

describe("reference population and wording", () => {
  it("states the US comparison and that it is not yet checked in Spain", () => {
    const en = buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "en" });
    expect(en.reference).toContain("Compared with US adults of your sex and age");
    expect(en.reference).toMatch(/Spanish population has not yet been verified/);
    const es = buildBioAgeV3View({ record: refused(["kidney"]), chronologicalAge: 47, locale: "es" });
    expect(es.reference).toContain("Comparada con adultos de Estados Unidos de tu sexo y edad");
    expect(es.reference).toMatch(/población española aún no se ha verificado/);
  });

  it("has no forbidden wording and no unfilled placeholder in any copy or view", () => {
    for (const lang of ["en", "es"] as const) {
      const all = JSON.stringify(BIO_AGE_V3_DISPLAY[lang]);
      expect(all).not.toMatch(FORBIDDEN);
    }
    const views = [
      buildBioAgeV3View({ record: rec({ provisional: true }), chronologicalAge: 40, locale: "en", previous: { record: rec({ ba: 30 }), drawDate: "2026-01-02" } }),
      buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "es", previous: { record: rec({ ba: 46 }), drawDate: "2026-01-02" } }),
      buildBioAgeV3View({ record: refused(["pregnancy", "missing_markers"]), chronologicalAge: 47, locale: "es" }),
    ];
    for (const v of views) {
      const t = viewText(v);
      expect(t).not.toMatch(/\{\w+\}/);
      expect(t).not.toMatch(FORBIDDEN);
    }
  });

  it("falls back to English for an unknown locale", () => {
    expect(buildBioAgeV3View({ record: rec(), chronologicalAge: 47, locale: "fr" }).locale).toBe("en");
  });
});

describe("flat segments of the model", () => {
  const required: [string, RegExp, RegExp][] = [
    ["hs_crp", /below 2\.1 mg\/L, hs-CRP/i, /por debajo de 2,1 mg\/L, la PCR-us/i],
    ["bun", /below 10 mg\/dL, urea nitrogen/i, /por debajo de 10 mg\/dL, el nitrógeno ureico/i],
    ["creatinine", /below 0\.6 mg\/dL in women and 0\.8 mg\/dL in men, creatinine/i, /por debajo de 0,6 mg\/dL en mujeres y 0,8 mg\/dL en hombres/i],
    ["alp", /below 40 U\/L, alkaline phosphatase/i, /por debajo de 40 U\/L, la fosfatasa alcalina/i],
    ["albumin", /above 50 g\/L, albumin/i, /por encima de 50 g\/L, la albúmina/i],
    ["hba1c", /below 4\.5%, HbA1c/i, /por debajo de 4,5 %, la HbA1c/i],
  ];

  it("lists each one in display-copy.json and words it for the client in both languages", () => {
    const en = flatSegmentTexts("en");
    const es = flatSegmentTexts("es");
    for (const [marker, enRe, esRe] of required) {
      expect(BIO_AGE_V3_DISPLAY.flat_segments.some((f) => f.marker === marker), marker).toBe(true);
      expect(en.some((s) => enRe.test(s)), `en ${marker}`).toBe(true);
      expect(es.some((s) => esRe.test(s)), `es ${marker}`).toBe(true);
    }
  });

  it("shows them on the card's view whether or not there is a figure", () => {
    for (const record of [rec(), refused(["kidney"])]) {
      const v = buildBioAgeV3View({ record, chronologicalAge: 47, locale: "en" });
      expect(v.flatSegments.length).toBe(7);
    }
  });
});

// ─── The card ───

describe("BiologicalAgeV3Card", () => {
  it("renders nothing without a view (flag off)", () => {
    expect(renderToStaticMarkup(createElement(BiologicalAgeV3Card, { view: null }))).toBe("");
  });

  it("renders the figure with its range, direction, reference and flat segments", () => {
    const view = buildBioAgeV3View({ record: rec({ provisional: true }), chronologicalAge: 58, locale: "en" });
    const html = renderToStaticMarkup(createElement(BiologicalAgeV3Card, { view }));
    expect(html).toContain("Estimated biological age: 47 years (95% range: 43 to 50)");
    expect(html).toContain("Younger than your age (58)");
    expect(html).toContain("Provisional:");
    expect(html).toContain("Compared with US adults of your sex and age");
    expect(html).toContain("Below 2.1 mg/L, hs-CRP does not change your biological age.");
  });

  it("renders the reasons and no figure for a refusal", () => {
    const view = buildBioAgeV3View({ record: refused(["collection_method"]), chronologicalAge: 47, locale: "es" });
    const html = renderToStaticMarkup(createElement(BiologicalAgeV3Card, { view }));
    expect(html).toContain("No hemos calculado tu edad biológica en este resultado.");
    expect(html).toContain("muestra de sangre extraída de una vena");
    expect(html).not.toContain("Edad biológica estimada");
  });
});

// ─── Flags ───

describe("display flags", () => {
  afterEach(() => vi.unstubAllEnvs());

  it("are both off by default", () => {
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", undefined as unknown as string);
    vi.stubEnv("BIO_AGE_V3_VISIBLE", undefined as unknown as string);
    expect(isBioAgeKdmVisible()).toBe(false);
    expect(isBioAgeV3Visible()).toBe(false);
    expect(isBioAgeKdmVisible({})).toBe(false);
    expect(isBioAgeV3Visible({})).toBe(false);
  });

  it("are on only for true or 1", () => {
    for (const v of ["true", "TRUE", " 1 ", "1"]) expect(flagOn(v), v).toBe(true);
    for (const v of ["false", "0", "yes", "", "on", undefined, null]) expect(flagOn(v), String(v)).toBe(false);
    expect(isBioAgeKdmVisible({ BIO_AGE_KDM_VISIBLE: "true" })).toBe(true);
    expect(isBioAgeV3Visible({ BIO_AGE_V3_VISIBLE: "1" })).toBe(true);
    expect(isBioAgeV3Visible({ BIO_AGE_KDM_VISIBLE: "true" })).toBe(false);
  });
});

// ─── The old figure hidden: pages (server-side stripping) ───

describe("old KDM figure removed from the rows the pages send", () => {
  const lab = {
    id: "l1",
    collection_date: "2026-10-01",
    biological_age: 41.2,
    biological_age_comprehensive: 40.1,
    bio_age_method: "KDM_v2.2.3_Reference",
    bio_age_n_markers: 9,
    bio_age_applied_spanish_calibration: false,
    longevity_score: 80,
  } as unknown as LabResult;
  const profile = {
    id: "u1",
    full_name: "Ana",
    current_ba: 42.5,
    current_ba_method: "Reference",
    current_ba_n_labs_averaged: 2,
    current_ba_window_months: 12,
    current_ba_n_markers_used: 9,
    current_ba_computed_at: "2026-10-02",
  } as unknown as Profile;

  it("nulls every KDM field of the lab and the profile when off, keeping the rest", () => {
    const l = labForDisplay(lab, false) as unknown as Record<string, unknown>;
    for (const f of KDM_LAB_FIELDS) expect(l[f], f).toBeNull();
    expect(l.longevity_score).toBe(80);
    expect(l.id).toBe("l1");
    const p = profileForDisplay(profile, false) as unknown as Record<string, unknown>;
    for (const f of KDM_PROFILE_FIELDS) expect(p[f], f).toBeNull();
    expect(p.full_name).toBe("Ana");
    // The dashboard's fallback (profile.current_ba ?? latestLab.biological_age) then has nothing to show.
    expect((p.current_ba as number | null) ?? (l.biological_age as number | null) ?? null).toBeNull();
    // The input is not mutated: values stay as stored.
    expect(lab.biological_age).toBe(41.2);
  });

  it("strips history items (the lab page's selector rows) and leaves absent fields absent", () => {
    const item = { id: "l2", collection_date: "2026-01-01", source: "eva_kit", status: "ready", biological_age: 39, longevity_score: 70 };
    const out = labForDisplay(item, false);
    expect(out.biological_age).toBeNull();
    expect("bio_age_method" in out).toBe(false);
  });

  it("returns the rows unchanged when on, and null as null", () => {
    expect(labForDisplay(lab, true)).toBe(lab);
    expect(profileForDisplay(profile, true)).toBe(profile);
    expect(labForDisplay(null, false)).toBeNull();
    expect(profileForDisplay(null, false)).toBeNull();
  });

  it("defaults to the environment flag (off)", () => {
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", "");
    expect((labForDisplay(lab) as LabResult).biological_age).toBeNull();
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", "true");
    expect((labForDisplay(lab) as LabResult).biological_age).toBe(41.2);
    vi.unstubAllEnvs();
  });
});

// ─── The old figure hidden: results-ready email ───

describe("results-ready email", () => {
  const data: ResultsReadyData = {
    firstName: "Ana",
    biomarkerCount: 24,
    longevityScore: 81,
    biologicalAge: 41.2,
    baDelta: -3.8,
    locale: "en",
  } as ResultsReadyData;

  afterEach(() => vi.unstubAllEnvs());

  it("carries no biological age when the flag is off, in either language", () => {
    for (const locale of ["en", "es"]) {
      const html = renderResultsReady({ ...data, locale }, locale, false);
      expect(html).not.toMatch(/Biological Age|Edad Biol/i);
      expect(html).not.toContain("41.2");
      expect(html).not.toMatch(/younger|older|mas joven|mayor/);
      expect(html).toMatch(/24 biomar(k|c)/);
      expect(html).toContain("Longevity Score: 81/100");
    }
  });

  it("reads the server flag by default (off unless set)", () => {
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", "");
    expect(renderResultsReady(data, "en")).not.toContain("Biological Age");
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", "true");
    expect(renderResultsReady(data, "en")).toContain("Biological Age: 41.2 (3.8y younger)");
  });

  it("keeps today's line when the flag is on", () => {
    expect(renderResultsReady({ ...data, locale: "es" }, "es", true)).toContain("Edad Biologica: 41.2 (3.8a mas joven)");
  });
});

// ─── The old figure hidden: AI chat context ───

const chat = vi.hoisted(() => ({ instructions: [] as string[] }));

vi.mock("@/lib/supabase/server", () => {
  const chain = (): Record<string, unknown> => {
    const c: Record<string, unknown> = {};
    for (const m of ["select", "eq", "order"]) c[m] = () => c;
    c.single = async () => ({ data: { subscription_status: "active" }, error: null });
    c.limit = async () => ({ data: [{ role: "user", content: "hello" }], error: null });
    c.insert = async () => ({ error: null });
    return c;
  };
  return {
    createClient: async () => ({
      auth: { getUser: async () => ({ data: { user: { id: "u1" } } }) },
      from: () => chain(),
    }),
  };
});
vi.mock("@/lib/stripe/helpers", () => ({ hasPaidAccess: () => true }));
vi.mock("@/lib/ai/prompts", () => ({ getPrompt: async () => ({ content: "SYSTEM", model: "test-model" }) }));
vi.mock("@/lib/queries", () => ({
  getUserProfile: async () => ({ full_name: "Ana", date_of_birth: "1980-01-01", sex: "female", locale: "es", subscription_status: "active", current_ba: 42.5 }),
  getLatestLabResult: async () => ({ id: "l1", collection_date: "2026-10-01", biological_age: 41.2, longevity_score: 80, summary_narrative: "fine" }),
  getBiomarkerValues: async () => [],
  getWearableData: async () => [],
  getActionSteps: async () => [],
}));
vi.mock("@google/genai", () => ({
  GoogleGenAI: class {
    models = {
      generateContentStream: async (args: { config: { systemInstruction: string } }) => {
        chat.instructions.push(args.config.systemInstruction);
        return (async function* () {
          yield { text: "ok" };
        })();
      },
    };
  },
}));

describe("AI chat context", () => {
  beforeEach(() => {
    chat.instructions.length = 0;
    vi.stubEnv("GEMINI_API_KEY", "test");
  });
  afterEach(() => vi.unstubAllEnvs());

  async function contextSent(): Promise<string> {
    const { POST } = await import("@/app/api/ai/chat/route");
    const res = await POST({ json: async () => ({ message: "What is my biological age?" }) } as never);
    await res.text(); // the stream calls the model when read
    expect(chat.instructions).toHaveLength(1);
    return chat.instructions[0];
  }

  it("does not carry the stored figure when the flag is off", async () => {
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", "");
    const ctx = await contextSent();
    expect(ctx).not.toContain("41.2");
    expect(ctx).not.toContain("42.5");
    expect(ctx).not.toMatch(/Biological Age: \d/);
    expect(ctx).toContain("Biological Age: not available to this client. Do not state, estimate or discuss a biological age figure.");
    expect(ctx).toContain("Longevity Score: 80/100");
  });

  it("carries it as today when the flag is on", async () => {
    vi.stubEnv("BIO_AGE_KDM_VISIBLE", "true");
    expect(await contextSent()).toContain("Biological Age: 41.2");
  });

  it("chatBioAgeLine follows the flag", () => {
    expect(chatBioAgeLine(41.2, false)).not.toContain("41.2");
    expect(chatBioAgeLine(41.2, true)).toBe("Biological Age: 41.2");
    expect(chatBioAgeLine(null, true)).toBe("Biological Age: not calculated");
  });
});
