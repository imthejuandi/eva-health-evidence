/**
 * Supplement parsing + biomarker offset application.
 *
 * The eva-health `patient_context_versions.supplements` JSONB field stores
 * supplements as `{key, dose}` where `dose` is free-text ("10g", "5000",
 * "1000mcg", "2,5 gramos", etc.). This module normalizes those strings into
 * structured (value, unit) tuples and exposes the per-supplement adjustment
 * used by the biological age models.
 *
 * Current biomarker adjustment:
 *
 *   - Creatine supplementation → serum creatinine. See
 *     `creatineCreatinineDivisor` for the rule and its sources.
 *
 * Future biomarker offsets (deferred to a separate PR):
 *
 *   - Iron supplementation → ferritin (varies wildly by dose/duration)
 *   - Levothyroxine → TSH suppression (binary suppression vs dose-dependent)
 *   - Statins → total cholesterol / LDL drop (well-characterized but already
 *     intended in the clinical signal — usually NOT something to "correct")
 */

// ─── Public types ───

/**
 * Shape of one supplement entry from
 * `patient_context_versions.supplements`. The `key` is the supplement's
 * canonical identifier (e.g., "creatine", "vitamin_d"); `dose` is a
 * free-text string entered via the UI.
 */
export interface SupplementEntry {
  key: string;
  dose?: string | null;
}

/**
 * Parsed (value, unit) for a single dose string. `unit` is the lowercased
 * unit token from the input; if no unit was supplied, `unit` is `null`
 * and the caller can fall back to the supplement's `defaultUnit`.
 */
export interface ParsedDose {
  value: number;
  unit: string | null;
}

// ─── Default units per supplement (Spanish market convention) ───

/**
 * Default unit assumed when a user enters a bare numeric dose (e.g., "5000"
 * for vitamin D defaults to IU). Used by `parseSupplementDose`.
 *
 * If a supplement isn't in this map, the parser still extracts a numeric
 * value but the unit stays `null` — the caller decides what to do.
 */
export const SUPPLEMENT_DEFAULT_UNITS: Record<string, string> = {
  creatine: "g",
  vitamin_d: "iu",
  vitamin_b12: "mcg",
  b12: "mcg",
  iron: "mg",
  magnesium: "mg",
  omega_3: "g",
  fish_oil: "g",
  zinc: "mg",
  vitamin_c: "mg",
  vitamin_e: "mg",
  folate: "mcg",
  folic_acid: "mcg",
  coq10: "mg",
  vitamin_k2: "mcg",
  vitamin_a: "iu",
  selenium: "mcg",
};

// ─── Parsing ───

/** Unit words, English and Spanish, to the unit token the module uses. */
const UNIT_SYNONYMS: Record<string, string> = {
  g: "g", gr: "g", grs: "g", gm: "g", gms: "g", grm: "g", grms: "g", gram: "g", grams: "g", gramo: "g", gramos: "g",
  mg: "mg", mgs: "mg", mgr: "mg", milligram: "mg", milligrams: "mg", miligram: "mg", miligrams: "mg", miligramo: "mg",
  miligramos: "mg",
  mcg: "mcg", ug: "mcg", "µg": "mcg", "μg": "mcg", microgram: "mcg", micrograms: "mcg", microgramo: "mcg",
  microgramos: "mcg",
  iu: "iu", ui: "iu", units: "iu", unidades: "iu",
};

/**
 * A number as people write it: "5", "2,5", "2.5", ".5", "5.000", "5,000", "2 500" (a space, or a no-break space,
 * between groups of three digits), "1.250,5".
 */
const NUMBER = String.raw`(?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)*|[.,]\d+)`;
const WORD = String.raw`[a-zµμáéíóúñü]+`;

/**
 * The value of a number token, given the unit written after it. Both marks: the last one is the decimal mark. One
 * mark repeated, or a space between groups of three digits: thousands. One mark followed by exactly three digits after
 * a non-zero lead ("5.000", "1,000"): thousands, except in grams, where "1,250 g" is 1.25 g. Any other single mark is
 * a decimal mark ("2,5", "0.500").
 */
function readNumber(token: string, unit: string | null): number {
  let t = token.replace(/[\u00a0\u202f]/g, " ");
  if (/^\d{1,3}( \d{3})+/.test(t)) t = t.replace(/ /g, "");
  if (t.startsWith(".") || t.startsWith(",")) t = `0${t}`;
  const marks = t.match(/[.,]/g) ?? [];
  if (marks.length === 0) return parseFloat(t);
  if (new Set(marks).size === 2) {
    const decimal = t.lastIndexOf(".") > t.lastIndexOf(",") ? "." : ",";
    const grouping = decimal === "." ? "," : ".";
    return parseFloat(t.split(grouping).join("").replace(decimal, "."));
  }
  if (marks.length > 1) return parseFloat(t.replace(/[.,]/g, ""));
  if (/^[1-9]\d{0,2}[.,]\d{3}$/.test(t) && unit !== "g") return parseFloat(t.replace(/[.,]/, ""));
  return parseFloat(t.replace(",", "."));
}

/** The unit token for a word written after a number: a known unit word, else the word itself, else null. */
function unitOf(word: string | undefined): string | null {
  if (!word) return null;
  return UNIT_SYNONYMS[word] ?? word;
}

/** Lowercased, trimmed, with "×" read as "x". */
function normalizeDose(dose: string): string {
  return dose.trim().toLowerCase().replace(/×/g, "x");
}

/**
 * Parse a free-text supplement dose into `{value, unit}`: the first number, and the word right after it.
 *
 * Accepts common formats, in English and Spanish:
 *   "10g"          → { value: 10, unit: "g" }
 *   "10 g"         → { value: 10, unit: "g" }
 *   "10grams"      → { value: 10, unit: "g" }
 *   "5 gramos"     → { value: 5, unit: "g" }
 *   "2,5 g/día"    → { value: 2.5, unit: "g" }   (decimal comma)
 *   "5.000 mg"     → { value: 5000, unit: "mg" } (thousands separator)
 *   "5000"         → { value: 5000, unit: null }  (caller applies default)
 *   "1000 mcg"     → { value: 1000, unit: "mcg" }
 *   "1000mcg/day"  → { value: 1000, unit: "mcg" }
 *   "  2.5 g  "    → { value: 2.5, unit: "g" }
 *
 * See `readNumber` for separators. A unit word the module does not know is
 * kept as typed (lowercased), so the caller can refuse it.
 *
 * Returns `null` if no number can be extracted.
 */
export function parseSupplementDose(dose: string | null | undefined): ParsedDose | null {
  if (!dose || typeof dose !== "string") return null;
  const text = normalizeDose(dose);
  if (!text) return null;
  const m = text.match(new RegExp(`(${NUMBER})\\s*(${WORD})?`));
  if (!m) return null;
  const unit = unitOf(m[2]);
  const value = readNumber(m[1], unit);
  if (!Number.isFinite(value)) return null;
  return { value, unit };
}

/**
 * Resolve a supplement's dose to `{value, unit}` using the default unit
 * when the dose string doesn't specify one. Returns `null` if parsing fails.
 */
export function resolveSupplementDose(
  key: string,
  dose: string | null | undefined,
): ParsedDose | null {
  const parsed = parseSupplementDose(dose);
  if (!parsed) return null;
  if (parsed.unit) return parsed;
  const defaultUnit = SUPPLEMENT_DEFAULT_UNITS[key.toLowerCase()];
  return { value: parsed.value, unit: defaultUnit ?? null };
}

// ─── Creatine → creatinine ───

/**
 * Average rise of serum creatinine with creatine supplementation, as a
 * fraction of the person's creatinine.
 *
 * Creatine raises serum creatinine: more creatine stored in muscle means more
 * creatinine made from it. In trials in healthy adults, measured kidney
 * filtration did not change. Two 2026 meta-analyses of randomised trials
 * found a mean rise of 0.13 mg/dL (95% CI 0.07 to 0.18; 19 trials; Tsiaras
 * 2026, J Ren Nutr, PMID 42035842) and 0.14 mg/dL (0.05 to 0.22; 26 studies,
 * kidney disease and dialysis included; de Souza Almeida 2026, Int Urol
 * Nephrol, PMID 42507286). Neither reports the baseline creatinine.
 *
 * Applying the rise as 13% of the person's creatinine is EVA's assumption:
 * 0.13 mg/dL at 1.0 mg/dL. A ratio scales the adjustment with the person's
 * creatinine, so it is smaller in women; whether their rise is smaller too is
 * not established. If a woman's rise is the trials' 0.13 mg/dL, the typical
 * woman of 45 (0.75 mg/dL) still reads 0.36 years older on the lab page, and
 * 0.55 in version 3, after declaring 3 g/day or more
 * (docs/biomarker-evidence/longevity/CALIBRATION-AND-CREATINE.md).
 */
export const CREATINE_CREATININE_RISE = 0.13;

/**
 * Daily dose (g) from which the whole rise applies: EVA's choice, because
 * 3 g/day fills muscle creatine as much as higher doses, only more slowly
 * (Hultman 1996, PMID 8828669). Whether a higher dose raises creatinine more
 * is not known: no meta-analysis analysed dose, and the two small trials that
 * compared doses found no difference in creatinine between groups, not even
 * against placebo, so they do not inform a gradient (Vilar Neto 2020, PMID
 * 32670557: 3 and 5 g/day, 12 men per arm, 35 days; Kondo 2016, PMID 26907087:
 * 2, 4 and 10 g/day for 8 weeks, adolescent girls with depression).
 * Naeini 2025 (BMC Nephrol, PMID 41199218) analysed follow-up, not dose: 0.12
 * mg/dL within a week, in studies of 20 g/day loading, and a non-significant
 * 0.04 mg/dL at 1 to 12 weeks. 10 g/day for 12 weeks gave 6 to 18% (Chun
 * 2026, JISSN, PMID 42578920).
 *
 * Below 3 g/day the rise is taken as proportional to the dose, also an
 * assumption. Two known gaps (Hultman 1996, PMID 8828669):
 *   - after a loading week, 2 g/day kept muscle creatine full, so a loaded
 *     client on 2 g/day is under-corrected (0.39 years on the lab page, 0.57 in
 *     version 3, for the typical man of 45);
 *   - 3 g/day takes about 28 days to fill muscle creatine, yet the whole rise
 *     is removed from the first day, so a client who started without loading
 *     in the weeks before the draw is over-corrected (up to 1.12 years on the
 *     lab page, 1.78 in version 3).
 * The context form records neither loading nor a start date.
 */
export const CREATINE_SATURATING_DOSE_G = 3;

/** A creatine dose written without a unit is read as milligrams from this value up ("5000"), else as grams ("5"). */
export const CREATINE_BARE_DOSE_MG_FROM = 100;

/** Grams in one unit of mass. */
const GRAMS_PER_UNIT: Record<string, number> = { g: 1, mg: 1e-3, mcg: 1e-6 };

/**
 * Counts written as words, Spanish and English: "dos veces al día", "tres días a la semana", "twice a day", "cada
 * quince días". Not "once": in Spanish it is eleven.
 */
const COUNT_WORDS: Record<string, number> = {
  medio: 0.5, media: 0.5, half: 0.5, un: 1, una: 1, uno: 1, one: 1, dos: 2, two: 2, twice: 2, tres: 3, three: 3,
  thrice: 3, cuatro: 4, four: 4, cinco: 5, five: 5, seis: 6, six: 6, siete: 7, seven: 7, quince: 15, fifteen: 15,
};
const LETTER = "a-zµμáéíóúñü";
const COUNT_WORD = `(?<![${LETTER}])(?:${Object.keys(COUNT_WORDS).sort((a, b) => b.length - a.length).join("|")})(?![${LETTER}])`;
/** A count: a number, or a number word. */
const COUNT = `(?:${NUMBER}|${COUNT_WORD})`;

/** What separates the two ends of a range of counts, which reads its lower end: "2-3 cápsulas", "2 o 3 veces". */
const RANGE_SEPARATOR = String.raw`(?:-|–|—|~|a|o|ó|y|to|or|and)`;
const FREQUENCY_RANGE = `(?:\\s*(?:-|–|—|~|a|o|ó|to|or)\\s*${COUNT})?`;
const WEEK = `(?:semana|week|wk|sem)(?![${LETTER}])`;

/**
 * A unit of intake with no mass of its own: "2 cápsulas de 750 mg" is 2 × 750 mg. A trailing "." or a word such as
 * "masticables" or "de creatina" may follow it.
 */
const SERVING = String.raw`(?:c[áa]psulas?|capsules?|c[áa]ps|caps?|tomas?|cacitos?|cazos?|medidas?|scoops?|servings?|comprimidos?|pastillas?|tabletas?|tablets?|tabs?|pills?|sobres?|sachets?|dosis|doses?|cucharaditas?|cucharadas?|porci[oó]n(?:es)?|gominolas?|gomitas?|gumm(?:y|ies)|sticks?|servicios?)\.?(?:\s+(?:masticables?|chewables?|de\s+creatina|of\s+creatine))?`;
/** A mass marked as per serving: "(750 mg cada una)", "1 g each", "750 mg c/u", "750 mg/cápsula". */
const EACH = String.raw`(?:\)?\s*(?:cada\s+un[oa]|each|c\/u|\/\s*c[áa]psula|por\s+c[áa]psula|per\s+(?:capsule|gummy|tablet|serving)))`;

/**
 * A dose per unit of body weight: it cannot be read without the weight. A slash, "*", "por", "per", "cada", "each" or
 * "x" before kg, kilo, kilogramo, lb, libra or pound ("0,3 g/kg/día", "0,3 g/kilo", "0,1 g x kg", "0,1 g/lb"), or kg
 * to the power -1 ("0,3 g kg-1 día-1", "0,3 g·kg⁻¹").
 */
const PER_KG = new RegExp(
  `(?:\\/|\\*|(?<![${LETTER}])(?:por|per|cada|each|x))\\s*(?:kg|kilo|lb|libra|pound)|(?<![${LETTER}])kg\\s*\\^?\\s*[-−–⁻]\\s*[1¹](?![.,]?\\d)`,
);

/** A slash between two numbers ("1/2 g", "3/5 g"): a fraction or a range, unclear. */
const SLASH_BETWEEN_NUMBERS = new RegExp(`${NUMBER}\\s*\\/\\s*${NUMBER}`);

/** A dose the client no longer takes ("ya no", "lo dejé", "tomaba", "antes 5 g", "stopped", "used to"). */
const STOPPED = new RegExp(
  `(?<![${LETTER}])(?:` +
    [
      `ya\\s+no(?!\\s+(?:hago|cargo)(?![${LETTER}]))`,
      `no\\s+(?:la\\s+|lo\\s+)?(?:estoy\\s+)?tom(?:o|ando)`,
      `est(?:aba|uve)\\s+tomando`,
      `llev[oa]\\s+[^,.;]{1,25}?\\s+sin\\s+tomar(?:la|lo)s?`,
      `hasta\\s+hace`,
      `until\\s+(?:last\\s+[${LETTER}]+|\\S+\\s+\\S+\\s+ago)`,
      `(?:lo|la)\\s+(?:he\\s+)?dej[${LETTER}]*`,
      `(?:lo|la)\\s+he\\s+parado`,
      `parad[oa]`,
      `dej[eé]`,
      `dejad[oa]s?`,
      `tomaba`,
      `sol[ií]a`,
      `suspend[${LETTER}]*`,
      `interrump[${LETTER}]*`,
      `par[eé]`,
      `pausad[oa]`,
      `en\\s+pausa`,
      `(?:ahora|actualmente)\\s+no(?!\\s+(?:hago|cargo)(?![${LETTER}]))`,
      `antes(?!\\s+(?:de|del|o|u|y|e)(?![${LETTER}]))`,
      `stopped`,
      `no\\s+longer`,
      `not\\s+(?:any\\s*more|taking)`,
      `used\\s+to`,
      `quit`,
      `was\\s+taking`,
      `discontinu[${LETTER}]*`,
      `paused`,
      `on\\s+hold`,
      `previously`,
      `formerly`,
    ].join("|") +
    `)(?![${LETTER}])`,
);

/**
 * Schedules with no count of days a week, unless the text gives one: weekday names, weekends, training days
 * ("cuando entreno"), intervals of weeks or months ("cada 2 semanas").
 */
const UNCOUNTED_SCHEDULE = new RegExp(
  [
    `(?<![${LETTER}])(?:lunes|martes|mi[ée]rcoles|jueves|viernes|s[áa]bados?|domingos?|(?:mon|tues?|wed(?:nes)?|weds|thu(?:rs?)?|fri|sat(?:ur)?|sun)(?:days?)?|lun|mar|mi[ée]|jue|vie|s[áa]b|dom|entre\\s+semana|fin(?:es)?\\s+de\\s+semana|findes?|weekends?|weekdays?|d[ií]as?\\s+(?:de|que|en\\s+que)\\s+(?:entreno|entrenamiento|entrene|gym|gimnasio|voy|hago|deporte|pesas|juego|corro)|(?:training|workout|gym|lifting|exercise)\\s+days?|al\\s+mes|mensual(?:es|mente)?|monthly|per\\s+month|a\\s+month)(?![${LETTER}])`,
    `\\/\\s*mes(?![${LETTER}])`,
    `(?<![${LETTER}0-9])[lmxjvsd]\\s*[-,]\\s*[lmxjvsd](?:\\s*[-,]\\s*[lmxjvsd])*(?![${LETTER}])`,
    `(?<![${LETTER}])(?:m\\s*-\\s*w\\s*-\\s*f|m\\s*[-–]\\s*f|tu?\\s*\\/\\s*th|mwf|lmxjv|(?:de\\s+)?l\\s+a\\s+[vs]|d[ií]as\\s+laborables|work\\s*days?)(?![${LETTER}])`,
    `(?<![${LETTER}])(?:(?:cada|every|c\\/)\\s*(?:${COUNT}|otra|other|second|2nd)\\s*(?:semanas?|weeks?|sem|wks?|mes(?:es)?|months?)|cada\\s+mes|every\\s+month|quincen(?:al(?:es|mente)?|as?)|fortnight(?:ly)?|bi-?weekly|bi-?monthly)(?![${LETTER}])`,
    `(?<![${LETTER}])(?:cuando\\s+(?:entren[oea]s?|voy\\s+al\\s+(?:gym|gimnasio)|hago\\s+(?:deporte|ejercicio|pesas))|(?:por|en\\s+cada|cada|tras\\s+cada|despu[ée]s\\s+de\\s+cada|antes\\s+de\\s+cada)\\s+(?:entrenos?|entrenamientos?|sesi[oó]n(?:es)?)|when\\s+i\\s+(?:train|work\\s*out|lift|exercise|go\\s+to\\s+the\\s+gym)|(?:after|before|on|with)\\s+(?:each|every)\\s+(?:workout|training|session)s?)(?![${LETTER}])`,
  ].join("|"),
);
/**
 * Irregular intake ("si me acuerdo", "de vez en cuando", "en ciclos"): no count of days, whatever else the text says
 * ("5 g, 3 días a la semana, a veces 4" asks too).
 */
const IRREGULAR_INTAKE = new RegExp(
  `(?<![${LETTER}])(?:si\\s+me\\s+acuerdo|siempre\\s+que\\s+me\\s+acuerdo|d[ií]as\\s+que\\s+me\\s+acuerdo|cuando\\s+(?:me\\s+acuerdo|puedo)|(?:if|when)\\s+i\\s+remember|de\\s+vez\\s+en\\s+cuando|ocasional(?:es|mente)?|now\\s+and\\s+then|irregular(?:es|mente)?|en\\s+ciclos|ciclos?|ciclando|cycl(?:e|es|ing))(?![${LETTER}])`,
);
/** A timing or manner after a word such as "a veces" ("a veces con la comida"): about when, not whether. */
const TIMING_FOLLOWS = `(?=\\s*,?\\s*(?:con|en|por|a\\s+la\\s+misma|los\\s+mismos|repartid[oa]s|with|in\\s+the|at)(?![${LETTER}]))`;
/** "a veces", "algunos días", "no siempre": irregular intake, unless a timing follows ("a veces en ayunas"). */
const SOMETIMES = new RegExp(
  `(?<![${LETTER}])(?:a\\s+veces|siempre\\s+que\\s+puedo|algunos\\s+d[ií]as|no\\s+siempre|sometimes|some\\s+days)(?![${LETTER}])(?!${TIMING_FOLLOWS})`,
);
/** "most days", "la mayoría de los días": irregular intake, unless the text says daily and a timing follows. */
const MOST_DAYS = new RegExp(`(?<![${LETTER}])(?:most\\s+days|la\\s+mayor[ií]a\\s+de(?:\\s+los)?\\s+d[ií]as)(?![${LETTER}])`);
const MOST_DAYS_TIMING = new RegExp(`${MOST_DAYS.source}${TIMING_FOLLOWS}`);
/** Cycling negated ("no hago ciclos", "sin descanso ni ciclos", "no cycling"): not a schedule. */
const NEGATED_CYCLING = new RegExp(
  `(?<![${LETTER}])(?:sin(?:\\s+hacer)?|ni|nunca(?:\\s+hago)?|no(?:\\s+hago)?(?:\\s+ning[uú]n)?|not|without|(?:i\\s+)?don['’]?t|never)\\s+(?:cicl[${LETTER}]*|cycl[${LETTER}]*(?:\\s+it)?)(?![${LETTER}])`,
  "g",
);
/** Before and after training ("2,5 g antes y después de entrenar"): two intakes on training days, which are not counted. */
const BEFORE_AND_AFTER = new RegExp(
  `(?<![${LETTER}])(?:(?:antes|pre)\\s*(?:y|e|\\/|\\+|&|-)\\s*(?:despu[ée]s|post)|before\\s*(?:and|&|\\/|\\+)\\s*after|pre\\s*(?:and|&|\\/|-)\\s*post)(?![${LETTER}])`,
);
/** A day word negated ("no todos los días", "not every day"), which would otherwise be read as every day. */
const NOT_DAILY = new RegExp(
  `(?<![${LETTER}])(?:no\\s+(?:todos\\s+los\\s+d[ií]as|a\\s+diario|diari[oa]|cada\\s+d[ií]a)|not\\s+(?:every\\s*day|daily|each\\s+day))(?![${LETTER}])`,
);
/** A week word no frequency read ("durante la semana", "semana sí"): a schedule the reader may have missed. */
const UNREAD_WEEK = new RegExp(`(?<![${LETTER}])(?:semanas?|sem|weeks?|wks?|quincenas?|fortnights?)(?![${LETTER}])`);

/**
 * Durations, which change nothing and are removed first: "durante una semana", "desde hace 2 meses", "llevo 1
 * semana", "for about a week", "a week ago", "los últimos 3 meses", "la semana pasada", "desde esta semana" ("esta semana"
 * only next to a start: "una vez esta semana" is not a duration), "x 30 días", "x 4 sem",
 * "durante 2-3 semanas". A duration followed by a per-week phrase is a frequency ("durante 3 días a la semana",
 * "llevo 4 días a la semana tomando 5 g"), and a count after "cada" or "every" an interval ("cada 2 semanas").
 */
const DURATION_UNIT = `(?:d[ií]as?|semanas?|sem|mes(?:es)?|años?|days?|weeks?|wks?|months?|years?|d)`;
const NOT_PER_WEEK = `(?!\\s*(?:(?:\\/|a|al|por|per|each|cada|en|x)\\s*)?(?:la\\s+)?(?:${WEEK}|(?:semanal(?:es|mente)?|weekly)(?![${LETTER}])))`;
const HEDGE = `(?:(?:about|almost|nearly|around|roughly|approximately|approx\\.?|more\\s+than|casi|unos|unas|aprox\\.?|aproximadamente|m[aá]s\\s+de|alrededor\\s+de|cerca\\s+de)\\s+)?`;
const LED_DURATION = new RegExp(
  `(?<![${LETTER}])(?:durante|desde\\s+hace|hace|llevo|lleva|for|during|since|over)\\s+${HEDGE}(?:(?:${COUNT}${FREQUENCY_RANGE}|an?|un[oa]?)\\s*)?${DURATION_UNIT}(?![${LETTER}])${NOT_PER_WEEK}(?:\\s+ago)?` +
    `|(?<![${LETTER}])${HEDGE}(?:${COUNT}|an?)\\s*${DURATION_UNIT}\\s+ago(?![${LETTER}])` +
    `|(?<![${LETTER}])(?:(?:desde|since|from)\\s+)?(?:(?:el|la|los|las|the)\\s+)?(?:(?:[uú]ltim[oa]s?|last|past|previous)\\s+(?:${COUNT}\\s*)?${DURATION_UNIT}|${DURATION_UNIT}\\s+(?:pasad[oa]s?|anterior(?:es)?)|(?<=(?:desde|since|from|empec[eé]|empez[oó]|started|starting|began)\\s+)(?:est[ea]|this)\\s+${DURATION_UNIT}|(?:est[ea]|this)\\s+${DURATION_UNIT}(?=\\s+(?:empec[eé]|empez[oó]|started|began)(?![${LETTER}])))(?![${LETTER}])`,
  "g",
);
const DURATION = new RegExp(
  `(?<!(?:cada|every|c\\/)\\s*)(?:(?<![\\d.,])(${COUNT})(?:\\.?[ªº°]|st|nd|rd|th)?${FREQUENCY_RANGE}|(?<![${LETTER}])(?:primer[oa]?|segund[oa]|tercer[oa]?|first|second|third))\\s*${DURATION_UNIT}(?![${LETTER}])`,
  "g",
);

/**
 * How often, read and then removed from the text before the amount is read, in this order:
 *   - times a day: "2 veces al día", "dos tomas al día", "3 veces diarias", "twice a day", "once or twice a day",
 *     "2x/día", "bid"; after "en" or "repartidos en" the amount is the day's total, split ("2 g en dos tomas al día");
 *   - times of day, or meals, named in one list, one intake each: "mañana y noche", "por la mañana y por la noche",
 *     "por las mañanas y por las noches", "mañana, tarde y noche", "am y pm", "en desayuno, comida y cena"; after
 *     "entre" or "repartidos entre" the amount is the day's total; joined by "o" ("mañana, tarde o noche", "con la
 *     comida o la cena") they are one intake;
 *   - every N hours: "cada 8 horas", "c/12h";
 *   - days a week: "3 días a la semana", "tres veces por semana", "3 por semana", "3 veces x semana", "3x/week",
 *     "3 días semanales", "3 d/sem";
 *   - every other day, or every N days: "días alternos", "día sí, día no", "cada 3 días", "every 2 days";
 *   - a weekly amount: "5 g a la semana", "5 g/semana", "5 g x semana", "5 g per week", "semanales", "weekly";
 *   - "daily" words: "al día", "/día", "x día", "diarios", "per day", "daily".
 * A range of counts reads its lower end, as amounts do ("2-3 veces al día" is 2).
 */
const TIMES_WORD = `(?:veces|vezes|vez|times|tomas|v\\.?|x)`;
const TIMES_PER_DAY = new RegExp(
  `(${COUNT})${FREQUENCY_RANGE}\\s*${TIMES_WORD}\\s*(?:(?:(?:\\/|al|a|por|per|each|cada|x)\\s*)?(?:d[ií]a|day)|diari[oa]s|daily)(?![${LETTER}])` +
    `|(twice|thrice)\\s+(?:a\\s+|per\\s+)?(?:day|daily)` +
    `|(?<![${LETTER}])(bid|b\\.i\\.d\\.?|tid|t\\.i\\.d\\.?)(?![${LETTER}])`,
);
const TIME_OF_DAY = `(?:ma[ñn]anas?|mediod[ií]a|tardes?|noches?|mornings?|noon|afternoons?|evenings?|nights?|am|pm)`;
const AT_TIME = `(?:(?:(?:por|en|a|de)\\s+)?las?\\s+|al\\s+|a\\s+|de\\s+|(?:in\\s+)?the\\s+|at\\s+)?`;
const TIMES_OF_DAY = new RegExp(
  `(?<![${LETTER}])${AT_TIME}${TIME_OF_DAY}(?:\\s*(?:,|\\+|&|y|and)\\s*${AT_TIME}${TIME_OF_DAY})+(?![${LETTER}])`,
);
/** Two times of day joined by "y" ("tarde y noche"). */
const TIMES_AND = new RegExp(`${TIME_OF_DAY}\\s*,?\\s*(?:y|and|\\+|&)\\s+${AT_TIME}${TIME_OF_DAY}(?![${LETTER}])`);
/** Two times of day joined by "o" ("mañana, tarde o noche"): one of them, not each. */
const EITHER_TIMES = new RegExp(
  `(?<![${LETTER}])${TIME_OF_DAY}\\s*,?\\s*(?:o|u|ó|or)\\s+${AT_TIME}${TIME_OF_DAY}(?![${LETTER}])`,
);
/** Meals named in one list ("en desayuno, comida y cena"): one intake each. */
const MEAL_WORD = `(?:desayuno|almuerzo|comida|merienda|cena|breakfast|lunch|dinner|supper)`;
const MEAL = new RegExp(`(?<![${LETTER}])${MEAL_WORD}(?![${LETTER}])`, "g");
/** Two meals joined by "y" ("comida, y con la cena"). */
const MEALS_AND = new RegExp(
  `${MEAL_WORD}\\s*,?\\s*(?:y|and|\\+|&)\\s+(?:(?:con|en|with|at)\\s+)?(?:(?:el|la|the)\\s+)?${MEAL_WORD}(?![${LETTER}])`,
);
/** Two meals joined by "o" ("con la comida o la cena"): one of them, not each. */
const EITHER_MEALS = new RegExp(
  `(?<![${LETTER}])${MEAL_WORD}\\s*,?\\s*(?:o|u|ó|or)\\s+(?:(?:con|en|with|at)\\s+)?(?:(?:el|la|the)\\s+)?${MEAL_WORD}(?![${LETTER}])`,
);
/** A count of times with no day or week ("1,5 g 2x", "dos veces"): a day or a week? */
const DANGLING_TIMES = new RegExp(`(${COUNT})\\s*(?:veces|vezes|vez|times|x)(?![${LETTER}])(?!\\s*${NUMBER})`);
/** A day's total split into intakes ("5 g en 2 tomas", "2 g divididos en 2 tomas"): read as the total. */
const SPLIT_INTAKES = new RegExp(
  `(?:(?<![${LETTER}])en|into|repartid[oa]s?\\s+en|dividid[oa]s?\\s+en|split\\s+into|divided\\s+into)\\s+${COUNT}\\s*(?:tomas|dosis|doses|veces|times)(?![${LETTER}])`,
);
/** Weeks on and off ("una semana sí y otra no", "8 semanas sí, 4 no", "8 weeks on, 4 off"): no count of days. */
const ALTERNATE_WEEKS = new RegExp(
  `semana\\s+s[ií]\\s*,?\\s*(?:y\\s+)?(?:otra|semana)\\s+no|week\\s+on\\s*,?\\s*(?:a\\s+)?week\\s+off` +
    `|semanas?\\s+s[ií]\\s*,?\\s*(?:y\\s+)?${COUNT}\\s*(?:semanas?\\s+)?no|weeks?\\s+on\\s*,?\\s*${COUNT}\\s*(?:weeks?\\s+)?off`,
);
const SPLIT_BEFORE = new RegExp(`(?:(?<![${LETTER}])en|into|repartid[oa]s?\\s+en|dividid[oa]s?\\s+en|split\\s+into|divided\\s+into)\\s*$`);
/** Before a list of times of day or meals, the amount is the day's total: "2 g repartidos entre desayuno y cena". */
const SPLIT_ACROSS = new RegExp(
  `(?:(?<![${LETTER}])(?:entre|between)|(?:repartid[oa]s?|dividid[oa]s?)\\s+(?:en|entre)|(?:split|divided)\\s+(?:into|between|across))\\s*(?:(?:el|la|los|las|the)\\s+)?$`,
);
const EVERY_N_HOURS = new RegExp(`(?<![${LETTER}])(?:cada|every|c\\/)\\s*(${NUMBER})\\s*(?:h|hs|hrs?|horas?|hours?)(?![${LETTER}])`);
const DAYS_PER_WEEK = new RegExp(
  `(${COUNT})${FREQUENCY_RANGE}\\s*(?:(?:d[ií]as?|d|veces|vez|v\\.?|days?|times|x)\\s*(?:(?:\\/|a|al|por|per|each|cada|en|x|de\\s+cada|de)\\s*)?|(?:\\/|a|al|por|per|each|cada|en|x)\\s*)(?:la\\s+)?${WEEK}` +
    `|(${COUNT})\\s*(?:d[ií]as?|d|veces|vez|days?|times|x)?\\s*(?:semanal(?:es|mente)?|weekly)(?![${LETTER}])`,
);
const EVERY_OTHER_DAY = new RegExp(
  `(?:en\\s+|a\\s+)?d[ií]as\\s+alternos|cada\\s+(?:dos|2|otro)\\s+d[ií]as?|every\\s+(?:other|second|2nd)\\s+day|alternate\\s+days|(?:(?:un|1)\\s+)?d[ií]a\\s+s[ií]\\s*,?\\s*(?:y\\s+)?(?:otro|(?:(?:un|1)\\s+)?d[ií]a|1|uno)\\s+no|day\\s+on\\s*,?\\s*day\\s+off` +
    `|alternando\\s+d[ií]as|d[ií]as\\s+intercalados|d[ií]a\\s+(?:de\\s+)?por\\s+medio|interdiari[oa]s?`,
);
const EVERY_N_DAYS = new RegExp(
  `(?<![${LETTER}])(?:cada|every|c\\/)\\s*(${COUNT})\\s*(?:d[ií]as?|days?|d)(?![${LETTER}])` +
    `|(?<![${LETTER}])(?:every\\s+(third|3rd|fourth|4th)\\s+day|cada\\s+(tercer|cuarto)\\s+d[ií]a)(?![${LETTER}])`,
);
const ORDINAL_DAYS: Record<string, number> = { third: 3, "3rd": 3, tercer: 3, fourth: 4, "4th": 4, cuarto: 4 };
const WEEKLY_AMOUNT = new RegExp(
  `(?:\\/|(?<![${LETTER}])(?:a\\s+la|a|al|por|per|cada|each|every|x|en\\s+la))\\s*(?:la\\s+)?${WEEK}` +
    `|(?<![${LETTER}])(?:semanal(?:es|mente)?|weekly)(?![${LETTER}])`,
);
const DAILY = new RegExp(
  `\\/\\s*(?:d[ií]a|day|d)(?![${LETTER}])|(?<![${LETTER}])(?:al|a|por|per|cada|each|every|todos\\s+los|x)\\s+(?:d[ií]as?|days?)(?:(?<=(?:cada|each|every|todos\\s+los)\\s+(?:d[ií]as?|days?))\\s+(?:de|of)\\s+(?:la|the)\\s+(?:semana|week)(?![${LETTER}])(?!\\s*,?\\s*(?:que|en\\s+(?:que|los\\s+que)|laboral(?:es)?|laborables?|salvo|menos|excepto|quitando|de\\s+entreno|except|but|i|when|that)(?![${LETTER}])))?(?![${LETTER}])|(?<![${LETTER}])(?:diari[oa]s?|daily|a\\s+diario|toda\\s+la\\s+semana|all\\s+week(?:\\s+long)?)(?![${LETTER}])`,
);

/** A count's value: a number word, else the number. */
function readCount(token: string): number {
  return COUNT_WORDS[token] ?? readNumber(token, null);
}

/** A value in grams, or null when the unit is not a mass. */
function grams(value: number, unit: string | null): number | null {
  const perUnit = unit === null ? undefined : GRAMS_PER_UNIT[unit];
  return perUnit === undefined || !Number.isFinite(value) ? null : value * perUnit;
}

/** "y media" followed by "hora" is half an hour ("2 g y media hora antes de entrenar"), not half a gram. */
const NOT_HALF_HOUR = `(?!\\s+(?:horas?|h)(?![${LETTER}]))`;

/**
 * Creatine doses only: an apostrophe or an accent as a decimal mark ("2'5 g", "1´5"), fraction glyphs ("1½",
 * "1⁄2", "2 y ½"), "y medio" after whole grams ("2 gramos y medio"), "un cuarto de", "tres cuartos de", "un par
 * de" and "a couple of" (2, but not "un par de veces se me ha olvidado"), and "once or twice" (Spanish "once" is eleven,
 * so it is not a count word).
 */
function normalizeCreatineText(text: string): string {
  return text
    .replace(/[⁄∕]/g, "/")
    .replace(/(\d)\s*['´’‘`′ʼ＇]\s*(\d)/g, "$1,$2")
    .replace(/(\d)\s+y\s+½/g, "$1,5")
    .replace(/(\d)\s*½/g, "$1,5").replace(/(\d)\s*¼/g, "$1,25").replace(/(\d)\s*¾/g, "$1,75")
    .replace(/½/g, "0,5").replace(/¼/g, "0,25").replace(/¾/g, "0,75")
    .replace(new RegExp(`(?<![\\d.,])(\\d+)\\s*(g|gr|grs|gramos?|grams?)\\s+y\\s+medi[oa](?![${LETTER}])${NOT_HALF_HOUR}`, "g"), "$1,5 $2")
    .replace(new RegExp(`(?<![${LETTER}])un\\s+cuarto\\s+de(?![${LETTER}])`, "g"), "0,25")
    .replace(new RegExp(`(?<![${LETTER}])tres\\s+cuartos\\s+de(?![${LETTER}])`, "g"), "0,75")
    .replace(new RegExp(`(?<![${LETTER}])once\\s+or\\s+twice(?![${LETTER}])`, "g"), "1 or 2 times")
    .replace(
      new RegExp(
        `(?<![${LETTER}])(?:un\\s+par\\s+de|a\\s+couple\\s+of)(?![${LETTER}])(?!\\s+(?:veces|times)\\s+(?:se\\s+me|me\\s+la|me\\s+lo|la\\s+he|lo\\s+he|he|i\\s+(?:forgot|missed|skipped))(?![${LETTER}]))`,
        "g",
      ),
      "2",
    );
}
/** "y medio" left after a decimal amount ("2,5 g y medio", "2,5 y medio"): unclear. */
const LEFTOVER_Y_MEDIO = new RegExp(
  `\\d\\s*(?:(?:g|gr|grs|gramos?|grams?|mg|mgs|miligramos?|milligrams?)\\s*)?y\\s+medi[oa](?![${LETTER}])${NOT_HALF_HOUR}`,
);

/** How often the dose is taken, and the text left once the frequency words are removed. */
interface Frequency {
  timesPerDay: number | null;
  daysPerWeek: number | null;
  everyNDays: number | null;
  weeklyAmount: boolean;
  daily: boolean;
  /** The size of the list of times of day or meals that gave timesPerDay, when one did. */
  listSize: number | null;
  rest: string;
}

/**
 * A clock time after "a las" ("a las 9", "a las 21:30"), not a count ("bajé a las 2 cápsulas"): never an amount. It is
 * replaced by a mark, not a space, so the amounts on either side never join into a range ("3 g a las 8 - 2 g a las 20"
 * is two amounts). Two clock times with no count of times a day are a schedule the reader does not count: it asks.
 */
const CLOCK_TIME = new RegExp(
  `(?<![${LETTER}])a\\s+las\\s+\\d{1,2}(?:[:.h]\\d{2})?(?!\\d|[.,]\\d)(?=\\s*(?:$|[,;.:()+-]|hs?(?![${LETTER}])|(?:y|o|de\\s+la|del|am|pm)(?![${LETTER}])|\\d))`,
  "g",
);

function readFrequency(text: string): Frequency {
  const splitDeclared = SPLIT_INTAKES.test(text);
  let rest = text.replace(CLOCK_TIME, " @ ").replace(LED_DURATION, " ").replace(SPLIT_INTAKES, " ");
  const take = (re: RegExp): RegExpMatchArray | null => {
    const m = rest.match(re);
    if (m) rest = `${rest.slice(0, m.index)} ${rest.slice((m.index ?? 0) + m[0].length)}`;
    return m;
  };
  const timesAt = rest.match(TIMES_PER_DAY)?.index;
  const split = timesAt !== undefined && SPLIT_BEFORE.test(rest.slice(0, timesAt));
  const times = take(TIMES_PER_DAY);
  const named = times?.[3];
  let timesPerDay = times && !split ? (named ? (/^t/.test(named) ? 3 : 2) : readCount(times[1] ?? times[2])) : null;
  // A list of times of day: one intake each, unless the day's total is split or the times are joined by "o", and it
  // must agree with a count of times.
  let listSize: number | null = null;
  const listAt = rest.match(TIMES_OF_DAY)?.index;
  const listSplit = splitDeclared || split || (listAt !== undefined && SPLIT_ACROSS.test(rest.slice(0, listAt)));
  // "o" between two times makes them one intake ("mañana, tarde o noche"); with another time joined by "y" as well
  // ("mañana o tarde, y noche") the count is unclear: it asks.
  const either = EITHER_TIMES.test(rest);
  if (either && (TIMES_OF_DAY.test(rest.replace(EITHER_TIMES, " ")) || TIMES_AND.test(rest))) timesPerDay = NaN;
  const list = either ? null : take(TIMES_OF_DAY);
  if (list && !listSplit) {
    const times = new Set(
      list[0].match(new RegExp(`(?<![${LETTER}])${TIME_OF_DAY}(?![${LETTER}])`, "g"))?.map((t) => t.replace("ñ", "n").replace(/s$/, "")),
    );
    if (timesPerDay === null) listSize = times.size;
    timesPerDay = timesPerDay === null || timesPerDay === times.size ? times.size : NaN;
  }
  const hours = take(EVERY_N_HOURS);
  let everyNDays: number | null = null;
  if (hours) {
    const h = readNumber(hours[1], null);
    if (h > 0 && h < 24) timesPerDay = (timesPerDay ?? 1) * (24 / h);
    else everyNDays = h / 24;
  }
  const days = take(DAYS_PER_WEEK);
  if (take(EVERY_OTHER_DAY)) everyNDays = everyNDays === null ? 2 : NaN;
  const interval = take(EVERY_N_DAYS);
  if (interval) {
    const n = interval[1] !== undefined ? readCount(interval[1]) : ORDINAL_DAYS[interval[2] ?? interval[3]];
    everyNDays = everyNDays === null ? n : NaN;
  }
  const weeklyAmount = take(WEEKLY_AMOUNT) !== null;
  let daily = false;
  while (take(DAILY)) daily = true;
  rest = rest.replace(DURATION, " ");
  const meals = new Set(rest.match(MEAL) ?? []);
  const mealAt = rest.search(MEAL);
  const mealSplit = splitDeclared || split || (mealAt >= 0 && SPLIT_ACROSS.test(rest.slice(0, mealAt)));
  if (EITHER_MEALS.test(rest) && MEALS_AND.test(rest)) timesPerDay = NaN;
  if (meals.size > 1 && timesPerDay === null && !mealSplit && !EITHER_MEALS.test(rest)) {
    timesPerDay = meals.size;
    listSize = meals.size;
  }
  return {
    timesPerDay,
    daysPerWeek: days ? readCount(days[1] ?? days[2]) : null,
    everyNDays,
    weeklyAmount,
    daily,
    listSize,
    rest,
  };
}

/** Every amount with a mass unit in the text, in grams, in order. */
function massAmounts(text: string): number[] {
  const out: number[] = [];
  for (const m of text.matchAll(new RegExp(`(${NUMBER})\\s*(${WORD})`, "g"))) {
    const g = grams(readNumber(m[1], unitOf(m[2])), unitOf(m[2]));
    if (g !== null) out.push(g);
  }
  return out;
}

/**
 * Servings of a mass, each read as count × mass; a range of servings reads its lower end:
 *   - "2 cápsulas de 750 mg", "4 cápsulas x 750 mg", "4 cápsulas 750mg", "1 cacito de 5 g";
 *   - the mass marked as each: "2 cápsulas (750 mg cada una)", "4 gummies (1 g each)";
 *   - a count, a mass, a serving word: "2 500mg capsules", "half a 5g scoop";
 *   - a count "de" a mass: "2 de 750 mg", "4 diarias de 750 mg";
 *   - a count, then a mass each: "4 al día, 1 g cada una".
 */
const SERVINGS_OF = new RegExp(
  `(${COUNT})(?:\\s*${RANGE_SEPARATOR}\\s*${COUNT})?\\s*(?:de\\s+)?${SERVING}\\s*(?:(?:de|of)\\s+|[x*]\\s*|(?=\\d))(${NUMBER})\\s*(${WORD})`,
);
const SERVINGS_EACH = new RegExp(
  `(${COUNT})(?:\\s*${RANGE_SEPARATOR}\\s*${COUNT})?\\s*(?:de\\s+)?${SERVING}\\s*[,(]?\\s*(${NUMBER})\\s*(${WORD})\\s*${EACH}`,
);
const COUNT_MASS_SERVING = new RegExp(`(?<![\\d.,])(${COUNT})\\s+(?:a\\s+)?(${NUMBER})\\s*(${WORD})\\s+${SERVING}`);
const COUNT_OF_MASS = new RegExp(`^[\\s,]*(${COUNT})\\s+de\\s+(${NUMBER})\\s*(${WORD})`);
const COUNT_THEN_EACH = new RegExp(`(?<![\\d.,])(${COUNT})(?:\\s*[,;]\\s*|\\s+)(${NUMBER})\\s*(${WORD})\\s*${EACH}`);
/** "2 x 5 g", "2x5g". */
const COUNT_TIMES = new RegExp(`(?<![\\d.,])(${COUNT})\\s*[x*]\\s*(${NUMBER})\\s*(${WORD})`);
/** "5 g x 2". */
const TIMES_COUNT = new RegExp(`(${NUMBER})\\s*(${WORD})\\s*[x*]\\s*(${COUNT})`);
/**
 * Ranges, which read their lower end, in either order: "3-5 g", "3 a 5 g", "3 g a 5 g", "3 o 5 g", "entre 3 y 5 g",
 * "3 y 5 g", "5 a 3 g". "y" between two amounts that each carry a unit ("1 g y 1 g") is two doses, not a range.
 */
const RANGES = [
  new RegExp(`(?:entre|between)\\s+(${NUMBER})\\s*(?:(${WORD})\\s*)?(?:y|and)\\s*(${NUMBER})\\s*(${WORD})`),
  new RegExp(`(${NUMBER})\\s*(?:(${WORD})\\s*)?(?:-|–|—|~|a|o|ó|to|or)\\s*(${NUMBER})\\s*(${WORD})`),
  new RegExp(`(${NUMBER})()\\s*(?:y|and)\\s*(${NUMBER})\\s*(${WORD})`),
];
/**
 * A count of servings no form read, other than one, before the amount ("4 gominolas, 1 g", "2 cápsulas (750
 * mg)") or after it outside brackets ("2,5 g por toma, 2 tomas"): the mass may be each or the total. A total
 * given with "=" ("2 scoops = 10 g") or a count in brackets after it ("5 g (2 cápsulas)") is read as written.
 */
const UNREAD_SERVINGS = new RegExp(`(?:^|[^\\d.,])(${COUNT})\\s*(?:de\\s+)?${SERVING}(?![${LETTER}.])(?!\\s*=)`, "g");
/** A second amount written without its unit ("1,5 g mañana y 1,5 noche", "2,5 g + 2,5"): two doses. */
const UNITLESS_SECOND_AMOUNT = new RegExp(
  `(${NUMBER})\\s*(${WORD})[^\\d]*?(?:y|and|\\+|,)\\s*(${NUMBER})(?=\\s*(?:$|por|pre|post|am|pm|ma[ñn]ana|tarde|noche|night|evening|morning|antes|despu[ée]s|before|after|al|a\\s+la))`,
);

/** A serving word that counts intakes rather than units with a mass of their own ("2 tomas de 1 g"). */
const INTAKE_SERVING = new RegExp(`(?<![${LETTER}])(?:tomas?|dosis|doses?)(?![${LETTER}])`);
/** A serving word with a mass of its own ("cápsulas", "comprimidos"): an "x" count is of those, not of intakes. */
const OWN_MASS_SERVING = new RegExp(`(?<![${LETTER}])(?!(?:tomas?|dosis|doses?)(?![${LETTER}]))${SERVING}(?![${LETTER}])`);

/** Grams taken each time, and the count of intakes the mass was multiplied by ("2 tomas de 1 g", "1 g x 2"), if any. */
interface Intake {
  grams: number;
  intakes: number | null;
}

/** The grams of a match, its count of intakes, and the text without it; null when the match does not give a mass. */
function readMatch(
  text: string,
  m: RegExpMatchArray | null,
  value: (m: RegExpMatchArray) => number | null,
  intakes: (m: RegExpMatchArray) => number | null = () => null,
) {
  if (!m || m.index === undefined) return null;
  const g = value(m);
  return g === null ? null : { grams: g, intakes: intakes(m), rest: `${text.slice(0, m.index)} ${text.slice(m.index + m[0].length)}` };
}

/** A year or a clock time before an amount ("desde 2024, 5 g", "8:00 1 g"): not part of it. */
const YEAR_OR_CLOCK = new RegExp(`(?<![\\d.,])(?:(?:19|20)\\d{2}|\\d{1,2}[:h]\\d{2})(?!\\d|[.,]\\d)`, "g");

/**
 * Grams taken each time, read from the text left once the frequency words are removed; null when no mass can be
 * read, or when the text holds two amounts that are not one of the forms below ("1 g mañana y 1 g noche"), or a
 * count of servings that the mass may or may not be per serving of.
 */
function gramsPerIntake(text: string): Intake | null {
  const unitGrams = (n: string, w: string) => grams(readNumber(n, unitOf(w)), unitOf(w));
  const countTimesMass = (m: RegExpMatchArray) => {
    const each = unitGrams(m[2], m[3]);
    return each === null ? null : readCount(m[1]) * each;
  };
  const servingIntakes = (m: RegExpMatchArray) => (INTAKE_SERVING.test(m[0]) ? readCount(m[1]) : null);
  const forms = [
    readMatch(text, text.match(SERVINGS_EACH), countTimesMass, servingIntakes),
    readMatch(text, text.match(SERVINGS_OF), countTimesMass, servingIntakes),
    readMatch(text, text.match(COUNT_MASS_SERVING), countTimesMass, servingIntakes),
    readMatch(text, text.match(COUNT_OF_MASS), countTimesMass),
    readMatch(text, text.match(COUNT_THEN_EACH), countTimesMass),
    readMatch(text, text.match(COUNT_TIMES), countTimesMass, (m) => (OWN_MASS_SERVING.test(text) ? null : readCount(m[1]))),
    readMatch(
      text,
      text.match(TIMES_COUNT),
      (m) => {
        const each = unitGrams(m[1], m[2]);
        return each === null ? null : each * readCount(m[3]);
      },
      (m) => (OWN_MASS_SERVING.test(text) ? null : readCount(m[3])),
    ),
    ...RANGES.map((re) =>
      readMatch(text, text.match(re), (m) => {
        // A unit after the first end must be the second end's.
        if (m[2] && unitOf(m[2]) !== unitOf(m[4])) return null;
        const first = unitGrams(m[1], m[4]);
        const second = unitGrams(m[3], m[4]);
        return first === null || second === null ? null : Math.min(first, second);
      }),
    ),
  ];
  const form = forms.find((f) => f !== null);
  if (form) return massAmounts(form.rest).length === 0 ? { grams: form.grams, intakes: form.intakes } : null;

  const amounts = massAmounts(text);
  if (amounts.length > 1) return null;
  if (amounts.length === 1) {
    const mass = [...text.matchAll(new RegExp(`(${NUMBER})\\s*(${WORD})`, "g"))].find((m) => grams(1, unitOf(m[2])) !== null);
    const at = mass?.index ?? 0;
    const after = text.slice(at + (mass?.[0].length ?? 0));
    // A digit right before the amount, joined by spaces or marks the reader does not know ("0 5 g", "2:5 g",
    // "2, 5 g"): part of the number, or a count? A year or a clock time before it is neither.
    if (new RegExp(`\\d[^\\d${LETTER}()%]{0,3}$`).test(text.slice(0, at).replace(YEAR_OR_CLOCK, " "))) return null;
    // The amount marked as each with no count of servings read ("750 mg each, 4 al día"), unless "each" is a time.
    if (new RegExp(`^\\s*${EACH}(?!\\s*${AT_TIME}${TIME_OF_DAY}(?![${LETTER}]))`).test(after)) return null;
    const around = `${text.slice(0, at)} ${after.replace(/\([^)]*\)/g, " ")}`;
    if ([...around.matchAll(UNREAD_SERVINGS)].some((m) => readCount(m[1]) !== 1)) return null;
    if (UNITLESS_SECOND_AMOUNT.test(text)) return null;
    return { grams: amounts[0], intakes: null };
  }
  // A number alone: grams below CREATINE_BARE_DOSE_MG_FROM, else milligrams.
  const bare = text.match(new RegExp(`^[\\s(),.;:-]*(${NUMBER})[\\s(),.;:]*$`));
  if (!bare) return null;
  const value = readNumber(bare[1], null);
  return { grams: value >= CREATINE_BARE_DOSE_MG_FROM ? value / 1000 : value, intakes: null };
}

/** A dose taken each time below this many grams is more likely a unit slip ("5 mg" for 5 g) than a dose: the form asks. */
const SMALLEST_CREATINE_INTAKE_G = 0.1;

/** A stop negated ("nunca he parado", "sin haber parado"): the client still takes it. */
const NEGATED_STOP = new RegExp(`(?<![${LETTER}])(?:nunca|no|sin|jam[aá]s)\\s+(?:(?:lo|la)\\s+)?(?:he\\s+|haber\\s+)?parad[oa](?![${LETTER}])`, "g");
/** A current dose stated ("ahora 5 g", "now 5 g"), which past phrasing ("hasta hace", "estaba tomando") does not stop. */
const CURRENT_DOSE = new RegExp(`(?<![${LETTER}])(?:ahora|actualmente|now|currently)(?!\\s+no(?![${LETTER}]))(?![${LETTER}])`);
const PAST_PHRASING = new RegExp(
  `(?<![${LETTER}])(?:est(?:aba|uve)\\s+tomando|hasta\\s+hace|until\\s+(?:last\\s+[${LETTER}]+|\\S+\\s+\\S+\\s+ago))(?![${LETTER}])`,
  "g",
);

/** Longer texts are not read: the context form stores at most 120 characters (patient-context/schema.ts). */
const LONGEST_CREATINE_DOSE = 120;

/**
 * More grams a day than this is not a creatine dose (a loading phase is 20 to 25 g a day): more likely a misread
 * ("desde 2023 - 1,5 g"), so the form asks.
 */
const LARGEST_CREATINE_G_PER_DAY = 50;

/**
 * Grams of creatine per day in a free-text dose, as clients write it: "5 g",
 * "5 gramos al día", "5000 mg", "5" (grams below 100, else milligrams), "3 a
 * 5 g" (the lower end), "2 x 2,5 g", "2 cápsulas de 750 mg", "1 cacito (5 g)",
 * "2,5 g dos veces al día" (5), "5 g, 3 días a la semana" (5 × 3/7), "5 g en
 * días alternos" (2.5), "5 g cada 3 días" (5/3), "35 g a la semana" (5).
 *
 * Null when it cannot be read as a daily mass: no amount with a mass unit
 * ("1 cacito"), a dose per unit of body weight ("0,3 g/kg/día", "0,3 g/kilo"),
 * a slash between numbers ("1/2 g"), two amounts that are not a range or a
 * product ("1 g mañana y 1 g noche", "20 g 5 días y luego 5 g"), two ways of
 * saying how often that disagree ("5 g al día, 3 días a la semana": every day,
 * or three days a week?), a schedule with no count of days a week ("5 g los
 * lunes", "los días de entreno", "cada 2 semanas", "a veces", "si me acuerdo",
 * "no todos los días", "antes y después de entrenar", "a las 9 y a las 21"), a
 * list of times that mixes "o" and "y" ("mañana o tarde, y noche"), a week word
 * no frequency read ("durante la semana", "una vez esta semana"), a dose the
 * client stopped ("ya no, antes 5 g", "estuve tomando 5 g", but not "nunca he
 * parado" or "hasta hace un mes en ayunas, ahora con comida"), an intake under
 * 0.1 g ("5 mg"), or more than 50 g a day. The context form asks for grams a day then, and shows what it read
 * otherwise (PatientContextGate). Zero only when the client wrote zero.
 */
export function readCreatineDose(dose: string | null | undefined): number | null {
  if (typeof dose !== "string" || dose.length > LONGEST_CREATINE_DOSE) return null;
  const text = normalizeCreatineText(normalizeDose(dose));
  if (!text) return null;
  const stopText = (CURRENT_DOSE.test(text) ? text.replace(PAST_PHRASING, " ") : text).replace(NEGATED_STOP, " ");
  if (
    STOPPED.test(stopText) ||
    [PER_KG, SLASH_BETWEEN_NUMBERS, ALTERNATE_WEEKS, NOT_DAILY, LEFTOVER_Y_MEDIO, BEFORE_AND_AFTER].some((re) => re.test(text))
  ) {
    return null;
  }
  const f = readFrequency(text);
  const weekly = [f.daysPerWeek !== null, f.everyNDays !== null, f.weeklyAmount].filter(Boolean).length;
  if (weekly > 1 || (weekly === 1 && f.daily)) return null;
  const schedule = f.rest.replace(NEGATED_CYCLING, " ");
  if (IRREGULAR_INTAKE.test(schedule) || SOMETIMES.test(schedule)) return null;
  if (MOST_DAYS.test(schedule) && !(f.daily && MOST_DAYS_TIMING.test(schedule))) return null;
  if (weekly === 0 && UNCOUNTED_SCHEDULE.test(schedule)) return null;
  if (UNREAD_WEEK.test(f.rest)) return null;
  const dangling = f.rest.match(DANGLING_TIMES);
  if (dangling && readCount(dangling[1]) !== 1) return null;
  if (f.timesPerDay !== null && !(f.timesPerDay > 0 && f.timesPerDay <= 10)) return null;
  if (f.daysPerWeek !== null && !(f.daysPerWeek > 0 && f.daysPerWeek <= 7)) return null;
  if (f.everyNDays !== null && !(f.everyNDays >= 1 && f.everyNDays <= 7)) return null;
  if (f.timesPerDay === null && (f.rest.match(/@/g) ?? []).length > 1) return null;
  const intake = gramsPerIntake(f.rest);
  if (intake === null) return null;
  // A count of intakes written twice, as a count ("2 tomas de 1 g", "1 g x2") and as a list ("mañana y noche"), is
  // one count. Servings with a mass of their own ("2 cápsulas de 750 mg, mañana y noche") stay each time.
  const each = f.listSize !== null && intake.intakes === f.listSize ? intake.grams / f.listSize : intake.grams;
  if (each > 0 && each < SMALLEST_CREATINE_INTAKE_G) return null;
  const perDay =
    (f.timesPerDay ?? 1) *
    (f.daysPerWeek !== null ? f.daysPerWeek / 7 : 1) *
    (f.everyNDays !== null ? 1 / f.everyNDays : 1) *
    (f.weeklyAmount ? 1 / 7 : 1);
  const g = each * perDay;
  // Zero only when the client wrote zero.
  if (g === 0 && /[1-9]/.test(text)) return null;
  if (g > LARGEST_CREATINE_G_PER_DAY) return null;
  return Number.isFinite(g) && g >= 0 ? g : null;
}

/**
 * The creatine dose the client declared, in grams per day; null when
 * creatine is not declared, or its dose is missing, zero or cannot be read
 * (`readCreatineDose`): then nothing is adjusted.
 */
export function creatineDoseGramsPerDay(
  supplements: readonly SupplementEntry[] | null | undefined,
): number | null {
  if (!Array.isArray(supplements)) return null;
  for (const s of supplements) {
    if (!s?.key || s.key.toLowerCase() !== "creatine") continue;
    const g = readCreatineDose(s.dose);
    return g !== null && g > 0 ? g : null;
  }
  return null;
}

/**
 * What a declared creatine dose divides serum creatinine by before a
 * biological age reads it (EVA's rule since 30 October 2026):
 *
 *   divisor = 1 + CREATINE_CREATININE_RISE × min(dose, 3) / 3
 *
 *   no dose  → 1 (unchanged)
 *   1 g/day  → 1.043
 *   2 g/day  → 1.087
 *   3 g/day and more → 1.13
 *
 * It replaces the earlier dose formula, min(0.05 + 0.025 × g/day, 0.40)
 * mg/dL subtracted, which had no source and removed two to four times the
 * trial rise at 10 to 20 g/day.
 */
export function creatineCreatinineDivisor(gramsPerDay: number | null | undefined): number {
  if (typeof gramsPerDay !== "number" || !Number.isFinite(gramsPerDay) || gramsPerDay <= 0) {
    return 1;
  }
  return (
    1 +
    (CREATINE_CREATININE_RISE * Math.min(gramsPerDay, CREATINE_SATURATING_DOSE_G)) /
      CREATINE_SATURATING_DOSE_G
  );
}

/** Serum creatinine (any unit) with the declared creatine dose's rise removed. */
export function creatineAdjustedCreatinine(
  creatinine: number,
  supplements: readonly SupplementEntry[] | null | undefined,
): number {
  return creatinine / creatineCreatinineDivisor(creatineDoseGramsPerDay(supplements));
}
