import { describe, it, expect } from "vitest";
import { classifyZone } from "./zone-classifier";
import { calculateLongevityScoreV2, type BiomarkerInput } from "./longevity-score";
import { calculateAllMetrics } from "./calculated-metrics";
import { matchBiomarkerName } from "./name-matcher";
import { pickReferenceRows } from "./reference-row";
import { signedRows } from "./__tests__/fixtures/reviewed-rows";

// ═══════════════════════════════════════════════════════════════════════════════
// Zone Classification
// ═══════════════════════════════════════════════════════════════════════════════

describe("Zone Classifier", () => {
  describe("standard ranges (Vitamin D: optimal 40-60, normal 10-100)", () => {
    it("classifies critical_low (below normal)", () => {
      expect(classifyZone(5, 40, 60, 10, 100)).toBe("critical_low");
    });
    it("classifies below_optimal (below optimal, above normal)", () => {
      expect(classifyZone(28, 40, 60, 10, 100)).toBe("below_optimal");
    });
    it("classifies optimal", () => {
      expect(classifyZone(55, 40, 60, 10, 100)).toBe("optimal");
    });
    it("classifies above_optimal (above optimal, below normal high)", () => {
      expect(classifyZone(85, 40, 60, 10, 100)).toBe("above_optimal");
    });
    it("classifies critical_high (above normal)", () => {
      expect(classifyZone(105, 40, 60, 10, 100)).toBe("critical_high");
    });
  });

  describe("boundary values", () => {
    it("optimal_low boundary is inclusive", () => {
      expect(classifyZone(40, 40, 60, 10, 100)).toBe("optimal");
    });
    it("optimal_high boundary is inclusive", () => {
      expect(classifyZone(60, 40, 60, 10, 100)).toBe("optimal");
    });
    it("normal_low boundary is below_optimal (< is critical, = is below_optimal)", () => {
      expect(classifyZone(10, 40, 60, 10, 100)).toBe("below_optimal");
      expect(classifyZone(9, 40, 60, 10, 100)).toBe("critical_low");
    });
  });

  describe("one-sided ranges", () => {
    // hs-CRP: optimal_low=null, optimal_high=1.0
    it("one-sided lower: value within optimal", () => {
      expect(classifyZone(0.3, null, 1.0, null, 10.0)).toBe("optimal");
    });
    it("one-sided lower: value above optimal", () => {
      expect(classifyZone(3.5, null, 1.0, null, 10.0)).toBe("above_optimal");
    });
    it("one-sided lower: value critical high", () => {
      expect(classifyZone(12, null, 1.0, null, 10.0)).toBe("critical_high");
    });

    // eGFR: optimal_low=90, optimal_high=null
    it("one-sided upper: value within optimal", () => {
      expect(classifyZone(105, 90, null, 60, null)).toBe("optimal");
    });
    it("one-sided upper: value below optimal", () => {
      expect(classifyZone(75, 90, null, 60, null)).toBe("below_optimal");
    });
    it("one-sided upper: value critical low", () => {
      expect(classifyZone(50, 90, null, 60, null)).toBe("critical_low");
    });
  });

  describe("reference limits always define out of range", () => {
    // Row with a floor but no evidence-based ceiling: above the reference limit is still out of range.
    it("above normal_high with no optimal ceiling is critical_high", () => {
      expect(classifyZone(140, 40, null, 20, 130)).toBe("critical_high");
      expect(classifyZone(120, 40, null, 20, 130)).toBe("optimal");
    });
    // Inconsistent row (optimal ceiling above the reference limit): the reference limit wins.
    it("normal_high wins over an optimal ceiling above it", () => {
      expect(classifyZone(1000, 500, 1100, 200, 900)).toBe("critical_high");
      expect(classifyZone(850, 500, 1100, 200, 900)).toBe("optimal");
    });
    it("below normal_low with no optimal floor is critical_low", () => {
      expect(classifyZone(3, null, 100, 5, 150)).toBe("critical_low");
      expect(classifyZone(6, null, 100, 5, 150)).toBe("optimal");
    });
  });

  // The database lookups by fixed age brackets (classifyBiomarker/s) matched no live row and are gone (C4):
  // rows are picked in reference-row.ts.
  it("exports only pure helpers, no database lookup", async () => {
    expect(Object.keys(await import("./zone-classifier")).sort()).toEqual(["ZONE_CONFIG", "calculateAge", "classifyZone", "parseDateOfBirth"]);
  });

  describe("missing reference (all nulls)", () => {
    // No bounds means no category: the value must not be shown as optimal.
    it("returns unclassified when all ranges are null", () => {
      expect(classifyZone(50, null, null, null, null)).toBe("unclassified");
    });
    it("classifies as soon as one bound exists", () => {
      expect(classifyZone(200, 205, null, null, null)).toBe("below_optimal");
      expect(classifyZone(210, 205, null, null, null)).toBe("optimal");
    });
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Age Group Matching (tested via the longevity score on the reviewed rows)
// ═══════════════════════════════════════════════════════════════════════════════

// The score reads the reviewed rows of the seed, picked for the person as processing picks them.
const ROWS = signedRows();
const score = (panel: BiomarkerInput[], sex: "male" | "female", age: number) => calculateLongevityScoreV2(panel, sex, age, ROWS);

describe("Age Group Matching (via score validation)", () => {
  const minimalPanel = [
    { code: "APOB", value: 80 }, { code: "HBA1C", value: 5.2 },
    { code: "GLUCOSE", value: 85 }, { code: "HSCRP", value: 0.5 },
    { code: "ALT", value: 20 }, { code: "RDW", value: 12 },
    { code: "HGB", value: 15 }, { code: "HDL_C", value: 55 },
    { code: "TG", value: 80 }, { code: "WBC", value: 5500 },
    { code: "CREATININE", value: 0.9 },
  ];

  it("age 17 still calculates (no row's age group contains a minor: each marker falls back to its rows)", () => {
    expect(pickReferenceRows(ROWS, "male", 17).fallbacks).toContain("hba1c");
    const r = score(minimalPanel, "male", 17);
    expect(r.validation.valid).toBe(true);
  });

  it("age 25 calculates", () => {
    const r = score(minimalPanel, "male", 25);
    expect(r.validation.valid).toBe(true);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 30 calculates correctly", () => {
    const r = score(minimalPanel, "male", 30);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 55 calculates correctly", () => {
    const r = score(minimalPanel, "male", 55);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 96 calculates (rows with no upper age)", () => {
    const r = score(minimalPanel, "male", 96);
    expect(r.longevityScore).toBeGreaterThan(0);
  });

  it("age 105 calculates (rows with no upper age)", () => {
    const r = score(minimalPanel, "male", 105);
    expect(r.longevityScore).toBeGreaterThan(0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Longevity Score (the penalty engine, on the reviewed rows)
// ═══════════════════════════════════════════════════════════════════════════════

describe("Longevity Score", () => {
  const fullPanel = [
    { code: "APOB", value: 109.7 }, { code: "LDL_C", value: 118 },
    { code: "HBA1C", value: 5.2 }, { code: "GLUCOSE", value: 87 },
    { code: "INSULIN", value: 3.5 }, { code: "HOMA_IR", value: 0.71 },
    { code: "HSCRP", value: 0.59 }, { code: "EGFR", value: 78 },
    { code: "HDL_C", value: 45 }, { code: "TG", value: 67 },
    { code: "LPA", value: 14.7 }, { code: "ALT", value: 59 },
    { code: "RDW", value: 11.9 }, { code: "ALBUMIN", value: 42.7 },
    { code: "VITD", value: 11.6 }, { code: "TESTOSTERONE", value: 5.63 },
    { code: "WBC", value: 7870 }, { code: "LYMPH_PCT", value: 42.4 },
    { code: "FERRITIN", value: 217.56 }, { code: "TSAT", value: 71.88 },
    { code: "TSH", value: 1.23 }, { code: "SHBG", value: 22.6 },
    { code: "URIC_ACID", value: 5.9 }, { code: "GGT", value: 22 },
    { code: "AST", value: 39 }, { code: "HGB", value: 15.1 },
    { code: "MCV", value: 95.6 }, { code: "B12", value: 315 },
    { code: "FOLATE", value: 7.3 }, { code: "CREATININE", value: 1.17 },
    { code: "PLT", value: 299000 }, { code: "MAGNESIUM", value: 2.0 },
    { code: "ZINC", value: 65 }, { code: "FT4", value: 0.84 },
    { code: "FT3", value: 2.45 }, { code: "BILIRUBIN", value: 0.4 },
    { code: "ALP", value: 83 },
  ];

  it("full panel passes validation", () => {
    const r = score(fullPanel, "male", 30);
    expect(r.validation.valid).toBe(true);
    expect(r.confidence).not.toBe("insufficient");
  });

  it("produces valid longevity score (1-100)", () => {
    const r = score(fullPanel, "male", 30);
    expect(r.longevityScore).toBeGreaterThanOrEqual(1);
    expect(r.longevityScore).toBeLessThanOrEqual(100);
  });

  it("computes no biological age of its own (the KDM estimate is EVA's)", () => {
    const r = score(fullPanel, "male", 30);
    expect(r).not.toHaveProperty("biologicalAge");
    expect(r.markerScores[0]).not.toHaveProperty("baYearsImpact");
  });

  it("suppresses LDL_C when APOB present (redundancy)", () => {
    const r = score(fullPanel, "male", 30);
    expect(r.suppressedMarkers.some((s) => s.code === "LDL_C" && s.suppressedBy === "APOB")).toBe(true);
  });

  it("a penalised marker costs score points; an optimal marker costs none and earns none", () => {
    const r = score(fullPanel, "male", 30);
    const vitd = r.markerScores.find((m) => m.code === "VITD")!;
    expect(vitd.rawPenalty).toBeGreaterThan(0);
    expect(vitd.lsPointsImpact).toBeGreaterThan(0);
    const optimal = r.markerScores.filter((m) => m.rawPenalty === 0);
    expect(optimal.length).toBeGreaterThan(0);
    for (const m of optimal) expect(m.lsPointsImpact).toBe(0);
  });

  it("returns insufficient for too few markers", () => {
    const r = score([{ code: "HBA1C", value: 5.2 }], "male", 30);
    expect(r.validation.valid).toBe(false);
    expect(r.longevityScore).toBe(-1);
  });

  it("returns insufficient when domains are missing", () => {
    // Only metabolic markers — missing cardiovascular, inflammatory, organ_function, hematology
    const r = score([
      { code: "HBA1C", value: 5.2 }, { code: "GLUCOSE", value: 87 },
      { code: "INSULIN", value: 3.5 }, { code: "HOMA_IR", value: 0.71 },
      { code: "URIC_ACID", value: 5.0 },
      { code: "B12", value: 500 }, { code: "FOLATE", value: 12 },
      { code: "MAGNESIUM", value: 2.2 }, { code: "ZINC", value: 90 },
    ], "male", 30);
    expect(r.validation.valid).toBe(false);
  });

  it("perfect panel produces high longevity score", () => {
    const perfectPanel = [
      { code: "APOB", value: 60 }, { code: "HBA1C", value: 5.0 },
      { code: "GLUCOSE", value: 82 }, { code: "INSULIN", value: 3.0 },
      { code: "HSCRP", value: 0.3 }, { code: "EGFR", value: 110 },
      { code: "HDL_C", value: 65 }, { code: "TG", value: 60 },
      { code: "ALT", value: 18 }, { code: "RDW", value: 12 },
      { code: "HGB", value: 15.5 }, { code: "WBC", value: 5000 },
      { code: "ALBUMIN", value: 46 }, { code: "VITD", value: 50 },
      { code: "CREATININE", value: 0.9 },
    ];
    const r = score(perfectPanel, "male", 30);
    expect(r.longevityScore).toBeGreaterThanOrEqual(85);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Calculated Metrics
// ═══════════════════════════════════════════════════════════════════════════════

describe("Calculated Metrics", () => {
  // Reviewed rows, picked for the person the way processing picks them. The nlr row is the CMO's
  // (2026-09-25): 18-59 reference 0.8–3.5, 60+ 0.8–3.9, optimal 0.8–2.0 at every age.
  const REVIEWED = [
    { biomarker_key: "homa_ir", sex: "both", age_group_en: "All Adults", normal_low: 0, normal_high: 3.46, optimal_low: null, optimal_high: 1.8 },
    { biomarker_key: "non_hdl_cholesterol", sex: "both", age_group_en: "All Adults", normal_low: 0, normal_high: 130, optimal_low: null, optimal_high: 90 },
    { biomarker_key: "nlr", sex: "both", age_group_en: "18-59", normal_low: 0.8, normal_high: 3.5, optimal_low: 0.8, optimal_high: 2.0 },
    { biomarker_key: "nlr", sex: "both", age_group_en: "60+", normal_low: 0.8, normal_high: 3.9, optimal_low: 0.8, optimal_high: 2.0 },
  ];
  const rowsFor = (sex: string, age: number) => pickReferenceRows(REVIEWED, sex, age).picked;
  const inputs = (values: Record<string, number>) => Object.entries(values).map(([biomarker_key, value]) => ({ biomarker_key, value }));
  const metric = (key: string, values: Record<string, number>, rows = rowsFor("male", 45)) =>
    calculateAllMetrics(inputs(values), rows).find((m) => m.metricKey === key);

  it("HOMA-IR: (5 * 90) / 405 ≈ 1.11 → optimal on the homa_ir row", () => {
    const homa = metric("homa_ir", { fasting_insulin: 5.0, glucose_fasting: 90 });
    expect(homa).toBeDefined();
    expect(homa!.value).toBeCloseTo(1.11, 1);
    expect(homa!.zone).toBe("optimal");
  });

  it("HOMA-IR takes its category from the homa_ir row (optimal ≤1.8, reference ≤3.46)", () => {
    expect(metric("homa_ir", { insulin_fasting: 10, glucose_fasting: 89 })).toMatchObject({ value: 2.2, zone: "above_optimal" });
    expect(metric("homa_ir", { insulin_fasting: 18, glucose_fasting: 108 })).toMatchObject({ value: 4.8, zone: "critical_high" });
  });

  it("computed non-HDL-C takes its category from the non_hdl_cholesterol row", () => {
    expect(metric("non_hdl", { total_cholesterol: 220, hdl_cholesterol: 50 })).toMatchObject({ value: 170, zone: "critical_high" });
    expect(metric("non_hdl", { total_cholesterol: 150, hdl_cholesterol: 50 })).toMatchObject({ value: 100, zone: "above_optimal" });
    expect(metric("non_hdl", { total_cholesterol: 140, hdl_cholesterol: 50 })).toMatchObject({ value: 90, zone: "optimal" });
  });

  it("NLR takes its category from the nlr row picked for the person's age", () => {
    expect(metric("nlr", { neutrophils: 4.5, lymphocytes: 1.5 })).toMatchObject({ value: 3.0, zone: "above_optimal" });
    expect(metric("nlr", { neutrophils: 66.6, lymphocytes: 18 }, rowsFor("female", 45))).toMatchObject({ value: 3.7, zone: "critical_high" });
    expect(metric("nlr", { neutrophils: 66.6, lymphocytes: 18 }, rowsFor("female", 65))).toMatchObject({ value: 3.7, zone: "above_optimal" });
    expect(metric("nlr", { neutrophils: 35, lymphocytes: 50 })).toMatchObject({ value: 0.7, zone: "critical_low" });
  });

  it("a metric with no reviewed row has no category: TG/HDL, De Ritis, omega-3 index, FAI", () => {
    expect(metric("tg_hdl_ratio", { triglycerides: 200, hdl_cholesterol: 50 })).toMatchObject({ value: 4.0, zone: "unclassified" });
    expect(metric("de_ritis", { ast: 35, alt: 20 })).toMatchObject({ value: 1.75, zone: "unclassified" });
    expect(metric("omega3_index", { epa: 1.1, dha: 3.2, total_fatty_acids: 61 })).toMatchObject({ value: 7.05, zone: "unclassified" });
    expect(metric("fai", { testosterone: 600, shbg: 40 })).toMatchObject({ zone: "unclassified" });
  });

  it("without rows every metric is unclassified, and no metric carries text of its own", () => {
    const all = { insulin_fasting: 12.4, glucose_fasting: 97, triglycerides: 131, hdl_cholesterol: 47, ast: 27, alt: 33, neutrophils: 61.3, lymphocytes: 27.9, total_cholesterol: 213 };
    const bare = calculateAllMetrics(inputs(all));
    expect(bare.map((m) => m.zone)).toEqual(bare.map(() => "unclassified"));
    for (const m of calculateAllMetrics(inputs(all), rowsFor("male", 45))) {
      expect([m.interpretation, m.interpretation_es]).toEqual(["", ""]);
    }
  });

  it("keys, names, values and units are the ones computed before the change", () => {
    const values = {
      insulin_fasting: 12.4, glucose_fasting: 97, triglycerides: 131, hdl_cholesterol: 47, ast: 27, alt: 33, epa: 1.1, dha: 3.2,
      total_fatty_acids: 61, neutrophils: 61.3, lymphocytes: 27.9, testosterone_total: 5.1, shbg: 38, total_cholesterol: 213,
    };
    expect(calculateAllMetrics(inputs(values), rowsFor("female", 45)).map((m) => [m.metricKey, m.metricName, m.value, m.unit])).toEqual([
      ["homa_ir", "HOMA-IR", 2.97, ""],
      ["tg_hdl_ratio", "TG/HDL Ratio", 2.79, ""],
      ["de_ritis", "De Ritis Ratio (AST/ALT)", 0.82, ""],
      ["omega3_index", "Omega-3 Index", 7.05, "%"],
      ["nlr", "Neutrophil-to-Lymphocyte Ratio", 2.2, ""],
      ["fai", "Free Androgen Index", 46.53, ""],
      ["non_hdl", "Non-HDL Cholesterol", 166, "mg/dL"],
    ]);
  });

  it("returns empty for missing biomarkers", () => {
    const metrics = calculateAllMetrics([]);
    expect(metrics.length).toBe(0);
  });

  it("skips metrics with missing inputs", () => {
    const metrics = calculateAllMetrics([
      { biomarker_key: "ast", value: 25 },
      // alt is missing, so De Ritis can't compute
    ]);
    expect(metrics.find((m) => m.metricKey === "de_ritis")).toBeUndefined();
  });

  // ─── A bounded input ("<2", whose value is the bound) ───
  // The metric is a bound when every bounded input moves it the same way, and is placed only where every value it
  // allows has one zone (bounded-result.ts classifyResultZone); when its inputs move it opposite ways it stays
  // unclassified. Known issue C-06: a metric is never classified from a bound as if the bound were measured.
  const withBounds = (values: Record<string, number>, signs: Record<string, "<" | ">">) =>
    Object.entries(values).map(([biomarker_key, value]) => ({ biomarker_key, value, comparator: signs[biomarker_key] ?? null }));
  const boundedMetric = (key: string, values: Record<string, number>, signs: Record<string, "<" | ">">, rows = rowsFor("male", 45)) =>
    calculateAllMetrics(withBounds(values, signs), rows).find((m) => m.metricKey === key);

  it('a bounded insulin gives an unclassified HOMA-IR when its bound spans the optimal ceiling: insulin "<10" with glucose 96', () => {
    // Measured, 10 µU/mL gives 2.37, above the 1.8 ceiling; "<10" allows every HOMA-IR from 0 up to 2.37.
    expect(metric("homa_ir", { insulin_fasting: 10, glucose_fasting: 96 })).toMatchObject({ value: 2.37, comparator: null, zone: "above_optimal" });
    expect(boundedMetric("homa_ir", { insulin_fasting: 10, glucose_fasting: 96 }, { insulin_fasting: "<" })).toMatchObject({
      value: 2.37, comparator: "<", zone: "unclassified",
    });
  });

  it('insulin "<2" with glucose 96 gives HOMA-IR "<0.47": every value it allows is below the 1.8 ceiling, so it is optimal', () => {
    // The homa_ir row has no optimal floor and a reference floor of 0, so the bound is placed, as insulin "<2" is.
    expect(boundedMetric("homa_ir", { insulin_fasting: 2, glucose_fasting: 96 }, { insulin_fasting: "<" })).toMatchObject({
      value: 0.47, comparator: "<", zone: "optimal",
    });
  });

  it('a "<" on an input the metric falls with bounds the metric from below: lymphocytes "<10" % puts NLR above 6', () => {
    // NLR ">6" is above the 18-59 reference ceiling of 3.5 whatever its true value.
    expect(boundedMetric("nlr", { neutrophils: 60, lymphocytes: 10 }, { lymphocytes: "<" })).toMatchObject({ value: 6, comparator: ">", zone: "critical_high" });
    // HDL ">100" with total cholesterol 180 puts non-HDL below 80, inside the optimal band (ceiling 90).
    expect(boundedMetric("non_hdl", { total_cholesterol: 180, hdl_cholesterol: 100 }, { hdl_cholesterol: ">" })).toMatchObject({ value: 80, comparator: "<", zone: "optimal" });
  });

  it("inputs that move the metric opposite ways leave it unclassified, with no comparator", () => {
    expect(boundedMetric("homa_ir", { insulin_fasting: 2, glucose_fasting: 200 }, { insulin_fasting: "<", glucose_fasting: ">" })).toMatchObject({
      comparator: null, zone: "unclassified",
    });
    expect(boundedMetric("non_hdl", { total_cholesterol: 150, hdl_cholesterol: 40 }, { total_cholesterol: "<", hdl_cholesterol: "<" })).toMatchObject({
      comparator: null, zone: "unclassified",
    });
    // Two bounds that move it the same way still give a bound: TG "<50" and HDL ">100" put TG/HDL below 0.5.
    expect(boundedMetric("tg_hdl_ratio", { triglycerides: 50, hdl_cholesterol: 100 }, { triglycerides: "<", hdl_cholesterol: ">" })).toMatchObject({
      value: 0.5, comparator: "<", zone: "unclassified", // no reviewed tg_hdl_ratio row
    });
  });

  it('a metric bounded by "<" is never above optimal or above the range, at any bound and any measured glucose', () => {
    for (let x = 0.5; x <= 40; x += 0.5) {
      for (let glucose = 60; glucose <= 300; glucose += 7) {
        const homa = boundedMetric("homa_ir", { insulin_fasting: x, glucose_fasting: glucose }, { insulin_fasting: "<" })!;
        expect(homa.comparator).toBe("<");
        expect(["above_optimal", "critical_high"], `insulin <${x}, glucose ${glucose}`).not.toContain(homa.zone);
      }
    }
  });

  it("a measured panel: a null comparator beside each value changes nothing, and no metric has a comparator", () => {
    const values = { insulin_fasting: 12.4, glucose_fasting: 97, triglycerides: 131, hdl_cholesterol: 47, neutrophils: 61.3, lymphocytes: 27.9, total_cholesterol: 213 };
    const rows = rowsFor("female", 45);
    expect(calculateAllMetrics(withBounds(values, {}), rows)).toEqual(calculateAllMetrics(inputs(values), rows));
    for (const m of calculateAllMetrics(inputs(values), rows)) expect(m.comparator).toBeNull();
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Name Matcher
// ═══════════════════════════════════════════════════════════════════════════════

describe("Name Matcher", () => {
  describe("exact match", () => {
    it("matches canonical key directly", () => {
      const r = matchBiomarkerName("Hemoglobin");
      expect(r.biomarkerKey).toBe("hemoglobin");
      expect(r.confidence).toBe("exact");
    });

    it("matches with different casing", () => {
      const r = matchBiomarkerName("HBA1C");
      expect(r.biomarkerKey).toBe("hba1c");
      expect(r.confidence).toBe("exact");
    });
  });

  describe("alias match", () => {
    it("matches English alias", () => {
      const r = matchBiomarkerName("Vitamin D");
      expect(r.biomarkerKey).toBe("vitamin_d_25_oh");
      expect(r.confidence).toBe("alias");
    });

    it("matches Spanish alias", () => {
      const r = matchBiomarkerName("Glucosa en ayunas");
      expect(r.biomarkerKey).toBe("glucose_fasting");
      expect(r.confidence).toBe("alias");
    });

    it("matches common abbreviation", () => {
      const r = matchBiomarkerName("GPT");
      expect(r.biomarkerKey).toBe("alt");
      expect(r.confidence).toBe("alias");
    });

    it("matches lab variant name", () => {
      const r = matchBiomarkerName("Hemoglobina glicosilada");
      expect(r.biomarkerKey).toBe("hba1c");
      expect(r.confidence).toBe("alias");
    });

    it("matches hs-CRP Spanish", () => {
      const r = matchBiomarkerName("PCR ultrasensible");
      expect(r.biomarkerKey).toBe("hs_crp");
      expect(r.confidence).toBe("alias");
    });

    it("matches ApoB variants", () => {
      expect(matchBiomarkerName("Apo B").biomarkerKey).toBe("apolipoprotein_b_apob");
      expect(matchBiomarkerName("Apolipoproteina B").biomarkerKey).toBe(
        "apolipoprotein_b_apob",
      );
    });
  });

  describe("fuzzy match (Levenshtein ≤ 2)", () => {
    it("matches with 1 char typo", () => {
      const r = matchBiomarkerName("ferritni");
      expect(r.biomarkerKey).toBe("ferritin");
      expect(r.confidence).toBe("fuzzy");
    });

    it("matches with transposition", () => {
      const r = matchBiomarkerName("creatinien");
      expect(r.confidence).toBe("fuzzy");
      expect(r.biomarkerKey).toBe("creatinine");
    });
  });

  describe("no match", () => {
    it("returns null for unrecognizable name", () => {
      const r = matchBiomarkerName("xyzzy foobarbaz");
      expect(r.biomarkerKey).toBeNull();
      expect(r.confidence).toBe("none");
    });

    it("returns null for empty string", () => {
      const r = matchBiomarkerName("");
      expect(r.biomarkerKey).toBeNull();
      expect(r.confidence).toBe("none");
    });
  });

  describe("Spanish accents and CBC-prefix tolerance", () => {
    it("matches accented Spanish name (Neutrófilos → neutrophils)", () => {
      const r = matchBiomarkerName("Neutrófilos");
      expect(r.biomarkerKey).toBe("neutrophils");
      expect(r.confidence).toBe("alias");
    });

    it("strips '%' prefix used for CBC differential lines", () => {
      const r = matchBiomarkerName("% Neutrófilos");
      expect(r.biomarkerKey).toBe("neutrophils");
      expect(r.confidence).toBe("alias");
    });

    it("strips '#' prefix used for absolute CBC counts", () => {
      const r = matchBiomarkerName("# Eosinófilos");
      expect(r.biomarkerKey).toBe("eosinophils");
      expect(r.confidence).toBe("alias");
    });

    it("matches Basófilos with accent", () => {
      const r = matchBiomarkerName("Basófilos");
      expect(r.biomarkerKey).toBe("basophils");
      expect(r.confidence).toBe("alias");
    });
  });

  describe("parenthesis-splitting fallback", () => {
    it("matches when abbreviation is wrapped: 'SHBG (Sex hormone binding globulin)'", () => {
      const r = matchBiomarkerName("SHBG (Sex hormone binding globulin)");
      // SHBG resolves exact on the inner-or-outer split — exact beats alias.
      expect(r.biomarkerKey).toBe("shbg");
      expect(r.confidence).toBe("exact");
    });

    it("matches when full name leads and abbreviation is in parens", () => {
      const r = matchBiomarkerName("Sex Hormone Binding Globulin (SHBG)");
      expect(r.biomarkerKey).toBe("shbg");
      expect(r.confidence).toBe("exact");
    });

    it("matches Spanish AMH wrapped variant", () => {
      const r = matchBiomarkerName("Hormona Antimulleriana (AMH)");
      expect(r.biomarkerKey).toBe("anti_mullerian_hormone_amh");
      // Both the abbreviation and the full name resolve via alias to
      // the seed key — alias is the highest confidence available.
      expect(r.confidence).toBe("alias");
    });
  });

  describe("newly-added aliases", () => {
    it("matches AMH abbreviation", () => {
      const r = matchBiomarkerName("AMH");
      expect(r.biomarkerKey).toBe("anti_mullerian_hormone_amh");
      expect(r.confidence).toBe("alias");
    });

    it("matches Spanish lipasa", () => {
      const r = matchBiomarkerName("Lipasa");
      expect(r.biomarkerKey).toBe("lipase");
      expect(r.confidence).toBe("alias");
    });

    it("matches Spanish amilasa", () => {
      const r = matchBiomarkerName("Amilasa");
      expect(r.biomarkerKey).toBe("amylase");
      expect(r.confidence).toBe("alias");
    });

    it("matches PSA (Spanish full name)", () => {
      const r = matchBiomarkerName("Antigeno prostatico especifico");
      expect(r.biomarkerKey).toBe("psa_total");
      expect(r.confidence).toBe("alias");
    });
  });

  // Every key the matcher emits must be a real biomarker_references
  // slug, otherwise /confirm's allow-list 422s the whole upload.
  describe("emits real seed keys (no key drift)", () => {
    it("Insulina → insulin_fasting (not fasting_insulin)", () => {
      expect(matchBiomarkerName("Insulina").biomarkerKey).toBe("insulin_fasting");
      expect(matchBiomarkerName("Insulina basal").biomarkerKey).toBe(
        "insulin_fasting",
      );
    });

    it("Vitamina D variants → vitamin_d_25_oh", () => {
      expect(matchBiomarkerName("Vitamina D").biomarkerKey).toBe("vitamin_d_25_oh");
      expect(matchBiomarkerName("25-OH Vitamina D").biomarkerKey).toBe(
        "vitamin_d_25_oh",
      );
      expect(matchBiomarkerName("25-Hidroxivitamina D").biomarkerKey).toBe(
        "vitamin_d_25_oh",
      );
    });

    it("Hierro → iron_serum", () => {
      expect(matchBiomarkerName("Hierro").biomarkerKey).toBe("iron_serum");
    });

    it("T4 libre / T3 libre → thyroxine/triiodothyronine seed keys", () => {
      expect(matchBiomarkerName("T4 libre").biomarkerKey).toBe(
        "free_t4_thyroxine",
      );
      expect(matchBiomarkerName("T3 libre").biomarkerKey).toBe(
        "free_t3_triiodothyronine",
      );
    });

    it("Testosterona total / Cortisol → seed keys", () => {
      expect(matchBiomarkerName("Testosterona total").biomarkerKey).toBe(
        "testosterone_total",
      );
      expect(matchBiomarkerName("Cortisol").biomarkerKey).toBe(
        "cortisol_morning_8am",
      );
    });
  });

  describe("HOMA-IR the laboratory reports itself", () => {
    it.each(["HOMA", "HOMA-IR", "HOMA IR", "homa-ir", "Indice HOMA", "Índice HOMA", "Indice HOMA-IR", "Índice HOMA-IR"])("%s → homa_ir", (name) => {
      const r = matchBiomarkerName(name);
      expect(r.biomarkerKey).toBe("homa_ir");
      expect(["exact", "alias"]).toContain(r.confidence);
    });

    it("'homa' is short: names one letter away never fuzzy-match it", () => {
      for (const name of ["hora", "coma", "soma", "homo", "hema", "homa2"]) {
        expect(matchBiomarkerName(name).biomarkerKey, name).not.toBe("homa_ir");
      }
    });
  });

  // Fuzzy matching used to resolve short clinical abbreviations to
  // unrelated biomarkers (Levenshtein ≤ 2 on 2-3 char strings).
  describe("fuzzy false-positive guards", () => {
    it("'pH' does not match Luteinizing Hormone", () => {
      const r = matchBiomarkerName("pH");
      expect(r.biomarkerKey).toBeNull();
      expect(r.confidence).toBe("none");
    });

    it("'INR' does not fuzzy-match a biomarker", () => {
      expect(matchBiomarkerName("INR").biomarkerKey).toBeNull();
    });

    it("'ADE' resolves to rdw, not hba1c", () => {
      const r = matchBiomarkerName("ADE");
      expect(r.biomarkerKey).toBe("rdw");
    });

    it("'Vitamina B6' does not match B12 (digit guard)", () => {
      const r = matchBiomarkerName("Vitamina B6");
      expect(r.biomarkerKey).not.toBe("vitamin_b12");
    });
  });
});
