/**
 * Unit tests of the biological age v3 TypeScript port (`./biological-age-v3.ts`): unit conversions, tier choice, every
 * reason for no result, every clamp, the CRP cap flag, the validated age range, and that blood-count values are
 * ignored. Numerical parity with the Python reference is `biological-age-v3.parity.test.ts`.
 *
 * Run: `npx vitest run src/lib/biomarkers/biological-age-v3.test.ts`
 */
import { describe, it, expect } from "vitest";
import {
  BA_V3_AGE_RANGE,
  BA_V3_EVA_UNITS,
  BA_V3_MODEL_SHA256,
  BA_V3_TIER_MARKERS,
  computeBiologicalAgeV3,
  __test,
  type BiologicalAgeV3NoResult,
  type BiologicalAgeV3Outcome,
  type BiologicalAgeV3Result,
  type BiomarkerV3Input,
} from "./biological-age-v3";

const { MODEL } = __test;

// A typical 50-year-old in EVA units, inside every credit limit (the Python unit tests' TYPICAL profile,
// ml/biological-age/models/candidates/tests/test_phenoage_v3.py, converted: albumin 4.3 g/dL, CRP 0.3 mg/dL).
const TYPICAL: Record<string, number> = {
  albumin: 43,
  alp: 70,
  hs_crp: 3,
  creatinine: 0.95,
  bun: 14,
  ggt: 25,
  hba1c: 5.4,
};

// integration_notes.units of model-v3.json, written out here so the test does not read them from the module.
const FACTOR: Record<string, number> = {
  albumin: 0.1,
  alp: 1,
  hs_crp: 0.1,
  creatinine: 1,
  bun: 1,
  ggt: 1,
  hba1c: 1,
};

const BLOOD_COUNT: BiomarkerV3Input[] = [
  { code: "lymphocytes", value: 30, unit: "%" },
  { code: "mcv", value: 90, unit: "fL" },
  { code: "rdw", value: 13, unit: "%" },
  { code: "white_blood_cell_count", value: 6500, unit: "/µL" },
];

/** TYPICAL with overrides; a key set to `undefined` is left out. */
function panel(overrides: Record<string, number | undefined> = {}): BiomarkerV3Input[] {
  const values: Record<string, number | undefined> = { ...TYPICAL, ...overrides };
  return Object.entries(values)
    .filter((e): e is [string, number] => e[1] !== undefined)
    .map(([code, value]) => ({ code, value, unit: BA_V3_EVA_UNITS[code] }));
}

function result(outcome: BiologicalAgeV3Outcome): BiologicalAgeV3Result {
  if (outcome.ba === null) throw new Error(`expected a result, got ${outcome.reason} (${outcome.markers.join(", ")})`);
  return outcome;
}

function refusal(outcome: BiologicalAgeV3Outcome): BiologicalAgeV3NoResult {
  if (outcome.ba !== null) throw new Error(`expected no result, got BA ${outcome.ba}`);
  return outcome;
}

const baOf = (inputs: BiomarkerV3Input[], sex = "male", age = 50) =>
  result(computeBiologicalAgeV3(inputs, sex, age)).ba;

/**
 * Step 6 of integration_notes.formula, written independently of the module's code: BA = K[sex] + w_age[sex] * age
 * + sum_j w_j * f_j, f_j = transform(clamp(EVA value x FACTOR)). Agrees with steps 3-5 to about 1e-9 years.
 */
function linearForm(values: Record<string, number>, tier: "base" | "plus_hba1c", sex: "male" | "female", age: number) {
  const t = MODEL.tiers[tier];
  let ba = t.linear_form.constant_years[sex] + t.linear_form.age_weight_effective[sex] * age;
  for (const m of t.markers) {
    const spec = MODEL.markers[m];
    let x = values[spec.eva_key] * FACTOR[spec.eva_key];
    const lo = spec.clamp.lower?.[sex];
    const hi = spec.clamp.upper?.[sex];
    if (lo !== undefined && x < lo) x = lo;
    if (hi !== undefined && x > hi) x = hi;
    ba += t.linear_form.marker_weights[m] * (spec.transform === "log" ? Math.log(x) : x);
  }
  return ba;
}

/** Deterministic pseudo-random numbers (mulberry32). */
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

describe("the model data", () => {
  it("is the frozen model-v3.json (model_sha256 dc60ee29...), with its two releasable tiers only", () => {
    expect(BA_V3_MODEL_SHA256).toBe("dc60ee29d88621c716086434c9894779417a3189fe7c2ee5178f010eec45bb10");
    expect(Object.keys(MODEL.tiers).sort()).toEqual(["base", "plus_hba1c"]);
    expect(BA_V3_TIER_MARKERS.base).toEqual(["albumin", "alp", "hs_crp", "creatinine", "bun", "ggt"]);
    expect(BA_V3_TIER_MARKERS.plus_hba1c).toEqual(["albumin", "alp", "hs_crp", "creatinine", "bun", "ggt", "hba1c"]);
  });

  it("result carries modelSha256", () => {
    expect(result(computeBiologicalAgeV3(panel(), "female", 40)).modelSha256).toBe(BA_V3_MODEL_SHA256);
  });
});

describe("units", () => {
  it("expects the EVA units of integration_notes.units", () => {
    expect(BA_V3_EVA_UNITS).toEqual({
      albumin: "g/L",
      alp: "U/L",
      hs_crp: "mg/L",
      creatinine: "mg/dL",
      bun: "mg/dL",
      ggt: "U/L",
      hba1c: "%",
    });
  });

  it("converts albumin g/L and hs-CRP mg/L by x 0.1 and passes the other markers unchanged", () => {
    for (const m of Object.keys(MODEL.markers)) {
      expect(MODEL.markers[m].factor, m).toBe(FACTOR[MODEL.markers[m].eva_key]);
    }
    expect(MODEL.markers.albumin.model_unit).toBe("g/dL");
    expect(MODEL.markers.crp.model_unit).toBe("mg/dL");
  });

  it("albumin enters in g/dL: +1 g/L moves the result by one tenth of the per-g/dL weight", () => {
    const w = MODEL.tiers.base.linear_form.marker_weights.albumin;
    const delta = baOf(panel({ albumin: 41, hba1c: undefined })) - baOf(panel({ albumin: 40, hba1c: undefined }));
    expect(delta).toBeCloseTo(w * 0.1, 9);
  });

  it("hs-CRP enters in mg/dL: the 0.21 mg/dL floor sits at 2.1 mg/L and the 1.0 mg/dL cap at 10 mg/L", () => {
    const clampsOf = (hsCrp: number) =>
      result(computeBiologicalAgeV3(panel({ hs_crp: hsCrp }), "male", 50)).clampsApplied;
    expect(clampsOf(2.0)).toEqual([{ key: "hs_crp", side: "lower" }]);
    expect(clampsOf(2.2)).toEqual([]);
    expect(clampsOf(9)).toEqual([]);
    expect(clampsOf(11)).toEqual([{ key: "hs_crp", side: "upper" }]);
  });

  it("equals the linear form (step 6) computed from the EVA values with the written-out factors", () => {
    for (const tier of ["base", "plus_hba1c"] as const) {
      for (const sex of ["male", "female"] as const) {
        const values = tier === "base" ? { ...TYPICAL, hba1c: undefined } : TYPICAL;
        const r = result(computeBiologicalAgeV3(panel(values), sex, 57));
        expect(r.tier).toBe(tier);
        expect(Math.abs(r.ba - linearForm(TYPICAL, tier, sex, 57))).toBeLessThan(1e-9);
      }
    }
  });

  it("agrees with the linear form within 1e-9 years on 400 varied profiles, clamps included", () => {
    const next = rng(20260930);
    const normal = () => Math.sqrt(-2 * Math.log(1 - next())) * Math.cos(2 * Math.PI * next());
    let worst = 0;
    for (let i = 0; i < 400; i++) {
      const values: Record<string, number> = {};
      for (const [k, v] of Object.entries(TYPICAL)) values[k] = v * Math.exp(0.4 * normal());
      const tier = i % 2 === 0 ? "plus_hba1c" : "base";
      const sex = i % 4 < 2 ? "male" : "female";
      const age = 20 + Math.floor(next() * 65);
      const inputs = panel(tier === "base" ? { ...values, hba1c: undefined } : values);
      const r = result(computeBiologicalAgeV3(inputs, sex, age));
      expect(r.tier).toBe(tier);
      worst = Math.max(worst, Math.abs(r.ba - linearForm(values, tier, sex, age)));
    }
    expect(worst).toBeLessThan(1e-9);
  });

  it("accepts notation variants of the EVA unit (canonical-units normalizeUnit)", () => {
    const reference = computeBiologicalAgeV3(panel(), "male", 50);
    const variants: Record<string, string> = {
      albumin: " g/l ",
      alp: "IU/L",
      hs_crp: "MG/L",
      creatinine: "mg/dl",
      bun: "MG/DL",
      ggt: "UI/L",
      hba1c: " % ",
    };
    const inputs = panel().map((i) => ({ ...i, unit: variants[i.code] }));
    expect(computeBiologicalAgeV3(inputs, "male", 50)).toEqual(reference);
  });

  it("refuses a value in another unit (unit_mismatch) instead of converting it", () => {
    const cases: [string, number, string][] = [
      ["albumin", 4.3, "g/dL"],
      ["hs_crp", 0.3, "mg/dL"],
      ["creatinine", 84, "µmol/L"],
      ["bun", 5, "mmol/L"],
      ["alp", 1.2, "µkat/L"],
      ["ggt", 0.4, "µkat/L"],
      ["hba1c", 36, "mmol/mol"],
    ];
    for (const [code, value, unit] of cases) {
      const inputs = panel().map((i) => (i.code === code ? { code, value, unit } : i));
      const r = refusal(computeBiologicalAgeV3(inputs, "male", 50));
      expect(r.reason, code).toBe("unit_mismatch");
      expect(r.markers).toEqual([code]);
    }
  });

  it("refuses a missing or empty unit (unit_mismatch)", () => {
    for (const unit of ["", "   ", undefined, null]) {
      const inputs = panel().map((i) => (i.code === "ggt" ? { ...i, unit: unit as unknown as string } : i));
      const r = refusal(computeBiologicalAgeV3(inputs, "female", 50));
      expect(r.reason).toBe("unit_mismatch");
      expect(r.markers).toEqual(["ggt"]);
    }
  });

  it("refuses HbA1c in a wrong unit rather than dropping to the base tier", () => {
    const inputs = panel({ hba1c: undefined }).concat({ code: "hba1c", value: 36, unit: "mmol/mol" });
    const r = refusal(computeBiologicalAgeV3(inputs, "male", 50));
    expect(r.reason).toBe("unit_mismatch");
    expect(r.markers).toEqual(["hba1c"]);
  });
});

describe("tier choice", () => {
  it("uses plus_hba1c when all seven markers are present and valid", () => {
    const r = result(computeBiologicalAgeV3(panel(), "male", 50));
    expect(r.tier).toBe("plus_hba1c");
    expect(r.markersUsed).toEqual([...BA_V3_TIER_MARKERS.plus_hba1c]);
  });

  it("uses base without HbA1c", () => {
    const r = result(computeBiologicalAgeV3(panel({ hba1c: undefined }), "male", 50));
    expect(r.tier).toBe("base");
    expect(r.markersUsed).toEqual([...BA_V3_TIER_MARKERS.base]);
  });

  it("uses base when HbA1c is present but invalid, with the same result as without it", () => {
    const withoutHbA1c = computeBiologicalAgeV3(panel({ hba1c: undefined }), "female", 63);
    for (const bad of [NaN, Infinity, -Infinity, 0, -1]) {
      expect(computeBiologicalAgeV3(panel({ hba1c: bad }), "female", 63), String(bad)).toEqual(withoutHbA1c);
    }
  });

  it("HbA1c changes the result (it is used in plus_hba1c)", () => {
    expect(baOf(panel({ hba1c: 6.5 }))).toBeGreaterThan(baOf(panel({ hba1c: 5.2 })));
  });

  it("does not depend on the order of the inputs", () => {
    const inputs = panel().concat(BLOOD_COUNT);
    const reversed = [...inputs].reverse();
    expect(computeBiologicalAgeV3(reversed, "female", 45)).toEqual(computeBiologicalAgeV3(inputs, "female", 45));
  });
});

describe("no result", () => {
  it("sex_unknown for anything but male or female (matched after toLowerCase, as process-results does)", () => {
    for (const sex of ["other", "", "M", "F", "unknown", " male", null, undefined, 1 as unknown as string]) {
      const r = refusal(computeBiologicalAgeV3(panel(), sex, 50));
      expect(r.reason, String(sex)).toBe("sex_unknown");
      expect(r.markers).toEqual([]);
    }
    expect(computeBiologicalAgeV3(panel(), "Male", 50)).toEqual(computeBiologicalAgeV3(panel(), "male", 50));
    expect(computeBiologicalAgeV3(panel(), "FEMALE", 50)).toEqual(computeBiologicalAgeV3(panel(), "female", 50));
    expect(baOf(panel(), "male")).not.toBeCloseTo(baOf(panel(), "female"), 3);
  });

  it("age_outside_validated_range below 20 and above 84, and for a non-finite age", () => {
    for (const age of [19, 19.99, 84.01, 84.5, 85, 0, -5, 120, NaN, Infinity, -Infinity]) {
      const r = refusal(computeBiologicalAgeV3(panel(), "male", age));
      expect(r.reason, String(age)).toBe("age_outside_validated_range");
    }
  });

  it("missing_markers names every absent Base marker", () => {
    for (const key of BA_V3_TIER_MARKERS.base) {
      const r = refusal(computeBiologicalAgeV3(panel({ [key]: undefined }), "male", 50));
      expect(r.reason, key).toBe("missing_markers");
      expect(r.markers).toEqual([key]);
    }
    const none = refusal(computeBiologicalAgeV3([], "female", 50));
    expect(none.reason).toBe("missing_markers");
    expect(none.markers).toEqual([...BA_V3_TIER_MARKERS.base]);
    const onlyBloodCount = refusal(computeBiologicalAgeV3(BLOOD_COUNT, "female", 50));
    expect(onlyBloodCount.reason).toBe("missing_markers");
  });

  it("missing_markers when BUN is given as urea: no conversion outside integration_notes", () => {
    const inputs = panel({ bun: undefined }).concat({ code: "urea", value: 30, unit: "mg/dL" });
    const r = refusal(computeBiologicalAgeV3(inputs, "male", 50));
    expect(r.reason).toBe("missing_markers");
    expect(r.markers).toEqual(["bun"]);
  });

  it("invalid_value for a non-finite Base marker", () => {
    for (const key of BA_V3_TIER_MARKERS.base) {
      for (const bad of [NaN, Infinity, -Infinity]) {
        const r = refusal(computeBiologicalAgeV3(panel({ [key]: bad }), "male", 50));
        expect(r.reason, `${key} ${bad}`).toBe("invalid_value");
        expect(r.markers).toEqual([key]);
      }
    }
  });

  it("invalid_value for a non-positive log marker, even where its floor would clamp it", () => {
    for (const key of ["alp", "hs_crp", "creatinine", "bun", "ggt"]) {
      expect(MODEL.markers[key === "hs_crp" ? "crp" : key].transform).toBe("log");
      for (const bad of [0, -0.5]) {
        const r = refusal(computeBiologicalAgeV3(panel({ [key]: bad }), "female", 50));
        expect(r.reason, `${key} ${bad}`).toBe("invalid_value");
        expect(r.markers).toEqual([key]);
      }
    }
  });

  it("duplicate_marker when a model marker is given twice with different values; identical repeats are fine", () => {
    const twice = panel().concat({ code: "albumin", value: 44, unit: "g/L" });
    const r = refusal(computeBiologicalAgeV3(twice, "male", 50));
    expect(r.reason).toBe("duplicate_marker");
    expect(r.markers).toEqual(["albumin"]);
    const repeated = panel().concat({ code: "albumin", value: 43, unit: "g/l" });
    expect(computeBiologicalAgeV3(repeated, "male", 50)).toEqual(computeBiologicalAgeV3(panel(), "male", 50));
  });

  it("checks in a fixed order: sex, age, units, duplicates, then markers", () => {
    const everythingWrong = [
      { code: "albumin", value: 4.3, unit: "g/dL" },
      { code: "ggt", value: 20, unit: "U/L" },
      { code: "ggt", value: 21, unit: "U/L" },
    ];
    expect(refusal(computeBiologicalAgeV3(everythingWrong, "x", 10)).reason).toBe("sex_unknown");
    expect(refusal(computeBiologicalAgeV3(everythingWrong, "male", 10)).reason).toBe("age_outside_validated_range");
    expect(refusal(computeBiologicalAgeV3(everythingWrong, "male", 50)).reason).toBe("unit_mismatch");
    expect(refusal(computeBiologicalAgeV3(everythingWrong.slice(1), "male", 50)).reason).toBe("duplicate_marker");
    expect(refusal(computeBiologicalAgeV3(everythingWrong.slice(2), "male", 50)).reason).toBe("missing_markers");
  });
});

describe("clamps (credit limits)", () => {
  const cases: {
    name: string;
    key: string;
    beyond: number;
    bound: number;
    inside: number;
    side: "lower" | "upper";
    sex: "male" | "female";
  }[] = [
    { name: "albumin above 50 g/L", key: "albumin", beyond: 55, bound: 50, inside: 49, side: "upper", sex: "male" },
    { name: "ALP below 40 U/L", key: "alp", beyond: 30, bound: 40, inside: 41, side: "lower", sex: "female" },
    { name: "BUN below 10 mg/dL", key: "bun", beyond: 7, bound: 10, inside: 11, side: "lower", sex: "male" },
    { name: "creatinine below 0.8 mg/dL in men", key: "creatinine", beyond: 0.6, bound: 0.8, inside: 0.85, side: "lower", sex: "male" },
    { name: "creatinine below 0.6 mg/dL in women", key: "creatinine", beyond: 0.5, bound: 0.6, inside: 0.7, side: "lower", sex: "female" },
    { name: "hs-CRP below the 2.1 mg/L floor", key: "hs_crp", beyond: 0.5, bound: 2.1, inside: 2.5, side: "lower", sex: "female" },
    { name: "hs-CRP above the 10 mg/L cap", key: "hs_crp", beyond: 25, bound: 10, inside: 9.5, side: "upper", sex: "male" },
    { name: "HbA1c below 4.5 %", key: "hba1c", beyond: 4.0, bound: 4.5, inside: 4.6, side: "lower", sex: "male" },
  ];

  for (const c of cases) {
    it(`${c.name}: counts as the bound, and is reported`, () => {
      const at = (v: number) => result(computeBiologicalAgeV3(panel({ [c.key]: v }), c.sex, 50));
      const beyond = at(c.beyond);
      expect(beyond.ba).toBeCloseTo(at(c.bound).ba, 12);
      expect(beyond.clampsApplied).toEqual([{ key: c.key, side: c.side }]);
      expect(at(c.bound).clampsApplied).toEqual([]); // strict comparisons (features.apply_clamps)
      expect(at(c.inside).clampsApplied).toEqual([]);
      expect(at(c.inside).ba).not.toBeCloseTo(at(c.bound).ba, 6);
    });
  }

  it("the creatinine floor depends on sex: 0.7 mg/dL is clamped in a man, not in a woman", () => {
    const man = result(computeBiologicalAgeV3(panel({ creatinine: 0.7 }), "male", 50));
    const woman = result(computeBiologicalAgeV3(panel({ creatinine: 0.7 }), "female", 50));
    expect(man.clampsApplied).toEqual([{ key: "creatinine", side: "lower" }]);
    expect(woman.clampsApplied).toEqual([]);
  });

  it("GGT has no credit limit", () => {
    expect(MODEL.markers.ggt.clamp).toEqual({});
    expect(baOf(panel({ ggt: 5 }))).toBeLessThan(baOf(panel({ ggt: 8 })));
  });

  it("lists every clamp applied, in the model's marker order", () => {
    const r = result(
      computeBiologicalAgeV3(
        panel({ albumin: 55, alp: 30, hs_crp: 20, creatinine: 0.5, bun: 5, hba1c: 4.0 }),
        "male",
        50,
      ),
    );
    expect(r.clampsApplied).toEqual([
      { key: "albumin", side: "upper" },
      { key: "alp", side: "lower" },
      { key: "hs_crp", side: "upper" },
      { key: "creatinine", side: "lower" },
      { key: "bun", side: "lower" },
      { key: "hba1c", side: "lower" },
    ]);
  });

  it("the interval's measurement noise passes through the clamps: a value far beyond a floor adds almost none", () => {
    const crp = MODEL.markers.crp;
    const deep = __test.measurementVariance(0.001, crp, "male"); // 0.01 mg/L, 210 times below the 2.1 mg/L floor
    const free = __test.measurementVariance(0.5, crp, "male");
    expect(deep).toBeLessThan(1e-6 * free);
  });

  it("the measurement noise of an unclamped log marker is sigma^2 = (CVi^2 + 3^2) / 100^2", () => {
    const ggt = MODEL.markers.ggt; // no clamp
    const sigma2 = (ggt.cvi_pct ** 2 + 3 ** 2) / 100 ** 2;
    expect(__test.measurementVariance(25, ggt, "female")).toBeCloseTo(sigma2, 12);
  });

  it("the measurement noise of a linear marker far from its bound is the lognormal variance", () => {
    const alb = MODEL.markers.albumin; // linear; cap 5.0 g/dL is 13 SD above 3.0 g/dL
    const s2 = (alb.cvi_pct ** 2 + 3 ** 2) / 100 ** 2;
    const expected = 3.0 ** 2 * (Math.exp(2 * s2) - Math.exp(s2));
    expect(__test.measurementVariance(3.0, alb, "male") / expected).toBeCloseTo(1, 9);
  });
});

describe("CRP cap flag", () => {
  it("is set only when hs-CRP is above 10 mg/L", () => {
    const capped = (v: number, tier: "base" | "plus_hba1c") =>
      result(computeBiologicalAgeV3(panel(tier === "base" ? { hs_crp: v, hba1c: undefined } : { hs_crp: v }), "female", 50))
        .crpCapped;
    for (const tier of ["base", "plus_hba1c"] as const) {
      expect(capped(0.3, tier)).toBe(false);
      expect(capped(9.9, tier)).toBe(false);
      expect(capped(10, tier)).toBe(false);
      expect(capped(10.01, tier)).toBe(true);
      expect(capped(150, tier)).toBe(true);
    }
  });

  it("a capped result equals the result at 10 mg/L", () => {
    expect(baOf(panel({ hs_crp: 150 }), "female")).toBeCloseTo(baOf(panel({ hs_crp: 10 }), "female"), 12);
  });
});

describe("validated age range", () => {
  it("is 20 to 84 years", () => {
    expect(BA_V3_AGE_RANGE).toEqual({ min: 20, max: 84 });
  });

  it("includes both ends, 20 and 84", () => {
    for (const age of [20, 84]) {
      for (const sex of ["male", "female"]) {
        expect(computeBiologicalAgeV3(panel(), sex, age).ba, `${sex} ${age}`).not.toBeNull();
        expect(computeBiologicalAgeV3(panel({ hba1c: undefined }), sex, age).ba, `${sex} ${age}`).not.toBeNull();
      }
    }
  });

  it("excludes 19 and 85 (no extrapolation)", () => {
    for (const age of [19, 85]) {
      expect(refusal(computeBiologicalAgeV3(panel(), "female", age)).reason).toBe("age_outside_validated_range");
    }
  });
});

describe("blood-count markers (not part of version 3)", () => {
  it("do not change the result in either tier", () => {
    for (const values of [{}, { hba1c: undefined }]) {
      for (const sex of ["male", "female"]) {
        const without = computeBiologicalAgeV3(panel(values), sex, 52);
        const withBloodCount = computeBiologicalAgeV3(panel(values).concat(BLOOD_COUNT), sex, 52);
        expect(withBloodCount).toEqual(without);
        expect(result(withBloodCount).markersUsed).not.toContain("rdw");
      }
    }
  });

  it("are ignored even with a wrong unit, an invalid value, or given twice", () => {
    const odd: BiomarkerV3Input[] = [
      { code: "white_blood_cell_count", value: 6.5, unit: "x10^3/µL" },
      { code: "rdw", value: NaN, unit: "%" },
      { code: "mcv", value: 90, unit: "fL" },
      { code: "mcv", value: 95, unit: "fL" },
      { code: "lymphocytes", value: -3, unit: "" },
    ];
    expect(computeBiologicalAgeV3(panel().concat(odd), "male", 50)).toEqual(computeBiologicalAgeV3(panel(), "male", 50));
  });
});

describe("output", () => {
  it("the interval is symmetric around the result and contains it", () => {
    for (const values of [{}, { hba1c: undefined }, { hs_crp: 40, bun: 5 }]) {
      const r = result(computeBiologicalAgeV3(panel(values), "male", 70));
      const [lo, hi] = r.interval;
      expect(lo).toBeLessThan(r.ba);
      expect(hi).toBeGreaterThan(r.ba);
      expect(hi - r.ba).toBeCloseTo(r.ba - lo, 10);
    }
  });

  it("is deterministic and leaves its inputs unchanged", () => {
    const inputs = Object.freeze(panel().concat(BLOOD_COUNT).map((i) => Object.freeze({ ...i })));
    const snapshot = JSON.stringify(inputs);
    const first = computeBiologicalAgeV3(inputs, "female", 38);
    const second = computeBiologicalAgeV3(inputs, "female", 38);
    expect(second).toEqual(first);
    expect(JSON.stringify(inputs)).toBe(snapshot);
  });

  it("ignores entries that are not objects with a string code", () => {
    const junk = [null, undefined, 42, "albumin", { value: 3 }] as unknown as BiomarkerV3Input[];
    expect(computeBiologicalAgeV3(panel().concat(junk), "male", 50)).toEqual(computeBiologicalAgeV3(panel(), "male", 50));
  });
});
