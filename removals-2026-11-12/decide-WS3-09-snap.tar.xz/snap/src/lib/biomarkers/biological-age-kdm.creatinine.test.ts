/**
 * Of the kidney filtration markers, creatinine and urea (BUN) enter the biological age; creatinine is adjusted for a declared creatine
 * dose (CEO decision, 30 October 2026; docs/biomarker-evidence/longevity/CALIBRATION-AND-CREATINE.md):
 *   - cystatin C and a laboratory's eGFR never enter either version, and nothing stands in for creatinine;
 *   - creatinine outside 0.2 to 15 mg/dL is refused, so no biological age is computed;
 *   - creatinine is divided by the declared dose's divisor, whatever else the lab contains;
 *   - each lab uses the context it is read under (patient-context/lab-context.ts): in processing
 *     (loadLabState, patient-context/physiological-state.ts) and in the dashboard's rolling average
 *     (adjustCreatinineByLab).
 * Scripted database (fake-supabase) for the reads, no network.
 */
import { describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import {
  applyLifestyleAdjustments,
  computeComprehensiveBA,
  computeReferenceBA,
  KDM_REFERENCE_BA_METHOD,
  KIDNEY_MARKERS_NOT_USED,
  passesKdmGate,
  resolveKdmParams,
} from "./biological-age-kdm";
import { __test as kdmAdapter } from "./kdm-adapter";
import { explainBiologicalAge } from "./biological-age-explain";
import library from "./data/marker_library_v2_2.json";
import { adjustCreatinineByLab, computeRollingAverageBA, recomputeAndCacheUserBA } from "./rolling-average-ba";
import { processLabResults, recomputeLabMetrics } from "./process-results";
import { getCanonicalUnit } from "./canonical-units";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";
import { contextVersionForLab } from "@/lib/patient-context/lab-context";
import { LAB_STATE_LAB_COLUMNS, loadLabState } from "@/lib/patient-context/physiological-state";
import { labCreatinineReadable } from "./creatinine-plausibility";

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});

// The Base Panel tests of the typical man of 45 (docs/biomarker-evidence/longevity/base-panel/panels.json).
const BASE: Record<string, number> = {
  albumin: 44, creatinine: 1.0, bun: 15, uric_acid: 6, alp: 72, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47,
  triglycerides: 140, hs_crp: 1.8, apolipoprotein_b_apob: 105, alt: 30, fructosamine: 200,
};
const inputs = (values: Record<string, number>) => Object.entries(values).map(([code, value]) => ({ code, value }));
const NONE = { supplements: null };
const CREATINE_5G = { supplements: [{ key: "creatine", dose: "5 g" }] };

describe("cystatin C and a laboratory eGFR never enter", () => {
  it("cystatin C and a laboratory eGFR change neither version", () => {
    const extras: Record<string, number>[] = [
      { cystatin_c: 0.85 },
      { cystatin_c: 1.5 },
      { egfr_creatinine_based: 70 },
      { cystatin_c: 1.2, egfr_creatinine_based: 48 },
    ];
    for (const extra of extras) {
      const label = JSON.stringify(extra);
      const ref = computeReferenceBA(inputs({ ...BASE, ...extra }), "male", 45, NONE)!;
      const comp = computeComprehensiveBA(inputs({ ...BASE, ...extra }), "male", 45, NONE)!;
      expect(ref.BA, label).toBe(computeReferenceBA(inputs(BASE), "male", 45, NONE)!.BA);
      expect(comp.BA, label).toBe(computeComprehensiveBA(inputs(BASE), "male", 45, NONE)!.BA);
      for (const marker of KIDNEY_MARKERS_NOT_USED) {
        expect(ref.used_markers, label).not.toContain(marker);
        expect(comp.used_markers, label).not.toContain(marker);
      }
      expect(ref.used_markers, label).toContain("Creatinina");
      expect(comp.used_markers, label).toContain("Creatinina");
    }
  });

  it("the typical man of 45 with cystatin C 0.85 mg/L: the lab page reads 51.3 again, not 52.3", () => {
    const ref = computeReferenceBA(inputs({ ...BASE, cystatin_c: 0.85 }), "male", 45, NONE)!;
    expect(ref.BA).toBeCloseTo(51.29, 2);
    expect(ref.n_markers_used).toBe(10);
  });

  it("no biological age without creatinine: cystatin C does not stand in for it", () => {
    const { creatinine: _omit, ...withoutCreatinine } = BASE;
    void _omit;
    expect(computeReferenceBA(inputs({ ...withoutCreatinine, cystatin_c: 0.85 }), "male", 45, NONE)).toBeNull();
    expect(computeComprehensiveBA(inputs({ ...withoutCreatinine, cystatin_c: 0.85 }), "male", 45, NONE)).toBeNull();
    expect(passesKdmGate({ "Albúmina": 4.4, "Cistatina C": 0.85 })).toBe(false);
  });

  it("the gate: eight base markers without creatinine fail, cystatin C or not (the old gate let it stand in)", () => {
    const eightWithoutCreatinine = {
      "Albúmina": 4.4, "BUN (Nitrógeno Ureico en Sangre)": 15, "Ácido Úrico": 6, "ALP (Fosfatasa Alcalina)": 72,
      "GGT (Gamma-glutamil Transferasa)": 32, "Colesterol Total": 205, "Colesterol HDL": 47, "Triglicéridos": 140,
    };
    expect(passesKdmGate({ ...eightWithoutCreatinine, "Cistatina C": 0.85 })).toBe(false);
    expect(passesKdmGate(applyLifestyleAdjustments({ ...eightWithoutCreatinine, "Cistatina C": 0.85 }, null))).toBe(false);
    expect(passesKdmGate({ ...eightWithoutCreatinine, "Creatinina": 1.0 })).toBe(true);
  });

  it("with two creatinine rows, an implausible one, or two that disagree, give no figure, whatever their order", () => {
    const rest = inputs({ ...BASE, creatinine: undefined as unknown as number }).filter((i) => i.code !== "creatinine");
    const withCreatinine = (...values: number[]) => [...rest, ...values.map((value) => ({ code: "creatinine", value }))];
    for (const rows of [[1.0, 88.4], [88.4, 1.0], [1.0, 12], [12, 1.0]]) {
      expect(computeReferenceBA(withCreatinine(...rows), "male", 45, NONE), String(rows)).toBeNull();
      expect(computeComprehensiveBA(withCreatinine(...rows), "male", 45, NONE), String(rows)).toBeNull();
      expect(explainBiologicalAge(withCreatinine(...rows), "male", 45, {}), String(rows)).toBeNull();
    }
    // The same result listed twice is read once; so is a second row under the upper-case code.
    const once = computeReferenceBA(withCreatinine(1.0), "male", 45, NONE)!.BA;
    expect(computeReferenceBA(withCreatinine(1.0, 1.0), "male", 45, NONE)!.BA).toBe(once);
    expect(computeReferenceBA([...withCreatinine(1.0), { code: "CREATININE", value: 1.0 }], "male", 45, NONE)!.BA).toBe(once);
    expect(computeReferenceBA([...withCreatinine(1.0), { code: "CREATININE", value: 88.4 }], "male", 45, NONE)).toBeNull();
    // The explanation prepares the values as the figure does.
    expect(explainBiologicalAge(withCreatinine(1.0, 1.0), "male", 45, {})!.ba).toBe(once);
  });

  it("one creatinine printed in mg/dL and in µmol/L (stored as × 0.0113) is one result, read in any order", () => {
    const rest = inputs({ ...BASE, creatinine: undefined as unknown as number }).filter((i) => i.code !== "creatinine");
    const withCreatinine = (...values: number[]) => [...rest, ...values.map((value) => ({ code: "creatinine", value }))];
    // Two decimals, one decimal and whole µmol/L, as reports print them.
    for (const [mgDl, umol] of [[1.0, 88], [0.65, 57], [0.94, 84], [1.39, 122], [14.86, 1313], [0.9, 84], [1.4, 122], [0.7, 66]]) {
      const pair = [mgDl, umol * 0.0113];
      expect(labCreatinineReadable(pair), String(pair)).toBe(true);
      expect(computeReferenceBA(withCreatinine(...pair), "male", 45, NONE), String(pair)).not.toBeNull();
    }
    for (const order of [[1.0, 1.004, 1.008], [1.004, 1.0, 1.008], [1.008, 1.004, 1.0]]) {
      expect(labCreatinineReadable(order), String(order)).toBe(true);
    }
    // Different results stay unread, in any order: [1.05, 1.0, 1.1] is within the bound of its first value both ways,
    // but 1.0 and 1.1 are two results.
    for (const values of [[1.05, 1.0, 1.1], [1.0, 1.05, 1.1], [1.1, 1.05, 1.0], [1.0, 1.07], [0.9, 1.4], [1.0, 88.4]]) {
      expect(labCreatinineReadable(values), String(values)).toBe(false);
      expect(computeReferenceBA(withCreatinine(...values), "male", 45, NONE), String(values)).toBeNull();
    }
    expect(labCreatinineReadable([])).toBe(true);
  });

  it("the explanation moves a creatinine listed twice as one value", () => {
    const rest = inputs({ ...BASE, creatinine: undefined as unknown as number }).filter((i) => i.code !== "creatinine");
    const bands = { creatinine: { optimal_low: 0.7, optimal_high: 1.1 } };
    const one = explainBiologicalAge([...rest, { code: "creatinine", value: 1.3 }], "male", 45, bands)!;
    const twice = explainBiologicalAge([...rest, { code: "creatinine", value: 1.3 }, { code: "creatinine", value: 1.3 }], "male", 45, bands)!;
    const move = one.potential.find((m) => m.code === "creatinine");
    expect(move?.delta).toBeLessThan(0);
    expect(twice.ba).toBe(one.ba);
    expect(twice.check.ok).toBe(true);
    expect(twice.potential.map((m) => m.delta)).toEqual(one.potential.map((m) => m.delta));
    expect(twice.potentialBA).toBe(one.potentialBA);
    // Two prints of one result: the explanation reads the last, as the figure does, and its shares add up.
    const prints = explainBiologicalAge([...rest, { code: "creatinine", value: 1.3 }, { code: "creatinine", value: 1.305 }], "male", 45, bands)!;
    expect(prints.check.ok).toBe(true);
    expect(prints.contributions.find((c) => c.code === "creatinine")?.value).toBe(1.305);
  });

  it("creatinine outside 0.2 to 15 mg/dL gives no biological age: 88.4 is µmol/L stored as mg/dL", () => {
    for (const creatinine of [88.4, 15.01, 0.19]) {
      const label = String(creatinine);
      expect(computeReferenceBA(inputs({ ...BASE, creatinine, cystatin_c: 0.85 }), "male", 45, NONE), label).toBeNull();
      expect(computeComprehensiveBA(inputs({ ...BASE, creatinine }), "male", 45, NONE), label).toBeNull();
      expect(applyLifestyleAdjustments({ "Creatinina": creatinine }, CREATINE_5G), label).toEqual({});
    }
    // Both ends are plausible; the range applies to the measured value, before the creatine divisor.
    expect(computeReferenceBA(inputs({ ...BASE, creatinine: 0.2 }), "male", 45, CREATINE_5G)).not.toBeNull();
    expect(computeReferenceBA(inputs({ ...BASE, creatinine: 15 }), "male", 45, NONE)).not.toBeNull();
  });
});

describe("the creatine adjustment", () => {
  it("applies with cystatin C present too (the old rule dropped creatinine and the adjustment)", () => {
    const adjusted = applyLifestyleAdjustments({ "Creatinina": 1.13, "Cistatina C": 0.85, "TFGe (basada en Creatinina)": 80 }, CREATINE_5G);
    expect(adjusted).toEqual({ "Creatinina": expect.closeTo(1.0, 10) });
  });

  it("a declared 5 g/day reads like the same person with 13% less creatinine, in both versions", () => {
    const user = inputs({ ...BASE, creatinine: 1.13 });
    expect(computeReferenceBA(user, "male", 45, CREATINE_5G)!.BA).toBeCloseTo(
      computeReferenceBA(inputs({ ...BASE, creatinine: 1.0 }), "male", 45, NONE)!.BA,
      10,
    );
    expect(computeComprehensiveBA(user, "male", 45, CREATINE_5G)!.BA).toBeCloseTo(
      computeComprehensiveBA(inputs({ ...BASE, creatinine: 1.0 }), "male", 45, NONE)!.BA,
      10,
    );
  });

  it("20 g/day removes no more than 5 g/day; no dose removes nothing", () => {
    const at = (dose: string | null) => computeReferenceBA(inputs(BASE), "male", 45, { supplements: [{ key: "creatine", dose }] })!.BA;
    expect(at("20 g")).toBeCloseTo(at("5 g"), 10);
    expect(at(null)).toBe(computeReferenceBA(inputs(BASE), "male", 45, NONE)!.BA);
    expect(at("1 g")).toBeGreaterThan(at("3 g"));
  });

  it("the methodology pages' count: the dashboard figure can use up to 46 of the 81 trained markers", () => {
    const withParams = (keys: string[], sex: "male" | "female") =>
      Object.keys(resolveKdmParams(Object.fromEntries(keys.map((k) => [k, 1])), sex, false).params).length;
    const trained = Object.entries(library.markers).filter(([, m]) => m.kdm_contribution === "trained").map(([k]) => k);
    const mapped = [...new Set(Object.values(kdmAdapter.CODE_TO_KDM).map((m) => m.kdm))];
    expect(trained).toHaveLength(81);
    // resolveKdmParams leaves out the kidney markers not used: 79 of the 81 have parameters for men.
    expect(withParams(trained, "male")).toBe(81 - KIDNEY_MARKERS_NOT_USED.length);
    for (const sex of ["male", "female"] as const) expect(withParams(mapped, sex), sex).toBe(46);
  });

  it("the new tag marks figures computed under these rules", () => {
    expect(KDM_REFERENCE_BA_METHOD).toBe("KDM_v2.2_ReferenceBA_r2");
    expect(KDM_REFERENCE_BA_METHOD.startsWith("KDM_v2.2")).toBe(true); // the dashboard's isKdm check
  });
});

describe("each lab uses the context it is read under", () => {
  const VERSIONS = [
    { id: "ctx-1", version_number: 1, created_at: "2025-11-20T09:00:00Z", supplements: [] },
    { id: "ctx-2", version_number: 2, created_at: "2026-05-10T09:00:00Z", supplements: [{ key: "creatine", dose: "5 g" }] },
    { id: "ctx-3", version_number: 3, created_at: "2026-09-01T09:00:00Z", supplements: [{ key: "creatine", dose: "2,5 g" }] },
  ];

  it("the recorded version, else the latest created on or before the lab, else none", () => {
    const at = (lab: { patient_context_version_id?: string | null; created_at?: string | null }) =>
      contextVersionForLab(lab, VERSIONS)?.id ?? null;
    expect(at({ patient_context_version_id: "ctx-1", created_at: "2026-10-01T00:00:00Z" })).toBe("ctx-1");
    expect(at({ patient_context_version_id: null, created_at: "2026-06-01T00:00:00Z" })).toBe("ctx-2");
    expect(at({ patient_context_version_id: null, created_at: "2026-05-10T09:00:00Z" })).toBe("ctx-2"); // on the day
    expect(at({ patient_context_version_id: null, created_at: "2025-10-01T00:00:00Z" })).toBeNull(); // before any
    expect(at({ patient_context_version_id: "gone", created_at: "2026-01-15T00:00:00Z" })).toBe("ctx-1");
    expect(at({ patient_context_version_id: null, created_at: null })).toBe("ctx-3"); // no creation time: the latest
  });

  it("rolling average: January before creatine, May on 5 g/day, a lab with no recorded context, a lab before any", () => {
    const labs = [
      { id: "lab-jan", collection_date: "2026-01-10", created_at: "2026-01-12T10:00:00Z", patient_context_version_id: "ctx-1" },
      { id: "lab-may", collection_date: "2026-05-10", created_at: "2026-05-12T10:00:00Z", patient_context_version_id: "ctx-2" },
      { id: "lab-admin", collection_date: "2026-09-10", created_at: "2026-09-12T10:00:00Z", patient_context_version_id: null },
      { id: "lab-old", collection_date: "2025-10-01", created_at: "2025-10-03T10:00:00Z", patient_context_version_id: null },
    ];
    const rows = [
      { lab_result_id: "lab-jan", biomarker_key: "creatinine", value: 1.13 },
      { lab_result_id: "lab-may", biomarker_key: "creatinine", value: 1.13 },
      { lab_result_id: "lab-admin", biomarker_key: "CREATININE", value: 1.13 },
      { lab_result_id: "lab-old", biomarker_key: "creatinine", value: 1.13 },
      { lab_result_id: "lab-may", biomarker_key: "albumin", value: 44 },
      { lab_result_id: "lab-unknown", biomarker_key: "creatinine", value: 1.13 },
    ];
    const out = adjustCreatinineByLab(rows, labs, VERSIONS);
    expect(out[0].value).toBe(1.13); // January: no creatine then
    expect(out[1].value).toBeCloseTo(1.0, 10); // May: 5 g/day
    expect(out[2].value).toBeCloseTo(1.13 / (1 + (0.13 * 2.5) / 3), 10); // no recorded context: ctx-3, in force then
    expect(out[3].value).toBe(1.13); // entered before any context: nothing to adjust for
    expect(out[4]).toEqual(rows[4]); // other markers untouched
    expect(out[5]).toEqual(rows[5]); // a row of no listed lab
  });

  type Script = {
    lab?: { patient_context_version_id: string | null; created_at: string | null } | null;
    snapshot?: unknown;
    inForce?: unknown;
    failOn?: "lab_results" | "recorded" | "in_force";
  };
  function database(script: Script) {
    const respond = (c: FakeCall): FakeResponse => {
      const recorded = c.table === "patient_context_versions" && argsOf(c, "eq", "id");
      const which = c.table === "lab_results" ? "lab_results" : recorded ? "recorded" : "in_force";
      if (script.failOn === which) return { error: { message: "connection reset" } };
      if (c.table === "lab_results") return { data: script.lab ?? null };
      if (recorded) return { data: script.snapshot ?? null };
      if (c.table === "patient_context_versions") return { data: script.inForce ?? null };
      return { data: null };
    };
    return fakeSupabase(respond, { project: true });
  }
  const own = { supplements: [{ key: "creatine", dose: "5 g" }] };
  const inForce = { supplements: [{ key: "creatine", dose: "10 g" }] };

  const supplementsOf = async (client: unknown) => (await loadLabState(client as never, "u1", "lab-1")).supplements;

  it("processing reads the lab by id and owner, then the version recorded with it", async () => {
    const { client, calls } = database({ lab: { patient_context_version_id: "ctx-7", created_at: "2026-05-12T10:00:00Z" }, snapshot: own, inForce });
    expect(await supplementsOf(client)).toEqual(own.supplements);
    const [lab, version] = calls;
    expect(lab.table).toBe("lab_results");
    expect(argsOf(lab, "select")).toEqual([LAB_STATE_LAB_COLUMNS]);
    expect(argsOf(lab, "eq", "id")).toEqual(["id", "lab-1"]);
    expect(argsOf(lab, "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(argsOf(version, "eq", "id")).toEqual(["id", "ctx-7"]);
    expect(argsOf(version, "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(calls).toHaveLength(2);
  });

  it("processing without a recorded version, or with one that is gone: the latest created on or before the lab", async () => {
    for (const versionId of [null, "gone"]) {
      const { client, calls } = database({ lab: { patient_context_version_id: versionId, created_at: "2026-05-12T10:00:00Z" }, inForce });
      expect(await supplementsOf(client), String(versionId)).toEqual(inForce.supplements);
      const read = calls[calls.length - 1];
      expect(argsOf(read, "eq", "user_id")).toEqual(["user_id", "u1"]);
      expect(argsOf(read, "lte", "created_at")).toEqual(["created_at", "2026-05-12T10:00:00Z"]);
      expect(argsOf(read, "order")).toEqual(["version_number", { ascending: false }]);
    }
    expect(await supplementsOf(database({ lab: null }).client)).toBeNull();
    const none = database({ lab: { patient_context_version_id: null, created_at: "2025-10-03T10:00:00Z" } });
    expect(await supplementsOf(none.client)).toBeNull();
  });

  it.each(["lab_results", "recorded", "in_force"] as const)(
    "a read error (%s) throws: no figure is stored from another context",
    async (failOn) => {
      const { client } = database({ lab: { patient_context_version_id: "ctx-7", created_at: "2026-05-12T10:00:00Z" }, snapshot: failOn === "in_force" ? null : own, inForce, failOn });
      await expect(loadLabState(client as never, "u1", "lab-1")).rejects.toThrow(/connection reset/);
    },
  );
});

describe("wiring: processing and the dashboard average apply each lab's own context", () => {
  const AGE = 45;
  const DOB = `${new Date().getFullYear() - AGE}-01-01`;
  const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000).toISOString().slice(0, 10);
  const ageAt = (dob: string, date: string) => {
    const [by, bm, bd] = dob.split("-").map(Number);
    const [y, m, d] = date.split("-").map(Number);
    return y - by - (m < bm || (m === bm && d < bd) ? 1 : 0);
  };
  const raw = (values: Record<string, number>) =>
    Object.entries(values).map(([key, value]) => ({ name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const }));
  const REFERENCE_ROWS = reviewedRows();
  const VERSIONS = [
    { id: "ctx-7", version_number: 7, created_at: "2026-01-02T09:00:00Z", supplements: [{ key: "creatine", dose: "5 g" }], conditions: { keys: [] } },
    { id: "ctx-9", version_number: 9, created_at: "2026-03-02T09:00:00Z", supplements: [], conditions: { keys: [] } },
    // Confirmed for a lab after it arrived: recorded on the lab, created after it.
    { id: "ctx-late", version_number: 10, created_at: `${daysAgo(1)}T10:00:00Z`, supplements: [{ key: "creatine", dose: "5 g" }], conditions: { keys: [] } },
  ];

  /** One lab recorded under ctx-7 (5 g/day); the client's latest version, ctx-9, has no creatine. */
  function processing(values: Record<string, number>, recorded: string | null) {
    const updates: Array<Record<string, unknown>> = [];
    const respond = (c: FakeCall): FakeResponse => {
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { date_of_birth: DOB, sex: "male" } };
      if (c.table === "biomarker_references") {
        const [, sexes] = argsOf(c, "in") as [string, string[]];
        return { data: REFERENCE_ROWS.filter((r) => sexes.includes(r.sex)) };
      }
      if (c.table === "lab_results" && argsOf(c, "select")?.[0] === LAB_STATE_LAB_COLUMNS) {
        return { data: { patient_context_version_id: recorded, created_at: "2026-01-05T10:00:00Z" } };
      }
      if (c.table === "patient_context_versions") {
        const id = argsOf(c, "eq", "id")?.[1];
        if (id) return { data: VERSIONS.find((v) => v.id === id) ?? null };
        return { data: null }; // nothing in force before the lab, so an unrecorded lab reads no creatine
      }
      if (c.table === "biomarker_values" && ops(c).startsWith("select")) {
        return { data: Object.entries(values).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal" })) };
      }
      if (c.table === "lab_results" && ops(c).startsWith("update")) {
        const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
        if ("biological_age" in update) updates.push(update);
      }
      return { data: null };
    };
    return { client: fakeSupabase(respond, { project: true }).client, updates };
  }

  it("processLabResults and recomputeLabMetrics store the figures of the dose recorded with the lab", async () => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    const user = { ...BASE, creatinine: 1.13 };
    const same = { ...BASE, creatinine: 1.0 };
    const expected = computeReferenceBA(inputs(user), "male", AGE, CREATINE_5G)!;
    expect(expected.BA).toBeCloseTo(computeReferenceBA(inputs(same), "male", AGE, NONE)!.BA, 10);

    const processed = processing(user, "ctx-7");
    await processLabResults("u1", "lab-1", raw(user), processed.client);
    const recomputed = processing(user, "ctx-7");
    await recomputeLabMetrics("u1", "lab-1", recomputed.client as never);
    const unadjusted = processing(user, null);
    await recomputeLabMetrics("u1", "lab-1", unadjusted.client as never);

    for (const [label, db] of [["processLabResults", processed], ["recomputeLabMetrics", recomputed]] as const) {
      expect(db.updates[0].biological_age, label).toBeCloseTo(expected.BA, 10);
      expect(db.updates[0].biological_age_comprehensive, label).toBeCloseTo(
        computeComprehensiveBA(inputs(user), "male", AGE, CREATINE_5G)!.BA,
        10,
      );
      expect(db.updates[0].bio_age_method, label).toBe(KDM_REFERENCE_BA_METHOD);
    }
    expect(unadjusted.updates[0].biological_age).toBeCloseTo(computeReferenceBA(inputs(user), "male", AGE, NONE)!.BA, 10);
    expect(unadjusted.updates[0].biological_age).toBeGreaterThan(expected.BA);
  });

  it("a failed read stores nothing: processing reads the lab's context before writing, a recompute throws on the profile", async () => {
    const failing = (what: "context" | "profile") =>
      fakeSupabase((c: FakeCall): FakeResponse => {
        if (c.table === "profiles" && ops(c).startsWith("select")) {
          return what === "profile" ? { error: { message: "connection reset" } } : { data: { date_of_birth: DOB, sex: "male" } };
        }
        if (c.table === "lab_results" && argsOf(c, "select")?.[0] === LAB_STATE_LAB_COLUMNS) {
          return what === "context" ? { error: { message: "connection reset" } } : { data: { patient_context_version_id: null, created_at: null } };
        }
        if (c.table === "biomarker_references") {
          const [, sexes] = argsOf(c, "in") as [string, string[]];
          return { data: REFERENCE_ROWS.filter((r) => sexes.includes(r.sex)) };
        }
        if (c.table === "biomarker_values" && ops(c).startsWith("select")) {
          return { data: Object.entries({ ...BASE, creatinine: 1.13 }).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal" })) };
        }
        return { data: null };
      });
    const writes = (calls: FakeCall[]) => calls.filter((c) => /^(insert|update|upsert|delete)/.test(ops(c)) && c.table !== "profiles");

    const processing = failing("context");
    await expect(processLabResults("u1", "lab-1", raw({ ...BASE, creatinine: 1.13 }), processing.client)).rejects.toThrow(/connection reset/);
    expect(writes(processing.calls)).toEqual([]);

    const quiet = vi.spyOn(console, "error").mockImplementation(() => {});
    const recompute = failing("profile");
    await expect(recomputeLabMetrics("u1", "lab-1", recompute.client as never)).rejects.toThrow(/profile.*connection reset/);
    expect(recompute.calls.some((c) => c.table === "lab_results" && ops(c).startsWith("update"))).toBe(false);
    quiet.mockRestore();
  });

  /** Two ready labs: January under ctx-9 (no creatine), February under ctx-7 (5 g/day); both creatinine 1.13. */
  function dashboard(failOn?: string) {
    const labs = [
      { id: "lab-feb", collection_date: daysAgo(20), created_at: `${daysAgo(19)}T10:00:00Z`, patient_context_version_id: "ctx-7" },
      { id: "lab-jan", collection_date: daysAgo(50), created_at: `${daysAgo(49)}T10:00:00Z`, patient_context_version_id: "ctx-9" },
    ];
    const rows = labs.flatMap((l) => Object.entries({ ...BASE, creatinine: 1.13 }).map(([biomarker_key, value]) => ({ lab_result_id: l.id, biomarker_key, value })));
    const respond = (c: FakeCall): FakeResponse => {
      if (failOn === c.table) return { error: { message: "connection reset" } };
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { sex: "male", date_of_birth: DOB } };
      if (c.table === "lab_results") return { data: labs };
      if (c.table === "biomarker_values") return { data: rows };
      if (c.table === "patient_context_versions") return { data: VERSIONS };
      return { data: null };
    };
    return { ...fakeSupabase(respond, { project: true }), labs };
  }

  it("computeRollingAverageBA: each lab's creatinine adjusted by its own context, then the labs averaged", async () => {
    const { client, calls, labs } = dashboard();
    const result = await computeRollingAverageBA("u1", client);
    const age = ageAt(DOB, labs[0].collection_date);
    // January keeps 1.13, February reads 1.00: the average creatinine is 1.065.
    const expected = computeComprehensiveBA(inputs({ ...BASE, creatinine: (1.13 + 1.0) / 2 }), "male", age, NONE)!;
    expect(result).toMatchObject({ method: "Comprehensive", n_labs_averaged: 2, window_months: 6 });
    expect(result!.ba).toBeCloseTo(expected.BA, 10);

    const values = calls.find((c) => c.table === "biomarker_values")!;
    expect(argsOf(values, "select")).toEqual(["lab_result_id, biomarker_key, value"]);
    const versions = calls.find((c) => c.table === "patient_context_versions")!;
    expect(argsOf(versions, "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(String(argsOf(calls.find((c) => c.table === "lab_results")!, "select")?.[0])).toContain("created_at");
  });

  /** Ready labs, most recent first, each with its own measured creatinine and context version. */
  function dashboardOf(spec: Array<{ creatinine: number; context: string }>) {
    const labs = spec.map((l, i) => ({
      id: `lab-${i}`, collection_date: daysAgo(20 + 30 * i), created_at: `${daysAgo(19 + 30 * i)}T10:00:00Z`, patient_context_version_id: l.context,
    }));
    const rows = labs.flatMap((l, i) =>
      Object.entries({ ...BASE, creatinine: spec[i].creatinine }).map(([biomarker_key, value]) => ({ lab_result_id: l.id, biomarker_key, value })),
    );
    const respond = (c: FakeCall): FakeResponse => {
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { sex: "male", date_of_birth: DOB } };
      if (c.table === "lab_results") return { data: ops(c).endsWith("maybeSingle") ? labs[0] : labs };
      if (c.table === "biomarker_values") return { data: rows };
      if (c.table === "patient_context_versions") return { data: VERSIONS };
      return { data: null };
    };
    return { client: fakeSupabase(respond, { project: true }).client, age: ageAt(DOB, labs[0].collection_date) };
  }

  it("a lab whose two creatinine rows include an implausible one adds no creatinine to the dashboard", () => {
    const labs = [{ id: "lab-a", created_at: "2026-10-01T10:00:00Z", patient_context_version_id: null }];
    const rows = [
      { lab_result_id: "lab-a", biomarker_key: "creatinine", value: 1.0 },
      { lab_result_id: "lab-a", biomarker_key: "CREATININE", value: 88.4 },
      { lab_result_id: "lab-a", biomarker_key: "albumin", value: 4.4 },
      { lab_result_id: "lab-b", biomarker_key: "creatinine", value: 1.0 },
      { lab_result_id: "lab-b", biomarker_key: "creatinine", value: 1.0 },
      { biomarker_key: "creatinine", value: 0.9 },
      { biomarker_key: "creatinine", value: 88.4 },
    ];
    const out = adjustCreatinineByLab(rows, labs as never, []);
    // Lab b's result listed twice counts once: its last row.
    expect(out).toEqual([
      { lab_result_id: "lab-a", biomarker_key: "albumin", value: 4.4 },
      { lab_result_id: "lab-b", biomarker_key: "creatinine", value: 1.0 },
      { biomarker_key: "creatinine", value: 0.9 },
    ]);
    expect(out[1]).toBe(rows[4]);
  });

  it("the dashboard checks each lab's measured creatinine, as the lab page does, before averaging", async () => {
    // 88.4 (µmol/L stored as mg/dL) does not count: the dashboard reads the other lab's creatinine alone.
    const mixed = dashboardOf([{ creatinine: 1.0, context: "ctx-9" }, { creatinine: 88.4, context: "ctx-9" }]);
    const result = await computeRollingAverageBA("u1", mixed.client);
    expect(result).toMatchObject({ method: "Comprehensive", n_labs_averaged: 2 });
    expect(result!.ba).toBeCloseTo(computeComprehensiveBA(inputs({ ...BASE, creatinine: 1.0 }), "male", mixed.age, NONE)!.BA, 10);

    // Measured 16 mg/dL is implausible even though 16 / 1.13 is not: no figure, as on the lab page.
    expect(await computeRollingAverageBA("u1", dashboardOf([{ creatinine: 16, context: "ctx-7" }]).client)).toBeNull();

    // Measured 0.2 mg/dL is plausible, and stays usable once divided by 1.13 for 5 g/day.
    const low = dashboardOf([{ creatinine: 0.2, context: "ctx-7" }]);
    const lowResult = await computeRollingAverageBA("u1", low.client);
    expect(lowResult!.ba).toBeCloseTo(
      computeComprehensiveBA(inputs({ ...BASE, creatinine: 0.2 }), "male", low.age, CREATINE_5G)!.BA,
      10,
    );
  });

  it.each(["window", "latest"] as const)("the %s lab read fails alone: it throws, and nothing is cached", async (which) => {
    // One lab: the window reads find too few labs, so the most recent lab is read too.
    const lab = { id: "lab-0", collection_date: daysAgo(20), created_at: `${daysAgo(19)}T10:00:00Z`, patient_context_version_id: "ctx-9" };
    const { client, calls } = fakeSupabase((c: FakeCall): FakeResponse => {
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { sex: "male", date_of_birth: DOB } };
      if (c.table === "lab_results") {
        const latest = ops(c).endsWith("maybeSingle");
        if ((which === "latest") === latest) return { error: { message: "connection reset" } };
        return { data: latest ? lab : [lab] };
      }
      if (c.table === "biomarker_values") return { data: Object.entries(BASE).map(([biomarker_key, value]) => ({ lab_result_id: "lab-0", biomarker_key, value })) };
      if (c.table === "patient_context_versions") return { data: VERSIONS };
      return { data: null };
    });
    await expect(recomputeAndCacheUserBA("u1", client)).rejects.toThrow(/connection reset/);
    expect(calls.some((c) => c.table === "profiles" && ops(c).startsWith("update"))).toBe(false);
  });

  it("the context recorded on a lab is used even when it was created after the lab arrived", async () => {
    const late = dashboardOf([{ creatinine: 1.13, context: "ctx-late" }]);
    const result = await computeRollingAverageBA("u1", late.client);
    expect(result!.ba).toBeCloseTo(computeComprehensiveBA(inputs({ ...BASE, creatinine: 1.0 }), "male", late.age, NONE)!.BA, 10);
  });

  it.each(["profiles", "lab_results", "biomarker_values", "patient_context_versions"])(
    "a read error (%s) throws, and the cached figure is not overwritten",
    async (table) => {
      const { client, calls } = dashboard(table);
      await expect(recomputeAndCacheUserBA("u1", client)).rejects.toThrow(/connection reset/);
      expect(calls.some((c) => c.table === "profiles" && ops(c).startsWith("update"))).toBe(false);
    },
  );
});
