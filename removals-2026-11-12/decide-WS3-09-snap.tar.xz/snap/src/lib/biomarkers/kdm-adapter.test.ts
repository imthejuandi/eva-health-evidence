/**
 * Unit tests for kdm-adapter.ts.
 *
 * Run: `npx vitest run src/lib/biomarkers/kdm-adapter.test.ts`
 */
import { describe, it, expect } from "vitest";
import {
  kdmInputsFromBiomarkerValues,
  __test,
} from "./kdm-adapter";
import { computeComprehensiveBA, computeReferenceBA } from "./biological-age-kdm";
import { getCanonicalUnit } from "./canonical-units";
import library from "./data/marker_library_v2_2.json";

describe("kdmInputsFromBiomarkerValues", () => {
  it("maps engine codes (uppercase) to Spanish KDM keys", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "APOB", value: 75 },
      { code: "HBA1C", value: 5.3 },
      { code: "ALBUMIN", value: 44 },
      { code: "CREATININE", value: 0.9 },
    ]);

    expect(result.inputs["Apolipoproteína B (ApoB)"]).toBe(75);
    expect(result.inputs["HbA1c (Hemoglobina Glicosilada)"]).toBe(5.3);
    expect(result.inputs["Albúmina"]).toBeCloseTo(4.4, 9); // 44 g/L → 4.4 g/dL for the KDM library
    expect(result.inputs["Creatinina"]).toBe(0.9);
    expect(result.skipped).toEqual([]);
    expect(result.unconverted).toEqual([]);
  });

  it("maps DB keys (snake_case) to the same Spanish keys", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "apolipoprotein_b", value: 75 },
      { code: "vitamin_d_25_oh", value: 42 },
      { code: "hs_crp", value: 0.8 },
    ]);

    expect(result.inputs["Apolipoproteína B (ApoB)"]).toBe(75);
    expect(result.inputs["Vitamina D (25-OH)"]).toBe(42);
    expect(result.inputs["PCR de Alta Sensibilidad (hs-PCR)"]).toBe(0.8);
  });

  it("brings raw cells/µL CBC counts to the KDM library's ×10³/μL and ×10⁶/μL", () => {
    // Engine canonical is Echevarne's raw count per µL (2026-09-17); the KDM
    // library keeps the thousands/millions scale, so the adapter divides.
    const result = kdmInputsFromBiomarkerValues([
      { code: "WBC", value: 6800 },
      { code: "PLT", value: 250000 },
      { code: "red_blood_cell_count", value: 4900000 },
    ]);

    expect(result.inputs["Recuento de Glóbulos Blancos"]).toBeCloseTo(6.8, 9);
    expect(result.inputs["Recuento de Plaquetas"]).toBeCloseTo(250, 9);
    expect(result.inputs["Recuento de Glóbulos Rojos"]).toBeCloseTo(4.9, 9);
    expect(result.converted).toEqual(["Recuento de Glóbulos Blancos", "Recuento de Plaquetas", "Recuento de Glóbulos Rojos"]);
    expect(result.unconverted).toEqual([]);
  });

  it("bridges the other Echevarne units the KDM library does not use", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "ALBUMIN", value: 44 }, // g/L → 4.4 g/dL
      { code: "calcium_serum", value: 95 }, // mg/L → 9.5 mg/dL
      { code: "TESTOSTERONE", value: 5.5 }, // ng/mL → 550 ng/dL
    ]);
    expect(result.inputs["Albúmina"]).toBeCloseTo(4.4, 9);
    expect(result.inputs["Calcio (Sérico)"]).toBeCloseTo(9.5, 9);
    expect(result.inputs["Testosterona Total"]).toBeCloseTo(550, 9);
    expect(result.unconverted).toEqual([]);
  });

  it("records unmapped codes under skipped", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "HOMA_IR", value: 1.5 }, // computed metric, no KDM equivalent
      { code: "NLR", value: 1.8 }, // computed ratio, no KDM equivalent
      { code: "UNKNOWN_CODE", value: 99 },
    ]);

    expect(Object.keys(result.inputs)).toHaveLength(0);
    expect(result.skipped).toEqual(["HOMA_IR", "NLR", "UNKNOWN_CODE"]);
  });

  it("drops non-finite values silently (NaN-safety for the joint estimator)", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "APOB", value: NaN },
      { code: "HBA1C", value: Infinity },
      { code: "ALBUMIN", value: -Infinity },
      { code: "GLUCOSE", value: 90 }, // valid; should land in inputs
    ]);

    expect(Object.keys(result.inputs)).toEqual(["Glucosa (Ayunas)"]);
    expect(result.inputs["Glucosa (Ayunas)"]).toBe(90);
  });

  it("emits unconverted when unit mismatch has no conversion factor", () => {
    // Direct test of convertUnit via internal __test surface
    expect(__test.convertUnit(40, "ng/mL", "nmol/L")).toBeNull();
    expect(__test.convertUnit(40, "mg/dL", "mg/dL")).toBe(40);
  });

  describe("the unit map's factors, from the engine's unit to the library's (check D4)", () => {
    const libraryUnit = (kdm: string) => (library.markers as Record<string, { unit?: string }>)[kdm]?.unit ?? "";
    // "µUI/mL" and "µIU/mL" are the same unit written two ways.
    const unit = (u: string) => __test.normalizeUnitString(u).replace(/ui/g, "iu");
    // Each a decimal shift, worked out from the prefixes; `factor` is the map's entry as kdm-adapter.ts writes it.
    const CASES = [
      { code: "white_blood_cell_count", value: 6800, kdm: "Recuento de Glóbulos Blancos", expected: 6.8, factor: "0.001", basis: "1 ×10³/µL = 1000 cells/µL" },
      { code: "platelet_count", value: 250_000, kdm: "Recuento de Plaquetas", expected: 250, factor: "0.001", basis: "1 ×10³/µL = 1000 cells/µL" },
      { code: "red_blood_cell_count", value: 4_900_000, kdm: "Recuento de Glóbulos Rojos", expected: 4.9, factor: "0.000001", basis: "1 ×10⁶/µL = 1 000 000 cells/µL" },
      { code: "albumin", value: 44, kdm: "Albúmina", expected: 4.4, factor: "0.1", basis: "1 g/dL = 10 g/L" },
      { code: "total_protein", value: 72, kdm: "Proteínas Totales", expected: 7.2, factor: "0.1", basis: "1 g/dL = 10 g/L" },
      { code: "calcium_serum", value: 95, kdm: "Calcio (Sérico)", expected: 9.5, factor: "0.1", basis: "1 mg/dL = 10 mg/L" },
      { code: "testosterone_total", value: 5.5, kdm: "Testosterona Total", expected: 550, factor: "100", basis: "1 ng/mL = 100 ng/dL" },
    ];

    it.each(CASES)("$code: ×$factor into the library's unit ($basis)", ({ code, value, kdm, expected }) => {
      const entry = __test.CODE_TO_KDM[code];
      expect(entry.kdm).toBe(kdm);
      // From the unit processing stores the value in (the seed's canonical unit) to the unit the library declares.
      expect(unit(entry.engineUnit)).toBe(unit(getCanonicalUnit(code)!));
      expect(unit(entry.kdmUnit)).toBe(unit(libraryUnit(kdm)));
      expect(unit(entry.engineUnit)).not.toBe(unit(entry.kdmUnit));
      expect(__test.convertUnit(value, entry.engineUnit, entry.kdmUnit)).toBeCloseTo(expected, 9);
      const result = kdmInputsFromBiomarkerValues([{ code, value }]);
      expect(result.inputs[kdm]).toBeCloseTo(expected, 9);
      expect(result.converted).toEqual([kdm]);
      expect(result.unconverted).toEqual([]);
    });
  });

  it("normalizeUnitString collapses micro and ×10 variants", () => {
    expect(__test.normalizeUnitString("10³/µL")).toBe(
      __test.normalizeUnitString("×10³/μL"),
    );
    expect(__test.normalizeUnitString("μg/dL")).toBe(
      __test.normalizeUnitString("µg/dL"),
    );
  });

  it("synthetic 14-marker base-panel input maps cleanly", () => {
    // Synthetic input simulating a user uploading the KDM 14-marker base panel
    // via engine codes that map to it. Note: 4 of the 14 base panel markers
    // (BUN, Total Cholesterol, Fructosamine, and Cystatin-not-base) are
    // ABSENT from the eva engine's 39-code list, so this input uses
    // engine codes for the 10 overlapping markers, plus DB keys for the
    // 4 KDM-base-only markers.
    const result = kdmInputsFromBiomarkerValues([
      { code: "ALBUMIN", value: 44 },
      { code: "CREATININE", value: 0.9 },
      { code: "blood_urea_nitrogen", value: 14 },
      { code: "URIC_ACID", value: 5.2 },
      { code: "ALP", value: 75 },
      { code: "GGT", value: 18 },
      { code: "total_cholesterol", value: 180 },
      { code: "HDL_C", value: 55 },
      { code: "TG", value: 90 },
      { code: "HSCRP", value: 0.7 },
      { code: "FERRITIN", value: 80 },
      { code: "VITD", value: 42 },
      { code: "TSH", value: 1.8 },
      // Fructosamine intentionally omitted — derived from HbA1c in B.9.
    ]);

    expect(Object.keys(result.inputs).length).toBeGreaterThanOrEqual(13);
    expect(result.unconverted).toEqual([]);
    expect(result.inputs["Albúmina"]).toBeCloseTo(4.4, 9); // 44 g/L → 4.4 g/dL for the KDM library
    expect(result.inputs["Creatinina"]).toBe(0.9);
    expect(result.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBe(14);
    expect(result.inputs["Colesterol Total"]).toBe(180);
  });

  it("last duplicate wins when same KDM key supplied via two synonyms", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "APOB", value: 70 },
      { code: "apolipoprotein_b", value: 75 }, // second one wins
    ]);
    expect(result.inputs["Apolipoproteína B (ApoB)"]).toBe(75);
  });

  describe("Urea cross-molecule scaling to BUN", () => {
    it("scales a urea-keyed value to BUN via ×0.4665", () => {
      const result = kdmInputsFromBiomarkerValues([
        // 30 mg/dL Urea ≈ 14 mg/dL BUN (the KDM library is anchored on BUN).
        { code: "urea", value: 30 },
      ]);
      // Allow for floating-point: 30 × 0.4665 = 13.995.
      expect(result.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBeCloseTo(
        13.995,
        3,
      );
      expect(result.converted).toContain("BUN (Nitrógeno Ureico en Sangre)");
      expect(result.unconverted).toEqual([]);
    });

    it("prefers same-molecule BUN over cross-molecule Urea when both are present", () => {
      // Lab reports BOTH a Urea row AND a BUN row for the same draw.
      // bun's value should win regardless of array order because it's
      // same-molecule (no cross-molecule scaling needed).
      const ureaFirst = kdmInputsFromBiomarkerValues([
        { code: "urea", value: 30 }, // → would scale to 13.995
        { code: "bun", value: 14 }, // same-molecule, wins
      ]);
      expect(ureaFirst.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBe(14);

      const bunFirst = kdmInputsFromBiomarkerValues([
        { code: "bun", value: 14 }, // same-molecule, wins
        { code: "urea", value: 30 }, // → would scale to 13.995, dropped
      ]);
      expect(bunFirst.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBe(14);
    });

    it("falls back to scaled Urea when no BUN row is present", () => {
      const result = kdmInputsFromBiomarkerValues([
        { code: "urea", value: 40 },
      ]);
      expect(result.inputs["BUN (Nitrógeno Ureico en Sangre)"]).toBeCloseTo(
        18.66,
        2,
      );
    });
  });
});

describe("DB keys reach the KDM library (fix of 2026-09-25)", () => {
  // Serum calcium, iron and TIBC were mapped as "calcium", "iron" and
  // "total_iron_binding_capacity"; the DB keys (slugs of the seed names) are
  // calcium_serum, iron_serum and iron_binding_capacity_tibc, so the three
  // never reached the Comprehensive BA.
  it("maps serum calcium, iron and TIBC by their DB keys, in the library's units", () => {
    const result = kdmInputsFromBiomarkerValues([
      { code: "calcium_serum", value: 95 }, // mg/L (Echevarne) → 9.5 mg/dL
      { code: "iron_serum", value: 95 }, // µg/dL
      { code: "iron_binding_capacity_tibc", value: 320 }, // µg/dL
    ]);
    expect(result.inputs["Calcio (Sérico)"]).toBeCloseTo(9.5, 9);
    expect(result.inputs["Hierro (Sérico)"]).toBe(95);
    expect(result.inputs["Capacidad de Fijación del Hierro (TIBC)"]).toBe(320);
    expect(result.converted).toEqual(["Calcio (Sérico)"]);
    expect(result.skipped).toEqual([]);
    expect(result.unconverted).toEqual([]);
  });

  // Snake_case keys that are not DB keys: synonyms kept for other callers.
  // Every other snake_case key in the map must be a key the database can hold.
  const NOT_DB_KEYS = [
    "apolipoprotein_b", "lipoprotein_a", "apolipoprotein_a1", "apolipoprotein_a1_apoa1", "fasting_insulin", "egfr",
    "blood_urea_nitrogen", "cystatin_c", "alkaline_phosphatase", "transferrin_saturation", "testosterone", "free_t4",
    "free_t3", "folate", "magnesium", "zinc", "fibrinogen",
  ];
  const snakeKeys = Object.keys(__test.CODE_TO_KDM).filter((k) => k !== k.toUpperCase());
  // "µUI/mL" (TSH) and "µIU/mL" are the same unit written two ways.
  const unit = (u: string) => __test.normalizeUnitString(u).replace(/ui/g, "iu");

  it("every snake_case key is a DB key of the seed, or a listed synonym", () => {
    const notInSeed = snakeKeys.filter((k) => getCanonicalUnit(k) === null);
    expect(notInSeed.sort()).toEqual([...NOT_DB_KEYS].sort());
  });

  it("every DB key is read in the seed's canonical unit", () => {
    for (const key of snakeKeys.filter((k) => getCanonicalUnit(k) !== null)) {
      expect(unit(__test.CODE_TO_KDM[key].engineUnit), key).toBe(unit(getCanonicalUnit(key)!));
    }
  });

  it("the three now count in the Comprehensive BA; the Reference BA is unchanged", () => {
    const base = [
      { code: "albumin", value: 44 }, { code: "creatinine", value: 1.0 }, { code: "bun", value: 15 },
      { code: "uric_acid", value: 6.0 }, { code: "alp", value: 72 }, { code: "ggt", value: 32 },
      { code: "total_cholesterol", value: 205 }, { code: "hdl_cholesterol", value: 47 },
      { code: "triglycerides", value: 140 }, { code: "hs_crp", value: 1.8 }, { code: "hba1c", value: 5.5 },
    ];
    const extra = [
      { code: "calcium_serum", value: 95 },
      { code: "iron_serum", value: 95 },
      { code: "iron_binding_capacity_tibc", value: 320 },
    ];
    const comp = computeComprehensiveBA([...base, ...extra], "male", 45)!;
    expect(comp.used_markers).toEqual(
      expect.arrayContaining(["Calcio (Sérico)", "Hierro (Sérico)", "Capacidad de Fijación del Hierro (TIBC)"]),
    );
    expect(comp.n_markers_used).toBe(computeComprehensiveBA(base, "male", 45)!.n_markers_used + 3);
    expect(computeReferenceBA([...base, ...extra], "male", 45)).toEqual(computeReferenceBA(base, "male", 45));
  });
});
