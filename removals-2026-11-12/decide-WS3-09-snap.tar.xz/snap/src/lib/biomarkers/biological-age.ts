/**
 * Re-exports the longevity-score engine (`./longevity-score`, the owner of the
 * penalty math) for the import sites that read it from here. The score is `calculateLongevityScoreV2`, the one
 * score; the first score and its `calculate` alias have been removed.
 *
 * This module computes no biological age. Use `computeReferenceBA` /
 * `computeComprehensiveBA` from `./biological-age-kdm` for the KDM biological
 * age (KDM v2.2.2 joint estimator; in-sample HR 1.39 Reference / 1.65
 * Comprehensive per SD of biological age, Cox model with age and sex, NHANES
 * n=18,570; not tested outside NHANES). `lab_results.biological_age` holds
 * the KDM Reference BA, written by the orchestrator in `process-results.ts`.
 *
 * Split rationale: see audit/longevity_score_audit_report.md
 */

export * from "./longevity-score";
