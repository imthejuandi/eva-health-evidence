/**
 * Calculated/derived metrics from raw biomarker values.
 * Each metric: check required biomarkers → calculate → classify → return.
 *
 * A metric has no thresholds of its own. Its category comes from a reviewed
 * reference row, picked for the person like any result (the refMap processing
 * classifies with): HOMA-IR from the `homa_ir` row, computed non-HDL-C from
 * `non_hdl_cholesterol`, any other metric from the row whose biomarker_key is
 * its metric key (`nlr`). Without a row the metric is `unclassified`. Metrics
 * carry no text either: the reviewed messages live on the rows.
 *
 * A metric computed from a bounded result ("<2", whose value is the bound) is
 * not a measured value. Each metric rises or falls with each of its inputs, so
 * a bound on an input gives the direction of the metric's true value: insulin
 * "<2" with a measured glucose puts HOMA-IR below the value computed from 2,
 * lymphocytes "<500" puts NLR above it. When every bounded input moves the
 * metric the same way, the metric is itself a bound with that comparator, and
 * it is classified as any bound is (bounded-result.ts classifyResultZone):
 * placed only when every value it allows falls in one zone. When the inputs
 * move it opposite ways the direction is not certain, and the metric stays
 * unclassified, with no comparator.
 *
 * eGFR (ruling D-28) is the one metric that needs the person: it is computed from the measured creatinine, the age
 * at the draw and sex with the one declared equation (egfr.ts, data/egfr-equation.json), under the metric key
 * `egfr_computed`, and classified against the reviewed `egfr_creatinine_based` rows, which describe this value. That
 * biomarker key is where a laboratory's own eGFR is stored; the laboratory's figure is never read here and never
 * classified (lab-reported.ts). Without a person, or when the lab's creatinine rows cannot be read as one plausible
 * result (creatinine-plausibility.ts), no eGFR is computed. In declared pregnancy it is a value with no category.
 */

import { classifyResultZone } from "./bounded-result";
import { labCreatinineReadable } from "./creatinine-plausibility";
import { computeEgfr, EGFR_CREATININE_KEY, EGFR_EQUATION, EGFR_METRIC_KEY, reportedEgfr } from "./egfr";
import type { Zone } from "./zone-classifier";

export interface CalculatedMetric {
  metricName: string;
  metricKey: string;
  /** The metric computed from its inputs' values (a bound's value is the bound itself). */
  value: number;
  /** "<" or ">" when the metric is a bound (a bounded input, every one moving it the same way); null otherwise. */
  comparator: "<" | ">" | null;
  unit: string;
  zone: Zone;
  interpretation: string;
  interpretation_es: string;
}

/** The bounds of a reviewed row, as processing's refMap holds them. */
export interface MetricReferenceRow {
  optimal_low: number | null;
  optimal_high: number | null;
  normal_low: number | null;
  normal_high: number | null;
}

/** A metric whose reviewed row has another key than the metric. */
const METRIC_ROW_KEY: Record<string, string> = {
  non_hdl: "non_hdl_cholesterol",
  [EGFR_METRIC_KEY]: "egfr_creatinine_based",
};

/** Who the results belong to, for the metric that needs it (eGFR): the age at the draw, and sex as stored. */
export interface MetricPerson {
  /** Completed years at the lab's collection date (egfr.ts ageAtDraw), not today's age. */
  age: number;
  sex: string | null | undefined;
  /**
   * Pregnancy declared for this lab (patient-context/physiological-state.ts). The reviewed eGFR rows say that no
   * equation is valid in pregnancy and that the pregnancy rule applies (docs/signoff/work/decisions/f03_kidney.json;
   * state-rules.md 2.1 and 2.2): the computed eGFR then has no category.
   */
  pregnancy?: boolean;
}

type BiomarkerMap = Record<string, number>;
/** +1: the metric rises as the input rises; -1: it falls. */
type Rises = 1 | -1;
type Metric = Pick<CalculatedMetric, "metricName" | "metricKey" | "value" | "unit"> & {
  /** The inputs the value was computed from, each with the way the metric moves when it rises. */
  inputs: Array<[key: string, rises: Rises]>;
};

function has(map: BiomarkerMap, ...keys: string[]): boolean {
  return keys.every((k) => k in map && map[k] != null && isFinite(map[k]));
}

// ─── 1. HOMA-IR ───

function calcHomaIR(map: BiomarkerMap): Metric | null {
  // The seed (and Echevarne D0154) key insulin as `insulin_fasting`; the
  // legacy `fasting_insulin` spelling is still honoured.
  const insulinKey = has(map, "insulin_fasting") ? "insulin_fasting" : "fasting_insulin";
  if (!has(map, insulinKey, "glucose_fasting")) return null;
  const value = (map[insulinKey] * map["glucose_fasting"]) / 405;
  return {
    metricName: "HOMA-IR", metricKey: "homa_ir", value: Math.round(value * 100) / 100, unit: "",
    inputs: [[insulinKey, 1], ["glucose_fasting", 1]],
  };
}

// ─── 2. TG/HDL Ratio ───

function calcTgHdlRatio(map: BiomarkerMap): Metric | null {
  if (!has(map, "triglycerides", "hdl_cholesterol")) return null;
  const value = Math.round((map["triglycerides"] / map["hdl_cholesterol"]) * 100) / 100;
  return { metricName: "TG/HDL Ratio", metricKey: "tg_hdl_ratio", value, unit: "", inputs: [["triglycerides", 1], ["hdl_cholesterol", -1]] };
}

// ─── 3. De Ritis Ratio (AST/ALT) ───

function calcDeRitis(map: BiomarkerMap): Metric | null {
  if (!has(map, "ast", "alt") || map["alt"] === 0) return null;
  const value = Math.round((map["ast"] / map["alt"]) * 100) / 100;
  return { metricName: "De Ritis Ratio (AST/ALT)", metricKey: "de_ritis", value, unit: "", inputs: [["ast", 1], ["alt", -1]] };
}

// ─── 4. Omega-3 Index ───

function calcOmega3Index(map: BiomarkerMap): Metric | null {
  if (!has(map, "epa", "dha", "total_fatty_acids") || map["total_fatty_acids"] === 0) return null;
  const value = Math.round(((map["epa"] + map["dha"]) / map["total_fatty_acids"]) * 10000) / 100;
  return {
    metricName: "Omega-3 Index", metricKey: "omega3_index", value, unit: "%",
    inputs: [["epa", 1], ["dha", 1], ["total_fatty_acids", -1]],
  };
}

// ─── 5. NLR (Neutrophil-to-Lymphocyte Ratio) ───

function calcNLR(map: BiomarkerMap): Metric | null {
  if (!has(map, "neutrophils", "lymphocytes") || map["lymphocytes"] === 0) return null;
  const value = Math.round((map["neutrophils"] / map["lymphocytes"]) * 100) / 100;
  return { metricName: "Neutrophil-to-Lymphocyte Ratio", metricKey: "nlr", value, unit: "", inputs: [["neutrophils", 1], ["lymphocytes", -1]] };
}

// ─── 6. Free Androgen Index ───

function calcFAI(map: BiomarkerMap): Metric | null {
  // FAI = total testosterone (nmol/L) × 100 / SHBG (nmol/L). Testosterone is
  // stored in ng/mL (Echevarne's unit, canonical since 2026-09-17):
  // 1 ng/mL = 3.467 nmol/L. The legacy "testosterone" key is honoured too.
  const tKey = has(map, "testosterone_total") ? "testosterone_total" : "testosterone";
  if (!has(map, tKey, "shbg") || map["shbg"] === 0) return null;
  const testosteroneNmolL = map[tKey] * 3.467;
  const value = Math.round((testosteroneNmolL / map["shbg"]) * 10000) / 100;
  return { metricName: "Free Androgen Index", metricKey: "fai", value, unit: "", inputs: [[tKey, 1], ["shbg", -1]] };
}

// ─── 7. Non-HDL Cholesterol ───

function calcNonHDL(map: BiomarkerMap): Metric | null {
  if (!has(map, "total_cholesterol", "hdl_cholesterol")) return null;
  const value = Math.round((map["total_cholesterol"] - map["hdl_cholesterol"]) * 10) / 10;
  return {
    metricName: "Non-HDL Cholesterol", metricKey: "non_hdl", value, unit: "mg/dL",
    inputs: [["total_cholesterol", 1], ["hdl_cholesterol", -1]],
  };
}

// ─── 8. eGFR, computed by the app ───

/**
 * eGFR from the measured creatinine (the stored value, never adjusted for creatine), by the declared equation. It
 * falls as creatinine rises, so a creatinine reported as "<" a bound gives an eGFR above the computed value. The
 * value is the reported one (the equation's decimals), and the category is that of the value shown.
 */
function calcEgfr(map: BiomarkerMap, person: MetricPerson | null | undefined): Metric | null {
  if (!person || !has(map, EGFR_CREATININE_KEY)) return null;
  const value = reportedEgfr(computeEgfr({ creatinine: map[EGFR_CREATININE_KEY], age: person.age, sex: person.sex }));
  if (value === null) return null;
  return {
    metricName: "eGFR", metricKey: EGFR_METRIC_KEY, value, unit: EGFR_EQUATION.result_unit,
    inputs: [[EGFR_CREATININE_KEY, -1]],
  };
}

/**
 * The comparator of a metric given its inputs' comparators: none when no input is a bound; "<" or ">" when every
 * bounded input moves the metric the same way ("<" on an input the metric rises with, or ">" on one it falls with,
 * puts the metric below its computed value); undefined when they move it opposite ways.
 */
function metricComparator(
  inputs: Metric["inputs"],
  comparators: ReadonlyMap<string, "<" | ">">,
): "<" | ">" | null | undefined {
  let direction: Rises | null = null;
  for (const [key, rises] of inputs) {
    const c = comparators.get(key);
    if (!c) continue;
    const d = ((c === ">" ? 1 : -1) * rises) as Rises;
    if (direction !== null && d !== direction) return undefined;
    direction = d;
  }
  return direction === null ? null : direction === 1 ? ">" : "<";
}

// ─── Public API ───

/**
 * Every metric the values allow, classified against `referenceRows` (the
 * rows picked for the person, keyed by biomarker_key). Without rows every
 * metric is `unclassified`; the values do not depend on them. A biomarker's
 * `comparator` ("<" or ">", its value being the bound) makes the metrics
 * computed from it bounds or leaves them unclassified (module comment).
 * `person` (the age at the draw and sex) adds the eGFR the app computes; without it there is none.
 */
export function calculateAllMetrics(
  biomarkers: Array<{ biomarker_key: string; value: number; comparator?: "<" | ">" | null }>,
  referenceRows: ReadonlyMap<string, MetricReferenceRow> = new Map(),
  person?: MetricPerson | null,
): CalculatedMetric[] {
  const map: BiomarkerMap = {};
  const comparators = new Map<string, "<" | ">">();
  for (const b of biomarkers) {
    map[b.biomarker_key] = b.value;
    // The last value of a key is the one computed with, so its comparator is the one read.
    if (b.comparator === "<" || b.comparator === ">") comparators.set(b.biomarker_key, b.comparator);
    else comparators.delete(b.biomarker_key);
  }

  const results: CalculatedMetric[] = [];
  // Every creatinine row of the lab must be the same plausible result, or the lab gives no eGFR (as it gives no
  // biological age): the value computed with would otherwise be a guess between them.
  const creatinineRows = biomarkers.filter((b) => b.biomarker_key === EGFR_CREATININE_KEY).map((b) => b.value);
  const egfr = (m: BiomarkerMap) => (labCreatinineReadable(creatinineRows) ? calcEgfr(m, person) : null);
  const fns = [calcHomaIR, calcTgHdlRatio, calcDeRitis, calcOmega3Index, calcNLR, calcFAI, calcNonHDL, egfr];

  for (const fn of fns) {
    const computed = fn(map);
    if (!computed) continue;
    const { inputs, ...metric } = computed;
    const comparator = metricComparator(inputs, comparators);
    const row = referenceRows.get(METRIC_ROW_KEY[metric.metricKey] ?? metric.metricKey);
    const noCategory = metric.metricKey === EGFR_METRIC_KEY && person?.pregnancy === true;
    const zone: Zone =
      row && comparator !== undefined && !noCategory
        ? classifyResultZone(metric.value, comparator, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high)
        : "unclassified";
    results.push({ ...metric, comparator: comparator ?? null, zone, interpretation: "", interpretation_es: "" });
  }

  return results;
}
