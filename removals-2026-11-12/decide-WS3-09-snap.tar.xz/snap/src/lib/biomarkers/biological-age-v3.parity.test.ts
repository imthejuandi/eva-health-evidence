/**
 * Biological age v3: the TypeScript port against the Python reference (CHARTER.md T11: "TypeScript matches the
 * Python reference within 1e-6 years on at least 500 fixture rows").
 *
 * Fixture: `__tests__/fixtures/ba-v3-python-parity.json`, public NHANES IV waves 1-4 rows (validation split, no
 * identifiers) with the result of `PhenoAgeV3.predict_interval` of the frozen `ml/biological-age/model-v3.json`.
 * Written, deterministically, by
 *   cd ml/biological-age && .venv/bin/python integration/build_ts_parity_fixture.py
 * The TypeScript model data (`./data/ba_v3_model.json`) is written by
 *   cd ml/biological-age && .venv/bin/python integration/export_ts_model.py
 *
 * Every row must match the reference's biological age and both interval bounds within 1e-6 years, and the TypeScript
 * must choose the row's tier. The maximum absolute differences are printed and appear in the test names.
 *
 * Run: `npx vitest run src/lib/biomarkers/biological-age-v3.parity.test.ts`
 */
import { describe, it, expect } from "vitest";
import {
  BA_V3_MODEL_SHA256,
  computeBiologicalAgeV3,
  type BiologicalAgeV3Outcome,
  type BiomarkerV3Input,
} from "./biological-age-v3";
import modelData from "./data/ba_v3_model.json";
import fixtureData from "./__tests__/fixtures/ba-v3-python-parity.json";

const TOLERANCE_YEARS = 1e-6; // CHARTER.md T11
const FROZEN_MODEL_SHA256 = "dc60ee29d88621c716086434c9894779417a3189fe7c2ee5178f010eec45bb10";
const FROZEN_FILE_SHA256 = "367072a01cf8edf730f117c0ec4145dd3b5c0f18b980c43aa901bdd95539caa6";

interface ParityRow {
  tier: "plus_hba1c" | "base";
  sex: "male" | "female";
  age: number;
  values: Record<string, number>;
  ba: number;
  lower: number;
  upper: number;
  clamps_applied: [string, "lower" | "upper"][];
  crp_capped: boolean;
}

interface ParityFixture {
  source_model_sha256: string;
  source_file_sha256: string;
  seed: number;
  units: Record<string, string>;
  ignored_keys: string[];
  rows: ParityRow[];
}

const fixture = fixtureData as unknown as ParityFixture;
const rows = fixture.rows;

function inputsOf(row: ParityRow): BiomarkerV3Input[] {
  return Object.entries(row.values).map(([code, value]) => ({ code, value, unit: fixture.units[code] }));
}

const outcomes: BiologicalAgeV3Outcome[] = rows.map((row) => computeBiologicalAgeV3(inputsOf(row), row.sex, row.age));

function maxAbsDiff(pick: (row: ParityRow, i: number) => number | null): number {
  let max = 0;
  rows.forEach((row, i) => {
    const d = pick(row, i);
    max = Math.max(max, d === null ? Infinity : d);
  });
  return max;
}

const maxBa = maxAbsDiff((row, i) => {
  const o = outcomes[i];
  return o.ba === null ? null : Math.abs(o.ba - row.ba);
});
const maxLower = maxAbsDiff((row, i) => {
  const o = outcomes[i];
  return o.ba === null ? null : Math.abs(o.interval[0] - row.lower);
});
const maxUpper = maxAbsDiff((row, i) => {
  const o = outcomes[i];
  return o.ba === null ? null : Math.abs(o.interval[1] - row.upper);
});
const fmt = (x: number) => x.toExponential(2);

describe("biological age v3: TypeScript vs the Python reference (T11)", () => {
  it("the TypeScript data and the fixture come from the frozen model-v3.json", () => {
    expect(modelData.source_model_sha256).toBe(FROZEN_MODEL_SHA256);
    expect(modelData.source_file_sha256).toBe(FROZEN_FILE_SHA256);
    expect(BA_V3_MODEL_SHA256).toBe(FROZEN_MODEL_SHA256);
    expect(fixture.source_model_sha256).toBe(FROZEN_MODEL_SHA256);
    expect(fixture.source_file_sha256).toBe(FROZEN_FILE_SHA256);
  });

  it(`the fixture has at least 500 rows (${rows.length}), at least 300 per tier`, () => {
    expect(rows.length).toBeGreaterThanOrEqual(500);
    expect(rows.filter((r) => r.tier === "plus_hba1c").length).toBeGreaterThanOrEqual(300);
    expect(rows.filter((r) => r.tier === "base").length).toBeGreaterThanOrEqual(300);
  });

  it("every row gives a result, in the row's tier", () => {
    const wrong = rows.flatMap((row, i) => {
      const o = outcomes[i];
      if (o.ba === null) return [`row ${i}: no result (${o.reason}: ${o.markers.join(", ")})`];
      return o.tier === row.tier ? [] : [`row ${i}: tier ${o.tier}, expected ${row.tier}`];
    });
    expect(wrong).toEqual([]);
  });

  it(`biological age within 1e-6 years on every row (max |difference| ${fmt(maxBa)} years)`, () => {
    console.info(
      `[T11 parity] ${rows.length} rows: max |BA difference| ${maxBa} years; ` +
        `max |lower bound difference| ${maxLower} years; max |upper bound difference| ${maxUpper} years`,
    );
    const over = rows.flatMap((row, i) => {
      const o = outcomes[i];
      return o.ba !== null && Math.abs(o.ba - row.ba) <= TOLERANCE_YEARS ? [] : [`row ${i}`];
    });
    expect(over).toEqual([]);
    expect(maxBa).toBeLessThanOrEqual(TOLERANCE_YEARS);
  });

  it(`interval bounds within 1e-6 years on every row (max |difference| lower ${fmt(maxLower)}, upper ${fmt(maxUpper)} years)`, () => {
    const over = rows.flatMap((row, i) => {
      const o = outcomes[i];
      if (o.ba === null) return [`row ${i}`];
      const ok =
        Math.abs(o.interval[0] - row.lower) <= TOLERANCE_YEARS && Math.abs(o.interval[1] - row.upper) <= TOLERANCE_YEARS;
      return ok ? [] : [`row ${i}`];
    });
    expect(over).toEqual([]);
    expect(maxLower).toBeLessThanOrEqual(TOLERANCE_YEARS);
    expect(maxUpper).toBeLessThanOrEqual(TOLERANCE_YEARS);
  });

  it("the clamps applied and the CRP cap flag agree with the reference on every row", () => {
    const wrong = rows.flatMap((row, i) => {
      const o = outcomes[i];
      if (o.ba === null) return [`row ${i}`];
      const got = JSON.stringify(o.clampsApplied.map((c) => [c.key, c.side]));
      const ok = got === JSON.stringify(row.clamps_applied) && o.crpCapped === row.crp_capped;
      return ok ? [] : [`row ${i}: ${got} / ${o.crpCapped}, expected ${JSON.stringify(row.clamps_applied)} / ${row.crp_capped}`];
    });
    expect(wrong).toEqual([]);
  });

  it("the fixture exercises every clamp, the CRP cap, both age ends and ignored blood-count values", () => {
    const seen = new Set(rows.flatMap((r) => r.clamps_applied.map(([key, side]) => `${r.tier} ${key} ${side}`)));
    for (const tier of ["base", "plus_hba1c"]) {
      for (const clamp of ["albumin upper", "alp lower", "bun lower", "creatinine lower", "hs_crp lower", "hs_crp upper"]) {
        expect(seen.has(`${tier} ${clamp}`), `${tier} ${clamp}`).toBe(true);
      }
    }
    expect(seen.has("plus_hba1c hba1c lower")).toBe(true);
    expect(rows.some((r) => r.crp_capped)).toBe(true);
    expect(rows.some((r) => r.age === 20)).toBe(true);
    expect(rows.some((r) => r.age === 84)).toBe(true);
    for (const sex of ["male", "female"]) {
      expect(rows.some((r) => r.sex === sex && r.clamps_applied.some(([key]) => key === "creatinine"))).toBe(true);
    }
    const withBloodCount = rows.filter((r) => fixture.ignored_keys.every((k) => k in r.values));
    expect(withBloodCount.length).toBeGreaterThan(0);
    for (const row of withBloodCount) {
      const o = outcomes[rows.indexOf(row)];
      expect(o.ba === null ? [] : o.markersUsed.filter((k) => fixture.ignored_keys.includes(k))).toEqual([]);
    }
  });
});
