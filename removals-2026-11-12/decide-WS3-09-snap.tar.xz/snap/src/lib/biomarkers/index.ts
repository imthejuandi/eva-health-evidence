export { ZONE_CONFIG } from "./zone-config";
export type { Zone } from "./zone-config";
export { classifyZone, calculateAge } from "./zone-classifier";

export type { BiomarkerInput, FullResult, MarkerScore, Confidence } from "./biological-age";

export { calculateAllMetrics } from "./calculated-metrics";
export type { CalculatedMetric } from "./calculated-metrics";

export { matchBiomarkerName, matchBiomarkerNames, DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
export type { MatchResult } from "./name-matcher";

export { processLabResults } from "./process-results";
export type { RawBiomarker, ProcessedBiomarker, UnmatchedBiomarker, ProcessingResult } from "./process-results";
