/**
 * Longevity Score (penalty engine)
 *
 * Entry: `calculateLongevityScoreV2(values, sex, age, rows, context?) → FullResult`,
 * the one score: each marker is scored against the reviewed biomarker_references
 * row picked for the person, the row its result is classified with. The first
 * score, which read ranges written in this file, and the server switch that
 * chose between the two have been removed; the name keeps its "V2" for the
 * callers that import it.
 *
 * The optional context (ScoreContext) carries what the lab's interpretation
 * knows and the values alone do not: declared pregnancy or lactation and a
 * value in the critical tier (no score: `withheld`), and declared oral
 * oestrogen (hs-CRP not scored, triglycerides on their reference interval
 * only). A scored marker outside its reference interval holds the score below
 * the top grade (`cap`). The rules are written out in
 * docs/signoff/work/score/specification.md.
 *
 * What the engine knows about the markers comes from one file, data/score-spec.json (ScoreSpec): the markers and
 * the reviewed row each reads, their weights, which picked rows are eligible to score, the redundancy groups, the
 * coverage rule (domains and minimums), the grade table, the penalty and score curves, the cap and the confidence
 * rule. The file is generated (scripts/score/build-score-spec.ts) from the rulings recorded in
 * docs/signoff/work/score/spec-inputs.json, the families' decided rows and the verifier's grades; nobody edits it
 * by hand. A marker scores only through a picked row the file lists as eligible, whose optimal bounds are the
 * bounds the verifier graded. The score has no bonus: it is 100 when every scoring marker is optimal, and only
 * penalties lower it. Two literals stay in this module as copies of the file, because the acceptance test's runner
 * imports one and reads the other from the source text (the row keys and the redundancy groups); the engine reads
 * neither, and score-spec.test.ts holds each equal to the file.
 *
 * This module owns the LONGEVITY SCORE — a 1-100 deviation-from-optimal-range
 * metric that answers "how close to longevity-medicine optimal are you?"
 *
 * It computes no biological age. EVA's biological age is the KDM estimate
 * (`biological-age-kdm.ts`); the penalty-derived age this engine used to
 * return was never read and has been deleted.
 *
 * Split rationale: see audit/longevity_score_audit_report.md
 */

import { classifyZone as classifyReviewedZone } from "./zone-classifier";
import { pickReferenceRows } from "./reference-row";

import specFile from "./data/score-spec.json";

// ─── Enums ───

export type Zone = "critical_low" | "below_optimal" | "optimal" | "above_optimal" | "critical_high";
export type Confidence = "high" | "moderate" | "low" | "insufficient";

// ─── Data Types ───

// ─── The specification ───

/** One marker of the specification. It carries no range: the range is the reviewed row's. */
export interface ScoreSpecMarker {
  /** The biomarker_references key its results are stored and classified under. */
  key: string;
  name: string;
  /** EVA's canonical unit for the marker, the unit of its stored values and of its reviewed row. */
  unit: string;
  category: string;
  /** The marker's weight in the score, from the grade of its rows that score. null: no row of it scores. */
  weight: number | null;
  /** The worst verifier grade among the marker's rows that score; null when none does. */
  grade: string | null;
  /** The marker scores only when the lab's context confirms fasting (ScoreContext.confirmedFasting). */
  requires_confirmed_fasting: boolean;
  /** The marker is passed over when the HbA1c exclusion holds for the result (ScoreContext.hba1cExcluded). */
  passed_over_on_hba1c_exclusion: boolean;
  /**
   * Which picked rows may score, keyed by rowEligibilityKey ("<sex>|<age_group_en>"). A row the map does not name
   * may not, and neither may a named row whose optimal bounds differ from the bounds graded (optimal_low and
   * optimal_high here): the grade belongs to that band and to no other.
   */
  rows: Record<string, ScoreSpecRow>;
}

export interface ScoreSpecRow {
  /** The verifier's grade of the row's optimal band. */
  grade: string | null;
  eligible: boolean;
  /** The optimal bounds the grade was given on. */
  optimal_low: number | null;
  optimal_high: number | null;
  /** Why the row does not score, when it does not. */
  reason?: string;
}

export interface ScoreSpecGroup {
  name: string;
  /** Engine codes, the preferred member first. */
  priority_order: string[];
}

export interface ScoreSpecDomain {
  description: string;
  /** The engine codes that cover the domain when they score. */
  markers: string[];
  min_count: number;
}

export interface ScoreSpec {
  version: string;
  markers: Record<string, ScoreSpecMarker>;
  groups: ScoreSpecGroup[];
  coverage: { domains: Record<string, ScoreSpecDomain>; min_markers: number; min_domains: number };
  /** The grade table, top grade first: a score has the first grade whose minimum it reaches. */
  grades: { min: number; label: string }[];
  /**
   * A marker's penalty as a fraction of its weight: `at_reference_limit` where in range meets out of range, `max`
   * at most, the in-range term raised to `in_range_exponent`, and `no_band_width` (of the limit's absolute value)
   * as the width of a side that has no band.
   */
  penalty_curve: { max: number; at_reference_limit: number; in_range_exponent: number; no_band_width: number };
  /** score = scale × e^(−k × net penalty ratio), rounded and held between floor and ceiling. */
  score_curve: { scale: number; k: number; floor: number; ceiling: number };
  /** out_of_range.grade: the best grade a score can have while a scored marker is outside its reference interval. */
  caps: { out_of_range: { grade: string } };
  /**
   * The first level whose minimum of covered domains holds; `otherwise` when none does; `below_coverage` under the
   * coverage rule. Shown to no client.
   */
  confidence: {
    levels: { level: Confidence; min_domains: number }[];
    otherwise: Confidence;
    below_coverage: Confidence;
  };
  /** The ages the population check of the score covers. Not read by the engine. */
  population_check?: { min_age: number; max_age: number };
}

/** The specification the score runs on (data/score-spec.json). */
export const SCORE_SPEC: ScoreSpec = specFile as unknown as ScoreSpec;

/** The key a marker's `rows` map is read with: the picked row's sex, lower case, and its age group as stored. */
export function rowEligibilityKey(row: { sex: string | null; age_group_en: string | null }): string {
  return `${(row.sex ?? "").toLowerCase()}|${row.age_group_en ?? ""}`;
}

const sameBound = (a: unknown, b: number | null): boolean => {
  const x = a == null || a === "" ? null : Number(a);
  if (x === null || b === null) return x === b;
  return Number.isFinite(x) && Math.abs(x - b) <= 1e-9 * Math.max(1, Math.abs(b));
};

/**
 * Whether a marker's picked row may score under the specification: the marker has a weight, the row is listed as
 * eligible, and its optimal bounds are the bounds the grade was given on. A row that is not the graded row (an
 * earlier row under the same sex and age group, or one changed since) does not score.
 */
function rowEligible(marker: ScoreSpecMarker, row: { sex: string | null; age_group_en: string | null } & Pick<ReviewedRange, "optimal_low" | "optimal_high">): boolean {
  const entry = marker.rows[rowEligibilityKey(row)];
  return (
    marker.weight != null &&
    entry?.eligible === true &&
    sameBound(row.optimal_low, entry.optimal_low) &&
    sameBound(row.optimal_high, entry.optimal_high)
  );
}

export interface BiomarkerInput {
  code: string;
  value: number;
  /**
   * The limits this result was classified and is displayed against, when the interpretation gives them (a state or
   * pre-analytical rule can move them: triglycerides not confirmed fasting read against 175 mg/dL). The marker is
   * then charged on these, never re-read against the picked row, so a result costs what its displayed category
   * says. Absent: the picked row's own bounds. Limits with no bound at all: the result is not scored.
   */
  limits?: ReviewedRange;
}

export interface MarkerScore {
  code: string;
  name: string;
  value: number;
  unit: string;
  zone: Zone;
  rawPenalty: number;
  weightedPenalty: number;
  /** The marker's weight (ScoreSpecMarker.weight). */
  weight: number;
  optimalLow: number | null;
  optimalHigh: number | null;
  category: string;
  lsPointsImpact: number;
  suppressed: boolean;
  suppressedBy: string | null;
}

export interface DomainCoverage {
  domain: string;
  description: string;
  covered: boolean;
  markersPresent: string[];
  markersPossible: Set<string>;
}

export interface ValidationResult {
  valid: boolean;
  /** The markers that score for the person: after the redundancy groups, row eligibility and the exclusions. */
  totalMarkers: number;
  domainsCovered: number;
  domainsRequired: number;
  domainDetails: DomainCoverage[];
  missingDomains: string[];
  errorMessage: string | null;
}

export interface FullResult {
  confidence: Confidence;
  chronologicalAge: number;
  validation: ValidationResult;
  longevityScore: number;
  lsPenaltyPoints: number;
  lsGrade: string;
  netPenaltyRatio: number;
  totalWeightedPenalty: number;
  maxPossibleWeightedPenalty: number;
  markerScores: MarkerScore[];
  suppressedMarkers: MarkerScore[];
  markersMeasured: number;
  markersScored: number;
  markersAvailable: number;
  /** Why there is no score although values were given (ScoreContext); null when the score was not withheld. */
  withheld: { reason: WithheldReason } | null;
  /** The cap that lowered this score (OUT_OF_RANGE_CAP); null when none did. */
  cap: ScoreCap | null;
  /**
   * Present markers that would score and that a rule takes out of the score for this result (a declared state,
   * fasting not confirmed, the HbA1c exclusion): no penalty, no cap, not counted for coverage. A marker another
   * member of its group replaces is in suppressedMarkers instead.
   */
  excludedMarkers: ExcludedMarker[];
}

// ─── Context: withholding and state exclusions ───

/**
 * Why a score is withheld. When several hold, the first of this order is the reason: the critical tier is
 * evaluated before any state rule.
 */
export type WithheldReason = "critical_value" | "pregnancy" | "lactation";

/** What the lab's interpretation tells the score beyond the values. Everything is optional: absent means not declared. */
export interface ScoreContext {
  /** The lab's declared physiological state (patient-context/physiological-state.ts); only these two fields are read. */
  state?: { pregnancy?: boolean; lactation?: boolean } | null;
  /** Oral oestrogen declared: hormone therapy by mouth or oral contraception (state-rules.md 4.2). */
  oralOestrogen?: boolean;
  /**
   * A value of this lab, scored or not, is in the critical tier. Processing computes it over every value of the lab
   * (isCriticalValue); the engine also checks the values it is given against their rows' critical fields.
   */
  criticalTier?: boolean;
  /**
   * The lab's context confirms the sample was taken fasting. Absent or false: not confirmed, and a marker that
   * requires it (fasting glucose) does not score.
   */
  confirmedFasting?: boolean;
  /**
   * The HbA1c exclusion of the biological age holds for this result (glycation-exclusion.ts: anaemia, iron
   * deficiency or an eGFR below 30). HbA1c is then passed over, and the next member of its group may score.
   */
  hba1cExcluded?: boolean;
}

export interface ScoreCap {
  /** The highest score the cap allows: the top of the grade below the top grade (GRADES). */
  level: number;
  /** That grade. */
  grade: string;
  /** The score these values give without the cap. */
  uncappedScore: number;
  /** The scored markers outside their reference interval, the costliest first: the markers that hold the score. */
  markers: string[];
}

export interface ExcludedMarker {
  code: string;
  reason: "oral_oestrogen" | "fasting_not_confirmed" | "hba1c_exclusion";
}

/** The reason the context alone withholds the score for, or null. */
export function withheldByContext(context: ScoreContext | null | undefined): WithheldReason | null {
  if (context?.criticalTier) return "critical_value";
  if (context?.state?.pregnancy) return "pregnancy";
  if (context?.state?.lactation) return "lactation";
  return null;
}

/** The critical fields of a row, where it carries them. */
export interface CriticalFields {
  critical_low?: number | null;
  critical_high?: number | null;
}

const criticalField = (x: unknown): number | null => {
  if (x == null || x === "") return null;
  const n = Number(x);
  return Number.isFinite(n) ? n : null;
};

/**
 * Whether a value is in the critical tier of its row: at or below the row's critical_low, at or above its
 * critical_high. The only trigger is a critical field; the reference interval never is one, and a row without
 * critical fields has no critical tier. A bounded result ("<20", ">1000") is critical only when its bound already
 * lies at or beyond the limit on its own side; one that only might be critical is not.
 */
export function isCriticalValue(value: number, row: CriticalFields | null | undefined, comparator?: "<" | ">" | null): boolean {
  if (!row || !Number.isFinite(value)) return false;
  const low = criticalField(row.critical_low);
  const high = criticalField(row.critical_high);
  if (low != null && comparator !== ">" && value <= low) return true;
  if (high != null && comparator !== "<" && value >= high) return true;
  return false;
}

// With oral oestrogen declared (state-rules.md 4.2): hs-CRP is not a score input, and triglycerides lose their
// optimal band and are charged only outside the reference limit they are displayed against.
const ORAL_OESTROGEN_NOT_SCORED: ReadonlySet<string> = new Set(["HSCRP"]);
const ORAL_OESTROGEN_REFERENCE_ONLY: ReadonlySet<string> = new Set(["TG"]);

// ─── Redundancy groups ───
//
// A literal copy of the specification's groups: the acceptance test's runner reads this block from the source
// text. The engine reads the specification; score-spec.test.ts holds the two equal.

export const REDUNDANT_GROUPS = [
  { name: "Atherogenic particles", priorityOrder: ["APOB", "NON_HDL", "LDL_C"] },
  { name: "Glycaemia", priorityOrder: ["HBA1C", "GLUCOSE"] },
  { name: "Kidney filtration", priorityOrder: ["EGFR"] },
  { name: "Liver enzymes", priorityOrder: ["ALT", "GGT"] },
  { name: "Red cell mass", priorityOrder: ["HGB"] },
  { name: "White cells", priorityOrder: ["WBC"] },
];

// ─── Penalty on the reviewed ranges (score v2) ───
//
// A marker's penalty, as a fraction of its weight, follows the three categories of classifyZone
// (zone-classifier.ts), one side of the row at a time. With the specification's curve (penalty_curve: 0.4 at the
// reference limit, exponent 2, 25% width where a side has no band, 1 at most):
//   optimal        0
//   in range       0.4 × (d / band)²          d: distance past the optimal bound; band: from that bound
//                                             to the reference limit on the same side
//   out of range   0.4 + 0.6 × min(e / w, 1)  e: distance past the reference limit; w: the band on that
//                                             side, or 25% of |limit| when the side has no band
// A side with an optimal bound but no reference limit (eGFR from 60: above 105) is in range only:
// 0.4 × min(d / (25% of |bound|), 1)². Both limits are continuous: 0 at the optimal bound, 0.4 where in
// range meets out of range. A side with no band (optimal and reference share the limit, as vitamin D's
// 30 ng/mL) steps from 0 to 0.4 there, exactly where its category steps from optimal to out of range.
// (A reference floor of 0 with no band has no width: only a negative value is past it, at 1.)

/** The bounds of a reviewed biomarker_references row. */
export interface ReviewedRange {
  optimal_low: number | null;
  optimal_high: number | null;
  normal_low: number | null;
  normal_high: number | null;
}

type PenaltyCurve = ScoreSpec["penalty_curve"];

function inRangePenalty(d: number, band: number | null, bound: number, c: PenaltyCurve): number {
  const width = band ?? c.no_band_width * Math.abs(bound);
  return width > 0 ? c.at_reference_limit * Math.min(d / width, 1) ** c.in_range_exponent : c.at_reference_limit;
}

function outOfRangePenalty(e: number, band: number | null, limit: number, c: PenaltyCurve): number {
  const width = band != null && band > 0 ? band : c.no_band_width * Math.abs(limit);
  return c.at_reference_limit + (c.max - c.at_reference_limit) * (width > 0 ? Math.min(e / width, 1) : 1);
}

export function reviewedPenalty(v: number, row: ReviewedRange, curve: PenaltyCurve = SCORE_SPEC.penalty_curve): number {
  const { optimal_low: oL, optimal_high: oH, normal_low: nL, normal_high: nH } = row;
  switch (classifyReviewedZone(v, oL, oH, nL, nH)) {
    case "critical_low":
      return outOfRangePenalty(nL! - v, oL == null ? null : oL - nL!, nL!, curve);
    case "critical_high":
      return outOfRangePenalty(v - nH!, oH == null ? null : nH! - oH, nH!, curve);
    case "below_optimal":
      return inRangePenalty(oL! - v, nL == null ? null : oL! - nL, oL!, curve);
    case "above_optimal":
      return inRangePenalty(v - oH!, nH == null ? null : nH - oH!, oH!, curve);
    default:
      return 0; // optimal (a row with no bounds is never scored)
  }
}

// ─── Validation ───

/**
 * The coverage rule, over the markers that score for the person: the present markers left after the redundancy
 * groups, row eligibility and the exclusions. A marker another one replaces, or one that cannot score, counts
 * toward neither minimum and covers no domain.
 */
function validateMarkers(scoring: ReadonlySet<string>, coverage: ScoreSpec["coverage"]): ValidationResult {
  const domainDetails: DomainCoverage[] = [];
  let dc = 0;
  const missing: string[] = [];
  const domains = Object.entries(coverage.domains);

  for (const [dn, dd] of domains) {
    const possible = new Set(dd.markers);
    const present = [...scoring].filter((c) => possible.has(c));
    const covered = present.length >= dd.min_count;
    if (covered) dc++;
    else missing.push(dn);
    domainDetails.push({ domain: dn, description: dd.description, covered, markersPresent: present.sort(), markersPossible: possible });
  }

  const t = scoring.size;
  const ok = t >= coverage.min_markers && dc >= coverage.min_domains;
  let err: string | null = null;
  if (!ok) {
    const parts: string[] = [];
    if (t < coverage.min_markers) parts.push(`Need ${coverage.min_markers}+ markers, got ${t}.`);
    if (dc < coverage.min_domains) parts.push(`Need ${coverage.min_domains}/${domains.length} domains, got ${dc}.`);
    err = parts.join(" ");
  }

  return { valid: ok, totalMarkers: t, domainsCovered: dc, domainsRequired: coverage.min_domains, domainDetails, missingDomains: missing, errorMessage: err };
}

/**
 * In each group the first present member that can score for the person (it has a rule: its picked row exists, is
 * eligible and has bounds, and no state excludes it) and that no rule of the result passes over (`blocked`: fasting
 * not confirmed, the HbA1c exclusion) scores, and every other present member that has a rule is suppressed by it,
 * except a passed-over member ahead of it in the order: that one is not replaced, it is excluded for its own
 * reason. A group none of whose present members can score suppresses nothing, and none of them scores.
 */
function resolveRedundancies(
  codes: ReadonlySet<string>,
  rules: ReadonlyMap<string, MarkerRule>,
  groups: readonly ScoreSpecGroup[],
  blocked: ReadonlyMap<string, ExcludedMarker["reason"]>,
): Record<string, string> {
  const sup: Record<string, string> = {};
  for (const g of groups) {
    const best = g.priority_order.findIndex((c) => codes.has(c) && rules.has(c) && !blocked.has(c));
    if (best < 0) continue;
    g.priority_order.forEach((c, i) => {
      if (i === best || !codes.has(c) || !rules.has(c)) return;
      if (blocked.has(c) && i < best) return;
      sup[c] = g.priority_order[best];
    });
  }
  return sup;
}

function assessConfidence(valid: boolean, dc: number, rule: ScoreSpec["confidence"]): Confidence {
  if (!valid) return rule.below_coverage;
  return rule.levels.find((l) => dc >= l.min_domains)?.level ?? rule.otherwise;
}

// ─── Score conversions ───

function netRatioToLongevityScore(netRatio: number, c: ScoreSpec["score_curve"]): number {
  const raw = c.scale * Math.exp(-c.k * netRatio);
  return Math.max(c.floor, Math.min(c.ceiling, Math.round(raw)));
}

// The grade table is the specification's, top grade first: a score has the first grade whose minimum it reaches.
// The lowest grade is "Needs attention" (Gate 1: a low score is not a laboratory critical value). Scores stored
// before that rename carry "Critical"; the dashboard shows both as "Needs attention" / "Requiere atención"
// (dashboard-format.ts).
function longevityGrade(score: number, grades: ScoreSpec["grades"]): string {
  return (grades.find((g) => score >= g.min) ?? grades[grades.length - 1]).label;
}

/**
 * The cap of a specification: the grade it names (caps.out_of_range.grade) and the highest score of that grade,
 * read from the grade table (scores are whole numbers, so it is one below the minimum of the grade above), never
 * written as a number.
 */
function outOfRangeCap(spec: ScoreSpec): { readonly level: number; readonly grade: string } {
  const i = spec.grades.findIndex((g) => g.label === spec.caps.out_of_range.grade);
  if (i < 1) throw new Error(`score specification: the cap's grade "${spec.caps.out_of_range.grade}" must be a grade below the top grade`);
  return { level: spec.grades[i - 1].min - 1, grade: spec.grades[i].label };
}

/**
 * While any scored marker is outside its reference interval the score is at most the top of the grade below the
 * top grade. Only a marker that scores triggers it: a suppressed, excluded or unscored marker never changes the
 * score.
 */
export const OUT_OF_RANGE_CAP: { readonly level: number; readonly grade: string } = outOfRangeCap(SCORE_SPEC);

// ─── Main engine ───

/** How one marker is scored for this person: its weight, optimal band, category and penalty. */
interface MarkerRule {
  code: string;
  def: ScoreSpecMarker;
  weight: number;
  optimalLow: number | null;
  optimalHigh: number | null;
  zone: (v: number) => Zone;
  penalty: (v: number) => number;
}

/**
 * The engine. `rules` are the markers the specification can score for this person. Weights, domains, redundancy
 * and the score curve are the specification's. The score is the curve of the weighted penalties over the largest
 * penalty the scoring markers could have: nothing offsets a penalty.
 */
function scoreWithRules(
  results: BiomarkerInput[],
  spec: ScoreSpec,
  rules: ReadonlyMap<string, MarkerRule>,
  chronologicalAge: number,
  withheld: WithheldReason | null,
  excludedByState: ExcludedMarker[],
  blocked: ReadonlyMap<string, ExcludedMarker["reason"]>,
): FullResult {
  const codes = new Set(results.filter((r) => r.code in spec.markers).map((r) => r.code));
  // The markers that score: present, scorable for the person, not passed over by a rule of the result, and not
  // replaced by a member of their group.
  const sups = resolveRedundancies(codes, rules, spec.groups, blocked);
  const scoring = new Set([...codes].filter((c) => rules.has(c) && !(c in sups) && !blocked.has(c)));
  // A present marker that would score but for a rule of the result is excluded, with the rule as the reason.
  const excludedMarkers: ExcludedMarker[] = [
    ...excludedByState,
    ...[...codes].filter((c) => rules.has(c) && blocked.has(c) && !(c in sups)).sort().map((code) => ({ code, reason: blocked.get(code)! })),
  ];
  const val = validateMarkers(scoring, spec.coverage);
  const toScore = (ratio: number) => netRatioToLongevityScore(ratio, spec.score_curve);
  const capRule = outOfRangeCap(spec);

  const empty: FullResult = {
    confidence: spec.confidence.below_coverage, chronologicalAge, validation: val,
    longevityScore: -1, lsPenaltyPoints: 0,
    lsGrade: "Insufficient Data", netPenaltyRatio: 0,
    totalWeightedPenalty: 0, maxPossibleWeightedPenalty: 0,
    markerScores: [], suppressedMarkers: [],
    markersMeasured: codes.size, markersScored: 0, markersAvailable: 0,
    withheld: null, cap: null, excludedMarkers,
  };

  // Withheld: nothing is computed, whatever the values would give.
  if (withheld) return { ...empty, lsGrade: WITHHELD_GRADE, withheld: { reason: withheld } };
  if (!val.valid) return empty;

  const scored: MarkerScore[] = [];
  const suppressed: MarkerScore[] = [];
  let twp = 0, mwp = 0;
  const exact: { wp: number; out: boolean }[] = []; // per scored marker, unrounded

  for (const res of results) {
    const rule = rules.get(res.code);
    if (!rule) continue;
    const isSup = res.code in sups;
    if (!isSup && blocked.has(res.code)) continue; // excluded: neither scored nor replaced
    const md = rule.def;

    const w = rule.weight;
    const z = rule.zone(res.value);
    const rp = rule.penalty(res.value);
    const wp = rp * w;

    const s: MarkerScore = {
      code: res.code, name: md.name, value: res.value, unit: md.unit,
      zone: z, rawPenalty: round4(rp), weightedPenalty: round4(wp),
      weight: w,
      optimalLow: rule.optimalLow, optimalHigh: rule.optimalHigh,
      category: md.category, lsPointsImpact: 0,
      suppressed: isSup, suppressedBy: sups[res.code] ?? null,
    };

    if (isSup) {
      suppressed.push(s);
    } else {
      // Out of range means outside the reference interval the result is displayed against.
      const out = z === "critical_low" || z === "critical_high";
      scored.push(s);
      exact.push({ wp, out });
      twp += wp;
      mwp += spec.penalty_curve.max * w;
    }
  }

  const nr = mwp > 0 ? twp / mwp : 0;

  // Longevity Score, held at the cap while any scored marker is outside its reference interval.
  const uncapped = toScore(nr);
  const capped = (score: number, anyOut: boolean) => (anyOut ? Math.min(score, capRule.level) : score);
  const outCount = exact.filter((e) => e.out).length;
  const ls = capped(uncapped, outCount > 0);
  const lsGrade = longevityGrade(ls, spec.grades);
  const cap: ScoreCap | null = ls < uncapped
    ? {
        level: capRule.level, grade: capRule.grade, uncappedScore: uncapped,
        markers: scored
          .map((s, i) => ({ code: s.code, ...exact[i] }))
          .filter((m) => m.out)
          .sort((a, b) => b.wp - a.wp)
          .map((m) => m.code),
      }
    : null;

  // LS per-marker impact: the score these values would have if this marker cost nothing.
  if (mwp > 0) {
    for (const [i, s] of scored.entries()) {
      const e = exact[i];
      const hypLs = capped(toScore((twp - e.wp) / mwp), outCount - (e.out ? 1 : 0) > 0);
      s.lsPointsImpact = round1(hypLs - ls);
    }
  }

  const conf = assessConfidence(val.valid, val.domainsCovered, spec.confidence);

  // Penalty points describe the score before the cap (cap.uncappedScore when a cap applied).
  const lsPenPts = round1(spec.score_curve.ceiling - uncapped);

  return {
    confidence: conf, chronologicalAge, validation: val,
    longevityScore: ls, lsPenaltyPoints: lsPenPts,
    lsGrade, netPenaltyRatio: round4(nr),
    totalWeightedPenalty: round4(twp), maxPossibleWeightedPenalty: round4(mwp),
    markerScores: scored, suppressedMarkers: suppressed,
    markersMeasured: codes.size, markersScored: scored.length, markersAvailable: rules.size,
    withheld: null, cap, excludedMarkers,
  };
}

/** The grade field of a withheld result: not a grade, and never stored (the caller stores null). */
const WITHHELD_GRADE = "Withheld";

// ─── The score on the reviewed ranges ───

/** A biomarker_references row as processing loads it. */
export interface ReviewedRow extends ReviewedRange, CriticalFields {
  biomarker_key: string;
  sex: string | null;
  age_group_en: string | null;
}

/**
 * The reviewed row each engine code reads: the key its results are stored and classified under. Only the codes that
 * score or can take a group's place are here. A literal copy of the specification's keys, which the acceptance
 * test's runner imports. The engine reads the specification; score-spec.test.ts holds the two equal.
 */
export const REVIEWED_ROW_KEY: Readonly<Record<string, string>> = {
  APOB: "apolipoprotein_b_apob", NON_HDL: "non_hdl_cholesterol", LDL_C: "ldl_cholesterol", HDL_C: "hdl_cholesterol",
  TG: "triglycerides", HBA1C: "hba1c", GLUCOSE: "glucose_fasting", URIC_ACID: "uric_acid", HSCRP: "hs_crp",
  WBC: "white_blood_cell_count", HGB: "hemoglobin", ALT: "alt", GGT: "ggt", ALP: "alp", ALBUMIN: "albumin",
  EGFR: "egfr_creatinine_based", VITD: "vitamin_d_25_oh",
};

/**
 * The longevity score: the engine above, with each marker's range taken from the reviewed row picked for
 * the person (pickReferenceRows, the rule processing classifies with). A result is optimal, in range or out
 * of range in the score exactly as on its page, and costs nothing exactly when it is optimal. A marker whose
 * row is missing, has no bounds or is not eligible under the specification is not scored; in a redundancy group
 * the first present member that can score does, and the others are suppressed by it. A score is given only when
 * the markers that actually score meet the specification's coverage rule (FullResult.validation). There is no
 * bonus: the score is 100 when every scoring marker is optimal. `rows` are biomarker_references rows (processing
 * passes every row for the person's sex and "both"); the function reads nothing else.
 *
 * With a `context` (ScoreContext):
 *   - no score (`withheld`, longevityScore -1) while a value is in the critical tier (context.criticalTier, or any
 *     value given here at or beyond a critical field of its picked row, scored or not), and in declared pregnancy
 *     or lactation;
 *   - with oral oestrogen declared, hs-CRP is not scored (no penalty, no cap, not counted for coverage) and
 *     triglycerides are charged only outside their reference limit, with no optimal band;
 *   - a marker that requires fasting (fasting glucose) scores only with context.confirmedFasting, and with none
 *     given it does not score (fail closed);
 *   - with context.hba1cExcluded, HbA1c is passed over and the next member of its group may score.
 * With or without one, a scored marker outside its reference interval holds the score at OUT_OF_RANGE_CAP (`cap`),
 * and a result that carries its own `limits` is charged on those.
 *
 * `spec` is the specification to score with; callers leave it out and get SCORE_SPEC (tests pass their own).
 */
export function calculateLongevityScoreV2(
  results: BiomarkerInput[],
  sex: "male" | "female",
  chronologicalAge: number,
  rows: readonly ReviewedRow[],
  context?: ScoreContext | null,
  spec: ScoreSpec = SCORE_SPEC,
): FullResult {
  const picked = pickReferenceRows(rows, sex, chronologicalAge).picked;
  const oralOestrogen = context?.oralOestrogen === true;

  // The critical tier comes first, over every value given, whatever the state and whether or not it scores.
  const criticalHere = results.some((r) => {
    const key = spec.markers[r.code]?.key;
    return key !== undefined && isCriticalValue(r.value, picked.get(key));
  });
  const withheld: WithheldReason | null = criticalHere ? "critical_value" : withheldByContext(context);

  const rules = new Map<string, MarkerRule>();
  const excluded: ExcludedMarker[] = [];
  // Markers a rule of this result passes over: they keep their rule, score nothing and take no member's place.
  const blocked = new Map<string, ExcludedMarker["reason"]>();
  for (const [code, def] of Object.entries(spec.markers)) {
    const row = picked.get(def.key);
    if (def.weight == null || !row || !rowEligible(def, row)) continue;
    const input = results.find((r) => r.code === code);
    if (oralOestrogen && ORAL_OESTROGEN_NOT_SCORED.has(code)) {
      if (input) excluded.push({ code, reason: "oral_oestrogen" });
      continue;
    }
    if (def.requires_confirmed_fasting && context?.confirmedFasting !== true) blocked.set(code, "fasting_not_confirmed");
    if (def.passed_over_on_hba1c_exclusion && context?.hba1cExcluded === true) blocked.set(code, "hba1c_exclusion");
    // The limits the result is displayed against, when the interpretation gave them; else the picked row's.
    const shown: ReviewedRange = input?.limits ?? row;
    const referenceOnly = oralOestrogen && ORAL_OESTROGEN_REFERENCE_ONLY.has(code);
    const range: ReviewedRange = {
      optimal_low: referenceOnly ? null : shown.optimal_low,
      optimal_high: referenceOnly ? null : shown.optimal_high,
      normal_low: shown.normal_low,
      normal_high: shown.normal_high,
    };
    const { optimal_low: oL, optimal_high: oH, normal_low: nL, normal_high: nH } = range;
    if (oL == null && oH == null && nL == null && nH == null) continue;
    rules.set(code, {
      code, def, weight: def.weight, optimalLow: oL, optimalHigh: oH,
      // Never "unclassified": a range with no bounds was skipped above.
      zone: (v) => classifyReviewedZone(v, oL, oH, nL, nH) as Zone,
      penalty: (v) => reviewedPenalty(v, range, spec.penalty_curve),
    });
  }
  return scoreWithRules(results, spec, rules, chronologicalAge, withheld, excluded, blocked);
}

function round1(n: number): number { return Math.round(n * 10) / 10; }
function round4(n: number): number { return Math.round(n * 10000) / 10000; }
