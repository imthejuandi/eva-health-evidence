/**
 * KDM adapter — maps eva-health biomarker codes to KDM library Spanish keys.
 *
 * The KDM library (`./data/marker_library_v2_2.json`) is keyed by Spanish
 * marker names (e.g., "Apolipoproteína B (ApoB)"). The eva-health pipeline
 * uses two parallel identifier conventions for the same markers:
 *
 *   1. ENGINE codes — uppercase (e.g., "APOB", "VITD"). Used by the
 *      longevity-score `buildRegistry()` and the inputs to
 *      `calculateLongevityScore`.
 *   2. DB keys — snake_case slugs of the English display name (e.g.,
 *      "apolipoprotein_b_apob", "vitamin_d_25_oh"). Used in the
 *      `biomarker_references` table and produced by `name-matcher.ts`.
 *
 * This adapter accepts either form on input and emits a Spanish-keyed map
 * suitable for the KDM estimator. Units are checked against the library's
 * declared unit per marker; mismatches go through the conversion table or
 * are flagged as `unconverted` (and the marker is dropped from the output).
 *
 * Status: B.4 — adapter implementation. The estimator (B.5) is the next
 * consumer; for now this module is unit-testable in isolation.
 *
 * See plan: /Users/jdl/.claude/plans/glowing-mixing-cray.md §B.4
 */

import type { BiomarkerInput } from "./longevity-score";

// ─── Public types ───

/** KDM library primary key — Spanish marker name. */
export type KdmMarkerKey = string;

export interface KdmAdapterResult {
  /** Spanish-keyed input map ready for the KDM joint estimator. */
  inputs: Record<KdmMarkerKey, number>;
  /** Markers we skipped because no eva-code → KDM-key mapping exists. */
  skipped: string[];
  /**
   * Markers where the eva engine unit and KDM library unit differ and no
   * conversion factor is registered. These are dropped from `inputs` to
   * avoid feeding the estimator a wrong-unit number.
   */
  unconverted: KdmMarkerKey[];
  /**
   * Markers whose value was unit-converted (engine unit ≠ KDM unit and a
   * conversion factor was applied). Useful for diagnostics.
   */
  converted: KdmMarkerKey[];
}

// ─── Mapping table ───
// engine code (uppercase) OR DB key (snake_case) → KDM Spanish marker key.

/**
 * Urea → BUN: BUN is urea's nitrogen fraction, BUN = Urea × 28/60 ≈ 0.4665, both in mg/dL. The one factor the
 * app uses for it: the `urea` entry below (KDM v2.2) and the biological age v3 adapter
 * (`biological-age-v3-adapter.ts`) both read this constant.
 */
export const UREA_TO_BUN_FACTOR = 0.4665;

interface AdapterEntry {
  /** KDM library primary key (Spanish marker name). */
  kdm: KdmMarkerKey;
  /** Canonical eva-health engine input unit for this marker. */
  engineUnit: string;
  /** Unit declared in the KDM library `markers[name].unit`. */
  kdmUnit: string;
  /**
   * Cross-molecule scaling factor applied AFTER unit normalization.
   *
   * Used when an eva-health biomarker is a different molecule than the
   * KDM library marker but is biochemically linked by a fixed ratio.
   * The only current case: Urea (the whole molecule) vs. BUN (its
   * nitrogen fraction): BUN = Urea × 28/60 ≈ 0.4665. The eva-health
   * `urea` row stores Urea in mg/dL; KDM is anchored on BUN in mg/dL;
   * so this factor scales the input down before feeding the joint
   * estimator.
   *
   * Kept separate from CONVERSION_FACTORS (which handles same-molecule
   * unit-system conversions like μ↔u or hormone IU equivalences) so
   * the unit table doesn't accumulate fake unit strings.
   */
  crossMoleculeFactor?: number;
}

// LOCKED canonical mapping. New entries: confirm engineUnit against
// `canonical-units.ts` / `buildRegistry()` AND kdmUnit against the library
// before adding. If the two differ, register the conversion in
// `convertUnit()` below.
const CODE_TO_KDM: Record<string, AdapterEntry> = {
  // ── Lipids (T1/T2) ──
  APOB: { kdm: "Apolipoproteína B (ApoB)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  apolipoprotein_b: { kdm: "Apolipoproteína B (ApoB)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  apolipoprotein_b_apob: { kdm: "Apolipoproteína B (ApoB)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  LDL_C: { kdm: "Colesterol LDL", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  ldl_cholesterol: { kdm: "Colesterol LDL", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  HDL_C: { kdm: "Colesterol HDL", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  hdl_cholesterol: { kdm: "Colesterol HDL", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  TG: { kdm: "Triglicéridos", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  triglycerides: { kdm: "Triglicéridos", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  LPA: { kdm: "Lipoproteína(a)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  lipoprotein_a: { kdm: "Lipoproteína(a)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  lipoproteina: { kdm: "Lipoproteína(a)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  // Total cholesterol & ApoA1 — outside the 39 engine codes but in KDM base panel.
  // Use only the DB-key form; engine has no code for these.
  total_cholesterol: { kdm: "Colesterol Total", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  apolipoprotein_a1: { kdm: "Apolipoproteína A1 (ApoA1)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  apolipoprotein_a1_apoa1: { kdm: "Apolipoproteína A1 (ApoA1)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  // ── Metabolic ──
  HBA1C: { kdm: "HbA1c (Hemoglobina Glicosilada)", engineUnit: "%", kdmUnit: "%" },
  hba1c: { kdm: "HbA1c (Hemoglobina Glicosilada)", engineUnit: "%", kdmUnit: "%" },

  GLUCOSE: { kdm: "Glucosa (Ayunas)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  glucose_fasting: { kdm: "Glucosa (Ayunas)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  INSULIN: { kdm: "Insulina (Ayunas)", engineUnit: "µU/mL", kdmUnit: "μU/mL" },
  fasting_insulin: { kdm: "Insulina (Ayunas)", engineUnit: "µU/mL", kdmUnit: "μU/mL" },
  insulin_fasting: { kdm: "Insulina (Ayunas)", engineUnit: "µU/mL", kdmUnit: "μU/mL" },

  // HOMA-IR and NLR are computed ratios — not in KDM library, intentionally skipped.

  // ── Inflammation ──
  HSCRP: { kdm: "PCR de Alta Sensibilidad (hs-PCR)", engineUnit: "mg/L", kdmUnit: "mg/L" },
  hs_crp: { kdm: "PCR de Alta Sensibilidad (hs-PCR)", engineUnit: "mg/L", kdmUnit: "mg/L" },

  // ── Kidney ──
  EGFR: { kdm: "TFGe (basada en Creatinina)", engineUnit: "mL/min/1.73m²", kdmUnit: "mL/min/1.73m²" },
  egfr: { kdm: "TFGe (basada en Creatinina)", engineUnit: "mL/min/1.73m²", kdmUnit: "mL/min/1.73m²" },
  egfr_creatinine_based: { kdm: "TFGe (basada en Creatinina)", engineUnit: "mL/min/1.73m²", kdmUnit: "mL/min/1.73m²" },

  CREATININE: { kdm: "Creatinina", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  creatinine: { kdm: "Creatinina", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  URIC_ACID: { kdm: "Ácido Úrico", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  uric_acid: { kdm: "Ácido Úrico", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  // BUN — base panel marker, not in engine codes.
  blood_urea_nitrogen: { kdm: "BUN (Nitrógeno Ureico en Sangre)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  bun: { kdm: "BUN (Nitrógeno Ureico en Sangre)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  // Base Panel glycation marker (Echevarne FRUC → B0158, µmol/L).
  FRUCTOSAMINE: { kdm: "Fructosamina", engineUnit: "µmol/L", kdmUnit: "μmol/L" },
  fructosamine: { kdm: "Fructosamina", engineUnit: "µmol/L", kdmUnit: "μmol/L" },

  // Urea — same biology as BUN but reported as the whole molecule (EU
  // convention). Feeds the same KDM marker via a cross-molecule scale
  // factor (BUN = Urea × 28/60 ≈ 0.4665) applied AFTER unit
  // normalization.
  urea: {
    kdm: "BUN (Nitrógeno Ureico en Sangre)",
    engineUnit: "mg/dL",
    kdmUnit: "mg/dL",
    crossMoleculeFactor: UREA_TO_BUN_FACTOR,
  },

  // Cystatin C — not in engine codes but in KDM.
  cystatin_c: { kdm: "Cistatina C", engineUnit: "mg/L", kdmUnit: "mg/L" },

  // ── Liver ──
  ALT: { kdm: "ALT (Alanina Aminotransferasa)", engineUnit: "U/L", kdmUnit: "U/L" },
  alt: { kdm: "ALT (Alanina Aminotransferasa)", engineUnit: "U/L", kdmUnit: "U/L" },

  AST: { kdm: "AST (Aspartato Aminotransferasa)", engineUnit: "U/L", kdmUnit: "U/L" },
  ast: { kdm: "AST (Aspartato Aminotransferasa)", engineUnit: "U/L", kdmUnit: "U/L" },

  GGT: { kdm: "GGT (Gamma-glutamil Transferasa)", engineUnit: "U/L", kdmUnit: "U/L" },
  ggt: { kdm: "GGT (Gamma-glutamil Transferasa)", engineUnit: "U/L", kdmUnit: "U/L" },

  ALBUMIN: { kdm: "Albúmina", engineUnit: "g/L", kdmUnit: "g/dL" },
  albumin: { kdm: "Albúmina", engineUnit: "g/L", kdmUnit: "g/dL" },

  BILIRUBIN: { kdm: "Bilirrubina Total", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  total_bilirubin: { kdm: "Bilirrubina Total", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  ALP: { kdm: "ALP (Fosfatasa Alcalina)", engineUnit: "U/L", kdmUnit: "U/L" },
  alkaline_phosphatase: { kdm: "ALP (Fosfatasa Alcalina)", engineUnit: "U/L", kdmUnit: "U/L" },
  alp: { kdm: "ALP (Fosfatasa Alcalina)", engineUnit: "U/L", kdmUnit: "U/L" },

  // ── Hematology ──
  RDW: { kdm: "ADE (Amplitud de Distribución Eritrocitaria)", engineUnit: "%", kdmUnit: "%" },
  rdw: { kdm: "ADE (Amplitud de Distribución Eritrocitaria)", engineUnit: "%", kdmUnit: "%" },

  HGB: { kdm: "Hemoglobina", engineUnit: "g/dL", kdmUnit: "g/dL" },
  hemoglobin: { kdm: "Hemoglobina", engineUnit: "g/dL", kdmUnit: "g/dL" },

  MCV: { kdm: "VCM (Volumen Corpuscular Medio)", engineUnit: "fL", kdmUnit: "fL" },
  mcv: { kdm: "VCM (Volumen Corpuscular Medio)", engineUnit: "fL", kdmUnit: "fL" },

  WBC: { kdm: "Recuento de Glóbulos Blancos", engineUnit: "/µL", kdmUnit: "×10³/μL" },
  white_blood_cell_count: { kdm: "Recuento de Glóbulos Blancos", engineUnit: "/µL", kdmUnit: "×10³/μL" },

  PLT: { kdm: "Recuento de Plaquetas", engineUnit: "/µL", kdmUnit: "×10³/μL" },
  platelet_count: { kdm: "Recuento de Plaquetas", engineUnit: "/µL", kdmUnit: "×10³/μL" },

  LYMPH_PCT: { kdm: "Linfocitos", engineUnit: "%", kdmUnit: "%" },
  lymphocytes: { kdm: "Linfocitos", engineUnit: "%", kdmUnit: "%" },

  // ── Iron ──
  FERRITIN: { kdm: "Ferritina", engineUnit: "ng/mL", kdmUnit: "ng/mL" },
  ferritin: { kdm: "Ferritina", engineUnit: "ng/mL", kdmUnit: "ng/mL" },

  TSAT: { kdm: "Saturación de Hierro (TSAT)", engineUnit: "%", kdmUnit: "%" },
  transferrin_saturation: { kdm: "Saturación de Hierro (TSAT)", engineUnit: "%", kdmUnit: "%" },
  iron_saturation_tsat: { kdm: "Saturación de Hierro (TSAT)", engineUnit: "%", kdmUnit: "%" },

  // ── Hormones ──
  TESTOSTERONE: { kdm: "Testosterona Total", engineUnit: "ng/mL", kdmUnit: "ng/dL" },
  testosterone: { kdm: "Testosterona Total", engineUnit: "ng/mL", kdmUnit: "ng/dL" },
  testosterone_total: { kdm: "Testosterona Total", engineUnit: "ng/mL", kdmUnit: "ng/dL" },

  ESTRADIOL: { kdm: "Estradiol", engineUnit: "pg/mL", kdmUnit: "pg/mL" },
  estradiol: { kdm: "Estradiol", engineUnit: "pg/mL", kdmUnit: "pg/mL" },

  SHBG: { kdm: "SHBG (Globulina Fijadora de Hormonas Sexuales)", engineUnit: "nmol/L", kdmUnit: "nmol/L" },
  shbg: { kdm: "SHBG (Globulina Fijadora de Hormonas Sexuales)", engineUnit: "nmol/L", kdmUnit: "nmol/L" },

  // ── Thyroid ──
  TSH: { kdm: "TSH", engineUnit: "µUI/mL", kdmUnit: "mIU/L" },
  tsh: { kdm: "TSH", engineUnit: "µUI/mL", kdmUnit: "mIU/L" },

  FT4: { kdm: "T4 Libre (Tiroxina)", engineUnit: "ng/dL", kdmUnit: "ng/dL" },
  free_t4: { kdm: "T4 Libre (Tiroxina)", engineUnit: "ng/dL", kdmUnit: "ng/dL" },
  free_t4_thyroxine: { kdm: "T4 Libre (Tiroxina)", engineUnit: "ng/dL", kdmUnit: "ng/dL" },

  FT3: { kdm: "T3 Libre (Triyodotironina)", engineUnit: "pg/mL", kdmUnit: "pg/mL" },
  free_t3: { kdm: "T3 Libre (Triyodotironina)", engineUnit: "pg/mL", kdmUnit: "pg/mL" },
  free_t3_triiodothyronine: { kdm: "T3 Libre (Triyodotironina)", engineUnit: "pg/mL", kdmUnit: "pg/mL" },

  // ── Nutrients ──
  VITD: { kdm: "Vitamina D (25-OH)", engineUnit: "ng/mL", kdmUnit: "ng/mL" },
  vitamin_d_25_oh: { kdm: "Vitamina D (25-OH)", engineUnit: "ng/mL", kdmUnit: "ng/mL" },

  B12: { kdm: "Vitamina B12 (Cobalamina)", engineUnit: "pg/mL", kdmUnit: "pg/mL" },
  vitamin_b12: { kdm: "Vitamina B12 (Cobalamina)", engineUnit: "pg/mL", kdmUnit: "pg/mL" },

  FOLATE: { kdm: "Folato (Vitamina B9)", engineUnit: "ng/mL", kdmUnit: "ng/mL" },
  folate: { kdm: "Folato (Vitamina B9)", engineUnit: "ng/mL", kdmUnit: "ng/mL" },

  MAGNESIUM: { kdm: "Magnesio (Sérico)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  magnesium: { kdm: "Magnesio (Sérico)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  magnesium_serum: { kdm: "Magnesio (Sérico)", engineUnit: "mg/dL", kdmUnit: "mg/dL" },

  ZINC: { kdm: "Zinc (Sérico)", engineUnit: "µg/dL", kdmUnit: "μg/dL" },
  zinc: { kdm: "Zinc (Sérico)", engineUnit: "µg/dL", kdmUnit: "μg/dL" },
  zinc_serum: { kdm: "Zinc (Sérico)", engineUnit: "µg/dL", kdmUnit: "μg/dL" },

  // Additional KDM-only DB keys for the broader panel (no engine code).
  homocysteine: { kdm: "Homocisteína", engineUnit: "μmol/L", kdmUnit: "μmol/L" },
  fibrinogen: { kdm: "Fibrinógeno", engineUnit: "mg/dL", kdmUnit: "mg/dL" },
  total_protein: { kdm: "Proteínas Totales", engineUnit: "g/L", kdmUnit: "g/dL" },
  globulin: { kdm: "Globulina", engineUnit: "g/dL", kdmUnit: "g/dL" },
  hematocrit: { kdm: "Hematocrito", engineUnit: "%", kdmUnit: "%" },
  red_blood_cell_count: { kdm: "Recuento de Glóbulos Rojos", engineUnit: "/µL", kdmUnit: "×10⁶/μL" },
  // Serum calcium, iron and TIBC: the DB keys are the slugs of the seed names
  // "Calcium (Serum)", "Iron (Serum)", "Iron Binding Capacity (TIBC)" (Echevarne
  // B0010, B0013, B1386). Until 2026-09-25 this map used "calcium", "iron" and
  // "total_iron_binding_capacity", which no DB row carries, so the three never
  // reached the Comprehensive BA. Calcium is stored in mg/L (Echevarne), the
  // library uses mg/dL; iron and TIBC are µg/dL on both sides.
  calcium_serum: { kdm: "Calcio (Sérico)", engineUnit: "mg/L", kdmUnit: "mg/dL" },
  iron_serum: { kdm: "Hierro (Sérico)", engineUnit: "µg/dL", kdmUnit: "μg/dL" },
  iron_binding_capacity_tibc: { kdm: "Capacidad de Fijación del Hierro (TIBC)", engineUnit: "µg/dL", kdmUnit: "μg/dL" },
};

// ─── Unit-conversion helpers ───

/**
 * Convert `value` from `fromUnit` to `toUnit`.
 * Returns the converted number, or `null` if no conversion is registered.
 *
 * Where the engine's canonical unit and the KDM library's unit are the same
 * unit written two ways (the "µ" vs "μ" micro signs, "10³/µL" vs "×10³/μL"),
 * the value passes unchanged. Where they differ — Echevarne's units became
 * the engine's canonical ones on 2026-09-17 — CONVERSION_FACTORS bridges
 * them with decimal shifts only (raw cells/µL to ×10³/µL and ×10⁶/µL, g/L
 * and mg/L to the per-decilitre units, ng/mL to ng/dL).
 *
 * Future-proofs against drift: if a future canonical-units.ts change makes
 * an engineUnit diverge from a kdmUnit (e.g., switching Vitamin D to
 * nmol/L), add the multiplicative factor here, with its basis.
 */
function convertUnit(value: number, fromUnit: string, toUnit: string): number | null {
  if (normalizeUnitString(fromUnit) === normalizeUnitString(toUnit)) return value;

  const key = `${normalizeUnitString(fromUnit)}->${normalizeUnitString(toUnit)}`;
  const factor = CONVERSION_FACTORS[key];
  if (typeof factor === "number") return value * factor;

  return null;
}

/** Collapse micro-sign variants and CBC count formats so identity comparison works. */
function normalizeUnitString(u: string): string {
  return u
    .replace(/μ/g, "µ")           // greek-mu → micro-sign
    .replace(/×10/g, "10")        // "×10³/µL" → "10³/µL"
    .replace(/\s+/g, "")          // strip whitespace
    .toLowerCase();
}

/**
 * Multiplicative factors keyed `<from>-><to>` (both normalized).
 * Each entry represents a numerically-justified conversion. Most current
 * entries are factor 1.0 because the underlying units are dimensionally
 * equivalent under IU ≡ U (the convention for hormone immunoassays):
 *   - 1 mIU/L  ≡ 1 µU/mL   (TSH, FSH, LH, insulin)
 *   - 1 µUI/mL ≡ 1 µU/mL   (Spanish unit notation for the same thing)
 *
 * Add multiplicative conversions here when actual unit *systems* diverge:
 *   "ng/ml->nmol/l": 2.496,   // Vitamin D
 *   "mmol/l->mg/dl": 18.018,  // Glucose (if engine switches to SI)
 */
const CONVERSION_FACTORS: Record<string, number> = {
  // Echevarne's units became eva's canonical on 2026-09-17; the KDM library
  // keeps its own, so these decimal shifts bridge engine → KDM.
  "/µl->10³/µl": 0.001, // WBC, PLT: 1 ×10³/µL = 1000 cells/µL, so raw cells/µL × 0.001
  "/µl->10⁶/µl": 0.000001, // RBC: 1 ×10⁶/µL = 1 000 000 cells/µL, so raw cells/µL × 0.000001
  "g/l->g/dl": 0.1, // albumin, total protein: 1 g/dL = 10 g/L
  "mg/l->mg/dl": 0.1, // calcium: 1 mg/dL = 10 mg/L
  "ng/ml->ng/dl": 100, // testosterone: 1 ng/mL = 100 ng/dL
  // TSH and similar hormone immunoassays
  "miu/l->µu/ml": 1.0,
  "µu/ml->miu/l": 1.0,
  "µui/ml->miu/l": 1.0,
  "miu/l->µui/ml": 1.0,
  "µui/ml->µu/ml": 1.0,
  "µu/ml->µui/ml": 1.0,
};

// ─── Public API ───

/**
 * Adapt a set of eva-health biomarker values to a KDM-ready input map.
 *
 * Inputs may use either ENGINE codes (e.g., "APOB") or DB keys
 * (e.g., "apolipoprotein_b") — both resolve to the same KDM Spanish key.
 * If the same Spanish key is supplied via two synonyms (e.g., "APOB" and
 * "apolipoprotein_b" for the same person), the LAST one wins — caller
 * should not pass duplicates.
 *
 * Markers with no mapping are listed under `skipped`. Markers with a
 * unit mismatch and no registered conversion are listed under `unconverted`
 * (their value is dropped from `inputs`).
 */
export function kdmInputsFromBiomarkerValues(
  values: BiomarkerInput[],
): KdmAdapterResult {
  const inputs: Record<KdmMarkerKey, number> = {};
  const skipped: string[] = [];
  const unconverted: KdmMarkerKey[] = [];
  const converted: KdmMarkerKey[] = [];
  // Tracks which KDM keys currently hold a cross-molecule-scaled value
  // (e.g. Urea→BUN). A later same-molecule reading for the same KDM
  // key replaces it; a later cross-molecule reading is dropped.
  const crossMoleculeKeys = new Set<KdmMarkerKey>();

  // When two codes resolve to the same KDM key, prefer the entry that
  // does NOT need cross-molecule scaling — same-molecule readings are
  // closer to the joint estimator's calibration. Concretely: a lab
  // reporting both Urea (50 mg/dL) and BUN (10 mg/dL) for one draw
  // used to be order-dependent (last write wins); now BUN always wins
  // because urea's crossMoleculeFactor is set and bun's is not.
  for (const v of values) {
    const entry = CODE_TO_KDM[v.code];
    if (!entry) {
      skipped.push(v.code);
      continue;
    }

    if (!Number.isFinite(v.value)) {
      // Non-numeric / NaN / ±Infinity — drop silently. Estimator math
      // would NaN-poison the joint sum otherwise.
      continue;
    }

    const unit_normalized = convertUnit(v.value, entry.engineUnit, entry.kdmUnit);
    if (unit_normalized === null) {
      unconverted.push(entry.kdm);
      continue;
    }

    // Cross-molecule scaling (e.g. Urea → BUN ×0.4665). Applied after
    // unit normalization so the multiplicative chain reads
    // "unit-convert, then molecule-scale". Kept off of CONVERSION_FACTORS
    // so the unit table doesn't accumulate fake unit strings.
    const final_value = entry.crossMoleculeFactor != null
      ? unit_normalized * entry.crossMoleculeFactor
      : unit_normalized;

    // Skip if a same-molecule reading for this KDM key already won.
    // (We mark the previous winner by remembering its cross-molecule
    // status in a sibling Set.)
    if (
      inputs[entry.kdm] !== undefined &&
      !crossMoleculeKeys.has(entry.kdm) &&
      entry.crossMoleculeFactor != null
    ) {
      continue;
    }

    if (final_value !== v.value) {
      converted.push(entry.kdm);
    }

    inputs[entry.kdm] = final_value;
    if (entry.crossMoleculeFactor != null) {
      crossMoleculeKeys.add(entry.kdm);
    } else {
      crossMoleculeKeys.delete(entry.kdm);
    }
  }

  return { inputs, skipped, unconverted, converted };
}

// ─── Test-only exports ───
// Internal helpers exposed only for unit testing. Production callers should
// use `kdmInputsFromBiomarkerValues` exclusively.
export const __test = {
  CODE_TO_KDM,
  convertUnit,
  normalizeUnitString,
};
