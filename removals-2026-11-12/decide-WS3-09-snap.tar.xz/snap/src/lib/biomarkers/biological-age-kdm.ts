/**
 * KDM v2.2 Biological Age module: the Klemera-Doubal joint estimator.
 *
 * This module produces a population-anchored biological age from the
 * Klemera-Doubal Method (KDM) joint estimator (Klemera & Doubal 2006;
 * Levine 2013; Kwon & Belsky 2021). The library data was trained on
 * NHANES Continuous 1999-2018, each marker on its own sample; the mortality
 * check used n=18,570. For 17 markers the NHANES intercept q is moved by
 * the ratio of a Spanish summary value to the NHANES mean (mostly from
 * PESA; each marker's source is in its `spanish_recalibration` block in
 * `data/marker_library_v2_2.json`). Some of those values are medians or
 * per-sex values that are not in the cited sources (see
 * /metodologia/completa, section 04). No Spanish individual-level or
 * outcome data is used.
 *
 * Original v2.2 mortality check (NHANES, follow-up through 2019). These
 * figures are in-sample: they come from the same subjects the parameters
 * were fitted on (scripts/honest_holdout_validation.py), and they predate
 * v2.2.2 (see the table below):
 *   - Reference BA  : HR per SD of biological age = 1.373 [1.29, 1.46], in
 *     a Cox model with age and sex. C-stat 0.770 is for that whole model; in
 *     EVA's 2007-2014 NHANES comparison, age and sex alone give C 0.771 and
 *     KDM adds about 0.009 (ml/biological-age/MODEL-CARD.md, section 10).
 *   - Calibration slope = 1.027 (v2.2 only; none is stored for v2.2.2).
 *
 * --- Conceptual distinction from the longevity score ---
 * KDM is population-anchored: "how fast are you aging vs typical for your CA?"
 * The longevity-score (./longevity-score.ts) is optimal-range-anchored: "how
 * close are you to longevity-medicine optimal targets?" The two are intentionally
 * distinct metrics — both write to lab_results in parallel.
 *
 * --- Status ---
 * B.5 — core joint-estimator math (incl. natural-log transform when
 *       `log_transformed: true`; skip rule for value ≤ 0).
 * B.6 — sex-aware parameter resolution + s_ca lookup. Propagates
 *       `log_transformed` from the library entry into the resolved params.
 * B.7 — Spanish-recalibration q swap.
 * B.8 — covered by B.5/B.6 wire-up; verified end-to-end against the real
 *       hs-CRP library entry in `biological-age-kdm.test.ts`.
 * B.9 — Fructosamine = 19.97·HbA1c − 39.4 (source not traced) derived when
 *       HbA1c is supplied and Fructosamine is missing. Since 2026-09-25 a
 *       measured fructosamine is set aside by default: the model was
 *       trained on the derived scale only (`FructosaminePolicy`).
 * B.10 — gating (≥ 8 of 14 base + Alb + Crea); `computeReferenceBA` and
 *        `computeComprehensiveBA` are now live. Numerical parity vs
 *        Python lands in B.12.
 *
 * --- Path B parameter corrections (2026-05-26 post-launch) ---
 *
 * v2.2.1 (initial Path B): BUN and derived Fructosamine were trained with
 * 1st-99th percentile winsorization applied before the OLS fit. This
 * tightened their residual SD `s`, inflating the joint-estimator weight
 * `(k/s)²` beyond what is statistically justified. The first Path B
 * (deployed in PR #32) overrode (k, q, s) for those two markers only.
 *
 * v2.2.2 (full Path B, this commit): the same issue applied to every
 * trained marker. The Comprehensive BA (full-panel joint estimator) was
 * systematically biased relative to the Reference BA by mean −1.59 years
 * across NHANES — caused by cumulative weight inflation across all
 * winsorized markers. Full Path B applies unwinsorized (k, q, s) to 80 of
 * the 81 trained markers (IGF-1, from NHANES III, has no Path B refit) via
 * `data/path_b_overrides.json`.
 *
 * Mortality re-check on n=18,570 NHANES subjects across configs (in-sample;
 * HR/SD is per SD of biological age, from Cox(BA_z, age, sex)):
 *
 *                          Reference HR/SD    Comprehensive HR/SD    Mean Δ (Comp − Ref)
 *   v2.2  (winsorized):    1.367              1.631                  −1.93 y
 *   v2.2.1 (BUN+Fruct):    1.406              1.658                  −1.59 y
 *   v2.2.2 (FULL Path B):  1.391              1.654                  +0.07 y  ← deployed
 *
 * The published v2.2.2 run refit Path B on the fly and kept sex-stratified
 * markers at library values (docs/runbooks/kdm-panel-revalidation.md), so
 * its figures are not exactly those of the deployed parameter files.
 *
 * Both tiers clear the spec's HR/SD ≥ 1.02 and C-stat ≥ 0.75 (C 0.77 and
 * 0.775 in `data/path_b_overrides.json` `_meta.validation_summary`, both
 * in-sample). No calibration slope is stored for v2.2.2, so the spec's
 * slope range [0.9, 1.1] is unchecked for this version. v2.2.2 essentially
 * eliminates the population-level Reference/Comprehensive discrepancy
 * (mean Δ +0.07 y).
 *
 * See `scripts/comprehensive_ba_mortality_validation.py` for the run that
 * justifies full Path B; see `generate_path_b_full_overrides.py` for the
 * refit pipeline. The Comprehensive BA has the larger in-sample HR/SD
 * (1.65 vs 1.39). Each is per SD of its own tier's BA and both are
 * in-sample, so neither figure is a held-out comparison of the tiers.
 *
 * See plan: /Users/jdl/.claude/plans/glowing-mixing-cray.md §B.3-B.12
 */

import type { BiomarkerInput } from "./longevity-score";
import { kdmInputsFromBiomarkerValues } from "./kdm-adapter";
import {
  creatineAdjustedCreatinine,
  type SupplementEntry,
} from "./supplements";
import { CREATININE_KEYS, isPlausibleCreatinineMgDl, labCreatinineReadable } from "./creatinine-plausibility";
import libraryData from "./data/marker_library_v2_2.json";
import sCaData from "./data/kdm_s_ca.json";
import pathBData from "./data/path_b_overrides.json";

// ─── Public types ───

export type Sex = "male" | "female";

/**
 * Result of a KDM joint-estimator computation.
 *
 * `null` is returned when the gating condition fails (see B.10):
 *   - fewer than 8 of 14 base-panel markers present, OR
 *   - Albumin missing, OR
 *   - Creatinine missing.
 *
 * When non-null:
 *   - `BA`        : final CA-anchored biological age (years). This is the
 *                   number written to `lab_results.biological_age`.
 *   - `BA_E`      : pre-anchoring biological age estimate (years). Internal
 *                   diagnostic — the joint estimator's raw output before
 *                   shrinkage toward CA via `s_CA`.
 *   - `s_BA`      : KDM-method s_BA estimate (years). Joint-estimator standard
 *                   deviation; smaller = tighter agreement across markers.
 *   - `n_markers_used`            : count of markers that contributed.
 *   - `used_markers`              : Spanish marker names that contributed
 *                                   (post-adapter — see kdm-adapter.ts in B.4).
 *   - `applied_spanish_recalibration_markers`
 *                                 : subset of `used_markers` where the Spanish
 *                                   recalibrated `q_spain` was applied instead
 *                                   of the NHANES `q_NHANES`. See B.7.
 */
export type KdmReferenceBAResult = {
  BA: number;
  BA_E: number;
  s_BA: number;
  n_markers_used: number;
  used_markers: string[];
  applied_spanish_recalibration_markers: string[];
} | null;

/**
 * Comprehensive BA result — uses the full trained panel rather than just the
 * 14-marker base panel. Same gating (≥8 base + Albumin + Creatinine) but the
 * joint estimator runs over every available marker for which the library has
 * trained KDM parameters. The dashboard's rolling average shows this tier
 * first, for every client (`rolling-average-ba.ts`).
 */
export type KdmComprehensiveBAResult = KdmReferenceBAResult;

// ─── Internal types ───

/**
 * Per-marker KDM parameters supplied to the joint estimator.
 *
 * `q` is the intercept of the marker's regression on age (its value at
 * age 0, on the model scale).
 * `k` is the slope (units per year of CA). `s` is the residual SD.
 * `log_transformed` indicates the marker value must be natural-logged
 * before plugging into the estimator (applied in B.8).
 *
 * The caller is responsible for resolving sex-stratified vs pooled
 * parameters before calling `klemeraDoubalBa`; this struct represents
 * the already-resolved (k, q, s) tuple for one marker.
 */
export interface KdmMarkerParams {
  k: number;
  q: number;
  s: number;
  log_transformed?: boolean;
}

/**
 * Per-stratum s_ca lookup. `s_ca` is the residual SD of (BA_E − CA) in the
 * training population. The estimator uses it as the prior precision when
 * shrinking BA toward CA. Falls back to `pooled` then to a literal 10.0
 * when neither sex-specific nor pooled is available.
 */
export interface SCaPooled {
  male?: number;
  female?: number;
  pooled?: number;
}

/**
 * Raw return shape of the joint estimator before the outer wrappers
 * (`computeReferenceBA` / `computeComprehensiveBA`) add the
 * `applied_spanish_recalibration_markers` field. Internal — exported only
 * for testing and for the wrappers in B.10-B.11.
 */
export interface KdmJointEstimatorResult {
  BA: number;
  BA_E: number;
  s_BA: number;
  n_markers_used: number;
  used_markers: string[];
}

// ─── Core joint estimator ───

/**
 * Klemera-Doubal joint estimator. Direct TypeScript port of
 * `klemera_doubal_ba()` in
 * `/Users/jdl/Projects/KDM Final Training/training_package_v2_2/training_scripts/kdm_training.py`
 * lines 321-361.
 *
 * Math (Klemera & Doubal 2006, eqs. 35-39):
 *
 *   BA_E = Σᵢ (xᵢ − qᵢ) · (kᵢ / sᵢ²) / Σᵢ (kᵢ / sᵢ)²
 *   s_BA² = 1 / Σᵢ (kᵢ / sᵢ)²
 *
 * CA-anchored shrinkage (Klemera & Doubal 2006, eq. 39):
 *
 *   BA = (BA_E / s_BA² + CA / s_CA²) / (1 / s_BA² + 1 / s_CA²)
 *
 * For log-distributed markers the natural log of x is used before
 * plugging into the formula (set `log_transformed: true` on the param
 * struct; the caller is responsible for confirming x > 0). Markers with
 * non-finite values, missing/zero `s`, or value ≤ 0 (when log-transformed)
 * are silently skipped.
 *
 * Returns `null` when no marker contributed (denominator == 0).
 *
 * Status: B.5 — sex stratification is delegated to the caller via the
 * pre-resolved `params` argument; B.6 adds the sex-aware lookup at the
 * call site. Spanish recalibration is delegated similarly via the
 * caller's choice of `q` (B.7).
 */
export function klemeraDoubalBa(
  values: Record<string, number>,
  params: Record<string, KdmMarkerParams>,
  ca: number,
  useCaAnchor: boolean,
  sCaPooled: SCaPooled,
  sex: Sex,
): KdmJointEstimatorResult | null {
  let num = 0.0;
  let denom = 0.0;
  const used: string[] = [];

  for (const [marker, rawValue] of Object.entries(values)) {
    if (!Number.isFinite(rawValue)) continue;

    const p = params[marker];
    if (!p) continue;

    const { k, q, s, log_transformed } = p;
    if (!Number.isFinite(k) || !Number.isFinite(q)) continue;
    if (!Number.isFinite(s) || s <= 0) continue;

    let v = rawValue;
    if (log_transformed) {
      if (rawValue <= 0) continue;
      v = Math.log(rawValue);
    }
    if (!Number.isFinite(v)) continue;

    num += (v - q) * (k / (s * s));
    denom += (k / s) ** 2;
    used.push(marker);
  }

  if (denom === 0 || used.length === 0) return null;

  const BA_E = num / denom;
  const s_BA2 = 1.0 / denom;

  let BA: number;
  if (useCaAnchor) {
    const sCaCandidate = sex === "male" ? sCaPooled.male : sCaPooled.female;
    const sCa =
      typeof sCaCandidate === "number" && sCaCandidate > 0
        ? sCaCandidate
        : typeof sCaPooled.pooled === "number" && sCaPooled.pooled > 0
          ? sCaPooled.pooled
          : 10.0;
    const sCa2 = sCa * sCa;
    BA = (BA_E / s_BA2 + ca / sCa2) / (1.0 / s_BA2 + 1.0 / sCa2);
  } else {
    BA = BA_E;
  }

  return {
    BA,
    BA_E,
    s_BA: Math.sqrt(s_BA2),
    n_markers_used: used.length,
    used_markers: used,
  };
}

// ─── Sex-aware parameter resolution (B.6) ───

/**
 * Shape of one marker entry in `data/marker_library_v2_2.json::markers`.
 * Permissive (Record-typed) at the JSON boundary so we can resolve at
 * runtime; the strict `KdmMarkerParams` shape is what we hand to the
 * estimator.
 */
export interface KdmLibraryMarker {
  sex_stratified?: boolean;
  log_transformed?: boolean;
  kqs?: { k: number; q: number; s: number } | null;
  kqs_M?: { k: number; q: number; s: number } | null;
  kqs_F?: { k: number; q: number; s: number } | null;
  /**
   * Spanish recalibration block (B.7).
   *
   * Top-level `q_spain` is populated for pooled-fit markers (11 markers in
   * v2.2). For sex-stratified markers, the `per_sex.{M,F}.q_spain` block is
   * populated only when sex-specific Spanish reference means were supplied
   * (6 markers, copied by scripts/fix_spanish_recalibration_bug.py). When
   * absent, the recalibration is a no-op for that marker and the NHANES q
   * from `kqs[_M|_F]` is used.
   *
   * `q_spain` is on the marker's model scale. The move is the ratio of the
   * Spanish to the NHANES mean (`slope`, clinical scale): slope × q_NHANES
   * for a linear marker, q_NHANES + ln(slope) for a log-transformed one
   * (fixed 2026-09-25 by scripts/fix_log_scale_q_spain.py; the previous
   * value is kept in `q_spain_log_fix`).
   */
  spanish_recalibration?: {
    calibration_status?: string;
    q_spain?: number | null;
    per_sex?: {
      M?: { q_spain?: number | null } | null;
      F?: { q_spain?: number | null } | null;
    } | null;
  } | null;
}

/**
 * Path B parameter overrides for ALL trained markers whose `s` was tightened
 * by winsorization in the original training pipeline. The JSON is generated
 * by `scripts/generate_path_b_full_overrides.py` from raw NHANES values
 * (1999-2018 cycles), re-fitting each marker's OLS without the 1st-99th
 * percentile clip step that the original training applied.
 *
 * The library JSON is preserved as the historical training record; these
 * overrides apply at lookup time inside `computeBa`.
 */
interface PathBFit {
  k: number;
  q: number;
  s: number;
  r2: number;
  n: number;
}
interface PathBEntry {
  log_transformed?: boolean;
  sex_stratified?: boolean;
  kqs?: PathBFit;
  kqs_M?: PathBFit;
  kqs_F?: PathBFit;
}
const PATH_B_OVERRIDES = (
  pathBData as unknown as { markers: Record<string, PathBEntry> }
).markers;

/**
 * Look up Path B (k, q, s) for a marker + sex. Returns null if the marker
 * has no Path B refit (skipped during generation due to n<100 or
 * missing parameters).
 */
function pathBLookup(
  markerKey: string,
  sex: Sex,
): { k: number; q: number; s: number } | null {
  const entry = PATH_B_OVERRIDES[markerKey];
  if (!entry) return null;
  if (entry.sex_stratified) {
    const block = sex === "male" ? entry.kqs_M : entry.kqs_F;
    if (!block) return null;
    return { k: block.k, q: block.q, s: block.s };
  }
  if (!entry.kqs) return null;
  return { k: entry.kqs.k, q: entry.kqs.q, s: entry.kqs.s };
}

/**
 * Pick the right (k, q, s) tuple for a marker given the subject's sex.
 *
 * Mirrors `kdm_training.py` lines 333-341:
 *   - If `sex_stratified: true` → use `kqs_M` (male) or `kqs_F` (female).
 *   - Otherwise → use pooled `kqs`.
 *
 * Returns `null` if the relevant block is missing, has a null `k`, or has
 * a non-positive `s` (matches the Python skip conditions). B.7 will layer
 * Spanish-recalibration q swap on top of this.
 */
export function resolveMarkerParams(
  entry: KdmLibraryMarker,
  sex: Sex,
): KdmMarkerParams | null {
  const block = entry.sex_stratified
    ? sex === "male"
      ? entry.kqs_M
      : entry.kqs_F
    : entry.kqs;

  if (!block) return null;
  const { k, q, s } = block;
  if (!Number.isFinite(k) || !Number.isFinite(q)) return null;
  if (!Number.isFinite(s) || s <= 0) return null;

  return { k, q, s, log_transformed: entry.log_transformed ?? false };
}

/**
 * Lookup the Spanish-recalibrated q for one marker (B.7).
 *
 * Mirrors `recalibrate.py` per-sex / pooled write paths:
 *   - pooled (non sex-stratified): `spanish_recalibration.q_spain`
 *   - sex-stratified: `spanish_recalibration.per_sex.{M,F}.q_spain`
 *
 * Returns `null` if no recalibrated q is available. The recalibration is
 * applied ONLY when `calibration_status` starts with `"recalibrated_"` — a
 * status like `"unrecalibrated"` or `"insufficient_source_data"` means
 * the NHANES q stays.
 */
export function resolveSpanishRecalibratedQ(
  entry: KdmLibraryMarker,
  sex: Sex,
): number | null {
  const sr = entry.spanish_recalibration;
  if (!sr) return null;
  if (!sr.calibration_status?.startsWith("recalibrated_")) return null;

  if (entry.sex_stratified) {
    const bucket = sex === "male" ? sr.per_sex?.M : sr.per_sex?.F;
    const q = bucket?.q_spain;
    return typeof q === "number" && Number.isFinite(q) ? q : null;
  }

  const q = sr.q_spain;
  return typeof q === "number" && Number.isFinite(q) ? q : null;
}

/**
 * Resolve marker params with Spanish recalibration applied where possible.
 *
 * Composition of `resolveMarkerParams` (B.6) + `resolveSpanishRecalibratedQ`
 * (B.7). Returns the params with `q` swapped to `q_spain` when available,
 * along with a flag indicating whether the swap happened.
 *
 * Returns `null` if the underlying (k, q, s) tuple is unavailable, matching
 * `resolveMarkerParams` semantics.
 */
export function resolveMarkerParamsWithRecalibration(
  entry: KdmLibraryMarker,
  sex: Sex,
): { params: KdmMarkerParams; spanishRecalibrationApplied: boolean } | null {
  const baseParams = resolveMarkerParams(entry, sex);
  if (!baseParams) return null;

  const qSpain = resolveSpanishRecalibratedQ(entry, sex);
  if (qSpain === null) {
    return { params: baseParams, spanishRecalibrationApplied: false };
  }

  return {
    params: { ...baseParams, q: qSpain },
    spanishRecalibrationApplied: true,
  };
}

// ─── Fructosamine derivation (B.9) and measured fructosamine ───

/**
 * Spanish marker key for Fructosamine in the KDM library.
 */
export const FRUCTOSAMINE_KDM_KEY = "Fructosamina";

/**
 * Spanish marker key for HbA1c in the KDM library.
 */
export const HBA1C_KDM_KEY = "HbA1c (Hemoglobina Glicosilada)";

/**
 * How a MEASURED fructosamine enters the model.
 *
 * The model's "Fructosamina" was never measured. NHANES has no fructosamine:
 * the training data derived it from HbA1c (19.97 × HbA1c − 39.4, about
 * 70 µmol/L at HbA1c 5.5%), and its (k, q, s) were fitted on those derived
 * values. A laboratory's measured fructosamine is on another scale (the Base
 * Panel's enzymatic assay: reference 122–236 µmol/L, about three times
 * higher), which the model read as decades of aging: +30 years for a
 * 45-year-old man at 190 µmol/L.
 *
 *  - `"hba1c_only"` (default since 2026-09-25): the model sees only the
 *    fructosamine derived from HbA1c, as in training. A measured value is set
 *    aside: the derived value replaces it when HbA1c is present; otherwise the
 *    marker is absent. Absent, it no longer counts toward the gate, and when
 *    that is what fails the gate, `computeReferenceBA` /
 *    `computeComprehensiveBA` log why.
 *  - `"as_measured"`: the behaviour before 2026-09-25. A measured value is
 *    used as is and wins over the derived one. Kept to reproduce stored
 *    results and to roll the fix back.
 *
 * Mapping a measured value through an HbA1c equivalent (Cohen 2003:
 * HbA1c = 0.017 × fructosamine + 1.61) was rejected: that regression is on
 * the NBT assay scale (205–285 µmol/L), and on the Base Panel's scale it moves
 * the BA by −26 to +5 years across 122–260 µmol/L at ages 35–65
 * (docs/biomarker-evidence/longevity/BA-INPUT-FIXES.md).
 */
export type FructosaminePolicy = "hba1c_only" | "as_measured";

/** Policy used when the caller does not pass one. */
export const DEFAULT_FRUCTOSAMINE_POLICY: FructosaminePolicy = "hba1c_only";

/**
 * The Fructosamine value the model sees, from the KDM-keyed inputs.
 *
 * Derived from HbA1c via the locked formula (source not traced):
 *
 *   Fructosamine (µmol/L) = 19.97 × HbA1c (%) − 39.4
 *
 * Spec rationale: Fructosamine measures the same underlying physiology as
 * HbA1c (mean glucose exposure over ~14-21 days vs ~3 months) on a
 * different timescale. The mapping converts between
 * the two so that lab panels containing HbA1c but not Fructosamine still
 * contribute a Fructosamine value to the KDM estimator.
 *
 * A measured Fructosamine in `inputs` is handled by `policy` (see
 * `FructosaminePolicy`): by default it is replaced by the derived value, or
 * removed when HbA1c is missing. With `"as_measured"` the measured value wins
 * and the map is returned unchanged, as before 2026-09-25. If HbA1c is
 * missing, nothing is derived.
 *
 * Caller pattern (used in B.10/B.13):
 *   const adapted = kdmInputsFromBiomarkerValues(values);
 *   const filled = deriveFructosamineIfMissing(adapted.inputs);
 *   const ba = computeReferenceBA(filled, sex, age);
 */
export function deriveFructosamineIfMissing(
  inputs: Record<string, number>,
  policy: FructosaminePolicy = DEFAULT_FRUCTOSAMINE_POLICY,
): Record<string, number> {
  let base = inputs;
  if (FRUCTOSAMINE_KDM_KEY in inputs) {
    if (policy === "as_measured") return inputs;
    base = { ...inputs };
    delete base[FRUCTOSAMINE_KDM_KEY];
  }

  const hba1c = base[HBA1C_KDM_KEY];
  if (typeof hba1c !== "number" || !Number.isFinite(hba1c)) return base;

  const derived = 19.97 * hba1c - 39.4;
  if (!Number.isFinite(derived)) return base;

  return { ...base, [FRUCTOSAMINE_KDM_KEY]: derived };
}

/**
 * Which trained panel to use s_ca for: `"reference"` (14-marker base panel)
 * or `"comprehensive"` (full trained panel).
 */
export type SCaTier = "reference" | "comprehensive";

/**
 * Per-stratum s_ca lookup from `data/kdm_s_ca.json`.
 *
 * Returns the male/female/pooled `SCaPooled` block for the requested tier,
 * ready to hand to `klemeraDoubalBa`. Throws if the JSON shape is
 * unexpectedly missing the tier (configuration bug).
 */
export function resolveSCa(tier: SCaTier): SCaPooled {
  const block = (sCaData as Record<string, unknown>)[tier];
  if (!block || typeof block !== "object") {
    throw new Error(`kdm_s_ca.json: missing tier "${tier}"`);
  }
  const b = block as Record<string, unknown>;
  return {
    male: typeof b.male === "number" ? b.male : undefined,
    female: typeof b.female === "number" ? b.female : undefined,
    pooled: typeof b.pooled === "number" ? b.pooled : undefined,
  };
}

// ─── Library access ───

/** Typed view of the bundled marker library JSON. */
const library = libraryData as unknown as {
  meta: {
    base_panel: string[];
    sex_stratified_markers: string[];
  };
  markers: Record<string, KdmLibraryMarker>;
};

/** The 14-marker base panel (KDM v2.2). Sourced from `marker_library_v2_2.json::meta.base_panel`. */
export const BASE_PANEL: readonly string[] = library.meta.base_panel;

/** Albumin and Creatinine are MANDATORY for KDM gating (Klemera & Doubal 2006 anchoring requirement). */
export const MANDATORY_BASE_MARKERS = [
  "Albúmina",
  "Creatinina",
] as const;

/** Minimum count of base-panel markers required to compute a KDM result. */
export const MIN_BASE_PANEL_MARKERS = 8;

/**
 * Kidney filtration markers that never enter the biological age, in either version (CEO decision, 30 October 2026);
 * of the kidney filtration markers, creatinine and urea (BUN) do. They are stored and shown as results.
 *   - Cystatin C: EVA's laboratory does not deliver it and it is rarely measured in Spain; its parameters rest on
 *     1,664 NHANES values, with age explaining under 3% of their spread. Under the earlier rules a cystatin C result
 *     removed creatinine, and nothing took its place in the Reference version (urea stayed).
 *   - A laboratory's eGFR: computed from the same creatinine, so it would count creatinine twice, and it carries no
 *     creatine adjustment. EVA's laboratory does not deliver it either; it came only from uploaded reports.
 * docs/biomarker-evidence/longevity/CYSTATIN-C-FIX-OPTIONS.md and CALIBRATION-AND-CREATINE.md.
 */
export const KIDNEY_MARKERS_NOT_USED: readonly string[] = ["Cistatina C", "TFGe (basada en Creatinina)"];

/** Provenance tag stored with each Reference BA (`lab_results.bio_age_method`); the rules it names: ./bio-age-method. */
export { KDM_REFERENCE_BA_METHOD } from "./bio-age-method";

// ─── Gating helper (B.10) ───

/**
 * Apply KDM v2.2 gating to a KDM-keyed input map.
 *
 * Mirrors `kdm_training.py` lines 391-395 / 430-434 and the mortality validation run
 * (`scripts/comprehensive_ba_mortality_validation.py`, MANDATORY):
 *   - At least 8 of the 14 base-panel markers present
 *   - Albúmina present
 *   - Creatinina present. Nothing stands in for it: cystatin C and a laboratory's eGFR are
 *     KIDNEY_MARKERS_NOT_USED.
 *
 * Returns `true` to proceed, `false` to abort with a null result.
 */
export function passesKdmGate(inputs: Record<string, number>): boolean {
  for (const marker of MANDATORY_BASE_MARKERS) {
    const v = inputs[marker];
    if (typeof v !== "number" || !Number.isFinite(v)) return false;
  }
  return countBasePanelMarkers(inputs) >= MIN_BASE_PANEL_MARKERS;
}

/**
 * Base-panel markers present in a KDM-keyed input map, as the gate counts
 * them (`passesKdmGate` requires `MIN_BASE_PANEL_MARKERS`). Every one of them
 * enters both versions, so the count is of markers the estimator uses.
 */
export function countBasePanelMarkers(inputs: Record<string, number>): number {
  return BASE_PANEL.filter((m) => {
    const v = inputs[m];
    return typeof v === "number" && Number.isFinite(v);
  }).length;
}

// ─── Internal compute helper ───

/**
 * Resolve the (k, q, s) tuple the joint estimator uses for each marker of
 * `kdmInputs`: sex stratification + Spanish recalibration, then the Path B
 * override. `applied` lists the markers whose Spanish q was swapped in.
 *
 * `restrictToBasePanel`:
 *   - true  → only base-panel markers contribute (Reference BA)
 *   - false → every KDM-mapped marker contributes (Comprehensive BA)
 *
 * Exported for `biological-age-explain.ts`, which decomposes the BA with
 * exactly these parameters.
 */
export function resolveKdmParams(
  kdmInputs: Record<string, number>,
  sex: Sex,
  restrictToBasePanel: boolean,
): { params: Record<string, KdmMarkerParams>; applied: string[] } {
  const params: Record<string, KdmMarkerParams> = {};
  const applied: string[] = [];
  const considerSet = restrictToBasePanel ? new Set(BASE_PANEL) : null;

  for (const markerKey of Object.keys(kdmInputs)) {
    if (considerSet && !considerSet.has(markerKey)) continue;
    if (KIDNEY_MARKERS_NOT_USED.includes(markerKey)) continue;
    const entry = library.markers[markerKey];
    if (!entry) continue;
    const resolved = resolveMarkerParamsWithRecalibration(entry, sex);
    if (!resolved) continue;

    // Apply Path B parameter overrides for markers whose `s` was tightened
    // by Phase 1 winsorization. Spanish recalibration's q swap stays
    // applied; Path B replaces (k, s) and the NHANES q baseline only when
    // no Spanish q_spain was substituted (otherwise the recalibrated q
    // wins).
    const override = pathBLookup(markerKey, sex);
    if (override) {
      params[markerKey] = {
        k: override.k,
        // Spanish q wins if it was applied; otherwise use Path B's q.
        q: resolved.spanishRecalibrationApplied ? resolved.params.q : override.q,
        s: override.s,
        log_transformed: resolved.params.log_transformed,
      };
    } else {
      params[markerKey] = resolved.params;
    }
    if (resolved.spanishRecalibrationApplied) applied.push(markerKey);
  }

  return { params, applied };
}

/**
 * Common path for Reference / Comprehensive BA — runs gating, resolves
 * per-marker params (`resolveKdmParams`), and calls the joint estimator.
 */
function computeBa(
  kdmInputs: Record<string, number>,
  sex: Sex,
  age: number,
  tier: SCaTier,
  restrictToBasePanel: boolean,
): KdmReferenceBAResult {
  if (!passesKdmGate(kdmInputs)) return null;

  const { params, applied } = resolveKdmParams(kdmInputs, sex, restrictToBasePanel);

  if (Object.keys(params).length === 0) return null;

  const sCa = resolveSCa(tier);
  const ba = klemeraDoubalBa(kdmInputs, params, age, true, sCa, sex);
  if (!ba) return null;

  return {
    BA: ba.BA,
    BA_E: ba.BA_E,
    s_BA: ba.s_BA,
    n_markers_used: ba.n_markers_used,
    used_markers: ba.used_markers,
    applied_spanish_recalibration_markers: applied.filter((m) =>
      ba.used_markers.includes(m),
    ),
  };
}

// ─── Public API ───

/**
 * Optional patient context used by the KDM pipeline for lifestyle
 * adjustments (creatine supplementation).
 */
export interface KdmPatientContext {
  /**
   * Supplements from `patient_context_versions.supplements`: those of the context the lab result is read under
   * (patient-context/lab-context.ts).
   */
  supplements?: SupplementEntry[] | null;
  /**
   * The caller already checked each measured creatinine against its plausible range and removed its creatine rise
   * (the dashboard's rolling average does both per lab, before averaging): creatinine is then taken as given.
   */
  creatinineAlreadyAdjusted?: boolean;
}

/**
 * Prepare the KDM-keyed input map for the estimator:
 *
 *  - Cystatin C and a laboratory's eGFR are removed
 *    (KIDNEY_MARKERS_NOT_USED); creatinine and urea (BUN) enter.
 *  - Creatinine outside its extreme physiological range (creatinine-
 *    plausibility.ts, 0.2 to 15 mg/dL) is removed as a unit or extraction
 *    error. Creatinine is mandatory, so the gate then fails: no biological
 *    age rather than a wrong one.
 *  - Creatine supplementation raises serum creatinine; in trials in healthy
 *    adults, measured kidney filtration did not change. Creatinine is divided
 *    by the declared dose's divisor (`creatineCreatinineDivisor` in
 *    ./supplements) before the joint estimator sees it.
 *
 * Returns a NEW object — does not mutate the input.
 */
export function applyLifestyleAdjustments(
  inputs: Record<string, number>,
  context: KdmPatientContext | null | undefined,
): Record<string, number> {
  const out = { ...inputs };
  for (const marker of KIDNEY_MARKERS_NOT_USED) delete out[marker];

  const creatinine = out["Creatinina"];
  if (typeof creatinine === "number" && !context?.creatinineAlreadyAdjusted) {
    if (isPlausibleCreatinineMgDl(creatinine)) {
      out["Creatinina"] = creatineAdjustedCreatinine(creatinine, context?.supplements ?? null);
    } else {
      delete out["Creatinina"];
    }
  }

  return out;
}

/** Options of `computeReferenceBA` / `computeComprehensiveBA`. */
export interface KdmComputeOptions {
  /** How a measured fructosamine enters the model. Default `DEFAULT_FRUCTOSAMINE_POLICY`. */
  fructosamine?: FructosaminePolicy;
}

/**
 * One lab's values with its creatinine removed when the lab's creatinine cannot be read (labCreatinineReadable: an
 * implausible value, or two values that are not the same result), as on the dashboard and in version 3. Creatinine
 * is mandatory, so the lab then gives no biological age. Creatinine the caller already checked and adjusted (the
 * dashboard's average) is taken as given. Exported for `biological-age-explain.ts`, which must prepare the values as
 * the BA does.
 */
export function withReadableCreatinine(
  values: BiomarkerInput[],
  context: KdmPatientContext | null | undefined,
): BiomarkerInput[] {
  if (context?.creatinineAlreadyAdjusted) return values;
  const creatinine = values.filter((v) => CREATININE_KEYS.has(v.code) && Number.isFinite(Number(v.value)));
  return labCreatinineReadable(creatinine.map((v) => Number(v.value)))
    ? values
    : values.filter((v) => !CREATININE_KEYS.has(v.code));
}

/**
 * Steps 1–3 of the pipeline below: adapter, Fructosamine, lifestyle
 * adjustments. When the gate then fails only because a measured
 * fructosamine was set aside (it would pass with the value as measured),
 * logs why: the BA is not silently lost.
 */
function prepareKdmInputs(
  values: BiomarkerInput[],
  context: KdmPatientContext | null | undefined,
  policy: FructosaminePolicy,
  tier: SCaTier,
): Record<string, number> {
  const adapted = kdmInputsFromBiomarkerValues(withReadableCreatinine(values, context)).inputs;
  const adjusted = applyLifestyleAdjustments(deriveFructosamineIfMissing(adapted, policy), context);

  if (
    FRUCTOSAMINE_KDM_KEY in adapted &&
    !(FRUCTOSAMINE_KDM_KEY in adjusted) &&
    !passesKdmGate(adjusted) &&
    passesKdmGate(applyLifestyleAdjustments(deriveFructosamineIfMissing(adapted, "as_measured"), context))
  ) {
    console.warn(
      `[biological-age-kdm] ${tier} BA not computed: measured fructosamine is not used ` +
        `(the model was trained on fructosamine derived from HbA1c, and no HbA1c was supplied), ` +
        `which leaves ${countBasePanelMarkers(adjusted)} of the ${MIN_BASE_PANEL_MARKERS} ` +
        `base-panel markers the gate requires.`,
    );
  }
  return adjusted;
}

/**
 * Reference Biological Age — 14-marker base-panel joint estimator.
 *
 * Pipeline:
 *   1. `kdmInputsFromBiomarkerValues` — map engine codes / DB keys to KDM keys
 *   2. `deriveFructosamineIfMissing` — derived from HbA1c (formula source
 *      not traced); a measured
 *      value per `options.fructosamine` (default: set aside, see
 *      `FructosaminePolicy`)
 *   3. `applyLifestyleAdjustments` — cystatin C and a laboratory eGFR left
 *      out; creatinine adjusted for a declared creatine dose
 *   4. `passesKdmGate` — ≥ 8 of 14 base + Albúmina + Creatinina
 *   5. `resolveMarkerParamsWithRecalibration` (+ Path B override) per marker
 *   6. `klemeraDoubalBa` with Reference-tier s_ca
 *
 * Returns `null` when gating fails.
 */
export function computeReferenceBA(
  values: BiomarkerInput[],
  sex: Sex,
  age: number,
  context?: KdmPatientContext | null,
  options?: KdmComputeOptions,
): KdmReferenceBAResult {
  if (!Number.isFinite(age) || age <= 0) return null;
  const policy = options?.fructosamine ?? DEFAULT_FRUCTOSAMINE_POLICY;
  const adjusted = prepareKdmInputs(values, context, policy, "reference");
  return computeBa(adjusted, sex, age, "reference", true);
}

/**
 * Comprehensive Biological Age — full-panel joint estimator.
 *
 * Same pipeline as `computeReferenceBA` but the joint estimator runs over
 * every KDM-mapped marker (not just the 14-marker base panel). The
 * dashboard's rolling average shows this tier first (`rolling-average-ba.ts`).
 *
 * Returns `null` when gating fails.
 */
export function computeComprehensiveBA(
  values: BiomarkerInput[],
  sex: Sex,
  age: number,
  context?: KdmPatientContext | null,
  options?: KdmComputeOptions,
): KdmComprehensiveBAResult {
  if (!Number.isFinite(age) || age <= 0) return null;
  const policy = options?.fructosamine ?? DEFAULT_FRUCTOSAMINE_POLICY;
  const adjusted = prepareKdmInputs(values, context, policy, "comprehensive");
  return computeBa(adjusted, sex, age, "comprehensive", false);
}
