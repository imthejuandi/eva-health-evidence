/**
 * Mapping from the canonical keys returned by name-matcher.ts to the actual
 * slugified keys produced by supabase/seed.ts from the source JSON's
 * biomarker names.
 *
 * Why this exists:
 *   name-matcher.ts uses short, conventional keys like "apolipoprotein_b",
 *   "cortisol_am", "lipoprotein_a". The seed JSON's biomarker names are more
 *   verbose ("Apolipoprotein B (ApoB)", "Cortisol (Morning, 8AM)",
 *   "Lipoprotein(a)") and slugify to different strings. Without a remap,
 *   every biomarker in this list falls through refMap.get() and gets
 *   zone = "unclassified" even when the seed data is populated.
 *
 * Keep this in sync whenever either side changes.
 */

export const MATCHER_TO_SEED_KEY: Record<string, string> = {
  // ── Lipids ──
  apolipoprotein_b: "apolipoprotein_b_apob",
  lipoprotein_a: "lipoproteina",

  // ── Thyroid ──
  free_t3: "free_t3_triiodothyronine",
  free_t4: "free_t4_thyroxine",
  anti_tpo: "thyroid_peroxidase_antibodies_tpo",
  anti_tg: "thyroglobulin_antibodies_tgab",

  // ── Iron panel ──
  tibc: "iron_binding_capacity_tibc",
  transferrin_saturation: "iron_saturation_tsat",
  serum_iron: "iron_serum",

  // ── Liver ──
  alkaline_phosphatase: "alp",

  // ── Metabolic ──
  fasting_insulin: "insulin_fasting",

  // ── Minerals ──
  magnesium: "magnesium_serum",
  zinc: "zinc_serum",

  // ── Hormones ──
  cortisol_am: "cortisol_morning_8am",
  dhea_s: "dhea_sulfate",
  testosterone: "testosterone_total",
  free_testosterone: "testosterone_free",
  lh: "luteinizing_hormone_lh",

  // ── Kidney ──
  egfr: "egfr_creatinine_based",

  // ── Autoimmune ──
  rheumatoid_factor: "rheumatoid_factor_rf",

  // ── Keys the matcher emitted before it was aligned to the seed slugs ──
  // Stored rows and callers that pass a key may still carry them. Each is the
  // same analyte as its one target row, which processing used to reach by
  // containment between keys; that lookup is gone, so the pair is written
  // here. The canonical-unit gate still runs on the target key afterwards.
  amh: "anti_mullerian_hormone_amh",
  apolipoprotein_a1: "apolipoprotein_a1_apoa1",
  calcium: "calcium_serum",
  copper: "copper_serum",
  dha: "omega_3_dha",
  epa: "omega_3_epa",
  folate: "folate_vitamin_b9",
  methylmalonic_acid: "methylmalonic_acid_mma",
  microalbumin: "microalbumin_urine",
  selenium: "selenium_serum",
};

import { normalizeUnit } from "./canonical-units";

/**
 * Treat the unit as a CBC absolute-count form (as opposed to a
 * percentage) for the differential %/absolute split.
 *
 * A leukocyte differential line is only ever reported one of two ways:
 * as a percentage ("%") or as an absolute cell count. So rather than try
 * to enumerate every count notation a lab or the OCR step might emit
 * ("x10³/µL", "10⁹/L", "K/µL", "/µL", "/mm³", and mangled forms like
 * "/mL" or "/mi"), we treat ANY non-empty, non-percentage unit as the
 * absolute count. convertBiomarker then rescales it to the canonical
 * ×10³/µL (raw /µL counts are divided by 1000). An empty unit stays on
 * the percentage row, since a bare differential number is usually a %.
 */
function isAbsoluteCountUnit(unit: string): boolean {
  if (!unit) return false;
  const u = normalizeUnit(unit);
  if (!u) return false;
  if (u === "%" || u.includes("%")) return false;
  return true;
}

/**
 * CBC differential biomarkers whose seed table has both a percentage row
 * (e.g. "lymphocytes") and an absolute-count row (e.g. "lymphocytes_absolute").
 * The matcher collapses both to the base key; this helper picks the right
 * one based on the reported unit.
 */
const CBC_DIFF_BASE_KEYS = new Set([
  "lymphocytes",
  "monocytes",
  "neutrophils",
  "eosinophils",
  "basophils",
]);

export function resolveCbcDifferentialKey(
  matcherKey: string,
  unit: string,
): string {
  if (!CBC_DIFF_BASE_KEYS.has(matcherKey)) return matcherKey;
  return isAbsoluteCountUnit(unit) ? `${matcherKey}_absolute` : matcherKey;
}

/**
 * Apply all key remappings: matcher→seed key + CBC %/absolute disambiguation.
 * Called from process-results.ts after name matching.
 */
export function remapToSeedKey(matcherKey: string, unit: string): string {
  const afterCbc = resolveCbcDifferentialKey(matcherKey, unit);
  return MATCHER_TO_SEED_KEY[afterCbc] ?? afterCbc;
}
