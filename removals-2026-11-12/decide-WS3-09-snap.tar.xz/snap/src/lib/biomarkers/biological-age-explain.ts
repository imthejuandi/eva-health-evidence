/**
 * Biological-age explanations — internal only. Nothing here is stored or
 * shown to users.
 *
 * For the inputs of a KDM biological age (`computeReferenceBA` /
 * `computeComprehensiveBA`), `explainBiologicalAge` returns:
 *   - `contributions`: each marker's exact share of the gap BA − CA, in years
 *     (positive = older);
 *   - `potential`: for each marker with a reviewed optimal band, the BA if only
 *     that marker moved to the nearest edge of its band — kept only when the
 *     move lowers the BA;
 *   - `conflicts`: moves toward the band that would raise the BA. KDM counts
 *     each marker in one direction (docs/biomarker-evidence/longevity/
 *     KDM-DIRECTION.md), so these are reported and never counted;
 *   - `potentialBA`: the BA with every kept move applied together.
 *
 * The decomposition is exact. With D = Σⱼ (kⱼ/sⱼ)² + 1/s_CA²,
 *
 *   BA − CA = Σⱼ (vⱼ − qⱼ − kⱼ·CA) · (kⱼ/sⱼ²) / D
 *
 * where vⱼ is the value the estimator sees (unit conversion, creatine adjustment,
 * derived Fructosamine, then ln for log-transformed markers) and (kⱼ, qⱼ, sⱼ)
 * the parameters it uses (sex, Spanish q, Path B), both taken from the
 * model's own pipeline. `check` confirms the shares add up to the model's
 * BA − CA.
 *
 * Pure: the optimal bands come in as an argument — the reference rows already
 * picked for the person, keyed like the input codes.
 */

import type { BiomarkerInput } from "./longevity-score";
import { kdmInputsFromBiomarkerValues } from "./kdm-adapter";
import { CREATININE_KEYS } from "./creatinine-plausibility";
import {
  applyLifestyleAdjustments,
  computeComprehensiveBA,
  computeReferenceBA,
  deriveFructosamineIfMissing,
  FRUCTOSAMINE_KDM_KEY,
  HBA1C_KDM_KEY,
  resolveKdmParams,
  resolveSCa,
  withReadableCreatinine,
  type KdmPatientContext,
  type SCaTier,
  type Sex,
} from "./biological-age-kdm";

// ─── Public types ───

/** Optimal band of a reference row. A null bound means no limit on that side. */
export interface OptimalBand {
  optimal_low: number | null;
  optimal_high: number | null;
}

export interface MarkerContribution {
  /** KDM library key (Spanish marker name). */
  marker: string;
  /** Input code that supplied the value; for Fructosamine derived from HbA1c, the HbA1c code. */
  code: string;
  /** Value as supplied, in the engine unit. */
  value: number;
  /** Value the estimator used, in the KDM unit (before ln for log-transformed markers). */
  modelValue: number;
  /** Share of BA − CA in years; positive = older. */
  years: number;
}

export interface MarkerMove {
  code: string;
  from: number;
  /** Nearest edge of the optimal band. */
  to: number;
  /** BA if only this marker moved. */
  ba: number;
  /** ba − BA in years: negative in `potential`, positive (the rise) in `conflicts`. */
  delta: number;
}

export interface BiologicalAgeExplanation {
  tier: SCaTier;
  ca: number;
  ba: number;
  /** Sorted by size of the share, largest first. */
  contributions: MarkerContribution[];
  /** Σ contributions against BA − CA; `ok` when they agree to 1e-9 years. */
  check: { sum: number; gap: number; ok: boolean };
  /** Moves that lower the BA, largest first. */
  potential: MarkerMove[];
  /** Moves toward optimal that raise the BA, largest rise first. Never counted. */
  conflicts: MarkerMove[];
  /** BA with every move in `potential` applied together (recomputed). */
  potentialBA: number;
}

// ─── Helpers ───

const SUM_TOLERANCE = 1e-9;
// A move that changes the BA by less than this (years) does not reach the
// estimator: marker outside the tier, cystatin C or a laboratory's eGFR (never used), …
const NO_EFFECT = 1e-9;

/** s_CA for the tier and sex, picked as `klemeraDoubalBa` picks it. */
function selectSCa(tier: SCaTier, sex: Sex): number {
  const s = resolveSCa(tier);
  const own = sex === "male" ? s.male : s.female;
  if (typeof own === "number" && own > 0) return own;
  if (typeof s.pooled === "number" && s.pooled > 0) return s.pooled;
  return 10.0;
}

/**
 * Which input supplied each KDM marker: the last input whose own adapted
 * value equals the panel's (the adapter's precedence, read back rather than
 * re-implemented). Fructosamine derived from HbA1c points to the HbA1c input.
 */
function sourceByMarker(
  values: BiomarkerInput[],
  adapted: Record<string, number>,
): Map<string, BiomarkerInput> {
  const out = new Map<string, BiomarkerInput>();
  for (const v of values) {
    for (const [marker, x] of Object.entries(kdmInputsFromBiomarkerValues([v]).inputs)) {
      if (x === adapted[marker]) out.set(marker, v);
    }
  }
  const hba1c = out.get(HBA1C_KDM_KEY);
  if (hba1c && !out.has(FRUCTOSAMINE_KDM_KEY)) out.set(FRUCTOSAMINE_KDM_KEY, hba1c);
  return out;
}

/** Nearest edge of the optimal band, or null when the value is inside it or there is no band. */
function nearestOptimalEdge(value: number, band: OptimalBand | undefined): number | null {
  if (!band || !Number.isFinite(value)) return null;
  if (band.optimal_low != null && value < band.optimal_low) return band.optimal_low;
  if (band.optimal_high != null && value > band.optimal_high) return band.optimal_high;
  return null;
}

/** `values` with the entries at the given indices set to new values. */
function withValues(values: BiomarkerInput[], target: Map<number, number>): BiomarkerInput[] {
  return values.map((v, i) => {
    const to = target.get(i);
    return to === undefined ? v : { ...v, value: to };
  });
}

// ─── Public API ───

/**
 * The values with only their last creatinine row (CREATININE_KEYS) that holds a number, unless the caller already
 * adjusted creatinine.
 */
function creatinineOnce(values: BiomarkerInput[], context: KdmPatientContext | null | undefined): BiomarkerInput[] {
  if (context?.creatinineAlreadyAdjusted) return values;
  const last = values.map((v) => CREATININE_KEYS.has(v.code) && Number.isFinite(Number(v.value))).lastIndexOf(true);
  return values.filter((v, i) => !CREATININE_KEYS.has(v.code) || i === last);
}

/**
 * Explain a KDM biological age (Reference tier by default — the stored
 * number). `values`, `sex`, `age` and `context` are the arguments of
 * `computeReferenceBA` / `computeComprehensiveBA`; `bands` maps an input
 * code to the optimal band of the reference row picked for this person.
 *
 * Returns `null` when the BA itself is null (gate failed).
 */
export function explainBiologicalAge(
  values: BiomarkerInput[],
  sex: Sex,
  age: number,
  bands: Record<string, OptimalBand | undefined>,
  tier: SCaTier = "reference",
  context?: KdmPatientContext | null,
): BiologicalAgeExplanation | null {
  const computeBA = tier === "reference" ? computeReferenceBA : computeComprehensiveBA;
  const result = computeBA(values, sex, age, context);
  if (!result) return null;
  // The figure exists, so the lab's creatinine rows are the same result: keep the last, the one the figure reads
  // (kdm-adapter.ts), so that moving creatinine moves one value and the rows never disagree.
  const rows = creatinineOnce(values, context);

  // Same preparation and parameters as the BA itself.
  const adapted = kdmInputsFromBiomarkerValues(withReadableCreatinine(rows, context)).inputs;
  const inputs = applyLifestyleAdjustments(deriveFructosamineIfMissing(adapted), context);
  const { params } = resolveKdmParams(inputs, sex, tier === "reference");

  let denom = 0;
  for (const m of result.used_markers) denom += (params[m].k / params[m].s) ** 2;
  const sCa = selectSCa(tier, sex);
  const d = denom + 1 / (sCa * sCa);

  const sources = sourceByMarker(rows, adapted);
  const contributions = result.used_markers
    .map((marker): MarkerContribution => {
      const { k, q, s, log_transformed } = params[marker];
      const x = inputs[marker];
      const v = log_transformed ? Math.log(x) : x;
      const src = sources.get(marker);
      return {
        marker,
        code: src?.code ?? marker,
        value: src?.value ?? x,
        modelValue: x,
        years: ((v - q - k * age) * (k / (s * s))) / d,
      };
    })
    .sort((a, b) => Math.abs(b.years) - Math.abs(a.years));
  const sum = contributions.reduce((acc, c) => acc + c.years, 0);
  const gap = result.BA - age;

  // Direction rule: each marker alone to the nearest edge of its band; keep
  // the move only if it lowers the BA, report it as a conflict if it raises it.
  const moves: { index: number; move: MarkerMove }[] = [];
  rows.forEach((v, index) => {
    const to = nearestOptimalEdge(v.value, bands[v.code]);
    if (to === null) return;
    const moved = computeBA(withValues(rows, new Map([[index, to]])), sex, age, context);
    if (!moved) return;
    moves.push({ index, move: { code: v.code, from: v.value, to, ba: moved.BA, delta: moved.BA - result.BA } });
  });
  const kept = moves.filter((m) => m.move.delta < -NO_EFFECT);
  const conflicts = moves
    .filter((m) => m.move.delta > NO_EFFECT)
    .map((m) => m.move)
    .sort((a, b) => b.delta - a.delta);

  // Recompute with every kept move at once rather than adding single moves.
  const all = kept.length
    ? computeBA(withValues(rows, new Map(kept.map((m) => [m.index, m.move.to]))), sex, age, context)
    : result;

  return {
    tier,
    ca: age,
    ba: result.BA,
    contributions,
    check: { sum, gap, ok: Math.abs(sum - gap) <= SUM_TOLERANCE },
    potential: kept.map((m) => m.move).sort((a, b) => a.delta - b.delta),
    conflicts,
    potentialBA: all ? all.BA : result.BA,
  };
}
