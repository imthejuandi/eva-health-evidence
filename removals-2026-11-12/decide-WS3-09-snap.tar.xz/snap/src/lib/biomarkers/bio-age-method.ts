/**
 * Provenance tags of `lab_results.bio_age_method`, kept apart from the KDM module (and its data files) so client
 * components can test a stored figure's tag.
 */

/**
 * Reference BA under the `_r2` rules (decided 30 October 2026, written from their deployment): cystatin C and a
 * laboratory eGFR never enter, so a cystatin C result no longer removes creatinine; a lab whose creatinine values
 * include one outside 0.2 to 15 mg/dL, or two that are not the same result (creatinine-plausibility.ts), gives no
 * figure; and a declared creatine dose is adjusted for with the context the lab is read under
 * (patient-context/lab-context.ts).
 */
export const KDM_REFERENCE_BA_METHOD = "KDM_v2.2_ReferenceBA_r2";

/**
 * Reference BA rows written from 26 May 2026 until the `_r2` rules were deployed, under the earlier rules. A
 * laboratory eGFR never entered this figure. With two creatinine rows, the last was read, with no plausibility check. A cystatin C result removed creatinine, and with it the creatine
 * correction, and nothing took its place in the estimate: cystatin C itself never entered, and urea (BUN) stayed.
 * Cystatin C still stood in for creatinine at the minimum-marker check, so a lab with cystatin C and no creatinine
 * got a figure, which the `_r2` rules withhold. The dose formula subtracted min(0.05 + 0.025 × g/day, 0.40) mg/dL
 * from creatinine, using the client's latest context. A laboratory eGFR, and cystatin C in creatinine's place,
 * entered only the Comprehensive figures: biological_age_comprehensive on the same row, and the dashboard's, which
 * carry no tag.
 */
export const KDM_REFERENCE_BA_METHOD_BEFORE_R2 = "KDM_v2.2_ReferenceBA";
