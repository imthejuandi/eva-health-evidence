/**
 * The age groups of biomarker_references in production (2026-09-25, 30 labels), for the tests of the shared
 * age matcher (reference-row.ts). Only the labels, never values: no patient data.
 */

// Every age_group_en in biomarker_references (production, 2026-09-25).
export const LIVE_LABELS = [
  "All Adults", "18-21", "22-25", "26-30", "31-35", "36-40", "41-45", "46+", "18-29", "30-39", "40-59", "60+",
  "18-39", "Postmenopausal", "Premenopausal (follicular)", "Premenopausal (luteal)", "Premenopausal (ovulatory)",
  "18-49", "50+", "Ovulatory peak", "40-49", "50-59", "50-74", "75+", "On Hormone Therapy", "60-69", "70+", "18-59",
  "60-89", "90+",
];

// Each marker's labels by sex in production, for the markers with more than one row or a label other than
// "All Adults" (every other marker has a single "All Adults" row per sex).
export const LIVE_SETS: Array<[key: string, sex: string, labels: string[]]> = [
  ["anti_mullerian_hormone_amh", "female", ["18-21", "22-25", "26-30", "31-35", "36-40", "41-45", "46+"]],
  ["dhea_sulfate", "female", ["18-29", "30-39", "40-59", "60+"]],
  ["dhea_sulfate", "male", ["18-29", "30-39", "40-59", "60+"]],
  ["egfr_creatinine_based", "both", ["18-39", "40-59", "60+"]],
  ["estradiol", "female", ["Postmenopausal", "Premenopausal (follicular)", "Premenopausal (luteal)", "Premenopausal (ovulatory)"]],
  ["estradiol", "male", ["All Adults"]],
  ["ferritin", "female", ["18-49", "50+"]],
  ["ferritin", "male", ["All Adults"]],
  ["fsh", "female", ["Ovulatory peak", "Postmenopausal", "Premenopausal (follicular)"]],
  ["fsh", "male", ["All Adults"]],
  ["igf_1_insulin_like_growth_factor_1", "both", ["18-29", "30-39", "40-49", "50-59", "60+"]],
  ["luteinizing_hormone_lh", "female", ["Ovulatory peak", "Postmenopausal", "Premenopausal (follicular)"]],
  ["luteinizing_hormone_lh", "male", ["All Adults"]],
  ["nt_probnp", "both", ["18-49", "50-74", "75+"]],
  ["progesterone", "female", ["On Hormone Therapy", "Postmenopausal", "Premenopausal (follicular)", "Premenopausal (luteal)", "Premenopausal (ovulatory)"]],
  ["progesterone", "male", ["All Adults"]],
  ["prolactin", "female", ["18-49", "50+"]],
  ["prolactin", "male", ["All Adults"]],
  ["psa_total", "male", ["18-49", "50-59", "60-69", "70+"]],
  ["shbg", "female", ["All Adults"]],
  ["shbg", "male", ["18-39", "40-59", "60+"]],
  ["testosterone_free", "female", ["18-39", "40-59", "60+"]],
  ["testosterone_free", "male", ["18-39", "40-59", "60+"]],
  ["testosterone_total", "female", ["18-49", "50+"]],
  ["testosterone_total", "male", ["All Adults"]],
  ["total_bilirubin", "both", ["18-59", "60-89", "90+"]],
  ["tsh", "both", ["18-39", "40-59", "60+"]],
  ["apolipoprotein_b_apob", "both", ["All Adults"]],
];
