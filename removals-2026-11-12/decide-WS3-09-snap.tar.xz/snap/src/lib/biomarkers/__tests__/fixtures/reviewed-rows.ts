/**
 * The reviewed rows of the seed (supabase/seed-data/biomarker-ranges-en.json) keyed as biomarker_references
 * keys them, for the score tests. One key differs from the seeder's: the NLR row's name slugifies to
 * neutrophil_to_lymphocyte_ratio_nlr, while the database keys it nlr (migration 20260925012000_nlr_row.sql).
 * The seed has no folate row (production has folate_vitamin_b9).
 */
import { seedReferenceRows } from "../../seed-references";

export const SEED_KEY_TO_DB_KEY: Readonly<Record<string, string>> = { neutrophil_to_lymphocyte_ratio_nlr: "nlr" };

export function reviewedRows() {
  return seedReferenceRows().map((r) => ({ ...r, biomarker_key: SEED_KEY_TO_DB_KEY[r.biomarker_key] ?? r.biomarker_key }));
}

// ─── The rows the score runs on ───

import fs from "node:fs";
import path from "node:path";
import { SCORE_SPEC } from "../../longevity-score";

const DECISIONS_DIR = path.resolve(__dirname, "../../../../../docs/signoff/work/decisions");
const STATE_LABEL: Readonly<Record<string, string>> = { pregnancy: "Pregnancy", lactation: "Lactation" };

interface DecidedRow {
  marker_key: string;
  sex: string;
  age_group: string;
  physiological_state?: string | null;
  reference_low: number | null;
  reference_high: number | null;
  optimal_low: number | null;
  optimal_high: number | null;
}

/**
 * The seed's rows with the rows of every marker the score specification names replaced by the families' decided
 * rows (docs/signoff/work/decisions): the rows the database holds once the sign-off compile is applied. The score
 * counts a marker only through a row whose optimal band is the one the verifier graded, so on the seed as it
 * stands today most markers do not score; the score tests run on these rows. A state row carries its state as the
 * age group label, as the compile writes it.
 */
export function signedRows() {
  const seed = reviewedRows();
  const scoreKeys = new Set(Object.values(SCORE_SPEC.markers).map((m) => m.key));
  const decided: DecidedRow[] = fs
    .readdirSync(DECISIONS_DIR)
    .filter((f) => f.endsWith(".json"))
    .sort()
    .flatMap((f) => (JSON.parse(fs.readFileSync(path.join(DECISIONS_DIR, f), "utf8")) as { final_rows: DecidedRow[] }).final_rows)
    .filter((r) => scoreKeys.has(r.marker_key));
  const kept = seed.filter((r) => !scoreKeys.has(r.biomarker_key));
  const replaced = decided.map((d) => {
    const template = seed.find((r) => r.biomarker_key === d.marker_key);
    if (!template) throw new Error(`signedRows: the seed has no row for ${d.marker_key}`);
    const state = d.physiological_state ?? "none";
    return {
      ...template,
      sex: d.sex,
      age_group_en: state === "none" ? d.age_group : (STATE_LABEL[state] ?? state),
      optimal_low: d.optimal_low,
      optimal_high: d.optimal_high,
      normal_low: d.reference_low,
      normal_high: d.reference_high,
    };
  });
  return [...kept, ...replaced];
}
