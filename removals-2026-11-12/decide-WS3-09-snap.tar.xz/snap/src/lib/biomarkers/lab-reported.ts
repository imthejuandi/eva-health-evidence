/**
 * Results a laboratory reports that EVA shows as a value only (rulings D-06 and D-28).
 *
 * A laboratory's own eGFR is stored under `egfr_creatinine_based`. Its equation is unknown, and the reviewed eGFR
 * rows describe the eGFR the app computes from the measured creatinine (calculated-metrics.ts, `egfr_computed`).
 * So the laboratory's figure is stored and shown as a number: no category, no colour, no interval from those rows
 * beside it, and it is never a score input. It still counts toward the critical tier (process-results.ts).
 *
 * Processing stores such a row already as value-only. Rows stored before that keep the category and interval they
 * were given, so every reader passes its rows through `shownAsValueOnly` rather than trusting the stored fields.
 *
 * No server import: client components may use this module.
 */

/** The seed key, and the key legacy rows may carry (key-aliases.ts remaps `egfr` to it). */
export const LAB_REPORTED_VALUE_ONLY_KEYS: ReadonlySet<string> = new Set(["egfr_creatinine_based", "egfr"]);

/** Whether results stored under this key are shown as a value only. */
export function isLabReportedValueOnly(biomarkerKey: string | null | undefined): boolean {
  return typeof biomarkerKey === "string" && LAB_REPORTED_VALUE_ONLY_KEYS.has(biomarkerKey);
}

const INTERVAL_FIELDS = ["optimal_low", "optimal_high", "normal_low", "normal_high"] as const;

/**
 * The row as a reader may show it: a value-only result loses the category and the interval it may have been stored
 * with (`zone` becomes "unclassified", the four bounds null; only fields the row carries are touched). Any other row
 * is returned as it is.
 */
export function shownAsValueOnly<T extends { biomarker_key: string }>(row: T): T {
  if (!isLabReportedValueOnly(row.biomarker_key)) return row;
  const shown: Record<string, unknown> = { ...row };
  if ("zone" in shown) shown.zone = "unclassified";
  for (const field of INTERVAL_FIELDS) if (field in shown) shown[field] = null;
  return shown as T;
}
