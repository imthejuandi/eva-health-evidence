import { describe, expect, it } from "vitest";
import { ageGroupContains, pickReferenceRow, pickReferenceRows, referenceRowFor } from "./reference-row";
import { LIVE_LABELS, LIVE_SETS } from "./__tests__/fixtures/live-age-groups";

const row = (sex: string, age_group_en: string) => ({ sex, age_group_en });

// The phase-labelled female rows EVA stores for LH, in two different database orders.
const lhRows = [
  row("female", "Postmenopausal"),
  row("female", "Ovulatory peak"),
  row("female", "Premenopausal (follicular)"),
  row("male", "18-69"),
];

describe("pickReferenceRow", () => {
  it("returns the only match unchanged", () => {
    expect(pickReferenceRow([row("both", "All Adults")], "female", 30)).toEqual(row("both", "All Adults"));
    expect(pickReferenceRow([], "female", 30)).toBeUndefined();
  });

  it("does not depend on the order the database returns rows", () => {
    const women = lhRows.filter((r) => r.sex === "female");
    for (const age of [25, 49, 50, 70]) {
      const a = pickReferenceRow(women, "female", age);
      const b = pickReferenceRow([...women].reverse(), "female", age);
      expect(a).toEqual(b);
    }
  });

  it("reads a woman under 50 against the follicular row", () => {
    expect(pickReferenceRow(lhRows, "female", 32)?.age_group_en).toBe("Premenopausal (follicular)");
    expect(pickReferenceRow(lhRows, "female", 49)?.age_group_en).toBe("Premenopausal (follicular)");
  });

  it("reads a woman from 50 against the postmenopausal row", () => {
    expect(pickReferenceRow(lhRows, "female", 50)?.age_group_en).toBe("Postmenopausal");
    expect(pickReferenceRow(lhRows, "female", 68)?.age_group_en).toBe("Postmenopausal");
  });

  it("prefers follicular over luteal and generic premenopausal rows", () => {
    const progesterone = [row("female", "Premenopausal (luteal)"), row("female", "Postmenopausal"), row("female", "Premenopausal (follicular)")];
    expect(pickReferenceRow(progesterone, "female", 28)?.age_group_en).toBe("Premenopausal (follicular)");
    const generic = [row("female", "Postmenopausal"), row("female", "Premenopausal")];
    expect(pickReferenceRow(generic, "female", 28)?.age_group_en).toBe("Premenopausal");
  });

  it("falls back to a mid-cycle row only when nothing else matches", () => {
    expect(pickReferenceRow([row("female", "Ovulatory peak"), row("female", "Premenopausal (luteal)")], "female", 30)?.age_group_en).toBe("Ovulatory peak");
  });

  it("prefers the user's sex over 'both', and a numeric band over a label", () => {
    expect(pickReferenceRow([row("both", "All Adults"), row("female", "All Adults")], "female", 40)?.sex).toBe("female");
    expect(pickReferenceRow([row("male", "All Adults"), row("male", "40-59")], "Male", 45)?.age_group_en).toBe("40-59");
  });
});

// ─── The shared age matcher, on every label production uses ───

// Both sides of every band edge, plus a minor.
const AGES = [17, 18, 21, 22, 25, 26, 29, 30, 31, 35, 36, 39, 40, 41, 45, 46, 49, 50, 59, 60, 69, 70, 74, 75, 89, 90, 100];

// Read independently of the code under test: a numeric band contains its ages; every other label except
// hormone therapy (which EVA cannot know) contains every adult.
function expectedContains(label: string, age: number): boolean {
  const band = label.match(/^(\d+)-(\d+)$/);
  if (band) return age >= Number(band[1]) && age <= Number(band[2]);
  const open = label.match(/^(\d+)\+$/);
  if (open) return age >= Number(open[1]);
  return label !== "On Hormone Therapy" && age >= 18;
}

// The row an adult should read: the numeric band containing the age, else "All Adults", else the menopausal
// status the age stands in for (follicular under 50, postmenopausal from 50).
function expectedLabel(labels: string[], age: number): string {
  return (
    labels.find((l) => /\d/.test(l) && expectedContains(l, age)) ??
    (labels.includes("All Adults") ? "All Adults" : age < 50 ? "Premenopausal (follicular)" : "Postmenopausal")
  );
}

const liveRows = LIVE_SETS.flatMap(([biomarker_key, sex, labels]) => labels.map((age_group_en) => ({ biomarker_key, sex, age_group_en })));

describe("ageGroupContains", () => {
  it("the fixture holds every live label", () => {
    expect(new Set(liveRows.map((r) => r.age_group_en))).toEqual(new Set(LIVE_LABELS));
  });

  it.each(LIVE_LABELS)("%s contains exactly the ages it should", (label) => {
    for (const age of AGES) expect(ageGroupContains(label, age), `${label} at ${age}`).toBe(expectedContains(label, age));
  });

  it("reads the other spellings a band can take", () => {
    expect(ageGroupContains("18 - 25", 25)).toBe(true);
    expect(ageGroupContains("18 to 25", 26)).toBe(false);
    expect(ageGroupContains("18 a 25", 18)).toBe(true);
    expect(ageGroupContains("65 and over", 65)).toBe(true);
    expect(ageGroupContains("over 65", 64)).toBe(false);
    expect(ageGroupContains("Under 18", 17)).toBe(true);
    expect(ageGroupContains("ALL ADULTS", 40)).toBe(true);
  });

  it("contains nothing for a missing label or age", () => {
    expect(ageGroupContains(null, 40)).toBe(false);
    expect(ageGroupContains("", 40)).toBe(false);
    expect(ageGroupContains("All Adults", NaN)).toBe(false);
    expect(ageGroupContains("Unknown window", 40)).toBe(false);
  });
});

describe("referenceRowFor, on every live marker's rows, both sexes, ages 18–100", () => {
  const keys = [...new Set(LIVE_SETS.map(([key]) => key))];

  it.each(keys)("%s", (key) => {
    const rows = liveRows.filter((r) => r.biomarker_key === key);
    for (const sex of ["male", "female"]) {
      const own = rows.filter((r) => r.sex === sex || r.sex === "both").map((r) => r.age_group_en);
      for (let age = 18; age <= 100; age++) {
        const { row, ageMatched } = referenceRowFor(rows, sex, age);
        if (own.length === 0) {
          expect(row, `${key} ${sex} ${age}`).toBeUndefined();
          continue;
        }
        expect(ageMatched, `${key} ${sex} ${age}: every adult has a row`).toBe(true);
        expect(row?.age_group_en, `${key} ${sex} ${age}`).toBe(expectedLabel(own, age));
        expect(row?.sex === sex || row?.sex === "both").toBe(true);
        // Never the database order: reversed and rotated lists give the same row.
        expect(referenceRowFor([...rows].reverse(), sex, age).row).toBe(row);
        expect(referenceRowFor([...rows.slice(1), rows[0]], sex, age).row).toBe(row);
      }
    }
  });

  it("never reads the hormone-therapy row or a mid-cycle row", () => {
    const progesterone = liveRows.filter((r) => r.biomarker_key === "progesterone");
    for (let age = 18; age <= 100; age++) {
      const label = referenceRowFor(progesterone, "female", age).row?.age_group_en;
      expect(["Premenopausal (follicular)", "Postmenopausal"]).toContain(label);
    }
  });

  it("a minor still gets one row, the same whatever the order, marked as not age-matched", () => {
    for (const [key, sex] of [["anti_mullerian_hormone_amh", "female"], ["estradiol", "female"], ["tsh", "male"], ["psa_total", "male"]]) {
      const rows = liveRows.filter((r) => r.biomarker_key === key);
      const first = referenceRowFor(rows, sex, 17);
      expect(first.ageMatched).toBe(false);
      expect(first.row).toBeDefined();
      expect(referenceRowFor([...rows].reverse(), sex, 17).row).toBe(first.row);
    }
    expect(referenceRowFor(liveRows.filter((r) => r.biomarker_key === "estradiol"), "female", 17).row?.age_group_en).toBe("Premenopausal (follicular)");
  });
});

describe("pickReferenceRows", () => {
  it("picks one row per marker, and only the person's sex or 'both'", () => {
    const { picked, fallbacks } = pickReferenceRows(liveRows, "male", 45);
    expect(fallbacks).toEqual([]);
    expect(picked.has("anti_mullerian_hormone_amh")).toBe(false); // female rows only
    expect(picked.get("psa_total")?.age_group_en).toBe("18-49");
    expect(picked.get("shbg")?.age_group_en).toBe("40-59");
    expect(picked.get("estradiol")).toMatchObject({ sex: "male", age_group_en: "All Adults" });
    expect(picked.size).toBe(new Set(liveRows.filter((r) => r.sex !== "female").map((r) => r.biomarker_key)).size);
  });

  it("lists the markers that fell back", () => {
    const { picked, fallbacks } = pickReferenceRows(liveRows, "female", 16);
    expect(fallbacks.sort()).toEqual([...picked.keys()].sort());
  });
});
