/**
 * EVA biological age v3: TypeScript port of the frozen model (CHARTER.md test T11, production parity).
 *
 * SHADOW MODE ONLY. `./process-results.ts` uses this module through `./biological-age-v3-adapter.ts`, beside the
 * live biological age, which is still KDM v2.2 (`./biological-age-kdm.ts`). Its result is stored in the
 * `bio_age_v3_shadow` table, which only the service role can read, and is shown to no one. Replacing KDM v2.2 for
 * clients needs CEO and physician approval (ml/biological-age/ATTEMPTS.md, "Orchestrator decision after check S1":
 * conditions for production use).
 *
 * --- Source ---
 * Frozen artifact `ml/biological-age/model-v3.json` (attempt 4, `phenoage_v3_a4_crp_clamp`):
 *   file SHA-256   367072a01cf8edf730f117c0ec4145dd3b5c0f18b980c43aa901bdd95539caa6
 *   model_sha256   dc60ee29d88621c716086434c9894779417a3189fe7c2ee5178f010eec45bb10
 * `ml/biological-age/integration/export_ts_model.py` copies what this module needs, unchanged, into
 * `./data/ba_v3_model.json` (it checks both hashes and records them as `source_file_sha256` and
 * `source_model_sha256`). Python reference: `PhenoAgeV3.predict_ba` and `PhenoAgeV3.predict_interval` in
 * `ml/biological-age/models/candidates/phenoage_v3.py`, with `features.py` (clamps, transforms), `gompertz.py`
 * (conversion to years) and `interval.py` (interval). Parity: `biological-age-v3.parity.test.ts`, on the fixture
 * written by `ml/biological-age/integration/build_ts_parity_fixture.py`.
 *
 * --- Formula --- (model-v3.json `integration_notes.formula`, steps 1-7; the PhenoAge method of Levine et al. 2018
 * and Liu et al. 2018, re-estimated on NHANES III, with the years conversion of BioAge `phenoage_calc.R` at commit
 * b1f9fc02f086cd4aa74185f2335ab1366082e7fe)
 *   1. Sex: male reads the model's "male" entries (NHANES code 1), female the "female" entries (code 2).
 *   2. For each marker j of the tier, in the tier's order: x_j = EVA value x factor_j (the model unit;
 *      `integration_notes.units`); if x_j < lower_j[sex], x_j = lower_j[sex]; then if x_j > upper_j[sex],
 *      x_j = upper_j[sex] (this includes the CRP floor 0.21 mg/dL and cap 1.0 mg/dL); f_j = ln(x_j) for a log
 *      marker, else x_j.
 *   3. eta = a + b_age * age + sum_j b_j * f_j                      (the tier's Gompertz model, NHANES III)
 *   4. BA_u = (ln(-BA_n) + eta + ln(expm1(120 s) / s)) / BA_d + BA_i  (s: the tier's Gompertz shape per month)
 *      This is BioAge's log(BA_n * log(1 - m)) / BA_d + BA_i, m = 1 - exp(-exp(eta) expm1(120 s) / s), written
 *      without forming m (gompertz.py `years_from_eta`).
 *   5. BA = BA_u - slope[sex] * age + c[sex]  (slope: least-squares slope of (BA_u - age) on age in NHANES III, by
 *      sex; c: per-sex intercept set on NHANES IV waves 1-4)
 *   6. Check only: BA = K[sex] + w_age[sex] * age + sum_j w_j * f_j (the tier's linear form), to about 1e-9 years.
 *   7. Interval: BA -/+ z * sqrt(var_meas + var_par), z = 1.959964.
 *      var_meas = sum_j w_j^2 Var_Z[f_j(clamp(x_j exp(Z sigma_j)))], Z ~ N(0, 1), sigma_j = sqrt(CVi_j^2 + 3^2) / 100,
 *      by 64-node Gauss-Hermite quadrature (nodes and weights exported from numpy), with x_j the model-unit value
 *      before clamping; var_par = u' S u, u = (1[male], 1[female], age 1[male], age 1[female], f_1, f_2, ...) and
 *      S the tier's bootstrap parameter covariance (200 NHANES III replicates).
 *
 * --- Tiers --- (ATTEMPTS.md: release rule fixed before sealed run 2; verifier/results/release_by_tier_run2.md)
 *   - `plus_hba1c`: albumin, ALP, hs-CRP, creatinine, BUN, GGT and HbA1c. Used when all seven are present and valid.
 *   - `base`: the six Base Panel serum markers. Used otherwise, when all six are present and valid.
 *   The blood-count tier (`plus_hba1c_cbc`: + lymphocyte %, MCV, RDW, WBC) is not part of version 3 and is absent
 *   from this module and its data. On NHANES 2015-2018, data never used to compute this model's biological age
 *   (check S1), it read 3.03 years older than Base overall, failing S1's composition gate; the Verifier attributes
 *   the shift almost entirely to RDW (median 12.5% in 1999-2006, 13.5% in 2015-2018), an analyzer or method change
 *   being the likely cause (unverified), and blood counts from unknown analyzers would make this worse. It can
 *   return only in a later version. A blood-count value in the input is ignored.
 *
 * --- Inputs and refusals ---
 *   - Inputs are EVA keys in EVA units (`BA_V3_EVA_UNITS`): albumin g/L, alp U/L, hs_crp mg/L, creatinine mg/dL,
 *     bun mg/dL, ggt U/L, hba1c %. A model marker whose unit is not its EVA unit (compared after `normalizeUnit`, so
 *     notation variants such as "g/l" match) is refused with `unit_mismatch`, never converted by guess. Other keys
 *     are ignored. `value` is read as exact: a bounded lab result ("<0.5") must be resolved by the caller.
 *   - A value is valid when it is a finite number, and above zero for a log marker. An invalid HbA1c leaves the
 *     `base` tier; an invalid Base marker gives no result (`invalid_value`).
 *   - Age must be within the validated range 20-84 years, both ends included (the charter's inclusion, on NHANES
 *     ages in whole years; the app's `calculateAge` returns completed years, so 84.5 is outside); outside it there
 *     is no result (`age_outside_validated_range`): the CMO decided against extrapolation.
 *   - Sex: "male" or "female", the KDM code's `Sex`, which process-results derives from `profiles.sex` after
 *     `toLowerCase()`; matched the same way here. Anything else gives `sex_unknown` (process-results would default
 *     it to male; this module does not guess).
 *   - hs-CRP above 10 mg/L is capped at 10 mg/L (1.0 mg/dL in the model) and flagged with `crpCapped: true`; the
 *     caller suggests a retest (CHARTER.md section 4, acute inflammation).
 *
 * Pure and deterministic: no I/O, no clock, no randomness, inputs never mutated.
 */

import type { Sex } from "./biological-age-kdm";
import { normalizeUnit } from "./canonical-units";
import type { BiomarkerInput } from "./longevity-score";
import modelData from "./data/ba_v3_model.json";

// ─── Public types ───

/** The two releasable tiers of version 3, most extended first in the order they are tried. */
export type BiologicalAgeV3Tier = "plus_hba1c" | "base";

/** Why there is no result. */
export type BiologicalAgeV3NullReason =
  | "sex_unknown"
  | "age_outside_validated_range"
  | "unit_mismatch"
  | "duplicate_marker"
  | "missing_markers"
  | "invalid_value";

/** One lab value: an EVA key (`code`), its value, and the unit the value is in (must be the key's EVA unit). */
export interface BiomarkerV3Input extends BiomarkerInput {
  unit: string;
}

/** A credit limit that changed a marker's value (EVA key; which bound). */
export interface BiologicalAgeV3Clamp {
  key: string;
  side: "lower" | "upper";
}

export interface BiologicalAgeV3Result {
  /** Biological age, years. */
  ba: number;
  /** 95% interval [lower, upper], years. */
  interval: [number, number];
  tier: BiologicalAgeV3Tier;
  /** EVA keys of the tier's markers, in the model's order. */
  markersUsed: string[];
  /** Markers whose value was replaced by a credit-limit bound, in the model's order. */
  clampsApplied: BiologicalAgeV3Clamp[];
  /** hs-CRP was above 10 mg/L and was capped at 10 mg/L: the caller suggests a retest. */
  crpCapped: boolean;
  /** `model_sha256` of the frozen artifact this module computes. */
  modelSha256: string;
}

export interface BiologicalAgeV3NoResult {
  ba: null;
  reason: BiologicalAgeV3NullReason;
  /**
   * EVA keys behind the reason: the keys with a wrong unit (`unit_mismatch`), given twice with different values
   * (`duplicate_marker`), missing from the Base tier (`missing_markers`) or invalid in it (`invalid_value`).
   * Empty for `sex_unknown` and `age_outside_validated_range`.
   */
  markers: string[];
}

export type BiologicalAgeV3Outcome = BiologicalAgeV3Result | BiologicalAgeV3NoResult;

// ─── The exported model (./data/ba_v3_model.json) ───

type BySex = { male: number; female: number };

interface MarkerSpec {
  eva_key: string;
  eva_unit: string;
  model_unit: string;
  /** integration_notes.units: model_value = eva_value x factor */
  factor: number;
  transform: "log" | "linear";
  clamp: { lower?: Partial<BySex>; upper?: Partial<BySex> };
  cvi_pct: number;
}

interface TierSpec {
  label: string;
  markers: string[];
  gompertz: { log_rate_intercept: number; shape_per_month: number; coefficients: Record<string, number> };
  age_calibration_slope_per_year: BySex;
  calibration_intercepts_years: BySex;
  linear_form: { constant_years: BySex; age_weight_effective: BySex; marker_weights: Record<string, number> };
  parameter_covariance: { order: string[]; matrix: number[][] };
}

interface ModelSpec {
  source_model_sha256: string;
  source_file_sha256: string;
  tier_order: string[];
  age_years: { min: number; max: number; inclusive: boolean };
  horizon_months: number;
  conversion: { BA_n: number; BA_d: number; BA_i: number };
  markers: Record<string, MarkerSpec>;
  tiers: Record<BiologicalAgeV3Tier, TierSpec>;
  interval: { z: number; analytical_cv_pct: number; quadrature: { nodes: number[]; weights: number[] } };
}

const MODEL = modelData as unknown as ModelSpec;

const TIER_ORDER: readonly BiologicalAgeV3Tier[] = ["plus_hba1c", "base"];

/** Fails at import on a malformed data file (a build error, caught by the tests), never at call time. */
function checkModel(model: ModelSpec): void {
  const fail = (what: string): never => {
    throw new Error(`ba_v3_model.json: ${what}`);
  };
  if (model.tier_order.join(",") !== TIER_ORDER.join(",")) fail(`tier_order ${model.tier_order.join(",")}`);
  const q = model.interval.quadrature;
  if (q.nodes.length !== 64 || q.weights.length !== 64) fail("the quadrature needs 64 nodes and weights");
  for (const tier of TIER_ORDER) {
    const t = model.tiers[tier];
    if (!t) fail(`tier ${tier} missing`);
    const order = ["constant_male", "constant_female", "age_male", "age_female", ...t.markers];
    if (t.parameter_covariance.order.join(",") !== order.join(",")) fail(`${tier}: covariance order`);
    if (t.parameter_covariance.matrix.length !== order.length) fail(`${tier}: covariance size`);
    for (const row of t.parameter_covariance.matrix) if (row.length !== order.length) fail(`${tier}: covariance size`);
    for (const name of ["age", ...t.markers]) {
      if (!Number.isFinite(t.gompertz.coefficients[name])) fail(`${tier}: Gompertz coefficient ${name}`);
    }
    for (const m of t.markers) {
      const spec = model.markers[m];
      if (!spec) fail(`${tier}: marker ${m} has no entry`);
      if (spec.transform !== "log" && spec.transform !== "linear") fail(`${m}: transform ${spec.transform}`);
      if (!(spec.factor > 0)) fail(`${m}: factor ${spec.factor}`);
      if (!Number.isFinite(t.linear_form.marker_weights[m])) fail(`${tier}: marker weight ${m}`);
    }
  }
}
checkModel(MODEL);

/** `model_sha256` of the frozen artifact (model-v3.json) this module computes. */
export const BA_V3_MODEL_SHA256: string = MODEL.source_model_sha256;

/** Validated age range, years, both ends included. */
export const BA_V3_AGE_RANGE: Readonly<{ min: number; max: number }> = Object.freeze({
  min: MODEL.age_years.min,
  max: MODEL.age_years.max,
});

/** The EVA unit each input key must carry: albumin g/L, alp U/L, hs_crp mg/L, creatinine mg/dL, ... */
export const BA_V3_EVA_UNITS: Readonly<Record<string, string>> = Object.freeze(
  Object.fromEntries(Object.values(MODEL.markers).map((s) => [s.eva_key, s.eva_unit])),
);

/** EVA keys of each tier's markers, in the model's order. */
export const BA_V3_TIER_MARKERS: Readonly<Record<BiologicalAgeV3Tier, readonly string[]>> = Object.freeze({
  plus_hba1c: Object.freeze(MODEL.tiers.plus_hba1c.markers.map((m) => MODEL.markers[m].eva_key)),
  base: Object.freeze(MODEL.tiers.base.markers.map((m) => MODEL.markers[m].eva_key)),
});

/** EVA key -> model marker name (hs_crp -> crp; the others are the same). */
const MARKER_BY_EVA_KEY: ReadonlyMap<string, string> = new Map(
  Object.entries(MODEL.markers).map(([marker, spec]) => [spec.eva_key, marker]),
);

// ─── Steps ───

/** Step 1. The KDM code's sex values, compared after toLowerCase() as process-results does; nothing else. */
function resolveSex(sex: unknown): Sex | null {
  if (typeof sex !== "string") return null;
  const s = sex.toLowerCase();
  return s === "male" || s === "female" ? s : null;
}

/** A unit is accepted only when it is the marker's EVA unit, up to notation (canonical-units.normalizeUnit). */
function isEvaUnit(unit: unknown, evaUnit: string): boolean {
  if (typeof unit !== "string") return false;
  const supplied = normalizeUnit(unit);
  return supplied !== "" && supplied === normalizeUnit(evaUnit);
}

/** A finite number, and above zero for a log marker. */
function isValidValue(value: unknown, spec: MarkerSpec): value is number {
  if (typeof value !== "number" || !Number.isFinite(value)) return false;
  return spec.transform !== "log" || value > 0;
}

/**
 * Step 2, the clamp: features.py `apply_clamps` (strict comparisons; the lower bound first, then the upper bound;
 * no bound for this sex means no clamp). Bounds are in the model unit.
 */
function clampValue(x: number, spec: MarkerSpec, sex: Sex): { value: number; side: "lower" | "upper" | null } {
  let value = x;
  let side: "lower" | "upper" | null = null;
  const lo = spec.clamp.lower?.[sex];
  const hi = spec.clamp.upper?.[sex];
  if (lo !== undefined && value < lo) {
    value = lo;
    side = "lower";
  }
  if (hi !== undefined && value > hi) {
    value = hi;
    side = "upper";
  }
  return { value, side };
}

/** Step 2, the transform: features.py `model_input` (natural log for a log marker, identity otherwise). */
function transform(x: number, spec: MarkerSpec): number {
  return spec.transform === "log" ? Math.log(x) : x;
}

/**
 * Step 7, measurement noise of one marker: interval.py `measurement_variance`. A repeat draw is x exp(z sigma),
 * z ~ N(0, 1), sigma = sqrt(CVi^2 + analytical CV^2) / 100 (interval.py `sigma`); each draw is clamped and
 * transformed; the variance over z is computed with the 64-node Gauss-Hermite rule (weights summing to 1).
 * `x` is the model-unit value before clamping.
 */
function measurementVariance(x: number, spec: MarkerSpec, sex: Sex): number {
  const { nodes, weights } = MODEL.interval.quadrature;
  const analytical = MODEL.interval.analytical_cv_pct;
  const sigma = Math.sqrt(spec.cvi_pct ** 2 + analytical ** 2) / 100;
  const f = new Array<number>(nodes.length);
  let mean = 0;
  for (let k = 0; k < nodes.length; k++) {
    f[k] = transform(clampValue(x * Math.exp(nodes[k] * sigma), spec, sex).value, spec);
    mean += f[k] * weights[k];
  }
  let variance = 0;
  for (let k = 0; k < nodes.length; k++) {
    const d = f[k] - mean;
    variance += d * d * weights[k];
  }
  return variance;
}

/** Steps 2 to 7 for one tier, from EVA-unit values that are present and valid for every marker of the tier. */
function computeTier(
  tier: BiologicalAgeV3Tier,
  evaValues: ReadonlyMap<string, number>,
  sex: Sex,
  age: number,
): BiologicalAgeV3Result {
  const t = MODEL.tiers[tier];
  const g = t.gompertz;
  const conv = MODEL.conversion;
  const raw: number[] = []; // model unit, before the clamps (the measurement noise starts from these)
  const f: number[] = []; // after the clamps and the transform
  const clampsApplied: BiologicalAgeV3Clamp[] = [];
  let crpCapped = false;

  // Step 2. integration_notes.units: model_value = eva_value x factor.
  for (const m of t.markers) {
    const spec = MODEL.markers[m];
    const x = (evaValues.get(m) as number) * spec.factor;
    const clamped = clampValue(x, spec, sex);
    if (clamped.side !== null) {
      clampsApplied.push({ key: spec.eva_key, side: clamped.side });
      if (m === "crp" && clamped.side === "upper") crpCapped = true; // above 1.0 mg/dL, i.e. above 10 mg/L
    }
    raw.push(x);
    f.push(transform(clamped.value, spec));
  }

  // Step 3, summed in phenoage_v3.py `linear_predictor`'s order: intercept, then age, then the markers.
  let eta = g.log_rate_intercept;
  eta = eta + g.coefficients.age * age;
  for (let j = 0; j < t.markers.length; j++) eta = eta + g.coefficients[t.markers[j]] * f[j];

  // Step 4: gompertz.py `years_from_eta` and `log_cumhaz_from_eta`; BioAge phenoage_calc.R's inversion.
  const s = g.shape_per_month;
  const logCumulativeHazard = eta + Math.log(Math.expm1(s * MODEL.horizon_months) / s);
  const baUncalibrated = (Math.log(-conv.BA_n) + logCumulativeHazard) / conv.BA_d + conv.BA_i;

  // Step 5: phenoage_v3.py `predict_ba` (the NHANES III age slope by sex, then the per-sex intercept).
  const ba = baUncalibrated - t.age_calibration_slope_per_year[sex] * age + t.calibration_intercepts_years[sex];

  // Step 7: phenoage_v3.py `predict_interval`.
  let varMeasurement = 0;
  for (let j = 0; j < t.markers.length; j++) {
    const m = t.markers[j];
    const w = t.linear_form.marker_weights[m];
    varMeasurement += w * w * measurementVariance(raw[j], MODEL.markers[m], sex);
  }
  const male = sex === "male" ? 1 : 0;
  const female = sex === "female" ? 1 : 0;
  const u = [male, female, age * male, age * female, ...f];
  const S = t.parameter_covariance.matrix;
  let varParameters = 0;
  for (let i = 0; i < u.length; i++) {
    for (let k = 0; k < u.length; k++) varParameters += u[i] * S[i][k] * u[k];
  }
  const sd = Math.sqrt(varMeasurement + varParameters);
  const z = MODEL.interval.z;

  return {
    ba,
    interval: [ba - z * sd, ba + z * sd],
    tier,
    markersUsed: t.markers.map((m) => MODEL.markers[m].eva_key),
    clampsApplied,
    crpCapped,
    modelSha256: MODEL.source_model_sha256,
  };
}

function noResult(reason: BiologicalAgeV3NullReason, markers: string[] = []): BiologicalAgeV3NoResult {
  return { ba: null, reason, markers: [...new Set(markers)] };
}

// ─── Public API ───

/**
 * Biological age v3 (years, with a 95% interval) from EVA-keyed lab values, sex and age in completed years.
 *
 * Checks, in this order, each giving `{ ba: null, reason, markers }`:
 *   1. sex is "male" or "female" (any case)                          else `sex_unknown`
 *   2. age is a number within 20-84, both included                    else `age_outside_validated_range`
 *   3. every model marker present carries its EVA unit                else `unit_mismatch`
 *   4. no model marker is given twice with different values           else `duplicate_marker`
 *   5. tier: `plus_hba1c` if its seven markers are present and valid, else `base` if the six Base markers are;
 *      otherwise `missing_markers` (a Base marker absent) or `invalid_value` (a Base marker present but invalid).
 * Keys that are not model markers (blood counts, lipids, ...) are ignored whatever their unit.
 */
export function computeBiologicalAgeV3(
  inputs: readonly BiomarkerV3Input[],
  sex: string | null | undefined,
  age: number,
): BiologicalAgeV3Outcome {
  const resolvedSex = resolveSex(sex);
  if (resolvedSex === null) return noResult("sex_unknown");

  const range = MODEL.age_years;
  if (typeof age !== "number" || !Number.isFinite(age) || age < range.min || age > range.max) {
    return noResult("age_outside_validated_range");
  }

  const evaValues = new Map<string, number>(); // model marker name -> EVA-unit value
  const wrongUnit: string[] = [];
  const duplicated: string[] = [];
  for (const input of inputs ?? []) {
    if (input === null || typeof input !== "object" || typeof input.code !== "string") continue;
    const marker = MARKER_BY_EVA_KEY.get(input.code);
    if (marker === undefined) continue; // not a marker of version 3
    if (!isEvaUnit(input.unit, MODEL.markers[marker].eva_unit)) {
      wrongUnit.push(input.code);
      continue;
    }
    if (evaValues.has(marker) && !Object.is(evaValues.get(marker), input.value)) duplicated.push(input.code);
    evaValues.set(marker, input.value);
  }
  if (wrongUnit.length > 0) return noResult("unit_mismatch", wrongUnit);
  if (duplicated.length > 0) return noResult("duplicate_marker", duplicated);

  const usable = (m: string) => evaValues.has(m) && isValidValue(evaValues.get(m), MODEL.markers[m]);
  for (const tier of TIER_ORDER) {
    if (MODEL.tiers[tier].markers.every(usable)) return computeTier(tier, evaValues, resolvedSex, age);
  }

  const base = MODEL.tiers.base.markers;
  const missing = base.filter((m) => !evaValues.has(m));
  if (missing.length > 0) return noResult("missing_markers", missing.map((m) => MODEL.markers[m].eva_key));
  return noResult(
    "invalid_value",
    base.filter((m) => !usable(m)).map((m) => MODEL.markers[m].eva_key),
  );
}

// ─── Test-only exports ───
// Internal steps exposed for unit tests only (the pattern of kdm-adapter.ts).
export const __test = {
  MODEL,
  clampValue,
  measurementVariance,
  resolveSex,
  isEvaUnit,
};
