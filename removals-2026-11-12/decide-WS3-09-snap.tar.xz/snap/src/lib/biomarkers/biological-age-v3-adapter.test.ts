/**
 * The biological age v3 adapter (`./biological-age-v3-adapter.ts`): every marker's unit path, urea to BUN, where
 * HbA1c comes from (this result, else the other result drawn closest to it), each HbA1c exclusion, pregnancy (no
 * result at all), bounded values, the hs-CRP cap, age and sex, the creatine adjustment of creatinine, the stored
 * record, and the database reads (scripted database, fake-supabase; no network).
 *
 * Expected numbers come from the frozen module itself (`computeBiologicalAgeV3`) on the inputs each rule says it
 * must receive, so these tests check what the adapter gives the module, not the model.
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import {
  BA_V3_EVA_UNITS,
  BA_V3_MODEL_SHA256,
  BA_V3_TIER_MARKERS,
  computeBiologicalAgeV3,
  type BiologicalAgeV3Result,
  type BiomarkerV3Input,
} from "./biological-age-v3";
import {
  BIO_AGE_V3_ADAPTER_VERSION,
  EVA_LABORATORY_SOURCES,
  HBA1C_WINDOW_DAYS,
  OTHER_RESULT_KEYS,
  PREGNANCY_CONDITION,
  assembleBioAgeV3Inputs,
  bioAgeV3Record,
  completedYearsAt,
  computeBioAgeV3Shadow,
  hba1cPercentFromMmolPerMol,
  laboratoryOf,
  loadBioAgeV3Sources,
  shiftIsoDate,
  type BioAgeV3OtherResult,
  type BioAgeV3Sources,
  type BioAgeV3ValueRow,
} from "./biological-age-v3-adapter";
import { BA_V3_RULES_VERSION } from "./biological-age-v3-rules";
import { getCanonicalUnit, normalizeUnit } from "./canonical-units";
import { UREA_TO_BUN_FACTOR, __test as kdmAdapter } from "./kdm-adapter";
import { calculateAge } from "./zone-classifier";

const NOW = new Date("2026-10-01T09:00:00.000Z");
const DRAW = "2026-09-20";
const DOB = "1976-03-10"; // 50 at the draw

// A typical profile, in the units the app stores (its canonical units).
const TYPICAL: Record<string, number> = { albumin: 43, alp: 70, hs_crp: 3, creatinine: 0.95, bun: 14, ggt: 25 };
const HBA1C = 5.4;

/** A stored row in the key's canonical unit. */
function row(key: string, value: number, more: Partial<BioAgeV3ValueRow> = {}): BioAgeV3ValueRow {
  return { biomarker_key: key, value, unit: getCanonicalUnit(key), comparator: null, normal_low: null, ...more };
}

/** Rows for a set of values; a key set to undefined is left out. */
function rows(values: Record<string, number | undefined>): BioAgeV3ValueRow[] {
  return Object.entries(values)
    .filter((e): e is [string, number] => e[1] !== undefined)
    .map(([k, v]) => row(k, v));
}

/**
 * Sources of one result. By default a venous draw analysed at EVA's laboratory (Echevarne), the only kind the
 * collection-method rule lets through (biological-age-v3-rules.ts); the tests of that rule override both.
 */
function sources(over: Partial<BioAgeV3Sources> = {}): BioAgeV3Sources {
  return {
    values: rows(TYPICAL),
    drawDate: DRAW,
    otherResults: [],
    dateOfBirth: DOB,
    sex: "male",
    conditionKeys: [],
    now: NOW,
    labSource: "echevarne",
    collectionMethod: "venous",
    ...over,
  };
}

function other(id: string, collectionDate: string | null, values: BioAgeV3ValueRow[], createdAt?: string): BioAgeV3OtherResult {
  return { id, collection_date: collectionDate, created_at: createdAt ?? `${collectionDate ?? "2026-01-01"}T10:00:00+00:00`, values };
}

/** The module on values in its own units: what the adapter's record must equal. */
function moduleOn(values: Record<string, number>, sex = "male", age = 50): BiologicalAgeV3Result {
  const inputs: BiomarkerV3Input[] = Object.entries(values).map(([code, value]) => ({ code, value, unit: BA_V3_EVA_UNITS[code] }));
  const outcome = computeBiologicalAgeV3(inputs, sex, age);
  if (outcome.ba === null) throw new Error(`the module gave no result: ${outcome.reason}`);
  return outcome;
}

const inputOf = (s: BioAgeV3Sources, code: string) => assembleBioAgeV3Inputs(s).inputs.filter((i) => i.code === code);
const daysFrom = (date: string, days: number) => shiftIsoDate(date, days);

const MODEL_KEYS = BA_V3_TIER_MARKERS.plus_hba1c; // the six Base markers and HbA1c

describe("units: every marker's path", () => {
  it("the app's canonical unit is the module's unit for each of the seven markers, so none needs converting", () => {
    expect([...MODEL_KEYS].sort()).toEqual(["albumin", "alp", "bun", "creatinine", "ggt", "hba1c", "hs_crp"]);
    for (const key of MODEL_KEYS) {
      expect(normalizeUnit(getCanonicalUnit(key)), key).toBe(normalizeUnit(BA_V3_EVA_UNITS[key]));
    }
    // Urea, the source of a missing BUN, is stored in the unit the factor is defined for.
    expect(getCanonicalUnit("urea")).toBe("mg/dL");
  });

  it.each(MODEL_KEYS)("%s: a value stored in the canonical unit reaches the module unchanged, with that unit", (key) => {
    const s = sources({ values: rows({ ...TYPICAL, hba1c: HBA1C }) });
    const [input] = inputOf(s, key);
    expect(input).toEqual({ code: key, value: { ...TYPICAL, hba1c: HBA1C }[key], unit: getCanonicalUnit(key) });
    const record = bioAgeV3Record(s);
    expect(record.tier).toBe("plus_hba1c");
    expect(record.ba).toBe(moduleOn({ ...TYPICAL, hba1c: HBA1C }).ba);
  });

  it.each(MODEL_KEYS)("%s: a row stored without a unit gets the canonical unit", (key) => {
    for (const unit of ["", null, undefined, "  "]) {
      const values = rows({ ...TYPICAL, hba1c: HBA1C }).map((r) => (r.biomarker_key === key ? { ...r, unit } : r));
      const s = sources({ values });
      expect(inputOf(s, key)[0].unit, `${key} ${JSON.stringify(unit)}`).toBe(getCanonicalUnit(key));
      expect(bioAgeV3Record(s).ba).toBe(moduleOn({ ...TYPICAL, hba1c: HBA1C }).ba);
    }
  });

  it.each([
    ["albumin", "g/l"],
    ["alp", "UI/L"],
    ["hs_crp", "MG/L"],
    ["creatinine", "mg/dl"],
    ["bun", "mg/dl."],
    ["ggt", "U/l"],
    ["hba1c", " % "],
  ])("%s: the notation %j of the canonical unit is labelled with the canonical unit", (key, unit) => {
    const values = rows({ ...TYPICAL, hba1c: HBA1C }).map((r) => (r.biomarker_key === key ? { ...r, unit } : r));
    const s = sources({ values });
    expect(inputOf(s, key)[0].unit).toBe(getCanonicalUnit(key));
    expect(bioAgeV3Record(s).tier).toBe("plus_hba1c");
  });

  it.each([
    ["albumin", "g/dL", 4.3],
    ["alp", "µkat/L", 1.2],
    ["hs_crp", "mg/dL", 0.3],
    ["creatinine", "µmol/L", 84],
    ["bun", "mmol/L", 5],
    ["ggt", "µkat/L", 0.4],
  ])("%s in %s: passed as stored, and the module refuses it (unit_mismatch), never converted by guess", (key, unit, value) => {
    const values = rows(TYPICAL).map((r) => (r.biomarker_key === key ? { ...r, value, unit } : r));
    const s = sources({ values });
    expect(inputOf(s, key)).toEqual([{ code: key, value, unit }]);
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, tier: null, reason: "unit_mismatch" });
  });

  it("HbA1c in mmol/mol: the IFCC-NGSP master equation as research/hba1c.json quotes it, % = mmol/mol / 10.929 + 2.15", () => {
    expect(hba1cPercentFromMmolPerMol(39)).toBe(39 / 10.929 + 2.15);
    expect(hba1cPercentFromMmolPerMol(39)).toBeCloseTo(5.72, 2); // the file's own example: 39 mmol/mol -> 5.72%
    expect(hba1cPercentFromMmolPerMol(23)).toBeCloseTo(4.25, 2); // and 23 -> 4.25%
    const s = sources({ values: [...rows(TYPICAL), row("hba1c", 36, { unit: "mmol/mol" })] });
    expect(inputOf(s, "hba1c")).toEqual([{ code: "hba1c", value: 36 / 10.929 + 2.15, unit: "%" }]);
    const record = bioAgeV3Record(s);
    expect(record).toMatchObject({ tier: "plus_hba1c", hba1c_source: "same_draw", hba1c_excluded_reason: null });
    expect(record.ba).toBe(moduleOn({ ...TYPICAL, hba1c: 36 / 10.929 + 2.15 }).ba);
  });

  it("HbA1c in any other unit: not used, Base tier, unit_not_convertible", () => {
    for (const unit of ["mg/dL", "mmol/L", "ratio"]) {
      const s = sources({ values: [...rows(TYPICAL), row("hba1c", 5.4, { unit })] });
      expect(inputOf(s, "hba1c")).toEqual([]);
      expect(bioAgeV3Record(s), unit).toMatchObject({
        tier: "base",
        hba1c_source: "same_draw",
        hba1c_excluded_reason: "unit_not_convertible",
        ba: moduleOn(TYPICAL).ba,
      });
    }
  });
});

describe("BUN from urea", () => {
  it("uses the factor the app already uses: kdm-adapter's UREA_TO_BUN_FACTOR, 0.4665, the one KDM v2.2 reads", () => {
    expect(UREA_TO_BUN_FACTOR).toBe(0.4665);
    expect(kdmAdapter.CODE_TO_KDM.urea.crossMoleculeFactor).toBe(UREA_TO_BUN_FACTOR);
  });

  it("no bun in the result and urea in mg/dL: BUN = urea x 0.4665, in mg/dL", () => {
    const s = sources({ values: rows({ ...TYPICAL, bun: undefined, urea: 30 }) });
    expect(inputOf(s, "bun")).toEqual([{ code: "bun", value: 30 * UREA_TO_BUN_FACTOR, unit: "mg/dL" }]);
    const record = bioAgeV3Record(s);
    expect(record.tier).toBe("base");
    expect(record.ba).toBe(moduleOn({ ...TYPICAL, bun: 30 * UREA_TO_BUN_FACTOR }).ba);
  });

  it("bun and urea both present: bun is used, urea ignored", () => {
    const s = sources({ values: rows({ ...TYPICAL, urea: 60 }) });
    expect(inputOf(s, "bun")).toEqual([{ code: "bun", value: 14, unit: "mg/dL" }]);
    expect(bioAgeV3Record(s).ba).toBe(moduleOn(TYPICAL).ba);
  });

  it("urea stored without a unit is in the canonical mg/dL", () => {
    const values = rows({ ...TYPICAL, bun: undefined }).concat(row("urea", 30, { unit: "" }));
    expect(inputOf(sources({ values }), "bun")[0].value).toBe(30 * UREA_TO_BUN_FACTOR);
  });

  it("urea in another unit is not converted: no BUN, missing_markers", () => {
    const values = rows({ ...TYPICAL, bun: undefined }).concat(row("urea", 5, { unit: "mmol/L" }));
    const s = sources({ values });
    expect(inputOf(s, "bun")).toEqual([]);
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, reason: "missing_markers" });
  });

  it("urea from another result is never used: Base markers come from this result only", () => {
    const s = sources({
      values: rows({ ...TYPICAL, bun: undefined }),
      otherResults: [other("lab-0", daysFrom(DRAW, -10), [row("urea", 30), row("bun", 14)])],
    });
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, reason: "missing_markers" });
  });
});

describe("Base markers come from this result only", () => {
  it("a Base marker found only in another recent result leaves the Base tier incomplete", () => {
    const s = sources({
      values: rows({ ...TYPICAL, alp: undefined }),
      otherResults: [other("lab-0", daysFrom(DRAW, -5), [row("alp", 70), row("hba1c", 5.4)])],
    });
    expect(assembleBioAgeV3Inputs(s).inputs.map((i) => i.code)).not.toContain("alp");
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, reason: "missing_markers", hba1c_source: "other_result" });
  });

  it("a marker given twice with two values is passed as is, and the module refuses it (duplicate_marker)", () => {
    const s = sources({ values: [...rows(TYPICAL), row("ggt", 40)] });
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, reason: "duplicate_marker" });
  });
});

describe("HbA1c: where it comes from", () => {
  it("this result's own HbA1c: same_draw, Base + HbA1c tier", () => {
    const record = bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hba1c: HBA1C }) }));
    expect(record).toMatchObject({ tier: "plus_hba1c", hba1c_source: "same_draw", hba1c_excluded_reason: null });
    expect(record.markers_used).toEqual(["albumin", "alp", "hs_crp", "creatinine", "bun", "ggt", "hba1c"]);
    expect(record.ba).toBe(moduleOn({ ...TYPICAL, hba1c: HBA1C }).ba);
  });

  it.each([-60, 60, -HBA1C_WINDOW_DAYS, HBA1C_WINDOW_DAYS, 0])(
    "another result drawn %i days from this draw: other_result",
    (days) => {
      const s = sources({ otherResults: [other("lab-0", daysFrom(DRAW, days), [row("hba1c", 5.9)])] });
      const record = bioAgeV3Record(s);
      expect(record).toMatchObject({ tier: "plus_hba1c", hba1c_source: "other_result", hba1c_excluded_reason: null });
      expect(record.ba).toBe(moduleOn({ ...TYPICAL, hba1c: 5.9 }).ba);
    },
  );

  it.each([-(HBA1C_WINDOW_DAYS + 1), HBA1C_WINDOW_DAYS + 1, -365])("another result drawn %i days away: not used", (days) => {
    const s = sources({ otherResults: [other("lab-0", daysFrom(DRAW, days), [row("hba1c", 5.9)])] });
    expect(bioAgeV3Record(s)).toMatchObject({ tier: "base", hba1c_source: null, hba1c_excluded_reason: null });
  });

  it("several within the window: the one drawn closest to this draw, before or after it", () => {
    const results = [
      other("lab-a", daysFrom(DRAW, -80), [row("hba1c", 5.2)]),
      other("lab-b", daysFrom(DRAW, -10), [row("hba1c", 5.9)]),
      other("lab-c", daysFrom(DRAW, 30), [row("hba1c", 6.1)]),
    ];
    expect(inputOf(sources({ otherResults: results }), "hba1c")[0].value).toBe(5.9);
    // A later draw that is closer wins over an earlier one.
    const closerLater = [...results, other("lab-d", daysFrom(DRAW, 4), [row("hba1c", 6.3)])];
    expect(inputOf(sources({ otherResults: closerLater }), "hba1c")[0].value).toBe(6.3);
    // Not the latest draw: lab-c (+30 days) is the most recent, lab-b (-10 days) the closest.
    expect(inputOf(sources({ otherResults: results.slice(1) }), "hba1c")[0].value).toBe(5.9);
    // Read order does not matter.
    expect(inputOf(sources({ otherResults: [...closerLater].reverse() }), "hba1c")[0].value).toBe(6.3);
  });

  it("the closest other result without HbA1c is skipped for the next closest that has it", () => {
    const s = sources({
      otherResults: [
        other("lab-a", daysFrom(DRAW, -40), [row("hba1c", 5.6)]),
        other("lab-b", daysFrom(DRAW, -5), [row("ferritin", 90)]),
        other("lab-c", daysFrom(DRAW, 60), [row("hba1c", 6.2)]),
      ],
    });
    expect(inputOf(s, "hba1c")[0].value).toBe(5.6);
  });

  it("at equal distance, before and after this draw: the one stored last", () => {
    const before = daysFrom(DRAW, -7);
    const after = daysFrom(DRAW, 7);
    const s = (beforeStored: string, afterStored: string) =>
      sources({
        otherResults: [
          other("lab-a", before, [row("hba1c", 5.3)], `${beforeStored}T10:00:00+00:00`),
          other("lab-b", after, [row("hba1c", 5.7)], `${afterStored}T10:00:00+00:00`),
        ],
      });
    expect(inputOf(s(daysFrom(DRAW, 20), after), "hba1c")[0].value).toBe(5.3);
    expect(inputOf(s(before, after), "hba1c")[0].value).toBe(5.7);
  });

  it("two on the same day: the one stored last", () => {
    const day = daysFrom(DRAW, -3);
    const s = sources({
      otherResults: [
        other("lab-a", day, [row("hba1c", 5.3)], `${day}T08:00:00+00:00`),
        other("lab-b", day, [row("hba1c", 5.7)], `${day}T18:00:00+00:00`),
      ],
    });
    expect(inputOf(s, "hba1c")[0].value).toBe(5.7);
  });

  it("this result's HbA1c wins over any other result's", () => {
    const s = sources({
      values: rows({ ...TYPICAL, hba1c: 5.2 }),
      otherResults: [other("lab-0", daysFrom(DRAW, 2), [row("hba1c", 6.4)])],
    });
    expect(inputOf(s, "hba1c")).toEqual([{ code: "hba1c", value: 5.2, unit: "%" }]);
    expect(bioAgeV3Record(s).hba1c_source).toBe("same_draw");
  });

  it("an HbA1c from another result in mmol/mol is converted the same way", () => {
    const s = sources({ otherResults: [other("lab-0", daysFrom(DRAW, -20), [row("hba1c", 40, { unit: "mmol/mol" })])] });
    expect(inputOf(s, "hba1c")).toEqual([{ code: "hba1c", value: 40 / 10.929 + 2.15, unit: "%" }]);
  });

  it("without a draw date on this result, or on the other result, no other result is used", () => {
    const withHbA1c = [other("lab-0", daysFrom(DRAW, -1), [row("hba1c", 5.9)])];
    expect(bioAgeV3Record(sources({ drawDate: null, otherResults: withHbA1c }))).toMatchObject({ tier: "base", hba1c_source: null });
    expect(bioAgeV3Record(sources({ drawDate: "not a date", otherResults: withHbA1c }))).toMatchObject({ hba1c_source: null });
    const undated = [other("lab-0", null, [row("hba1c", 5.9)])];
    expect(bioAgeV3Record(sources({ otherResults: undated }))).toMatchObject({ tier: "base", hba1c_source: null });
  });

  it("an HbA1c outside its plausibility range (3 to 18 %) is supplied and refused: no result (implausible_value)", () => {
    // Changed by the refusal rules (adapter 1.3.0): before them the module dropped the invalid HbA1c and kept the
    // Base tier. Whether an implausible HbA1c refuses the figure or only drops HbA1c is for the physician to confirm.
    const record = bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hba1c: 0 }) }));
    expect(record).toMatchObject({ tier: null, ba: null, hba1c_source: "same_draw", hba1c_excluded_reason: null, reason: "implausible_value" });
    expect(record.reasons).toEqual([expect.objectContaining({ code: "implausible_value", marker: "hba1c" })]);
  });
});

describe("HbA1c exclusions: HbA1c is not used, and the Base tier is computed", () => {
  const BASE_BA = () => moduleOn(TYPICAL).ba;
  const withHbA1c = (extra: BioAgeV3ValueRow[]) => [...rows({ ...TYPICAL, hba1c: HBA1C }), ...extra];

  function expectExcluded(s: BioAgeV3Sources, reason: string, source: "same_draw" | "other_result" = "same_draw") {
    expect(inputOf(s, "hba1c")).toEqual([]);
    expect(bioAgeV3Record(s)).toMatchObject({ tier: "base", ba: BASE_BA(), hba1c_source: source, hba1c_excluded_reason: reason });
  }
  function expectUsed(s: BioAgeV3Sources) {
    expect(bioAgeV3Record(s)).toMatchObject({ tier: "plus_hba1c", hba1c_excluded_reason: null });
  }

  it("anaemia: haemoglobin below the reference lower limit stored with it, in this result", () => {
    expectExcluded(sources({ values: withHbA1c([row("hemoglobin", 11.8, { normal_low: 13 })]) }), "anaemia");
  });

  it("anaemia in another result within the window counts, even with this result's HbA1c", () => {
    const s = sources({
      values: withHbA1c([row("hemoglobin", 14.5, { normal_low: 13 })]),
      otherResults: [other("lab-0", daysFrom(DRAW, -70), [row("hemoglobin", 11.9, { normal_low: 12 })])],
    });
    expectExcluded(s, "anaemia");
  });

  it("anaemia on the result the HbA1c came from (numeric columns read back as strings count too)", () => {
    const hemoglobin: BioAgeV3ValueRow = { biomarker_key: "hemoglobin", value: "10.9", unit: "g/dL", normal_low: "12" };
    const s = sources({ otherResults: [other("lab-0", daysFrom(DRAW, -30), [row("hba1c", 5.9), hemoglobin])] });
    expectExcluded(s, "anaemia", "other_result");
  });

  it("not anaemia: haemoglobin at its lower limit, or with no lower limit stored", () => {
    expectUsed(sources({ values: withHbA1c([row("hemoglobin", 13, { normal_low: 13 })]) }));
    expectUsed(sources({ values: withHbA1c([row("hemoglobin", 9, { normal_low: null })]) }));
  });

  it("anaemia from a bound: '<13' with a lower limit of 13 is below it; '>12' is read at its bound", () => {
    expectExcluded(sources({ values: withHbA1c([row("hemoglobin", 13, { comparator: "<", normal_low: 13 })]) }), "anaemia");
    expectUsed(sources({ values: withHbA1c([row("hemoglobin", 13, { comparator: ">", normal_low: 13 })]) }));
  });

  it("iron deficiency: ferritin below its stored lower limit (also when reported as '<5')", () => {
    expectExcluded(sources({ values: withHbA1c([row("ferritin", 12, { normal_low: 31 })]) }), "iron_deficiency");
    expectExcluded(sources({ values: withHbA1c([row("ferritin", 5, { comparator: "<", normal_low: 31 })]) }), "iron_deficiency");
    expectUsed(sources({ values: withHbA1c([row("ferritin", 31, { normal_low: 31 })]) }));
  });

  it("eGFR below 30 (the stored egfr_creatinine_based, or a legacy egfr row)", () => {
    expectExcluded(sources({ values: withHbA1c([row("egfr_creatinine_based", 25)]) }), "egfr_below_30");
    expectExcluded(sources({ values: withHbA1c([row("egfr_creatinine_based", 30, { comparator: "<" })]) }), "egfr_below_30");
    expectExcluded(sources({ values: withHbA1c([{ biomarker_key: "egfr", value: 22, unit: "mL/min/1.73m²" }]) }), "egfr_below_30");
    expectExcluded(sources({ values: withHbA1c([row("egfr_creatinine_based", 28, { unit: "" })]) }), "egfr_below_30");
    expectUsed(sources({ values: withHbA1c([row("egfr_creatinine_based", 30)]) }));
    expectUsed(sources({ values: withHbA1c([row("egfr_creatinine_based", 90, { comparator: ">" })]) }));
  });

  it("eGFR in another unit is not read", () => {
    expectUsed(sources({ values: withHbA1c([row("egfr_creatinine_based", 0.4, { unit: "mL/s" })]) }));
  });

  it("other conditions in the patient context exclude nothing", () => {
    // Lactation and chronic kidney disease, listed here before the refusal rules, now give no result at all (below).
    expectUsed(sources({ values: withHbA1c([]), conditionKeys: ["prediabetes"] }));
    expect(bioAgeV3Record(sources({ values: withHbA1c([]), conditionKeys: ["lactating"] }))).toMatchObject({ ba: null, reason: "lactation" });
    expect(bioAgeV3Record(sources({ values: withHbA1c([]), conditionKeys: ["ckd"] }))).toMatchObject({ ba: null, reason: "kidney" });
  });

  it("results drawn outside the window do not count", () => {
    const s = sources({
      values: withHbA1c([]),
      otherResults: [other("lab-0", daysFrom(DRAW, -120), [row("hemoglobin", 9, { normal_low: 13 }), row("ferritin", 4, { normal_low: 31 }), row("egfr_creatinine_based", 12)])],
    });
    expectUsed(s);
  });

  it("several hold: the first in the order anaemia, iron deficiency, eGFR", () => {
    const all = [row("hemoglobin", 10, { normal_low: 13 }), row("ferritin", 8, { normal_low: 31 }), row("egfr_creatinine_based", 20)];
    expectExcluded(sources({ values: withHbA1c(all) }), "anaemia");
    expectExcluded(sources({ values: withHbA1c(all.slice(1)) }), "iron_deficiency");
    expectExcluded(sources({ values: withHbA1c(all.slice(2)) }), "egfr_below_30");
  });

  it("no HbA1c anywhere: nothing to exclude, whatever the haemoglobin", () => {
    const s = sources({ values: [...rows(TYPICAL), row("hemoglobin", 9, { normal_low: 13 })] });
    expect(bioAgeV3Record(s)).toMatchObject({ tier: "base", hba1c_source: null, hba1c_excluded_reason: null });
  });
});

describe("pregnancy: no version 3 at all", () => {
  const PREGNANT = ["prediabetes", PREGNANCY_CONDITION];
  const NONE = {
    tier: null, ba: null, interval_low: null, interval_high: null, markers_used: [], clamps_applied: [],
    crp_capped: false, provisional: false, hba1c_source: null, hba1c_excluded_reason: null, reason: "pregnancy",
    bounded_markers: [], lab_source: "echevarne", base_from_eva_laboratory: true, creatine_g_per_day: null,
    creatinine_divisor: 1, rules_version: BA_V3_RULES_VERSION, collection_method: "venous",
  };

  it("a complete Base Panel with HbA1c: ba null, reason pregnancy, nothing else recorded", () => {
    const record = bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hba1c: HBA1C }), sex: "female", conditionKeys: PREGNANT }));
    expect(record).toEqual({
      model_sha256: BA_V3_MODEL_SHA256,
      adapter_version: BIO_AGE_V3_ADAPTER_VERSION,
      computed_at: NOW.toISOString(),
      ...NONE,
      reasons: [{ code: "pregnancy", detail: expect.any(String) }],
    });
  });

  it("whatever else holds: HbA1c from another result, bounds, hs-CRP above 10, a missing marker, any age, any sex", () => {
    const cases: Array<Partial<BioAgeV3Sources>> = [
      { values: rows(TYPICAL), otherResults: [other("lab-0", daysFrom(DRAW, -3), [row("hba1c", 5.9)])] },
      { values: rows(TYPICAL).map((r) => (r.biomarker_key === "hs_crp" ? { ...r, value: 25, comparator: ">" } : r)) },
      { values: rows({ ...TYPICAL, ggt: undefined }) },
      { dateOfBirth: "2010-01-01" },
      { dateOfBirth: null },
      { sex: null },
    ];
    for (const c of cases) {
      expect(bioAgeV3Record(sources({ ...c, conditionKeys: PREGNANT }))).toMatchObject(NONE);
    }
  });

  it("the module is not consulted: an input it would refuse changes nothing", () => {
    const refused = rows(TYPICAL).map((r) => (r.biomarker_key === "albumin" ? { ...r, unit: "g/dL" } : r));
    expect(bioAgeV3Record(sources({ values: refused }))).toMatchObject({ reason: "unit_mismatch" });
    expect(bioAgeV3Record(sources({ values: refused, conditionKeys: PREGNANT }))).toMatchObject({ reason: "pregnancy" });
  });
});

describe("bounded results ('<0.5'): the bound is used and listed", () => {
  it("hs-CRP '<0.5': 0.5 reaches the module and bounded_markers lists it", () => {
    const values = rows(TYPICAL).map((r) => (r.biomarker_key === "hs_crp" ? { ...r, value: 0.5, comparator: "<" } : r));
    const record = bioAgeV3Record(sources({ values }));
    expect(record.bounded_markers).toEqual([{ key: "hs_crp", comparator: "<", value: 0.5 }]);
    expect(record.ba).toBe(moduleOn({ ...TYPICAL, hs_crp: 0.5 }).ba);
  });

  it("every bound given to the module, under the key it received: GGT '>500', urea as BUN, another result's HbA1c", () => {
    const values = rows({ ...TYPICAL, bun: undefined })
      .map((r) => (r.biomarker_key === "ggt" ? { ...r, value: 500, comparator: ">" } : r))
      .concat(row("urea", 10, { comparator: "<" }));
    const s = sources({ values, otherResults: [other("lab-0", daysFrom(DRAW, -7), [row("hba1c", 4, { comparator: "<" })])] });
    expect(bioAgeV3Record(s).bounded_markers).toEqual([
      { key: "ggt", comparator: ">", value: 500 },
      { key: "bun", comparator: "<", value: 10 * UREA_TO_BUN_FACTOR },
      { key: "hba1c", comparator: "<", value: 4 },
    ]);
  });

  it("a bound that was not given to the module (an excluded HbA1c, a haemoglobin) is not listed", () => {
    const s = sources({ values: [...rows(TYPICAL), row("hba1c", 6, { comparator: ">" }), row("hemoglobin", 10, { comparator: "<", normal_low: 13 })] });
    expect(bioAgeV3Record(s)).toMatchObject({ hba1c_excluded_reason: "anaemia", bounded_markers: [] });
  });
});

describe("hs-CRP above 10 mg/L: capped by the module, record provisional", () => {
  it("25 mg/L: crp_capped and provisional", () => {
    const record = bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hs_crp: 25 }) }));
    expect(record).toMatchObject({ crp_capped: true, provisional: true, tier: "base" });
    expect(record.clamps_applied).toContainEqual({ key: "hs_crp", side: "upper" });
  });

  it("10 mg/L: neither", () => {
    expect(bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hs_crp: 10 }) }))).toMatchObject({ crp_capped: false, provisional: false });
  });
});

describe("age and sex", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("age is completed years at the draw", () => {
    expect(assembleBioAgeV3Inputs(sources({ dateOfBirth: "1976-09-21", drawDate: "2026-09-20" })).age).toBe(49);
    expect(assembleBioAgeV3Inputs(sources({ dateOfBirth: "1976-09-21", drawDate: "2026-09-21" })).age).toBe(50);
    expect(assembleBioAgeV3Inputs(sources({ dateOfBirth: "21/09/1976", drawDate: "2026-09-21" })).age).toBe(50);
  });

  it("the module receives that age", () => {
    const record = bioAgeV3Record(sources({ dateOfBirth: "1976-09-21", drawDate: "2026-09-20" }));
    expect(record.ba).toBe(moduleOn(TYPICAL, "male", 49).ba);
  });

  it("without a draw date: completed years when computed, the age KDM v2.2 uses (calculateAge)", () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    vi.setSystemTime(NOW);
    for (const dob of ["1976-03-10", "1980-10-01", "1980-10-02", "15/03/1990"]) {
      expect(completedYearsAt(dob, new Date()), dob).toBe(calculateAge(dob));
      expect(assembleBioAgeV3Inputs(sources({ dateOfBirth: dob, drawDate: null, now: new Date() })).age).toBe(calculateAge(dob));
    }
  });

  it("outside the signed range 20-79 at the draw: no result (age_outside_signed_range); 20 and 79 included", () => {
    // Changed by the refusal rules (adapter 1.3.0): the module accepts 20 to 84 and its reason was
    // age_outside_validated_range; the signed range is 20 to 79 until acceptance check B5 passes, so 80 to 84 are
    // refused too and every age outside the range reads age_outside_signed_range.
    const at = (age: number) => bioAgeV3Record(sources({ dateOfBirth: `${2026 - age}-01-01` }));
    for (const age of [19, 80, 84, 85]) {
      expect(at(age), String(age)).toMatchObject({ ba: null, reason: "age_outside_signed_range" });
    }
    expect(at(20).ba).toEqual(expect.any(Number));
    expect(at(79).ba).toEqual(expect.any(Number));
  });

  it("a date of birth that cannot be read: age_unknown", () => {
    for (const dob of [null, undefined, "", "not a date"]) {
      expect(bioAgeV3Record(sources({ dateOfBirth: dob })), String(dob)).toMatchObject({ ba: null, reason: "age_unknown" });
    }
  });

  it("sex as the module documents: male or female in any case; anything else refused, never defaulted to male", () => {
    const female = moduleOn(TYPICAL, "female").ba;
    expect(bioAgeV3Record(sources({ sex: "Female" })).ba).toBe(female);
    expect(bioAgeV3Record(sources({ sex: "FEMALE" })).ba).toBe(female);
    expect(bioAgeV3Record(sources({ sex: "male" })).ba).toBe(moduleOn(TYPICAL, "male").ba);
    for (const sex of [null, undefined, "", "other", "f"]) {
      expect(bioAgeV3Record(sources({ sex })), String(sex)).toMatchObject({ ba: null, reason: "sex_unknown" });
    }
  });
});

describe("creatine: creatinine divided by the declared dose's divisor", () => {
  const creatine = (dose: string | null) => [{ key: "creatine", dose }];

  it("no declared dose: creatinine as stored, divisor 1", () => {
    for (const supplements of [undefined, null, [], creatine(null), creatine("1 scoop"), [{ key: "vitamin_d", dose: "4000" }]]) {
      const s = sources({ supplements });
      expect(inputOf(s, "creatinine")).toEqual([{ code: "creatinine", value: 0.95, unit: "mg/dL" }]);
      expect(assembleBioAgeV3Inputs(s)).toMatchObject({ creatineGramsPerDay: null, creatinineDivisor: 1 });
    }
  });

  it("3 g/day and more: the pooled 13% rise removed; below, in proportion to the dose", () => {
    const cases: Array<[string, number, number]> = [["5 g", 5, 1.13], ["20 gramos", 20, 1.13], ["3g/día", 3, 1.13], ["1,5 g", 1.5, 1.065]];
    for (const [dose, grams, divisor] of cases) {
      const s = sources({ supplements: creatine(dose) });
      const [creatinine] = inputOf(s, "creatinine");
      expect(creatinine.value, dose).toBeCloseTo(0.95 / divisor, 10);
      expect(assembleBioAgeV3Inputs(s).creatineGramsPerDay, dose).toBe(grams);
      expect(assembleBioAgeV3Inputs(s).creatinineDivisor, dose).toBeCloseTo(divisor, 10);
    }
  });

  it("the module reads the adjusted creatinine: the record equals the module on it, and says what was done", () => {
    const record = bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hba1c: HBA1C }), supplements: creatine("5 g") }));
    const expected = moduleOn({ ...TYPICAL, creatinine: 0.95 / 1.13, hba1c: HBA1C });
    expect(record.ba).toBe(expected.ba);
    expect(record).toMatchObject({ creatine_g_per_day: 5, creatinine_divisor: expect.closeTo(1.13, 10) });
    // Creatine makes the age read younger than the same values without it: the rise is removed.
    expect(record.ba!).toBeLessThan(bioAgeV3Record(sources({ values: rows({ ...TYPICAL, hba1c: HBA1C }) })).ba!);
  });

  it("other markers are untouched", () => {
    const s = sources({ supplements: creatine("5 g") });
    for (const code of ["albumin", "alp", "hs_crp", "bun", "ggt"]) {
      expect(inputOf(s, code), code).toEqual(inputOf(sources(), code));
    }
  });
});

describe("creatinine plausibility: outside 0.2 to 15 mg/dL, no version 3", () => {
  it("an implausible creatinine is withheld and the record says so: 88.4 is µmol/L stored as mg/dL", () => {
    for (const creatinine of [88.4, 15.01, 0.19]) {
      const s = sources({ values: rows({ ...TYPICAL, creatinine }), supplements: [{ key: "creatine", dose: "5 g" }] });
      expect(inputOf(s, "creatinine"), String(creatinine)).toEqual([]);
      expect(assembleBioAgeV3Inputs(s).implausibleMarkers, String(creatinine)).toEqual(["creatinine"]);
      expect(bioAgeV3Record(s), String(creatinine)).toMatchObject({ ba: null, tier: null, reason: "implausible_value" });
    }
  });

  it("with two creatinine rows, an implausible one withholds both, whatever their order", () => {
    for (const pair of [[1.0, 88.4], [88.4, 1.0]]) {
      const s = sources({
        values: [...rows({ ...TYPICAL, creatinine: undefined }), ...pair.map((value) => row("creatinine", value))],
      });
      expect(inputOf(s, "creatinine"), String(pair)).toEqual([]);
      expect(assembleBioAgeV3Inputs(s).implausibleMarkers, String(pair)).toEqual(["creatinine"]);
      expect(bioAgeV3Record(s), String(pair)).toMatchObject({ ba: null, reason: "implausible_value" });
    }
  });

  it("the same result listed twice is given once, the last row; two results are both given and refused", () => {
    const withCreatinine = (...values: number[]) =>
      sources({ values: [...rows({ ...TYPICAL, creatinine: undefined }), ...values.map((value) => row("creatinine", value))] });
    // One creatinine printed in mg/dL and µmol/L: 0.95 and 84 µmol/L × 0.0113.
    const printedTwice = withCreatinine(0.95, 84 * 0.0113);
    expect(inputOf(printedTwice, "creatinine").map((i) => i.value)).toEqual([84 * 0.0113]);
    expect(bioAgeV3Record(printedTwice).ba).not.toBeNull();
    expect(bioAgeV3Record(withCreatinine(1.0, 1.0)).ba).toBe(bioAgeV3Record(withCreatinine(1.0)).ba);
    // Two different results: both reach the module, which refuses them.
    const different = withCreatinine(0.9, 1.1);
    expect(inputOf(different, "creatinine")).toHaveLength(2);
    expect(assembleBioAgeV3Inputs(different).implausibleMarkers).toEqual([]);
    expect(bioAgeV3Record(different)).toMatchObject({ ba: null, reason: "duplicate_marker" });
  });

  it("both ends are plausible, and the range applies to the measured value, before the creatine divisor", () => {
    // 15 mg/dL is plausible but above the upper reference limit: refused by the kidney rule, not as implausible
    // (changed by the refusal rules, adapter 1.3.0: before them 15 gave a figure).
    expect(bioAgeV3Record(sources({ values: rows({ ...TYPICAL, creatinine: 15 }) }))).toMatchObject({ ba: null, reason: "kidney" });
    const low = sources({ values: rows({ ...TYPICAL, creatinine: 0.2 }), supplements: [{ key: "creatine", dose: "5 g" }] });
    expect(inputOf(low, "creatinine")[0].value).toBeCloseTo(0.2 / 1.13, 10);
    expect(bioAgeV3Record(low).ba).not.toBeNull();
  });

  it("creatinine in another unit is not judged here: the module refuses the unit", () => {
    const s = sources({ values: [...rows({ ...TYPICAL, creatinine: undefined }), row("creatinine", 88.4, { unit: "µmol/L" })] });
    expect(assembleBioAgeV3Inputs(s).implausibleMarkers).toEqual([]);
    expect(bioAgeV3Record(s)).toMatchObject({ ba: null, reason: "unit_mismatch" });
  });
});

describe("the stored record", () => {
  const KEYS = [
    "model_sha256", "adapter_version", "computed_at", "tier", "ba", "interval_low", "interval_high", "markers_used",
    "clamps_applied", "crp_capped", "provisional", "hba1c_source", "hba1c_excluded_reason", "reason", "bounded_markers",
    "lab_source", "base_from_eva_laboratory", "creatine_g_per_day", "creatinine_divisor", "reasons", "rules_version",
    "collection_method",
  ];

  it("a result: the module's numbers, the model hash, the adapter version, when; JSON as stored", () => {
    const s = sources({ values: rows({ ...TYPICAL, hba1c: HBA1C, albumin: 55 }) });
    const record = bioAgeV3Record(s);
    const expected = moduleOn({ ...TYPICAL, hba1c: HBA1C, albumin: 55 });
    expect(Object.keys(record).sort()).toEqual([...KEYS].sort());
    expect(record).toEqual({
      model_sha256: BA_V3_MODEL_SHA256,
      adapter_version: BIO_AGE_V3_ADAPTER_VERSION,
      computed_at: NOW.toISOString(),
      tier: "plus_hba1c",
      ba: expected.ba,
      interval_low: expected.interval[0],
      interval_high: expected.interval[1],
      markers_used: expected.markersUsed,
      clamps_applied: [{ key: "albumin", side: "upper" }],
      crp_capped: false,
      provisional: false,
      hba1c_source: "same_draw",
      hba1c_excluded_reason: null,
      reason: null,
      reasons: [],
      rules_version: BA_V3_RULES_VERSION,
      collection_method: "venous",
      bounded_markers: [],
      lab_source: "echevarne",
      base_from_eva_laboratory: true,
      creatine_g_per_day: null,
      creatinine_divisor: 1,
    });
    expect(record.model_sha256).toBe("dc60ee29d88621c716086434c9894779417a3189fe7c2ee5178f010eec45bb10");
    expect(JSON.parse(JSON.stringify(record))).toEqual(record);
  });

  it("no result: ba null with the module's reason, the rest empty", () => {
    const record = bioAgeV3Record(sources({ values: rows({ ...TYPICAL, ggt: undefined }) }));
    expect(Object.keys(record).sort()).toEqual([...KEYS].sort());
    expect(record).toMatchObject({
      tier: null, ba: null, interval_low: null, interval_high: null, markers_used: [], clamps_applied: [],
      crp_capped: false, provisional: false, reason: "missing_markers", model_sha256: BA_V3_MODEL_SHA256,
      reasons: [{ code: "missing_markers", marker: "ggt", detail: expect.any(String) }],
    });
  });

  it("the sources are not modified", () => {
    const s = sources({
      values: [...rows({ ...TYPICAL, bun: undefined, urea: 30 }), row("hemoglobin", 14, { normal_low: 13 })],
      otherResults: [other("lab-0", daysFrom(DRAW, -20), [row("hba1c", 40, { unit: "mmol/mol" })])],
    });
    const before = structuredClone(s);
    bioAgeV3Record(s);
    expect(s).toEqual(before);
  });
});

describe("the laboratory: lab_source and base_from_eva_laboratory", () => {
  /** A record without the two laboratory fields: version 3's own. */
  const v3Fields = (r: object) =>
    Object.fromEntries(Object.entries(r).filter(([k]) => k !== "lab_source" && k !== "base_from_eva_laboratory"));

  it("EVA's own laboratory is Echevarne: the bridge's 'echevarne' and the admin entry's 'lab_partner'", () => {
    expect([...EVA_LABORATORY_SOURCES].sort()).toEqual(["echevarne", "lab_partner"]);
    for (const source of ["echevarne", "lab_partner"]) {
      expect(laboratoryOf(source), source).toEqual({ lab_source: source, base_from_eva_laboratory: true });
    }
  });

  it("any other source is not EVA's laboratory, kept as stored; no source at all is null", () => {
    for (const source of ["user_upload", "upload", "manual", "eva_kit", "eva", "Echevarne", " echevarne", ""]) {
      expect(laboratoryOf(source), source).toEqual({ lab_source: source, base_from_eva_laboratory: false });
    }
    for (const source of [null, undefined, 42]) {
      expect(laboratoryOf(source), String(source)).toEqual({ lab_source: null, base_from_eva_laboratory: false });
    }
  });

  it("on every record; only a result from EVA's laboratory can give a figure (collection_method otherwise)", () => {
    // Changed by the refusal rules (adapter 1.3.0): before them version 3 was computed whatever the laboratory
    // (shadow mode), and an upload gave the same figure as an Echevarne result.
    const cases: Array<Partial<BioAgeV3Sources>> = [
      {},
      { values: rows({ ...TYPICAL, hba1c: HBA1C }) },
      { values: rows({ ...TYPICAL, ggt: undefined }) },
      { conditionKeys: [PREGNANCY_CONDITION] },
    ];
    for (const c of cases) {
      const eva = bioAgeV3Record(sources({ ...c, labSource: "echevarne" }));
      const upload = bioAgeV3Record(sources({ ...c, labSource: "user_upload" }));
      const unread = bioAgeV3Record(sources({ ...c, labSource: null }));
      expect(eva).toMatchObject({ lab_source: "echevarne", base_from_eva_laboratory: true });
      expect(upload).toMatchObject({ lab_source: "user_upload", base_from_eva_laboratory: false });
      expect(unread).toMatchObject({ lab_source: null, base_from_eva_laboratory: false });
      for (const other of [upload, unread]) {
        expect(other.ba).toBeNull();
        expect(other.reasons.map((r) => r.code)).toContain("collection_method");
      }
      if (eva.reason !== "pregnancy") expect(upload.reason).toBe("collection_method");
      else expect(v3Fields(upload)).toMatchObject({ reason: "pregnancy", ba: null });
    }
    expect(bioAgeV3Record(sources({ labSource: "echevarne" })).ba).toBe(moduleOn(TYPICAL).ba);
    expect(bioAgeV3Record(sources({ labSource: "user_upload" })).ba).toBeNull();
  });
});

// ─── Reading the sources (scripted database) ───

type Script = {
  lab?: {
    collection_date: string | null;
    created_at?: string | null;
    patient_context_version_id: string | null;
    source?: string | null;
  } | null;
  ownValues?: BioAgeV3ValueRow[];
  otherLabs?: Array<{ id: string; collection_date: string | null; created_at: string | null }>;
  otherValues?: Array<BioAgeV3ValueRow & { lab_result_id: string }>;
  snapshot?: { conditions: { keys: string[] }; supplements?: unknown } | null;
  latest?: { conditions: { keys: string[] }; supplements?: unknown } | null;
  failOn?: string;
};

function scripted(script: Script) {
  const respond = (c: FakeCall): FakeResponse => {
    const select = String(argsOf(c, "select")?.[0] ?? "");
    const key = `${c.table}:${select}`;
    if (script.failOn && key.startsWith(script.failOn)) return { error: { message: "connection reset" } };
    if (c.table === "lab_results" && select === "collection_date, created_at, patient_context_version_id, source") return { data: script.lab ?? null };
    if (c.table === "lab_results" && select === "id, collection_date, created_at") return { data: script.otherLabs ?? [] };
    if (c.table === "biomarker_values" && select.startsWith("lab_result_id")) return { data: script.otherValues ?? [] };
    if (c.table === "biomarker_values") return { data: script.ownValues ?? [] };
    if (c.table === "patient_context_versions" && argsOf(c, "eq", "id")) return { data: script.snapshot ?? null };
    if (c.table === "patient_context_versions") return { data: script.latest ?? null };
    throw new Error(`unexpected call ${key} ${ops(c)}`);
  };
  return fakeSupabase(respond);
}

const ARGS = { userId: "u1", labResultId: "lab-1", profile: { date_of_birth: DOB, sex: "male" }, now: NOW };

describe("reading the sources", () => {
  it("this result's draw date, the other results of the window with their HbA1c and exclusion rows, the context snapshot", async () => {
    const own = rows(TYPICAL);
    const { client, calls } = scripted({
      lab: { collection_date: DRAW, patient_context_version_id: "ctx-7", source: "echevarne" },
      otherLabs: [{ id: "lab-0", collection_date: "2026-08-21", created_at: "2026-08-22T10:00:00+00:00" }],
      otherValues: [{ lab_result_id: "lab-0", ...row("hba1c", 5.8) }, { lab_result_id: "lab-0", ...row("hemoglobin", 14, { normal_low: 13 }) }],
      snapshot: { conditions: { keys: ["pregnancy_current"] }, supplements: [{ key: "creatine", dose: "5 g" }] },
    });
    const s = await loadBioAgeV3Sources(client, { ...ARGS, values: own });

    expect(s).toEqual({
      values: own,
      drawDate: DRAW,
      otherResults: [
        {
          id: "lab-0",
          collection_date: "2026-08-21",
          created_at: "2026-08-22T10:00:00+00:00",
          values: [{ lab_result_id: "lab-0", ...row("hba1c", 5.8) }, { lab_result_id: "lab-0", ...row("hemoglobin", 14, { normal_low: 13 }) }],
        },
      ],
      dateOfBirth: DOB,
      sex: "male",
      conditionKeys: ["pregnancy_current"],
      supplements: [{ key: "creatine", dose: "5 g" }],
      now: NOW,
      labSource: "echevarne",
      collectionMethod: null, // the app records no collection method yet
    });

    // This result, by id and owner.
    const [lab, others, otherValues, context] = calls;
    expect(lab.ops).toEqual([
      { op: "select", args: ["collection_date, created_at, patient_context_version_id, source"] },
      { op: "eq", args: ["id", "lab-1"] },
      { op: "eq", args: ["user_id", "u1"] },
      { op: "maybeSingle", args: [] },
    ]);
    // The client's other results: not this one, processed, drawn within 90 days either side.
    expect(others.table).toBe("lab_results");
    expect(others.ops).toEqual([
      { op: "select", args: ["id, collection_date, created_at"] },
      { op: "eq", args: ["user_id", "u1"] },
      { op: "neq", args: ["id", "lab-1"] },
      { op: "in", args: ["status", ["ready", "pending_context"]] },
      { op: "gte", args: ["collection_date", "2026-06-22"] },
      { op: "lte", args: ["collection_date", "2026-12-19"] },
    ]);
    // Only the rows HbA1c and its exclusions need.
    expect(otherValues.ops).toEqual([
      { op: "select", args: ["lab_result_id, biomarker_key, value, unit, comparator, normal_low"] },
      { op: "in", args: ["lab_result_id", ["lab-0"]] },
      { op: "in", args: ["biomarker_key", [...OTHER_RESULT_KEYS]] },
    ]);
    expect(context.table).toBe("patient_context_versions");
    expect(argsOf(context, "select")).toEqual(["conditions, supplements"]);
    expect(argsOf(context, "eq", "id")).toEqual(["id", "ctx-7"]);
    expect(argsOf(context, "eq", "user_id")).toEqual(["user_id", "u1"]);
    // Read-only: no other call, and no write.
    expect(calls).toHaveLength(4);
    expect(calls.every((c) => ops(c).startsWith("select"))).toBe(true);
  });

  it("this result's lab_results.source comes with its draw date; null when the row has none or is not found", async () => {
    const cases: Array<[Script["lab"], string | null]> = [
      [{ collection_date: DRAW, patient_context_version_id: null, source: "lab_partner" }, "lab_partner"],
      [{ collection_date: DRAW, patient_context_version_id: null, source: "user_upload" }, "user_upload"],
      [{ collection_date: DRAW, patient_context_version_id: null }, null],
      [null, null],
    ];
    for (const [lab, expected] of cases) {
      const { client, calls } = scripted({ lab, otherLabs: [] });
      expect((await loadBioAgeV3Sources(client, { ...ARGS, values: [] })).labSource, String(expected)).toBe(expected);
      expect(calls.filter((c) => c.table === "lab_results").length).toBeLessThanOrEqual(2);
    }
  });

  it("the recompute path reads this result's own rows, with units, bounds and lower and upper limits", async () => {
    const own = [row("hs_crp", 0.5, { comparator: "<" }), row("albumin", 43)];
    const { client, calls } = scripted({ lab: { collection_date: DRAW, patient_context_version_id: null }, ownValues: own });
    const s = await loadBioAgeV3Sources(client, { ...ARGS, values: null });
    expect(s.values).toEqual(own);
    const read = calls.find((c) => c.table === "biomarker_values")!;
    expect(read.ops).toEqual([
      { op: "select", args: ["biomarker_key, value, unit, comparator, normal_low, normal_high"] },
      { op: "eq", args: ["lab_result_id", "lab-1"] },
    ]);
  });

  it("no context snapshot on the result: the client's latest context version created on or before it", async () => {
    const { client, calls } = scripted({
      lab: { collection_date: DRAW, created_at: "2026-09-21T10:00:00+00:00", patient_context_version_id: null },
      latest: { conditions: { keys: ["pregnancy_current"] } },
    });
    const s = await loadBioAgeV3Sources(client, { ...ARGS, values: [] });
    expect(s.conditionKeys).toEqual(["pregnancy_current"]);
    const context = calls.filter((c) => c.table === "patient_context_versions");
    expect(context).toHaveLength(1);
    expect(argsOf(context[0], "eq", "user_id")).toEqual(["user_id", "u1"]);
    expect(argsOf(context[0], "lte", "created_at")).toEqual(["created_at", "2026-09-21T10:00:00+00:00"]);
    expect(argsOf(context[0], "order")).toEqual(["version_number", { ascending: false }]);
  });

  it("a snapshot that no longer exists falls back to the version in force at the result", async () => {
    const { client, calls } = scripted({
      lab: { collection_date: DRAW, created_at: "2026-09-21T10:00:00+00:00", patient_context_version_id: "gone" },
      snapshot: null,
      latest: { conditions: { keys: ["ckd"] } },
    });
    expect((await loadBioAgeV3Sources(client, { ...ARGS, values: [] })).conditionKeys).toEqual(["ckd"]);
    const fallback = calls.filter((c) => c.table === "patient_context_versions")[1];
    expect(argsOf(fallback, "lte", "created_at")).toEqual(["created_at", "2026-09-21T10:00:00+00:00"]);
  });

  it("no draw date: other results are not read", async () => {
    const { client, calls } = scripted({ lab: { collection_date: null, patient_context_version_id: null } });
    const s = await loadBioAgeV3Sources(client, { ...ARGS, values: [] });
    expect(s).toMatchObject({ drawDate: null, otherResults: [], conditionKeys: [] });
    expect(calls.filter((c) => c.table === "lab_results")).toHaveLength(1);
  });

  it("no other result in the window: their values are not read", async () => {
    const { client, calls } = scripted({ lab: { collection_date: DRAW, patient_context_version_id: null }, otherLabs: [] });
    await loadBioAgeV3Sources(client, { ...ARGS, values: [] });
    expect(calls.filter((c) => c.table === "biomarker_values")).toHaveLength(0);
  });

  it.each([
    "lab_results:collection_date",
    "lab_results:id, collection_date",
    "biomarker_values:lab_result_id",
    "biomarker_values:biomarker_key",
    "patient_context_versions",
  ])("a database error reading %s throws (the caller stores { reason: \"error\" })", async (failOn) => {
    const { client } = scripted({
      lab: { collection_date: DRAW, patient_context_version_id: null },
      otherLabs: [{ id: "lab-0", collection_date: DRAW, created_at: null }],
      failOn,
    });
    await expect(computeBioAgeV3Shadow(client, { ...ARGS, values: null })).rejects.toThrow(/biological age v3: reading .* failed: connection reset/);
  });

  it("end to end: HbA1c from the closest other result, excluded by the anaemia that result shows", async () => {
    const { client } = scripted({
      lab: { collection_date: DRAW, patient_context_version_id: "ctx-1" },
      ownValues: rows(TYPICAL),
      otherLabs: [
        { id: "lab-0", collection_date: "2026-07-01", created_at: null },
        { id: "lab-9", collection_date: "2026-09-25", created_at: null },
      ],
      otherValues: [
        { lab_result_id: "lab-0", ...row("hba1c", 5.8) },
        { lab_result_id: "lab-9", ...row("hba1c", 6.1) },
        { lab_result_id: "lab-9", ...row("hemoglobin", 10.5, { normal_low: 12 }) },
      ],
      snapshot: { conditions: { keys: [] } },
    });
    const record = await computeBioAgeV3Shadow(client, { ...ARGS, values: null });
    // The app records no collection method, so no figure (changed by the refusal rules, adapter 1.3.0: before them
    // the Base tier figure); the HbA1c choice is still recorded.
    expect(record).toMatchObject({ tier: null, ba: null, reason: "collection_method", hba1c_source: "other_result", hba1c_excluded_reason: "anaemia" });
    expect(bioAgeV3Record({ ...(await loadBioAgeV3Sources(client, { ...ARGS, values: null })), labSource: "echevarne", collectionMethod: "venous" })).toMatchObject({
      tier: "base", ba: moduleOn(TYPICAL).ba, hba1c_source: "other_result", hba1c_excluded_reason: "anaemia",
    });
  });

  it("end to end: a result from EVA's laboratory and one uploaded by the client: no figure while the method is unknown", async () => {
    const run = async (source: string) => {
      const { client } = scripted({
        lab: { collection_date: DRAW, patient_context_version_id: null, source },
        ownValues: rows(TYPICAL),
        otherLabs: [],
      });
      return computeBioAgeV3Shadow(client, { ...ARGS, values: null });
    };
    const eva = await run("echevarne");
    const upload = await run("user_upload");
    // Changed by the refusal rules (adapter 1.3.0): before them both gave the same figure.
    expect(eva).toMatchObject({ lab_source: "echevarne", base_from_eva_laboratory: true, ba: null, reason: "collection_method", collection_method: "unknown" });
    expect(upload).toMatchObject({ lab_source: "user_upload", base_from_eva_laboratory: false, ba: null, reason: "collection_method" });
  });

  it("end to end: the pregnancy the context snapshot records means no version 3", async () => {
    const { client } = scripted({
      lab: { collection_date: DRAW, patient_context_version_id: "ctx-1" },
      ownValues: rows({ ...TYPICAL, hba1c: HBA1C }),
      snapshot: { conditions: { keys: ["pregnancy_current"] } },
    });
    expect(await computeBioAgeV3Shadow(client, { ...ARGS, values: null })).toMatchObject({ ba: null, reason: "pregnancy" });
  });
});
