/**
 * Biological age v3 in shadow mode, inside processing. After processLabResults and recomputeLabMetrics write the
 * KDM v2.2 values, the v3 record the adapter computes from the same values is upserted into bio_age_v3_shadow on
 * lab_result_id, always through the service-role client (createAdminClient), never through the caller's client.
 * lab_results receives exactly what it received before v3 existed, and every KDM, score and count value, and the
 * result processLabResults returns, are the same whether v3 works, throws, meets a database error, hangs past its
 * time budget, fails to load, has no service role, or cannot store its record.
 * Scripted databases (fake-supabase), no network.
 */
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { getCanonicalUnit } from "./canonical-units";
import { computeComprehensiveBA, computeReferenceBA, KDM_REFERENCE_BA_METHOD } from "./biological-age-kdm";
import { bioAgeV3Record, type BioAgeV3ValueRow } from "./biological-age-v3-adapter";
import { BIO_AGE_V3_BUDGET_MS, processLabResults, recomputeLabMetrics } from "./process-results";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

const v3 = vi.hoisted(() => ({ mode: "real" as "real" | "throw" | "hang" }));

// The service-role client: a scripted one that only accepts the shadow upsert. Every call on either client goes
// into one log, in order.
const shadow = vi.hoisted(() => ({
  available: true,
  storeError: null as null | { code: string; message: string },
  upserts: [] as unknown[][],
  log: [] as string[],
}));

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));

vi.mock("@/lib/supabase/admin", async () => {
  const fake = await import("@/lib/testing/fake-supabase");
  return {
    createAdminClient: () => {
      if (!shadow.available) return null;
      return fake.fakeSupabase((c) => {
        shadow.log.push(`service-role ${c.table} ${fake.ops(c)}`);
        if (c.table !== "bio_age_v3_shadow" || !fake.ops(c).startsWith("upsert")) {
          throw new Error(`unexpected service-role call: ${c.table} ${fake.ops(c)}`);
        }
        shadow.upserts.push(fake.argsOf(c, "upsert") ?? []);
        return shadow.storeError ? { error: shadow.storeError } : { data: null };
      }).client;
    },
  };
});

// The adapter as shipped, except that a test can make its entry point throw or never settle.
vi.mock("./biological-age-v3-adapter", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./biological-age-v3-adapter")>();
  return {
    ...actual,
    computeBioAgeV3Shadow: (...args: Parameters<typeof actual.computeBioAgeV3Shadow>) => {
      if (v3.mode === "throw") throw new Error("v3 exploded");
      if (v3.mode === "hang") return new Promise<never>(() => {});
      return actual.computeBioAgeV3Shadow(...args);
    },
  };
});

const NOW = new Date("2026-10-01T09:00:00.000Z");
const DOB = "1976-03-10"; // 50 now and at the draw
const AGE = 50;
const DRAW = "2026-09-20";
const ROWS = reviewedRows();

// A Base Panel and a few more tests, in the units results are stored in, without HbA1c: the HbA1c comes from
// another result drawn a month earlier, so the v3 record reads the client's other results.
const VALUES: Record<string, number> = {
  albumin: 44, alp: 72, hs_crp: 1.8, creatinine: 1.0, bun: 15, ggt: 32, uric_acid: 6.0, total_cholesterol: 205,
  hdl_cholesterol: 47, triglycerides: 140, apolipoprotein_b_apob: 105, alt: 30, fructosamine: 190,
  ldl_cholesterol: 130, ast: 25, glucose_fasting: 96, hemoglobin: 15.2, ferritin: 180, vitamin_d_25_oh: 24, tsh: 1.9,
};
const LOWER_LIMIT: Record<string, number> = { hemoglobin: 13, ferritin: 31 };
const OTHER_LAB = { id: "lab-0", collection_date: "2026-08-21", created_at: "2026-08-22T10:00:00+00:00" };
const OTHER_VALUES = [
  { lab_result_id: "lab-0", biomarker_key: "hba1c", value: 5.6, unit: "%", comparator: null, normal_low: 4.3 },
];
// This result as stored, for the recompute path.
const STORED = Object.entries(VALUES).map(([biomarker_key, value]) => ({
  biomarker_key, value, unit: getCanonicalUnit(biomarker_key), comparator: null,
  normal_low: LOWER_LIMIT[biomarker_key] ?? null, zone: "optimal",
}));
const RAW = Object.entries(VALUES).map(([key, value]) => ({
  name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const,
}));
const KDM_COLUMNS_BEFORE_V3 = [
  "action_count", "attention_count", "bio_age_applied_spanish_calibration", "bio_age_method", "bio_age_n_markers",
  "biological_age", "biological_age_comprehensive", "longevity_grade", "longevity_score", "optimal_count",
];

const asInputs = (values: Record<string, number>) => Object.entries(values).map(([code, value]) => ({ code, value }));

type Options = { profile?: { date_of_birth: string | null; sex: string | null }; v3ReadFails?: boolean };

/** The caller's client (user-scoped or not, processing cannot tell): a scripted database. */
function database(options: Options = {}) {
  const updates: Array<Record<string, unknown>> = [];
  let inserted: BioAgeV3ValueRow[] = [];
  const respond = (c: FakeCall): FakeResponse => {
    const select = String(argsOf(c, "select")?.[0] ?? "");
    const op = ops(c);
    shadow.log.push(`caller ${c.table} ${op}`);
    if (c.table === "profiles" && op.startsWith("select")) return { data: options.profile ?? { date_of_birth: DOB, sex: "male" } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "biomarker_values" && op.startsWith("insert")) {
      inserted = argsOf(c, "insert")?.[0] as BioAgeV3ValueRow[];
      return { data: null };
    }
    // Reads only the v3 adapter makes.
    if (c.table === "lab_results" && select === "collection_date, created_at, patient_context_version_id, source") {
      return options.v3ReadFails ? { error: { message: "connection reset" } } : { data: { collection_date: DRAW, patient_context_version_id: null } };
    }
    if (c.table === "lab_results" && select === "id, collection_date, created_at") return { data: [OTHER_LAB] };
    if (c.table === "biomarker_values" && select === "lab_result_id, biomarker_key, value, unit, comparator, normal_low") {
      return { data: OTHER_VALUES };
    }
    if (c.table === "patient_context_versions" && select === "conditions, supplements") return { data: { conditions: { keys: [] } } };
    // This result's stored rows (recomputeLabMetrics, and v3 on that path).
    if (c.table === "biomarker_values" && op.startsWith("select")) return { data: STORED };
    if (c.table === "lab_results" && op.startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      if ("optimal_count" in update) updates.push(update);
    }
    return { data: null };
  };
  const { client, calls } = fakeSupabase(respond);
  const writes = () => calls.filter((c) => /^(insert|update|upsert|delete)/.test(ops(c))).map((c) => ({ table: c.table, ops: c.ops }));
  // The reads only v3 makes, by their exact column lists (the rolling average also reads lab_result_id and
  // collection_date, with other columns).
  const V3_SELECTS = [
    /^collection_date, created_at, patient_context_version_id, source$/,
    /^id, collection_date, created_at$/,
    /^(lab_result_id, )?biomarker_key, value, unit, comparator, normal_low$/,
    /^conditions, supplements$/,
  ];
  const v3Reads = () => calls.filter((c) => V3_SELECTS.some((re) => re.test(String(argsOf(c, "select")?.[0] ?? ""))));
  return { client, calls, updates, writes, v3Reads, inserted: () => inserted };
}

/** The v3 record the adapter gives on these sources. */
function expectedRecord(
  values: readonly BioAgeV3ValueRow[],
  profile = { dateOfBirth: DOB as string | null, sex: "male" as string | null },
  collection: { collectionMethod?: string | null; labSource?: string | null } = {},
) {
  return bioAgeV3Record({
    values,
    drawDate: DRAW,
    otherResults: [{ ...OTHER_LAB, values: OTHER_VALUES }],
    dateOfBirth: profile.dateOfBirth,
    sex: profile.sex,
    conditionKeys: [],
    now: NOW,
    ...collection,
  });
}

/** The single upsert the shadow write must be. */
const upsertOf = (record: unknown) => [
  { lab_result_id: "lab-1", user_id: "u1", record, computed_at: NOW.toISOString() },
  { onConflict: "lab_result_id" },
];

/** What KDM v2.2 writes for these values: computed by its own modules, with no v3 code involved. */
function kdmColumns() {
  const reference = computeReferenceBA(asInputs(VALUES), "male", AGE, { supplements: null })!;
  const comprehensive = computeComprehensiveBA(asInputs(VALUES), "male", AGE, { supplements: null });
  return {
    biological_age: reference.BA,
    bio_age_method: KDM_REFERENCE_BA_METHOD,
    bio_age_n_markers: reference.n_markers_used,
    bio_age_applied_spanish_calibration: reference.applied_spanish_recalibration_markers,
    biological_age_comprehensive: comprehensive?.BA ?? null,
  };
}

/** Runs processing with v3 hanging: lets processing reach v3's budget timer, then lets the budget run out. */
async function withV3Hanging<T>(run: () => Promise<T>): Promise<T> {
  v3.mode = "hang";
  vi.useRealTimers();
  vi.useFakeTimers({ toFake: ["Date", "setTimeout", "clearTimeout"] });
  vi.setSystemTime(NOW);
  const pending = run();
  for (let i = 0; i < 10_000 && vi.getTimerCount() === 0; i++) await Promise.resolve();
  expect(vi.getTimerCount()).toBe(1);
  await vi.advanceTimersByTimeAsync(BIO_AGE_V3_BUDGET_MS);
  return pending;
}

describe("biological age v3 in shadow mode, inside processing", () => {
  let errors: ReturnType<typeof vi.spyOn>;

  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    // The premise: KDM gives a biological age on these values, so "unchanged" compares numbers, not nulls.
    expect(computeReferenceBA(asInputs(VALUES), "male", AGE, { supplements: null })).not.toBeNull();
  });
  beforeEach(() => {
    v3.mode = "real";
    Object.assign(shadow, { available: true, storeError: null, upserts: [], log: [] });
    errors = vi.spyOn(console, "error").mockImplementation(() => {});
    vi.useFakeTimers({ toFake: ["Date"] });
    vi.setSystemTime(NOW);
  });
  afterEach(() => {
    vi.useRealTimers();
    errors.mockRestore();
  });

  it("processLabResults: after the KDM update, one upsert of the adapter's record into bio_age_v3_shadow, by the service role", async () => {
    const db = database();
    await processLabResults("u1", "lab-1", RAW, db.client);

    // lab_results gets what it got before v3: the KDM, score and count columns, nothing else.
    expect(db.updates).toHaveLength(1);
    expect(Object.keys(db.updates[0]).sort()).toEqual(KDM_COLUMNS_BEFORE_V3);
    expect(db.updates[0]).toMatchObject(kdmColumns());

    const expected = expectedRecord(db.inserted());
    // The premise: from a venous draw analysed at EVA's laboratory these sources give a figure with the other
    // result's HbA1c. The app records no collection method yet, so the stored record is refused for it.
    const venous = expectedRecord(db.inserted(), undefined, { collectionMethod: "venous", labSource: "echevarne" });
    expect(venous).toMatchObject({ tier: "plus_hba1c", hba1c_source: "other_result", reason: null });
    expect(expected).toMatchObject({ tier: null, hba1c_source: "other_result", reason: "collection_method" });
    expect(shadow.upserts).toEqual([upsertOf(expected)]);

    // In that order, and the caller's client never touches the shadow table.
    const kdmUpdate = shadow.log.indexOf("caller lab_results update.eq");
    const shadowUpsert = shadow.log.indexOf("service-role bio_age_v3_shadow upsert");
    expect(kdmUpdate).toBeGreaterThanOrEqual(0);
    expect(shadowUpsert).toBeGreaterThan(kdmUpdate);
    expect(db.calls.some((c) => c.table === "bio_age_v3_shadow")).toBe(false);
    expect(errors).not.toHaveBeenCalled();
  });

  it("recomputeLabMetrics: the same, from the rows stored for the result", async () => {
    const db = database();
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    expect(db.updates).toHaveLength(1);
    expect(Object.keys(db.updates[0]).sort()).toEqual(KDM_COLUMNS_BEFORE_V3);
    expect(db.updates[0]).toMatchObject(kdmColumns());
    expect(shadow.upserts).toEqual([upsertOf(expectedRecord(STORED))]);
    expect(shadow.log.indexOf("service-role bio_age_v3_shadow upsert")).toBeGreaterThan(shadow.log.indexOf("caller lab_results update.eq"));
    expect(db.calls.some((c) => c.table === "bio_age_v3_shadow")).toBe(false);
    expect(errors).not.toHaveBeenCalled();
  });

  it("KDM, score, counts and the returned result are identical whatever happens to v3", async () => {
    type Run = { name: string; update: Record<string, unknown>; result: unknown; upserts: unknown[][]; errors: number };
    const runs: Run[] = [];
    const run = async (name: string, setup: () => void, options: Options = {}, hang = false) => {
      Object.assign(shadow, { available: true, storeError: null, upserts: [], log: [] });
      v3.mode = "real";
      errors.mockClear();
      setup();
      const db = database(options);
      const go = () => processLabResults("u1", "lab-1", RAW, db.client);
      const result = hang ? await withV3Hanging(go) : await go();
      expect(db.updates, name).toHaveLength(1);
      runs.push({ name, update: db.updates[0], result, upserts: [...shadow.upserts], errors: errors.mock.calls.length });
    };

    await run("v3 working", () => {});
    await run("v3 throwing", () => (v3.mode = "throw"));
    await run("v3 meeting a database error", () => {}, { v3ReadFails: true });
    await run("v3 hanging", () => {}, {}, true);
    await run("no service role", () => (shadow.available = false));
    await run("the record cannot be stored (no table yet)", () => (shadow.storeError = { code: "42P01", message: 'relation "public.bio_age_v3_shadow" does not exist' }));

    const [working, ...others] = runs;
    expect(working.update).toMatchObject(kdmColumns());
    for (const r of others) {
      expect(r.update, r.name).toEqual(working.update);
      expect(r.result, r.name).toEqual(working.result);
      expect(r.errors, r.name).toBeGreaterThan(0); // every failure is logged
    }
    const byName = Object.fromEntries(runs.map((r) => [r.name, r]));
    // A failure to compute replaces the record with { reason: "error" }; no time or no service role stores nothing.
    expect(byName["v3 throwing"].upserts).toEqual([upsertOf({ reason: "error" })]);
    expect(byName["v3 meeting a database error"].upserts).toEqual([upsertOf({ reason: "error" })]);
    expect(byName["v3 hanging"].upserts).toEqual([]);
    expect(byName["no service role"].upserts).toEqual([]);
    expect(byName["the record cannot be stored (no table yet)"].upserts).toHaveLength(1);
  });

  it("recomputeLabMetrics: identical KDM, score and counts with v3 working or throwing", async () => {
    const working = database();
    await recomputeLabMetrics("u1", "lab-1", working.client as never);
    v3.mode = "throw";
    shadow.upserts = [];
    const throwing = database();
    await recomputeLabMetrics("u1", "lab-1", throwing.client as never);
    expect(throwing.updates[0]).toEqual(working.updates[0]);
    expect(shadow.upserts).toEqual([upsertOf({ reason: "error" })]);
  });

  it("an exception inside v3 never reaches the caller", async () => {
    v3.mode = "throw";
    const result = await processLabResults("u1", "lab-1", RAW, database().client);
    expect(result.kdmBiologicalAge.reference?.BA).toBe(kdmColumns().biological_age);
    await expect(recomputeLabMetrics("u1", "lab-1", database().client as never)).resolves.toBeUndefined();
    expect(errors.mock.calls.map((call: unknown[]) => String(call[0]))).toEqual([
      expect.stringMatching(/biological age v3 \(shadow\) failed for lab lab-1; storing \{ reason: "error" \}/),
      expect.stringMatching(/biological age v3 \(shadow\) failed for lab lab-1; storing \{ reason: "error" \}/),
    ]);
  });

  it("v3 writes only through the service role: the caller's client gets the same writes with v3 as without it", async () => {
    const withV3 = database();
    await processLabResults("u1", "lab-1", RAW, withV3.client);
    shadow.available = false; // v3 does nothing at all without the service role
    const withoutV3 = database();
    await processLabResults("u1", "lab-1", RAW, withoutV3.client);
    expect(withV3.writes()).toEqual(withoutV3.writes());
    // What v3 adds on the caller's client are reads.
    expect(withoutV3.v3Reads()).toHaveLength(0);
    expect(withV3.v3Reads().length).toBeGreaterThan(0);
    for (const c of withV3.v3Reads()) expect(ops(c).startsWith("select"), `${c.table} ${ops(c)}`).toBe(true);
    expect(withV3.calls.length - withoutV3.calls.length).toBe(withV3.v3Reads().length);
  });

  it("the result processLabResults returns is unchanged: no v3 in it", async () => {
    const result = await processLabResults("u1", "lab-1", RAW, database().client);
    expect(Object.keys(result).sort()).toEqual(
      ["biologicalAge", "calculatedMetrics", "fullBioAgeResult", "kdmBiologicalAge", "missingRefKeys", "processed", "refMapSize", "scoreWithheld", "unmatched"],
    );
    expect(JSON.stringify(result)).not.toMatch(/bio_age_v3|plus_hba1c|model_sha256/);
  });

  it("recomputeLabMetrics without a usable profile: KDM left as stored (as before), v3 records why there is no age", async () => {
    const db = database({ profile: { date_of_birth: null, sex: null } });
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    expect(db.updates[0]).not.toHaveProperty("biological_age");
    expect(shadow.upserts[0][0]).toMatchObject({ record: { ba: null, reason: "sex_unknown" } });
    shadow.upserts = [];
    await recomputeLabMetrics("u1", "lab-1", database({ profile: { date_of_birth: null, sex: "female" } }).client as never);
    expect(shadow.upserts[0][0]).toMatchObject({ record: { ba: null, reason: "age_unknown" } });
  });

  // Last: it replaces the adapter module for the rest of this file.
  it("a v3 adapter that fails to load (a broken model file): { reason: \"error\" } stored, processing as it was", async () => {
    const before = database();
    await processLabResults("u1", "lab-1", RAW, before.client);
    shadow.upserts = [];

    vi.resetModules();
    vi.doMock("./biological-age-v3-adapter", () => {
      throw new Error("ba_v3_model.json: tier_order");
    });
    const fresh = await import("./process-results");
    const db = database();
    const result = await fresh.processLabResults("u1", "lab-1", RAW, db.client);
    expect(db.updates[0]).toEqual(before.updates[0]);
    expect(result.kdmBiologicalAge.reference?.BA).toBe(kdmColumns().biological_age);
    expect(shadow.upserts).toEqual([upsertOf({ reason: "error" })]);
    expect(errors).toHaveBeenCalledTimes(1);
    vi.doUnmock("./biological-age-v3-adapter");
    vi.resetModules();
  });
});
