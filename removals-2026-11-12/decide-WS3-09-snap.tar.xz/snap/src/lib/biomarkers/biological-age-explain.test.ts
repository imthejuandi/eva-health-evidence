/**
 * Tests for biological-age-explain.ts — internal explanations of the KDM
 * biological age: exact contributions, the direction rule, potential BA.
 *
 * Run: `npx vitest run src/lib/biomarkers/biological-age-explain.test.ts`
 */
import { describe, it, expect } from "vitest";
import { explainBiologicalAge, type OptimalBand } from "./biological-age-explain";
import {
  computeComprehensiveBA,
  computeReferenceBA,
  FRUCTOSAMINE_KDM_KEY,
  type KdmPatientContext,
  type SCaTier,
  type Sex,
} from "./biological-age-kdm";
import type { BiomarkerInput } from "./longevity-score";

const baFn = (tier: SCaTier) => (tier === "reference" ? computeReferenceBA : computeComprehensiveBA);
const TIERS: SCaTier[] = ["reference", "comprehensive"];

// All 14 KDM base markers: 13 inputs + Fructosamine derived from HbA1c. DB keys, engine units.
const BASE: BiomarkerInput[] = [
  { code: "albumin", value: 44 },
  { code: "creatinine", value: 0.95 },
  { code: "bun", value: 15 },
  { code: "uric_acid", value: 5.5 },
  { code: "alp", value: 70 },
  { code: "ggt", value: 25 },
  { code: "total_cholesterol", value: 190 },
  { code: "hdl_cholesterol", value: 55 },
  { code: "triglycerides", value: 100 },
  { code: "hs_crp", value: 1 },
  { code: "ferritin", value: 120 },
  { code: "vitamin_d_25_oh", value: 32 },
  { code: "tsh", value: 1.8 },
  { code: "hba1c", value: 5.3 },
];

const EXTENDED: BiomarkerInput[] = [
  { code: "apolipoprotein_b_apob", value: 85 },
  { code: "ldl_cholesterol", value: 110 },
  { code: "glucose_fasting", value: 92 },
  { code: "alt", value: 24 },
  { code: "ast", value: 22 },
  { code: "total_bilirubin", value: 0.7 },
  { code: "hemoglobin", value: 14.2 },
  { code: "hematocrit", value: 42 },
  { code: "mcv", value: 90 },
  { code: "rdw", value: 13.1 },
  { code: "platelet_count", value: 240000 },
  { code: "white_blood_cell_count", value: 6200 },
  { code: "lymphocytes", value: 31 },
  { code: "vitamin_b12", value: 520 },
];

// Reviewed optimal bands for adults under 50 (supabase/seed-data/biomarker-ranges-en.json).
// Lymphocyte % has no bounds from Gate 1.
const band = (optimal_low: number | null, optimal_high: number | null): OptimalBand => ({ optimal_low, optimal_high });
const SHARED: Record<string, OptimalBand> = {
  albumin: band(42, 48), bun: band(10, 18), alp: band(40, 80), total_cholesterol: band(120, 190),
  triglycerides: band(null, 80), hs_crp: band(null, 0.5), vitamin_d_25_oh: band(30, 50), tsh: band(1, 3),
  hba1c: band(4.5, 5.4), fructosamine: band(null, 200), apolipoprotein_b_apob: band(null, 70),
  ldl_cholesterol: band(null, 70), glucose_fasting: band(74, 90), total_bilirubin: band(0.4, 1),
  mcv: band(82, 93), rdw: band(11.5, 13), platelet_count: band(175000, 300000),
  white_blood_cell_count: band(4500, 6000), lymphocytes: band(null, null), vitamin_b12: band(400, 800),
};
const BANDS: Record<Sex, Record<string, OptimalBand>> = {
  male: {
    ...SHARED, creatinine: band(0.8, 1.1), uric_acid: band(4, 6), ggt: band(5, 30), hdl_cholesterol: band(50, 80),
    ferritin: band(40, 150), alt: band(10, 30), ast: band(15, 30), hemoglobin: band(14, 16), hematocrit: band(40, 46),
  },
  female: {
    ...SHARED, creatinine: band(0.6, 0.9), uric_acid: band(3.1, 5), ggt: band(5, 20), hdl_cholesterol: band(60, 90),
    ferritin: band(50, 150), alt: band(10, 25), ast: band(8, 25), hemoglobin: band(13, 15), hematocrit: band(37, 43),
  },
};

const set = (values: BiomarkerInput[], patch: Record<string, number>) =>
  values.map((v) => (v.code in patch ? { ...v, value: patch[v.code] } : v));
const without = (values: BiomarkerInput[], codes: string[]) => values.filter((v) => !codes.includes(v.code));

describe("contributions — exact share of BA − CA", () => {
  const cases: [string, BiomarkerInput[], Sex, number, KdmPatientContext?][] = [
    ["man 45, base panel", BASE, "male", 45],
    ["woman 45, base panel", BASE, "female", 45],
    ["man 25, base + extended", [...BASE, ...EXTENDED], "male", 25],
    ["woman 78, base + extended", [...BASE, ...EXTENDED], "female", 78],
    ["man 60, 5 base markers missing", without(BASE, ["ferritin", "vitamin_d_25_oh", "tsh", "ggt", "hba1c"]), "male", 60],
    ["woman 35, measured fructosamine", [...without(BASE, ["hba1c"]), { code: "fructosamine", value: 230 }], "female", 35],
    ["man 30, creatine 5 g/day", BASE, "male", 30, { supplements: [{ key: "creatine", dose: "5 g" }] }],
    ["woman 52, cystatin C and a laboratory eGFR, which do not enter", [...BASE, { code: "cystatin_c", value: 0.9 }, { code: "egfr_creatinine_based", value: 70 }], "female", 52],
    ["man 40, urea instead of BUN", [...without(BASE, ["bun"]), { code: "urea", value: 34 }], "male", 40],
  ];

  for (const [label, values, sex, age, context] of cases) {
    for (const tier of TIERS) {
      it(`sum to the model's BA − CA within 1e-9 years — ${label}, ${tier}`, () => {
        const ba = baFn(tier)(values, sex, age, context);
        const e = explainBiologicalAge(values, sex, age, {}, tier, context);
        expect(ba).not.toBeNull();
        expect(e).not.toBeNull();
        expect(e!.ba).toBe(ba!.BA);
        expect(e!.contributions.map((c) => c.marker).sort()).toEqual([...ba!.used_markers].sort());
        expect(Math.abs(e!.check.sum - (ba!.BA - age))).toBeLessThanOrEqual(1e-9);
        expect(e!.check.ok).toBe(true);
      });
    }
  }

  it("reports the value the estimator used: units, derived Fructosamine, creatine adjustment", () => {
    const e = explainBiologicalAge(BASE, "male", 30, {}, "reference", { supplements: [{ key: "creatine", dose: "5 g" }] })!;
    const by = (marker: string) => e.contributions.find((c) => c.marker === marker)!;
    expect(by("Albúmina")).toMatchObject({ code: "albumin", value: 44, modelValue: 4.4 });
    expect(by(FRUCTOSAMINE_KDM_KEY)).toMatchObject({ code: "hba1c", value: 5.3 });
    expect(by(FRUCTOSAMINE_KDM_KEY).modelValue).toBeCloseTo(19.97 * 5.3 - 39.4, 10);
    expect(by("Creatinina").value).toBe(0.95);
    expect(by("Creatinina").modelValue).toBeCloseTo(0.95 / 1.13, 10); // 5 g/day: the full 13% rise removed
  });

  it("returns null when the BA gate fails", () => {
    expect(explainBiologicalAge(BASE.slice(0, 7), "male", 45, BANDS.male)).toBeNull();
  });
});

describe("direction rule", () => {
  it("vitamin D 20 → 30 ng/mL makes a 45-year-old man 1.7 years older: a conflict, never counted", () => {
    const values = set(BASE, { vitamin_d_25_oh: 20 });
    const e = explainBiologicalAge(values, "male", 45, { vitamin_d_25_oh: band(30, 50) })!;
    expect(e.potential).toEqual([]);
    expect(e.potentialBA).toBe(e.ba);
    expect(e.conflicts).toHaveLength(1);
    expect(e.conflicts[0]).toMatchObject({ code: "vitamin_d_25_oh", from: 20, to: 30 });
    expect(e.conflicts[0].delta).toBeCloseTo(1.7, 1); // KDM-DIRECTION.md

    // The rise equals the change in vitamin D's own share (decomposition vs recomputed BA).
    const share = (v: BiomarkerInput[]) =>
      explainBiologicalAge(v, "male", 45, {})!.contributions.find((c) => c.code === "vitamin_d_25_oh")!.years;
    expect(e.conflicts[0].delta).toBeCloseTo(share(set(BASE, { vitamin_d_25_oh: 30 })) - share(values), 9);
  });

  it("ferritin 30 → 50 ng/mL makes a 45-year-old woman 3.0 years older: a conflict", () => {
    const e = explainBiologicalAge(set(BASE, { ferritin: 30 }), "female", 45, { ferritin: band(50, 150) })!;
    expect(e.potential).toEqual([]);
    expect(e.conflicts.map((c) => c.code)).toEqual(["ferritin"]);
    expect(e.conflicts[0].delta).toBeCloseTo(3.0, 1); // KDM-DIRECTION.md
  });

  it("counts moves that lower the BA and recomputes potential BA with all of them together", () => {
    const values = set(BASE, { hs_crp: 3, triglycerides: 200, vitamin_d_25_oh: 20 });
    const e = explainBiologicalAge(values, "male", 45, BANDS.male)!;
    expect(e.potential.map((m) => m.code).sort()).toEqual(["hs_crp", "triglycerides"]);
    expect(e.potential.every((m) => m.delta < 0)).toBe(true);
    expect(e.conflicts.map((c) => c.code)).toEqual(["vitamin_d_25_oh"]);
    const both = computeReferenceBA(set(values, { hs_crp: 0.5, triglycerides: 80 }), "male", 45)!;
    expect(e.potentialBA).toBe(both.BA);
    // KDM is linear in each marker, so the joint move equals the sum of single moves.
    expect(e.potentialBA).toBeCloseTo(e.ba + e.potential.reduce((a, m) => a + m.delta, 0), 9);
  });

  it("a panel already optimal gives no moves", () => {
    const optimal = set([...BASE, ...EXTENDED], {
      albumin: 45, bun: 14, alp: 60, triglycerides: 70, hs_crp: 0.4, ggt: 20, ferritin: 100,
      apolipoprotein_b_apob: 65, ldl_cholesterol: 65, glucose_fasting: 85, hemoglobin: 15, rdw: 12.5,
      white_blood_cell_count: 5500, vitamin_b12: 600,
    });
    for (const tier of TIERS) {
      const e = explainBiologicalAge(optimal, "male", 45, BANDS.male, tier)!;
      expect(e.potential).toEqual([]);
      expect(e.conflicts).toEqual([]);
      expect(e.potentialBA).toBe(e.ba);
    }
  });

  it("never moves a marker without bounds, or one that does not reach the estimator", () => {
    const values = set(
      [...BASE, ...EXTENDED, { code: "cystatin_c", value: 1.2 }, { code: "egfr_creatinine_based", value: 70 }],
      { lymphocytes: 55, ldl_cholesterol: 130, creatinine: 1.4 },
    );
    // Bands outside which both kidney values sit, so a move would be tried if they reached the estimator.
    const bands = { ...BANDS.male, cystatin_c: band(0.62, 0.85), egfr_creatinine_based: band(90, null) };
    const ref = explainBiologicalAge(values, "male", 45, bands, "reference")!;
    const comp = explainBiologicalAge(values, "male", 45, bands, "comprehensive")!;
    const moved = (e: typeof ref) => [...e.potential, ...e.conflicts].map((m) => m.code);
    expect(moved(comp)).not.toContain("lymphocytes"); // no bounds (Gate 1)
    expect(moved(ref)).not.toContain("ldl_cholesterol"); // not in the base panel
    expect(moved(comp)).toContain("ldl_cholesterol");
    // Creatinine enters both versions; cystatin C and a laboratory eGFR never enter either.
    expect(moved(ref)).toContain("creatinine");
    expect(moved(comp)).toContain("creatinine");
    expect([...moved(ref), ...moved(comp)]).not.toContain("cystatin_c");
    expect([...moved(ref), ...moved(comp)]).not.toContain("egfr_creatinine_based");
  });

  it("potential BA is never above the BA (random panels, both tiers)", () => {
    let seed = 20260930;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    let checked = 0;
    let kept = 0;
    let conflicts = 0;
    for (let t = 0; t < 150; t++) {
      const sex: Sex = rnd() < 0.5 ? "male" : "female";
      const age = 20 + Math.floor(rnd() * 65);
      const values = [...BASE, ...EXTENDED]
        .filter((v) => ["albumin", "creatinine"].includes(v.code) || rnd() < 0.8)
        .map((v) => ({ ...v, value: v.value * (0.5 + rnd()) }));
      for (const tier of TIERS) {
        const e = explainBiologicalAge(values, sex, age, BANDS[sex], tier);
        if (!e) continue;
        checked++;
        kept += e.potential.length;
        conflicts += e.conflicts.length;
        expect(e.check.ok).toBe(true);
        expect(e.potentialBA).toBeLessThanOrEqual(e.ba);
        expect(e.potential.every((m) => m.delta < 0)).toBe(true);
        expect(e.conflicts.every((m) => m.delta > 0)).toBe(true);
        expect(e.potentialBA).toBeCloseTo(e.ba + e.potential.reduce((a, m) => a + m.delta, 0), 9);
      }
    }
    expect(checked).toBeGreaterThan(200);
    expect(kept).toBeGreaterThan(0);
    expect(conflicts).toBeGreaterThan(0);
  });
});
