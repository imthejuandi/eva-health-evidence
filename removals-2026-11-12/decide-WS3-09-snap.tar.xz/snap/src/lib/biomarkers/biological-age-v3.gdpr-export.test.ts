/**
 * The GDPR export (GET /api/gdpr/export) includes the user's biological age v3 shadow records: they are personal
 * data. bio_age_v3_shadow is closed to every role but the service role, so the route reads it with the admin
 * client, scoped to the user's id; the user's own client is never asked for it. Before the migration (no table) or
 * without a service role, the export still works, with an empty list. Scripted databases (fake-supabase).
 */
import { beforeEach, describe, expect, it, vi } from "vitest";
import { argsOf, type FakeCall } from "@/lib/testing/fake-supabase";

const state = vi.hoisted(() => ({
  userCalls: [] as FakeCall[],
  adminCalls: [] as FakeCall[],
  admin: true,
  shadowError: null as null | { code: string; message: string },
  /**
   * fakeSupabase builders settle through a bare `then(resolve, reject)`; the export also chains
   * `.then((r) => r.data)`, which needs a promise back, so the user's client gets one.
   */
  promising<C extends { from(table: string): unknown }>(client: C): C {
    return {
      ...client,
      from: (table: string) => {
        const builder = client.from(table) as { then: (resolve: (v: unknown) => void, reject?: (e: unknown) => void) => void };
        const settle = builder.then;
        builder.then = ((onFulfilled?: (v: unknown) => unknown, onRejected?: (e: unknown) => unknown) =>
          new Promise((resolve, reject) => settle(resolve, reject)).then(onFulfilled, onRejected)) as never;
        return builder;
      },
    } as C;
  },
}));

const SHADOW_ROWS = [
  {
    lab_result_id: "11111111-1111-1111-1111-111111111111",
    user_id: "u1",
    record: { ba: 48.2, tier: "base", reason: null, adapter_version: "1.0.0" },
    computed_at: "2026-10-01T09:00:00+00:00",
  },
];

vi.mock("@/lib/supabase/server", async () => {
  const fake = await import("@/lib/testing/fake-supabase");
  return {
    createClient: async () => {
      const { client, calls } = fake.fakeSupabase(() => ({ data: [] }));
      state.userCalls = calls;
      return Object.assign(state.promising(client), {
        auth: { getUser: async () => ({ data: { user: { id: "u1", email: "u1@example.com" } } }) },
      });
    },
  };
});

vi.mock("@/lib/supabase/admin", async () => {
  const fake = await import("@/lib/testing/fake-supabase");
  return {
    createAdminClient: () =>
      state.admin
        ? fake.fakeSupabase((c) => {
            state.adminCalls.push(c);
            if (c.table === "bio_age_v3_shadow") return state.shadowError ? { error: state.shadowError } : { data: SHADOW_ROWS };
            return { data: [] };
          }).client
        : null,
  };
});

import { GET } from "@/app/api/gdpr/export/route";

async function exported(): Promise<Record<string, unknown>> {
  const res = await GET();
  expect(res.status).toBe(200);
  return (await res.json()) as Record<string, unknown>;
}

describe("the GDPR export includes the biological age v3 shadow records", () => {
  beforeEach(() => {
    Object.assign(state, { userCalls: [], adminCalls: [], admin: true, shadowError: null });
  });

  it("read with the service role, scoped to the user; the user's client is never asked for them", async () => {
    const body = await exported();
    expect(body.bio_age_v3_shadow).toEqual(SHADOW_ROWS);
    const reads = state.adminCalls.filter((c) => c.table === "bio_age_v3_shadow");
    expect(reads).toHaveLength(1);
    expect(reads[0].ops).toEqual([
      { op: "select", args: ["*"] },
      { op: "eq", args: ["user_id", "u1"] },
      { op: "order", args: ["computed_at"] },
    ]);
    expect(state.userCalls.some((c) => c.table === "bio_age_v3_shadow")).toBe(false);
    // The rest of the export is as before.
    expect(Object.keys(body)).toEqual(expect.arrayContaining(["lab_results", "biomarker_values", "lab_messages", "patient_context_versions"]));
    expect(argsOf(state.userCalls.find((c) => c.table === "lab_results")!, "select")).toEqual(["*"]);
  });

  it("before the migration (no table yet): an empty list, nothing logged", async () => {
    const errors = vi.spyOn(console, "error").mockImplementation(() => {});
    state.shadowError = { code: "42P01", message: 'relation "public.bio_age_v3_shadow" does not exist' };
    expect((await exported()).bio_age_v3_shadow).toEqual([]);
    expect(errors).not.toHaveBeenCalled();
    errors.mockRestore();
  });

  it("any other read error: an empty list, and the error is logged", async () => {
    const errors = vi.spyOn(console, "error").mockImplementation(() => {});
    state.shadowError = { code: "57014", message: "canceling statement due to statement timeout" };
    expect((await exported()).bio_age_v3_shadow).toEqual([]);
    expect(errors).toHaveBeenCalledTimes(1);
    errors.mockRestore();
  });

  it("without a service role: an empty list", async () => {
    state.admin = false;
    expect((await exported()).bio_age_v3_shadow).toEqual([]);
  });
});
