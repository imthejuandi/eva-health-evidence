/**
 * Choose the one reference row that applies to a user, from the rows whose
 * age group already matches their age.
 *
 * The choice must not depend on the order in which the database returns rows.
 * Several female hormone markers carry rows labelled by menstrual phase or
 * menopausal status ("Premenopausal (follicular)", "Ovulatory peak",
 * "Postmenopausal", …); every one of them matches any adult woman, so without
 * a rule the first row returned would win, and an UPDATE can change that order.
 *
 * Rules, in order:
 * 1. A row for the user's sex beats a "both" row.
 * 2. A numeric age band ("18-39", "60+") beats a labelled window.
 * 3. Among labelled windows, age stands in for menopausal status: under 50 the
 *    follicular (then generic premenopausal) row, from 50 the postmenopausal
 *    row. Mid-cycle windows (ovulatory, luteal) are used only when nothing
 *    else matches, because a result without a cycle day is read as follicular.
 *    50 is the same age proxy EVA's ferritin rows use.
 * 4. Ties are broken by the label, so the result is always the same.
 */
export interface ReferenceRowLike {
  sex: string | null;
  age_group_en: string | null;
}

export const MENOPAUSE_PROXY_AGE = 50;

function labelRank(label: string | null, age: number): number {
  const s = (label ?? "").toLowerCase().trim();
  if (/\d/.test(s)) return 0;
  const follicular = s.includes("follicular");
  const midCycle = s.includes("ovulatory") || s.includes("luteal");
  const post = s.startsWith("postmenopausal");
  const peri = s.startsWith("perimenopausal");
  const pre = s.startsWith("premenopausal");
  if (age >= MENOPAUSE_PROXY_AGE) {
    if (post) return 1;
    if (peri) return 2;
    if (follicular) return 3;
    if (midCycle) return 5;
    if (pre) return 4;
  } else {
    if (follicular) return 1;
    if (midCycle) return 5;
    if (pre) return 2;
    if (peri) return 3;
    if (post) return 6;
  }
  return 7;
}

export function pickReferenceRow<T extends ReferenceRowLike>(
  matches: readonly T[],
  sex: string,
  age: number,
): T | undefined {
  if (matches.length <= 1) return matches[0];
  const want = sex.toLowerCase();
  const sexRank = (r: T) => (r.sex?.toLowerCase() === want ? 0 : r.sex?.toLowerCase() === "both" ? 1 : 2);
  return [...matches].sort(
    (a, b) =>
      sexRank(a) - sexRank(b) ||
      labelRank(a.age_group_en, age) - labelRank(b.age_group_en, age) ||
      (a.age_group_en ?? "").localeCompare(b.age_group_en ?? ""),
  )[0];
}

/**
 * Whether a row's age group (age_group_en) contains `age`. The one matcher
 * every route uses, so the upload preview, processing, a manual edit and the
 * marker picker always read the same row.
 *
 * - Numeric bands contain exactly their ages: "18-39", "18 - 25", "18 to 25",
 *   "18 a 25", "60+", "65 and over", "over 65", "under 18".
 * - "All Adults" and the female hormone windows ("Premenopausal (follicular)",
 *   "Ovulatory peak", "Postmenopausal", …) are not age limits: they contain
 *   every adult, and pickReferenceRow chooses among them.
 * - "On Hormone Therapy", and any label not recognised, contains no age. EVA
 *   does not record hormone therapy, so that row is never read.
 */
export function ageGroupContains(ageGroup: string | null | undefined, age: number): boolean {
  if (!ageGroup || !Number.isFinite(age)) return false;
  const str = ageGroup.toLowerCase().trim();

  if (
    str === "all adults" ||
    str === "all ages" ||
    str === "adult" ||
    str === "adults" ||
    str.startsWith("premenopausal") ||
    str.startsWith("postmenopausal") ||
    str.startsWith("perimenopausal") ||
    str.startsWith("ovulatory") ||
    str.startsWith("follicular") ||
    str.startsWith("luteal")
  ) {
    return age >= 18;
  }

  const range = str.match(/(\d{1,3})\s*(?:-|–|to|a)\s*(\d{1,3})/);
  if (range) return age >= Number(range[1]) && age <= Number(range[2]);

  const openEnd =
    str.match(/(\d{1,3})\s*\+/) ||
    str.match(/(\d{1,3})\s*(?:and|or)\s*(?:over|older|más)/) ||
    str.match(/(?:over|mayor)\s*(?:de\s*)?(\d{1,3})/);
  if (openEnd) return age >= Number(openEnd[1]);

  const openStart = str.match(/(?:under|below|menor\s*(?:de)?)\s*(\d{1,3})/);
  if (openStart) return age < Number(openStart[1]);

  return false;
}

/**
 * The row that applies to a person among one marker's rows: their sex's rows
 * and "both" rows whose age group contains their age, chosen by
 * pickReferenceRow. When no age group contains the age (a minor, or a label
 * nothing recognises) the same rule runs over all their rows, so the choice
 * still never depends on database order; `ageMatched` is then false.
 */
export function referenceRowFor<T extends ReferenceRowLike>(
  rows: readonly T[],
  sex: string,
  age: number,
): { row: T | undefined; ageMatched: boolean } {
  const want = sex.toLowerCase();
  const own = rows.filter((r) => r.sex?.toLowerCase() === want || r.sex?.toLowerCase() === "both");
  const row = pickReferenceRow(own.filter((r) => ageGroupContains(r.age_group_en, age)), sex, age);
  return row ? { row, ageMatched: true } : { row: pickReferenceRow(own, sex, age), ageMatched: false };
}

/**
 * referenceRowFor for every marker in `rows`, keyed by biomarker_key.
 * `fallbacks` lists the markers whose row did not match the person's age.
 */
export function pickReferenceRows<T extends ReferenceRowLike & { biomarker_key: string }>(
  rows: readonly T[],
  sex: string,
  age: number,
): { picked: Map<string, T>; fallbacks: string[] } {
  const byKey = new Map<string, T[]>();
  for (const r of rows) {
    const list = byKey.get(r.biomarker_key);
    if (list) list.push(r);
    else byKey.set(r.biomarker_key, [r]);
  }
  const picked = new Map<string, T>();
  const fallbacks: string[] = [];
  for (const [key, list] of byKey) {
    const { row, ageMatched } = referenceRowFor(list, sex, age);
    if (!row) continue;
    picked.set(key, row);
    if (!ageMatched) fallbacks.push(key);
  }
  return { picked, fallbacks };
}
