/**
 * Lab result processing pipeline.
 *
 * Orchestrates: name matching → zone classification → calculated metrics →
 * biological age → DB persistence.
 */

import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { type SupabaseClient } from "@supabase/supabase-js";
import { matchBiomarkerName } from "./name-matcher";
import { buildEngineInputs } from "./engine-inputs";
import { glycationExclusion, type GlycationRow } from "./glycation-exclusion";
import { ZONE_CONFIG, calculateAge } from "./zone-classifier";
import { classifyResultZone, isUnplacedBound } from "./bounded-result";
import {
  calculateLongevityScoreV2,
  isCriticalValue,
  withheldByContext,
  type ReviewedRow,
  type ScoreContext,
  type WithheldReason,
} from "./longevity-score";
import {
  computeReferenceBA,
  computeComprehensiveBA,
  KDM_REFERENCE_BA_METHOD,
  type KdmPatientContext,
  type KdmReferenceBAResult,
} from "./biological-age-kdm";
import { loadLabState, type LabState } from "@/lib/patient-context/physiological-state";
import { recomputeAndCacheUserBA } from "./rolling-average-ba";
import { calculateAllMetrics, type MetricPerson } from "./calculated-metrics";
import { ageAtDraw, EGFR_METRIC_KEY } from "./egfr";
import { isLabReportedValueOnly, shownAsValueOnly } from "./lab-reported";
import { convertBiomarker } from "./unit-conversions";
import { pickReferenceRows } from "./reference-row";
import { remapToSeedKey } from "./key-aliases";
import { seedBiomarkerReferences } from "./seed-references";
import { getCanonicalUnit, validateCanonicalUnit, normalizeUnit } from "./canonical-units";
import type { BiomarkerInput, FullResult } from "./biological-age";
import type { CalculatedMetric } from "./calculated-metrics";
import type { Zone } from "./zone-classifier";
// Types only: the biological age v3 adapter is loaded lazily, inside bioAgeV3Shadow's guard (end of this file).
import type { BioAgeV3ShadowArgs, BioAgeV3Stored } from "./biological-age-v3-adapter";

// ─── Input / Output types ───

/**
 * Raw biomarker from extraction.
 * biomarkerKey is optional: if provided (from user's manual confirmation),
 * it's used directly instead of running name matching again.
 * matchConfidence is optional but should be supplied alongside biomarkerKey
 * by the confirm route — it records how the row resolved to its key so we
 * can later audit how often users accept vs. correct fuzzy matches.
 */
export interface RawBiomarker {
  name: string;
  value: number;
  unit: string;
  /** "<" / ">" when the lab reported a bounded value ("<0,500"); `value` is the bound. */
  comparator?: "<" | ">";
  biomarkerKey?: string;
  matchConfidence?: "exact" | "alias" | "fuzzy" | "user";
}

export interface ProcessedBiomarker {
  biomarkerKey: string;
  name: string;
  value: number;
  unit: string;
  comparator?: "<" | ">" | null;
  zone: Zone;
  zoneLabel: string;
  zoneLabel_es: string;
  optimalLow: number | null;
  optimalHigh: number | null;
  matchConfidence: "exact" | "alias" | "fuzzy" | "user";
}

export interface UnmatchedBiomarker {
  name: string;
  value: number;
  unit: string;
  /** Reason why we couldn't process it. "unmatched" = name didn't match
   * any canonical biomarker. "unit_mismatch" = matched a biomarker but
   * couldn't auto-convert the supplied unit to the canonical one. */
  reason?: "unmatched" | "unit_mismatch";
  /** When reason=unit_mismatch, the canonical unit the seed expects. */
  expectedUnit?: string | null;
  /** The bound's sign, when the result was a bound: the caller names the result as it was reported (set-aside.ts). */
  comparator?: "<" | ">";
}

export interface ProcessingResult {
  processed: ProcessedBiomarker[];
  calculatedMetrics: CalculatedMetric[];
  /**
   * Legacy result object preserved for backward compatibility with admin
   * UI / API route responses. The `biologicalAge` number inside is the
   * KDM Reference BA when available, otherwise null. The longevity-score
   * fields (`longevityScore`, `lsGrade`, `confidence`) come from the
   * separate longevity-score engine. `longevityScore` and `lsGrade` are null
   * when these values give no score (as stored in lab_results), never 0.
   *
   * For the structured KDM result (including comprehensive BA + applied
   * Spanish recalibration markers), see `kdmBiologicalAge`.
   */
  biologicalAge: {
    biologicalAge: number | null;
    delta: number | null;
    longevityScore: number | null;
    lsGrade: string | null;
    confidence: string;
  } | null;
  /**
   * KDM v2.2 biological age, a separate metric (tested against NHANES
   * deaths, in-sample only). Null when the KDM gate fails (< 8 base panel
   * + Alb + Crea). Coexists with
   * the longevity score (`biologicalAge.longevityScore` above), which is
   * intentionally distinct (optimal-range-anchored vs population-anchored).
   */
  kdmBiologicalAge: {
    reference: KdmReferenceBAResult;
    comprehensive: KdmReferenceBAResult;
  };
  fullBioAgeResult: FullResult | null;
  /**
   * Why this lab has no score although its values might give one: a value in the critical tier, or declared
   * pregnancy or lactation (longevity-score.ts WithheldReason). Null when the score was not withheld; too few
   * markers or domains is not a withholding. No sentence is written here: the copy is rendered by reason code.
   */
  scoreWithheld: WithheldReason | null;
  unmatched: UnmatchedBiomarker[];
  /** Diagnostic: how many reference rows we could resolve for this sex+age */
  refMapSize: number;
  /** Diagnostic: sample of biomarker_keys that failed the refMap lookup */
  missingRefKeys: string[];
}

// ─── Pipeline ───

/**
 * Process lab results. Throws on any unrecoverable error (missing profile,
 * DB write failure). Does NOT silently fail.
 */
export async function processLabResults(
  userId: string,
  labResultId: string,
  rawBiomarkers: RawBiomarker[],
  client?: SupabaseClient,
  options?: {
    /**
     * The reported units come from a structured lab feed (HL7 OBX-6) and are
     * taken at face value: the CBC magnitude arbiter, built for OCR'd and
     * hand-typed reports whose unit label is often wrong, is switched off.
     */
    trustUnits?: boolean;
    /**
     * The lab's patient context (its supplements and physiological state),
     * read by a caller that deletes the lab's values before calling
     * (loadLabState): read here, after the delete, a failed read would leave
     * the lab with no values. Read here when absent.
     */
    labState?: LabState;
  },
): Promise<ProcessingResult> {
  // Service contexts (admin manual entry) pass a service-role client so the
  // cross-user writes below aren't blocked by RLS; user flows pass nothing and
  // get the RLS-bound client unchanged.
  const supabase = client ?? (await createClient());

  // 1. Get user profile (DOB, sex)
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("date_of_birth, sex")
    .eq("id", userId)
    .single();

  if (profileError) {
    throw new Error(`Failed to load profile: ${profileError.message}`);
  }

  if (!profile?.date_of_birth || !profile?.sex) {
    throw new Error("Profile incomplete: date_of_birth and sex are required for lab processing");
  }

  const age = calculateAge(profile.date_of_birth);
  if (isNaN(age)) {
    throw new Error(
      `Invalid date_of_birth format "${profile.date_of_birth}". Expected YYYY-MM-DD. Please update your profile.`,
    );
  }
  const sex = profile.sex as string;

  // 1b. The lab's patient context, read once (loadLabState,
  // patient-context/physiological-state.ts): the version recorded with this
  // lab result, else the client's latest version created on or before it,
  // with the lab's per-draw answers, unless the caller read it before
  // deleting the lab's values. It gives the supplements for KDM's creatine
  // adjustment (step 6c) and the lab's physiological state (state-rules.md
  // section 1), which the score reads (step 6a). Read before anything is written, so
  // a failed read leaves nothing half-stored. If there is none (older
  // accounts, fresh signups), KDM runs without lifestyle adjustments — safe
  // degraded behavior — and the state is unknown.
  const labState = options?.labState ?? (await loadLabState(supabase, userId, labResultId));
  const kdmContext: KdmPatientContext = { supplements: labState.supplements };

  // 2. Match names + classify zones
  const processed: ProcessedBiomarker[] = [];
  const unmatched: UnmatchedBiomarker[] = [];

  // Fetch ALL reference ranges for this sex (across all age groups) and
  // then filter in code. This is resilient to age_group_en format variations
  // in the seed data (e.g. "18-25", "18 - 25", "18-25y", "All Adults") —
  // any format where we can extract a numeric low/high bound works.
  async function loadRefs() {
    return supabase
      .from("biomarker_references")
      .select("biomarker_key, sex, age_group_en, optimal_low, optimal_high, normal_low, normal_high, panel_category")
      .in("sex", [sex.toLowerCase(), "both"]);
  }

  let { data: allRefs, error: refsError } = await loadRefs();

  if (refsError) {
    throw new Error(`Failed to load biomarker references: ${refsError.message}`);
  }

  // Auto-seed path: if the table is empty, try to bootstrap it from the
  // committed JSON using the admin client. This makes reprocess work
  // end-to-end on a fresh database without requiring a local terminal.
  if (!allRefs || allRefs.length === 0) {
    console.log(
      "[process-results] biomarker_references empty — attempting auto-seed from committed JSON.",
    );
    const admin = createAdminClient();
    if (!admin) {
      throw new Error(
        "biomarker_references is empty and SUPABASE_SERVICE_ROLE_KEY is not set, " +
          "so auto-seed cannot run. Set the env var in Vercel and retry.",
      );
    }
    try {
      const { inserted } = await seedBiomarkerReferences(admin);
      console.log(`[process-results] Auto-seed complete: ${inserted} rows upserted.`);
    } catch (seedErr) {
      const msg = seedErr instanceof Error ? seedErr.message : String(seedErr);
      throw new Error(`biomarker_references auto-seed failed: ${msg}`);
    }
    // Re-fetch after seeding
    ({ data: allRefs, error: refsError } = await loadRefs());
    if (refsError) {
      throw new Error(`Failed to re-load biomarker_references after seed: ${refsError.message}`);
    }
    if (!allRefs || allRefs.length === 0) {
      throw new Error(
        "biomarker_references is still empty after auto-seed — check server logs " +
          "for the actual Supabase error.",
      );
    }
  }

  /**
   * One reference row per biomarker for this user's sex and age, picked by
   * the shared rule in reference-row.ts (the upload preview and manual edits
   * use the same one). A marker with no row for the age still gets one, so
   * zone classification can run; it is logged so the rows can be fixed.
   */
  const refMap = new Map<string, { optimal_low: number | null; optimal_high: number | null; normal_low: number | null; normal_high: number | null; panel_category: string | null; critical_low: number | null; critical_high: number | null }>();

  if (allRefs) {
    const { picked, fallbacks } = pickReferenceRows(allRefs, sex, age);
    for (const key of fallbacks) {
      console.warn(
        `[process-results] No age_group match for ${key} at age=${age}. ` +
          `Available: ${allRefs.filter((r) => r.biomarker_key === key).map((r) => r.age_group_en).join(", ")}. Using fallback row.`,
      );
    }
    for (const [key, row] of picked) {
      refMap.set(key, {
        optimal_low: row.optimal_low,
        optimal_high: row.optimal_high,
        normal_low: row.normal_low,
        normal_high: row.normal_high,
        panel_category: row.panel_category ?? null,
        // Present only when the loaded rows carry them: loadRefs does not ask for the critical columns, which the
        // database does not hold yet, so today both are null and the critical tier below is never set.
        critical_low: (row as CriticalColumns).critical_low ?? null,
        critical_high: (row as CriticalColumns).critical_high ?? null,
      });
    }
  }

  // DIAGNOSTIC: dump the first 30 keys present in refMap so we can see what
  // biomarker_keys actually exist in the seeded database. Combined with the
  // per-biomarker lookup logs below, this makes classification failures
  // obvious in Vercel function logs.
  console.log(
    `[process-results] refMap built for sex=${sex.toLowerCase()}, age=${age}. ` +
      `${refMap.size} keys available. First 30: ${Array.from(refMap.keys()).slice(0, 30).join(", ")}`,
  );

  const missingRefKeys: string[] = [];

  // The critical tier of this lab: set when any value, scored or not and whatever its category, is at or beyond a
  // critical field of its row (isCriticalValue). Evaluated on every value as it is read, before any state rule.
  let criticalTier = false;

  const biomarkerValuesToInsert: Array<{
    lab_result_id: string;
    biomarker_key: string;
    biomarker_name: string;
    value: number;
    unit: string;
    zone: string;
    optimal_low: number | null;
    optimal_high: number | null;
    normal_low: number | null;
    normal_high: number | null;
    reported_value: number;
    reported_unit: string | null;
    comparator: "<" | ">" | null;
    category: string;
    match_confidence: "exact" | "alias" | "fuzzy" | "user";
  }> = [];

  for (const raw of rawBiomarkers) {
    // Prefer the user-provided biomarkerKey (from manual confirmation) over re-matching.
    // This respects the user's explicit selection in the UI.
    let biomarkerKey: string | null;
    let confidence: "exact" | "alias" | "fuzzy" | "user";

    if (raw.biomarkerKey) {
      biomarkerKey = raw.biomarkerKey;
      // If the caller told us how the row resolved (the confirm route
      // does), trust it. Otherwise default to "user" — historically this
      // path was only used for manual UI confirmations.
      confidence = raw.matchConfidence ?? "user";
    } else {
      const match = matchBiomarkerName(raw.name);
      if (!match.biomarkerKey || match.confidence === "none") {
        console.log(`[process-results] UNMATCHED name: "${raw.name}"`);
        unmatched.push({
          name: raw.name,
          value: raw.value,
          unit: raw.unit,
          ...(raw.comparator ? { comparator: raw.comparator } : {}),
          reason: "unmatched",
        });
        continue;
      }
      biomarkerKey = match.biomarkerKey;
      confidence = match.confidence as "exact" | "alias" | "fuzzy";
    }

    // Remap the matcher's short canonical key to the seed's verbose slug
    // (e.g. "apolipoprotein_b" → "apolipoprotein_b_apob") and disambiguate
    // CBC differential %/absolute rows by looking at the reported unit.
    // Done BEFORE unit conversion because the conversion table keys off
    // seed-style biomarker keys (e.g. "testosterone_total" not "testosterone").
    const remappedKey = remapToSeedKey(biomarkerKey, raw.unit);
    if (remappedKey !== biomarkerKey) {
      console.log(
        `[process-results] Remapped key: ${biomarkerKey} → ${remappedKey} ` +
          `(unit="${raw.unit}")`,
      );
      biomarkerKey = remappedKey;
    }

    // Apply unit conversion BEFORE looking up the reference range.
    // This handles cholesterol (mmol/L → mg/dL), Urea (mmol/L → mg/dL),
    // BUN (mmol/L → mg/dL), etc. — same-molecule unit-system conversions
    // only. Cross-molecule scaling (Urea ↔ BUN) is NOT done here so each
    // marker keeps its own reference range; that conversion only happens
    // later inside the KDM joint estimator (which is anchored on BUN).
    // The converted value is what gets zone-classified and stored, so
    // downstream displays show the unit the EVA ranges expect.
    // Pass the canonical normal-high so convertBiomarker can spot a CBC
    // count reported on the raw cells/µL scale even when the unit string
    // is mislabelled (a /µL count tagged "10³/µL" is a common lab/OCR
    // quirk). The key is exact here, so refMap.get hits the right row.
    const conv = convertBiomarker(biomarkerKey, raw.value, raw.unit, {
      normalHigh: refMap.get(biomarkerKey)?.normal_high ?? null,
      trustUnit: options?.trustUnits === true,
    });
    if (conv.converted) {
      console.log(
        `[process-results] Converted ${raw.name} (${biomarkerKey}): ` +
          `${raw.value} ${raw.unit} → ${conv.value.toFixed(3)} ${conv.unit}. ${conv.note}`,
      );
    }
    const effectiveValue = conv.value;
    // A lab that prints no unit at all (Echevarne sends IDH/RDW and IDP bare)
    // gets the seed's canonical one, so the row never displays blank. The
    // gate below still rejects a unit that is present and wrong.
    const effectiveUnit = conv.unit || getCanonicalUnit(biomarkerKey) || "";

    // Canonical unit gate. After remap + conversion, the supplied unit
    // MUST match the seed's canonical unit for this biomarker_key. If
    // it doesn't, we refuse to insert the row — silently zone-classifying
    // a value in the wrong unit is the bug class that produced the
    // "Lymphocytes 2.10 10e3/µL marked critical low" screenshot. The
    // user gets a clear unit_mismatch error in the unmatched list.
    const canonical = getCanonicalUnit(biomarkerKey);
    if (canonical !== null) {
      const validation = validateCanonicalUnit(biomarkerKey, effectiveUnit);
      if (!validation.ok) {
        console.warn(
          `[process-results] UNIT MISMATCH for ${biomarkerKey} ("${raw.name}"): ` +
            `supplied "${effectiveUnit}" (normalized "${normalizeUnit(effectiveUnit)}") ` +
            `does not match canonical "${canonical}". Skipping row.`,
        );
        unmatched.push({
          name: raw.name,
          value: raw.value,
          unit: raw.unit,
          ...(raw.comparator ? { comparator: raw.comparator } : {}),
          reason: "unit_mismatch",
          expectedUnit: canonical,
        });
        continue;
      }
    }

    // The one lookup: the reference row whose key is exactly the (possibly remapped) key. A key with no row is
    // never joined to a row with a similar key: a different slug for the same marker is an explicit alias
    // (key-aliases.ts). Without a row the result is stored under its own key, unclassified, with no reference
    // fields, and is logged below.
    const ref = refMap.get(biomarkerKey);
    const matcherKey: string = biomarkerKey; // narrow for use inside closures

    if (!ref) {
      const sameLetter = Array.from(refMap.keys())
        .filter((k) => k[0] === matcherKey[0])
        .slice(0, 10)
        .join(", ") || "(none)";
      console.warn(
        `[process-results] NO REFERENCE for "${matcherKey}" (name="${raw.name}"). ` +
          `Available DB keys starting with same letter: ${sameLetter}`,
      );
      missingRefKeys.push(matcherKey);
    }
    // A bounded result ("<0,500") keeps the bound as its value and is placed only where every value the bound allows
    // falls in one zone (bounded-result.ts); any other result is classified as classifyZone places it. Every unit
    // conversion above increases with the value, so the comparator holds for the converted bound.
    //
    // A laboratory's own eGFR is a value only (lab-reported.ts, rulings D-06 and D-28): the eGFR rows describe the
    // eGFR the app computes from creatinine (step 4), so this result gets no category and no interval from them.
    // The row still gives its unit, its panel and its critical fields: a kidney value at or beyond a critical limit
    // is never hidden, whoever computed it.
    const shownRef = isLabReportedValueOnly(biomarkerKey) ? undefined : ref;
    const zone = shownRef
      ? classifyResultZone(effectiveValue, raw.comparator, shownRef.optimal_low, shownRef.optimal_high, shownRef.normal_low, shownRef.normal_high)
      : ("unclassified" as Zone);

    if (isCriticalValue(effectiveValue, ref, raw.comparator)) criticalTier = true;

    const zoneConf = ZONE_CONFIG[zone];

    const entry: ProcessedBiomarker = {
      biomarkerKey,
      name: raw.name,
      value: effectiveValue,
      unit: effectiveUnit,
      comparator: raw.comparator ?? null,
      zone,
      zoneLabel: zoneConf.label,
      zoneLabel_es: zoneConf.label_es,
      optimalLow: shownRef?.optimal_low ?? null,
      optimalHigh: shownRef?.optimal_high ?? null,
      matchConfidence: confidence,
    };

    processed.push(entry);

    biomarkerValuesToInsert.push({
      lab_result_id: labResultId,
      biomarker_key: biomarkerKey,
      biomarker_name: raw.name,
      value: effectiveValue,
      unit: effectiveUnit,
      // What the lab actually printed, before any rescale/conversion — the
      // audit trail behind the canonical value ("your lab said 4.2 mmol/L").
      reported_value: raw.value,
      reported_unit: raw.unit || null,
      // A bounded value ("<0,500") keeps its comparator; the number is the bound.
      comparator: raw.comparator ?? null,
      zone,
      optimal_low: shownRef?.optimal_low ?? null,
      optimal_high: shownRef?.optimal_high ?? null,
      normal_low: shownRef?.normal_low ?? null,
      normal_high: shownRef?.normal_high ?? null,
      // Category was previously hard-coded to "" — meaning every row went
      // into a single empty bucket and the dashboard's by-category section
      // had nothing to group by. We now stamp the panel_category from
      // biomarker_references (e.g. "cardiovascular", "thyroid"). If the
      // ref lookup failed for some reason we fall back to "uncategorized"
      // rather than empty so the UI never silently hides the row.
      category: ref?.panel_category ?? "uncategorized",
      match_confidence: confidence,
    });
  }

  // 3. Persist biomarker_values — fail loudly on error
  if (biomarkerValuesToInsert.length > 0) {
    const { error: insertError } = await supabase
      .from("biomarker_values")
      .insert(biomarkerValuesToInsert);

    if (insertError) {
      throw new Error(`Failed to insert biomarker_values: ${insertError.message}`);
    }
  }

  // 4. Calculate derived metrics, each classified against its reviewed row
  //    from the same refMap (homa_ir, non_hdl_cholesterol, nlr). A bound's
  //    comparator goes with it: a metric computed from a bound is itself a
  //    bound, or unclassified when its direction is not certain
  //    (calculated-metrics.ts). The eGFR the app computes is one of them: from the measured creatinine, sex and
  //    the age at the draw (the lab's collection date, not today's age), classified against the eGFR rows. It is
  //    not a score input (engine-inputs.ts), and it counts toward the critical tier like any value of the lab.
  const person: MetricPerson = { age: ageAtDraw(profile.date_of_birth, labState.collectionDate), sex, pregnancy: labState.state.pregnancy };
  const calculatedMetrics = calculateAllMetrics(
    processed.map((p) => ({ biomarker_key: p.biomarkerKey, value: p.value, comparator: p.comparator ?? null })),
    refMap,
    person,
  );
  if (computedEgfrCritical(calculatedMetrics, refMap)) criticalTier = true;

  // 5. Compute zone counts — these should ALWAYS be saved, regardless of
  // whether biological age can be calculated. Previously they were nested
  // inside the bio-age conditional, which meant users with < 8 biomarkers
  // saw zero counts on the dashboard even though the data was in biomarker_values.
  const optimalCount = processed.filter((p) => p.zone === "optimal").length;
  const attentionCount = processed.filter(
    (p) => p.zone === "below_optimal" || p.zone === "above_optimal",
  ).length;
  const actionCount = processed.filter(
    (p) => p.zone === "critical_low" || p.zone === "critical_high",
  ).length;

  // 6. Build engine inputs for the longevity-score engine: mapped DB keys
  // plus the computed ratios (NLR, HOMA-IR) — see engine-inputs.ts. Only a
  // result placed in a category is an input: a bounded result the app could
  // not place is left out (bounded-result.ts isUnplacedBound: its bound is
  // not a measured value), and any other result left unclassified is not
  // scored itself (scoreInputRows).
  const engineInputs: BiomarkerInput[] = buildEngineInputs(
    scoreInputRows(processed.map((p) => ({ biomarkerKey: p.biomarkerKey, value: p.value, comparator: p.comparator, zone: p.zone }))),
  );

  // 6a. Calculate longevity score (optimal-range-anchored) on the same
  //     reference rows the results were just classified with. Whether these
  //     values give a score is the engine's decision alone (its coverage
  //     rule counts the markers that actually score); processing has no
  //     gate of its own.
  //     The lab's context goes with the values: no score in declared
  //     pregnancy or lactation, none while a value is in the critical tier,
  //     and the oral-oestrogen rules (longevity-score.ts ScoreContext).
  let biologicalAge: ProcessingResult["biologicalAge"] = null;
  let fullBioAgeResult: FullResult | null = null;
  const sexParam = sex.toLowerCase() === "female" ? "female" : "male";
  const scoreContext = scoreContextOf(labState, criticalTier, biomarkerValuesToInsert);
  const lsResult = calculateLongevityScoreV2(engineInputs, sexParam, age, allRefs ?? [], scoreContext);
  const scoreWithheld: WithheldReason | null = lsResult.withheld?.reason ?? null;
  if (lsResult.longevityScore > 0) {
    fullBioAgeResult = lsResult;
    biologicalAge = {
      // `biologicalAge` is populated from the KDM result below — leave
      // null here and overwrite once KDM completes.
      biologicalAge: null,
      delta: null,
      longevityScore: lsResult.longevityScore,
      lsGrade: lsResult.lsGrade,
      confidence: lsResult.confidence,
    };
  }

  // 6c. Calculate KDM v2.2 biological age (population-anchored, mortality-
  // validated). The KDM module accepts BiomarkerInput[] with either engine
  // codes or DB keys; we feed the DB keys here so non-engine markers (e.g.,
  // Calcium, BUN, Total Cholesterol — base-panel-relevant but not in the
  // 39-code longevity engine) can contribute. Cystatin C and a laboratory's
  // eGFR are read but never used (KIDNEY_MARKERS_NOT_USED). The KDM gate
  // (≥ 8/14 base panel + Albumin + Creatinine) is enforced inside the
  // module; null result means gate failed.
  const kdmInputs: BiomarkerInput[] = processed.map((p) => ({
    code: p.biomarkerKey,
    value: p.value,
  }));
  const kdmReference = computeReferenceBA(kdmInputs, sexParam, age, kdmContext);
  const kdmComprehensive = computeComprehensiveBA(kdmInputs, sexParam, age, kdmContext);
  const kdmBiologicalAge = {
    reference: kdmReference,
    comprehensive: kdmComprehensive,
  };

  // Backfill legacy result shape: when KDM produced a Reference BA, surface
  // it on the legacy `biologicalAge` object so admin / email consumers see
  // the KDM Reference number. When KDM gate failed but longevity
  // succeeded, the object still has the score but BA is null.
  if (biologicalAge && kdmReference) {
    biologicalAge.biologicalAge = kdmReference.BA;
    biologicalAge.delta = kdmReference.BA - age;
  } else if (!biologicalAge && kdmReference) {
    // KDM succeeded but longevity didn't (e.g., domain coverage failed).
    // Surface what we have so the dashboard can still show a BA; there is
    // no score, so it is null (never 0, which the email and dashboard would print).
    biologicalAge = {
      biologicalAge: kdmReference.BA,
      delta: kdmReference.BA - age,
      longevityScore: null,
      lsGrade: null,
      confidence: "",
    };
  }

  // 7. Update lab_results with zone counts (always) + bio age + longevity.
  // Single update so counts are never missed when BA computation skips.
  const labResultUpdate: Record<string, number | string | string[] | null> = {
    optimal_count: optimalCount,
    attention_count: attentionCount,
    action_count: actionCount,
  };

  // A biological age these values do not give (the KDM gate fails) is cleared, so reprocessing a lab
  // never leaves the one an earlier model computed.
  labResultUpdate.biological_age = kdmReference?.BA ?? null;
  labResultUpdate.bio_age_method = kdmReference ? KDM_REFERENCE_BA_METHOD : null;
  labResultUpdate.bio_age_n_markers = kdmReference?.n_markers_used ?? null;
  labResultUpdate.bio_age_applied_spanish_calibration =
    kdmReference?.applied_spanish_recalibration_markers ?? null;
  labResultUpdate.biological_age_comprehensive = kdmComprehensive?.BA ?? null;
  // Likewise the score: when these values give none (the engine's coverage rule fails, or the score is
  // withheld), longevity_score and longevity_grade are written as null, never as 0 and never left from an earlier run.
  labResultUpdate.longevity_score = biologicalAge?.longevityScore ?? null;
  labResultUpdate.longevity_grade = biologicalAge?.lsGrade ?? null;

  const { error: updateError } = await supabase
    .from("lab_results")
    .update(labResultUpdate)
    .eq("id", labResultId);

  if (updateError) {
    throw new Error(`Failed to update lab_results: ${updateError.message}`);
  }

  // 7b. Biological age v3 in shadow mode (biological-age-v3-adapter.ts), from the values just stored (with their
  // bounds and the reference limits of each row, which the refusal rules read), now that the KDM values are written:
  // upserted into bio_age_v3_shadow with the service-role client, shown and returned nowhere. A record refused by a
  // rule (biological-age-v3-rules.ts) stores no figure and its reason codes (`reason`, `reasons`). It never throws;
  // a failure is logged.
  await bioAgeV3Shadow(supabase, { userId, labResultId, values: biomarkerValuesToInsert, profile });

  // 8. Recompute the user's rolling-average BA across all recent labs and
  // cache it on `profiles.current_ba*`. This is what the dashboard reads.
  // We don't fail the whole pipeline if this errors — the per-lab BA was
  // already written above.
  try {
    await recomputeAndCacheUserBA(userId, supabase);
  } catch (err) {
    console.error("[processLabResults] recomputeAndCacheUserBA failed:", err);
  }

  return {
    processed,
    calculatedMetrics,
    biologicalAge,
    kdmBiologicalAge,
    fullBioAgeResult,
    scoreWithheld,
    unmatched,
    refMapSize: refMap.size,
    missingRefKeys: missingRefKeys.slice(0, 20),
  };
}

// ─── Lab-level metric recomputation (manual-edit path) ───

/**
 * Recompute every lab-level metric the dashboard reads — zone counts,
 * KDM biological age (Reference + Comprehensive), longevity score, and
 * the user's rolling-average BA cached on profile.current_ba* — from
 * the CURRENT biomarker_values rows for a single lab.
 *
 * This is the "edit path" version of steps 5-8 of processLabResults.
 * Whereas processLabResults works from the in-memory `processed` array
 * it just wrote, this loads the persisted state and recomputes — so
 * when /api/biomarker-values/[id] updates a single row, we can refresh
 * the whole panel's BA, score and counts without re-running name
 * matching, unit conversion or re-inserting biomarker_values (the row
 * being edited is already correctly classified by the PATCH handler).
 *
 * Idempotent. Throws if a read the figures need, or the lab_results UPDATE,
 * fails; the stored figures are then left as they were. A longevity gate
 * that doesn't pass clears the stored score, and a KDM gate that doesn't pass
 * clears the stored biological age (both with a complete profile), since these
 * values no longer give one; reference rows the score cannot read clear the
 * stored score as well (no score is left on a failed read). The rolling-average cache is
 * refreshed whatever happened, so a lab that has just turned ready counts on
 * the dashboard even when its own figures could not be recomputed; that
 * refresh is best-effort, and an error there is logged, not thrown.
 */
export async function recomputeLabMetrics(
  userId: string,
  labResultId: string,
  supabase: ServerClient,
): Promise<void> {
  try {
    await recomputeLabFigures(userId, labResultId, supabase);
  } finally {
    // 6. Rolling-average BA → profile.current_ba*. Best-effort.
    try {
      await recomputeAndCacheUserBA(userId, supabase);
    } catch (err) {
      console.error("[recomputeLabMetrics] recomputeAndCacheUserBA failed:", err);
    }
  }
}

/** Steps 1 to 5b of recomputeLabMetrics: this lab's counts, score, KDM figures and version 3 record. */
async function recomputeLabFigures(
  userId: string,
  labResultId: string,
  supabase: ServerClient,
): Promise<void> {
  // 1. Profile (date_of_birth + sex). Required for age-dependent
  //    longevity scoring and KDM. If missing we can still recompute
  //    zone counts but skip BA/longevity. A failed read throws, rather
  //    than being taken for a missing profile.
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("date_of_birth, sex")
    .eq("id", userId)
    .maybeSingle();
  if (profileError) {
    throw new Error(`recomputeLabMetrics: failed to load the profile: ${profileError.message}`);
  }

  // 2. All biomarker_values for this lab.
  const { data: values, error: valuesError } = await supabase
    .from("biomarker_values")
    .select("biomarker_key, value, zone, comparator, unit, normal_low")
    .eq("lab_result_id", labResultId);
  if (valuesError) {
    throw new Error(
      `recomputeLabMetrics: failed to load biomarker_values: ${valuesError.message}`,
    );
  }
  if (!values || values.length === 0) {
    return;
  }
  // A laboratory's own eGFR stored before it became a value only keeps a category on its row: it is read here
  // without one (lab-reported.ts), so it is neither counted nor scored.
  const shown = values.map(shownAsValueOnly);

  // 3. Zone counts.
  const optimalCount = shown.filter((v) => v.zone === "optimal").length;
  const attentionCount = shown.filter(
    (v) => v.zone === "below_optimal" || v.zone === "above_optimal",
  ).length;
  const actionCount = shown.filter(
    (v) => v.zone === "critical_low" || v.zone === "critical_high",
  ).length;

  const labResultUpdate: Record<string, number | string | string[] | null> = {
    optimal_count: optimalCount,
    attention_count: attentionCount,
    action_count: actionCount,
  };

  // 4. BA + longevity require a fully-populated profile. Without it we
  //    still ship the zone counts (above) — they're what the headline
  //    "X needs attention" tile reads.
  if (profile?.date_of_birth && profile?.sex) {
    const age = calculateAge(profile.date_of_birth);
    const sex = (profile.sex as string).toLowerCase();
    const sexParam: "female" | "male" = sex === "female" ? "female" : "male";

    if (Number.isFinite(age)) {
      // 4a. The lab's patient context, read once (loadLabState), as in processLabResults: the version recorded with
      //     this lab result, else the latest created on or before it, with the lab's per-draw answers. Its supplements
      //     drive the creatine adjustment of creatinine (4c); its physiological state goes to the score (4b). Missing
      //     context = KDM runs without lifestyle adjustments (degraded but safe) and the state is unknown. A failed
      //     read throws before anything is stored.
      const labState = await loadLabState(supabase, userId, labResultId);

      // 4b. Longevity score — mapped engine codes plus computed ratios. Whether they give a score is the engine's
      //     decision alone, as in processLabResults: there is no gate here.
      //     As in processLabResults, only a result placed in a category is scored (not a bounded result the app could
      //     not place, nor any other unclassified one), and when these values give no score (the engine's coverage
      //     rule fails, or the score is withheld) longevity_score and longevity_grade are written as null, as the
      //     biological age is below: a stored score never outlives the values that gave it.
      //     A declared state that withholds the score (pregnancy, lactation) clears it before any row is read.
      //     Reference rows that cannot be read clear it too (loadScoreRows): without them nothing shows that the
      //     stored values still give the stored score, so no score is left standing on a failed read.
      const engineInputs: BiomarkerInput[] = buildEngineInputs(
        scoreInputRows(shown.map((v) => ({ biomarkerKey: v.biomarker_key, value: Number(v.value), comparator: v.comparator, zone: v.zone }))),
      );
      const withheldByState = withheldByContext(scoreContextOf(labState, false)) !== null;
      // The score reads the reference rows for the user's sex, as processLabResults does, whatever the number of
      // values: the critical tier is evaluated over every stored value of the lab.
      const rows = withheldByState ? null : await loadScoreRows(supabase, sex);
      if (rows === null) {
        // Withheld by the declared state, or the rows could not be read: no score.
        labResultUpdate.longevity_score = null;
        labResultUpdate.longevity_grade = null;
      } else {
        // The lab's context, as in processLabResults: its declared state, and the critical tier over every stored
        // value of the lab, scored or not, against the row picked for the person (set only when the rows carry
        // critical fields, which loadScoreRows does not ask for yet).
        const pickedRows = pickReferenceRows(rows, sex, age).picked;
        const sign = (c: unknown) => (c === "<" || c === ">" ? c : null);
        // The eGFR the app computes counts too, as in processLabResults: only its value is needed here.
        const computed = calculateAllMetrics(
          values.filter((v) => Number.isFinite(Number(v.value))).map((v) => ({ biomarker_key: v.biomarker_key, value: Number(v.value), comparator: sign(v.comparator) })),
          undefined,
          { age: ageAtDraw(profile.date_of_birth, labState.collectionDate), sex },
        );
        const criticalTier =
          values.some((v) => isCriticalValue(Number(v.value), pickedRows.get(v.biomarker_key), sign(v.comparator))) ||
          computedEgfrCritical(computed, pickedRows);
        const lsResult = calculateLongevityScoreV2(engineInputs, sexParam, age, rows, scoreContextOf(labState, criticalTier, values as GlycationRow[]));
        const scored = lsResult.longevityScore > 0;
        labResultUpdate.longevity_score = scored ? lsResult.longevityScore : null;
        labResultUpdate.longevity_grade = scored ? lsResult.lsGrade : null;
      }

      // 4c. KDM Reference + Comprehensive BA, the creatine adjustment from the context's supplements (4a).
      const kdmContext: KdmPatientContext = { supplements: labState.supplements };
      const kdmInputs: BiomarkerInput[] = values
        .filter((v) => Number.isFinite(Number(v.value)))
        .map((v) => ({ code: v.biomarker_key, value: Number(v.value) }));
      const kdmReference = computeReferenceBA(kdmInputs, sexParam, age, kdmContext);
      const kdmComprehensive = computeComprehensiveBA(kdmInputs, sexParam, age, kdmContext);

      // As in processLabResults: when these values give no biological age the stored one is cleared,
      // not left from an earlier model (for example one that read measured fructosamine).
      labResultUpdate.biological_age = kdmReference?.BA ?? null;
      labResultUpdate.bio_age_method = kdmReference ? KDM_REFERENCE_BA_METHOD : null;
      labResultUpdate.bio_age_n_markers = kdmReference?.n_markers_used ?? null;
      labResultUpdate.bio_age_applied_spanish_calibration =
        kdmReference?.applied_spanish_recalibration_markers ?? null;
      labResultUpdate.biological_age_comprehensive = kdmComprehensive?.BA ?? null;
    }
  }

  // 5. Persist everything we recomputed in a single UPDATE.
  const { error: updateError } = await supabase
    .from("lab_results")
    .update(labResultUpdate)
    .eq("id", labResultId);
  if (updateError) {
    throw new Error(
      `recomputeLabMetrics: lab_results update failed: ${updateError.message}`,
    );
  }

  // 5b. Biological age v3 in shadow mode, as in processLabResults: recomputed whenever the lab is, so a corrected
  //     result never keeps a stale record (without a usable profile it records why there is no age). It reads this
  //     result's rows itself, with units, bounds and lower and upper limits; never throws.
  await bioAgeV3Shadow(supabase, { userId, labResultId, values: null, profile });
}

type ServerClient = Awaited<ReturnType<typeof createClient>>;

/** The critical fields a loaded biomarker_references row carries once the sign-off columns exist. */
type CriticalColumns = { critical_low?: number | null; critical_high?: number | null };

/**
 * The results the score may read, as buildEngineInputs takes them: only a result placed in a category is a score
 * input. A bounded result the app could not place is left out altogether (its bound is not a measured value, so
 * no ratio is computed from it either). Any other result left unclassified, by a missing or boundless row or by a
 * rule, is marked value-only: it is not scored, and a ratio the app computes from it still is, on the ratio's own
 * row (the white-cell percentages carry no category and give the NLR).
 */
function scoreInputRows(
  results: ReadonlyArray<{ biomarkerKey: string; value: number; comparator?: unknown; zone?: unknown }>,
): Array<{ biomarkerKey: string; value: number; valueOnly: boolean }> {
  return results
    .filter((r) => !isUnplacedBound(r))
    .map((r) => ({ biomarkerKey: r.biomarkerKey, value: r.value, valueOnly: r.zone === "unclassified" }));
}

/**
 * Whether the eGFR the app computed is at or beyond a critical field of the eGFR row picked for the person (the row
 * it is classified against). A metric that is a bound is critical only when the bound already lies beyond the limit
 * (isCriticalValue).
 */
function computedEgfrCritical(metrics: readonly CalculatedMetric[], rows: ReadonlyMap<string, CriticalColumns>): boolean {
  const egfr = metrics.find((m) => m.metricKey === EGFR_METRIC_KEY);
  return egfr !== undefined && isCriticalValue(egfr.value, rows.get("egfr_creatinine_based"), egfr.comparator);
}

/**
 * What the score is told about the lab beyond its values (longevity-score.ts ScoreContext).
 *
 * `stored` are the lab's own results as stored (key, value, unit, comparator and the lower limit stored with each):
 * the HbA1c exclusion is read from them with the function the biological age uses (glycation-exclusion.ts), so
 * the score passes over an HbA1c the biological age refuses on the same result (ruling D-06). Only this lab's
 * results are read here; the biological age also reads the client's other recent results.
 *
 * Fasting is not confirmed here: the lab's context does not carry the fasting answer to processing yet, so a
 * marker that requires it (fasting glucose) does not score (fail closed) until the pre-analytical rules bring it.
 */
function scoreContextOf(labState: LabState, criticalTier: boolean, stored: readonly GlycationRow[] = []): ScoreContext {
  return {
    state: labState.state,
    oralOestrogen: labState.state.oralOestrogen,
    criticalTier,
    hba1cExcluded: glycationExclusion(stored) !== null,
  };
}

/** Time budget of the biological age v3 shadow work (computing and storing); past it processing goes on without it. */
export const BIO_AGE_V3_BUDGET_MS = 10_000;

/** Where the v3 shadow records live: one row per lab result, readable and writable by the service role only. */
export const BIO_AGE_V3_SHADOW_TABLE = "bio_age_v3_shadow";

/**
 * Biological age v3 in shadow mode (biological-age-v3-adapter.ts): computes the record of one lab result, reading
 * with the caller's client, and upserts it into bio_age_v3_shadow on lab_result_id. The write always goes through
 * the service-role client (createAdminClient), whatever client the caller holds: the table is closed to every other
 * role, and the upload-confirm, reprocess, value-edit and regenerate-summary routes reach here with a user-scoped
 * client (the webhook, lab bridge, admin entry and admin recalc pass the service role). Best-effort and isolated:
 * it never throws and never waits past BIO_AGE_V3_BUDGET_MS. A failure to compute (loading the adapter or the model
 * included) is logged and stored as { reason: "error" }, so an earlier record is not kept; a failure to store is
 * logged.
 */
async function bioAgeV3Shadow(
  supabase: SupabaseClient | ServerClient,
  args: Omit<BioAgeV3ShadowArgs, "now">,
): Promise<void> {
  const where = `lab ${args.labResultId}`;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let timedOut = false;
  const budget = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      timedOut = true;
      reject(new Error(`timed out after ${BIO_AGE_V3_BUDGET_MS} ms`));
    }, BIO_AGE_V3_BUDGET_MS);
  });
  budget.catch(() => {}); // raced below, or abandoned once the work is done: never an unhandled rejection

  try {
    const admin = createAdminClient();
    if (!admin) throw new Error("no service-role client (SUPABASE_SERVICE_ROLE_KEY is not set)");
    const now = new Date();

    let record: BioAgeV3Stored;
    try {
      const computing = import("./biological-age-v3-adapter").then((adapter) =>
        adapter.computeBioAgeV3Shadow(supabase as SupabaseClient, { ...args, now }),
      );
      record = await Promise.race([computing, budget]);
    } catch (err) {
      if (timedOut) throw err; // out of time: nothing more is attempted
      console.error(`[process-results] biological age v3 (shadow) failed for ${where}; storing { reason: "error" }:`, err);
      record = { reason: "error" };
    }

    const storing = admin
      .from(BIO_AGE_V3_SHADOW_TABLE)
      .upsert(
        { lab_result_id: args.labResultId, user_id: args.userId, record, computed_at: now.toISOString() },
        { onConflict: "lab_result_id" },
      );
    const { error } = await Promise.race([storing, budget]);
    if (error) throw new Error(error.message);
  } catch (err) {
    console.error(`[process-results] biological age v3 (shadow) record not stored for ${where}:`, err);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

/**
 * The reference rows the score reads when a lab is recomputed: every row for
 * the user's sex and "both", as processLabResults loads them. Null if they
 * cannot be read: there is then nothing to score against, and the caller
 * clears the stored score (fail-closed: a score is never left standing
 * when the rows that would confirm it cannot be read). The next recompute
 * that reads them stores the score again.
 */
async function loadScoreRows(supabase: ServerClient, sex: string): Promise<ReviewedRow[] | null> {
  const { data, error } = await supabase
    .from("biomarker_references")
    .select("biomarker_key, sex, age_group_en, optimal_low, optimal_high, normal_low, normal_high")
    .in("sex", [sex, "both"]);
  if (error) {
    console.error("[recomputeLabMetrics] biomarker_references read failed; longevity score cleared:", error);
    return null;
  }
  return data ?? [];
}
