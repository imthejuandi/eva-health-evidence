/**
 * Biological age version 3: what the client is shown (pure formatting, no I/O).
 *
 * Reads the stored record (biological-age-v3-adapter.ts BioAgeV3Record, kept in bio_age_v3_shadow) and turns it into
 * plain strings in the client's language. Every sentence and every display threshold comes from
 * docs/signoff/work/v3/display-copy.json, the file the physician signs (DSRT checks B6 and X2 read it too), so the
 * copy shown is the copy signed. Nothing here computes or changes the biological age: the frozen module
 * (biological-age-v3.ts) and the adapter do that. The page decides whether to call this at all
 * (bio-age-flags.ts isBioAgeV3Visible, false by default).
 *
 * The rules (display-copy.json `rules`, wording-rules.md section 8):
 * - the figure is always shown with its 95% range, in whole years (the range rounded outward);
 * - "younger" or "older" only when the range shown excludes the chronological age, else "not distinguishable";
 * - a change between two results is called real only above the reliable-change threshold (about 4.3 years,
 *   MODEL-CARD.md section 14), between results of the same tier, neither provisional;
 * - a provisional figure (hs-CRP above 10 mg/L, capped) carries its marker and the retest suggestion;
 * - with no figure, every refusal reason is given in plain words;
 * - the US reference population is stated; the flat segments of the model are listed.
 */
import displayCopy from "../../../docs/signoff/work/v3/display-copy.json";
import { isoToEuropean } from "./date-format";
import type { BioAgeV3Record, BioAgeV3Stored } from "./biological-age-v3-adapter";

export type BioAgeV3Locale = "en" | "es";

interface LanguageCopy {
  title: string;
  figure: string;
  direction: { younger: string; older: string; indistinct: string };
  reference: string;
  not_diagnosis: string;
  provisional: string;
  change: {
    real_lower: string;
    real_higher: string;
    no_change: string;
    not_compared_tier: string;
    not_compared_provisional: string;
  };
  refusal: { heading: string; reasons: Record<string, string>; closer: string };
  flat_segments: Record<string, string> & { heading: string; intro: string };
}

interface DisplayRules {
  range_always_shown: boolean;
  direction_only_when_interval_excludes_age: boolean;
  reliable_change_years: number;
  compare_only_same_tier: boolean;
  compare_provisional: boolean;
  provisional_crp_above_mg_l: number;
}

interface FlatSegmentEntry {
  marker: string;
  side: string;
  copy_key: string;
}

interface DisplayCopyFile {
  rules: DisplayRules;
  flat_segments: FlatSegmentEntry[];
  en: LanguageCopy;
  es: LanguageCopy;
}

export const BIO_AGE_V3_DISPLAY: DisplayCopyFile = displayCopy as unknown as DisplayCopyFile;

/** The reliable-change threshold, years (display-copy.json rules; MODEL-CARD.md section 14; pending physician). */
export const RELIABLE_CHANGE_YEARS: number = BIO_AGE_V3_DISPLAY.rules.reliable_change_years;

export function copyFor(locale: string): LanguageCopy {
  return locale === "es" ? BIO_AGE_V3_DISPLAY.es : BIO_AGE_V3_DISPLAY.en;
}

function lang(locale: string): BioAgeV3Locale {
  return locale === "es" ? "es" : "en";
}

/** Replaces {name} placeholders; a missing value leaves the placeholder visible, which a test would catch. */
export function fill(template: string, values: Readonly<Record<string, string | number>>): string {
  return template.replace(/\{(\w+)\}/g, (m, k: string) => (k in values ? String(values[k]) : m));
}

/** One decimal, with the locale's decimal separator. */
export function oneDecimal(n: number, locale: string): string {
  const s = (Math.round(n * 10) / 10).toFixed(1);
  return lang(locale) === "es" ? s.replace(".", ",") : s;
}

/** A threshold as written in the copy (4.3 / 4,3); whole numbers without decimals. */
function thresholdText(n: number, locale: string): string {
  const s = String(n);
  return lang(locale) === "es" ? s.replace(".", ",") : s;
}

// ─── The figure ───

export interface WholeYearsFigure {
  ba: number;
  low: number;
  high: number;
}

/** The figure in whole years: the age to the nearest year, the range rounded outward so it contains the computed one. */
export function wholeYearsFigure(ba: number, intervalLow: number, intervalHigh: number): WholeYearsFigure {
  return { ba: Math.round(ba), low: Math.floor(intervalLow), high: Math.ceil(intervalHigh) };
}

export type BioAgeV3Direction = "younger" | "older" | "indistinct";

/**
 * "younger" only when the whole range shown is below the chronological age, "older" only when it is above;
 * otherwise "indistinct". Judged on the rounded range shown, so the words never contradict the numbers.
 */
export function directionOf(chronologicalAge: number, figure: Pick<WholeYearsFigure, "low" | "high">): BioAgeV3Direction {
  if (figure.high < chronologicalAge) return "younger";
  if (figure.low > chronologicalAge) return "older";
  return "indistinct";
}

// ─── Change between two results ───

export type BioAgeV3ChangeKind = "real_lower" | "real_higher" | "no_change" | "not_compared_tier" | "not_compared_provisional";

type FigureRecord = Pick<BioAgeV3Record, "ba" | "tier" | "provisional">;

/**
 * Whether the change from `previous` to `current` is real: above the reliable-change threshold (strictly), between
 * results of the same tier, neither provisional. null when either has no figure (nothing to compare).
 */
export function changeKind(
  current: FigureRecord,
  previous: FigureRecord,
  threshold: number = RELIABLE_CHANGE_YEARS,
): { kind: BioAgeV3ChangeKind; years: number } | null {
  if (current.ba == null || previous.ba == null) return null;
  const diff = current.ba - previous.ba;
  const years = Math.abs(diff);
  const rules = BIO_AGE_V3_DISPLAY.rules;
  if (!rules.compare_provisional && (current.provisional || previous.provisional)) return { kind: "not_compared_provisional", years };
  if (rules.compare_only_same_tier && current.tier !== previous.tier) return { kind: "not_compared_tier", years };
  if (years > threshold) return { kind: diff < 0 ? "real_lower" : "real_higher", years };
  return { kind: "no_change", years };
}

// ─── Refusals ───

/**
 * The plain-words reason for each code, in the record's order; an unknown code gets the generic one. Deduplicated on
 * the sentence, not only the code: two codes can share one sentence (the signed and the model's age range), and the
 * client reads each sentence once (the card also keys its list on the text).
 */
export function refusalReasons(record: Pick<BioAgeV3Record, "reason" | "reasons"> | { reason: "error" }, locale: string): string[] {
  const reasons = copyFor(locale).refusal.reasons;
  const codes: string[] = [];
  const entries = "reasons" in record && Array.isArray(record.reasons) ? record.reasons : [];
  for (const e of entries) if (!codes.includes(e.code)) codes.push(e.code);
  if (record.reason && !codes.includes(record.reason)) codes.unshift(record.reason);
  if (!codes.length) codes.push("error");
  return [...new Set(codes.map((c) => reasons[c] ?? reasons.error))];
}

// ─── The whole view ───

export interface BioAgeV3PreviousResult {
  record: BioAgeV3Stored;
  /** The earlier result's draw date (YYYY-MM-DD). */
  drawDate: string | null;
}

export interface BioAgeV3DisplayInput {
  record: BioAgeV3Stored;
  /** Completed years at this result's draw (the age the model used); null when unknown. */
  chronologicalAge: number | null;
  locale: string;
  previous?: BioAgeV3PreviousResult | null;
}

/** Strings only: what the card renders, safe to pass to a client component. */
export interface BioAgeV3View {
  kind: "figure" | "refused";
  locale: BioAgeV3Locale;
  title: string;
  /** "Estimated biological age: 47 years (95% range: 44 to 50)". Present when kind is "figure". */
  figure: string | null;
  direction: BioAgeV3Direction | null;
  directionText: string | null;
  provisionalText: string | null;
  changeKind: BioAgeV3ChangeKind | null;
  changeText: string | null;
  reference: string;
  notDiagnosis: string;
  /** Present when kind is "refused". */
  refusalHeading: string | null;
  refusalReasons: string[];
  refusalCloser: string | null;
  flatHeading: string;
  flatIntro: string;
  flatSegments: string[];
}

function isFigureRecord(r: BioAgeV3Stored): r is BioAgeV3Record & { ba: number; interval_low: number; interval_high: number } {
  return "ba" in r && r.ba != null && r.interval_low != null && r.interval_high != null && Number.isFinite(r.ba);
}

/** The flat segments in client wording, in display-copy.json's order, one sentence per copy key. */
export function flatSegmentTexts(locale: string): string[] {
  const c = copyFor(locale).flat_segments;
  const keys = [...new Set(BIO_AGE_V3_DISPLAY.flat_segments.map((f) => f.copy_key.replace(/^flat_segments\./, "")))];
  return keys.map((k) => c[k]).filter((s): s is string => typeof s === "string");
}

/**
 * The card's content. A figure without its 95% range is never produced: a record whose range is missing is shown as
 * refused (reason "error").
 */
export function buildBioAgeV3View(input: BioAgeV3DisplayInput): BioAgeV3View {
  const locale = lang(input.locale);
  const c = copyFor(locale);
  const base = {
    locale,
    title: c.title,
    reference: c.reference,
    notDiagnosis: c.not_diagnosis,
    flatHeading: c.flat_segments.heading,
    flatIntro: c.flat_segments.intro,
    flatSegments: flatSegmentTexts(locale),
  };
  const r = input.record;
  if (!isFigureRecord(r)) {
    const refused = "ba" in r && r.ba != null ? ({ reason: "error" } as const) : r;
    return {
      ...base,
      kind: "refused",
      figure: null,
      direction: null,
      directionText: null,
      provisionalText: null,
      changeKind: null,
      changeText: null,
      refusalHeading: c.refusal.heading,
      refusalReasons: refusalReasons(refused, locale),
      refusalCloser: c.refusal.closer,
    };
  }

  const fig = wholeYearsFigure(r.ba, r.interval_low, r.interval_high);
  const figure = fill(c.figure, { ba: fig.ba, low: fig.low, high: fig.high });
  const age = input.chronologicalAge;
  const direction = age != null && Number.isFinite(age) ? directionOf(age, fig) : null;
  const directionText = direction ? fill(c.direction[direction], { age: age as number }) : null;

  let ck: BioAgeV3ChangeKind | null = null;
  let changeText: string | null = null;
  const prev = input.previous;
  // Compared only with a dated earlier result: the sentence names its date.
  if (prev && prev.drawDate && "ba" in prev.record) {
    const ch = changeKind(r, prev.record);
    if (ch) {
      ck = ch.kind;
      changeText = fill(c.change[ch.kind], {
        date: isoToEuropean(prev.drawDate),
        years: oneDecimal(ch.years, locale),
        threshold: thresholdText(RELIABLE_CHANGE_YEARS, locale),
      });
    }
  }

  return {
    ...base,
    kind: "figure",
    figure,
    direction,
    directionText,
    provisionalText: r.provisional ? c.provisional : null,
    changeKind: ck,
    changeText,
    refusalHeading: null,
    refusalReasons: [],
    refusalCloser: null,
  };
}
