/**
 * The score engine runs on a generated specification file (data/score-spec.json, ScoreSpec in longevity-score.ts).
 *
 *  - The two literals the acceptance test's runner reads from the engine (REVIEWED_ROW_KEY, which it imports;
 *    REDUNDANT_GROUPS, which it parses from the source text) equal the file.
 *  - The engine's source holds no tier and no bonus: the score has neither.
 *  - With changed copies of the specification: a marker scores only when its picked row is eligible and carries the
 *    graded band; in a group the first present member that can score does and the others are suppressed by it;
 *    weights, coverage, grades, curves, cap and confidence are the file's.
 *
 * That the file is what the generator writes from the rulings, the decided rows and the verifier's grades is
 * tested with the generator (src/lib/signoff/build-score-spec.test.ts). The scored set itself is tested in
 * longevity-score.reviewed.test.ts.
 */
import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import specFile from "./data/score-spec.json";
import {
  calculateLongevityScoreV2,
  OUT_OF_RANGE_CAP,
  REDUNDANT_GROUPS,
  REVIEWED_ROW_KEY,
  reviewedPenalty,
  rowEligibilityKey,
  SCORE_SPEC,
  type BiomarkerInput,
  type FullResult,
  type ReviewedRange,
  type ScoreSpec,
  type ScoreSpecMarker,
} from "./longevity-score";
import { pickReferenceRows } from "./reference-row";
import { signedRows } from "./__tests__/fixtures/reviewed-rows";
import { engineRedundantGroups } from "../../../scripts/signoff/checks/score";

const ROOT = path.resolve(__dirname, "../../..");
const SEED = signedRows();
const SEX = "male" as const;
const AGE = 45;
const PICKED = pickReferenceRows(SEED, SEX, AGE).picked;
const rowOf = (code: string, spec: ScoreSpec = SCORE_SPEC) => PICKED.get(spec.markers[code].key)!;

/** A value inside the optimal band of the marker's picked row (reference limits win over optimal bounds). */
function optimalValue(code: string): number {
  const r: ReviewedRange = rowOf(code);
  const band = [Math.max(r.optimal_low ?? -Infinity, r.normal_low ?? -Infinity), Math.min(r.optimal_high ?? Infinity, r.normal_high ?? Infinity)];
  return band.find(Number.isFinite) ?? 1;
}
/** A value just past the marker's upper reference limit: out of range. */
const aboveReference = (code: string) => rowOf(code).normal_high! * 1.1;
const panel = (codes: string[], values: Record<string, number> = {}): BiomarkerInput[] =>
  codes.map((code) => ({ code, value: values[code] ?? optimalValue(code) }));

/** The specification with a change applied to a deep copy of it. */
function specWith(change: (spec: ScoreSpec) => void): ScoreSpec {
  const spec = structuredClone(SCORE_SPEC);
  change(spec);
  return spec;
}
const marker = (spec: ScoreSpec, code: string): ScoreSpecMarker => spec.markers[code];
const pickedKey = (code: string) => rowEligibilityKey(rowOf(code));
const score = (inputs: BiomarkerInput[], spec?: ScoreSpec, context?: Parameters<typeof calculateLongevityScoreV2>[4]) =>
  calculateLongevityScoreV2(inputs, SEX, AGE, SEED, context, spec);
const scoredCodes = (r: FullResult) => r.markerScores.map((m) => m.code).sort();
const suppressedBy = (r: FullResult) => Object.fromEntries(r.suppressedMarkers.map((m) => [m.code, m.suppressedBy]));

/** Ten markers that all score for a man of 45, in five domains. */
const TEN = ["APOB", "HDL_C", "TG", "HBA1C", "HSCRP", "ALT", "ALBUMIN", "HGB", "URIC_ACID", "VITD"];

describe("the literals the acceptance test's runner reads equal the specification file", () => {
  const source = fs.readFileSync(path.join(ROOT, "src/lib/biomarkers/longevity-score.ts"), "utf8");

  it("the engine's specification is the file", () => {
    expect(SCORE_SPEC).toEqual(specFile);
    expect(SCORE_SPEC.version).toBe("score 2.0");
  });

  it("REVIEWED_ROW_KEY: every code of the file with its key, and nothing else", () => {
    expect(REVIEWED_ROW_KEY).toEqual(Object.fromEntries(Object.entries(SCORE_SPEC.markers).map(([code, m]) => [code, m.key])));
  });

  it("REDUNDANT_GROUPS: the file's groups, in the file's order, also as the runner parses the source text", () => {
    expect(REDUNDANT_GROUPS).toEqual(SCORE_SPEC.groups.map((g) => ({ name: g.name, priorityOrder: g.priority_order })));
    expect(engineRedundantGroups(ROOT)).toEqual(SCORE_SPEC.groups.map((g) => g.priority_order));
  });

  it("every group member is a marker of the file, and no marker is in two groups", () => {
    const members = SCORE_SPEC.groups.flatMap((g) => g.priority_order);
    expect(members.filter((c) => !(c in SCORE_SPEC.markers))).toEqual([]);
    expect(new Set(members).size).toBe(members.length);
  });

  it("the engine's source and the file hold no tier and no bonus term", () => {
    // Comments may say that the score has no bonus; no identifier or data key may carry one.
    const code = source.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
    expect(code.match(/tier(?!\b)|\bTier\b|TIER|[bB]onus|BONUS|deep_target|sex_only|SCORED_FOR_SEX_ONLY/g) ?? []).toEqual([]);
    expect(code).toMatch(/criticalTier/); // the critical tier of a value is another thing, and stays
    expect(JSON.stringify(specFile).match(/"tier"|bonus|deep_target|sex_only/g) ?? []).toEqual([]);
  });
});

describe("row eligibility: a marker scores only through an eligible row that carries the graded band", () => {
  const BOTH = panel(["APOB", "LDL_C", ...TEN.filter((c) => c !== "APOB")]);

  it("the key is the picked row's sex and age group", () => {
    expect(rowEligibilityKey({ sex: "Both", age_group_en: "All Adults" })).toBe("both|All Adults");
    expect(rowEligibilityKey({ sex: null, age_group_en: null })).toBe("|");
    expect(pickedKey("APOB")).toBe("both|All Adults");
    expect(pickedKey("ALT")).toBe("male|All Adults");
  });

  it("apoB eligible: it scores and LDL-C is suppressed by it", () => {
    const r = score(BOTH);
    expect(scoredCodes(r)).toContain("APOB");
    expect(suppressedBy(r)).toEqual({ LDL_C: "APOB" });
  });

  it("apoB's picked row not eligible: the group passes to LDL-C, and apoB neither scores nor is listed as suppressed", () => {
    const spec = specWith((s) => { marker(s, "APOB").rows[pickedKey("APOB")].eligible = false; });
    const r = score(BOTH, spec);
    expect(scoredCodes(r)).toContain("LDL_C");
    expect(scoredCodes(r)).not.toContain("APOB");
    expect(suppressedBy(r)).toEqual({});
    // apoB far out of range costs nothing and holds nothing.
    const out = score(panel(["APOB", "LDL_C", ...TEN.filter((c) => c !== "APOB")], { APOB: aboveReference("APOB") }), spec);
    expect(out).toMatchObject({ longevityScore: 100, cap: null });
  });

  it("a row the map does not name, a marker with no weight, and a band other than the graded one are not eligible", () => {
    const unnamed = specWith((s) => { marker(s, "APOB").rows = { "female|All Adults": marker(s, "APOB").rows[pickedKey("APOB")] }; });
    expect(scoredCodes(score(BOTH, unnamed))).not.toContain("APOB");
    const noWeight = specWith((s) => { marker(s, "APOB").weight = null; });
    expect(scoredCodes(score(BOTH, noWeight))).not.toContain("APOB");
    const otherBand = specWith((s) => { marker(s, "APOB").rows[pickedKey("APOB")].optimal_high = 80; });
    expect(scoredCodes(score(BOTH, otherBand))).not.toContain("APOB");
    for (const spec of [unnamed, noWeight, otherBand]) expect(scoredCodes(score(BOTH, spec))).toContain("LDL_C");
  });

  it("no eligible member: none of the group scores and none is suppressed", () => {
    const spec = specWith((s) => {
      for (const code of ["APOB", "NON_HDL", "LDL_C"]) marker(s, code).rows[pickedKey(code)].eligible = false;
    });
    const r = score(panel(["APOB", "NON_HDL", "LDL_C", ...TEN.filter((c) => c !== "APOB")]), spec);
    expect(scoredCodes(r).filter((c) => ["APOB", "NON_HDL", "LDL_C"].includes(c))).toEqual([]);
    expect(suppressedBy(r)).toEqual({});
    expect(r.validation.totalMarkers).toBe(9);
  });

  it("the group order is the file's", () => {
    const spec = specWith((s) => { s.groups[0].priority_order = ["LDL_C", "NON_HDL", "APOB"]; });
    const r = score(BOTH, spec);
    expect(scoredCodes(r)).toContain("LDL_C");
    expect(suppressedBy(r)).toEqual({ APOB: "LDL_C" });
  });

  it("a present member whose row is missing or has no bounds passes the group on as well", () => {
    const without = SEED.filter((r) => r.biomarker_key !== "apolipoprotein_b_apob");
    const r = calculateLongevityScoreV2(BOTH, SEX, AGE, without);
    expect(scoredCodes(r)).toContain("LDL_C");
    expect(suppressedBy(r)).toEqual({});
  });
});

describe("weights, coverage, grades, curves, cap and confidence come from the file", () => {
  const inputs = panel(TEN, { TG: aboveReference("TG") });
  const base = score(inputs);

  it("weights: a marker's weight is the file's, in its own figures and in the score", () => {
    const spec = specWith((s) => { marker(s, "TG").weight = 6; });
    const r = score(inputs, spec);
    const tg = (x: FullResult) => x.markerScores.find((m) => m.code === "TG")!;
    expect(tg(base).weight).toBe(2);
    expect(tg(r).weight).toBe(6);
    expect(tg(r).weightedPenalty).toBeCloseTo(tg(base).weightedPenalty * 3, 3);
    expect(r.maxPossibleWeightedPenalty).toBe(base.maxPossibleWeightedPenalty + 4);
    expect(r.longevityScore).toBeLessThan(base.longevityScore);
  });

  it("coverage: the two minimums and the domain lists", () => {
    const three = panel(["APOB", "HBA1C", "HSCRP"]);
    expect(score(three).longevityScore).toBe(-1);
    const loose = specWith((s) => { s.coverage.min_markers = 3; s.coverage.min_domains = 3; });
    expect(score(three, loose)).toMatchObject({ longevityScore: 100, validation: { valid: true, totalMarkers: 3, domainsCovered: 3, domainsRequired: 3 } });
    const strict = specWith((s) => { s.coverage.min_markers = 11; });
    expect(score(inputs, strict).validation).toMatchObject({ valid: false, errorMessage: "Need 11+ markers, got 10." });
    const allFive = specWith((s) => { s.coverage.min_domains = 5; s.coverage.domains.inflammation.markers = ["WBC"]; });
    expect(score(inputs, allFive).validation).toMatchObject({ valid: false, domainsCovered: 4, missingDomains: ["inflammation"], errorMessage: "Need 5/5 domains, got 4." });
    // Vitamin D covers no domain on the file's lists; a list that names it would let it cover one.
    const noBloodCount = panel(TEN.filter((c) => c !== "HGB"));
    expect(score(noBloodCount).validation.missingDomains).toEqual(["blood_count"]);
    const vitD = specWith((s) => { s.coverage.domains.blood_count.markers = ["VITD"]; });
    expect(score(noBloodCount, vitD).validation.missingDomains).toEqual([]);
  });

  it("grades: the labels and cut-offs, and the cap read from them", () => {
    const optimal = panel(TEN);
    expect(score(optimal)).toMatchObject({ longevityScore: 100, lsGrade: "Elite" });
    const spec = specWith((s) => {
      s.grades = [{ min: 98, label: "Top" }, { min: 60, label: "Middle" }, { min: 1, label: "Low" }];
      s.caps.out_of_range.grade = "Middle";
    });
    expect(score(optimal, spec)).toMatchObject({ longevityScore: 100, lsGrade: "Top" });
    expect(OUT_OF_RANGE_CAP).toEqual({ level: 94, grade: "Excellent" });
    // One marker just out of range, light beside the others: the values give more than either cap allows.
    const light = (s: ScoreSpec) => { marker(s, "TG").weight = 0.25; };
    const oneOut = panel(TEN, { TG: rowOf("TG").normal_high! * 1.01 });
    const onFile = score(oneOut, specWith(light));
    expect(onFile).toMatchObject({ longevityScore: 94, lsGrade: "Excellent", cap: { level: 94, grade: "Excellent", markers: ["TG"] } });
    expect(onFile.cap!.uncappedScore).toBeGreaterThan(94);
    // The same values on another table: the same uncapped score, held at the top of "Middle", one below "Top".
    const lower = specWith((s) => {
      light(s);
      s.grades = [{ min: 90, label: "Top" }, { min: 60, label: "Middle" }, { min: 1, label: "Low" }];
      s.caps.out_of_range.grade = "Middle";
    });
    expect(score(oneOut, lower)).toMatchObject({
      longevityScore: 89, lsGrade: "Middle",
      cap: { level: 89, grade: "Middle", uncappedScore: onFile.cap!.uncappedScore, markers: ["TG"] },
    });
    // A cap that names the top grade, or no grade of the table, is refused.
    expect(() => score(optimal, specWith((s) => { s.caps.out_of_range.grade = "Elite"; }))).toThrow(/cap/);
    expect(() => score(optimal, specWith((s) => { s.caps.out_of_range.grade = "No such grade"; }))).toThrow(/cap/);
  });

  it("curves: the score curve and the penalty curve", () => {
    const ratio = base.netPenaltyRatio;
    expect(ratio).toBeGreaterThan(0);
    expect(base.cap).toBeNull(); // below the cap already: the score is the curve's
    expect(base.longevityScore).toBe(Math.round(100 * Math.exp(-3 * ratio)));
    const steep = specWith((s) => { s.score_curve.k = 12; });
    expect(score(inputs, steep).longevityScore).toBe(Math.round(100 * Math.exp(-12 * ratio)));
    const floor = specWith((s) => { s.score_curve.k = 500; s.score_curve.floor = 7; s.grades[s.grades.length - 1].min = 7; });
    expect(score(inputs, floor).longevityScore).toBe(7);

    // The penalty at the reference limit, and the width of a side with no band.
    const row: ReviewedRange = { optimal_low: null, optimal_high: 100, normal_low: null, normal_high: 150 };
    expect(reviewedPenalty(150, row)).toBeCloseTo(0.4, 10);
    expect(reviewedPenalty(125, row)).toBeCloseTo(0.1, 10);
    const curve = { max: 1, at_reference_limit: 0.2, in_range_exponent: 1, no_band_width: 0.5 };
    expect(reviewedPenalty(150, row, curve)).toBeCloseTo(0.2, 10);
    expect(reviewedPenalty(125, row, curve)).toBeCloseTo(0.1, 10);
    const noBand: ReviewedRange = { optimal_low: null, optimal_high: 100, normal_low: null, normal_high: 100 };
    expect(reviewedPenalty(110, noBand)).toBeCloseTo(0.4 + 0.6 * (10 / 25), 10);
    expect(reviewedPenalty(110, noBand, curve)).toBeCloseTo(0.2 + 0.8 * (10 / 50), 10);
    // The engine charges with the curve of the specification it is given.
    const tgPenalty = (x: FullResult) => x.markerScores.find((m) => m.code === "TG")!.rawPenalty;
    const flat = specWith((s) => { s.penalty_curve = curve; });
    expect(tgPenalty(score(inputs, flat))).toBeCloseTo(reviewedPenalty(aboveReference("TG"), rowOf("TG"), curve), 4);
    expect(tgPenalty(score(inputs, flat))).not.toBeCloseTo(tgPenalty(base), 2);
  });

  it("confidence: the levels and their minimums of covered domains", () => {
    expect(base.confidence).toBe("high"); // five domains
    expect(score(inputs, specWith((s) => { s.confidence.levels[0].min_domains = 6; })).confidence).toBe("moderate");
    expect(score(inputs, specWith((s) => { s.confidence.levels = []; })).confidence).toBe("low");
    // Under the coverage rule there is no score and the file's word for it.
    expect(score(panel(["APOB", "HBA1C"])).confidence).toBe("insufficient");
    expect(score(panel(["APOB", "HBA1C"]), specWith((s) => { s.confidence.below_coverage = "low"; })).confidence).toBe("low");
  });
});
