/**
 * Serum creatinine outside its extreme physiological range is a unit or extraction error, not a result: 88.4 is a
 * µmol/L value stored as mg/dL. Both biological age versions read creatinine and require it, so such a value gives
 * no biological age rather than a wrong one (biological-age-kdm.ts,
 * applyLifestyleAdjustments; biological-age-v3-adapter.ts, reason "implausible_value").
 */
import bounds from "./data/plausibility_bounds.json";

/** Stored keys whose value is serum creatinine in mg/dL (kdm-adapter maps both to "Creatinina"). */
export const CREATININE_KEYS: ReadonlySet<string> = new Set(["creatinine", "CREATININE"]);

/** The range, mg/dL (plausibility_bounds.json, "Creatinina": Tietz 8e). These are not reference ranges. */
export const CREATININE_PLAUSIBLE_MG_DL: { readonly lower: number; readonly upper: number } = {
  lower: bounds.markers["Creatinina"].lower,
  upper: bounds.markers["Creatinina"].upper,
};

/** True when a creatinine in mg/dL is within CREATININE_PLAUSIBLE_MG_DL, both ends included. */
export function isPlausibleCreatinineMgDl(value: number): boolean {
  return Number.isFinite(value) && value >= CREATININE_PLAUSIBLE_MG_DL.lower && value <= CREATININE_PLAUSIBLE_MG_DL.upper;
}

/**
 * Two creatinine values (mg/dL) this close are the same result listed twice, including one result printed in both
 * mg/dL and µmol/L: the µmol/L line is stored as value × 0.0113 (unit-conversions.ts), so the two rows differ by the
 * rounding of each print (up to 0.05 mg/dL for a one-decimal print, and half a µmol/L, about 0.0057 mg/dL) and by that
 * factor's distance from 1/88.4 (0.11%). The bound covers every such pair from 0.2 to 15 mg/dL, with mg/dL printed to
 * one, two or three decimals; values this close are within a laboratory's own measurement variation, and the figure
 * reads the last row. It still tells 1.0 from 1.06, or 0.9 from 1.1.
 */
const SAME_CREATININE_MG_DL = 0.057;
const SAME_CREATININE_RELATIVE = 0.0011;

/**
 * Whether one lab's creatinine values (mg/dL) can be read: every one plausible, and all the same result. A lab can
 * hold more than one creatinine row (an uploaded report listing it twice). An implausible value, or two that
 * disagree, may be the one a figure would read (a misread µmol/L value next to a urine creatinine filed as serum, say),
 * so the lab then gives no creatinine, and no biological age, rather than a wrong one. True for no values. The order
 * of the values does not matter.
 */
export function labCreatinineReadable(valuesMgDl: readonly number[]): boolean {
  if (!valuesMgDl.every(isPlausibleCreatinineMgDl)) return false;
  if (valuesMgDl.length < 2) return true;
  const highest = Math.max(...valuesMgDl);
  return highest - Math.min(...valuesMgDl) <= SAME_CREATININE_MG_DL + SAME_CREATININE_RELATIVE * highest + 1e-9;
}
