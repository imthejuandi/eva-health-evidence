/**
 * The one way biomarker rows become Longevity Score engine inputs.
 *
 * Two rules the 2026-09-21 audit found broken in two places at once:
 *   1. Engine codes come from DB_KEY_TO_ENGINE_CODE — never from a guess.
 *   2. Ratios the engine scores (NLR, HOMA-IR) are COMPUTED from their
 *      components by calculated-metrics, never taken from a raw row. The
 *      neutrophil percentage used to be pushed as "NLR" (a 60 % read as a
 *      ratio of 60 → critical on every hemogram); HOMA-IR never reached the
 *      engine at all.
 *
 * Values are in eva's canonical units (Echevarne's, since 2026-09-17) and the
 * engine registry is kept in the same units — longevity-score.test.ts asserts
 * that for every mapped key.
 */
import { DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
import { calculateAllMetrics } from "./calculated-metrics";
import type { BiomarkerInput } from "./longevity-score";

// The eGFR the app computes (`egfr_computed`) is deliberately absent: under ruling D-06 it becomes the engine's
// EGFR input only once the reviewed eGFR rows stop saying it does not count toward the score. Until then no eGFR
// reaches the score: the laboratory's own is never an input (name-matcher.ts DB_KEY_TO_ENGINE_CODE has no eGFR
// key), and the metrics below are computed without a person, so no eGFR is computed here at all.
//
// Non-HDL cholesterol is computed from total and HDL cholesterol when the lab did not report it; a stored value
// wins (ruling D-06). The specification decides which codes score: one it does not know is ignored by the engine.
const METRIC_TO_ENGINE_CODE: Record<string, string> = {
  nlr: "NLR",
  homa_ir: "HOMA_IR",
  non_hdl: "NON_HDL",
};

/**
 * `valueOnly` marks a result the app shows without a category (zone "unclassified"): it is not a score input
 * itself, and its code is not filled from a ratio either, but it still feeds the ratios computed from it (the
 * neutrophil and lymphocyte percentages carry no category and give the NLR, which is scored on its own row).
 * A value-only row does not take its code from a classified row stored under another key of the same code.
 */
export function buildEngineInputs(
  rows: ReadonlyArray<{ biomarkerKey: string; value: number; valueOnly?: boolean }>,
): BiomarkerInput[] {
  const inputs: BiomarkerInput[] = [];
  const seen = new Set<string>();
  const valueOnly = new Set<string>();
  for (const r of rows) {
    if (!Number.isFinite(r.value)) continue;
    const code = DB_KEY_TO_ENGINE_CODE[r.biomarkerKey];
    if (!code) continue;
    if (r.valueOnly) {
      valueOnly.add(code);
      continue;
    }
    if (seen.has(code)) continue;
    seen.add(code);
    inputs.push({ code, value: r.value });
  }
  // Only the metric values are read here; the score classifies them itself.
  const metrics = calculateAllMetrics(
    rows.filter((r) => Number.isFinite(r.value)).map((r) => ({ biomarker_key: r.biomarkerKey, value: r.value })),
  );
  for (const m of metrics) {
    const code = METRIC_TO_ENGINE_CODE[m.metricKey];
    if (!code || seen.has(code) || valueOnly.has(code)) continue;
    seen.add(code);
    inputs.push({ code, value: m.value });
  }
  return inputs;
}
