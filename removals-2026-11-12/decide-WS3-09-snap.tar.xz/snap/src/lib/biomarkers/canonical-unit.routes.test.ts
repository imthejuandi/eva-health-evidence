/**
 * The upload preview (POST /api/lab-results/extract) applies the canonical-unit gate that processing applies
 * (processLabResults, process-results.ts). A value that convertBiomarker cannot bring to the seed's unit is refused
 * at processing as unit_mismatch, so the preview shows it as reported, with no category and no plausibility flag:
 * both would compare it with a range written in another unit. Lp(a) in nmol/L is the common case: no fixed factor
 * links it to mg/dL (check D4), and family f07's rule shows such a result "as a value with no category".
 *
 * Both paths run for real on a scripted database (fake-supabase) and a scripted extraction model, on the seed's
 * reviewed rows. Each preview row is then confirmed as the upload client sends it (its value, unit and matched key),
 * so the tests compare what the review step shows with what processing stores.
 */
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { classifyZone } from "./zone-classifier";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

const state = vi.hoisted(() => ({ client: null as unknown, modelText: "" }));

vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.client }));

// processLabResults upserts the biological age v3 shadow record with the service-role client: a scripted one here,
// so the test never reaches a real database.
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});
vi.mock("@/lib/ai/prompts", () => ({ getPrompt: async () => ({ model: "test", content: "extract" }) }));
vi.mock("@google/genai", () => ({
  GoogleGenAI: class {
    models = { generateContent: async () => ({ candidates: [{ finishReason: "STOP" }], text: state.modelText }) };
  },
  Type: { OBJECT: "OBJECT", ARRAY: "ARRAY", STRING: "STRING", NUMBER: "NUMBER" },
}));

import { POST as extract } from "@/app/api/lab-results/extract/route";
import { processLabResults } from "./process-results";

const ROWS = reviewedRows();
const SEX = "male";
const AGE = 45;

type Reported = { name: string; value: number; unit: string };
type PreviewRow = {
  name: string;
  value: number;
  unit: string;
  matchedKey: string | null;
  zone: string | null;
  zoneLabel: string | null;
  zoneColor: string | null;
  implausible: boolean;
};

function database(onInsert: (rows: Array<Record<string, unknown>>) => void = () => {}) {
  const dob = `${new Date().getFullYear() - AGE}-01-01`;
  const respond = (c: FakeCall): FakeResponse => {
    if (c.table === "profiles" && ops(c).startsWith("select")) {
      return { data: { date_of_birth: dob, sex: SEX, subscription_status: "active", total_uploads_used: 0, locale: "en" } };
    }
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-1" } };
    if (c.table === "biomarker_values" && ops(c).startsWith("insert")) onInsert(argsOf(c, "insert")?.[0] as Array<Record<string, unknown>>);
    return { data: null };
  };
  const { client } = fakeSupabase(respond);
  return Object.assign(client, {
    auth: { getUser: async () => ({ data: { user: { id: "u1" } } }) },
    storage: { from: () => ({ upload: async () => ({ error: null }) }) },
  });
}

/** The review rows the upload preview returns for a report the extraction model reads as `reported`. */
async function preview(reported: Reported[]): Promise<PreviewRow[]> {
  state.client = database();
  state.modelText = JSON.stringify({ collection_date: null, biomarkers: reported });
  const form = new FormData();
  form.append("files", new File([new Uint8Array([37, 80, 68, 70])], "lab.pdf", { type: "application/pdf" }));
  const res = await extract(new NextRequest("http://localhost/api/lab-results/extract", { method: "POST", body: form }));
  expect(res.status).toBe(200);
  return ((await res.json()) as { extractedBiomarkers: PreviewRow[] }).extractedBiomarkers;
}

/** Processing of one preview row, confirmed as the upload client sends it: its value, unit and matched key. */
async function confirm(row: PreviewRow) {
  let stored: Array<Record<string, unknown>> = [];
  const client = database((rows) => (stored = rows));
  const result = await processLabResults(
    "u1",
    "lab-1",
    [{ name: row.name, value: row.value, unit: row.unit, biomarkerKey: row.matchedKey!, matchConfidence: "exact" }],
    client,
  );
  return { unmatched: result.unmatched, stored };
}

/** The seed row the preview and processing classify an Lp(a) against (one row for every adult). */
const LPA = ROWS.find((r) => r.biomarker_key === "lipoproteina" && (r.sex === SEX || r.sex === "both"))!;

describe("the upload preview applies processing's canonical-unit gate (check D4)", () => {
  beforeAll(() => {
    vi.stubEnv("GEMINI_API_KEY", "test");
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
  });
  afterAll(() => {
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  it("an Lp(a) in nmol/L previews as reported, with no category and no plausibility flag", async () => {
    expect(LPA.unit_en).toBe("mg/dL");
    for (const value of [40, 75, 200, 600]) {
      const [row] = await preview([{ name: "Lipoproteína (a)", value, unit: "nmol/L" }]);
      // Still recognised as Lp(a), so the client sees which marker it is.
      expect(row).toMatchObject({ matchedKey: "lipoproteina", value, unit: "nmol/L" });
      expect(row).toMatchObject({ zone: null, zoneLabel: null, zoneColor: null, implausible: false });
    }
  });

  it("an Lp(a) in µg/mL, the same mass on another scale, is still converted ÷10 and classified in mg/dL", async () => {
    const [row] = await preview([{ name: "Lipoproteína (a)", value: 300, unit: "µg/mL" }]);
    expect(row.matchedKey).toBe("lipoproteina");
    expect(row.value).toBeCloseTo(30, 6);
    expect(row.unit).toBe("mg/dL");
    expect(row.zone).toBe(classifyZone(30, LPA.optimal_low, LPA.optimal_high, LPA.normal_low, LPA.normal_high));
    expect(row.zoneLabel).not.toBeNull();
  });

  // Each report row is previewed, then confirmed as the client sends it. The preview leaves a recognised row without a
  // category exactly when processing refuses it as unit_mismatch, and otherwise shows the value, unit and category
  // processing stores.
  const cases: Array<[Reported, "refused" | "stored"]> = [
    [{ name: "Lipoproteína (a)", value: 75, unit: "nmol/L" }, "refused"],
    [{ name: "Lp(a)", value: 600, unit: "nmol/L" }, "refused"],
    // EVA has no molar factor for ferritin: a second marker, so the gate is not an Lp(a) special case.
    [{ name: "Ferritina", value: 674, unit: "pmol/L" }, "refused"],
    [{ name: "Lipoproteína (a)", value: 300, unit: "µg/mL" }, "stored"],
    [{ name: "Lipoproteína (a)", value: 40, unit: "mg/dL" }, "stored"],
    // A lab that prints no unit: processing stores the seed's unit, and the gate lets it through on both paths.
    [{ name: "Lipoproteína (a)", value: 20, unit: "" }, "stored"],
    [{ name: "Apolipoproteína B", value: 0.9, unit: "g/L" }, "stored"],
  ];

  it.each(cases)("%o: the preview shows what processing does with it (%s)", async (reported, outcome) => {
    const [row] = await preview([reported]);
    expect(row.matchedKey).not.toBeNull();
    const { unmatched, stored } = await confirm(row);
    if (outcome === "refused") {
      expect(unmatched).toEqual([expect.objectContaining({ name: reported.name, reason: "unit_mismatch" })]);
      expect(stored).toEqual([]);
      expect(row).toMatchObject({ value: reported.value, unit: reported.unit });
      expect(row).toMatchObject({ zone: null, zoneLabel: null, zoneColor: null, implausible: false });
    } else {
      expect(unmatched).toEqual([]);
      expect(stored).toHaveLength(1);
      expect(row.zone).not.toBeNull();
      expect(row.zone).toBe(stored[0].zone);
      expect(row.value).toBeCloseTo(stored[0].value as number, 9);
      if (reported.unit) expect(row.unit).toBe(stored[0].unit);
    }
  });
});
