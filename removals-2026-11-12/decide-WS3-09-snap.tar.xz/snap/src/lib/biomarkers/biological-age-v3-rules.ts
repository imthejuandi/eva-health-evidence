/**
 * Biological age version 3: the refusal and gating rules. Whether the frozen model's figure may be given at all for
 * one lab result, and whether a figure given is provisional. These rules never change the model (its coefficients,
 * transforms and clamps live in ./data/ba_v3_model.json and ./biological-age-v3.ts, frozen): they only decide whether
 * its number is given.
 *
 * Every number here comes from ./data/ba_v3_rules.json, where each value carries its unit, reason code, source and
 * `pending_physician_confirmation: true`. Nothing clinical is written in this file: change the JSON, not the code.
 *
 * The rules, in the order the reasons are listed (ba_v3_rules.json meta.evaluation_order). Every rule that holds is
 * listed; any of them refuses the figure; the first is the record's `reason`.
 *   pregnancy, lactation          declared in the patient context (condition keys pregnancy_current, lactating)
 *   sex_unknown                   sex other than male or female (any letter case); no default
 *   age_unknown                   no age in completed years at the draw
 *   age_outside_signed_range      age outside min_age to max_age (20 to 79; 84 only if acceptance check B5 passes)
 *   collection_method             anything but a venous draw analysed at EVA's laboratory; an unknown method counts as
 *                                 not venous until the app records it
 *   implausible_value             a marker outside its extreme physiological range (inclusive bounds)
 *   kidney                        creatinine (measured, before the creatine divisor) above the upper reference limit
 *                                 of the person's creatinine row, or chronic kidney disease declared
 *   albumin_low                   albumin below 30 g/L
 *   crp_above_limit               hs-CRP above 50 mg/L (above 10 mg/L the figure is provisional)
 *   alp_above_limit, ggt_above_limit   above the stated multiple of the upper reference limit of the person's row
 *
 * Bounded results ("<5", ">8"): the value is the bound itself, never half of it. A '<' bound at a lower limit counts
 * as below that limit and a '>' bound at an upper limit counts as above it. Plausibility judges the bound itself (a
 * detection-limit result such as hs-CRP "<0.05" is a real result, not an error).
 *
 * Markers are judged only in the unit the rule is written in (the EVA unit the model reads). A marker in any other
 * unit is left to the model, which refuses it (`unit_mismatch`); a value that is not a number is left to the model
 * too (`invalid_value`).
 *
 * Pure: no I/O, no clock, no randomness; the input is not modified.
 */
import RULES_JSON from "./data/ba_v3_rules.json";
import { normalizeUnit } from "./canonical-units";

// ─── Types ───

/** The reason codes these rules give. */
export type BioAgeV3RuleCode =
  | "pregnancy"
  | "lactation"
  | "sex_unknown"
  | "age_unknown"
  | "age_outside_signed_range"
  | "collection_method"
  | "implausible_value"
  | "kidney"
  | "albumin_low"
  | "crp_above_limit"
  | "alp_above_limit"
  | "ggt_above_limit";

/** One marker value as the rules read it: the measured value in the rule's unit, the bound resolved. */
export interface BioAgeV3RuleMarker {
  /** EVA key: albumin, alp, hs_crp, creatinine, bun, ggt, hba1c. */
  key: string;
  /** The measured value (a bound "<5" is 5). Creatinine before the creatine divisor. */
  value: number;
  unit: string;
  /** "<" or ">" when the laboratory reported a bound; `value` is then the bound. */
  comparator?: "<" | ">" | null;
  /** The upper reference limit stored with the person's row (biomarker_values.normal_high), in the row's unit. */
  normal_high?: number | null;
}

export interface BioAgeV3RuleContext {
  /** patient_context_versions.conditions.keys. */
  conditions: readonly string[];
  /** Pregnancy declared other than by a condition key; the keys in ba_v3_rules.json count too. */
  pregnant?: boolean;
  /** Lactation declared other than by a condition key; the keys in ba_v3_rules.json count too. */
  lactating?: boolean;
}

export interface BioAgeV3RuleCollection {
  /** How the sample was collected ("venous", "capillary"); null or absent when not recorded. */
  method: string | null | undefined;
  /** The result was analysed at EVA's laboratory (biological-age-v3-adapter laboratoryOf). */
  fromEvaLaboratory: boolean;
}

export interface BioAgeV3RuleInput {
  /** The values the model will read (and creatinine as measured), with their bounds and the rows' upper limits. */
  markers: readonly BioAgeV3RuleMarker[];
  sex: string | null | undefined;
  /** Completed years at the draw; NaN when unknown. */
  age: number;
  context: BioAgeV3RuleContext;
  collection: BioAgeV3RuleCollection;
}

export interface BioAgeV3RuleReason {
  code: BioAgeV3RuleCode;
  /** The EVA key behind the reason, for a marker rule. */
  marker?: string;
  /** What was found and the limit it broke, in plain words. */
  detail: string;
}

export interface BioAgeV3RuleOutcome {
  /** No rule refuses the figure. */
  eligible: boolean;
  /** Every refusal that holds, in the evaluation order. Empty when eligible. */
  reasons: BioAgeV3RuleReason[];
  /** hs-CRP above the provisional limit: a figure given is provisional (retest suggested). */
  provisional: boolean;
  /** The collection method as read: "venous", "capillary", ... or "unknown". */
  collection_method: string;
}

// ─── The configuration ───

interface Bounds {
  lower: number;
  upper: number;
  unit: string;
}
interface SexLimits {
  male: number;
  female: number;
  unit: string;
}
interface RulesConfig {
  meta: { version: string };
  plausibility: { markers: Record<string, Bounds> };
  kidney: {
    creatinine_above_reference_upper_limit: { unit: string; fallback_upper_limit_when_the_row_has_none: SexLimits };
    declared_kidney_disease: { condition_keys: string[] };
  };
  albumin_low: { value: number; unit: string };
  hs_crp: { provisional_above: { value: number; unit: string }; refuse_above: { value: number; unit: string } };
  liver_enzymes: {
    multiple_of_upper_reference_limit: number;
    alp: { unit: string; fallback_upper_limit_when_the_row_has_none: SexLimits };
    ggt: { unit: string; fallback_upper_limit_when_the_row_has_none: SexLimits };
  };
  states: { pregnancy: { condition_keys: string[] }; lactation: { condition_keys: string[] } };
  age: { min_age: number; max_age: number };
  sex: { accepted: string[] };
  collection_method: { accepted: { method: string; laboratory: string }[] };
}

/** The rules as configured (ba_v3_rules.json). */
export const BA_V3_RULES: Readonly<RulesConfig> = RULES_JSON as unknown as RulesConfig;

/** Version of the rules file, stored in every record. */
export const BA_V3_RULES_VERSION: string = BA_V3_RULES.meta.version;

/** The signed age range, completed years, both ends included. */
export const BA_V3_SIGNED_AGE_RANGE: Readonly<{ min: number; max: number }> = Object.freeze({
  min: BA_V3_RULES.age.min_age,
  max: BA_V3_RULES.age.max_age,
});

/** The order reasons are listed in (and the first is the record's `reason`). */
export const BA_V3_RULE_ORDER: readonly BioAgeV3RuleCode[] = [
  "pregnancy",
  "lactation",
  "sex_unknown",
  "age_unknown",
  "age_outside_signed_range",
  "collection_method",
  "implausible_value",
  "kidney",
  "albumin_low",
  "crp_above_limit",
  "alp_above_limit",
  "ggt_above_limit",
];

/** Collection method recorded when none is known. */
export const UNKNOWN_COLLECTION_METHOD = "unknown";

// ─── Comparisons ───

/** Above `limit`; a '>' bound at the limit is above it. */
function above(m: BioAgeV3RuleMarker, limit: number): boolean {
  return m.comparator === ">" ? m.value >= limit : m.value > limit;
}

/** Below `limit`; a '<' bound at the limit is below it. */
function below(m: BioAgeV3RuleMarker, limit: number): boolean {
  return m.comparator === "<" ? m.value <= limit : m.value < limit;
}

function fmt(m: BioAgeV3RuleMarker): string {
  return `${m.comparator ?? ""}${m.value} ${m.unit}`;
}

/** The markers of `key` the rules can judge: a finite value in the rule's unit. */
function judged(markers: readonly BioAgeV3RuleMarker[], key: string, unit: string): BioAgeV3RuleMarker[] {
  return markers.filter(
    (m) => m.key === key && Number.isFinite(m.value) && normalizeUnit(m.unit) === normalizeUnit(unit),
  );
}

function resolvedSex(sex: unknown): "male" | "female" | null {
  if (typeof sex !== "string") return null;
  const s = sex.toLowerCase();
  return BA_V3_RULES.sex.accepted.includes(s) && (s === "male" || s === "female") ? s : null;
}

/**
 * The upper reference limit for a marker: the one stored with the person's row when it is a positive number, else the
 * configured fallback for their sex; null when neither is known.
 */
function upperLimit(m: BioAgeV3RuleMarker, fallback: SexLimits, sex: "male" | "female" | null): { limit: number; from: string } | null {
  const own = typeof m.normal_high === "number" ? m.normal_high : NaN;
  if (Number.isFinite(own) && own > 0) return { limit: own, from: "the person's reference row" };
  if (sex === null) return null;
  return { limit: fallback[sex], from: `the ${sex} fallback limit` };
}

/** Normalised collection method: lower case, trimmed; "unknown" when absent or empty. */
export function collectionMethodOf(method: unknown): string {
  if (typeof method !== "string" || method.trim() === "") return UNKNOWN_COLLECTION_METHOD;
  return method.trim().toLowerCase();
}

// ─── The rules ───

/** Whether version 3's figure may be given, why not, and whether it is provisional. Pure. */
export function evaluateBioAgeV3Rules(input: BioAgeV3RuleInput): BioAgeV3RuleOutcome {
  const R = BA_V3_RULES;
  const found: BioAgeV3RuleReason[] = [];
  const conditions = new Set(input.context.conditions);
  const sex = resolvedSex(input.sex);
  const markers = input.markers;

  // States.
  if (input.context.pregnant === true || R.states.pregnancy.condition_keys.some((k) => conditions.has(k))) {
    found.push({ code: "pregnancy", detail: "pregnancy declared in the patient context" });
  }
  if (input.context.lactating === true || R.states.lactation.condition_keys.some((k) => conditions.has(k))) {
    found.push({ code: "lactation", detail: "lactation declared in the patient context" });
  }

  // Sex and age.
  if (sex === null) found.push({ code: "sex_unknown", detail: `sex ${JSON.stringify(input.sex ?? null)} is not male or female` });
  if (typeof input.age !== "number" || !Number.isFinite(input.age)) {
    found.push({ code: "age_unknown", detail: "no age at the draw (date of birth missing or unreadable)" });
  } else if (input.age < R.age.min_age || input.age > R.age.max_age) {
    found.push({
      code: "age_outside_signed_range",
      detail: `age ${input.age} outside the signed range ${R.age.min_age} to ${R.age.max_age}`,
    });
  }

  // Collection method.
  const method = collectionMethodOf(input.collection.method);
  const accepted = R.collection_method.accepted.some(
    (a) => a.method === method && (a.laboratory !== "eva" || input.collection.fromEvaLaboratory),
  );
  if (!accepted) {
    found.push({
      code: "collection_method",
      detail: `collection method ${method}${input.collection.fromEvaLaboratory ? "" : ", not analysed at EVA's laboratory"}; only a venous draw analysed at EVA's laboratory is accepted`,
    });
  }

  // Plausibility: the bound itself is judged, inclusive bounds.
  for (const [key, b] of Object.entries(R.plausibility.markers)) {
    for (const m of judged(markers, key, b.unit)) {
      if (m.value < b.lower || m.value > b.upper) {
        found.push({ code: "implausible_value", marker: key, detail: `${key} ${fmt(m)} outside ${b.lower} to ${b.upper} ${b.unit}` });
      }
    }
  }

  // Kidney: measured creatinine above the upper reference limit, or declared kidney disease.
  const kidney = R.kidney.creatinine_above_reference_upper_limit;
  const plausibleCreatinine = R.plausibility.markers.creatinine;
  for (const m of judged(markers, "creatinine", kidney.unit)) {
    if (m.value < plausibleCreatinine.lower || m.value > plausibleCreatinine.upper) continue; // implausible already
    const u = upperLimit(m, kidney.fallback_upper_limit_when_the_row_has_none, sex);
    if (u !== null && above(m, u.limit)) {
      found.push({ code: "kidney", marker: "creatinine", detail: `creatinine ${fmt(m)} above the upper reference limit ${u.limit} ${kidney.unit} (${u.from})` });
    }
  }
  const ckd = R.kidney.declared_kidney_disease.condition_keys.filter((k) => conditions.has(k));
  if (ckd.length > 0) found.push({ code: "kidney", detail: `kidney disease declared in the patient context (${ckd.join(", ")})` });

  // Albumin below the limit.
  for (const m of judged(markers, "albumin", R.albumin_low.unit)) {
    if (below(m, R.albumin_low.value)) {
      found.push({ code: "albumin_low", marker: "albumin", detail: `albumin ${fmt(m)} below ${R.albumin_low.value} ${R.albumin_low.unit}` });
    }
  }

  // hs-CRP: provisional above one limit, refused above the other.
  let provisional = false;
  const crp = R.hs_crp;
  for (const m of judged(markers, "hs_crp", crp.refuse_above.unit)) {
    if (above(m, crp.refuse_above.value)) {
      found.push({ code: "crp_above_limit", marker: "hs_crp", detail: `hs-CRP ${fmt(m)} above ${crp.refuse_above.value} ${crp.refuse_above.unit}` });
    }
  }
  for (const m of judged(markers, "hs_crp", crp.provisional_above.unit)) {
    if (above(m, crp.provisional_above.value)) provisional = true;
  }

  // ALP and GGT above the multiple of the upper reference limit.
  const L = R.liver_enzymes;
  for (const [key, code] of [["alp", "alp_above_limit"], ["ggt", "ggt_above_limit"]] as const) {
    const spec = L[key];
    for (const m of judged(markers, key, spec.unit)) {
      const u = upperLimit(m, spec.fallback_upper_limit_when_the_row_has_none, sex);
      if (u === null) continue;
      const limit = L.multiple_of_upper_reference_limit * u.limit;
      if (above(m, limit)) {
        found.push({
          code,
          marker: key,
          detail: `${key} ${fmt(m)} above ${L.multiple_of_upper_reference_limit} x the upper reference limit ${u.limit} ${spec.unit} (${u.from}) = ${limit} ${spec.unit}`,
        });
      }
    }
  }

  const reasons = BA_V3_RULE_ORDER.flatMap((code) => found.filter((r) => r.code === code));
  return { eligible: reasons.length === 0, reasons, provisional, collection_method: method };
}
