/**
 * The upload preview (POST /api/lab-results/extract) and processing (processLabResults) classify against the
 * same reference row, for every live age label, at representative ages, for both sexes.
 *
 * Both paths run for real on a scripted database (fake-supabase) and a scripted extraction model. Every row
 * carries its own name and its own reference ceiling, so the name the preview shows and the ceiling
 * processing stores say which row each path read.
 *
 * A result the report prints as a bound ("<5") keeps its sign in the preview, which places it as processing
 * does (bounded-result.ts classifyResultZone), on the seed's rows.
 */
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { getCanonicalUnit } from "./canonical-units";
import { LIVE_SETS } from "./__tests__/fixtures/live-age-groups";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

const state = vi.hoisted(() => ({ client: null as unknown, modelText: "" }));

vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.client }));

// processLabResults upserts the biological age v3 shadow record with the service-role client: a scripted one here,
// so the test never reaches a real database (process-results.bio-age-v3.test.ts covers that write).
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});
vi.mock("@/lib/ai/prompts", () => ({ getPrompt: async () => ({ model: "test", content: "extract" }) }));
vi.mock("@google/genai", () => ({
  GoogleGenAI: class {
    models = { generateContent: async () => ({ candidates: [{ finishReason: "STOP" }], text: state.modelText }) };
  },
  Type: { OBJECT: "OBJECT", ARRAY: "ARRAY", STRING: "STRING", NUMBER: "NUMBER" },
}));

import { POST as extract } from "@/app/api/lab-results/extract/route";
import { processLabResults } from "./process-results";
import { isLabReportedValueOnly } from "./lab-reported";

// The extraction name matcher does not know three live markers (progesterone, IGF-1, NT-proBNP), so markers
// it does know carry their rows here: every live label is still read by both paths.
const STAND_IN: Record<string, string> = {
  progesterone: "cortisol_morning_8am",
  igf_1_insulin_like_growth_factor_1: "leptin",
  nt_probnp: "homocysteine",
};

const ROWS = LIVE_SETS.flatMap(([key, sex, labels]) =>
  labels.map((age_group_en) => ({ biomarker_key: STAND_IN[key] ?? key, sex, age_group_en })),
).map((r, i) => ({
  ...r,
  name_en: `${r.biomarker_key} | ${r.sex} | ${r.age_group_en}`,
  name_es: `${r.biomarker_key} | ${r.sex} | ${r.age_group_en}`,
  normal_low: 0,
  normal_high: 1000 + i,
  optimal_low: null,
  optimal_high: null,
  panel_category: "test",
}));
const byName = new Map(ROWS.map((r) => [r.name_en, r]));
const byCeiling = new Map(ROWS.map((r) => [r.normal_high, r]));

function database(
  sex: string,
  age: number,
  onInsert: (rows: Array<{ biomarker_key: string; normal_high: number }>) => void,
  rows: ReadonlyArray<{ sex: string }> = ROWS,
) {
  const dob = `${new Date().getFullYear() - age}-01-01`;
  const respond = (c: FakeCall): FakeResponse => {
    if (c.table === "profiles" && ops(c).startsWith("select")) {
      return { data: { date_of_birth: dob, sex, subscription_status: "active", total_uploads_used: 0, locale: "en" } };
    }
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: rows.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "lab_results" && ops(c).startsWith("insert")) return { data: { id: "lab-1" } };
    if (c.table === "biomarker_values" && ops(c).startsWith("insert")) onInsert(argsOf(c, "insert")?.[0] as never);
    return { data: null };
  };
  const { client } = fakeSupabase(respond);
  return Object.assign(client, {
    auth: { getUser: async () => ({ data: { user: { id: "u1" } } }) },
    storage: { from: () => ({ upload: async () => ({ error: null }) }) },
  });
}

async function previewRows(sex: string, age: number, keys: string[]) {
  state.client = database(sex, age, () => {});
  state.modelText = JSON.stringify({ collection_date: null, biomarkers: keys.map((k) => ({ name: k, value: 1, unit: getCanonicalUnit(k) ?? "" })) });
  const form = new FormData();
  form.append("files", new File([new Uint8Array([37, 80, 68, 70])], "lab.pdf", { type: "application/pdf" }));
  const res = await extract(new NextRequest("http://localhost/api/lab-results/extract", { method: "POST", body: form }));
  expect(res.status).toBe(200);
  const body = (await res.json()) as { extractedBiomarkers: Array<{ matchedKey: string | null; matchedName: string | null }> };
  return new Map(body.extractedBiomarkers.map((b) => [b.matchedKey, byName.get(b.matchedName ?? "")]));
}

async function processedRows(sex: string, age: number, keys: string[]) {
  let inserted: Array<{ biomarker_key: string; normal_high: number }> = [];
  const client = database(sex, age, (rows) => (inserted = rows));
  const raw = keys.map((k) => ({ name: k, value: 1, unit: getCanonicalUnit(k) ?? "", biomarkerKey: k, matchConfidence: "exact" as const }));
  await processLabResults("u1", "lab-1", raw, client);
  return new Map(inserted.map((v) => [v.biomarker_key, byCeiling.get(v.normal_high)]));
}

const AGES = [18, 21, 22, 25, 26, 29, 30, 31, 35, 36, 39, 40, 41, 45, 46, 49, 50, 59, 60, 69, 70, 74, 75, 89, 90, 100];

describe("the upload preview reads the same row as processing", () => {
  beforeAll(() => {
    vi.stubEnv("GEMINI_API_KEY", "test");
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
  });
  afterAll(() => {
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  for (const sex of ["female", "male"]) {
    it(`${sex}, every live label, ages ${AGES[0]}–${AGES[AGES.length - 1]}`, async () => {
      const keys = [...new Set(ROWS.filter((r) => r.sex === sex || r.sex === "both").map((r) => r.biomarker_key))];
      const labelsRead = new Set<string>();
      for (const age of AGES) {
        const preview = await previewRows(sex, age, keys);
        const processed = await processedRows(sex, age, keys);
        for (const key of keys) {
          const row = processed.get(key);
          // A laboratory's own eGFR is stored with no interval (lab-reported.ts): there is no row to compare.
          if (isLabReportedValueOnly(key)) {
            expect(row, `${key}, ${sex} ${age}: stored with no interval`).toBeUndefined();
            continue;
          }
          expect(row, `${key}, ${sex} ${age}: processed`).toBeDefined();
          expect(preview.get(key), `${key}, ${sex} ${age}: preview`).toBe(row);
          labelsRead.add(row!.age_group_en);
        }
      }
      // Every label a person of this sex can read was read by both paths at some age.
      const reachable = new Set(ROWS.filter((r) => (r.sex === sex || r.sex === "both") && !isLabReportedValueOnly(r.biomarker_key) && !/luteal|ovulatory|Hormone Therapy/i.test(r.age_group_en)).map((r) => r.age_group_en));
      expect(labelsRead).toEqual(reachable);
    });
  }

  // ─── A printed bound (known issue C-06, decision CEO-15) ───

  // The outer describe sets the extraction key and quiets the logs for these tests too.
  describe("keeps a printed bound's sign and places it as processing does", () => {
    // The seed's rows: hs-CRP has no optimal floor, an optimal ceiling of 0.5 mg/L and a reference range of 0 to 3.
    const SEED = reviewedRows();
    type Previewed = { name: string; value: number; comparator: string | null; signToReview: string | null; matchedKey: string | null; zone: string | null };

    /** The preview of what the extraction model returned, as the review screen receives it. */
    async function preview(biomarkers: Array<Record<string, unknown>>): Promise<Previewed[]> {
      state.client = database("male", 45, () => {}, SEED);
      state.modelText = JSON.stringify({ collection_date: null, biomarkers });
      const form = new FormData();
      form.append("files", new File([new Uint8Array([37, 80, 68, 70])], "lab.pdf", { type: "application/pdf" }));
      const res = await extract(new NextRequest("http://localhost/api/lab-results/extract", { method: "POST", body: form }));
      expect(res.status).toBe(200);
      return ((await res.json()) as { extractedBiomarkers: Previewed[] }).extractedBiomarkers;
    }

    /** The zone processing stores for the same result, with the comparator the confirm route passes on. */
    async function stored(value: number, comparator?: "<" | ">") {
      let inserted: Array<{ biomarker_key: string; normal_high: number; zone?: string; comparator?: string | null }> = [];
      const client = database("male", 45, (rows) => (inserted = rows), SEED);
      await processLabResults("u1", "lab-1", [{ name: "hs-CRP", value, unit: "mg/L", biomarkerKey: "hs_crp", matchConfidence: "exact", ...(comparator ? { comparator } : {}) }], client);
      return inserted[0];
    }

    it('"<1.75" keeps its sign; the preview gives the zone processing stores, unclassified, never above optimal', async () => {
      const [bound, measured] = await preview([
        { name: "hs-CRP", value: 1.75, comparator: "<", unit: "mg/L" },
        { name: "hs-CRP", value: 1.75, comparator: null, unit: "mg/L" },
      ]);
      expect(bound).toMatchObject({ matchedKey: "hs_crp", value: 1.75, comparator: "<", signToReview: null, zone: "unclassified" });
      expect(await stored(1.75, "<")).toMatchObject({ comparator: "<", zone: bound.zone });
      // The same number without its sign is above optimal, in the preview and in processing.
      expect(measured).toMatchObject({ comparator: null, zone: "above_optimal" });
      expect(await stored(1.75)).toMatchObject({ comparator: null, zone: measured.zone });
    });

    it('a value the model returns as the printed text, "<0,2", is read with its sign as the bound 0.2', async () => {
      const [b] = await preview([{ name: "hs-CRP", value: "<0,2", unit: "mg/L" }]);
      expect(b).toMatchObject({ value: 0.2, comparator: "<", zone: "optimal" });
      expect(await stored(0.2, "<")).toMatchObject({ zone: b.zone });
    });

    it("a laboratory's own eGFR previews as a value with no category, as processing stores it (D-28)", async () => {
      const [lab, creatinine] = await preview([
        { name: "Filtrado glomerular estimado", value: 52, unit: "mL/min/1.73m²" },
        { name: "Creatinina", value: 1.0, unit: "mg/dL" },
      ]);
      expect(lab).toMatchObject({ matchedKey: "egfr_creatinine_based", value: 52, zone: "unclassified" });
      expect(creatinine).toMatchObject({ matchedKey: "creatinine", zone: "optimal" });
      let inserted: Array<{ biomarker_key: string; normal_high: number; zone?: string }> = [];
      const client = database("male", 45, (rows) => (inserted = rows), SEED);
      await processLabResults("u1", "lab-1", [{ name: "eGFR", value: 52, unit: "mL/min/1.73m²", biomarkerKey: "egfr_creatinine_based", matchConfidence: "exact" }], client);
      expect(inserted[0]).toMatchObject({ zone: lab.zone, normal_high: null });
    });

    it('"≤" and "≥" are returned with no sign to store, the printed sign, and no category: the result is set aside (D-24)', async () => {
      const [atMost, atLeast] = await preview([
        { name: "hs-CRP", value: 0.2, comparator: "≤", unit: "mg/L" },
        { name: "hs-CRP", value: "≥1,75", unit: "mg/L" },
      ]);
      // Not placed: the result is not stored under any sign, so the review shows no category for it.
      expect(atMost).toMatchObject({ value: 0.2, comparator: null, signToReview: "≤", zone: null, zoneLabel: null });
      expect(atLeast).toMatchObject({ value: 1.75, comparator: null, signToReview: "≥", zone: null, zoneLabel: null });
    });
  });
});
