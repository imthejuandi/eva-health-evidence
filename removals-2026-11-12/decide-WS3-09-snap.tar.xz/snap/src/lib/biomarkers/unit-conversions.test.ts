import { beforeAll, describe, it, expect, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { convertBiomarker } from "./unit-conversions";
import { remapToSeedKey } from "./key-aliases";
import { normalizeUnit, validateCanonicalUnit } from "./canonical-units";
import { processLabResults } from "./process-results";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

// The canonical-unit gate test runs processLabResults on a scripted client (fake-supabase): no module may reach a
// real database.
vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});

/**
 * CBC counts. Since 2026-09-17 the canonical unit is the RAW number of
 * cells per µL — Echevarne's convention and what its PDF shows the patient —
 * so partner results pass through untouched and the "thousands" (×10³/µL ≡
 * ×10⁹/L ≡ K/µL) and "millions" (×10⁶/µL, red cells) notations used by other
 * labs are multiplied back up. Pure decimal shifts, never a formula.
 */
describe("CBC counts: canonical is raw cells/µL (Echevarne, 2026-09-17)", () => {
  const cases: Array<[string, number, number]> = [
    ["lymphocytes_absolute", 2.34, 2340],
    ["monocytes_absolute", 0.5, 500],
    ["neutrophils_absolute", 4.2, 4200],
    ["eosinophils_absolute", 0.2, 200],
    ["basophils_absolute", 0.04, 40],
    ["white_blood_cell_count", 6.5, 6500],
    ["platelet_count", 250, 250000],
  ];

  it.each(cases)("scales %s from ×10³/µL up to raw cells/µL", (key, scaled, expected) => {
    const res = convertBiomarker(key, scaled, "x10³/µL");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(expected, 6);
    // Result must satisfy the canonical-unit gate so the row is stored.
    expect(validateCanonicalUnit(key, res.unit).ok).toBe(true);
  });

  it("accepts every thousands notation (mil/mm³, K/µL, 10^3/µL, 10⁹/L)", () => {
    for (const unit of ["mil/mm³", "K/µL", "10^3/µL", "10⁹/L"]) {
      expect(convertBiomarker("neutrophils_absolute", 4.2, unit).value).toBeCloseTo(4200, 6);
    }
  });

  it("leaves a raw count untouched under any raw notation, OCR-mangled ones included", () => {
    for (const unit of ["/µL", "/mm³", "células/µL", "/mL", "/mi", "/mcL"]) {
      const res = convertBiomarker("lymphocytes_absolute", 2340, unit);
      expect(res.converted).toBe(false);
      expect(res.value).toBe(2340);
      expect(validateCanonicalUnit("lymphocytes_absolute", res.unit).ok).toBe(true);
    }
  });

  it("red blood cells: ×10⁶/µL and 10^12/L scale up by a million; raw passes through", () => {
    expect(convertBiomarker("red_blood_cell_count", 4.85, "x10⁶/µL").value).toBeCloseTo(4_850_000, 6);
    expect(convertBiomarker("red_blood_cell_count", 4.85, "10^12/L").value).toBeCloseTo(4_850_000, 6);
    const raw = convertBiomarker("red_blood_cell_count", 4_850_000, "/µL");
    expect(raw.converted).toBe(false);
    expect(validateCanonicalUnit("red_blood_cell_count", raw.unit).ok).toBe(true);
  });

  it("is idempotent: converting the output again is a no-op", () => {
    const first = convertBiomarker("lymphocytes_absolute", 2.34, "x10³/µL");
    const second = convertBiomarker("lymphocytes_absolute", first.value, first.unit);
    expect(second.converted).toBe(false);
    expect(second.value).toBe(first.value);
  });
});

/**
 * The unit string cannot be trusted on its own — labs and OCR mislabel in
 * both directions — so the value's magnitude against the raw-scale
 * normal-high arbitrates, except for eosinophils and basophils, whose raw
 * counts are legitimately tiny.
 */
describe("CBC magnitude arbitration (mislabelled units)", () => {
  it("a raw count mislabelled 10³/µL stays raw when the normal-high says so", () => {
    const res = convertBiomarker("lymphocytes_absolute", 2331, "10³/µL", { normalHigh: 3500 });
    expect(res.converted).toBe(false);
    expect(res.value).toBe(2331);
  });

  it("a thousands value mislabelled /µL scales up only where no patient can be that low: total white and red cells", () => {
    expect(convertBiomarker("white_blood_cell_count", 4.5, "/µL", { normalHigh: 11000 }).value).toBeCloseTo(4500, 6);
    expect(convertBiomarker("red_blood_cell_count", 4.9, "/µL", { normalHigh: 5650000 }).value).toBeCloseTo(4900000, 6);
  });

  it("never second-guesses a small raw count that can be real in a sick patient", () => {
    // Severe thrombocytopenia, agranulocytosis, monocytopenia — ×1000 here would be the dangerous error.
    expect(convertBiomarker("platelet_count", 1500, "/µL", { normalHigh: 400000 }).value).toBe(1500);
    expect(convertBiomarker("neutrophils_absolute", 12, "/µL", { normalHigh: 7500 }).value).toBe(12);
    expect(convertBiomarker("monocytes_absolute", 2, "/µL", { normalHigh: 800 }).value).toBe(2);
    expect(convertBiomarker("eosinophils_absolute", 20, "/µL", { normalHigh: 500 }).value).toBe(20);
    expect(convertBiomarker("basophils_absolute", 5, "/µL", { normalHigh: 200 }).value).toBe(5);
  });

  it("without a usable unit, the magnitude decides", () => {
    expect(convertBiomarker("monocytes_absolute", 0.69, "", { normalHigh: 800 }).value).toBeCloseTo(690, 6);
    expect(convertBiomarker("monocytes_absolute", 690, "", { normalHigh: 800 }).value).toBe(690);
    expect(convertBiomarker("eosinophils_absolute", 0.3, "", { normalHigh: 500 }).value).toBeCloseTo(300, 6);
  });

  it("real thrombocytosis or lymphocytosis is not a unit error", () => {
    expect(convertBiomarker("platelet_count", 600, "x10³/µL", { normalHigh: 400000 }).value).toBeCloseTo(600000, 6);
    const lym = convertBiomarker("lymphocytes_absolute", 8000, "/µL", { normalHigh: 3500 });
    expect(lym.converted).toBe(false);
    expect(lym.value).toBe(8000);
  });
});

describe("trusted units: the lab's HL7 label decides, no magnitude arbitration (bridge, 2026-09-21)", () => {
  it("keeps Echevarne's '44 /µL' dummy as 44, where the arbiter would have made it 44 000", () => {
    const arbitrated = convertBiomarker("white_blood_cell_count", 44, "/µL", { normalHigh: 11000 });
    expect(arbitrated.value).toBe(44000);
    const trusted = convertBiomarker("white_blood_cell_count", 44, "/µL", { normalHigh: 11000, trustUnit: true });
    expect(trusted.converted).toBe(false);
    expect(trusted.value).toBe(44);
    expect(trusted.unit).toBe("/µL");
    expect(convertBiomarker("red_blood_cell_count", 4.9, "/µL", { normalHigh: 5650000, trustUnit: true }).value).toBe(4.9);
  });

  it("still multiplies an explicit thousands or millions label up to raw cells/µL", () => {
    const wbc = convertBiomarker("white_blood_cell_count", 6.5, "x10³/µL", { normalHigh: 11000, trustUnit: true });
    expect(wbc.converted).toBe(true);
    expect(wbc.value).toBeCloseTo(6500, 6);
    expect(convertBiomarker("red_blood_cell_count", 4.9, "x10⁶/µL", { normalHigh: 5650000, trustUnit: true }).value).toBeCloseTo(4900000, 6);
    // Even where the arbiter would have called the label a mislabel: the label wins.
    expect(convertBiomarker("lymphocytes_absolute", 2331, "10³/µL", { normalHigh: 3500, trustUnit: true }).value).toBeCloseTo(2331000, 6);
  });

  it("with no unit at all there is nothing to trust, so the magnitude still decides", () => {
    expect(convertBiomarker("monocytes_absolute", 0.69, "", { normalHigh: 800, trustUnit: true }).value).toBeCloseTo(690, 6);
    expect(convertBiomarker("monocytes_absolute", 690, "", { normalHigh: 800, trustUnit: true }).value).toBe(690);
  });

  it("a real Echevarne differential passes through unchanged, count and formula consistent", () => {
    const wbc = convertBiomarker("white_blood_cell_count", 6500, "/µL", { normalHigh: 11000, trustUnit: true });
    const neu = convertBiomarker("neutrophils_absolute", 3770, "/µL", { normalHigh: 7500, trustUnit: true });
    expect(wbc.value).toBe(6500);
    expect(neu.value).toBe(3770);
    expect(neu.converted).toBe(false);
  });
});

describe("CBC differential key routing by unit", () => {
  it("routes a raw /µL count to the absolute key", () => {
    expect(remapToSeedKey("lymphocytes", "/µL")).toBe("lymphocytes_absolute");
    expect(remapToSeedKey("basophils", "/mm³")).toBe("basophils_absolute");
  });

  it("keeps a percentage on the percentage key", () => {
    expect(remapToSeedKey("lymphocytes", "%")).toBe("lymphocytes");
  });

  it("routes the ×10³/µL notation to the absolute key", () => {
    expect(remapToSeedKey("neutrophils", "x10³/µL")).toBe("neutrophils_absolute");
  });

  it("routes OCR-mangled count units (/mi, /mL, /MI) to the absolute key", () => {
    // The phone screenshot showed the absolute count unit rendered as
    // "/MI" — any non-% unit on a differential line is an absolute count.
    expect(remapToSeedKey("lymphocytes", "/mi")).toBe("lymphocytes_absolute");
    expect(remapToSeedKey("lymphocytes", "/MI")).toBe("lymphocytes_absolute");
    expect(remapToSeedKey("monocytes", "/mL")).toBe("monocytes_absolute");
  });

  it("end-to-end: a /mi count routes to the absolute key and stays raw", () => {
    const key = remapToSeedKey("lymphocytes", "/mi");
    expect(key).toBe("lymphocytes_absolute");
    const conv = convertBiomarker(key, 2331, "/mi", { normalHigh: 3500 });
    expect(conv.converted).toBe(false);
    expect(conv.value).toBe(2331);
    expect(validateCanonicalUnit(key, conv.unit).ok).toBe(true);
  });
});

describe("AMH pmol/L → ng/mL (Echevarne D0694)", () => {
  it("divides by 7.14 and lands on the canonical unit", () => {
    const res = convertBiomarker("anti_mullerian_hormone_amh", 21.42, "pmol/L");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(3.0, 6);
    expect(res.unit).toBe("ng/mL");
    expect(validateCanonicalUnit("anti_mullerian_hormone_amh", res.unit).ok).toBe(true);
  });

  it("leaves ng/mL untouched", () => {
    const res = convertBiomarker("anti_mullerian_hormone_amh", 3.0, "ng/mL");
    expect(res.value).toBeCloseTo(3.0, 6);
  });
});

/**
 * Echevarne's serum units are canonical (2026-09-17): what the lab sends
 * passes through; the per-decilitre notations other labs use shift by ten.
 */
describe("Echevarne serum units are canonical (catalog 2026-08-25)", () => {
  it("calcium: mg/L passes through, mg/dL ×10, mmol/L ×40.08", () => {
    const ech = convertBiomarker("calcium_serum", 95, "mg/L");
    expect(ech.converted).toBe(false);
    expect(validateCanonicalUnit("calcium_serum", ech.unit).ok).toBe(true);
    expect(convertBiomarker("calcium_serum", 9.5, "mg/dL").value).toBeCloseTo(95, 6);
    expect(convertBiomarker("calcium_serum", 2.4, "mmol/L").value).toBeCloseTo(96.19, 2);
  });

  it("albumin and total protein: g/L passes through, g/dL ×10", () => {
    const alb = convertBiomarker("albumin", 45, "g/L");
    expect(alb.converted).toBe(false);
    expect(validateCanonicalUnit("albumin", alb.unit).ok).toBe(true);
    expect(convertBiomarker("albumin", 4.5, "g/dL").value).toBeCloseTo(45, 6);
    const tp = convertBiomarker("total_protein", 7.2, "g/dL");
    expect(tp.value).toBeCloseTo(72, 6);
    expect(validateCanonicalUnit("total_protein", tp.unit).ok).toBe(true);
  });

  it("testosterone (total): ng/mL passes through, ng/dL ÷100, nmol/L ×0.2884", () => {
    expect(convertBiomarker("testosterone_total", 5.5, "ng/mL").converted).toBe(false);
    const us = convertBiomarker("testosterone_total", 550, "ng/dL");
    expect(us.value).toBeCloseTo(5.5, 6);
    expect(validateCanonicalUnit("testosterone_total", us.unit).ok).toBe(true);
    expect(convertBiomarker("testosterone_total", 19.07, "nmol/L").value).toBeCloseTo(5.5, 2);
  });
});

/**
 * Every factor convertBiomarker applies (acceptance check D4), each called with the unit the lab reports. The
 * expected value is worked out from the factor's basis, not from the factor the code writes: the molar mass from
 * standard atomic weights, or the published conversion. The code writes its factors to three to five significant
 * figures, so each must reproduce its basis to within 0.2%. The result must also be in the seed's canonical unit,
 * or processing would refuse the row.
 */
describe("every conversion factor reproduces its basis (check D4)", () => {
  /** Molar masses, g/mol. */
  const M = {
    urea: 60.056, // CH4N2O
    ureaNitrogen: 2 * 14.007, // the two nitrogen atoms of one urea: BUN
    glucose: 180.156, // C6H12O6
    cholesterol: 386.66, // C27H46O
    triolein: 885.4, // C57H104O6, the triglyceride the conventional factor counts
    creatinine: 113.12, // C4H7N3O
    uricAcid: 168.11, // C5H4N4O3
    bilirubin: 584.67, // C33H36N4O6
    calcidiol: 400.65, // 25-hydroxyvitamin D3, C27H44O2
    amhDimer: 140_000, // the assays' convention for AMH
    cobalamin: 1355.4, // cyanocobalamin, C63H88CoN14O14P
    homocysteine: 135.18, // C4H9NO2S
    calcium: 40.078,
    iron: 55.845,
    cortisol: 362.47, // C21H30O5
    testosterone: 288.43, // C19H28O2
    estradiol: 272.39, // C18H24O2
    dheaSulfate: 368.49, // C19H28O5S
    lead: 207.2,
    mercury: 200.59,
    triiodothyronine: 650.98, // C15H12I3NO4
    thyroxine: 776.87, // C15H11I4NO4
    magnesium: 24.305,
    zinc: 65.38,
    crpPentamer: 113_800, // as the code's factor takes it; no family file gives one (see unit-conversions.ts)
    shbgDimer: 94_900, // as the code's factor takes it; no family file gives one (see unit-conversions.ts)
  };

  interface FactorCase {
    key: string;
    value: number;
    unit: string;
    /** Worked out from the basis. */
    expected: number;
    expectedUnit: string;
    /** The factor as unit-conversions.ts writes it. */
    factor: string;
    basis: string;
  }

  const CASES: FactorCase[] = [
    { key: "urea", value: 7.7, unit: "mmol/L", expected: (7.7 * M.urea) / 10, expectedUnit: "mg/dL", factor: "×6.006", basis: "urea 60.06 g/mol" },
    { key: "urea", value: 0.3, unit: "g/L", expected: 30, expectedUnit: "mg/dL", factor: "×100", basis: "1 g/L = 100 mg/dL" },
    { key: "bun", value: 5, unit: "mmol/L", expected: (5 * M.ureaNitrogen) / 10, expectedUnit: "mg/dL", factor: "×2.801", basis: "urea nitrogen 28.01 g/mol" },
    { key: "bun", value: 0.14, unit: "g/L", expected: 14, expectedUnit: "mg/dL", factor: "×100", basis: "1 g/L = 100 mg/dL" },
    { key: "glucose_fasting", value: 7, unit: "mmol/L", expected: (7 * M.glucose) / 10, expectedUnit: "mg/dL", factor: "×18.0182", basis: "glucose 180.16 g/mol" },
    { key: "total_cholesterol", value: 5, unit: "mmol/L", expected: (5 * M.cholesterol) / 10, expectedUnit: "mg/dL", factor: "×38.67", basis: "cholesterol 386.66 g/mol" },
    { key: "ldl_cholesterol", value: 2.6, unit: "mmol/L", expected: (2.6 * M.cholesterol) / 10, expectedUnit: "mg/dL", factor: "×38.67", basis: "cholesterol 386.66 g/mol" },
    { key: "hdl_cholesterol", value: 1.3, unit: "mmol/L", expected: (1.3 * M.cholesterol) / 10, expectedUnit: "mg/dL", factor: "×38.67", basis: "cholesterol 386.66 g/mol" },
    { key: "non_hdl_cholesterol", value: 3.4, unit: "mmol/L", expected: (3.4 * M.cholesterol) / 10, expectedUnit: "mg/dL", factor: "×38.67", basis: "cholesterol 386.66 g/mol" },
    { key: "triglycerides", value: 1.7, unit: "mmol/L", expected: (1.7 * M.triolein) / 10, expectedUnit: "mg/dL", factor: "×88.57", basis: "triolein 885.4 g/mol" },
    { key: "creatinine", value: 88.4, unit: "µmol/L", expected: (88.4 * M.creatinine) / 10_000, expectedUnit: "mg/dL", factor: "×0.0113", basis: "creatinine 113.12 g/mol" },
    { key: "uric_acid", value: 360, unit: "µmol/L", expected: (360 * M.uricAcid) / 10_000, expectedUnit: "mg/dL", factor: "×0.01681", basis: "uric acid 168.11 g/mol" },
    { key: "total_bilirubin", value: 17.1, unit: "µmol/L", expected: (17.1 * M.bilirubin) / 10_000, expectedUnit: "mg/dL", factor: "×0.0585", basis: "bilirubin 584.67 g/mol" },
    { key: "direct_bilirubin", value: 5.13, unit: "μmol/L", expected: (5.13 * M.bilirubin) / 10_000, expectedUnit: "mg/dL", factor: "×0.0585", basis: "bilirubin 584.67 g/mol" },
    { key: "vitamin_d_25_oh", value: 75, unit: "nmol/L", expected: (75 * M.calcidiol) / 1000, expectedUnit: "ng/mL", factor: "÷2.496", basis: "25-hydroxyvitamin D3 400.65 g/mol" },
    { key: "calcium_serum", value: 9.5, unit: "mg/dL", expected: 95, expectedUnit: "mg/L", factor: "×10", basis: "1 mg/dL = 10 mg/L" },
    { key: "albumin", value: 4.1, unit: "g/dL", expected: 41, expectedUnit: "g/L", factor: "×10", basis: "1 g/dL = 10 g/L" },
    { key: "total_protein", value: 7.2, unit: "g/dL", expected: 72, expectedUnit: "g/L", factor: "×10", basis: "1 g/dL = 10 g/L" },
    { key: "anti_mullerian_hormone_amh", value: 23, unit: "pmol/L", expected: (23 * M.amhDimer) / 1e6, expectedUnit: "ng/mL", factor: "÷7.14", basis: "AMH dimer 140 kDa" },
    { key: "vitamin_b12", value: 221, unit: "pmol/L", expected: (221 * M.cobalamin) / 1000, expectedUnit: "pg/mL", factor: "×1.355", basis: "cobalamin 1355.4 g/mol" },
    { key: "homocysteine", value: 2, unit: "mg/L", expected: 2000 / M.homocysteine, expectedUnit: "µmol/L", factor: "×7.397", basis: "homocysteine 135.18 g/mol" },
    { key: "homocysteine", value: 0.2, unit: "mg/dL", expected: 2000 / M.homocysteine, expectedUnit: "µmol/L", factor: "×73.97", basis: "homocysteine 135.18 g/mol" },
    { key: "hba1c", value: 48, unit: "mmol/mol", expected: 48 / 10.929 + 2.15, expectedUnit: "%", factor: "×0.0915 + 2.15", basis: "IFCC-NGSP master equation, % = mmol/mol / 10.929 + 2.15" },
    { key: "hs_crp", value: 0.3, unit: "mg/dL", expected: 3, expectedUnit: "mg/L", factor: "×10", basis: "1 mg/dL = 10 mg/L" },
    { key: "calcium_serum", value: 2.4, unit: "mmol/L", expected: 2.4 * M.calcium, expectedUnit: "mg/L", factor: "×40.08", basis: "calcium 40.078 g/mol" },
    { key: "calcium_serum", value: 4.8, unit: "mEq/L", expected: (4.8 / 2) * M.calcium, expectedUnit: "mg/L", factor: "×20.04", basis: "Ca²⁺, two charges: 1 mEq/L = 0.5 mmol/L" },
    { key: "hemoglobin", value: 145, unit: "g/L", expected: 14.5, expectedUnit: "g/dL", factor: "×0.1", basis: "1 g/dL = 10 g/L" },
    { key: "mchc", value: 335, unit: "g/L", expected: 33.5, expectedUnit: "g/dL", factor: "×0.1", basis: "1 g/dL = 10 g/L" },
    { key: "hematocrit", value: 0.42, unit: "L/L", expected: 42, expectedUnit: "%", factor: "×100", basis: "a volume fraction × 100" },
    { key: "globulin", value: 28, unit: "g/L", expected: 2.8, expectedUnit: "g/dL", factor: "×0.1", basis: "1 g/dL = 10 g/L" },
    { key: "iron_serum", value: 17.9, unit: "µmol/L", expected: (17.9 * M.iron) / 10, expectedUnit: "µg/dL", factor: "×5.585", basis: "iron 55.845 g/mol" },
    { key: "iron_binding_capacity_tibc", value: 60, unit: "µmol/L", expected: (60 * M.iron) / 10, expectedUnit: "µg/dL", factor: "×5.585", basis: "the iron transferrin binds, 55.845 g/mol" },
    { key: "cortisol_morning_8am", value: 400, unit: "nmol/L", expected: (400 * M.cortisol) / 10_000, expectedUnit: "µg/dL", factor: "×0.03626", basis: "cortisol 362.47 g/mol" },
    { key: "cortisol_morning_8am", value: 150, unit: "ng/mL", expected: 15, expectedUnit: "µg/dL", factor: "÷10", basis: "1 µg/dL = 10 ng/mL" },
    { key: "testosterone_total", value: 19.07, unit: "nmol/L", expected: (19.07 * M.testosterone) / 1000, expectedUnit: "ng/mL", factor: "×0.2884", basis: "testosterone 288.43 g/mol" },
    { key: "testosterone_total", value: 550, unit: "ng/dL", expected: 5.5, expectedUnit: "ng/mL", factor: "÷100", basis: "1 ng/mL = 100 ng/dL" },
    { key: "testosterone_free", value: 347, unit: "pmol/L", expected: (347 * M.testosterone) / 10_000, expectedUnit: "ng/dL", factor: "÷34.67", basis: "testosterone 288.43 g/mol" },
    { key: "testosterone_free", value: 100, unit: "pg/mL", expected: 10, expectedUnit: "ng/dL", factor: "÷10", basis: "1 ng/dL = 10 pg/mL" },
    { key: "estradiol", value: 367, unit: "pmol/L", expected: (367 * M.estradiol) / 1000, expectedUnit: "pg/mL", factor: "÷3.671", basis: "estradiol 272.39 g/mol" },
    { key: "dhea_sulfate", value: 5, unit: "µmol/L", expected: (5 * M.dheaSulfate) / 10, expectedUnit: "µg/dL", factor: "×36.848", basis: "DHEA sulfate 368.49 g/mol" },
    { key: "insulin_fasting", value: 69.45, unit: "pmol/L", expected: 10, expectedUnit: "µU/mL", factor: "÷6.945", basis: "1 µIU/mL = 6.945 pmol/L (insulin_fasting.json)" },
    { key: "prolactin", value: 212, unit: "mIU/L", expected: 10, expectedUnit: "ng/mL", factor: "÷21.2", basis: "WHO IS 84/500: 1 ng/mL = 21.2 mIU/L" },
    { key: "lead_blood", value: 48.3, unit: "nmol/L", expected: (48.3 * M.lead) / 10_000, expectedUnit: "µg/dL", factor: "÷48.3", basis: "lead 207.2 g/mol" },
    { key: "mercury_blood", value: 50, unit: "nmol/L", expected: (50 * M.mercury) / 1000, expectedUnit: "µg/L", factor: "÷4.99", basis: "mercury 200.59 g/mol" },
    { key: "free_t3_triiodothyronine", value: 5, unit: "pmol/L", expected: (5 * M.triiodothyronine) / 1000, expectedUnit: "pg/mL", factor: "×0.651", basis: "triiodothyronine 650.98 g/mol" },
    { key: "free_t4_thyroxine", value: 15, unit: "pmol/L", expected: (15 * M.thyroxine) / 10_000, expectedUnit: "ng/dL", factor: "×0.0777", basis: "thyroxine 776.87 g/mol" },
    { key: "free_t4_thyroxine", value: 12, unit: "pg/mL", expected: 1.2, expectedUnit: "ng/dL", factor: "÷10", basis: "1 ng/dL = 10 pg/mL" },
    { key: "free_t4_thyroxine", value: 0.012, unit: "ng/mL", expected: 1.2, expectedUnit: "ng/dL", factor: "×100", basis: "1 ng/mL = 100 ng/dL" },
    { key: "magnesium_serum", value: 0.85, unit: "mmol/L", expected: (0.85 * M.magnesium) / 10, expectedUnit: "mg/dL", factor: "×2.43", basis: "magnesium 24.305 g/mol" },
    { key: "magnesium_serum", value: 1.7, unit: "mEq/L", expected: (1.7 / 2) * (M.magnesium / 10), expectedUnit: "mg/dL", factor: "×1.215", basis: "Mg²⁺, two charges: 1 mEq/L = 0.5 mmol/L" },
    { key: "zinc_serum", value: 12, unit: "µmol/L", expected: (12 * M.zinc) / 10, expectedUnit: "µg/dL", factor: "×6.538", basis: "zinc 65.38 g/mol" },
    { key: "apolipoprotein_b_apob", value: 0.9, unit: "g/L", expected: 90, expectedUnit: "mg/dL", factor: "×100", basis: "1 g/L = 100 mg/dL" },
    { key: "hs_crp", value: 26.4, unit: "nmol/L", expected: (26.4 * M.crpPentamer) / 1e6, expectedUnit: "mg/L", factor: "×0.1138", basis: "CRP pentamer taken as 113.8 kDa" },
    { key: "shbg", value: 3.8, unit: "µg/mL", expected: (3.8 / M.shbgDimer) * 1e6, expectedUnit: "nmol/L", factor: "÷0.0949", basis: "SHBG homodimer taken as 94.9 kDa" },
    { key: "lipoproteina", value: 300, unit: "µg/mL", expected: 30, expectedUnit: "mg/dL", factor: "÷10", basis: "1 mg/dL = 10 µg/mL" },
  ];

  it.each(CASES)("$key: $value $unit → $expectedUnit, factor $factor ($basis)", ({ key, value, unit, expected, expectedUnit }) => {
    const res = convertBiomarker(key, value, unit);
    expect(res.converted).toBe(true);
    expect(Math.abs(res.value - expected) / expected).toBeLessThan(0.002);
    expect(normalizeUnit(res.unit)).toBe(normalizeUnit(expectedUnit));
    expect(validateCanonicalUnit(key, res.unit).ok).toBe(true);
  });
});

describe("Lp(a) canonical unit is mg/dL (Echevarne alignment, 2026-08-25)", () => {
  it("passes mg/dL through as canonical", () => {
    expect(validateCanonicalUnit("lipoproteina", "mg/dL").ok).toBe(true);
  });

  it("does not convert nmol/L: the value keeps its unit and fails the canonical-unit gate (check D4)", () => {
    // nmol/L counts Lp(a) particles and mg/dL weighs them; a particle's mass depends on its apo(a) isoform, so no
    // fixed factor links the two (the ÷2.5 this replaced was an isoform-dependent approximation).
    for (const unit of ["nmol/L", "nmol/l", "NMOL/L"]) {
      const res = convertBiomarker("lipoproteina", 75, unit);
      expect(res).toEqual({ value: 75, unit, converted: false });
      expect(validateCanonicalUnit("lipoproteina", res.unit)).toMatchObject({ ok: false, canonical: "mg/dL" });
    }
  });

  it("converts µg/mL to mg/dL via ÷10", () => {
    const res = convertBiomarker("lipoproteina", 300, "µg/mL");
    expect(res.converted).toBe(true);
    expect(res.value).toBeCloseTo(30, 6);
    expect(res.unit).toBe("mg/dL");
  });
});

/**
 * The canonical-unit gate is in processLabResults (process-results.ts): a value convertBiomarker could not bring to
 * the seed's unit is not stored, and is listed as unmatched with reason unit_mismatch and the unit expected.
 * Scripted database (fake-supabase), no network.
 */
describe("processing lists an Lp(a) in nmol/L as unit_mismatch and stores nothing for it (check D4)", () => {
  const ROWS = reviewedRows();

  function database() {
    const dob = `${new Date().getFullYear() - 45}-01-01`;
    const stored: Array<Record<string, unknown>> = [];
    const respond = (c: FakeCall): FakeResponse => {
      if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { date_of_birth: dob, sex: "male" } };
      if (c.table === "biomarker_references") {
        const [, sexes] = argsOf(c, "in") as [string, string[]];
        return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
      }
      if (c.table === "biomarker_values" && ops(c).startsWith("insert")) {
        stored.push(...(argsOf(c, "insert")?.[0] as Array<Record<string, unknown>>));
      }
      return { data: null };
    };
    return { client: fakeSupabase(respond).client, stored };
  }

  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  it("an Lp(a) in nmol/L ends in the unmatched list with reason unit_mismatch; the rest of the result is stored", async () => {
    const db = database();
    const result = await processLabResults(
      "u1",
      "lab-1",
      [
        { name: "Lipoproteína (a)", value: 75, unit: "nmol/L", biomarkerKey: "lipoproteina", matchConfidence: "exact" },
        { name: "Apolipoproteína B", value: 0.9, unit: "g/L", biomarkerKey: "apolipoprotein_b_apob", matchConfidence: "exact" },
      ],
      db.client,
    );
    expect(result.unmatched).toEqual([
      { name: "Lipoproteína (a)", value: 75, unit: "nmol/L", reason: "unit_mismatch", expectedUnit: "mg/dL" },
    ]);
    expect(result.processed.map((p) => p.biomarkerKey)).toEqual(["apolipoprotein_b_apob"]);
    expect(db.stored).toEqual([expect.objectContaining({ biomarker_key: "apolipoprotein_b_apob", value: 90, unit: "mg/dL" })]);
  });

  it("the same Lp(a) in µg/mL, a mass unit, is converted ÷10 and stored in mg/dL", async () => {
    const db = database();
    const result = await processLabResults(
      "u1",
      "lab-1",
      [{ name: "Lipoproteína (a)", value: 300, unit: "µg/mL", biomarkerKey: "lipoproteina", matchConfidence: "exact" }],
      db.client,
    );
    expect(result.unmatched).toEqual([]);
    expect(db.stored).toEqual([
      expect.objectContaining({ biomarker_key: "lipoproteina", value: 30, unit: "mg/dL", reported_value: 300, reported_unit: "µg/mL" }),
    ]);
  });
});

/**
 * Spanish labs write "UI" (unidades internacionales) where the seed says
 * "IU". Echevarne's training ORU X68800192 (2026-09-17) reported TSH as
 * "22,000 µUI/mL" and the row was silently dropped as a unit mismatch —
 * the only base-panel marker that failed to land.
 */
describe("Spanish UI ≡ IU, bare U ≡ IU", () => {
  it("TSH in µUI/mL (Echevarne) is the canonical unit and passes through", () => {
    const res = convertBiomarker("tsh", 22, "µUI/mL");
    expect(res.converted).toBe(false);
    expect(res.value).toBe(22);
    expect(validateCanonicalUnit("tsh", res.unit).ok).toBe(true);
  });

  it("TSH in mIU/L or mUI/L (other labs) is the same number, relabelled", () => {
    for (const unit of ["mIU/L", "mUI/L"]) {
      const res = convertBiomarker("tsh", 2.1, unit);
      expect(res.value).toBe(2.1);
      expect(validateCanonicalUnit("tsh", res.unit).ok).toBe(true);
    }
  });

  it("insulin µU/mL (Echevarne) ≡ µIU/mL ≡ µUI/mL; antibodies UI/mL ≡ IU/mL", () => {
    for (const unit of ["µU/mL", "µIU/mL", "µUI/mL"]) {
      expect(validateCanonicalUnit("insulin_fasting", unit).ok).toBe(true);
    }
    expect(validateCanonicalUnit("thyroid_peroxidase_antibodies_tpo", "UI/mL").ok).toBe(true);
    expect(validateCanonicalUnit("alt", "IU/L").ok).toBe(true);
  });
});
