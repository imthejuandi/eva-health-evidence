/**
 * The eGFR the app computes, and the laboratory's own eGFR as a value only (rulings D-28 and D-06).
 *
 *  1. The equation is data (data/egfr-equation.json) and CKD-EPI 2021 is the one the code implements: the app's
 *     value equals the acceptance runner's ckdEpi2021 (check K1) over a grid, and the National Kidney Foundation's
 *     published test table; a declared equation the code does not implement computes nothing.
 *  2. The age is the age at the draw.
 *  3. The metric `egfr_computed`: classified against the `egfr_creatinine_based` rows, never under that key.
 *  4. Processing: the laboratory's eGFR is stored with no category and no interval, is never a score input, and
 *     still counts toward the critical tier; the computed eGFR is not a score input either.
 *  5. Readers show a laboratory eGFR stored earlier, with a category, as a value only.
 *
 * Processing and the routes run for real on a scripted database (fake-supabase); nothing reaches a database.
 */
import { beforeAll, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { LAB_STATE_LAB_COLUMNS, UNKNOWN_STATE } from "@/lib/patient-context/physiological-state";
// The runner's function, read only: the app's computation is held equal to it.
import { ckdEpi2021 } from "../../../scripts/signoff/checks/coherence";
import { completedYearsAt } from "./biological-age-v3-adapter";
import { calculateAllMetrics } from "./calculated-metrics";
import { getCanonicalUnit } from "./canonical-units";
import { ageAtDraw, computeEgfr, EGFR_EQUATION, EGFR_METRIC_KEY, isEgfrEquationImplemented, reportedEgfr, type EgfrEquation } from "./egfr";
import { buildEngineInputs } from "./engine-inputs";
import { isLabReportedValueOnly, shownAsValueOnly } from "./lab-reported";
import { DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
import { pickReferenceRows } from "./reference-row";
import { classifyZone } from "./zone-classifier";
import { reviewedRows, signedRows } from "./__tests__/fixtures/reviewed-rows";
import type { RawBiomarker } from "./process-results";

const state = vi.hoisted(() => ({ client: null as unknown }));

vi.mock("@/lib/supabase/server", () => ({ createClient: async () => state.client }));
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});
// The value-edit route regenerates the interpretation after the update: not under test here.
vi.mock("@/lib/ai/regenerate-master", () => ({ regenerateMasterForLab: async () => ({ ok: true }) }));

import { processLabResults, recomputeLabMetrics } from "./process-results";
import { getBiomarkerValues } from "@/lib/queries";
import { PATCH as editValue } from "@/app/api/biomarker-values/[id]/route";

const SEED = reviewedRows();
const AGE = 45;
const THIS_YEAR = new Date().getFullYear();
const DOB = `${THIS_YEAR - AGE}-01-01`;
const picked = (sex: string, age: number) => pickReferenceRows(SEED, sex, age).picked;
const egfrRow = (sex: string, age: number) => picked(sex, age).get("egfr_creatinine_based")!;
const zoneOnEgfrRow = (value: number, sex: string, age: number) => {
  const r = egfrRow(sex, age);
  return classifyZone(value, r.optimal_low, r.optimal_high, r.normal_low, r.normal_high);
};

// ─── 1. The equation ───

describe("the declared equation is CKD-EPI 2021, read from data", () => {
  it("declares its name, its units and its constants", () => {
    expect(EGFR_EQUATION.equation).toBe("ckd_epi_2021");
    expect(isEgfrEquationImplemented()).toBe(true);
    // Creatinine is stored in the unit the equation takes, so no conversion stands between them.
    expect(EGFR_EQUATION.creatinine_unit).toBe(getCanonicalUnit("creatinine"));
    expect(EGFR_EQUATION.result_unit).toBe(getCanonicalUnit("egfr_creatinine_based"));
    expect(EGFR_EQUATION.constants).toEqual({
      scale: 142, exponent_above_kappa: -1.2, age_base: 0.9938,
      female: { kappa: 0.7, alpha: -0.241, factor: 1.012 },
      male: { kappa: 0.9, alpha: -0.302, factor: 1 },
    });
  });

  it("equals the runner's ckdEpi2021 for every creatinine of a grid, ages 18 to 90, both sexes", () => {
    const creatinines = [0.2, 0.3, 0.45, 0.6, 0.69, 0.7, 0.71, 0.8, 0.89, 0.9, 0.91, 1, 1.1, 1.3, 1.5, 2, 2.9, 4, 6.5, 10, 15];
    let compared = 0;
    for (const sex of ["male", "female"] as const) {
      for (let age = 18; age <= 90; age++) {
        for (const creatinine of creatinines) {
          const app = computeEgfr({ creatinine, age, sex });
          const runner = ckdEpi2021(creatinine, age, sex);
          expect(app, `${sex} ${age} ${creatinine}`).not.toBeNull();
          expect(Math.abs(app! - runner), `${sex} ${age} ${creatinine}`).toBeLessThanOrEqual(1e-9 * runner);
          compared++;
        }
      }
    }
    expect(compared).toBe(2 * 73 * creatinines.length);
  });

  // The National Kidney Foundation's test table for laboratories implementing the equation (Clin Chem
  // 2022;68:511-520 and the NKF's example implementation request): values on both sides of each sex's knot.
  it.each([
    [18, "male", 0.9, 127], [18, "male", 0.91, 125], [18, "female", 0.7, 128], [18, "female", 0.71, 126],
    [90, "male", 0.5, 97], [90, "male", 1.5, 44], [90, "female", 0.5, 89], [90, "female", 1.5, 33],
  ] as const)("the published test table: age %i, %s, creatinine %f mg/dL gives %i", (age, sex, creatinine, expected) => {
    expect(reportedEgfr(computeEgfr({ creatinine, age, sex }))).toBe(expected);
  });

  it("is not computed below 18 (the published table: 'do not calculate')", () => {
    expect(computeEgfr({ creatinine: 0.8, age: 17, sex: "male" })).toBeNull();
    expect(computeEgfr({ creatinine: 0.8, age: 17, sex: "female" })).toBeNull();
    expect(computeEgfr({ creatinine: 0.8, age: 18, sex: "female" })).not.toBeNull();
  });

  it("reads sex as male or female in any case, and computes nothing for anything else", () => {
    const at = (sex: unknown) => computeEgfr({ creatinine: 1, age: 50, sex });
    expect(at("Female")).toBe(at("female"));
    expect(at(" MALE ")).toBe(at("male"));
    expect(at("male")).not.toBe(at("female"));
    for (const sex of ["other", "intersex", "", "m", "f", null, undefined, 1]) expect(at(sex), String(sex)).toBeNull();
  });

  it("computes nothing from an age or a creatinine that is not a usable number", () => {
    for (const age of [NaN, Infinity, -1]) expect(computeEgfr({ creatinine: 1, age, sex: "male" })).toBeNull();
    for (const creatinine of [0, -0.5, NaN, Infinity]) expect(computeEgfr({ creatinine, age: 50, sex: "male" })).toBeNull();
  });

  describe("fails closed on an equation the code cannot compute", () => {
    const declared = (over: Partial<EgfrEquation>): EgfrEquation => ({ ...EGFR_EQUATION, ...over });
    const input = { creatinine: 1, age: 50, sex: "male" };

    it("a declared equation the code does not implement computes nothing: no fallback to CKD-EPI 2021", () => {
      for (const equation of ["ekfc", "ckd_epi_2009", "mdrd", "", "toString", "constructor"]) {
        expect(isEgfrEquationImplemented(declared({ equation })), equation).toBe(false);
        expect(computeEgfr(input, declared({ equation })), equation).toBeNull();
      }
      expect(computeEgfr(input, declared({}))).toBe(computeEgfr(input));
    });

    it("a constant that is missing or not a number computes nothing", () => {
      const c = EGFR_EQUATION.constants as Record<string, unknown> & { male: Record<string, number>; female: Record<string, number> };
      const broken: unknown[] = [
        null, {}, { ...c, scale: undefined }, { ...c, scale: "142" }, { ...c, age_base: NaN }, { ...c, exponent_above_kappa: null },
        { ...c, female: undefined }, { ...c, male: { ...c.male, kappa: 0 } }, { ...c, female: { ...c.female, alpha: "x" } },
        { ...c, male: { kappa: 0.9, alpha: -0.302 } },
      ];
      for (const constants of broken) expect(computeEgfr(input, declared({ constants })), JSON.stringify(constants)).toBeNull();
      // Even when only the other sex's constants are broken: the equation as declared is not usable.
      expect(computeEgfr(input, declared({ constants: { ...c, female: {} } }))).toBeNull();
    });

    it("the numbers come from the data: other constants give another value", () => {
      const c = EGFR_EQUATION.constants as Record<string, unknown>;
      const doubled = computeEgfr(input, declared({ constants: { ...c, scale: 284 } }));
      expect(doubled).toBeCloseTo(2 * computeEgfr(input)!, 9);
    });

    it("an equation that takes creatinine in another unit than the stored one computes nothing", () => {
      expect(computeEgfr(input, declared({ creatinine_unit: "µmol/L" }))).toBeNull();
      expect(computeEgfr(input, declared({ creatinine_unit: undefined as never }))).toBeNull();
    });

    it("an equation with no readable minimum age or decimals gives nothing to show", () => {
      expect(computeEgfr(input, declared({ min_age_years: undefined as never }))).toBeNull();
      expect(reportedEgfr(94.6, declared({ result_decimals: undefined as never }))).toBeNull();
      expect(reportedEgfr(94.6, declared({ result_decimals: 1.5 }))).toBeNull();
      expect(reportedEgfr(94.64, declared({ result_decimals: 1 }))).toBe(94.6);
      expect(reportedEgfr(94.6)).toBe(95);
      expect(reportedEgfr(null)).toBeNull();
    });
  });
});

// ─── 2. The age at the draw ───

describe("the age is the age at the draw, not today's", () => {
  it("counts completed years at the collection date", () => {
    expect(ageAtDraw("1980-06-15", "2025-06-14")).toBe(44);
    expect(ageAtDraw("1980-06-15", "2025-06-15")).toBe(45);
    expect(ageAtDraw("1980-06-15", "2025-06-15T08:30:00+00:00")).toBe(45);
    expect(ageAtDraw("15/06/1980", "2010-01-01")).toBe(29);
  });

  it("is the biological age's rule (completedYearsAt), date for date", () => {
    for (const dob of ["1958-02-28", "1980-06-15", "1996-02-29", "2001-12-31"]) {
      for (const draw of ["2019-02-28", "2020-02-29", "2023-06-14", "2023-06-15", "2025-12-31", "2026-01-01"]) {
        const [y, m, d] = draw.split("-").map(Number);
        expect(ageAtDraw(dob, draw), `${dob} at ${draw}`).toBe(completedYearsAt(dob, new Date(y, m - 1, d)));
      }
    }
  });

  it("a lab with no readable draw date is aged when computed; an unreadable date of birth gives no age", () => {
    const now = new Date(2026, 10, 10);
    for (const draw of [null, undefined, "", "not a date", "2025-02-30"]) expect(ageAtDraw("1980-06-15", draw, now)).toBe(46);
    expect(ageAtDraw(null, "2025-06-15")).toBeNaN();
    expect(ageAtDraw("", "2025-06-15")).toBeNaN();
  });

  it("a draw date that cannot be one gives no age, and so no eGFR: after the day it is computed, or before birth", () => {
    const now = new Date(2026, 10, 10, 15, 0);
    expect(ageAtDraw("1980-06-15", "2999-01-01", now)).toBeNaN();
    expect(ageAtDraw("1980-06-15", "2026-11-11", now)).toBeNaN();
    expect(ageAtDraw("1980-06-15", "1979-12-31", now)).toBeNaN();
    // The day itself, and the day of birth, are draw dates.
    expect(ageAtDraw("1980-06-15", "2026-11-10", now)).toBe(46);
    expect(ageAtDraw("1980-06-15", "1980-06-15", now)).toBe(0);
    for (const draw of ["2999-01-01", "1979-12-31"]) {
      expect(computeEgfr({ creatinine: 1, age: ageAtDraw("1980-06-15", draw, now), sex: "male" }), draw).toBeNull();
    }
  });
});

// ─── 3. The metric ───

describe("the calculated metric egfr_computed", () => {
  const rows = picked("male", AGE);
  const metric = (
    biomarkers: Array<{ biomarker_key: string; value: number; comparator?: "<" | ">" | null }>,
    person: { age: number; sex: string | null } | null = { age: AGE, sex: "male" },
    reference = rows,
  ) => calculateAllMetrics(biomarkers, reference, person).find((m) => m.metricKey === EGFR_METRIC_KEY);
  const creatinine = (value: number, comparator?: "<" | ">") => ({ biomarker_key: "creatinine", value, comparator });

  it("is computed from creatinine, the age and sex, under its own key, and classified on the eGFR row", () => {
    // Male, 45: the 40-59 row (optimal from 75, reference from 60).
    for (const [value, zone] of [[1.0, "optimal"], [1.4, "below_optimal"], [1.6, "critical_low"]] as const) {
      const m = metric([creatinine(value)])!;
      expect(m.value).toBe(Math.round(ckdEpi2021(value, AGE, "male")));
      expect(m.zone).toBe(zone);
      expect(m.zone).toBe(zoneOnEgfrRow(m.value, "male", AGE));
      expect(m).toMatchObject({ metricKey: "egfr_computed", unit: "mL/min/1.73m²", comparator: null });
    }
    expect(EGFR_METRIC_KEY).not.toBe("egfr_creatinine_based");
    expect(isLabReportedValueOnly(EGFR_METRIC_KEY)).toBe(false);
  });

  it("uses the person's sex and the age given, and the row picked for them", () => {
    const female = calculateAllMetrics([creatinine(1.0)], picked("female", 70), { age: 70, sex: "Female" }).find((m) => m.metricKey === EGFR_METRIC_KEY)!;
    expect(female.value).toBe(Math.round(ckdEpi2021(1.0, 70, "female")));
    expect(female.zone).toBe(zoneOnEgfrRow(female.value, "female", 70));
    expect(metric([creatinine(1.0)], { age: 30, sex: "male" })!.value).toBeGreaterThan(metric([creatinine(1.0)], { age: 60, sex: "male" })!.value);
  });

  it("is not computed without a person, without sex, under 18, or without creatinine", () => {
    expect(calculateAllMetrics([creatinine(1.0)], rows).some((m) => m.metricKey === EGFR_METRIC_KEY)).toBe(false);
    expect(metric([creatinine(1.0)], null)).toBeUndefined();
    expect(metric([creatinine(1.0)], { age: AGE, sex: "other" })).toBeUndefined();
    expect(metric([creatinine(1.0)], { age: AGE, sex: null })).toBeUndefined();
    expect(metric([creatinine(1.0)], { age: 17, sex: "male" })).toBeUndefined();
    expect(metric([creatinine(1.0)], { age: NaN, sex: "male" })).toBeUndefined();
    expect(metric([{ biomarker_key: "egfr_creatinine_based", value: 88 }])).toBeUndefined();
  });

  it("never reads the laboratory's eGFR: the value comes from creatinine alone", () => {
    const alone = metric([creatinine(1.0)])!;
    for (const lab of [15, 60, 130]) {
      expect(metric([creatinine(1.0), { biomarker_key: "egfr_creatinine_based", value: lab }, { biomarker_key: "egfr", value: lab }])).toEqual(alone);
    }
  });

  it("without the eGFR row it has a value and no category", () => {
    expect(metric([creatinine(1.0)], { age: AGE, sex: "male" }, new Map())).toMatchObject({ value: 95, zone: "unclassified" });
  });

  it("a bounded creatinine makes it a bound the other way round (eGFR falls as creatinine rises)", () => {
    // "<0.5": eGFR above the value computed from 0.5, which is optimal on a row with no ceiling at this age.
    expect(metric([creatinine(0.5, "<")])).toMatchObject({ value: Math.round(ckdEpi2021(0.5, AGE, "male")), comparator: ">", zone: "optimal" });
    // ">1.6": eGFR below the value computed from 1.6, already below the reference limit.
    expect(metric([creatinine(1.6, ">")])).toMatchObject({ comparator: "<", zone: "critical_low" });
    // ">1.0": eGFR below 95 could be anywhere: not placed.
    expect(metric([creatinine(1.0, ">")])).toMatchObject({ value: 95, comparator: "<", zone: "unclassified" });
  });

  it("in declared pregnancy it is a value with no category (the eGFR rows: no equation is valid in pregnancy)", () => {
    const rowsF = picked("female", 31);
    const at = (pregnancy: boolean | undefined, value = 0.5) =>
      calculateAllMetrics([creatinine(value)], rowsF, { age: 31, sex: "female", pregnancy }).find((m) => m.metricKey === EGFR_METRIC_KEY)!;
    expect(at(false)).toMatchObject({ value: 129, zone: "optimal" });
    expect(at(undefined)).toEqual(at(false));
    expect(at(true)).toEqual({ ...at(false), zone: "unclassified" });
    // Whatever the value would be placed as.
    expect(at(false, 1.6).zone).toBe("critical_low");
    expect(at(true, 1.6).zone).toBe("unclassified");
    // Only eGFR: the other metrics are classified as before.
    const others = (pregnancy: boolean) =>
      calculateAllMetrics([{ biomarker_key: "insulin_fasting", value: 9 }, { biomarker_key: "glucose_fasting", value: 96 }], rowsF, { age: 31, sex: "female", pregnancy });
    expect(others(true)).toEqual(others(false));
  });

  it("a creatinine that cannot be read as one plausible result gives no eGFR", () => {
    expect(metric([creatinine(88.4)])).toBeUndefined(); // µmol/L stored as mg/dL
    expect(metric([creatinine(0.9), creatinine(1.4)])).toBeUndefined(); // two rows that disagree
    expect(metric([creatinine(1.0), creatinine(1.01)])).toMatchObject({ value: Math.round(ckdEpi2021(1.01, AGE, "male")) }); // the same result twice
  });
});

// ─── 4. Processing ───

/** A typical 45-year-old man (bounded-result.test.ts), without the kidney values, which each test gives. */
const PANEL: Record<string, number> = {
  apolipoprotein_b_apob: 105, ldl_cholesterol: 130, hdl_cholesterol: 47, triglycerides: 140, hs_crp: 2.5,
  glucose_fasting: 96, hba1c: 5.5, insulin_fasting: 9, alt: 30, ast: 25, ggt: 32, albumin: 44,
  uric_acid: 6.0, alp: 72, total_bilirubin: 0.7, hemoglobin: 15.2, rdw: 13.2, mcv: 90,
  platelet_count: 240000, white_blood_cell_count: 6800, lymphocytes_absolute: 2040,
  vitamin_d_25_oh: 24, vitamin_b12: 450, ferritin: 180, tsh: 1.9, shbg: 35, testosterone_total: 4.8,
};

type Stored = Record<string, unknown>;

function database(options: { stored?: Stored[]; rows?: ReadonlyArray<Record<string, unknown> & { sex: string }>; collectionDate?: string | null; sex?: string } = {}) {
  const rows = options.rows ?? SEED;
  const inserted: Stored[] = [];
  const labUpdates: Stored[] = [];
  const valueUpdates: Stored[] = [];
  const respond = (c: FakeCall): FakeResponse => {
    if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { id: "u1", date_of_birth: DOB, sex: options.sex ?? "male" } };
    if (c.table === "biomarker_references") {
      const sexes = argsOf(c, "in", "sex")?.[1] as string[] | undefined;
      const key = argsOf(c, "eq", "biomarker_key")?.[1];
      return { data: rows.filter((r) => (!sexes || sexes.includes(r.sex)) && (key === undefined || r.biomarker_key === key)) };
    }
    if (c.table === "lab_results" && argsOf(c, "select")?.[0] === LAB_STATE_LAB_COLUMNS) {
      return { data: { patient_context_version_id: null, created_at: "2026-01-01T00:00:00Z", transient_context: null, collection_date: options.collectionDate ?? null } };
    }
    if (c.table === "lab_results" && ops(c).startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Stored;
      if ("optimal_count" in update) labUpdates.push(update);
    }
    if (c.table === "biomarker_values" && ops(c).startsWith("insert")) inserted.push(...(argsOf(c, "insert")?.[0] as Stored[]));
    if (c.table === "biomarker_values" && ops(c).startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Stored;
      valueUpdates.push(update);
      return { data: update };
    }
    if (c.table === "biomarker_values" && ops(c).startsWith("select")) {
      const stored = options.stored ?? [];
      return { data: ops(c).endsWith("single") ? stored[0] ?? null : stored };
    }
    return { data: null };
  };
  const { client } = fakeSupabase(respond);
  Object.assign(client, { auth: { getUser: async () => ({ data: { user: { id: "u1" } } }) } });
  return { client, inserted, labUpdates, valueUpdates };
}

const raw = (key: string, value: number, comparator?: "<" | ">"): RawBiomarker => ({
  name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact", ...(comparator ? { comparator } : {}),
});
const panel = (kidney: Record<string, number>): RawBiomarker[] => Object.entries({ ...PANEL, ...kidney }).map(([k, v]) => raw(k, v));

async function processed(biomarkers: RawBiomarker[], options: Parameters<typeof database>[0] = {}) {
  const db = database(options);
  const result = await processLabResults("u1", "lab-1", biomarkers, db.client);
  return { result, inserted: db.inserted, update: db.labUpdates[0] };
}

/** The seed's rows with a critical field on the eGFR rows (the seed carries none yet): at or below 15. */
const WITH_CRITICAL = SEED.map((r) => (r.biomarker_key === "egfr_creatinine_based" ? { ...r, critical_low: 15, critical_high: null } : r));
/**
 * The same critical field on the rows the score runs on (the families' decided rows for the scoring markers): a
 * marker scores only through a graded band, so a lab scores on these and not on the seed as it stands.
 */
const SCORING_WITH_CRITICAL = signedRows().map((r) => (r.biomarker_key === "egfr_creatinine_based" ? { ...r, critical_low: 15, critical_high: null } : r));

describe("processing", () => {
  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  it("stores the laboratory's eGFR as a value only: no category and no interval, whatever the value", async () => {
    for (const value of [130, 95, 68, 40]) {
      const { result, inserted } = await processed([raw("egfr_creatinine_based", value), raw("creatinine", 1.0)]);
      const row = inserted.find((r) => r.biomarker_key === "egfr_creatinine_based")!;
      expect(row).toMatchObject({
        value, unit: "mL/min/1.73m²", zone: "unclassified", comparator: null,
        optimal_low: null, optimal_high: null, normal_low: null, normal_high: null,
        // Still shown with the kidney results.
        category: "kidneys",
      });
      expect(result.processed.find((p) => p.biomarkerKey === "egfr_creatinine_based")).toMatchObject({ zone: "unclassified", optimalLow: null, optimalHigh: null });
      // Creatinine, measured, keeps its own category and interval.
      expect(inserted.find((r) => r.biomarker_key === "creatinine")).toMatchObject({ zone: "optimal", optimal_low: 0.8, normal_high: 1.3 });
    }
  });

  it("the same holds for a report line matched by name, and for the legacy key", async () => {
    const { inserted } = await processed([
      { name: "Filtrado glomerular estimado", value: 52, unit: "mL/min/1.73m²" },
      { name: "eGFR", value: 51, unit: "mL/min/1.73m²", biomarkerKey: "egfr", matchConfidence: "user" },
    ]);
    expect(inserted).toHaveLength(2);
    for (const row of inserted) expect(row).toMatchObject({ biomarker_key: "egfr_creatinine_based", zone: "unclassified", optimal_low: null, normal_low: null });
  });

  it("computes its own eGFR from creatinine, sex and the age at the draw, classified on the eGFR row", async () => {
    // Drawn ten years ago, at 35: the value and the category are those of a 35-year-old's result on this row.
    const drawn = `${THIS_YEAR - 10}-06-01`;
    const { result } = await processed([raw("creatinine", 1.1)], { collectionDate: drawn });
    const m = result.calculatedMetrics.find((x) => x.metricKey === EGFR_METRIC_KEY)!;
    expect(m.value).toBe(Math.round(ckdEpi2021(1.1, AGE - 10, "male")));
    expect(m.value).not.toBe(Math.round(ckdEpi2021(1.1, AGE, "male")));
    expect(m.zone).toBe(zoneOnEgfrRow(m.value, "male", AGE));

    // No draw date: aged when computed.
    const undated = (await processed([raw("creatinine", 1.1)])).result.calculatedMetrics.find((x) => x.metricKey === EGFR_METRIC_KEY)!;
    expect(undated.value).toBe(Math.round(ckdEpi2021(1.1, AGE, "male")));

    // The laboratory's own figure beside it changes nothing.
    const withLab = (await processed([raw("creatinine", 1.1), raw("egfr_creatinine_based", 30)], { collectionDate: drawn })).result;
    expect(withLab.calculatedMetrics.find((x) => x.metricKey === EGFR_METRIC_KEY)).toEqual(m);
    // And nothing is stored under the laboratory's key for it.
    expect((await processed([raw("creatinine", 1.1)])).inserted.map((r) => r.biomarker_key)).toEqual(["creatinine"]);
  });

  it("computes no eGFR for a lab whose draw date lies in the future", async () => {
    const { result } = await processed([raw("creatinine", 1.1)], { collectionDate: "2999-01-01" });
    expect(result.calculatedMetrics.some((x) => x.metricKey === EGFR_METRIC_KEY)).toBe(false);
    expect(result.calculatedMetrics.every((x) => Number.isFinite(x.value))).toBe(true);
  });

  it("gives the computed eGFR no category when the lab's context declares pregnancy; its critical limit still counts", async () => {
    const pregnant = { labState: { supplements: null, state: { ...UNKNOWN_STATE, pregnancy: true } } };
    const egfrOf = async (options?: typeof pregnant, rows = SEED, value = 0.5) => {
      const db = database({ sex: "female", rows });
      const result = await processLabResults("u1", "lab-1", [raw("creatinine", value)], db.client, options);
      return { m: result.calculatedMetrics.find((x) => x.metricKey === EGFR_METRIC_KEY)!, result };
    };
    const plain = await egfrOf();
    expect(plain.m.zone).toBe("optimal");
    expect((await egfrOf(pregnant)).m).toEqual({ ...plain.m, zone: "unclassified" });
    // A computed eGFR at the critical limit is still in the critical tier in pregnancy (state-rules.md 2.1).
    const critical = await egfrOf(pregnant, WITH_CRITICAL, 3.7);
    expect(critical.m).toMatchObject({ value: 15, zone: "unclassified" });
    expect(critical.result.scoreWithheld).toBe("critical_value");
  });

  it("computes no eGFR for a profile whose sex is neither male nor female", async () => {
    const { result } = await processed([raw("creatinine", 1.1)], { sex: "other" });
    expect(result.calculatedMetrics.some((x) => x.metricKey === EGFR_METRIC_KEY)).toBe(false);
  });

  it("neither eGFR is a score input: the score is the same with, without, and whatever the laboratory's eGFR", async () => {
    const without = await processed(panel({ creatinine: 1.0 }));
    expect(without.update.longevity_score).toEqual(expect.any(Number));
    expect(without.result.calculatedMetrics.some((m) => m.metricKey === EGFR_METRIC_KEY)).toBe(true);
    for (const lab of [120, 95, 61, 40]) {
      const withLab = await processed(panel({ creatinine: 1.0, egfr_creatinine_based: lab }));
      expect(withLab.update.longevity_score, `laboratory eGFR ${lab}`).toBe(without.update.longevity_score);
      expect(withLab.result.fullBioAgeResult!.markerScores.map((m) => m.code)).toEqual(without.result.fullBioAgeResult!.markerScores.map((m) => m.code));
      expect(withLab.result.fullBioAgeResult!.markerScores.some((m) => m.code === "EGFR")).toBe(false);
    }
    // The computed eGFR does not score either: a creatinine that gives a low computed eGFR is charged as creatinine only.
    const low = await processed(panel({ creatinine: 1.6 }));
    expect(low.result.calculatedMetrics.find((m) => m.metricKey === EGFR_METRIC_KEY)).toMatchObject({ zone: "critical_low" });
    expect(low.result.fullBioAgeResult!.markerScores.some((m) => m.code === "EGFR")).toBe(false);
  });

  it("no stored key and no metric maps to the engine's EGFR code", () => {
    expect(DB_KEY_TO_ENGINE_CODE.egfr_creatinine_based).toBeUndefined();
    expect(DB_KEY_TO_ENGINE_CODE.egfr).toBeUndefined();
    expect(Object.values(DB_KEY_TO_ENGINE_CODE)).not.toContain("EGFR");
    const inputs = buildEngineInputs([
      { biomarkerKey: "creatinine", value: 1.0 }, { biomarkerKey: "egfr_creatinine_based", value: 95 }, { biomarkerKey: "egfr", value: 95 },
      { biomarkerKey: EGFR_METRIC_KEY, value: 95 },
    ]);
    expect(inputs).toEqual([{ code: "CREATININE", value: 1.0 }]);
  });

  it("the laboratory's eGFR still counts toward the critical tier: at or beyond a critical limit, no score", async () => {
    const atLimit = await processed(panel({ creatinine: 1.0, egfr_creatinine_based: 15 }), { rows: WITH_CRITICAL });
    expect(atLimit.result.scoreWithheld).toBe("critical_value");
    expect(atLimit.update).toMatchObject({ longevity_score: null, longevity_grade: null });
    // Shown as a value all the same.
    expect(atLimit.inserted.find((r) => r.biomarker_key === "egfr_creatinine_based")).toMatchObject({ value: 15, zone: "unclassified", normal_low: null });

    const above = await processed(panel({ creatinine: 1.0, egfr_creatinine_based: 16 }), { rows: SCORING_WITH_CRITICAL });
    expect(above.result.scoreWithheld).toBeNull();
    expect(above.update.longevity_score).toEqual(expect.any(Number));
    // A bound that only might be critical is not: ">10" is not at or below 15 for certain; "<15" is.
    const mightBe = await processed([...panel({ creatinine: 1.0 }), raw("egfr_creatinine_based", 10, ">")], { rows: WITH_CRITICAL });
    expect(mightBe.result.scoreWithheld).toBeNull();
    const below = await processed([...panel({ creatinine: 1.0 }), raw("egfr_creatinine_based", 15, "<")], { rows: WITH_CRITICAL });
    expect(below.result.scoreWithheld).toBe("critical_value");
  });

  it("the computed eGFR counts toward the critical tier too", async () => {
    // Creatinine 4.7 mg/dL in a 45-year-old man: a computed eGFR of 15 as reported; 4.5 mg/dL gives 16.
    expect(Math.round(ckdEpi2021(4.7, AGE, "male"))).toBe(15);
    expect(Math.round(ckdEpi2021(4.5, AGE, "male"))).toBe(16);
    const critical = await processed(panel({ creatinine: 4.7 }), { rows: WITH_CRITICAL });
    expect(critical.result.scoreWithheld).toBe("critical_value");
    expect(critical.update).toMatchObject({ longevity_score: null });
    const not = await processed(panel({ creatinine: 4.5 }), { rows: WITH_CRITICAL });
    expect(not.result.scoreWithheld).toBeNull();
  });

  describe("recomputing a lab stored before this rule", () => {
    const stored = (kidney: Stored[]): Stored[] => [
      ...Object.entries(PANEL).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal", comparator: null })),
      ...kidney,
    ];
    async function recomputed(values: Stored[], rows: Parameters<typeof database>[0] = {}) {
      const db = database({ stored: values, ...rows });
      await recomputeLabMetrics("u1", "lab-1", db.client as never);
      return db.labUpdates[0];
    }
    const creatinine = { biomarker_key: "creatinine", value: 1.0, zone: "optimal", comparator: null };

    it("a laboratory eGFR stored with a category is neither counted nor scored", async () => {
      const without = await recomputed(stored([creatinine]));
      for (const zone of ["optimal", "below_optimal", "critical_low"]) {
        const withLab = await recomputed(stored([creatinine, { biomarker_key: "egfr_creatinine_based", value: 40, zone, comparator: null }]));
        expect(withLab, zone).toMatchObject({
          optimal_count: without.optimal_count, attention_count: without.attention_count, action_count: without.action_count,
          longevity_score: without.longevity_score, longevity_grade: without.longevity_grade,
        });
      }
      expect(without.longevity_score).toEqual(expect.any(Number));
    });

    it("the critical tier still reads it, and the computed eGFR", async () => {
      const lab = await recomputed(stored([creatinine, { biomarker_key: "egfr_creatinine_based", value: 12, zone: "critical_low", comparator: null }]), { rows: WITH_CRITICAL });
      expect(lab).toMatchObject({ longevity_score: null, longevity_grade: null });
      const computed = await recomputed(stored([{ ...creatinine, value: 4.7, zone: "critical_high" }]), { rows: WITH_CRITICAL });
      expect(computed).toMatchObject({ longevity_score: null, longevity_grade: null });
      const neither = await recomputed(stored([creatinine, { biomarker_key: "egfr_creatinine_based", value: 40, zone: "critical_low", comparator: null }]), { rows: WITH_CRITICAL });
      expect(neither.longevity_score).toEqual(expect.any(Number));
    });
  });
});

// ─── 5. Readers ───

describe("readers show a laboratory eGFR as a value only", () => {
  const STORED = {
    id: "v1", lab_result_id: "lab-1", biomarker_key: "egfr_creatinine_based", biomarker_name: "eGFR", value: 52, unit: "mL/min/1.73m²",
    zone: "critical_low", optimal_low: 75, optimal_high: null, normal_low: 60, normal_high: null, comparator: null, category: "kidneys",
  };

  it("shownAsValueOnly removes the category and the interval of such a row, and touches nothing else", () => {
    expect(shownAsValueOnly(STORED)).toEqual({ ...STORED, zone: "unclassified", optimal_low: null, normal_low: null });
    expect(shownAsValueOnly({ ...STORED, biomarker_key: "egfr" })).toMatchObject({ zone: "unclassified", optimal_low: null, normal_low: null });
    const creatinine = { ...STORED, biomarker_key: "creatinine", zone: "optimal" };
    expect(shownAsValueOnly(creatinine)).toBe(creatinine);
    // Only the fields a row carries: a narrow select gains none.
    expect(shownAsValueOnly({ biomarker_key: "egfr_creatinine_based", value: 52 })).toEqual({ biomarker_key: "egfr_creatinine_based", value: 52 });
    // The reference row itself, read for a page about the laboratory's value: no interval beside the value.
    expect(shownAsValueOnly({ ...egfrRow("male", AGE) })).toMatchObject({ optimal_low: null, optimal_high: null, normal_low: null, normal_high: null, name_en: egfrRow("male", AGE).name_en });
    expect(isLabReportedValueOnly(null)).toBe(false);
  });

  it("the dashboard's read (getBiomarkerValues) returns it with no category and no interval", async () => {
    const creatinine = { ...STORED, id: "v2", biomarker_key: "creatinine", value: 1.0, zone: "optimal", optimal_low: 0.8, normal_low: 0.7 };
    const { client } = database({ stored: [STORED, creatinine] });
    const values = await getBiomarkerValues("lab-1", client);
    expect(values.find((v) => v.biomarker_key === "egfr_creatinine_based")).toMatchObject({ value: 52, zone: "unclassified", optimal_low: null, normal_low: null, category: "kidneys" });
    expect(values.find((v) => v.biomarker_key === "creatinine")).toEqual(creatinine);
  });

  it("a corrected laboratory eGFR stays a value only (the value-edit route)", async () => {
    const db = database({ stored: [{ ...STORED, lab_results: { user_id: "u1", collection_date: "2026-01-01" } }] });
    state.client = db.client;
    const res = await editValue(
      new NextRequest("http://localhost/api/biomarker-values/v1", { method: "PATCH", body: JSON.stringify({ value: 48 }) }),
      { params: Promise.resolve({ id: "v1" }) },
    );
    expect(res.status).toBe(200);
    expect(db.valueUpdates[0]).toMatchObject({
      biomarker_key: "egfr_creatinine_based", value: 48, zone: "unclassified",
      optimal_low: null, optimal_high: null, normal_low: null, normal_high: null,
    });
  });

  it("a corrected creatinine is still classified on its own row by the same route", async () => {
    const stored = { ...STORED, biomarker_key: "creatinine", unit: "mg/dL", value: 1.0, zone: "optimal", lab_results: { user_id: "u1", collection_date: "2026-01-01" } };
    const db = database({ stored: [stored] });
    state.client = db.client;
    const res = await editValue(
      new NextRequest("http://localhost/api/biomarker-values/v1", { method: "PATCH", body: JSON.stringify({ value: 1.2 }) }),
      { params: Promise.resolve({ id: "v1" }) },
    );
    expect(res.status).toBe(200);
    expect(db.valueUpdates[0]).toMatchObject({ biomarker_key: "creatinine", value: 1.2, zone: "above_optimal", optimal_high: 1.1, normal_high: 1.3 });
  });
});
