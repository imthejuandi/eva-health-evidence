/**
 * Reprocessing never keeps a biological age the lab's values no longer give. When the KDM gate fails, the
 * stored Reference and Comprehensive BA are cleared; when it passes, they are written. The case that matters:
 * a result whose stored BA read measured fructosamine, which the model now sets aside.
 * Scripted database (fake-supabase), no network.
 */
import { beforeAll, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { getCanonicalUnit } from "./canonical-units";
import { computeComprehensiveBA, computeReferenceBA, KDM_REFERENCE_BA_METHOD } from "./biological-age-kdm";
import { processLabResults, recomputeLabMetrics } from "./process-results";
import { reviewedRows } from "./__tests__/fixtures/reviewed-rows";

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));

// processLabResults upserts the biological age v3 shadow record with the service-role client: a scripted one here,
// so the test never reaches a real database (process-results.bio-age-v3.test.ts covers that write).
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});

const ROWS = reviewedRows();
const AGE = 45;
// The Base Panel without hs-CRP, uric acid and ALP, and no HbA1c: with measured fructosamine set aside,
// 7 of the 8 base markers the gate requires.
const SHORT: Record<string, number> = {
  albumin: 44, creatinine: 1.0, bun: 15, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47, triglycerides: 140,
  fructosamine: 190, apolipoprotein_b_apob: 105, alt: 30,
};
// The same tests with HbA1c 5.5%: 8 base markers, the gate passes.
const FULL: Record<string, number> = { ...SHORT, hba1c: 5.5 };
const BA_COLUMNS = ["biological_age", "bio_age_method", "bio_age_n_markers", "bio_age_applied_spanish_calibration", "biological_age_comprehensive"];

const asInputs = (values: Record<string, number>) => Object.entries(values).map(([code, value]) => ({ code, value }));

function database(values: Record<string, number>) {
  const dob = `${new Date().getFullYear() - AGE}-01-01`;
  const updates: Array<Record<string, unknown>> = [];
  const respond = (c: FakeCall): FakeResponse => {
    if (c.table === "profiles" && ops(c).startsWith("select")) return { data: { date_of_birth: dob, sex: "male" } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    if (c.table === "biomarker_values" && ops(c).startsWith("select")) {
      return { data: Object.entries(values).map(([biomarker_key, value]) => ({ biomarker_key, value, zone: "optimal" })) };
    }
    if (c.table === "lab_results" && ops(c).startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      if ("optimal_count" in update) updates.push(update);
    }
    return { data: null };
  };
  return { client: fakeSupabase(respond).client, updates };
}

const raw = (values: Record<string, number>) =>
  Object.entries(values).map(([key, value]) => ({
    name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const,
  }));

describe("a biological age the values no longer give is cleared, not kept", () => {
  beforeAll(() => {
    vi.spyOn(console, "log").mockImplementation(() => {});
    vi.spyOn(console, "warn").mockImplementation(() => {});
    vi.spyOn(console, "error").mockImplementation(() => {});
    // The premise: one panel fails the gate, the other passes.
    expect(computeReferenceBA(asInputs(SHORT), "male", AGE, { supplements: null })).toBeNull();
    expect(computeReferenceBA(asInputs(FULL), "male", AGE, { supplements: null })).not.toBeNull();
  });

  it("recomputeLabMetrics: the gate fails, every biological-age column is written as null", async () => {
    const db = database(SHORT);
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    expect(db.updates).toHaveLength(1);
    for (const col of BA_COLUMNS) {
      expect(db.updates[0], col).toHaveProperty(col);
      expect(db.updates[0][col], col).toBeNull();
    }
  });

  it("recomputeLabMetrics: the gate passes, the new biological age is written", async () => {
    const db = database(FULL);
    await recomputeLabMetrics("u1", "lab-1", db.client as never);
    const reference = computeReferenceBA(asInputs(FULL), "male", AGE, { supplements: null })!;
    const comprehensive = computeComprehensiveBA(asInputs(FULL), "male", AGE, { supplements: null });
    expect(db.updates[0]).toMatchObject({
      biological_age: reference.BA,
      bio_age_method: KDM_REFERENCE_BA_METHOD,
      bio_age_n_markers: reference.n_markers_used,
      biological_age_comprehensive: comprehensive?.BA ?? null,
    });
  });

  it("processLabResults (the reprocess route): the gate fails, every biological-age column is written as null", async () => {
    const db = database(SHORT);
    const result = await processLabResults("u1", "lab-1", raw(SHORT), db.client);
    expect(result.kdmBiologicalAge?.reference ?? null).toBeNull();
    for (const col of BA_COLUMNS) expect(db.updates[0][col], col).toBeNull();
  });

  it("processLabResults: the gate passes, the new biological age is written", async () => {
    const db = database(FULL);
    await processLabResults("u1", "lab-1", raw(FULL), db.client);
    expect(db.updates[0].biological_age).toEqual(expect.any(Number));
    expect(db.updates[0].bio_age_method).toBe(KDM_REFERENCE_BA_METHOD);
  });
});
