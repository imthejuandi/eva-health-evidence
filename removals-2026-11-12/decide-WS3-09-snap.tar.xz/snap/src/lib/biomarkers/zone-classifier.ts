import { ZONE_CONFIG, type Zone } from "./zone-config";

// Re-export client-safe types and config
export { ZONE_CONFIG, type Zone };

// ─── Age ───

/**
 * Parse a date-of-birth string tolerantly. Handles:
 *   - ISO: "1990-03-15" or "1990-03-15T00:00:00Z"
 *   - European: "15/03/1990" or "15-03-1990"
 *   - US: "03/15/1990" (only when unambiguous — month > 12 on the EU side)
 *   - Reverse: "1990/03/15"
 * Returns a valid Date or null.
 */
export function parseDateOfBirth(dob: string): Date | null {
  if (!dob || typeof dob !== "string") return null;
  const trimmed = dob.trim();

  // 1. ISO date (YYYY-MM-DD, optionally with time)
  const isoMatch = trimmed.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (isoMatch) {
    const [, y, m, d] = isoMatch;
    const date = new Date(Number(y), Number(m) - 1, Number(d));
    return isNaN(date.getTime()) ? null : date;
  }

  // 2. YYYY/MM/DD
  const revSlash = trimmed.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (revSlash) {
    const [, y, m, d] = revSlash;
    const date = new Date(Number(y), Number(m) - 1, Number(d));
    return isNaN(date.getTime()) ? null : date;
  }

  // 3. DD/MM/YYYY or DD-MM-YYYY (European — our default in the UI)
  const euMatch = trimmed.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/);
  if (euMatch) {
    const [, aStr, bStr, yStr] = euMatch;
    const a = Number(aStr);
    const b = Number(bStr);
    const y = Number(yStr);
    // If "a" > 12 it can't be a month — it's DD/MM/YYYY
    // If "b" > 12 it can't be a month — must be MM/DD/YYYY
    // Otherwise default to European DD/MM/YYYY (placeholder hint matches)
    let day: number, month: number;
    if (a > 12) { day = a; month = b; }
    else if (b > 12) { day = b; month = a; }
    else { day = a; month = b; }
    const date = new Date(y, month - 1, day);
    return isNaN(date.getTime()) ? null : date;
  }

  // 4. Last resort: let Date parse it
  const fallback = new Date(trimmed);
  return isNaN(fallback.getTime()) ? null : fallback;
}

export function calculateAge(dob: string): number {
  const birth = parseDateOfBirth(dob);
  if (!birth) return NaN;
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

// ─── Core zone logic ───

export function classifyZone(
  value: number,
  optimalLow: number | null,
  optimalHigh: number | null,
  normalLow: number | null,
  normalHigh: number | null,
): Zone {
  // Three categories, each side judged on its own:
  //   out of range  — outside the reference range (normal_low … normal_high) → critical_low / critical_high
  //   in range      — inside the reference range, outside the optimal band   → below_optimal / above_optimal
  //   optimal       — inside the optimal band (a null bound means no limit on that side)
  // The reference limits always win: a value above normal_high is out of range even when the row has
  // no optimal ceiling, or an optimal ceiling above normal_high.
  // A row with no bounds at all (e.g. free PSA, read only as a ratio) cannot place a value in any category.
  if (normalLow == null && normalHigh == null && optimalLow == null && optimalHigh == null) return "unclassified";
  if (normalLow != null && value < normalLow) return "critical_low";
  if (normalHigh != null && value > normalHigh) return "critical_high";
  if (optimalLow != null && value < optimalLow) return "below_optimal";
  if (optimalHigh != null && value > optimalHigh) return "above_optimal";
  return "optimal";
}
