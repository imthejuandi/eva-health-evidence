/**
 * The eGFR the app computes (ruling D-28): one declared equation, from the measured creatinine, the age at the draw
 * and sex.
 *
 * The equation is data (data/egfr-equation.json: its name, its constants, its units, its source); which equation
 * EVA uses is the physician's choice. This module implements the equations it knows by name (IMPLEMENTED: CKD-EPI
 * 2021 only) and reads every number from the data file. A declared equation it does not implement, a constant that
 * is not a number, or a creatinine unit other than the one results are stored in computes nothing: there is no
 * default equation and no default constant.
 *
 * The creatinine is the measured one, as stored (mg/dL): never divided by a creatine factor (that adjustment is the
 * biological age's own, biological-age-kdm.ts). Sex is "male" or "female"; anything else computes nothing.
 *
 * calculated-metrics.ts turns the value into the `egfr_computed` metric and classifies it against the reviewed
 * eGFR rows. A laboratory's own eGFR is another thing (lab-reported.ts).
 */
import equationData from "./data/egfr-equation.json";
import { getCanonicalUnit, normalizeUnit } from "./canonical-units";
import { parseDateOfBirth } from "./zone-classifier";

/** The declared equation, as the data file gives it. `constants` is read by the implementation the name selects. */
export interface EgfrEquation {
  equation: string;
  creatinine_unit: string;
  result_unit: string;
  /** The decimals the result is reported with; the category is that of the reported value. */
  result_decimals: number;
  /** The youngest age (completed years) the equation is computed for. */
  min_age_years: number;
  constants: unknown;
}

export const EGFR_EQUATION: EgfrEquation = equationData;

/** The key creatinine results are stored under, and the key of the metric (never the laboratory eGFR's key). */
export const EGFR_CREATININE_KEY = "creatinine";
export const EGFR_METRIC_KEY = "egfr_computed";

type Sex = "male" | "female";
type Formula = (creatinine: number, age: number, sex: Sex) => number;

const isNumber = (x: unknown): x is number => typeof x === "number" && Number.isFinite(x);

/** CKD-EPI 2021 with the constants given; null when one of them is missing or not a number. */
function ckdEpi2021(constants: unknown): Formula | null {
  const c = (constants ?? {}) as { scale?: unknown; exponent_above_kappa?: unknown; age_base?: unknown } & Record<Sex, unknown>;
  const bySex = (s: Sex) => (c[s] ?? {}) as { kappa?: unknown; alpha?: unknown; factor?: unknown };
  const { scale, exponent_above_kappa: above, age_base: ageBase } = c;
  if (!isNumber(scale) || !isNumber(above) || !isNumber(ageBase)) return null;
  for (const s of ["male", "female"] as const) {
    const { kappa, alpha, factor } = bySex(s);
    if (!isNumber(kappa) || kappa <= 0 || !isNumber(alpha) || !isNumber(factor)) return null;
  }
  return (creatinine, age, sex) => {
    const { kappa, alpha, factor } = bySex(sex) as { kappa: number; alpha: number; factor: number };
    const r = creatinine / kappa;
    return scale * Math.min(r, 1) ** alpha * Math.max(r, 1) ** above * ageBase ** age * factor;
  };
}

/** The equations this code implements, by the name the data file declares. */
const IMPLEMENTED: Readonly<Record<string, (constants: unknown) => Formula | null>> = {
  ckd_epi_2021: ckdEpi2021,
};

/** Whether the code implements the declared equation. */
export function isEgfrEquationImplemented(equation: EgfrEquation = EGFR_EQUATION): boolean {
  return Object.hasOwn(IMPLEMENTED, equation?.equation);
}

function sexOf(sex: unknown): Sex | null {
  const s = typeof sex === "string" ? sex.trim().toLowerCase() : "";
  return s === "male" || s === "female" ? s : null;
}

/**
 * eGFR in the equation's result unit, unrounded, from a measured creatinine in the unit creatinine results are
 * stored in. Null (nothing is computed) when: the declared equation is not implemented or its constants cannot be
 * read; it takes creatinine in another unit than the stored one; sex is not male or female; the age is not a number
 * or is below the equation's minimum; the creatinine is not a positive number; or the result is not a positive
 * number.
 */
export function computeEgfr(
  input: { creatinine: number; age: number; sex: unknown },
  equation: EgfrEquation = EGFR_EQUATION,
): number | null {
  if (!equation || !isEgfrEquationImplemented(equation)) return null;
  const formula = IMPLEMENTED[equation.equation](equation.constants);
  if (!formula) return null;
  const storedUnit = getCanonicalUnit(EGFR_CREATININE_KEY);
  if (storedUnit === null || typeof equation.creatinine_unit !== "string") return null;
  if (normalizeUnit(storedUnit) !== normalizeUnit(equation.creatinine_unit)) return null;
  const sex = sexOf(input.sex);
  if (!sex) return null;
  if (!isNumber(equation.min_age_years) || !isNumber(input.age) || input.age < equation.min_age_years) return null;
  if (!isNumber(input.creatinine) || input.creatinine <= 0) return null;
  const value = formula(input.creatinine, input.age, sex);
  return isNumber(value) && value > 0 ? value : null;
}

/**
 * The eGFR as reported: rounded to the decimals the equation declares. Null when it declares none that can be read
 * (a whole number from 0 to 3), or when `value` is null.
 */
export function reportedEgfr(value: number | null, equation: EgfrEquation = EGFR_EQUATION): number | null {
  const decimals = equation?.result_decimals;
  if (value === null || !Number.isInteger(decimals) || decimals < 0 || decimals > 3) return null;
  const scale = 10 ** decimals;
  return Math.round(value * scale) / scale;
}

/**
 * Completed years at the draw: the lab's collection date ("YYYY-MM-DD", or a timestamp starting with it) against
 * the date of birth, with zone-classifier.calculateAge's arithmetic and date-of-birth parsing (the rule the
 * biological age uses, biological-age-v3-adapter.ts completedYearsAt). A result with no readable draw date is aged
 * at `now`, as there. NaN (no age, so nothing is computed from it) when the date of birth cannot be read, and when
 * the draw date cannot be a draw date: later than `now`, or before the date of birth.
 */
export function ageAtDraw(dateOfBirth: string | null | undefined, collectionDate: string | null | undefined, now: Date = new Date()): number {
  if (typeof dateOfBirth !== "string") return NaN;
  const birth = parseDateOfBirth(dateOfBirth);
  const asOf = drawDate(collectionDate) ?? now;
  if (!birth || isNaN(asOf.getTime())) return NaN;
  if (asOf.getTime() > now.getTime() || asOf.getTime() < birth.getTime()) return NaN;
  let age = asOf.getFullYear() - birth.getFullYear();
  const m = asOf.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && asOf.getDate() < birth.getDate())) age--;
  return age;
}

/** A real calendar date at the start of the string, as a local date (as parseDateOfBirth reads the birth date). */
function drawDate(s: string | null | undefined): Date | null {
  const m = typeof s === "string" ? /^(\d{4})-(\d{2})-(\d{2})/.exec(s.trim()) : null;
  if (!m) return null;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const date = new Date(y, mo - 1, d);
  return date.getFullYear() === y && date.getMonth() === mo - 1 && date.getDate() === d ? date : null;
}
