/**
 * No guessed marker key. A result is stored, classified and scored only under the key it was matched to: the
 * reference row is looked up by that exact key (after the explicit aliases of key-aliases.ts), never by containment
 * between keys. A result whose key has no row for the person is stored under its own key, unclassified, with no
 * reference fields, and is not a score input; it never sets the critical tier.
 *
 * The case that showed the fault: a fasting glucose whose row was missing was stored and classified as AST, because
 * "glucose_fasting" contains "ast". Scripted database (fake-supabase), no network.
 */
import { beforeAll, describe, expect, it, vi } from "vitest";
import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { classifyResultZone } from "./bounded-result";
import { getCanonicalUnit } from "./canonical-units";
import { buildEngineInputs } from "./engine-inputs";
import { MATCHER_TO_SEED_KEY, remapToSeedKey } from "./key-aliases";
import { calculateLongevityScoreV2 } from "./longevity-score";
import { processLabResults, type RawBiomarker } from "./process-results";
import { pickReferenceRows } from "./reference-row";
import { reviewedRows, signedRows } from "./__tests__/fixtures/reviewed-rows";

vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the tests pass their own client");
  },
}));
// The biological age v3 shadow record is written with the service-role client: a scripted one, never a database.
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return { createAdminClient: () => fakeSupabase(() => ({ data: null })).client };
});

type Row = ReturnType<typeof reviewedRows>[number] & { critical_low?: number | null; critical_high?: number | null };
type Inserted = {
  biomarker_key: string; value: number; zone: string; category: string;
  optimal_low: number | null; optimal_high: number | null; normal_low: number | null; normal_high: number | null;
};

const SEED: Row[] = signedRows();
const USER = "22222222-2222-4222-8222-222222222222";
const LAB = "33333333-3333-4333-8333-333333333333";
const AGE = 45;

/** The reference rows without those of the given keys: the markers whose row is missing. */
const without = (rows: readonly Row[], ...keys: string[]) => rows.filter((r) => !keys.includes(r.biomarker_key));

/** A database holding the given reference rows, for a person of the given sex; `inserted` collects what is stored. */
function database(rows: readonly Row[], sex: "male" | "female" = "male") {
  const inserted: Inserted[] = [];
  const respond = (c: FakeCall): FakeResponse => {
    const op = ops(c);
    if (c.table === "profiles" && op.startsWith("select")) return { data: { date_of_birth: `${new Date().getFullYear() - AGE}-01-01`, sex } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: rows.filter((r) => sexes.includes(r.sex ?? "")) };
    }
    if (c.table === "biomarker_values" && op.startsWith("insert")) inserted.push(...(argsOf(c, "insert")?.[0] as Inserted[]));
    return { data: null };
  };
  return { client: fakeSupabase(respond).client, inserted };
}

/** Results as a caller that already holds the key passes them (confirm, admin, webhook, reprocess). */
const rawOf = (values: Record<string, number>, units: Record<string, string> = {}): RawBiomarker[] =>
  Object.entries(values).map(([key, value]) => ({
    name: key, value, unit: units[key] ?? getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const,
  }));

const NO_REFERENCE = { optimal_low: null, optimal_high: null, normal_low: null, normal_high: null };

// The Base Panel with HbA1c, hs-CRP, uric acid and haemoglobin (nine scoring markers in five domains, so it is
// scored), a fasting glucose and an AST.
const PANEL: Record<string, number> = {
  albumin: 44, creatinine: 1.0, bun: 15, ggt: 32, total_cholesterol: 205, hdl_cholesterol: 47, triglycerides: 140,
  fructosamine: 190, apolipoprotein_b_apob: 105, alt: 30, hba1c: 5.5, hs_crp: 1.8, glucose_fasting: 110, ast: 25,
  uric_acid: 5.5, hemoglobin: 15,
};
const scoreOf = (values: Record<string, number>, rows: readonly Row[] = SEED) =>
  calculateLongevityScoreV2(buildEngineInputs(Object.entries(values).map(([biomarkerKey, value]) => ({ biomarkerKey, value }))), "male", AGE, [...rows]);

beforeAll(() => {
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
});

describe("a fasting glucose whose row is missing is not stored, classified or scored as AST", () => {
  const { glucose_fasting: _glucose, ...NO_GLUCOSE } = PANEL;
  void _glucose;

  it("the premise: with its row the glucose is classified and reaches the score, where HbA1c takes its group's place", async () => {
    const db = database(SEED);
    const result = await processLabResults(USER, LAB, rawOf(PANEL), db.client);
    expect(db.inserted.find((v) => v.biomarker_key === "glucose_fasting")).toMatchObject({ zone: "critical_high", category: "metabolic" });
    expect(result.fullBioAgeResult!.suppressedMarkers.find((m) => m.code === "GLUCOSE")).toMatchObject({ zone: "critical_high", suppressedBy: "HBA1C" });
    expect(scoreOf(PANEL).markersMeasured).toBe(scoreOf(NO_GLUCOSE).markersMeasured + 1);
  });

  it("stored as glucose_fasting, unclassified, with no reference fields; the AST result is the only AST", async () => {
    const db = database(without(SEED, "glucose_fasting"));
    const result = await processLabResults(USER, LAB, rawOf(PANEL), db.client);

    const glucose = db.inserted.filter((v) => v.biomarker_key === "glucose_fasting");
    expect(glucose).toHaveLength(1);
    expect(glucose[0]).toMatchObject({ value: 110, zone: "unclassified", category: "uncategorized", ...NO_REFERENCE });
    expect(db.inserted.filter((v) => v.biomarker_key === "ast").map((v) => v.value)).toEqual([25]);
    expect(result.processed.find((p) => p.biomarkerKey === "glucose_fasting")).toMatchObject({ zone: "unclassified", optimalLow: null, optimalHigh: null });
    expect(result.missingRefKeys).toEqual(["glucose_fasting"]);
  });

  it("does not reach the score inputs: the score is the panel's without the glucose", async () => {
    const rows = without(SEED, "glucose_fasting");
    const result = await processLabResults(USER, LAB, rawOf(PANEL), database(rows).client);
    const scored = result.fullBioAgeResult!;
    expect([...scored.markerScores, ...scored.suppressedMarkers, ...scored.excludedMarkers].some((m) => m.code === "GLUCOSE")).toBe(false);
    expect(scored.markersMeasured).toBe(scoreOf(NO_GLUCOSE, rows).markersMeasured);
    expect(scored.longevityScore).toBe(scoreOf(NO_GLUCOSE, rows).longevityScore);
  });

  it("alone, with only the AST row to be mistaken for: still glucose_fasting, and nothing is stored as AST", async () => {
    const db = database(SEED.filter((r) => r.biomarker_key === "ast"));
    await processLabResults(USER, LAB, rawOf({ glucose_fasting: 110 }, { glucose_fasting: "mg/dL" }), db.client);
    expect(db.inserted.map((v) => v.biomarker_key)).toEqual(["glucose_fasting"]);
    expect(db.inserted[0]).toMatchObject({ zone: "unclassified", ...NO_REFERENCE });
  });

  it("never sets the critical tier: a critical limit on the AST row does not withhold the score for a glucose of 110", async () => {
    // AST's row with a critical limit the glucose value is beyond and the AST value is not.
    const rows = without(SEED, "glucose_fasting").map((r) => (r.biomarker_key === "ast" ? { ...r, critical_high: 100 } : r));
    const result = await processLabResults(USER, LAB, rawOf(PANEL), database(rows).client);
    expect(result.scoreWithheld).toBeNull();
    expect(result.biologicalAge?.longevityScore).toBe(scoreOf(NO_GLUCOSE, rows).longevityScore);

    // The control: the same limit does withhold when the AST result itself is beyond it.
    const beyond = await processLabResults(USER, LAB, rawOf({ ...PANEL, ast: 140 }), database(rows).client);
    expect(beyond.scoreWithheld).not.toBeNull();
  });
});

describe("a key with no row is never joined to a row whose key contains it or is contained in it", () => {
  // [the result's key, a key with a row that contains it or is contained in it, the person's sex]
  const PAIRS: Array<[string, string, "male" | "female"]> = [
    // contained in another key
    ["hdl_cholesterol", "non_hdl_cholesterol", "male"],
    ["albumin", "microalbumin_urine", "male"],
    ["mch", "mchc", "male"],
    ["bun", "bun_creatinine_ratio", "male"],
    ["lymphocytes", "lymphocytes_absolute", "male"],
    ["total_cholesterol", "total_cholesterol_hdl_ratio", "male"],
    // contains another key
    ["insulin_fasting", "ast", "male"],
    ["mchc", "mch", "male"],
    ["egfr_creatinine_based", "creatinine", "male"],
    ["thyroglobulin_antibodies_tgab", "globulin", "male"],
    ["neutrophils_absolute", "neutrophils", "male"],
  ];

  it.each(PAIRS)("%s without its row is stored as itself, not as %s", async (key, other) => {
    expect(key.includes(other) || other.includes(key)).toBe(true);
    const rows = without(SEED, key);
    expect(rows.some((r) => r.biomarker_key === other)).toBe(true);

    const db = database(rows);
    const result = await processLabResults(USER, LAB, rawOf({ [key]: 1 }), db.client);
    expect(db.inserted.map((v) => v.biomarker_key)).toEqual([key]);
    expect(db.inserted[0]).toMatchObject({ zone: "unclassified", category: "uncategorized", ...NO_REFERENCE });
    expect(result.missingRefKeys).toEqual([key]);
  });

  it("a marker with rows for the other sex only (PSA for a woman) is stored as itself, unclassified", async () => {
    expect(SEED.filter((r) => r.biomarker_key === "psa_total").map((r) => r.sex)).toEqual(expect.arrayContaining(["male"]));
    const db = database(SEED, "female");
    await processLabResults(USER, LAB, rawOf({ psa_total: 1 }), db.client);
    expect(db.inserted.map((v) => v.biomarker_key)).toEqual(["psa_total"]);
    expect(db.inserted[0]).toMatchObject({ zone: "unclassified", ...NO_REFERENCE });
  });

  it("the same through the name matcher: a matched name whose row is missing keeps the matched key", async () => {
    const db = database(without(SEED, "glucose_fasting"));
    await processLabResults(USER, LAB, [{ name: "Glucosa", value: 110, unit: "mg/dL" }], db.client);
    expect(db.inserted.map((v) => v.biomarker_key)).toEqual(["glucose_fasting"]);
    expect(db.inserted[0]).toMatchObject({ zone: "unclassified", ...NO_REFERENCE });
  });
});

describe("the pairs the containment lookup joined rightly are explicit aliases, each classified against its row", () => {
  // Reference rows for the targets the seed has no row for, so that every alias has a row to classify against.
  // The bounds are test values, not clinical ones.
  const testRow = (biomarker_key: string): Row => ({
    ...SEED.find((r) => r.biomarker_key === "vitamin_b12")!,
    biomarker_key, sex: "both", age_group_en: "All Adults", normal_low: 10, normal_high: 100, optimal_low: 20, optimal_high: 60,
  });
  const ROWS: Row[] = [...SEED, ...["apolipoprotein_a1_apoa1", "copper_serum", "folate_vitamin_b9", "selenium_serum"].map(testRow)];

  // [the key a stored row or a caller may carry, the key of its row, the person's sex]
  const ALIASES: Array<[string, string, "male" | "female"]> = [
    ["amh", "anti_mullerian_hormone_amh", "female"],
    ["apolipoprotein_a1", "apolipoprotein_a1_apoa1", "male"],
    ["calcium", "calcium_serum", "male"],
    ["copper", "copper_serum", "male"],
    ["dha", "omega_3_dha", "male"],
    ["epa", "omega_3_epa", "male"],
    ["folate", "folate_vitamin_b9", "male"],
    ["methylmalonic_acid", "methylmalonic_acid_mma", "male"],
    ["microalbumin", "microalbumin_urine", "male"],
    ["selenium", "selenium_serum", "male"],
  ];

  it.each(ALIASES)("%s is %s: stored under that key and classified against its row", async (alias, target, sex) => {
    expect(MATCHER_TO_SEED_KEY[alias]).toBe(target);
    const unit = getCanonicalUnit(target) ?? "";
    expect(remapToSeedKey(alias, unit)).toBe(target);

    const row = pickReferenceRows(ROWS.filter((r) => r.sex === sex || r.sex === "both"), sex, AGE).picked.get(target)!;
    expect(row).toBeDefined();
    // A value inside the row's bounds where it has two, else just past the one it has.
    const [low, high] = [row.normal_low ?? row.optimal_low, row.normal_high ?? row.optimal_high];
    const value = low != null && high != null ? (low + high) / 2 : (high ?? low ?? 1) * 0.5;
    const expected = classifyResultZone(value, undefined, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high);
    expect(expected).not.toBe("unclassified");

    const db = database(ROWS, sex);
    const result = await processLabResults(USER, LAB, [{ name: alias, value, unit, biomarkerKey: alias, matchConfidence: "exact" }], db.client);
    expect(db.inserted.map((v) => v.biomarker_key)).toEqual([target]);
    expect(db.inserted[0]).toMatchObject({
      value, zone: expected, category: row.panel_category,
      optimal_low: row.optimal_low, optimal_high: row.optimal_high, normal_low: row.normal_low, normal_high: row.normal_high,
    });
    expect(result.missingRefKeys).toEqual([]);
  });

  it("an alias is a written pair, not a pattern: keys that only resemble a row's key are left as they are", () => {
    for (const key of ["glucose", "cholesterol", "iron", "ana", "calprotectin", "vitamin_e_alpha_tocopherol", "a"]) {
      expect(remapToSeedKey(key, "")).toBe(key);
    }
  });

  it("an aliased key in the wrong unit is refused by the unit gate of its row, as its own key would be", async () => {
    const db = database(ROWS);
    const result = await processLabResults(USER, LAB, [{ name: "calcium", value: 9.5, unit: "pg/mL", biomarkerKey: "calcium", matchConfidence: "exact" }], db.client);
    expect(db.inserted).toEqual([]);
    expect(result.unmatched).toEqual([expect.objectContaining({ name: "calcium", reason: "unit_mismatch", expectedUnit: getCanonicalUnit("calcium_serum") })]);
  });
});
