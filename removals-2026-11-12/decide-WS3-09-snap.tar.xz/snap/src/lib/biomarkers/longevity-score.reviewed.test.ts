/**
 * The longevity score on the reviewed ranges (score 2.0, the only score).
 */
import { describe, expect, it } from "vitest";
import {
  calculateLongevityScoreV2,
  isCriticalValue,
  OUT_OF_RANGE_CAP,
  REVIEWED_ROW_KEY,
  reviewedPenalty,
  rowEligibilityKey,
  SCORE_SPEC,
  withheldByContext,
  type BiomarkerInput,
  type ReviewedRange,
  type ReviewedRow,
  type ScoreSpec,
} from "./longevity-score";
import { classifyZone } from "./zone-classifier";
import { pickReferenceRows } from "./reference-row";
import { DB_KEY_TO_ENGINE_CODE } from "./name-matcher";
import { unitsMatch } from "./canonical-units";
import { buildEngineInputs } from "./engine-inputs";
import { formatLongevityGrade } from "@/lib/dashboard-format";
import { reviewedRows, signedRows } from "./__tests__/fixtures/reviewed-rows";

// mulberry32: the same "random" rows and values on every run.
function random(seed: number): () => number {
  return () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const range = (optimal_low: number | null, optimal_high: number | null, normal_low: number | null, normal_high: number | null): ReviewedRange => ({
  optimal_low, optimal_high, normal_low, normal_high,
});

// A row as the reviewed data has them: reference limits outside or on the optimal bounds, any of the four
// missing (at least one present), a reference floor sometimes 0, values from 0.1 to 100 000.
function randomRow(rnd: () => number): ReviewedRange {
  const scale = 10 ** (rnd() * 6 - 1);
  const [a, b, c, d] = [rnd(), rnd(), rnd(), rnd()].map((x) => x * scale).sort((x, y) => x - y);
  const oL = rnd() < 0.75 ? b : null;
  const oH = rnd() < 0.75 ? c : null;
  const nL = rnd() < 0.7 ? (oL != null && rnd() < 0.25 ? oL : rnd() < 0.1 ? 0 : a) : null;
  const nH = rnd() < 0.7 ? (oH != null && rnd() < 0.25 ? oH : d) : null;
  return [oL, oH, nL, nH].every((x) => x == null) ? randomRow(rnd) : range(oL, oH, nL, nH);
}

const ROWS = (() => {
  const rnd = random(20260928);
  return Array.from({ length: 3000 }, () => randomRow(rnd));
})();

const boundsOf = (r: ReviewedRange) => [r.optimal_low, r.optimal_high, r.normal_low, r.normal_high].filter((x): x is number => x != null);
const spanOf = (r: ReviewedRange) => Math.max(...boundsOf(r).map(Math.abs), 1);
// A probe distance far below every width the penalty divides by (bands, 25% widths), so a continuous
// penalty moves by less than 1e-6 across it.
function probe(r: ReviewedRange): number {
  const widths = [...boundsOf(r).map((x) => 0.25 * Math.abs(x))];
  const sorted = [...boundsOf(r)].sort((x, y) => x - y);
  for (let i = 1; i < sorted.length; i++) widths.push(sorted[i] - sorted[i - 1]);
  return 1e-7 * Math.min(...widths.filter((w) => w > 0), spanOf(r));
}
const show = (r: ReviewedRange) => `[${r.optimal_low}, ${r.optimal_high}] ref [${r.normal_low}, ${r.normal_high}]`;

describe("reviewedPenalty: worked examples", () => {
  const ldl = range(null, 60, 0, 100);
  const vitaminD = range(30, 50, 30, 100); // optimal and reference share 30: no band below
  const egfr60 = range(65, 105, 60, null); // no reference limit above 105

  it("costs nothing anywhere in the optimal band", () => {
    for (const v of [0, 45, 60]) expect(reviewedPenalty(v, ldl)).toBe(0);
    for (const v of [30, 40, 50]) expect(reviewedPenalty(v, vitaminD)).toBe(0);
  });

  it("in range: 0.4 × (d / band)²", () => {
    expect(reviewedPenalty(80, ldl)).toBeCloseTo(0.4 * (20 / 40) ** 2, 12);
    expect(reviewedPenalty(100, ldl)).toBeCloseTo(0.4, 12);
    expect(reviewedPenalty(62, egfr60)).toBeCloseTo(0.4 * (3 / 5) ** 2, 12);
  });

  it("out of range: 0.4 + 0.6 × min(e / w, 1), w the band on that side", () => {
    expect(reviewedPenalty(120, ldl)).toBeCloseTo(0.4 + 0.6 * (20 / 40), 12);
    expect(reviewedPenalty(140, ldl)).toBeCloseTo(1, 12);
    expect(reviewedPenalty(400, ldl)).toBe(1);
    expect(reviewedPenalty(57.5, egfr60)).toBeCloseTo(0.4 + 0.6 * (2.5 / 5), 12);
  });

  it("out of range on a side with no band: w is 25% of the limit", () => {
    expect(reviewedPenalty(24, vitaminD)).toBeCloseTo(0.4 + 0.6 * (6 / 7.5), 12); // 0.88
    expect(reviewedPenalty(22.5, vitaminD)).toBeCloseTo(1, 12);
    // A limit of 0 has no width: only a negative value is past it, at the full weight.
    expect(reviewedPenalty(-0.001, ldl)).toBe(1);
  });

  it("a side with an optimal bound and no reference limit is in range only, up to 0.4", () => {
    expect(reviewedPenalty(115, egfr60)).toBeCloseTo(0.4 * (10 / 26.25) ** 2, 12);
    expect(reviewedPenalty(131.25, egfr60)).toBeCloseTo(0.4, 12);
    expect(reviewedPenalty(400, egfr60)).toBeCloseTo(0.4, 12);
  });
});

describe("reviewedPenalty: properties over 3 000 random rows", () => {
  it("is continuous at every limit; a side with no band steps from 0 to exactly 0.4 at its reference limit", () => {
    const failures: string[] = [];
    for (const row of ROWS) {
      const { optimal_low: oL, optimal_high: oH, normal_low: nL, normal_high: nH } = row;
      const p = (v: number) => reviewedPenalty(v, row);
      const eps = probe(row);
      const noBandBelow = nL != null && (oL == null || oL <= nL);
      const noBandAbove = nH != null && (oH == null || oH >= nH);
      for (const [limit, side] of [[oL, "low"], [nL, "low"], [oH, "high"], [nH, "high"]] as const) {
        if (limit == null) continue;
        const inside = side === "low" ? limit + eps : limit - eps;
        const outside = side === "low" ? limit - eps : limit + eps;
        const step = (limit === nL && side === "low" && noBandBelow) || (limit === nH && side === "high" && noBandAbove);
        if (!step) {
          if (Math.abs(p(inside) - p(outside)) > 1e-6) failures.push(`${show(row)}: jump at ${limit}`);
        } else if (p(limit) !== 0 || Math.abs(p(outside) - (limit === 0 ? 1 : 0.4)) > 1e-6) {
          failures.push(`${show(row)}: step at ${limit} is ${p(limit)} → ${p(outside)}`);
        }
      }
    }
    expect(failures).toEqual([]);
  });

  it("has no other jump anywhere", () => {
    const rnd = random(7);
    const failures: string[] = [];
    for (const row of ROWS) {
      const span = spanOf(row);
      const eps = probe(row);
      const steps = [row.normal_low, row.normal_high].filter((x): x is number => x != null);
      for (let i = 0; i < 20; i++) {
        const v = (rnd() * 3 - 1) * span;
        if (steps.some((s) => Math.abs(s - v) <= 2 * eps)) continue;
        if (Math.abs(reviewedPenalty(v, row) - reviewedPenalty(v + eps, row)) > 1e-6) failures.push(`${show(row)}: jump at ${v}`);
      }
    }
    expect(failures).toEqual([]);
  });

  it("never falls as a value moves away from the optimal band, on either side", () => {
    const failures: string[] = [];
    for (const row of ROWS) {
      const { optimal_low: oL, optimal_high: oH, normal_low: nL, normal_high: nH } = row;
      const lower = Math.max(oL ?? -Infinity, nL ?? -Infinity);
      const upper = Math.min(oH ?? Infinity, nH ?? Infinity);
      const step = spanOf(row) / 80;
      for (const [start, dir] of [[lower, -1], [upper, 1]] as const) {
        if (!Number.isFinite(start)) continue;
        let previous = reviewedPenalty(start, row);
        if (previous !== 0) failures.push(`${show(row)}: ${start} is not optimal`);
        for (let k = 1; k <= 200; k++) {
          const now = reviewedPenalty(start + dir * k * step, row);
          if (now < previous) failures.push(`${show(row)}: falls at ${start + dir * k * step}`);
          previous = now;
        }
      }
    }
    expect(failures).toEqual([]);
  });

  it("matches the category: 0 optimal, (0, 0.4] in range, (0.4, 1] out of range", () => {
    const rnd = random(11);
    const failures: string[] = [];
    for (const row of ROWS) {
      const span = spanOf(row);
      for (let i = 0; i < 20; i++) {
        const v = (rnd() * 3 - 1) * span;
        const p = reviewedPenalty(v, row);
        const zone = classifyZone(v, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high);
        const ok =
          zone === "optimal" ? p === 0
          : zone === "below_optimal" || zone === "above_optimal" ? p > 0 && p <= 0.4
          : p > 0.4 && p <= 1;
        if (!ok) failures.push(`${show(row)}: ${v} is ${zone}, penalty ${p}`);
      }
    }
    expect(failures).toEqual([]);
  });
});

// ─── The score on the rows it runs on: the seed's rows with the families' decided rows for the scoring markers ───

const SEED = signedRows();
const PEOPLE: Array<["male" | "female", number]> = [["male", 25], ["male", 45], ["male", 72], ["female", 25], ["female", 45], ["female", 72]];
const CODES = Object.keys(REVIEWED_ROW_KEY);
const FASTING = { confirmedFasting: true };
const hasBounds = (r: ReviewedRange) => [r.optimal_low, r.optimal_high, r.normal_low, r.normal_high].some((x) => x != null);

// The optimal band of a row as classifyZone reads it (reference limits win over optimal bounds).
function optimalBand(r: ReviewedRange): [number, number] {
  return [Math.max(r.optimal_low ?? -Infinity, r.normal_low ?? -Infinity), Math.min(r.optimal_high ?? Infinity, r.normal_high ?? Infinity)];
}

// One value per marker that has a row for the person: `at(row)` chooses it.
function panel(sex: "male" | "female", age: number, at: (row: ReviewedRange, code: string) => number): BiomarkerInput[] {
  const picked = pickReferenceRows(SEED, sex, age).picked;
  return CODES.flatMap((code) => {
    const row = picked.get(REVIEWED_ROW_KEY[code]);
    return row && hasBounds(row) ? [{ code, value: at(row, code) }] : [];
  });
}
const codesOf = (list: { code: string }[]) => list.map((m) => m.code).sort();

describe("Score 2.0: ranges from the reviewed rows", () => {
  it("a fully optimal panel scores the maximum, for men and women at every age", () => {
    const rnd = random(3);
    for (const [sex, age] of PEOPLE) {
      for (const pick of ["middle", "random"] as const) {
        const inputs = panel(sex, age, (row) => {
          const [lo, hi] = optimalBand(row);
          const a = Number.isFinite(lo) ? lo : Math.min(0, hi);
          const b = Number.isFinite(hi) ? hi : a * 2 + 10;
          return pick === "middle" ? (a + b) / 2 : a + rnd() * (b - a);
        });
        const r = calculateLongevityScoreV2(inputs, sex, age, SEED);
        expect(r.validation.valid, `${sex} ${age}`).toBe(true);
        expect(r.markersScored, `${sex} ${age}`).toBe(sex === "male" ? 12 : 11);
        expect(r.markerScores.filter((m) => m.zone !== "optimal" || m.rawPenalty !== 0), `${sex} ${age}`).toEqual([]);
        expect(r.longevityScore, `${sex} ${age}`).toBe(100);
        expect(r.lsGrade).toBe("Elite");
      }
    }
  });

  it("every marker is scored against the row its page shows: same bounds, same category, no cost exactly when optimal", () => {
    const rnd = random(5);
    for (const [sex, age] of PEOPLE) {
      const picked = pickReferenceRows(SEED, sex, age).picked;
      for (let i = 0; i < 25; i++) {
        const inputs = panel(sex, age, (row) => {
          const bounds = [row.optimal_low, row.optimal_high, row.normal_low, row.normal_high].filter((x): x is number => x != null);
          const lo = Math.min(...bounds), hi = Math.max(...bounds);
          return lo - 0.5 * (hi - lo + 1) + rnd() * 2 * (hi - lo + 1);
        });
        for (const m of calculateLongevityScoreV2(inputs, sex, age, SEED, FASTING).markerScores) {
          const row = picked.get(REVIEWED_ROW_KEY[m.code])!;
          expect([m.optimalLow, m.optimalHigh]).toEqual([row.optimal_low, row.optimal_high]);
          expect(m.zone).toBe(classifyZone(m.value, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high));
          // rawPenalty is shown to 4 decimals; the totals use the exact penalty.
          expect(m.rawPenalty).toBeCloseTo(reviewedPenalty(m.value, row), 4);
          expect(reviewedPenalty(m.value, row) === 0).toBe(m.zone === "optimal");
        }
      }
    }
  });

  it("each marker reads the row its results are stored and classified under", () => {
    const seedKeys = new Set(SEED.map((r) => r.biomarker_key));
    for (const [key, code] of Object.entries(DB_KEY_TO_ENGINE_CODE)) {
      if (code in REVIEWED_ROW_KEY && seedKeys.has(key)) expect(REVIEWED_ROW_KEY[code], key).toBe(key);
    }
    expect(Object.values(REVIEWED_ROW_KEY).filter((k) => !seedKeys.has(k))).toEqual([]);
    // No stored key maps to the kidney slot: it is for the eGFR the app computes, never a laboratory's own.
    expect(Object.values(DB_KEY_TO_ENGINE_CODE)).not.toContain("EGFR");
  });

  it("each marker's unit is its reviewed row's unit", () => {
    for (const [sex, age] of PEOPLE) {
      const picked = pickReferenceRows(SEED, sex, age).picked;
      const inputs = panel(sex, age, (row) => optimalBand(row).find(Number.isFinite) ?? 1);
      for (const m of calculateLongevityScoreV2(inputs, sex, age, SEED, FASTING).markerScores) {
        const unit = picked.get(REVIEWED_ROW_KEY[m.code])!.unit_en;
        expect(unitsMatch(m.unit, unit), `${m.code}: '${m.unit}' vs '${unit}'`).toBe(true);
      }
    }
  });

  it("a marker scores only through the graded row: no row, no bounds, or another band under the same sex and age group, and it does not score", () => {
    const inputs = panel("male", 45, (row) => optimalBand(row).find(Number.isFinite) ?? 1);
    const scored = (rows: typeof SEED) => codesOf(calculateLongevityScoreV2(inputs, "male", 45, rows).markerScores);
    expect(scored(SEED)).toContain("ALBUMIN");
    expect(scored(SEED.filter((r) => r.biomarker_key !== "albumin"))).not.toContain("ALBUMIN");
    const change = (patch: Partial<ReviewedRange>) => SEED.map((r) => (r.biomarker_key === "albumin" ? { ...r, ...patch } : r));
    expect(scored(change({ optimal_low: null, optimal_high: null, normal_low: null, normal_high: null }))).not.toContain("ALBUMIN");
    // The band nobody graded: an optimal floor of 40 where the verifier graded 41.
    expect(scored(change({ optimal_low: 40 }))).not.toContain("ALBUMIN");
    expect(scored(change({ optimal_high: 50 }))).not.toContain("ALBUMIN");
    // The reference interval is not what the grade is given on: moving it keeps the marker in the score.
    expect(scored(change({ normal_low: 30 }))).toContain("ALBUMIN");
    // A database that returns its numeric columns as text still matches.
    expect(scored(SEED.map((r) => (r.biomarker_key === "albumin" ? { ...r, optimal_low: "41.0" as unknown as number } : r)))).toContain("ALBUMIN");
  });

  it("on the seed as it stands today (the rows before the sign-off compile) too few graded bands exist for a score", () => {
    const rows = reviewedRows();
    for (const [sex, age] of PEOPLE) {
      const picked = pickReferenceRows(rows, sex, age).picked;
      const inputs = CODES.flatMap((code) => {
        const row = picked.get(REVIEWED_ROW_KEY[code]);
        return row && hasBounds(row) ? [{ code, value: optimalBand(row).find(Number.isFinite) ?? 1 }] : [];
      });
      const r = calculateLongevityScoreV2(inputs, sex, age, rows, FASTING);
      // Only the rows whose optimal band already equals the graded one score.
      for (const m of r.markerScores) {
        const row = picked.get(REVIEWED_ROW_KEY[m.code])!;
        const graded = SCORE_SPEC.markers[m.code].rows[rowEligibilityKey(row)];
        expect([row.optimal_low, row.optimal_high], m.code).toEqual([graded.optimal_low, graded.optimal_high]);
      }
    }
  });
});

describe("Score 2.0: the scored set, groups and orders (rulings D-02, D-05, D-06)", () => {
  const optimalPanel = (sex: "male" | "female", age: number) => panel(sex, age, (row) => optimalBand(row).find(Number.isFinite) ?? 1);
  const run = (sex: "male" | "female", inputs: BiomarkerInput[], context?: Parameters<typeof calculateLongevityScoreV2>[4]) =>
    calculateLongevityScoreV2(inputs, sex, 45, SEED, context);
  const without = (inputs: BiomarkerInput[], ...codes: string[]) => inputs.filter((i) => !codes.includes(i.code));

  it("a man: apoB, HbA1c and ALT take their groups; no kidney marker scores", () => {
    const r = run("male", optimalPanel("male", 45), FASTING);
    expect(codesOf(r.markerScores)).toEqual(["ALBUMIN", "ALP", "ALT", "APOB", "HBA1C", "HDL_C", "HGB", "HSCRP", "TG", "URIC_ACID", "VITD", "WBC"]);
    expect(Object.fromEntries(r.suppressedMarkers.map((m) => [m.code, m.suppressedBy]))).toEqual({ NON_HDL: "APOB", LDL_C: "APOB", GLUCOSE: "HBA1C", GGT: "ALT" });
    expect(r.excludedMarkers).toEqual([]);
  });

  it("a woman: the liver group scores GGT while her ALT band is grade C, and her white cell row waits for a verdict", () => {
    const inputs = optimalPanel("female", 45);
    const r = run("female", inputs, FASTING);
    expect(codesOf(r.markerScores)).toEqual(["ALBUMIN", "ALP", "APOB", "GGT", "HBA1C", "HDL_C", "HGB", "HSCRP", "TG", "URIC_ACID", "VITD"]);
    expect(codesOf(r.suppressedMarkers)).toEqual(["GLUCOSE", "LDL_C", "NON_HDL"]);
    expect(SCORE_SPEC.markers.ALT.rows["female|All Adults"]).toMatchObject({ grade: "C", eligible: false });
    expect(SCORE_SPEC.markers.WBC.rows["female|All Adults"]).toMatchObject({ eligible: false });
    // Her ALT far out of range changes nothing: it does not score and replaces nothing.
    const alt = run("female", inputs.map((i) => (i.code === "ALT" ? { ...i, value: 600 } : i)), FASTING);
    expect(alt).toMatchObject({ longevityScore: 100, cap: null });
    expect(codesOf(alt.markerScores)).toEqual(codesOf(r.markerScores));
  });

  it("with each priority member removed, only the next eligible member scores", () => {
    const man = optimalPanel("male", 45);
    const atherogenic = (inputs: BiomarkerInput[]) => codesOf(run("male", inputs, FASTING).markerScores).filter((c) => ["APOB", "NON_HDL", "LDL_C"].includes(c));
    expect(atherogenic(man)).toEqual(["APOB"]);
    expect(atherogenic(without(man, "APOB"))).toEqual(["NON_HDL"]);
    expect(atherogenic(without(man, "APOB", "NON_HDL"))).toEqual(["LDL_C"]);
    expect(atherogenic(without(man, "APOB", "NON_HDL", "LDL_C"))).toEqual([]);
    const liver = (sex: "male" | "female", inputs: BiomarkerInput[]) => codesOf(run(sex, inputs).markerScores).filter((c) => ["ALT", "GGT"].includes(c));
    expect(liver("male", man)).toEqual(["ALT"]);
    expect(liver("male", without(man, "ALT"))).toEqual(["GGT"]);
    expect(liver("male", without(man, "ALT", "GGT"))).toEqual([]);
    const woman = optimalPanel("female", 45);
    expect(liver("female", woman)).toEqual(["GGT"]);
    expect(liver("female", without(woman, "GGT"))).toEqual([]); // her ALT never takes the place
    // ALP scores on its own, whatever the liver group does.
    expect(codesOf(run("male", without(man, "ALT", "GGT")).markerScores)).toContain("ALP");
  });

  it("fasting glucose scores only with fasting confirmed, and only when HbA1c does not", () => {
    const man = optimalPanel("male", 45);
    const glycaemia = (inputs: BiomarkerInput[], context?: Parameters<typeof calculateLongevityScoreV2>[4]) => {
      const r = run("male", inputs, context);
      return { scored: codesOf(r.markerScores).filter((c) => ["HBA1C", "GLUCOSE"].includes(c)), excluded: r.excludedMarkers, missing: r.validation.missingDomains };
    };
    // HbA1c present: it scores, and glucose is replaced by it whatever the fasting answer.
    expect(glycaemia(man, FASTING)).toEqual({ scored: ["HBA1C"], excluded: [], missing: [] });
    expect(glycaemia(man)).toEqual({ scored: ["HBA1C"], excluded: [], missing: [] });
    // No HbA1c: glucose scores with fasting confirmed, and without the answer it does not (fail closed).
    expect(glycaemia(without(man, "HBA1C"), FASTING)).toEqual({ scored: ["GLUCOSE"], excluded: [], missing: [] });
    for (const context of [undefined, {}, { confirmedFasting: false }]) {
      expect(glycaemia(without(man, "HBA1C"), context)).toEqual({ scored: [], excluded: [{ code: "GLUCOSE", reason: "fasting_not_confirmed" }], missing: ["glycaemia"] });
    }
    // A glucose far out of range that does not score costs nothing.
    const high = run("male", without(man, "HBA1C").map((i) => (i.code === "GLUCOSE" ? { ...i, value: 180 } : i)));
    expect(high).toMatchObject({ longevityScore: 100, cap: null });
  });

  it("HbA1c is passed over when the biological age's HbA1c exclusion holds; glucose then takes the place if fasting is confirmed", () => {
    const man = optimalPanel("male", 45).map((i) => (i.code === "HBA1C" ? { ...i, value: 7.5 } : i));
    const charged = run("male", man, FASTING);
    expect(charged.markerScores.find((m) => m.code === "HBA1C")).toMatchObject({ zone: "critical_high" });
    const passed = run("male", man, { ...FASTING, hba1cExcluded: true });
    expect(codesOf(passed.markerScores)).toContain("GLUCOSE");
    expect(codesOf([...passed.markerScores, ...passed.suppressedMarkers])).not.toContain("HBA1C");
    expect(passed.excludedMarkers).toEqual([{ code: "HBA1C", reason: "hba1c_exclusion" }]);
    expect(passed).toMatchObject({ longevityScore: 100, cap: null });
    // Without a fasting answer neither scores, and the glycaemia domain is not covered.
    const neither = run("male", man, { hba1cExcluded: true });
    expect(neither.excludedMarkers).toEqual([{ code: "GLUCOSE", reason: "fasting_not_confirmed" }, { code: "HBA1C", reason: "hba1c_exclusion" }]);
    expect(neither.validation.missingDomains).toEqual(["glycaemia"]);
    expect(neither.longevityScore).toBe(100);
  });

  it("no laboratory eGFR, total cholesterol, cystatin C, creatinine, AST, iron marker or Lp(a) is a code of the score", () => {
    expect(Object.keys(SCORE_SPEC.markers).sort()).toEqual([...CODES].sort());
    for (const key of ["total_cholesterol", "cystatin_c", "creatinine", "ast", "ferritin", "iron_saturation_tsat", "lipoproteina", "fructosamine", "nlr", "homa_ir"]) {
      expect(Object.values(REVIEWED_ROW_KEY), key).not.toContain(key);
    }
    // The kidney slot exists and no row of it scores yet: an eGFR given to the engine changes nothing.
    expect(SCORE_SPEC.markers.EGFR.weight).toBeNull();
    expect(Object.values(SCORE_SPEC.markers.EGFR.rows).filter((r) => r.eligible)).toEqual([]);
    const man = optimalPanel("male", 45);
    const low = run("male", [...without(man, "EGFR"), { code: "EGFR", value: 25 }]);
    expect(codesOf([...low.markerScores, ...low.suppressedMarkers])).not.toContain("EGFR");
    expect(low).toMatchObject({ longevityScore: 100, cap: null });
  });

  it("1,000 seeded panels: a marker outside the specification, at any value, never changes the score", () => {
    const rnd = random(20261110);
    // Engine codes of class b to e markers and of class a markers that do not score, as the app's inputs name them.
    const outside = [...new Set(Object.values(DB_KEY_TO_ENGINE_CODE))].filter((c) => !(c in SCORE_SPEC.markers)).sort();
    expect(outside).toEqual(expect.arrayContaining(["AST", "CREATININE", "FERRITIN", "LPA", "TSH", "MCV", "TESTOSTERONE", "INSULIN", "FRUCTOSAMINE"]));
    let scoredPanels = 0;
    for (let i = 0; i < 1000; i++) {
      const [sex, age] = PEOPLE[Math.floor(rnd() * PEOPLE.length)];
      const base = panel(sex, age, (row) => {
        const bounds = [row.optimal_low, row.optimal_high, row.normal_low, row.normal_high].filter((x): x is number => x != null);
        const lo = Math.min(...bounds), hi = Math.max(...bounds);
        return rnd() < 0.7 ? (optimalBand(row).find(Number.isFinite) ?? 1) : lo + rnd() * (hi - lo) * 1.2;
      }).filter(() => rnd() < 0.9);
      const context = { confirmedFasting: rnd() < 0.5 };
      const extra = outside.filter(() => rnd() < 0.5).map((code) => ({ code, value: 10 ** (rnd() * 8 - 2) }));
      const plain = calculateLongevityScoreV2(base, sex, age, SEED, context);
      const withExtra = calculateLongevityScoreV2([...extra, ...base], sex, age, SEED, context);
      expect(withExtra, `#${i}`).toEqual(plain);
      if (plain.longevityScore > 0) scoredPanels++;
    }
    expect(scoredPanels).toBeGreaterThan(300);
  });
});

describe("Score 2.0: weights, no bonus, coverage (rulings D-03, D-04, D-07)", () => {
  const optimalPanel = (sex: "male" | "female", age: number) => panel(sex, age, (row) => optimalBand(row).find(Number.isFinite) ?? 1);

  it("each scoring marker weighs what the specification gives it for its grade: A 3, B 2", () => {
    const r = calculateLongevityScoreV2(optimalPanel("male", 45), "male", 45, SEED);
    for (const m of [...r.markerScores, ...r.suppressedMarkers]) {
      const def = SCORE_SPEC.markers[m.code];
      expect(m.weight, m.code).toBe(def.weight);
      expect(m.weight, m.code).toBe({ A: 3, B: 2 }[def.grade as "A" | "B"]);
    }
    expect(r.markerScores.filter((m) => m.weight === 3).map((m) => m.code)).toEqual(["APOB"]);
    expect(r.maxPossibleWeightedPenalty).toBe(3 + 11 * 2);
  });

  it("there is no bonus: anywhere inside the optimal band scores the same, and nothing offsets a penalty", () => {
    const edge = panel("male", 45, (row) => optimalBand(row).find(Number.isFinite) ?? 1);
    const middle = panel("male", 45, (row) => {
      const [lo, hi] = optimalBand(row);
      return Number.isFinite(lo) && Number.isFinite(hi) ? (lo + hi) / 2 : (optimalBand(row).find(Number.isFinite) ?? 1);
    });
    const [a, b] = [edge, middle].map((inputs) => calculateLongevityScoreV2(inputs, "male", 45, SEED));
    expect([a.longevityScore, a.totalWeightedPenalty]).toEqual([100, 0]);
    expect([b.longevityScore, b.totalWeightedPenalty]).toEqual([100, 0]);
    for (const field of ["lsBonusPoints", "totalWeightedBonus", "netWeightedScore"]) expect(field in a, field).toBe(false);
    for (const m of a.markerScores) for (const field of ["rawBonus", "weightedBonus", "bonusEligible", "tier", "tierWeight"]) expect(field in m, field).toBe(false);
    // One in-range result beside eleven optimal ones: the score is the curve of its penalty alone.
    const tg = pickReferenceRows(SEED, "male", 45).picked.get("triglycerides")!; // optimal to 80, reference to 150
    const r = calculateLongevityScoreV2(middle.map((i) => (i.code === "TG" ? { ...i, value: 115 } : i)), "male", 45, SEED);
    const penalty = reviewedPenalty(115, tg) * 2;
    expect(penalty).toBeCloseTo(0.4 * 0.25 * 2, 9);
    expect(r.totalWeightedPenalty).toBeCloseTo(penalty, 4);
    expect(r.netPenaltyRatio).toBeCloseTo(penalty / 25, 4);
    expect(r.longevityScore).toBe(Math.round(100 * Math.exp(-3 * (penalty / 25))));
    expect(r.lsPenaltyPoints).toBe(100 - r.longevityScore);
  });

  it("at least 8 scoring markers in 4 of the 5 domains; ALP, uric acid and vitamin D count and cover no domain", () => {
    const man = optimalPanel("male", 45);
    const only = (...codes: string[]) => calculateLongevityScoreV2(man.filter((i) => codes.includes(i.code)), "male", 45, SEED).validation;
    // Eight markers, four domains: lipids, glycaemia, inflammation, organ function.
    expect(only("APOB", "HDL_C", "TG", "HBA1C", "HSCRP", "ALT", "ALBUMIN", "URIC_ACID")).toMatchObject({ valid: true, totalMarkers: 8, domainsCovered: 4, missingDomains: ["blood_count"] });
    // Seven: too few, although five domains are covered.
    expect(only("APOB", "HDL_C", "HBA1C", "HSCRP", "ALT", "ALBUMIN", "HGB")).toMatchObject({ valid: false, totalMarkers: 7, domainsCovered: 5 });
    // Markers another member replaces do not count toward the eight: ten measured, seven scoring.
    expect(only("APOB", "NON_HDL", "LDL_C", "HDL_C", "HBA1C", "HSCRP", "ALT", "GGT", "ALBUMIN", "HGB")).toMatchObject({ valid: false, totalMarkers: 7 });
    // ALP, uric acid and vitamin D make the eight and cover nothing: three domains with them is not enough.
    expect(only("APOB", "HDL_C", "TG", "HSCRP", "WBC", "ALT", "ALBUMIN", "ALP", "URIC_ACID", "VITD")).toMatchObject({ valid: false, totalMarkers: 10, domainsCovered: 3, missingDomains: ["glycaemia", "blood_count"] });
    expect(Object.keys(SCORE_SPEC.coverage.domains)).toEqual(["lipids", "glycaemia", "inflammation", "organ_function", "blood_count"]);
    for (const code of ["ALP", "URIC_ACID", "VITD"]) expect(Object.values(SCORE_SPEC.coverage.domains).some((d) => d.markers.includes(code)), code).toBe(false);
  });

  it("the confidence rating follows the domains covered and no tier", () => {
    const man = optimalPanel("male", 45);
    expect(calculateLongevityScoreV2(man, "male", 45, SEED).confidence).toBe("high");
    expect(calculateLongevityScoreV2(man.filter((i) => i.code !== "HGB"), "male", 45, SEED).confidence).toBe("moderate");
    expect(calculateLongevityScoreV2(man.slice(0, 3), "male", 45, SEED).confidence).toBe("insufficient");
  });

  it("from stored results: a reported non-HDL cholesterol wins, and without one it is computed from total and HDL", () => {
    const stored = (values: Record<string, number>) => buildEngineInputs(Object.entries(values).map(([biomarkerKey, value]) => ({ biomarkerKey, value })));
    expect(stored({ total_cholesterol: 190, hdl_cholesterol: 55 })).toEqual([{ code: "HDL_C", value: 55 }, { code: "NON_HDL", value: 135 }]);
    expect(stored({ total_cholesterol: 190, hdl_cholesterol: 55, non_hdl_cholesterol: 128 }).filter((i) => i.code === "NON_HDL")).toEqual([{ code: "NON_HDL", value: 128 }]);
    // Total cholesterol itself is never an input; a laboratory's eGFR neither.
    expect(stored({ total_cholesterol: 190, egfr_creatinine_based: 50 })).toEqual([]);
    // A value-only row does not take the code from a classified row stored under another key of the same marker,
    // and a value-only stored non-HDL is not replaced by the computed one.
    expect(buildEngineInputs([{ biomarkerKey: "apolipoprotein_b", value: 80, valueOnly: true }, { biomarkerKey: "apolipoprotein_b_apob", value: 82 }])).toEqual([{ code: "APOB", value: 82 }]);
    expect(buildEngineInputs([{ biomarkerKey: "non_hdl_cholesterol", value: 128, valueOnly: true }, { biomarkerKey: "total_cholesterol", value: 190 }, { biomarkerKey: "hdl_cholesterol", value: 55 }]).filter((i) => i.code === "NON_HDL")).toEqual([]);
  });
});

describe("Longevity Score v2: grade", () => {
  it("the lowest grade is 'Needs attention'; the dashboard shows a stored 'Critical' grade the same way", () => {
    // Every marker well past its reference limit.
    const worst = panel("female", 60, (row) => (row.normal_high != null ? row.normal_high * 3 + 1 : 0));
    const v2 = calculateLongevityScoreV2(worst, "female", 60, SEED);
    expect(v2.longevityScore).toBeLessThan(20);
    expect(v2.lsGrade).toBe("Needs attention");
    expect(formatLongevityGrade(v2.lsGrade, "es")).toBe("Requiere atención");
    // Scores stored before the rename carry "Critical".
    for (const locale of ["en", "es"] as const) expect(formatLongevityGrade(v2.lsGrade, locale)).toBe(formatLongevityGrade("Critical", locale));
  });
});

const optimal = (sex: "male" | "female", age: number) => panel(sex, age, (row) => optimalBand(row).find(Number.isFinite) ?? 1);
const withValue = (inputs: BiomarkerInput[], code: string, value: number) => inputs.map((i) => (i.code === code ? { ...i, value } : i));
const scoredOrNot = (r: ReturnType<typeof calculateLongevityScoreV2>, code: string) =>
  r.markerScores.find((m) => m.code === code) ?? r.suppressedMarkers.find((m) => m.code === code);
const NO_SCORE = { longevityScore: -1, markerScores: [], suppressedMarkers: [], markersScored: 0, cap: null };

describe("Score context: no score in declared pregnancy or lactation", () => {
  it.each([
    ["pregnancy", { pregnancy: true, lactation: false }],
    ["lactation", { pregnancy: false, lactation: true }],
  ] as const)("declared %s: no score, whatever the values, with the reason", (reason, state) => {
    for (const [sex, age] of PEOPLE) {
      const inputs = optimal(sex, age);
      expect(calculateLongevityScoreV2(inputs, sex, age, SEED).longevityScore).toBe(100); // the same values score without it
      const r = calculateLongevityScoreV2(inputs, sex, age, SEED, { state });
      expect(r, `${sex} ${age}`).toMatchObject({ ...NO_SCORE, withheld: { reason } });
      expect(r.lsGrade).not.toMatch(/Elite|Excellent|Insufficient/);
    }
  });

  it("pregnancy comes before lactation, and too few markers are still reported as withheld", () => {
    expect(calculateLongevityScoreV2([{ code: "HBA1C", value: 5.2 }], "female", 30, SEED, { state: { pregnancy: true, lactation: true } }).withheld).toEqual({ reason: "pregnancy" });
    expect(withheldByContext({ state: { pregnancy: false, lactation: false } })).toBeNull();
    expect(withheldByContext(undefined)).toBeNull();
  });

  it("the four-argument call and a context that declares nothing score as before, with nothing withheld, capped or excluded", () => {
    for (const [sex, age] of PEOPLE) {
      const inputs = optimal(sex, age);
      const plain = calculateLongevityScoreV2(inputs, sex, age, SEED);
      expect(plain).toMatchObject({ longevityScore: 100, lsGrade: "Elite", withheld: null, cap: null, excludedMarkers: [] });
      const undeclared = { state: { pregnancy: false, lactation: false }, oralOestrogen: false, criticalTier: false };
      expect(calculateLongevityScoreV2(inputs, sex, age, SEED, undeclared)).toEqual(plain);
      expect(calculateLongevityScoreV2(inputs, sex, age, SEED, null)).toEqual(plain);
    }
  });
});

describe("Score context: no score while a value is in the critical tier", () => {
  // Fixture rows: the seed's, with the critical fields of the draft critical-limits table on haemoglobin
  // (7.0 and 20.0 g/dL), LDL (a fixture limit on a marker apoB replaces) and GGT (one ALT replaces in a man).
  const CRITICAL: ReviewedRow[] = SEED.map((r) => {
    if (r.biomarker_key === "hemoglobin") return { ...r, critical_low: 7, critical_high: 20 };
    if (r.biomarker_key === "ldl_cholesterol") return { ...r, critical_low: null, critical_high: 500 };
    if (r.biomarker_key === "ggt") return { ...r, critical_low: null, critical_high: 1000 };
    return r;
  });
  const man = optimal("male", 45);
  const score = (inputs: BiomarkerInput[], context?: Parameters<typeof calculateLongevityScoreV2>[4]) =>
    calculateLongevityScoreV2(inputs, "male", 45, CRITICAL, context);

  it("a scored marker at or beyond its row's critical field: no score; just inside it: a score, never the top grade", () => {
    expect(score(man).longevityScore).toBe(100);
    for (const value of [6.2, 7, 20, 23.5]) {
      expect(score(withValue(man, "HGB", value)), `haemoglobin ${value}`).toMatchObject({ ...NO_SCORE, withheld: { reason: "critical_value" } });
    }
    for (const value of [7.1, 19.9]) {
      const r = score(withValue(man, "HGB", value));
      expect(r.withheld, `haemoglobin ${value}`).toBeNull();
      expect(r.longevityScore).toBeGreaterThan(0);
      expect(r.lsGrade).not.toBe("Elite");
    }
  });

  it("a value that does not score triggers it too: a marker another member of its group replaces", () => {
    for (const [code, value] of [["LDL_C", 510], ["GGT", 1200]] as const) {
      expect(score(withValue(man, code, value)), code).toMatchObject({ ...NO_SCORE, withheld: { reason: "critical_value" } });
      // The premise: it does not score in this panel, so without the critical field it leaves the panel at 100.
      const r = calculateLongevityScoreV2(withValue(man, code, value), "male", 45, SEED);
      expect(r.markerScores.some((m) => m.code === code)).toBe(false);
      expect(r.longevityScore).toBe(100);
    }
  });

  it("a code the specification does not name is not read by the engine: processing sets the tier for such a value", () => {
    const rows = CRITICAL.map((r) => (r.biomarker_key === "estradiol" ? { ...r, critical_low: null, critical_high: 1000 } : r));
    const inputs = [...man, { code: "ESTRADIOL", value: 1200 }];
    expect(calculateLongevityScoreV2(inputs, "male", 45, rows).withheld).toBeNull();
    expect(calculateLongevityScoreV2(inputs, "male", 45, rows, { criticalTier: true })).toMatchObject({ ...NO_SCORE, withheld: { reason: "critical_value" } });
  });

  it("the tier set by processing (a value the engine is never given, such as potassium) withholds the score", () => {
    expect(score(man, { criticalTier: true })).toMatchObject({ ...NO_SCORE, withheld: { reason: "critical_value" } });
    expect(calculateLongevityScoreV2(man, "male", 45, SEED, { criticalTier: true }).withheld).toEqual({ reason: "critical_value" });
  });

  it("the critical tier is the reason given first, in declared pregnancy too", () => {
    const pregnant = { state: { pregnancy: true, lactation: false } };
    expect(score(withValue(man, "HGB", 6.2), pregnant).withheld).toEqual({ reason: "critical_value" });
    expect(score(man, { ...pregnant, criticalTier: true }).withheld).toEqual({ reason: "critical_value" });
  });

  it("the reference interval is never the trigger: rows without critical fields withhold nothing, however far the value", () => {
    const r = calculateLongevityScoreV2(withValue(man, "HGB", 3), "male", 45, SEED);
    expect(r.withheld).toBeNull();
    expect(r.longevityScore).toBeGreaterThan(0);
    expect(r.markerScores.find((m) => m.code === "HGB")?.zone).toBe("critical_low"); // out of range, the legacy code
  });

  it("isCriticalValue: at or beyond a limit; a bound only when it already lies at or beyond the limit on its side", () => {
    const row = { critical_low: 2.8, critical_high: 6 };
    expect([2.7, 2.8, 2.81, 5.99, 6, 6.4].map((v) => isCriticalValue(v, row))).toEqual([true, true, false, false, true, true]);
    expect(isCriticalValue(6.5, row, ">")).toBe(true); // ">6.5": every value it allows is above 6
    expect(isCriticalValue(2.5, row, "<")).toBe(true);
    expect(isCriticalValue(3, row, "<")).toBe(false); // "<3.0" only might be below 2.8
    expect(isCriticalValue(2.5, row, ">")).toBe(false); // ">2.5" says nothing about the low limit
    expect(isCriticalValue(6.5, row, "<")).toBe(false);
    expect(isCriticalValue(1, {})).toBe(false);
    expect(isCriticalValue(1, { critical_low: null, critical_high: null })).toBe(false);
    expect(isCriticalValue(1, undefined)).toBe(false);
    expect(isCriticalValue(0, { critical_low: null, critical_high: 6 })).toBe(false);
  });
});

describe("Out-of-range cap: a scored marker outside its reference interval rules out the top grade", () => {
  // 1% past a reference limit: the smallest out-of-range result. Null when the row has no usable limit on a side.
  function onePercentPast(row: ReviewedRange, side: "low" | "high"): number | null {
    const limit = side === "low" ? row.normal_low : row.normal_high;
    if (limit == null || limit <= 0) return null;
    const v = side === "low" ? limit * 0.99 : limit * 1.01;
    const zone = classifyZone(v, row.optimal_low, row.optimal_high, row.normal_low, row.normal_high);
    return zone === "critical_low" || zone === "critical_high" ? v : null;
  }

  // With the specification's weights one out-of-range marker among at most 13 already costs more than the cap
  // takes, so the cap binds only where the marker is light beside the others. LIGHT is such a specification: the
  // real one with three markers at an eighth of their weight.
  const LIGHT_CODES = ["ALP", "URIC_ACID", "VITD"];
  const LIGHT: ScoreSpec = {
    ...SCORE_SPEC,
    markers: Object.fromEntries(Object.entries(SCORE_SPEC.markers).map(([code, m]) => [code, LIGHT_CODES.includes(code) ? { ...m, weight: 0.25 } : m])),
  };

  it("the cap is the top of the grade below the top grade, as the engine grades scores", () => {
    const man = optimal("male", 45);
    const row = pickReferenceRows(SEED, "male", 45).picked.get("alp")!;
    const capped = calculateLongevityScoreV2(withValue(man, "ALP", onePercentPast(row, "high")!), "male", 45, SEED, null, LIGHT);
    expect(capped.cap).toEqual({ level: OUT_OF_RANGE_CAP.level, grade: OUT_OF_RANGE_CAP.grade, uncappedScore: capped.cap!.uncappedScore, markers: ["ALP"] });
    expect(capped.cap!.uncappedScore).toBeGreaterThan(OUT_OF_RANGE_CAP.level); // the cap lowered it
    expect(capped).toMatchObject({ longevityScore: OUT_OF_RANGE_CAP.level, lsGrade: OUT_OF_RANGE_CAP.grade });
    expect(capped.lsGrade).not.toBe("Elite");
    // Without the marker the panel scores 100: its impact is the whole difference, cap included.
    expect(capped.markerScores.find((m) => m.code === "ALP")?.lsPointsImpact).toBe(100 - OUT_OF_RANGE_CAP.level);
    // One point above the level is the top grade: an in-range panel that nets that score.
    const tops = new Map<number, string>();
    const rnd = random(5);
    for (let i = 0; i < 400 && !tops.has(OUT_OF_RANGE_CAP.level + 1); i++) {
      const inputs = panel("male", 45, (r) => {
        const hi = optimalBand(r)[1];
        if (rnd() < 0.85 || r.normal_high == null || !Number.isFinite(hi)) return optimalBand(r).find(Number.isFinite) ?? 1;
        return hi + rnd() * (r.normal_high - hi) * 0.999;
      });
      const r = calculateLongevityScoreV2(inputs, "male", 45, SEED);
      tops.set(r.longevityScore, r.lsGrade);
    }
    expect(tops.get(OUT_OF_RANGE_CAP.level + 1)).toBe("Elite");
  });

  it.each([["the specification", SCORE_SPEC], ["light markers", LIGHT]] as const)(
    "every scored marker, 1%% past either reference limit in an otherwise optimal panel: never the top grade (%s)",
    (_name, spec) => {
      let tested = 0;
      let capped = 0;
      for (const [sex, age] of PEOPLE) {
        const base = optimal(sex, age);
        const scoredCodes = new Set(calculateLongevityScoreV2(base, sex, age, SEED, null, spec).markerScores.map((m) => m.code));
        const picked = pickReferenceRows(SEED, sex, age).picked;
        for (const code of scoredCodes) {
          for (const side of ["low", "high"] as const) {
            const value = onePercentPast(picked.get(REVIEWED_ROW_KEY[code])!, side);
            if (value == null) continue;
            tested++;
            const r = calculateLongevityScoreV2(withValue(base, code, value), sex, age, SEED, null, spec);
            expect(r.longevityScore, `${sex} ${age} ${code} ${side}`).toBeLessThanOrEqual(OUT_OF_RANGE_CAP.level);
            expect(r.lsGrade, `${sex} ${age} ${code} ${side}`).not.toBe("Elite");
            // The cap is recorded when it lowered the score, with the marker that holds it.
            if (r.cap) {
              capped++;
              expect(r.cap).toMatchObject({ level: OUT_OF_RANGE_CAP.level, markers: [code] });
              expect(r.cap.uncappedScore, `${sex} ${age} ${code} ${side}`).toBeGreaterThan(OUT_OF_RANGE_CAP.level);
              expect(r.longevityScore, `${sex} ${age} ${code} ${side}`).toBe(OUT_OF_RANGE_CAP.level);
            }
          }
        }
      }
      expect(tested).toBeGreaterThan(80);
      // On the specification's own weights the penalty alone already holds the score below the top grade.
      if (spec === SCORE_SPEC) expect(capped).toBe(0);
      else expect(capped).toBeGreaterThan(10);
    },
  );

  it("1,000 seeded panels with at least one scored marker outside its interval: never the top grade; the cap names them", () => {
    const rnd = random(20261110);
    let capped = 0;
    for (let i = 0; i < 1000; i++) {
      const spec = rnd() < 0.5 ? SCORE_SPEC : LIGHT;
      const [sex, age] = PEOPLE[Math.floor(rnd() * PEOPLE.length)];
      const picked = pickReferenceRows(SEED, sex, age).picked;
      const base = optimal(sex, age);
      const scoredCodes = [...new Set(calculateLongevityScoreV2(base, sex, age, SEED, null, spec).markerScores.map((m) => m.code))].sort();
      // One marker 1% past a limit; now and then a second one, far past it.
      let inputs = base;
      const moved: string[] = [];
      for (let k = 0; k < (rnd() < 0.2 ? 2 : 1); k++) {
        const code = scoredCodes[Math.floor(rnd() * scoredCodes.length)];
        const row = picked.get(REVIEWED_ROW_KEY[code])!;
        const side = rnd() < 0.5 ? "low" : "high";
        const near = onePercentPast(row, side) ?? onePercentPast(row, side === "low" ? "high" : "low");
        if (near == null || moved.includes(code)) continue;
        inputs = withValue(inputs, code, k === 0 ? near : near > (row.normal_high ?? Infinity) ? near * 2 : near / 2);
        moved.push(code);
      }
      if (!moved.length) continue;
      const r = calculateLongevityScoreV2(inputs, sex, age, SEED, null, spec);
      const out = r.markerScores.filter((m) => m.zone === "critical_low" || m.zone === "critical_high").map((m) => m.code);
      expect(out.sort(), `#${i}`).toEqual([...moved].sort());
      expect(r.longevityScore, `#${i}`).toBeLessThanOrEqual(OUT_OF_RANGE_CAP.level);
      expect(r.lsGrade, `#${i}`).not.toBe("Elite");
      if (r.cap) {
        capped++;
        expect([...r.cap.markers].sort(), `#${i}`).toEqual(out);
        expect(r.longevityScore, `#${i}`).toBe(OUT_OF_RANGE_CAP.level);
      }
    }
    expect(capped).toBeGreaterThan(20); // the cap is what holds the panels whose out-of-range marker is light
  });

  it("a marker that does not score never changes the score: LDL far out of range behind an optimal apoB", () => {
    const r = calculateLongevityScoreV2(withValue(optimal("male", 45), "LDL_C", 400), "male", 45, SEED);
    expect(r.suppressedMarkers.find((m) => m.code === "LDL_C")).toMatchObject({ zone: "critical_high", suppressedBy: "APOB" });
    expect(r).toMatchObject({ longevityScore: 100, lsGrade: "Elite", cap: null });
  });

  it("a score already below the level is not touched and records no cap", () => {
    const r = calculateLongevityScoreV2(withValue(optimal("male", 45), "HBA1C", 9), "male", 45, SEED);
    expect(r.longevityScore).toBeLessThan(OUT_OF_RANGE_CAP.level);
    expect(r.cap).toBeNull();
  });
});

describe("Oral oestrogen declared: hs-CRP is not scored, triglycerides on their reference interval only", () => {
  const ORAL = { oralOestrogen: true };
  const woman = optimal("female", 35);
  const tg = pickReferenceRows(SEED, "female", 35).picked.get("triglycerides")!; // optimal to 80, reference to 150 mg/dL

  it("hs-CRP: not in the scored markers at any value, no penalty, no cap, listed as excluded", () => {
    for (const value of [0.3, 2, 8]) {
      const inputs = withValue(woman, "HSCRP", value);
      const without = calculateLongevityScoreV2(inputs.filter((i) => i.code !== "HSCRP"), "female", 35, SEED, ORAL);
      const r = calculateLongevityScoreV2(inputs, "female", 35, SEED, ORAL);
      expect(scoredOrNot(r, "HSCRP"), `hs-CRP ${value}`).toBeUndefined();
      expect(r.excludedMarkers).toEqual([{ code: "HSCRP", reason: "oral_oestrogen" }]);
      expect(r).toMatchObject({ longevityScore: 100, cap: null, withheld: null });
      expect({ ...r, excludedMarkers: [] }).toEqual({ ...without, markersMeasured: r.markersMeasured });
    }
    // The control: the same hs-CRP of 8 mg/L costs, and caps, when oral oestrogen is not declared.
    const charged = calculateLongevityScoreV2(withValue(woman, "HSCRP", 8), "female", 35, SEED);
    expect(charged.markerScores.find((m) => m.code === "HSCRP")).toMatchObject({ zone: "critical_high" });
    expect(charged.longevityScore).toBeLessThanOrEqual(OUT_OF_RANGE_CAP.level);
    expect(charged.excludedMarkers).toEqual([]);
  });

  it("hs-CRP neither counts toward the eight nor covers the inflammation domain", () => {
    // Nine scoring markers in four domains, hs-CRP the only inflammation marker and no blood count.
    const codes = ["APOB", "HDL_C", "TG", "HBA1C", "HSCRP", "GGT", "ALBUMIN", "URIC_ACID", "ALP"];
    const inputs = woman.filter((i) => codes.includes(i.code));
    expect(inputs).toHaveLength(codes.length);
    const declared = calculateLongevityScoreV2(inputs, "female", 35, SEED, ORAL);
    const not = calculateLongevityScoreV2(inputs, "female", 35, SEED);
    expect(not.validation).toMatchObject({ valid: true, totalMarkers: 9, domainsCovered: 4 });
    expect(declared.validation).toMatchObject({ valid: false, totalMarkers: 8, domainsCovered: 3 });
    expect(declared.validation.missingDomains).toContain("inflammation");
    expect(declared.longevityScore).toBe(-1);
    expect(declared.withheld).toBeNull(); // too few domains, not a withholding
  });

  it("triglycerides inside the reference limit cost nothing; outside it they are charged from that limit", () => {
    expect([tg.optimal_high, tg.normal_high]).toEqual([80, 150]);
    const at = (value: number, context?: typeof ORAL) =>
      calculateLongevityScoreV2(withValue(woman, "TG", value), "female", 35, SEED, context).markerScores.find((m) => m.code === "TG")!;
    // 140 mg/dL: above the optimal band, so it costs without the declaration and nothing with it.
    expect(at(140)).toMatchObject({ zone: "above_optimal" });
    expect(at(140).rawPenalty).toBeGreaterThan(0);
    expect(at(140, ORAL)).toMatchObject({ zone: "optimal", rawPenalty: 0, optimalLow: null, optimalHigh: null });
    expect(at(60, ORAL)).toMatchObject({ zone: "optimal", rawPenalty: 0 });
    // 160 mg/dL: outside the limit, charged as a side with no band (25% of the limit wide).
    expect(at(160, ORAL)).toMatchObject({ zone: "critical_high" });
    expect(at(160, ORAL).rawPenalty).toBeCloseTo(0.4 + 0.6 * (10 / (0.25 * 150)), 4);
    const out = calculateLongevityScoreV2(withValue(woman, "TG", 160), "female", 35, SEED, ORAL);
    expect(out.longevityScore).toBeLessThanOrEqual(OUT_OF_RANGE_CAP.level);
    expect(out.excludedMarkers.map((e) => e.code)).not.toContain("TG"); // triglycerides still score
  });

  it("triglycerides are charged against the limit they are displayed against, not re-read against the picked row", () => {
    // Displayed against 175 mg/dL (fasting not confirmed): 160 is inside, 180 outside.
    const shown: ReviewedRange = { optimal_low: tg.optimal_low, optimal_high: tg.optimal_high, normal_low: tg.normal_low, normal_high: 175 };
    const at = (value: number, context?: typeof ORAL) =>
      calculateLongevityScoreV2(woman.map((i) => (i.code === "TG" ? { code: "TG", value, limits: shown } : i)), "female", 35, SEED, context)
        .markerScores.find((m) => m.code === "TG")!;
    expect(at(160, ORAL)).toMatchObject({ zone: "optimal", rawPenalty: 0 });
    expect(at(180, ORAL)).toMatchObject({ zone: "critical_high" });
    expect(at(180, ORAL).rawPenalty).toBeCloseTo(0.4 + 0.6 * (5 / (0.25 * 175)), 4);
    // Without the declaration the displayed limits are used as they are, optimal band included.
    expect(at(160)).toMatchObject({ zone: "above_optimal", optimalHigh: 80 });
    expect(at(160).rawPenalty).toBeCloseTo(reviewedPenalty(160, shown), 4);
    // Limits with no bound: the result is shown as a value only and is not scored.
    const none: ReviewedRange = { optimal_low: null, optimal_high: null, normal_low: null, normal_high: null };
    const r = calculateLongevityScoreV2(woman.map((i) => (i.code === "TG" ? { ...i, limits: none } : i)), "female", 35, SEED);
    expect(scoredOrNot(r, "TG")).toBeUndefined();
  });

  it("without the declaration (transdermal therapy declares none) nothing changes", () => {
    const inputs = withValue(withValue(woman, "HSCRP", 2), "TG", 140);
    expect(calculateLongevityScoreV2(inputs, "female", 35, SEED, { oralOestrogen: false })).toEqual(calculateLongevityScoreV2(inputs, "female", 35, SEED));
  });
});
