/**
 * The zone of a laboratory result that may be a bound, in one place: process-results.ts classifies every result with
 * it, and check P3 of docs/signoff/ACCEPTANCE-TEST.md ("A bounded result such as "<5" resolves to the bound itself
 * and is never classified above optimal") runs it on the parser's output (scripts/signoff/checks/preanalytical.ts).
 *
 * A laboratory reports a value outside its assay's reportable range as a bound: "<0,500", ">8,000"
 * (lab-provider/hl7.ts parseHl7Value). The value stored and shown stays the bound itself, with its comparator; only
 * the zone depends on the comparator:
 *   - no comparator: exactly classifyZone (zone-classifier.ts) on the value;
 *   - "<X": the true value lies below X, anywhere from the lowest possible value up to X. The result takes the zone of
 *     the values just below X only when every value below X falls in that one zone; otherwise it cannot be placed and
 *     is "unclassified". "<=X" also allows X itself;
 *   - ">X" mirrors it: every value above X, with no upper limit. ">=X" also allows X itself.
 * So with an optimal ceiling of 0.5 mg/L and no floor, hs-CRP "<0.2" is optimal and "<1.75" is unclassified (the
 * true value may be optimal or above optimal), never above optimal; "<5" with a reference floor of 10 stays below the
 * range, as classifyZone places 5.
 *
 * The lowest possible value is 0 (LOWEST_POSSIBLE_VALUE): every marker is a concentration, activity, count, ratio,
 * percentage or rate, and no reference row has a negative bound. Without that floor, the reference floor of 0 that
 * hs-CRP, apoB, LDL and other rows carry (supabase/seed-data) would leave every "<X" result of those markers
 * unclassified, since a negative value would be below the range.
 *
 * Every way a result reaches the app keeps its comparator (decision CEO-15): the laboratory feed, the upload, the
 * administrator's entry and the manual lab provider read a reported result with readReportedValue below.
 */
import { parseHl7Number, parseHl7Value } from "../lab-provider/hl7";
import { classifyZone, type Zone } from "./zone-classifier";

/** How a bounded result relates to its value: "<0.5" is below 0.5, "<=0.5" at most 0.5, and so on. */
export type BoundComparator = "<" | "<=" | ">" | ">=";

/** No result can be lower: see the module comment. */
export const LOWEST_POSSIBLE_VALUE = 0;

const COMPARATORS: ReadonlySet<unknown> = new Set<BoundComparator>(["<", "<=", ">", ">="]);

/** True when `c` is one of the four comparators of a bounded result. */
export function isBoundComparator(c: unknown): c is BoundComparator {
  return COMPARATORS.has(c);
}

/**
 * The zone of a result: `value` (the bound itself when the laboratory reported a bound), its `comparator`, if any,
 * and the four bounds of the result's reference row, in classifyZone's order. A result with a comparator other than the
 * four, or with a comparator and a value that is not a finite number, cannot be placed: "unclassified".
 */
export function classifyResultZone(
  value: number,
  comparator: BoundComparator | null | undefined,
  optimalLow: number | null,
  optimalHigh: number | null,
  normalLow: number | null,
  normalHigh: number | null,
): Zone {
  const zoneOf = (v: number): Zone => classifyZone(v, optimalLow, optimalHigh, normalLow, normalHigh);
  if (comparator == null) return zoneOf(value);
  if (!isBoundComparator(comparator) || !Number.isFinite(value)) return "unclassified";

  // The values the result allows, from lo to hi, each end closed (included) or open, never below the lowest possible.
  const below = comparator === "<" || comparator === "<=";
  const lo = below ? LOWEST_POSSIBLE_VALUE : Math.max(value, LOWEST_POSSIBLE_VALUE);
  const loClosed = below || comparator === ">=" || value < LOWEST_POSSIBLE_VALUE;
  const hi = below ? value : Infinity;
  const hiClosed = comparator === "<=";
  if (lo > hi || (lo === hi && !(loClosed && hiClosed))) return "unclassified"; // no value is possible ("<0")

  // classifyZone changes only at the row's bounds, so the zones the result may have are those of each bound inside
  // the interval, of each closed end, and of one value in each stretch between them.
  const cuts = [...new Set([optimalLow, optimalHigh, normalLow, normalHigh])]
    .filter((b): b is number => typeof b === "number" && b > lo && b < hi)
    .sort((a, b) => a - b);
  const zones = new Set<Zone>(cuts.map(zoneOf));
  if (loClosed) zones.add(zoneOf(lo));
  if (hiClosed) zones.add(zoneOf(hi));
  const ends = [lo, ...cuts, hi];
  for (let i = 0; i + 1 < ends.length; i++) {
    const a = ends[i];
    const b = ends[i + 1];
    const inside = b === Infinity ? Math.min(Number.MAX_VALUE, a + Math.max(1, Math.abs(a))) : a + (b - a) / 2;
    if (inside > a && inside < b) zones.add(zoneOf(inside));
  }
  return zones.size === 1 ? [...zones][0] : "unclassified";
}

/**
 * A bounded result the app could not place: it has a comparator and classifyResultZone gave "unclassified". It is
 * stored and shown with its bound, but it is not scored: the score would read the bound as a measured value (hs-CRP
 * "<1.75" as 1.75, above optimal), which is the classification P3 forbids.
 */
export function isUnplacedBound(result: { comparator?: unknown; zone?: unknown }): boolean {
  return isBoundComparator(result.comparator) && result.zone === "unclassified";
}

// ─── Reading a reported result ───

/**
 * The comparators a stored result can carry. The biomarker_values.comparator column allows "<" and ">" only
 * (supabase/migrations/20260922000100_lab_notes_comparator_corrected.sql), so a result printed "≤5" or "≥5" is not
 * stored with its sign, nor under another sign or as a plain number: it is set aside and named to whoever submitted
 * it (decision D-24, readReportedValue, lab-results/set-aside.ts).
 */
export type StoredComparator = "<" | ">";

/** A sign a report may print before a value. */
type PrintedSign = "<" | ">" | "≤" | "≥";

/**
 * A map, not a plain object: the text looked up comes from a sender, and a plain object would answer "constructor",
 * "toString" or "__proto__" with an inherited member, which is not a sign and must not be read as "no sign".
 */
const PRINTED_SIGNS: ReadonlyMap<string, PrintedSign> = new Map<string, PrintedSign>([
  ["<", "<"],
  [">", ">"],
  ["≤", "≤"],
  ["⩽", "≤"],
  ["<=", "≤"],
  ["=<", "≤"],
  ["≥", "≥"],
  ["⩾", "≥"],
  [">=", "≥"],
  ["=>", "≥"],
]);

/** A reported result as readReportedValue reads it. */
export interface ReportedValue {
  /** The number: the bound itself when the result is a bound. */
  value: number;
  /** "<" or ">" for a bound; null for a measured value, and for a sign that cannot be stored (`review`). */
  comparator: StoredComparator | null;
  /** "≤" or "≥" when the result was printed with one of them: it cannot be stored as printed, and is set aside. */
  review: "≤" | "≥" | null;
}

/** The sign given beside a value, normalized: null for none ("" or "="), undefined when it is not a sign. */
function signBeside(c: unknown): PrintedSign | null | undefined {
  if (c == null) return null;
  if (typeof c !== "string") return undefined;
  const t = c.trim();
  if (t === "" || t === "=") return null;
  return PRINTED_SIGNS.get(t);
}

/**
 * A result as a report or a sender gives it, read into what is stored: `value` is the number, or the text the
 * laboratory printed ("5,4", "<5", ">8,000", read through lab-provider/hl7.ts parseHl7Value), and `comparator`, if
 * given, the sign beside it ("<" or ">"). Only "<" and ">" are stored. A result printed with "≤" or "≥" (also written
 * "<=", ">=", "⩽", "⩾") is returned with no comparator and with `review` set to its sign: every caller sets such a
 * result aside and names it, and processes the rest (D-24, lab-results/screen-results.ts). Null when there is no
 * number, when the comparator is not a sign, or when the text and the sign beside it point opposite ways.
 */
export function readReportedValue(value: unknown, comparator?: unknown): ReportedValue | null {
  const beside = signBeside(comparator);
  if (beside === undefined) return null;
  let number: number;
  let printed: PrintedSign | null = null;
  if (typeof value === "number") {
    number = value;
  } else if (typeof value === "string") {
    // parseHl7Value reads "<" and ">" only; the two-character and slanted forms of "≤" and "≥" are read here.
    const atMost = /^\s*(<=|>=|=<|=>|≤|≥|⩽|⩾)\s*(.*)$/.exec(value);
    if (atMost) {
      const sign = PRINTED_SIGNS.get(atMost[1]);
      if (!sign) return null;
      printed = sign;
      number = parseHl7Number(atMost[2]);
    } else {
      const parsed = parseHl7Value(value);
      if (!parsed) return null;
      number = parsed.value;
      printed = parsed.comparator ?? null;
    }
  } else {
    return null;
  }
  if (!Number.isFinite(number)) return null;
  const signs = [printed, beside].filter((s): s is PrintedSign => s != null);
  const below = signs.map((s) => s === "<" || s === "≤");
  if (below.some((b) => b !== below[0])) return null;
  const review = signs.find((s): s is "≤" | "≥" => s === "≤" || s === "≥") ?? null;
  if (review) return { value: number, comparator: null, review };
  const stored = signs.find((s): s is StoredComparator => s === "<" || s === ">") ?? null;
  return { value: number, comparator: stored, review: null };
}
