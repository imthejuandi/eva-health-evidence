/**
 * The app notices of MedicalDisclaimer.tsx, rendered as the labs page (light) and the dashboard (dark) render them,
 * and the context-needed email, held to docs/signoff/work/governance/wording-rules.md. Every rule is read from that
 * file:
 * - the banned-terms block that check M3 applies, parsed and matched with M3's own functions: its non_critical tier
 *   holds the critical tier's words of section 3.2, its any tier those of section 3.1;
 * - the critical tier's closing vocabulary in the tier table of section 2, which also lists "hoy" (the Spanish block
 *   bans it only in phrases such as "hoy mismo");
 * - the soon urgency of section 2 and the standard safety-net sentence of section 4 (required.out_of_range_closer),
 *   in the Spanish of Part I and the English of Part II.
 */
import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { createElement, type ReactElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { AiNotice, MedicalDisclaimer, OutOfRangeNotice } from "./MedicalDisclaimer";
import { renderContextNeeded } from "@/lib/email/templates/context-needed";
import { lexiconHits, parseLexicon, type TierRules } from "../../../scripts/signoff/checks/messages";

type Lang = "en" | "es";
const LANGS: Lang[] = ["en", "es"];

const ROOT = path.resolve(__dirname, "../../..");
const RULES = fs.readFileSync(path.join(ROOT, "docs/signoff/work/governance/wording-rules.md"), "utf8");
const LEXICON = parseLexicon(RULES);
const BLOCK = JSON.parse(RULES.match(/```json[^\n]*\n([\s\S]*?)\n```/)?.[1] ?? "{}") as Partial<
  Record<Lang, { required?: Record<string, string> }>
>;

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/** The banned words M3 finds in a text under the given tiers of the block, both languages' rules (as M3 scans app files). */
function m3Hits(text: string, tiers: string[]): string[] {
  if (!LEXICON) throw new Error("wording-rules.md has no banned-terms block");
  const hits = new Set<string>();
  for (const lang of LANGS) {
    const rules = tiers.map((t) => LEXICON.langs[lang]?.[t]).filter((r): r is TierRules => !!r);
    if (rules.length !== tiers.length) throw new Error(`wording-rules.md has no ${tiers.join("/")} tier for ${lang}`);
    for (const h of lexiconHits(text, rules, LEXICON.flags)) hits.add(h);
  }
  return [...hits].sort();
}

/** The critical tier's closing vocabulary in the tier table of section 2 ("Crítico" in Part I, "Critical" in Part II). */
function criticalVocabulary(lang: Lang): string[] {
  const row = RULES.split("\n").find((l) => l.startsWith(lang === "es" ? "| **Crítico** |" : "| **Critical** |"));
  if (!row) throw new Error(`wording-rules.md has no critical row in the ${lang} tier table`);
  const lastCell = row.split("|").filter((c) => c.trim()).pop() ?? "";
  return [...lastCell.matchAll(/"([^"]+)"/g)].map((m) => m[1]);
}

/** Words of that vocabulary, either language, found in a text as whole words. */
function criticalWords(text: string): string[] {
  return LANGS.flatMap(criticalVocabulary)
    .filter((w) => new RegExp(`(?<![\\p{L}])${escapeRe(w)}(?![\\p{L}])`, "iu").test(text))
    .map((w) => w.toLowerCase())
    .sort();
}

/** An urgency phrase of section 2, by its label: "soon" in Part II, "pronto" in Part I. */
function urgency(label: string): string {
  const m = RULES.match(new RegExp(`^- \\*\\*${label}:\\*\\* "([^"]+)"`, "m"));
  if (!m) throw new Error(`wording-rules.md has no ${label} urgency`);
  return m[1];
}

const SOON: Record<Lang, string> = { en: urgency("soon"), es: urgency("pronto") };
const CLOSER: Record<Lang, string | undefined> = {
  en: BLOCK.en?.required?.out_of_range_closer,
  es: BLOCK.es?.required?.out_of_range_closer,
};

const decode = (s: string) =>
  s.replace(/&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");

/** The text nodes of rendered markup, in order. */
const textNodes = (html: string) => html.split(/<[^>]*>/).map((s) => decode(s).trim()).filter(Boolean);

/** Every string a client can read or hear: the text nodes and the aria-labels. */
const clientStrings = (html: string) => [
  ...textNodes(html),
  ...[...html.matchAll(/aria-label="([^"]*)"/g)].map((m) => decode(m[1])),
];

const render = (el: ReactElement) => renderToStaticMarkup(el);

type Notice = [name: string, element: (locale: Lang) => ReactElement];

/** The notices as the pages render them: the labs page on cream (light), the dashboard on the dark band. */
const NOTICES: Notice[] = [
  ["MedicalDisclaimer", (locale) => createElement(MedicalDisclaimer, { locale })],
  ["MedicalDisclaimer, dark", (locale) => createElement(MedicalDisclaimer, { locale, tone: "dark" })],
  ["AiNotice", (locale) => createElement(AiNotice, { locale })],
  ["OutOfRangeNotice, no count", (locale) => createElement(OutOfRangeNotice, { locale })],
  ["OutOfRangeNotice, one value", (locale) => createElement(OutOfRangeNotice, { locale, count: 1 })],
  ["OutOfRangeNotice, three values, dark", (locale) => createElement(OutOfRangeNotice, { locale, count: 3, tone: "dark" })],
];
const CASES: [string, Lang, Notice[1]][] = NOTICES.flatMap(([name, el]) => LANGS.map((lang): [string, Lang, Notice[1]] => [name, lang, el]));

const contextNeeded = (lang: Lang) =>
  renderContextNeeded({ firstName: "Ana", biomarkerCount: 13, locale: lang, contextUrl: "https://eva.example/labs/1/context" }, lang);

describe("the rules this test reads from wording-rules.md", () => {
  it("finds the banned-terms block, the critical tier's vocabulary and the required sentences", () => {
    expect(LEXICON).not.toBeNull();
    for (const lang of LANGS) {
      expect(LEXICON?.langs[lang]?.non_critical?.regex.length).toBeGreaterThan(0);
      expect(criticalVocabulary(lang).length).toBeGreaterThan(0);
      expect(SOON[lang].length).toBeGreaterThan(0);
      expect(CLOSER[lang]?.length).toBeGreaterThan(0);
    }
  });

  // The withdrawn copy, quoted from the previous version of these files. The dropped Spanish emergency-services
  // sentence is checked by name below: "emergencia" is in neither the Spanish block nor the tier table.
  it.each([
    ["One of your markers is outside the reference range and may need prompt medical attention. Contact a healthcare professional to review it — this is not a diagnosis."],
    ["Algunos de tus marcadores están fuera del rango de referencia y podrían necesitar atención médica pronta. Contacta con un profesional sanitario para revisarlos; no es un diagnóstico."],
    ["In an emergency, contact your local emergency services."],
    ["This makes sure your interpretation accounts for what's actually true for you today. Takes about 30 seconds."],
    ["Esto nos asegura que tu interpretacion tenga en cuenta lo que es real para ti hoy. Toma 30 segundos."],
  ])("catches the withdrawn copy: %s", (text) => {
    expect([...m3Hits(text, ["non_critical"]), ...criticalWords(text)]).not.toEqual([]);
  });
});

describe("no notice uses the critical tier's words", () => {
  it.each(CASES)("%s (%s): none of section 3.2 or of the tier table", (_name, lang, el) => {
    const strings = clientStrings(render(el(lang)));
    expect(strings.length).toBeGreaterThan(0);
    for (const s of strings) {
      expect(m3Hits(s, ["non_critical"]), s).toEqual([]);
      expect(criticalWords(s), s).toEqual([]);
    }
  });

  it.each(CASES)("%s (%s): none of the words banned in any tier (section 3.1)", (_name, lang, el) => {
    for (const s of clientStrings(render(el(lang)))) expect(m3Hits(s, ["any"]), s).toEqual([]);
  });

  it.each(NOTICES)("%s says as much in Spanish as in English", (_name, el) => {
    const sentences = (s: string) => (s.match(/[.!?](?=\s|$)/g) ?? []).length;
    expect(textNodes(render(el("es"))).map(sentences)).toEqual(textNodes(render(el("en"))).map(sentences));
  });
});

describe("OutOfRangeNotice: a value outside the reference interval", () => {
  const FINDING: Record<Lang, { one: string; several: string }> = {
    en: {
      one: "One of your markers is outside the laboratory's reference interval.",
      several: "Some of your markers are outside the laboratory's reference interval.",
    },
    es: {
      one: "Uno de tus marcadores está fuera del intervalo de referencia del laboratorio.",
      several: "Algunos de tus marcadores están fuera del intervalo de referencia del laboratorio.",
    },
  };
  const KICKER: Record<Lang, string> = { en: "Out of range", es: "Fuera de rango" };

  it.each(LANGS)("says the value is outside the interval, then the soon urgency and the safety-net sentence, word for word (%s)", (lang) => {
    const [kicker, body, ...rest] = textNodes(render(createElement(OutOfRangeNotice, { locale: lang, count: 1 })));
    expect(rest).toEqual([]);
    expect(kicker).toBe(KICKER[lang]);
    expect(body).toBe(`${FINDING[lang].one} ${SOON[lang]} ${CLOSER[lang]}`);
  });

  it.each(LANGS)("speaks of several values only when the count is above one, on either tone (%s)", (lang) => {
    const body = (count: number | undefined, tone: "light" | "dark") =>
      textNodes(render(createElement(OutOfRangeNotice, { locale: lang, count, tone })))[1];
    for (const tone of ["light", "dark"] as const) {
      expect(body(undefined, tone)).toBe(`${FINDING[lang].one} ${SOON[lang]} ${CLOSER[lang]}`);
      expect(body(1, tone)).toBe(`${FINDING[lang].one} ${SOON[lang]} ${CLOSER[lang]}`);
      expect(body(2, tone)).toBe(`${FINDING[lang].several} ${SOON[lang]} ${CLOSER[lang]}`);
      expect(body(14, tone)).toBe(`${FINDING[lang].several} ${SOON[lang]} ${CLOSER[lang]}`);
    }
  });

  it.each(LANGS)("names the tier for screen readers (%s)", (lang) => {
    const html = render(createElement(OutOfRangeNotice, { locale: lang, count: 2 }));
    expect(html).toContain(`role="note" aria-label="${KICKER[lang]}"`);
  });
});

describe("MedicalDisclaimer: the general notice", () => {
  it.each(LANGS)("has no emergency-services sentence (%s)", (lang) => {
    for (const tone of ["light", "dark"] as const) {
      const text = textNodes(render(createElement(MedicalDisclaimer, { locale: lang, tone }))).join(" ");
      expect(text).toContain(lang === "es" ? "no consejo médico ni un diagnóstico" : "not medical advice or a diagnosis");
      expect(text).not.toMatch(/emergenc/i);
    }
  });

  // It also stands under the EVA AI chat (eva-ai-client.tsx), so it keeps a pointer for a client who feels unwell:
  // the last sentence of the standard closer, word for word (wording-rules.md section 4).
  it.each(LANGS)("ends with the safety-net sentence of the standard closer (%s)", (lang) => {
    const safetyNet = (CLOSER[lang] ?? "").split(/(?<=\.)\s+/).pop() ?? "";
    expect(safetyNet).toMatch(lang === "es" ? /^Si te encuentras mal/ : /^If you feel unwell/);
    for (const tone of ["light", "dark"] as const) {
      const text = textNodes(render(createElement(MedicalDisclaimer, { locale: lang, tone }))).join(" ");
      expect(text.endsWith(safetyNet)).toBe(true);
    }
  });
});

describe("the context-needed email", () => {
  it.each(LANGS)("uses no critical-tier word, nor any word banned in any tier (%s)", (lang) => {
    const strings = clientStrings(contextNeeded(lang));
    expect(strings.length).toBeGreaterThan(0);
    for (const s of strings) {
      expect(m3Hits(s, ["any", "non_critical"]), s).toEqual([]);
      expect(criticalWords(s), s).toEqual([]);
    }
  });
});
