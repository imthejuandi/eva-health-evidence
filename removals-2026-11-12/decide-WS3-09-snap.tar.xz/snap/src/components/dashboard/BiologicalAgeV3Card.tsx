import { FONT_CLASS } from "@/lib/dashboard-tokens";
import type { BioAgeV3View } from "@/lib/biomarkers/bio-age-v3-display";

/**
 * Biological age version 3 card. Renders a view built on the server by bio-age-v3-display.ts (buildBioAgeV3View)
 * from the stored record; it receives strings only, never the record. The server page builds the view only when
 * BIO_AGE_V3_VISIBLE is true (bio-age-flags.ts); with no view, nothing is rendered.
 *
 * What it always shows with a figure: the 95% range on the same line, the direction sentence (younger or older only
 * when the range excludes the age), the US reference population and "not a diagnosis". With no figure: the reasons
 * in plain words. Both: the flat segments of the model, folded.
 */
export function BiologicalAgeV3Card({ view }: { view: BioAgeV3View | null }) {
  if (!view) return null;
  return (
    <section
      aria-labelledby="bio-age-v3-title"
      className="rounded-[16px] border border-[#1d1b18]/10 bg-white/60 px-5 py-5 md:px-7 md:py-6"
    >
      <h2
        id="bio-age-v3-title"
        className={`${FONT_CLASS.dmMono} text-[10px] font-semibold uppercase tracking-[2px] text-[#8a7f76]`}
      >
        {view.title}
      </h2>

      {view.kind === "figure" ? (
        <div className="mt-3 space-y-2">
          <p className={`${FONT_CLASS.cormorant} text-[28px] font-medium leading-[1.2] text-[#1d1b18] md:text-[34px]`}>
            {view.figure}
          </p>
          {view.directionText && (
            <p className={`${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#1d1b18]`}>{view.directionText}</p>
          )}
          {view.provisionalText && (
            <p
              role="note"
              className={`${FONT_CLASS.manrope} rounded-[10px] border border-[#c49332]/40 bg-[#c49332]/[0.08] px-3 py-2 text-[13px] leading-[1.6] text-[#1d1b18]`}
            >
              {view.provisionalText}
            </p>
          )}
          {view.changeText && (
            <p className={`${FONT_CLASS.manrope} text-[14px] leading-[1.6] text-[#1d1b18]`}>{view.changeText}</p>
          )}
        </div>
      ) : (
        <div className="mt-3 space-y-2">
          <p className={`${FONT_CLASS.manrope} text-[15px] font-semibold leading-[1.5] text-[#1d1b18]`}>
            {view.refusalHeading}
          </p>
          <ul className={`${FONT_CLASS.manrope} list-disc space-y-1 pl-5 text-[14px] leading-[1.6] text-[#1d1b18]`}>
            {view.refusalReasons.map((r) => (
              <li key={r}>{r}</li>
            ))}
          </ul>
          {view.refusalCloser && (
            <p className={`${FONT_CLASS.manrope} text-[13px] leading-[1.6] text-[#8a7f76]`}>{view.refusalCloser}</p>
          )}
        </div>
      )}

      <p className={`mt-4 ${FONT_CLASS.manrope} text-[12px] leading-[1.6] text-[#8a7f76]`}>{view.reference}</p>
      {view.kind === "figure" && (
        <p className={`mt-1 ${FONT_CLASS.manrope} text-[12px] leading-[1.6] text-[#8a7f76]`}>{view.notDiagnosis}</p>
      )}

      <details className="mt-4">
        <summary className={`${FONT_CLASS.manrope} cursor-pointer text-[13px] font-semibold text-[#3a665e]`}>
          {view.flatHeading}
        </summary>
        <p className={`mt-2 ${FONT_CLASS.manrope} text-[13px] leading-[1.6] text-[#1d1b18]`}>{view.flatIntro}</p>
        <ul className={`mt-2 ${FONT_CLASS.manrope} list-disc space-y-1 pl-5 text-[13px] leading-[1.6] text-[#1d1b18]`}>
          {view.flatSegments.map((s) => (
            <li key={s}>{s}</li>
          ))}
        </ul>
      </details>
    </section>
  );
}
