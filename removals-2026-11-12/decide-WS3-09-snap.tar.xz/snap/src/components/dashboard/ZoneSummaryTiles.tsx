"use client";

interface ZoneSummaryTilesProps {
  optimal: number;
  attention: number;
  action: number;
  locale?: string;
}

export function ZoneSummaryTiles({ optimal, attention, action, locale = "en" }: ZoneSummaryTilesProps) {
  const t = locale === "es"
    ? { optimal: "Optimo", attention: "Atencion", action: "Fuera de rango" }
    : { optimal: "Optimal", attention: "Attention", action: "Out of range" };

  const tiles = [
    { count: optimal, label: t.optimal, color: "#3a665e", bg: "rgba(58,102,94,0.08)" },
    { count: attention, label: t.attention, color: "#c49332", bg: "rgba(196,147,50,0.08)" },
    { count: action, label: t.action, color: "#b04040", bg: "rgba(176,64,64,0.08)" },
  ];

  return (
    <div className="grid grid-cols-3 gap-4">
      {tiles.map((tile) => (
        <div
          key={tile.label}
          className="rounded-[20px] p-5 text-center shadow-[0_20px_60px_rgba(29,27,24,0.04)]"
          style={{ backgroundColor: tile.bg }}
        >
          <p
            className="font-[family-name:var(--font-manrope)] text-[28px] font-extrabold"
            style={{ color: tile.color }}
          >
            {tile.count}
          </p>
          <p className="mt-1 font-[family-name:var(--font-dm-mono)] text-[10px] font-semibold uppercase tracking-[1.2px] text-[#8a7f76]">
            {tile.label}
          </p>
        </div>
      ))}
    </div>
  );
}
