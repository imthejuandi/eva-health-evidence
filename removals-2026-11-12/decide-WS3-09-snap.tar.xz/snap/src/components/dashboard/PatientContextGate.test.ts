/**
 * The context form's summary view: creatine on file without a dose the reader can read is flagged there too, since a
 * client who taps "Sigue siendo correcto" never sees the editing view's message, and nothing is adjusted.
 */
import { describe, expect, it } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { PatientContextGate } from "./PatientContextGate";
import { emptySnapshot } from "@/lib/patient-context/options";

function summaryWith(dose: string | null, locale: "es" | "en" = "es") {
  const snapshot = { ...emptySnapshot(), supplements: [{ key: "creatine", dose }] };
  return renderToStaticMarkup(
    createElement(PatientContextGate, {
      profileLocale: locale,
      userSex: "male",
      onConfirm: async () => undefined,
      initialVersion: { id: "v1", version_number: 1, is_empty: false, created_at: new Date().toISOString(), snapshot: snapshot as never },
    }),
  );
}

describe("PatientContextGate summary view, creatine dose", () => {
  it("flags creatine with no dose", () => {
    const html = summaryWith(null);
    expect(html).toContain("Creatina · sin dosis");
    expect(html).toContain("Sin la dosis no ajustamos tu creatinina");
    expect(html).toContain("Pulsa «Actualizar» para escribirla.");
  });

  it("flags a dose the reader cannot read", () => {
    const html = summaryWith("1 cacito", "en");
    expect(html).toContain("We can&#x27;t read this dose");
    expect(html).toContain("Tap “Update” to write it.");
  });

  it("says nothing more when the dose is readable", () => {
    const html = summaryWith("5 g");
    expect(html).not.toContain("Sin la dosis");
    expect(html).not.toContain("No podemos leer esta dosis");
    expect(html).not.toContain("role=\"alert\"");
  });
});
