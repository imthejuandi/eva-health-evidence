export { RangeBar } from "./RangeBar";
export { TrendChart } from "./TrendChart";
export { StatusPill } from "./StatusPill";
export { SourceTag } from "./SourceTag";
export { MiniSparkline } from "./MiniSparkline";
export { ZoneSummaryTiles } from "./ZoneSummaryTiles";
export { ActionStepCard } from "./ActionStepCard";
export { BiomarkerRow } from "./BiomarkerRow";
export { WearableSnapshotGrid } from "./WearableSnapshotGrid";

// Editorial primitives — shared design language across dashboard
// sections. Lifted from the home dashboard's inline patterns and
// the investors deck's mobile/chapter-marker conventions. Use these
// instead of re-implementing the same patterns inline per section.
export { EditorialSectionHeader } from "./EditorialSectionHeader";
export { Disclosure } from "./Disclosure";
export { BiomarkerPill } from "./BiomarkerPill";
export { NumberedList } from "./NumberedList";
export { ScrollSnapCarousel } from "./ScrollSnapCarousel";
export { MobileDock } from "./MobileDock";
export { DashboardChrome, AmbientMesh, GrainOverlay } from "./DashboardChrome";
export { KitTimeline } from "./KitTimeline";
export { EditorialMasthead } from "./EditorialMasthead";
export { PrimaryPill } from "./PrimaryPill";
export { GhostLink } from "./GhostLink";
export { EditorialModal } from "./EditorialModal";
export {
  MedicalDisclaimer,
  AiNotice,
  OutOfRangeNotice,
} from "./MedicalDisclaimer";
export { ActivateKitForm } from "./ActivateKitForm";
