"use client";

import { FONT_CLASS, BRAND } from "@/lib/dashboard-tokens";

/* ──────────────────────────────────────────────────────────────────────────
 * Medical-safety surface — shared, bilingual (EN/ES) point-of-use notices.
 *
 * Closes CLAIM-006 ("medical disclaimer absent at point of use") and the
 * surfaceable parts of AI-001 / AI-011 from the Wave-2 audit:
 *
 *   • MedicalDisclaimer  — concise "educational, not medical advice" notice,
 *                          rendered adjacent to every result / AI surface.
 *   • AiNotice           — short "you're reading AI output, not a doctor"
 *                          kicker for the EVA chat (AI Act Art. 50 / AI-011).
 *   • OutOfRangeNotice   — shown when a biomarker sits outside the reference
 *                          interval of the laboratory (out-of-range tier).
 *
 * The copy follows docs/signoff/work/governance/wording-rules.md: Part I is
 * the Spanish, Part II the English. No notice uses the vocabulary of the
 * critical tier (section 3.2). That tier, the critical-value escalation of
 * AI-003, gets a notice only once a zone fed by the signed critical limits
 * exists, behind its server flag.
 *
 * Deliberately truthful and minimal: it does NOT claim any human / clinician
 * clinical review (there is no clinician on staff — the sign-off workflow is
 * out of scope for this ticket). Copy stays visually quiet/secondary to match
 * the app's editorial style; it reduces, never adds, medical claims.
 * ────────────────────────────────────────────────────────────────────────── */

type Tone = "light" | "dark";

/* Per-tone ink so the notice reads as quiet secondary text on both the
 * cream surfaces (labs / dashboard light) and the dark terra-deep Findings
 * band (#5a2716). Mirrors the muted-ink tokens used elsewhere. */
const TONE: Record<Tone, { rule: string; kicker: string; body: string }> = {
  light: {
    rule: "rgba(29,27,24,0.14)",
    kicker: BRAND.inkDim, // #8a7f76
    body: "rgba(29,27,24,0.55)",
  },
  dark: {
    rule: "rgba(253,237,214,0.22)",
    kicker: "rgba(253,237,214,0.55)",
    body: "rgba(253,237,214,0.62)",
  },
};

interface MedicalDisclaimerProps {
  locale: string;
  /** Surface tone — "light" for cream backgrounds (default), "dark" for the
   * terra-deep Findings band. */
  tone?: Tone;
  className?: string;
}

/**
 * MedicalDisclaimer — the concise, muted "not medical advice" line surfaced
 * at the point where a user reads interpretations. Small mono kicker + a
 * single secondary sentence, led by a hairline rule to match the editorial
 * section markers.
 */
export function MedicalDisclaimer({
  locale,
  tone = "light",
  className,
}: MedicalDisclaimerProps) {
  const isEs = locale === "es";
  const c = TONE[tone];

  const kicker = isEs ? "Aviso médico" : "Medical notice";
  // No emergency-services sentence: that vocabulary belongs to the critical
  // tier only (wording-rules.md section 3.2; Part IV asks the physician whether
  // to allow it here). The notice keeps the standard safety-net sentence
  // (section 4) instead, since it also stands under the EVA AI chat, where a
  // client may describe how they feel.
  const body = isEs
    ? "EVA es una herramienta educativa, no consejo médico ni un diagnóstico. Consulta siempre a un profesional sanitario colegiado antes de actuar sobre estos resultados. Si te encuentras mal, no esperes a la siguiente cita."
    : "EVA is an educational tool, not medical advice or a diagnosis. Always consult a licensed healthcare professional before acting on these results. If you feel unwell, do not wait for your next appointment.";

  return (
    <aside
      role="note"
      aria-label={kicker}
      className={`flex flex-col gap-2 ${className ?? ""}`}
    >
      <div className="flex items-center gap-2.5">
        <span
          aria-hidden
          className="inline-block h-px w-6 md:w-8"
          style={{ backgroundColor: c.rule }}
        />
        <p
          className={`${FONT_CLASS.dmMono} text-[9px] font-semibold uppercase tracking-[1.6px] md:text-[9.5px]`}
          style={{ color: c.kicker }}
        >
          {kicker}
        </p>
      </div>
      <p
        className={`max-w-[62ch] ${FONT_CLASS.manrope} text-[11px] leading-[1.55] md:text-[11.5px]`}
        style={{ color: c.body, textWrap: "pretty" as const }}
      >
        {body}
      </p>
    </aside>
  );
}

interface AiNoticeProps {
  locale: string;
  tone?: Tone;
  className?: string;
}

/**
 * AiNotice — short "this is AI, not a doctor" kicker for the EVA chat
 * surface. Satisfies the AI-001 "AI-generated educational information"
 * framing and the AI Act Art. 50 transparency duty (AI-011): the user is
 * told, at the point of interaction, that EVA is an AI assistant and not a
 * clinician. Intentionally does not assert human clinical review.
 */
export function AiNotice({ locale, tone = "light", className }: AiNoticeProps) {
  const isEs = locale === "es";
  const c = TONE[tone];

  const label = isEs ? "IA · No es un médico" : "AI · Not a doctor";
  const body = isEs
    ? "Estás hablando con una IA. EVA genera información educativa a partir de tus datos; no es un profesional sanitario y ningún clínico revisa sus respuestas."
    : "You're chatting with an AI. EVA generates educational information from your data; it is not a healthcare professional and its replies are not reviewed by a clinician.";

  return (
    <div
      role="note"
      aria-label={label}
      className={`flex flex-wrap items-center gap-x-2.5 gap-y-1 ${className ?? ""}`}
    >
      <span
        className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 ${FONT_CLASS.dmMono} text-[9px] font-semibold uppercase tracking-[1.4px]`}
        style={{
          borderColor: c.rule,
          color: c.kicker,
        }}
      >
        <span
          aria-hidden
          className="h-1.5 w-1.5 rounded-full"
          style={{ backgroundColor: c.kicker }}
        />
        {label}
      </span>
      <span
        className={`${FONT_CLASS.manrope} text-[11px] leading-[1.5] md:text-[11.5px]`}
        style={{ color: c.body }}
      >
        {body}
      </span>
    </div>
  );
}

interface OutOfRangeNoticeProps {
  locale: string;
  /** Number of biomarkers outside the reference interval, when known. Used
   * to pluralise the EN/ES copy; omit for a single-value notice. */
  count?: number;
  /** Surface tone of the parent. "light" (default) sits on cream; "dark"
   * renders an opaque cream callout so the body ink stays legible on the
   * dark terra-deep band. The accents are identical in both. */
  tone?: Tone;
  className?: string;
}

/**
 * OutOfRangeNotice — shown at the point of use when one or more biomarkers
 * sit outside the reference interval of the laboratory: the stored zone
 * codes critical_low and critical_high, which name the out-of-range tier and
 * are not critical values (wording-rules.md section 2). The caller passes the
 * count it already computed from each biomarker zone; zones are not
 * recomputed here.
 *
 * A hairline-framed callout, quiet and secondary. It says the value is
 * outside the interval, then the soon urgency of section 2 and the standard
 * safety-net sentence of section 4, each word for word.
 */
export function OutOfRangeNotice({
  locale,
  count,
  tone = "light",
  className,
}: OutOfRangeNoticeProps) {
  const isEs = locale === "es";
  const danger = BRAND.danger; // #b04040
  const plural = (count ?? 1) > 1;
  // On a dark band the faint 6%-red wash leaves the dark body ink
  // unreadable, so render an opaque cream surface there instead.
  const surface =
    tone === "dark" ? "rgba(254,248,242,0.94)" : "rgba(176,64,64,0.06)";

  const kicker = isEs ? "Fuera de rango" : "Out of range";
  const finding = isEs
    ? plural
      ? "Algunos de tus marcadores están fuera del intervalo de referencia del laboratorio."
      : "Uno de tus marcadores está fuera del intervalo de referencia del laboratorio."
    : plural
      ? "Some of your markers are outside the laboratory's reference interval."
      : "One of your markers is outside the laboratory's reference interval.";
  // wording-rules.md section 2, the soon urgency.
  const soon = isEs
    ? "Pide cita con tu médico en las próximas semanas."
    : "Book an appointment with your doctor in the next few weeks.";
  // wording-rules.md section 4, the standard safety-net sentence, without
  // variation.
  const safetyNet = isEs
    ? "Este resultado no es un diagnóstico. Coméntalo con tu médico, que conoce tu historia. Si te encuentras mal, no esperes a la siguiente cita."
    : "This result is not a diagnosis. Discuss it with your doctor, who knows your history. If you feel unwell, do not wait for your next appointment.";
  const body = [finding, soon, safetyNet].join(" ");

  return (
    <aside
      role="note"
      aria-label={kicker}
      className={`flex items-start gap-3 rounded-[14px] border px-4 py-3 ${className ?? ""}`}
      style={{
        borderColor: "rgba(176,64,64,0.30)",
        backgroundColor: surface,
      }}
    >
      <span
        aria-hidden
        className="mt-[3px] h-2 w-2 shrink-0 rounded-full"
        style={{ backgroundColor: danger }}
      />
      <div className="flex flex-col gap-1">
        <p
          className={`${FONT_CLASS.dmMono} text-[9.5px] font-semibold uppercase tracking-[1.6px]`}
          style={{ color: danger }}
        >
          {kicker}
        </p>
        <p
          className={`max-w-[60ch] ${FONT_CLASS.manrope} text-[12px] leading-[1.55] text-[#1d1b18]/80 md:text-[12.5px]`}
          style={{ textWrap: "pretty" as const }}
        >
          {body}
        </p>
      </div>
    </aside>
  );
}
