/**
 * SUPERSEDED (OPS-001 fix): Sentry is now initialized via the Next.js
 * instrumentation convention — see `src/instrumentation.ts` (server/edge)
 * and `src/instrumentation-client.ts` (browser). Both are env-gated:
 * without SENTRY_DSN / NEXT_PUBLIC_SENTRY_DSN they are no-ops.
 *
 * This file is kept only so older docs that reference it don't dangle;
 * it intentionally initializes nothing.
 */
export {};
