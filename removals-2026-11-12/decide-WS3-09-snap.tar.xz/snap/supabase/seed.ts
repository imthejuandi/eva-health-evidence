/**
 * Biomarker reference range seed script.
 *
 * Usage: pnpm tsx supabase/seed.ts
 *   (or: npx tsx supabase/seed.ts)
 *
 * Requires NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY env vars.
 */

import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "fs";
import { resolve } from "path";

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error(
    "Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY"
  );
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// ---------------------------------------------------------------------------
// Load JSON files
// ---------------------------------------------------------------------------

// Default to the committed copies inside the repo. Override with
// BIOMARKER_EN_PATH / BIOMARKER_ES_PATH env vars if you want to seed from
// a different source (e.g. a local working copy of the source-of-truth).
const EN_PATH = resolve(
  process.env.BIOMARKER_EN_PATH ??
    `${__dirname}/seed-data/biomarker-ranges-en.json`
);
const ES_PATH = resolve(
  process.env.BIOMARKER_ES_PATH ??
    `${__dirname}/seed-data/rangos-biomarcadores-es.json`
);

interface EnRow {
  Category: string;
  Biomarker: string;
  Unit: string;
  Sex: string;
  Age_Group: string;
  Normal_Low: number | null;
  Normal_High: number | null;
  Optimal_Low: number | null;
  Optimal_High: number | null;
  Tested_2x_Year: string;
  Clinical_Notes: string | null;
  Msg_Critical_Low: string | null;
  Msg_Below_Optimal: string | null;
  Msg_Optimal: string | null;
  Msg_Above_Optimal: string | null;
  Msg_Critical_High: string | null;
}

interface EsRow {
  Categoría: string;
  Biomarcador: string;
  Unidad: string;
  Sexo: string;
  Grupo_Edad: string;
  Normal_Bajo: number | null;
  Normal_Alto: number | null;
  Óptimo_Bajo: number | null;
  Óptimo_Alto: number | null;
  Analizado_2x_Año: string;
  Notas_Clínicas: string | null;
  Msg_Crítico_Bajo: string | null;
  Msg_Debajo_Óptimo: string | null;
  Msg_Óptimo: string | null;
  Msg_Encima_Óptimo: string | null;
  Msg_Crítico_Alto: string | null;
}

const enData: EnRow[] = JSON.parse(readFileSync(EN_PATH, "utf-8")).biomarker_ranges;
const esData: EsRow[] = JSON.parse(readFileSync(ES_PATH, "utf-8")).rangos_biomarcadores;

if (enData.length !== esData.length) {
  console.error(
    `Row count mismatch: EN=${enData.length} ES=${esData.length}`
  );
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[()]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

function normalizeSex(sex: string): string {
  const map: Record<string, string> = {
    Both: "both",
    Ambos: "both",
    Male: "male",
    Masculino: "male",
    Female: "female",
    Femenino: "female",
  };
  return map[sex] ?? sex.toLowerCase();
}

/** Map EN category names to panel_category slugs */
function mapCategory(category: string): string {
  const map: Record<string, string> = {
    Heart: "cardiovascular",
    Thyroid: "thyroid",
    Autoimmunity: "autoimmunity",
    "Immune Regulation": "immune",
    "Female Health": "hormonal",
    "Male Health": "hormonal",
    Metabolic: "metabolic",
    "Environmental Toxins": "environmental",
    "Biological Age": "biological_age",
    Nutrients: "nutrients",
    "Stress & Aging": "stress_aging",
    Liver: "liver",
    Blood: "blood",
    Kidneys: "kidneys",
    Pancreas: "pancreas",
  };
  return map[category] ?? slugify(category);
}

// ---------------------------------------------------------------------------
// Base panel biomarker names (EN)
// ---------------------------------------------------------------------------

const BASE_PANEL_NAMES = new Set([
  // CBC — maps to individual CBC components present in the dataset
  "White Blood Cell Count",
  "Red Blood Cell Count",
  "Hemoglobin",
  "Hematocrit",
  "Platelet Count",
  "MCV",
  "MCH",
  "MCHC",
  "RDW",
  "MPV",
  // Individual named base biomarkers
  "Glucose (Fasting)",
  "HbA1c",
  "Total Cholesterol",
  "LDL Cholesterol",
  "HDL Cholesterol",
  "Triglycerides",
  "Ferritin",
  "Vitamin D (25-OH)",
  "TSH",
  "ALT",
  "AST",
  "hs-CRP",
  "Creatinine",
  "Uric Acid",
]);

const GENETIC_BIOMARKERS = new Set(["Lipoprotein(a)"]);

// ---------------------------------------------------------------------------
// Build rows
// ---------------------------------------------------------------------------

interface SeedRow {
  biomarker_key: string;
  name_en: string;
  name_es: string;
  unit_en: string;
  unit_es: string;
  sex: string;
  age_group_en: string;
  age_group_es: string;
  normal_low: number | null;
  normal_high: number | null;
  optimal_low: number | null;
  optimal_high: number | null;
  tested_2x_year: boolean;
  panel_category: string;
  is_base_panel: boolean;
  is_genetic: boolean;
  clinical_notes_en: string | null;
  clinical_notes_es: string | null;
  msg_critical_low_en: string | null;
  msg_critical_low_es: string | null;
  msg_below_optimal_en: string | null;
  msg_below_optimal_es: string | null;
  msg_optimal_en: string | null;
  msg_optimal_es: string | null;
  msg_above_optimal_en: string | null;
  msg_above_optimal_es: string | null;
  msg_critical_high_en: string | null;
  msg_critical_high_es: string | null;
}

const rows: SeedRow[] = [];

for (let i = 0; i < enData.length; i++) {
  const en = enData[i];
  const es = esData[i];

  rows.push({
    biomarker_key: slugify(en.Biomarker),
    name_en: en.Biomarker,
    name_es: es.Biomarcador,
    unit_en: en.Unit,
    unit_es: es.Unidad,
    sex: normalizeSex(en.Sex),
    age_group_en: en.Age_Group,
    age_group_es: es.Grupo_Edad,
    normal_low: en.Normal_Low,
    normal_high: en.Normal_High,
    optimal_low: en.Optimal_Low,
    optimal_high: en.Optimal_High,
    tested_2x_year: en.Tested_2x_Year === "Yes",
    panel_category: mapCategory(en.Category),
    is_base_panel: BASE_PANEL_NAMES.has(en.Biomarker),
    is_genetic: GENETIC_BIOMARKERS.has(en.Biomarker),
    clinical_notes_en: en.Clinical_Notes,
    clinical_notes_es: es.Notas_Clínicas,
    msg_critical_low_en: en.Msg_Critical_Low,
    msg_critical_low_es: es.Msg_Crítico_Bajo,
    msg_below_optimal_en: en.Msg_Below_Optimal,
    msg_below_optimal_es: es.Msg_Debajo_Óptimo,
    msg_optimal_en: en.Msg_Optimal,
    msg_optimal_es: es.Msg_Óptimo,
    msg_above_optimal_en: en.Msg_Above_Optimal,
    msg_above_optimal_es: es.Msg_Encima_Óptimo,
    msg_critical_high_en: en.Msg_Critical_High,
    msg_critical_high_es: es.Msg_Crítico_Alto,
  });
}

// ---------------------------------------------------------------------------
// Insert
// ---------------------------------------------------------------------------

async function seed() {
  console.log(`Seeding ${rows.length} biomarker reference ranges...`);

  // Upsert in batches of 50
  const BATCH_SIZE = 50;
  let inserted = 0;

  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const { error } = await supabase
      .from("biomarker_references")
      .upsert(batch, {
        onConflict: "biomarker_key,sex,age_group_en",
      });

    if (error) {
      console.error(`Error at batch ${i}:`, error.message);
      console.error("First row in batch:", JSON.stringify(batch[0], null, 2));
      process.exit(1);
    }
    inserted += batch.length;
    console.log(`  ${inserted}/${rows.length} rows inserted`);
  }

  // Summary
  const baseCount = rows.filter((r) => r.is_base_panel).length;
  const geneticCount = rows.filter((r) => r.is_genetic).length;
  const categories = [...new Set(rows.map((r) => r.panel_category))];

  console.log("\nSeed complete:");
  console.log(`  Total rows: ${rows.length}`);
  console.log(`  Base panel rows: ${baseCount}`);
  console.log(`  Genetic marker rows: ${geneticCount}`);
  console.log(`  Categories: ${categories.join(", ")}`);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
