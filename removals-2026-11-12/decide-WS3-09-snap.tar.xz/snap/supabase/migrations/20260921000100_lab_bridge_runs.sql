-- ============================================================================
-- `lab_bridge_runs`: una fila por pasada del bridge (cron o botón).
--
-- Petición de Juan (2026-09-21): el resumen del botón desaparecía al recargar,
-- y el cron corre sin nadie mirando — la mesa de fulfillment necesita ver
-- siempre la última pasada y las anteriores. PHI: ninguna (solo contadores,
-- nombres de fichero y mensajes de alerta). RLS cerrada: escribe el bridge
-- con service-role, lee el panel de admin con service-role. Retención: el
-- propio bridge borra lo anterior a 90 días en cada pasada.
-- ============================================================================

create table if not exists public.lab_bridge_runs (
  id uuid primary key default gen_random_uuid(),
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  trigger text not null,              -- 'cron' | 'admin'
  processing_id text not null,        -- 'P' | 'T'
  ok boolean not null,
  error text,                         -- connection or configuration failure
  uploaded integer not null default 0,
  acks integer not null default 0,
  orus integer not null default 0,
  duplicates integer not null default 0,
  other_env integer not null default 0,
  errors jsonb not null default '[]'::jsonb,
  alerts jsonb not null default '[]'::jsonb,
  summary text not null,
  ms integer
);

create index if not exists idx_lab_bridge_runs_started
  on public.lab_bridge_runs (started_at desc);

alter table public.lab_bridge_runs enable row level security;

comment on table public.lab_bridge_runs is
  'One row per lab-bridge pass (cron or admin button): counters, file names, errors and alerts. No PHI. Service-role only; pruned by the bridge after 90 days.';
