-- ============================================================================
-- F7c — `lab_messages.sent_at`: cuándo subió el bridge el mensaje, que NO es
-- lo mismo que cuándo se encoló.
--
-- El vigilante de OMLs sin ACK (bridge sync §4) medía el timeout contra
-- `created_at`, la hora de encolado. Un pedido encolado el 09-09 y subido el
-- 09-15 (el buzón de ECH nos denegaba la escritura) disparaba la alerta
-- "OML sent without ACK past the timeout" en la misma pasada que lo subió.
-- El store en memoria de los tests ya usaba la hora real de envío, así que la
-- divergencia vivía solo en la implementación Supabase y los tests no la veían.
--
-- Backfill: lo ya subido toma la hora real del ciclo (`oml_sent_at`); si no la
-- hay, cae a `created_at` (comportamiento anterior, nunca peor).
-- ============================================================================

alter table public.lab_messages
  add column if not exists sent_at timestamptz;

update public.lab_messages m
   set sent_at = coalesce(c.oml_sent_at, m.created_at)
  from public.test_cycles c
 where c.id = m.cycle_id
   and m.direction = 'out'
   and m.status = 'sent'
   and m.sent_at is null;

update public.lab_messages
   set sent_at = created_at
 where direction = 'out'
   and status = 'sent'
   and sent_at is null;

-- Barrido de §4: outbound enviados esperando ACK, por hora de envío.
create index if not exists idx_lab_messages_awaiting_ack
  on public.lab_messages (sent_at)
  where direction = 'out' and status = 'sent';

comment on column public.lab_messages.sent_at is
  'When the bridge actually uploaded the message to the lab mailbox. The ACK timeout is measured from here, never from created_at (queued time): a message can sit queued for days if the mailbox refuses writes.';
