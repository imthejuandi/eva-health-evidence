-- ============================================================================
-- Track Full Panel one-time purchases as a paid-feature entitlement.
--
-- Two paid plans exist:
--   - Quarterly subscription. Captured by subscription_status = 'active'.
--   - Full Panel one-time payment. Was previously invisible at the row
--     level: subscription_status stayed 'free' because the user is not on
--     a recurring plan. That made it impossible to gate features like
--     EVA AI chat or wearable imports on "any paid plan", which is the
--     entitlement we now want.
--
-- This column captures the moment a user completed the Full Panel
-- checkout. Set by the Stripe webhook on checkout.session.completed when
-- session.metadata.plan === 'full_panel'. Once set it persists forever:
-- a Full Panel buyer keeps access to paid features even though there is
-- no recurring entitlement to refresh.
--
-- Business policy: anyone with subscription_status = 'active' OR a
-- non-null full_panel_purchased_at is a paying user. See hasPaidAccess()
-- in src/lib/stripe/helpers.ts.
-- ============================================================================

alter table public.profiles
  add column if not exists full_panel_purchased_at timestamptz;

comment on column public.profiles.full_panel_purchased_at is 'Timestamp of the user''s first Full Panel one-time purchase. Non-null means the user has paid for the Full Panel at least once and retains access to paid-only features (EVA AI chat, wearable imports) even without an active subscription.';

-- ----------------------------------------------------------------------------
-- Backfill for buyers from before this migration.
--
-- Without it, anyone who completed a Full Panel checkout before today
-- would unexpectedly lose access to EVA AI chat and wearable imports
-- the moment the paid-feature gates ship, because their
-- full_panel_purchased_at would still be NULL.
--
-- Source of truth: the booked_tests row inserted by the Stripe webhook
-- on checkout.session.completed (panel_type='full', any non-cancelled
-- status). We pick the EARLIEST such row per user as the canonical
-- purchase timestamp.
--
-- The is null guard keeps this idempotent; re-running the migration
-- never overwrites a value already set by the webhook.
-- ----------------------------------------------------------------------------
update public.profiles p
set full_panel_purchased_at = sub.first_purchase
from (
  select user_id, min(created_at) as first_purchase
  from public.booked_tests
  where panel_type = 'full'
    and status <> 'cancelled'
  group by user_id
) sub
where sub.user_id = p.id
  and p.full_panel_purchased_at is null;
