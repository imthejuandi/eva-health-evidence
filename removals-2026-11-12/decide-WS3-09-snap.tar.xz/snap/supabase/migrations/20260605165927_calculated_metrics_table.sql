-- ============================================================================
-- RECUPERADA DE LIVE (reparación OPS-004, paso 1).
-- Aplicada a producción fuera del flujo el 2026-06-05 (versión live
-- 20260605165927_calculated_metrics_table); SQL reconstruido en solo-lectura
-- desde el catálogo de producción el 2026-08-25 (0 filas en la recuperación).
--
-- Métricas derivadas por lab (ratios, índices compuestos) calculadas por el
-- motor de biomarcadores; una fila por (lab_result, metric_key). El acceso
-- del usuario se deriva de la propiedad del lab_result padre.
-- ============================================================================

create table if not exists public.calculated_metrics (
  id uuid primary key default gen_random_uuid(),
  lab_result_id uuid not null references public.lab_results(id) on delete cascade,
  metric_key text not null,
  metric_name text not null,
  value numeric not null,
  unit text not null default '',
  zone text not null,
  interpretation text,
  interpretation_es text,
  created_at timestamptz not null default now(),
  unique (lab_result_id, metric_key)
);

alter table public.calculated_metrics enable row level security;

drop policy if exists "Users can view own calculated metrics" on public.calculated_metrics;
create policy "Users can view own calculated metrics"
  on public.calculated_metrics for select
  using (exists (
    select 1 from public.lab_results lr
    where lr.id = calculated_metrics.lab_result_id and lr.user_id = auth.uid()
  ));

drop policy if exists "Users can insert own calculated metrics" on public.calculated_metrics;
create policy "Users can insert own calculated metrics"
  on public.calculated_metrics for insert
  with check (exists (
    select 1 from public.lab_results lr
    where lr.id = calculated_metrics.lab_result_id and lr.user_id = auth.uid()
  ));

drop policy if exists "Users can update own calculated metrics" on public.calculated_metrics;
create policy "Users can update own calculated metrics"
  on public.calculated_metrics for update
  using (exists (
    select 1 from public.lab_results lr
    where lr.id = calculated_metrics.lab_result_id and lr.user_id = auth.uid()
  ))
  with check (exists (
    select 1 from public.lab_results lr
    where lr.id = calculated_metrics.lab_result_id and lr.user_id = auth.uid()
  ));

drop policy if exists "Users can delete own calculated metrics" on public.calculated_metrics;
create policy "Users can delete own calculated metrics"
  on public.calculated_metrics for delete
  using (exists (
    select 1 from public.lab_results lr
    where lr.id = calculated_metrics.lab_result_id and lr.user_id = auth.uid()
  ));
