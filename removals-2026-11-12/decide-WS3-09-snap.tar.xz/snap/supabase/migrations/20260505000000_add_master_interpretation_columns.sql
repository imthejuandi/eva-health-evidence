-- ============================================================================
-- Master interpretation columns (the optimizer-tier source of truth).
--
-- Architecture: every lab interpretation has two representations.
--
--   1. The MASTER, written once at lab upload, always at the optimizer
--      (clinician) tier. This is the authoritative clinical content:
--      same findings, same values, same urgency, same priority order,
--      same recommended actions. Stored in the *_master columns added
--      below. Read-only after generation.
--
--   2. The ACTIVE view, derived from the master and rephrased into the
--      user's currently-selected health_knowledge tier (beginner /
--      familiar / optimizer). Stored in the existing columns the
--      dashboard, /labs and /biomarker pages already read from. When
--      the user changes tier we re-derive the active view from the
--      master without touching the master itself.
--
-- This guarantees that switching tiers can never silently change the
-- clinical interpretation — only the wording. The optimizer tier
-- copies the master verbatim into the active columns (no AI call).
--
-- Existing rows from before this migration carry NULL master columns;
-- the regenerate flow lazily backfills the master on the first tier
-- change for those legacy labs.
-- ============================================================================

alter table public.lab_results
  add column if not exists summary_narrative_master text,
  add column if not exists summary_narrative_master_es text;

alter table public.biomarker_values
  add column if not exists interpretation_master text,
  add column if not exists interpretation_master_es text;

alter table public.action_steps
  add column if not exists title_master text,
  add column if not exists title_master_es text,
  add column if not exists description_master text,
  add column if not exists description_master_es text;

comment on column public.lab_results.summary_narrative_master is 'Optimizer-tier source-of-truth lab summary (English). Generated once at upload, immutable.';
comment on column public.lab_results.summary_narrative_master_es is 'Optimizer-tier source-of-truth lab summary (Spanish).';
comment on column public.biomarker_values.interpretation_master is 'Optimizer-tier source-of-truth per-biomarker interpretation (English). Tier rephrases derive from this.';
comment on column public.biomarker_values.interpretation_master_es is 'Optimizer-tier source-of-truth per-biomarker interpretation (Spanish).';
comment on column public.action_steps.title_master is 'Optimizer-tier source-of-truth action title (English). Tier rephrases derive from this.';
comment on column public.action_steps.title_master_es is 'Optimizer-tier source-of-truth action title (Spanish).';
comment on column public.action_steps.description_master is 'Optimizer-tier source-of-truth action description (English).';
comment on column public.action_steps.description_master_es is 'Optimizer-tier source-of-truth action description (Spanish).';
