-- SEC-011 / GDPR-002: add the owner-scoped DELETE RLS policies that were
-- missing for these tables.
--
-- Without them, a user-authenticated DELETE silently affects 0 rows (Postgres
-- does not raise an error when RLS rejects a DELETE), so user data could be
-- left behind by any delete path running under the user's own session.
--
-- The account-erasure endpoint (api/gdpr/delete) uses the service-role client,
-- which bypasses RLS, so it does not depend on these policies — they close the
-- gap for user-initiated single-row deletes and provide defense in depth.
--
-- Mirrors the SELECT/INSERT policies already defined for each table. Append-only
-- tables (patient_context_versions) and profile/account rows are intentionally
-- excluded: those are erased only via the privileged endpoint above.

-- ─── chat_messages ───
drop policy if exists "Users can delete own messages" on public.chat_messages;
create policy "Users can delete own messages" on public.chat_messages
  for delete using (auth.uid() = user_id);

-- ─── wearable_data ───
drop policy if exists "Users can delete own wearable data" on public.wearable_data;
create policy "Users can delete own wearable data" on public.wearable_data
  for delete using (auth.uid() = user_id);

-- ─── booked_tests ───
drop policy if exists "Users can delete own booked tests" on public.booked_tests;
create policy "Users can delete own booked tests" on public.booked_tests
  for delete using (auth.uid() = user_id);

-- ─── storage.objects (lab-uploads bucket) ───
-- Mirrors the existing own-folder insert/select policies so users can remove
-- their own uploaded files.
drop policy if exists "Users can delete own uploads" on storage.objects;
create policy "Users can delete own uploads" on storage.objects
  for delete using (
    bucket_id = 'lab-uploads' and (storage.foldername(name))[1] = auth.uid()::text
  );
