-- ============================================================================
-- Add shipping address columns to profiles
--
-- Stripe Checkout collects the address on every paid checkout session via
-- shipping_address_collection. The webhook handler reads it back from
-- session.shipping_details on checkout.session.completed and persists it to
-- these columns. The user can later edit them from the profile page.
--
-- Country defaults to 'ES' since we currently only ship within Spain. When
-- we expand internationally the allowed_countries list in
-- src/app/api/stripe/checkout/route.ts and the default below should both
-- be revised.
-- ============================================================================

alter table public.profiles
  add column if not exists address_line1 text,
  add column if not exists address_line2 text,
  add column if not exists address_city text,
  add column if not exists address_postal_code text,
  add column if not exists address_province text,
  add column if not exists address_country text default 'ES',
  add column if not exists phone text;

comment on column public.profiles.address_line1 is 'Street address line 1 (Stripe shipping_details.address.line1)';
comment on column public.profiles.address_line2 is 'Street address line 2 / apt / suite (Stripe shipping_details.address.line2)';
comment on column public.profiles.address_city is 'City (Stripe shipping_details.address.city)';
comment on column public.profiles.address_postal_code is 'Postal code (Stripe shipping_details.address.postal_code)';
comment on column public.profiles.address_province is 'Province / region — corresponds to Stripe shipping_details.address.state';
comment on column public.profiles.address_country is 'ISO 3166-1 alpha-2 country code (Stripe shipping_details.address.country)';
comment on column public.profiles.phone is 'Phone number for the carrier — captured by Stripe phone_number_collection';
