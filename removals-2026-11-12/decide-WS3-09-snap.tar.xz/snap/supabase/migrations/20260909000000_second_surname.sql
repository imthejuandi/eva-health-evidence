-- Second surname as its own column.
--
-- The Echevarne order needs PID-5.1 (primer apellido) and PID-6.1 (segundo
-- apellido) as SEPARATE fields, and PID-6 is required (R) by the spec. Until
-- now the profile had a single "Apellido" field and the OML builder split it
-- on whitespace, which silently mis-splits compound surnames
-- ("García de la Torre Ruiz" → surname1 "García", surname2 "de la Torre Ruiz").
-- A wrong name on a lab order is a patient-identification defect, so the two
-- surnames are captured explicitly from now on.
--
-- Legacy rows keep `last_name` holding both surnames; the mapper still splits
-- those on whitespace as a fallback until the user edits their profile.
-- Nullable on purpose: no backfill guessing.

alter table public.profiles
  add column if not exists second_surname text;

comment on column public.profiles.last_name is
  'Primer apellido (PID-5.1). Legacy rows may still hold both surnames — see second_surname.';
comment on column public.profiles.second_surname is
  'Segundo apellido (PID-6.1, required by the Echevarne spec). Null on rows created before 2026-09-09.';
