-- ============================================================================
-- NLR row (20260925012000_nlr_row): English name shortened to "NLR", like BUN, MCV and HOMA-IR. The seed files
-- derive each biomarker_key from the English name (slug), and this row's key is nlr, the key the computed
-- metric already uses. The Spanish name stays "Índice Neutrófilo-Linfocito (INL)". Guarded by the current name,
-- so a second run changes nothing.
-- ============================================================================
update public.biomarker_references
   set name_en = 'NLR'
 where biomarker_key = 'nlr' and name_en = 'Neutrophil-to-Lymphocyte Ratio (NLR)';
