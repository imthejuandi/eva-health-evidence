-- Split the `full_name` column on profiles into `first_name` and
-- `last_name` so we can cross-reference individual name components
-- against lab report metadata (lab PDFs typically print first and last
-- name separately, and a single-field "full_name" makes matching
-- unreliable when middle names, surname prefixes, or transposed order
-- are involved).
--
-- Strategy:
-- 1. Add the two columns (nullable — existing rows may not fit the
--    assumption that the first space separates first from last).
-- 2. Backfill naively: everything before the first space goes to
--    first_name, everything after goes to last_name. Users can refine
--    on their profile page.
-- 3. Keep full_name in place as a compatibility column — the
--    onboarding and profile flows will now write BOTH, and code that
--    still reads full_name (emails, AI prompts, etc.) will continue to
--    work until we migrate every caller.

alter table public.profiles
  add column if not exists first_name text,
  add column if not exists last_name text;

update public.profiles
set
  first_name = coalesce(
    first_name,
    nullif(trim(split_part(full_name, ' ', 1)), '')
  ),
  last_name = coalesce(
    last_name,
    nullif(
      trim(regexp_replace(coalesce(full_name, ''), '^\S+\s*', '')),
      ''
    )
  )
where full_name is not null;
