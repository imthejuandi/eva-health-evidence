-- ============================================================================
-- Biological age v3 in shadow mode (2026-10-01, approved by the CEO).
--
-- One service-role-only table, one row per lab result. Whenever processing
-- computes the live biological age (KDM v2.2: processLabResults and
-- recomputeLabMetrics in src/lib/biomarkers/process-results.ts), it then
-- computes version 3 with src/lib/biomarkers/biological-age-v3-adapter.ts and
-- upserts the record here on lab_result_id, through the service-role client.
-- It feeds the comparison of the two methods before any switch
-- (ml/biological-age/PROPOSAL.md, condition 4) and is shown to no one.
--
-- Access: RLS on with no policies, and every table privilege revoked from
-- anon and authenticated, so no page, API payload or client-side Supabase
-- call can read or write it; the service role bypasses both. lab_results
-- keeps no copy, so no select("*") on it can carry the record. The GDPR
-- export reads the user's rows with the service role. A row goes with its
-- lab result, and with the account (ON DELETE CASCADE from lab_results and
-- from profiles).
--
-- New table only: no backfill, nothing reprocessed. Idempotent.
-- ============================================================================

create table if not exists public.bio_age_v3_shadow (
  lab_result_id uuid primary key references public.lab_results(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  record jsonb not null,
  computed_at timestamptz not null default now()
);

-- The GDPR export and the comparison read a user's rows.
create index if not exists idx_bio_age_v3_shadow_user
  on public.bio_age_v3_shadow (user_id);

-- RLS on, no policies = deny all to anon + authenticated. Service role bypasses RLS.
alter table public.bio_age_v3_shadow enable row level security;

-- No table privileges for them either (Supabase grants new public tables to both by default).
revoke all on table public.bio_age_v3_shadow from anon, authenticated;

comment on table public.bio_age_v3_shadow is
  'Biological age v3 in shadow mode: one record per lab result, computed beside KDM v2.2 whenever the result is processed or recomputed, and shown to no one. Written by src/lib/biomarkers/process-results.ts (adapter: biological-age-v3-adapter.ts) with the service-role client. RLS enabled with NO policies and all privileges revoked from anon and authenticated: service role only, never exposed to the browser. Feeds the KDM v2.2 / v3 comparison (ml/biological-age/PROPOSAL.md, condition 4).';
comment on column public.bio_age_v3_shadow.lab_result_id is
  'The lab result the record was computed for; the row is deleted with it.';
comment on column public.bio_age_v3_shadow.user_id is
  'Owner of the lab result (profiles.id); the row is deleted with the account.';
comment on column public.bio_age_v3_shadow.record is
  'model_sha256, adapter_version, computed_at, tier (base | plus_hba1c | null), ba (years, null when there is none), interval_low and interval_high (95%), markers_used, clamps_applied, crp_capped, provisional (hs-CRP above 10 mg/L was capped), hba1c_source (same_draw | other_result | null), hba1c_excluded_reason, reason (why ba is null, e.g. pregnancy), bounded_markers (values that were bounds such as <0.5). {"reason": "error"} when computing it failed.';
comment on column public.bio_age_v3_shadow.computed_at is
  'When the record was last computed; set on every upsert.';
