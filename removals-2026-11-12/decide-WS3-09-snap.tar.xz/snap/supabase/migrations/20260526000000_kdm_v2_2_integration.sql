-- ============================================================================
-- KDM v2.2 biological age integration.
--
-- Adds four columns to lab_results that capture the new mortality-validated
-- biological-age values + provenance. The existing `biological_age` column
-- (numeric, present in the base schema) is repurposed: from this migration
-- onward processLabResults() writes the KDM v2.2 Reference BA into it
-- (replacing the legacy penalty-derived deviation heuristic — see
-- src/lib/biomarkers/biological-age.ts top-of-file deprecation note).
--
-- The longevity_score / longevity_grade columns are unchanged and continue
-- to receive the optimal-range-anchored score from the longevity-score
-- engine. The two metrics are intentionally distinct (see plan workstream
-- B for the conceptual split).
--
-- Migration is purely additive: no data backfill, no destructive change.
-- Existing rows simply have NULLs in the new columns until they're
-- reprocessed.
-- ============================================================================

ALTER TABLE lab_results
  -- Reference BA companion: KDM joint estimator over the FULL trained panel
  -- (not just the 14-marker base panel). Wider standard error; treated as a
  -- supplementary metric when the user uploads an extended panel.
  ADD COLUMN biological_age_comprehensive numeric,

  -- Which BA method produced biological_age. Always "KDM_v2.2_ReferenceBA"
  -- for rows written after this migration. Older rows (pre-migration data
  -- written by the legacy penalty engine) keep NULL here, so downstream
  -- consumers can distinguish them.
  ADD COLUMN bio_age_method text,

  -- Number of markers that contributed to the Reference BA joint estimator
  -- for this row. Used by the dashboard orb's "N/14 marcadores" badge.
  ADD COLUMN bio_age_n_markers integer,

  -- Spanish marker names (KDM library primary keys) whose `q` was swapped
  -- from NHANES to Spanish-population mean for this user's BA computation.
  -- Diagnostic / transparency field — surfaced on the methodology page.
  ADD COLUMN bio_age_applied_spanish_calibration text[];

COMMENT ON COLUMN lab_results.biological_age IS
  'KDM v2.2 Reference Biological Age (years). Joint estimator over 14-marker base panel. Mortality-validated: HR/SD 1.37 [1.29, 1.46], C-stat 0.77 in NHANES n=18,570. Replaces the legacy penalty-derived deviation heuristic starting 2026-05-26.';

COMMENT ON COLUMN lab_results.biological_age_comprehensive IS
  'KDM v2.2 Comprehensive Biological Age (years). Same joint estimator but over the full trained panel rather than the 14-marker base panel. NULL when the user did not upload an extended panel.';

COMMENT ON COLUMN lab_results.bio_age_method IS
  'Method tag for biological_age provenance. Constant "KDM_v2.2_ReferenceBA" for rows written by the current pipeline. NULL for pre-migration legacy rows.';

COMMENT ON COLUMN lab_results.bio_age_n_markers IS
  'Marker count contributing to the Reference BA joint estimator on this row. The 14-marker base panel is the maximum; KDM gate requires at least 8 of those plus Albumin and Creatinine.';

COMMENT ON COLUMN lab_results.bio_age_applied_spanish_calibration IS
  'Spanish KDM marker names whose population mean (q) was swapped from NHANES to a Spanish-cohort value (PESA / ENRICA / Di@bet.es / Hortega / PREDIMED / EPIRCE / La Rioja / SEQC) during BA computation. Surfaced on the methodology page for transparency.';
