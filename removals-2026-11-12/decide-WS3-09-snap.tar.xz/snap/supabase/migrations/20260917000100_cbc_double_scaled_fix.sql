-- ============================================================================
-- Repara recuentos celulares que ya estaban divididos de más antes del cambio
-- de unidades (2026-09-17). Visto en PROD al auditar antes de migrar: filas
-- guardadas como `0.00674 x10³/µL` (leucocitos), `0.305 x10³/µL` (plaquetas)
-- y `0.0000051 x10⁶/µL` (hematíes) — un recuento crudo etiquetado como
-- «miles» recibió el ÷1000 dos veces. Tras la migración de unidades quedan
-- 1000× (10⁶× en hematíes) por debajo de cualquier suelo fisiológico.
--
-- Mismo árbitro que unit-conversions.ts: un valor por debajo de
-- normal_high / 200 no puede ser un recuento crudo (leucocitos 55, plaquetas
-- 2 000, hematíes 28 250). Eosinófilos y basófilos quedan fuera: un recuento
-- crudo de 5 es real en ellos. Se repite hasta que la cifra sea plausible y se
-- reclasifica la zona y los contadores del resultado afectado. `reported_*`
-- no se toca: es lo que se guardó entonces.
-- ============================================================================

create temp table cbc_fixed (id uuid primary key, lab_result_id uuid) on commit drop;

do $$
declare n int;
begin
  loop
    with fixed as (
      update public.biomarker_values v
         set value = v.value * case when v.biomarker_key = 'red_blood_cell_count' then 1000000 else 1000 end
       where v.biomarker_key in ('white_blood_cell_count','platelet_count','red_blood_cell_count',
                                 'lymphocytes_absolute','monocytes_absolute','neutrophils_absolute')
         and v.unit = '/µL'
         and v.normal_high is not null and v.normal_high > 0
         and v.value > 0 and v.value < v.normal_high / 200
      returning v.id, v.lab_result_id)
    insert into cbc_fixed select id, lab_result_id from fixed on conflict do nothing;
    get diagnostics n = row_count;
    exit when n = 0;
  end loop;
end $$;

-- Zona con las mismas reglas que zone-classifier.ts (crítico = fuera del rango normal).
update public.biomarker_values v
   set zone = case
     when v.normal_low   is not null and v.value < v.normal_low   then 'critical_low'
     when v.optimal_low  is not null and v.value < v.optimal_low  then 'below_optimal'
     when (v.optimal_low is null or v.value >= v.optimal_low)
      and (v.optimal_high is null or v.value <= v.optimal_high)   then 'optimal'
     when v.normal_high  is not null and v.value > v.normal_high  then 'critical_high'
     else 'above_optimal' end
 where v.id in (select id from cbc_fixed);

-- Contadores del resultado (optimal / attention / action) para los afectados.
update public.lab_results r
   set optimal_count   = s.optimal,
       attention_count = s.attention,
       action_count    = s.action
  from (
    select lab_result_id,
           count(*) filter (where zone = 'optimal') as optimal,
           count(*) filter (where zone in ('below_optimal','above_optimal')) as attention,
           count(*) filter (where zone in ('critical_low','critical_high')) as action
      from public.biomarker_values
     where lab_result_id in (select distinct lab_result_id from cbc_fixed)
     group by lab_result_id
  ) s
 where r.id = s.lab_result_id;
