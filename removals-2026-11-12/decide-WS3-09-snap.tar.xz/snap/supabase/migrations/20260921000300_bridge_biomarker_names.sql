-- ============================================================================
-- Resultados del bridge: nombre legible en `biomarker_values.biomarker_name`.
--
-- El bridge guardaba la clave («white_blood_cell_count») como nombre y así se
-- veía en /labs (2026-09-21). El código ya guarda el nombre localizado de la
-- semilla; esto repara las filas anteriores de resultados de Echevarne.
-- Idempotente (solo filas cuyo nombre sigue siendo la clave).
-- ============================================================================

with names as (
  select distinct on (biomarker_key) biomarker_key, name_es, name_en
    from public.biomarker_references
   order by biomarker_key
)
update public.biomarker_values v
   set biomarker_name = case when coalesce(p.locale, 'es') like 'es%' then coalesce(n.name_es, n.name_en) else coalesce(n.name_en, n.name_es) end
  from public.lab_results l
  join public.profiles p on p.id = l.user_id
  join names n on true
 where v.lab_result_id = l.id
   and l.source = 'echevarne'
   and n.biomarker_key = v.biomarker_key
   and v.biomarker_name = v.biomarker_key;
