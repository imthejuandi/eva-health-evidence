create table if not exists public.email_subscribers (
  id uuid default gen_random_uuid() primary key,
  email text not null unique,
  source text not null default 'blog',
  locale text not null default 'es',
  subscribed_at timestamptz not null default now()
);

alter table public.email_subscribers enable row level security;

-- Allow anonymous inserts (public signup form)
create policy "Anyone can subscribe" on public.email_subscribers
  for insert with check (true);

-- Only service role can read
create policy "Service role can read subscribers" on public.email_subscribers
  for select using (auth.role() = 'service_role');
