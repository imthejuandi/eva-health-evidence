-- Separate Urea from BUN.
--
-- Until now the pipeline treated "Urea" (whole molecule, European/Spanish
-- reporting convention) and "BUN" (Blood Urea Nitrogen, U.S. convention)
-- as the same biomarker: lab names matching either alias collapsed to
-- biomarker_key='bun' and the value was scaled (Urea × 0.4665) into the
-- BUN reference range. Clicking the row in the dashboard always opened
-- the BUN page regardless of which molecule the user's lab actually
-- reported.
--
-- This migration introduces a dedicated biomarker_key='urea' row with
-- longevity-optimal ranges scaled from EVA's BUN ranges via the
-- BUN/Urea molar conversion (×2.14, i.e. 1/0.4665). Existing biomarker
-- rows are intentionally left in place per product decision — only new
-- uploads route to the new key. The Urea↔BUN scaling is still applied
-- inside the KDM joint estimator so the bio-age algorithm sees the
-- right BUN-anchored value regardless of which molecule was uploaded.

insert into public.biomarker_references (
  biomarker_key,
  name_en,
  name_es,
  unit_en,
  unit_es,
  sex,
  age_group_en,
  age_group_es,
  normal_low,
  normal_high,
  optimal_low,
  optimal_high,
  tested_2x_year,
  panel_category,
  is_base_panel,
  is_genetic,
  clinical_notes_en,
  clinical_notes_es,
  msg_critical_low_en,
  msg_critical_low_es,
  msg_below_optimal_en,
  msg_below_optimal_es,
  msg_optimal_en,
  msg_optimal_es,
  msg_above_optimal_en,
  msg_above_optimal_es,
  msg_critical_high_en,
  msg_critical_high_es
) values (
  'urea',
  'Urea',
  'Urea',
  'mg/dL',
  'mg/dL',
  'both',
  'All Adults',
  'Todos los Adultos',
  15,
  43,
  21,
  39,
  true,
  'kidneys',
  false,
  false,
  'Urea is the whole molecule the kidneys filter out as the end-product of protein metabolism. European labs report Urea directly; U.S. labs typically report only its nitrogen fraction (BUN, which is Urea × 0.4665). Levels reflect kidney clearance but also shift with hydration and protein intake. Longevity-optimal ranges are tighter than the conventional reference: lower steady-state Urea within the healthy band associates with better kidney trajectory and lower all-cause mortality.',
  'La urea es la molécula completa que los riñones filtran como producto final del metabolismo proteico. Los laboratorios europeos reportan urea directamente; los estadounidenses suelen reportar solo su fracción de nitrógeno (BUN, que equivale a urea × 0,4665). Sus niveles reflejan la depuración renal, pero también varían con la hidratación y la ingesta proteica. Los rangos óptimos para longevidad son más estrechos que la referencia clínica habitual: una urea estable en la parte baja del rango sano se asocia a mejor trayectoria renal y menor mortalidad por todas las causas.',
  'Urea is low, which may reflect low protein intake, liver disease, or overhydration.',
  'La urea está baja, lo que puede reflejar baja ingesta proteica, hepatopatía o sobrehidratación.',
  'Urea is below optimal. If sustained, evaluate protein intake and liver function.',
  'La urea está por debajo del óptimo. Si persiste, evaluar la ingesta proteica y la función hepática.',
  'Urea is in the optimal range, reflecting balanced protein metabolism and kidney clearance.',
  'La urea está en el rango óptimo, reflejando metabolismo proteico equilibrado y depuración renal.',
  'Urea is above optimal. Consider high protein intake, dehydration, or early kidney stress.',
  'La urea está por encima del óptimo. Considerar alta ingesta proteica, deshidratación o estrés renal temprano.',
  'Urea is significantly elevated. Evaluate for kidney dysfunction, dehydration, GI bleeding, or heart failure.',
  'La urea está significativamente elevada. Evaluar disfunción renal, deshidratación, sangrado GI o insuficiencia cardíaca.'
)
on conflict (biomarker_key, sex, age_group_en) do update set
  name_en = excluded.name_en,
  name_es = excluded.name_es,
  unit_en = excluded.unit_en,
  unit_es = excluded.unit_es,
  normal_low = excluded.normal_low,
  normal_high = excluded.normal_high,
  optimal_low = excluded.optimal_low,
  optimal_high = excluded.optimal_high,
  tested_2x_year = excluded.tested_2x_year,
  panel_category = excluded.panel_category,
  is_base_panel = excluded.is_base_panel,
  is_genetic = excluded.is_genetic,
  clinical_notes_en = excluded.clinical_notes_en,
  clinical_notes_es = excluded.clinical_notes_es,
  msg_critical_low_en = excluded.msg_critical_low_en,
  msg_critical_low_es = excluded.msg_critical_low_es,
  msg_below_optimal_en = excluded.msg_below_optimal_en,
  msg_below_optimal_es = excluded.msg_below_optimal_es,
  msg_optimal_en = excluded.msg_optimal_en,
  msg_optimal_es = excluded.msg_optimal_es,
  msg_above_optimal_en = excluded.msg_above_optimal_en,
  msg_above_optimal_es = excluded.msg_above_optimal_es,
  msg_critical_high_en = excluded.msg_critical_high_en,
  msg_critical_high_es = excluded.msg_critical_high_es;
