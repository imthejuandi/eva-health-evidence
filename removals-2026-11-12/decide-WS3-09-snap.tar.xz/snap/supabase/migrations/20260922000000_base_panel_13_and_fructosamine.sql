-- ============================================================================
-- Panel Base (2026-09-22): 13 pruebas fijadas por el fundador — albúmina,
-- fosfatasa alcalina, PCR ultrasensible, creatinina, BUN, ácido úrico,
-- colesterol total, HDL, triglicéridos, ApoB, ALT, GGT y fructosamina. Es el
-- panel base del KDM v2.2 menos ferritina, vitamina D y TSH, más ApoB y ALT.
-- Mismo contenido que `supabase/seed-data/*.json` y `seed-references.ts`
-- (BASE_PANEL_NAMES) y que `ECH_PANEL_ORDER_CODES.base`.
--
-- 1. Nueva referencia: fructosamina (Echevarne FRUC → B0158, µmol/L).
--    Intervalo de referencia del ensayo del laboratorio (122–236); techo
--    óptimo provisional (200) pendiente de firma médica.
-- 2. `is_base_panel` pasa a reflejar el panel real (antes marcaba 24 filas
--    del panel provisional de 2026-09-09).
-- Idempotente.
-- ============================================================================

insert into public.biomarker_references (
  biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es,
  normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category,
  is_base_panel, is_genetic,
  clinical_notes_en, clinical_notes_es,
  msg_critical_low_en, msg_critical_low_es,
  msg_below_optimal_en, msg_below_optimal_es,
  msg_optimal_en, msg_optimal_es,
  msg_above_optimal_en, msg_above_optimal_es,
  msg_critical_high_en, msg_critical_high_es
) values (
  'fructosamine', 'Fructosamine', 'Fructosamina', 'µmol/L', 'µmol/L', 'both', 'All Adults', 'Todos los Adultos',
  122, 236, null, 200, false, 'metabolic',
  true, false,
  $en$Glycated serum proteins, mainly albumin: a 2–3 week window on average blood glucose, complementing HbA1c (which reads 2–3 months). Reference interval from the laboratory's assay (122–236 µmol/L); the optimal ceiling is a provisional longevity target pending medical sign-off.$en$,
  $es$Proteínas séricas glicadas, sobre todo albúmina: refleja la glucosa media de las últimas 2–3 semanas y complementa a la HbA1c (2–3 meses). Intervalo de referencia del ensayo del laboratorio (122–236 µmol/L); el techo óptimo es un objetivo de longevidad provisional pendiente de firma médica.$es$,
  $en$Fructosamine is very low, which can reflect low serum protein rather than glucose control; interpret together with albumin.$en$,
  $es$La fructosamina está muy baja, lo que puede reflejar proteínas séricas bajas más que el control de la glucosa; interpretar junto con la albúmina.$es$,
  null, null,
  $en$Fructosamine is in the optimal range, reflecting stable average blood glucose over the past 2–3 weeks.$en$,
  $es$La fructosamina está en el rango óptimo, reflejando una glucosa media estable en las últimas 2–3 semanas.$es$,
  $en$Fructosamine is above optimal, suggesting higher-than-ideal average glucose over recent weeks; worth reviewing carbohydrate load, sleep and activity.$en$,
  $es$La fructosamina está por encima del óptimo, lo que sugiere una glucosa media más alta de lo ideal en las últimas semanas; conviene revisar la carga de carbohidratos, el sueño y la actividad.$es$,
  $en$Fructosamine is significantly elevated, consistent with sustained hyperglycemia over recent weeks; medical evaluation is advised.$en$,
  $es$La fructosamina está significativamente elevada, compatible con hiperglucemia sostenida en las últimas semanas; se aconseja valoración médica.$es$
)
on conflict (biomarker_key, sex, age_group_en) do update set
  name_en = excluded.name_en, name_es = excluded.name_es,
  unit_en = excluded.unit_en, unit_es = excluded.unit_es,
  age_group_es = excluded.age_group_es,
  normal_low = excluded.normal_low, normal_high = excluded.normal_high,
  optimal_low = excluded.optimal_low, optimal_high = excluded.optimal_high,
  tested_2x_year = excluded.tested_2x_year, panel_category = excluded.panel_category,
  is_base_panel = excluded.is_base_panel, is_genetic = excluded.is_genetic,
  clinical_notes_en = excluded.clinical_notes_en, clinical_notes_es = excluded.clinical_notes_es,
  msg_critical_low_en = excluded.msg_critical_low_en, msg_critical_low_es = excluded.msg_critical_low_es,
  msg_below_optimal_en = excluded.msg_below_optimal_en, msg_below_optimal_es = excluded.msg_below_optimal_es,
  msg_optimal_en = excluded.msg_optimal_en, msg_optimal_es = excluded.msg_optimal_es,
  msg_above_optimal_en = excluded.msg_above_optimal_en, msg_above_optimal_es = excluded.msg_above_optimal_es,
  msg_critical_high_en = excluded.msg_critical_high_en, msg_critical_high_es = excluded.msg_critical_high_es;

update public.biomarker_references
   set is_base_panel = (biomarker_key in (
     'albumin', 'alp', 'hs_crp', 'creatinine', 'bun', 'uric_acid',
     'total_cholesterol', 'hdl_cholesterol', 'triglycerides',
     'apolipoprotein_b_apob', 'alt', 'ggt', 'fructosamine'
   ))
 where is_base_panel is distinct from (biomarker_key in (
     'albumin', 'alp', 'hs_crp', 'creatinine', 'bun', 'uric_acid',
     'total_cholesterol', 'hdl_cholesterol', 'triglycerides',
     'apolipoprotein_b_apob', 'alt', 'ggt', 'fructosamine'
   ));
