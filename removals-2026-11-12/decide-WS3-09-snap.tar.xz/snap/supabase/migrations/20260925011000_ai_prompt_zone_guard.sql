-- ============================================================================
-- Gate 1 (LBL, VD, PLAN), 2026-09-25: the AI chat and the master interpretation receive the internal
-- zone codes (critical_low, below_optimal, …) next to every biomarker. The prompts now define the codes
-- in plain terms, stop calling out-of-range results "critical" (it means outside the laboratory's
-- reference range, not a panic value), never grade results that have no category, state the vitamin D
-- decision, and keep the chat from attributing the biological age to single markers.
-- Decisions: docs/biomarker-evidence/longevity/GATE-1-DECISIONS.md.
-- Each update is guarded by the md5 of the prompt as it was and by the presence of the lines it
-- replaces, so it applies once and never overwrites a prompt edited since. Rollback:
-- docs/biomarker-evidence/snapshots/rollback-ai-prompts-2026-09-25.sql.
-- ============================================================================

update public.ai_prompts
   set content = replace(replace(content,
         '- Frame EVERYTHING against EVA''s OPTIMAL ranges, never standard "normal" lab ranges',
         '- Frame EVERYTHING against EVA''s OPTIMAL ranges as the goal; the laboratory''s reference range only tells whether a result is in range or out of range (see RESULT CATEGORIES)'),
         '- NEVER say "you''re fine" or "within normal range" for markers outside EVA optimal',
         '- NEVER say "you''re fine" for markers outside EVA optimal. A result can be inside the laboratory''s reference range and still outside EVA''s optimal band; then say exactly that')
       || E'\n\n' || $guard$RESULT CATEGORIES. Each biomarker line shows its zone in brackets. optimal: inside EVA's optimal band. below_optimal or above_optimal: in range, meaning inside the laboratory's reference range but outside EVA's optimal band; this is an opportunity to improve, not a disease. critical_low or critical_high: out of range, meaning below or above the laboratory's reference range. Despite the internal code name this is not a critical or panic value: say "below the reference range" or "above the reference range", never "critical", and suggest discussing it with a physician. unclassified: EVA gives this marker no category (for example white-cell percentages, which EVA reads through the absolute counts, or arachidonic acid, read through the arachidonic acid/EPA ratio); never grade it.

VITAMIN D. Between 20 and 29 ng/mL vitamin D is below the laboratory's reference range but is not a deficiency; below 20 ng/mL it is a deficiency.

BIOLOGICAL AGE. The biological age is a population-level estimate from a model validated against mortality. Never attribute it, or a change in it, to a single marker, and never tell the user that improving a marker toward EVA's optimal range made them biologically older. If asked why it changed, explain that it reflects the combination of all the markers in the model.$guard$,
       updated_at = now()
 where key = 'eva_chat_system'
   and md5(content) = '6463df7b2301394dd3f1827f9cc004d8'
   and position('- Frame EVERYTHING against EVA''s OPTIMAL ranges, never standard "normal" lab ranges' in content) > 0
   and position('- NEVER say "you''re fine" or "within normal range" for markers outside EVA optimal' in content) > 0;

update public.ai_prompts
   set content = replace(replace(content,
         'Frame ALL interpretations against EVA''s longevity-OPTIMAL ranges, never standard population reference ranges.',
         'Frame ALL interpretations against EVA''s longevity-OPTIMAL ranges as the goal; use the laboratory''s reference range only to say whether a marker is in range or out of range.'),
         'Below-optimal markers carry a real longevity cost; explain that cost. Critical-zone markers carry urgency; convey it without being alarmist.',
         $new$Markers in range but outside optimal (zone below_optimal or above_optimal, inside the laboratory's reference range) carry a real longevity cost; explain that cost. Out-of-range markers (zone critical_low or critical_high) are below or above the laboratory's reference range; despite the internal code name this is not a critical or panic value, so write "below the reference range" or "above the reference range", never "critical", and recommend discussing them with a physician without being alarmist. Markers with zone unclassified have no EVA category (for example white-cell percentages, read through the absolute counts); do not treat them as abnormal. Vitamin D between 20 and 29 ng/mL is below the laboratory's reference range but is not a deficiency; below 20 ng/mL it is.$new$),
       updated_at = now()
 where key = 'master_interpretation'
   and md5(content) = '7d975b0737fdd484fa960b271e6b12c1'
   and position('Frame ALL interpretations against EVA''s longevity-OPTIMAL ranges, never standard population reference ranges.' in content) > 0
   and position('Below-optimal markers carry a real longevity cost; explain that cost. Critical-zone markers carry urgency; convey it without being alarmist.' in content) > 0;
