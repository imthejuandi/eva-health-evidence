-- ============================================================================
-- Rule 4 — Patient context, gated on every new lab.
--
-- Two new tables and three new columns on lab_results give every
-- interpretation a frozen point-in-time view of the user's medications,
-- supplements, conditions, lifestyle, and the per-draw context (fasting,
-- last workout, illness, cycle day) on the day the sample was processed.
--
-- Design points worth knowing before reading further:
--
--   * patient_context_versions is append-only. Editing context creates a
--     new row, never overwrites. Each lab_result carries an FK to the
--     version that was current on the day it was processed — so a Tuesday
--     edit can never silently rewrite the context attached to last
--     month's lab interpretation.
--
--   * Per-draw transient context (fasted, last workout, cycle day, time
--     of draw, sleep/hydration the night before) lives directly on
--     lab_results as jsonb. It has no meaning outside the one draw, so
--     versioning would be overhead.
--
--   * lab_results.status grows a new "pending_context" value. The
--     webhook lands here. The AI interpretation does not fire until the
--     user confirms or updates their context. Existing rows backfill to
--     "ready" because they were already interpreted.
--
--   * patient_context_drafts is a single-row-per-user scratch space so
--     bouncing the tab during a long edit doesn't lose progress.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. patient_context_versions — append-only history of the durable
--    context the AI uses to interpret bloodwork.
-- ----------------------------------------------------------------------------

create table if not exists public.patient_context_versions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  version_number integer not null,

  -- Each section is jsonb so we can iterate the question set in the
  -- onboarding/upload UI without a schema migration every time. Keys
  -- inside are stable English enum strings (e.g. "statin_rosuvastatin",
  -- "creatine") so the AI prompt and i18n labels both look them up the
  -- same way.
  medications jsonb not null default '[]'::jsonb,
  supplements jsonb not null default '[]'::jsonb,
  conditions jsonb not null default '{"keys": []}'::jsonb,
  lifestyle jsonb not null default '{}'::jsonb,
  sex_specific jsonb not null default '{}'::jsonb,

  -- Mark the row that represents "nothing filled in yet" so the upload
  -- UI can tell the user "we haven't asked you these questions yet"
  -- versus "you confirmed everything is empty".
  is_empty boolean not null default false,

  created_at timestamptz not null default now(),
  unique (user_id, version_number)
);

create index if not exists idx_patient_context_versions_user
  on public.patient_context_versions (user_id, created_at desc);

alter table public.patient_context_versions enable row level security;
create policy "Users can view own context versions"
  on public.patient_context_versions for select
  using (auth.uid() = user_id);
create policy "Users can insert own context versions"
  on public.patient_context_versions for insert
  with check (auth.uid() = user_id);
-- No update / delete policy: append-only by design.

-- ----------------------------------------------------------------------------
-- 2. patient_context_drafts — one row per user, transient autosave.
--    The upload UI writes here every couple seconds while the user is
--    editing context, and clears the row after a successful save. Not
--    used for interpretation — just a "don't lose my work" scratchpad.
-- ----------------------------------------------------------------------------

create table if not exists public.patient_context_drafts (
  user_id uuid references public.profiles(id) on delete cascade primary key,
  draft jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.patient_context_drafts enable row level security;
create policy "Users can view own context draft"
  on public.patient_context_drafts for select
  using (auth.uid() = user_id);
create policy "Users can upsert own context draft"
  on public.patient_context_drafts for insert
  with check (auth.uid() = user_id);
create policy "Users can update own context draft"
  on public.patient_context_drafts for update
  using (auth.uid() = user_id);
create policy "Users can delete own context draft"
  on public.patient_context_drafts for delete
  using (auth.uid() = user_id);

-- ----------------------------------------------------------------------------
-- 3. lab_results: add the FK + transient column + the new status value.
--
-- Postgres CHECK constraints aren't extensible in place — drop + recreate.
-- The webhook handler will be updated in the same release to insert new
-- rows with status='pending_context'. Existing rows are unaffected.
-- ----------------------------------------------------------------------------

alter table public.lab_results
  add column if not exists patient_context_version_id uuid
    references public.patient_context_versions(id) on delete set null,
  add column if not exists transient_context jsonb;

create index if not exists idx_lab_results_pending_context
  on public.lab_results (user_id, created_at desc)
  where status = 'pending_context';

alter table public.lab_results
  drop constraint if exists lab_results_status_check;
alter table public.lab_results
  add constraint lab_results_status_check
  check (status in ('pending_context', 'processing', 'ready', 'error'));

comment on column public.lab_results.patient_context_version_id is
  'Snapshot pointer to the patient_context_versions row that was current on the day this lab was processed. Frozen at confirm time so retroactive context edits never rewrite past interpretations.';
comment on column public.lab_results.transient_context is
  'Per-draw context that has no meaning beyond this one lab: fasted hours, last workout intensity/timing, recent illness, cycle day (premenopausal), time of draw, sleep/hydration the night before. Set to {"skipped": true} when the user opts to skip the strip.';

comment on table public.patient_context_versions is
  'Append-only history of every version of a user durable medical context (medications, supplements, conditions, lifestyle, sex_specific). Each lab_result FK''s the version that was current on the day it was processed.';
comment on table public.patient_context_drafts is
  'Single-row-per-user autosave scratchpad for in-progress context edits. Cleared on successful save. Not referenced by lab interpretation.';
