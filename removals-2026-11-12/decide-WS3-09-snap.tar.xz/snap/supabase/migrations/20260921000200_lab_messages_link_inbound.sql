-- ============================================================================
-- Enlaza a su ciclo los mensajes ENTRANTES ya archivados (ORU y ACK de ECH).
--
-- El bridge archivaba los mensajes de Echevarne con `cycle_id` nulo y solo
-- enlazaba los salientes. Sin ese enlace el HL7 crudo no forma parte del
-- historial del cliente ni lo sigue la cascada de borrado GDPR (decisión de
-- retención del 2026-09-17). El código ya enlaza al casar el mensaje; esto
-- repara lo archivado antes. Idempotente; en producción no hay filas todavía.
-- ============================================================================

-- ACK de ECH → su MSH-10 es el MSH-10 de nuestro OML → ciclo del OML.
update public.lab_messages m
   set cycle_id = o.cycle_id
  from public.lab_messages o
 where m.direction = 'in' and m.msg_type = 'ACK' and m.cycle_id is null
   and o.direction = 'out' and o.msg_type = 'OML'
   and o.message_control_id = m.message_control_id;

-- ORU de ECH → su MSH-10 es «<nº de petición>-<secuencia>» → ciclo por etiqueta.
update public.lab_messages m
   set cycle_id = c.id
  from public.test_cycles c
 where m.direction = 'in' and m.msg_type = 'ORU' and m.cycle_id is null
   and split_part(m.message_control_id, '-', 1) = c.kit_label_code;
