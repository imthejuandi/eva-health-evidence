-- Add DELETE RLS policies that were missing from the original schema.
--
-- Without these, client-authenticated DELETE calls silently return 0 rows
-- affected (Supabase does not raise an error on RLS rejection for DELETE),
-- which causes reprocess flows to accumulate duplicates instead of replacing.

-- ─── biomarker_values ───
-- Allow users to delete biomarker_values tied to their own lab_results.
-- Mirrors the existing SELECT/INSERT/UPDATE policies.
create policy "Users can delete own biomarker values" on public.biomarker_values
  for delete using (
    exists (
      select 1 from public.lab_results lr
      where lr.id = lab_result_id and lr.user_id = auth.uid()
    )
  );

-- ─── action_steps ───
-- Allow users to delete their own action steps. Needed for reprocess so a
-- fresh summary run can re-insert steps without duplicates.
create policy "Users can delete own action steps" on public.action_steps
  for delete using (auth.uid() = user_id);

-- ─── lab_results ───
-- Allow users to delete their own lab results (cascades to biomarker_values,
-- calculated_metrics, and action_steps via ON DELETE CASCADE).
create policy "Users can delete own lab results" on public.lab_results
  for delete using (auth.uid() = user_id);
