-- ============================================================================
-- RECUPERADA DE LIVE (reparación OPS-004, paso 1).
-- Aplicada a producción fuera del flujo el 2026-06-05 (versión live
-- 20260605163720_wearable_data_update_policy); SQL reconstruido en
-- solo-lectura desde pg_policies el 2026-08-25.
--
-- Añade la política UPDATE propia que faltaba en wearable_data (el upsert de
-- importaciones repetidas de Apple Health necesita UPDATE además de INSERT).
-- ============================================================================

drop policy if exists "Users can update own wearable data" on public.wearable_data;
create policy "Users can update own wearable data"
  on public.wearable_data for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
