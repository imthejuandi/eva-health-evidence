-- ============================================================================
-- Rule 1 — Track how each biomarker_value was matched to its canonical key.
--
-- Confidence levels mirror the matcher's enum (src/lib/biomarkers/name-matcher.ts):
--   * exact   — raw name slugified directly to a known canonical key
--   * alias   — raw name matched a curated alias entry (EN + ES variants)
--   * fuzzy   — raw name resolved via Levenshtein distance (UI requires
--               an explicit user confirmation tap before save)
--   * user    — user picked the key manually from the reference list
--
-- Stored so we can later audit how often users accepted vs. corrected
-- fuzzy matches and tune the alias table accordingly. Defaults to 'user'
-- for legacy rows so backfilled labs don't masquerade as auto-matched.
-- ============================================================================

alter table public.biomarker_values
  add column if not exists match_confidence text
    check (match_confidence in ('exact', 'alias', 'fuzzy', 'user'));

comment on column public.biomarker_values.match_confidence is
  'How the biomarker name resolved to its canonical key. exact|alias auto-confirmed at extract; fuzzy must be user-confirmed in the upload UI; user is a manual selection from the reference list.';
