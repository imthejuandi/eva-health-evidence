-- ============================================================================
-- Entitlement columns (F2/F3 del plan de logística).
--
-- El webhook de Stripe pasa a escribir SOLO entitlement: qué plan tiene el
-- usuario y hasta cuándo ha pagado. El cycle-scheduler (F4) lee estas columnas
-- para decidir cuándo toca ciclo — el pago nunca crea kits directamente.
--
--   plan             'quarterly' | 'annual' (NULL = sin suscripción).
--   paid_until       fecha hasta la que el entitlement está cubierto
--                    (= current_period_end del último invoice de Stripe).
--   next_panel_type  panel que llevará el PRÓXIMO ciclo al crearse
--                    (configurable por decisión de producto; se congela en
--                    test_cycles.panel_type al crear el ciclo). Referencia
--                    conceptual a panels.id — sin FK a propósito: panels es
--                    config de marketing y sus ids pueden evolucionar.
--
-- El guard de columnas billing (20260604000000) se extiende con plan y
-- paid_until. next_panel_type queda FUERA del guard a propósito: es editable
-- por el usuario/admin por diseño.
-- ============================================================================

alter table public.profiles
  add column if not exists plan text
    check (plan in ('quarterly','annual')),
  add column if not exists paid_until date,
  add column if not exists next_panel_type text not null default 'base';

comment on column public.profiles.plan is
  'Stripe entitlement plan: quarterly | annual. Written ONLY by the Stripe webhook (service role). NULL = no active subscription plan recorded.';
comment on column public.profiles.paid_until is
  'Date through which the subscription entitlement is paid (Stripe current_period_end). The cycle-scheduler gates cycle creation on this. Written ONLY by the Stripe webhook.';
comment on column public.profiles.next_panel_type is
  'Panel type the NEXT test cycle will use when the scheduler creates it (frozen onto test_cycles.panel_type at creation). User/admin-configurable — intentionally NOT covered by the billing guard.';

-- Extender el guard (misma función; se añaden las dos columnas nuevas).
create or replace function public.prevent_billing_self_write()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  if coalesce(auth.role(), '') in ('authenticated', 'anon')
     and (
       new.subscription_status is distinct from old.subscription_status
       or new.subscription_period_end is distinct from old.subscription_period_end
       or new.full_panel_purchased_at is distinct from old.full_panel_purchased_at
       or new.plan is distinct from old.plan
       or new.paid_until is distinct from old.paid_until
     ) then
    raise exception 'billing columns (subscription_status, subscription_period_end, full_panel_purchased_at, plan, paid_until) can only be changed by a service-role context';
  end if;
  return new;
end;
$$;
