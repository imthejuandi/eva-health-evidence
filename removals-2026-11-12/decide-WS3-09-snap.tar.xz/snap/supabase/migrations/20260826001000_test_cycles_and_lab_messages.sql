-- ============================================================================
-- F2 — El corazón de la logística: máquina de estados de ciclos de test y
-- archivo de mensajería HL7. Diseño en docs/lab-integration-message-logistics.md.
--
-- test_cycles: una fila por kit/ciclo. TODOS los actores (Stripe→entitlement,
-- cron scheduler, panel Ops, activación del paciente, Lab Bridge) leen y
-- escriben esta fila; los emails salen de sus transiciones.
--
-- lab_messages: archivo de TODA la mensajería HL7 con Echevarne (OML/ORU/ACK,
-- ambos sentidos) con dedupe por MSH-10. El payload crudo es PHI → RLS
-- deny-all (solo service-role), patrón admin_audit_log. Sustituye a la
-- nunca-creada lab_provider_results (SEC-019).
--
-- Escrituras: exclusivamente service-role (scheduler/admin/bridge). El usuario
-- solo LEE sus ciclos (KitTimeline). GDPR delete queda cubierto por CASCADE:
-- profiles → test_cycles → lab_messages.
-- ============================================================================

create table if not exists public.test_cycles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  -- nº de ciclo del usuario (1, 2, 3…)
  seq integer not null,
  -- congelado desde profiles.next_panel_type al crear el ciclo
  panel_type text not null default 'base',
  status text not null default 'awaiting_fulfillment'
    check (status in (
      'awaiting_fulfillment', -- creado por el scheduler; en cola de Ops
      'kit_assigned',         -- Ops escaneó la calcomanía
      'shipped',              -- etiqueta DHL creada, kit en camino
      'activated',            -- paciente confirmó extracción (+consentimiento)
      'order_sent',           -- OML^O21 subido al buzón SFTP
      'order_accepted',       -- ACK CA de Echevarne
      'results_partial',      -- ORU con ORC.5 = A
      'results_final',        -- ORU con ORC.5 = CM
      'completed',            -- interpretación lista (lab_results.ready)
      'cancelled',
      'error'                 -- ACK CE u otro fallo; requiere Ops
    )),
  -- cuándo tocaba este ciclo (ancla de cadencia del scheduler)
  due_date date not null,
  -- ORC.2.1 del OML — LA clave de matching con el ORU de vuelta
  placer_order_number text unique,
  -- la calcomanía / label de Trak de Echevarne (SPM.2.1 en el ORU)
  kit_label_code text unique,
  dhl_tracking_out text,
  dhl_tracking_return text,
  extraction_confirmed_at timestamptz,
  oml_sent_at timestamptz,
  -- resultado del ACK al OML: 'CA' | 'CE:<código>'
  oml_ack text,
  lab_result_id uuid references public.lab_results(id) on delete set null,
  created_at timestamptz not null default now(),
  -- responsabilidad de quien transiciona (no hay trigger de touch a propósito:
  -- todas las escrituras pasan por rutas service-role que lo estampan)
  updated_at timestamptz not null default now(),
  unique (user_id, seq)
);

-- Regla de oro del scheduler hecha constraint: UN ciclo abierto por usuario.
-- Ejecutar el cron dos veces no puede duplicar ciclos.
create unique index if not exists one_open_cycle_per_user
  on public.test_cycles (user_id)
  where status not in ('completed', 'cancelled');

-- Barridos del scheduler (¿qué toca? ¿qué está atascado?).
create index if not exists idx_test_cycles_status_due
  on public.test_cycles (status, due_date);

alter table public.test_cycles enable row level security;

-- El usuario ve sus ciclos (KitTimeline / dispatch). Sin INSERT/UPDATE/DELETE:
-- todas las escrituras via service-role (patrón full_schema select-own).
drop policy if exists "Users can view own test cycles" on public.test_cycles;
create policy "Users can view own test cycles"
  on public.test_cycles for select
  using (auth.uid() = user_id);

comment on table public.test_cycles is
  'One row per kit/test cycle — the state machine every actor (Stripe entitlement, scheduler cron, Ops panel, patient activation, Lab Bridge) reads and transitions. Writes are service-role only; users have read-only visibility of their own cycles.';
comment on column public.test_cycles.placer_order_number is
  'eva''s petition number (OML ORC.2.1). The lab echoes it back in the ORU — primary matching key. Format agreed with ECH in F0.';
comment on column public.test_cycles.kit_label_code is
  'Echevarne sample sticker ("label de Trak") assigned by Ops at fulfillment; cross-checked against SPM.2.1 of the incoming ORU.';

create table if not exists public.lab_messages (
  id uuid primary key default gen_random_uuid(),
  cycle_id uuid references public.test_cycles(id) on delete cascade,
  direction text not null check (direction in ('out', 'in')),
  msg_type text not null check (msg_type in ('OML', 'ORU', 'ACK')),
  -- MSH-10. UNIQUE = dedupe estructural de redeliveries de ECH.
  message_control_id text unique,
  raw text not null,
  status text not null default 'received'
    check (status in ('queued', 'sent', 'received', 'processed', 'error')),
  error text,
  created_at timestamptz not null default now()
);

create index if not exists idx_lab_messages_cycle
  on public.lab_messages (cycle_id, created_at desc);
create index if not exists idx_lab_messages_outbox
  on public.lab_messages (status)
  where status = 'queued';

-- PHI cruda → deny-all: RLS activa sin políticas (patrón admin_audit_log).
-- Solo el service-role (bridge/cron/admin) puede leer o escribir.
alter table public.lab_messages enable row level security;

comment on table public.lab_messages is
  'Archive of ALL HL7 traffic with the lab (OML/ORU/ACK, both directions), deduped by MSH-10. Raw payloads are PHI: deny-all RLS, service-role only. Retention policy: pending F0 decision (90-day proposal). Supersedes the never-created lab_provider_results (SEC-019).';
