-- ============================================================================
-- Guard paid-entitlement columns on profiles against user self-writes.
--
-- The "Users can update own profile" RLS policy on public.profiles is
-- column-unrestricted (USING auth.uid() = id, no WITH CHECK), so without this
-- guard an authenticated user could set their OWN:
--   - subscription_status     = 'active'   (free quarterly subscription)
--   - subscription_period_end = <future>   (extend access)
--   - full_panel_purchased_at = <now>      (free Full Panel access)
-- and unlock paid features without paying.
--
-- These columns are written ONLY by the Stripe webhook (api/stripe/webhook),
-- which now uses the service-role client. This BEFORE UPDATE trigger therefore
-- blocks changes to them from the PostgREST API roles (authenticated / anon)
-- while leaving service-role (the webhook) and direct Studio/superuser writes
-- (auth.role() is then null) unaffected. Same-value writes are not affected —
-- the guard only fires when a protected column actually changes.
--
-- Mirrors the is_admin guard from 20260603110000_admin_role_and_audit_log.sql.
-- Idempotent and safe to re-run.
-- ============================================================================
create or replace function public.prevent_billing_self_write()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  if coalesce(auth.role(), '') in ('authenticated', 'anon')
     and (
       new.subscription_status is distinct from old.subscription_status
       or new.subscription_period_end is distinct from old.subscription_period_end
       or new.full_panel_purchased_at is distinct from old.full_panel_purchased_at
     ) then
    raise exception 'billing columns (subscription_status, subscription_period_end, full_panel_purchased_at) can only be changed by a service-role context';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_prevent_billing_self_write on public.profiles;
create trigger trg_prevent_billing_self_write
  before update on public.profiles
  for each row execute function public.prevent_billing_self_write();
