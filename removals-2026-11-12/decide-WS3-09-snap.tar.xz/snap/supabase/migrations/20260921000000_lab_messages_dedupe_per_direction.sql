-- ============================================================================
-- Dedupe de `lab_messages` por (dirección, MSH-10), no solo por MSH-10.
--
-- Hallazgo de la ronda 4 con Echevarne (2026-09-21): sus ACK a nuestros OML
-- llevan como MSH-10 **nuestro propio identificador de mensaje** (254899.ACK
-- → MSH-10 = `EVA000001004M1`, el MSH-10 del OML que acusa; ya era así en el
-- 254818.ACK de la ronda 1). Con UNIQUE(message_control_id) sobre toda la
-- tabla, archivar ese ACK chocaba con la fila del OML saliente, el bridge lo
-- leía como «duplicado», lo movía a procesados sin archivarlo y el pedido
-- quedaba «sin acuse» aunque ECH lo había acusado en el mismo minuto. Tres
-- rondas de «¿por qué no vemos su ACK?» explicadas por esto.
--
-- El dedupe de re-entregas sigue intacto: dos ficheros ENTRANTES con el mismo
-- MSH-10 siguen chocando. Solo dejan de chocar un saliente y un entrante.
-- ============================================================================

do $$
declare c record;
begin
  for c in
    select con.conname
      from pg_constraint con
      join pg_class rel on rel.oid = con.conrelid
      join pg_namespace nsp on nsp.oid = rel.relnamespace
     where nsp.nspname = 'public' and rel.relname = 'lab_messages'
       and con.contype = 'u'
       and (select array_agg(att.attname::text order by att.attnum)
              from unnest(con.conkey) k join pg_attribute att on att.attrelid = rel.oid and att.attnum = k)
           = array['message_control_id']
  loop
    execute format('alter table public.lab_messages drop constraint %I', c.conname);
  end loop;
end $$;

create unique index if not exists lab_messages_direction_control_id_key
  on public.lab_messages (direction, message_control_id);

comment on index public.lab_messages_direction_control_id_key is
  'MSH-10 dedupe per direction: ECH''s ACKs reuse our OML''s MSH-10 as their own, so inbound and outbound must not collide (2026-09-21).';
