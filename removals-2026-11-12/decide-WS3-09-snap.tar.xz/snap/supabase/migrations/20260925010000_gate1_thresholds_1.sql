-- ============================================================================
-- Gate 1 threshold decisions (2026-09-25), approved by the CMO on the approval pack of the same day.
-- Decisions and rationale: docs/biomarker-evidence/longevity/GATE-1-DECISIONS.md; source of this SQL:
-- docs/biomarker-evidence/longevity/gate1/changes.json via docs/biomarker-evidence/tools/gate1.js;
-- field by field: docs/biomarker-evidence/longevity/gate1/CHANGES.md.
--  • L1  total cholesterol: no optimal floor (optimal ≤190 mg/dL).
--  • L34 LDL-C optimal ≤60 and non-HDL-C optimal ≤90 mg/dL, the ESC/EAS equivalents of apoB ≤70.
--  • R1  hematocrit optimal: men 42–48 %, women 39–45 %, matching hemoglobin.
--  • W1  white-cell percentages: no bounds (no category); the absolute counts carry the category.
--  • F2  arachidonic acid: no reference floor (no category); read through the AA/EPA ratio.
--  • G1  new HOMA-IR row: optimal ≤1.8, reference ≤3.46.
--  • VD, L1, L34, K1, K2, W1, F1, F2: messages and clinical notes.
-- Bounds are guarded by their current values and texts by the md5 of their current English and Spanish
-- text, so the statements are idempotent and leave rows edited by hand since untouched. Stored results
-- keep the category they had when processed: nothing is reprocessed.
-- ============================================================================
-- Part 1 of 2.

-- L1: total_cholesterol (both)
update public.biomarker_references set optimal_low = null
 where biomarker_key = 'total_cholesterol' and sex = 'both' and age_group_en = 'All Adults'
   and optimal_low is not distinct from 120;

-- L34: ldl_cholesterol (both)
update public.biomarker_references set optimal_high = 60
 where biomarker_key = 'ldl_cholesterol' and sex = 'both' and age_group_en = 'All Adults'
   and optimal_high is not distinct from 70;

-- L34: non_hdl_cholesterol (both)
update public.biomarker_references set optimal_high = 90
 where biomarker_key = 'non_hdl_cholesterol' and sex = 'both' and age_group_en = 'All Adults'
   and optimal_high is not distinct from 100;

-- R1: hematocrit (male)
update public.biomarker_references set optimal_low = 42, optimal_high = 48
 where biomarker_key = 'hematocrit' and sex = 'male' and age_group_en = 'All Adults'
   and optimal_low is not distinct from 40 and optimal_high is not distinct from 46;

-- R1: hematocrit (female)
update public.biomarker_references set optimal_low = 39, optimal_high = 45
 where biomarker_key = 'hematocrit' and sex = 'female' and age_group_en = 'All Adults'
   and optimal_low is not distinct from 37 and optimal_high is not distinct from 43;

-- W1: neutrophils (both)
update public.biomarker_references set normal_low = null, normal_high = null, optimal_low = null, optimal_high = null
 where biomarker_key = 'neutrophils' and sex = 'both' and age_group_en = 'All Adults'
   and normal_low is not distinct from 45 and normal_high is not distinct from 75 and optimal_low is not distinct from 45 and optimal_high is not distinct from 60;

-- W1: lymphocytes (both)
update public.biomarker_references set normal_low = null, normal_high = null, optimal_low = null, optimal_high = null
 where biomarker_key = 'lymphocytes' and sex = 'both' and age_group_en = 'All Adults'
   and normal_low is not distinct from 20 and normal_high is not distinct from 45 and optimal_low is not distinct from 25 and optimal_high is not distinct from 40;

-- W1: monocytes (both)
update public.biomarker_references set normal_low = null, normal_high = null, optimal_low = null, optimal_high = null
 where biomarker_key = 'monocytes' and sex = 'both' and age_group_en = 'All Adults'
   and normal_low is not distinct from 0.2 and normal_high is not distinct from 10 and optimal_low is not distinct from 0.2 and optimal_high is not distinct from 8;

-- W1: eosinophils (both)
update public.biomarker_references set normal_low = null, normal_high = null, optimal_low = null, optimal_high = null
 where biomarker_key = 'eosinophils' and sex = 'both' and age_group_en = 'All Adults'
   and normal_low is not distinct from 0 and normal_high is not distinct from 5 and optimal_low is not distinct from 0 and optimal_high is not distinct from 4;

-- W1: basophils (both)
update public.biomarker_references set normal_low = null, normal_high = null, optimal_low = null, optimal_high = null
 where biomarker_key = 'basophils' and sex = 'both' and age_group_en = 'All Adults'
   and normal_low is not distinct from 0 and normal_high is not distinct from 1.5 and optimal_low is not distinct from 0 and optimal_high is not distinct from 1;

-- F2: omega_6_arachidonic_acid (both)
update public.biomarker_references set normal_low = null
 where biomarker_key = 'omega_6_arachidonic_acid' and sex = 'both' and age_group_en = 'All Adults'
   and normal_low is not distinct from 6.9;

-- G1: new row homa_ir
insert into public.biomarker_references (biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category, is_base_panel, is_genetic, clinical_notes_en, clinical_notes_es, msg_critical_low_en, msg_critical_low_es, msg_below_optimal_en, msg_below_optimal_es, msg_optimal_en, msg_optimal_es, msg_above_optimal_en, msg_above_optimal_es, msg_critical_high_en, msg_critical_high_es)
values ('homa_ir', 'HOMA-IR', 'HOMA-IR', 'index', 'índice', 'both', 'All Adults', 'Todos los Adultos', 0, 3.46, null, 1.8, true, 'metabolic', false, false, 'An estimate of insulin resistance calculated from fasting glucose and fasting insulin (glucose in mg/dL × insulin in µU/mL ÷ 405). A higher value means the body needs more insulin to keep glucose normal, often years before glucose itself rises. It is valid only on a fasting sample.', 'Una estimación de la resistencia a la insulina calculada a partir de la glucosa y la insulina en ayunas (glucosa en mg/dL × insulina en µU/mL ÷ 405). Un valor más alto significa que el cuerpo necesita más insulina para mantener la glucosa normal, a menudo años antes de que la glucosa suba. Solo es válido con una muestra en ayunas.', null, null, null, null, 'HOMA-IR is in the optimal range, which indicates good insulin sensitivity.', 'El HOMA-IR está en el rango óptimo, lo que indica una buena sensibilidad a la insulina.', 'HOMA-IR is above the optimal level but within the reference range. In a large study of Spanish adults, values toward the upper part of this range were linked to the metabolic syndrome. It is an early signal, not a diagnosis.', 'El HOMA-IR está por encima del nivel óptimo, pero dentro del intervalo de referencia. En un gran estudio en adultos españoles, los valores de la parte alta de este intervalo se asociaron al síndrome metabólico. Es una señal temprana, no un diagnóstico.', 'HOMA-IR is above the reference range. It suggests insulin resistance, which is linked to higher mortality in adults without diabetes. Discuss it with your doctor.', 'El HOMA-IR está por encima del intervalo de referencia. Sugiere resistencia a la insulina, que se asocia a una mayor mortalidad en adultos sin diabetes. Coméntalo con tu médico.')
on conflict (biomarker_key, sex, age_group_en) do nothing;

-- VD: msg_critical_low
update public.biomarker_references r
   set msg_critical_low_en = v.new_en, msg_critical_low_es = v.new_es
  from (values
  ('vitamin_d_25_oh', 'both', 'All Adults', '325e5ee26e6fdae0226eab9e32356f4c', '0f14749743f74a383c14d74aef1e8518', 'Vitamin D is below the reference range (30–100 ng/mL). Between 20 and 29 ng/mL this is not a deficiency: European guidelines consider 20 ng/mL or more sufficient for most adults, and large European studies show little or no extra risk at these levels. Below 20 ng/mL it is a deficiency, which can affect bone health. Low levels are common in Spain, especially in winter and spring. Discuss it with your doctor, particularly if you have osteoporosis, have had a fracture or are over 65.', 'La vitamina D está por debajo del intervalo de referencia (30–100 ng/mL). Entre 20 y 29 ng/mL no es una deficiencia: las guías europeas consideran suficiente un nivel de 20 ng/mL o más para la mayoría de los adultos, y los grandes estudios en población europea muestran poco o ningún riesgo adicional en esos niveles. Por debajo de 20 ng/mL sí es una deficiencia, que puede afectar a la salud ósea. Los niveles bajos son frecuentes en España, sobre todo en invierno y primavera. Coméntalo con tu médico, sobre todo si tienes osteoporosis, has tenido alguna fractura o tienes más de 65 años.')
  ) as v(biomarker_key, sex, age_group_en, old_en_md5, old_es_md5, new_en, new_es)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en
   and md5(r.msg_critical_low_en) is not distinct from v.old_en_md5
   and md5(r.msg_critical_low_es) is not distinct from v.old_es_md5;

-- L1, K2, F1: msg_optimal
update public.biomarker_references r
   set msg_optimal_en = v.new_en, msg_optimal_es = v.new_es
  from (values
  ('total_cholesterol', 'both', 'All Adults', '75de45e52ee7d9b4f7a8a7c886419026', '10f04d2498c7de532b7520d89740c796', 'Total cholesterol is in the optimal range. It adds together protective and harmful cholesterol, so read it with LDL-C, non-HDL-C, ApoB and HDL-C. A very low value without cholesterol-lowering treatment is uncommon; if yours is new or unexplained, mention it to your doctor.', 'El colesterol total está en el rango óptimo. Suma el colesterol protector y el dañino, así que interprétalo junto con el colesterol LDL, el colesterol no HDL, la ApoB y el colesterol HDL. Un valor muy bajo sin tratamiento para reducir el colesterol es poco frecuente; si el tuyo es nuevo o no tiene explicación, coméntalo con tu médico.'),
  ('creatinine', 'female', 'All Adults', 'c5b9d3514317a977a3bf48db0040a028', '6d993f5819c20f21e41cbfdd1a77394f', 'Creatinine is in the optimal range. It reflects muscle mass as well as kidney function, so kidney function is judged by eGFR, which adjusts creatinine for age and sex.', 'La creatinina está en el rango óptimo. Refleja la masa muscular además de la función renal, por lo que esta se valora con la TFGe, que ajusta la creatinina según la edad y el sexo.'),
  ('creatinine', 'male', 'All Adults', 'c5b9d3514317a977a3bf48db0040a028', '6d993f5819c20f21e41cbfdd1a77394f', 'Creatinine is in the optimal range. It reflects muscle mass as well as kidney function, so kidney function is judged by eGFR, which adjusts creatinine for age and sex.', 'La creatinina está en el rango óptimo. Refleja la masa muscular además de la función renal, por lo que esta se valora con la TFGe, que ajusta la creatinina según la edad y el sexo.'),
  ('omega_3_total', 'both', 'All Adults', '068d26b65b83a9c4637d9a6e8c84b643', 'da7897a0ff4ec90c7b885d528e65b41b', 'Total omega-3 is in the optimal range. Higher blood levels of the long-chain omega-3s EPA and DHA are linked to lower cardiovascular and all-cause mortality.', 'El omega-3 total está en el rango óptimo. Unos niveles sanguíneos más altos de los omega-3 de cadena larga EPA y DHA se asocian a una menor mortalidad cardiovascular y total.')
  ) as v(biomarker_key, sex, age_group_en, old_en_md5, old_es_md5, new_en, new_es)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en
   and md5(r.msg_optimal_en) is not distinct from v.old_en_md5
   and md5(r.msg_optimal_es) is not distinct from v.old_es_md5;

-- L1, L34, K2: msg_above_optimal
update public.biomarker_references r
   set msg_above_optimal_en = v.new_en, msg_above_optimal_es = v.new_es
  from (values
  ('total_cholesterol', 'both', 'All Adults', null, null, 'Total cholesterol is slightly above the optimal level but within the reference range. Part of it can be HDL cholesterol, which does not build plaque, so LDL-C, non-HDL-C and ApoB give the clearer picture of risk.', 'El colesterol total está ligeramente por encima del nivel óptimo, pero dentro del intervalo de referencia. Una parte puede ser colesterol HDL, que no forma placa, por lo que el colesterol LDL, el colesterol no HDL y la ApoB muestran mejor el riesgo.'),
  ('ldl_cholesterol', 'both', 'All Adults', '0c66330e21851983bd86842afaf2096e', 'bf1f3e13f28c1b9598aa118c5f1eb15f', 'LDL cholesterol is above the optimal target, contributing to increased atherogenic risk and potential arterial plaque development. When LDL-C and ApoB disagree, ApoB is the better guide.', 'El colesterol LDL está por encima del objetivo óptimo, contribuyendo a un mayor riesgo aterogénico y desarrollo potencial de placa arterial. Cuando el colesterol LDL y la ApoB no coinciden, la ApoB es la mejor guía.'),
  ('non_hdl_cholesterol', 'both', 'All Adults', '77a02f3094881824d78a016eaf17b6cd', '2a03d1f7783dd7e4093d6cf1785741f6', 'Non-HDL cholesterol is above optimal, indicating an increased concentration of all atherogenic lipoproteins. When non-HDL-C and ApoB disagree, ApoB is the better guide.', 'El colesterol no-HDL está por encima del óptimo, indicando una concentración aumentada de todas las lipoproteínas aterogénicas. Cuando el colesterol no HDL y la ApoB no coinciden, la ApoB es la mejor guía.'),
  ('creatinine', 'female', 'All Adults', '4ac9e74ec17b3d7f55d508e9daece827', 'f108c667ca023ac4388486f4213c0417', 'Creatinine is above the optimal range but within the reference range. It rises with muscle mass, so a very muscular person can have a high value without any kidney problem. Kidney function is judged by eGFR, which adjusts creatinine for age and sex.', 'La creatinina está por encima del rango óptimo, pero dentro del intervalo de referencia. Aumenta con la masa muscular, así que una persona muy musculada puede tener un valor alto sin ningún problema renal. La función renal se valora con la TFGe, que ajusta la creatinina según la edad y el sexo.'),
  ('creatinine', 'male', 'All Adults', '4ac9e74ec17b3d7f55d508e9daece827', 'f108c667ca023ac4388486f4213c0417', 'Creatinine is above the optimal range but within the reference range. It rises with muscle mass, so a very muscular person can have a high value without any kidney problem. Kidney function is judged by eGFR, which adjusts creatinine for age and sex.', 'La creatinina está por encima del rango óptimo, pero dentro del intervalo de referencia. Aumenta con la masa muscular, así que una persona muy musculada puede tener un valor alto sin ningún problema renal. La función renal se valora con la TFGe, que ajusta la creatinina según la edad y el sexo.')
  ) as v(biomarker_key, sex, age_group_en, old_en_md5, old_es_md5, new_en, new_es)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en
   and md5(r.msg_above_optimal_en) is not distinct from v.old_en_md5
   and md5(r.msg_above_optimal_es) is not distinct from v.old_es_md5;
