-- ============================================================================
-- Evidence-based optimal ranges (2026-09-23) — Chief-Medical-Officer review of every
-- biomarker in biomarker_references. One evidence agent per biomarker answered
-- (1) whether the optimal level differs by sex or age and (2) the optimal level
-- in eva's canonical unit, with every number taken from sources found by web
-- search and every study unit checked or converted to ours; an independent
-- verifier then re-checked sources, units and structure. Dossier:
-- docs/biomarker-evidence/ · published sources: supabase/seed-data/biomarker-sources.json
-- and docs/biomarker-optimal-ranges-sources.md · row-by-row changes:
-- docs/biomarker-evidence/CHANGES.md.
--
-- Only normal_*/optimal_* and the row structure by sex/age band change; names,
-- units and copy are untouched (except the B12 message that quotes its threshold).
-- New rows clone the copy of an existing row of the same marker (its template) and
-- are inserted before any delete. Each step is one statement over a VALUES table
-- keyed by (biomarker_key, sex, age_group_en), the table's unique key. Idempotent:
-- INSERT … ON CONFLICT, UPDATE … FROM, DELETE … USING.
-- Stored biomarker_values keep the zone computed when they were processed.
-- Rows — inserted: 9 · updated: 145 · deleted: 12 · copy: 1
-- ============================================================================

-- 1. New rows (template sex/age → new sex/age, then normal and optimal bounds)
insert into public.biomarker_references (biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category, is_base_panel, is_genetic, clinical_notes_en, clinical_notes_es, msg_critical_low_en, msg_critical_low_es, msg_below_optimal_en, msg_below_optimal_es, msg_optimal_en, msg_optimal_es, msg_above_optimal_en, msg_above_optimal_es, msg_critical_high_en, msg_critical_high_es)
select t.biomarker_key, t.name_en, t.name_es, t.unit_en, t.unit_es, v.sex, v.age_group_en, v.age_group_es, v.normal_low::numeric, v.normal_high::numeric, v.optimal_low::numeric, v.optimal_high::numeric, t.tested_2x_year, t.panel_category, t.is_base_panel, t.is_genetic, t.clinical_notes_en, t.clinical_notes_es, t.msg_critical_low_en, t.msg_critical_low_es, t.msg_below_optimal_en, t.msg_below_optimal_es, t.msg_optimal_en, t.msg_optimal_es, t.msg_above_optimal_en, t.msg_above_optimal_es, t.msg_critical_high_en, t.msg_critical_high_es
  from (values
  ('alp', 'both', '18-49', 'female', 'All Adults', 'Todos los Adultos', 35, 104, 40, 90),
  ('alp', 'both', '18-49', 'male', 'All Adults', 'Todos los Adultos', 40, 129, 40, 90),
  ('copper_serum', 'both', 'All Adults', 'male', 'All Adults', 'Todos los Adultos', 70, 140, 75, 120),
  ('copper_serum', 'both', 'All Adults', 'female', 'All Adults', 'Todos los Adultos', 70, 155, 85, 130),
  ('dhea_sulfate', 'female', '50+', 'female', '60+', '60+', 12, 102, 37, 102),
  ('dhea_sulfate', 'male', '40-49', 'male', '60+', '60+', 21, 375, 70, 375),
  ('ferritin', 'female', 'Premenopausal', 'female', '18-49', '18-49', 10, 200, 50, 150),
  ('ferritin', 'female', 'Postmenopausal', 'female', '50+', '50+', 20, 300, 40, 150),
  ('testosterone_total', 'male', '18-39', 'male', 'All Adults', 'Todos los Adultos', 1.88, 9.16, 3.5, 9.16)
  ) as v(biomarker_key, template_sex, template_age_group, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high)
  join public.biomarker_references t on t.biomarker_key = v.biomarker_key and t.sex = v.template_sex and t.age_group_en = v.template_age_group
on conflict (biomarker_key, sex, age_group_en) do update set normal_low = excluded.normal_low, normal_high = excluded.normal_high, optimal_low = excluded.optimal_low, optimal_high = excluded.optimal_high;

-- 2. Changed ranges (normal_low, normal_high, optimal_low, optimal_high)
update public.biomarker_references r
   set normal_low = v.normal_low::numeric, normal_high = v.normal_high::numeric, optimal_low = v.optimal_low::numeric, optimal_high = v.optimal_high::numeric
  from (values
  ('adiponectin', 'female', 'All Adults', 3.75, 23.35, null, 23.35),
  ('adiponectin', 'male', 'All Adults', 0.84, 16.5, null, 16.5),
  ('albumin', 'both', 'All Adults', 35, 48, 42, 48),
  ('alt', 'male', 'All Adults', 7, 55, 10, 30),
  ('alt', 'female', 'All Adults', 7, 49, 10, 25),
  ('anti_mullerian_hormone_amh', 'female', '18-25', 0.278, 13, 2, 8),
  ('anti_mullerian_hormone_amh', 'female', '26-30', 0.287, 12.242, 1.5, 6),
  ('anti_mullerian_hormone_amh', 'female', '31-35', 0.065, 10.042, 1, 5),
  ('anti_mullerian_hormone_amh', 'female', '36-40', 0.024, 9.232, 0.7, 3.5),
  ('anti_mullerian_hormone_amh', 'female', '41-45', 0.01, 4.5, 0.3, 2),
  ('anti_mullerian_hormone_amh', 'female', '46+', 0, 1.5, 0, 1),
  ('amylase', 'both', 'All Adults', 25, 118, 30, 100),
  ('apolipoprotein_a1_apoa1', 'female', 'All Adults', 110, 205, 150, 205),
  ('apolipoprotein_a1_apoa1', 'male', 'All Adults', 110, 180, 140, 180),
  ('apolipoprotein_b_apob', 'both', 'All Adults', 0, 130, null, 90),
  ('ast', 'male', 'All Adults', 8, 48, 15, 30),
  ('ast', 'female', 'All Adults', 8, 34, 8, 25),
  ('total_bilirubin', 'both', 'All Adults', 0.1, 1.2, 0.4, 1),
  ('bun', 'both', 'All Adults', 7, 25, 10, 18),
  ('urea', 'both', 'All Adults', 15, 54, 21, 39),
  ('bun_creatinine_ratio', 'both', 'All Adults', 10, 20, 11, 18),
  ('calcium_serum', 'both', 'All Adults', 85, 105, 92, 100),
  ('chloride', 'both', 'All Adults', 96, 111, 100, 106),
  ('cortisol_morning_8am', 'both', 'All Adults', 5.7, 22.5, 8, 15),
  ('creatinine', 'female', 'All Adults', 0.55, 1.02, 0.6, 0.9),
  ('cystatin_c', 'both', 'All Adults', 0.5, 1.11, null, 0.85),
  ('dhea_sulfate', 'female', '18-29', 52, 421, 52, 421),
  ('dhea_sulfate', 'female', '30-39', 40, 301, 40, 301),
  ('dhea_sulfate', 'female', '40-59', 22, 218, 37, 218),
  ('dhea_sulfate', 'male', '18-29', 74, 492, 74, 492),
  ('dhea_sulfate', 'male', '30-39', 80, 450, 80, 450),
  ('dhea_sulfate', 'male', '40-59', 49, 351, 70, 351),
  ('egfr_creatinine_based', 'both', '18-39', 75, null, 90, null),
  ('egfr_creatinine_based', 'both', '40-59', 60, null, 75, null),
  ('egfr_creatinine_based', 'both', '60+', 60, null, 65, 105),
  ('eosinophils', 'both', 'All Adults', 0, 5, 0, 4),
  ('estradiol', 'female', 'Premenopausal (follicular)', 20, 145, 20, 145),
  ('estradiol', 'female', 'Premenopausal (ovulatory)', 64, 357, 64, 357),
  ('estradiol', 'female', 'Premenopausal (luteal)', 56, 214, 56, 214),
  ('estradiol', 'female', 'Postmenopausal', 0, 32, 5, 20),
  ('folate_vitamin_b9', 'both', 'All Adults', 4, null, 7, 20),
  ('free_t4_thyroxine', 'both', 'All Adults', 0.89, 1.76, 1, 1.4),
  ('fsh', 'female', 'Premenopausal (follicular)', 2.5, 10.2, 3, 10),
  ('fsh', 'female', 'Ovulatory peak', 3.4, 33.4, null, 33.4),
  ('fsh', 'female', 'Postmenopausal', 23, 116.3, null, 116.3),
  ('fsh', 'male', 'All Adults', 1.4, 18.1, 1.5, 8),
  ('ggt', 'male', 'All Adults', 5, 73, 5, 30),
  ('glucose_fasting', 'both', 'All Adults', 65, 99, 75, 95),
  ('hba1c', 'both', 'All Adults', 4, 5.6, 4.5, 5.4),
  ('hdl_cholesterol', 'male', 'All Adults', 40, 100, 50, 80),
  ('hdl_cholesterol', 'female', 'All Adults', 50, 115, 60, 90),
  ('hematocrit', 'male', 'All Adults', 38.3, 50, 40, 46),
  ('hematocrit', 'female', 'All Adults', 35.5, 45.9, 37, 43),
  ('hemoglobin', 'male', 'All Adults', 13, 17.5, 14, 16),
  ('hemoglobin', 'female', 'All Adults', 12, 16, 13, 15),
  ('holo_transcobalamin_active_b12', 'both', 'All Adults', 35, null, 70, null),
  ('homocysteine', 'both', 'All Adults', 3.7, 15, null, 10),
  ('hs_crp', 'both', 'All Adults', 0, 3, null, 1),
  ('igf_1_insulin_like_growth_factor_1', 'both', '18-29', 83.6, 350, 150, 250),
  ('igf_1_insulin_like_growth_factor_1', 'both', '30-39', 63.4, 260, 130, 220),
  ('igf_1_insulin_like_growth_factor_1', 'both', '40-49', 53.3, 230, 120, 190),
  ('igf_1_insulin_like_growth_factor_1', 'both', '50-59', 44.7, 215, 110, 170),
  ('igf_1_insulin_like_growth_factor_1', 'both', '60+', 30.6, 225, 90, 150),
  ('insulin_fasting', 'both', 'All Adults', 0, 29.1, null, 8),
  ('iodine_urine', 'both', 'All Adults', 50, 300, 100, 200),
  ('iron_serum', 'male', 'All Adults', 60, 175, 70, 150),
  ('iron_binding_capacity_tibc', 'both', 'All Adults', 250, 425, 275, 375),
  ('lead_blood', 'both', 'All Adults', 0, 5, null, 1.5),
  ('leptin', 'male', 'All Adults', 0.7, 10, 0.7, 5),
  ('leptin', 'female', 'All Adults', 0.7, 30, 0.7, 12),
  ('luteinizing_hormone_lh', 'female', 'Ovulatory peak', 8.7, 76.3, 15, 60),
  ('luteinizing_hormone_lh', 'female', 'Postmenopausal', 7.9, 53.8, null, 53.8),
  ('luteinizing_hormone_lh', 'male', 'All Adults', 1.5, 9.3, 2, 7),
  ('lipase', 'both', 'All Adults', 0, 53, 12, 50),
  ('lymphocytes', 'both', 'All Adults', 20, 45, 25, 40),
  ('lymphocytes_absolute', 'both', 'All Adults', 1000, 4000, 1500, 3000),
  ('magnesium_serum', 'both', 'All Adults', 1.7, 2.6, 2, 2.2),
  ('mch', 'both', 'All Adults', 25, 35, 28, 32),
  ('mchc', 'both', 'All Adults', 28, 37, 32, 35),
  ('mcv', 'both', 'All Adults', 80, 100, 82, 93),
  ('mercury_blood', 'both', 'All Adults', 0, 15, null, 5),
  ('microalbumin_urine', 'both', 'All Adults', 0, 30, null, 10),
  ('monocytes', 'both', 'All Adults', 0.2, 10, 0.2, 8),
  ('monocytes_absolute', 'both', 'All Adults', 200, 950, 200, 700),
  ('mpv', 'both', 'All Adults', 6, 11, 6, 11),
  ('neutrophils', 'both', 'All Adults', 40, 75, 40, 60),
  ('neutrophils_absolute', 'both', 'All Adults', 1710, 8575, 2000, 4000),
  ('ldl_small', 'both', 'All Adults', null, 700, null, 700),
  ('ldl_peak_size', 'both', 'All Adults', null, null, 205, null),
  ('hdl_large', 'both', 'All Adults', 2.5, 15, 5, 15),
  ('non_hdl_cholesterol', 'both', 'All Adults', 0, 160, null, 130),
  ('nt_probnp', 'both', '18-49', 0, 125, null, 100),
  ('nt_probnp', 'both', '50-74', 0, 250, null, 125),
  ('nt_probnp', 'both', '75+', 0, 500, null, 250),
  ('omega_3_total', 'both', 'All Adults', 1.9, null, 4, null),
  ('omega_3_epa', 'both', 'All Adults', 0.3, null, 1, null),
  ('omega_3_dha', 'both', 'All Adults', 1.3, null, 3, null),
  ('omega_6_total', 'both', 'All Adults', 23.6, null, null, null),
  ('omega_6_arachidonic_acid', 'both', 'All Adults', 6.9, null, null, null),
  ('omega_6_linoleic_acid', 'both', 'All Adults', 15, null, null, null),
  ('omega_6_omega_3_ratio', 'both', 'All Adults', null, 10, null, 10),
  ('arachidonic_acid_epa_ratio', 'both', 'All Adults', null, 42, null, 4),
  ('platelet_count', 'both', 'All Adults', 150000, 450000, 175000, 300000),
  ('potassium', 'both', 'All Adults', 3.5, 5.1, 4, 4.8),
  ('progesterone', 'female', 'On Hormone Therapy', 0, 40, null, 40),
  ('progesterone', 'female', 'Postmenopausal', 0, 0.73, null, 0.73),
  ('progesterone', 'female', 'Premenopausal (follicular)', 0, 1.4, null, 1.4),
  ('progesterone', 'female', 'Premenopausal (luteal)', 1.7, 28.03, 5, 28.03),
  ('progesterone', 'female', 'Premenopausal (ovulatory)', 0, 4, null, 4),
  ('progesterone', 'male', 'All Adults', 0, 1.22, null, 1.22),
  ('prolactin', 'female', 'All Adults', 3, 29, 5, 20),
  ('prolactin', 'male', 'All Adults', 3, 18, 5, 15),
  ('psa_total', 'male', '60-69', 0, 4.5, null, 2),
  ('pth_intact_parathyroid_hormone', 'both', 'All Adults', 15, 80.1, 20, 45),
  ('red_blood_cell_count', 'male', 'All Adults', 4200000, 5800000, 4500000, 5500000),
  ('red_blood_cell_count', 'female', 'All Adults', 3800000, 5300000, 4000000, 5000000),
  ('rdw', 'both', 'All Adults', 11.5, 14.5, 11.5, 13),
  ('selenium_serum', 'both', 'All Adults', 0, 150, 110, 140),
  ('total_protein', 'both', 'All Adults', 57, 83, 65, 80),
  ('globulin', 'both', 'All Adults', 1.9, 4, 2.2, 3),
  ('albumin_globulin_ratio', 'both', 'All Adults', 1, 2.5, 1.4, 2.2),
  ('shbg', 'female', 'All Adults', 11, 180, 40, 100),
  ('shbg', 'male', '18-39', 12, 95, 20, 45),
  ('shbg', 'male', '40-59', 15, 113, 20, 50),
  ('shbg', 'male', '60+', 20, 115, 25, 55),
  ('sodium', 'both', 'All Adults', 135, 145, 138, 142),
  ('testosterone_free', 'female', '18-39', 0.07, 0.75, null, 0.75),
  ('testosterone_free', 'female', '40-59', 0.07, 0.75, null, 0.75),
  ('testosterone_free', 'female', '60+', 0.07, 0.75, null, 0.75),
  ('testosterone_total', 'female', 'All Adults', 0.08, 0.6, 0.1, 0.45),
  ('thyroglobulin_antibodies_tgab', 'both', 'All Adults', 0, 4.5, null, 4.5),
  ('total_cholesterol', 'both', 'All Adults', 0, 200, 125, 190),
  ('thyroid_peroxidase_antibodies_tpo', 'both', 'All Adults', 0, 13.8, null, 13.8),
  ('tsh', 'both', '18-39', 0.4, 4.78, 1, 3),
  ('tsh', 'both', '40-59', 0.4, 4.78, 1, 3),
  ('tsh', 'both', '60+', 0.4, 6, 1, 4),
  ('vitamin_a_retinol', 'both', 'All Adults', 30, 86, 50, 75),
  ('vitamin_b1_thiamine', 'both', 'All Adults', 70, null, 100, null),
  ('vitamin_b12', 'both', 'All Adults', 200, 911, 400, 800),
  ('vitamin_c_ascorbic_acid', 'both', 'All Adults', 0.4, null, 0.9, null),
  ('vitamin_d_25_oh', 'both', 'All Adults', 20, 100, 30, 50),
  ('vitamin_e_alpha_tocopherol', 'both', 'All Adults', 5, 26.5, 13, 26.5),
  ('vitamin_k1_phylloquinone', 'both', 'All Adults', 0.1, 2.2, 0.3, 2.2),
  ('white_blood_cell_count', 'both', 'All Adults', 3800, 11500, 4500, 6000),
  ('zinc_serum', 'both', 'All Adults', 60, 130, 75, 110)
  ) as v(biomarker_key, sex, age_group_en, normal_low, normal_high, optimal_low, optimal_high)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;

-- 3. Removed rows
delete from public.biomarker_references r
 using (values
  ('alp', 'both', '18-49'),
  ('alp', 'both', '50+'),
  ('copper_serum', 'both', 'All Adults'),
  ('dhea_sulfate', 'female', '40-49'),
  ('dhea_sulfate', 'female', '50+'),
  ('dhea_sulfate', 'male', '40-49'),
  ('dhea_sulfate', 'male', '50+'),
  ('ferritin', 'female', 'Premenopausal'),
  ('ferritin', 'female', 'Postmenopausal'),
  ('testosterone_total', 'male', '18-39'),
  ('testosterone_total', 'male', '40-59'),
  ('testosterone_total', 'male', '60+')
  ) as v(biomarker_key, sex, age_group_en)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;

-- 4. Copy that quotes a threshold
update public.biomarker_references set msg_below_optimal_en = replace(msg_below_optimal_en, '500 pg/mL', '400 pg/mL'), msg_below_optimal_es = replace(msg_below_optimal_es, '500 pg/mL', '400 pg/mL') where biomarker_key = 'vitamin_b12';
