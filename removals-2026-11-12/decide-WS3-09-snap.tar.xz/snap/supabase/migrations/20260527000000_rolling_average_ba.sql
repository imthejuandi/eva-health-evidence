-- ============================================================================
-- Rolling-average biological age — cached per-user current BA.
--
-- Adds five columns to `profiles` that hold the user-facing biological age,
-- computed from biomarkers AVERAGED across the user's labs in a recent
-- time window. This is what the dashboard displays as the user's "current"
-- BA — a single, stable number that smooths inter-lab measurement noise.
--
-- The number is recomputed and cached on every successful lab upload by
-- `recomputeAndCacheUserBA()` in `src/lib/biomarkers/rolling-average-ba.ts`.
-- This is intentional: the BA only changes when new lab data arrives, so
-- recomputing on every dashboard hit would waste compute. The cached
-- values stay valid until the next lab upload triggers a fresh compute.
--
-- Window selection (handled at compute time, not at SQL level):
--   1. 6-month window primary: average biomarkers from labs in the last
--      6 months when ≥ 2 labs exist in that window.
--   2. 12-month fallback: when < 2 labs in 6 months, fall back to 12.
--   3. Single-lab fallback: when < 2 labs in 12 months, use the most
--      recent lab's biomarkers directly.
--
-- Tier selection:
--   - Comprehensive when the joint estimator gate passes with enough
--     extended-panel markers (always preferred).
--   - Reference as fallback when only base panel uploaded.
-- ============================================================================

ALTER TABLE profiles
  ADD COLUMN current_ba                 numeric,
  ADD COLUMN current_ba_method          text,
  ADD COLUMN current_ba_n_labs_averaged integer,
  ADD COLUMN current_ba_window_months   integer,
  ADD COLUMN current_ba_n_markers_used  integer,
  ADD COLUMN current_ba_computed_at     timestamptz;

COMMENT ON COLUMN profiles.current_ba IS
  'Cached biological age in years, computed from biomarkers averaged across labs in the recent window (6 or 12 months). This is the value the dashboard shows. Recomputed on each lab upload.';

COMMENT ON COLUMN profiles.current_ba_method IS
  '"Comprehensive" when the full-panel joint estimator was used (preferred), "Reference" when only base-panel markers were available, NULL when no BA could be computed.';

COMMENT ON COLUMN profiles.current_ba_n_labs_averaged IS
  'How many lab_results contributed to the rolling average (1 = single-lab fallback, 2+ = averaged window).';

COMMENT ON COLUMN profiles.current_ba_window_months IS
  '6 when the 6-month window had ≥2 labs; 12 when the 12-month fallback was used; NULL for single-lab fallback (no window).';

COMMENT ON COLUMN profiles.current_ba_n_markers_used IS
  'How many distinct biomarkers contributed to the joint estimator (post-averaging, post-gate).';

COMMENT ON COLUMN profiles.current_ba_computed_at IS
  'Timestamp of the most recent recompute. Useful for diagnosing stale caches.';
