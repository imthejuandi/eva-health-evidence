-- ============================================================================
-- EVA Health Full Schema
-- ============================================================================

-- Profiles (extends Supabase auth.users)
create table if not exists public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text,
  email text,
  date_of_birth text,
  sex text check (sex in ('male', 'female')),
  height_cm numeric,
  weight_kg numeric,
  health_knowledge text check (health_knowledge in ('beginner', 'familiar', 'optimizer')),
  onboarding_completed boolean not null default false,
  subscription_status text not null default 'free' check (subscription_status in ('free', 'active', 'cancelled', 'past_due')),
  subscription_period_end timestamptz,
  locale text not null default 'es',
  total_uploads_used integer not null default 0,
  stripe_customer_id text,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
create policy "Users can view own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert with check (auth.uid() = id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Lab Results
create table if not exists public.lab_results (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  source text not null default 'user_upload',
  panel_type text default 'uploaded',
  status text not null default 'processing' check (status in ('processing', 'ready', 'error')),
  collection_date date,
  biological_age numeric,
  longevity_score integer,
  longevity_grade text,
  summary_narrative text,
  summary_narrative_es text,
  strengths text[] default '{}',
  needs_attention text[] default '{}',
  optimal_count integer default 0,
  attention_count integer default 0,
  action_count integer default 0,
  created_at timestamptz not null default now()
);

alter table public.lab_results enable row level security;
create policy "Users can view own lab results" on public.lab_results for select using (auth.uid() = user_id);
create policy "Users can insert own lab results" on public.lab_results for insert with check (auth.uid() = user_id);
create policy "Users can update own lab results" on public.lab_results for update using (auth.uid() = user_id);

-- Biomarker Values (per-result biomarker readings)
create table if not exists public.biomarker_values (
  id uuid default gen_random_uuid() primary key,
  lab_result_id uuid references public.lab_results(id) on delete cascade not null,
  biomarker_key text not null,
  biomarker_name text,
  category text default '',
  value numeric not null,
  unit text not null,
  zone text not null default 'unclassified',
  optimal_low numeric,
  optimal_high numeric,
  normal_low numeric,
  normal_high numeric,
  interpretation text,
  interpretation_es text,
  created_at timestamptz not null default now()
);

alter table public.biomarker_values enable row level security;
create policy "Users can view own biomarker values" on public.biomarker_values
  for select using (
    exists (select 1 from public.lab_results lr where lr.id = lab_result_id and lr.user_id = auth.uid())
  );
create policy "Users can insert own biomarker values" on public.biomarker_values
  for insert with check (
    exists (select 1 from public.lab_results lr where lr.id = lab_result_id and lr.user_id = auth.uid())
  );
create policy "Users can update own biomarker values" on public.biomarker_values
  for update using (
    exists (select 1 from public.lab_results lr where lr.id = lab_result_id and lr.user_id = auth.uid())
  );

-- Biomarker References (longevity-optimal ranges, seeded from JSON)
create table if not exists public.biomarker_references (
  id uuid default gen_random_uuid() primary key,
  biomarker_key text not null,
  name_en text not null,
  name_es text not null,
  unit_en text,
  unit_es text,
  sex text not null,
  age_group_en text not null,
  age_group_es text,
  normal_low numeric,
  normal_high numeric,
  optimal_low numeric,
  optimal_high numeric,
  tested_2x_year boolean default false,
  panel_category text,
  is_base_panel boolean default false,
  is_genetic boolean default false,
  clinical_notes_en text,
  clinical_notes_es text,
  msg_critical_low_en text,
  msg_critical_low_es text,
  msg_below_optimal_en text,
  msg_below_optimal_es text,
  msg_optimal_en text,
  msg_optimal_es text,
  msg_above_optimal_en text,
  msg_above_optimal_es text,
  msg_critical_high_en text,
  msg_critical_high_es text,
  unique(biomarker_key, sex, age_group_en)
);

-- References are public (read-only for all)
alter table public.biomarker_references enable row level security;
create policy "Anyone can read biomarker references" on public.biomarker_references for select using (true);

-- Action Steps
create table if not exists public.action_steps (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  lab_result_id uuid references public.lab_results(id) on delete cascade not null,
  priority integer not null default 1,
  category text not null default 'lifestyle',
  title text not null,
  title_es text,
  description text not null,
  description_es text,
  related_biomarker_keys text[] default '{}',
  status text not null default 'pending' check (status in ('pending', 'in_progress', 'completed', 'dismissed')),
  created_at timestamptz not null default now()
);

alter table public.action_steps enable row level security;
create policy "Users can view own action steps" on public.action_steps for select using (auth.uid() = user_id);
create policy "Users can insert own action steps" on public.action_steps for insert with check (auth.uid() = user_id);
create policy "Users can update own action steps" on public.action_steps for update using (auth.uid() = user_id);

-- Wearable Data
create table if not exists public.wearable_data (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  date date not null,
  hrv_ms numeric,
  resting_hr_bpm numeric,
  sleep_hours numeric,
  respiratory_rate numeric,
  recovery_score numeric,
  steps integer,
  source text not null default 'apple_health',
  unique(user_id, date, source)
);

alter table public.wearable_data enable row level security;
create policy "Users can view own wearable data" on public.wearable_data for select using (auth.uid() = user_id);
create policy "Users can insert own wearable data" on public.wearable_data for insert with check (auth.uid() = user_id);

-- Email Subscribers
create table if not exists public.email_subscribers (
  id uuid default gen_random_uuid() primary key,
  email text not null unique,
  source text not null default 'blog',
  locale text not null default 'es',
  subscribed_at timestamptz not null default now()
);

alter table public.email_subscribers enable row level security;
drop policy if exists "Anyone can subscribe" on public.email_subscribers;
create policy "Anyone can subscribe" on public.email_subscribers for insert with check (true);
drop policy if exists "Service role can read subscribers" on public.email_subscribers;
create policy "Service role can read subscribers" on public.email_subscribers for select using (auth.role() = 'service_role');

-- Booked Tests
create table if not exists public.booked_tests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  panel_type text not null default 'base',
  status text not null default 'scheduled' check (status in ('scheduled', 'kit_sent', 'sample_received', 'processing', 'completed', 'cancelled')),
  scheduled_date date,
  created_at timestamptz not null default now()
);

alter table public.booked_tests enable row level security;
create policy "Users can view own booked tests" on public.booked_tests for select using (auth.uid() = user_id);
create policy "Users can insert own booked tests" on public.booked_tests for insert with check (auth.uid() = user_id);

-- Storage bucket for lab uploads
insert into storage.buckets (id, name, public) values ('lab-uploads', 'lab-uploads', false)
on conflict (id) do nothing;

create policy "Users can upload to own folder" on storage.objects
  for insert with check (bucket_id = 'lab-uploads' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users can read own uploads" on storage.objects
  for select using (bucket_id = 'lab-uploads' and (storage.foldername(name))[1] = auth.uid()::text);
