-- Identity document for the lab order (PID.3).
-- Echevarne requires a categorized identifier on every OML (J. Fajardo,
-- 2026-08-31): PID.3.5 ∈ NHC | DNI | NIF | CIF | NIE | PASAPORTE | DNI_TUTOR |
-- NIF_TUTOR | NIE_TUTOR | OTROS | CENSO | ID. eva captures it on the profile
-- page next to the shipping address and requires it BEFORE a kit ships,
-- because the initial OML is sent at dispatch (hybrid design, see
-- docs/context/correspondence/2026-08-31-respuesta-fajardo.md).
--
-- Personal data (not Art. 9). Covered by the existing profiles RLS
-- ("Users can update own profile"), the GDPR export (select *) and the
-- account-deletion cascade.

alter table public.profiles
  add column if not exists id_document_type text,
  add column if not exists id_document_number text;

alter table public.profiles
  drop constraint if exists profiles_id_document_type_check;
alter table public.profiles
  add constraint profiles_id_document_type_check check (
    id_document_type is null or id_document_type in (
      'DNI', 'NIF', 'CIF', 'NIE', 'PASAPORTE', 'CENSO', 'OTROS', 'ID',
      'DNI_TUTOR', 'NIF_TUTOR', 'NIE_TUTOR'
    )
  );

-- Both or neither: a type without a number (or vice versa) is meaningless.
alter table public.profiles
  drop constraint if exists profiles_id_document_pair_check;
alter table public.profiles
  add constraint profiles_id_document_pair_check check (
    (id_document_type is null) = (id_document_number is null)
  );

comment on column public.profiles.id_document_type is
  'PID.3.5 IdentifierTypeCode per Echevarne spec v2.8 (DNI|NIF|CIF|NIE|PASAPORTE|CENSO|OTROS|ID|*_TUTOR)';
comment on column public.profiles.id_document_number is
  'Identity document number, normalized (uppercase, no spaces/separators); sent as PID.3.1';
