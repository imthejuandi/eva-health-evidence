-- Short, stable, alphanumeric patient reference for the lab (PID.3 «NHC»)
-- and for the placer order number (ORC-2.1). Echevarne (J. Fajardo,
-- 2026-09-07) requires both to be short alphanumeric references — our
-- previous UUID-derived, hyphenated formats were rejected in training.
--
-- NHC  = 'EVA' || lpad(patient_number, 6, '0')           e.g. EVA000042
-- Placer = NHC || lpad(cycle seq, 3, '0')                 e.g. EVA000042001
-- (both computed in code: src/lib/cycles/identifiers.ts)
--
-- Identity column: Postgres backfills existing rows on ADD COLUMN.

alter table public.profiles
  add column if not exists patient_number bigint generated always as identity;

create unique index if not exists profiles_patient_number_key
  on public.profiles (patient_number);

comment on column public.profiles.patient_number is
  'Sequential patient reference; rendered as EVA + 6 digits for Echevarne (PID.3 NHC) and as the placer order prefix';
