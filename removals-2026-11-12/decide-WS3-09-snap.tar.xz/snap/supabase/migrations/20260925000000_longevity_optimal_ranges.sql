-- ============================================================================
-- Longevity-medicine review (2026-09-25) of every range in biomarker_references, after the
-- evidence-based review applied in 20260923000000. One longevity-medicine reviewer per
-- biomarker set the optimal band at the level linked to the lowest risk of death and
-- age-related disease (Mendelian randomisation, trials and large cohorts ahead of
-- guideline treatment targets), with the reference range following the partner lab
-- unless a named clinical threshold applies; an independent verifier re-checked every
-- new source, unit and row. Dossier: docs/biomarker-evidence/longevity/ · published
-- sources: supabase/seed-data/biomarker-sources.json and
-- docs/biomarker-optimal-ranges-sources.md · row-by-row changes:
-- docs/biomarker-evidence/longevity/CHANGES.md.
--
-- Only normal_*/optimal_* and the row structure by sex/age band change; names,
-- units and copy are untouched (except the B12 message that quotes its threshold).
-- New rows clone the copy of an existing row of the same marker (its template) and
-- are inserted before any delete. Each step is one statement over a VALUES table
-- keyed by (biomarker_key, sex, age_group_en), the table's unique key. Idempotent:
-- INSERT … ON CONFLICT, UPDATE … FROM, DELETE … USING.
-- Stored biomarker_values keep the zone computed when they were processed.
-- Rows — inserted: 13 · updated: 79 · deleted: 6 · copy: 0
-- ============================================================================

-- 1. New rows (template sex/age → new sex/age, then normal and optimal bounds)
insert into public.biomarker_references (biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category, is_base_panel, is_genetic, clinical_notes_en, clinical_notes_es, msg_critical_low_en, msg_critical_low_es, msg_below_optimal_en, msg_below_optimal_es, msg_optimal_en, msg_optimal_es, msg_above_optimal_en, msg_above_optimal_es, msg_critical_high_en, msg_critical_high_es)
select t.biomarker_key, t.name_en, t.name_es, t.unit_en, t.unit_es, v.sex, v.age_group_en, v.age_group_es, v.normal_low::numeric, v.normal_high::numeric, v.optimal_low::numeric, v.optimal_high::numeric, t.tested_2x_year, t.panel_category, t.is_base_panel, t.is_genetic, t.clinical_notes_en, t.clinical_notes_es, t.msg_critical_low_en, t.msg_critical_low_es, t.msg_below_optimal_en, t.msg_below_optimal_es, t.msg_optimal_en, t.msg_optimal_es, t.msg_above_optimal_en, t.msg_above_optimal_es, t.msg_critical_high_en, t.msg_critical_high_es
  from (values
  ('anti_mullerian_hormone_amh', 'female', '26-30', 'female', '18-21', '18-21', 0.87, 11.37, 2, 8),
  ('anti_mullerian_hormone_amh', 'female', '36-40', 'female', '22-25', '22-25', 0.278, 8.011, 2, 6),
  ('total_bilirubin', 'both', 'All Adults', 'both', '18-59', '18-59', 0.3, 1.2, 0.4, 1),
  ('total_bilirubin', 'both', 'All Adults', 'both', '60-89', '60-89', 0.2, 1.1, 0.4, 1),
  ('total_bilirubin', 'both', 'All Adults', 'both', '90+', '90+', 0.2, 0.9, 0.4, 0.9),
  ('neutrophils_absolute', 'both', 'All Adults', 'male', 'All Adults', 'Todos los Adultos', 1890, 8575, 2000, 4000),
  ('neutrophils_absolute', 'both', 'All Adults', 'female', 'All Adults', 'Todos los Adultos', 1710, 8575, 2000, 4000),
  ('prolactin', 'female', 'All Adults', 'female', '18-49', '18-49', 2.8, 29.2, 5, 20),
  ('prolactin', 'female', 'All Adults', 'female', '50+', '50+', 1.8, 20.3, 5, 15),
  ('testosterone_total', 'female', 'All Adults', 'female', '18-49', '18-49', 0.08, 0.35, 0.1, 0.35),
  ('testosterone_total', 'female', 'All Adults', 'female', '50+', '50+', null, 0.36, null, 0.36),
  ('white_blood_cell_count', 'both', 'All Adults', 'male', 'All Adults', 'Todos los Adultos', 4200, 11500, 4500, 6000),
  ('white_blood_cell_count', 'both', 'All Adults', 'female', 'All Adults', 'Todos los Adultos', 3800, 11500, 4500, 6000)
  ) as v(biomarker_key, template_sex, template_age_group, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high)
  join public.biomarker_references t on t.biomarker_key = v.biomarker_key and t.sex = v.template_sex and t.age_group_en = v.template_age_group
on conflict (biomarker_key, sex, age_group_en) do update set normal_low = excluded.normal_low, normal_high = excluded.normal_high, optimal_low = excluded.optimal_low, optimal_high = excluded.optimal_high;

-- 2. Changed ranges (normal_low, normal_high, optimal_low, optimal_high)
update public.biomarker_references r
   set normal_low = v.normal_low::numeric, normal_high = v.normal_high::numeric, optimal_low = v.optimal_low::numeric, optimal_high = v.optimal_high::numeric
  from (values
  ('alp', 'female', 'All Adults', 35, 104, 40, 80),
  ('alp', 'male', 'All Adults', 40, 129, 40, 80),
  ('alt', 'male', 'All Adults', 10, 49, 10, 30),
  ('alt', 'female', 'All Adults', 10, 49, 10, 25),
  ('anti_mullerian_hormone_amh', 'female', '41-45', 0.024, 4.48, 0.3, 2),
  ('amylase', 'both', 'All Adults', 30, 118, 30, 118),
  ('apolipoprotein_b_apob', 'both', 'All Adults', 0, 100, null, 70),
  ('ast', 'male', 'All Adults', 0, 34, 15, 30),
  ('ast', 'female', 'All Adults', 0, 34, 8, 25),
  ('basophils', 'both', 'All Adults', 0, 1.5, 0, 1),
  ('basophils_absolute', 'both', 'All Adults', 0, 175, 0, 100),
  ('bun', 'both', 'All Adults', 10, 25, 10, 18),
  ('calcium_serum', 'both', 'All Adults', 83, 106, 92, 100),
  ('chloride', 'both', 'All Adults', 102, 111, 102, 107),
  ('copper_serum', 'female', 'All Adults', 70, 140, 85, 130),
  ('cystatin_c', 'both', 'All Adults', 0.62, 1.11, null, 0.85),
  ('estradiol', 'male', 'All Adults', 0, 40, 15, 35),
  ('ferritin', 'male', 'All Adults', 31, 300, 40, 150),
  ('ferritin', 'female', '18-49', 31, 200, 50, 150),
  ('ferritin', 'female', '50+', 31, 291, 40, 150),
  ('folate_vitamin_b9', 'both', 'All Adults', 5.38, null, 10, 20),
  ('ggt', 'male', 'All Adults', 0, 73, 5, 30),
  ('ggt', 'female', 'All Adults', 0, 38, 5, 20),
  ('glucose_fasting', 'both', 'All Adults', 74, 99, 74, 90),
  ('hba1c', 'both', 'All Adults', 4.3, 5.6, 4.5, 5.4),
  ('hematocrit', 'male', 'All Adults', 40, 52, 40, 46),
  ('hematocrit', 'female', 'All Adults', 36, 48, 37, 43),
  ('homocysteine', 'both', 'All Adults', 3.7, 13.9, null, 10),
  ('hs_crp', 'both', 'All Adults', 0, 3, null, 0.5),
  ('igf_1_insulin_like_growth_factor_1', 'both', '18-29', 83.6, 323, 150, 250),
  ('igf_1_insulin_like_growth_factor_1', 'both', '30-39', 63.4, 234, 130, 220),
  ('igf_1_insulin_like_growth_factor_1', 'both', '40-49', 53.3, 219, 120, 190),
  ('igf_1_insulin_like_growth_factor_1', 'both', '50-59', 44.7, 210, 110, 170),
  ('iodine_urine', 'both', 'All Adults', 50, 300, 100, 300),
  ('iron_serum', 'male', 'All Adults', 65, 175, 70, 150),
  ('iron_serum', 'female', 'All Adults', 50, 170, 60, 140),
  ('iron_binding_capacity_tibc', 'both', 'All Adults', 250, 425, 250, 425),
  ('ldl_cholesterol', 'both', 'All Adults', 0, 100, null, 70),
  ('leptin', 'male', 'All Adults', 0.7, 8.3, 0.7, 5),
  ('leptin', 'female', 'All Adults', 0.7, 8.3, 0.7, 8.3),
  ('lipase', 'both', 'All Adults', 12, 53, 12, 53),
  ('magnesium_serum', 'both', 'All Adults', 1.6, 2.6, 2, 2.2),
  ('neutrophils', 'both', 'All Adults', 45, 75, 45, 60),
  ('ldl_particle_number', 'both', 'All Adults', null, 1300, null, 1000),
  ('hdl_large', 'both', 'All Adults', 2.5, 15, 2.5, 15),
  ('non_hdl_cholesterol', 'both', 'All Adults', 0, 130, null, 100),
  ('nt_probnp', 'both', '18-49', 0, 125, null, 75),
  ('nt_probnp', 'both', '50-74', 0, 125, null, 100),
  ('nt_probnp', 'both', '75+', 0, 300, null, 250),
  ('omega_6_omega_3_ratio', 'both', 'All Adults', null, 10, null, 8),
  ('progesterone', 'female', 'Premenopausal (luteal)', 3.34, 28.03, 5, 28.03),
  ('prolactin', 'male', 'All Adults', 2.1, 17.7, 5, 15),
  ('psa_total', 'male', '18-49', 0, 3, null, 1),
  ('psa_total', 'male', '50-59', 0, 3, null, 1.5),
  ('psa_total', 'male', '60-69', 0, 3, null, 2),
  ('psa_total', 'male', '70+', 0, 4, null, 2),
  ('pth_intact_parathyroid_hormone', 'both', 'All Adults', 18.4, 80.1, 18.4, 45),
  ('rheumatoid_factor_rf', 'both', 'All Adults', 0, 14, null, 14),
  ('total_protein', 'both', 'All Adults', 57, 82, 65, 80),
  ('albumin_globulin_ratio', 'both', 'All Adults', 1, 2.5, 1.4, 2.5),
  ('shbg', 'female', 'All Adults', 10.8, 180, 40, 100),
  ('shbg', 'male', '18-39', 14.5, 95, 20, 45),
  ('shbg', 'male', '40-59', 14.5, 113.2, 20, 50),
  ('shbg', 'male', '60+', 21.6, 113.2, 25, 55),
  ('sodium', 'both', 'All Adults', 136, 145, 138, 142),
  ('testosterone_free', 'male', '18-39', 5, 21, 6, 20),
  ('testosterone_free', 'male', '40-59', 4, 18, 6, 17),
  ('testosterone_total', 'male', 'All Adults', 1.88, 6.84, 3.5, 6.84),
  ('total_cholesterol', 'both', 'All Adults', 0, 200, 120, 190),
  ('tsh', 'both', '18-39', 0.55, 4.78, 1, 3),
  ('tsh', 'both', '40-59', 0.55, 4.78, 1, 3),
  ('tsh', 'both', '60+', 0.55, 4.78, 1, 4),
  ('uric_acid', 'male', 'All Adults', 3.7, 7, 4, 6),
  ('uric_acid', 'female', 'All Adults', 3.1, 6, 3.1, 5),
  ('vitamin_b12', 'both', 'All Adults', 211, 911, 400, 800),
  ('vitamin_b6_pyridoxal_5_phosphate', 'both', 'All Adults', 20, 125, 40, 100),
  ('vitamin_c_ascorbic_acid', 'both', 'All Adults', 0.5, null, 0.9, null),
  ('vitamin_d_25_oh', 'both', 'All Adults', 30, 100, 30, 50),
  ('zinc_serum', 'both', 'All Adults', 67, 120, 75, 110)
  ) as v(biomarker_key, sex, age_group_en, normal_low, normal_high, optimal_low, optimal_high)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;

-- 3. Removed rows
delete from public.biomarker_references r
 using (values
  ('anti_mullerian_hormone_amh', 'female', '18-25'),
  ('total_bilirubin', 'both', 'All Adults'),
  ('neutrophils_absolute', 'both', 'All Adults'),
  ('prolactin', 'female', 'All Adults'),
  ('testosterone_total', 'female', 'All Adults'),
  ('white_blood_cell_count', 'both', 'All Adults')
  ) as v(biomarker_key, sex, age_group_en)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;

-- 4. Copy that quotes a threshold
-- none
