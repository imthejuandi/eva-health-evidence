-- ============================================================================
-- Observaciones del laboratorio, valores acotados y correcciones (2026-09-22).
--
-- 1. lab_results.lab_notes: las observaciones de texto que el laboratorio
--    envía con el resultado (OBX de tipo TX: valoraciones, comentarios de
--    interferencia, «se recomienda…»), como [{code, text}]. Se muestran
--    al paciente como parte del resultado y se pasan a la interpretación.
-- 2. lab_results.corrected_at: cuándo un ORU final o corregido reemplazó
--    los valores de un resultado ya registrado (una sola fila por ciclo).
-- 3. biomarker_values.comparator: «<» o «>» cuando el laboratorio informa
--    un valor acotado («<0,500»); el número guardado es el límite.
-- Idempotente.
-- ============================================================================

alter table public.lab_results
  add column if not exists lab_notes jsonb,
  add column if not exists corrected_at timestamptz;

alter table public.biomarker_values
  add column if not exists comparator text
    check (comparator is null or comparator in ('<', '>'));

comment on column public.lab_results.lab_notes is
  'Observaciones de texto del laboratorio (OBX TX) tal como llegaron: [{code, text}]. Parte del resultado; también entran en la interpretación.';
comment on column public.lab_results.corrected_at is
  'Última vez que un ORU final/corregido reemplazó los valores de este resultado.';
comment on column public.biomarker_values.comparator is
  'Comparador de un valor acotado informado por el laboratorio (< o >); value es el límite.';
