-- Migrate legacy biomarker_values rows whose name was "Urea" but whose
-- biomarker_key is 'bun' (because the pre-Urea-split name-matcher
-- collapsed both Urea and BUN to 'bun', and convertBiomarker scaled
-- the stored value by ×0.4665 to fit BUN's reference range).
--
-- Reverse the scaling (×1/0.4665 = ×2.14358) to recover the Urea-scale
-- reading, then reclassify against the urea reference range
-- (Normal 15-43 mg/dL, Optimal 21-39 mg/dL). This lets clicking a
-- "Urea"-labelled row on the dashboard land on /biomarker/urea
-- instead of /biomarker/bun for users with pre-PR data.
--
-- Rows whose name contains "BUN" or "Blood Urea Nitrogen" are left
-- alone — the old pipeline stored those without scaling.
update public.biomarker_values
set
  biomarker_key = 'urea',
  value = value * 2.14358,
  optimal_low = 21,
  optimal_high = 39,
  normal_low = 15,
  normal_high = 43,
  category = 'kidneys',
  zone = case
    when value * 2.14358 < 15 then 'critical_low'
    when value * 2.14358 < 21 then 'below_optimal'
    when value * 2.14358 <= 39 then 'optimal'
    when value * 2.14358 <= 43 then 'above_optimal'
    else 'critical_high'
  end
where biomarker_key = 'bun'
  and biomarker_name ilike '%urea%'
  and biomarker_name not ilike '%bun%'
  and biomarker_name not ilike '%blood urea nitrogen%';
