-- ============================================================================
-- Security hardening: SECURITY DEFINER exposure, mutable search_path, and an
-- over-permissive email_subscribers INSERT policy.
--
-- Closes:
--   SEC-004  handle_new_user() is executable by anon/authenticated as a
--            SECURITY DEFINER function via /rest/v1/rpc/handle_new_user.
--   SEC-005  Mutable search_path on handle_new_user() and
--            set_ai_prompts_updated_at(), plus an always-true ("Anyone can
--            subscribe") INSERT policy on public.email_subscribers.
--
-- Idempotent and safe to re-run. Trigger execution does NOT require role
-- EXECUTE, so revoking it does not break signup or the updated_at bump.
--
-- NOTE (gated, not SQL): SEC-005 also requires enabling Supabase Auth
-- "leaked password protection" (HaveIBeenPwned check). That is an Auth
-- configuration setting, tracked separately on the Wave 2 gated-infra
-- checklist — it cannot be set from a migration.
-- ============================================================================

-- SEC-004 — a trigger function never needs EXECUTE granted to the API roles;
-- it is only reachable as an RPC because EXECUTE was left to PUBLIC. Revoke it.
revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- SEC-005 — pin search_path so a SECURITY DEFINER function cannot be hijacked
-- by objects planted in an earlier schema on the path. Applied to both flagged
-- functions.
alter function public.handle_new_user() set search_path = public, pg_temp;
alter function public.set_ai_prompts_updated_at() set search_path = public, pg_temp;

-- SEC-005 — replace the always-true INSERT policy with a shape-constrained one.
-- Anon can still subscribe via the public form, but only with a syntactically
-- valid, length-bounded email (no arbitrary rows). Volume abuse is handled
-- separately by app-layer rate limiting (SEC-002).
drop policy if exists "Anyone can subscribe" on public.email_subscribers;
create policy "Anyone can subscribe with a valid email"
  on public.email_subscribers
  for insert
  with check (
    email is not null
    and char_length(email) <= 254
    and email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'
  );
