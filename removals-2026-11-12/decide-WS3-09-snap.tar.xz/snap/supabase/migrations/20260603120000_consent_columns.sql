-- ============================================================================
-- Add consent / legal-acceptance columns to profiles
--
-- Closes the non-gated parts of T2.6:
--   GDPR-003  Recorded, withdrawable consent for special-category health data
--             (Art. 9 GDPR) — Terms of Service + Privacy Policy acceptance.
--   GDPR-013  Consent must be demonstrably recorded (Art. 7(1) GDPR) — we now
--             persist the timestamp at which each acceptance was given.
--   LEG-007   Commercial-email / marketing opt-in (LSSI-CE Art. 21) — explicit,
--             separate, optional consent with a recorded timestamp; withdrawable
--             from the profile page.
--   LEG-008   18+ age confirmation at signup (Terms require 18+).
--
-- All columns are added idempotently (`add column if not exists`) so this
-- migration is safe to re-run. The signup flow writes these on a BEST-EFFORT
-- basis, so a deploy that lands before this migration cannot break account
-- creation — the columns simply stay null until the migration runs.
--
-- Email verification (GDPR-006) is intentionally NOT addressed here: it is
-- gated on a Supabase Auth project setting (enable email confirmations), not
-- on application code, and remains the one outstanding T2.6 item.
-- ============================================================================

alter table public.profiles
  add column if not exists terms_accepted_at timestamptz,
  add column if not exists privacy_accepted_at timestamptz,
  add column if not exists age_confirmed_at timestamptz,
  add column if not exists marketing_opt_in boolean not null default false,
  add column if not exists marketing_opt_in_at timestamptz;

comment on column public.profiles.terms_accepted_at is 'Timestamp the user accepted the Terms of Service at signup (GDPR-013 recorded consent; LEG). Null = not yet recorded.';
comment on column public.profiles.privacy_accepted_at is 'Timestamp the user accepted the Privacy Policy / Art. 9 special-category health-data processing at signup (GDPR-003/013). Null = not yet recorded.';
comment on column public.profiles.age_confirmed_at is 'Timestamp the user confirmed they are 18 or older at signup (LEG-008). Null = not yet confirmed.';
comment on column public.profiles.marketing_opt_in is 'Whether the user has opted in to commercial / marketing email (LSSI-CE Art. 21, LEG-007). Defaults false (no opt-in). Toggled from the profile page.';
comment on column public.profiles.marketing_opt_in_at is 'Timestamp of the most recent marketing opt-in/out change (LEG-007). Set whenever marketing_opt_in changes; supports demonstrable consent + withdrawal records.';
