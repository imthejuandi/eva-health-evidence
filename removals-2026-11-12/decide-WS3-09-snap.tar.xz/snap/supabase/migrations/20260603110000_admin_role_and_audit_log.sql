-- ============================================================================
-- Admin authorization model + audit trail (SEC-003, non-gated parts)
--
-- Closes the non-gated parts of SEC-003: admin status was decided purely by a
-- plaintext ADMIN_EMAILS env string match, duplicated across four call sites,
-- with no role in the database and no record of what admins did.
--
-- This migration introduces:
--   1. profiles.is_admin  — the authoritative, DB-backed admin flag. The shared
--      requireAdmin() helper treats a row with is_admin = true as admin.
--      ADMIN_EMAILS stays only as a bootstrap seed (so the first admins can sign
--      in before any row is flagged) — see src/lib/auth/require-admin.ts.
--   2. public.admin_audit_log  — an append-only record of every admin mutation
--      (actor, target, action, detail, timestamp), written via the service-role
--      client by logAdminAction().
--
-- Access model for admin_audit_log: RLS is enabled with NO policies. This denies
-- every anon and authenticated request by default — identical posture to
-- public.ai_prompts. Only the service-role key (used server-side via
-- createAdminClient) can read or write the log, so it cannot be read, forged or
-- tampered with from the browser. Writes are append-only by convention (the app
-- only ever INSERTs); no UPDATE/DELETE path is exposed.
--
-- Idempotent and safe to re-run.
--
-- NOTE (gated, NOT in this migration): SEC-003 also calls for enforcing MFA on
-- admin accounts (Supabase Auth AAL2 / supabase.auth.mfa) and checking the
-- assurance level in requireAdmin(). That is gated via Supabase Auth and is
-- intentionally NOT built here — it remains the one outstanding piece of SEC-003.
-- ============================================================================

-- 1. Authoritative admin flag on profiles. Defaults false so existing rows are
--    non-admin; flip to true in Studio (or via a seeded migration) to grant.
alter table public.profiles
  add column if not exists is_admin boolean not null default false;

comment on column public.profiles.is_admin is
  'Authoritative admin flag checked by requireAdmin(). ADMIN_EMAILS is only a bootstrap seed; this column is the live gate.';

-- 2. Append-only audit log of admin mutations. Service-role only (see header).
create table if not exists public.admin_audit_log (
  id uuid not null default gen_random_uuid() primary key,
  actor_id uuid,
  actor_email text,
  action text not null,
  target_user_id uuid,
  target_id text,
  detail jsonb,
  created_at timestamptz not null default now()
);

comment on table public.admin_audit_log is
  'Append-only audit trail of privileged admin mutations (SEC-003). Written by logAdminAction() via the service-role client. RLS enabled with NO policies = deny all to anon + authenticated; service role bypasses RLS. Never exposed to the browser.';
comment on column public.admin_audit_log.actor_id is 'auth.users id of the admin who performed the action.';
comment on column public.admin_audit_log.actor_email is 'Email of the acting admin at the time of the action (denormalized for audit readability).';
comment on column public.admin_audit_log.action is 'Stable action identifier, e.g. enter_results, reprocess, update_booking.';
comment on column public.admin_audit_log.target_user_id is 'The user the action acted upon, when applicable.';
comment on column public.admin_audit_log.target_id is 'Free-form identifier of the affected resource (lab_result id, booking id, etc.).';
comment on column public.admin_audit_log.detail is 'Optional structured context for the action (e.g. the new booking status).';

-- Common lookup: most recent actions, optionally scoped to one actor.
create index if not exists admin_audit_log_created_at_idx
  on public.admin_audit_log (created_at desc);
create index if not exists admin_audit_log_actor_id_idx
  on public.admin_audit_log (actor_id);

-- RLS on, no policies = deny all to anon + authenticated. Service role bypasses RLS.
alter table public.admin_audit_log enable row level security;

-- 3. Prevent privilege escalation via is_admin.
--    The existing "Users can update own profile" policy on public.profiles is
--    column-unrestricted (USING auth.uid() = id, no WITH CHECK), so without this
--    guard an authenticated user could set their OWN is_admin = true and
--    self-elevate to admin (requireAdmin() reads this column). This BEFORE
--    UPDATE trigger blocks ANY change to is_admin coming from the PostgREST API
--    roles (authenticated / anon). Service-role writes (programmatic grants) and
--    direct superuser / Studio access (auth.role() is then null) are allowed, so
--    admins can still be seeded. Same-value writes are unaffected — the guard
--    only fires when is_admin actually changes.
create or replace function public.prevent_is_admin_self_escalation()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  if new.is_admin is distinct from old.is_admin
     and coalesce(auth.role(), '') in ('authenticated', 'anon') then
    raise exception 'is_admin can only be changed by a service-role context';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_prevent_is_admin_self_escalation on public.profiles;
create trigger trg_prevent_is_admin_self_escalation
  before update on public.profiles
  for each row execute function public.prevent_is_admin_self_escalation();
