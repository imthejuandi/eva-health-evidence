-- ============================================================================
-- F8b/F8c/F8d — Las unidades de Echevarne pasan a ser las canónicas de eva,
-- el valor reportado por el laboratorio se conserva junto al canónico, y el
-- mensaje HL7 crudo forma parte del historial del cliente.
--
-- Decisión (Juan, 2026-09-17): «usemos sus medidas» — así lo que envía el
-- laboratorio socio nunca se convierte, y el paciente ve en la app el mismo
-- número que en el PDF de Echevarne. Solo hay dos clases de cambio y ninguna
-- es una conversión real:
--   · etiqueta (misma cifra): TSH mUI/L → µUI/mL; insulina µUI/mL → µU/mL;
--     omega «% de AG totales» → «%»; ratio AA/EPA «ratio» → «índice».
--   · desplazamiento decimal exacto: hematíes ×10⁶ y leucocitos, plaquetas y
--     fórmula absoluta ×10³ → células/µL; albúmina y proteínas totales g/dL →
--     g/L (×10); calcio mg/dL → mg/L (×10); testosterona total ng/dL → ng/mL
--     (÷100).
-- La semilla del repo (supabase/seed-data/*.json) ya está en las nuevas
-- unidades; aquí se alinean las dos tablas que las copian. Idempotente: cada
-- UPDATE exige la unidad antigua, así que una segunda ejecución no toca nada.
-- ============================================================================

-- ── 1. Valor reportado por el laboratorio (F8c) ──────────────────────────────
alter table public.biomarker_values
  add column if not exists reported_value numeric,
  add column if not exists reported_unit text;

comment on column public.biomarker_values.reported_value is
  'The number exactly as the lab printed it, before any rescale or conversion. NULL on rows stored before 2026-09-17.';
comment on column public.biomarker_values.reported_unit is
  'The unit string exactly as the lab printed it. Shown next to the canonical value when the two differ.';

-- Las filas anteriores no tienen dato original: el canónico de entonces es
-- lo mejor que sabemos. Se copia ANTES de reescalar para que quede la cifra
-- que el usuario ya vio.
update public.biomarker_values
   set reported_value = value, reported_unit = unit
 where reported_value is null;

-- ── 2. Reescalado de referencias y valores (F8b) ─────────────────────────────
-- (clave, unidad_en nueva, unidad_es nueva, factor, patrón de la unidad antigua)
create temp table unit_change (
  biomarker_key text primary key,
  unit_en text not null,
  unit_es text not null,
  factor numeric not null,
  old_unit_regex text not null
) on commit drop;

insert into unit_change values
  ('tsh',                       'µIU/mL', 'µUI/mL', 1,       '^m(i?u|ui)/l$'),
  ('insulin_fasting',           'µU/mL',  'µU/mL',  1,       '^(µ|u|μ)(iu|ui)/ml$'),
  ('arachidonic_acid_epa_ratio','index',  'índice', 1,       '^ratio$'),
  ('omega_3_epa',               '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('omega_3_dha',               '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('omega_3_dpa',               '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('omega_3_total',             '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('omega_6_linoleic_acid',     '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('omega_6_arachidonic_acid',  '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('omega_6_total',             '%',      '%',      1,       '^% (of total fa|de ag totales)$'),
  ('red_blood_cell_count',      '/µL',    '/µL',    1000000, '10|^m/|^mill'),
  ('white_blood_cell_count',    '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('platelet_count',            '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('lymphocytes_absolute',      '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('monocytes_absolute',        '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('neutrophils_absolute',      '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('eosinophils_absolute',      '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('basophils_absolute',        '/µL',    '/µL',    1000,    '10|^k/|^mil/'),
  ('albumin',                   'g/L',    'g/L',    10,      '^g/dl$'),
  ('total_protein',             'g/L',    'g/L',    10,      '^g/dl$'),
  ('calcium_serum',             'mg/L',   'mg/L',   10,      '^mg/dl$'),
  ('testosterone_total',        'ng/mL',  'ng/mL',  0.01,    '^ng/dl$');

-- Rangos de referencia (una fila por sexo y grupo de edad).
update public.biomarker_references r
   set unit_en = c.unit_en,
       unit_es = c.unit_es,
       normal_low   = r.normal_low   * c.factor,
       normal_high  = r.normal_high  * c.factor,
       optimal_low  = r.optimal_low  * c.factor,
       optimal_high = r.optimal_high * c.factor
  from unit_change c
 where r.biomarker_key = c.biomarker_key
   and lower(replace(r.unit_en, 'μ', 'µ')) ~ c.old_unit_regex;

-- Valores ya almacenados: la cifra canónica y la copia de rangos que lleva
-- cada fila. `reported_*` no se toca: es lo que dijo el laboratorio.
update public.biomarker_values v
   set unit = c.unit_es,
       value        = v.value        * c.factor,
       normal_low   = v.normal_low   * c.factor,
       normal_high  = v.normal_high  * c.factor,
       optimal_low  = v.optimal_low  * c.factor,
       optimal_high = v.optimal_high * c.factor
  from unit_change c
 where v.biomarker_key = c.biomarker_key
   and lower(replace(coalesce(v.unit, ''), 'μ', 'µ')) ~ c.old_unit_regex;

-- ── 3. Retención del mensaje del laboratorio (F8d) ───────────────────────────
-- Decisión (Juan, 2026-09-17): el HL7 crudo se conserva mientras exista la
-- cuenta, como parte del historial del cliente, para poder revisar cualquier
-- resultado años después. No hay purga a 90 días. Se borra solo con la cuenta
-- (GDPR: profiles → test_cycles → lab_messages, ON DELETE CASCADE).
comment on table public.lab_messages is
  'Archive of ALL HL7 traffic with the lab (OML/ORU/ACK, both directions), deduped by MSH-10. Raw payloads are PHI: deny-all RLS, service-role only. Retention (decided 2026-09-17): kept for the life of the account as part of the customer''s history — no time-based purge; removed only by the GDPR account-deletion cascade.';
