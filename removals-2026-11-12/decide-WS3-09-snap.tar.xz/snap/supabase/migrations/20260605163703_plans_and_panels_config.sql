-- ============================================================================
-- RECUPERADA DE LIVE (reparación OPS-004, paso 1).
-- Esta migración se aplicó a producción fuera del flujo el 2026-06-05
-- (versión live 20260605163703_plans_and_panels_config) y su SQL no estaba en
-- el repo. Reconstruida en solo-lectura desde el catálogo de producción el
-- 2026-08-25 (columnas, constraints y políticas verificadas; ambas tablas
-- tenían 0 filas en el momento de la recuperación — sin datos que migrar).
--
-- Config de planes y paneles servida desde BD (pricing bilingüe ES/EN).
-- Lectura pública (contenido de marketing); escrituras solo service-role.
-- ============================================================================

create table if not exists public.plans (
  key text primary key,
  name_en text not null,
  name_es text not null,
  price_en text not null,
  price_es text not null,
  price_suffix_en text not null,
  price_suffix_es text not null,
  amount_eur numeric not null default 0,
  billing text not null,
  features_en jsonb not null default '[]'::jsonb,
  features_es jsonb not null default '[]'::jsonb,
  sort_order integer not null default 0,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists public.panels (
  id text primary key,
  name text not null,
  name_es text not null,
  icon text not null default '',
  location text not null,
  location_es text not null,
  price text not null,
  price_es text not null,
  description text not null,
  description_es text not null,
  included_in_subscription boolean not null default false,
  biomarker_count integer,
  pricing_mode text,
  addon_price_eur numeric,
  sort_order integer not null default 0,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

alter table public.plans enable row level security;
alter table public.panels enable row level security;

drop policy if exists "Plans are publicly readable" on public.plans;
create policy "Plans are publicly readable"
  on public.plans for select using (true);

drop policy if exists "Panels are publicly readable" on public.panels;
create policy "Panels are publicly readable"
  on public.panels for select using (true);
