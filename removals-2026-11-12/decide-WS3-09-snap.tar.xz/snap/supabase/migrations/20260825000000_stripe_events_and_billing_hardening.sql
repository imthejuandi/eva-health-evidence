-- ============================================================================
-- ⚠️  NO APLICAR EN LIVE hasta reconciliar el drift de migraciones (OPS-004,
--     docs/runbooks/migration-reconcile.md) y validar en staging primero.
--     El código que la consume ya está desplegado en tolerante: sin esta
--     migración simplemente loguea y sigue (sin dedupe / sin welcome).
--
-- Billing/webhook hardening (F1/F2 del plan):
--   1. stripe_events — registro de eventos de Stripe YA PROCESADOS. El webhook
--      comprueba antes de procesar y escribe tras el éxito, de modo que una
--      redelivery at-least-once no duplica kits ni re-dispara emails.
--   2. UNIQUE en profiles.stripe_customer_id — dos perfiles con el mismo
--      customer desincronizaban el entitlement en silencio (.single() fallaba
--      y el evento se saltaba).
--   3. Retirar el INSERT propio de booked_tests — cualquier usuario autenticado
--      podía auto-insertarse kits (incluso panel full) saltándose el gate de
--      suscripción; los kits los crea solo el sistema (service-role).
--   4. profiles.welcome_email_sent_at — claim idempotente del email de
--      bienvenida (POST /api/emails/welcome).
-- ============================================================================

-- 1 ── Registro de eventos Stripe procesados (dedupe de redeliveries)
create table if not exists public.stripe_events (
  id text primary key,            -- Stripe event id (evt_...)
  type text not null,
  processed_at timestamptz not null default now()
);

comment on table public.stripe_events is
  'Stripe webhook events already processed successfully. Insert-after-success; the webhook early-returns when the id is present so at-least-once redeliveries are no-ops.';

-- Solo service-role: RLS activo sin políticas = deny-all para anon/authenticated
-- (mismo patrón que admin_audit_log).
alter table public.stripe_events enable row level security;

-- 2 ── stripe_customer_id único (los NULL no chocan en un unique index parcial)
create unique index if not exists profiles_stripe_customer_id_key
  on public.profiles (stripe_customer_id)
  where stripe_customer_id is not null;

-- 3 ── Los kits solo los crea el sistema. La política de INSERT propio de
-- booked_tests permitía a cualquier usuario autenticado fabricarse kits.
-- (El nombre real lleva espacios — full_schema.sql:206; se dropea también la
-- variante con guiones bajos por si algún entorno la creó así.)
drop policy if exists "Users can insert own booked tests" on public.booked_tests;
drop policy if exists "Users can insert own booked_tests" on public.booked_tests;

-- 4 ── Claim idempotente del email de bienvenida
alter table public.profiles
  add column if not exists welcome_email_sent_at timestamptz;

comment on column public.profiles.welcome_email_sent_at is
  'Set atomically by POST /api/emails/welcome the first time the welcome email is claimed; non-null means already sent (idempotency guard).';
