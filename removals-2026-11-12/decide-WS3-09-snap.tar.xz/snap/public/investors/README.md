# Investor pitch

Two versions of the pitch share `/investors`, served by viewport.

## Routing

```
/investors            ─→  detects window width and replaces the URL
                          ≤ 960px  →  /investors/m/   (mobile-native)
                          ≥ 961px  →  /investors/d/   (desktop deck-stage)
```

The router is `index.html` at this folder's root. It's a tiny stub that
runs synchronously in `<head>` and uses `location.replace()` (no history
entry), so the back button skips past it. Any `?to=<recipient>` query
or `#hash` is forwarded to the chosen version, so per-investor
tracking still works on either.

If a reader has JavaScript disabled they see two clear "Mobile" /
"Desktop" buttons and can pick manually.

## File layout

```
public/investors/
├── index.html          # Viewport-aware redirect stub
├── tracking.js         # Shared analytics — both versions reference it
│                       # via /investors/tracking.js
├── m/                  # Mobile-native rebuild (claude/investors-mobile-native)
│   ├── index.html
│   ├── pitch.css
│   └── pitch.js
└── d/                  # Desktop deck-stage pitch (original)
    ├── index.html
    ├── deck-stage.js
    ├── interactions.js
    └── mobile.css
```

## Direct links

- `https://evahealth.es/investors`     — auto-routes by viewport
- `https://evahealth.es/investors/m/`  — force mobile version
- `https://evahealth.es/investors/d/`  — force desktop version

## Routing in `src/proxy.ts`

The Next.js proxy middleware skips locale routing for any path under
`/investors*`, so `/investors/m/`, `/investors/d/`, and the root stub
all bypass the `/es` and `/en` redirects. Vercel's directory-index
serving resolves `/investors/m/` → `/investors/m/index.html` and
`/investors/d/` → `/investors/d/index.html` automatically.

## Updating either version

- **Mobile**: edit files in `public/investors/m/`. The mobile pitch
  uses absolute `/investors/m/<asset>` paths, so internal references
  must keep that prefix.
- **Desktop**: edit files in `public/investors/d/`. Same rule —
  internal references use `/investors/d/<asset>`.
- **Tracking**: there is one shared `tracking.js` at
  `/investors/tracking.js`. Both versions reference it via that
  absolute path. Don't duplicate.

The `?v=N` query string on every asset reference is a cache-buster.
Bump it whenever an asset's content changes so existing visitors
fetch fresh files.
