/* ============================================================
   EVA Health · Investor Pitch · Mobile-Native
   Scroll choreography, reveals, count-ups, type-in, parallax, TOC.
   ============================================================ */
(function () {
  'use strict';

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ── DOM refs ───────────────────────────────────────────── */
  const progressFill   = document.querySelector('.chrome-progress > i');
  const progressMeter  = document.querySelector('.chrome-progress');
  const chromePill     = document.getElementById('chrome-pill');
  const chromeNumeral  = document.getElementById('chrome-numeral');
  const chromeSlide    = document.getElementById('chrome-slide');
  const chromeTitle    = document.getElementById('chrome-title');
  const tocSheet       = document.getElementById('toc-sheet');
  const tocItems       = Array.from(document.querySelectorAll('.toc-item'));
  const chapters       = Array.from(document.querySelectorAll('.chapter[data-chapter]'));
  const cover          = document.getElementById('cover');
  const parallaxEls    = Array.from(document.querySelectorAll('[data-parallax]'));
  const revealEls      = Array.from(document.querySelectorAll('[data-reveal]'));
  const countEls       = Array.from(document.querySelectorAll('[data-count]'));
  const barEls         = Array.from(document.querySelectorAll('.bar'));
  const glyphEls       = Array.from(document.querySelectorAll('.cover-eva-glyph'));

  /* ── Section identity — tag slide-heads with chapter+slide info ──
     Parses each slide-head's eyebrow text ("§ NN · Title") and stores
     the parts on data-attributes for the chrome pill to pick up.
     Also prepends a chapter Roman numeral mark to the eyebrow so each
     slide reads "I · § NN · Title" instead of just "§ NN · Title". */
  const slideHeads = [];
  document.querySelectorAll('.chapter[data-chapter] .slide-head').forEach(function (head) {
    const ch = head.closest('.chapter');
    if (!ch) return;
    const eyebrow = head.querySelector('.eyebrow');
    if (!eyebrow) return;

    const text = eyebrow.textContent.trim();
    const match = text.match(/§\s*(\d+)\s*[·•]\s*(.+?)$/);
    if (match) {
      head.dataset.slideNum = match[1];
      head.dataset.slideTitle = match[2];
    }
    head.dataset.chapter = ch.dataset.chapter;
    head.dataset.chapterTitle = ch.dataset.chapterTitle;

    // Prepend chapter mark to the eyebrow if not already present
    if (!eyebrow.querySelector('.slide-chapter-mark')) {
      const mark = document.createElement('span');
      mark.className = 'slide-chapter-mark';
      const num = document.createElement('span');
      num.className = 'slide-chapter-num';
      num.textContent = ch.dataset.chapter;
      const div = document.createElement('span');
      div.className = 'slide-chapter-divider';
      div.setAttribute('aria-hidden', 'true');
      div.textContent = '·';
      mark.appendChild(num);
      mark.appendChild(div);
      eyebrow.prepend(mark);
    }

    slideHeads.push(head);
  });

  let scrollMax = 1;
  function recomputeScrollMax() {
    scrollMax = (document.documentElement.scrollHeight - window.innerHeight) || 1;
  }

  /* ── 1. Scroll progress ─────────────────────────────────── */
  function updateProgress() {
    const y = window.scrollY;
    const pct = Math.min(1, Math.max(0, y / scrollMax));
    if (progressFill) progressFill.style.transform = 'scaleX(' + pct + ')';
    if (progressMeter) progressMeter.setAttribute('aria-valuenow', String(Math.round(pct * 100)));
  }

  /* ── 2. Chapter pill — chapter numeral + current slide breadcrumb ── */
  let lastPillKey = '';
  function currentChapterByProbe(probeOffset) {
    const probe = window.scrollY + probeOffset;
    let current = null;
    for (const ch of chapters) {
      if (probe >= ch.offsetTop) current = ch;
    }
    return current;
  }
  function currentSlideHeadByProbe(chapter, probeY) {
    if (!chapter) return null;
    let current = null;
    for (const head of slideHeads) {
      if (head.closest('.chapter') !== chapter) continue;
      const top = head.getBoundingClientRect().top + window.scrollY;
      if (top <= probeY) current = head;
    }
    return current;
  }

  function updateChapterPill() {
    if (!chromePill || !cover) return;
    // Hide pill while viewing cover
    const coverEnd = cover.offsetTop + cover.offsetHeight - 240;
    if (window.scrollY < coverEnd) {
      chromePill.classList.remove('is-visible');
      lastPillKey = '';
      return;
    }
    chromePill.classList.add('is-visible');

    const probeY = window.scrollY + window.innerHeight * 0.22;
    const ch = currentChapterByProbe(window.innerHeight * 0.22);
    if (!ch) return;
    const head = currentSlideHeadByProbe(ch, probeY);

    // Build pill text — chapter Roman numeral + slide breadcrumb
    let slideText, titleText;
    if (head && head.dataset.slideNum) {
      slideText = '§ ' + head.dataset.slideNum;
      titleText = head.dataset.slideTitle || '';
    } else {
      // On the act-break (no slide-head reached yet) — show chapter title
      slideText = ch.dataset.chapterTitle || '';
      titleText = '';
    }

    const key = ch.id + '|' + slideText + '|' + titleText;
    if (key === lastPillKey) return;
    lastPillKey = key;
    chromeNumeral.textContent = ch.dataset.chapter;
    chromeSlide.textContent   = slideText;
    chromeTitle.textContent   = titleText;
  }

  /* ── 3. Reveal-on-scroll ───────────────────────────────── */
  const revealIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const delay = el.dataset.revealDelay;
      if (delay) el.style.setProperty('--reveal-delay', delay + 'ms');
      el.classList.add('is-revealed');
      revealIO.unobserve(el);
    });
  }, { threshold: 0.18, rootMargin: '0px 0px -6% 0px' });
  revealEls.forEach(function (el) { revealIO.observe(el); });

  /* Bars: fill when their carrying row enters. We watch the bar itself. */
  const barIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-revealed');
      barIO.unobserve(entry.target);
    });
  }, { threshold: 0.4 });
  barEls.forEach(function (el) { barIO.observe(el); });

  /* ── 4. Count-up numbers ───────────────────────────────── */
  function fmt(value, el) {
    const decimals = parseInt(el.dataset.decimals || '0', 10);
    const thousands = el.dataset.thousands === '1';
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    let s = Number(value).toFixed(decimals);
    if (thousands) {
      const parts = s.split('.');
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      s = parts.join('.');
    }
    return prefix + s + suffix;
  }

  function runCountUp(el) {
    if (el.dataset.counted === '1') return;
    el.dataset.counted = '1';
    const target = parseFloat(el.dataset.count);
    if (Number.isNaN(target)) return;
    if (reduced) {
      el.textContent = fmt(target, el);
      return;
    }
    const dur = parseInt(el.dataset.duration || '1100', 10);
    const t0 = performance.now();
    function tick(now) {
      const t = Math.min(1, (now - t0) / dur);
      // expo-out for confident landing
      const e = 1 - Math.pow(1 - t, 5);
      el.textContent = fmt(target * e, el);
      if (t < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  const countIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      runCountUp(entry.target);
      countIO.unobserve(entry.target);
    });
  }, { threshold: 0.55 });
  countEls.forEach(function (el) { countIO.observe(el); });

  /* ── 5. Cover type-in ──────────────────────────────────── */
  function startCoverTypeIn() {
    if (!glyphEls.length) return;
    if (reduced) {
      glyphEls.forEach(function (g) { g.classList.add('is-shown'); });
      return;
    }
    glyphEls.forEach(function (g, i) {
      setTimeout(function () { g.classList.add('is-shown'); }, 240 + i * 240);
    });
  }

  /* ── 6. TOC sheet ──────────────────────────────────────── */
  function openToc() {
    if (!tocSheet) return;
    tocSheet.setAttribute('open', 'true');
    tocSheet.setAttribute('aria-hidden', 'false');
    if (chromePill) chromePill.setAttribute('aria-expanded', 'true');
    document.documentElement.style.overflow = 'hidden';
  }
  function closeToc() {
    if (!tocSheet) return;
    tocSheet.removeAttribute('open');
    tocSheet.setAttribute('aria-hidden', 'true');
    if (chromePill) chromePill.setAttribute('aria-expanded', 'false');
    document.documentElement.style.overflow = '';
  }

  if (chromePill) {
    chromePill.addEventListener('click', function () {
      if (tocSheet.hasAttribute('open')) closeToc();
      else openToc();
    });
  }
  if (tocSheet) {
    tocSheet.addEventListener('click', function (e) {
      if (e.target === tocSheet) closeToc();
    });
  }
  tocItems.forEach(function (item) {
    item.addEventListener('click', function () {
      const id = item.dataset.target;
      closeToc();
      const target = document.getElementById(id);
      if (!target) return;
      // Wait for sheet close transition
      setTimeout(function () {
        target.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' });
      }, 280);
    });
  });

  // Close on Escape
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && tocSheet && tocSheet.hasAttribute('open')) closeToc();
  });

  function updateTocCurrent() {
    const probe = window.scrollY + 200;
    let currentId = 'cover';
    for (const ch of chapters) {
      if (probe >= ch.offsetTop) currentId = ch.id;
    }
    tocItems.forEach(function (it) {
      it.classList.toggle('is-current', it.dataset.target === currentId);
    });
  }

  /* ── 7. Parallax act numerals (subtle) ─────────────────── */
  function updateParallax() {
    if (reduced) return;
    const vh = window.innerHeight;
    parallaxEls.forEach(function (el) {
      const rect = el.getBoundingClientRect();
      const center = rect.top + rect.height / 2;
      const dist = (center - vh / 2) / vh;
      // Cap movement to ±18px so it stays subtle
      const offset = Math.max(-18, Math.min(18, dist * 22));
      el.style.transform = 'translate3d(0,' + offset.toFixed(2) + 'px,0)';
    });
  }

  /* ── Combined scroll handler (rAF-throttled) ───────────── */
  let ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      updateProgress();
      updateChapterPill();
      updateParallax();
      updateTocCurrent();
      ticking = false;
    });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', function () {
    recomputeScrollMax();
    updateProgress();
    updateParallax();
  });

  /* ── Init ──────────────────────────────────────────────── */
  function init() {
    recomputeScrollMax();
    updateProgress();
    updateChapterPill();
    updateParallax();
    updateTocCurrent();
    startCoverTypeIn();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }

  // After fonts settle, recalc scroll bounds (Cormorant load can shift layout)
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(function () {
      recomputeScrollMax();
      updateProgress();
    });
  }

  /* ────────────────────────────────────────────────────────
     v2 visual primitives — flip-number, sticky-scene, orb,
     seismograph, spain, signature, growth curve, moats.
     ──────────────────────────────────────────────────────── */

  /* ── Flip-number ─────────────────────────────────────────
     Markup: <span class="flip" data-flip="1.1" data-decimals="1"
                   data-prefix="€" data-suffix="T"></span>
     JS builds the cells (digit + dot + prefix/suffix) on init.
     On intersect, each cell sets a CSS variable --flip-target
     to translateY(-N em), so the digit "rolls" into place. */
  function buildFlip(el) {
    if (el.dataset.flipBuilt === '1') return;
    el.dataset.flipBuilt = '1';
    const target = String(el.dataset.flip || '0');
    const decimals = parseInt(el.dataset.decimals || '0', 10);
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    // Format target string with decimals applied (no thousands here; flip is for
    // hero numbers, prefer compact form like "12.4" or "80.2").
    const targetNum = parseFloat(target);
    const targetStr = decimals > 0 ? targetNum.toFixed(decimals) : String(Math.round(targetNum));

    el.textContent = '';

    if (prefix) {
      const p = document.createElement('span');
      p.className = 'flip-cell flip-sym';
      p.textContent = prefix;
      el.appendChild(p);
    }

    for (const ch of targetStr) {
      const cell = document.createElement('span');
      if (ch === '.') {
        cell.className = 'flip-cell flip-dot';
        cell.textContent = '.';
      } else if (ch === ',') {
        cell.className = 'flip-cell flip-comma';
        cell.textContent = ',';
      } else {
        cell.className = 'flip-cell flip-num';
        const track = document.createElement('span');
        track.className = 'flip-track';
        // Build 0–9 digit column
        for (let i = 0; i <= 9; i++) {
          const d = document.createElement('span');
          d.className = 'flip-digit';
          d.textContent = String(i);
          track.appendChild(d);
        }
        const digit = parseInt(ch, 10);
        cell.style.setProperty('--flip-target', '-' + digit + 'em');
        cell.appendChild(track);
      }
      el.appendChild(cell);
    }

    if (suffix) {
      const s = document.createElement('span');
      s.className = 'flip-cell flip-sym';
      s.textContent = suffix;
      el.appendChild(s);
    }
  }

  const flipEls = Array.from(document.querySelectorAll('[data-flip]'));
  flipEls.forEach(buildFlip);

  const flipIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      // Stagger digits with a tiny per-cell delay for added rhythm
      const cells = el.querySelectorAll('.flip-cell.flip-num .flip-track');
      cells.forEach(function (track, i) {
        track.style.transitionDelay = (i * 80) + 'ms';
      });
      el.classList.add('is-revealed');
      flipIO.unobserve(el);
    });
  }, { threshold: 0.55 });
  flipEls.forEach(function (el) { flipIO.observe(el); });

  /* ── Orb activation (start breathing on intersect) ─────── */
  const orbEls = Array.from(document.querySelectorAll('.orb'));
  const orbIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) entry.target.classList.add('is-alive');
    });
  }, { threshold: 0.2 });
  orbEls.forEach(function (el) { orbIO.observe(el); });

  /* ── Sticky-scene progress (slide 10 Act II only) ─────── */
  const stickyScenes = Array.from(document.querySelectorAll('.sticky-scene'));

  function updateStickyScenes() {
    if (reduced) {
      stickyScenes.forEach(function (s) { s.style.setProperty('--p', '1'); });
      return;
    }
    const vh = window.innerHeight;
    stickyScenes.forEach(function (s) {
      const rect = s.getBoundingClientRect();
      const parentH = s.offsetHeight;
      const traveled = -rect.top;
      const denom = Math.max(1, parentH - vh);
      const p = Math.min(1, Math.max(0, traveled / denom));
      s.style.setProperty('--p', p.toFixed(4));
    });
  }

  /* ── Slide 06 · tap-driven phone ─────────────────────────
     Tap the phone frame to advance the active step (1 → 5 → wrap).
     The first tap drops the idle pulse + tap hint via data-tapped="1". */
  const flowStage     = document.getElementById('flow-stage');
  const flowFrame     = document.getElementById('flow-phone-frame');
  const flowStepNum   = document.querySelector('[data-flow-step-num]');
  const flowStepTitle = document.querySelector('[data-flow-step-title]');
  const flowStepBody  = document.querySelector('[data-flow-step-body]');
  const FLOW_COPY = [
    { title: 'Order',          body: 'Subscribe at €99/quarter. Kit arrives in days.' },
    { title: 'Collect & Send', body: 'Needle-free at-home device. 500µL. Ten minutes. Picked up straight from your house.' },
    { title: 'Interpret',      body: 'Results scored against optimal ranges. Biological Age computed. Wearable data correlated.' },
    { title: 'Act',            body: 'Personalised action steps. EVA AI on call. Optional doctor consult.' },
    { title: 'Retest',         body: 'Repeat the base panel, swap to a specialty deep-dive, or upgrade to the full lab. You choose.' }
  ];

  function setFlowStep(step) {
    if (!flowStage) return;
    const clamped = Math.min(5, Math.max(1, step));
    flowStage.dataset.step = String(clamped);
    if (flowStepNum)   flowStepNum.textContent   = String(clamped).padStart(2, '0');
    const c = FLOW_COPY[clamped - 1];
    if (flowStepTitle) flowStepTitle.textContent = c.title;
    if (flowStepBody)  flowStepBody.textContent  = c.body;
  }
  function advanceFlowStep() {
    if (!flowStage) return;
    flowStage.dataset.tapped = '1';
    const cur = parseInt(flowStage.dataset.step || '1', 10);
    const next = cur >= 5 ? 1 : cur + 1; // wrap back to step 1 after step 5
    setFlowStep(next);
  }
  if (flowFrame) {
    flowFrame.addEventListener('click', advanceFlowStep);
    flowFrame.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        advanceFlowStep();
      }
    });
  }
  // Hook the sticky-scene update into the rAF scroll loop above.
  // (It would be cleaner to merge, but to avoid touching the existing
  // onScroll closure we add a second light listener.)
  let stickyTicking = false;
  function onStickyScroll() {
    if (stickyTicking) return;
    stickyTicking = true;
    requestAnimationFrame(function () {
      updateStickyScenes();
      stickyTicking = false;
    });
  }
  window.addEventListener('scroll', onStickyScroll, { passive: true });
  window.addEventListener('resize', updateStickyScenes);

  // Initial paint
  updateStickyScenes();

  /* ── Seismograph / spain / curve / sig / moats reveals ── */
  const drawIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-revealed');
        drawIO.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });
  document
    .querySelectorAll('.seismo, .spain, .curve, .sig, .moats-fig')
    .forEach(function (el) { drawIO.observe(el); });

  /* ── Rail-dots — track active card on horizontal scroll-snap rails ─ */
  Array.from(document.querySelectorAll('[data-rail]')).forEach(function (rail) {
    // Find the dots list — assumed to be the immediate next sibling
    let dotsList = rail.nextElementSibling;
    while (dotsList && !dotsList.classList.contains('rail-dots')) {
      dotsList = dotsList.nextElementSibling;
    }
    if (!dotsList) return;
    const dots = Array.from(dotsList.children);
    const cards = Array.from(rail.children).filter(function (c) {
      return c.nodeType === 1; // element
    });
    if (!cards.length || !dots.length) return;

    function setActive(idx) {
      dots.forEach(function (d, i) {
        d.classList.toggle('is-active', i === idx);
      });
    }

    function compute() {
      // Active card = the one whose center is closest to the rail's
      // visible center.
      const railRect = rail.getBoundingClientRect();
      const center = railRect.left + railRect.width / 2;
      let bestIdx = 0;
      let bestDist = Infinity;
      cards.forEach(function (card, i) {
        const r = card.getBoundingClientRect();
        const cardCenter = r.left + r.width / 2;
        const dist = Math.abs(cardCenter - center);
        if (dist < bestDist) {
          bestDist = dist;
          bestIdx = i;
        }
      });
      setActive(bestIdx);
    }

    let railTicking = false;
    rail.addEventListener('scroll', function () {
      if (railTicking) return;
      railTicking = true;
      requestAnimationFrame(function () {
        compute();
        railTicking = false;
      });
    }, { passive: true });

    // Initial paint
    compute();
  });

  /* ── Floating CTA — appears when user reaches Chapter VII ──── */
  const ctaFloat = document.querySelector('.cta-float');
  const chVII = document.getElementById('ch-vii');
  if (ctaFloat && chVII) {
    const ctaIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          ctaFloat.classList.add('is-shown');
        } else {
          // Only hide if scrolling back UP past the chapter
          if (entry.boundingClientRect.top > 0) {
            ctaFloat.classList.remove('is-shown');
          }
        }
      });
    }, { threshold: 0, rootMargin: '0px 0px -50% 0px' });
    ctaIO.observe(chVII);
  }

  /* ── Forecast-compare bars: trigger fill on intersect ─────── */
  const fcbBars = Array.from(document.querySelectorAll('.fcb-bar'));
  if (fcbBars.length) {
    const fcbIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        // Stagger: pessimistic first, normal next, optimistic last
        const parent = entry.target.parentElement;
        const order = ['fcb-pess', 'fcb-norm', 'fcb-opt'].indexOf(parent.classList[1] || parent.classList[0]) ||
                      Array.prototype.indexOf.call(parent.parentElement.children, parent);
        entry.target.style.transitionDelay = (Math.max(0, order) * 200) + 'ms';
        entry.target.classList.add('is-revealed');
        fcbIO.unobserve(entry.target);
      });
    }, { threshold: 0.4 });
    fcbBars.forEach(function (b) { fcbIO.observe(b); });
  }
})();
