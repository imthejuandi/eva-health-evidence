/* EVA pitch — interactions layer
 * - Reveal-on-scroll / on-slide-enter for elements with [data-reveal]
 * - Number count-ups for elements with [data-count]
 * - Tap/click to expand source detail on [data-source-detail]
 * - Mobile bottom dock: prev / next / counter / TOC
 * - Clickable TOC overlay (works on desktop and mobile)
 *
 * Designed to coexist with deck-stage.js. On mobile (≤ MOBILE_BP) it sets the
 * `noscale` attribute on <deck-stage> so all sections render at authored size,
 * then mobile.css handles the reflow.
 */
(function () {
  const MOBILE_BP = 960;
  const stage = document.querySelector('deck-stage');
  if (!stage) return;

  const isMobile = () => window.innerWidth <= MOBILE_BP;

  /* ─── 0. Auto-tag content for reveals + count-ups ──
   * We keep the manual data-* annotations on slides 09 & 10 (they have
   * curated source-detail panels). For every other slide we walk the DOM
   * once on load and apply [data-reveal] + parse big numeric displays into
   * data-count animations, so dynamism is uniform across the deck without
   * touching the markup.
   */
  function autoTagSlides() {
    const sections = stage.querySelectorAll(':scope > section');
    sections.forEach((sec) => {
      // Section-level reveal targets: header + every direct top-level grouping
      // We avoid double-tagging anything already authored with data-reveal.
      const candidates = sec.querySelectorAll(
        '.section-head, .cover-grid, .cover-left, .orb-wrap, ' +
        '.problem-grid, .problem-left, .problem-stat, ' +
        '.bm-grid > .bm-card, ' +
        '.sol-wrap, .sol-pillars, .sol-pillar, ' +
        '.pillar-grid > .pillar-card, ' +
        '.flow-wrap, .flow-step, .phone-stage, ' +
        '.pricing-grid, .price-hero, .price-side, ' +
        '.cohort-grid > .cohort-card, ' +
        '.comp-table, .comp-callout, ' +
        '.moat-grid > .moat-card, ' +
        '.now-grid > .now-card, ' +
        '.forecast-table, .forecast-caption, ' +
        '.cred-wrap, .cred-bar-row, .excluded-card, ' +
        '.roadmap-wrap > .phase-card, ' +
        '.founder-grid, .founder-portrait, .founder-grid > div, ' +
        '.ask-wrap > div, .ask-bullet, ' +
        '.contact-wrap > *'
      );
      candidates.forEach((el) => {
        if (!el.hasAttribute('data-reveal')) el.setAttribute('data-reveal', '');
      });

      // Count-up targets: any element with a class that holds the section's
      // hero numeric stat — but ONLY parse numbers that are simple numerics.
      const numericSelectors = [
        '.problem-stat-n',
        '.cred-bar-num',
        '.fc-cell.normal',
        '.fc-cell.value',
        '.price-amount',
        '.full-lab-price',
        '.pillar-num',
        '.phase-marker',
        '.moat-num',
        '.cohort-name',
        '.flow-num',
        '.now-num span:first-child',
      ];
      // Iterate but skip — these are NOT numeric-animatable in a way that's
      // safe across all sections (most contain "01" labels, currency mixes,
      // ranges, etc). Instead, count up on a tighter whitelist:
      // - .problem-stat-n  (€1.1T)
      // - .cred-bar-num    (~2,000)
      // - .price-amount    (€99/qtr)
      // - .full-lab-price  (€299)
      const countTargets = sec.querySelectorAll(
        '.problem-stat-n, .cred-bar-num, .price-amount, .full-lab-price, ' +
        '.fc-cell.normal:not(.head):not(.label), ' +
        '.fc-row:not(.head) .fc-cell.value'
      );
      countTargets.forEach(parseAndTagCount);
    });
  }

  /**
   * Parse an element's textContent into a count-up wrapper if it contains a
   * recognisable numeric. Examples handled:
   *   "€1.1T" → € + count(1.1) + T
   *   "~2,000" → ~ + count(2000) + (commas re-formatted)
   *   "€99/qtr" → € + count(99) + /qtr
   *   "2,952" → count(2952)
   *   "1,978" → count(1978)
   *   "~1,200" → ~ + count(1200)
   *   "Pillar 01" → skipped (label, not stat)
   * If we can't safely parse, we leave it untouched.
   */
  function parseAndTagCount(el) {
    if (el.dataset.countParsed === '1') return;
    if (el.querySelector('[data-count]')) {
      el.dataset.countParsed = '1';
      return;
    }
    // Use innerHTML so we preserve <sup> tags (e.g. €99<sup>/qtr</sup>)
    const html = el.innerHTML.trim();
    // Match: optional prefix (€, $, ~, +, -, ≈), the number, optional suffix
    // before any tag boundary. We capture the number including thousands
    // separators and decimals.
    const m = html.match(/^([€$~+\-≈]*)\s*([0-9][0-9.,]*)\s*(.*)$/s);
    if (!m) return;
    const prefix = m[1];
    const numStr = m[2];
    const suffix = m[3];
    // Clean number: 1,200 → 1200; 1.1 stays 1.1 (decimal point);
    // Heuristic: if it has a comma AND a dot, comma is thousands.
    // If it has only a comma, treat comma as thousands when followed by 3 digits.
    let cleanNum;
    let decimals = 0;
    if (numStr.includes(',') && numStr.includes('.')) {
      cleanNum = parseFloat(numStr.replace(/,/g, ''));
      decimals = (numStr.split('.')[1] || '').length;
    } else if (numStr.includes(',')) {
      // comma as thousands separator
      cleanNum = parseFloat(numStr.replace(/,/g, ''));
      decimals = 0;
    } else if (numStr.includes('.')) {
      cleanNum = parseFloat(numStr);
      decimals = (numStr.split('.')[1] || '').length;
    } else {
      cleanNum = parseInt(numStr, 10);
      decimals = 0;
    }
    if (isNaN(cleanNum)) return;
    // Reformat to match the original formatting (preserve commas)
    const formatted = formatNumber(cleanNum, decimals, numStr.includes(','));
    el.dataset.countParsed = '1';
    el.innerHTML =
      prefix +
      '<span data-count="' + cleanNum + '" data-decimals="' + decimals +
      (numStr.includes(',') ? '" data-thousands="1' : '') +
      '">' + formatted + '</span>' +
      (suffix ? ' ' + suffix : '');
  }

  function formatNumber(n, decimals, withCommas) {
    let s = n.toFixed(decimals);
    if (withCommas) {
      const parts = s.split('.');
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      s = parts.join('.');
    }
    return s;
  }

  /* ─── 1. Mobile mode toggle ──────────────────────── */
  // Inject mobile overrides into deck-stage's shadow DOM.
  // The shadow CSS uses ::slotted(*) { position:absolute; inset:0 } — that
  // beats anything we can write from the light side. So we patch the shadow.
  function injectShadowMobileCSS() {
    if (!stage.shadowRoot) return;
    if (stage.shadowRoot.querySelector('#mobile-shadow-css')) return;
    const s = document.createElement('style');
    s.id = 'mobile-shadow-css';
    s.textContent = `
      @media (max-width: 960px) {
        :host([noscale]) {
          position: static !important;
          inset: auto !important;
          display: block !important;
          width: 100% !important;
          height: auto !important;
          overflow: visible !important;
        }
        :host([noscale]) .canvas {
          width: 100% !important;
          height: auto !important;
          min-height: auto !important;
          background: var(--bone, #fff8f3) !important;
          transform: none !important;
        }
        :host([noscale]) ::slotted(*) {
          position: relative !important;
          inset: auto !important;
          width: 100% !important;
          height: auto !important;
          opacity: 1 !important;
          pointer-events: auto !important;
          visibility: visible !important;
          display: block !important;
        }
        :host([noscale]) .overlay { display: none !important; }
        :host([noscale]) .stage { display: block !important; position: static !important; }
      }
    `;
    stage.shadowRoot.appendChild(s);
  }

  function applyMobileMode() {
    if (isMobile()) {
      stage.setAttribute('noscale', '');
      document.body.classList.add('is-mobile');
      injectShadowMobileCSS();
    } else {
      stage.removeAttribute('noscale');
      document.body.classList.remove('is-mobile');
    }
  }
  // Auto-tag every section for reveals + count-ups, then enable mobile mode.
  autoTagSlides();
  applyMobileMode();
  let _resizeRaf;
  window.addEventListener('resize', () => {
    cancelAnimationFrame(_resizeRaf);
    _resizeRaf = requestAnimationFrame(applyMobileMode);
  });

  /* ─── 2. Reveal-on-enter ─────────────────────────── */
  // Stagger any [data-reveal] descendant when its parent <section> becomes
  // visible (desktop: when stage navigates to it; mobile: IntersectionObserver).
  function revealSection(section) {
    if (!section || section.dataset.revealed === '1') return;
    section.dataset.revealed = '1';
    const targets = section.querySelectorAll('[data-reveal]');
    targets.forEach((el, i) => {
      el.style.setProperty('--reveal-delay', (i * 60) + 'ms');
      el.classList.add('is-revealed');
    });
    // Trigger any count-ups inside
    section.querySelectorAll('[data-count]').forEach(runCountUp);
  }

  // Desktop: hook deck-stage slideIndexChanged. This is the SOLE trigger
  // on desktop — all 19 slides are stacked at inset:0 inside the canvas,
  // so an IntersectionObserver would mark every slide as "intersecting"
  // immediately at load and burn the reveal-once gate before navigation.
  window.addEventListener('message', (e) => {
    if (e.data && typeof e.data.slideIndexChanged === 'number') {
      const sections = stage.querySelectorAll(':scope > section');
      const sec = sections[e.data.slideIndexChanged];
      revealSection(sec);
    }
  });
  // Initial slide reveal (covers the case where deck-stage doesn't broadcast
  // an init slideIndexChanged before our listener attaches).
  setTimeout(() => {
    const sections = stage.querySelectorAll(':scope > section');
    // Find the section currently flagged active by deck-stage.
    let active = sections[0];
    sections.forEach(s => {
      if (s.hasAttribute('data-deck-active')) active = s;
    });
    if (active) revealSection(active);
  }, 80);

  // Mobile: IntersectionObserver for sections — only meaningful when the
  // canvas is in vertical flow (noscale on body.is-mobile). Guarded so it
  // doesn't fire on desktop where all sections share the same viewport box.
  const io = new IntersectionObserver((entries) => {
    if (!document.body.classList.contains('is-mobile')) return;
    entries.forEach(entry => {
      if (entry.isIntersecting) revealSection(entry.target);
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });
  // Defer attaching the observer until mobile mode actually engages —
  // observing in desktop mode is harmless thanks to the guard above, but
  // we still want sections to enter unrevealed so the IO can animate them
  // when the user scrolls. We attach immediately; the guard handles desktop.
  stage.querySelectorAll(':scope > section').forEach(s => io.observe(s));

  /* ─── 3. Number count-ups ───────────────────────── */
  function runCountUp(el) {
    if (el.dataset.counted === '1') return;
    el.dataset.counted = '1';
    const target = parseFloat(el.dataset.count);
    if (isNaN(target)) return;
    const decimals = (el.dataset.decimals != null) ? parseInt(el.dataset.decimals, 10) : 0;
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    const withCommas = el.dataset.thousands === '1';
    const dur = parseInt(el.dataset.duration, 10) || 1100;
    function fmt(v) {
      let s = v.toFixed(decimals);
      if (withCommas) {
        const parts = s.split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        s = parts.join('.');
      }
      return prefix + s + suffix;
    }
    const startTime = performance.now();
    function tick(now) {
      const t = Math.min(1, (now - startTime) / dur);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = fmt(target * eased);
      if (t < 1) requestAnimationFrame(tick);
      else el.textContent = fmt(target);
    }
    requestAnimationFrame(tick);
  }

  /* ─── 4. Tap-to-expand source detail ─────────────── */
  // Any [data-source-detail] element gets a click handler that toggles
  // its `.is-expanded` class, revealing a child `.source-detail-body`.
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-source-detail]');
    if (!trigger) {
      // Close all if click outside
      document.querySelectorAll('.is-expanded[data-source-detail]').forEach(el => {
        el.classList.remove('is-expanded');
      });
      return;
    }
    e.stopPropagation();
    const wasOpen = trigger.classList.contains('is-expanded');
    document.querySelectorAll('.is-expanded[data-source-detail]').forEach(el => {
      el.classList.remove('is-expanded');
    });
    if (!wasOpen) trigger.classList.add('is-expanded');
  });

  /* ─── 5. Mobile bottom dock + TOC ─────────────────── */
  const dock = document.createElement('div');
  dock.className = 'mobile-dock';
  dock.innerHTML = `
    <button class="md-btn md-prev" aria-label="Previous slide">‹</button>
    <button class="md-counter" aria-label="Open table of contents">
      <span class="md-current">1</span>
      <span class="md-sep">/</span>
      <span class="md-total">1</span>
    </button>
    <button class="md-btn md-next" aria-label="Next slide">›</button>
  `;
  document.body.appendChild(dock);

  const toc = document.createElement('div');
  toc.className = 'mobile-toc';
  toc.innerHTML = `
    <div class="mt-backdrop"></div>
    <div class="mt-panel">
      <div class="mt-head">
        <div class="mt-title">Contents</div>
        <button class="mt-close" aria-label="Close">×</button>
      </div>
      <div class="mt-list"></div>
    </div>
  `;
  document.body.appendChild(toc);

  function buildToc() {
    const list = toc.querySelector('.mt-list');
    list.innerHTML = '';
    const sections = stage.querySelectorAll(':scope > section');
    sections.forEach((sec, i) => {
      const label = sec.getAttribute('data-label') || ('Slide ' + (i + 1));
      const headline = sec.querySelector('.h-headline, .sol-headline, .cover-h1, h1, h2');
      const sub = headline ? headline.textContent.trim().slice(0, 60) : '';
      const item = document.createElement('button');
      item.className = 'mt-item';
      item.dataset.index = i;
      item.innerHTML = `
        <span class="mt-num">${String(i + 1).padStart(2, '0')}</span>
        <span class="mt-text">
          <span class="mt-label">${label.replace(/^\d+\s+/, '')}</span>
          ${sub ? `<span class="mt-sub">${sub}</span>` : ''}
        </span>
      `;
      item.addEventListener('click', () => {
        goTo(i);
        closeToc();
      });
      list.appendChild(item);
    });
    dock.querySelector('.md-total').textContent = sections.length;
  }
  buildToc();

  function goTo(i) {
    const sections = stage.querySelectorAll(':scope > section');
    if (i < 0 || i >= sections.length) return;
    if (isMobile()) {
      const target = sections[i];
      // Use explicit scrollTo with offsetTop — more reliable than
      // scrollIntoView for slotted elements, and avoids the document
      // re-layout side effects scrollIntoView can cause on some browsers.
      const top = target.offsetTop;
      // Account for the bottom dock so the bottom edge isn't covered
      window.scrollTo({ top, behavior: 'smooth' });
      updateCurrent(i);
    } else if (typeof stage.goTo === 'function') {
      stage.goTo(i);
    }
  }

  function updateCurrent(i) {
    dock.querySelector('.md-current').textContent = i + 1;
    toc.querySelectorAll('.mt-item').forEach((item, idx) => {
      item.classList.toggle('is-current', idx === i);
    });
  }

  // Wire dock buttons
  dock.querySelector('.md-prev').addEventListener('click', () => {
    if (isMobile()) {
      const cur = currentMobileIndex();
      goTo(Math.max(0, cur - 1));
    } else if (typeof stage.prev === 'function') stage.prev();
  });
  dock.querySelector('.md-next').addEventListener('click', () => {
    const sections = stage.querySelectorAll(':scope > section');
    if (isMobile()) {
      const cur = currentMobileIndex();
      goTo(Math.min(sections.length - 1, cur + 1));
    } else if (typeof stage.next === 'function') stage.next();
  });
  dock.querySelector('.md-counter').addEventListener('click', openToc);
  toc.querySelector('.mt-close').addEventListener('click', closeToc);
  toc.querySelector('.mt-backdrop').addEventListener('click', closeToc);

  function openToc() { toc.classList.add('is-open'); }
  function closeToc() { toc.classList.remove('is-open'); }

  // Mobile current detection
  function currentMobileIndex() {
    const sections = [...stage.querySelectorAll(':scope > section')];
    const mid = window.innerHeight / 2;
    let best = 0, bestDist = Infinity;
    sections.forEach((sec, i) => {
      const r = sec.getBoundingClientRect();
      const dist = Math.abs((r.top + r.height / 2) - mid);
      if (dist < bestDist) { bestDist = dist; best = i; }
    });
    return best;
  }

  // Desktop: track slide changes from deck-stage
  window.addEventListener('message', (e) => {
    if (e.data && typeof e.data.slideIndexChanged === 'number') {
      updateCurrent(e.data.slideIndexChanged);
    }
  });

  // Mobile: track scroll
  let scrollRaf;
  window.addEventListener('scroll', () => {
    if (!isMobile()) return;
    cancelAnimationFrame(scrollRaf);
    scrollRaf = requestAnimationFrame(() => {
      updateCurrent(currentMobileIndex());
    });
  }, { passive: true });

  /* ─── 6. Card lift on hover/tap (handled in CSS) ──── */
  // Just ensure tap-able cards get focus styling
  document.querySelectorAll('[data-source-detail]').forEach(el => {
    if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        el.click();
      }
    });
  });

  /* ─── 7. Open TOC with 'T' key on desktop ─────────── */
  window.addEventListener('keydown', (e) => {
    if (e.key === 't' || e.key === 'T') {
      if (toc.classList.contains('is-open')) closeToc();
      else openToc();
    } else if (e.key === 'Escape') {
      closeToc();
    }
  });
})();
