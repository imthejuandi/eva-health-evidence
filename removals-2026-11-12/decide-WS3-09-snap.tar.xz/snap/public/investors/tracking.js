/**
 * EVA Health Pitch · Investor Tracking Module
 *
 * Fires events into Vercel Web Analytics (and any other analytics on the page):
 *   - Vercel Web Analytics (window.va)         ← PRIMARY
 *   - Google Analytics 4   (gtag)
 *   - Plausible            (plausible)
 *   - Fathom               (fathom.trackEvent)
 *   - Custom DOM event     (window dispatches "eva-track" with detail)
 *
 * Whichever providers exist on the page will receive events; the rest no-op.
 *
 * VERCEL SETUP:
 *   1. In your Vercel project dashboard → Analytics tab → enable Web Analytics.
 *   2. Add this script tag to the <head> of EVA Health Pitch.html (or your site
 *      template) BEFORE tracking.js loads:
 *        <script defer src="/_vercel/insights/script.js"></script>
 *      Vercel injects window.va automatically when the deck is served from a
 *      Vercel deployment with Analytics enabled.
 *   3. Deploy. Custom events appear in the Analytics tab under "Events".
 *   4. Filter by the `recipient` property to see per-investor activity.
 *
 * Usage:
 *   <script src="tracking.js"></script>
 *
 * Per-recipient tracking:
 *   Append ?to=<name> (or ?recipient=<name>) to the deck URL.
 *   The recipient name is attached to every event as `recipient`.
 *
 * Events fired:
 *   - deck_opened           {recipient, slide_total}
 *   - slide_view            {recipient, slide_index, slide_label}
 *   - slide_dwell           {recipient, slide_index, slide_label, dwell_ms}
 *   - deck_completed        {recipient, total_time_ms}                  (reached final slide)
 *   - deck_session_end      {recipient, total_time_ms, last_slide}      (page hidden/unloaded)
 *   - tweaks_opened         {recipient}
 *   - cta_click             {recipient, cta}                            (Request Full Deck / email / etc.)
 */
(function () {
  'use strict';

  // ─── Recipient ────────────────────────────────────────────────
  const params = new URLSearchParams(window.location.search);
  const recipient = params.get('to') || params.get('recipient') || 'anonymous';

  // ─── State ────────────────────────────────────────────────────
  const sessionStart = Date.now();
  let currentSlide = null;
  let currentSlideLabel = null;
  let slideEnterTime = null;
  let totalSlides = 0;
  let reachedEnd = false;
  let lastSlideIndex = 0;

  // ─── Multi-provider event dispatcher ──────────────────────────
  function track(eventName, props = {}) {
    const payload = { recipient, ...props };

    // Vercel Web Analytics — PRIMARY
    // window.va is injected by /_vercel/insights/script.js
    // Vercel only accepts string/number/boolean prop values, so coerce.
    if (typeof window.va === 'function') {
      try {
        const safe = {};
        for (const k in payload) {
          const v = payload[k];
          if (v === null || v === undefined) continue;
          if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') {
            safe[k] = v;
          } else {
            safe[k] = String(v);
          }
        }
        window.va('event', { name: eventName, data: safe });
      } catch (e) {}
    }

    // Google Analytics 4
    if (typeof window.gtag === 'function') {
      try { window.gtag('event', eventName, payload); } catch (e) {}
    }

    // Plausible
    if (typeof window.plausible === 'function') {
      try { window.plausible(eventName, { props: payload }); } catch (e) {}
    }

    // Fathom
    if (window.fathom && typeof window.fathom.trackEvent === 'function') {
      try {
        // Fathom doesn't take props natively — encode key facts in event name
        const tag = props.slide_label ? `${eventName}:${props.slide_label}` : eventName;
        window.fathom.trackEvent(tag);
      } catch (e) {}
    }

    // Custom DOM event — for any other listener you wire up
    try {
      window.dispatchEvent(new CustomEvent('eva-track', {
        detail: { event: eventName, ...payload }
      }));
    } catch (e) {}

    // Console (helpful while testing — remove if noisy)
    if (window.__EVA_TRACK_DEBUG__) {
      console.log('[track]', eventName, payload);
    }
  }

  // ─── Slide change handler ─────────────────────────────────────
  function getSlideLabel(idx) {
    const sections = document.querySelectorAll('deck-stage > section');
    if (idx < 0 || idx >= sections.length) return null;
    return sections[idx].getAttribute('data-label') || `slide-${idx + 1}`;
  }

  function onSlideChange(idx) {
    // Emit dwell for previous slide
    if (currentSlide !== null && slideEnterTime !== null) {
      const dwell = Date.now() - slideEnterTime;
      track('slide_dwell', {
        slide_index: currentSlide,
        slide_label: currentSlideLabel,
        dwell_ms: dwell,
      });
    }

    currentSlide = idx;
    currentSlideLabel = getSlideLabel(idx);
    slideEnterTime = Date.now();
    lastSlideIndex = idx;

    track('slide_view', {
      slide_index: idx,
      slide_label: currentSlideLabel,
    });

    // Detect deck completion (final slide reached, fire once)
    if (!reachedEnd && idx === totalSlides - 1) {
      reachedEnd = true;
      track('deck_completed', {
        total_time_ms: Date.now() - sessionStart,
      });
    }
  }

  // ─── Listen for deck-stage's slideIndexChanged postMessage ────
  window.addEventListener('message', (e) => {
    if (e.data && typeof e.data === 'object' && 'slideIndexChanged' in e.data) {
      onSlideChange(e.data.slideIndexChanged);
    }
  });

  // ─── Init: count slides, fire deck_opened, capture first slide ─
  function init() {
    const sections = document.querySelectorAll('deck-stage > section');
    totalSlides = sections.length;

    track('deck_opened', { slide_total: totalSlides });

    // Initial slide (deck-stage may not post for the first one immediately)
    setTimeout(() => {
      if (currentSlide === null) {
        // Read current slide from URL hash (deck-stage uses #/N)
        const m = window.location.hash.match(/(\d+)/);
        const idx = m ? Math.max(0, parseInt(m[1], 10) - 1) : 0;
        onSlideChange(idx);
      }
    }, 200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // ─── Session end (final dwell + total time) ───────────────────
  function endSession() {
    // Final dwell for current slide
    if (currentSlide !== null && slideEnterTime !== null) {
      track('slide_dwell', {
        slide_index: currentSlide,
        slide_label: currentSlideLabel,
        dwell_ms: Date.now() - slideEnterTime,
      });
    }

    track('deck_session_end', {
      total_time_ms: Date.now() - sessionStart,
      last_slide: lastSlideIndex,
      last_slide_label: getSlideLabel(lastSlideIndex),
    });
  }

  // visibilitychange is more reliable than beforeunload on mobile
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') endSession();
  });
  window.addEventListener('pagehide', endSession);

  // ─── Tweaks panel opened ──────────────────────────────────────
  // The toolbar posts __activate_edit_mode when Tweaks toggle is flipped on
  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === '__activate_edit_mode') {
      track('tweaks_opened');
    }
  });

  // ─── CTA clicks ───────────────────────────────────────────────
  document.addEventListener('click', (e) => {
    const target = e.target;
    if (!target || !target.closest) return;

    // Email link
    const email = target.closest('a[href^="mailto:"]');
    if (email) {
      track('cta_click', { cta: 'email', href: email.getAttribute('href') });
      return;
    }

    // "Request the Full Deck" button (and any other .btn inside the deck)
    const btn = target.closest('.btn, .contact-email, [data-cta]');
    if (btn) {
      const ctaName =
        btn.getAttribute('data-cta') ||
        (btn.textContent || '').trim().slice(0, 60) ||
        'unknown';
      track('cta_click', { cta: ctaName });
    }
  }, true);

  // Expose for debugging
  window.__evaTrack = track;
})();
