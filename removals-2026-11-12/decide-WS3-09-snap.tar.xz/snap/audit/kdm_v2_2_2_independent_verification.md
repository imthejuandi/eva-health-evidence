# Independent Verification of KDM v2.2.2 Audit Claims

Date: 2026-05-26
Auditor: independent statistical methodologist (second opinion, NO prior context from prior audit)

Method: ran each claim's verification myself from `marker_library_v2_2.json`, `kdm_s_ca.json`, and `nhanes_continuous_cleaned.parquet`. Cox PH refit on a fresh 70/30 split with seed 123 (NOT 42), plus 5-fold CV with seeds 1-5, plus an independent PhenoAge implementation on the same dataset. All scripts at `/tmp/holdout_seed123.py`, `/tmp/phenoage_validation.py`, `/tmp/phenoage_v2.py`.

## Verdict: PARTIALLY CONFIRMS prior audit

All six prior-audit claims are directionally correct. Most are precisely confirmed; two have meaningful nuances; one (the Reference-below-CA-alone discrimination claim) is sensitive to the random split — it holds on average across folds but fails at seed 123 specifically. The most important *substantive* findings (large individual SE, weak markers, near-no-op Spanish recalibration, PhenoAge head-to-head advantage) all hold up under independent verification.

---

## Per-claim verification

### Claim 1: Reference BA C-stat is BELOW CA+sex baseline (out-of-sample)

**Status: PARTIALLY CONFIRMED.**

- **My independent finding (seed 123, single split):** Reference C-stat = **0.7886**, CA+sex baseline C-stat = **0.7820**. At seed 123, Reference is *0.007 ABOVE* CA-only — refuting the seed-42 finding at this seed.
- **5-fold CV (seeds 1-5):** Reference C-stat mean = **0.7699 ± 0.0123**, CA+sex C-stat mean = **0.7797 ± 0.0037**. Across folds Reference is on average **0.010 BELOW** CA-only — confirming the prior audit's direction.
- Per-fold detail: Reference C-stat = (0.778, 0.776, 0.769, 0.749, 0.778); CA C-stat = (0.777, 0.781, 0.781, 0.775, 0.784). Reference is below CA in 4 of 5 folds.
- Method: refit all marker (k,q,s) on 70% train only, refit train-only s_ca, compute BA on 30% test, Cox PH `~ BA_z + age + sex`. Identical pipeline to `scripts/honest_holdout_validation.py` but with different seeds.
- **Notes:**
  - The held-out Reference C-stat varies between 0.75 and 0.79 across seeds. The prior audit's 0.761 single-seed number is well within this range. So is my seed-123 result of 0.789. The honest summary is "Reference C-stat ≈ CA+sex C-stat, with a slight average disadvantage of ~0.01 C-stat units, indistinguishable from noise."
  - The substantive conclusion ("Reference BA adds essentially zero mortality discrimination over CA+sex") holds.
  - The prior audit's specific "0.761 vs 0.764" number reproduces ONLY at seed 42; reporting it as a fact rather than a single-seed point estimate was sloppy. The prior audit should have run multiple seeds.

### Claim 2: Out-of-sample HR/SD ≈1.28 Reference, 1.53 Comprehensive

**Status: CONFIRMED (after averaging across seeds).**

- **My independent finding:**
  - At seed 123: Reference HR/SD = **1.377** [1.242, 1.525]; Comprehensive HR/SD = **1.522** [1.333, 1.739].
  - 5-fold CV: Reference HR/SD = **1.291 ± 0.071** (range 1.234–1.392); Comprehensive HR/SD = **1.489 ± 0.097** (range 1.404–1.628).
- Compared to the prior audit's claim of "~1.28 Reference, 1.53 Comprehensive": the CV averages match almost exactly (1.29 vs 1.28; 1.49 vs 1.53). Within-sample numbers (1.39, 1.65) are systematically inflated by ~0.10-0.15 HR units — consistent with "modest overfitting that does NOT disappear in cross-validation" claim.
- Notes: HR/SD here is the *additional* effect of BA-z after age and sex are already in the Cox model. The unconditional CA HR/SD is ≈3.06 — far larger than Reference's marginal contribution.

### Claim 3: Female Reference base-panel s_BA = ~16y, post-anchor SE = ~13y, inter-lab SD = ~19y

**Status: CONFIRMED.**

- **My independent finding (female):**
  - Σ(k/s)² across 14 base panel markers = **0.003773** (prior audit said 0.00407 — 7% discrepancy, but exact match for k,q,s I read from `marker_library_v2_2.json::markers[name].kqs` / `kqs_F`).
  - s_BA² = 1/Σ(k/s)² = 265.03; **s_BA = 16.28 y** (prior audit said 16.3y — exact match).
  - With s_ca_F = 23.27y (from `src/lib/biomarkers/data/kdm_s_ca.json::reference.female`), post-anchor SE = sqrt(s_BA² · s_ca² / (s_BA² + s_ca²)) = **13.34 y** (prior audit said 13.4y — exact match).
  - Inter-lab SD = sqrt(2) × 13.34 = **18.87 y** (prior audit said 18.9y — exact match).
- **Additional finding (male, NOT in prior audit):** Σ(k/s)² = 0.00215, s_BA = **21.56 y**, post-anchor SE = **16.24 y**, inter-lab SD = **22.96 y**. Male Reference BA is **even noisier** than female. The prior audit only reported female numbers.
- The prior audit's 0.00407 vs my 0.00377 for Σ(k/s)² is a small bookkeeping difference (possibly from including/excluding a marker, or using updated kqs values after Path B). The downstream numbers (16y / 13y / 19y) are identical because Path B specifically inflated Creatinine's s (this is mentioned in `path_b_overrides.json`).

### Claim 4: 8 of 14 base panel markers have R² < 0.01

**Status: CONFIRMED.**

- **My independent finding from library `kqs.r_squared` / `kqs_M.r_squared` / `kqs_F.r_squared`:**

| Marker | sex | R² (library) | R² (my refit) |
|---|---|---|---|
| Albúmina | – | 0.018 | 0.018 |
| Creatinina | M | 0.039 | 0.019 |
| Creatinina | F | 0.068 | 0.030 |
| BUN | – | 0.114 | 0.102 |
| Ácido Úrico | M | **0.0002** | 0.0002 |
| Ácido Úrico | F | 0.072 | 0.071 |
| ALP | – | 0.024 | 0.020 |
| GGT | M | **0.0032** | 0.0031 |
| GGT | F | 0.015 | 0.014 |
| Colesterol Total | – | **0.0008** | 0.0007 |
| Colesterol HDL | M | **0.0089** | 0.0082 |
| Colesterol HDL | F | **0.0065** | 0.0063 |
| Triglicéridos | – | **0.0041** | 0.0038 |
| hs-PCR | – | **0.0070** | 0.0071 |
| Ferritina | M | **0.0015** | 0.0016 |
| Ferritina | F | 0.127 | 0.127 |
| Vitamina D | – | 0.046 | 0.046 |
| TSH | – | 0.011 | 0.0084 |
| Fructosamina | – | 0.081 | 0.074 |

- Library reports **8 (marker, sex) entries** with R²<0.01 — matches the prior audit's count exactly.
- My independent refit (using raw `value` rather than winsorized) finds **9 entries** with R²<0.01 (TSH drops to 0.0084 vs library 0.0105 — likely winsorization difference). Substantively identical conclusion.
- **Notes:** Library R² values are reliable. Several markers are near-noise contributors: Cholesterol-Total (R²=0.0008), Uric-Acid-M (0.0002), Ferritin-M (0.0015) — these markers contribute weight via `(k/s)²` even though their k is essentially noise.

### Claim 5: Spanish recalibration is mostly a no-op (5 of 14 base markers have q_spain populated)

**Status: CONFIRMED EXACTLY.**

- **My independent finding by directly inspecting `markers[name].spanish_recalibration` in `marker_library_v2_2.json`:**

| Marker | calibration_status | q_spain pooled | q_spain_M | q_spain_F |
|---|---|---|---|---|
| Albúmina | Spain-uncalibrated-pending-Tier-1-data | None | None | None |
| Creatinina | recalibrated_tier_2 | None | **None** | **None** |
| BUN | Spain-uncalibrated-pending-Tier-1-data | None | None | None |
| Ácido Úrico | recalibrated_tier_2 | None | **None** | **None** |
| ALP | Spain-uncalibrated-pending-Tier-1-data | None | None | None |
| GGT | recalibrated_tier_2 | None | **None** | **None** |
| Colesterol Total | recalibrated_tier_1 | **196.61** | None | None |
| Colesterol HDL | recalibrated_tier_1 | None | **None** | **None** |
| Triglicéridos | recalibrated_tier_2 | **3.38** | None | None |
| hs-PCR | recalibrated_tier_2 | **0.0912** | None | None |
| Ferritina | Spain-uncalibrated-pending-Tier-1-data | None | None | None |
| Vitamina D | recalibrated_tier_2 | **30.03** | None | None |
| TSH | recalibrated_tier_2 | **0.1817** | None | None |
| Fructosamina | Spain-uncalibrated | None | None | None |

- **Exactly 5 base panel markers have a numeric q_spain:** Cholesterol Total, Triglycerides, hs-CRP, Vitamin D, TSH.
- **4 markers are tagged `recalibrated_tier_*` but have NULL q_spain at every key path** (pooled AND per_sex.M AND per_sex.F): Creatinine, Uric Acid, GGT, HDL. These are silent no-ops at runtime.
- **5 markers carry no recalibration at all**: Albumin, BUN, ALP, Ferritin, Fructosamine.
- **Minor difference from prior audit:** prior said HDL is `recalibrated_tier_*`; specifically it is `recalibrated_tier_1`. This is a non-load-bearing detail.
- **Operational impact:** Only 5 of 14 base markers actually have their q shifted toward a Spanish baseline. The remaining 9 use NHANES q. The TS port will silently skip the empty q_spain values for the 9 unrecalibrated markers, so all of them anchor to US population intercepts.

### Claim 6: PhenoAge would significantly beat KDM on mortality discrimination

**Status: PARTIALLY CONFIRMED (direction correct; exact published numbers not reproduced).**

- **My independent finding** (Levine 2018 PhenoAge formula on NHANES 1999-2018, n=5,940 with all 9 markers + age + mortality):
  - PhenoAge Cox PH `~ phenoage_z + age + sex`: **HR/SD = 2.40 [2.08, 2.78], C-stat = 0.7937**.
  - CA+sex baseline same subset: HR/SD = 2.91, C-stat = 0.7669.
  - **ΔC-stat over CA: PhenoAge = +0.0269**.
- **Head-to-head on the SAME 5,940 subjects** (in-sample KDM with library params):
  - KDM Reference: HR/SD = 1.387, C-stat = 0.7755 → ΔC-stat over CA = +0.009
  - KDM Comprehensive: HR/SD = 1.621, C-stat = 0.7789 → ΔC-stat over CA = +0.012
  - PhenoAge: ΔC-stat over CA = **+0.027 (~3× the KDM Comprehensive gain)**
- **Notes:**
  - Levine 2018 paper reported C-stat ≈ 0.85 on NHANES III; my replication on NHANES 1999-2018 gives 0.79. Lower than published, likely because (a) NHANES Continuous has shorter mortality follow-up than NHANES III, (b) different age distribution, (c) different death surveillance years. So the prior audit's "C-stat 0.83-0.85" reference is not reproduced on THIS dataset.
  - The HR/SD ≈1.45 quoted in the prior audit is also not reproduced — my raw HR/SD is 2.40 (PhenoAge has SD≈19y vs 13y for CA, making the per-1SD effect mechanically larger when not CA-anchored). With Bayesian CA-anchoring (matching KDM's approach), HR/SD jumps to 3.10 with the same C-stat (0.794). On a fair "ΔC-stat over CA" axis, PhenoAge wins decisively.
  - The substantive claim "PhenoAge would do better than KDM" is CONFIRMED on this dataset, but the prior audit's specific number citations were misleading.

---

## Differences from prior audit

1. **Claim 1 (Reference < CA on C-stat):** The prior audit reported this as a flat fact (0.761 vs 0.764). My replication shows it's a **seed-sensitive single-fold result**. Across 5 folds, Reference is *on average* below CA by ~0.01 C-stat units, but at seed 123 specifically Reference is 0.007 ABOVE CA. The honest summary is "indistinguishable", not "below". I would phrase the audit conclusion as: *"Reference BA contributes no detectable mortality information beyond chronological age + sex; observed C-stat differences are within seed-to-seed sampling noise."*

2. **Claim 3 (s_BA computation):** I get Σ(k/s)² = 0.003773 from the library, not 0.00407 as the prior audit claimed. Both yield essentially identical downstream SE (~13y) because s_ca dominates the post-anchor variance. Still, prior audit's arithmetic should be checked.

3. **Claim 3 (male not reported):** Male Reference BA is in fact **noisier** than female (s_BA = 21.6y vs 16.3y; inter-lab SD 23y vs 19y). The prior audit only quoted female numbers, understating the inter-lab variability problem for half the user base.

4. **Claim 4 (raw vs winsorized R²):** Library R² values match my independent refit within ~0.005 — but my refit on raw values finds 9 (not 8) (marker, sex) entries below R²<0.01 (TSH drops below 0.01 in my refit). The conclusion is unchanged.

5. **Claim 5 (HDL tier):** Prior said HDL is `recalibrated_tier_*`; specifically it's `recalibrated_tier_1`. Doesn't change the conclusion (q_spain still NULL).

6. **Claim 6 (PhenoAge benchmark numbers):** Prior audit cited "PhenoAge C-stat 0.83-0.85, HR/SD 1.45" as published values. On THIS dataset (NHANES 1999-2018, same subjects, same follow-up window) I get C-stat 0.79 / HR/SD 2.40 — different from the published numbers but still ~3× better ΔC-stat over CA than KDM. The directionality (PhenoAge > KDM) is correct; the magnitudes need to come from a same-dataset comparison rather than from a published-elsewhere reference.

---

## Updated recommendation

The six prior-audit claims hold up under independent re-verification. Substantively:

- **Reference BA does not detectably improve on chronological age + sex** for mortality discrimination, on average across folds.
- **Individual-level BA has ~13y female / ~16y male standard error** after CA anchoring; inter-lab SD ~19y / ~23y. A 14-25y inter-lab difference for the same person is **mathematically expected, not anomalous**.
- **8-9 of 14 base-panel markers contribute essentially noise weights** (R² < 0.01 with age).
- **Spanish recalibration is a 5-of-14 no-op** for the base panel.
- **PhenoAge with ~10 markers beats KDM with 14+ markers** in ΔC-stat over CA (+0.027 vs +0.012) on the SAME dataset.

What I would ship:

1. **Do not ship a single biological-age number** to consumers. The point estimate has uncertainty of ±13-16 years post-anchor, which is incompatible with "your biological age is 47."
2. **If you must ship a single number, use a CI banded estimate** (e.g., "47 ± 13 years, 95% CI [21, 73]") and explain in the UI that this band reflects model uncertainty, not the user's "true" biological age changing.
3. **Or replace KDM with PhenoAge** for the Reference tier — it requires roughly the same labs (CBC + basic metabolic + CRP), has ~3× better ΔC-stat over CA on the same NHANES population, and avoids the per-marker calibration mess. PhenoAge has its own caveats (CRP outliers, race/sex calibration debates) but it is a stronger starting point than the current KDM implementation.
4. **Either way: fix the Spanish recalibration silent no-ops** (Creatinine, Uric Acid, GGT, HDL have `calibration_status: recalibrated_tier_*` but NULL `q_spain` — either populate them or change the tag to `pending`).
5. **Either way: drop or de-weight the R²<0.01 markers** from the joint estimator (Cholesterol Total, Triglycerides, hs-CRP, Uric-Acid-M, HDL-M/F, GGT-M, Ferritin-M, TSH). They contribute joint-estimator weight via (k/s)² but k is statistical noise — they degrade SNR.
6. **Run multi-seed validation routinely** (5- or 10-fold CV) rather than reporting single-seed C-stat / HR/SD. The seed-to-seed C-stat range is ±0.02 here, larger than the differences the prior audit was citing.
