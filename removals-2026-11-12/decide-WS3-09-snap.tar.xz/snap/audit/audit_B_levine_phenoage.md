# Audit B: Levine 2018 PhenoAge vs EVA Health KDM v2.2.2

**Date**: 2026-05-26
**Auditor**: Independent (no prior context inherited from earlier audits)
**Reference standard**: Levine et al. 2018, *Aging*, "An epigenetic biomarker of aging for lifespan and healthspan", supplementary table — PhenoAge formula as published
**Comparison target**: deployed EVA Health KDM v2.2.2 (`src/lib/biomarkers/biological-age-kdm.ts`, with Path B overrides)
**Cohort**: NHANES Continuous 1999–2018 (`nhanes_continuous_cleaned.parquet`, n=32,167 adults)

---

## TL;DR

Levine PhenoAge and EVA Health KDM v2.2.2 do not merely disagree by calibration — they make **statistically and biologically different claims** about the same NHANES subject. (1) Their Pearson r on shared NHANES subjects is 0.79 with Bland–Altman 95% LoA of **[−13.0, +36.2] years** — far beyond clinical noise. (2) PhenoAge dominates v2.2.2 on every mortality metric (HR/SD 2.43 vs 1.51, C-stat 0.800 vs 0.784 on the same 5,676 subjects / 378 deaths). (3) For users with BUN > 15 mg/dL, BUN inflates the v2.2.2 Reference BA by **+6.36 years on average** vs the no-BUN counterfactual, and it inflates it by **+9.75 years for user 7e397cf0** specifically (33.13 with BUN vs 23.38 without). The deployed Reference BA assigns BUN a 37.6% weight share for this user. **Verdict: v2.2.2 over-penalizes for BUN in this user's panel, and PhenoAge is the better-validated choice.**

---

## My PhenoAge implementation

Direct port of Levine 2018 supplementary formula:

```
xb = -19.907 - 0.0336·Alb(g/L) + 0.0095·Crea(umol/L) + 0.1953·Glu(mmol/L)
   + 0.0954·ln(CRP, mg/L) - 0.0120·Lymph(%) + 0.0268·MCV(fL)
   + 0.3306·RDW(%) + 0.00188·ALP(U/L) + 0.0554·WBC(10⁹/L) + 0.0804·Age
M = 1 - exp(-1.51714 · exp(xb) · (exp(0.0076927·Age) - 1) / 0.0076927)
PhenoAge = 141.50225 + ln(-0.00553·ln(1 - M)) / 0.09165
```

**Verification steps**:

1. **Sanity check vs Kwon & Belsky 2021 BioAge R package example**:
   Input: 51-yo, Alb=4.7, Crea=1.17, Glu=77, CRP=0.7, Lymph=27.6, MCV=89.1, RDW=12.5, ALP=46, WBC=4.9 → my result **35.6** (Kwon/Belsky doc references give ~36, consistent).
2. **Healthy 30-yo with low CRP (Alb=4.5, Crea=0.85, Glu=90, CRP=0.5, ...)** → PhenoAge = **9.15**. This is expected: PhenoAge is mortality-anchored, not CA-anchored, so very low values for young/healthy subjects are by design.
3. **NHANES Continuous (1999–2018) mean PhenoAge − CA = −6.84 yrs (SD 8.98, r = 0.909, n = 5,964)**. Pearson r ≈ 0.91 with CA is consistent with the published value; the −6.84 mean offset reflects calibration drift between Levine's training era (NHANES III ~1988–1994) and NHANES Continuous (likely cleaner CRP and ALP assays, healthier sampled population). This is a documented behavior and does not invalidate within-cohort comparisons.

**NHANES marker mapping (Spanish keys ↔ PhenoAge inputs)**:

| PhenoAge input | Spanish key (NHANES) | n with value |
|---|---|---|
| Albumin (g/dL) | Albúmina | 18,634 |
| Creatinine (mg/dL) | Creatinina | 18,632 |
| Glucose (mg/dL) | Glucosa (Ayunas) | 10,788 |
| CRP (mg/L) | PCR de Alta Sensibilidad (hs-PCR) | 15,669 |
| Lymphocyte (%) | Linfocitos | 22,171 |
| MCV (fL) | VCM (Volumen Corpuscular Medio) | 22,208 |
| RDW (%) | ADE (Amplitud de Distribución Eritrocitaria) | 22,208 |
| ALP (U/L) | ALP (Fosfatasa Alcalina) | 18,629 |
| WBC (10⁹/L) | Recuento de Glóbulos Blancos | 22,207 |

**Subjects with all 9 PhenoAge markers + age**: 5,967 (PhenoAge non-null: 5,964; 3 dropped because CRP ≤ 0).

---

## Head-to-head BA comparison (PhenoAge vs v2.2.2 Reference BA)

Subset: NHANES subjects passing BOTH the v2.2.2 gate AND having all 9 PhenoAge markers.
**n = 5,964**

| Metric | Value |
|---|---|
| Mean (Ref_BA − PhenoAge) | **+11.62 yrs** |
| Median (Ref_BA − PhenoAge) | +11.74 yrs |
| SD of difference | 12.55 yrs |
| Pearson r | **0.787** |
| Bland-Altman 95% LoA | **[−12.98, +36.21] yrs** |

**Interpretation**: On the average NHANES adult, v2.2.2 reads ~12 years older than PhenoAge. The LoA span of nearly 50 years means individual disagreements can be enormous. The two models are NOT measuring the same thing and are NOT interchangeable.

**Comparison vs chronological age** (across the FULL NHANES adult population where each estimator passed its own gate):

| Estimator | n | Mean (BA − CA) | SD (BA − CA) | Pearson r with CA |
|---|---|---|---|---|
| PhenoAge | 5,964 | −6.84 | 8.98 | **0.909** |
| v2.2.2 Reference | 18,631 | +2.99 | 14.09 | 0.688 |
| v2.2.2 Comprehensive | 18,631 | +0.97 | 9.28 | 0.822 |

PhenoAge correlates more tightly with CA (r=0.91) than v2.2.2 Reference does (r=0.69). v2.2.2 Comprehensive sits in between.

---

## BUN sensitivity test (v2.2.2 Reference BA: with BUN vs without)

Procedure: For every NHANES subject who passed the gate WITH BUN present, recomputed Reference BA after forcibly dropping BUN. Compared `BA_with_BUN − BA_without_BUN`.

**Full population (n = 18,629)**:

| Quantile | Δ (with − without BUN), yrs |
|---|---|
| p10 | −7.48 |
| p25 | −4.40 |
| p50 | **−1.06** |
| p75 | +2.85 |
| p90 | +6.96 |
| Mean | −0.44 |
| SD | **6.53** |

Net mean effect is small (−0.44 yrs) because BUN is bidirectional — low BUN pulls BA down, high BUN pushes BA up — and population is roughly centered.

**But the SD of 6.53 yrs is enormous**: BUN alone moves the deployed Reference BA by 6–7 years (1σ) in either direction. For a single subject, BUN can swing their reported BA by 10+ years.

**Subjects with BUN > 15 mg/dL (n = 5,175, 28% of NHANES adults)**:

| Metric | Value |
|---|---|
| Mean Δ (with − without BUN) | **+6.36 yrs** |
| SD Δ | 6.73 yrs |

For "high-BUN" subjects who also have PhenoAge available (n = 1,717):

| Metric | Value |
|---|---|
| Mean(Ref_BA_with_BUN − PhenoAge) | +17.63 yrs |
| Mean(Ref_BA_without_BUN − PhenoAge) | +11.86 yrs |
| Pearson r(Ref_BA_with_BUN, PhenoAge) | 0.792 |
| Pearson r(Ref_BA_without_BUN, PhenoAge) | **0.823** |

**Removing BUN from the deployed Reference BA brings it closer to PhenoAge** by ~5.8 yrs on average AND improves correlation with PhenoAge (0.823 > 0.792). BUN is actively making the deployed estimator disagree more with the better-validated reference.

### Why does BUN have such a large per-subject effect in the Reference BA?

Path B (k, q, s) for BUN: **k = 0.1252, q = 7.07, s = 4.96**. The joint-estimator marker weight is `(k/s)² = 6.37×10⁻⁴`. With Reference's 14-marker base panel having a typical total weight of ~0.0017 (for a subject like user 7e397cf0 with 11 markers used), **BUN's share is ~38%**. A single marker contributing nearly 40% of the BA estimate is a fragile design: any individual subject's BUN excursion (dehydration, transient renal stress, high-protein meal, GI bleed) propagates directly into a 5–10 year BA swing.

For comparison, PhenoAge does **not** include BUN — Levine explicitly excluded it after weight selection. The 9 markers PhenoAge uses each carry a calibrated, mortality-justified weight derived from a Cox-model variable-selection step in Levine 2018.

---

## User 7e397cf0 (30-year-old male, creatine 10 g/day)

Biomarker panel as supplied. Creatinine 0.96 used (post-offset for creatine supplementation).

### PhenoAge

User is missing RDW and ALP. Imputed with NHANES adult-male means at age 28–32:
- RDW imputed = **12.81 %** (NHANES 28–32 M mean)
- ALP imputed = **67.25 U/L** (NHANES 28–32 M mean)

```
PhenoAge = 13.00 years
```

For a 30-year-old, this means biological age **17 years younger than chronological age** — a strong "healthy aging" signal. PhenoAge gives this because the user's CRP, glucose, lymphocyte%, MCV, WBC and albumin are all in young-healthy ranges, and the formula is dominated by mortality-risk markers, not by absolute health-vs-CA distance.

### v2.2.2 Reference BA (deployed, with BUN)

| Quantity | Value |
|---|---|
| BA_E (pre-anchor) | 36.20 |
| BA (CA-anchored to 30) | **33.13** |
| Markers used | 11 |

This **matches the user-reported 33.13 exactly**, confirming faithful replication of the deployed code.

### v2.2.2 Reference BA — counterfactual (BUN removed)

| Quantity | Value |
|---|---|
| BA_E (pre-anchor) | 12.94 |
| BA (CA-anchored to 30) | **23.38** |
| Markers used | 10 |

**BUN alone moves this user's Reference BA from 23.38 → 33.13 — a +9.75 year swing.**

### v2.2.2 Comprehensive BA

| Quantity | Value |
|---|---|
| BA_E | 38.29 |
| BA (CA-anchored to 30) | **34.04** |
| Markers used | 31 |

(User-reported Comprehensive was 36.18; my replication is 34.04 — small ~2 yr gap likely from a few markers in their actual panel I didn't enumerate. Within reasonable agreement.)

### Per-marker contribution to Reference BA_E (deployed)

For the 11 markers actually used:

| Marker | Value | q (path B) | k | s | Weight share | Marginal yrs |
|---|---|---|---|---|---|---|
| **BUN** | 16.36 | 7.07 | 0.1252 | 4.961 | **37.6%** | **+28.2** |
| Fructosamina (log) | log(70.4) | 4.08 | — | — | 27.1% | (smaller via log) |
| Vitamin D 25-OH | 25.0 | 30.04 | 0.4412 | 27.05 | 15.7% | −1.8 |
| Albumin | 4.75 | 4.39 | −0.0033 | 0.322 | 6.2% | −6.7 |
| Creatinine (M) | 0.96 | 0.807 | 0.0040 | 0.389 | 6.3% | +2.4 |
| HDL | 37 | 42.89 | 0.0995 | 14.80 | 2.7% | −1.6 |
| hs-CRP (log) | log(1.1) | 0.091 | — | — | 2.3% | small |
| Triglycerides (log) | log(102) | 3.38 | — | — | 1.3% | small |
| Total Cholesterol | 170 | 196.6 | 0.0817 | 41.01 | 0.2% | −0.8 |
| Ferritina (log) | log(177) | 5.18 | — | — | 0.5% | small |
| Uric Acid | 5.8 | 6.11 | −0.0014 | 1.31 | 0.07% | +0.15 |

BUN is the dominant single contributor to this user's BA estimate.

### Summary table for the user

| Estimator | BA |
|---|---|
| **Levine PhenoAge (independent, imputed RDW/ALP)** | **13.00** |
| v2.2.2 Reference (deployed, with BUN) | 33.13 |
| v2.2.2 Reference (without BUN, counterfactual) | 23.38 |
| v2.2.2 Comprehensive (deployed) | 34.04 |
| User's chronological age | 30.00 |

The deployed Reference BA (33.13) is **20 years older** than PhenoAge says (13.0). PhenoAge sees a healthy 30-year-old; v2.2.2 sees a "biologically aging at pace" 30-year-old. The single biggest reason for the gap is BUN, accounting for ~10 yrs of the 20-yr discrepancy.

**Where's the discrepancy coming from in v2.2.2?**

1. **BUN (~38% weight share)**: User's BUN = 16.36 is moderately elevated (NHANES p70 for adults; for a 30-yo male this is on the high end, often due to high-protein diet or training-related dehydration). Path B `k = +0.125 / year` makes BUN aggressively additive when above q ≈ 7.
2. **Fructosamina (27% weight share)**: Derived from HbA1c 5.5 via Cohen 2010 (Fructosamina = 70.4 µmol/L). User's value sits above q ≈ exp(4.08) ≈ 59, so this also pushes BA up.
3. **Vitamin D 25-OH (16% weight share)**: User at 25 ng/mL, q ≈ 30, k positive → small downward pull.
4. **Albumin (6%)**: 4.75 vs q = 4.39 — high albumin, but k is NEGATIVE (k = −0.003) so this pulls BA *down* slightly. Sensible.

PhenoAge does not include BUN, Fructosamine, Vitamin D, HDL, total cholesterol, triglycerides, ferritin, or uric acid — because Levine's variable-selection retained only 9 markers as independently mortality-predictive after Cox regularization. The deployed model fires on many markers whose individual mortality value is weak, then amplifies idiosyncratic variation.

---

## Mortality discrimination head-to-head

Cox PH (predictor + age + sex_M, predictor standardized to per-SD HR) on the **same** NHANES subjects who had both PhenoAge AND v2.2.2 Reference BA AND mortality follow-up.

**n = 5,676 subjects, 378 deaths**.

| Model | HR per SD | 95% CI | C-statistic |
|---|---|---|---|
| **Levine PhenoAge** | **2.425** | [2.088, 2.817] | **0.7999** |
| v2.2.2 Reference | 1.511 | [1.369, 1.669] | 0.7835 |
| v2.2.2 Comprehensive | 1.691 | [1.464, 1.953] | 0.7864 |

PhenoAge wins both metrics:
- HR/SD: 2.43 (PhenoAge) vs 1.51 (v2.2.2 Ref) — PhenoAge captures **1.6× the per-SD mortality signal**.
- C-stat: 0.800 vs 0.784 — PhenoAge has materially stronger discrimination, even with age and sex already in the model.

This is a direct head-to-head on the same subjects. There is no cherry-picking. PhenoAge dominates v2.2.2 on mortality, on subjects where both models have full panel coverage.

The deployed v2.2.2 documentation claims an HR/SD of 1.373 for Reference BA, which is broadly consistent with my 1.511 (different subset; mine drops anyone without full PhenoAge markers, which biases toward healthier middle-aged subjects). The relative ordering (PhenoAge > v2.2.2 in both HR/SD and C-stat) is robust.

---

## Verdict

**Does v2.2.2 over-penalize for BUN?**

**Yes — demonstrably**.

1. For the deployed v2.2.2 Reference BA panel, BUN carries a 37.6% weight share in user 7e397cf0's joint estimate.
2. For NHANES subjects with BUN > 15 (28% of adults), BUN alone shifts their reported Reference BA by **+6.36 years on average** vs the no-BUN counterfactual.
3. For user 7e397cf0 specifically, removing BUN drops his Reference BA from 33.13 to 23.38 — **a 9.75-year swing from a single biomarker**.
4. Removing BUN improves the correlation between v2.2.2 Reference BA and Levine PhenoAge (0.823 vs 0.792 in the high-BUN subset).
5. BUN's biological signal is dominated by hydration status, dietary protein, and transient renal stress. Using it with a per-marker weight this high makes the BA estimator a *protein-and-hydration meter* rather than a mortality-anchored aging proxy.

**Is PhenoAge a better choice?**

**Yes — and the case is clean**.

1. **Mortality discrimination is materially higher**: HR/SD 2.43 vs 1.51, C-stat 0.800 vs 0.784, on the same NHANES subjects.
2. **PhenoAge is mortality-anchored by construction** (Cox-model variable selection at Levine's training step), whereas v2.2.2 KDM is age-anchored by the slope/intercept fit. KDM picks up "biomarkers correlated with age," not "biomarkers that predict death."
3. **PhenoAge correlates more tightly with CA (r=0.91 vs r=0.69 for v2.2.2 Reference)**, giving cleaner directionality.
4. **PhenoAge has 9 carefully selected markers**, each with a known mortality contribution. v2.2.2 Reference uses 14 markers, some of which (BUN, Vitamin D, Fructosamine) carry transient/lifestyle signal that swamps the aging component.
5. **PhenoAge is independently validated** in dozens of follow-up papers (Levine 2018, Liu 2018, Belsky 2020, Kwon 2021, etc.). The deployed v2.2.2 is a bespoke implementation with a single internal NHANES validation.

**Caveats for fair reading**:

- PhenoAge requires RDW and ALP which weren't in the user's panel. Imputation here is reasonable but not free of bias. A real product should require those markers or use a clearly disclosed imputation policy.
- PhenoAge produces very low BAs (13 yrs in this user's case) for young/healthy people. This can confuse consumers who expect "BA ≈ CA when you're healthy." Product communication needs to be careful.
- v2.2.2 Comprehensive (the 31-marker version) is closer to PhenoAge in correlation with CA (r=0.82 vs r=0.69 for Reference). If the deployed system insists on staying with KDM, **promoting Comprehensive over Reference would be an improvement**.

**Concrete recommendation**:

If consumers see a single number on screen and it influences supplement / lifestyle decisions, that number should be Levine PhenoAge, not v2.2.2 Reference. The Reference BA's BUN dependency means a user can change his reported "biological age" by ~10 years by drinking water vs being slightly dehydrated. That is not the signal a consumer health product should emit.

---

### Replication artifacts

- Script: `/tmp/audit_B_phenoage.py` (full implementation, single file)
- Subject-level results: `/Users/jdl/product_reviews/eva-health/audit/audit_B_outputs/subject_level_results.parquet`
- Summary JSON: `/Users/jdl/product_reviews/eva-health/audit/audit_B_outputs/summary.json`
