# Longevity Score & Optimal Ranges — Audit Report (Workstream A)

**Auditor:** Claude (acting as longevity-medicine domain expert)
**Date:** 2026-05-26
**Repo:** `github.com/imthejuandi/eva-health`
**HEAD audited:** `36d06f8 content(biomarkers): plain-language definitions for all 104 biomarkers (#30)`
**Purpose:** confirm the live longevity-score system's optimal ranges and scoring math are coherent with current longevity-medicine evidence before integrating the new mortality-validated KDM v2.2 biological-age model in Workstream B.

---

## Executive summary

The eva-health longevity score is **substantially consensus-aligned** with current longevity-medicine evidence. The scoring engine sits in `src/lib/biomarkers/biological-age.ts` and scores **39 biomarkers** (a curated subset of the 104+ biomarkers that the dashboard surfaces for display). Of those 39, **36 have optimal ranges that match published longevity-medicine consensus** (Attia *Outlive*, Levine PhenoAge 2018, IFM, ESC/EAS 2019/2022, ADA, Endocrine Society, Bryan Johnson Blueprint, Spanish societies). The tier-weight taxonomy (T1=3.0, T2=2.0, T3=1.5, T4=1.0), the 15-marker bonus-eligibility list, and the quadratic penalty curve all stand up to scrutiny.

**No critical conflicts. No deal-breakers. Three minor enhancements recommended (none blocking).**

The KDM v2.2 integration in Workstream B can proceed without optimal-range changes. The longevity score's own ground truth (aspirational optimal targets) is sound; the new KDM module will run in parallel using its own ground truth (population-mean-anchored, mortality-validated). The two coexist by design — see "Key conceptual distinction" in the plan file.

**VERDICT: ✓ GREEN-LIGHT Workstream B.**

---

## What was audited

### A.0 — Repo sync
- Local `/Users/jdl/product_reviews/eva-health/` was 316 commits behind `origin/main` with uncommitted iOS/Capacitor work.
- Preserved iOS/Capacitor work on side branch `iOS-capacitor-wip` (commit `acac3ff`) — recoverable for future.
- Synced main to origin/main HEAD `36d06f8`.
- Mapped current file layout: `audit/file_layout_v2.md`.

### A.1 — Biomarker catalog
Extracted **39 scoring-engine biomarkers** from `buildRegistry()` in `biological-age.ts`. Catalog: `audit/longevity_score_catalog.json`.

Distinct from the 104+ display biomarkers (sourced from `supabase/seed-data/{rangos-biomarcadores-es,biomarker-ranges-en}.json`) — the 104+ are shown to the user with plain-language definitions but only the 39 here feed the scoring math.

### A.2 — Longevity-medicine evidence review
For each of the 39 scoring biomarkers, compared the current optimal range against established longevity-medicine sources (Attia *Outlive*, Levine PhenoAge 2018, IFM, ESC/EAS, ADA, Endocrine Society, Bryan Johnson Blueprint, Spanish societies SEEN/SEA/SEC).

Full marker-by-marker review: `audit/optimal_ranges_review.md`.

### A.3 — Internal consistency
- Tier-weight distribution vs evidence: aligned. T1 = strongest mortality predictors (APOB, glycemic, hs-CRP, eGFR); T2-T4 in defensible descending impact.
- Bonus-eligibility list (15 markers, 7 with deep aspirational targets + 8 bounded): all defensible.
- Penalty curve (quadratic with 1.0 cap): mathematically appropriate, validated via 3-user spot-check.

### A.4 — Sex/age stratification
- Live sex-stratifies 10 markers (ALP, ALT, AST, CREATININE, FERRITIN, GGT, HDL_C, HGB, SHBG, URIC_ACID).
- KDM v2.2 sex-stratifies 19 markers (11 of which are in the live scoring engine).
- 8-marker overlap. Differences are by design: KDM stratifies for *training-data* reasons; live stratifies for *clinical-optimal-range* reasons. No conflict.
- Live age-stratifies 3 markers (EGFR, TESTOSTERONE, ESTRADIOL) — appropriately conservative.

---

## Findings table

| Finding type | Count | Items |
|---|---|---|
| **Consensus-aligned** | 36 / 39 | All T1, most T2, all T4, most T3 |
| **Minor update recommended** (post-merge polish) | 2 / 39 | HGB M upper (17.5 → 16.5 per WHO); URIC_ACID M upper (5.5 → 6.0 per Attia) |
| **Needs JD discussion** (philosophy, not safety) | 1 / 39 | TESTOSTERONE age-graded vs flat optimal_low for older men |
| **Critical conflicts** | 0 | — |
| **Tier weight drift** | 0 | — |
| **Bonus list issues** | 0 | — |
| **Penalty curve issues** | 0 | — |
| **Sex/age stratification conflicts** | 0 | KDM and live systems coexist by design |

### Recommended micro-updates (NOT BLOCKING — can ship as follow-up PR after B/C merge)

1. **HGB M optimal_high: 17.5 → 16.5 g/dL** (WHO 2011 threshold). Low risk, single number change in `buildRegistry()`.
2. **URIC_ACID M optimal_high: 5.5 → 6.0 mg/dL** (Attia consensus). Low risk, single number change.
3. **TESTOSTERONE age-graded vs flat floor — JD decision required**: do we accept "physiologic decline as normal" (current age-graded ladder) or flag low T in older men as treatable (flat optimal_low ≥500 across all male ages)? My recommendation: keep current age-graded approach but add UI annotation "TRT discussion warranted if symptomatic and T<500".

### Future enhancement candidates (deferred, not Workstream A scope)

- **HRT-aware Estradiol scoring** for post-menopausal women on hormone replacement (currently would be falsely "above optimal")
- **NLR re-tier** from T3 → T2 based on recent mortality literature
- **ALBUMIN re-tier** from T2 → T1 based on PhenoAge weighting (cosmetic — already in bonus list)
- **URIC_ACID, FERRITIN** added to bonus-eligibility list (URIC lower-better target; FERRITIN bounded around 40-80)
- **EGFR bonus deep target** of 120 is unreachable for >40yo users — adjust to age-graded deep target or accept it's a no-op for most users

---

## Decision required from JD before Workstream B begins

✅ **One question to answer**: do you accept the GREEN-LIGHT verdict and authorize Workstream B to proceed as planned, with the 3 minor-update items deferred to a post-merge polish PR?

Implicit choices baked into this verdict (please flag if you want any changed):
1. Optimal ranges stay as currently coded — no changes pre-merge.
2. Tier weights stay 3/2/1.5/1 — no rebalancing.
3. Bonus list stays 15 markers — no additions/removals.
4. KDM v2.2 BA replaces the existing penalty-derived BA in `lab_results.biological_age`; longevity-score logic stays untouched in its own module (per plan §B).
5. The 3 minor updates (HGB M, URIC_ACID M, TESTOSTERONE) become a follow-up PR after B/C merge.

If JD agrees: proceed to Workstream B.0 (create feature branch `kdm-v2-2-integration` off `origin/main`).

If JD wants any change: revise this audit and re-issue verdict.

---

## Artifacts

| File | Purpose |
|---|---|
| `audit/file_layout_v2.md` | Current production file layout (post-sync) |
| `audit/longevity_score_catalog.json` | 39 scoring-engine biomarkers with tiers, ranges, bonus flags |
| `audit/optimal_ranges_review.md` | Per-marker evidence review (A.2-A.4) |
| `audit/longevity_score_audit_report.md` | This document — go/no-go verdict |

---

*End of Workstream A. JD review checkpoint here before Workstream B starts.*
