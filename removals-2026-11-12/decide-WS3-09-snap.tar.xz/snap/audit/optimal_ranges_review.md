# Optimal ranges review — longevity-medicine evidence audit

**Auditor:** Claude (acting as longevity-medicine domain expert)
**Date:** 2026-05-26
**Repo HEAD:** `36d06f8`
**Catalog source:** `audit/longevity_score_catalog.json` (39 scoring-engine biomarkers; the broader 166-row dashboard reference table is informational only — not part of scoring math, deferred from this audit)

## Reference sources used

1. **Peter Attia — *Outlive* (2023) + The Drive podcast** — modern longevity-medicine targets, most aggressive published consensus
2. **Levine PhenoAge 2018** — mortality-weighted biomarker selection, validated in NHANES + UK Biobank
3. **Institute for Functional Medicine (IFM)** — functional optimal ranges (tighter than reference ranges)
4. **ESC/EAS 2019 + 2022 dyslipidemia guidelines** — European standard used in Spain
5. **ADA Standards of Care** — glycemic targets
6. **KDIGO 2024** — renal function
7. **Endocrine Society 2024 Vit D + 2018 Testosterone**
8. **Bryan Johnson Blueprint** — aspirational/protocol-level targets (cited where deep-bonus targets are explicit)
9. **Spanish Endocrine/Cardiology societies** (SEEN, SEA, SEC) — used where Spanish-specific guidance differs

## Top 15 mortality-impact markers (A.2.1) — DETAILED REVIEW

### T1.APOB — Apolipoprotein B
- **Current**: `optimal ≤80 mg/dL` (M = F), bonus deep target **40 mg/dL**
- **Consensus**: ESC/EAS 2019: <100 moderate risk, <80 high, <65 very-high; Attia: <60-80; AACE: <70 very-high. Blueprint: <50.
- **Verdict**: **consensus-aligned**. Headline 80 matches ESC/EAS high-risk threshold. Bonus deep target 40 is appropriately aspirational.
- **No change recommended.**

### T1.EGFR — Estimated GFR
- **Current**: age + sex-stratified, optimal_low: 100→65 across 18→70+, critical 60→40, bonus deep target **120**
- **Consensus**: KDIGO 2024: ≥90 normal, 60-89 mildly decreased; age-adjusted optimal accepted.
- **Verdict**: **consensus-aligned**. Age-stratification correctly handles physiologic decline.
- **Note**: bonus deep target 120 is unrealistic for >40yo but doesn't cause harm given the bonus is only awarded when crossed.
- **No change recommended.**

### T1.GLUCOSE — Fasting Glucose
- **Current**: `72-90 mg/dL` (M = F), bonus eligible (bounded)
- **Consensus**: ADA <100 normal; Attia: 70-85 optimal; IFM: 70-85; Levine PhenoAge: even within "normal", lower is better for mortality.
- **Verdict**: **consensus-aligned**. Upper of 90 matches Attia/IFM tight target.
- **No change recommended.**

### T1.HBA1C — Hemoglobin A1c
- **Current**: `4.5-5.4%` (M = F), bonus eligible (bounded)
- **Consensus**: ADA <5.7 normal; Attia: <5.4 optimal; Blueprint: <5.3. Levine PhenoAge: HbA1c is one of the strongest mortality biomarkers — tighter is better.
- **Verdict**: **consensus-aligned**. Upper of 5.4 is appropriately strict.
- **No change recommended.**

### T1.HOMA_IR — Insulin Resistance
- **Current**: `optimal ≤1.0` (M = F), bonus deep target **0.3**
- **Consensus**: Gayoso-Diz 2013 EPIRCE Spanish cohort: <2.6 = no IR; Attia/IFM: <1.0 optimal; Blueprint: <1.0.
- **Verdict**: **consensus-aligned**. <1.0 is the modern longevity target. Deep target 0.3 is Blueprint-aspirational.
- **No change recommended.**

### T1.HSCRP — High-Sensitivity CRP
- **Current**: `optimal ≤1.0 mg/L` (M = F), bonus deep target **0.2 mg/L**
- **Consensus**: AHA: <1 low risk, >3 high; Attia: <1.0, ideally <0.5; Blueprint: <0.5; Levine PhenoAge: hs-CRP weighted heavily.
- **Verdict**: **consensus-aligned**. <1.0 is the AHA low-risk threshold; bonus deep target 0.2 is Blueprint-grade aspirational.
- **No change recommended.**

### T1.INSULIN — Fasting Insulin
- **Current**: `optimal ≤6 µIU/mL` (M = F), bonus deep target **2.0 µIU/mL**
- **Consensus**: IFM: <5-6; Attia: <5-6; Kraft 1975 + Joseph Kraft work: <5 metabolically healthy.
- **Verdict**: **consensus-aligned**. ≤6 is standard longevity target.
- **No change recommended.**

### T1.LDL_C — LDL Cholesterol
- **Current**: `optimal ≤100 mg/dL` (M = F), NOT bonus-eligible
- **Consensus**: ESC/EAS 2019: <100 moderate, <70 high, <55 very high; Attia: <70-80 if Lp(a) elevated or fam hx CVD; <100 general.
- **Verdict**: **consensus-aligned** for general adult target. Note that the rationale for *not* including LDL in the bonus list is sound — APOB already captures atherogenic particle burden, and bonus-eligibility for both would double-reward.
- **No change recommended.**

### T2.ALBUMIN — Serum Albumin
- **Current**: `4.2-5.0 g/dL` (M = F), critical low **3.0**, bonus eligible (bounded)
- **Consensus**: Standard ref 3.5-5.0; Levine PhenoAge: lower albumin = strong mortality signal; longevity-medicine: 4.5+ optimal.
- **Verdict**: **consensus-aligned**.
- **No change recommended.**

### T2.ALT — Alanine Aminotransferase
- **Current**: `M 7-30, F 7-19 U/L` (sex-stratified), bonus eligible (bounded)
- **Consensus**: AGA 2017: <30 M, <19 F (matches exactly). Recent MASH-screening movement pushes to <25 M, <17 F.
- **Verdict**: **consensus-aligned** with AGA. The recent MASH-screening trend toward <25/<17 could be a *future* update but current is defensible.
- **No change recommended.**

### T2.ESTRADIOL — Estradiol (female-anchored, age-stratified)
- **Current**: F: `18-29: 30-120; 30-39: 30-120; 40-49: 20-120; 50-59: 5-40; 60-69: 5-40; 70+: 5-40 pg/mL`. M: null (not scored)
- **Consensus**: Reproductive-age F: 30-120 (varies by cycle phase); post-menopausal F: <40 (or higher if on HRT).
- **Verdict**: **consensus-aligned** for natural-cycle interpretation. ⚠ **Flag**: post-menopausal women on HRT will have estradiol > 40 — current scoring would falsely penalize them as "above optimal". Worth a future enhancement to ask user about HRT and adjust accordingly. Not a blocker for B/C deployment.
- **No change recommended for current scope.** Recommend Phase 2 feature: HRT flag.

### T2.HDL_C — HDL Cholesterol
- **Current**: `M 50-90, F 55-100 mg/dL` (sex-stratified), bonus eligible (bounded)
- **Consensus**: ESC: M >40, F >50 acceptable; >60 protective. The optimal_high cap (M 90 / F 100) correctly accounts for the **J-curve** literature (Voight 2012, Madsen 2017, Krause 2018) — very high HDL associated with increased mortality risk, especially in some populations.
- **Verdict**: **consensus-aligned**. Sex-stratification matches female physiologically-higher HDL.
- **No change recommended.**

### T2.LPA — Lipoprotein(a)
- **Current**: `optimal ≤30 mg/dL` (M = F), critical **75**, bonus deep target **7**
- **Consensus**: ESC/EAS 2022: <30 low, 30-50 moderate, >50 high; Attia: <30 mg/dL or <75 nmol/L (note: units differ — ng/mL × ~2.5 ≈ nmol/L conversion has lab variability).
- **Verdict**: **consensus-aligned**. Bonus deep target 7 is Blueprint-aspirational. Lp(a) is genetic; lifestyle modification is limited — but the score correctly rewards low values.
- **No change recommended.**

### T2.RDW — Red Cell Distribution Width
- **Current**: `11-13%` (M = F), critical_high **16.5**, bonus eligible (bounded)
- **Consensus**: Standard ref 11.5-14.5%; Levine PhenoAge: RDW heavily mortality-weighted; longevity: <13% optimal.
- **Verdict**: **consensus-aligned**. Strict upper of 13% matches longevity-medicine targets.
- **No change recommended.**

### T2.TESTOSTERONE — Total Testosterone (male-anchored, age-stratified)
- **Current**: M only, age-stratified: `18-29: 600-900; 30-39: 550-900; 40-49: 500-850; 50-59: 450-800; 60-69: 400-750; 70+: 350-700 ng/dL`
- **Consensus**: Endocrine Society 2018: T 300-1000 ng/dL adult range; age-related decline accepted but contested. Modern longevity-medicine (Morgentaler 2016, ISSAM): low T in older men is treatable, not the "new normal" — many longevity clinics target 600-900 across all male ages with TRT if needed.
- **Verdict**: **minor-update-recommended**. The age-graded optimal_low ladder (600→350) accepts physiologic decline as "optimal" — this may under-incentivize TRT discussion for older men with T<500. Two options:
  - (a) Keep current age-graded — defensible, conservative
  - (b) Flatten optimal_low to 500-600 across all M ages — aligns with longevity-medicine view that low T in older men should be flagged
- **Recommendation**: Discuss with JD before changing. Current is not "wrong" — it's a deliberate choice between "physiologic norms" and "longevity-aspirational". Leaning toward keeping current with a UI annotation that "TRT may be appropriate if symptomatic".

### T2.TG — Triglycerides
- **Current**: `optimal ≤100 mg/dL` (M = F), critical_high **500**, bonus deep target **50**
- **Consensus**: ATP III: <150 normal; Attia: <80-100 optimal; Blueprint: <80. Levine PhenoAge: TG mortality-associated.
- **Verdict**: **consensus-aligned**. ≤100 is tight but standard longevity target.
- **No change recommended.**

### T2.VITD — 25-OH Vitamin D
- **Current**: `40-60 ng/mL` (M = F), critical_low **10**, bonus eligible (bounded)
- **Consensus**: Endocrine Society 2024: ≥20 sufficient; Holick / Vit D Council: 40-60 optimal; Attia: 40-60; SEEN (Spanish Endo): ≥30.
- **Verdict**: **consensus-aligned**. 40-60 is the longevity-medicine target. **Spanish-context note**: La Rioja cohort mean is ~18 ng/mL — most Spanish users will be "below optimal", which is biologically correct (population deficiency is widespread). This is intentional UX.
- **No change recommended.**

---

## Next 20 markers — Tier 3 + Tier 4 review (A.2.2)

(Combined; the scoring registry has only 22 T3+T4 markers, so A.2.2 + A.2.3 collapse into one section.)

### T3 markers (11)

| Code | Current optimal | Verdict | Source / Note |
|---|---|---|---|
| **WBC** | 4-7 (×10³/µL) | consensus-aligned | Reference 4-11; tight upper reflects chronic-inflammation concern. Attia/IFM: <7. |
| **LYMPH_PCT** | 25-45% | consensus-aligned | Reference 20-40; slightly raised upper reflects immune-function emphasis. |
| **NLR** | 0.8-2.5 | consensus-aligned | Established cutoffs: <2 ideal, >3 elevated. |
| **FERRITIN** | M 40-150, F 30-100 ng/mL | consensus-aligned | Sex-stratified. Attia: 30-150 M, 30-100 F. Upper protects against iron overload. |
| **TSAT** | 20-45% | consensus-aligned | Standard iron-overload screening cutoff is >45%. |
| **TSH** | 0.5-2.5 µIU/mL | consensus-aligned | ATA reference 0.4-4.0; longevity-medicine 0.5-2.5 for QoL + cognition. |
| **SHBG** | M 25-60, F 30-80 nmol/L | consensus-aligned | Reference ranges; bidirectional risk pattern. |
| **URIC_ACID** | M 3-5.5, F 2.5-5 mg/dL | **minor-update-recommended** | Attia: <6.0 M, <5.0 F. Live M upper 5.5 is slightly stricter than Attia. Acceptable. |
| **GGT** | M 9-30, F 6-20 U/L | consensus-aligned | Matches ATP/IFM tight cutoffs. |
| **AST** | M 10-30, F 10-25 U/L | consensus-aligned | Matches longevity-medicine cutoffs. |
| **HGB** | M 14-17.5, F 12.5-15.5 g/dL | **minor-update-recommended** | WHO upper M 16.5 (live has 17.5 — somewhat permissive). Consider M 14-16.5. Source: WHO 2011 Hemoglobin thresholds. |

### T4 markers (11)

| Code | Current optimal | Verdict |
|---|---|---|
| **MCV** | 82-98 fL | consensus-aligned (ref 80-100) |
| **B12** | 500-1000 pg/mL | consensus-aligned (longevity-aspirational; ref ≥200) |
| **FOLATE** | ≥10 ng/mL | consensus-aligned (longevity-aspirational; ref ≥3) |
| **CREATININE** | M 0.7-1.2, F 0.5-1.0 mg/dL | consensus-aligned (standard sex-stratified) |
| **PLT** | 150-300 (×10³/µL) | consensus-aligned (tight upper for clotting-risk) |
| **MAGNESIUM** | 2.0-2.5 mg/dL | consensus-aligned (ref 1.7-2.4; slightly tight) |
| **ZINC** | 80-120 µg/dL | consensus-aligned |
| **FT4** | 1.0-1.5 ng/dL | consensus-aligned |
| **FT3** | 2.5-3.5 pg/mL | consensus-aligned |
| **BILIRUBIN** | 0.3-1.2 mg/dL | consensus-aligned |
| **ALP** | M 40-100, F 35-100 U/L | consensus-aligned (tight upper for bone/liver) |

---

## Summary of A.2 findings

| Verdict | Count | Markers |
|---|---|---|
| consensus-aligned | 36 / 39 | All T1, all T2 (except Testosterone), all T4, 9 of 11 T3 |
| minor-update-recommended | 2 / 39 | URIC_ACID (M upper), HGB (M upper) |
| needs-discussion | 1 / 39 | TESTOSTERONE (age-graded vs flat optimal_low for older men) |
| evidence-gap | 0 / 39 | — |

**Note on Estradiol HRT edge case**: not counted as a marker issue but flagged as a future UX enhancement (HRT-flag handling).

## Recommendations for action before Workstream B starts

1. **HGB M upper**: change `optimal_high` from 17.5 to 16.5 to align with WHO 2011 threshold. Minor adjustment, low risk.
2. **URIC_ACID M upper**: optional — extend `optimal_high` from 5.5 to 6.0 to align with Attia. Minor.
3. **TESTOSTERONE age-graded floor**: defer to JD — current is conservative (accepts physiologic decline) vs aspirational (flat optimal_low at 500-600 across ages). My recommendation: keep current; add UI annotation "TRT discussion warranted if symptomatic and T<500".
4. **Estradiol + HRT**: add to backlog as v1.1 UX enhancement.

None of these block Workstream B integration. The longevity score's existing optimal-range definitions are **substantially consensus-aligned**. The KDM integration in B can proceed without optimal-range changes; the recommended micro-updates above can be a follow-up small PR after B/C merge.

**Verdict for A.5: GREEN-LIGHT Workstream B** with no required changes to optimal ranges. The 2 minor updates and 1 needs-discussion item are nice-to-have post-merge polish.

---

## A.3 — Internal consistency check

### A.3.1 — Tier-weight vs mortality-impact evidence

| Tier | Weight | Markers | Evidence alignment |
|---|---|---|---|
| T1 | 3.0 | APOB, LDL_C, HBA1C, GLUCOSE, INSULIN, HOMA_IR, HSCRP, EGFR | ✓ The strongest mortality predictors per Levine PhenoAge: atherogenic burden (APOB/LDL), glycemic (HbA1c/glucose/insulin/HOMA-IR), inflammation (hs-CRP), renal (eGFR). **Aligned.** |
| T2 | 2.0 | HDL_C, TG, LPA, ALT, RDW, ALBUMIN, VITD, TESTOSTERONE, ESTRADIOL | ✓ Includes ALBUMIN (top PhenoAge predictor), RDW (top PhenoAge), Lp(a) (genetic CV risk), and sex hormones. **Aligned** with one note: ALBUMIN's mortality association is arguably T1-strength; current T2 is defensible but conservative. Not a blocking concern. |
| T3 | 1.5 | WBC, LYMPH_PCT, NLR, FERRITIN, TSAT, TSH, SHBG, URIC_ACID, GGT, AST, HGB | ✓ Mix of CBC differentials, iron panel, thyroid, hormones, additional liver. **Aligned.** Note: NLR has recent strong mortality literature and could justify T2 — worth a future review. |
| T4 | 1.0 | MCV, B12, FOLATE, CREATININE, PLT, MAGNESIUM, ZINC, FT4, FT3, BILIRUBIN, ALP | ✓ Supplementary markers. **Aligned.** CREATININE alone (T4) is acceptable because EGFR (T1) is the primary renal signal — creatinine just feeds eGFR. |

**Verdict: T1/T2/T3/T4 distribution is consensus-aligned.** Two minor optimization opportunities (ALBUMIN → T1?, NLR → T2?) but not blocking.

### A.3.2 — Bonus-eligibility audit

Current bonus list (15 markers): APOB, HBA1C, GLUCOSE, HOMA_IR, HSCRP, EGFR, INSULIN, HDL_C, TG, ALT, RDW, ALBUMIN, VITD, TESTOSTERONE, LPA.

**With explicit deep targets (lower_better / higher_better):**

| Marker | Deep target | Source | Verdict |
|---|---|---|---|
| APOB | <40 mg/dL | Blueprint | aspirational, defensible |
| HSCRP | <0.2 mg/L | Blueprint | aspirational, defensible |
| HOMA_IR | <0.3 | Aspirational | defensible |
| INSULIN | <2 µUI/mL | Aspirational | defensible |
| TG | <50 mg/dL | Blueprint | aspirational, defensible |
| LPA | <7 mg/dL | Blueprint | aspirational, defensible |
| EGFR | >120 | Aspirational | ⚠ unrealistic for >40yo. Doesn't cause harm — bonus is effectively unreachable for that population. Cosmetic only. |

**Bounded bonus (rewards middle of optimal):** HBA1C, GLUCOSE, HDL_C, ALT, RDW, ALBUMIN, VITD, TESTOSTERONE — all consensus-aligned.

**Missing from bonus list (could be added):**
- URIC_ACID — lower UA = better metabolic health. Minor enhancement.
- FERRITIN — 40-80 ng/mL = sweet spot for iron homeostasis. Minor enhancement.

**Over-rewarded:** none identified.

**Verdict: bonus-eligibility list is consensus-aligned.** Two minor enhancement candidates (URIC_ACID, FERRITIN) are nice-to-haves, not blocking.

### A.3.3 — Penalty curve sanity check

Formula: `penalty = min((distance/margin)², 1.0)` where `distance = value − optimal_high` (or `optimal_low − value`); `margin = critical_high − optimal_high` (or `optimal_low − critical_low`).

Worked example for APOB (optimal_high=80, critical_high=160 → margin=80):
- value 100 → distance=20, ratio=0.25, **penalty=0.0625 (mild)**
- value 140 → distance=60, ratio=0.75, **penalty=0.5625 (severe)**
- value 160 → distance=80, ratio=1.0, **penalty=1.0 (max)**
- value >160 → penalty=1.0 capped

**Properties:**
- Quadratic correctly under-penalizes mild deviations and amplifies severe ones
- Cap at 1.0 prevents any single outlier marker from dominating the score
- Symmetric on both sides (optimal_low and optimal_high)

**3-user spot-check (qualitative):**
| User profile | Estimated Longevity Score | Estimated BA |
|---|---|---|
| All values at midpoint of optimal | 95-100 | CA − 5 to −8 |
| All values at population average for age band | 70-80 | ≈ CA (calibration anchor) |
| All values 50% of the way from optimal to critical | 40-55 | CA + 5 to +10 |

**Verdict: penalty curve is appropriately calibrated.** Matches longevity-medicine intuition (gentle for near-optimal, steep for severe).

---

## A.4 — Sex/age stratification audit

### A.4.1 — Sex stratification cross-reference

| System | Sex-stratified markers | Count |
|---|---|---|
| Live longevity score | ALP, ALT, AST, CREATININE, FERRITIN, GGT, HDL_C, HGB, SHBG, URIC_ACID | 10 |
| KDM v2.2 (per spec §6.4) | 19 markers total; of those present in live scoring engine: ALT, CREATININE, ESTRADIOL, FERRITIN, GGT, HDL_C, HGB, SHBG, TESTOSTERONE, TSAT, URIC_ACID | 11 |

**Overlap (sex-stratified in BOTH):** ALT, CREATININE, FERRITIN, GGT, HDL_C, HGB, SHBG, URIC_ACID (8 markers).

**KDM-only stratification** (sex-stratified in KDM but pooled in live):
- **ESTRADIOL** — live treats as sex-anchored (female-only scoring); functionally equivalent to sex-stratification. No conflict.
- **TESTOSTERONE** — same as Estradiol, sex-anchored (male-only). Functionally equivalent.
- **TSAT** — KDM stratifies; live pools. Modest clinical difference; live could be updated post-merge if desired (M usually ~5% higher TSAT). Not blocking.

**Live-only stratification** (sex-stratified in live but pooled in KDM):
- **ALP** — live M/F differs; KDM pools. Different design choices — live reflects clinical optimal ranges (female bone-metabolism context), KDM reflects training data structure. No conflict.
- **AST** — same pattern.

**Verdict: No critical sex-stratification conflict.** The two systems differentiate for different reasons (KDM = statistical training need; live = clinical optimal-range need) and can coexist. The KDM module in Workstream B will use KDM's 19-marker stratification for BA computation; the longevity score keeps its 10-marker stratification.

### A.4.2 — Age stratification audit

Live age-stratified markers (3): EGFR, TESTOSTERONE, ESTRADIOL.

| Marker | Age bands | Verdict |
|---|---|---|
| EGFR | 6 bands (18-29, 30-39, 40-49, 50-59, 60-69, 70+) — accepts physiologic decline | ✓ Correct |
| TESTOSTERONE | M only, 6 bands — accepts age-decline | ✓ Defensible (see A.2 testosterone discussion) |
| ESTRADIOL | F only, 6 bands — reproductive vs post-menopausal | ✓ Correct |

**Markers that arguably could be age-stratified but aren't:**
- FT4/FT3 — age-related changes are modest; not stratifying is fine
- HGB — slight age-related lower-bound shift in elderly; minor

**Verdict: age stratification is appropriately conservative.** Live only stratifies where physiology requires it.

---

## Final summary of A.2 + A.3 + A.4

| Finding type | Count | Items |
|---|---|---|
| Consensus-aligned | 36 / 39 markers | All T1, most T2, all T4, most T3 |
| Minor update recommended | 2 / 39 | HGB M upper (17.5 → 16.5), URIC_ACID M upper (5.5 → 6.0) |
| Needs JD discussion | 1 / 39 | TESTOSTERONE age-graded floor (conservative vs aspirational) |
| Critical conflicts | 0 | — |
| Tier weight drift | 0 | All tiers consensus-aligned |
| Bonus list issues | 0 | All 15 defensible. EGFR deep-target 120 cosmetic only. |
| Penalty curve issues | 0 | Quadratic + cap behaves correctly |
| Sex-stratification conflicts (with KDM) | 0 | Two systems coexist by design |
| Age-stratification gaps | 0 | Conservative, appropriate |

**FINAL VERDICT: GREEN-LIGHT Workstream B integration.** No optimal-range changes are required before deploying KDM. The 3 small items above can be a follow-up polish PR after B/C merge.
