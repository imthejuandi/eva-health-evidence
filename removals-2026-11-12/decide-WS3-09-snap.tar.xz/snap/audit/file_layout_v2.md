# File layout v2 — eva-health (post-sync, origin/main HEAD = 36d06f8)

**Sync timestamp:** 2026-05-26 (after fast-forward from 316 commits behind)
**Audit branch state:** `main` clean, working tree clean. Pre-sync iOS/Capacitor work preserved on side branch `iOS-capacitor-wip` (commit `acac3ff`).
**Current HEAD:** `36d06f8 content(biomarkers): plain-language definitions for all 104 biomarkers (#30)`

## Live biomarker module map

### `src/lib/biomarkers/` — the algorithm engine
| File | Lines | Role |
|---|---|---|
| `biological-age.ts` | 582 | **Main algorithm.** v4.0 penalty engine. Single `calculate(inputs, sex, age) → FullResult` returns BOTH biological age (years) AND longevity score (1-100). Both metrics from the same penalty math. |
| `process-results.ts` | 546 | **Upload orchestration.** Entry: `processLabResults()`. Imports `calculate as calculateBioAge` from biological-age.ts. Writes `lab_results.biological_age`, `lab_results.longevity_score`. |
| `biomarker-engine.test.ts` | — | Existing test file. Target location for KDM validation tests added in B.12. |
| `calculated-metrics.ts` | — | Derived metrics (HOMA-IR, TG/HDL, De Ritis, Omega-3 index, NLR, FAI, Non-HDL). |
| `canonical-units.ts` | — | Unit conversion (used by upload pipeline). |
| `key-aliases.ts` | — | Biomarker name aliases (Spanish ↔ English ↔ short codes). |
| `name-matcher.ts` | — | Fuzzy matching for uploaded biomarker names. |
| `seed-references.ts` | — | DB seeding orchestration — reads from `supabase/seed-data/*.json`. |
| `unit-conversions.ts` | — | Unit conversion tables. |
| `zone-classifier.ts` | — | Zone (optimal / below-optimal / above-optimal / critical) classification. |
| `zone-config.ts` | — | Zone classification config. |
| `date-format.ts` | — | Date formatting utility. |
| `index.ts` | — | Re-export barrel. |

### Constants observed in `biological-age.ts`

- `LS_FLOOR = 1`, `LS_CEILING = 100`
- `BA_FLOOR = 18.0`, `BA_CEILING = 99.0`
- `MAX_MARKER_PENALTY = 1.0`, `PENALTY_STEEPNESS = 2.0`, `BONUS_RATIO = 0.3`
- `MINIMUM_TOTAL_MARKERS = 8`, `MINIMUM_DOMAINS_COVERED = 4`
- `BA_SENSITIVITY = 0.5`
- `TIER_WEIGHTS = { 1: 3.0, 2: 2.0, 3: 1.5, 4: 1.0 }`
- `POPULATION_AVG_PENALTY_RATIO`: 13 age buckets — 18-24, 25-29, 30-34, 35-39, 40-44, 45-49, 50-54, 55-59, 60-64, 65-69, 70-74, 75-79, 80+. **Finer granularity than the older 9-bucket XLSX** seen in prior exploration. The current canonical age taxonomy lives here in code (not in the seed JSON, which uses verbal labels like "All Adults" / "Todos los Adultos").

### Types exported by `biological-age.ts`
- `Tier` (1 | 2 | 3 | 4)
- `Zone` (critical_low | below_optimal | optimal | above_optimal | critical_high)
- `Confidence` (high | moderate | low | insufficient)
- `BiomarkerInput`, `MarkerScore`, `DomainCoverage`, `ValidationResult`, `FullResult`
- `BIOMARKER_TIER` map (biomarker code → Tier)
- `calculate()` function

## Live seed data (production source of truth for reference ranges)

| File | Top-level keys | Marker rows |
|---|---|---|
| `supabase/seed-data/rangos-biomarcadores-es.json` | `rangos_biomarcadores`, `metricas_calculadas`, `guia_esquema_app` | 166 rows (biomarker × sex × age_group tuples) |
| `supabase/seed-data/biomarker-ranges-en.json` | `biomarker_ranges`, `calculated_metrics`, `app_schema_guide` | 166 rows (parity) |

**Per-row schema (ES example, ApoB):**
```
{
  "Categoría": "Corazón",
  "Biomarcador": "Apolipoproteína B (ApoB)",
  "Unidad": "mg/dL",
  "Sexo": "Ambos",                  // Ambos / Hombre / Mujer
  "Grupo_Edad": "Todos los Adultos", // verbal label, NOT the 13-bucket numeric taxonomy used in biological-age.ts
  "Normal_Bajo": 60,
  "Normal_Alto": 130,
  "Óptimo_Bajo": null,
  "Óptimo_Alto": 80,
  "Analizado_2x_Año": "No",
  "Notas_Clínicas": "...",
  "Msg_Crítico_Bajo": null, "Msg_Debajo_Óptimo": null,
  "Msg_Óptimo": "...", "Msg_Sobre_Óptimo": "...", "Msg_Crítico_Alto": "..."
}
```

**166 rows ≠ 104 biomarkers:** the row count expands because sex-stratified or age-stratified markers have multiple rows. The "104 biomarkers" count from PR #30 is the count of distinct biomarker entities; the 166-row table is the cross-product.

`metricas_calculadas` (7 entries) holds the derived metrics (HOMA-IR, TG/HDL, etc.) — these are independent of the 166 biomarker rows.

## Dashboard routes

| Route | Purpose |
|---|---|
| `src/app/[locale]/(dashboard)/dashboard/` | Main dashboard — renders BiologicalAgeOrb + Longevity Score |
| `src/app/[locale]/(dashboard)/biomarker/[key]/` | Per-biomarker detail page |
| `src/app/[locale]/(dashboard)/labs/[id]/context/` | Lab result detail with context |
| `src/app/[locale]/(dashboard)/upload/` | Lab upload page |
| `src/app/[locale]/(dashboard)/profile/` | User profile |
| `src/app/[locale]/(dashboard)/onboarding/` | First-run onboarding |
| `src/app/[locale]/(dashboard)/eva-ai/` | AI chat |
| `src/app/[locale]/(dashboard)/labs/manage/` | Lab management |
| `src/app/[locale]/(dashboard)/book/` | Book test |
| `src/app/[locale]/(admin)/admin/` | Admin |
| `src/app/[locale]/(marketing)/` | Marketing (about, blog, contact, how-it-works, legal/cookies). **No `metodologia` route yet — Workstream D will create it.** |

## Supabase

### Migrations (11 to date, chronological)
- `20260326000000_email_subscribers.sql`
- `20260403000000_full_schema.sql` ← core schema (lab_results, biomarker_values, biomarker_references)
- `20260403100000_chat_messages.sql`
- `20260410000000_add_delete_policies.sql`
- `20260411000000_split_profile_name.sql`
- `20260501000000_add_shipping_address.sql`
- `20260505000000_add_master_interpretation_columns.sql`
- `20260506000000_track_full_panel_purchase.sql`
- `20260513000000_create_ai_prompts_table.sql`
- `20260514000000_add_match_confidence_to_biomarker_values.sql`
- `20260515000000_patient_context.sql`

The B.14 migration (`<date>_kdm_v2_2_integration.sql`) will be the 12th.

## Key call-sites that Workstream B will modify

1. **`src/lib/biomarkers/biological-age.ts`** — split into:
   - `longevity-score.ts` (penalty engine only, drops BA branch)
   - Existing file kept as backward-compat re-export shim
   - New `biological-age-kdm.ts` (KDM joint estimator)
   - New `kdm-adapter.ts` (biomarker code → Spanish-marker-name mapping)

2. **`src/lib/biomarkers/process-results.ts`** line 1 import + the BA-write block:
   ```typescript
   import { calculate as calculateBioAge } from "./biological-age";
   ```
   Will become:
   ```typescript
   import { calculateLongevityScore } from "./longevity-score";
   import { computeReferenceBA, computeComprehensiveBA } from "./biological-age-kdm";
   ```

3. **Dashboard server fetch** at `src/app/[locale]/(dashboard)/dashboard/page.tsx` — adds new fields from `lab_results`.

4. **`BiologicalAgeOrb` component** — add optional `markersUsed` prop.

## Notes for downstream workstreams

- **No `audit/` directory existed prior to this commit.** Created during A.0; files placed here are internal artifacts (not part of the production build). Decide later whether to commit `audit/` to a side branch or gitignore.
- **Existing `biomarker-engine.test.ts` is the target file for KDM validation tests** added in B.12 — keeping all biomarker engine tests co-located.
- **The seed data already separates Spanish and English** properly (`rangos-biomarcadores-es.json` vs `biomarker-ranges-en.json`) — Workstream D's deep methodology can follow this `*.es.md` / `*.en.md` parity convention.

---

**Workstream A.0 complete.** Proceeding to A.1 (catalog 104 biomarkers).
