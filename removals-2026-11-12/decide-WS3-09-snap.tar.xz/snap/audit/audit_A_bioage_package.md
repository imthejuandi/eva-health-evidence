# Audit A: BioAge R Package Style KDM vs EVA Health v2.2.2

Independent statistical audit of EVA Health's v2.2.2 KDM biological-age model
against a reference implementation following Kwon & Belsky 2021's BioAge R
package conventions. Both implementations were run on the same NHANES
1999-2018 continuous-cleaned dataset (n=18,570 with mortality follow-up).

## TL;DR

- **Both estimators are valid.** Across n=18,548 jointly-gated NHANES
  subjects, EVA v2.2.2 Reference vs my BioAge-style implementation have
  Pearson r = 0.716, mean difference = +1.4 y, SD of difference = 16.4 y.
  Both produce HR/SD ≈ 1.33-1.36 and C-stat ≈ 0.78-0.79 for all-cause
  mortality, indistinguishable from each other.
- **BUN carries an unusually large weight in EVA v2.2.2.** Population-wide,
  BUN accounts for **34.3% of the (k/s)² joint-estimator weight** in the
  Reference panel — the single largest marker. Combined with Fructosamine
  (24.0%), these two markers make up **58% of the total weight** in a
  14-marker panel. This is a consequence of NHANES training-data
  idiosyncrasies (BUN R² vs age = 0.10, k = 0.125 mg/dL per year of CA).
- **For the specific user 7e397cf0, BUN inflates Reference BA by +9.75 y.**
  Removing BUN from the joint estimator drops Reference BA from 33.13 → 23.38.
  This is consistent with the population pattern: 25-35y NHANES subjects with
  BUN > 14 mg/dL see a mean +8.6 y BUN effect.
- **My BioAge-style BA for this user is 35.75 y — actually OLDER than EVA's
  33.13 y.** So the deployed v2.2.2 system is NOT inflating BA beyond what a
  standard reference implementation would produce for these biomarkers. The
  +3.13 y Δ from CA reflects the user's genuinely above-average BUN,
  Fructosamine, Triglycerides, and below-average Vitamin D.

## My BioAge implementation

**Reference:** Kwon & Belsky 2021 (Geroscience) — `BioAge` R package implementing the
Klemera-Doubal 2006 joint estimator on the Levine 2013 / 2018 9-marker panel.

**Markers (BioAge canon):** Albumin, Creatinine, Glucose, ln(CRP),
Lymphocyte %, MCV, RDW, ALP, WBC.

**Procedure:**
1. Filter NHANES to subjects with all 9 markers present (complete-case
   training cohort, n=5,943).
2. Fit OLS of marker value (or ln(value) for CRP) on age — **no winsorization**.
3. Use intercept as `q` (predicted value at age 0), slope as `k`, residual
   SD as `s`.
4. Apply Klemera-Doubal joint estimator with CA-anchored shrinkage:

       BA_E = Σᵢ (xᵢ−qᵢ) (kᵢ/sᵢ²)  /  Σᵢ (kᵢ/sᵢ)²
       s_BA² = 1 / Σᵢ (kᵢ/sᵢ)²
       BA   = (BA_E/s_BA² + CA/s_CA²) / (1/s_BA² + 1/s_CA²)

5. `s_CA` estimated as SD(BA_E − CA) on the complete-case cohort = **38.10 y**.

**OLS fits (unwinsorized):**

| Marker | n | k | q (intercept) | s (residual SD) | R² | log |
|---|---:|---:|---:|---:|---:|---|
| Albumin (g/dL) | 5,943 | -0.00207 | 4.282 | 0.331 | 0.007 | No |
| Creatinine (mg/dL) | 5,943 | 0.00392 | 0.674 | 0.343 | 0.023 | No |
| Glucose (mg/dL) | 5,943 | 0.474 | 87.19 | 36.92 | 0.029 | No |
| ln(CRP) | 5,943 | 0.00617 | 0.371 | 1.231 | 0.004 | Yes |
| Lymphocytes (%) | 5,943 | -0.0594 | 34.32 | 8.42 | 0.009 | No |
| MCV (fL) | 5,943 | 0.0727 | 85.44 | 5.96 | 0.026 | No |
| RDW (%) | 5,943 | 0.00893 | 12.86 | 1.30 | 0.008 | No |
| ALP (U/L) | 5,943 | 0.254 | 58.89 | 25.83 | 0.017 | No |
| WBC (×10³/µL) | 5,943 | -0.00595 | 7.06 | 2.03 | 0.001 | No |

Individual marker R² values are all in the 0.001-0.029 range — consistent
with published BioAge fits. KDM combines weak signals; no single marker
explains much variance.

## Head-to-head BA comparison (all NHANES subjects)

**Cohort:** n=18,548 subjects gated by BOTH EVA v2.2.2 (≥8 of 14 base panel
+ Albumin + Creatinine) and my BioAge (≥5 of 9 + Albumin).

**Summary statistics:**

|  | EVA v2.2.2 Reference | EVA v2.2.2 Comprehensive | BioAge-style (my impl) |
|---|---:|---:|---:|
| Mean BA | 51.95 | 51.93 | 50.54 |
| SD BA | 19.29 | 16.24 | 23.26 |
| Mean CA | 51.81 | 51.81 | 51.81 |
| Mean Δ vs BioAge | +1.42 y | +1.39 y | — |
| SD of Δ | 16.45 y | 15.63 y | — |
| Pearson r vs BioAge | 0.716 | 0.742 | — |
| Bland-Altman 95% LoA | [−30.8, +33.7] y | [−29.3, +32.0] y | — |

The two estimators correlate moderately strongly (r ≈ 0.72) but the LoA is
wide (±32 y). This is intrinsic to KDM models with low per-marker R² —
BA_E variance is dominated by which markers each subject has. EVA's BA has
LOWER SD than mine (19 vs 23) because v2.2.2 uses TIGHTER s values (Path B
overrides) than my unwinsorized fit, which makes the CA-anchored shrinkage
pull harder toward CA.

## BUN contribution isolated

**(k/s)² weight by marker in the v2.2.2 Reference panel (males):**

| Marker | k | s | (k/s)² | Weight % | log |
|---|---:|---:|---:|---:|---|
| **BUN** | **0.12516** | **4.961** | **0.000636** | **34.29%** | No |
| **Fructosamine** | **0.00456** | **0.216** | **0.000446** | **24.04%** | Yes |
| Vitamin D | 0.441 | 27.05 | 0.000266 | 14.33% | No |
| ALP | 0.265 | 24.62 | 0.000116 | 6.23% | No |
| Creatinine | 0.00402 | 0.389 | 0.000107 | 5.75% | No |
| Albumin | -0.00326 | 0.322 | 0.000103 | 5.52% | No |
| TSH | 0.00506 | 0.746 | 0.000046 | 2.48% | Yes |
| HDL | 0.0995 | 14.80 | 0.000045 | 2.43% | No |
| hs-CRP | 0.00771 | 1.224 | 0.000040 | 2.14% | Yes |
| Triglycerides | 0.00266 | 0.579 | 0.000021 | 1.14% | Yes |
| GGT | -0.00267 | 0.648 | 0.000017 | 0.92% | Yes |
| Ferritin | -0.00251 | 0.870 | 0.000008 | 0.45% | Yes |
| Total Cholesterol | 0.0817 | 41.01 | 0.000004 | 0.21% | No |
| Uric Acid | -0.00139 | 1.307 | 0.000001 | 0.06% | No |

**BUN alone carries 34.3% of the joint-estimator weight.** This is because
BUN's slope-to-noise ratio (k/s ≈ 0.0252) is unusually large in NHANES.
The age-slope k = 0.125 mg/dL/y is steep (BUN increases ~6 mg/dL over a
50-year span), and BUN's residual SD s ≈ 5 is small relative to that slope.

**Population-wide BUN effect (n=18,570 NHANES subjects):**

| Statistic | Δ_BUN = BA_with − BA_without (years) |
|---|---:|
| Mean | +0.13 |
| SD | 6.54 |
| 1st percentile | −12.74 |
| 5th percentile | −8.73 |
| 25th percentile | −3.87 |
| Median | −0.53 |
| 75th percentile | +3.43 |
| 95th percentile | +10.64 |
| 99th percentile | +19.83 |

The mean is near zero (good — implies no average bias), but the SD is 6.5
years and the tails are wide. A subject 1 SD above the BUN population mean
sees roughly +6.5 y added to BA from BUN alone.

**Stratified by BUN quintile:**

| BUN range (mg/dL) | n | Mean Δ_BUN (y) | SD |
|---|---:|---:|---:|
| 2.0 - 10.0 | 5,104 | −5.62 | 3.40 |
| 10.0 - 12.0 | 3,528 | −2.21 | 2.76 |
| 12.0 - 14.0 | 3,376 | +0.10 | 2.86 |
| 14.0 - 17.0 | 3,454 | +2.84 | 3.17 |
| 17.0 - 98.0 | 3,107 | +9.23 | 7.51 |

A user in the top BUN quintile sees ~+9 y added to BA from BUN alone.

**Among young (25-35 y) NHANES subjects with BUN > 14 mg/dL** (the closest
demographic match to user 7e397cf0): n=520, mean Δ_BUN = **+8.57 y**.

**Mortality validation impact of removing BUN:**

| Configuration | HR/SD | C-stat |
|---|---:|---:|
| v2.2.2 Reference (with BUN) | 1.355 | 0.781 |
| v2.2.2 Reference (no BUN) | **1.519** | 0.785 |

Removing BUN actually *increases* the HR/SD (1.355 → 1.519). This is
because BUN, as 34% of the joint weight, makes BA more "BUN-driven" — but
BUN's own age-adjusted mortality signal (HR per SD = 1.13) is weaker than
Albumin's (HR/SD = 0.72 → 1/0.72 = 1.39 for −1 SD). When BUN dominates the
joint, it crowds out stronger mortality predictors.

Note though that BUN does carry signal: BUN HR per SD adjusted for age+sex
is 1.13 (p < 1e-7), so it's not noise. The issue is **weight allocation**,
not BUN inclusion.

## User 7e397cf0 specifically

| Implementation | BA | BA_E | n_used | Δ vs CA (30) |
|---|---:|---:|---:|---:|
| My BioAge (no Spanish recal) | **35.75** | 42.74 | 7 | +5.75 |
| EVA v2.2.2 Reference (with Spanish recal) | **33.13** ✓ | 36.20 | 11 | +3.13 |
| EVA v2.2.2 Reference (no Spanish recal) | 27.95 | — | 11 | -2.05 |
| EVA v2.2.2 Reference WITHOUT BUN (with Spanish) | **23.38** | 12.94 | 10 | -6.62 |
| EVA v2.2.2 Comprehensive (with Spanish recal) | **34.04** | 38.29 | 31 | +4.04 |

Stated deployed values for parity check:
- Reference 33.13 → I get **33.13** (EXACT MATCH ✓)
- Comprehensive 36.18 → I get **34.04** (Δ −2.14, likely missing RDW or
  another marker that's in the deployed data but not in my user inputs)

**Per-marker BA_E contribution for the v2.2.2 Reference (with Spanish recal):**

| Marker | Value | q (after Spanish) | Weight % | Implied age | BA_E contrib |
|---|---:|---:|---:|---:|---:|
| **BUN** | **16.36** | 7.07 | **37.94%** | **74.2** | **+28.17** |
| Fructosamine (HbA1c-derived) | 70.44 | 4.08 (log) | 26.60% | 39.1 | +10.41 |
| Albumin | 4.75 | 4.39 | 6.11% | −109.5 | −6.69 |
| Triglycerides (Spanish q) | 102 | 3.38 (log) | 1.26% | 467 | +5.89 |
| Creatinine (post creatine offset, 0.96) | 0.96 | 0.81 | 6.37% | 38.1 | +2.43 |
| Vitamin D (Spanish q) | 25 | 30.04 | 15.86% | −11.4 | −1.81 |
| HDL | 37 | 42.88 | 2.69% | −59.2 | −1.59 |
| Total Cholesterol (Spanish q) | 170 | 196.61 | 0.24% | −325.6 | −0.77 |
| Uric Acid | 5.8 | 6.11 | 0.07% | 222.7 | +0.15 |
| hs-CRP (Spanish q) | 1.1 | 0.09 (log) | 2.37% | 0.54 | +0.01 |
| Ferritin | 177 | 5.17 (log) | 0.50% | −0.56 | −0.003 |

**Where the gap comes from (33.13 vs 35.75):**
- My BioAge panel doesn't include BUN or Fructosamine. Without these two
  high-weight markers, MCV (98.8 vs q=85.4, +20 fL above norm) gets to
  dominate, pushing BA_E higher.
- EVA's Reference has Spanish recalibration on hs-CRP, Triglycerides,
  Vitamin D etc. — those lower q values flip some markers from "younger
  signal" to "older signal" (e.g., the user's Triglycerides of 102 now
  reads as elevated vs Spanish q=29.4).
- Albumin: user is 4.75 vs q=4.39 → implied age −109.5 (much younger than
  CA). This is fighting the BUN/Fructosamine signal and dragging BA down.
- **The two implementations actually agree the user is biologically OLDER
  than their CA — they differ by only 2.6 y.**

## Mortality validation comparison

**Cox PH: hazard ~ BA + age + sex. n=17,353-17,368 (subjects with death follow-up).**

| Implementation | HR per SD | 95% CI | C-stat |
|---|---:|---:|---:|
| BioAge-style (my impl) | **1.329** | [1.290, 1.370] | **0.7916** |
| EVA v2.2.2 Reference | 1.355 | [1.293, 1.419] | 0.7806 |
| EVA v2.2.2 Reference WITHOUT BUN | 1.519 | [1.430, 1.613] | 0.7845 |
| EVA v2.2.2 Comprehensive | 1.610 | [1.503, 1.724] | 0.7851 |

- The two **Reference**-style implementations are nearly identical in
  mortality discrimination (HR/SD 1.33 vs 1.36; C-stat 0.79 vs 0.78).
- EVA's stated in-sample HR/SD = 1.39 for Reference and 1.65 for
  Comprehensive — I get 1.36 and 1.61, well within their reported CIs.
- The **Comprehensive** estimator is genuinely more discriminative (HR/SD
  1.61 vs 1.35) — adding more markers helps, even with the BUN weighting
  concern.
- Removing BUN from Reference actually IMPROVES HR/SD (1.355 → 1.519) but
  this reflects the joint-weight reallocation effect described above, not
  that BUN is anti-predictive.

## Verdict

**Is EVA's KDM produce reasonable BAs vs a standard reference? Yes.**
For the specific user, my BioAge implementation puts BA at 35.75 y vs
EVA's 33.13 y — EVA is actually ~2.6 y *more conservative* (closer to CA)
than the BioAge standard. Population-wide, the two are correlated r=0.72
and have nearly identical mortality predictiveness. No evidence EVA is
systematically inflating BA above what a textbook KDM implementation
would produce.

**Is BUN inflating BA more than it should? Yes, structurally —
but the math is technically correct.**
- BUN carries 34% of the joint-estimator weight in v2.2.2's Reference
  panel — disproportionate vs other markers. This is a direct consequence
  of BUN having the highest k/s ratio in the NHANES training fit (large
  age slope, small residual SD).
- For users with above-population BUN (such as 7e397cf0 at 16.36 mg/dL),
  BUN dominates the BA computation. The user's BUN alone contributes
  +28.2 y to BA_E (which shrinks to +9.75 y after CA anchoring). For
  comparison, all other 10 markers combined contribute only +8.0 y to BA_E.
- Importantly: BUN does have a genuine age-adjusted mortality signal
  (HR per SD = 1.13, p < 1e-7), so it's not noise. The issue is that the
  joint-estimator weight far exceeds what BUN's standalone mortality
  predictiveness justifies.
- **Recommendation:** Consider whether BUN's standalone HR per SD (1.13)
  warrants 34% of the joint weight versus, say, Albumin's HR per SD of
  0.72 (much stronger signal) carrying only 5.5% of the weight. A
  weight-by-mortality-signal scheme rather than weight-by-(k/s)² could
  rebalance, but that would be a departure from canonical Klemera-Doubal
  and require recalibration.

**Honest framing for the user.** A 30-year-old whose BUN is 16.36 mg/dL
genuinely sits 5.5 mg/dL above the population mean for that age — that's
the equivalent of ~+44 years of NHANES "BUN aging." Whether you trust BUN
to mean that much physiologically is a separate question; the math is
working as designed.

---

**Files produced:**
- `/Users/jdl/product_reviews/eva-health/audit/audit_a_run.py` — Reproducible audit code
- `/Users/jdl/product_reviews/eva-health/audit/audit_a_summary.json` — Numerical summary
- `/Users/jdl/product_reviews/eva-health/audit/audit_a_eva_df.parquet` — EVA BA per NHANES SEQN
- `/Users/jdl/product_reviews/eva-health/audit/audit_a_ba_bioage_df.parquet` — BioAge BA per SEQN
- `/Users/jdl/product_reviews/eva-health/audit/audit_a_merged.parquet` — Joint frame
- `/Users/jdl/product_reviews/eva-health/audit/audit_a_run.log` — Full run output
