# Independent Expert Audit — EVA Health KDM v2.2.2 Biological Age Algorithm

**Auditor role:** independent methodologist (Levine/Belsky-level perspective)
**Date:** 2026-05-26
**Codebase reviewed:** `eva-health` (TypeScript port) + `KDM Final Training/training_package_v2_2` (Python training)
**Scope:** mathematical correctness, statistical methodology, validation honesty, Spanish recalibration, individual variance, marker selection, generalizability, production-readiness.

---

## VERDICT

**DO NOT SHIP** (as a public-facing biological age number) — pivot to "Aging Score" or a CI-banded estimate, OR delete the Reference tier entirely.

---

## Executive summary

The Klemera-Doubal math implementation is correct and the TypeScript port appears faithful to the Python reference. However the underlying model is a **weak biological-age estimator that, in its honest out-of-sample form, does not improve mortality discrimination over chronological age + sex** (Reference C-stat 0.761 vs CA-alone 0.764). The Comprehensive tier adds only 0.002 of C-stat over CA. With BA standard error of ~13y after CA-anchoring (and ~16y pre-anchor), individual-level BA estimates have an inter-lab measurement noise SD of ~19y — making a 14-year inter-lab difference for the same person **mathematically expected, not anomalous**. This is statistically defensible per KDM theory but is incompatible with a consumer dashboard that displays "your biological age is X" as a single number. Five of fourteen base panel markers contribute weights that are essentially noise (r² < 0.01), three trained sex-stratified base markers have Spanish recalibration listed as `recalibrated_tier_*` but no `per_sex.q_spain` populated (a silent no-op — only 4-5 base markers actually receive a Spanish q), and `Path B` doubled the effective creatinine s — halving the kidney marker's joint-estimator weight in the deployed model. Spanish recalibration is only multiplicative on `q` (the age-50 baseline), leaving NHANES slopes `k` and SD `s` unchanged — meaning aging-rate dynamics are assumed identical between US and Spanish populations with no evidence offered.

---

## Strengths

1. **Klemera-Doubal math is implemented correctly.** TS code at `src/lib/biomarkers/biological-age-kdm.ts:204-265` is a faithful port of `kdm_training.py:321-361`, with the joint-estimator numerator/denominator and CA-anchored shrinkage matching Klemera & Doubal 2006 eqs. 35-39 exactly. The log-transform branch (when `log_transformed: true`), skip-rule for `s <= 0` or non-finite `k`, and sex-aware `s_ca` selection are all correct.
2. **Bit-for-bit parity test exists** (`biological-age-kdm.parity.test.ts`) with 5 fixtures verifying `|TS_BA − Python_BA| ≤ 0.1y`. Good engineering hygiene.
3. **Gating logic** (`passesKdmGate`, `biological-age-kdm.ts:550-577`) is conservative and well-motivated: requires Albumin + (Creatinine OR Cystatin C) + ≥8 base-panel markers. The Cystatin-C-substitutes-for-Creatinine logic is biologically sound (Cystatin C unaffected by muscle mass).
4. **Creatine-supplement correction is reasonable** (`supplements.ts:148-163`): the formula `0.05 + 0.025 × g/day` capped at 0.40 mg/dL is consistent with Mayer & Mannion 1985 and ISSN 2017.
5. **Sample size is large** (NHANES Continuous 1999-2018, n≈18,570 with mortality follow-up through 2019). Sufficient for stable OLS estimates of `(k, q, s)` for the major markers.
6. **Two-tier reporting** (Reference vs Comprehensive) is a sensible design — Reference for clinical-minimum panels, Comprehensive when the user uploads a deep panel.
7. **Honest holdout validation was performed and reported transparently** (`scripts/honest_holdout_validation.py`). This is exactly the right scientific practice — most consumer bio-age products never do this.
8. **Sex stratification is applied** for 19 markers known to be sex-dimorphic; the per-sex `s_ca` block in `kdm_s_ca.json` is also stratified.

---

## Critical issues

### 1. [BLOCKER] Reference BA adds no mortality information over chronological age

Out-of-sample (`scripts/honest_holdout_validation.py`) numbers:

| Metric | CA alone | Reference KDM | Δ vs CA |
|---|---|---|---|
| HR/SD | 2.883 | 1.277 | n/a (different scale) |
| C-statistic | 0.764 | **0.761** | **−0.003** |

In a Cox model that includes CA + BA, BA's `HR/SD=1.28` is its *marginal* effect after CA is already in the model — the unconditional HR for CA itself is 2.88 (~6%/year mortality acceleration). The Reference BA's C-statistic is **lower** than CA alone. This is statistically equivalent to "Reference BA = CA + noise". Shipping a dashboard label like "your biological age is X" when X carries no incremental information beyond your chronological age + sex is, at best, misleading; at worst, deceptive.

The Comprehensive tier is marginally better (C-stat 0.766, +0.002) — that delta is well within noise. The marketing claim that the algorithm "predicts mortality" is true only in the same trivial sense that calendar age predicts mortality.

For comparison: Levine PhenoAge HR/SD ≈ 1.45, GrimAge HR/SD ≈ 1.7, DunedinPACE HR/SD ≈ 1.6 in the published validation studies.

**Bottom line:** the held-out validation is the truth; the in-sample HR/SD of 1.39/1.65 reflected overfitting.

### 2. [BLOCKER] Individual-level BA standard error is 13y after CA-anchoring → 19y inter-lab SD

I computed this analytically from the deployed parameters:

- Female Reference s_BA (joint-estimator standard error) = 16.28y from Σ(k/s)² = 0.00407 over the 14 base-panel weights.
- After CA-anchoring with `s_ca_F = 23.27y`: final BA standard error = `sqrt(s_BA² × s_ca²/(s_BA² + s_ca²))` = **13.35y**.
- Two independent lab draws on the same person therefore have a difference SD of `sqrt(2) × 13.35` = **18.87y**.
- A 14-year BA difference between two labs is **0.74σ** — easily within one standard deviation of the model's own measurement noise.

This means the algorithm cannot detect a biologically meaningful change of less than ~26y (2σ) between visits in the same person. The user's observed "33 vs 19" and "19 vs 25.86" inter-lab differences are perfectly consistent with the model's stated uncertainty — but the dashboard displays the point estimate as if it had clinical precision. **A confidence interval is mandatory.**

For weak panels (8 of 14 markers, weakest combination), s_BA inflates to 53y; final BA SE is ~21y, inter-lab SD ~30y. The product is reporting a number whose uncertainty bound is roughly half the human lifespan.

### 3. [MAJOR] Eight of fourteen base panel markers have r² < 0.01 with chronological age

From the deployed library (`marker_library_v2_2.json`):

| Marker | r² | Comment |
|---|---|---|
| Total Cholesterol | 0.0008 | essentially flat with age |
| Uric Acid (M) | 0.0002 | flat in men; only women track |
| Ferritin (M) | 0.0015 | flat / non-monotonic in men |
| GGT (M) | 0.0032 | weak |
| Triglycerides | 0.0041 | weak |
| HDL (F) | 0.0065 | weak |
| hs-CRP | 0.0070 | weak (after log-transform) |
| HDL (M) | 0.0089 | weak |

Note that `kdm_training.py` itself includes a "sign sanity check" that aborts only at <80% sign agreement — it does **not** require statistical significance. The deployed v2.2 sign-CI gate (`check_base_panel_k_ci`, lines 262-318) checks whether the bootstrap CI for `k` crosses zero, but per the code comment it treats sex-stratified markers as "warn unless both strata null" — letting Uric Acid (M) with k≈−0.001 (CI almost certainly crosses zero) through.

KDM theory does not require markers to be strongly age-correlated; weak-but-real-signal markers should be down-weighted automatically by `(k/s)²`. But weak markers with very uncertain `k` add *noise*, not just downweighted signal. Levine 2013/2018 explicitly screened for univariate age-association significance before including a marker in PhenoAge or KDM-Bio.

### 4. [MAJOR] Spanish recalibration is incomplete and largely a no-op

The library claims 9 of 14 base-panel markers are "recalibrated", but inspection of `marker_library_v2_2.json` shows:

- **Sex-stratified markers with `calibration_status: "recalibrated_tier_*"` but NO `per_sex.q_spain` populated** (silent no-op — code in `resolveSpanishRecalibratedQ` returns `null`, falls back to NHANES `q`):
  - Creatinine (sex-strat, both M and F null)
  - Uric Acid (sex-strat, both M and F null)
  - GGT (sex-strat, both M and F null)
  - HDL (sex-strat, both M and F null)
- **Sex-stratified base panel markers with NO recalibration block** (Ferritin)
- **Actually recalibrated** base panel markers (pooled with `q_spain` populated):
  - Total Cholesterol (slope 1.016)
  - Triglycerides (slope 0.744)
  - hs-CRP (slope **0.335** — flagged as outside [0.5, 2.0] range; only accepted because `recalibrate.py:43-75` widens the bound to [0.25, 4.0] for log-distributed markers)
  - Vitamin D (slope 0.706 after unit conversion)
  - TSH (slope 1.106)

So only **5 of 14 base panel markers actually get a Spanish q applied** — and one of those (hs-CRP) has a slope of 0.335 which a stricter sanity-check would have rejected. Albumin, BUN, ALP, and Fructosamine remain `Spain-uncalibrated-pending-Tier-1-data`.

Worse: the recalibration is **multiplicative on `q` only** — `q_spain = slope × q_NHANES`. The slope `k` (units per year of CA) and residual SD `s` are kept from NHANES. The implicit assumption is that *aging rate* and *biomarker variability* are the same in Spain and the US, which is testable but untested here. For markers like Triglycerides where Spanish levels are 26% lower than US baseline (slope 0.744), it's plausible the slope and variance are also different.

### 5. [MAJOR] Path B unwinsorization halved the kidney marker weight; "essentially eliminated discrepancy" oversells the win

From `path_b_overrides.json` vs library:

| Marker | s (winsorized) | s (raw, Path B) | s ratio | (k/s)² ratio |
|---|---|---|---|---|
| Creatinine (M) | 0.21 | 0.39 | 1.85× | **0.48×** |
| Creatinine (F) | 0.18 | 0.30 | 1.66× | **0.42×** |
| BUN | 4.39 | 4.96 | 1.13× | 0.88× |
| ALP | 21.24 | 24.62 | 1.16× | 0.82× |
| TSH | 0.67 | 0.75 | 1.11× | 0.71× |
| Albumin | 0.31 | 0.32 | 1.04× | 0.94× |

The deployed Reference BA gives the kidney marker (Creatinine) roughly half the weight it had pre-Path-B. The justification — "winsorization tightened s and inflated weights" — is technically true, but the user-facing implication ("v2.2.2 essentially eliminates the population-level Reference/Comprehensive discrepancy while preserving mortality predictiveness") buries the lede: **the population-level mean Reference and Comprehensive BAs converged because they both became less discriminating**. The honest holdout numbers show Reference HR/SD fell from 1.391 (in-sample, v2.2.2 claim) to 1.277 (out-of-sample) — a 27% drop in the marginal hazard contribution. The "fix" reduced overfitting on the population-mean discrepancy but the underlying signal-to-noise was always weak.

That a "fix" applied 6 months after launch changed user-facing BAs noticeably is itself a stability red flag for a product positioning itself on scientific rigor. From the code comment in `biological-age-kdm.ts:35-48`: "The Comprehensive BA (full-panel joint estimator) was systematically biased relative to the Reference BA by mean −1.59 years across NHANES." That isn't a "bug" — it's a model-specification choice (winsorized vs not). Two reasonable choices yielded two answers, both internally consistent. Neither is definitively correct.

### 6. [MAJOR] Marker selection is idiosyncratic and weaker than Levine PhenoAge

The base panel includes **BUN** (which Levine 2018 KDM-Bio and Levine 2013 PhenoAge both exclude — Levine notes BUN is poorly age-correlated outside renal disease; though our r²=0.11 suggests it does carry signal in NHANES) and **Fructosamine** (derived from HbA1c via the Cohen 2010 formula `Fruct = 19.97 × HbA1c − 39.4`), but **excludes RDW** (Red Cell Distribution Width) and **ALP** appears in our panel but ALP and RDW are both core PhenoAge markers. RDW is widely cited as one of the most robust age-correlated CBC markers and should be in any clinical base panel.

The Fructosamine derivation is mechanically reasonable (both measure mean glycemia on different timescales) but it means the panel **double-counts glucose homeostasis**: if HbA1c is uploaded, the model adds both HbA1c (when in the panel) and a Fructosamine derived from HbA1c. Joint estimators assume marker conditional independence given CA; a derived Fructosamine breaks that assumption and inflates the effective weight of glycemic information.

`FRUCTOSAMINE_KDM_KEY` is also in the **base panel** (line 14 of `marker_library_v2_2.json`). If a user uploads HbA1c but not Fructosamine, the engine derives Fructosamine from HbA1c — then both contribute. If the user uploads neither, Fructosamine is one of the 14 base-panel markers that can be absent under the ≥8-of-14 gating.

### 7. [MAJOR] Spanish recalibration cohorts are clinical/disease-enriched, not population-representative

The codebase cites PESA, ENRICA, Di@bet.es, Hortega, PREDIMED, EPIRCE, La Rioja, SEQC, plus Echevarne (a private lab). Several of these are problematic as "general Spanish population" references:

- **PESA**: bank workers in Madrid, ages 40-54 at enrollment. Healthier than the general Spanish population (working-age employed in financial sector with healthcare access). Total Cholesterol slope of 1.016 (essentially no recalibration) is plausible; hs-CRP slope of 0.335 is striking and is likely both real (Mediterranean diet) and partially confounded (PESA is selection-biased healthy).
- **PREDIMED**: a *randomized clinical trial* of Mediterranean diet in cardiovascular-risk patients (high-CVD-risk Spaniards). Disease-enriched baseline.
- **Di@bet.es**: population study but focused on diabetes prevalence — sampling weighted toward older / metabolic-risk individuals.
- **Echevarne**: a private lab's "antiaging" reference document with no sampling-frame description, classified as Tier-3 (no recalibration applied) — but appearing as the cited source for several markers.

A defensible recalibration needs a Spanish-population probability sample with the full age range (preferably an NHANES-equivalent like ENRICA was designed to approximate). The current basket is a convenience sample of whatever published Spanish reference means could be located. Not fatal, but worth being honest about.

### 8. [MAJOR] In-sample (1.39) vs out-of-sample (1.28) HR/SD gap indicates 15-20% overfit

`scripts/honest_holdout_validation.py` performs a proper 70/30 split with no test-set leakage. The drop from 1.391 to 1.277 (Reference) and 1.654 to 1.525 (Comprehensive) means the deployed parameters are mildly overfit to the training population. This is normal for any OLS-fit model, but two things are worth noting:

1. The library JSON's `model_meta.mortality_validation.hr_per_sd: 1.3725` (line 70-75 of the JSON) is the **in-sample** number — it should be replaced or annotated with the held-out estimate.
2. The TS source comment at lines 11-13 advertises "Reference BA: HR per SD = 1.373 [1.29, 1.46], C-stat 0.770" — this number is now stale (and was an in-sample inflated number). Users / regulators / journalists reading this docstring will be misled.

### 9. [MINOR] s_ca = 10.0 fallback is hard-coded and used in parity fixtures

`biological-age-kdm.ts:251`: `: 10.0;` (literal default when `pooled` also unavailable).
The parity fixtures use `s_ca = 10.0` (not the real ~23y) to make the math identity test easier, but this means the parity test does **not** validate realistic behavior at the deployed s_ca level. The math is correct either way, but reviewers may incorrectly conclude that "TS parity is verified end-to-end."

### 10. [MINOR] Path B `r²` values reflect the underlying signal — they didn't improve

Looking at Path B refits in `path_b_overrides.json`:
- Albumin r² 0.018 → 0.018 (essentially unchanged)
- Total Cholesterol r² 0.0008 → 0.0007 (unchanged)
- Creatinine (M) r² 0.039 → 0.019 (**halved**)
- Ferritin (F) r² 0.127 → 0.127 (unchanged)

Path B isn't increasing model quality; it's correcting an *artifact* of the winsorization choice. Whether the winsorized or unwinsorized parameters are "right" depends on what you think the population is — clinical-normal-range subjects (winsorized) or all NHANES subjects (unwinsorized, including renal/liver patients). For a *consumer wellness product* aimed at relatively healthy users, the winsorized version is arguably more representative of the deployment population, not less. Reasonable people can disagree, but it's worth surfacing this tradeoff.

### 11. [MINOR] No clear evidence the algorithm has been validated on Spanish (not US) mortality data

The mortality validation is entirely on NHANES (US population, US mortality patterns, US healthcare access patterns). The Spanish recalibration adjusts marker baselines but does not validate that the resulting BA predicts mortality in any Spanish cohort. PESA has follow-up but the codebase contains no validation against PESA mortality (or any Spanish mortality data). The product is sold as Spanish-population-tuned but the predictive validity is unverified outside the US.

### 12. [MINOR] HbA1c-derived Fructosamine + HbA1c in same panel violates marker independence

If a user uploads HbA1c, `deriveFructosamineIfMissing` fills in Fructosamine from the Cohen 2010 formula. If the user also uploads Fructosamine independently, the measured one wins (per `biological-age-kdm.ts:469-480`) — good. But the trained panel can include *both* HbA1c (when supplied) and Fructosamine, and they're not independent — they measure overlapping glycemic exposure. The joint estimator treats them as independent and double-counts that signal. Levine's PhenoAge avoided this by using one glucose marker.

---

## Specific recommendations

In priority order (highest impact first):

1. **STOP shipping a point-estimate "biological age" number to consumers.** Instead ship either:
   - "Aging Score" (normalized 0-100, framed as relative rank, no year units), OR
   - BA ± 13y 95% CI explicitly displayed, OR
   - Acceleration (BA − CA) with prediction interval, and never the raw BA.
   The current dashboard implies precision the model does not have.
2. **Drop the Reference tier**. With C-stat 0.761 vs CA-alone 0.764, it's adding nothing. Use Comprehensive when ≥30 markers are uploaded; otherwise fall back to CA-only with a "panel insufficient for biological age estimation" message.
3. **Re-run mortality validation on a Spanish cohort** (PESA, CDC partnership with Spanish biobanks, or any partner with Spanish mortality follow-up). NHANES-only validation does not justify the product's Spanish-market positioning.
4. **Add RDW to the base panel.** RDW is a well-validated age-correlated CBC marker; the engine code in `kdm-adapter.ts:148-149` already maps `RDW` to `"ADE (Amplitud de Distribución Eritrocitaria)"` — finish the wiring.
5. **Audit the Spanish recalibration**. For each sex-stratified marker listed as `recalibrated_tier_*` without `per_sex.q_spain` (Creatinine, Uric Acid, GGT, HDL): either populate `per_sex.q_spain` from sex-stratified Spanish data, or change `calibration_status` to `"sex_strat_no_spanish_data"` so the no-op is visible. Currently the JSON reads as if these were recalibrated when they were not.
6. **Drop markers with r² < 0.01 from the base panel** OR re-classify the base panel: Total Cholesterol, Uric Acid (M), Ferritin (M), HDL (M), HDL (F), Triglycerides, hs-CRP, GGT (M) all contribute mostly noise and add measurement variance. A 6-7 marker base panel of high-r² markers (BUN, Ferritin (F), Fructosamine/HbA1c, Creatinine (F), UA (F), Vitamin D) would be cleaner.
7. **Replace the in-sample mortality numbers in `marker_library_v2_2.json::model_meta.mortality_validation` and in the TS source comment** with the held-out 70/30 numbers. Annotate the in-sample numbers as "training-set, not for deployment evaluation."
8. **Add a `s_BA` ≤ threshold abort**. If the joint estimator's `s_BA` exceeds (say) 20 years, return `null` rather than shipping a number whose uncertainty exceeds reasonable bounds. Current gating only checks marker count, not uncertainty.
9. **Validate the Fructosamine derivation chain.** When both HbA1c and Fructosamine are in the panel, prefer measured Fructosamine. When deriving from HbA1c, do **not** also keep HbA1c in the joint estimator — or down-weight one by half. As currently coded, both contribute as independent markers.
10. **Document Path B's effect on creatinine.** The user-facing impact (kidney function gets half the weight it used to) deserves explicit disclosure if the product is marketed on its lab-based grounding. Either revert Creatinine to the winsorized parameters (treating Path B as a population-mean correction only) or be transparent about the change.
11. **Remove or refactor the parity fixture's `s_ca = 10.0`.** Have at least one parity case use the deployed `s_ca = 23.27` so the math is verified end-to-end in deployment conditions.
12. **Add an inter-visit consistency check.** If two BA estimates for the same user from different labs differ by < 13y (1 SD), display them as "consistent within measurement uncertainty" rather than as two distinct ages. This addresses the user's "33 vs 19" complaint directly.

---

## Comparison to published bio-age methods

| Method | n | C-stat (mortality) | HR per SD | Markers | Notes |
|---|---|---|---|---|---|
| **KDM v2.2.2 Reference (held-out)** | 18,570 | **0.761** | **1.277** | 14 | **Below CA-alone (0.764)** |
| **KDM v2.2.2 Comprehensive (held-out)** | 18,570 | 0.766 | 1.525 | 60-80 | +0.002 over CA |
| Levine PhenoAge (2018) | 9,926 NHANES | 0.83-0.85 | 1.45 | 10 | Trained on Gompertz survival, not OLS |
| Levine KDM-Bio (Kwon & Belsky 2021 reimpl.) | 9,389 NHANES | 0.80-0.82 | ~1.45 | 10 | Same KDM math, different markers |
| GrimAge (Lu et al. 2019) | varies | 0.85-0.88 | 1.7-2.0 | DNAm | Methylation, expensive (~$200/test) |
| DunedinPACE (Belsky 2022) | 1,000 (cohort-specific) | n/a (rate) | ~1.6 | DNAm | Pace of aging measure |
| BioAge (Sebastiani et al. 2017) | 4,704 (FHS) | 0.78-0.81 | 1.3-1.5 | 19 | Z-score composite |
| CA + sex (baseline) | 18,570 | 0.764 | 2.88 (per CA SD) | 0 | Hard to beat in older populations |

**Reading:** EVA Health's Reference KDM is the only entry in this table that fails to beat CA + sex baseline on C-statistic. The Comprehensive tier is competitive on HR/SD but barely improves discrimination. Levine PhenoAge — built from similar inputs with a *single* glycemic marker, 10 markers total, and survival-fit weights — substantially outperforms our 14-marker linear-OLS KDM. The methodology gap is real, not marketing.

---

## Final answer on dashboard deployment

**Do not ship as "Biological Age" with a single year-valued number.** Three viable paths forward:

| Option | Description | Effort | Defensibility |
|---|---|---|---|
| A. **Ship as "Aging Score"** | Normalized 0-100, ranked vs Spanish age-matched cohort. No year units. | Low (UI relabel + percentile lookup table) | High |
| B. **Ship BA with explicit CI** | "Your biological age is 45 ± 13 years (95% CI). Variation between labs of less than this is expected." | Medium (UI redesign, education copy) | Medium-High |
| C. **Ship Comprehensive only with ≥30 markers, drop Reference** | Higher signal panel, clearer panel-required messaging. | Medium (gating logic + UI states) | Medium |
| D. **Status quo** | Ship Reference/Comprehensive BA as point estimates. | Zero | **Low — not recommended.** |

If you must ship a year-valued biological age (option D), at minimum:

1. Display the 95% CI alongside the point estimate.
2. Stop displaying Reference BA as a separate number (it adds no info over CA).
3. Add a "panel quality" indicator that reflects the joint-estimator s_BA.
4. Re-run mortality validation on Spanish data within 12 months and publish results.

The Klemera-Doubal joint estimator math is implemented correctly. What's wrong is the **package the math is sold in** — a deterministic-looking single-number BA, dressed in a clinical font, derived from a model that does not improve mortality discrimination over a calendar and a date of birth.

---

## Files referenced

Source (TypeScript, deployed):
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/biological-age-kdm.ts`
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/kdm-adapter.ts`
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/supplements.ts`
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/marker_library_v2_2.json`
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/path_b_overrides.json`
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/data/kdm_s_ca.json`
- `/Users/jdl/product_reviews/eva-health/src/lib/biomarkers/biological-age-kdm.parity.test.ts`

Training (Python reference):
- `/Users/jdl/Projects/KDM Final Training/training_package_v2_2/training_scripts/kdm_training.py`
- `/Users/jdl/Projects/KDM Final Training/training_package_v2_2/training_scripts/prepare_nhanes.py`
- `/Users/jdl/Projects/KDM Final Training/training_package_v2_2/training_scripts/recalibrate.py`

Validation (load-bearing for these findings):
- `/Users/jdl/product_reviews/eva-health/scripts/honest_holdout_validation.py`
- `/Users/jdl/product_reviews/eva-health/scripts/path_b_mortality_revalidation.py`
- `/Users/jdl/product_reviews/eva-health/scripts/comprehensive_ba_mortality_validation.py`
