# Audit C: Independent Klemera-Doubal 2006 Implementation vs EVA Health v2.2.2

**Auditor:** Independent statistical methodologist (no prior context on v2.2.2)
**Date:** 2026-05-26
**Reference paper:** Klemera P, Doubal S. *A new approach to the concept and computation of biological age.* Mech Ageing Dev. 2006; 127(3):240-8 (equations 35-39).
**Training data:** NHANES Continuous 1999-2018, ages 30-79, `nhanes_continuous_cleaned.parquet`, n=32,167 unique (SEQN, cycle) subjects, 18,631 of whom pass the 10-marker gate.

## TL;DR

1. **My independent KDM and v2.2.2 give nearly the same BA for user 7e397cf0** — 32.4 vs 32.9 (creat=0.96 variant). The v2.2.2 deployed implementation is NOT mis-implementing the Klemera-Doubal math.
2. **BUN over-contributes to BA in this kind of user.** With user 7e397cf0's value of 16.36 mg/dL (90th percentile for his age), BUN alone inflates his v2.2.2 Reference BA by **+9.2 years**, and an even greater **+12.5 years** in my independent KDM. This is reproducible across implementations — it is a property of the K&D math applied to BUN with k=0.125 and the user's value, not a v2.2.2 bug.
3. **v2.2.2 Reference has a persistent +2.8 year mean upward bias against CA across the entire NHANES population** that my implementation does not have (+0.1 y). Root cause: v2.2.2 uses several markers (BUN, HbA1c-derived Fructosamine, Vitamin D) whose population means systematically exceed the q-line projection at most ages.
4. **Mortality discrimination is comparable** between my KDM (HR/SD = 1.32, C-stat = 0.78) and v2.2.2 Reference (1.35, 0.78). v2.2.2 Comprehensive is more discriminative (1.61, 0.79) — but it also widens its individual-vs-individual disagreement with my implementation (Pearson r = 0.83 vs 0.93 for Reference).
5. **Verdict:** v2.2.2 is producing mathematically correct BAs that are *not* unreasonable, but BUN's high weight (~38% of joint estimator) combined with linear extrapolation off a low-r² line is structurally fragile for unusual marker values. The +2.8 y population bias is the more concerning finding and should be remedied by intercept recalibration before consumer ship.

---

## 1. My implementation

### Marker panel (10 markers; my independent choice)

The original Klemera-Doubal 2006 paper used 10 markers. NHANES doesn't have SBP/FEV1/ESR/phenotypic age in our parquet, so I substituted physiologically analogous markers while keeping the kidney/lipid/inflammation/hematopoiesis/immune coverage:

| # | Marker | Role | Original K&D 2006? |
|---|---|---|---|
| 1 | Albumin | liver/nutrition (mandatory) | yes |
| 2 | Creatinine (sex-stratified) | kidney (mandatory) | (BUN proxy in K&D) |
| 3 | **BUN** | kidney | **yes** |
| 4 | Uric Acid (sex-stratified) | metabolic | no (but standard KDM) |
| 5 | Total Cholesterol | lipid | yes |
| 6 | HbA1c (log) | glucose homeostasis | (Glucose in K&D) |
| 7 | hs-CRP (log) | inflammation | (ESR in K&D) |
| 8 | Hemoglobin (sex-stratified) | hematopoiesis | yes |
| 9 | Lymphocyte % | immune | yes |
| 10 | Alkaline Phosphatase | liver/bone | no (broadens coverage) |

Sex stratification: Creatinine, Hemoglobin, Uric Acid (all have physiologically distinct male/female reference means at every age).
Log-transformed: hs-CRP, HbA1c (skewed distributions).

### OLS fits

Direct OLS on raw (unwinsorized) NHANES. Residual SD uses ddof=2.

| Marker | n | k | q (intercept) | s | r² |
|---|---|---|---|---|---|
| Albumin | 18634 | −0.00326 | 4.393 | 0.322 | 0.018 |
| Creatinine M | 9186 | 0.00402 | 0.807 | 0.389 | 0.019 |
| Creatinine F | 9446 | 0.00396 | 0.572 | 0.300 | 0.030 |
| BUN | 18630 | 0.12516 | 7.068 | 4.961 | **0.102** |
| Uric Acid M | 9185 | −0.00139 | 6.109 | 1.307 | 0.0002 |
| Uric Acid F | 9444 | 0.02564 | 3.509 | 1.230 | 0.071 |
| Total Cholesterol | 21973 | 0.08172 | 193.85 | 41.01 | 0.001 |
| HbA1c (log) | 22200 | 0.00303 | 1.590 | 0.150 | 0.068 |
| hs-CRP (log) | 15669 | 0.00771 | 0.266 | 1.224 | 0.007 |
| Hemoglobin M | 10884 | −0.02145 | 16.10 | 1.229 | 0.053 |
| Hemoglobin F | 11324 | 0.01045 | 12.76 | 1.258 | 0.012 |
| Lymphocyte % | 22171 | −0.04999 | 33.66 | 8.359 | 0.006 |
| ALP | 18629 | 0.26483 | 56.68 | 24.62 | 0.020 |

s_CA (SD of BA_E − CA): **M = 29.74, F = 27.66, pooled = 28.72** (years).

Gating: Albumin and Creatinine mandatory; ≥7 of 10 markers present.

---

## 2. Population-level head-to-head (18,631 NHANES subjects)

### Distribution of BA and (BA − CA)

| Implementation | n | mean BA | SD BA | mean (BA−CA) | SD (BA−CA) |
|---|---|---|---|---|---|
| My KDM (10 markers) | 18,631 | 51.92 | 21.90 | **+0.10** | 17.40 |
| v2.2.2 Reference (14 markers, with BUN) | 18,631 | 54.62 | 19.42 | **+2.81** | 14.09 |
| v2.2.2 Comprehensive | 18,631 | 52.69 | 16.28 | **+0.88** | 9.27 |

**Key takeaways:**

- v2.2.2 Reference has a **systematic +2.8-year upward bias** against CA across all of NHANES. Mine is centered at zero, which is what an honest BA should do on the training population.
- v2.2.2 Reference bias persists at every age decile (30s, 40s, 50s, 60s, 70s) — it is not a young-user-only artifact. Per-age-bin means (CA → BA Reference): 30s→38.3, 40s→47.5, 50s→58.8, 60s→68.3, 70s→76.6, i.e. uniformly old by ~3 years.
- v2.2.2 Comprehensive nearly removes the bias (+0.88 y) but at the cost of a much narrower SD of (BA−CA) (9.3 y) — the Comprehensive shrinks toward CA aggressively because its tighter s_CA = ~14 vs Reference s_CA = ~24.
- My implementation has wider SD (17.4 y) because s_CA is wider (~29 y). Both shrinkage regimes are defensible; v2.2.2 Comprehensive is the most conservative.

### Subject-level agreement

| Comparison | Pearson r | mean diff | SD diff | \|diff\|>5y | \|diff\|>10y |
|---|---|---|---|---|---|
| v2.2.2 Reference vs mine | **0.931** | +2.71 y | 8.07 y | 51.7% | 21.6% |
| v2.2.2 Comprehensive vs mine | 0.832 | +0.78 y | 12.31 y | — | — |

A Pearson r of 0.93 means the two methods agree on **rank order** of subjects nearly perfectly, but for >half of subjects the absolute BAs differ by >5 years, and for >1-in-5 subjects by >10 years. **At the individual-decision level, the two implementations do NOT give consistent BAs.**

---

## 3. BUN contribution analysis

### Distribution of v2.2.2 Reference (BA_with_BUN − BA_without_BUN) across NHANES

| Stat | Value (years) |
|---|---|
| mean | −0.41 |
| SD | **6.53** |
| 5th %ile | −9.30 |
| 25th %ile | −4.37 |
| median | −1.02 |
| 75th %ile | +2.90 |
| 95th %ile | +10.02 |
| \|delta\|>3 y | **59.3%** |
| \|delta\|>5 y | **37.3%** |
| \|delta\|>10 y | 9.0% |

**Interpretation:** BUN moves the Reference BA by >5 years in over a third of NHANES subjects, and by >10 years in nearly 1 in 10. It is on average mildly *deflating* (mean −0.4 y) because most NHANES BUN values are below the q-line for older subjects, but the SD is large.

### Per-marker weight share in joint estimator (user 7e397cf0, v2.2.2 Reference with creat=0.96)

| Marker | (x−q)/k = single-marker BA implied | Joint estimator weight (k/s)² | % of total weight |
|---|---|---|---|
| **BUN** | **74.2 y** | 0.000636 | **37.9%** |
| Fructosamine (derived from HbA1c) | 39.1 y | 0.000446 | **26.6%** |
| Vitamin D | −11.4 y | 0.000266 | 15.9% |
| Creatinine | 30.7 y | 0.000107 | 6.4% |
| Albumin | −109.5 y | 0.000103 | 6.1% |
| HDL | −58.7 y | 0.000045 | 2.7% |
| hs-CRP | +0.5 y | 0.000040 | 2.4% |
| Triglycerides | 467 y | 0.000021 | 1.3% |
| Ferritin | −0.6 y | 0.000008 | 0.5% |
| Total Cholesterol | −325.6 y | 0.000004 | 0.2% |
| Uric Acid | 216.4 y | 0.000001 | 0.1% |

Three markers (BUN, Fructosamine, Vitamin D) carry **80% of the joint estimator weight** in this case. BUN alone is 38%, and BUN says "this is a 74-year-old."

### My KDM weight share for the same user

| Marker | % of total weight |
|---|---|
| BUN | **38.8%** |
| HbA1c | 24.9% |
| Hemoglobin | 18.6% |
| Creatinine | 6.5% |
| Albumin | 6.3% |
| hs-CRP | 2.4% |
| Lymphocyte % | 2.2% |
| Total Cholesterol | 0.2% |
| Uric Acid | 0.1% |

**My KDM gives BUN the same ~38% weight** — this confirms BUN's weight is a property of the math (k≈0.125, s≈5, ratio (k/s)²≈0.0006) and not a v2.2.2-specific implementation bug. Any honest KDM with BUN included will give it heavy weight.

---

## 4. User 7e397cf0 — three views

User: 30-year-old male; BUN = 16.36 mg/dL (90th percentile for his age cohort in NHANES).

| Implementation | creat = 1.26 | creat = 0.96 (creatine-adj) |
|---|---|---|
| v2.2.2 Reference (with BUN) | **BA = 35.30** | **BA = 32.90** (prompt cites 33.13 — close match) |
| v2.2.2 Reference (WITHOUT BUN) | 26.07 | 23.09 |
| v2.2.2 Comprehensive | 35.38 | 34.56 (prompt cites 36.18 — within 1.6 y) |
| My KDM (10-marker) | **BA = 35.29** | **BA = 32.41** |
| My KDM WITHOUT BUN | 23.67 | 19.93 |

**BUN-driven inflation for this user:**
- v2.2.2 Reference: **+9.2 to +9.8 years**
- My independent KDM: **+11.6 to +12.5 years**

Both implementations show roughly the same BUN inflation. My implementation actually shows *more* BUN inflation than v2.2.2, because v2.2.2 has Fructosamine, Vitamin D, and triglycerides in its base panel that pull this particular user toward an even higher non-BUN baseline; my smaller panel doesn't have those, so removing BUN drops more.

**The headline:** my BA of 32.4 essentially matches v2.2.2 Reference's 32.9 (creat-adjusted). Two implementations built from the same paper, with mostly different marker panels, give the user *the same answer to within half a year*. v2.2.2 is not mis-applying the math.

---

## 5. Mortality discrimination head-to-head (n=17,368, deaths=1,109)

Cox proportional-hazards with BA standardized to N(0,1), controlling for age and sex.

| Implementation | HR per SD | 95% CI | C-stat |
|---|---|---|---|
| My KDM (10 markers) | 1.316 | [1.270, 1.363] | 0.784 |
| v2.2.2 Reference | 1.354 | [1.292, 1.420] | 0.780 |
| v2.2.2 Comprehensive | **1.609** | [1.502, 1.723] | 0.785 |

All three methods clear conventional discrimination thresholds. v2.2.2 Comprehensive has notably stronger HR/SD (1.61 vs ~1.32) — it picks up more mortality signal from the full panel. My 10-marker panel mortality discrimination is comparable to v2.2.2 Reference.

---

## 6. Verdict

### Is v2.2.2 producing reasonable BAs?

**Mathematically, yes.** v2.2.2 is correctly implementing the Klemera-Doubal 2006 joint estimator (eqs. 35-39) plus CA-anchored shrinkage. My independent implementation agrees with v2.2.2 to within ~0.5 years for user 7e397cf0 and gives Pearson r = 0.93 with v2.2.2 Reference across all NHANES.

**Two real concerns remain:**

1. **+2.8 year population bias.** v2.2.2 Reference has mean(BA−CA) = +2.81 y across NHANES, persisting at every age decile. An honest BA on its training population should have mean(BA−CA) near zero. This is consistent with the v2.2.2 commit-message note that "Comprehensive BA was systematically biased relative to Reference BA by mean −1.59 years across NHANES" — Path B fixed the Comp/Ref relative gap but did NOT verify either is centered on CA. **Both Reference and Comprehensive should be intercept-recalibrated to remove the residual ~+2.8 y bias.**

2. **BUN's 38% weight is structurally fragile.** With k=0.125 mg/dL per year and a residual SD s=4.96 mg/dL on an r²=0.10 fit, BUN dominates the joint estimator weight whenever the user is in the panel. A BUN value that is 5 mg/dL above the q-line moves BA by ~10 years in either direction. Because BUN can be transiently elevated by dehydration, high-protein diet, GI bleeding, or muscle catabolism, **a single BUN reading carrying 38% of a consumer BA decision is brittle**. The original Klemera-Doubal paper did include BUN — but they also had 10 markers, none with this dominant a weight. v2.2.2's wider panel doesn't dilute BUN's weight because BUN's (k/s)² is naturally one of the largest.

### Recommendations

- **(P0) Intercept-recalibrate Reference and Comprehensive** on the NHANES training set itself so mean(BA−CA) is centered on zero. This is a 1-line fix in the BA formula and removes the +2.8 y systematic optimism.
- **(P0) Cap any single marker's joint-estimator weight at ~20%** (or equivalently, downweight BUN's (k/s)² by a factor of ~2) — this preserves BUN's mortality signal but eliminates the 10-year single-marker swing for atypical users.
- **(P1) Add a user-facing disclosure** when one marker is contributing >30% of the BA. Consumer BAs whose answer pivots on a single lab value need contextual framing.
- **(P2) Consider switching to BUN/Creatinine ratio** (BUN:Cr) as a single feature instead of two correlated markers. This is the standard nephrology framing and removes the ambiguity between "is BUN telling me about kidney function or about protein intake/hydration?"

The user 7e397cf0 BA of 33 is **honest given the inputs** (his BUN really is in the 90th percentile for his age) — but it is also **misleading** as a "you are 3 years older than 30" verdict, because it rests heavily on a single transient marker. The math is right; the product story around it needs work.

---

## Appendix: Working artifacts

- `audit_C_work/build_kdm.py` — my Klemera-Doubal implementation, OLS fits, BA computation
- `audit_C_work/run_v222.py` — v2.2.2 reproduction on NHANES with library + Path B overrides
- `audit_C_work/head_to_head.py` — head-to-head + user 7e397cf0 + Cox PH
- `audit_C_work/my_kdm_results.parquet` — per-subject BA from my implementation
- `audit_C_work/v222_kdm_results.parquet` — per-subject BA from v2.2.2 with/without BUN, Comprehensive
- `audit_C_work/my_params.json` — my OLS fits and s_CA
- `audit_C_work/head_to_head_merged.parquet` — merged per-subject comparison
