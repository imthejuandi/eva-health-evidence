"""Run every validation-stage test on one model; write JSON and a markdown summary.

Usage, from ml/biological-age:
    .venv/bin/python harness/run_validation.py --model models.candidates.<name>:build
        [--outcome allcause|bioage_status] [--n-boot 1000] [--workers 4] [--t10] [--out harness/results]

What runs (CHARTER.md section 6):
- harness self-checks (survival code against lifelines, units, eva_bounds.json regenerated identical);
- T0 data integrity and T1 faithful implementation (shared by every model);
- on the validation split (NHANES IV waves 1-4): T2, T3 and T8 as previews (their verdicts come from the sealed
  test), T4, T5, T6, T7, T9; T10 with --t10 (two independent builds in fresh processes).
- comparators on the same subjects: EVA's current KDM (the T2 comparison; its Base Panel tier against the model's
  base tier, like for like), the original PhenoAge and the BioAge KDM for context.
The primary outcome is all-cause mortality (pipeline/data.py); --outcome bioage_status is a sensitivity run only.
"""
from __future__ import annotations

import os

for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse  # noqa: E402
import sys  # noqa: E402
from pathlib import Path  # noqa: E402

HARNESS = Path(__file__).resolve().parent
sys.path.insert(0, str(HARNESS.parent))
sys.path.insert(0, str(HARNESS))

import report  # noqa: E402
import suite  # noqa: E402
import t0 as T0  # noqa: E402
import t1 as T1  # noqa: E402
from candidate import load_model  # noqa: E402
from profiles import load_bounds, load_cv, typical_profiles  # noqa: E402
from thresholds import load as load_thresholds  # noqa: E402

from pipeline import data  # noqa: E402

PREVIEW = {"T2", "T3", "T8"}


def evaluate_candidate(spec: str, outcome: str, n_boot: int, workers: int, with_t10: bool) -> dict:
    thr = load_thresholds()
    out = {"model_spec": spec, "outcome": outcome, "n_boot": n_boot, "seed": suite.SEED,
           "code_sha256": suite.code_fingerprint()}
    out["harness_checks"] = suite.harness_checks()
    out["T0"] = T0.run()
    out["T1"] = T1.run(thr)
    val = data.load_split("validation", outcome).df
    model = load_model(spec)
    out["model"] = {"name": model.name, "description": model.description, "tiers": model.tiers,
                    "mortality_model": model.mortality_model}
    out.update(suite.outcome_evaluation(val, model, thr, n_boot=n_boot, workers=workers, split="validation"))
    profiles = typical_profiles(val)
    out["typical_profiles"] = profiles
    out.update(suite.profile_tests(model, val, profiles, load_bounds(), load_cv(), thr))
    if with_t10:
        out["T10"] = suite.t10(spec)
    out["summary"] = {t: out[t]["verdict"] for t in ("T0", "T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10")
                      if t in out}
    return out


def markdown(res: dict) -> str:
    m = res["model"]
    lines = [f"# Validation run: {m['name']}", "", m["description"], "",
             f"Outcome: {res['outcome']} mortality. Validation split: NHANES IV waves 1-4. Bootstrap: {res['n_boot']} "
             f"resamples, seed {res['seed']}. T2, T3 and T8 are previews: their charter verdict comes from the sealed "
             "test.", "",
             f"Harness self-checks: survival code vs lifelines {res['harness_checks']['survival_vs_lifelines']['verdict']}, "
             f"EVA units {res['harness_checks']['eva_units']['verdict']}, NHANES units "
             f"{res['harness_checks']['nhanes_units']['verdict']}, eva_bounds.json regenerated identical: "
             f"{res['harness_checks']['eva_bounds_regenerated_identical']}.", "",
             f"T0 data integrity: {res['T0']['verdict']}. T1 faithful implementation: {res['T1']['verdict']} "
             f"(PhenoAge r {res['T1']['phenoage']['by_split']['validation']['ours_bioage_crp']['pearson_r']:.10f}, "
             f"KDM r {res['T1']['kdm']['ours']['pearson_r']:.9f}).", ""]
    lines += report.model_table(res, PREVIEW)
    lines += ["", "## T2 criteria", ""]
    for k, v in res["T2"]["criteria"].items():
        lines.append(f"- {k}: {v['verdict']}. {v['detail']}")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", required=True, help="module.path:factory")
    ap.add_argument("--outcome", default=data.PRIMARY_OUTCOME, choices=["allcause", "bioage_status"])
    ap.add_argument("--n-boot", type=int, default=suite.N_BOOT)
    ap.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    ap.add_argument("--t10", action="store_true")
    ap.add_argument("--out", default=str(HARNESS / "results"))
    args = ap.parse_args()
    res = evaluate_candidate(args.model, args.outcome, args.n_boot, args.workers, args.t10)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"validation_{res['model']['name']}_{args.outcome}"
    digest = suite.write_json(out_dir / f"{stem}.json", res)
    (out_dir / f"{stem}.md").write_text(markdown(res) + f"\nResults JSON SHA-256: {digest}\n", encoding="utf-8")
    print(f"wrote {out_dir / stem}.json and .md; summary: {res['summary']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
