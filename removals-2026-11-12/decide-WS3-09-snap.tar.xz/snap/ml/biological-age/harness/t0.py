"""T0, data integrity (CHARTER.md section 6): split membership, no subject in two splits, the test ID hash, identical
inclusion rules. Also checks the data definitions the harness relies on, and audits the code for reads that would
bypass the seal.

Validation stage: reads the test split's IDs only (pipeline.data.sealed_test_ids), never its values.
Test stage: final_test.py passes the loaded test split, and the same checks run on it.

The seal audit is textual on purpose: outside the allowed files, even a comment or a string that names the raw files
or their reader fails T0. Candidate code refers to the data only through pipeline.data.
"""
from __future__ import annotations

import hashlib
import inspect
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline import data  # noqa: E402
from pipeline.paths import DATA_DIR, HARNESS_DIR, PROGRAM_DIR  # noqa: E402

TEST_IDS_FILE = HARNESS_DIR / "test_ids.sha256"
# Only these files may name the raw files, import the .rda reader or request the test split.
SEAL_ALLOWED = {"pipeline/data.py", "fetch_data.py", "harness/t0.py", "harness/final_test.py",
                "harness/write_test_ids.py"}
SEAL_PATTERNS = [r"NHANES[34]\.rda", r"\bpyreadr\b", r"read_r\(", r"load_split\(\s*[\"']test[\"']",
                 r"_raw_rows\(", r"_read_rda\(", r"_unsealed_view\("]


def recorded_test_hash() -> str | None:
    if not TEST_IDS_FILE.exists():
        return None
    return TEST_IDS_FILE.read_text(encoding="utf-8").split()[0]


def seal_audit() -> dict:
    offenders = []
    for path in sorted(PROGRAM_DIR.rglob("*.py")):
        rel = path.relative_to(PROGRAM_DIR).as_posix()
        if rel.startswith((".venv/", "data/")) or rel in SEAL_ALLOWED:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for pat in SEAL_PATTERNS:
            for m in re.finditer(pat, text):
                line = text.count("\n", 0, m.start()) + 1
                offenders.append(f"{rel}:{line}: {pat}")
    return {"verdict": "pass" if not offenders else "fail", "offenders": offenders,
            "rule": "only " + ", ".join(sorted(SEAL_ALLOWED)) + " may read the raw files or request the test split"}


def seal_refusal() -> dict:
    """Every other route to the test split must fail loudly (this process is not final_test.py)."""
    if Path(getattr(sys.modules.get("__main__"), "__file__", "") or "").name == "final_test.py":
        return {"verdict": "n/a", "note": "not run inside final_test.py"}
    attempts = {
        "pipeline.data.load_split('test')": lambda: data.load_split("test"),
        "pipeline.data.raw_bioage_rows('test')": lambda: data.raw_bioage_rows("test"),
        "pipeline.data.analysis_rows('test')": lambda: data.analysis_rows("test"),
    }
    out = {}
    for label, attempt in attempts.items():
        try:
            attempt()
            out[label] = "NOT REFUSED"
        except data.SealedSplitError:
            out[label] = "refused (SealedSplitError)"
    ok = all(v.startswith("refused") for v in out.values())
    return {"verdict": "pass" if ok else "fail", "attempts": out}


def status_rule(frame: pd.DataFrame) -> dict:
    """BioAge `status` = deaths from UCOD 1,2,3,5,6,7,9 or unknown cause; 4, 8, 10 coded 0; NHANES III capped at 240."""
    st, uc, tm = frame["status_bioage"], frame["ucod_leading"], frame["time_months"]
    counted = uc.isin(data.BIOAGE_STATUS_CAUSES)
    excluded = uc.isin(data.BIOAGE_EXCLUDED_CAUSES)
    problems = {
        "status 1 with an excluded cause (4, 8, 10)": int(((st == 1) & excluded).sum()),
        "status 0 with a counted cause, not censored at 240 months": int(
            ((st == 0) & counted & ~((frame["source"] == "NHANES3") & (tm == data.NHANES3_FOLLOW_UP_CAP_MONTHS))).sum()),
        "NHANES III follow-up above 240 months": int(((frame["source"] == "NHANES3") & (tm > 240)).sum()),
    }
    deaths_all = int((frame["event_allcause"] == 1).sum())
    return {
        "verdict": "pass" if not any(problems.values()) else "fail",
        "violations": problems,
        "deaths_allcause": deaths_all,
        "deaths_bioage_status": int((st == 1).sum()),
        "allcause_deaths_coded_0_by_bioage": int(((frame["event_allcause"] == 1) & (st == 0)).sum()),
        "by_cause_coded_0": {int(k): int(v) for k, v in uc[(frame["event_allcause"] == 1) & (st == 0)].value_counts().sort_index().items()},
    }


def inclusion_check(split: data.Split) -> dict:
    df = split.df
    r = data.INCLUSION_RULES
    bad = {
        "age outside 20-84": int(((df["age"] < r["age_min"]) | (df["age"] > r["age_max"])).sum()),
        "age at the cycle's top code (unknown age)": int((df["age"] >= df["wave"].map(data.TOP_CODED_AGE)).sum()),
        "known pregnancy": int((df["pregnant"] == 1).sum()),
    }
    if split.spec["outcome"]:
        bad["mortality status or follow-up missing"] = int((df["status_bioage"].isna() | df["time_months"].isna()).sum())
    return {"n_included": int(len(df)), "flow": split.flow, "violations": bad,
            "mortality_rule_applies": bool(split.spec["outcome"]),
            "verdict": "pass" if not any(bad.values()) else "fail"}


def run(test_split: data.Split | None = None) -> dict:
    """T0. test_split: only when called from final_test.py; otherwise the test split is checked through its IDs."""
    out: dict = {"stage": "test" if test_split is not None else "validation"}
    # Data files
    files = {}
    for source, expected in data.RDA_SHA256.items():
        got = hashlib.sha256((DATA_DIR / f"{source}.rda").read_bytes()).hexdigest()
        files[source] = {"sha256": got, "matches_charter": got == expected}
    out["data_files"] = files
    # Split membership and disjointness
    ids = {name: data.split_ids(name) for name in data.SPLITS}
    membership = {}
    for name in ("train", "validation", "nonoutcome"):
        rows = data.raw_bioage_rows(name)
        spec = data.SPLITS[name]
        membership[name] = {"rows": int(len(rows)), "waves": sorted(int(w) for w in rows["wave"].unique()),
                            "expected_waves": list(spec["waves"]), "source": spec["source"],
                            "ok": set(rows["wave"].unique()) == set(spec["waves"])}
    membership["test"] = {"rows": len(ids["test"]), "expected_waves": list(data.SEALED_WAVES), "source": "NHANES4",
                          "ok": len(ids["test"]) > 0}
    overlaps = {}
    names = list(ids)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            overlaps[f"{a} & {b}"] = len(set(ids[a]) & set(ids[b]))
    dup = {name: len(v) - len(set(v)) for name, v in ids.items()}
    out["split_membership"] = membership
    out["overlaps"] = overlaps
    out["duplicate_ids_within_split"] = dup
    # Test ID hash
    got = data.test_ids_sha256(ids["test"])
    rec = recorded_test_hash()
    out["test_id_hash"] = {"computed": got, "recorded": rec, "file": "harness/test_ids.sha256",
                           "verdict": "pass" if rec is not None and rec == got else "fail"}
    # Inclusion rules: one function, one set of rules
    source = inspect.getsource(data.apply_inclusion)
    out["inclusion"] = {
        "rules": data.INCLUSION_RULES,
        "function": "pipeline.data.apply_inclusion",
        "function_sha256": hashlib.sha256(source.encode()).hexdigest(),
        "note": "Every split goes through the same function with the same rules; the mortality-status rule applies "
                "where the split has mortality linkage (train, validation, test), not to waves 9-10, which have none.",
        "by_split": {},
    }
    status = {}
    splits = {name: data.load_split(name) for name in ("train", "validation", "nonoutcome")}
    if test_split is not None:
        splits["test"] = test_split
    for name, sp in splits.items():
        out["inclusion"]["by_split"][name] = inclusion_check(sp)
        if sp.spec["outcome"]:
            status[name] = status_rule(sp.df)
    out["bioage_status_rule"] = status
    out["seal_audit"] = seal_audit()
    out["seal_refusal"] = seal_refusal() if test_split is None else {"verdict": "n/a", "note": "test stage"}
    checks = [
        all(f["matches_charter"] for f in files.values()),
        all(m["ok"] for m in membership.values()),
        not any(overlaps.values()),
        not any(dup.values()),
        out["test_id_hash"]["verdict"] == "pass",
        all(v["verdict"] == "pass" for v in out["inclusion"]["by_split"].values()),
        all(v["verdict"] == "pass" for v in status.values()),
        out["seal_audit"]["verdict"] == "pass",
        out["seal_refusal"]["verdict"] in ("pass", "n/a"),
    ]
    out["verdict"] = "pass" if all(checks) else "fail"
    return out


if __name__ == "__main__":
    import json

    print(json.dumps(run(), indent=2, default=str))
