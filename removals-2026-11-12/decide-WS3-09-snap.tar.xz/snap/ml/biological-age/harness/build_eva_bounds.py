"""Write harness/eva_bounds.json: EVA's reviewed optimal and reference bounds for every candidate marker (T6).

Source: supabase/seed-data/biomarker-ranges-en.json, read the way the seeder reads it
(src/lib/biomarkers/seed-references.ts): key = slugify(English name), sex normalized, and rows that share
(key, sex, age group) keep the LAST occurrence (`dedupeByConflictKey`). Sex-specific rows are kept per sex; a "Both"
row applies to both sexes. Where a marker's rows are age-banded, the 40-59 band is used (none of the candidate
markers is banded; eGFR is, and is not a candidate). Values are converted to the NHANES units of the analysis
columns with the factors of pipeline/units.py. Each entry keeps its source row.

Usage: python harness/build_eva_bounds.py   (deterministic; rerunning rewrites the same file)
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.paths import EVA_SEED_EN, HARNESS_DIR  # noqa: E402
from pipeline.units import BY_COLUMN, slugify  # noqa: E402

OUT = HARNESS_DIR / "eva_bounds.json"

# Charter candidate markers (CHARTER.md section 4) plus the comparator inputs that have an EVA row.
MARKERS = [
    "albumin", "alp", "crp", "creatinine", "bun", "uric_acid", "total_cholesterol", "hdl", "ggt", "triglycerides",
    "hba1c", "glucose_fasting", "lymphocyte_pct", "mcv", "rdw", "wbc", "cystatin_c",
]
# Comparator-only inputs and the EVA row used for them in T6.
COMPARATOR_ROWS = {
    "glucose": ("glucose_fasting", "The original PhenoAge reads serum glucose in any fasting state; T6 applies EVA's "
                                   "fasting-glucose row to it."),
    "sbp": (None, "Blood pressure has no row in EVA's laboratory seed."),
}
AGE_BAND = "40-59"
SEX_MAP = {"Both": "both", "Male": "male", "Female": "female"}
FIELDS = [("reference_low", "Normal_Low"), ("reference_high", "Normal_High"),
          ("optimal_low", "Optimal_Low"), ("optimal_high", "Optimal_High")]


def seeded_rows() -> list[dict]:
    rows = json.loads(EVA_SEED_EN.read_text(encoding="utf-8"))["biomarker_ranges"]
    kept: dict[tuple, dict] = {}
    for index, r in enumerate(rows):
        key = (slugify(r["Biomarker"]), SEX_MAP.get(r["Sex"], r["Sex"].lower()), r["Age_Group"])
        kept[key] = {"index": index, **r}  # last occurrence wins, as dedupeByConflictKey
    return list(kept.values())


def entry_for(column: str, eva_key: str | None, rows: list[dict]) -> dict:
    unit = BY_COLUMN[column]
    base = {"column": column, "nhanes_unit": unit.nhanes_unit}
    if eva_key is None:
        return {**base, "eva_key": None, "has_bounds": False, "by_sex": {}}
    to_eva = BY_COLUMN[column].to_eva if BY_COLUMN[column].to_eva is not None else BY_COLUMN[eva_col(eva_key)].to_eva
    to_nhanes = 1.0 / to_eva
    mine = [r for r in rows if slugify(r["Biomarker"]) == eva_key]
    banded = sorted({r["Age_Group"] for r in mine} - {"All Adults"})
    if banded:
        mine = [r for r in mine if r["Age_Group"] == AGE_BAND]
    by_sex = {}
    for r in mine:
        sex = SEX_MAP.get(r["Sex"], r["Sex"].lower())
        values = {name: (None if r[src] is None else round(r[src] * to_nhanes, 10)) for name, src in FIELDS}
        by_sex[sex] = {
            **values,
            "eva_values": {src: r[src] for _, src in FIELDS},
            "source_row": {"file": "supabase/seed-data/biomarker-ranges-en.json", "index": r["index"],
                           "Biomarker": r["Biomarker"], "Unit": r["Unit"], "Sex": r["Sex"],
                           "Age_Group": r["Age_Group"], "Category": r["Category"]},
        }
    has_bounds = any(v[name] is not None for v in by_sex.values() for name, _ in FIELDS)
    return {**base, "eva_key": eva_key, "eva_unit": mine[0]["Unit"] if mine else None, "to_nhanes": to_nhanes,
            "age_banded_rows": banded, "has_bounds": has_bounds, "by_sex": by_sex}


def eva_col(eva_key: str) -> str:
    return next(u.column for u in BY_COLUMN.values() if u.eva_key == eva_key)


def render() -> str:
    """The exact text of eva_bounds.json built from the current seed file (nothing is written)."""
    return json.dumps(build(), indent=2, ensure_ascii=False) + "\n"


def main() -> None:
    OUT.write_text(render(), encoding="utf-8")
    print(f"wrote {OUT}")


def build() -> dict:
    rows = seeded_rows()
    markers = {}
    for column in MARKERS:
        markers[column] = entry_for(column, BY_COLUMN[column].eva_key, rows)
    for column, (eva_key, note) in COMPARATOR_ROWS.items():
        entry = entry_for(column, eva_key, rows)
        entry["note"] = note
        markers[column] = entry
    markers["lymphocyte_pct"]["note"] = (
        "EVA's white-cell percentage rows have no bounds (Gate 1 decision W1, "
        "docs/biomarker-evidence/longevity/GATE-1-DECISIONS.md). T6 cannot test this marker; see the T6 rule below.")
    markers["cystatin_c"]["note"] = "No cystatin C row in EVA's seed. T6 cannot test this marker."
    out = {
        "_source": "supabase/seed-data/biomarker-ranges-en.json (sha256 "
                   + hashlib.sha256(EVA_SEED_EN.read_bytes()).hexdigest() + "), rows as seeded: key = slugify(name), "
                   "duplicates keep the last occurrence (src/lib/biomarkers/seed-references.ts).",
        "_generated_by": "harness/build_eva_bounds.py",
        "_units": "Bounds are in the NHANES units of the analysis columns (pipeline/units.py); eva_values are the "
                  "seed's values in EVA's units.",
        "_rows": "by_sex has 'male' and 'female' for sex-specific rows, or 'both'. Age-banded rows: band 40-59.",
        "_t6_rules": [
            "A side of the optimal band is tested only when that optimal bound exists.",
            "Start point: the reference limit on that side; if there is none, the sex-specific validation 1st "
            "(lower side) or 99th (upper side) percentile (CHARTER.md T6).",
            "A reference lower limit of 0 is EVA's way of writing 'no lower limit' (hs-CRP 0-3, GGT 0-73, total "
            "cholesterol 0-200, triglycerides 0-150) and is treated as absent.",
            "A side is not applicable when the start point already lies inside the optimal band, or equals the "
            "optimal bound (a move of zero length).",
            "Markers without any EVA bound (lymphocyte %, cystatin C, blood pressure) cannot be tested by T6: they "
            "are listed as untestable in every T6 result, and the T6 verdict covers the other markers only.",
        ],
        "markers": markers,
    }
    return out


if __name__ == "__main__":
    main()
