"""Markdown rendering of harness results (run_validation.py, run_baselines.py, final_test.py)."""
from __future__ import annotations


def _n(x, d=3):
    return "–" if x is None else f"{x:.{d}f}"


def _ci(ci, d=3):
    return "–" if not ci or ci[0] is None else f"{ci[0]:.{d}f} to {ci[1]:.{d}f}"


def t2_text(t2: dict) -> str:
    if t2.get("hr_per_sd") is None:
        return f"n={t2['n']} ({t2['deaths']} deaths); no acceleration; C age+sex {_n(t2['c_age_sex'], 4)}"
    return (f"n={t2['n']} ({t2['deaths']} deaths); HR/SD {_n(t2['hr_per_sd'])} ({_ci(t2['hr_ci_bootstrap'])}); "
            f"C {_n(t2['c_full'], 4)} vs {_n(t2['c_age_sex'], 4)}, gain {_n(t2['c_gain'], 4)} "
            f"({_ci(t2['c_gain_ci_bootstrap'], 4)})")


def t3_text(t3: dict) -> str:
    worst = max((abs(b["mean_gap"]) for b in t3["mean_gap_by_sex_age_band"].values() if b["mean_gap"] is not None),
                default=None)
    s = (f"mean gap {_n(t3['mean_gap_overall'], 2)} y (worst band |{_n(worst, 2)}|); slope on age "
         f"{_n(t3['slope_ba_on_age'])}")
    g = t3.get("gompertz_10y")
    if g:
        s += f"; Gompertz slope {_n(g['calibration_slope'])} ({_ci(g['calibration_slope_ci_bootstrap'])})"
    for tier, r in t3.get("extended_tiers", {}).items():
        s += f"; [{tier}: {r['verdict']}, " + t3_text(r) + "]"
    return s


def t4_text(t4: dict) -> str:
    if t4.get("verdict") == "n/a":
        return t4.get("note", "")
    parts = []
    for tier, r in t4["tiers"].items():
        worst = max((abs(b["mean_diff"]) for b in r["by_sex_age_band"].values() if b["mean_diff"] is not None),
                    default=None)
        parts.append(f"{tier}: n={r['n']}, base - extended {_n(r['mean_base_minus_extended'], 2)} y "
                     f"(worst band |{_n(worst, 2)}|)")
    return "; ".join(parts)


def t5_text(t5: dict) -> str:
    if t5.get("verdict") == "n/a":
        return "no markers"
    fails = []
    for tier, r in t5["tiers"].items():
        for e in r["markers"]:
            if e["older_verdict"] == "fail":
                fails.append(f"{e['marker']} ({e['sex']}, {tier}): {_n(e['effect_years'], 2)} y")
            if e["range_verdict"] == "fail":
                fails.append(f"{e['marker']} ({e['sex']}, {tier}): P1-P99 {_n(e['effect_p1_to_p99_years'], 1)} y")
    return "all markers older when adverse, P1-P99 effects within 20 y" if not fails else "; ".join(fails[:8]) + (
        f"; +{len(fails) - 8} more" if len(fails) > 8 else "")


def t6_text(t6: dict) -> str:
    if t6.get("verdict") == "n/a" and not any(r["sides"] or r["untestable"] for r in t6["tiers"].values()):
        return "no markers"
    fails, untest = [], set()
    for tier, r in t6["tiers"].items():
        for e in r["sides"]:
            if e["verdict"] == "fail":
                fails.append(f"{e['marker']} {e['side']} ({e['sex']}, {tier}): {e['start']:.3g}->{e['optimal_bound']:.3g}"
                             f" {_n(e['change_years'], 2)} y")
        untest |= {u["marker"] for u in r["untestable"]}
    s = "no side makes the result older" if not fails else "; ".join(fails[:6]) + (
        f"; +{len(fails) - 6} more" if len(fails) > 6 else "")
    if untest:
        s += f" (untestable, no EVA bounds: {', '.join(sorted(untest))})"
    return s


def t7_text(t7: dict) -> str:
    if t7.get("verdict") == "n/a" and all(not r["varied"] and not r["held_fixed_no_cv"] for r in t7["tiers"].values()):
        return "no markers"
    parts = []
    for tier, r in t7["tiers"].items():
        bs = r["by_sex"]
        parts.append(f"{tier}: SD {_n(bs['male']['sd_years'], 2)}/{_n(bs['female']['sd_years'], 2)} y, RC "
                     f"{_n(bs['male']['reliable_change_95_years'], 1)}/{_n(bs['female']['reliable_change_95_years'], 1)} y"
                     f" (men/women)" + (f", fixed: {', '.join(r['held_fixed_no_cv'])}" if r["held_fixed_no_cv"] else ""))
    return "; ".join(parts)


def t8_text(t8: dict) -> str:
    if "groups" not in t8:
        return t8.get("note", "")
    g = "; ".join(f"{k} {_n(v['hr_per_sd'], 2)} ({_ci(v['hr_ci_bootstrap'], 2)})" for k, v in t8["groups"].items())
    r = ", ".join(f"{k.split()[-1]}: {_n(v.get('hr_per_sd'), 2)}" + ("" if v["verdict"] != "n/a" else " (<50 deaths)")
                  for k, v in t8["race_ethnicity"].items())
    s = f"{g}; ethnicity {r}"
    for tier, sub in t8.get("extended_tiers", {}).items():
        s += f"; [{tier}: {sub['verdict']}, " + t8_text(sub) + "]"
    return s


def t9_text(t9: dict) -> str:
    if t9.get("verdict") == "n/a":
        return "no markers"
    parts = []
    for tier, r in t9["tiers"].items():
        worst = max(r["shifts"], key=lambda e: abs(e["shift_years"] or 0))
        parts.append(f"{tier}: largest {worst['change']} {_n(worst['shift_years'], 2)} y ({worst['sex']})")
    return "; ".join(parts)


TEXT = {"T2": t2_text, "T3": t3_text, "T4": t4_text, "T5": t5_text, "T6": t6_text, "T7": t7_text, "T8": t8_text,
        "T9": t9_text}


def model_table(results: dict, preview: set[str]) -> list[str]:
    lines = ["| Test | Verdict | Key numbers |", "|---|---|---|"]
    for test in ("T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10"):
        r = results.get(test)
        if r is None:
            continue
        verdict = r.get("verdict_summary", r.get("verdict", ""))
        label = test + (" (validation preview)" if test in preview else "")
        text = TEXT[test](r["result"] if "result" in r else r) if test in TEXT else r.get("note", "")
        lines.append(f"| {label} | {verdict} | {text} |")
    return lines
