"""The sealed final test (CHARTER.md sections 6 and 7). VERIFIER ONLY. The Builder wrote it and never ran it.

Runs T0 and the test-stage tests T2, T3, T4 and T8 on the sealed split (NHANES IV waves 5-8) for one frozen
candidate, with every comparator on the same subjects, using exactly the code run_validation.py runs on validation
(suite.outcome_evaluation). It is the only program allowed to read the sealed split (pipeline/data.py enforces this).

Usage, from ml/biological-age:
    .venv/bin/python harness/final_test.py --model models.candidates.<name>:build \\
        --artifact models/candidates/<name>/model-v3.json [--diagnosed-fix "..."] [--workers 4]

Budget (harness/final_test_budget.py): a "start" record is appended to harness/final_test_log.jsonl BEFORE the
sealed data is read, so every attempt counts; a third run is refused; a second run needs a failed or incomplete first
run and --diagnosed-fix. The log records the SHA-256 of the frozen artifact, of every file in the candidate's
directory and of the harness code, so the Verifier can check them against the freeze record. Thresholds are read from
harness/thresholds.json, validated against CHARTER.md before anything runs. Nothing here re-estimates the candidate:
its calibration intercept was set on validation and is part of the frozen artifact (T3).
"""
from __future__ import annotations

import os

for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import argparse  # noqa: E402
import datetime  # noqa: E402
import hashlib  # noqa: E402
import importlib.util  # noqa: E402
import sys  # noqa: E402
from pathlib import Path  # noqa: E402

HARNESS = Path(__file__).resolve().parent
sys.path.insert(0, str(HARNESS.parent))
sys.path.insert(0, str(HARNESS))

import report  # noqa: E402
import suite  # noqa: E402
import t0 as T0  # noqa: E402
from candidate import load_model  # noqa: E402
from final_test_budget import BudgetError, append, next_run, read_log  # noqa: E402
from thresholds import load as load_thresholds  # noqa: E402

from pipeline import data  # noqa: E402

LOG = HARNESS / "final_test_log.jsonl"
TEST_STAGE = ("T0", "T2", "T3", "T4", "T8")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def candidate_files(spec: str) -> dict:
    module = spec.partition(":")[0]
    origin = importlib.util.find_spec(module).origin
    folder = Path(origin).resolve().parent
    return {p.relative_to(HARNESS.parent).as_posix(): sha256_file(p) for p in sorted(folder.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", required=True)
    ap.add_argument("--artifact", required=True, help="the frozen model-v3.json")
    ap.add_argument("--diagnosed-fix", default=None)
    ap.add_argument("--n-boot", type=int, default=suite.N_BOOT)
    ap.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    args = ap.parse_args()

    thr = load_thresholds()  # refuses to run if thresholds.json drifted from the charter
    if args.n_boot != thr["general"]["bootstrap_resamples"]:
        print("refused: the final test uses the charter's 1,000 bootstrap resamples")
        return 2
    artifact = Path(args.artifact).resolve()
    if not artifact.is_file():
        print(f"refused: frozen artifact {artifact} not found")
        return 2
    try:
        run = next_run(read_log(LOG), args.diagnosed_fix)
    except BudgetError as e:
        print(e)
        return 3
    start = {
        "event": "start", "run": run, "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "model_spec": args.model, "artifact": str(artifact.relative_to(HARNESS.parent)),
        "artifact_sha256": sha256_file(artifact), "candidate_files_sha256": candidate_files(args.model),
        "harness_code_sha256": suite.code_fingerprint(), "diagnosed_fix": args.diagnosed_fix,
    }
    append(LOG, start)  # counted from here on, whatever happens next

    test = data.load_split("test")
    res = {"run": run, "outcome": test.df.attrs.get("outcome"), "freeze": start, "n_boot": args.n_boot,
           "seed": suite.SEED}
    res["T0"] = T0.run(test_split=test)
    model = load_model(args.model)
    res["model"] = {"name": model.name, "description": model.description, "tiers": model.tiers,
                    "mortality_model": model.mortality_model}
    res.update(suite.outcome_evaluation(test.df, model, thr, n_boot=args.n_boot, workers=args.workers, split="test"))
    res["summary"] = {t: res[t]["verdict"] for t in TEST_STAGE}
    # T4 is "n/a" for a model with one tier (no extended markers); every other test-stage test must pass.
    all_pass = all(v == "pass" or (t == "T4" and v == "n/a") for t, v in res["summary"].items())
    out_dir = HARNESS / "results"
    out_dir.mkdir(exist_ok=True)
    digest = suite.write_json(out_dir / f"final_test_run{run}.json", res)
    lines = [f"# Sealed final test, run {run}: {model.name}", "",
             f"All test-stage tests pass: {all_pass}. T0: {res['T0']['verdict']}.", ""]
    lines += report.model_table(res, set())
    lines += ["", "## T2 criteria", ""] + [f"- {k}: {v['verdict']}. {v['detail']}" for k, v in res["T2"]["criteria"].items()]
    lines += ["", f"Results JSON SHA-256: {digest}", ""]
    (out_dir / f"final_test_run{run}.md").write_text("\n".join(lines), encoding="utf-8")
    append(LOG, {"event": "complete", "run": run, "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 "summary": res["summary"], "all_test_stage_tests_pass": all_pass, "results_sha256": digest})
    print(f"run {run}: {res['summary']}; results in {out_dir}/final_test_run{run}.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
