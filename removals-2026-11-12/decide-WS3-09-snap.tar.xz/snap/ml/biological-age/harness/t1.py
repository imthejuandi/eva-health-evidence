"""T1, faithful implementation (CHARTER.md section 6).

- The original PhenoAge computed by our code from raw columns (models/comparators/phenoage.py, BioAge CRP transform)
  against BioAge's `phenoage0` on NHANES IV: the included validation subjects (waves 1-4) decide the verdict; waves
  9-10 and NHANES III are shown too. The sealed waves are never read.
- Our port of kdm_calc (models/comparators/kdm_bioage.py) against BioAge's `kdm0` in NHANES III, with the markers and
  training BioAge used for kdm0: fev, sbp, totchol, hba1c, albumin, creat, lncrp, alp, bun; NHANES III aged 30-75,
  pregnant == 0, by sex; s_ba2 = s2 - s_r with s2 on the complete cases (kdm_calc(complete, fit = kdm_calc(all)$fit)).
  kdm0 exists in NHANES IV only for 2007-2010 (spirometry), which is inside the sealed test split, so NHANES III is
  where it can be checked.
- Documented contrasts, not verdicts: PhenoAge with ln(CRP) instead of ln(1 + CRP), and the pinned single kdm_calc
  call, against the same references.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.comparators import kdm_bioage, phenoage  # noqa: E402
from pipeline import data  # noqa: E402


def agreement(ours: np.ndarray, ref: np.ndarray, thr: dict | None = None) -> dict:
    m = np.isfinite(ours) & np.isfinite(ref)
    d = np.abs(ours[m] - ref[m])
    out = {"n": int(m.sum()), "pearson_r": float(np.corrcoef(ours[m], ref[m])[0, 1]),
           "median_abs_diff_years": float(np.median(d)), "max_abs_diff_years": float(d.max())}
    if thr is not None:
        ok = out["pearson_r"] >= thr["pearson_r_min"] and out["median_abs_diff_years"] <= thr["median_abs_diff_max_years"]
        out["verdict"] = "pass" if ok else "fail"
    return out


def kdm0_reproduction(rule: str) -> tuple[np.ndarray, np.ndarray, dict]:
    raw = data.raw_bioage_rows("train")
    ours = np.full(len(raw), np.nan)
    params = {}
    for sex in (1, 2):
        keep = ((raw["age"] >= 30) & (raw["age"] <= 75) & (raw["pregnant"] == 0) & (raw["gender"] == sex)).fillna(False)
        train = raw.loc[keep, kdm_bioage.KDM0_MARKERS + ["age"]]
        if rule == "kdm0":
            _, fit_all = kdm_bioage.kdm_calc(train, kdm_bioage.KDM0_MARKERS)
            complete = train.dropna(subset=kdm_bioage.KDM0_MARKERS)
            kdm, fit = kdm_bioage.kdm_calc(complete, kdm_bioage.KDM0_MARKERS, fit=fit_all)
            ours[complete.index] = kdm
        else:
            kdm, fit = kdm_bioage.kdm_calc(train, kdm_bioage.KDM0_MARKERS)
            ours[train.index] = kdm
        params[{1: "male", 2: "female"}[sex]] = {"s_r": fit["s_r"], "s2": fit["s2"], "s_ba2": fit["s_ba2"],
                                                  "n_train": int(len(train))}
    ref = raw["kdm0"].to_numpy(dtype=float)
    # compare on rows where kdm0 exists; report rows where only one side exists
    only_ours = int(np.sum(np.isfinite(ours) & ~np.isfinite(ref)))
    only_ref = int(np.sum(~np.isfinite(ours) & np.isfinite(ref)))
    params["rows_only_ours"] = only_ours
    params["rows_only_kdm0"] = only_ref
    return ours, ref, params


def run(thresholds: dict) -> dict:
    thr = thresholds["T1"]
    out = {}
    pa, pl = phenoage.build_bioage(), phenoage.build_ln_crp()
    pheno = {}
    for split in ("validation", "nonoutcome", "train"):
        df = data.load_split(split).df
        ref = df["bioage_phenoage0"].to_numpy(dtype=float)
        pheno[split] = {
            "ours_bioage_crp": agreement(pa.predict_ba(df), ref, thr if split == "validation" else None),
            "contrast_ln_crp": agreement(pl.predict_ba(df), ref),
        }
    out["phenoage"] = {
        "reference": "BioAge phenoage0 (phenoage_calc, orig = TRUE)",
        "by_split": pheno,
        "verdict": pheno["validation"]["ours_bioage_crp"]["verdict"],
        "note": "Verdict on the included validation subjects (NHANES IV waves 1-4). Our code starts from the level "
                "columns (albumin g/dL, creatinine mg/dL, glucose mg/dL, CRP mg/dL); the residual difference comes "
                "from BioAge storing creat_umol rounded (float32).",
    }
    ours, ref, params = kdm0_reproduction("kdm0")
    ours_p, _, params_p = kdm0_reproduction("pinned")
    out["kdm"] = {
        "reference": "BioAge kdm0 in NHANES III (markers fev, sbp, totchol, hba1c, albumin, creat, lncrp, alp, bun)",
        "ours": {**agreement(ours, ref, thr), "parameters": params},
        "contrast_pinned_single_call": {**agreement(ours_p, ref), "parameters": params_p},
        "verdict": agreement(ours, ref, thr)["verdict"],
    }
    out["verdict"] = "pass" if out["phenoage"]["verdict"] == "pass" and out["kdm"]["verdict"] == "pass" else "fail"
    return out


if __name__ == "__main__":
    import json

    from thresholds import load

    print(json.dumps(run(load()), indent=2))
