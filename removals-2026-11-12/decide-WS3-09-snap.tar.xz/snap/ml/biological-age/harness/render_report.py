"""Render REPORT-baselines.md from the pipeline's outputs, so that every number in it is traced to code.

Inputs: harness/results/baselines.json (run_baselines.py), harness/results/data_definitions.json (describe_data.py),
harness/results/reproducibility.json (compare_runs.py, optional), pipeline/units.py, harness/thresholds.json.
Usage: .venv/bin/python harness/render_report.py [--results DIR] [--out PATH]
The prose is fixed; every number is read from those files.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

HARNESS = Path(__file__).resolve().parent
sys.path.insert(0, str(HARNESS.parent))

from pipeline.data import RDA_SHA256  # noqa: E402
from pipeline.units import BY_COLUMN, UNITS  # noqa: E402

RDA_SUFFIX = ".rda"

DISPLAY = {"albumin": "Albumin", "alp": "ALP", "crp": "CRP", "creatinine": "Creatinine", "bun": "BUN",
           "uric_acid": "Uric acid", "total_cholesterol": "Total cholesterol", "hdl": "HDL cholesterol", "ggt": "GGT",
           "triglycerides": "Triglycerides", "hba1c": "HbA1c", "glucose_fasting": "Fasting glucose",
           "lymphocyte_pct": "Lymphocyte %", "mcv": "MCV", "rdw": "RDW", "wbc": "WBC", "cystatin_c": "Cystatin C"}

LABELS = {
    "age_sex": "Age and sex only",
    "phenoage_bioage": "PhenoAge, BioAge CRP",
    "phenoage_ln_crp": "PhenoAge, ln(CRP), unverified",
    "kdm_bioage": "BioAge KDM",
    "kdm_bioage_pinned_s2": "BioAge KDM, pinned s2",
    "eva_kdm_v22_base_panel": "**EVA KDM v2.2, Base Panel**",
    "eva_kdm_v22_all_available": "EVA KDM v2.2, every marker",
    "eva_kdm_v22": "**EVA KDM v2.2**",
    "random_score": "Random score (tests of the tests)",
    "phenoage_crp_flipped": "PhenoAge, CRP sign flipped (tests of the tests)",
}
COMPARATOR_ROWS = ["age_sex", "phenoage_bioage", "phenoage_ln_crp", "kdm_bioage", "kdm_bioage_pinned_s2",
                   "eva_kdm_v22_base_panel", "eva_kdm_v22_all_available"]
SEX = {"male": "men", "female": "women"}


def n(x) -> str:
    return f"{int(x):,}"


def f(x, d=3) -> str:
    return "–" if x is None else f"{x:.{d}f}"


def ci(pair, d=3, sep=" to ") -> str:
    if not pair or pair[0] is None:
        return "–"
    return minus(f"{pair[0]:.{d}f}") + sep + minus(f"{pair[1]:.{d}f}")


def pct(x, d=1) -> str:
    return f"{100 * x:.{d}f}%"


def signed(x, d=2) -> str:
    return f"{x:+.{d}f}".replace("-", "−")


def minus(s: str) -> str:
    return s.replace("-", "−")


class Report:
    def __init__(self, b: dict, dd: dict, rep: dict | None, thr: dict):
        self.b, self.dd, self.rep, self.thr = b, dd, rep, thr
        self.L: list[str] = []

    def add(self, *lines: str) -> None:
        self.L.extend(lines)

    # ─── helpers over the results ───

    def row(self, key: str, label: str) -> dict:
        return self.b["outcome_tests"][key][label]

    def failing_criteria(self, r: dict) -> str:
        names = {"hr_lower_bound": "HR lower bound", "c_gain": "C gain", "at_least_eva_kdm": "below EVA's KDM"}
        bad = [names.get(k, k) for k, v in r["T2"]["criteria"].items() if v["verdict"] == "fail"]
        return r["T2"]["verdict"] + (f" ({', '.join(bad)})" if bad else "")

    def t3_cell(self, r: dict) -> str:
        t3 = r["T3"]
        g = t3.get("gompertz_10y")
        return (f"{t3['verdict']} ({minus(signed(t3['mean_gap_overall']))} y; {f(t3['slope_ba_on_age'])}; "
                f"{f(g['calibration_slope']) if g else 'none'})")

    def t8_cell(self, r: dict) -> str:
        t8 = r["T8"]
        if "groups" not in t8:
            return "n/a"
        bad = [f"{k} lower bound {v['hr_ci_bootstrap'][0]:.3f}" for k, v in t8["groups"].items() if v["verdict"] == "fail"]
        bad += [f"{k} {v['hr_per_sd']:.3f}" for k, v in t8["race_ethnicity"].items() if v["verdict"] == "fail"]
        return t8["verdict"] + (f" ({'; '.join(bad)})" if bad else "")

    # ─── sections ───

    def header(self):
        b, dd = self.b, self.dd
        tr = b["T0"]["bioage_status_rule"]["train"]
        va = b["T0"]["bioage_status_rule"]["validation"]
        crp = dd["crp_detection"]
        ext = dd["extremes"]
        pt = b["profile_tests"]["eva_kdm_v22"]
        t4 = pt["T4"]["tiers"]["all_available"]["mean_base_minus_extended"]
        t7 = pt["T7"]["tiers"]["base"]["by_sex"]
        bun = next(e for e in pt["T5"]["tiers"]["base"]["markers"] if e["marker"] == "bun" and e["sex"] == "male")
        er = b["outcome_tests"]["allcause|A"]["eva_kdm_v22_base_panel"]
        verdicts = {"T2 (preview)": er["T2"]["verdict"], "T3 (preview)": er["T3"]["verdict"],
                    "T8 (preview)": er["T8"]["verdict"], **{t: pt[t]["verdict"] for t in ("T4", "T5", "T6", "T7", "T9")},
                    "T10": pt["T10"]["verdict"]}
        order = ["T2 (preview)", "T3 (preview)", "T4", "T5", "T6", "T7", "T8 (preview)", "T9", "T10"]
        eva_fails = ", ".join(t for t in order if verdicts[t] == "fail") or "no test"
        eva_passes = ", ".join(t for t in order if verdicts[t] == "pass") or "no test"
        ln = b["T1"]["phenoage"]["by_split"]["validation"]["contrast_ln_crp"]
        pin = b["T1"]["kdm"]["contrast_pinned_single_call"]
        pk = b["T1"]["kdm"]
        s_ratio = pin["parameters"]["male"]["s_ba2"] / pk["ours"]["parameters"]["male"]["s_ba2"]
        self.add(
            "# EVA biological age, version 3: Builder's report",
            "",
            "29 September 2026. Written by the Builder of the v3 program. The contract is `CHARTER.md`, committed in "
            "096606d.",
            "",
            "This report covers four things: the data pipeline, the test harness, the comparators and the tests of "
            "the tests. Four things were not done:",
            "- no candidate model was built or tuned;",
            "- no threshold and no charter text was changed;",
            "- no survey weights were used;",
            "- the sealed test split was not evaluated. Section 8 says exactly what of it was looked at.",
            "",
            "This file is generated by `harness/render_report.py`. Every number in it comes from these files:",
            "- `harness/results/baselines.json`, from `harness/run_baselines.py`: comparators, tests of the tests, "
            "T0, T1, T10.",
            "- `harness/results/data_definitions.json`, from `harness/describe_data.py`: the data evidence.",
            "- `harness/results/reproducibility.json`, from `harness/compare_runs.py`.",
            "",
            "Items that could not be verified are listed in section 9.",
            "",
            "## 1. Summary",
            "",
            "**What was built.**",
            "",
            "| Path | What it is |",
            "|---|---|",
            "| `pipeline/data.py` | Loads the BioAge files, applies the charter's splits and inclusion rules, defines "
            "the outcome, seals the test split |",
            "| `pipeline/units.py` | NHANES unit of every analysis column and its conversion to EVA's canonical unit, "
            "checked against EVA's code |",
            "| `pipeline/survival.py` | Cox model (Efron ties), Harrell's C and bootstrap in numpy, checked against "
            "lifelines |",
            "| `harness/` | T0 to T10; `thresholds.json`, `eva_bounds.json` and `test_ids.sha256`; "
            "`run_validation.py` for candidates, `run_baselines.py`, `final_test.py` (never run) |",
            "| `models/comparators/` | Age and sex; original PhenoAge; BioAge-faithful KDM; EVA KDM v2.2 through the "
            "production TypeScript; the two tests-of-tests models |",
            "",
            "**Findings that change how the program works.**",
            "",
            "1. **BioAge's `status` is not all-cause mortality** (section 2.2).",
            "   - It counts deaths from heart disease, cancer, chronic lower respiratory disease, stroke, Alzheimer's "
            "disease, diabetes and kidney disease, or of unknown cause.",
            "   - Deaths from accidents, influenza and pneumonia, and all other causes are coded as survivors at "
            f"their death time. That is {pct(tr['allcause_deaths_coded_0_by_bioage'] / tr['deaths_allcause'], 0)} of "
            f"the deaths in NHANES III and {pct(va['allcause_deaths_coded_0_by_bioage'] / va['deaths_allcause'], 0)} "
            "in validation.",
            "   - The pilot in `ATTEMPTS.md` used this `status`, and did not apply the charter's inclusion rules "
            "either.",
            "   - The harness uses all-cause mortality, rebuilt from the cause-of-death field, as its primary outcome. "
            "BioAge's `status` is kept as a sensitivity outcome. **The orchestrator should confirm this before "
            "modeling starts.**",
            "2. **BioAge's `phenoage0` enters CRP as ln(1 + CRP mg/dL), not ln(CRP).**",
            "   - Our PhenoAge with BioAge's transform reproduces `phenoage0`: T1 passes.",
            f"   - With ln(CRP), agreement with `phenoage0` falls to r = {ln['pearson_r']:.4f}, a median gap of "
            f"{ln['median_abs_diff_years']:.2f} years, and T1 would fail.",
            "3. **`kdm0` is reproduced exactly once one detail is known.** The per-marker regressions use all "
            "available training rows; s2, and so the blending constant s_ba2, uses complete cases only. The pinned "
            f"single `kdm_calc` call gives an s_ba2 {s_ratio:.0f} times larger in men and does not reproduce `kdm0` "
            f"(r = {pin['pearson_r']:.3f}).",
            "4. **The BioAge files carry undocumented cleaning** (section 2.3):",
            f"   - extreme values are removed: BUN never above {ext['train']['bun']['max']:.0f} mg/dL, CRP under 5 "
            f"mg/dL, HbA1c at most {ext['train']['hba1c']['max']:.1f}%;",
            "   - creatinine is recalibrated;",
            "   - every `ln*` column is ln(1 + x);",
            f"   - the CRP detection limit differs across splits: {crp['train']['min_mg_dl']:.2f} mg/dL in NHANES III "
            f"against {crp['validation']['min_mg_dl']:.2f} mg/dL in NHANES IV. {pct(crp['train']['share_at_min'], 0)} "
            "of training subjects sit at the NHANES III limit, and "
            f"{pct(crp['validation']['share_below_nhanes3_limit_0_21'], 0)} of validation subjects are below it.",
            f"5. **EVA's current KDM v2.2 on validation fails {eva_fails}** (section 6; Base Panel markers, cohort A; "
            f"it passes {eva_passes}).",
            f"   - T4: the Base Panel reads {t4:.1f} years older than with every marker.",
            f"   - T7: the repeat-draw SD is {t7['male']['sd_years']:.1f} years in men.",
            f"   - T5: the BUN effect between its 1st and 99th percentiles is {bun['effect_p1_to_p99_years']:.0f} years "
            "in men.",
            "   - The Base model must still at least match it on T2.",
            "6. **The tests of the tests pass** (section 7). They prompted one implementation change, not a "
            "threshold change: T2's C-statistic gain is cross-fitted, because apparent C let a random score pass that "
            "criterion in a 20-resample trial.",
            "",
        )

    def data_section(self):
        b, dd = self.b, self.dd
        t0 = b["T0"]
        flows = dd["inclusion_flow"]
        tr, va = t0["bioage_status_rule"]["train"], t0["bioage_status_rule"]["validation"]
        fu = dd["follow_up"]["validation"]
        gap = dd["time_vs_permth_int"]
        preg = dd["pregnancy_unknown_nhanes3"]
        val_gap_min = minus(f"{gap['validation']['min_months']:.0f}")
        files = " and ".join(f"`data/{name}{RDA_SUFFIX}`" for name in RDA_SHA256)  # names built, not written out
        self.add(
            "## 2. Data definitions",
            "",
            "### 2.1 Source, splits, inclusion",
            "",
            f"- **Files.** BioAge commit b1f9fc0, {files}. Their SHA-256 match the charter and are checked on every "
            "read.",
            f"- **Splits.** As fixed by the charter, in `pipeline/data.py`. The test split holds "
            f"{n(t0['split_membership']['test']['rows'])} rows (waves 5 to 8). The SHA-256 of its sorted `sampleID` "
            f"list is in `harness/test_ids.sha256`: `{t0['test_id_hash']['recorded']}`. Sample IDs are unique and no "
            "subject is in two splits (T0).",
            "- **Inclusion.** One function, `apply_inclusion`, with one rule set:",
            "  - age 20 to 84;",
            "  - a known pregnancy excludes;",
            "  - mortality status and follow-up time known.",
            "- **Choices in applying the rules.**",
            f"  - Pregnancy is unknown for {n(preg['n'])} NHANES III rows, {preg['with_exam_follow_up']} of them "
            "examined, so how they are treated changes nobody's inclusion.",
            "  - \"Mortality status known\" also requires follow-up time. That excludes "
            f"{gap['train']['labs_without_follow_up_time']} NHANES III rows and "
            f"{gap['validation']['labs_without_follow_up_time']} validation rows that have laboratory values but no "
            "follow-up time.",
            "  - Waves 9 and 10 have no mortality linkage, so the mortality rule does not apply to them.",
            "",
            "| Split | Rows | Age 20-84 | Not pregnant | Status and follow-up known (included) |",
            "|---|---|---|---|---|",
        )
        names = {"train": "Train, NHANES III", "validation": "Validation, NHANES IV waves 1-4",
                 "nonoutcome": "Non-outcome, waves 9-10"}
        for s in ("train", "validation", "nonoutcome"):
            fl = flows[s]
            last = n(fl[3]["remaining"]) if len(fl) > 3 else f"{n(fl[2]['remaining'])} (rule not applicable)"
            self.add(f"| {names[s]} | {n(fl[0]['remaining'])} | {n(fl[1]['remaining'])} | {n(fl[2]['remaining'])} | "
                     f"{last} |")
        self.add(
            "",
            "### 2.2 Outcome: `time` and `status`",
            "",
            "BioAge ships no data-preparation code at the pinned commit (no `data-raw/`, no data documentation), so the "
            "definitions below were established from the files and are checked by T0 on every run.",
            "",
            "- **`time`** is in months from the MEC examination to death or to 31 December 2015; the harness calls "
            "it `time_months`.",
            f"  - It matches NCHS PERMTH_EXM: below the cap it is {gap['train']['min_months']:.0f} to "
            f"{gap['train']['max_months']:.0f} months under PERMTH_INT (`permth_int`, months from the interview) in "
            f"NHANES III, and {val_gap_min} to {gap['validation']['max_months']:.0f} months under it in waves 1 to 4.",
            "  - It is missing for people who were not examined.",
            "  - In NHANES III BioAge censored follow-up at 240 months: deaths after 240 months are coded alive at "
            "240.",
            "  - Maximum follow-up in validation is "
            + ", ".join(f"{fu[w]['max_follow_up_months']:.0f}" for w in ("1", "2", "3", "4"))
            + " months in waves 1 to 4.",
            "- **`status`** is 1 only for deaths whose NCHS UCOD_LEADING is 1, 2, 3, 5, 6, 7 or 9, or whose cause is "
            "missing.",
            "  - Deaths with codes 4 (accidents), 8 (influenza and pneumonia) and 10 (all other causes) are 0 at their "
            "death time.",
            "  - There are no exceptions in any visible split (T0 `bioage_status_rule`).",
            "  - The labels of the codes come from the NCHS linked-mortality documentation and were not re-read here. "
            "The rule itself is from the data.",
            "",
            "| Split | Included | Deaths, all-cause | Deaths in BioAge `status` | All-cause deaths coded alive (cause 4 / "
            "8 / 10) |",
            "|---|---|---|---|---|",
        )
        for s, r in (("Train", tr), ("Validation", va)):
            inc = flows["train" if s == "Train" else "validation"][3]["remaining"]
            c = r["by_cause_coded_0"]
            self.add(f"| {s} | {n(inc)} | {n(r['deaths_allcause'])} | {n(r['deaths_bioage_status'])} | "
                     f"{n(r['allcause_deaths_coded_0_by_bioage'])} ({n(c['4'])} / {n(c['8'])} / {n(c['10'])}) |")
        self.add(
            "",
            "- **All-cause mortality** (`event_allcause`, the primary outcome) is `status` = 1 or any recorded "
            "cause.",
            "  - In NHANES III a cause-4, 8 or 10 death counts only when `time` < 240. At exactly 240 months it "
            "cannot be told apart from a later death, so it stays censored.",
            "  - `pipeline.data.set_outcome(frame, \"bioage_status\")` switches any frame to BioAge's definition.",
            "",
        )

    def units_section(self):
        b, dd = self.b, self.dd
        nh = {r["check"]: r for r in b["harness_checks"]["nhanes_units"]["by_split"]["validation"]}
        crp = dd["crp_detection"]
        cal = dd["creatinine_calibration"]
        ext = dd["extremes"]
        fast = dd["fasting"]
        top = dd["age_top_coding"]
        self.add(
            "### 2.3 Variables, units, transforms",
            "",
            "Analysis columns are in NHANES conventional units. The units were inferred from the values and from "
            "BioAge's derived columns; the NHANES codebooks could not be opened. Conversion to EVA's canonical units:",
            "- Verified against the `Unit` field of `supabase/seed-data/biomarker-ranges-en.json`, the field that "
            "`canonical-units.ts` returns.",
            "- Also verified against `engineUnit` in `kdm-adapter.ts`.",
            "- Cystatin C has no seed row; its unit comes from the adapter.",
            "",
            "| Column | BioAge column | NHANES unit | EVA key | EVA unit | Multiply by |",
            "|---|---|---|---|---|---|",
        )
        for u in UNITS:
            fac = "none" if u.to_eva is None else f"{u.to_eva:g}"
            self.add(f"| {u.column} | {u.bioage_column} | {u.nhanes_unit} | {u.eva_key or 'none'} | "
                     f"{u.eva_unit or 'none'} | {fac} |")
        maxe = max(r["max_abs_error"] or 0 for s in b["harness_checks"]["nhanes_units"]["by_split"].values()
                   for r in s if r["check"].startswith("ln"))
        self.add(
            "",
            "Unit checks against BioAge's derived columns, re-run on every harness run (`pipeline/units.py`):",
            f"- albumin_gL = albumin × 10 (maximum error {nh['albumin_gL = albumin x 10']['max_abs_error']:.0g});",
            f"- creat_umol = creat × 88.4 (maximum error {nh['creat_umol = creat x 88.4']['max_abs_error']:.4f}, "
            "float32 rounding);",
            f"- glucose_mmol = glucose × 0.0555 (maximum error "
            f"{nh['glucose_mmol = glucose x 0.0555']['max_abs_error']:.0g}).",
            "",
            "Other properties of the files, with evidence in `data_definitions.md`:",
            "- **`ln*` columns are ln(1 + x).** This holds for `lncrp`, `lncreat`, `lnalp`, `lnbun` and `lnuap` "
            f"(maximum error {maxe:.0e}). `lnhba1c` is ln(1 + x) in NHANES III but ln(x) in NHANES IV. The analysis "
            "frame therefore exposes no BioAge `ln*` column, and every transform is computed from the level column.",
            "- **Creatinine is recalibrated.** Every value lies on the original 0.1 mg/dL grid after inverting a "
            f"linear map: NHANES III 0.960x − 0.088 "
            f"({pct(cal['NHANES III: (creat + 0.088) / 0.960 on a 0.1 grid'], 0)} of values); wave 1 (1999-2000) "
            f"1.013x + 0.147 ({pct(cal['wave 1: (creat - 0.147) / 1.013 on a 0.1 grid'], 0)}); wave 4 (2005-2006) "
            f"0.978x − 0.016 ({pct(cal['wave 4: (creat + 0.016) / 0.978 on a 0.1 grid'], 0)}). Waves 2, 3, 9 and 10 "
            "are unchanged: they are on a 0.01 grid. The sealed waves were not checked.",
            f"- **CRP detection limits differ across splits.** The lowest value is {crp['train']['min_mg_dl']:.2f} "
            f"mg/dL in NHANES III, reached by {pct(crp['train']['share_at_min'])} of included training subjects, "
            f"against {crp['validation']['min_mg_dl']:.2f} mg/dL in waves 1 to 4 and "
            f"{crp['nonoutcome']['min_mg_dl']:.3f} mg/dL in 2015-2018. "
            f"{pct(crp['validation']['share_below_nhanes3_limit_0_21'])} of validation subjects are below NHANES "
            "III's limit. CRP is in mg/dL throughout; BioAge converted 2015-2018 hs-CRP.",
            "- **Extreme values are missing.** BioAge's cleaning set them to missing by an undocumented rule. Largest "
            "value per split:",
            "",
            "  | Marker | Train | Validation | Waves 9-10 |",
            "  |---|---|---|---|",
        )
        for m, lab in (("bun", "BUN (mg/dL)"), ("crp", "CRP (mg/dL)"), ("hba1c", "HbA1c (%)"),
                       ("glucose", "Glucose (mg/dL)"), ("creatinine", "Creatinine (mg/dL)"), ("alp", "ALP (U/L)"),
                       ("ggt", "GGT (U/L)")):
            self.add(f"  | {lab} | " + " | ".join(f"{ext[s][m]['max']:.4g}" for s in ("train", "validation", "nonoutcome"))
                     + " |")
        self.add(
            "",
            "- **Fasting subsample.** Triglycerides and fasting glucose are kept only when fasting is 8 to under 24 "
            "hours (`phpfast`), in every split. NHANES III measured triglycerides in everyone, so this keeps "
            f"{n(fast['train']['triglycerides_fasting_included'])} of its "
            f"{n(fast['train']['triglycerides_any_state_raw_rows'])} measured values. Validation keeps "
            f"{n(fast['validation']['triglycerides_fasting_included'])} of "
            f"{n(fast['validation']['triglycerides_any_state_raw_rows'])}.",
            f"- **Age top-coding.** Age is top-coded at {top['train']['0']['max_age']:.0f} in NHANES III, at "
            f"{top['validation']['1']['max_age']:.0f} in waves 1 to 4, and at {top['nonoutcome']['9']['max_age']:.0f} "
            "in waves 9 and 10.",
            "  - NHANES top-codes at 80 from 2007, so in the test split \"80\" means 80 and over. The charter's rule "
            "\"age at most 84\" is applied to the recorded value in every split.",
            "  - In the test split, the 60-84 band therefore contains people aged 85 and over. The sealed waves were "
            "not checked.",
            "- **Ethnicity codes** (1 to 4; race 3 = codes 3 and 4) are not labelled in the files. By their "
            "proportions they are non-Hispanic White, non-Hispanic Black, Mexican American or Hispanic, and other. "
            "These labels are inferred, not verified. T8 uses the four codes.",
            "",
        )

    def reference_section(self):
        k = self.b["T1"]["kdm"]
        pin = k["contrast_pinned_single_call"]["parameters"]["male"]["s2"]
        s2 = k["ours"]["parameters"]["male"]["s2"]
        self.add(
            "### 2.4 What `phenoage0` and `kdm0` are",
            "",
            "- **`phenoage0`** is BioAge `phenoage_calc(orig = TRUE)`. It uses Levine's published coefficients on:",
            "  - `albumin_gL`, `creat_umol`, `glucose_mmol` (serum glucose in any fasting state);",
            "  - `lncrp`, which is ln(1 + CRP mg/dL);",
            "  - lymphocyte %, MCV, RDW, ALP, WBC and age.",
            "",
            "  It is present for every row with those inputs. In NHANES III that is ages 20 to 84 only, and it is "
            "missing in waves 7 and 8 (no CRP).",
            "- **`kdm0`** is BioAge KDM on Levine 2013's markers without CMV: FEV1, systolic pressure, total "
            "cholesterol, HbA1c, albumin, creatinine, `lncrp`, ALP and BUN.",
            "  - It is trained as `kdm_nhanes` does: NHANES III, ages 30 to 75, `pregnant == 0`, separately by sex.",
            f"  - It exists only for complete cases: {n(k['ours']['n'])} in NHANES III, and in NHANES IV only "
            "2007-2010, inside the sealed split.",
            "  - Reproduction recipe: regressions and s_r on every available row; s2 and s_ba2 on complete cases "
            "(`kdm_calc(complete, fit = kdm_calc(all)$fit)`).",
            "  - At the pinned commit, `kdm_calc` also averages rows with up to all-but-one marker missing into s2, "
            f"rescaled by 9/(markers observed). That inflates s2 from {s2:.0f} to {pin:.0f} in men.",
            "",
        )

    def t1_section(self):
        t1 = self.b["T1"]
        thr = self.thr["T1"]
        p = t1["phenoage"]["by_split"]
        k = t1["kdm"]
        self.add(
            "## 3. T1: faithful implementation",
            "",
            f"Thresholds: Pearson r ≥ {thr['pearson_r_min']} and median absolute difference ≤ "
            f"{thr['median_abs_diff_max_years']} years.",
            "",
            "| Check | Sample | n | Pearson r | Median \\|Δ\\| (years) | Max \\|Δ\\| | Verdict |",
            "|---|---|---|---|---|---|---|",
        )

        def line(label, sample, r, verdict):
            self.add(f"| {label} | {sample} | {n(r['n'])} | {r['pearson_r']:.13f} | {r['median_abs_diff_years']:.3g} | "
                     f"{r['max_abs_diff_years']:.3g} | {verdict} |")

        line("Our original PhenoAge (BioAge CRP) vs `phenoage0`", "Validation, included", p["validation"]["ours_bioage_crp"],
             f"**{p['validation']['ours_bioage_crp']['verdict']}**")
        line("Same", "Waves 9-10, included", p["nonoutcome"]["ours_bioage_crp"], "(shown)")
        line("Same", "NHANES III, included", p["train"]["ours_bioage_crp"], "(shown)")
        line("Contrast: PhenoAge with ln(CRP) vs `phenoage0`", "Validation", p["validation"]["contrast_ln_crp"],
             "would fail")
        line("Our `kdm_calc` port vs `kdm0` (kdm0 recipe)", "NHANES III", k["ours"], f"**{k['ours']['verdict']}**")
        line("Contrast: pinned single `kdm_calc` call vs `kdm0`", "NHANES III", k["contrast_pinned_single_call"],
             "would fail")
        pm, pf = k["ours"]["parameters"]["male"], k["ours"]["parameters"]["female"]
        self.add(
            "",
            "- **PhenoAge.** Our code starts from the level columns (albumin g/dL, creatinine mg/dL, glucose mg/dL, "
            "CRP mg/dL). The residual comes from BioAge storing `creat_umol` rounded.",
            f"- **KDM.** Fitted constants in NHANES III, kdm0 recipe: men s_r {pm['s_r']:.1f}, s2 {pm['s2']:.1f}, "
            f"s_ba2 {pm['s_ba2']:.1f}; women s_r {pf['s_r']:.1f}, s2 {pf['s2']:.1f}, s_ba2 {pf['s_ba2']:.1f}.",
            "",
        )

    def harness_section(self):
        b = self.b
        sc = b["harness_checks"]["survival_vs_lifelines"]
        prof = b["typical_profiles"]
        self.add(
            "## 4. The harness",
            "",
            "**Running it.**",
            "- A candidate: `.venv/bin/python harness/run_validation.py --model models.candidates.<name>:build "
            "[--t10]`. It writes `harness/results/validation_<name>_<outcome>.json` and `.md`.",
            "- Every comparator result: `.venv/bin/python harness/run_baselines.py`, then "
            "`harness/describe_data.py` and `harness/render_report.py`.",
            "- The model interface is in `harness/candidate.py`:",
            "  - `predict_ba(df, tier)` in years;",
            "  - `tiers`, each with the markers it reads and the markers it requires; the Base model's tier is named "
            "`base`;",
            "  - `mortality_model`, and `predict_mortality_10y` for mortality models;",
            "  - `artifact_bytes()`, optional, for T10.",
            "",
            "**Thresholds.**",
            "- `harness/thresholds.json` holds every threshold with its charter text quoted verbatim.",
            "- `harness/thresholds.py` refuses to load it if a quote is not in `CHARTER.md`, or if a number is not "
            "written in its quote.",
            "",
            "**Sealing.**",
            "- `pipeline/data.py` drops waves 5 to 8 right after reading. `load_split(\"test\")` raises "
            "`SealedSplitError` unless the running program is `harness/final_test.py` and is also the caller.",
            "- T0 does two things on every run:",
            "  - it tries every other route to the test split and records that each is refused;",
            "  - it audits every Python file in the folder for code that names the raw files, imports the `.rda` "
            "reader or asks for the test split.",
            "- `sealed_test_ids()` returns only the test IDs, for the hash and the disjointness check.",
            "",
            "**Final test (`harness/final_test.py`, not run).**",
            "- The budget rules are in `final_test_budget.py`. A \"start\" record, with the SHA-256 of the frozen "
            "artifact, the candidate's files and the harness code, is appended to `harness/final_test_log.jsonl` "
            "before the sealed data is read.",
            "- A third run is refused. A second run needs a failed or incomplete first run and `--diagnosed-fix`.",
            "- The rules are exercised on a temporary log by `harness/selftest_final_test_budget.py`, which passes.",
            "- The evaluation code is the same function `run_validation.py` runs on validation "
            "(`suite.outcome_evaluation`).",
            "",
            "**Definitions the charter left open, as implemented** (details in the docstring of "
            "`harness/evaluate.py`).",
            "",
            "| Item | Implementation |",
            "|---|---|",
            "| Acceleration | Biological age regressed (OLS) on age within the evaluated sample; residual divided by "
            "its SD, pooled over sexes |",
            "| HR per SD (T2, T8) | Cox model, Efron ties, on [acceleration, age, female]; within one sex "
            "[acceleration, age] |",
            "| C-statistic gain (T2) | Harrell's C of the out-of-fold linear predictor of Cox[acceleration, age, "
            "female] minus that of Cox[age, female]; 10 folds fixed by a hash of the subject ID. Apparent C also "
            "reported; section 7 says why the verdict uses cross-fitted C |",
            "| Bootstrap | 1,000 subject resamples, 95% percentile intervals. Models fixed: each resample refits the "
            "Cox model for the HR and recomputes C on the fixed out-of-fold predictors (the option the task "
            "allowed). Same resamples for every model on the same subjects, so model differences are paired |",
            "| T2 comparison with EVA's KDM | Point estimates on the intersection of subjects; the Base model against "
            "EVA's KDM on Base Panel markers (like for like); paired bootstrap differences reported |",
            "| T3 Gompertz 10-year calibration slope | Coefficient of ln(−ln(1 − predicted 10-year mortality)) in a Cox "
            "model of observed survival (van Houwelingen; Royston and Altman). Horizon-free for a proportional-hazards "
            "Gompertz model, which matters because wave 5 has at most 109 months of follow-up |",
            "| T3 and T8 over tiers | Neither names the Base model, so every tier is judged on the subjects with its "
            "markers and all must pass (an interpretation; see section 10) |",
            "| Typical profiles (T5, T6, T7, T9) | Medians of included validation adults aged 40-59 by sex, per marker "
            f"(fasting markers from the fasting subsample); age = their median age, {prof['1']['age']:.0f} in men and "
            f"{prof['2']['age']:.0f} in women |",
            "| T5 | Other markers at the typical profile; the marker moved from its sex-specific validation median to "
            "its adverse 97.5th percentile (2.5th where lower is adverse), and from P1 to P99. The adverse direction "
            "comes from the charter's direction table. For comparator inputs not in the table: serum glucose follows "
            "fasting glucose; systolic pressure is assumed \"higher\" (BioAge KDM only) |",
            "| T6 | 50 equal steps from the start to the optimal bound, each step at most 1e-9 years older. Start = "
            "reference limit, else the sex-specific validation P1 or P99. A reference lower limit of 0 is EVA's way "
            "of writing \"no limit\" and is treated as absent. A side whose start is inside the band, or equal to the "
            "bound, is not tested |",
            "| T6 without bounds | Lymphocyte % (white-cell percentages have no bounds, Gate 1 decision W1), cystatin "
            "C (no seed row) and systolic pressure are listed as untestable in every result. The verdict covers the "
            "markers with bounds |",
            "| T7 | Every model marker with a CV in `cv.json` varied together: x·exp(z·σ), σ = √(CVi² + 3²)/100. CRP "
            "then capped at 10 mg/L (charter). 4,000 draws per sex, same draws for every model. Reliable change = "
            "1.96·√2·SD. Markers without a CV in `cv.json` (HbA1c, glucose, blood count, cystatin C) are held fixed "
            "and listed; only the Base model has a T7 threshold |",
            "| T9 | Creatinine ×1.05, albumin ×0.97, CRP ×1.25, one at a time on the typical profiles, per tier |",
            "| T10 | Two builds from the raw files in fresh processes; the artifact and the predictions (train and "
            "validation, every tier) are hashed. `run_baselines.py` is the one command for comparator results; two "
            "full runs are compared in section 6 |",
            "",
            "**Checks on the harness itself.**",
            f"- The numpy Cox model matches lifelines to {sc['cox_max_abs_coef_diff']:.0e} in coefficients and "
            f"{sc['cox_max_abs_se_diff']:.0e} in standard errors.",
            f"- Harrell's C matches lifelines exactly ({sc['c_ours']:.10f} and {sc['c_lifelines']:.10f}), including "
            f"tied risks and weighted against expanded resamples ({sc['c_weighted']:.10f} and "
            f"{sc['c_expanded_lifelines']:.10f}).",
            f"- `eva_bounds.json` regenerates identically ({b['harness_checks']['eva_bounds_regenerated_identical']}).",
            f"- The EVA unit check reports {b['harness_checks']['eva_units']['verdict']}; the NHANES unit check reports "
            f"{b['harness_checks']['nhanes_units']['verdict']}.",
            "",
            "**EVA bounds.** `harness/eva_bounds.json` holds, for each candidate marker, EVA's reference and optimal "
            "bounds converted to NHANES units, with the seed row each comes from:",
            "- rows are read as the seeder reads them: the key is the slug of the English name, and a duplicate keeps "
            "its last occurrence (hs-CRP, row 31);",
            "- sex-specific rows are kept per sex;",
            "- no candidate marker has age-banded rows (eGFR does and is not a candidate); the 40-59 band would be "
            "used.",
            "",
        )

    def comparators_section(self):
        b = self.b
        pk, pp = b["models"]["kdm_bioage"]["parameters"], b["models"]["kdm_bioage_pinned_s2"]["parameters"]
        inert = b["eva_kdm_extra_markers_inert"]
        br = b["eva_kdm_bridge_vs_numbers_md"]
        man = br["panels"][0]
        fev_n = next(r["n"] for r in b["harness_checks"]["nhanes_units"]["by_split"]["validation"]
                     if r["check"].startswith("fev_1000"))
        self.add(
            "## 5. Comparators",
            "",
            "- **Age and sex only.** Biological age = age. It is the reference for the C-statistic gain; it has no "
            "hazard ratio.",
            "- **Original PhenoAge.** BioAge's constants, CRP as ln(1 + CRP), which is the T1-verified form. The "
            "ln(CRP) variant is reported beside it and marked unverified. The 10-year mortality function is Levine's "
            "`m_orig`, used by T3.",
            "- **BioAge KDM.** Line-by-line port of `kdm_calc` with s_ba2 = s2 − s_r (Levine 2013, equation 5).",
            "  - Training follows `kdm_nhanes`; the markers are BioAge's README set for NHANES IV: albumin, ALP, lncrp, "
            "total cholesterol, lncreat, HbA1c, systolic pressure, BUN, uric acid, lymphocyte %, MCV, WBC.",
            f"  - Primary version: the kdm0 recipe (s_ba2 men {pk['male']['s_ba2']:.1f}, women "
            f"{pk['female']['s_ba2']:.1f}).",
            f"  - Sensitivity version: the pinned single call (s_ba2 men {pp['male']['s_ba2']:,.0f}, women "
            f"{pp['female']['s_ba2']:,.0f}).",
            f"  - The original kdm0 markers cannot be used on validation: validation has {fev_n} FEV1 values.",
            "- **EVA KDM v2.2 Reference BA.** `computeReferenceBA` from `src/lib/biomarkers/biological-age-kdm.ts`, "
            "unchanged, run with `npx tsx`. Inputs are mapped to EVA keys and units.",
            "  - Default fructosamine policy (`hba1c_only`); no supplements recorded.",
            "  - **Base Panel markers**: albumin, creatinine, BUN, uric acid, ALP, GGT, total cholesterol, HDL, "
            "triglycerides, hs-CRP.",
            "  - **Every available marker**: the Base Panel markers plus HbA1c, which enters as fructosamine = "
            "19.97 × HbA1c − 39.4, and cystatin C, which makes production drop creatinine. Fasting glucose, "
            "lymphocyte %, MCV, RDW and WBC are sent as well; they cannot change the Reference BA (checked: "
            f"{inert['max_abs_difference_years']:.1f} years difference over {n(inert['n'])} subjects).",
            "  - Markers of the model's 14-marker base panel that the BioAge NHANES files do not contain: **ferritin, "
            "vitamin D (25-OH), TSH**, and measured fructosamine (HbA1c stands in for it).",
            f"  - Bridge check: it reproduces all {2 * len(br['panels'])} Reference BAs of NUMBERS.md section C (seven "
            f"synthetic panels, full and Base Panel) to the printed decimal ({br['verdict']}). The Base Panel "
            f"synthetic man of 45 gives {man['ours_base_panel']:.1f} years, against {man['numbers_md_base_panel']:.1f} "
            "printed.",
            "",
        )

    def results_section(self):
        b = self.b
        A, B = b["outcome_tests"]["allcause|A"], b["outcome_tests"]["allcause|B"]
        dA = A["phenoage_bioage"]["T2"]["result"]["deaths"]
        dB = B["phenoage_bioage"]["T2"]["result"]["deaths"]
        self.add(
            "## 6. Every validation-stage test on every comparator",
            "",
            "All values are on validation.",
            f"- **Cohort A**, n = {n(b['cohort_sizes']['A'])} ({n(dA)} all-cause deaths): subjects for whom every "
            "comparator gives a result.",
            f"- **Cohort B**, n = {n(b['cohort_sizes']['B'])} ({n(dB)} deaths): cohort A with all nine Base "
            "candidate markers, including GGT. GGT exists only in waves 2 (partly), 3 and 4.",
            "",
            "T2, T3 and T8 are previews here, because their verdicts belong to the sealed test. The T2 verdict "
            "combines three criteria: HR lower bound ≥ 1.20, C gain > 0 with its CI excluding 0, and at least EVA's "
            "KDM (Base Panel) on the same subjects.",
            "",
            "**All-cause mortality, cohort A.**",
            "",
            "| Comparator | HR per SD (95% CI) | C gain (95% CI) | T2 | T3 (mean gap; slope; Gompertz slope) | T8 |",
            "|---|---|---|---|---|---|",
        )
        for label in COMPARATOR_ROWS:
            r = A[label]
            t2 = r["T2"]["result"]
            if t2.get("hr_per_sd") is None:
                self.add(f"| {LABELS[label]} | reference (C = {t2['c_age_sex']:.4f}) | reference | reference | pass (by "
                         "construction) | n/a |")
                continue
            self.add(f"| {LABELS[label]} | {t2['hr_per_sd']:.3f} ({ci(t2['hr_ci_bootstrap'])}) | {t2['c_gain']:.4f} "
                     f"({ci(t2['c_gain_ci_bootstrap'], 4)}) | {self.failing_criteria(r)} | {self.t3_cell(r)} | "
                     f"{self.t8_cell(r)} |")
        self.add(
            "",
            "**All-cause mortality, cohort B**, the subjects a nine-marker Base model would be judged on.",
            "",
            "| Comparator | HR per SD (95% CI) | C gain (95% CI) | T2 | T3 (mean gap; slope; Gompertz slope) | T8 |",
            "|---|---|---|---|---|---|",
        )
        for label in COMPARATOR_ROWS[1:]:
            r = B[label]
            t2 = r["T2"]["result"]
            self.add(f"| {LABELS[label]} | {t2['hr_per_sd']:.3f} ({ci(t2['hr_ci_bootstrap'])}) | {t2['c_gain']:.4f} "
                     f"({ci(t2['c_gain_ci_bootstrap'], 4)}) | {self.failing_criteria(r)} | {self.t3_cell(r)} | "
                     f"{self.t8_cell(r)} |")
        eB = B["eva_kdm_v22_base_panel"]["T2"]["result"]
        pdA = A["phenoage_bioage"]["T2"]["vs_eva_kdm_base_panel"]["paired_difference"]
        t3 = A["phenoage_bioage"]["T3"]
        diag = t3["diagnostic_band_gaps_after_one_intercept"]
        worst_band = max(diag, key=lambda k: abs(diag[k]))
        g = t3["gompertz_10y"]
        S = b["outcome_tests"]["bioage_status|A"]
        sens = {k: S[k]["T2"]["result"]["hr_per_sd"] for k in ("phenoage_bioage", "kdm_bioage", "eva_kdm_v22_base_panel")}
        t8e = S["eva_kdm_v22_base_panel"]["T8"]
        t8bad = [(k, v["hr_ci_bootstrap"][0]) for k, v in t8e["groups"].items() if v["verdict"] == "fail"]
        sens_line = (f"PhenoAge {sens['phenoage_bioage']:.3f}, BioAge KDM {sens['kdm_bioage']:.3f}, EVA KDM Base "
                     f"Panel {sens['eva_kdm_v22_base_panel']:.3f}.")
        if t8bad:
            sens_line += (f" EVA KDM (Base Panel) then also fails T8: its lower bound at "
                          f"{t8bad[0][0].replace('ages ', 'ages ')} is {t8bad[0][1]:.3f}.")
        self.add(
            "",
            "**What the numbers say.**",
            f"- **What the Base model must beat.** In cohort B, T2 requires the Base model to reach at least HR "
            f"{eB['hr_per_sd']:.3f} and a C gain of {eB['c_gain']:.4f}. Its own HR lower bound must also be ≥ 1.20.",
            f"- **PhenoAge against EVA's KDM, same subjects** (paired bootstrap, cohort A): "
            f"{signed(pdA['hr_difference'], 3)} in HR ({ci(pdA['hr_difference_ci_bootstrap'], 3)}) and "
            f"{signed(pdA['c_gain_difference'], 4)} in C gain ({ci(pdA['c_gain_difference_ci_bootstrap'], 4)}).",
            "- **Calibration of PhenoAge.**",
            f"  - After one validation intercept, its sex-by-age band gaps range from {minus(f'{min(diag.values()):.2f}')} to "
            f"{signed(max(diag.values()))} years. That fails T3's ±1.5 for {worst_band.replace('male', 'men').replace('femen', 'women')}, so "
            "an intercept alone would not calibrate it.",
            f"  - It predicts {pct(g['mean_predicted_10y_mortality'])} 10-year mortality against "
            f"{pct(g['observed_10y_mortality_km'])} observed (Kaplan-Meier, cohort A). Its Gompertz calibration slope "
            f"of {g['calibration_slope']:.3f} misses the 0.8-1.2 range.",
            f"- **Sensitivity outcome (BioAge `status`, cohort A).** The HRs barely change: {sens_line}",
            "",
        )
        self.profile_table()

    def profile_table(self):
        pt = self.b["profile_tests"]
        self.add(
            "**Profile tests, composition and reproducibility** (outcome-independent). Each cell gives the verdict "
            "and its key number.",
            "",
            "| Comparator | T4 panel composition | T5 information | T6 perverse incentive | T7 noise, SD men / women (base "
            "tier) | T9 assay | T10 |",
            "|---|---|---|---|---|---|---|",
        )
        for key in ("age_sex", "phenoage_bioage", "phenoage_ln_crp", "kdm_bioage", "kdm_bioage_pinned_s2", "eva_kdm_v22"):
            e = pt[key]
            if e["T5"]["verdict"] == "n/a":
                self.add(f"| {LABELS[key]} | n/a | n/a (no markers) | n/a | n/a | n/a | {e['T10']['verdict']} |")
                continue
            # T4
            if e["T4"]["verdict"] == "n/a":
                t4 = "n/a"
            else:
                r = e["T4"]["tiers"]["all_available"]
                bands = [v["mean_diff"] for v in r["by_sex_age_band"].values()]
                t4 = (f"{e['T4']['verdict']}: Base Panel reads {r['mean_base_minus_extended']:.2f} y older than every "
                      f"marker (bands {min(bands):.2f} to {max(bands):.2f})")
            # T5
            items = []
            for tier, tr in e["T5"]["tiers"].items():
                for m in tr["markers"]:
                    if m["range_verdict"] == "fail":
                        items.append((m["effect_p1_to_p99_years"], f"{m['marker']} P1-P99 {m['effect_p1_to_p99_years']:.1f} y "
                                      f"({SEX[m['sex']]}{'' if tier == 'base' else ', ' + tier})"))
                    if m["older_verdict"] == "fail":
                        eff = minus(f"{m['effect_years']:+.2f}")
                        where = SEX[m["sex"]] + ("" if tier == "base" else f", {tier}")
                        items.append((100 + abs(m["effect_years"] or 0), f"{m['marker']} {eff} y when adverse ({where})"))
            ranges = sorted((x for x in items if x[0] < 100), key=lambda t: -t[0])
            directions = sorted((x for x in items if x[0] >= 100), key=lambda t: -t[0])
            shown = ranges[:3] + directions[:3]
            rest = len(items) - len(shown)
            t5 = f"{e['T5']['verdict']}: " + "; ".join(x for _, x in shown) + (f"; {rest} more" if rest > 0 else "")
            # T6
            sides = [s for tr in e["T6"]["tiers"].values() for s in tr["sides"] if s["verdict"] == "fail"]
            uniq = sorted({(s["marker"], s["side"]) for s in sides})
            untest = sorted({u["marker"] for tr in e["T6"]["tiers"].values() for u in tr["untestable"]})
            t6 = (f"{e['T6']['verdict']}: {len(sides)} failing sides ("
                  + ", ".join(f"{m} {s}" for m, s in uniq) + ")"
                  + (f"; untestable: {', '.join(untest)}" if untest else ""))
            # T7
            bt = e["T7"]["tiers"]["base"]
            t7 = (f"{e['T7']['verdict']}: {bt['by_sex']['male']['sd_years']:.2f} / {bt['by_sex']['female']['sd_years']:.2f} y "
                  f"(reliable change {bt['by_sex']['male']['reliable_change_95_years']:.1f} / "
                  f"{bt['by_sex']['female']['reliable_change_95_years']:.1f})")
            if bt["held_fixed_no_cv"]:
                t7 += f"; held fixed: {', '.join(bt['held_fixed_no_cv'])}"
            # T9
            worst = max((s for tr in e["T9"]["tiers"].values() for s in tr["shifts"]), key=lambda s: abs(s["shift_years"]))
            t9 = f"{e['T9']['verdict']}: largest {worst['change']} {abs(worst['shift_years']):.2f} y ({SEX[worst['sex']]})"
            self.add(f"| {LABELS[key]} | {t4} | {t5} | {t6} | {t7} | {t9} | {e['T10']['verdict']} |")
        rep = self.rep
        self.add("")
        if rep:
            same = "byte-identical" if rep["identical"] else "NOT identical"
            self.add(f"**Reproducibility of this report.** `run_baselines.py` was run twice, with "
                     f"{rep['run_a']['label']} and with {rep['run_b']['label']}. The two `baselines.json` files are "
                     f"{same} (SHA-256 `{rep['run_a']['sha256']}`).")
        else:
            self.add("**Reproducibility of this report.** Not yet compared (run `harness/compare_runs.py`).")
        self.add("")

    def tests_of_tests(self):
        t = self.b["tests_of_tests"]
        rs = t["random_score_fails_T2"]
        fam = t["random_score_family"]
        fix = t["c_gain_fix"]
        f5, f6 = t["crp_flipped_fails_T5"], t["crp_flipped_fails_T6"]
        eff = {e["sex"]: e["effect_years"] for e in f5["flipped_crp"]}
        side = {e["sex"]: e for e in f6["flipped_crp"] if e["verdict"] == "fail"}
        s_any = next(iter(side.values()))
        rows = fix["rows"]
        app_pass = [k for k, v in rows.items() if v["apparent"].get("c_gain_criterion_would_pass")]
        ex = rows[app_pass[0]] if app_pass else None
        S = self.b["outcome_tests"]["bioage_status|A"]["random_score"]["T2"]["result"]
        self.add(
            "## 7. Tests of the tests (charter section 6)",
            "",
            "| Test of the test | Outcome |",
            "|---|---|",
            f"| A random score fails T2 | **{rs['verdict'].capitalize()}.** HR {rs['random_score_hr']:.3f} "
            f"({ci(rs['random_score_hr_ci'])}), C gain CI {ci(rs['random_score_c_gain_ci'], 4)}; all three T2 "
            "criteria fail. The original PhenoAge passes the same criteria on the same subjects |",
            f"| {fam['k']} further independent random scores (added for specificity) | "
            f"**{'Pass' if fam['fail_T2'] == fam['k'] else 'Fail'}.** {fam['fail_T2']} of {fam['k']} fail T2. "
            f"{fam['pass_hr_criterion']} pass the HR criterion (HRs {fam['hr_range'][0]:.3f} to "
            f"{fam['hr_range'][1]:.3f}, largest lower bound {fam['largest_hr_lower_bound']:.3f}). "
            f"{fam['pass_c_gain_criterion']} pass the C-gain criterion (largest lower bound "
            f"{minus(format(fam['largest_c_gain_lower_bound'], '.5f'))}) |",
            f"| PhenoAge with the CRP sign flipped fails T5 | **{f5['verdict'].capitalize()}.** Moving CRP from its "
            f"median to its adverse 97.5th percentile makes it {abs(eff['male']):.2f} y (men) and "
            f"{abs(eff['female']):.2f} y (women) *younger*. The original PhenoAge's CRP passes |",
            f"| The same model fails T6 | **{f6['verdict'].capitalize()}.** Moving CRP from {10 * s_any['start']:g} to "
            f"{10 * s_any['optimal_bound']:g} mg/L (EVA's reference limit to its optimal bound) makes it "
            f"{s_any['change_years']:.2f} y *older*. The original's CRP sides pass |",
            "| EVA's current KDM through every test | Done; results in section 6, reported as they are |",
            "",
            "**Why T2's C-statistic gain is cross-fitted.** This is the one change the tests of the tests prompted. "
            "It changed the implementation, not the threshold.",
            "- The first version used apparent C: the Cox model was refitted in each bootstrap resample and C was "
            "computed on that same resample. That scores coefficients on the data they were fitted on, which biases "
            "the gain upward (optimism), most visibly for a score that carries no information.",
            "- In a 20-resample trial, apparent C let a random score pass the C-gain criterion "
            "(`run_baselines.py --n-boot 20` reproduces it). The HR criterion, which this choice does not affect, "
            "still rejected it. T2 now computes C from 10-fold cross-fitted linear predictors, so no coefficient is "
            "scored on data it was fitted on.",
        )
        judged = (f"- At the charter's {n(self.b['n_boot'])} resamples, `run_baselines.py` judges the same "
                  f"{fix['random_scores_judged']} random-score evaluations both ways: "
                  f"{fix['would_pass_c_gain_criterion_with_apparent_c']} pass the C-gain criterion with apparent C "
                  f"and {fix['pass_c_gain_criterion_with_cross_fitted_c']} with cross-fitted C.")
        margin = (f"the largest lower bound is {minus(format(fix['apparent_largest_lower_bound'], '.6f'))} against "
                  f"{minus(format(fix['cross_fitted_largest_lower_bound'], '.6f'))}, and the mean upper bound "
                  f"{fix['apparent_mean_upper_bound']:.6f} against {fix['cross_fitted_mean_upper_bound']:.6f}.")
        if fix["would_pass_c_gain_criterion_with_apparent_c"] == 0:
            self.add(f"{judged} So at full size apparent C rejects them too, with less margin: {margin}")
        else:
            self.add(f"{judged} Apparent against cross-fitted C: {margin}")
        if ex:
            self.add(f"- Example (`{app_pass[0]}`): apparent gain {ex['apparent']['c_gain_apparent']:.4f} "
                     f"({ci(ex['apparent']['c_gain_apparent_ci_bootstrap'], 4)}) against cross-fitted "
                     f"{minus(format(ex['cross_fitted']['c_gain'], '.4f'))} ({ci(ex['cross_fitted']['ci'], 4)}).")
        gaps = [r["c_full_apparent"] - r["c_age_sex_apparent"] - r["c_gain"]
                for models in self.b["outcome_tests"].values() for m, rr in models.items() if m in COMPARATOR_ROWS
                for r in [rr["T2"]["result"]] if r.get("c_full_apparent") is not None]
        self.add(f"- For the comparators, the full-sample apparent gain minus the cross-fitted gain ranges from "
                 f"{signed(min(gaps), 5)} to {signed(max(gaps), 5)} (both values are in every T2 result). "
                 "Cross-fitting removes almost nothing from a real signal.")
        self.add(
            "",
            "A random score can still show a hazard ratio away from 1 by chance. The primary random score gives "
            f"{S['hr_per_sd']:.3f} ({ci(S['hr_ci_bootstrap'])}) under the BioAge-status outcome, while the "
            f"{fam['k']} further scores span {fam['hr_range'][0]:.3f} to {fam['hr_range'][1]:.3f}. It fails T2 either "
            "way.",
            "",
        )

    def closing(self):
        dd = self.dd
        pr = dd["pilot_reconstruction"]
        impl = dd["t6_monotone_implications"]
        need = [e for e in impl if e["status"].startswith("a monotone effect needs")]
        cov = dd["coverage_by_wave"]["validation"]
        crp = dd["crp_detection"]
        lo3, lo4 = crp["train"]["min_mg_dl"], crp["validation"]["min_mg_dl"]
        gomp = self.b["outcome_tests"]["allcause|A"]["phenoage_bioage"]["T3"]["gompertz_10y"]["calibration_slope"]
        self.add(
            "## 8. What was looked at in the sealed split",
            "",
            "Before the seal existed (the first hour of this work), I read the whole NHANES IV file to learn its "
            "structure:",
            "- row counts per wave;",
            "- missingness per column;",
            "- the coding of `status` against the cause of death;",
            "- death counts per wave, and the age distribution.",
            "",
            "The orchestrator's brief had also given coverage notes by wave. I did not compute any association "
            "between a marker and an outcome in waves 5 to 8, and did not evaluate any model there. Every definition "
            "in section 2 was re-derived from the visible splits only, with `describe_data.py` and T0.",
            "",
            "Since then, test rows are read only for their IDs (the hash and T0's disjointness check). The Verifier "
            "should know this history.",
            "",
            "## 9. Not verified, or assumed",
            "",
            "1. BioAge's data-preparation code is not in the repository at the pinned commit. Every data definition "
            "in section 2 is inferred from the files: `time`, the `status` rule, the 240-month censoring, the `ln*` "
            "columns, creatinine recalibration, removed extremes. The rule that removed the extremes is unknown.",
            "2. The NHANES and NCHS codebooks could not be opened (cdc.gov is not reachable). Units are inferred from "
            "values and BioAge's derived columns. The meanings of UCOD_LEADING codes 1 to 10 are from NCHS "
            "documentation not re-read here.",
            "3. Levine et al. 2018 could not be opened. The ln(CRP) reading of the paper is unverified; the "
            "T1-verified PhenoAge uses BioAge's ln(1 + CRP).",
            "4. The pilot's code is not in the repository. Its samples are reproduced exactly from the data: "
            f"{n(pr['phenoage0_and_status_known'])} PhenoAge subjects with {n(pr['their_bioage_deaths'])} deaths, and "
            f"{n(pr['base8_no_ggt_and_status_known'])} with {n(pr['base8_their_bioage_deaths'])} for the eight markers "
            "without GGT. They are every validation row with the markers and a known `status`: no age limit "
            f"({pr['of_which_age_85_topcoded']} people top-coded at 85) and no pregnancy exclusion "
            f"({pr['of_which_pregnant']}).",
            "5. The fasting window of 8 to under 24 hours is the usual NHANES fasting-subsample window. It was not "
            "checked against the codebook, and some cycles use 8.5 hours.",
            "6. Ethnicity labels are inferred (section 2.3). The test split's top-coding at 80 and its CRP gap in "
            "waves 7 and 8 come from the brief and NHANES convention, not from reading those waves.",
            "7. Harness choices that the charter leaves open are listed in section 4. The calibration-slope method "
            "(van Houwelingen; Royston and Altman) and the combined CV for T7 are standard, but those papers were not "
            "opened here.",
            "8. Systolic pressure's adverse direction (\"higher\") is a harness assumption for the BioAge KDM "
            "comparator; it is not in the charter's table.",
            "",
            "## 10. What the Modeler needs to know",
            "",
            "**Decisions to confirm before modeling.**",
            "- **The outcome.** The harness default is all-cause mortality. The charter's thresholds were informed "
            "by a pilot that used BioAge's cause-restricted `status` without the inclusion rules.",
            "- **Two interpretations of mine.**",
            "  - T3 and T8 must pass in every tier.",
            "  - T2's comparison uses EVA's KDM on the Base Panel.",
            "",
            "**Data.**",
            f"- **CRP differs between training and validation.** It is censored at {crp['train']['min_mg_dl']:.2f} "
            f"mg/dL in NHANES III ({pct(crp['train']['share_at_min'], 0)} of subjects at the limit) and continuous "
            f"down to {crp['validation']['min_mg_dl']:.2f} mg/dL in NHANES IV. A model fitted on NHANES III sees "
            f"{pct(crp['validation']['share_below_nhanes3_limit_0_21'], 0)} of validation below anything it was "
            "trained on. How much that matters depends on the transform: between those two limits ln(1 + CRP) "
            f"moves only from {math.log1p(lo4):.2f} to {math.log1p(lo3):.2f}, while ln(CRP) moves from "
            f"{minus(format(math.log(lo4), '.1f'))} to {minus(format(math.log(lo3), '.1f'))}. A model on ln(CRP) "
            "would extrapolate far below its training data. That bears on T3.",
            "- **Coverage limits the samples.**",
            f"  - GGT is present in {cov['1']['ggt']} validation wave 1 subjects and {cov['2']['ggt']} in wave 2, so a "
            f"nine-marker Base model is validated on about {n(dd['base9_complete']['validation'])} subjects.",
            f"  - Cystatin C exists only in waves 1 and 2 ({cov['1']['cystatin_c'] + cov['2']['cystatin_c']:,} "
            "subjects).",
            "  - Triglycerides exist only in the fasting subsample.",
            "  - In the sealed split, CRP is missing in waves 7 and 8 (brief), so a Base model that requires CRP is "
            "tested on waves 5 and 6 only unless a tier handles missing CRP.",
            "- **Units and transforms.** Use the analysis columns and their units, and compute every transform "
            "yourself: BioAge's `ln*` columns are ln(1 + x) and inconsistent.",
            "",
            "**What T6 will demand.** With EVA's bounds, a monotone marker effect in the charter's direction needs a "
            "credit limit at the optimal bound for:",
        )
        for e in need:
            unit = BY_COLUMN[e["marker"]].nhanes_unit.replace("10^3 cells/uL", "× 10³/µL")
            self.add(f"- {DISPLAY[e['marker']]} ({'men' if e['sex'] == 1 else 'women'}): {e['side']} side, from "
                     f"{e['start']:g} to {e['bound']:g} {unit}.")
        self.add(
            "",
            "What the charter already covers:",
            "- Section 4 pre-lists clamps for creatinine at the EVA optimal floor, BUN at 10 mg/dL, uric acid at "
            "3 mg/dL and albumin at 50 g/L.",
            "- Section 5's direction table forbids rewarding ALP below 40 U/L, HDL above 80 mg/dL, HbA1c below 4.5% "
            "and fasting glucose below 70 mg/dL. A limit of 80 mg/dL on HDL satisfies T6 in both sexes.",
            "",
            "What it does not cover: men's uric acid needs 4.0 mg/dL (not 3), MCV needs 82 fL and WBC needs 4.5 × "
            "10³/µL. Under section 4 each needs a written reason in `ATTEMPTS.md`. Every side is listed in "
            "`data_definitions.md`.",
            "",
            "**Other constraints from the results.**",
            "- `cv.json` has no CV for HbA1c, glucose, the blood count or cystatin C, so T7 holds them fixed. Only the "
            "Base model has a T7 threshold.",
            "- T5's 20-year cap on the 1st-to-99th percentile effect is already exceeded by the original PhenoAge for "
            "RDW and glucose.",
            f"- Even the original PhenoAge misses T3's Gompertz slope in validation ({gomp:.3f}). The calibration "
            "intercept must be set on validation.",
            "",
        )

    def render(self) -> str:
        self.header()
        self.data_section()
        self.units_section()
        self.reference_section()
        self.t1_section()
        self.harness_section()
        self.comparators_section()
        self.results_section()
        self.tests_of_tests()
        self.closing()
        return "\n".join(self.L)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=str(HARNESS / "results"))
    ap.add_argument("--out", default=str(HARNESS.parent / "REPORT-baselines.md"))
    args = ap.parse_args()
    res = Path(args.results)
    b = json.loads((res / "baselines.json").read_text(encoding="utf-8"))
    dd = json.loads((res / "data_definitions.json").read_text(encoding="utf-8"))
    rp = res / "reproducibility.json"
    rep = json.loads(rp.read_text(encoding="utf-8")) if rp.exists() else None
    thr = json.loads((HARNESS / "thresholds.json").read_text(encoding="utf-8"))
    text = Report(b, dd, rep, thr).render()
    Path(args.out).write_text(text, encoding="utf-8")
    print(f"wrote {args.out} ({len(text.splitlines())} lines)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
