"""Self-test of the final-test budget rules on a temporary log. Never touches harness/final_test_log.jsonl and never
runs the final test. Usage: .venv/bin/python harness/selftest_final_test_budget.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from final_test_budget import BudgetError, append, next_run, read_log  # noqa: E402


def expect_refusal(records, fix, label):
    try:
        next_run(records, fix)
    except BudgetError as e:
        return f"{label}: refused as expected ({e})"
    raise AssertionError(f"{label}: NOT refused")


def main() -> int:
    lines = []
    with tempfile.TemporaryDirectory() as tmp:
        log = Path(tmp) / "log.jsonl"
        assert next_run(read_log(log), None) == 1
        lines.append("empty log: run 1 allowed")
        append(log, {"event": "start", "run": 1})
        lines.append(expect_refusal(read_log(log), None, "run 1 crashed, no diagnosed fix"))
        assert next_run(read_log(log), "fix: ...") == 2
        lines.append("run 1 crashed, diagnosed fix given: run 2 allowed")
        append(log, {"event": "complete", "run": 1, "all_test_stage_tests_pass": True})
        lines.append(expect_refusal(read_log(log), "fix", "run 1 passed"))
        log.write_text("")
        append(log, {"event": "start", "run": 1})
        append(log, {"event": "complete", "run": 1, "all_test_stage_tests_pass": False})
        assert next_run(read_log(log), "diagnosed: ...") == 2
        lines.append("run 1 failed, diagnosed fix given: run 2 allowed")
        append(log, {"event": "start", "run": 2})
        lines.append(expect_refusal(read_log(log), "another fix", "third run"))
    print("\n".join(lines))
    print("final-test budget self-test: pass")
    return 0


if __name__ == "__main__":
    sys.exit(main())
