"""Harness self-check: the numpy Cox (Efron ties) and Harrell's C against lifelines 0.30.3 on real validation data.

Run by run_validation.py and run_baselines.py; the numbers go into their output. Fails if the Cox coefficients
differ by more than 1e-6 or C by more than 1e-12, or if weighted C (bootstrap counts) differs from C on the
expanded rows.
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline import data  # noqa: E402
from pipeline.survival import bootstrap_counts, cox_efron, harrell_c  # noqa: E402


def run() -> dict:
    from lifelines import CoxPHFitter
    from lifelines.utils import concordance_index

    v = data.load_split("validation").df.dropna(subset=["albumin", "crp"])
    X = np.column_stack([v["albumin"], np.log(v["crp"]), v["age"], v["female"]])
    t, e = v["time"].to_numpy(float), v["event"].to_numpy(float)
    ours = cox_efron(t, e, X)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        cph = CoxPHFitter().fit(pd.DataFrame(X, columns=list("abcd")).assign(T=t, E=e), "T", "E")
    lp = X @ ours.beta
    c_ours, c_ll = harrell_c(t, e, lp), concordance_index(t, -lp, e)
    counts = next(bootstrap_counts(len(t), 1, 11))
    idx = np.repeat(np.arange(len(t)), counts)
    c_w, c_x = harrell_c(t, e, lp, weights=counts), concordance_index(t[idx], -lp[idx], e[idx])
    out = {
        "n": int(len(t)), "deaths": int(e.sum()),
        "cox_max_abs_coef_diff": float(np.max(np.abs(ours.beta - cph.params_.to_numpy()))),
        "cox_max_abs_se_diff": float(np.max(np.abs(ours.se - cph.standard_errors_.to_numpy()))),
        "cox_loglik_diff": float(ours.loglik - cph.log_likelihood_),
        "c_ours": c_ours, "c_lifelines": c_ll, "c_weighted": c_w, "c_expanded_lifelines": c_x,
    }
    ok = (out["cox_max_abs_coef_diff"] < 1e-6 and abs(c_ours - c_ll) < 1e-12 and abs(c_w - c_x) < 1e-12)
    out["verdict"] = "pass" if ok else "fail"
    return out


if __name__ == "__main__":
    import json

    print(json.dumps(run(), indent=2))
