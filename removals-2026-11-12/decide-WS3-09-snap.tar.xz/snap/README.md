# EVA Health

Operations and onboarding guide for the EVA Health web application.

EVA Health, S.L. is a Spanish preventative-health startup. The platform takes lab
panels and wearable data, runs them through an AI interpretation pipeline, and
delivers biological-age and biomarker insights to users. It therefore processes
**special-category health data** under GDPR — treat every environment, secret,
and database with that in mind. Compliance and operational context lives under
[`docs/audit/`](docs/audit/).

---

## ⚠️ This is NOT the Next.js you know — read before writing code

This repo runs on a **customized fork of Next.js 16.2.1**. APIs, conventions, and
file structure differ from upstream Next.js and from anything in your memory or
training data. Two rules for every engineer (and every AI agent) touching code:

1. **Middleware is renamed `proxy`.** The edge middleware lives in
   [`src/proxy.ts`](src/proxy.ts) — *not* `middleware.ts`. It wires the beta
   gate, security headers (CSP), rate limiting, locale handling, and admin
   routing. In this fork `proxy` is a first-class file convention (see
   `node_modules/next/dist/docs/01-app/01-getting-started/16-proxy.md` and
   `.../01-app/03-api-reference/03-file-conventions/proxy.md`).
2. **Read the bundled docs first.** Per [`AGENTS.md`](AGENTS.md), before writing
   any Next.js code you must read the relevant guide under
   `node_modules/next/dist/docs/` and heed its deprecation notices. Do not assume
   upstream behavior.

---

## Architecture

- **Framework:** Next.js 16.2.1 (customized fork), React 19, App Router,
  TypeScript, Tailwind CSS v4.
- **Routing / i18n:** App Router under [`src/app/[locale]/`](src/app). Locale is
  the first path segment (`es` / `en`), handled by `src/proxy.ts` and
  `next-intl`. Route groups:
  - `(marketing)` — public marketing + legal pages
  - `(auth)` — sign-up / sign-in
  - `(dashboard)` — authenticated user app (lab results, biomarkers, AI chat)
  - `(admin)` — admin-only surfaces (gated by `is_admin`, see below)
  - plus `beta/` (pre-launch gate) and `checkout-resume/`
- **API:** Route handlers under [`src/app/api/`](src/app/api) — `ai`, `stripe`,
  `lab-results`, `wearables`, `gdpr`, `emails`, `cron`, `admin`, etc.
- **Database / auth:** Supabase (Postgres 17) in the **EU `eu-west-1`** region
  (prod project ref `injlkejrcxdejsijkyff`). Auth + Row-Level Security (RLS) are
  the primary access controls. The browser uses the **anon** key (RLS-scoped);
  server code uses the **service-role** key (bypasses RLS) only where required —
  Stripe webhook, cron, and AI-prompt management.
- **AI pipeline:** Google **Gemini** via the `@google/genai` SDK. Uploaded lab
  PDFs are parsed/extracted, biomarkers are computed (biological-age / KDM
  engine in `src/lib/biomarkers/`), and interpretations are generated and
  delivered. The "context-needed" flow has a 72-hour fallback driven by a daily
  cron (below). *Note: code calls Gemini; some older docs still reference
  Anthropic — `.env.example` and this file are authoritative.*
- **Billing:** Stripe (quarterly subscription + one-time full-panel). Checkout is
  server-driven; entitlements are written by the Stripe webhook using the
  service-role client (a DB trigger blocks users from self-editing billing
  columns).
- **Email:** Resend (transactional email).
- **Scheduled jobs:** Vercel Cron runs `GET /api/cron/auto-resolve-pending-context`
  daily at `03:00` (see [`vercel.json`](vercel.json)). It emits structured
  `[ALERT]` / `[OK]` log lines plus a backlog signal for monitoring (OPS-010).
- **Rate limiting:** Upstash Redis, configured in `src/proxy.ts`. **Fails open**
  (no throttling) until `UPSTASH_REDIS_REST_*` are set — see the access &
  secrets runbook.
- **Lab kit / partners:** Tasso collection kit; candidate labs Echevarne /
  Eurofins (not yet contracted).

---

## Local setup

Requirements: Node.js 20+ and npm.

```bash
# 1. Install dependencies (clean, lockfile-faithful install)
npm ci

# 2. Configure environment
cp .env.example .env.local
#    then fill in real values — see "Environment variables" below

# 3. Run the dev server
npm run dev
```

The app runs at <http://localhost:3000>. With `BETA_GATE_ENABLED=true` you'll hit
the beta gate first (`BETA_ACCESS_PASSWORD`).

---

## Scripts

| Script              | What it does                                              |
| ------------------- | -------------------------------------------------------- |
| `npm run dev`       | Start the dev server (Next.js fork).                     |
| `npm run build`     | Production build (`next build`).                          |
| `npm run start`     | Serve the production build (`next start`).                |
| `npm run lint`      | ESLint. *Advisory in CI today — see the deploy section.* |
| `npm run typecheck` | `tsc --noEmit` — blocking in CI.                          |
| `npm test`          | Run the Vitest suite once (`vitest run`) — blocking in CI.|
| `npm run seed`      | Seed biomarker reference data (`tsx supabase/seed.ts`).  |

---

## Environment variables

All required variables (names, grouping, and inline notes) are documented in
**[`.env.example`](.env.example)** — copy it to `.env.local` for local dev. **Do
not** list real values here or commit them; `.gitignore` ignores every `.env*`
file, and production values live **only** in the Vercel project env (scoped per
environment). The rotation policy and owners are in the
[access & secrets runbook](docs/runbooks/access-and-secrets.md).

At a glance:

- **Public (browser bundle, never secret):** `NEXT_PUBLIC_SUPABASE_URL`,
  `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_APP_URL`,
  `NEXT_PUBLIC_PLAUSIBLE_DOMAIN`.
- **Server (secret):** `SUPABASE_SERVICE_ROLE_KEY`, `GEMINI_API_KEY`,
  `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_ID_QUARTERLY`,
  `STRIPE_PRICE_ID_FULL_PANEL`, `RESEND_API_KEY`, `CRON_SECRET`,
  `LAB_WEBHOOK_SECRET`, `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`,
  `BETA_GATE_ENABLED`, `BETA_ACCESS_PASSWORD`, `ADMIN_EMAILS`.

`SUPABASE_SERVICE_ROLE_KEY` bypasses RLS and can read/write **all** patient
health data — treat it as the most sensitive secret in the system.

---

## Deploy

- **Host:** Vercel (Vercel Inc., US company; EU edge region `cdg1` = Paris, set
  in [`vercel.json`](vercel.json)). Deploys run from the Git integration.
- **CI gate:** [`.github/workflows/ci.yml`](.github/workflows/ci.yml) runs on
  every PR and on pushes to `main`: **typecheck → test → build are blocking**;
  ESLint is currently **advisory** (the tree carries pre-existing lint errors —
  flip it to blocking once cleared). Keep the default branch protected so these
  checks must pass before merge.
- **Secrets:** set all server vars in **Vercel → Project → Settings →
  Environment Variables**, scoped per environment. Some features stay inert until
  their secret is set (rate limiting, cron, lab webhook) — see
  [`docs/audit/OPERATOR-SETUP.md`](docs/audit/OPERATOR-SETUP.md).
- A longer step-by-step (domains, Stripe live mode, Resend DNS) lives in
  [`docs/deployment.md`](docs/deployment.md).

---

## Database & migration workflow

- Schema changes go through **committed migrations only** in
  [`supabase/migrations/`](supabase/migrations) — never ad-hoc SQL or dashboard
  edits against production. Apply them **staging-first**, then production.
- There is a known repo-vs-live migration drift (OPS-004). Before relying on the
  migration history, reconcile it using the
  [migration reconcile runbook](docs/runbooks/migration-reconcile.md).
- Seed reference data with `npm run seed`.

---

## Runbooks & operator docs

Operational procedures live in [`docs/runbooks/`](docs/runbooks):

- [Incident response](docs/runbooks/incident-response.md) — roles, severity,
  containment, post-mortem.
- [Breach notification](docs/runbooks/breach-notification.md) — GDPR Art. 33
  (72-hour AEPD) decision tree and templates.
- [Backup & restore](docs/runbooks/backup-and-restore.md) — PITR, RTO/RPO, and
  the restore drill.
- [Migration reconcile](docs/runbooks/migration-reconcile.md) — fixing the
  repo↔live schema drift and the going-forward process.
- [Access & secrets](docs/runbooks/access-and-secrets.md) — access matrix and the
  key-rotation policy.

For the gated, owner-executed launch actions (Vercel/Supabase/Stripe dashboard
steps, secrets, decommissioning), see
[`docs/audit/OPERATOR-SETUP.md`](docs/audit/OPERATOR-SETUP.md).
