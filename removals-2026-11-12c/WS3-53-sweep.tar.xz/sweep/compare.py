"""WS3-53 sweep: compare the base tree's outputs with the package's, case by case, and explain every difference.

Usage: python3 -I compare.py <base.jsonl> <current.jsonl>
Every difference is put in a named category; a difference no category explains is printed as UNEXPECTED.
"""
import json
import sys
from collections import Counter, defaultdict

EVA = {"echevarne", "lab_partner"}
KDM_COLUMNS = {"biological_age", "bio_age_method", "bio_age_n_markers", "bio_age_applied_spanish_calibration", "biological_age_comprehensive"}


def load(path):
    out = {}
    for line in open(path, encoding="utf8"):
        d = json.loads(line)
        out[(d["panel"], d["source"])] = d
    return out


def without(d, keys):
    return {k: v for k, v in d.items() if k not in keys}


def main(base_path, current_path):
    base, cur = load(base_path), load(current_path)
    assert base.keys() == cur.keys(), "the two runs hold different cases"
    cats = Counter()
    unexpected = []
    examples = defaultdict(list)
    panels = {p for p, _ in base}

    def note(cat, case, detail=""):
        cats[cat] += 1
        if len(examples[cat]) < 3:
            examples[cat].append(f"{case[0]} [{case[1]}] {detail}".strip())

    for case in sorted(base):
        b, c = base[case], cur[case]
        source = case[1]
        eva = source in EVA
        # 1. Classification, stored rows, score, metrics: never different.
        for field in ("processed", "inserted", "score", "scoreWithheld", "metrics"):
            if b[field] != c[field]:
                unexpected.append((case, field))
        # 2. The lab's update (processing and recompute): equal but for the KDM columns of a lab not from EVA's laboratory.
        for field in ("processUpdate", "recomputeUpdate"):
            if len(b[field]) != len(c[field]):
                unexpected.append((case, field + " count"))
                continue
            for ub, uc in zip(b[field], c[field]):
                if without(ub, KDM_COLUMNS) != without(uc, KDM_COLUMNS):
                    unexpected.append((case, field + " non-KDM"))
                kb, kc = {k: ub.get(k) for k in KDM_COLUMNS}, {k: uc.get(k) for k in KDM_COLUMNS}
                if kb == kc:
                    continue
                if not eva and all(v is None for v in kc.values()) and set(KDM_COLUMNS) <= set(uc):
                    note(f"{field}: KDM figure cleared for a lab not from EVA's laboratory", case, f"base biological_age {kb['biological_age']}")
                else:
                    unexpected.append((case, field + " KDM"))
        # 3. The answer: the score as before; the biological age and its difference none for another laboratory.
        ab, ac = b["answer"], c["answer"]
        if ab != ac:
            if (not eva and ab is not None and ac is None and ab.get("longevityScore") is None) or (
                not eva and ab is not None and ac is not None and without(ab, {"biologicalAge", "delta"}) == without(ac, {"biologicalAge", "delta"}) and ac["biologicalAge"] is None and ac["delta"] is None
            ):
                note("answer: no biological age for a lab not from EVA's laboratory (score unchanged)", case, f"base {ab.get('biologicalAge')}")
            elif not eva and ab is not None and ac is not None and ab.get("longevityScore") is None:
                unexpected.append((case, "answer"))
            else:
                unexpected.append((case, "answer"))
        if b["kdm"] != c["kdm"]:
            if not eva and c["kdm"] == {"reference": None, "comprehensive": None}:
                note("kdm: none for a lab not from EVA's laboratory", case)
            else:
                unexpected.append((case, "kdm"))
        # 4. Version 3's records of the lab: the adapter's version only.
        for field in ("processedV3", "recomputedV3"):
            if len(b[field]) != len(c[field]):
                unexpected.append((case, field + " count"))
                continue
            for rb, rc in zip(b[field], c[field]):
                if rb == rc:
                    continue
                if without(rb, {"adapter_version"}) == without(rc, {"adapter_version"}) and (rb.get("adapter_version"), rc.get("adapter_version")) == ("1.3.0", "1.4.0"):
                    note(f"{field}: adapter_version 1.3.0 -> 1.4.0 only", case)
                else:
                    unexpected.append((case, field))
        # 5. The rolling average over an EVA lab and a lab of this source: the other laboratory's lab no longer averaged.
        rb, rc = b["rolling"], c["rolling"]
        if rb != rc:
            if not eva and rb is not None and rb.get("n_labs_averaged") == 2 and (rc is None or (rc.get("n_labs_averaged") == 1 and rc.get("window_months") is None)):
                note("rolling: the other laboratory's lab is no longer averaged (EVA's lab alone)", case, f"base {rb.get('ba'):.2f} over 2 labs -> {('%.2f' % rc['ba']) if rc else None} over 1")
            elif not eva and rb is None and rc is None:
                pass
            else:
                unexpected.append((case, "rolling"))
        # 6. Version 3 on an EVA lab with an HbA1c only on a lab of this source, 20 days earlier.
        for variant in ("stored", "venous"):
            vb, vc = b["v3Mixed"][variant], c["v3Mixed"][variant]
            if vb == vc:
                continue
            diff = {k for k in set(vb) | set(vc) if vb.get(k) != vc.get(k)}
            if diff == {"adapter_version"}:
                note(f"v3Mixed {variant}: adapter_version only", case)
            elif not eva and vb.get("hba1c_source") == "other_result" and vc.get("hba1c_source") is None and "adapter_version" in diff:
                rest = diff - {"adapter_version", "hba1c_source", "hba1c_excluded_reason", "tier", "ba", "interval_low", "interval_high", "markers_used", "clamps_applied", "bounded_markers", "reason", "reasons", "crp_capped", "provisional"}
                if rest:
                    unexpected.append((case, f"v3Mixed {variant} {sorted(rest)}"))
                else:
                    note(f"v3Mixed {variant}: the other laboratory's HbA1c is not taken (hba1c_source other_result -> none)", case, f"tier {vb.get('tier')} -> {vc.get('tier')}, ba {vb.get('ba')} -> {vc.get('ba')}")
            else:
                unexpected.append((case, f"v3Mixed {variant} {sorted(diff)}"))

    print(f"cases: {len(base)} ({len(panels)} panels x {len(base) // max(1, len(panels))} sources)")
    for cat, n in sorted(cats.items()):
        print(f"  {n:6d}  {cat}")
        for e in examples[cat]:
            print(f"            e.g. {e}")
    by_source = Counter(case[1] for case, _ in unexpected)
    print(f"UNEXPECTED differences: {len(unexpected)} {dict(by_source)}")
    for case, field in unexpected[:40]:
        print(f"  UNEXPECTED {case} {field}")
    # Per source: how many cases differ at all.
    for source in sorted({s for _, s in base}):
        n = sum(1 for case in base if case[1] == source and base[case] != cur[case])
        print(f"  source {source}: {n} of {len(panels)} cases differ")
    return 1 if unexpected else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
