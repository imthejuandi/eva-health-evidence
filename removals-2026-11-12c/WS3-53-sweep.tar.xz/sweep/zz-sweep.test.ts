/**
 * WS3-53 sweep (scratch, not committed): the 42 personas and seeded panels through processing, the recompute, the
 * rolling average and version 3, under every lab_results.source, on a scripted database. Copied into a tree (the base
 * commit's or the package's) as src/zz-sweep.test.ts and run there; writes one JSON line per case to SWEEP_OUT.
 */
import fs from "node:fs";
import path from "node:path";
import { it, vi } from "vitest";

const shadow = vi.hoisted(() => ({ upserts: [] as Array<Record<string, unknown>> }));
vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => {
    throw new Error("the sweep passes its own client");
  },
}));
vi.mock("@/lib/supabase/admin", async () => {
  const { fakeSupabase } = await import("@/lib/testing/fake-supabase");
  return {
    createAdminClient: () =>
      fakeSupabase((c) => {
        if (c.ops[0]?.op === "upsert") shadow.upserts.push(c.ops[0].args[0] as Record<string, unknown>);
        return { data: null };
      }).client,
  };
});

import { argsOf, fakeSupabase, ops, type FakeCall, type FakeResponse } from "@/lib/testing/fake-supabase";
import { processLabResults, recomputeLabMetrics } from "@/lib/biomarkers/process-results";
import { computeRollingAverageBA } from "@/lib/biomarkers/rolling-average-ba";
import { bioAgeV3Record, loadBioAgeV3Sources } from "@/lib/biomarkers/biological-age-v3-adapter";
import { signedRows } from "@/lib/biomarkers/__tests__/fixtures/reviewed-rows";
import { getCanonicalUnit } from "@/lib/biomarkers/canonical-units";

const OUT = process.env.SWEEP_OUT as string;
const ROOT = process.cwd();
const ROWS = signedRows();
const SOURCES = ["echevarne", "lab_partner", "user_upload", "upload", "manual"];
const TODAY = "2026-11-12";
const shift = (date: string, days: number) => new Date(Date.parse(`${date}T00:00:00Z`) + days * 86_400_000).toISOString().slice(0, 10);

type Panel = { id: string; sex: "male" | "female"; age: number; values: Record<string, number> };

/** Deterministic random numbers (mulberry32). */
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function personas(): Panel[] {
  const doc = JSON.parse(fs.readFileSync(path.join(ROOT, "scripts/signoff/fixtures/personas.json"), "utf8")) as {
    personas: Array<{ id: string; sex: "male" | "female"; age: number; values: Record<string, number> }>;
  };
  return doc.personas.map((p) => ({ id: `persona:${p.id}`, sex: p.sex, age: p.age, values: p.values }));
}

/** Panels drawn around each marker's rows: a fifth of the values below the reference interval, a fifth above. */
function seeded(n: number): Panel[] {
  const random = rng(53);
  const keys = [...new Set(personas().flatMap((p) => Object.keys(p.values)))].filter((k) => getCanonicalUnit(k) !== null).sort();
  const out: Panel[] = [];
  for (let i = 0; i < n; i++) {
    const sex = random() < 0.5 ? "male" : "female";
    const age = 20 + Math.floor(random() * 65);
    const values: Record<string, number> = {};
    for (const key of keys) {
      if (random() < 0.15) continue; // not every panel holds every marker
      const row = ROWS.find((r) => r.biomarker_key === key && (r.sex === sex || r.sex === "both"));
      const lo = row?.normal_low ?? row?.optimal_low ?? null;
      const hi = row?.normal_high ?? row?.optimal_high ?? null;
      const mid = lo !== null && hi !== null ? (lo + hi) / 2 : (hi ?? lo ?? 1);
      const span = lo !== null && hi !== null ? hi - lo : Math.abs(mid) * 0.5 || 1;
      const r = random();
      const v = r < 0.2 ? (lo ?? mid) - span * 0.3 * random() : r > 0.8 ? (hi ?? mid) + span * 0.3 * random() : (lo ?? mid - span / 2) + span * random();
      values[key] = Math.max(0.01, Number(v.toPrecision(4)));
    }
    out.push({ id: `seeded:${i}`, sex, age, values });
  }
  return out;
}

const raw = (values: Record<string, number>) =>
  Object.entries(values).map(([key, value]) => ({ name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact" as const }));

/** One lab with `source`, drawn today, of a client with `panel`'s sex and age; `stored` are what the recompute reads. */
function database(panel: Panel, source: string, stored: Array<Record<string, unknown>> = []) {
  const dob = `${Number(TODAY.slice(0, 4)) - panel.age}-01-01`;
  const updates: Array<Record<string, unknown>> = [];
  const inserted: Array<Record<string, unknown>> = [];
  const respond = (c: FakeCall): FakeResponse => {
    const op = ops(c);
    const select = String(argsOf(c, "select")?.[0] ?? "");
    if (c.table === "profiles" && op.startsWith("select")) return { data: { date_of_birth: dob, sex: panel.sex } };
    if (c.table === "biomarker_references") {
      const [, sexes] = argsOf(c, "in") as [string, string[]];
      return { data: ROWS.filter((r) => sexes.includes(r.sex)) };
    }
    const lab = { patient_context_version_id: null, created_at: `${TODAY}T09:00:00Z`, transient_context: null, collection_date: TODAY, source };
    if (c.table === "lab_results" && op.startsWith("select") && op.endsWith("maybeSingle") && select.includes("patient_context_version_id")) return { data: lab };
    if (c.table === "biomarker_values" && op.startsWith("insert")) {
      inserted.push(...(argsOf(c, "insert")?.[0] as Array<Record<string, unknown>>));
      return { data: null };
    }
    if (c.table === "biomarker_values" && op.startsWith("select")) return { data: stored };
    if (c.table === "lab_results" && op.startsWith("update")) {
      const update = argsOf(c, "update")?.[0] as Record<string, unknown>;
      if ("optimal_count" in update) updates.push(update);
      return { data: null };
    }
    return { data: op.endsWith("maybeSingle") || op.endsWith("single") ? null : [] };
  };
  return { client: fakeSupabase(respond).client, updates, inserted };
}

const record = (r: unknown) => {
  const { computed_at: _c, ...rest } = (r ?? {}) as Record<string, unknown>;
  return rest;
};

/** The rolling average over an EVA lab drawn 30 days ago and a lab with `source` drawn 10 days ago, with other values. */
async function rolling(panel: Panel, source: string) {
  const other: Record<string, number> = Object.fromEntries(Object.entries(panel.values).map(([k, v]) => [k, Number((v * 1.15).toPrecision(4))]));
  const labs = [
    { id: "lab-other", collection_date: shift(TODAY, -10), source, values: other },
    { id: "lab-eva", collection_date: shift(TODAY, -30), source: "echevarne", values: panel.values },
  ];
  const dob = `${Number(TODAY.slice(0, 4)) - panel.age}-01-01`;
  const respond = (c: FakeCall): FakeResponse => {
    const op = ops(c);
    if (c.table === "profiles" && op.startsWith("select")) return { data: { sex: panel.sex, date_of_birth: dob } };
    if (c.table === "lab_results") {
      const sources = argsOf(c, "in", "source")?.[1] as string[] | undefined; // the database applies the filter asked for
      const found = labs
        .filter((l) => !sources || sources.includes(l.source))
        .map((l) => ({ id: l.id, collection_date: l.collection_date, created_at: `${l.collection_date}T10:00:00Z`, patient_context_version_id: null, source: l.source }));
      return { data: op.endsWith("maybeSingle") ? (found[0] ?? null) : found };
    }
    if (c.table === "biomarker_values") {
      const ids = argsOf(c, "in", "lab_result_id")?.[1] as string[];
      return { data: labs.filter((l) => ids.includes(l.id)).flatMap((l) => Object.entries(l.values).map(([biomarker_key, value]) => ({ lab_result_id: l.id, biomarker_key, value }))) };
    }
    if (c.table === "patient_context_versions") return { data: [] };
    return { data: null };
  };
  // "Today" for the windows is the real clock: the labs are dated relative to TODAY, which is today in the run.
  return computeRollingAverageBA("u1", fakeSupabase(respond, { project: true }).client);
}

/** Version 3 on an EVA lab without HbA1c, with an HbA1c on a lab of `source` drawn 20 days earlier. */
async function v3Mixed(panel: Panel, source: string) {
  const own = Object.fromEntries(Object.entries(panel.values).filter(([k]) => k !== "hba1c"));
  const hba1c = panel.values.hba1c ?? 5.6;
  const respond = (c: FakeCall): FakeResponse => {
    const select = String(argsOf(c, "select")?.[0] ?? "");
    if (c.table === "lab_results" && select === "collection_date, created_at, patient_context_version_id, source") {
      return { data: { collection_date: TODAY, created_at: null, patient_context_version_id: null, source: "echevarne" } };
    }
    if (c.table === "lab_results" && select.startsWith("id, collection_date, created_at")) {
      return { data: [{ id: "lab-other", collection_date: shift(TODAY, -20), created_at: null, source }] };
    }
    if (c.table === "biomarker_values" && select.startsWith("lab_result_id")) {
      return { data: [{ lab_result_id: "lab-other", biomarker_key: "hba1c", value: hba1c, unit: "%", comparator: null, normal_low: 4 }] };
    }
    if (c.table === "biomarker_values") {
      return { data: Object.entries(own).map(([biomarker_key, value]) => ({ biomarker_key, value, unit: getCanonicalUnit(biomarker_key), comparator: null, normal_low: null, normal_high: null })) };
    }
    if (c.table === "patient_context_versions") return { data: null };
    return { data: null };
  };
  const sources = await loadBioAgeV3Sources(fakeSupabase(respond).client, {
    userId: "u1", labResultId: "lab-eva", values: null, profile: { date_of_birth: `${Number(TODAY.slice(0, 4)) - panel.age}-01-01`, sex: panel.sex }, now: new Date(`${TODAY}T12:00:00Z`),
  });
  // As stored (no collection method recorded), and as it would be with the venous draw recorded.
  const stored = record(bioAgeV3Record(sources));
  const venous = record(bioAgeV3Record({ ...sources, collectionMethod: "venous" }));
  return { stored, venous };
}

it("sweep", async () => {
  vi.spyOn(console, "log").mockImplementation(() => {});
  vi.spyOn(console, "warn").mockImplementation(() => {});
  vi.spyOn(console, "error").mockImplementation(() => {});
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(new Date(`${TODAY}T12:00:00Z`));
  const out = fs.createWriteStream(OUT);
  const panels = [...personas(), ...seeded(Number(process.env.SWEEP_SEEDED ?? 300))];
  for (const panel of panels) {
    for (const source of SOURCES) {
      shadow.upserts = [];
      const processed = database(panel, source);
      const result = await processLabResults("u1", "lab-1", raw(panel.values), processed.client);
      const processedV3 = shadow.upserts.map((u) => record(u.record));
      shadow.upserts = [];
      const recomputed = database(panel, source, processed.inserted);
      await recomputeLabMetrics("u1", "lab-1", recomputed.client as never);
      const recomputedV3 = shadow.upserts.map((u) => record(u.record));
      const line = {
        panel: panel.id,
        source,
        processed: result.processed.map((p) => [p.biomarkerKey, p.value, p.unit, p.zone]),
        inserted: processed.inserted,
        processUpdate: processed.updates,
        recomputeUpdate: recomputed.updates,
        score: result.fullBioAgeResult ? { score: result.fullBioAgeResult.longevityScore, grade: result.fullBioAgeResult.lsGrade, scored: result.fullBioAgeResult.markerScores.map((m) => [m.code, m.zone]) } : null,
        scoreWithheld: result.scoreWithheld,
        answer: result.biologicalAge,
        kdm: result.kdmBiologicalAge,
        metrics: result.calculatedMetrics.map((m) => [m.metricKey, m.value, m.zone]),
        processedV3,
        recomputedV3,
        rolling: await rolling(panel, source),
        v3Mixed: await v3Mixed(panel, source),
      };
      out.write(`${JSON.stringify(line)}\n`);
    }
  }
  await new Promise((r) => out.end(r));
}, 1_800_000);
