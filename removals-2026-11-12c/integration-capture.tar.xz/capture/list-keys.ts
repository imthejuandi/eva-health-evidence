const tree = process.argv[2];
(async () => {
  const { seedReferenceRows } = await import(`${tree}/src/lib/biomarkers/seed-references`);
  const { getCanonicalUnit } = await import(`${tree}/src/lib/biomarkers/canonical-units`);
  const keys = [...new Set(seedReferenceRows().map((r: { biomarker_key: string }) => r.biomarker_key))].sort() as string[];
  const want = ["albumin","alp","alt","ast","creatinine","bun","ggt","hba1c","glucose_fasting","insulin_fasting","apolipoprotein_b_apob","ldl_cholesterol","hdl_cholesterol","triglycerides","total_cholesterol","hemoglobin","hs_crp","vitamin_d_25_oh","neutrophils","lymphocytes","ferritin","testosterone_total","shbg","tsh"];
  for (const k of want) console.log(k, keys.includes(k) ? "ok" : "MISSING", getCanonicalUnit(k));
  console.log(keys.filter((k) => /vitamin_d|neutro|lympho|testost|shbg|insulin/.test(k)).join(" "));
})();
