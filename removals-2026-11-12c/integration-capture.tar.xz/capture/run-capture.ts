/**
 * Integration rehearsal (scratch, not committed): what a client would see from processing and recomputing, captured
 * for every case of cases.json (build-cases.ts) on the tree given, so that the capture at d97516e and the capture at
 * the head of ws3-int, with every flag off, can be compared field by field (compare.py).
 *
 * Run from the tree's root (tsconfig paths), with the flags unset:
 *   cd <tree> && env -u AI_TEXT_ENABLED -u CRITICAL_TIER_ENABLED -u BIO_AGE_KDM_VISIBLE -u BIO_AGE_V3_VISIBLE \
 *     npx tsx <this file> --tree <tree> --cases <cases.json> --double <tree whose fake-supabase is used> --out <file>
 *
 * For each case and each database variant it runs processLabResults on a scripted database (fake-supabase, one copy
 * for both trees, projecting each select as PostgREST does), then recomputeLabMetrics on the values processing
 * stored, and records: every processed result, the set-aside results, the calculated metrics and any refused ones,
 * the score and its withholding, every stored biomarker_values row, every lab_results update of both steps, the
 * message column each processed zone reads and its text on the picked row, and every database call made.
 * No database is reached: the clients are scripted; createAdminClient returns null without credentials.
 */
import fs from "node:fs";
import path from "node:path";

type Row = Record<string, unknown> & { biomarker_key: string; sex: string | null; age_group_en: string | null };
interface Raw { name: string; value: number; unit: string; comparator?: "<" | ">"; biomarkerKey?: string; matchConfidence?: "exact"; kind: string }
interface Case { id: string; sex: "male" | "female"; age: number; version: Record<string, unknown> | null; raw: Raw[] }

const arg = (name: string) => process.argv[process.argv.indexOf(name) + 1];

/** The message column each zone read before WS3-11: the seed's column of the same name (scripts/signoff/lib/seed.ts). */
const LEGACY_COLUMN: Record<string, string | null> = {
  critical_low: "msg_critical_low",
  below_optimal: "msg_below_optimal",
  optimal: "msg_optimal",
  above_optimal: "msg_above_optimal",
  critical_high: "msg_critical_high",
  unclassified: null,
};

async function main() {
  const tree = path.resolve(arg("--tree"));
  const double = path.resolve(arg("--double"));
  const input = JSON.parse(fs.readFileSync(arg("--cases"), "utf8")) as { rows: { plain: Row[]; migrated: Row[] }; cases: Case[] };
  const out = arg("--out");

  const { fakeSupabase, argsOf, ops } = await import(`${double}/src/lib/testing/fake-supabase`);
  const { processLabResults, recomputeLabMetrics } = await import(`${tree}/src/lib/biomarkers/process-results`);
  const { pickReferenceRows } = await import(`${tree}/src/lib/biomarkers/reference-row`);
  const { resolveState, LAB_STATE_LAB_COLUMNS } = await import(`${tree}/src/lib/patient-context/physiological-state`);
  let zoneMessageColumn: (z: string) => string | null = (z) => LEGACY_COLUMN[z] ?? null;
  let columnSource = "legacy (msg_<zone>)";
  if (fs.existsSync(`${tree}/src/lib/biomarkers/stored-zone.ts`)) {
    const sz = await import(`${tree}/src/lib/biomarkers/stored-zone`);
    if (typeof sz.zoneMessageColumn === "function") {
      zoneMessageColumn = sz.zoneMessageColumn;
      columnSource = "stored-zone.ts zoneMessageColumn";
    }
  }

  const USER = "22222222-2222-4222-8222-222222222222";
  const LAB = "11111111-1111-4111-8111-111111111111";
  const year = new Date().getFullYear();

  const run = async (c: Case, rows: Row[]) => {
    const dob = `${year - c.age}-01-01`;
    const inserted: Array<Record<string, unknown>> = [];
    const updates: Array<Record<string, unknown>> = [];
    const recomputeUpdates: Array<Record<string, unknown>> = [];
    const calls: string[] = [];
    let phase: "process" | "recompute" = "process";
    const respond = (call: { table: string; ops: { op: string; args: unknown[] }[] }) => {
      const op = ops(call);
      const select = argsOf(call, "select")?.[0];
      calls.push(`${phase} ${call.table} ${op}${select !== undefined ? ` [${String(select)}]` : ""}`);
      if (call.table === "profiles" && op.startsWith("select")) return { data: { date_of_birth: dob, sex: c.sex } };
      if (call.table === "biomarker_references") {
        const [, list] = (argsOf(call, "in") ?? [null, []]) as [string, string[]];
        return { data: rows.filter((r) => list.includes(String(r.sex ?? ""))).map((r) => ({ ...r })) };
      }
      if (call.table === "lab_results" && select === LAB_STATE_LAB_COLUMNS) {
        return { data: { patient_context_version_id: c.version ? "ctx-1" : null, created_at: null, transient_context: null, collection_date: "2026-11-01" } };
      }
      if (call.table === "patient_context_versions") return { data: c.version };
      if (call.table === "lab_results" && select === "id, collection_date, created_at") return { data: [] };
      if (call.table === "biomarker_values" && op.startsWith("insert")) {
        inserted.push(...(argsOf(call, "insert")?.[0] as Array<Record<string, unknown>>));
        return { data: null };
      }
      if (call.table === "biomarker_values" && op.startsWith("select")) return { data: inserted.map((r) => ({ ...r })) };
      if (call.table === "lab_results" && op.startsWith("update")) {
        const u = argsOf(call, "update")?.[0] as Record<string, unknown>;
        (phase === "process" ? updates : recomputeUpdates).push(u);
        return { data: [{ id: LAB }] };
      }
      return { data: null };
    };
    const { client } = fakeSupabase(respond, { project: true });
    let error: string | null = null;
    let result: Record<string, unknown> | null = null;
    try {
      const raw = c.raw.map(({ kind: _kind, ...r }) => r);
      const r = await processLabResults(USER, LAB, raw, client);
      const picked = pickReferenceRows(rows as never, c.sex, c.age, resolveState({ version: c.version as never, transient: null })).picked;
      result = {
        processed: r.processed.map((p: Record<string, unknown>) => {
          const column = zoneMessageColumn(String(p.zone));
          const row = picked.get(String(p.biomarkerKey)) as Record<string, unknown> | undefined;
          return {
            ...p,
            message_column: column,
            message_en: column ? (row?.[`${column}_en`] ?? null) : null,
            message_es: column ? (row?.[`${column}_es`] ?? null) : null,
          };
        }),
        scoreWithheld: r.scoreWithheld,
        biologicalAge: r.biologicalAge,
        score: r.fullBioAgeResult
          ? {
              score: r.fullBioAgeResult.longevityScore,
              grade: r.fullBioAgeResult.lsGrade,
              confidence: r.fullBioAgeResult.confidence,
              withheld: r.fullBioAgeResult.withheld ?? null,
              cap: r.fullBioAgeResult.cap ?? null,
              scored: r.fullBioAgeResult.markersScored ?? null,
              markerScores: (r.fullBioAgeResult.markerScores ?? []).map((m: Record<string, unknown>) => ({ code: m.code, value: m.value, zone: m.zone, rawPenalty: m.rawPenalty, scored: m.scored ?? null })),
            }
          : null,
        unmatched: r.unmatched,
        rowsPickedByAge: r.rowsPickedByAge,
        noRowForState: r.noRowForState,
        calculatedMetrics: r.calculatedMetrics,
        refusedMetrics: (r as Record<string, unknown>).refusedMetrics ?? "(absent)",
        refMapSize: r.refMapSize,
        missingRefKeys: r.missingRefKeys,
        kdm: r.kdmBiologicalAge,
        resultKeys: Object.keys(r).sort(),
      };
    } catch (e) {
      error = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    }
    phase = "recompute";
    let recomputeError: string | null = null;
    try {
      await recomputeLabMetrics(USER, LAB, client as never);
    } catch (e) {
      recomputeError = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    }
    return { error, result, stored: inserted, updates, recomputeUpdates, recomputeError, calls };
  };

  const quiet = { log: console.log, warn: console.warn, error: console.error, info: console.info };
  console.log = () => {};
  console.warn = () => {};
  console.error = () => {};
  console.info = () => {};
  const started = Date.now();
  const capture: Record<string, Record<string, unknown>> = {};
  for (const [name, rows] of [["plain", input.rows.plain], ["migrated", input.rows.migrated]] as const) {
    capture[name] = {};
    for (const c of input.cases) capture[name][c.id] = await run(c, rows);
  }
  console.log = quiet.log;
  console.warn = quiet.warn;
  console.error = quiet.error;
  console.info = quiet.info;
  const flags = Object.fromEntries(["AI_TEXT_ENABLED", "CRITICAL_TIER_ENABLED", "BIO_AGE_KDM_VISIBLE", "BIO_AGE_V3_VISIBLE"].map((k) => [k, process.env[k] ?? null]));
  fs.writeFileSync(out, JSON.stringify({ tree, flags, columnSource, cases: input.cases.length, capture }, null, 1));
  console.log(`captured ${input.cases.length} cases x 2 variants on ${tree} in ${Math.round((Date.now() - started) / 1000)}s; flags ${JSON.stringify(flags)}; message column ${columnSource} -> ${out}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
