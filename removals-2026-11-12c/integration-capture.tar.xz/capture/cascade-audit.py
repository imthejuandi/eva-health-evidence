"""Integration rehearsal (scratch): what the R5 and R6 cascades of compare.py absorb, path by path, so that no
difference unrelated to the cause hides in a case that has one. Usage: python3 -I cascade-audit.py cases before after"""
import json, re, sys
from collections import Counter
sys.argv = sys.argv[:4] + ["/dev/null"]
src = open(__file__.replace("cascade-audit.py", "compare.py")).read()
# Reuse compare.py's functions without running its main loop.
head = src.split("counter = Counter()")[0]
g = {"__file__": "compare.py"}
exec(compile(head, "compare.py", "exec"), g)
cases, before, after = g["cases"], g["before"], g["after"]
kinds = Counter()
odd = []
for cid in sorted(cases):
    b, a = before["capture"]["plain"][cid], after["capture"]["plain"][cid]
    g["CURRENT"]["case"] = cases[cid]
    exp = g["expected_after"](b, Counter())
    got = g["normalised_after"](a)
    changed = [r for r in cases[cid]["raw"] if r["kind"].startswith(("name-", "probe-")) and g["raw_outcome"](b, r) != g["raw_outcome"](a, r)]
    refused = (a.get("result") or {}).get("refusedMetrics") or []
    if not changed and not refused:
        continue
    for path, x, y in g["diff"](exp, got):
        p = re.sub(r"\[\d+\]", "[]", path)
        cause = "R6" if changed else "R5"
        kinds[(cause, p)] += 1
        # In an R6 case, a processed/stored/unmatched entry that moved must be the changed name's, or one shifted by it.
        if cause == "R6" and p in (".result.processed[].zone", ".result.processed[].value", ".stored[].zone") and not path.endswith("[len]"):
            odd.append((cid, path, x, y))
for (cause, p), n in sorted(kinds.items()):
    print(f"{cause} {p}: {n}")
print("entries to look at:", len(odd))
for o in odd[:20]:
    print(" ", o)
