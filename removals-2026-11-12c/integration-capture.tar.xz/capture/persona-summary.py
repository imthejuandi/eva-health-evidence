"""Integration rehearsal (scratch): per persona and per case group, what moved between the two captures (plain
variant), by rule of compare.py. Usage: python3 -I persona-summary.py cases before after"""
import json, sys
from collections import Counter
sys.argv = sys.argv[:4] + ["/dev/null"]
src = open(__file__.replace("persona-summary.py", "compare.py")).read()
g = {"__file__": "compare.py"}
exec(compile(src.split("counter = Counter()")[0], "compare.py", "exec"), g)
cases, before, after = g["cases"], g["before"], g["after"]
groups = Counter()
group_rules = {}
print("persona | rules | score before -> after | withheld before -> after | counts before -> after (optimal/attention/action)")
for cid in sorted(cases):
    b, a = before["capture"]["plain"][cid], after["capture"]["plain"][cid]
    g["CURRENT"]["case"] = cases[cid]
    local = Counter()
    g["expected_after"](b, local)
    rules = sorted({k.split()[0] for k in local})
    refused = (a.get("result") or {}).get("refusedMetrics") or []
    if refused:
        rules.append("R5")
    changed = [r for r in cases[cid]["raw"] if r["kind"].startswith(("name-", "probe-")) and g["raw_outcome"](b, r) != g["raw_outcome"](a, r)]
    if changed:
        rules.append("R6")
    sb = ((b.get("result") or {}).get("score") or {}).get("score")
    sa = ((a.get("result") or {}).get("score") or {}).get("score")
    wb = (b.get("result") or {}).get("scoreWithheld")
    wa = (a.get("result") or {}).get("scoreWithheld")
    cb = [(u.get("optimal_count"), u.get("attention_count"), u.get("action_count")) for u in b["updates"]]
    ca = [(u.get("optimal_count"), u.get("attention_count"), u.get("action_count")) for u in a["updates"]]
    grp = cid.split(":")[0]
    groups[(grp, "cases")] += 1
    if (sb, wb) != (sa, wa):
        groups[(grp, "score or withholding moved")] += 1
    if cb != ca:
        groups[(grp, "counts moved")] += 1
    for r in rules:
        groups[(grp, r)] += 1
    if grp == "persona":
        print(f"{cid[8:]} | {','.join(rules) or '-'} | {sb} -> {sa} | {wb} -> {wa} | {cb} -> {ca}")
print()
for (grp, what), n in sorted(groups.items()):
    print(f"{grp}: {what}: {n}")
