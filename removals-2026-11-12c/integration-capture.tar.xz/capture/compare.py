"""Integration rehearsal (scratch): compares the persona and panel capture at d97516e with the one at the head of
ws3-int, every flag off, and names the package and rule behind each difference.

Usage: python3 -I compare.py <cases.json> <before.json> <after.json> <report.md> [<details.json>]

Method: each d97516e result is first transformed by the changes the merged packages' rules predict, then compared with
the head's result field by field. What still differs is explained only by a cause present in that case:
  R1  WS3-11, ruling D-14: a value outside the reference interval is below_range / above_range (the critical codes mean
      the critical tier only, which is off): zone critical_low -> below_range, critical_high -> above_range, in the
      processed results, the stored rows and the calculated metrics; labels and message column unchanged.
  R2  WS3-11, ruling D-14: a value on a row with no optimal band (optimal_low and optimal_high both null) is in_range,
      shown 'In range' / 'En rango'; it reads the same message column (msg_optimal).
  R3  WS3-11 (fix round A3, processLabResults and recomputeLabMetrics step 3): an in_range result is in none of the
      three counts: optimal_count falls by the number of R2 results.
  R4  WS3-45: processing returns refusedMetrics (a new key of the result).
  R5  WS3-45: a calculated metric refused by the plausibility guard is no longer returned (calculatedMetrics loses it);
      where the score would have read it (refusal 'in' includes 'score'), the score's inputs change and so may the
      score, its grade, confidence, cap, marker scores and the stored longevity fields.
  R6  WS3-42: a result read by its name (no key given) matches differently: its processed or set-aside entry changes,
      and with it anything downstream (counts, score, biological age, metrics).
  R1b WS3-11, ruling D-14, in the score engine: a marker score's zone uses the same codes (the score's out-of-range
      test reads below_range / above_range).
  R2b WS3-11, ruling D-14: a calculated metric whose applicable row has no optimal band is in_range (checked against
      every row of the metric's key that applies to the person's sex and age).
  R7  WS3-13 (2da3e38, its deviation 7) with WS3-11's rounding (07bf274, A1): the unitless screen's review record
      rounds the converted value through critical-limit.ts roundToDecimals, which cuts it to 15 significant digits
      first, so a binary near-tie (13285.499999999998) is a tie and rounds half away from zero (13286, not 13285); the
      hit itself (side, limit, kind) is unchanged. Accepted only when the value cut to 15 digits is exactly halfway.
Anything else is UNEXPLAINED.
"""
import copy
import json
import sys
from collections import Counter, defaultdict

cases_path, before_path, after_path, report_path = sys.argv[1:5]
details_path = sys.argv[5] if len(sys.argv) > 5 else None
cases = {c["id"]: c for c in json.load(open(cases_path))["cases"]}
before = json.load(open(before_path))
after = json.load(open(after_path))

ZONE_RENAME = {"critical_low": "below_range", "critical_high": "above_range"}


def no_band(lo, hi):
    return lo is None and hi is None


def transform_zone(entry, lo_key, hi_key, counter, where):
    """R1 and R2 on one entry holding a zone (and labels when present). Returns 1 when R2 applied."""
    z = entry.get("zone")
    if z in ZONE_RENAME:
        entry["zone"] = ZONE_RENAME[z]
        counter[f"R1 {where} {z}->{ZONE_RENAME[z]}"] += 1
        return 0
    if z == "optimal" and lo_key is not None and no_band(entry.get(lo_key), entry.get(hi_key)):
        entry["zone"] = "in_range"
        if "zoneLabel" in entry:
            entry["zoneLabel"] = "In range"
            entry["zoneLabel_es"] = "En rango"
        counter[f"R2 {where} optimal->in_range"] += 1
        return 1
    return 0


def expected_after(b, counter):
    """The d97516e result transformed by R1-R4."""
    e = copy.deepcopy(b)
    r = e.get("result")
    in_range = 0
    if r:
        for p in r["processed"]:
            in_range += transform_zone(p, "optimalLow", "optimalHigh", counter, "processed")
        for m in r["calculatedMetrics"]:
            transform_zone(m, None, None, counter, "metric")
            if m.get("zone") == "optimal" and metric_row_has_no_band(m["metricKey"]):
                m["zone"] = "in_range"
                counter["R2b metric optimal->in_range (row with no band)"] += 1
        for ms in ((r.get("score") or {}).get("markerScores") or []):
            z = ms.get("zone")
            if z in ZONE_RENAME:
                ms["zone"] = ZONE_RENAME[z]
                counter[f"R1b markerScore {z}->{ZONE_RENAME[z]}"] += 1
        r.pop("refusedMetrics", None)
        r["resultKeys"] = [k for k in r["resultKeys"] if k != "refusedMetrics"]
    stored_in_range = 0
    for s in e["stored"]:
        stored_in_range += transform_zone(s, "optimal_low", "optimal_high", counter, "stored")
    for u in e["updates"]:
        if "optimal_count" in u and in_range:
            u["optimal_count"] -= in_range
            counter["R3 processing optimal_count"] += 1
    for u in e["recomputeUpdates"]:
        if "optimal_count" in u and stored_in_range:
            u["optimal_count"] -= stored_in_range
            counter["R3 recompute optimal_count"] += 1
    return e


ROWS = json.load(open(cases_path))["rows"]["plain"]
METRIC_ROW = {"egfr_computed": "egfr_creatinine_based", "non_hdl": "non_hdl_cholesterol"}
CURRENT = {}


def age_in(group, age):
    import re
    m = re.match(r"^\s*(\d+)\s*-\s*(\d+)\s*$", group or "")
    if m:
        return int(m.group(1)) <= age <= int(m.group(2))
    m = re.match(r"^\s*(\d+)\s*\+\s*$", group or "")
    if m:
        return age >= int(m.group(1))
    return None


def metric_row_has_no_band(metric_key):
    c = CURRENT["case"]
    key = METRIC_ROW.get(metric_key, metric_key)
    applicable = [r for r in ROWS if r["biomarker_key"] == key and r["sex"] in (c["sex"], "both") and age_in(r["age_group_en"], c["age"])]
    return bool(applicable) and all(no_band(r["optimal_low"], r["optimal_high"]) for r in applicable)


def tie_rounding(path, b_val, a_val, b_entry):
    """R7: the review record's compared value, a binary near-tie rounded half away from zero after the 15-digit cut."""
    if not path.endswith(".compared") or ".review.hits[" not in path:
        return False
    import re
    hit_path = path[: -len(".compared")]
    node = b_entry
    for part in re.findall(r"\.([A-Za-z_]+)|\[(\d+)\]", hit_path):
        node = node[part[0]] if part[0] else node[int(part[1])]
    v15 = float(f"{node['value']:.15g}")
    step = abs(a_val - b_val)
    return step > 0 and abs(abs(v15 - b_val) - step / 2) < 1e-9 * max(1, abs(v15)) and abs(abs(a_val - v15) - step / 2) < 1e-9 * max(1, abs(v15))


def normalised_after(a):
    e = copy.deepcopy(a)
    r = e.get("result")
    if r:
        r.pop("refusedMetrics", None)
        r["resultKeys"] = [k for k in r["resultKeys"] if k != "refusedMetrics"]
    return e


def diff(x, y, path=""):
    out = []
    if isinstance(x, dict) and isinstance(y, dict):
        for k in sorted(set(x) | set(y)):
            if k not in x or k not in y:
                out.append((f"{path}.{k}", x.get(k, "<absent>"), y.get(k, "<absent>")))
            else:
                out += diff(x[k], y[k], f"{path}.{k}")
    elif isinstance(x, list) and isinstance(y, list):
        if len(x) != len(y):
            out.append((f"{path}[len]", len(x), len(y)))
        for i, (p, q) in enumerate(zip(x, y)):
            out += diff(p, q, f"{path}[{i}]")
    elif x != y:
        out.append((path, x, y))
    return out


def raw_outcome(entry, raw):
    """How one raw result came out: ('processed', key, zone) or ('set-aside', reason) or ('missing',)."""
    r = entry.get("result") or {}
    out = [("processed", p["biomarkerKey"], p["matchConfidence"]) for p in r.get("processed", []) if p["name"] == raw["name"]]
    out += [("set-aside", u.get("reason")) for u in r.get("unmatched", []) if u["name"] == raw["name"] and u["value"] == raw["value"]]
    return tuple(out) if out else ("missing",)


SCORE_PATHS = (".result.score", ".result.biologicalAge.longevityScore", ".result.biologicalAge.lsGrade", ".result.biologicalAge.confidence")
SCORE_UPDATE_KEYS = ("longevity_score", "longevity_grade")

counter = Counter()
cause_cases = defaultdict(set)
unexplained = []
examples = defaultdict(list)
name_changes = []
refusals = Counter()
score_moves = []
variant_same = {}

for variant in ("plain", "migrated"):
    cb, ca = before["capture"][variant], after["capture"][variant]
    assert set(cb) == set(ca) == set(cases), "case sets differ"
    for cid in sorted(cases):
        b, a = cb[cid], ca[cid]
        if (b.get("error") or None) != (a.get("error") or None):
            unexplained.append((variant, cid, ".error", b.get("error"), a.get("error")))
            continue
        local = Counter()
        CURRENT["case"] = cases[cid]
        exp = expected_after(b, local)
        got = normalised_after(a)
        for k, v in local.items():
            counter[f"{k} [{variant}]"] += v
            cause_cases[k.split()[0]].add((variant, cid))
        ar = a.get("result") or {}
        refused = ar.get("refusedMetrics") if isinstance(ar.get("refusedMetrics"), list) else []
        if a.get("result"):
            cause_cases["R4"].add((variant, cid))
        for rm in refused:
            refusals[(rm["metricKey"], rm["reason"], ",".join(rm["in"]))] += 1
        # R6: names whose outcome changed.
        changed_names = []
        for raw in cases[cid]["raw"]:
            if raw["kind"].startswith(("name-", "probe-")):
                ob, oa = raw_outcome(b, raw), raw_outcome(a, raw)
                if ob != oa:
                    changed_names.append((raw["name"], raw["value"], raw["unit"], ob, oa))
        if changed_names:
            cause_cases["R6"].add((variant, cid))
            if variant == "plain":
                name_changes.extend((cid, *c) for c in changed_names)
        diffs = diff(exp, got)
        if not diffs:
            continue
        if changed_names:
            # R6: everything downstream of a changed match is explained by it.
            counter[f"R6 fields [{variant}]"] += len(diffs)
            examples["R6"].append((variant, cid, diffs[:6]))
            continue
        # R5: metrics the guard refused leave calculatedMetrics; the score may move where the score read one.
        refused_keys = {rm["metricKey"] for rm in refused if "metrics" in rm["in"]}
        score_refused = [rm for rm in refused if "score" in rm["in"]]
        if refused_keys and exp.get("result"):
            kept = [m for m in exp["result"]["calculatedMetrics"] if m["metricKey"] not in refused_keys]
            removed = [m["metricKey"] for m in exp["result"]["calculatedMetrics"] if m["metricKey"] in refused_keys]
            if removed:
                exp["result"]["calculatedMetrics"] = kept
                counter[f"R5 metrics removed [{variant}]"] += len(removed)
                cause_cases["R5"].add((variant, cid))
        rest = diff(exp, got)
        if rest and score_refused:
            def is_score_path(p):
                if p.startswith(SCORE_PATHS):
                    return True
                for upd in (".updates", ".recomputeUpdates"):
                    if p.startswith(upd) and p.split(".")[-1] in SCORE_UPDATE_KEYS:
                        return True
                return False
            score_diffs = [d for d in rest if is_score_path(d[0])]
            rest = [d for d in rest if not is_score_path(d[0])]
            if score_diffs:
                counter[f"R5 score fields [{variant}]"] += len(score_diffs)
                cause_cases["R5-score"].add((variant, cid))
                if variant == "plain":
                    sb = (b["result"] or {}).get("score") or {}
                    sa = (a["result"] or {}).get("score") or {}
                    score_moves.append((cid, [rm["metricKey"] + ":" + rm["reason"] for rm in score_refused], sb.get("score"), sa.get("score"), sb.get("grade"), sa.get("grade")))
        for d in rest:
            if tie_rounding(d[0], d[1], d[2], b):
                counter[f"R7 review compared tie [{variant}]"] += 1
                cause_cases["R7"].add((variant, cid))
                continue
            unexplained.append((variant, cid, *d))

    # The migrated rows (critical columns present) give what the plain rows give while the tier is off.
    variant_same[variant] = None
for name, cap in (("before", before), ("after", after)):
    same = sum(1 for cid in cases if cap["capture"]["plain"][cid] == cap["capture"]["migrated"][cid])
    variant_same[name] = same

lines = []
lines.append("# Persona and panel capture: d97516e against the head of ws3-int, every flag off\n")
lines.append(f"- cases: {len(cases)} (42 personas, 400 seeded panels, 36 calculated-metric edge panels, 42 matcher headline names), each on two database variants (plain: production's rows, no critical columns; migrated: the critical-limits table's limits on the rows, as the sign-off migration will hold them)")
lines.append(f"- before: {before['tree']} (flags {json.dumps(before['flags'])}; message column {before['columnSource']})")
lines.append(f"- after: {after['tree']} (flags {json.dumps(after['flags'])}; message column {after['columnSource']})")
lines.append(f"- plain and migrated identical case by case: before {variant_same['before']} of {len(cases)}, after {variant_same['after']} of {len(cases)} (WS3-13 with the tier off reads no critical column; the rows' critical columns change nothing)")
lines.append("")
lines.append("## Differences by rule (counts over both variants)\n")
for k in sorted(counter):
    lines.append(f"- {k}: {counter[k]}")
lines.append("")
lines.append("## Cases each rule touches (both variants)\n")
for k in sorted(cause_cases):
    lines.append(f"- {k}: {len(cause_cases[k])}")
lines.append("")
lines.append("## WS3-45 refusals at the head (plain and migrated)\n")
for (mk, reason, where), n in sorted(refusals.items()):
    lines.append(f"- {mk} {reason} in {where}: {n}")
lines.append("")
lines.append("## Scores that move (plain variant), each with the refusal that moves it\n")
if not score_moves:
    lines.append("- none")
for cid, why, s0, s1, g0, g1 in score_moves:
    lines.append(f"- {cid}: score {s0} -> {s1}, grade {g0} -> {g1}; refused {', '.join(why)}")
lines.append("")
lines.append("## Names whose match changed (plain variant; WS3-42)\n")
if not name_changes:
    lines.append("- none")
for cid, name, value, unit, ob, oa in name_changes:
    lines.append(f"- {cid}: '{name}' {value} {unit!r}: {ob} -> {oa}")
lines.append("")
lines.append(f"## Unexplained differences: {len(unexplained)}\n")
for u in unexplained[:200]:
    lines.append(f"- {u[0]} {u[1]} {u[2]}: {json.dumps(u[3])[:200]} -> {json.dumps(u[4])[:200]}")
open(report_path, "w").write("\n".join(lines) + "\n")
if details_path:
    json.dump({"counter": counter, "unexplained": unexplained, "name_changes": name_changes, "score_moves": score_moves, "examples": {k: v[:20] for k, v in examples.items()}}, open(details_path, "w"), indent=1, default=str)
print("\n".join(lines[:60]))
print(f"... unexplained {len(unexplained)}")
