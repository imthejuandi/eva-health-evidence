# Persona and panel capture: d97516e against the head of ws3-int, every flag off

- cases: 520 (42 personas, 400 seeded panels, 36 calculated-metric edge panels, 42 matcher headline names), each on two database variants (plain: production's rows, no critical columns; migrated: the critical-limits table's limits on the rows, as the sign-off migration will hold them)
- before: /tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/ws3-wave2/integration/base-tree-d97516e (flags {"AI_TEXT_ENABLED": null, "CRITICAL_TIER_ENABLED": null, "BIO_AGE_KDM_VISIBLE": null, "BIO_AGE_V3_VISIBLE": null}; message column legacy (msg_<zone>))
- after: /home/user/eva-health/.claude/worktrees/ws3-int (flags {"AI_TEXT_ENABLED": null, "CRITICAL_TIER_ENABLED": null, "BIO_AGE_KDM_VISIBLE": null, "BIO_AGE_V3_VISIBLE": null}; message column stored-zone.ts zoneMessageColumn)
- plain and migrated identical case by case: before 520 of 520, after 520 of 520 (WS3-13 with the tier off reads no critical column; the rows' critical columns change nothing)

## Differences by rule (counts over both variants)

- R1 metric critical_high->above_range [migrated]: 168
- R1 metric critical_high->above_range [plain]: 168
- R1 metric critical_low->below_range [migrated]: 115
- R1 metric critical_low->below_range [plain]: 115
- R1 processed critical_high->above_range [migrated]: 3467
- R1 processed critical_high->above_range [plain]: 3467
- R1 processed critical_low->below_range [migrated]: 2582
- R1 processed critical_low->below_range [plain]: 2582
- R1 stored critical_high->above_range [migrated]: 3467
- R1 stored critical_high->above_range [plain]: 3467
- R1 stored critical_low->below_range [migrated]: 2582
- R1 stored critical_low->below_range [plain]: 2582
- R1b markerScore critical_high->above_range [migrated]: 34
- R1b markerScore critical_high->above_range [plain]: 34
- R1b markerScore critical_low->below_range [migrated]: 21
- R1b markerScore critical_low->below_range [plain]: 21
- R2 processed optimal->in_range [migrated]: 169
- R2 processed optimal->in_range [plain]: 169
- R2 stored optimal->in_range [migrated]: 169
- R2 stored optimal->in_range [plain]: 169
- R2b metric optimal->in_range (row with no band) [migrated]: 3
- R2b metric optimal->in_range (row with no band) [plain]: 3
- R3 processing optimal_count [migrated]: 146
- R3 processing optimal_count [plain]: 146
- R3 recompute optimal_count [migrated]: 146
- R3 recompute optimal_count [plain]: 146
- R5 metrics removed [migrated]: 104
- R5 metrics removed [plain]: 104
- R5 score fields [migrated]: 52
- R5 score fields [plain]: 52
- R6 fields [migrated]: 2214
- R6 fields [plain]: 2214
- R7 review compared tie [migrated]: 1
- R7 review compared tie [plain]: 1

## Cases each rule touches (both variants)

- R1: 1034
- R1b: 62
- R2: 292
- R2b: 6
- R3: 292
- R4: 1040
- R5: 156
- R5-score: 8
- R6: 66
- R7: 2

## WS3-45 refusals at the head (plain and migrated)

- de_ritis input_not_positive in metrics: 28
- egfr_computed input_not_positive in metrics: 12
- fai input_not_positive in metrics: 12
- homa_ir input_not_positive in metrics: 24
- homa_ir input_not_positive in metrics,score: 28
- nlr input_not_positive in metrics: 2
- nlr input_not_positive in metrics,score: 10
- non_hdl input_not_positive in metrics: 26
- non_hdl input_not_positive in metrics,score: 30
- non_hdl total_not_above_hdl in metrics,score: 16
- tg_hdl_ratio input_not_positive in metrics: 20
- tg_hdl_ratio total_not_above_hdl in metrics: 38

## Scores that move (plain variant), each with the refusal that moves it

- edge:hdl-above-total-no-apob-no-ldl:female: score 63 -> 86, grade Average -> Excellent; refused non_hdl:total_not_above_hdl
- edge:hdl-above-total-no-apob-no-ldl:male: score 63 -> 86, grade Average -> Excellent; refused non_hdl:total_not_above_hdl
- edge:hdl-above-total-no-apob:female: score 63 -> 68, grade Average -> Good; refused non_hdl:total_not_above_hdl
- edge:hdl-above-total-no-apob:male: score 63 -> 68, grade Average -> Good; refused non_hdl:total_not_above_hdl

## Names whose match changed (plain variant; WS3-42)

- probe:00:LDL (nmol/L): 'LDL (nmol/L)' 1200 '': (('set-aside', 'unit_missing'),) -> (('set-aside', 'unmatched'),)
- probe:01:LDL-P (nmol/L): 'LDL-P (nmol/L)' 1200 '': (('set-aside', 'unit_missing'),) -> (('processed', 'ldl_particle_number', 'alias'),)
- probe:02:HDL (µmol/L): 'HDL (µmol/L)' 30 '': (('set-aside', 'unit_missing'),) -> (('set-aside', 'unmatched'),)
- probe:03:LDL (nm): 'LDL (nm)' 21 '': (('set-aside', 'unit_missing'),) -> (('set-aside', 'unmatched'),)
- probe:04:Mercurio (suero): 'Mercurio (suero)' 4 'µg/L': (('processed', 'mercury_blood', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:05:Magnesio (sangre total): 'Magnesio (sangre total)' 2 'mg/dL': (('processed', 'magnesium_serum', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:06:Hemoglobina (plasma): 'Hemoglobina (plasma)' 14 'g/dL': (('processed', 'hemoglobin', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:08:Potasio (suero o plasma): 'Potasio (suero o plasma)' 4.2 'mEq/L': (('set-aside', 'unmatched'),) -> (('processed', 'potassium', 'alias'),)
- probe:09:Potasio (sangre total): 'Potasio (sangre total)' 4.2 'mEq/L': (('processed', 'potassium', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:13:Bilirrubina (directa): 'Bilirrubina (directa)' 0.2 'mg/dL': (('processed', 'total_bilirubin', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:14:Bilirrubina (indirecta): 'Bilirrubina (indirecta)' 0.5 'mg/dL': (('processed', 'total_bilirubin', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:15:Calcio (iónico): 'Calcio (iónico)' 1.2 'mmol/L': (('processed', 'calcium_serum', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:16:Testosterona (biodisponible): 'Testosterona (biodisponible)' 200 'ng/dL': (('processed', 'testosterone_total', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:17:Cortisol (libre): 'Cortisol (libre)' 1 'µg/dL': (('processed', 'cortisol_morning_8am', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:18:Vitamina D (activa): 'Vitamina D (activa)' 40 'pg/mL': (('set-aside', 'unit_mismatch'),) -> (('set-aside', 'unmatched'),)
- probe:19:Cortisol (20:00): 'Cortisol (20:00)' 5 'µg/dL': (('processed', 'cortisol_morning_8am', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:22:Calcio, Serum: 'Calcio, Serum' 9.5 'mg/dL': (('set-aside', 'unmatched'),) -> (('processed', 'calcium_serum', 'alias'),)
- probe:23:Magnesio, Serum: 'Magnesio, Serum' 2.1 'mg/dL': (('set-aside', 'unmatched'),) -> (('processed', 'magnesium_serum', 'alias'),)
- probe:24:Glucosa / suero: 'Glucosa / suero' 90 'mg/dL': (('set-aside', 'unmatched'),) -> (('processed', 'glucose_fasting', 'alias'),)
- probe:25:Gamma-glutamiltransferasa: 'Gamma-glutamiltransferasa' 25 'U/L': (('set-aside', 'unmatched'),) -> (('processed', 'ggt', 'alias'),)
- probe:26:Vitamina D 25OH: 'Vitamina D 25OH' 35 'ng/mL': (('set-aside', 'unmatched'),) -> (('processed', 'vitamin_d_25_oh', 'alias'),)
- probe:27:25-Hydroxy Vitamin D: '25-Hydroxy Vitamin D' 35 'ng/mL': (('set-aside', 'unmatched'),) -> (('processed', 'vitamin_d_25_oh', 'alias'),)
- probe:28:PCR-hs: 'PCR-hs' 1.1 'mg/L': (('set-aside', 'unmatched'),) -> (('processed', 'hs_crp', 'alias'),)
- probe:29:17β-Estradiol: '17β-Estradiol' 60 'pg/mL': (('set-aside', 'unmatched'),) -> (('processed', 'estradiol', 'alias'),)
- probe:30:Hormona folículo estimulante: 'Hormona folículo estimulante' 6 'mIU/mL': (('set-aside', 'unmatched'),) -> (('processed', 'fsh', 'alias'),)
- probe:31:Omega-3 totales: 'Omega-3 totales' 8 '%': (('set-aside', 'unmatched'),) -> (('processed', 'omega_3_total', 'alias'),)
- probe:32:EPA (sangre): 'EPA (sangre)' 1 '%': (('processed', 'omega_3_epa', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:33:Folato (eritrocitos): 'Folato (eritrocitos)' 400 'ng/mL': (('processed', 'red_blood_cell_count', 'alias'),) -> (('set-aside', 'unmatched'),)
- probe:34:Índice Omega-3: 'Índice Omega-3' 6 '%': (('processed', 'omega_3_total', 'fuzzy'),) -> (('set-aside', 'unmatched'),)
- probe:37:Glucosa (n/a): 'Glucosa (n/a)' 90 'mg/dL': (('set-aside', 'unit_mismatch'),) -> (('processed', 'glucose_fasting', 'alias'),)
- probe:38:Glucosa (s/u): 'Glucosa (s/u)' 90 'mg/dL': (('set-aside', 'unmatched'),) -> (('processed', 'glucose_fasting', 'alias'),)
- probe:40:PSA libre %: 'PSA libre %' 20 '%': (('set-aside', 'unit_mismatch'),) -> (('set-aside', 'unmatched'),)
- probe:41:Lipoproteína (a) nmol/L: 'Lipoproteína (a) nmol/L' 75 'nmol/L': (('set-aside', 'unit_mismatch'),) -> (('set-aside', 'unmatched'),)

## Unexplained differences: 0

