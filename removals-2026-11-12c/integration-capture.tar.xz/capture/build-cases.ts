/**
 * Integration rehearsal (scratch, not committed): builds, once, the inputs of the persona and panel capture, so the
 * capture at d97516e and the capture at the head of ws3-int read byte-identical cases and database rows.
 *
 * Run from the tree whose data it reads (tsconfig paths): cd <tree> && npx tsx <this file> --tree <tree> --out <cases.json>
 * It is run on the extracted d97516e tree; nothing here reads code that a package changed (only the seed, the
 * decided rows, the governance critical-limits table, the personas and the base's unit conversions).
 *
 * Output:
 *   rows.plain     the seed with the decided rows of every scored marker (the fixture signedRows): biomarker_references
 *                  as production holds it, with no critical columns.
 *   rows.migrated  the same rows with the critical-limits table's limits on every row of each analyte the table gives
 *                  limits to, null elsewhere: the table as the sign-off migration will hold it.
 *   cases          the 42 personas, a seeded sweep of panels, explicit calculated-metric edge panels and the name
 *                  matcher's headline names, each raw result tagged with how it was built.
 */
import fs from "node:fs";
import path from "node:path";

type Row = Record<string, unknown> & { biomarker_key: string; sex: string | null; age_group_en: string | null };
interface Raw { name: string; value: number; unit: string; comparator?: "<" | ">"; biomarkerKey?: string; matchConfidence?: "exact"; kind: string }
interface Case { id: string; sex: "male" | "female"; age: number; version: Record<string, unknown> | null; raw: Raw[] }

async function main() {
  const tree = path.resolve(process.argv[process.argv.indexOf("--tree") + 1]);
  const out = process.argv[process.argv.indexOf("--out") + 1];
  const { signedRows } = await import(`${tree}/src/lib/biomarkers/__tests__/fixtures/reviewed-rows`);
  const { getCanonicalUnit, normalizeUnit } = await import(`${tree}/src/lib/biomarkers/canonical-units`);
  const { convertBiomarker } = await import(`${tree}/src/lib/biomarkers/unit-conversions`);
  const { pickReferenceRows } = await import(`${tree}/src/lib/biomarkers/reference-row`);

  const table = JSON.parse(fs.readFileSync(path.join(tree, "docs/signoff/work/governance/critical-limits.json"), "utf8")) as {
    entries: Array<{ marker_key: string; critical_low: number | null; critical_high: number | null; decimals: number | null }>;
  };
  const LIMITS = new Map(table.entries.filter((e) => e.critical_low != null || e.critical_high != null).map((e) => [e.marker_key, e]));

  const PLAIN: Row[] = (signedRows() as unknown as Row[]).map((r) => ({ ...r }));
  const MIGRATED: Row[] = PLAIN.map((r) => {
    const l = LIMITS.get(r.biomarker_key);
    return l ? { ...r, critical_low: l.critical_low, critical_high: l.critical_high } : { ...r, critical_low: null, critical_high: null };
  });

  // ─── The 42 personas, values by key in EVA's unit, as the acceptance test gives them ───
  interface Persona {
    id: string;
    sex: "male" | "female";
    age: number;
    state: { physiological_state: string; hormone_therapy?: string; oral_contraception?: boolean };
    context: { conditions: string[]; medications: string[]; supplements: Array<{ key: string; dose?: string }> };
    values: Record<string, number>;
  }
  const personas = (JSON.parse(fs.readFileSync(path.join(tree, "scripts/signoff/fixtures/personas.json"), "utf8")) as { personas: Persona[] }).personas;
  const versionOf = (p: Persona): Record<string, unknown> => {
    const sexSpecific: Record<string, unknown> = {};
    const menopause: Record<string, string> = { postmenopausal: "post", perimenopausal: "peri", premenopausal: "pre" };
    if (menopause[p.state.physiological_state]) sexSpecific.menopause_status = menopause[p.state.physiological_state];
    if (p.state.hormone_therapy) sexSpecific.hrt = p.state.hormone_therapy;
    if (p.state.oral_contraception) sexSpecific.contraception = "oral";
    return {
      version_number: 1,
      conditions: { keys: p.context.conditions },
      medications: p.context.medications.map((key) => ({ key })),
      supplements: p.context.supplements,
      sex_specific: sexSpecific,
    };
  };
  const byKey = (key: string, value: number, kind = "key-canonical"): Raw => ({ name: key, value, unit: getCanonicalUnit(key) ?? "", biomarkerKey: key, matchConfidence: "exact", kind });
  const cases: Case[] = personas.map((p) => ({
    id: `persona:${p.id}`,
    sex: p.sex,
    age: p.age,
    version: versionOf(p),
    raw: Object.entries(p.values).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => byKey(k, v)),
  }));

  // ─── Units EVA converts for each key (the base's convertBiomarker), with the factor checked both ways ───
  const CANDIDATE_UNITS = [
    "mmol/L", "µmol/L", "nmol/L", "pmol/L", "mg/dL", "mg/L", "g/L", "g/dL", "µg/dL", "µg/L", "ng/mL", "ng/dL", "pg/mL",
    "mEq/L", "mU/L", "mIU/L", "µIU/mL", "IU/L", "U/L", "µkat/L", "%", "mmol/mol", "mg/mmol", "mg/g", "ng/L", "µg/mL",
  ];
  const keys = [...new Set(PLAIN.map((r) => r.biomarker_key))].sort();
  const conversions = new Map<string, Array<{ unit: string; factor: number }>>();
  for (const key of keys) {
    const canonical = getCanonicalUnit(key);
    if (!canonical) continue;
    const list: Array<{ unit: string; factor: number }> = [];
    for (const unit of CANDIDATE_UNITS) {
      if (normalizeUnit(unit) === normalizeUnit(canonical)) continue;
      const one = convertBiomarker(key, 1000, unit, { trustUnit: true });
      if (!one.converted || !Number.isFinite(one.value) || one.value <= 0) continue;
      const factor = one.value / 1000;
      const back = convertBiomarker(key, 37 / factor, unit, { trustUnit: true });
      if (!back.converted || Math.abs(back.value - 37) > 1e-9 * 37) continue;
      list.push({ unit, factor });
    }
    if (list.length) conversions.set(key, list);
  }

  // ─── The sweep: seeded panels over every marker, values in and out of every band and at the critical limits ───
  let seed = 20261114;
  const rnd = () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const pick = <T,>(xs: readonly T[]): T => xs[Math.floor(rnd() * xs.length)];
  const num = (x: unknown) => (typeof x === "number" ? x : null);
  const valuesFor = (key: string, sex: "male" | "female", age: number): number[] => {
    const row = pickReferenceRows(PLAIN as never, sex, age).picked.get(key) as Row | undefined;
    const b = row ? [num(row.optimal_low), num(row.optimal_high), num(row.normal_low), num(row.normal_high)].filter((x): x is number => x != null) : [];
    const outv: number[] = [];
    for (const x of b) outv.push(x, x * 0.5, x * 0.9, x * 1.1, x * 2);
    const l = LIMITS.get(key);
    if (l) {
      const unit = 10 ** -(l.decimals ?? 0);
      for (const lim of [l.critical_low, l.critical_high]) {
        if (lim == null) continue;
        outv.push(lim, lim + unit, lim - unit, lim + unit / 2, lim - unit / 2, lim * 1.5, lim * 0.6);
      }
    }
    if (!outv.length) outv.push(1, 10, 100);
    return outv.filter((x) => Number.isFinite(x) && x >= 0);
  };
  // Names as a report prints them, from the seed rows (English and Spanish), for the matcher's path.
  const namesOf = new Map<string, { en: string; es: string }>();
  for (const r of PLAIN) if (!namesOf.has(r.biomarker_key)) namesOf.set(r.biomarker_key, { en: String(r.name_en), es: String(r.name_es) });

  const states = [null, { conditions: { keys: ["pregnancy_current"] } }, { conditions: { keys: ["lactating"] } }, { sex_specific: { contraception: "oral" } }, { sex_specific: { menopause_status: "post" } }, { sex_specific: { menopause_status: "post", hrt: "oral" } }];
  const PANELS = 400;
  for (let i = 0; i < PANELS; i++) {
    const sex = rnd() < 0.5 ? "male" : "female";
    const age = 18 + Math.floor(rnd() * 70);
    const chosen = keys.filter(() => rnd() < 0.45);
    const raw: Raw[] = [];
    for (const key of chosen) {
      let value = Number(pick(valuesFor(key, sex, age)).toPrecision(8));
      if (rnd() < 0.03) value = 0; // a printed zero: the lowest possible value (WS3-45 refuses a metric over it)
      const r = rnd();
      const conv = conversions.get(key) ?? [];
      const unit = getCanonicalUnit(key) ?? "";
      if (r < 0.08) raw.push({ name: key, value, unit, comparator: pick(["<", ">"] as const), biomarkerKey: key, matchConfidence: "exact", kind: "key-bound" });
      else if (r < 0.2 && conv.length) {
        const c = pick(conv);
        raw.push({ name: key, value: Number((value / c.factor).toPrecision(10)), unit: c.unit, biomarkerKey: key, matchConfidence: "exact", kind: `key-converted:${c.unit}` });
      } else if (r < 0.24) raw.push({ name: key, value, unit: "", biomarkerKey: key, matchConfidence: "exact", kind: "key-unitless" });
      else if (r < 0.34 && namesOf.has(key)) {
        const n = namesOf.get(key)!;
        const es = rnd() < 0.5;
        raw.push({ name: es ? n.es : n.en, value, unit, kind: es ? "name-es" : "name-en" });
      } else raw.push({ name: key, value, unit, biomarkerKey: key, matchConfidence: "exact", kind: "key-canonical" });
    }
    const st = sex === "female" ? pick(states) : null;
    cases.push({ id: `panel:${String(i).padStart(3, "0")}`, sex, age, version: st ? { version_number: 1, conditions: { keys: [] }, medications: [], supplements: [], sex_specific: {}, ...st } : null, raw });
  }

  // ─── Calculated-metric edges (WS3-45): a full lipid and glucose panel with one input moved ───
  const BASE_PANEL: Record<string, number> = {
    albumin: 45, alp: 70, alt: 22, ast: 24, creatinine: 0.9, bun: 14, ggt: 20, hba1c: 5.2, glucose_fasting: 88,
    insulin_fasting: 6, apolipoprotein_b_apob: 85, ldl_cholesterol: 110, hdl_cholesterol: 55, triglycerides: 90,
    total_cholesterol: 190, hemoglobin: 14.5, hs_crp: 0.8, vitamin_d_25_oh: 38, neutrophils: 55, lymphocytes: 33,
    ferritin: 90, testosterone_total: 5.2, shbg: 40, tsh: 1.8,
  };
  const edges: Array<[string, Record<string, number | null>]> = [
    ["hdl-above-total", { total_cholesterol: 150, hdl_cholesterol: 160 }],
    ["hdl-equal-total", { total_cholesterol: 160, hdl_cholesterol: 160 }],
    ["hdl-above-total-no-apob-no-ldl", { total_cholesterol: 150, hdl_cholesterol: 160, apolipoprotein_b_apob: null, ldl_cholesterol: null }],
    ["hdl-above-total-no-apob", { total_cholesterol: 150, hdl_cholesterol: 160, apolipoprotein_b_apob: null }],
    ["hdl-zero", { hdl_cholesterol: 0 }],
    ["total-zero", { total_cholesterol: 0 }],
    ["insulin-zero", { insulin_fasting: 0 }],
    ["glucose-zero", { glucose_fasting: 0 }],
    ["neutrophils-zero", { neutrophils: 0 }],
    ["lymphocytes-zero", { lymphocytes: 0 }],
    ["triglycerides-zero", { triglycerides: 0 }],
    ["ast-zero", { ast: 0 }],
    ["alt-zero", { alt: 0 }],
    ["shbg-zero", { shbg: 0 }],
    ["creatinine-zero", { creatinine: 0 }],
    ["normal", {}],
    ["no-total", { total_cholesterol: null }],
    ["hdl-above-total-no-total-tg", { total_cholesterol: null, hdl_cholesterol: 200 }],
  ];
  for (const [name, change] of edges) {
    for (const sex of ["male", "female"] as const) {
      const values: Record<string, number> = { ...BASE_PANEL };
      for (const [k, v] of Object.entries(change)) {
        if (v === null) delete values[k];
        else values[k] = v;
      }
      cases.push({ id: `edge:${name}:${sex}`, sex, age: 45, version: null, raw: Object.entries(values).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => byKey(k, v)) });
    }
  }

  // ─── The name matcher's headline names (WS3-42 commit messages), each in a small panel of its own ───
  const probes: Array<[string, number, string]> = [
    ["LDL (nmol/L)", 1200, ""], ["LDL-P (nmol/L)", 1200, ""], ["HDL (µmol/L)", 30, ""], ["LDL (nm)", 21, ""],
    ["Mercurio (suero)", 4, "µg/L"], ["Magnesio (sangre total)", 2, "mg/dL"], ["Hemoglobina (plasma)", 14, "g/dL"],
    ["Potasio (sangre)", 6.8, "mEq/L"], ["Potasio (suero o plasma)", 4.2, "mEq/L"], ["Potasio (sangre total)", 4.2, "mEq/L"],
    ["Glucosa (plasma)", 92, "mg/dL"], ["Homocisteína (suero)", 9, "µmol/L"], ["Magnesio sangre", 2, "mg/dL"],
    ["Bilirrubina (directa)", 0.2, "mg/dL"], ["Bilirrubina (indirecta)", 0.5, "mg/dL"], ["Calcio (iónico)", 1.2, "mmol/L"],
    ["Testosterona (biodisponible)", 200, "ng/dL"], ["Cortisol (libre)", 1, "µg/dL"], ["Vitamina D (activa)", 40, "pg/mL"],
    ["Cortisol (20:00)", 5, "µg/dL"], ["Cortisol (16:00 h)", 8, "µg/dL"], ["Glucosa (0 min)", 90, "mg/dL"],
    ["Calcio, Serum", 9.5, "mg/dL"], ["Magnesio, Serum", 2.1, "mg/dL"], ["Glucosa / suero", 90, "mg/dL"],
    ["Gamma-glutamiltransferasa", 25, "U/L"], ["Vitamina D 25OH", 35, "ng/mL"], ["25-Hydroxy Vitamin D", 35, "ng/mL"],
    ["PCR-hs", 1.1, "mg/L"], ["17β-Estradiol", 60, "pg/mL"], ["Hormona folículo estimulante", 6, "mIU/mL"],
    ["Omega-3 totales", 8, "%"], ["EPA (sangre)", 1, "%"], ["Folato (eritrocitos)", 400, "ng/mL"],
    ["Índice Omega-3", 6, "%"], ["# Neutrófilos", 3500, "/µL"], ["Neutrófilos", 0.3, ""], ["Glucosa (n/a)", 90, "mg/dL"],
    ["Glucosa (s/u)", 90, "mg/dL"], ["Iron % Saturation (TSAT)", 30, ""], ["PSA libre %", 20, "%"], ["Lipoproteína (a) nmol/L", 75, "nmol/L"],
  ];
  probes.forEach(([name, value, unit], i) => {
    const sex = i % 2 ? "female" : "male";
    cases.push({
      id: `probe:${String(i).padStart(2, "0")}:${name}`,
      sex,
      age: 40,
      version: null,
      raw: [{ name, value, unit, kind: "probe-ws3-42" }, byKey("albumin", 45), byKey("glucose_fasting", 88), byKey("hdl_cholesterol", 55), byKey("total_cholesterol", 190)],
    });
  });

  fs.writeFileSync(out, JSON.stringify({ built_on: fs.readFileSync(path.join(tree, "COMMIT.txt"), "utf8").trim(), seed: 20261114, rows: { plain: PLAIN, migrated: MIGRATED }, conversions: Object.fromEntries(conversions), cases }, null, 1));
  const kinds = new Map<string, number>();
  for (const c of cases) for (const r of c.raw) kinds.set(r.kind.split(":")[0], (kinds.get(r.kind.split(":")[0]) ?? 0) + 1);
  console.log(`cases ${cases.length} (personas ${personas.length}, panels ${PANELS}, edges ${edges.length * 2}, probes ${probes.length}); rows ${PLAIN.length}; raw kinds ${JSON.stringify(Object.fromEntries(kinds))}; keys with conversions ${conversions.size} -> ${out}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
