"""Integration rehearsal (scratch): the R5 and R6 cases of compare.py audited by name instead of by position.
R6 (a name the matcher reads differently): every processed and stored entry of any other name must be identical after
R1/R2. R5 (a metric the guard refused): the metrics missing at the head must be exactly the refused ones, and every
other metric identical after R1/R2b. Usage: python3 -I keyed-audit.py cases before after"""
import json, sys
from collections import Counter
sys.argv = sys.argv[:4] + ["/dev/null"]
src = open(__file__.replace("keyed-audit.py", "compare.py")).read()
g = {"__file__": "compare.py"}
exec(compile(src.split("counter = Counter()")[0], "compare.py", "exec"), g)
cases, before, after = g["cases"], g["before"], g["after"]
bad, checked = [], Counter()
for variant in ("plain", "migrated"):
    for cid in sorted(cases):
        b, a = before["capture"][variant][cid], after["capture"][variant][cid]
        g["CURRENT"]["case"] = cases[cid]
        exp = g["expected_after"](b, Counter())
        got = g["normalised_after"](a)
        if not exp.get("result"):
            continue
        changed = {r["name"] for r in cases[cid]["raw"] if r["kind"].startswith(("name-", "probe-")) and g["raw_outcome"](b, r) != g["raw_outcome"](a, r)}
        if changed:
            for field, key in (("processed", "name"), ("unmatched", "name")):
                eb = {x[key]: x for x in exp["result"][field] if x[key] not in changed}
                ea = {x[key]: x for x in got["result"][field] if x[key] not in changed}
                checked[f"R6 {field} entries of other names"] += len(eb)
                if eb != ea:
                    bad.append((variant, cid, field, sorted(set(eb) ^ set(ea)) or [k for k in eb if eb[k] != ea.get(k)]))
            sb = {x["biomarker_name"]: x for x in exp["stored"] if x["biomarker_name"] not in changed}
            sa = {x["biomarker_name"]: x for x in got["stored"] if x["biomarker_name"] not in changed}
            checked["R6 stored rows of other names"] += len(sb)
            if sb != sa:
                bad.append((variant, cid, "stored", [k for k in sb if sb[k] != sa.get(k)]))
        refused = {rm["metricKey"] for rm in ((a.get("result") or {}).get("refusedMetrics") or []) if "metrics" in rm["in"]}
        mb = {m["metricKey"]: m for m in exp["result"]["calculatedMetrics"]}
        ma = {m["metricKey"]: m for m in got["result"]["calculatedMetrics"]}
        missing = set(mb) - set(ma)
        extra = set(ma) - set(mb)
        if not changed:
            checked["metric sets compared"] += 1
            if missing != (refused & set(mb)) or extra:
                bad.append((variant, cid, "metric set", {"missing": sorted(missing), "refused": sorted(refused), "extra": sorted(extra)}))
            for k in set(mb) & set(ma):
                checked["metrics kept compared"] += 1
                if mb[k] != ma[k]:
                    bad.append((variant, cid, f"metric {k}", (mb[k], ma[k])))
            # A refused metric was never computed at the head from inputs that would give a valid one: the refused
            # metric's base value must be one the guard refuses (not finite, zero or below, or non-HDL from total <= HDL).
for k, n in sorted(checked.items()):
    print(f"{k}: {n}")
print("problems:", len(bad))
for x in bad[:30]:
    print(" ", x)
