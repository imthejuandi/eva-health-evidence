#!/usr/bin/env node
// build-items.cjs — builds items.json for the WS1 mop-up round. Read-only on the repository.
// Usage (from the repository root):
//   S=<scratch dir>
//   node docs/signoff/tools/compile.js --out-dir $S/compile-all            (compile of all 30 families, outside the repo)
//   npm run dsrt -- --seed-dir $S/compile-all --round 99 --out $S/checks-all.json
//   node $S/build-items.cjs <repo root> $S
// Re-run it after the D-43 rebuild and after any family file changes: every count comes from the files as they are.
"use strict";
const fs = require("fs");
const path = require("path");
const ROOT = path.resolve(process.argv[2] || ".");
const S = path.resolve(process.argv[3] || ".");
const W = path.join(ROOT, "docs/signoff/work");
const rj = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const { changedAfterVerdict } = require(path.join(ROOT, "docs/signoff/tools/lib/compile-diff.js"));

const famDoc = rj(path.join(W, "families.json"));
const F = famDoc.families;
const fams = Object.keys(F).sort();
const key = (r) => [r.marker_key, r.sex, r.age_group, r.physiological_state].join("|");
const k2f = {};
for (const f of fams) for (const k of F[f].keys) k2f[k] = f;
const short = (f) => f.slice(0, 3);
const fresh = rj(path.join(S, "checks-all.json"));
const changes = rj(path.join(S, "compile-all/changes.json"));
const res = (id) => fresh.results.find((r) => r.id === id) || { failures: [], status: "absent" };
const lastRound = (f) => (F[f].batch === "B01" ? 4 : 2);
const DEC = {}, VER = {}, LED = {};
for (const f of fams) { DEC[f] = rj(path.join(W, "decisions", f + ".json")); VER[f] = rj(path.join(W, "verify", f + ".json")); LED[f] = rj(path.join(W, "ledger", f + ".json")); }

const items = {}; // family -> []
const central = []; // items that belong to no family
for (const f of fams) items[f] = [];
const counters = {};
function add(f, kind, o) {
  const k = `${short(f)}-${kind}`;
  counters[k] = (counters[k] || 0) + 1;
  const it = { id: `${k}-${String(counters[k]).padStart(2, "0")}`, family: f, kind, ...o };
  items[f].push(it);
  return it;
}
function addCentral(kind, o) {
  counters[kind] = (counters[kind] || 0) + 1;
  central.push({ id: `central-${kind}-${String(counters[kind]).padStart(2, "0")}`, family: null, kind, ...o });
}
const FF = "family_fixer", VF = "verifier", CE = "central", W3 = "ws3_package", PH = "physician", EX = "external";

// ─── 1. D-30: rows the decision changed after the verifier's verdict ───
const OPT = ["optimal_low", "optimal_high", "grade"];
const BOUND = ["reference_low", "reference_high", "critical_low", "critical_high", "band_rule", "unit", "marker_class"];
const unexplained = changes.changes.filter((x) => !x.reason);
const unexplainedByRow = {};
for (const x of unexplained) { const k = x.loop_row_key || x.row_key; (unexplainedByRow[k] = unexplainedByRow[k] || []).push(x); }
const reverdictRows = {};
for (const f of fams) {
  const vm = new Map(VER[f].final_rows.map((r, i) => [key(r), [r, i]]));
  DEC[f].final_rows.forEach((r, i) => {
    const hit = vm.get(key(r));
    if (!hit) { add(f, "D30", { source: { file: `docs/signoff/work/decisions/${f}.json`, key: `final_rows[${i}] ${key(r)}` }, row_key: key(r), d30_class: "new_row", what: "Row the fixer added: no verifier verdict exists for it. It needs a research row (author) and a verifier verdict.", owner: VF, check: "E3; G2; D-02 (score eligibility)" }); return; }
    const [v, j] = hit;
    const ch = changedAfterVerdict(r, v);
    if (!ch.length) return;
    const opt = ch.filter((c) => OPT.includes(c));
    const bnd = ch.filter((c) => BOUND.includes(c));
    const cls = opt.length ? "optimal_bounds_or_grade" : bnd.length ? "other_bound_class_or_band_rule" : "text_only";
    const diff = [...opt, ...bnd].map((c) => `${c} ${JSON.stringify(v[c] ?? null)} -> ${JSON.stringify(r[c] ?? null)}`);
    const un = (unexplainedByRow[key(r)] || []).filter((x) => String(x.flag || "").startsWith("verdict on an earlier version"));
    (reverdictRows[f] = reverdictRows[f] || []).push(key(r));
    add(f, "D30", {
      source: { file: `docs/signoff/work/decisions/${f}.json`, key: `final_rows[${i}] ${key(r)}`, compared_with: `docs/signoff/work/verify/${f}.json final_rows[${j}]` },
      row_key: key(r), d30_class: cls, fields_changed_after_verdict: ch, bound_or_grade_changes: diff,
      what: cls === "optimal_bounds_or_grade"
        ? `Fresh verifier verdict and grade on the optimal bounds as compiled (${diff.join("; ")}). The verifier opens the source itself and writes its own evidence record where the bound's only record is the fixer's.`
        : cls === "other_bound_class_or_band_rule"
          ? `Fresh verifier verdict on the row as compiled: a reference bound, class or band rule changed after the verdict (${diff.join("; ")}).`
          : `Fresh verifier verdict on the row as compiled: only texts changed after the verdict (${ch.join(", ")}); the verifier re-reads them against the bounds and the wording rules.`,
      owner: VF,
      check: cls === "optimal_bounds_or_grade" ? "E3 (the verifier assigns the grade); D-02 score eligibility; D6 change reasons (C-21)" : "D6 change reasons (C-21, CEO-6): the verdict documents the row again; G2",
      closes_unexplained_changes: un.length,
      ruling: cls === "optimal_bounds_or_grade" ? "D-30 as worded (optimal bounds or grade)" : cls === "text_only" ? "CEO-6 (a verdict documents only a row unchanged since the verdict); needed to close C-21" : "D-30 as counted by the ruling (17 of 101 counted every bound) and CEO-6",
    });
  });
}

// ─── 2. C-21: unexplained changes a fresh verdict does not close ───
const NEEDS_RECORD = /^(normal_|optimal_|critical_|unit_|row$)/;
for (const x of unexplained) {
  if (String(x.flag || "").startsWith("verdict on an earlier version")) continue;
  const f = x.family;
  const rk = x.loop_row_key || x.row_key;
  const d30 = (reverdictRows[f] || []).includes(rk);
  const isRecord = NEEDS_RECORD.test(x.field) || /^(optimal|reference|critical)_(low|high)$/.test(x.field) || x.field === "row";
  const nonRowColumn = ["panel_category", "is_genetic", "name_es", "name_en"].includes(x.field);
  if (d30 && !isRecord && !nonRowColumn) continue; // closes with the fresh verdict (simulated: 277 -> 9)
  add(f, "C21", {
    source: { file: `${path.relative(ROOT, S) || "."}/compile-all/changes.json (compile of all families)`, key: `${rk} ${x.field}` }, row_key: rk, field: x.field, from: x.from, to: x.to, direction: x.direction, flag: x.flag || null,
    what: nonRowColumn
      ? `Change of ${x.field} (${JSON.stringify(x.from)} -> ${JSON.stringify(x.to)}) has no reason. The column is not one a family file supplies: the reason goes in docs/signoff/work/reconciliation/reasons.json, or the change is reverted in the compile.`
      : x.field === "row"
        ? `Production row ${rk} is removed without the decision's own record: add a changes[] entry with row_key, field "row", to null, a reason and evidence (CEO-11, C-02).`
        : `Add a change record (reason, source${x.direction === "loosen" ? ", and a grade A or B evidence id: it is a loosening" : ""}) whose "to" is the compiled value, or restore the production value: ${x.field} ${JSON.stringify(x.from)} -> ${JSON.stringify(x.to)}.`,
    owner: nonRowColumn ? CE : FF, check: "D6 (C-21); D5",
  });
}

// ─── 3. the family's failing checks, on today's runner and the compile of all 30 families ───
const allKeys = new Set(Object.keys(k2f));
const markerOf = (k) => { for (const s of String(k).split("|")) if (allKeys.has(s)) return s; return null; };
const famOfKey = (k) => { const s = String(k).split("|")[0]; if (F[s]) return s; const m = markerOf(k); return m ? k2f[m] : null; };
const K1_REL = { bun_creatinine: "f03_kidney", egfr_ckd_epi_2021: "f03_kidney", free_t_vermeulen: "f19_male_hormones", lymphocytes_absolute: "f12_white_cells_core", neutrophils_absolute: "f12_white_cells_core", nlr: "f12_white_cells_core", non_hdl: "f06_lipids_core", total_protein: "f01_albumin_proteins", homa_ir: "f05_glycaemia", tsat: "f14_iron" };
const src = (id, k) => ({ file: `${path.relative(ROOT, S) || "."}/checks-all.json (today's runner on the compile of all families); latest stored result docs/signoff/work/checks/<family>-r<n>.json`, key: `${id} ${k}` });
function checkItem(id, fl) {
  const k = String(fl.key), d = String(fl.detail || "");
  const f = famOfKey(k);
  const base = { source: src(id, k), failure_key: k, detail: d.slice(0, 400) };
  if (id === "D1") return addCentral("D1", { ...base, what: "The 'Biological Age' pseudo-row is still in the seed; a marker in no family has no retirement route (C-25, CEO-14).", owner: CE, check: "D1" });
  if (id === "D6") return addCentral("D6", { ...base, what: "The reconciliation set (diff, forward, rollback, reader tests) is written by the single compile (C-03) and D6's own test needs tightening (C-26).", owner: CE, check: "D6" });
  if (id === "L1") return addCentral("L1", { ...base, what: "The classifier derives 'critical' from reference limits (C-04).", owner: W3, package: "WS3-11, WS3-12, WS3-13", check: "L1" });
  if (id === "L2") return null; // aggregated below
  if (id === "P1") return addCentral("P1", { ...base, what: "Pre-analytical inputs missing in the app.", owner: W3, package: "WS3-20, WS3-23", check: "P1" });
  if (id === "S3") return null; // aggregated below
  if (id === "Q1") return null; // aggregated below
  if (id === "G2") { const m = k.split("|")[1]; const ff = k2f[m]; return add(ff, "G2", { ...base, what: "An added row differs from the template row the compile picked for it (category or 'tested twice a year' column, which no family file supplies): fix the template pick or the column in the compile, or record the difference centrally.", owner: CE, check: "G2" }); }
  if (id === "K1") { const rel = k.split("|")[1]; const ff = K1_REL[rel]; return add(ff, "K1", { ...base, k1_kind: k.split("|")[0], what: k.startsWith("opposite") ? "Opposite-category pair on a derived relationship inside the family. Not moved by the mop-up fixer: a bound may not move to pass a check; workstream 1-K decides (accepted reason, per-marker scale under D-14, or a physician question such as f03-DQ04)." : "One-step disagreement on a derived relationship: needs an accepted reason in coherence/accepted-reasons.json (C-13).", owner: CE, package: "WS1-K", check: "K1" }); }
  if (!f) return addCentral(id, { ...base, what: "Not attributable to a family.", owner: CE, check: id });
  if (id === "N1") return add(f, "N1", { ...base, what: "Population rule unresolved: a resolution in nhanes/n1-resolutions.json (C-14). The family's part, if any, is the 'reached by a minority' label and a physician question when more than 60% are non-optimal at 70 to 79.", owner: CE, package: "WS1-K", check: "N1" });
  if (id === "X1") return add(f, "X1", { ...base, what: "Version 3 reads albumin above 48 g/L as favourable while the row marks it out of range: one judged exception entry (D-25, C-15). The laboratory's ceiling may not move to pass the check; the dye Echevarne uses is awaited (methods letter).", owner: W3, package: "WS3-24", check: "X1" });
  if (id === "S2") return add(f, "S2", { ...base, what: "Scored set: classes, eligibility and groups are generated from the governance files and the verifier's grades.", owner: W3, package: "WS3-09", check: "S2" });
  if (id === "C1") {
    if (/labelled_by_age_proxy/.test(k)) return add(f, "C1", { ...base, what: "A 'Premenopausal' row is picked by age: accepted only in the narrow form of D-13 (no status recorded, flag set, note rendered).", owner: W3, package: "WS3-14, WS3-17", check: "C1" });
    return add(f, "C1", { ...base, what: "State or cycle-phase row never picked: the app's picker and the runner's C1 do not read the declared state yet.", owner: W3, package: /Pregnancy|Lactation/.test(k) ? "WS3-14, WS3-15, WS3-17" : "WS3-14, WS3-16, WS3-17", check: "C1" });
  }
  if (id === "D3") {
    if (/no_catalogue_band/.test(k)) return add(f, "D3", { ...base, what: "Pregnancy or lactation row with no Echevarne band for the state. Either remove the state row and rely on state rule 2.1 (as 9 families did), or keep it with its basis and source recorded. Depends on the physician's answer to D-12.", owner: FF, depends_on: "physician (D-12)", check: "D3; C1" });
    if (/band_split/.test(k)) return add(f, "D3", { ...base, what: "The row's age band spans two laboratory bands: cut the row at the laboratory's age (for example 18-20 and 21+), each with Echevarne's bounds.", owner: FF, needs: "new row keys: author stage and verifier verdict", check: "D3" });
    if (/no_catalogue_row/.test(k)) return add(f, "D3", { ...base, what: "No catalogue row for this key in this unit: record reference_basis population or decision_limit with its source on the row, or correct the unit; if the catalogue mapping is wrong it is a central input fix.", owner: FF, check: "D3" });
    if (/uncovered_ages/.test(k)) return add(f, "D3", { ...base, what: "The labelled row covers ages the catalogue band does not: state the age range the row applies to, or record the basis for the ages outside the laboratory's band.", owner: FF, check: "D3" });
    return add(f, "D3", { ...base, what: "Reference bounds differ from the catalogue without a recorded basis and source: correct the bounds or record reference_basis and its source.", owner: FF, check: "D3" });
  }
  if (id === "D5") return null; // covered by the C21 items (same rows), listed below when not
  if (id === "E1") {
    if (/\|number$/.test(k)) return add(f, "E1", { ...base, what: /pregnancy|lactation/.test(d) && !DEC[f].final_rows.some((r) => ["pregnancy", "lactation"].includes(r.physiological_state)) ? "The record supports a state row the decision removed: drop the stale supports[] link, or replace the quote with the exact sentence that holds the number." : "Replace the quote with the exact source sentence that holds the number (PubMed or PMC record), or state in the record's notes that the opened text does not hold it, so the grade rule applies.", owner: FF, stage: "evidence pass (research and verify files)", check: "E1" });
    return add(f, "E1", { ...base, what: "A sex, age or state split has no evidence record linked under the split's name: add the supports[] link, or the record, in the file named in the key (research, verify or decision).", owner: FF, stage: /\|decision\|/.test(k) ? "fixer (decision file)" : "evidence pass (research and verify files)", check: "E1" });
  }
  if (id === "E2") return add(f, "E2", { ...base, what: /unopenable/.test(k) ? (/catalogo-2026/.test(d) ? "The record cites Echevarne's catalogue by a repository URL the quote check cannot open, so the grade must be D. Cite the catalogue in reference_source only and drop the record from the bound's support, or regrade it D." : "Source not openable: switch the identifier to the PubMed or Europe PMC record of the same publication, or grade it D.") : "Quote not found in the source: copy the exact sentence, or state that the number is not in the opened text.", owner: FF, stage: "evidence pass (research and verify files)", check: "E2 (needs 98% found; 97.1% today)" });
  if (id === "M1") { const mk = markerOf(k); const locked = ["apolipoprotein_b_apob", "ldl_cholesterol", "non_hdl_cholesterol", "homa_ir"].includes(mk); return add(f, "M1", { ...base, what: "A reference floor of 0 makes a 'below range' zone reachable with no message. Set the floor to none with a change record, as f06 did for total cholesterol and triglycerides." + (locked ? " The row is a locked decision: E6 must not read the change as a silent change, so the orchestrator rules first whether the 0 floor is part of the lock." : ""), owner: FF, depends_on: locked ? "orchestrator ruling on the locked rows (E6)" : null, check: "M1; D5" }); }
  if (id === "M4") return add(f, "M4", { ...base, what: "The clinical note quotes a number that is neither a bound of the row nor in its explanatory_numbers: correct the note, or declare the number in explanatory_numbers if it is right (C-27).", owner: FF, check: "M4" });
  if (id === "Q1") return null; // aggregated below
  return add(f, id, { ...base, what: "Failing check.", owner: CE, check: id });
}
for (const r of fresh.results) if (r.status === "fail") for (const fl of r.failures) checkItem(r.id, fl);
// D5 failures not already covered by a C21 item
for (const fl of res("D5").failures) {
  const f = famOfKey(fl.key); const mk = markerOf(fl.key);
  if (items[f].some((it) => it.kind === "C21" && String(it.row_key).startsWith(mk + "|"))) continue;
  add(f, "D5", { source: src("D5", fl.key), failure_key: String(fl.key), detail: String(fl.detail).slice(0, 300), what: "Difference from production without a documented reason.", owner: FF, check: "D5" });
}
addCentral("L2", { source: src("L2", `${res("L2").failures.length} failures`), what: `Action-limits table after WS3-18 (merged 57c3b33): ${res("L2").summary}. The failures left wait on the physician (AL-08.2 has no follow-up sentence; AL-12.3 and AL-12.4 have no stated number).`, owner: PH, also: [W3], package: "WS3-18 (merged), WS3-23, WS3-29", check: "L2" });
for (const [f, rk, txt] of [
  ["f18_electrolytes", "potassium|both|All Adults|none", "the table's potassium action limit starts at 5.0 mEq/L and the f18 row's at 5.1; and 'at or above' against 'above' for potassium 6.0"],
  ["f22_prostate", "psa_total|male|18-49|none", "the table says PSA 'below 1' and 'below 2' where the f22 rows say '1 or less' and '2 or less'"],
  ["f12_white_cells_core", "neutrophils_absolute|female|All Adults|none", "the f12 rows add a 1,000/µL neutrophil tier the table does not have (AL-14; the table also needs ancestry, which EVA does not record)"],
  ["f30_urine_pancreas_bilirubin", "total_bilirubin|both|18-59|none", "'at or above' against 'above' for bilirubin 15 mg/dL"],
]) add(f, "TABLE", { source: { file: "docs/signoff/work/ws3/README.md", key: "Wave 3 results, WS3-18: the table and the decided rows disagree" }, row_key: rk, what: `The action-limits table and the decided row disagree: ${txt}. The orchestrator settles which is right before the round (governance/action-limits.json, with the physician where it is clinical); the fixer then aligns the row, and WS3-29's equality script regenerates the copied limits.`, owner: CE, also: [FF, PH], check: "L2; G6" });
addCentral("S3", { source: src("S3", `${res("S3").failures.length} failures`), what: "Redundancy groups double counted on the fixture panels.", owner: W3, package: "WS3-09", check: "S3" });
addCentral("Q1", { source: src("Q1", `${res("Q1").failures.length} failures`), what: "36 healthy personas see a 'critical' code (an out-of-range value on a row with no critical field, mostly LDL above 100 mg/dL) and 4 pregnant or lactating personas see a category or a score: the classifier zones and the state path. No row message carries critical-tier wording any more (M3: 0 hits).", owner: W3, package: "WS3-11, WS3-15, WS3-17", check: "Q1" });
for (const id of ["C2", "C3", "E3", "E5", "M5", "P2", "P3", "S4", "S6", "G1", "G4", "G5", "G6", "G7", "G8"]) {
  const r = res(id); if (r.status !== "blocked") continue;
  const own = { C2: [W3, "WS3-17"], C3: [CE, "family pages, pack assembly (WS4)"], E3: [CE, "grade C decision table (docs/signoff/work/grade-c-table.json), then the physician signs or refuses each band"], E5: [CE, "blind re-audit"], M5: [CE, "final judges"], P2: [W3, "WS3-19"], P3: [EX, "Echevarne's lowest reportable values (C-07)"], S4: [W3, "WS3-09"], S6: [W3, "WS3-26"], G1: [CE, "round changes file"], G4: [CE, "WS4"], G5: [CE, "WS4"], G6: [CE, "WS4"], G7: [CE, "WS4"], G8: [CE, "WS4"] }[id];
  addCentral("blocked", { source: src(id, "blocked"), what: `Blocked check: ${String(r.summary).slice(0, 200)}`, owner: own[0], package: own[1], check: id });
}

// ─── 4. hand-offs recorded by workstream 3, checked against the files of today ───
const HAND = "docs/signoff/work/ws3/README.md, 'WS1 hand-offs that WS3's checks wait on'";
const rulings = "docs/signoff/work/governance/fable-ws3-decisions.md";
const tab = {}; for (const e of rj(path.join(W, "governance/critical-limits.json")).entries) tab[e.marker_key] = e;
const closedHandoffs = [];
// 4a critical fields against the table
{
  const need = { calcium_serum: "f16_bone_mineral", potassium: "f18_electrolytes", sodium: "f18_electrolytes", total_bilirubin: "f30_urine_pancreas_bilirubin", tsh: "f15_thyroid" };
  for (const [mk, f] of Object.entries(need)) {
    const rs = DEC[f].final_rows.filter((r) => r.marker_key === mk); const e = tab[mk];
    const ok = rs.length && rs.every((r) => (r.critical_low ?? null) === (e.critical_low ?? null) && (r.critical_high ?? null) === (e.critical_high ?? null) && (e.none_because ? !!r.critical_none_reason : true));
    if (ok) closedHandoffs.push({ handoff: `critical fields or 'none, because' for ${mk} (${short(f)})`, status: "closed", evidence: `decisions/${f}.json rows equal governance/critical-limits.json; L1 reports ${res("L1").summary.split(";")[0]}` });
    else add(f, "HANDOFF", { source: { file: HAND, key: mk }, what: `Critical fields of ${mk} differ from critical-limits.json.`, owner: FF, check: "L1" });
  }
  for (const f of fams) DEC[f].final_rows.forEach((r, i) => {
    if (r.critical_low == null && r.critical_high == null) return;
    if (!tab[r.marker_key]) add(f, "HANDOFF", { source: { file: rulings, key: "D-18" , row: `decisions/${f}.json final_rows[${i}]` }, row_key: key(r), topic: "critical_limit_without_table_entry", what: `The row carries a critical limit (${r.critical_low ?? "none"} / ${r.critical_high ?? "none"} ${r.unit}) with no entry in critical-limits.json. Under D-18 it needs its own signed table entry or leaves the row. Recommended: the orchestrator adds the entry to the table for the physician's session 1 (urea mirrors BUN's 100 mg/dL); the fixer removes the field only if the entry is refused.`, owner: CE, also: [PH, FF], check: "L1 (as tightened by WS3-23)" });
    else {
      const cls = tab[r.marker_key].action_class;
      for (const side of ["critical_low", "critical_high"]) {
        const m = ((r.messages || {}).en || {})[side]; if (!m || r[side] == null) continue;
        if (cls === "emergency" && !/Go to an emergency department today/i.test(m)) add(f, "HANDOFF", { source: { file: rulings, key: "D-18", row: `decisions/${f}.json final_rows[${i}].messages.*.${side}` }, row_key: key(r), side, topic: "critical_message_weaker_than_table", what: "The row's critical-tier message closes with 'Contact a doctor today; if you cannot, go to an emergency department' where the table's action class is 'emergency' ('Go to an emergency department today'). Align it with the table's sentence in both languages, or drop the row's critical-tier message: under D-18 the app never shows it.", owner: FF, check: "L1; Q1 (critical wording equal to the signed table)" });
      }
    }
  });
}
// 4b duplicates
closedHandoffs.push({ handoff: "duplicate calcium (f16) and DHEA-S 18-29 (f21) rows", status: "closed", evidence: `D1: ${res("D1").summary}; C1 reports 0 both-vs-sex overlaps` });
// 4c state rows' messages against state-rules 2.1
for (const f of fams) DEC[f].final_rows.forEach((r, i) => {
  if (!["pregnancy", "lactation"].includes(r.physiological_state)) return;
  const en = (r.messages || {}).en || {}; const sides = ["below_range", "above_range", "below_optimal", "above_optimal"].filter((s) => en[s]);
  if (!sides.length) return;
  add(f, "HANDOFF", { source: { file: rulings, key: "D-12 (WS1 hand-off)", row: `decisions/${f}.json final_rows[${i}].messages` }, row_key: key(r), topic: "state_row_messages", what: `Under state rule 2.1 a declared pregnancy or lactation shows the laboratory interval only, so this row's ${sides.join(" and ")} messages are unreachable: delete them (both languages), with a change record. ${r.reference_basis === "echevarne_interval" ? "" : "The row's basis is a guideline limit, not the laboratory's interval: under D-12 the value is then shown without an interval, and haemoglobin and ferritin are the exceptions the physician is asked about, so keep the deleted texts in the family's question file. "}If the physician amends 2.1 for the marker, the texts return as a signed change.`, owner: FF, depends_on: "physician (D-12 question) only for the exception", check: "M1 (messages on unreachable zones); C2; Q1 rule 2" });
});
// 4d uACR
if (!Object.keys(k2f).some((k) => /acr|albumin_creatinine/.test(k))) add("f30_urine_pancreas_bilirubin", "HANDOFF", { source: { file: HAND, key: "a uACR row in mg/g (f30)" }, topic: "uacr_row", what: "No row exists for the urine albumin-to-creatinine ratio in mg/g (Echevarne B0848, '<30 mg/g creat', catalogue line 52); f30 has only the concentration in mg/L, to which action limit AL-03 does not apply. A new marker key is needed first (families.json f30 keys, marker-classes.json, the catalogue mapping in the family input), then an author writes the row, the verifier grades it and the fixer brings it into the decision.", owner: CE, also: [FF, VF], needs: "new marker key (central, in the D-43 rebuild), then author stage and verifier verdict", check: "L2 (urine_acr)" });
// 4e vitamin D grade
{ const r = DEC.f16_bone_mineral.final_rows.find((x) => x.marker_key === "vitamin_d_25_oh"); const v = VER.f16_bone_mineral.row_verdicts.find((x) => x.row_key === key(r));
  closedHandoffs.push({ handoff: "vitamin D's grade (f16)", status: v && v.grade === r.grade && !changedAfterVerdict(r, VER.f16_bone_mineral.final_rows.find((x) => key(x) === key(r))).length ? "closed" : "open", evidence: `verifier grade ${v && v.grade}, row grade ${r.grade}, row unchanged since the verdict` }); }
// 4f RCV inputs
for (const f of fams) DEC[f].final_rows.forEach((r, i) => {
  if (r.optimal_low == null && r.optimal_high == null) return;
  const rc = r.rcv || {};
  if (rc.rcv_pct != null) return;
  if (rc.cvi_pct == null) add(f, "HANDOFF", { source: { file: rulings, key: "D-23 (WS1 hand-off: RCV inputs)", row: `decisions/${f}.json final_rows[${i}].rcv` }, row_key: key(r), topic: "rcv_no_cvi", what: "The row has an optimal band and no within-person variation (CVI): add the CVI with its source (EFLM database or a published estimate), or state why none exists (a calculated value takes it from its components).", owner: FF, check: "P2" });
  else add(f, "HANDOFF", { source: { file: rulings, key: "D-23", row: `decisions/${f}.json final_rows[${i}].rcv` }, row_key: key(r), topic: "rcv_no_cva", what: "The row has a CVI and no analytical variation (CVA): Echevarne's figure is awaited (methods letter). No stand-in may be written unless the physician allows a sourced one (D-23 question).", owner: EX, also: [PH], check: "P2" });
});
// 4g albumin ceiling and dye
add("f01_albumin_proteins", "HANDOFF", { source: { file: HAND, key: "albumin's ceiling and dye (f01)" }, row_key: "albumin|both|All Adults|none", what: "Albumin's ceiling of 48 g/L and the dye Echevarne uses: nothing for the fixer. X1 closes by one judged exception (D-25, WS3-24), N1's 17.5% of young men outside by a WS1-K resolution, and the dye by the methods letter. The physician chooses between the exception and f01's stricter recommendation.", owner: W3, also: [EX, PH, CE], package: "WS3-24; WS1-K; methods letter", check: "X1; N1" });
// 4h f03 eGFR rows after WS3-28
DEC.f03_kidney.final_rows.forEach((r, i) => {
  if (r.marker_key !== "egfr_creatinine_based") return;
  add("f03_kidney", "HANDOFF", { source: { file: "docs/signoff/work/ws3/README.md", key: "WS3-28 (merged 131245a), D-28, D-37", row: `decisions/f03_kidney.json final_rows[${i}] method_note, messages, clinical_notes` }, row_key: key(r), topic: "egfr_text_after_ws3_28", what: "The row's texts say the app computes no eGFR and shows a laboratory eGFR as a value only. Since WS3-28 the app computes eGFR (CKD-EPI 2021, from creatinine, age at the draw and sex) and classifies only that one. Rewrite the method note, notes and messages to the rule as merged, in both languages; leave the sentence 'This marker does not count toward the score' as it is (it changes only if the physician admits the computed eGFR, D-06). The sentence for a laboratory's own eGFR moves to wording-rules.md section 7 (central, WS3-34).", owner: FF, also: [CE], check: "G6 (texts match the app); Q1; K1 texts" });
});
add("f03_kidney", "HANDOFF", { source: { file: rulings, key: "D-06 (WS1 hand-off)" }, what: "If the physician admits the computed eGFR to the score, f03's fixer changes the eGFR rows' 'This marker does not count toward the score' text. Not before.", owner: PH, also: [FF], check: "S2 (WS3-09 stops on a scored row that says it does not count)" });
// 4i identical state rows (D-13)
{
  const f = "f14_iron"; const rs = DEC[f].final_rows.filter((r) => r.marker_key === "ferritin" && ["premenopausal", "postmenopausal"].includes(r.physiological_state));
  const sig = (r) => [r.reference_low, r.reference_high, r.optimal_low, r.optimal_high, r.critical_low, r.critical_high].join(",");
  if (rs.length === 2 && sig(rs[0]) === sig(rs[1])) add(f, "HANDOFF", { source: { file: rulings, key: "D-13 (WS1 hand-off)", row: `decisions/${f}.json ferritin|female|All Adults|premenopausal and |postmenopausal` }, row_key: "ferritin|female|All Adults|premenopausal + postmenopausal", topic: "merge_identical_state_rows", what: `The premenopausal and postmenopausal ferritin rows hold the same bounds (${rs[0].reference_low} to ${rs[0].reference_high} ${rs[0].unit}): merge them into one row for women in no state, so the age-50 note does not show where the choice changes nothing. The merged row has a new key, so the author adds it to the research file, the verifier gives its verdict and the fixer records the two removals. TSAT's two rows differ (45 and 50%) and stay.`, owner: FF, needs: "new row key: author stage and verifier verdict", check: "C1 (labelled pick by age); D-13" });
}
// 4j out-of-range messages with critical-tier wording
closedHandoffs.push({ handoff: "out-of-range messages that still carry critical-tier wording (M3, Q1)", status: "closed for the rows and notes", evidence: `M3: ${res("M3").summary}. Q1's 36 'critical' codes come from the classifier, not from row text (WS3-11, WS3-17).` });
closedHandoffs.push({ handoff: "cycle-phase rows and the estradiol decision (f20)", status: "rows decided in B08; reachability waits on WS3-16 and WS3-17", evidence: "decisions/f20_female_hormones.json holds follicular, ovulatory, luteal and postmenopausal rows; C1's 16 unreachable f20 rows and the disputed items on the luteal days are listed as workstream 3 and central items" });
// stale app-state sentences
for (const f of fams) DEC[f].final_rows.forEach((r, i) => {
  if (!/reference-row\.ts|Until [^.]{0,80} reads the declared state/i.test(JSON.stringify(r))) return;
  add(f, "TEXT", { source: { file: `docs/signoff/work/decisions/${f}.json`, key: `final_rows[${i}] ${key(r)}` }, row_key: key(r), what: "A text on the row describes the app's code as it was ('until reference-row.ts reads the declared state …'). State the rule the physician signs instead (state-rules.md), without naming the app's files; WS3-03 already reads the state and WS3-14 to WS3-16 will apply it.", owner: FF, check: "G6; Q1" });
});
// class a rows that would score but say they do not count
for (const f of fams) DEC[f].final_rows.forEach((r, i) => {
  if (r.marker_class !== "a" || !["A", "B"].includes(r.grade) || (r.optimal_low == null && r.optimal_high == null)) return;
  if (!/does not count toward (the|your) (EVA )?score/i.test(JSON.stringify(r.messages || {}))) return;
  if (["egfr_creatinine_based", "cystatin_c"].includes(r.marker_key)) return; // D-06: no kidney marker scores yet; the sentence is right until the physician admits the computed eGFR
  add(f, "TEXT", { source: { file: rulings, key: "D-02 (WS3-09 stops on such a row)", row: `decisions/${f}.json final_rows[${i}]` }, row_key: key(r), what: "Class a row with a grade A or B band whose message says the marker does not count toward the score: WS3-09's generator stops on it. Decide with marker-classes.json which is right and correct the text or the class.", owner: FF, also: [CE], check: "S2" });
});
// marker class against governance
{
  const mc = rj(path.join(W, "governance/marker-classes.json")); const m = mc.markers || mc.entries || mc;
  const get = (k) => { const e = Array.isArray(m) ? m.find((x) => (x.marker_key || x.key) === k) : m[k]; return e && (e.class ?? e.draft_class); };
  const seen = new Set();
  for (const f of fams) for (const r of DEC[f].final_rows) { const g = get(r.marker_key); if (g === r.marker_class || seen.has(r.marker_key)) continue; seen.add(r.marker_key);
    add(f, "CLASS", { source: { file: "docs/signoff/work/governance/marker-classes.json", key: r.marker_key }, row_key: key(r), what: `The row's class (${r.marker_class}, from the verifier) differs from marker-classes.json (${g}). Under D-06 the class is taken from the verifier: the governance file is updated with WS3-09 and recorded in the decision register.`, owner: CE, package: "WS3-09 (marker-classes.json)", check: "S2; C-16" }); }
}
// C-29, C-22, C-23
{ const c = DEC.f05_glycaemia.changes.find((x) => /insulin_fasting/.test(x.row_key) && x.field === "reference_low" && !(x.evidence_ids || []).length);
  if (c) add("f05_glycaemia", "KNOWN", { source: { file: "docs/signoff/work/central/known-issues.md", key: "C-29" }, row_key: c.row_key, what: "The change record for insulin's reference floor (0 to none) names no evidence record: add the evidence id (Echevarne prints '<29.1' with no floor).", owner: FF, check: "D6" }); }

// ─── 5. judge-raised blocking items still open in the ledgers (physician question or disputed) ───
function judgeOwner(x) {
  const s = x.summary, c = String(x.check_id).replace(/ /g, "_"), id = x.id;
  const o = (owner, what, extra = {}) => ({ owner, what, ...extra });
  if (id === "f22_prostate--definition:reference_interval--psa_free.male.All_Adults.none--low") return o(FF, "Free PSA carries a reference floor of 0 on the laboratory basis although Echevarne prints no limit: set the floor to none with a change record (also M1 and D5 on this row).");
  if (id === "f12_white_cells_core--definition:optimal_band--nlr.both.65-74.none--low") return o(FF, "NLR's optimal floor of 0.37 is derived from laboratory intervals, not from outcomes: remove it (or cite outcome evidence), then the verifier grades the four NLR rows.", { also: [VF] });
  if (id === "f12_white_cells_core--L2--neutrophils_absolute.female.All_Adults.none--low") return o(CE, "Action limit AL-14 starts at 1,000/µL on the row and at 500/µL in action-limits.json: the orchestrator settles which is right in the governance table; the fixer then aligns the row.", { also: [FF] });
  if (id === "f18_electrolytes--G6--potassium.both.All_Adults.none--high") return o(FF, "Potassium of exactly 6.0 mEq/L gets three different follow-ups (critical limit compared strictly, action limit AL-09b, above-range message): make the row's texts and its action limit agree on which tier 6.0 belongs to, equal to critical-limits.json.");
  if (id === "f18_electrolytes--M3--sodium.both.All_Adults.none--low") return o(CE, "The sodium action text in governance/action-limits.json applies a disease definition to the client: governance table wording (disputed).");
  if (/^f03_kidney--G6--(bun|urea)\./.test(id) && /Clinical_Notes|Clinical notes/i.test(s)) return o(CE, "Already fixed: the BUN and urea notes in decisions/f03_kidney.json no longer hold the sentence the judge quoted (read on the files of today). The ledger entry stays open only because the raising lens has not re-read it: it closes in the mop-up's closing pass or in the cold panel.", { closing_pass: true });
  if (/^f03_kidney--(G6|N1)--creatinine\.female/.test(id) && /21\.1|23\.8/.test(s)) return o(FF, "Three figures for the same share of healthy women aged 70 to 79 outside the creatinine interval: the method note still says 18% and question f03-DQ02 says 21.1%, while check N1 reports 23.8%. Quote one figure, with its source, in both places.");
  if (/^f03_kidney--E3--/.test(id)) return o(VF, "BUN and urea carry a grade C band whose grade the fixer lowered: the verifier grades the band as compiled (D-30); the band then goes to the grade C table for the physician.", { also: [CE, PH] });
  if (id === "f03_kidney--Q1--egfr_creatinine_based.both.18-39.none--low") return o(FF, "eGFR messages name CKD-EPI 2021 while the method note says the app computes none: closed by the f03 eGFR text hand-off after WS3-28 (disputed).");
  if (id === "f04_inflammation--Q1--hs_crp.both.All_Adults.none--none") return o(FF, "The hs-CRP method note describes the app's code as it was: state the rule instead (see the TEXT item on this row).");
  if (id === "f08_uric_acid_metabolic--E3--uric_acid.female.All_Adults.none--high" || id === "f06_lipids_core--E3--hdl_cholesterol.female.All_Adults.none--low") return o(VF, "A judge challenged the grade B of this optimal bound (single-source or laboratory-derived edge): add the row to the verifier's re-verdict list, so the grade is confirmed or lowered by the verifier and not by a fixer.", { also: [PH] });
  if (/^f23_omega3--/.test(id) || /^f27_.*--E3--/.test(id)) return o(PH, "Grade C band narrower than the reference interval (disputed): it goes to the grade C decision table, which the orchestrator builds and the physician signs or refuses.", { also: [CE] });
  if (/^f27_/.test(id) && /definition:reference_interval|N1/.test(c + id)) return o(PH, "Liposcale target or percentile used as the reference limit (disputed): the physician decides the basis of the f27 limits.");
  if (/^f27_/.test(id) && /age_groups/.test(c)) return o(CE, "No written policy for ages 18 to 19, 70 to 84 and 85 and over: family page (C3), pack assembly.");
  if (/definition:age_groups/.test(c)) return o(CE, "Older-adult and 18-19 policy not written: family page (C3); the physician sees the disputed item.", { also: [PH] });
  if (/^f19_.*definition:reference_interval/.test(id)) return o(PH, "Free testosterone reference interval from a population study against Echevarne's immunoassay inputs (disputed): physician question.");
  if (/^f19_.*--K1--/.test(id)) return o(CE, "Free testosterone against total testosterone, SHBG and albumin: K1 pattern for WS1-K; the reference basis is a physician question.", { package: "WS1-K", also: [PH] });
  if (/^f20_.*definition:physiological_state--anti_mullerian/.test(id)) return o(PH, "No AMH policy for the postmenopausal state (disputed): physician question; a row is added only if he asks for one.");
  if (/^f20_/.test(id) && /luteal|cycle|follicular|C1--estradiol\.female\.All_Adults/.test(id + s) && /definition:physiological_state|C1|C2/.test(c)) return o(CE, "The cycle days of each phase and the precedence between a recorded cycle day and the age-50 fallback are not written: state-rules.md section 5 (governance), then WS3-16 applies it.", { also: [W3], package: "state-rules.md; WS3-16" });
  if (/^f20_.*--C1--/.test(id) || /^f20_.*definition:physiological_state--fsh\.female\.All_Adults\.postmenopausal/.test(id)) return o(W3, "The '21+' rows outrank the postmenopausal rows in today's picker: the state-aware picker (D-13) reaches the labelled row from the recorded status, with age 50 as the flagged fallback.", { package: "WS3-14, WS3-17" });
  if (id === "f22_prostate--G6--psa_total.male.70plus.none--high") return o(CE, "Ages for the PSA 3 ng/mL follow-up differ between governance AL-02 and the f22 rows (disputed): settle in action-limits.json; the physician sees it.", { also: [PH] });
  if (id === "f26_other_vitamins--N1--vitamin_c_ascorbic_acid.both.All_Adults.none--low") return o(CE, "Vitamin C reference floor against NHANES: N1 resolution (WS1-K) or a physician question.", { package: "WS1-K", also: [PH] });
  if (c === "G6" || (c === "D5" && /biomarker-sources/.test(s))) return o(CE, "The published summaries in biomarker-sources.json contradict the rows (C-09, C-28): compile-sources.js, in repair; nothing for the family.");
  if (c === "K1") return o(CE, "K1 pattern inside the family (C-13): workstream 1-K decides (accepted reason, per-marker scale or physician question); the mop-up fixer moves no bound for it.", { package: "WS1-K" });
  if (c === "N1") return o(CE, "Population rule (C-14): a WS1-K resolution; the method difference is a physician question.", { package: "WS1-K", also: [PH] });
  if (c === "X1") return o(W3, "Albumin above 48 g/L: one judged exception (D-25).", { package: "WS3-24" });
  if (c === "C3") return o(CE, "Family page with the scope and the age policies: pack assembly (WS4).");
  if (c === "C2") return o(W3, "Pregnancy, lactation or oral-oestrogen handling is not applied by the app yet (C-08).", { package: "WS3-14, WS3-15, WS3-16" });
  if (c === "E2") return o(CE, "Raised when the source cache was empty (C-17, done); the quote check now runs. Disputed, stays listed.");
  if (/definition:(marker_classes|optimal_band)/.test(c) || (c === "M3" && /Optimal/.test(s))) return o(W3, "An in-range value on a row with no optimal band is labelled 'Optimal' by the classifier: in range becomes its own zone (D-14).", { package: "WS3-11, WS3-12" });
  return o(PH, "Open judge item: stays a physician question.");
}
for (const f of fams) for (const x of LED[f].issues) {
  if (x.source.lens === "script" || x.severity !== "blocking") continue;
  if (!["physician_question", "disputed", "unreviewed", "confirmed", "open"].includes(x.status)) continue;
  const j = judgeOwner(x);
  add(f, "JUDGE", { source: { file: `docs/signoff/work/ledger/${f}.json`, key: x.id, judge_file: x.source.judge_file }, ledger_status: x.status, lens: x.source.lens, raised_in_round: x.source.round, check_id: x.check_id, row_key: x.row_key, summary: String(x.summary).slice(0, 500), what: j.what, owner: j.owner, also: j.also || undefined, package: j.package || undefined, check: x.check_id, closing_pass: j.closing_pass || (j.owner === FF && x.status !== "disputed") || undefined, note: x.status === "disputed" ? "Disputed by the refuters: it stays on the physician's list unless its cause disappears; the mop-up does not settle it." : "Confirmed by both refuters and open at the round limit." });
}

// ─── 6. minor judge items finalised as physician questions (not in the round's scope) ───
const minor = {};
for (const f of fams) minor[f] = LED[f].issues.filter((x) => x.source.lens !== "script" && x.severity === "minor" && x.status === "physician_question").map((x) => ({ ledger_id: x.id, lens: x.source.lens, check_id: x.check_id, row_key: x.row_key, summary: String(x.summary).slice(0, 220) }));

// ─── output ───
const OWNERS = [FF, VF, CE, W3, PH, EX];
const count = (list) => { const o = Object.fromEntries(OWNERS.map((w) => [w, 0])); for (const it of list) o[it.owner]++; return o; };
const byFamily = {};
const total = Object.fromEntries(OWNERS.map((w) => [w, 0]));
for (const f of fams) {
  const c = count(items[f]);
  for (const w of OWNERS) total[w] += c[w];
  const fixer = items[f].filter((x) => x.owner === FF);
  const d30 = items[f].filter((x) => x.kind === "D30");
  byFamily[f] = {
    title: F[f].title, batch: F[f].batch, rounds_run: lastRound(f), mopup_round: lastRound(f) + 1,
    counts: { total: items[f].length, ...c, minor_judge_items_listed_separately: minor[f].length },
    in_round: fixer.length + d30.length > 0,
    stages: {
      evidence_pass: fixer.some((x) => /evidence pass/.test(x.stage || "")),
      author_new_rows: items[f].some((x) => x.owner === FF && /author stage/.test(x.needs || "")),
      fixer: fixer.length > 0,
      verifier_reverdict_rows_today: d30.map((x) => x.row_key),
      closing_lenses: [...new Set(items[f].filter((x) => x.kind === "JUDGE" && x.closing_pass).map((x) => x.lens))].sort(),
    },
    items: items[f],
    minor_judge_items: minor[f],
  };
}
const cc = count(central); for (const w of OWNERS) total[w] += cc[w];
const out = {
  _doc: "Items for the mop-up round of workstream 1 (EVA physician sign-off programme). AI work product; a licensed physician reviews and signs. Built by build-items.cjs from the repository as it stood and from a compile of all 30 families run outside the repository; rebuild after the D-43 rebuild of inputs and briefs.",
  built_from: { branch: "claude/wonderful-meitner-l4g7p5", commit: require("child_process").execSync("git rev-parse --short HEAD", { cwd: ROOT }).toString().trim(), compile: "node docs/signoff/tools/compile.js --out-dir <scratch>/compile-all (30 families from decisions)", checks: `npm run dsrt -- --seed-dir <scratch>/compile-all: pass ${fresh.counts.pass}, fail ${fresh.counts.fail}, blocked ${fresh.counts.blocked}`, unexplained_changes_today: unexplained.length },
  owners: { family_fixer: "the family's fixer in the mop-up session (decision file; evidence pass for quotes in the research and verify files; author stage for a new row key)", verifier: "the independent verifier in the mop-up session (fresh verdict, D-30)", central: "the orchestrator, workstream 1-K or pack assembly", ws3_package: "a workstream 3 package (see package)", physician: "only the physician can answer", external: "data awaited from Echevarne" },
  item_fields: "id, family, kind, source {file, key or row}, what (what has to change), owner, also (others involved), depends_on, needs, package, check (the check it moves)",
  totals: { items: Object.values(total).reduce((a, b) => a + b, 0), by_owner: total, central_items_no_family: central.length, minor_judge_items_listed_separately: Object.values(minor).reduce((n, l) => n + l.length, 0), families_in_round: fams.filter((f) => byFamily[f].in_round).length },
  handoffs_checked_closed: closedHandoffs,
  families: byFamily,
  central_items: central,
};
fs.writeFileSync(path.join(S, "items.json"), JSON.stringify(out, null, 1) + "\n");
// console summary
console.log("family | total | fixer | verifier | central | ws3 | physician | external | minor | D30 strict/bound/text | stages");
for (const f of fams) { const b = byFamily[f], c = b.counts; const d = items[f].filter((x) => x.kind === "D30"); const n = (k) => d.filter((x) => x.d30_class === k).length;
  console.log([short(f), c.total, c.family_fixer, c.verifier, c.central, c.ws3_package, c.physician, c.external, c.minor_judge_items_listed_separately, `${n("optimal_bounds_or_grade")}/${n("other_bound_class_or_band_rule")}/${n("text_only")}`, `${b.stages.evidence_pass ? "E" : "-"}${b.stages.author_new_rows ? "A" : "-"}${b.stages.fixer ? "F" : "-"}${d.length ? "V" : "-"} ${b.stages.closing_lenses.join("")}`].join(" | ")); }
console.log("central (no family)", JSON.stringify(cc));
console.log("totals", JSON.stringify(out.totals));
const kinds = {}; for (const it of central) { const k = 'CENTRAL:' + it.kind + '/' + it.owner; kinds[k] = (kinds[k] || 0) + 1; } for (const f of fams) for (const it of items[f]) { const k = it.kind + (it.topic ? ':' + it.topic : '') + "/" + it.owner; kinds[k] = (kinds[k] || 0) + 1; } console.log(JSON.stringify(kinds));
console.log(JSON.stringify(closedHandoffs.map((h) => h.handoff + ": " + h.status)));
