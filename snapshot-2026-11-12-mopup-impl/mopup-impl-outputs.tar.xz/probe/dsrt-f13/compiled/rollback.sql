-- ============================================================================
-- Sign-off ranges: rollback of signoff_ranges
-- Built by docs/signoff/tools/compile.js from the sign-off decisions (docs/signoff/work/decisions/, else the
-- verify final_rows, else the research rows, else today's seed rows; per family in compile-report.json).
-- Baseline: docs/biomarker-evidence/snapshots/production-biomarker_references-2026-09-25-gate1.json (200 rows) plus the changes applied after it (20260925010000_gate1_thresholds_1, 20260925010100_gate1_thresholds_2; 20260925011000_ai_prompt_zone_guard; 20260925012000_nlr_row; 20260925012100_nlr_name_en; 20260925013000_in_range_messages_1, 20260925013100_in_range_messages_2, 20260925013200_in_range_messages_3): 203 rows.
-- NOT APPLIED. Not a file in supabase/migrations. Apply only after the physician has signed and the CEO approves.
-- Rows upserted: 10 (new 4) · rows deleted: 1 · field changes: 91
-- ============================================================================

-- 1. Rows the forward migration added
-- delete: 4 row(s)
delete from public.biomarker_references r
 using (values
  ('eosinophils_absolute', 'female', 'Lactation'),
  ('eosinophils_absolute', 'female', 'Pregnancy'),
  ('monocytes_absolute', 'female', 'All Adults'),
  ('monocytes_absolute', 'male', 'All Adults')
  ) as v(biomarker_key, sex, age_group_en)
 where r.biomarker_key = v.biomarker_key and r.sex = v.sex and r.age_group_en = v.age_group_en;

-- 2. Changed rows back to their baseline values (ids are untouched by the forward upsert)
-- restore: 6 row(s)
insert into public.biomarker_references (biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category, is_base_panel, is_genetic, clinical_notes_en, clinical_notes_es, msg_critical_low_en, msg_critical_low_es, msg_below_optimal_en, msg_below_optimal_es, msg_optimal_en, msg_optimal_es, msg_above_optimal_en, msg_above_optimal_es, msg_critical_high_en, msg_critical_high_es)
values
  ('basophils_absolute', 'Basophils (Absolute)', 'Basófilos (Absolutos)', '/µL', '/µL', 'both', 'All Adults', 'Todos los Adultos', 0, 175, 0, 100, true, 'immune', false, false, 'The direct count of basophils — a precise measure of these allergy- and inflammation-related white cells.', 'El recuento directo de basófilos — una medida precisa de estos glóbulos blancos vinculados a la alergia y la inflamación.', null, null, null, null, 'Basophils are in the optimal range, reflecting normal immune function.', 'Los basófilos están en el rango óptimo, reflejando función inmune normal.', 'Basophils are mildly elevated. Consider allergic reactions, chronic inflammation, or myeloproliferative conditions.', 'Los basófilos están ligeramente elevados. Considerar reacciones alérgicas, inflamación crónica o condiciones mieloproliferativas.', 'Basophils are above the reference range. A mildly high count can be due to measurement variation, and a repeat test can confirm it. If it stays high, it can reflect allergic or inflammatory conditions or a myeloproliferative (bone marrow) disorder; discuss it with your doctor.', 'Los basófilos están por encima del intervalo de referencia. Un recuento algo elevado puede deberse a la variación de la medición, y repetir el análisis puede confirmarlo. Si se mantiene alto, puede reflejar afecciones alérgicas o inflamatorias o un trastorno mieloproliferativo (de la médula ósea); coméntalo con tu médico.'),
  ('basophils', 'Basophils', 'Basófilos', '%', '%', 'both', 'All Adults', 'Todos los Adultos', null, null, null, null, true, 'immune', false, false, 'The rarest type of white blood cell, involved in allergic reactions and inflammation. EVA gives the percentage no category of its own. It changes whenever the other white cells change, so the category comes from the absolute basophil count, in cells/µL.', 'El tipo más raro de glóbulo blanco, implicado en las reacciones alérgicas y la inflamación. EVA no asigna una categoría propia al porcentaje. Cambia cada vez que cambian los demás glóbulos blancos, así que la categoría la da el recuento absoluto de basófilos, en células/µL.', null, null, null, null, 'Basophils are in the optimal range, reflecting normal immune function.', 'Los basófilos están en el rango óptimo, reflejando función inmune normal.', 'Basophils are mildly elevated. Consider allergic reactions, chronic inflammation, or myeloproliferative conditions.', 'Los basófilos están ligeramente elevados. Considerar reacciones alérgicas, inflamación crónica o condiciones mieloproliferativas.', 'Basophils are above the reference range. This can be seen with allergic or inflammatory conditions or with myeloproliferative (bone marrow) disorders. Discuss it with your doctor.', 'Los basófilos están por encima del intervalo de referencia. Puede observarse en afecciones alérgicas o inflamatorias o en trastornos mieloproliferativos (de la médula ósea). Coméntalo con tu médico.'),
  ('eosinophils_absolute', 'Eosinophils (Absolute)', 'Eosinófilos (Absolutos)', '/µL', '/µL', 'both', 'All Adults', 'Todos los Adultos', 0, 500, 0, 300, true, 'immune', false, false, 'The direct count of eosinophils, the white cells tied to allergic and parasitic responses.', 'El recuento directo de eosinófilos, los glóbulos blancos vinculados a las respuestas alérgicas y parasitarias.', null, null, null, null, 'Eosinophils are in the optimal range, with no evidence of allergic or parasitic activation.', 'Los eosinófilos están en el rango óptimo, sin evidencia de activación alérgica o parasitaria.', 'Eosinophils are above optimal, which may reflect allergic disease, parasitic infection, or medication effect.', 'Los eosinófilos están por encima del óptimo, lo que puede reflejar enfermedad alérgica, infección parasitaria o efecto medicamentoso.', 'Eosinophils are above the reference range. This is not a diagnosis in itself; it can be seen with allergies, parasitic infections or other eosinophil-related disorders. Discuss it with your doctor.', 'Los eosinófilos están por encima del intervalo de referencia. No es un diagnóstico en sí mismo; puede observarse en alergias, infecciones por parásitos u otros trastornos eosinofílicos. Coméntalo con tu médico.'),
  ('eosinophils', 'Eosinophils', 'Eosinófilos', '%', '%', 'both', 'All Adults', 'Todos los Adultos', null, null, null, null, true, 'immune', false, false, 'White blood cells that fight parasites and drive allergic responses. Elevations often point to allergies, asthma or parasitic infection. EVA gives the percentage no category of its own. It changes whenever the other white cells change, so the category comes from the absolute eosinophil count, in cells/µL.', 'Glóbulos blancos que combaten parásitos e impulsan las respuestas alérgicas. Sus elevaciones suelen indicar alergias, asma o infección parasitaria. EVA no asigna una categoría propia al porcentaje. Cambia cada vez que cambian los demás glóbulos blancos, así que la categoría la da el recuento absoluto de eosinófilos, en células/µL.', null, null, null, null, 'Eosinophils are in the optimal range, with no evidence of allergic or parasitic activation.', 'Los eosinófilos están en el rango óptimo, sin evidencia de activación alérgica o parasitaria.', 'Eosinophils are above optimal, which may reflect allergic disease, parasitic infection, or medication effect.', 'Los eosinófilos están por encima del óptimo, lo que puede reflejar enfermedad alérgica, infección parasitaria o efecto medicamentoso.', 'Eosinophils are above the reference range. This is not a diagnosis in itself; it can be seen with allergies, parasitic infections or other eosinophil-related disorders. Discuss it with your doctor.', 'Los eosinófilos están por encima del intervalo de referencia. No es un diagnóstico en sí mismo; puede observarse en alergias, infecciones por parásitos u otros trastornos eosinofílicos. Coméntalo con tu médico.'),
  ('monocytes', 'Monocytes', 'Monocitos', '%', '%', 'both', 'All Adults', 'Todos los Adultos', null, null, null, null, true, 'immune', false, false, 'White blood cells that clear debris and dead cells and mature into the tissue cleanup cells. Their percentage reflects ongoing immune activity and inflammation. EVA gives the percentage no category of its own. It changes whenever the other white cells change, so the category comes from the absolute monocyte count, in cells/µL.', 'Glóbulos blancos que retiran restos y células muertas y maduran en las células de limpieza de los tejidos. Su porcentaje refleja la actividad inmunitaria y la inflamación en curso. EVA no asigna una categoría propia al porcentaje. Cambia cada vez que cambian los demás glóbulos blancos, así que la categoría la da el recuento absoluto de monocitos, en células/µL.', 'Monocytes are below the reference range. A mildly low count is often not significant, and a repeat test can confirm it. Discuss it with your doctor.', 'Los monocitos están por debajo del intervalo de referencia. Un recuento ligeramente bajo a menudo no es relevante, y una nueva analítica puede confirmarlo. Coméntalo con tu médico.', null, null, 'Monocytes are in the optimal range, reflecting normal innate immune surveillance.', 'Los monocitos están en el rango óptimo, reflejando vigilancia inmune innata normal.', 'Monocytes are above optimal, which may suggest chronic infection, inflammation, or tissue injury.', 'Los monocitos están por encima del óptimo, lo que puede sugerir infección crónica, inflamación o lesión tisular.', 'Monocytes are above the reference range. This can be seen with a chronic infection, autoimmune disease or hematologic conditions; discuss it with your doctor. A value far outside the range needs prompt medical attention.', 'Los monocitos están por encima del intervalo de referencia. Puede observarse con una infección crónica, una enfermedad autoinmune o trastornos hematológicos; coméntalo con tu médico. Un valor muy alejado del intervalo requiere atención médica sin demora.'),
  ('vitamin_b12', 'Vitamin B12', 'Vitamina B12 (Cobalamina)', 'pg/mL', 'pg/mL', 'both', 'All Adults', 'Todos los Adultos', 211, 911, 400, 800, false, 'nutrients', false, false, 'A vitamin essential for nerve function, DNA synthesis and red blood cell formation. Because the body stores it, deficiency develops slowly but can cause lasting nerve damage if missed.', 'Una vitamina esencial para la función nerviosa, la síntesis de ADN y la formación de glóbulos rojos. Como el cuerpo la almacena, el déficit se desarrolla despacio, pero puede causar daño nervioso duradero si pasa inadvertido.', 'Vitamin B12 is below the reference range. Low B12 can cause megaloblastic anemia, neuropathy, fatigue and cognitive problems; discuss it with your doctor, who can look for a cause such as diet, malabsorption or pernicious anemia. A value far outside the range needs prompt medical attention.', 'La vitamina B12 está por debajo del intervalo de referencia. Una B12 baja puede causar anemia megaloblástica, neuropatía, fatiga y problemas cognitivos; coméntalo con tu médico, que puede buscar la causa, como la dieta, la malabsorción o la anemia perniciosa. Un valor muy alejado del intervalo requiere atención médica sin demora.', 'Vitamin B12 is below optimal. Even within the standard ''normal'' range, levels under 400 pg/mL are associated with subtle neurological symptoms and elevated homocysteine. Consider methylated B12 supplementation and confirm functional status with MMA.', 'La vitamina B12 está por debajo del óptimo. Incluso dentro del rango ''normal'' estándar, niveles bajo 400 pg/mL se asocian con síntomas neurológicos sutiles y homocisteína elevada. Considerar suplementación con B12 metilada y confirmar el estado funcional con MMA.', 'Vitamin B12 is in the optimal range, supporting nerve health, DNA synthesis, and red blood cell production. Homocysteine should track in the optimal range as well.', 'La vitamina B12 está en el rango óptimo, apoyando la salud nerviosa, la síntesis de ADN y la producción de glóbulos rojos. La homocisteína debería estar también en rango óptimo.', 'Vitamin B12 is above optimal. If you supplement, this is usually benign — methylcobalamin has no documented toxicity ceiling. If you don''t supplement, evaluate liver function and rule out hematologic conditions.', 'La vitamina B12 está por encima del óptimo. Si suplementas, esto suele ser benigno — la metilcobalamina no tiene techo de toxicidad documentado. Si no suplementas, evaluar función hepática y descartar condiciones hematológicas.', 'Vitamin B12 is above the reference range. It can reflect supplement use; without supplements, a high level can be associated with liver disease, kidney impairment or myeloproliferative (blood) disorders. Discuss it with your doctor.', 'La vitamina B12 está por encima del intervalo de referencia. Puede deberse a suplementos; si no los tomas, un nivel alto puede asociarse con enfermedad hepática, insuficiencia renal o trastornos mieloproliferativos (de la sangre). Coméntalo con tu médico.')
on conflict (biomarker_key, sex, age_group_en) do update set
  name_en = excluded.name_en,
  name_es = excluded.name_es,
  unit_en = excluded.unit_en,
  unit_es = excluded.unit_es,
  age_group_es = excluded.age_group_es,
  normal_low = excluded.normal_low,
  normal_high = excluded.normal_high,
  optimal_low = excluded.optimal_low,
  optimal_high = excluded.optimal_high,
  tested_2x_year = excluded.tested_2x_year,
  panel_category = excluded.panel_category,
  is_base_panel = excluded.is_base_panel,
  is_genetic = excluded.is_genetic,
  clinical_notes_en = excluded.clinical_notes_en,
  clinical_notes_es = excluded.clinical_notes_es,
  msg_critical_low_en = excluded.msg_critical_low_en,
  msg_critical_low_es = excluded.msg_critical_low_es,
  msg_below_optimal_en = excluded.msg_below_optimal_en,
  msg_below_optimal_es = excluded.msg_below_optimal_es,
  msg_optimal_en = excluded.msg_optimal_en,
  msg_optimal_es = excluded.msg_optimal_es,
  msg_above_optimal_en = excluded.msg_above_optimal_en,
  msg_above_optimal_es = excluded.msg_above_optimal_es,
  msg_critical_high_en = excluded.msg_critical_high_en,
  msg_critical_high_es = excluded.msg_critical_high_es;

-- 3. Rows the forward migration deleted, with their snapshot ids where known
-- re-insert (with id): 1 row(s)
insert into public.biomarker_references (id, biomarker_key, name_en, name_es, unit_en, unit_es, sex, age_group_en, age_group_es, normal_low, normal_high, optimal_low, optimal_high, tested_2x_year, panel_category, is_base_panel, is_genetic, clinical_notes_en, clinical_notes_es, msg_critical_low_en, msg_critical_low_es, msg_below_optimal_en, msg_below_optimal_es, msg_optimal_en, msg_optimal_es, msg_above_optimal_en, msg_above_optimal_es, msg_critical_high_en, msg_critical_high_es)
values
  ('b6a92c68-d7f6-489f-9301-0f783e7be3be', 'monocytes_absolute', 'Monocytes (Absolute)', 'Monocitos (Absolutos)', '/µL', '/µL', 'both', 'All Adults', 'Todos los Adultos', 200, 950, 200, 700, true, 'immune', false, false, 'The direct count of monocytes, the white cells responsible for cleanup and tissue repair.', 'El recuento directo de monocitos, los glóbulos blancos encargados de la limpieza y la reparación de los tejidos.', 'Monocytes are below the reference range. A mildly low count is often not significant, and a repeat test can confirm it. Discuss it with your doctor.', 'Los monocitos están por debajo del intervalo de referencia. Un recuento ligeramente bajo a menudo no es relevante, y una nueva analítica puede confirmarlo. Coméntalo con tu médico.', null, null, 'Monocytes are in the optimal range, reflecting normal innate immune surveillance.', 'Los monocitos están en el rango óptimo, reflejando vigilancia inmune innata normal.', 'Monocytes are above optimal, which may suggest chronic infection, inflammation, or tissue injury.', 'Los monocitos están por encima del óptimo, lo que puede sugerir infección crónica, inflamación o lesión tisular.', 'Monocytes are above the reference range. This can be seen with a chronic infection, autoimmune disease or hematologic conditions; discuss it with your doctor. A value far outside the range needs prompt medical attention.', 'Los monocitos están por encima del intervalo de referencia. Puede observarse con una infección crónica, una enfermedad autoinmune o trastornos hematológicos; coméntalo con tu médico. Un valor muy alejado del intervalo requiere atención médica sin demora.')
on conflict (biomarker_key, sex, age_group_en) do update set
  name_en = excluded.name_en,
  name_es = excluded.name_es,
  unit_en = excluded.unit_en,
  unit_es = excluded.unit_es,
  age_group_es = excluded.age_group_es,
  normal_low = excluded.normal_low,
  normal_high = excluded.normal_high,
  optimal_low = excluded.optimal_low,
  optimal_high = excluded.optimal_high,
  tested_2x_year = excluded.tested_2x_year,
  panel_category = excluded.panel_category,
  is_base_panel = excluded.is_base_panel,
  is_genetic = excluded.is_genetic,
  clinical_notes_en = excluded.clinical_notes_en,
  clinical_notes_es = excluded.clinical_notes_es,
  msg_critical_low_en = excluded.msg_critical_low_en,
  msg_critical_low_es = excluded.msg_critical_low_es,
  msg_below_optimal_en = excluded.msg_below_optimal_en,
  msg_below_optimal_es = excluded.msg_below_optimal_es,
  msg_optimal_en = excluded.msg_optimal_en,
  msg_optimal_es = excluded.msg_optimal_es,
  msg_above_optimal_en = excluded.msg_above_optimal_en,
  msg_above_optimal_es = excluded.msg_above_optimal_es,
  msg_critical_high_en = excluded.msg_critical_high_en,
  msg_critical_high_es = excluded.msg_critical_high_es;
-- re-insert (added after the snapshot, id not known): none

-- 4. Sign-off columns
alter table public.biomarker_references
  drop column if exists critical_low,
  drop column if exists critical_high,
  drop column if exists critical_none_reason,
  drop column if exists marker_class,
  drop column if exists reference_basis,
  drop column if exists reference_source,
  drop column if exists physiological_state,
  drop column if exists method_note,
  drop column if exists explanatory_numbers;
