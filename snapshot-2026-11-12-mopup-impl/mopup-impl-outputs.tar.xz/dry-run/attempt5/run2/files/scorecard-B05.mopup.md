# Scorecard: batch B05

AI work product of the sign-off loop (docs/signoff/LOOP-PROMPT.md). A licensed physician reviews and signs; nothing here is a sign-off. Verdicts are AI pre-review.

Run: batch B05, started 2026-11-12T14:00:00Z, round limit 3, agents 11 of a cap of 40, retries 0, nulls 0.

## Families

| Family | Stop | Rounds | Failing checks (latest) | Failures | Blocking a pass (confirmed + open script) | Disputed | Physician questions | Closed or refuted | Searches (author/verifier) |
|---|---|---|---|---|---|---|---|---|---|
| f12_white_cells_core | open (open, mop-up done: 0 rows still listed by the comparison (unreviewed), 6 failures on family checks; no further round without a new recorded decision (M-02)) | 1 | K1 11, N1 5, P2 6 | 22 | 0 | 0 | 40 | 42 | 0/0 |
| f13_white_cells_other | held (seal: differences the verifier's corrections[] does not name (a copying slip; the decision is not overwritten): eosinophils_absolute\|both\|All Adults\|none clinical_notes_en) | 1 | C1 2, D2 2, D3 2 | 6 | 0 | 0 | 13 | 19 | 0/0 |
| f14_iron | open (open, mop-up done: 0 rows still listed by the comparison (unreviewed), 10 failures on family checks; no further round without a new recorded decision (M-02)) | 1 | C1 3, E1 2 | 5 | 0 | 0 | 18 | 33 | 0/0 |

## Failing checks by family

### f12_white_cells_core: White cells: WBC, neutrophils, lymphocytes, NLR

Trend of attributable failures by round: r1 44, r2 18, r3 22.

Round 3 (docs/signoff/work/checks/f12_white_cells_core-r3.json):

- K1: 11 failures, e.g. `one_step\|lymphocytes_absolute\|female\|lymphocytes:critical_high,white_blood_cell_count:above_optimal->lymphocytes_absolute:optimal`, `one_step\|lymphocytes_absolute\|female\|lymphocytes:critical_low,white_blood_cell_count:below_optimal->lymphocytes_absolute:optimal`, `one_step\|lymphocytes_absolute\|male\|lymphocytes:critical_high,white_blood_cell_count:above_optimal->lymphocytes_absolute:optimal`, `one_step\|neutrophils_absolute\|female\|neutrophils:critical_high,white_blood_cell_count:above_optimal->neutrophils_absolute:optimal`, `one_step\|neutrophils_absolute\|female\|neutrophils:critical_low,white_blood_cell_count:below_optimal->neutrophils_absolute:optimal`, and 6 more
- N1: 5 failures, e.g. `lymphocytes\|female\|70-79\|reference_outside`, `lymphocytes\|male\|60-69\|reference_outside`, `lymphocytes\|male\|70-79\|reference_outside`, `white_blood_cell_count\|female\|70-79\|non_optimal_70_79`, `white_blood_cell_count\|male\|70-79\|non_optimal_70_79`
- P2: 6 failures, e.g. `nlr\|both\|18-64\|rcv`, `nlr\|both\|65-74\|rcv`, `nlr\|both\|75-84\|rcv`, `nlr\|both\|85+\|rcv`, `white_blood_cell_count\|female\|All Adults\|rcv`, and 1 more

Blocked checks (not passes): C2, C3, E3, E5, G1, G4, G5, G6, G7, G8, M5, P3, S6.

### f13_white_cells_other: White cells: monocytes, eosinophils, basophils

Trend of attributable failures by round: r1 25, r2 6.

Round 2 (docs/signoff/work/checks/f13_white_cells_other-r2.json):

- C1: 2 failures, e.g. `eosinophils_absolute\|female\|Lactation\|unreachable`, `eosinophils_absolute\|female\|Pregnancy\|unreachable`
- D2: 2 failures, e.g. `eosinophils_absolute\|female\|Lactation\|age_group`, `eosinophils_absolute\|female\|Pregnancy\|age_group`
- D3: 2 failures, e.g. `eosinophils_absolute\|female\|Lactation\|no_catalogue_band`, `eosinophils_absolute\|female\|Pregnancy\|no_catalogue_band`

Blocked checks (not passes): C2, C3, E5, G4, G5, G6, G7, G8, M5, P2, S4, S6.

### f14_iron: Iron status: ferritin, iron, TSAT, TIBC

Trend of attributable failures by round: r1 37, r2 12, r3 5.

Round 3 (docs/signoff/work/checks/f14_iron-r3.json):

- C1: 3 failures, e.g. `ferritin\|female\|Lactation\|unreachable`, `ferritin\|female\|Pregnancy\|unreachable`, `iron_saturation_tsat\|female\|18\|labelled_by_age_proxy`
- E1: 2 failures, e.g. `f14_iron\|research\|ferritin\|female\|All Adults\|lactation\|state_split`, `f14_iron\|verify\|ferritin\|female\|All Adults\|lactation\|state_split`

Blocked checks (not passes): C2, C3, E5, G1, G4, G5, G6, G7, G8, M5, P3, S6.

## Batch compile checks

- r1 (docs/signoff/work/checks/B05-r1.json): pass 15, fail 22, blocked 13
- r2 (docs/signoff/work/checks/B05-r2.json): pass 16, fail 21, blocked 13

## Issues

| Family | Open | Confirmed | Disputed | Unreviewed | Physician question | Refuted | Fixed | Closed |
|---|---|---|---|---|---|---|---|---|
| f12_white_cells_core | 0 | 0 | 0 | 0 | 40 | 3 | 0 | 39 |
| f13_white_cells_other | 0 | 0 | 0 | 0 | 13 | 0 | 0 | 19 |
| f14_iron | 0 | 0 | 0 | 0 | 18 | 1 | 0 | 32 |

## Physician questions and disputed items

### f12_white_cells_core (40)

- physician_question, blocking, J1: `f12_white_cells_core--K1--nlr.both.65-74.none--high`: J1: K1 nlr\|both\|65-74\|none B3: reference_high 3.92 puts the ratio above range while both counts are inside Echevarne's intervals (neutrophils 3,500 and lymphocytes 850/µL give 4.12 in either sex): an opposite-category pair, and K1 passes
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.lymphocytes_absolute.female.lymphocytes:critical_high_white_blood_cell_count:above_optimal-_lymphocytes_absolute:optimal--none`: K1 one_step\|lymphocytes_absolute\|female\|lymphocytes:critical_high,white_blood_cell_count:above_optimal->lymphocytes_absolute:optimal: seen at 83 ages from 18 to 100; e.g. lymphocytes 46.35, white_blood_cell_count 6180 gives lymphocytes_a
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.lymphocytes_absolute.female.lymphocytes:critical_low_white_blood_cell_count:below_optimal-_lymphocytes_absolute:optimal--none`: K1 one_step\|lymphocytes_absolute\|female\|lymphocytes:critical_low,white_blood_cell_count:below_optimal->lymphocytes_absolute:optimal: seen at 83 ages from 18 to 100; e.g. lymphocytes 19.4, white_blood_cell_count 3977 gives lymphocytes_abs
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.lymphocytes_absolute.male.lymphocytes:critical_high_white_blood_cell_count:above_optimal-_lymphocytes_absolute:optimal--none`: K1 one_step\|lymphocytes_absolute\|male\|lymphocytes:critical_high,white_blood_cell_count:above_optimal->lymphocytes_absolute:optimal: seen at 83 ages from 18 to 100; e.g. lymphocytes 46.35, white_blood_cell_count 6180 gives lymphocytes_abs
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.neutrophils_absolute.female.neutrophils:critical_high_white_blood_cell_count:above_optimal-_neutrophils_absolute:optimal--none`: K1 one_step\|neutrophils_absolute\|female\|neutrophils:critical_high,white_blood_cell_count:above_optimal->neutrophils_absolute:optimal: seen at 83 ages from 18 to 100; e.g. neutrophils 77.25, white_blood_cell_count 6180 gives neutrophils_a
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.neutrophils_absolute.female.neutrophils:critical_low_white_blood_cell_count:below_optimal-_neutrophils_absolute:optimal--none`: K1 one_step\|neutrophils_absolute\|female\|neutrophils:critical_low,white_blood_cell_count:below_optimal->neutrophils_absolute:optimal: seen at 83 ages from 18 to 100; e.g. neutrophils 43.65, white_blood_cell_count 3977 gives neutrophils_ab
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.neutrophils_absolute.male.neutrophils:critical_high_white_blood_cell_count:above_optimal-_neutrophils_absolute:optimal--none`: K1 one_step\|neutrophils_absolute\|male\|neutrophils:critical_high,white_blood_cell_count:above_optimal->neutrophils_absolute:optimal: seen at 83 ages from 18 to 100; e.g. neutrophils 77.25, white_blood_cell_count 6180 gives neutrophils_abs
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.nlr.female.neutrophils_absolute:optimal_lymphocytes_absolute:optimal-_nlr:above_optimal--none`: K1 one_step\|nlr\|female\|neutrophils_absolute:optimal,lymphocytes_absolute:optimal->nlr:above_optimal: seen at 83 ages from 18 to 100; e.g. neutrophils_absolute 1761, lymphocytes_absolute 782.8 gives nlr 2.25 (NLR = neutrophils / lymphocyt
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.nlr.female.neutrophils_absolute:optimal_lymphocytes_absolute:optimal-_nlr:below_optimal--none`: K1 one_step\|nlr\|female\|neutrophils_absolute:optimal,lymphocytes_absolute:optimal->nlr:below_optimal: seen at 83 ages from 18 to 100; e.g. neutrophils_absolute 1761, lymphocytes_absolute 5020 gives nlr 0.3509 (NLR = neutrophils / lymphocy
- physician_question, blocking, script: `f12_white_cells_core--K1--one_step.nlr.male.neutrophils_absolute:optimal_lymphocytes_absolute:optimal-_nlr:above_optimal--none`: K1 one_step\|nlr\|male\|neutrophils_absolute:optimal,lymphocytes_absolute:optimal->nlr:above_optimal: seen at 83 ages from 18 to 100; e.g. neutrophils_absolute 1947, lymphocytes_absolute 865.2 gives nlr 2.25 (NLR = neutrophils / lymphocytes
- physician_question, blocking, script: `f12_white_cells_core--K1--opposite.nlr.female.neutrophils_absolute:optimal_lymphocytes_absolute:optimal-_nlr:critical_high--none`: K1 opposite\|nlr\|female\|neutrophils_absolute:optimal,lymphocytes_absolute:optimal->nlr:critical_high: seen at 83 ages from 18 to 100; e.g. neutrophils_absolute 5143, lymphocytes_absolute 782.8 gives nlr 6.569 (NLR = neutrophils / lymphocy
- physician_question, blocking, script: `f12_white_cells_core--K1--opposite.nlr.male.neutrophils_absolute:optimal_lymphocytes_absolute:optimal-_nlr:critical_high--none`: K1 opposite\|nlr\|male\|neutrophils_absolute:optimal,lymphocytes_absolute:optimal->nlr:critical_high: seen at 83 ages from 18 to 100; e.g. neutrophils_absolute 5233, lymphocytes_absolute 865.2 gives nlr 6.048 (NLR = neutrophils / lymphocyte
- physician_question, blocking, J1: `f12_white_cells_core--L2--neutrophils_absolute.female.All_Adults.none--low`: J1: L2 neutrophils_absolute\|female\|All Adults\|none B7: action limit AL-14 starts at 1,000/µL on the row but at 500/µL in action-limits.json ('ANC below the row's floor and above 500/µL'), so for 500-999/µL the two give opposite advice: b
- physician_question, blocking, J1: `f12_white_cells_core--M3--none--none`: J1, mop-up closing pass: Mop-up dry run: an observation the closing lens enters for the orchestrator. (docs/signoff/work/decisions/f12_white_cells_core.json:1)
- physician_question, blocking, script: `f12_white_cells_core--N1--lymphocytes.female.70-79.reference_outside--none`: N1 lymphocytes\|female\|70-79\|reference_outside: 17.0% outside the reference limits (rule 2% to 15%)
- physician_question, blocking, script: `f12_white_cells_core--N1--lymphocytes.male.60-69.reference_outside--none`: N1 lymphocytes\|male\|60-69\|reference_outside: 16.8% outside the reference limits (rule 2% to 15%)
- physician_question, blocking, script: `f12_white_cells_core--N1--lymphocytes.male.70-79.reference_outside--none`: N1 lymphocytes\|male\|70-79\|reference_outside: 23.2% outside the reference limits (rule 2% to 15%)
- physician_question, blocking, script: `f12_white_cells_core--N1--white_blood_cell_count.female.70-79.non_optimal_70_79--none`: N1 white_blood_cell_count\|female\|70-79\|non_optimal_70_79: 61.8% non-optimal at 70-79: must be a physician question
- physician_question, blocking, script: `f12_white_cells_core--N1--white_blood_cell_count.male.70-79.non_optimal_70_79--none`: N1 white_blood_cell_count\|male\|70-79\|non_optimal_70_79: 72.0% non-optimal at 70-79: must be a physician question
- physician_question, blocking, script: `f12_white_cells_core--P2--nlr.both.18-64.rcv--none`: P2 nlr\|both\|18-64\|rcv: entry has no rcv_pct and no CVi/CVa to compute it
- physician_question, blocking, script: `f12_white_cells_core--P2--nlr.both.65-74.rcv--none`: P2 nlr\|both\|65-74\|rcv: entry has no rcv_pct and no CVi/CVa to compute it
- physician_question, blocking, script: `f12_white_cells_core--P2--nlr.both.75-84.rcv--none`: P2 nlr\|both\|75-84\|rcv: entry has no rcv_pct and no CVi/CVa to compute it
- physician_question, blocking, script: `f12_white_cells_core--P2--nlr.both.85plus.rcv--none`: P2 nlr\|both\|85+\|rcv: entry has no rcv_pct and no CVi/CVa to compute it
- physician_question, blocking, script: `f12_white_cells_core--P2--white_blood_cell_count.female.All_Adults.rcv--none`: P2 white_blood_cell_count\|female\|All Adults\|rcv: entry has no rcv_pct and no CVi/CVa to compute it
- physician_question, blocking, script: `f12_white_cells_core--P2--white_blood_cell_count.male.All_Adults.rcv--none`: P2 white_blood_cell_count\|male\|All Adults\|rcv: entry has no rcv_pct and no CVi/CVa to compute it
- physician_question, minor, J5: `f12_white_cells_core--C2--nlr.both.18-64.none--high`: J5: C2 nlr\|both\|18-64\|none In a declared pregnancy, state-rules 2.1 shows 'the laboratory's printed reference interval', but no laboratory prints one for the EVA-calculated NLR, so its pregnancy output is undefined. The row's state-split
- physician_question, minor, J1: `f12_white_cells_core--C3--white_blood_cell_count.female.All_Adults.none--none`: J1: C3 white_blood_cell_count\|female\|All Adults\|none No written policy for ages 18-19, 70-84 and 85 and over for the 3,800-6,000/µL optimal band; no family page (C3 blocked), and age_dependent_optimal is false
- physician_question, minor, J1: `f12_white_cells_core--E1--nlr.both.65-74.none--low`: J1: E1 nlr\|both\|65-74\|none E1 passes the five records behind optimal_low 0.37 although none quotes 0.37: the only digit in f12-F02's quote is 'Supplementary Fig. 5', and in f12-F04's it is 'Supplementary Figure S1'
- physician_question, minor, J1: `f12_white_cells_core--E3--white_blood_cell_count.female.All_Adults.none--low`: J1: E3 white_blood_cell_count\|female\|All Adults\|none optimal_low 4,100 is a narrowed bound resting on f12-F06 to f12-F08, whose grade B was proposed by the author; E3 needs a grade assigned by the verifier
- physician_question, minor, J1: `f12_white_cells_core--K1--lymphocytes_absolute.female.All_Adults.none--none`: J1: K1 lymphocytes_absolute\|female\|All Adults\|none K1 one-step pattern with no accepted reason: lymphocytes 46.35% (above range) with WBC 6,180/µL gives 2,864/µL, in range
- physician_question, minor, J1: `f12_white_cells_core--L1--white_blood_cell_count.female.All_Adults.none--high`: J1: L1 white_blood_cell_count\|female\|All Adults\|none critical-limits.json gives the women's reference interval as '3,800-? women' and the neutrophils' as '1,710-? women', where the rows hold 11,500 and 8,575/µL
- physician_question, minor, J5: `f12_white_cells_core--M2--neutrophils_absolute.male.All_Adults.none--low`: J5: M2 neutrophils_absolute\|male\|All Adults\|none The Duffy-null line says only 'a benign inherited variant (Duffy-null phenotype) with no consequences for health'. It omits two elements state-rules 6.1 requires: that it does not raise in
- physician_question, minor, J1: `f12_white_cells_core--M3--neutrophils_absolute.female.All_Adults.none--low`: J1: M3 neutrophils_absolute\|female\|All Adults\|none The critical message ends 'Go to an emergency department today.' (critical-limits.json action class 'emergency'), but wording-rules.md requires a single critical closer: 'Contact a docto
- physician_question, minor, J1: `f12_white_cells_core--N1--lymphocytes.both.All_Adults.none--low`: J1: N1 lymphocytes\|both\|All Adults\|none reference_low 20% leaves 23.2% of healthy men aged 70-79 below range (16.8% of men at 60-69, 17.0% of women at 70-79), and the below-range message does not name age as a common cause
- physician_question, minor, J5: `f12_white_cells_core--N1--nlr.both.65-74.none--high`: J5: N1 nlr\|both\|65-74\|none Optimal ceiling 2.0 is held from 18 to 85+ with no N1 test (distributions.json has no NLR). Rotterdam means are 1.82 at 65-74, 2.02 at 75-84 and 2.13 at 85+, so from 75 the typical ratio is at or above 2.0. Son
- physician_question, minor, J3: `f12_white_cells_core--N1--none--none`: J3: N1 N1 tests 16 markers (128 entries = 16 markers x 2 sexes x 4 age bands). Of f12's six markers, only white_blood_cell_count and lymphocytes (%) are in docs/signoff/work/nhanes/distributions.json. neutrophils_absolute, neutrophils (%), 
- physician_question, minor, J1: `f12_white_cells_core--N1--white_blood_cell_count.female.All_Adults.none--none`: J1: N1 white_blood_cell_count\|female\|All Adults\|none F12-DQ-4 tells the physician 'Check N1 reports 72.0% for men and 61.8% for women', which are the round-1 figures for a 3,800 floor; the round-2 result for this row's 4,100 floor is 63.
- physician_question, minor, J5: `f12_white_cells_core--Q1--white_blood_cell_count.female.All_Adults.none--low`: J5: Q1 white_blood_cell_count\|female\|All Adults\|none WBC is the scored class a member of the leukocyte group (marker-classes.json may_be_scored true). The Duffy-null persona's WBC of 3,400/µL is below the women's 3,800, so a benign varia
- physician_question, minor, J3: `f12_white_cells_core--definition:marker_classes--neutrophils_absolute.male.All_Adults.none--none`: J3: definition:marker classes neutrophils_absolute\|male\|All Adults\|none The pack gives this marker two classes. action-limits.json entry AL-14 gives neutrophils_absolute the marker_class 'a (ANC is scored)' (line 278). The row and marker
- physician_question, minor, J5: `f12_white_cells_core--definition:physiological_state--white_blood_cell_count.female.All_Adults.none--high`: J5: definition:physiological state white_blood_cell_count\|female\|All Adults\|none The women's above-optimal message lists time of day, exercise, stress, infection and smoking, but not pregnancy, although Dockree 2021 puts the pregnancy in

### f13_white_cells_other (13)

- physician_question, blocking, script: `f13_white_cells_other--C1--eosinophils_absolute.female.Lactation.unreachable--none`: C1 eosinophils_absolute\|female\|Lactation\|unreachable: row at file index 32 is never picked for any sex and age 18-120
- physician_question, blocking, script: `f13_white_cells_other--C1--eosinophils_absolute.female.Pregnancy.unreachable--none`: C1 eosinophils_absolute\|female\|Pregnancy\|unreachable: row at file index 31 is never picked for any sex and age 18-120
- physician_question, blocking, script: `f13_white_cells_other--D2--eosinophils_absolute.female.Lactation.age_group--none`: D2 eosinophils_absolute\|female\|Lactation\|age_group: EN "Lactation" vs ES "Lactancia" (expected "Lactation")
- physician_question, blocking, script: `f13_white_cells_other--D2--eosinophils_absolute.female.Pregnancy.age_group--none`: D2 eosinophils_absolute\|female\|Pregnancy\|age_group: EN "Pregnancy" vs ES "Embarazo" (expected "Pregnancy")
- physician_question, blocking, script: `f13_white_cells_other--D3--eosinophils_absolute.female.Lactation.no_catalogue_band--none`: D3 eosinophils_absolute\|female\|Lactation\|no_catalogue_band: the catalogue has no band covering this row's ages for female
- physician_question, blocking, script: `f13_white_cells_other--D3--eosinophils_absolute.female.Pregnancy.no_catalogue_band--none`: D3 eosinophils_absolute\|female\|Pregnancy\|no_catalogue_band: the catalogue has no band covering this row's ages for female
- physician_question, minor, J1: `f13_white_cells_other--D3--basophils.both.All_Adults.none--high`: J1: D3 basophils\|both\|All Adults\|none Echevarne prints '<1.5' %, but Normal_High 1.5 under the rule 'value > Normal_High' treats exactly 1.5% as in range (the same for eosinophils '<5' %, '<575'/µL and basophils '<175'/µL)
- physician_question, minor, J2: `f13_white_cells_other--D3--basophils_absolute.both.All_Adults.none--high`: J2: D3 basophils_absolute\|both\|All Adults\|none Normal_High 175/µL is inclusive in EVA, but Echevarne prints '<175' (catalogue line 204), which by the same HL7 evidence (bands % '5,000' at '0,000-5,000' flagged H) excludes 175 itself.
- physician_question, minor, J2: `f13_white_cells_other--D3--eosinophils.both.All_Adults.none--high`: J2: D3 eosinophils\|both\|All Adults\|none Normal_High 5% is inclusive in EVA, but Echevarne prints '<5' (catalogue line 201); by the HL7 evidence an eosinophil share of exactly 5.0% is flagged H by the laboratory and shown in range by EVA.
- physician_question, minor, J2: `f13_white_cells_other--D3--none--none`: J2: D3 D3 fails 'no_catalogue_band' on the eosinophils_absolute female Pregnancy and Lactation rows (docs/signoff/work/checks/B05-r1.json line 144) because the runner tests ages with ageGroupContains on the age label, which on state rows is
- physician_question, minor, J1: `f13_white_cells_other--L2--none--none`: J1: L2 Family-added action limits (basophils 1,000/µL or more, monocytes 1,000/µL or more, eosinophils 1,500/µL or more) exist only in row text, not in action-limits.json
- physician_question, minor, J3: `f13_white_cells_other--N1--none--none`: J3: N1 None of f13's six markers is in docs/signoff/work/nhanes/distributions.json. Several limits therefore have no check of population shares, although the rows themselves call them narrower than measured healthy limits: eosinophils <5% (
- physician_question, minor, J2: `f13_white_cells_other--definition:reference_interval--eosinophils_absolute.both.All_Adults.none--high`: J2: definition:reference interval eosinophils_absolute\|both\|All Adults\|none For 501 to 575/µL the client reads 'Your eosinophil count is above the reference interval, which ends at 500/µL' (biomarker-ranges-en.json line 839), while Echev

### f14_iron (18)

- physician_question, blocking, script: `f14_iron--C1--ferritin.female.Lactation.unreachable--none`: C1 ferritin\|female\|Lactation\|unreachable: row at file index 105 is never picked for any sex and age 18-120
- physician_question, blocking, script: `f14_iron--C1--ferritin.female.Pregnancy.unreachable--none`: C1 ferritin\|female\|Pregnancy\|unreachable: row at file index 104 is never picked for any sex and age 18-120
- physician_question, blocking, script: `f14_iron--C1--iron_saturation_tsat.female.18.labelled_by_age_proxy--none`: C1 iron_saturation_tsat\|female\|18\|labelled_by_age_proxy: labelled row "Premenopausal" is picked by the age proxy at age 18, not through a recorded state (2 labelled rows match)
- physician_question, blocking, script: `f14_iron--E1--f14_iron.research.ferritin.female.All_Adults.lactation.state_split--none`: E1 f14_iron\|research\|ferritin\|female\|All Adults\|lactation\|state_split: split by state (its physiological_state is lactation) without a record: none of the research file's records has a supports[] link {row_key: "ferritin\|female\|All 
- physician_question, blocking, script: `f14_iron--E1--f14_iron.verify.ferritin.female.All_Adults.lactation.state_split--none`: E1 f14_iron\|verify\|ferritin\|female\|All Adults\|lactation\|state_split: split by state (its physiological_state is lactation) without a record: none of the research and verify files' records has a supports[] link {row_key: "ferritin\|fem
- physician_question, minor, J5: `f14_iron--C1--iron_saturation_tsat.female.All_Adults.premenopausal--none`: J5: C1 iron_saturation_tsat\|female\|All Adults\|premenopausal No unlabelled female TSAT or ferritin row exists, so every woman without a recorded menopause status is put on a Premenopausal or Postmenopausal row by the age-50 proxy. C1 fail
- physician_question, minor, J5: `f14_iron--C2--iron_binding_capacity_tibc.both.All_Adults.none--high`: J5: C2 iron_binding_capacity_tibc\|both\|All Adults\|none The oral-oestrogen note of state-rules 4.2 sits only on SHBG, estradiol, TSH, free T4, hs-CRP and triglycerides. This row's own source f14-E31 (Campesi 2012) found that oral contrace
- physician_question, minor, J1: `f14_iron--E1--ferritin.female.All_Adults.pregnancy--none`: J1: E1 ferritin\|female\|All Adults\|pregnancy f14-E32 (Rosenmund 1986) supports the pregnancy state_split with a quote that holds no number
- physician_question, minor, J1: `f14_iron--K1--iron_saturation_tsat.male.All_Adults.none--both`: J1: K1 iron_saturation_tsat\|male\|All Adults\|none K1 opposite patterns: serum iron and TIBC inside their intervals (labelled 'optimal') with TSAT outside 20-50%, e.g. iron 66.95 µg/dL with TIBC 337.5 µg/dL gives 19.84%
- physician_question, minor, J3: `f14_iron--K1--iron_saturation_tsat.male.All_Adults.none--none`: J3: K1 iron_saturation_tsat\|male\|All Adults\|none K1 finds TSAT outside its interval while serum iron and TIBC are both inside theirs, for both sexes and on both sides, with no accepted reason. For example, iron 169.8 and TIBC 257.5 µg/dL
- physician_question, minor, J1: `f14_iron--L2--iron_saturation_tsat.male.All_Adults.none--high`: J1: L2 iron_saturation_tsat\|male\|All Adults\|none AL-01 names its marker 'transferrin_saturation', not the row key 'iron_saturation_tsat', so L2 reads 'TSAT with ferritin' as missing; all 17 entries fail L2's field test (direction, numeri
- physician_question, minor, J2: `f14_iron--L2--iron_saturation_tsat.male.All_Adults.none--none`: J2: L2 iron_saturation_tsat\|male\|All Adults\|none L2 reports 'tsat_with_ferritin\|missing' and all 17 action-limit entries incomplete (docs/signoff/work/checks/B05-r1.json line 1235), although docs/signoff/work/governance/action-limits.js
- physician_question, minor, J1: `f14_iron--M2--ferritin.female.All_Adults.none--none`: J1: M2 ferritin\|female\|All Adults\|none the new row's in-range message (dry run)
- physician_question, minor, J3: `f14_iron--N1--none--none`: J3: N1 None of f14's four markers is in docs/signoff/work/nhanes/distributions.json, and N1 reports 0 decision-limit rows. The ferritin decision limit of 31 ng/mL, the TSAT limits of 20% and 50% (45% for premenopausal women), and Echevarne'
- physician_question, minor, J2: `f14_iron--P1--iron_saturation_tsat.male.All_Adults.none--none`: J2: P1 iron_saturation_tsat\|male\|All Adults\|none No fasting, haemolysis or draw-time rule is required of TSAT: P1 lists serum iron, not TSAT, for haemolysis and draw time, and no iron marker for fasting (scripts/signoff/checks/preanalyti
- physician_question, minor, J1: `f14_iron--definition:reference_interval--ferritin.female.All_Adults.pregnancy--low`: J1: definition:reference interval ferritin\|female\|All Adults\|pregnancy ASH '≤30 ng/mL' is encoded as Normal_Low 31 under the rule 'value < Normal_Low', so a reported 30.5 ng/mL is classified below the interval although ASH would not call
- physician_question, minor, J1: `f14_iron--definition:reference_interval--iron_saturation_tsat.male.All_Adults.none--both`: J1: definition:reference interval iron_saturation_tsat\|male\|All Adults\|none Normal_Low 20% labelled decision_limit from an ASH remark that applies only to adults with anaemia of inflammation, applied to all adults; Normal_High 50% from t
- physician_question, minor, J3: `f14_iron--definition:reference_interval--iron_saturation_tsat.male.All_Adults.none--high`: J3: definition:reference interval iron_saturation_tsat\|male\|All Adults\|none Normal_High 50% and Normal_Low 20%, both with reference_basis decision_limit. EASL 2022 gives TSAT >50% for men only as part of a joint criterion, with ferritin 

## Agents

| Role | Agents | Retries | Nulls | Model asked -> reported |
|---|---|---|---|---|
| judge | 5 | 0 | 0 | claude-fable-5-2 -> claude-fable-5-2 |
| runner | 4 | 0 | 0 | claude-opus-5-5 -> claude-opus-5-5 |
| verifier | 2 | 0 | 0 | claude-fable-5-2 -> claude-fable-5-2 |

The reported model is the agent's own statement in its structured result; the workflow has no meta file to read it from.

## Mop-up round 3 (DR-2026-11-11-01)

One bounded pass per family from `docs/signoff/work/mopup/items/<family>.json` (docs/signoff/workflows/ws1-mopup.js). Start commit 02f151acba447e6dc07d6e6f816f2c462f8afb6a; run of 2026-11-12T14:00:00Z, a re-run from the stages f12_white_cells_core closing, f13_white_cells_other verifier, f14_iron verifier. 

| Family | End status | Last finished stage | Held | Rows still listed | Closed by the closing pass | Raised again or left open |
|---|---|---|---|---|---|---|
| f12_white_cells_core | open | closing | no | 0 | 5 | 3 |
| f13_white_cells_other | held | verifier | seal: seal: differences the verifier's corrections[] does not name (a copying slip; the decision is not overwritten): eosinophils_absolute\|both\|All Adults\|none clinical_notes_en | 1 | 0 | 0 |
| f14_iron | open | closing | no | 0 | 0 | 2 |

### Agents: model requested and reported, per agent (M-03)

| # | Label | Role | Requested | Effort | Reported | Result |
|---|---|---|---|---|---|---|
| 1 | setup B05 | runner | claude-opus-5-5 | medium | claude-opus-5-5 | ok |
| 2 | verifier f13_white_cells_other r3 | verifier | claude-fable-5-2 | max | claude-fable-5-2 | ok |
| 3 | verifier f14_iron r3 | verifier | claude-fable-5-2 | max | claude-fable-5-2 | ok |
| 4 | seal f13_white_cells_other r3 | runner | claude-opus-5-5 | medium | claude-opus-5-5 | ok |
| 5 | seal f14_iron r3 | runner | claude-opus-5-5 | medium | claude-opus-5-5 | ok |
| 6 | check f14_iron r3 | runner | claude-opus-5-5 | medium | claude-opus-5-5 | ok |
| 7 | closing J1 B05 r3 | judge | claude-fable-5-2 | max | claude-fable-5-2 | ok |
| 8 | closing J2 B05 r3 | judge | claude-fable-5-2 | max | claude-fable-5-2 | ok |
| 9 | closing J5 B05 r3 | judge | claude-fable-5-2 | max | claude-fable-5-2 | ok |
| 10 | newrows J1 f14_iron r3 | judge | claude-fable-5-2 | max | claude-fable-5-2 | ok |
| 11 | newrows J2 f14_iron r3 | judge | claude-fable-5-2 | max | claude-fable-5-2 | ok |

### Closing pass (M-11)

- f12_white_cells_core, J1: `f12_white_cells_core--E2--lymphocytes_absolute.female.All_Adults.none--high`: not_raised_again; closed through ledger.js apply
- f12_white_cells_core, J1: `f12_white_cells_core--N1--lymphocytes.both.All_Adults.none--low`: raised_again; stays open
- f12_white_cells_core, J1: `f12_white_cells_core--N1--white_blood_cell_count.female.All_Adults.none--none`: not_raised_again; left open: no file, line and value (M-11 (2))
- f12_white_cells_core, J1: `f12_white_cells_core--definition:optimal_band--nlr.both.65-74.none--low`: not_raised_again; closed through ledger.js apply
- f12_white_cells_core, J1: `f12_white_cells_core--definition:optimal_band--white_blood_cell_count.female.All_Adults.none--low`: not_raised_again; closed through ledger.js apply
- f14_iron, J1: `f14_iron--L2--iron_saturation_tsat.male.All_Adults.none--high`: raised_again; stays open
- f12_white_cells_core, J2: `f12_white_cells_core--definition:basis_of_each_bound--nlr.both.65-74.none--high`: not_raised_again; closed through ledger.js apply
- f14_iron, J2: `f14_iron--L2--iron_saturation_tsat.male.All_Adults.none--none`: raised_again; stays open
- f12_white_cells_core, J5: `f12_white_cells_core--M2--lymphocytes.both.All_Adults.none--low`: not_raised_again; closed through ledger.js apply
- f12_white_cells_core, J5: `f12_white_cells_core--definition:physiological_state--white_blood_cell_count.female.All_Adults.none--high`: raised_again; stays open

### Observations and new-row issues, entered as unreviewed (the orchestrator reads each one; M-11 (4), (5))

- f12_white_cells_core, J1, closing-pass observation: `f12_white_cells_core--M3--none--none` (M3): Mop-up dry run: an observation the closing lens enters for the orchestrator. (docs/signoff/work/decisions/f12_white_cells_core.json:1)
- f12_white_cells_core, J2, closing-pass observation: `f12_white_cells_core--M3--none--none` (M3): Mop-up dry run: an observation the closing lens enters for the orchestrator. (docs/signoff/work/decisions/f12_white_cells_core.json:1)
- f12_white_cells_core, J5, closing-pass observation: `f12_white_cells_core--M3--none--none` (M3): Mop-up dry run: an observation the closing lens enters for the orchestrator. (docs/signoff/work/decisions/f12_white_cells_core.json:1)
- f14_iron, J1, new-row issue (minor): `f14_iron--M2--ferritin.female.All_Adults.none--none` (M2, ferritin\|female\|All Adults\|none): J1: M2 ferritin\|female\|All Adults\|none the new row's in-range message (dry run) (docs/signoff/work/judges/mopup/J1-B05.f14_iron.newrows.json)
- f14_iron, J2, new-row issue (minor): `f14_iron--M2--ferritin.female.All_Adults.none--none` (M2, ferritin\|female\|All Adults\|none): J2: M2 ferritin\|female\|All Adults\|none the new row's in-range message (dry run) (docs/signoff/work/judges/mopup/J2-B05.f14_iron.newrows.json)

### Seal (only fields named in corrections[])

- f13_white_cells_other: stopped; copied nothing; differences not named in corrections[]: eosinophils_absolute\|both\|All Adults\|none clinical_notes_en
- f14_iron: sealed; copied ferritin\|female\|All Adults\|pregnancy method_note (corrections[8])

### Held families and how to resume

- f13_white_cells_other: held at the seal stage (seal: differences the verifier's corrections[] does not name (a copying slip; the decision is not overwritten): eosinophils_absolute\|both\|All Adults\|none clinical_notes_en). Resume after the cause is gone with args {"batch": "B05", "started_at": "<ISO time>", "families": ["f13_white_cells_other"], "from_stage": {"f13_white_cells_other": "seal"}}; stage 0 compares its files with the hashes recorded after the verifier stage.
