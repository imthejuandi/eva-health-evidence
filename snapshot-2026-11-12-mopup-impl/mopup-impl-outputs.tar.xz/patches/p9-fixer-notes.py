import sys
def patch(p, pairs):
    s = open(p).read()
    for a, b in pairs:
        c = s.count(a)
        if c != 1: sys.exit(f'{p}: expected 1 occurrence, found {c}: {a[:140]!r}')
        s = s.replace(a, b)
    open(p, 'w').write(s)
    print('patched', p)
W = '/home/user/eva-health/.claude/worktrees/mopup'
I = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-impl'
patch(W + '/docs/signoff/workflows/ws1-mopup-tools.cjs', [
 ('''    out.fixer_parts = st.fixer_parts || [];''',
  '''    out.fixer_parts = st.fixer_parts || [];
    out.fixer_notes = st.fixer_notes || [];'''),
])
patch(I + '/script/ws1-mopup.template.js', [
 ('''          author_rows: STR_LIST, author_items: STR_LIST, fixer_items: OBJ_LIST, fixer_parts: { type: 'array', items: STR_LIST },''',
  '''          author_rows: STR_LIST, author_items: STR_LIST, fixer_items: OBJ_LIST, fixer_parts: { type: 'array', items: STR_LIST }, fixer_notes: OBJ_LIST,'''),
 ('''    '- Do not change reference_low on a locked row (apoB, LDL-C, non-HDL-C, HOMA-IR) unless the item says the E6 baseline change is approved (M-04). Do not delete messages or rows of pregnancy and lactation rows (M-05).',''',
  '''    '- Do not change reference_low on a locked row (apoB, LDL-C, non-HDL-C, HOMA-IR) unless the item says the E6 baseline change is approved (M-04). Do not delete messages or rows of pregnancy and lactation rows (M-05).',
    ...(f.fixer_notes || []).map((n) => `- Ruling ${n.ruling}: ${n.text}.`),'''),
])
