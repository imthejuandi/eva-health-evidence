import sys
p = '/home/user/eva-health/.claude/worktrees/mopup/docs/signoff/work/mopup/build-items.cjs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    c = s.count(a)
    if c != n: sys.exit(f'expected {n} occurrence(s), found {c}: {a[:140]!r}')
    s = s.replace(a, b)

# header
rep('''// The builder runs docs/signoff/tools/compile.js itself''',
'''// The rulings before the launch (DR-2026-11-12-01, docs/signoff/work/governance/prelaunch-rulings.md; raw record
// docs/signoff/work/mopup/rulings/prelaunch.json) are built in as their 'work' fields say: CI-02, CI-03 and CI-39 give
// fixer items with the rulings' own texts, CI-05 a rule over every row, CI-11 fixer notes; a routes entry with 'ruling'
// and 'ruling_text' (CI-11, CI-39 and others) wins over the draft route, and the builder checks every quoted text
// against the raw record.
//
// The builder runs docs/signoff/tools/compile.js itself''')

# the raw record of the rulings before the launch, read with the routes
rep('''  const routesDoc = rjIf(routesFile);
  const ROUTE_ALIAS = { evidence: "evidence_pass" }; // the consolidation's name for the evidence pass''',
'''  // the rulings before the launch (DR-2026-11-12-01): every text the builder takes from them is checked against the raw record
  const PRE_FILE = path.join(W, "mopup/rulings/prelaunch.json");
  const PRE = rjIf(PRE_FILE);
  const PRE_REL = rel(PRE_FILE);
  const preRuling = (id) => (PRE?.rulings || []).find((r) => r.id === id) || null;
  const inRuling = (id, text) => { const r = preRuling(id); return !!r && [r.ruling, r.work, r.register_note, ...Object.values(r.sentences || {})].some((t) => typeof t === "string" && t.includes(text)); };
  const PRE_TAG = (id) => `${id} (DR-2026-11-12-01)`;
  const routesDoc = rjIf(routesFile);
  const ROUTE_ALIAS = { evidence: "evidence_pass" }; // the consolidation's name for the evidence pass''')
rep('''    ROUTES[id] = { ...r, route, reason: scrub(r.reason || ""), source: r.source == null ? null : scrub(r.source) };
  }''',
'''    ROUTES[id] = { ...r, route, reason: scrub(r.reason || ""), source: r.source == null ? null : scrub(r.source) };
    if (r.ruling || r.ruling_text) {
      if (!PRE) errors.push(`${rel(routesFile)}: ${id} names ruling ${r.ruling}, but ${PRE_REL} is missing`);
      else if (!r.ruling || !r.ruling_text || !inRuling(r.ruling, r.ruling_text)) errors.push(`${rel(routesFile)}: ${id}: ruling_text is not a text of ruling ${r.ruling} in ${PRE_REL}`);
    }
  }''')

# applyRoute: the ruling's text wins
rep('''    it.route = ov.route; it.route_reason = ov.reason; it.route_file = ROUTES_REL; it.routed_ledger_id = ledgerId;''',
'''    it.route = ov.route; it.route_reason = ov.reason; it.route_file = ROUTES_REL; it.routed_ledger_id = ledgerId;
    if (ov.ruling_text) { it.what = ov.ruling_text; it.ruling = PRE_TAG(ov.ruling); it.rule = undefined; it.needs = undefined; }''')
# central routes on b/d items: the ruling's text
rep('''what: `Central (the orchestrator's route): ${ov.reason}${cls === "d" ? " The physician question stays as triaged (consolidated question, part A)." : cls === "b" && t.linked_item ? ` The link stays as triaged (${scrub(t.linked_item)}).` : ""}`, owner: CE, route: "central", route_reason: ov.reason,''',
'''what: `${ov.ruling_text ? `Central (ruling ${PRE_TAG(ov.ruling)}): ${ov.ruling_text}` : `Central (the orchestrator's route): ${ov.reason}`}${cls === "d" ? " The physician question stays as triaged (consolidated question, part A)." : cls === "b" && t.linked_item ? ` The link stays as triaged (${scrub(t.linked_item)}).` : ""}`, owner: CE, route: "central", route_reason: ov.reason, ruling: ov.ruling ? PRE_TAG(ov.ruling) : "M-10",''')
rep('''consolidated_item: ciOf(x.id).join(", ") || undefined, linked_item: t && t.linked_item != null ? scrub(t.linked_item) : null, check: x.check_id, ruling: "M-10" });
      }
    }''',
'''consolidated_item: ciOf(x.id).join(", ") || undefined, linked_item: t && t.linked_item != null ? scrub(t.linked_item) : null, check: x.check_id });
      }
    }''')

# section 11: the fixer items and the rule of the rulings before the launch
rep('''  // ─── per-family stages, closing lists, fixer parts ───''',
'''  // ─── 11. the rulings before the launch (DR-2026-11-12-01): fixer items, the CI-05 rule, fixer notes ───
  const fixerNotes = {}; // family -> [{ ruling, text }]
  if (!PRE) warnings.push(`${PRE_REL} not found: the rulings before the launch are not built in`);
  else {
    const work = (id) => (preRuling(id) ? preRuling(id).work : "");
    const between = (id, a, b) => { const w = work(id); const i = w.indexOf(a); const j = b ? w.indexOf(b, i + 1) : w.length; if (i < 0 || j < 0) { errors.push(`${PRE_REL}: ruling ${id}'s work no longer holds '${a}'${b ? ` ... '${b}'` : ""}`); return ""; } return w.slice(i, j).trim(); };
    const quoted = (txt, after) => { const i = txt.indexOf(after); if (i < 0) return null; const m = txt.slice(i + after.length).match(/^\\s*'([^]*?)'(?= by\\b)/); return m ? m[1] : null; };
    const rowOf = (f, rk) => (DEC[f]?.final_rows || []).find((r) => key(r) === rk) || null;
    const holds = (r, lang, field, phrase) => !!r && String(field === "message" ? r.messages?.[lang]?.below_range : r[field] || "").includes(phrase);
    // CI-02: the f11 platelet row's below-range message
    {
      const f = "f11_platelets", rk = "platelet_count|both|All Adults|none", sen = preRuling("CI-02")?.sentences || {};
      const t = between("CI-02", "FIXER ITEM f11", " TABLE:").replace("the sentence in 'sentences'", `the sentence in 'sentences' (English: "${sen.en}" Spanish: "${sen.es}")`);
      const from = quoted(t, "(a) Replace");
      const ok = holds(rowOf(f, rk), "en", "message", from || "\\u0000");
      if (!ok) warnings.push(`CI-02: the f11 row's English below-range message no longer holds the text the ruling replaces`);
      if (t) add(f, "RULING", { source: { file: PRE_REL, key: "CI-02 work" }, row_key: rk, fields: ["messages.en.below_range", "messages.es.below_range"], what: t, text_found_in_row: ok, owner: FF, check: "M2 (texts); L2", ruling: PRE_TAG("CI-02") });
    }
    // CI-03: the two f12 neutrophil rows' below-range messages
    {
      const f = "f12_white_cells_core", sen = preRuling("CI-03")?.sentences || {};
      const t = between("CI-03", "FIXER ITEM f12").replace("the English sentence in 'sentences'", `the English sentence in 'sentences' ('${sen.en}')`).replace("the Spanish sentence in 'sentences'", `the Spanish sentence in 'sentences' ('${sen.es}')`);
      const fromEn = quoted(t, ". Replace"), fromEs = quoted(t, "Spanish: replace");
      for (const rk of ["neutrophils_absolute|male|All Adults|none", "neutrophils_absolute|female|All Adults|none"]) {
        const r = rowOf(f, rk);
        const ok = holds(r, "en", "message", fromEn || "\\u0000") && holds(r, "es", "message", fromEs || "\\u0000");
        if (!ok) warnings.push(`CI-03: ${rk} no longer holds the text the ruling replaces`);
        if (t) add(f, "RULING", { source: { file: PRE_REL, key: "CI-03 work" }, row_key: rk, fields: ["messages.en.below_range", "messages.es.below_range"], what: t, text_found_in_row: ok, owner: FF, check: "M2 (texts); L2", ruling: PRE_TAG("CI-03") });
      }
    }
    // CI-39: the f30 bilirubin notes that read '.006-60' as 0.006 years
    {
      const f = "f30_urine_pancreas_bilirubin";
      const t = between("CI-39", "FIXER ITEM f30", " METHODS LETTER");
      const rows = (DEC[f]?.final_rows || []).filter((r) => r.marker_key === "total_bilirubin" && ["method_note", "reference_source"].some((x) => /adult bands 0\\.006-60 years|ages 0\\.006-60/.test(String(r[x] || ""))));
      if (rows.length !== 3) warnings.push(`CI-39: ${rows.length} bilirubin rows hold the text the ruling replaces (the ruling names three)`);
      if (t) add(f, "RULING", { source: { file: PRE_REL, key: "CI-39 work" }, rows: rows.map(key), fields: ["method_note", "method_note_es", "reference_source", "reference_source_es"], what: t, owner: FF, check: "M2 (texts)", ruling: PRE_TAG("CI-39") });
    }
    // CI-11: the fixer notes of f07 and f22
    const note11 = "do not change reference_low on apoe_genotype or psa_free";
    if (!inRuling("CI-11", note11)) errors.push(`${PRE_REL}: ruling CI-11 no longer holds the fixer note '${note11}'`);
    else for (const f of ["f07_apolipoproteins", "f22_prostate"]) (fixerNotes[f] = fixerNotes[f] || []).push({ ruling: PRE_TAG("CI-11"), text: note11 });
    // CI-05: a row's action limit beyond the reference limit whose side's out-of-range message does not name its value
    const T05 = "State this action limit's rule in the out-of-range message in plain words, using only the action limit's own value, condition and urgency phrase; add the value to explanatory_numbers if it is missing; add no number and move no bound";
    if (!inRuling("CI-05", T05)) errors.push(`${PRE_REL}: ruling CI-05 no longer holds the item text the builder writes`);
    const COVERED = { "f11_platelets|platelet_count|both|All Adults|none": "CI-02", "f12_white_cells_core|neutrophils_absolute|male|All Adults|none": "CI-03", "f12_white_cells_core|neutrophils_absolute|female|All Adults|none": "CI-03" };
    const NUM_EN = /(?<![\\d.,])\\d{1,3}(?:,\\d{3})+(?:\\.\\d+)?(?!\\d)|(?<![\\d.,])\\d+(?:\\.\\d+)?(?!\\d)/g;
    const NUM_ES = /(?<![\\d.,])\\d{1,3}(?:\\.\\d{3})+(?:,\\d+)?(?!\\d)|(?<![\\d.,])\\d+(?:,\\d+)?(?!\\d)/g;
    const WORDS = { two: 2, three: 3, four: 4, five: 5, ten: 10, dos: 2, tres: 3, cuatro: 4, cinco: 5, diez: 10 };
    const namesValue = (text, v, limit) => {
      const t = String(text || "");
      const nums = [...[...t.matchAll(NUM_EN)].map((m) => Number(m[0].replace(/,/g, ""))), ...[...t.matchAll(NUM_ES)].map((m) => Number(m[0].replace(/\\./g, "").replace(",", ".")))];
      if (nums.some((n) => Math.abs(n - v) < 1e-9)) return true;
      const times = [...t.matchAll(/\\b(\\d+|two|three|four|five|ten|dos|tres|cuatro|cinco|diez)\\s*(?:x|×|times|veces)\\b/gi)].map((m) => WORDS[m[1].toLowerCase()] ?? Number(m[1]));
      return limit != null && times.some((k) => Math.abs(k * limit - v) <= 0.5);
    };
    const ci05 = { rows_checked: 0, action_limits_beyond: 0, listed: 0, named: 0, covered: [] };
    for (const f of fams) for (const r of DEC[f].final_rows) {
      ci05.rows_checked++;
      for (const a of r.action_limits || []) {
        if (typeof a.value !== "number" || !["below", "above"].includes(a.direction)) continue;
        const low = a.direction === "below";
        const limit = low ? r.reference_low : r.reference_high;
        if (limit == null || (low ? !(a.value < limit) : !(a.value > limit))) continue;
        ci05.action_limits_beyond++;
        const side = low ? "below_range" : "above_range";
        const missing = ["en", "es"].filter((lang) => !namesValue(r.messages?.[lang]?.[side], a.value, limit));
        if (!missing.length) { ci05.named++; continue; }
        const cov = COVERED[`${f}|${key(r)}`];
        if (cov) { ci05.covered.push(`${key(r)} (${cov})`); continue; }
        ci05.listed++;
        add(f, "ALMSG", { source: { file: `docs/signoff/work/decisions/${f}.json`, key: `${key(r)} action_limits '${scrub(a.name)}'` }, row_key: key(r), action_limit: { name: scrub(a.name), direction: a.direction, value: a.value, side, message_does_not_name_it: missing }, what: `${T05} (ruling CI-05). The action limit: '${scrub(a.name)}' (${a.direction} ${a.value}); messages.${missing.join(" and ")}.${side} does not name ${a.value}.`, owner: FF, check: "L2 (the row's message carries the rule; D-22)", ruling: PRE_TAG("CI-05") });
      }
    }
    var CI05_SUMMARY = ci05; // eslint-disable-line no-var -- reported in built_from
  }

  // ─── per-family stages, closing lists, fixer parts ───''')

# stages: fixer notes
rep('''      fixer_parts: fixerParts(fixerList),''',
'''      fixer_parts: fixerParts(fixerList),
      fixer_notes: fixerNotes[f] || [],''')
# built_from: the rulings before the launch
rep('''consolidated_items: CI ? { file: rel(CI_FILE), sha256: sha256File(CI_FILE) } : null, unexplained_changes_today: unexplained.length };''',
'''consolidated_items: CI ? { file: rel(CI_FILE), sha256: sha256File(CI_FILE) } : null, prelaunch_rulings: PRE ? { file: PRE_REL, sha256: sha256File(PRE_FILE), built_in: ["CI-02", "CI-03", "CI-05", "CI-11", "CI-39"], ci05_rule: typeof CI05_SUMMARY === "undefined" ? null : CI05_SUMMARY, route_overrides: Object.entries(ROUTES).filter(([, r]) => r.ruling).map(([id, r]) => ({ ledger_id: id, ruling: r.ruling })) } : null, unexplained_changes_today: unexplained.length };''')
open(p, 'w').write(s)
print('patched')
