import sys
p = '/home/user/eva-health/.claude/worktrees/mopup/docs/signoff/work/mopup/build-items.cjs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    c = s.count(a)
    if c != n: sys.exit(f'expected {n} occurrence(s), found {c}: {a[:120]!r}')
    s = s.replace(a, b)

rep('''    if (/^J[1-6]$/.test(x.source.lens)) { if (x.status !== "physician_question") warnings.push(`${ROUTES_REL}: ${id} is ${x.status}, not a physician question; its route is applied only to the plan's item`); routesApplied.judge_raised++; continue; }''',
'''    if (/^J[1-6]$/.test(x.source.lens)) {
      if (x.status !== "physician_question") {
        if (judgeItem[id] && ov.route !== "verifier") applyRoute(judgeItem[id], ov, id);
        warnings.push(`${ROUTES_REL}: ${id} is ${x.status}, not a physician question; ${judgeItem[id] ? `its route is applied to the plan's item ${judgeItem[id].id}` : "no item carries it, so its route is not applied"}`);
      }
      routesApplied.judge_raised++;
      continue;
    }''')

# per-family stages: the records of the verifier routes, with their file; the records the evidence pass touches
rep('''    const verifierRecords = open.filter((x) => x.owner === VF && x.kind === "REGRADE").flatMap((it) => it.evidence_ids.map((id) => ({ evidence_id: id, why: "catalogue record graded D only because the quote check could not open it (M-13)", item_id: it.id })));''',
'''    const verifierRecords = [];
    const putRecord = (id, why, itemId) => {
      const prev = verifierRecords.find((r) => r.evidence_id === id);
      if (prev) { if (!prev.item_ids.includes(itemId)) prev.item_ids.push(itemId); return; }
      const file = fileOfRecord(f, id);
      verifierRecords.push({ evidence_id: id, file, verdict_allowed: file === "research", why, item_ids: [itemId] });
    };
    for (const it of open.filter((x) => x.owner === VF && x.kind === "REGRADE")) for (const id of it.evidence_ids) putRecord(id, "catalogue record graded D only because the quote check could not open it (M-13)", it.id);
    for (const it of open.filter((x) => x.owner === VF && x.kind === "ROUTE" && x.records)) for (const id of it.records) putRecord(id, `routed: ${scrub(String(it.route_reason || "")).slice(0, 160)}`, it.id);''')
rep('''    const stages = {
      evidence_pass: fixerOwned.some((x) => stageOf(x) === "evidence_pass"),
      evidence_pass_items: fixerOwned.filter((x) => stageOf(x) === "evidence_pass").map((x) => x.id),''',
'''    const evItems = fixerOwned.filter((x) => stageOf(x) === "evidence_pass");
    const evRecords = [...new Set(evItems.flatMap((x) => [...(x.links || []).map((l) => l.evidence_id), ...recordsNamed(f, x.what)]))].sort();
    const stages = {
      evidence_pass: evItems.length > 0,
      evidence_pass_items: evItems.map((x) => x.id),
      evidence_pass_records: evRecords,''')

# reconciliation: script-raised routes, and links split into their ids (validation.md section 2)
rep('''      recon.push({ ledger_id: x.id, family: f, lens: x.source.lens, severity: x.severity, check_id: check, row_key: x.row_key, class: cls, class_by: "builder (script-raised: classed from the check that raised it)", evidence: fl ? `${CHECKS_REL}: ${check} still reports ${scrub(fl.key)}` : st === "blocked" ? `${CHECKS_REL}: ${check} is blocked (${scrub(String(r?.summary || "")).slice(0, 120)})` : `${CHECKS_REL}: ${check} ${st}; the failure is not reported on the compile of all 30 families`, linked_item: linked, linked_item_in_this_list: linked ? itemIds.has(linked) : null, route: cls === "a" ? "check sync: closes at the family's check stage (ledger.js checks) when its own run no longer reports it" : "stays until the check passes: the owned item is linked", item_id: linked, closing_lens: null });''',
'''      const ovs = ROUTES[x.id] || null;
      recon.push({ ledger_id: x.id, family: f, lens: x.source.lens, severity: x.severity, check_id: check, row_key: x.row_key, class: cls, class_by: "builder (script-raised: classed from the check that raised it)", evidence: fl ? `${CHECKS_REL}: ${check} still reports ${scrub(fl.key)}` : st === "blocked" ? `${CHECKS_REL}: ${check} is blocked (${scrub(String(r?.summary || "")).slice(0, 120)})` : `${CHECKS_REL}: ${check} ${st}; the failure is not reported on the compile of all 30 families`, linked_item: linked, linked_item_in_this_list: linked ? itemIds.has(linked) : null, route: cls === "a" ? "check sync: closes at the family's check stage (ledger.js checks) when its own run no longer reports it" : `stays until the check passes: the owned item is linked${ovs ? `; the orchestrator's route (${ovs.route}) moves that item` : ""}`, route_override: ovs, item_id: linked, closing_lens: null });''')
rep('''      recon.push({ ledger_id: x.id, family: f, lens, severity: x.severity, check_id: x.check_id, row_key: x.row_key, class: t ? t.class : null, class_by: t ? `triage (${TRIAGE[f].triaged_by})` : "untriaged (no triage file)", evidence: t ? scrub(t.evidence) : null, linked_item: t ? (t.linked_item == null ? null : scrub(t.linked_item)) : jit ? jit.id : null, linked_item_in_this_list: t && t.linked_item ? itemIds.has(t.linked_item) : null,''',
'''      const parts = t && t.linked_item ? linkParts(t.linked_item) : [];
      recon.push({ ledger_id: x.id, family: f, lens, severity: x.severity, check_id: x.check_id, row_key: x.row_key, class: t ? t.class : null, class_by: t ? `triage (${TRIAGE[f].triaged_by})` : "untriaged (no triage file)", evidence: t ? scrub(t.evidence) : null, linked_item: t ? (t.linked_item == null ? null : scrub(t.linked_item)) : jit ? jit.id : null, linked_items: parts.length ? parts.map((id) => ({ id, kind: linkKind(id) })) : undefined, linked_item_in_this_list: t && t.linked_item ? parts.some((p) => p.kind === "item" || itemIds.has(p)) && parts.filter((p) => linkKind(p) === "item").every((p) => itemIds.has(p)) : null,''')
rep('''  // ─── the reconciliation table: every physician question of the ledgers once (M-10 (1)) ───
  const itemIds = new Set([...central.map((x) => x.id), ...fams.flatMap((f) => items[f].map((x) => x.id))]);''',
'''  // ─── the reconciliation table: every physician question of the ledgers once (M-10 (1)) ───
  const itemIds = new Set([...central.map((x) => x.id), ...fams.flatMap((f) => items[f].map((x) => x.id))]);
  /** A triage link split into its ids (validation.md section 2: 'f19-E1-01 to f19-E1-14', 'f20-D3-01; f20-D3-02'). */
  function linkParts(text) {
    const outIds = [];
    for (const part of String(text).split(/\\s*[;,]\\s*/).filter(Boolean)) {
      const m = part.match(/^(f\\d{2}-[A-Z0-9]+-)(\\d{2})\\s+to\\s+(?:f\\d{2}-[A-Z0-9]+-)?(\\d{2})$/);
      if (m) { for (let n = Number(m[2]); n <= Number(m[3]); n++) outIds.push(`${m[1]}${String(n).padStart(2, "0")}`); continue; }
      outIds.push(part.replace(/\\s*\\(.*\\)$/, "").trim());
    }
    return outIds;
  }
  const linkKind = (id) => (itemIds.has(id) || /^(f\\d{2}|central)-[A-Z0-9]+-\\d{2}$/.test(id) ? "item" : /^WS3-\\d+/.test(id) ? "ws3_package" : /^C-\\d+/.test(id) ? "known_issue" : /^(D|CEO|M)-\\d+/.test(id) ? "ruling" : /^AL-/.test(id) ? "action_limit" : /^f\\d{2}-[A-Z]{1,3}\\d{2,3}$/.test(id) ? "evidence_record" : /(^|-)([A-Z]*Q|DQ|VQ|FQ|PQ)-?\\d+/i.test(id) ? "question" : "other");''')

# the summary: routes applied
rep('''  const BUILT_FROM = { commit: COMMIT, commit_date: COMMIT_DATE, builder: "docs/signoff/work/mopup/build-items.cjs", compile: "docs/signoff/tools/compile.js over the 30 families' decision files (run by the builder; compile-report exit " + compileExit + ")", checks: { file: CHECKS_REL, sha256: sha256File(checksFile), run_at_commit: fresh.git_commit || null, counts: fresh.counts, same_compile: !seedMismatch.length }, triage: { dir: TRIAGE_REL, files: triageInfo.files.length, missing: triageInfo.missing, invalid: triageInfo.invalid }, routes: fs.existsSync(routesFile) ? { file: rel(routesFile), sha256: sha256File(routesFile), entries: Object.keys(ROUTES).length } : null, unexplained_changes_today: unexplained.length };''',
'''  const BUILT_FROM = { commit: COMMIT, commit_date: COMMIT_DATE, builder: "docs/signoff/work/mopup/build-items.cjs", compile: "docs/signoff/tools/compile.js over the 30 families' decision files (run by the builder; compile-report exit " + compileExit + ")", checks: { file: CHECKS_REL, sha256: sha256File(checksFile), run_at_commit: fresh.git_commit || null, counts: fresh.counts, same_compile: !seedMismatch.length }, triage: { dir: TRIAGE_REL, files: triageInfo.files.length, missing: triageInfo.missing, invalid: triageInfo.invalid }, routes: fs.existsSync(routesFile) ? { file: rel(routesFile), sha256: sha256File(routesFile), entries: Object.keys(ROUTES).length, by_route: Object.values(ROUTES).reduce((o, r) => ({ ...o, [r.route]: (o[r.route] || 0) + 1 }), {}), applied: routesApplied } : null, consolidated_items: CI ? { file: rel(CI_FILE), sha256: sha256File(CI_FILE) } : null, unexplained_changes_today: unexplained.length };''')

# --check-dir
rep('''    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "build-items-check-"));''',
'''    const keep = !!flags["check-dir"];
    const tmp = keep ? path.resolve(flags["check-dir"]) : fs.mkdtempSync(path.join(os.tmpdir(), "build-items-check-"));''')
rep('''    fs.rmSync(tmp, { recursive: true, force: true });
    if (diffs.length)''', '''    if (!keep) fs.rmSync(tmp, { recursive: true, force: true });
    if (diffs.length)''')
open(p, 'w').write(s)
print('patched')
