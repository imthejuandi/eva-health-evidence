import json, sys
W = '/home/user/eva-health/.claude/worktrees/mopup'
p = W + '/docs/signoff/work/mopup/triage-routes.json'
d = json.loads(open(p).read())
R = {x['id']: x for x in json.load(open(W + '/docs/signoff/work/mopup/rulings/prelaunch.json'))['rulings']}
def text_of(rid):
    r = R[rid]
    return json.dumps({k: r[k] for k in ('ruling', 'work', 'register_note', 'sentences')}, ensure_ascii=False)
routes = d['routes']
SRC = 'docs/signoff/work/governance/prelaunch-rulings.md (raw: docs/signoff/work/mopup/rulings/prelaunch.json)'
T11 = "Change no bound on this row. Route: ruling CI-11. The floor 0 is removed in workstream 1-K once the validator change is approved."
T39 = "Change nothing on the row. Ruling CI-39: a band is read from its lower age; the shared age waits for Echevarne (methods letter)."
T02 = "The row's two follow-ups (below 100,000/µL; at or above 450,000/µL on a repeat) enter the table as family entries after the round, by the route of CI-05; nobody hand-drafts them before launch."
T05 = "Route for family follow-ups: generated family entries in the one table after the round; cap of 20 counts source entries only; fixers keep the rule in the out-of-range message."
T17 = "D-39's fixed line written (result.note.other_laboratory); 'the laboratory' defined as EVA's laboratory; named untrue texts fixed in f03, f09, f10, f15."
plan = [
 # (ledger id, ruling, text, why the draft is overridden, new entry?)
 ('f07_apolipoproteins--M1--apoe_genotype.both.All_Adults.critical_low--none', 'CI-11', T11, "items.json f07-M1-01 becomes a central item with the ruling's text; the route is hold, then an approved validator change, and the key does not move to non_rows (the draft named non_rows as an option)", False),
 ('f07_apolipoproteins--D1--apoe_genotype.both.All_Adults.none--low', 'CI-11', T11, "linked to f07-M1-01, which follows ruling CI-11", False),
 ('f07_apolipoproteins--M1--apoe_genotype.both.All_Adults.none--low', 'CI-11', T11, "the APOE half follows f07-M1-01, which follows ruling CI-11", False),
 ('f22_prostate--M1--psa_free.male.All_Adults.critical_low--none', 'CI-11', T11, "items.json f22-M1-01 becomes a central item with the ruling's text; not families.json non_rows (the draft named non_rows)", False),
 ('f22_prostate--M1--psa_free.male.All_Adults.none--low', 'CI-11', T11, "linked to f22-M1-01, which follows ruling CI-11; not families.json non_rows", False),
 ('f22_prostate--definition:reference_interval--psa_free.male.All_Adults.none--low', 'CI-11', T11, "items.json f22-JUDGE-02 becomes a central item with the ruling's text", False),
 ('f30_urine_pancreas_bilirubin--D3--total_bilirubin.both.90plus.band_split--none', 'CI-39', T39, "items.json f30-D3-02 becomes a central item with the ruling's text: the re-cut does not run", False),
 ('f30_urine_pancreas_bilirubin--D3--total_bilirubin.both.90plus.none--both', 'CI-39', T39, "linked to f30-D3-02, which follows ruling CI-39", False),
 ('f30_urine_pancreas_bilirubin--D3--total_bilirubin.both.90plus.none--high', 'CI-39', T39, "linked to f30-D3-02, which follows ruling CI-39", False),
 ('f30_urine_pancreas_bilirubin--D3--total_bilirubin.both.90plus.none--none', 'CI-39', T39, "linked to f30-D3-02, which follows ruling CI-39", False),
 ('f15_thyroid--D3--tsh.both.20plus.band_split--none', 'CI-39', T39, "script-raised item behind one of items.json f15-D3-01 to f15-D3-03, which become central items with the ruling's text; the re-cut does not run and f15 needs no author stage for this point (the draft had no entry)", True),
 ('f15_thyroid--D3--free_t4_thyroxine.both.20plus.band_split--none', 'CI-39', T39, "script-raised item behind one of items.json f15-D3-01 to f15-D3-03 (as above)", True),
 ('f15_thyroid--D3--free_t3_triiodothyronine.both.20plus.band_split--none', 'CI-39', T39, "script-raised item behind one of items.json f15-D3-01 to f15-D3-03 (as above)", True),
 ('f11_platelets--L2--platelet_count.female.All_Adults.pregnancy--low', 'CI-02', T02, "the draft proposed that the orchestrator draft the two table entries before launch; the ruling says nobody hand-drafts them", False),
 ('f13_white_cells_other--L2--none--none', 'CI-05', T05, "the draft left open whether the family follow-ups enter the signed table; the ruling sets the route (generated family entries after the round, WS3-40)", False),
 ('f19_male_hormones--L2--testosterone_total.male.50plus.none--low', 'CI-05', T05, "as for the other family follow-ups (route of CI-05)", False),
 ('f19_male_hormones--L2--testosterone_total.male.50plus.none--none', 'CI-05', T05, "as for the other family follow-ups (route of CI-05)", False),
 ('f20_female_hormones--L2--fsh.female.21plus.none--none', 'CI-05', T05, "as for the other family follow-ups (route of CI-05)", False),
 ('f28_autoimmunity--L2--rheumatoid_factor_rf.both.All_Adults.none--high', 'CI-05', T05, "as for the other family follow-ups (route of CI-05)", False),
 ('f09_red_cells--definition:reference_interval--red_blood_cell_count.female.All_Adults.none--none', 'CI-17', T17, "the draft waited for a central wording rule; ruling CI-17 writes it (wording-rules.md sections 4 and 7)", False),
]
for lid, rid, text, why, new in plan:
    if text not in text_of(rid): sys.exit(f'{rid}: text not in the ruling: {text[:60]}')
    if new:
        if lid in routes: sys.exit(f'{lid} already has an entry')
        routes[lid] = {'route': 'central', 'reason': f'Ruling {rid} (DR-2026-11-12-01): {why}.', 'source': f'{SRC}, {rid}', 'ruling': rid, 'ruling_text': text}
        continue
    e = routes.get(lid)
    if e is None: sys.exit(f'{lid}: no entry')
    if e.get('ruling'): sys.exit(f'{lid}: already overridden')
    routes[lid] = {'route': e['route'], 'reason': f'Ruling {rid} (DR-2026-11-12-01) wins over the draft route: {why}.', 'source': f"{SRC}, {rid}; draft: {e['source']}", 'ruling': rid, 'ruling_text': text, 'draft_reason': e['reason']}
d['_doc'] = d['_doc'] + " Updated after the rulings before the launch (DR-2026-11-12-01, docs/signoff/work/governance/prelaunch-rulings.md): where a ruling's item text and the draft route disagree, the ruling wins. Such an entry names the ruling in 'ruling', holds the ruling's own text in 'ruling_text' (the builder checks it against docs/signoff/work/mopup/rulings/prelaunch.json and writes it as the item's text) and keeps the draft's reason in 'draft_reason'."
open(p, 'w').write(json.dumps(d, indent=1, ensure_ascii=False))
print('entries', len([k for k in routes if not k.startswith('_')]), 'overridden', sum(1 for k, v in routes.items() if not k.startswith('_') and v.get('ruling')))
