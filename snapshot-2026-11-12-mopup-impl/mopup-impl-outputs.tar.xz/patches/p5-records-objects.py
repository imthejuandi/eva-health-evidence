import sys
def patch(p, pairs):
    s = open(p).read()
    for a, b in pairs:
        c = s.count(a)
        if c != 1: sys.exit(f'{p}: expected 1 occurrence, found {c}: {a[:140]!r}')
        s = s.replace(a, b)
    open(p, 'w').write(s)
    print('patched', p)
W = '/home/user/eva-health/.claude/worktrees/mopup'
I = '/tmp/claude-0/-home-user-eva-health/4e1a7523-c199-547a-904f-d87e53286958/scratchpad/mopup-impl'
patch(W + '/docs/signoff/workflows/ws1-mopup-tools.cjs', [
 ('''    out.verifier_records = (st.verifier_records || []).map((r) => r.evidence_id);''',
  '''    out.verifier_records = (st.verifier_records || []).map((r) => ({ id: r.evidence_id, file: r.file || null, why: r.why || null }));'''),
])
patch(I + '/script/ws1-mopup.template.js', [
 ('''          verifier_rows: OBJ_LIST, verifier_records: STR_LIST, closing: OBJ_LIST, new_rows: STR_LIST,''',
  '''          verifier_rows: OBJ_LIST, verifier_records: OBJ_LIST, closing: OBJ_LIST, new_rows: STR_LIST,'''),
 ('''  const records = [...new Set([...(f.verifier_records || []), ...st.evidence_changed])].sort()
  st.allowed_rows = [...list.map((x) => x.row), ...(f.author_rows || [])]
  st.allowed_records = records''',
  '''  // the items file's records, with the file each is in (M-01 (5)), and every record the evidence pass changed
  const listed = new Map((f.verifier_records || []).map((r) => [recId(r), typeof r === 'string' ? { id: r, file: null } : r]))
  for (const id of st.evidence_changed) if (!listed.has(id)) listed.set(id, { id, file: 'research or verify', why: 'changed by the evidence pass' })
  const records = [...listed.values()].sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
  st.allowed_rows = [...list.map((x) => x.row), ...(f.author_rows || [])]
  st.allowed_records = records.map((r) => r.id)'''),
 ('''  if (fromOf(f.family) === 'seal') { st.allowed_rows = [...(st.comparison || []).map((c) => c.row), ...(f.verifier_rows || []).map((r) => r.row_key), ...(f.author_rows || [])]; st.allowed_records = [...new Set([...(f.verifier_records || []), ...st.evidence_changed])] }''',
  '''  if (fromOf(f.family) === 'seal') { st.allowed_rows = [...(st.comparison || []).map((c) => c.row), ...(f.verifier_rows || []).map((r) => r.row_key), ...(f.author_rows || [])]; st.allowed_records = [...new Set([...(f.verifier_records || []).map(recId), ...st.evidence_changed])] }'''),
 ('''  if (!st.allowed_records.length) st.allowed_records = [...new Set([...(f.verifier_records || []), ...st.evidence_changed])]''',
  '''  if (!st.allowed_records.length) st.allowed_records = [...new Set([...(f.verifier_records || []).map(recId), ...st.evidence_changed])]'''),
 ('''    records.length ? `Evidence records on your list (a verdict and a grade you set yourself; for the catalogue records the cache now lets the quote check open the source, M-13): ${records.join(', ')}.` : 'No evidence record is on your list beyond the records of these rows.',''',
  '''    ...(records.length ? ['Evidence records on your list (M-01 (5)); for the catalogue records the cache now lets the quote check open the source (M-13):', ...records.map((r) => `- \\`${r.id}\\` (${r.file || 'research'} file): ${recordTask(r)}${r.why ? ` Why it is listed: ${r.why}` : ''}`)] : ['No evidence record is on your list beyond the records of these rows.']),'''),
 ('''function allowedOf(st) {''',
  '''const recId = (r) => (typeof r === 'string' ? r : r.id)
/** What the verifier may do with a listed record: the frozen validator accepts evidence_verdicts only for research records. */
function recordTask(r) {
  if (r.file === 'verify') return 'your own record. Re-open its source and check its quote and its supports links; correct it in place if they are wrong. Write no evidence_verdicts entry for it: the validator accepts verdicts only for research records, so its published grade stays with the central VERDICT item.'
  if (r.file === 'decision') return 'the fixer\\'s record (decision file). Re-open its source and check its quote; where a bound of a row in your file rests on it alone, write your own record from the source you opened, under a new id. Write no evidence_verdicts entry for it (the validator accepts verdicts only for research records) and change nothing in the decision file.'
  if (r.file === 'research or verify') return 'changed by the evidence pass: re-read it; a research record keeps an evidence verdict, which you set again (the evidence pass changes no grade, M-13).'
  return 'a verdict and a grade you set yourself.'
}

function allowedOf(st) {'''),
])
r = W + '/docs/signoff/work/mopup/dry-run/run.cjs'
patch(r, [
 ('''  const recs = (prompt.match(/Evidence records on your list[^:]*: ([^.]+)\\./) || [])[1];
  for (const id of recs ? recs.split(", ") : []) {''',
  '''  const recs = [...prompt.matchAll(/^- `(f\\d\\d-[A-Z]+\\d+)` \\((research|verify|decision|research or verify) file\\)/gm)].filter((m) => m[2] === "research").map((m) => m[1]);
  for (const id of recs) {'''),
 ('''  const setup2 = rj(path.join(r2.dir, "prompts", fs.readdirSync(path.join(r2.dir, "prompts")).find((x) => /setup/.test(x))));
  void setup2;
''', ''),
])
