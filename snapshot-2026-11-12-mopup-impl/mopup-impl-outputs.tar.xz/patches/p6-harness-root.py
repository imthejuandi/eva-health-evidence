import sys
p = '/home/user/eva-health/.claude/worktrees/mopup/docs/signoff/work/mopup/dry-run/run.cjs'
s = open(p).read()
def rep(a, b):
    global s
    c = s.count(a)
    if c != 1: sys.exit(f'expected 1 occurrence, found {c}: {a[:140]!r}')
    s = s.replace(a, b)
rep('''// phase() and log() stubbed, on scratch clones of this repository. No model is called and nothing is pushed.
//
//   node docs/signoff/work/mopup/dry-run/run.cjs --out <scratch dir outside the repository> [--triage-dir <dir>]
//''',
'''// phase() and log() stubbed, on one scratch clone of this repository. No model is called and nothing is pushed.
//
//   node docs/signoff/work/mopup/dry-run/run.cjs --out <scratch dir outside the repository> --root <scratch clone>
//
// --root is the one scratch clone every dry run reuses (no new copy of the repository per run). Before each reset the
// harness keeps what the clone holds on a branch of the clone (dry-run/keep/<out folder>-<step>), then resets it with
// git to this repository's HEAD, copies the working tree's changed docs/signoff files over it, links node_modules
// (never copied), runs the builder and commits the result as the dry run's rebuild commit. Only when --root does not
// exist yet does the harness clone the repository into it, once.
//''')
rep('''//   run 0  a separate clone: f12's verify file is changed after the rebuild; stage 0 stops the family (hash test)''',
'''//   run 0  f12's verify file is changed after the rebuild (one commit on top of it); stage 0 stops the family
//          (hash test); the clone is then kept on a branch and reset to the rebuild commit''')
rep('''// Every output is written under --out: the clones, each run's result, log, agent calls, prompts, and the files the
// runs wrote. Nothing is deleted.''',
'''// Every output is written under --out: each run's result, log, agent calls, prompts, and the files the runs wrote;
// the clone's states are kept on its branches. Nothing is deleted.''')
rep('''if (!ARGS.out) { console.error("usage: run.cjs --out <scratch dir> [--triage-dir <dir>]"); process.exit(2); }
const OUT = path.resolve(ARGS.out);
if (!path.relative(ROOT, OUT).startsWith("..")) { console.error("--out must be outside the repository"); process.exit(2); }''',
'''if (!ARGS.out || !ARGS.root) { console.error("usage: run.cjs --out <scratch dir> --root <scratch clone>"); process.exit(2); }
const OUT = path.resolve(ARGS.out);
const CLONE = path.resolve(ARGS.root);
for (const [n, d] of [["--out", OUT], ["--root", CLONE]]) if (!path.relative(ROOT, d).startsWith("..")) { console.error(`${n} must be outside the repository`); process.exit(2); }
const LABEL = path.basename(OUT).replace(/[^A-Za-z0-9._-]/g, "_");''')
rep('''function prepareClone(dir) {
  if (fs.existsSync(dir)) throw new Error(`${dir} exists: give a fresh --out`);
  execFileSync("git", ["clone", "-q", ROOT, dir]);
  // the working tree's changes of the mop-up files, so that the dry run tests what is about to be committed
  const changed = execFileSync("git", ["status", "--porcelain", "-uall"], { cwd: ROOT }).toString().split("\\n").filter(Boolean).map((l) => l.slice(3)).filter((p) => p.startsWith("docs/signoff/"));
  for (const p of changed) { const src = path.join(ROOT, p); if (!fs.existsSync(src)) continue; fs.mkdirSync(path.dirname(path.join(dir, p)), { recursive: true }); fs.copyFileSync(src, path.join(dir, p)); }
  fs.symlinkSync(path.join(fs.realpathSync(ROOT), "node_modules"), path.join(dir, "node_modules"));
  const triage = ARGS["triage-dir"] ? path.resolve(ARGS["triage-dir"]) : null;
  if (triage) { fs.mkdirSync(path.join(dir, "docs/signoff/work/mopup/triage"), { recursive: true }); for (const f of fs.readdirSync(triage).filter((x) => /^f\\d\\d_.*\\.json$/.test(x))) fs.copyFileSync(path.join(triage, f), path.join(dir, "docs/signoff/work/mopup/triage", f)); }
  const b = sh(dir, "node docs/signoff/work/mopup/build-items.cjs");
  fs.writeFileSync(path.join(OUT, `${path.basename(dir)}-build.out`), b.stdout + b.stderr);
  if (b.status !== 0) throw new Error(`the builder failed in the clone: ${b.stderr.slice(-400)}`);
  const c = sh(dir, "git add -A && git commit -q -m 'dry run: the rebuild commit (items files, checks file, triage files)' && git rev-parse HEAD");
  if (c.status !== 0) throw new Error(`commit in the clone failed: ${c.stderr}`);
  return { changed, head: c.stdout.trim().split("\\n").pop() };
}''',
'''/** Keep what the clone holds (tracked changes and untracked files) as a commit on a branch, before a reset. */
function keepState(dir, step) {
  if (!sh(dir, "git status --porcelain -uall").stdout.trim()) return null;
  const branch = `dry-run/keep/${LABEL}-${step}`;
  const r = sh(dir, `git checkout -q -B '${branch}' && git add -A && git commit -q -m 'dry run: the state kept before a reset (${LABEL}, ${step})' && git rev-parse HEAD`);
  if (r.status !== 0) throw new Error(`could not keep the state of the clone: ${r.stderr}`);
  return { branch, commit: r.stdout.trim().split("\\n").pop() };
}
function resetTo(dir, commit) {
  const r = sh(dir, `git checkout -q --detach ${commit} && git reset -q --hard ${commit} && git clean -q -fd -e node_modules`);
  if (r.status !== 0) throw new Error(`could not reset the clone to ${commit}: ${r.stderr}`);
}
function prepareClone(dir) {
  if (!fs.existsSync(dir)) { execFileSync("git", ["clone", "-q", ROOT, dir]); note(`cloned the repository once into ${dir} (later dry runs reuse it)`); }
  if (!fs.existsSync(path.join(dir, ".git"))) throw new Error(`${dir} is not a git clone`);
  const kept = keepState(dir, "before");
  const f = sh(dir, `git fetch -q '${ROOT}' HEAD && git rev-parse FETCH_HEAD`);
  if (f.status !== 0) throw new Error(`git fetch from the repository failed: ${f.stderr}`);
  const base = f.stdout.trim().split("\\n").pop();
  resetTo(dir, base);
  // the working tree's changes of the mop-up files, so that the dry run tests what is about to be committed
  const changed = execFileSync("git", ["status", "--porcelain", "-uall"], { cwd: ROOT }).toString().split("\\n").filter(Boolean).map((l) => l.slice(3)).filter((p) => p.startsWith("docs/signoff/"));
  for (const p of changed) { const src = path.join(ROOT, p); if (!fs.existsSync(src)) continue; fs.mkdirSync(path.dirname(path.join(dir, p)), { recursive: true }); fs.copyFileSync(src, path.join(dir, p)); }
  const nm = path.join(dir, "node_modules");
  if (!fs.existsSync(nm)) fs.symlinkSync(path.join(fs.realpathSync(ROOT), "node_modules"), nm);
  const b = sh(dir, `node docs/signoff/work/mopup/build-items.cjs --compile-dir '${path.join(OUT, "rebuild-compile")}'`);
  fs.writeFileSync(path.join(OUT, "rebuild-build.out"), b.stdout + b.stderr);
  if (b.status !== 0) throw new Error(`the builder failed in the clone: ${b.stderr.slice(-400)}`);
  const c = sh(dir, "git add -A && git commit -q -m 'dry run: the rebuild commit (items files)' && git rev-parse HEAD");
  if (c.status !== 0) throw new Error(`commit in the clone failed: ${c.stderr}`);
  return { changed, base, kept, head: c.stdout.trim().split("\\n").pop() };
}''')
rep('''  // run 0: a family whose files changed after the rebuild stops at stage 0
  const c0 = path.join(OUT, "clone-run0");
  const p0 = prepareClone(c0);
  note(`clone-run0 at ${p0.head.slice(0, 12)} (working-tree files carried over: ${p0.changed.length})`);
  const vf = famFile(c0, "verify", "f12_white_cells_core");
  fs.appendFileSync(vf, " ");
  sh(c0, "git commit -q -am 'dry run: f12 verify file changed after the rebuild'");
  const r0 = await run("run0", c0, { batch: "B05", started_at: "2026-11-12T07:00:00Z", families: ["f12_white_cells_core"] }, {});''',
'''  // run 0: a family whose files changed after the rebuild stops at stage 0
  const c0 = CLONE;
  const p0 = prepareClone(c0);
  note(`scratch clone ${c0} reset to ${p0.base.slice(0, 12)}${p0.kept ? ` (its earlier state kept on ${p0.kept.branch})` : ""}; working-tree files carried over: ${p0.changed.length}; rebuild commit ${p0.head.slice(0, 12)}`);
  wj(path.join(OUT, "clone.json"), { clone: c0, base: p0.base, rebuild_commit: p0.head, kept_before: p0.kept, carried_over: p0.changed });
  const vf = famFile(c0, "verify", "f12_white_cells_core");
  fs.appendFileSync(vf, " ");
  sh(c0, "git commit -q -am 'dry run: f12 verify file changed after the rebuild'");
  const r0 = await run("run0", c0, { batch: "B05", started_at: "2026-11-12T07:00:00Z", families: ["f12_white_cells_core"] }, {});''')
rep('''  // run 1: fresh start; the strongest model stops
  const c = path.join(OUT, "clone");
  const p1 = prepareClone(c);
  note(`clone at ${p1.head.slice(0, 12)} (the dry run's rebuild commit)`);''',
'''  // run 1: fresh start on the rebuild commit; the strongest model stops
  const c = CLONE;
  const kept0 = keepState(c, "run0-end");
  resetTo(c, p0.head);
  note(`clone back at the rebuild commit ${p0.head.slice(0, 12)}${kept0 ? ` (run 0's end state kept on ${kept0.branch})` : ""}`);''')
open(p, 'w').write(s)
print('patched')
