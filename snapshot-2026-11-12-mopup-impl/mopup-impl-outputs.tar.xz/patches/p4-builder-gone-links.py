import sys
p = '/home/user/eva-health/.claude/worktrees/mopup/docs/signoff/work/mopup/build-items.cjs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    c = s.count(a)
    if c != n: sys.exit(f'expected {n} occurrence(s), found {c}: {a[:120]!r}')
    s = s.replace(a, b)
rep('''  const byFamily = {};
  const total = Object.fromEntries(OWNERS.map((w) => [w, 0]));''',
'''  // A class b item whose linked item this build no longer makes (its owner landed after the triage; CI-62) goes to the
  // raising lens's closing list: the lens re-reads it on today's files and closes it or raises it again (M-10 (4)).
  const builtIds = new Set([...central.map((x) => x.id), ...fams.flatMap((f) => items[f].map((x) => x.id))]);
  const ITEM_ID_RE = /^(f\\d{2}|central)-[A-Z0-9]+-\\d{2}$/;
  const goneLinks = (t) => { const ids = String(t.linked_item || "").split(/\\s*[;,]\\s*/).map((x) => x.trim()).filter((x) => ITEM_ID_RE.test(x)); return ids.length && ids.every((x) => !builtIds.has(x)) ? ids : null; };
  const byFamily = {};
  const total = Object.fromEntries(OWNERS.map((w) => [w, 0]));''')
rep('''      if (t.class === "a" || t.class === "e") put(x.source.lens, x.id, `triage class ${t.class}`);''',
'''      if (t.class === "a" || t.class === "e") put(x.source.lens, x.id, `triage class ${t.class}`);
      else if (t.class === "b" && goneLinks(t) && !ROUTES[x.id]) put(x.source.lens, x.id, `triage class b; its linked item ${goneLinks(t).join(", ")} is not an item of this build any more (the files changed after the triage, CI-62): the lens re-reads it`);''')
open(p, 'w').write(s)
print('patched')
