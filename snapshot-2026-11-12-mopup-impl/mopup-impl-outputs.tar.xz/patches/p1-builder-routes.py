import sys
p = '/home/user/eva-health/.claude/worktrees/mopup/docs/signoff/work/mopup/build-items.cjs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    c = s.count(a)
    if c != n: sys.exit(f'expected {n} occurrence(s), found {c}: {a[:120]!r}')
    s = s.replace(a, b)

# --- header: routes format and --check-dir
rep('''//   --routes <file>      the orchestrator's override file (default docs/signoff/work/mopup/triage-routes.json):
//                        {ledger_id: {route: "fixer"|"evidence_pass"|"verifier"|"central", reason, rows?, text?}}''',
'''//   --routes <file>      the orchestrator's override file (default docs/signoff/work/mopup/triage-routes.json):
//                        {routes: {ledger_id: {route: "fixer"|"evidence"|"verifier"|"central", reason, source, rows?, text?}}}
//                        ("evidence" and "evidence_pass" name the same stage; keys starting with "_" are notes). A key is
//                        a judge-raised physician question (a class c route replaces the fixer; a b or d route is added)
//                        or a script-raised ledger item, whose route moves the item the builder made from its check.''')
rep('''//   --check              rebuild into a temporary folder and compare with --out; exit 1 on any difference''',
'''//   --check              rebuild into a temporary folder and compare with --out; exit 1 on any difference
//   --check-dir <dir>    with --check: rebuild into this folder and keep it (default: a temporary folder, removed)''')

# --- D3 runner gap: the label the compile writes is a cause too (CI-38, f20-D3-01)
rep('''D3 lists it because of how the frozen runner reads the catalogue (a unit label it does not match, an age written in a form it cannot parse, or an overlapping age band), not because the row departs from the line it cites: a D3 runner gap for central, whose change needs its own approval.''',
'''D3 lists it because of how the frozen runner reads the catalogue or the compiled row (a unit label it does not match, an age written in a form it cannot parse, an overlapping age band, or the state label the compile writes), not because the row departs from the line it cites: a D3 runner gap for central (the runner, or the compile's label), whose change needs its own approval.''')

# --- C21: on a class e row the record only (CI-38: 'restore the production value' would put an optimal band back)
rep('''  const NEEDS_RECORD = /^(normal_|optimal_|critical_|unit_|row$)/;''',
'''  const NEEDS_RECORD = /^(normal_|optimal_|critical_|unit_|row$)/;
  // A class e row is reference only: restoring a production optimal value would put an optimal band back on it (CI-38).
  const classEOptimal = (f, rk, x) => { const r = (DEC[f]?.final_rows || []).find((y) => key(y) === rk); return r && r.marker_class === "e" && /^optimal_(low|high)$/.test(String(x.field)) && x.to == null ? r : null; };''')
rep('''          : `Add a change record (reason, source${x.direction === "loosen" ? ", and a grade A or B evidence id: it is a loosening" : ""}) whose "to" is the compiled value, or restore the production value: ${x.field} ${JSON.stringify(x.from)} -> ${JSON.stringify(x.to)}. A fresh verdict never stands in for this record (M-01 (4); CEO-4, CEO-6, CEO-11).`,
      owner: nonRowColumn ? CE : FF, check: "D6 (C-21); D5",''',
'''          : classEOptimal(f, rk, x)
            ? `Add a change record whose "to" is the compiled value: ${x.field} ${JSON.stringify(x.from)} -> ${JSON.stringify(x.to)}, with its reason (the marker is class e, reference only, and carries no optimal band, as the row's own method note says), its source${x.direction === "loosen" ? " and, as it is a loosening, a grade A or B evidence id or a record of the decision's own" : ""}. Do not restore the production value: it would put an optimal band back on a class e row the verifier graded ${classEOptimal(f, rk, x).grade || "D"} (PLAN.md section 4; triage CI-38). A fresh verdict never stands in for this record (M-01 (4); CEO-4, CEO-6, CEO-11).`
            : `Add a change record (reason, source${x.direction === "loosen" ? ", and a grade A or B evidence id: it is a loosening" : ""}) whose "to" is the compiled value, or restore the production value: ${x.field} ${JSON.stringify(x.from)} -> ${JSON.stringify(x.to)}. A fresh verdict never stands in for this record (M-01 (4); CEO-4, CEO-6, CEO-11).`,
      owner: nonRowColumn ? CE : FF, check: "D6 (C-21); D5", rule: classEOptimal(f, rk, x) ? "class e row: the change record only, no restored optimal value (CI-38)" : undefined,''')

# --- routes: the consolidation's file format
rep('''  const routesDoc = rjIf(routesFile);
  const ROUTES = routesDoc ? (routesDoc.routes && typeof routesDoc.routes === "object" ? routesDoc.routes : Object.fromEntries(Object.entries(routesDoc).filter(([k]) => !k.startsWith("_")))) : {};
  for (const [id, r] of Object.entries(ROUTES)) if (!["fixer", "evidence_pass", "verifier", "central"].includes(r?.route)) errors.push(`${rel(routesFile)}: ${id}: route must be fixer, evidence_pass, verifier or central`);''',
'''  const routesDoc = rjIf(routesFile);
  const ROUTE_ALIAS = { evidence: "evidence_pass" }; // the consolidation's name for the evidence pass
  const ROUTES = {};
  for (const [id, r] of Object.entries(routesDoc ? (routesDoc.routes && typeof routesDoc.routes === "object" ? routesDoc.routes : routesDoc) : {})) {
    if (id.startsWith("_")) continue;
    const route = ROUTE_ALIAS[r?.route] || r?.route;
    if (!["fixer", "evidence_pass", "verifier", "central"].includes(route)) { errors.push(`${rel(routesFile)}: ${id}: route must be fixer, evidence (evidence_pass), verifier or central`); continue; }
    ROUTES[id] = { ...r, route, reason: scrub(r.reason || ""), source: r.source == null ? null : scrub(r.source) };
  }
  const ROUTES_REL = rel(routesFile);
  // The consolidation's central items (triage/consolidated/central-items.json), for the id a route belongs to.
  const CI_FILE = path.join(triageDir, "consolidated/central-items.json");
  const CI = rjIf(CI_FILE);
  const ciOf = (ledgerId) => (CI?.items || []).filter((c) => (c.ledger_items || []).some((l) => l.ledger_id === ledgerId)).map((c) => c.id);''')

# --- verifier routes: rows and records
rep('''  const triageReview = [];
  const triageItemOf = {}; // ledger id -> item
  const routedVerifier = {}; // family -> [{ledger_id, rows, reason}]''',
'''  /** Evidence record ids a route's reason names: single ids, ranges ('f19-F01 to f19-F09', 'f26-F01 to F15') and 'the f26-V records'. */
  function recordsNamed(f, text) {
    const R = recordIds(f);
    const has = (id) => R.research.has(id) || R.verify.has(id) || R.decision.has(id);
    const all = [...R.research, ...R.verify, ...R.decision];
    const outIds = new Set();
    const t = String(text || "");
    for (const m of t.matchAll(/\\b(f\\d{2})-([A-Z]{1,2})(\\d{2,3})\\s+to\\s+(?:f\\d{2}-)?([A-Z]{1,2})?(\\d{2,3})\\b/g)) {
      if (m[4] && m[4] !== m[2]) continue;
      for (let n = Number(m[3]); n <= Number(m[5]); n++) { const id = `${m[1]}-${m[2]}${String(n).padStart(m[3].length, "0")}`; if (has(id)) outIds.add(id); }
    }
    for (const m of t.matchAll(/\\b(f\\d{2}-[A-Z]{1,3}\\d{2,3})\\b(?!-\\d)/g)) if (has(m[1])) outIds.add(m[1]);
    for (const m of t.matchAll(/\\bthe (f\\d{2})-([A-Z]{1,2}) records\\b/g)) for (const id of all) if (new RegExp(`^${m[1]}-${m[2]}\\\\d+$`).test(id)) outIds.add(id);
    return [...outIds].sort();
  }
  const fileOfRecord = (f, id) => { const R = recordIds(f); return R.research.has(id) ? "research" : R.verify.has(id) ? "verify" : R.decision.has(id) ? "decision" : null; };
  // Rows a verifier route names in words only (summary.md, 'Before the round launches', point 2; CI-40).
  const ROUTE_ROWS = { "f09_red_cells--E3--hemoglobin.male.All_Adults.none--both": ["hemoglobin|male|All Adults|none", "hemoglobin|female|All Adults|none"] };
  // Records on a verifier's list that no ledger item routes (CI-40: 'include f12-V03, which no ledger item routes').
  const UNROUTED_VERIFIER_RECORDS = [{ family: "f12_white_cells_core", records: ["f12-V03"], ci: "CI-40", why: "a record the verifier wrote, with no evidence_verdicts entry; no ledger item routes it (CI-40)" }];
  // Evidence-pass links the consolidation names from an observation, with no ledger item (CI-51).
  const EXTRA_LINKS = [{ family: "f10_red_cell_indices", evidence_id: "f10-E08", row_key: "mcv|both|All Adults|none", bound: "reference_high", ci: "CI-51", observation: "f10.O04", why: "the record's own note says 'Not adopted as the bound', yet the link makes the compile list it among the ids of the 100 to 101 fL change" }];
  const verdictItemOf = (f) => items[f].find((it) => it.kind === "VERDICT") || null;
  const recordLine = (f, ids) => ids.map((id) => `${id} (${fileOfRecord(f, id)} file)`).join(", ");
  const RECORD_RULE = "Research records get a verdict and a grade. A record of the verify file (the verifier's own) or of the decision file (the fixer's) is re-opened and checked, quote and supports links, and corrected in the verifier's own file where it is the verifier's; where a bound of a row rests on a fixer's record alone, the verifier writes its own record from the source it opened. Neither gets an evidence_verdicts entry: the frozen validator accepts verdicts only for research records (docs/signoff/tools/validate.js, semanticVerify), so their published grade stays with the central VERDICT item.";
  function applyRoute(it, ov, ledgerId) {
    const owner = ov.route === "central" ? CE : ov.route === "verifier" ? VF : FF;
    if (it.owner !== owner) {
      it.route_moved_from = it.owner;
      if (owner === CE && it.owner === FF) it.what = `Central (the orchestrator's route): the fixer changes nothing for this item in this round. ${it.what}`;
      it.owner = owner;
      if (owner !== FF && owner !== VF) it.closing_pass = undefined;
    }
    if (ov.route === "evidence_pass") it.stage = "evidence pass (research and verify files)";
    else if (ov.route === "fixer") it.stage = "fixer (decision file)";
    it.route = ov.route; it.route_reason = ov.reason; it.route_file = ROUTES_REL; it.routed_ledger_id = ledgerId;
    const ci = ciOf(ledgerId); if (ci.length) it.consolidated_item = ci.join(", ");
  }
  const triageReview = [];
  const triageItemOf = {}; // ledger id -> item
  const routedVerifier = {}; // family -> [{ledger_id, rows, records, reason}]''')

# the triage loop: b/d texts for the fixer and evidence routes, verifier rows/records, central routes on b/d items
rep('''      if (cls === "c" || (ov && ["fixer", "evidence_pass"].includes(ov.route))) {
        const text = scrub((ov && ov.text) || (t && t.fixer_text) || "");''',
'''      const jit0 = judgeItem[x.id];
      if (ov && jit0 && ov.route !== "verifier") { applyRoute(jit0, ov, x.id); triageItemOf[x.id] = jit0; continue; } // the plan's item of this ledger id follows the route
      if (cls === "c" || (ov && ["fixer", "evidence_pass"].includes(ov.route))) {
        const routedText = ov && cls !== "c" ? `The orchestrator's route (${ROUTES_REL}): ${ov.reason}${t && t.notes ? ` Triage notes: ${t.notes}` : ""}${t ? ` Triage evidence: ${t.evidence}` : ""}${cls === "d" ? " The physician question stays as triaged." : cls === "b" && t.linked_item ? ` The link stays (${t.linked_item}).` : ""}` : "";
        const text = scrub((ov && ov.text) || (t && t.fixer_text) || routedText);''')
rep('''        if (route.route === "verifier") {
          (routedVerifier[f] = routedVerifier[f] || []).push({ ledger_id: x.id, rows: (ov && ov.rows) || (x.row_key ? [x.row_key] : []), reason: route.reason, text });
          continue;
        }''',
'''        if (route.route === "verifier") {
          (routedVerifier[f] = routedVerifier[f] || []).push({ ledger_id: x.id, rows: (ov && ov.rows) || ROUTE_ROWS[x.id] || (x.check_id === "E3" && x.row_key ? [x.row_key] : []), records: ov ? recordsNamed(f, ov.reason) : [], reason: route.reason, text: ov ? null : text });
          continue;
        }''')
rep('''      } else if (ov && ov.route === "verifier") {
        (routedVerifier[f] = routedVerifier[f] || []).push({ ledger_id: x.id, rows: ov.rows || (x.row_key ? [x.row_key] : []), reason: `orchestrator's route: ${ov.reason}`, text: ov.text ? scrub(ov.text) : null });
      }
    }''',
'''      } else if (ov && ov.route === "verifier") {
        (routedVerifier[f] = routedVerifier[f] || []).push({ ledger_id: x.id, rows: ov.rows || ROUTE_ROWS[x.id] || (x.check_id === "E3" && x.row_key ? [x.row_key] : []), records: recordsNamed(f, ov.reason), reason: `orchestrator's route: ${ov.reason}`, text: ov.text ? scrub(ov.text) : null });
      } else if (ov && ov.route === "central") {
        // class b and d: the route is added; the link (b) and the physician question (d) stay as triaged
        triageItemOf[x.id] = add(f, "ROUTE", { source: { file: ROUTES_REL, key: x.id }, ledger_id: x.id, lens: x.source.lens, triage_class: cls, row_key: x.row_key, what: `Central (the orchestrator's route): ${ov.reason}${cls === "d" ? " The physician question stays as triaged (consolidated question, part A)." : cls === "b" && t.linked_item ? ` The link stays as triaged (${scrub(t.linked_item)}).` : ""}`, owner: CE, route: "central", route_reason: ov.reason, consolidated_item: ciOf(x.id).join(", ") || undefined, linked_item: t && t.linked_item != null ? scrub(t.linked_item) : null, check: x.check_id, ruling: "M-10" });
      }
    }''')
rep('''    for (const r of routedVerifier[f] || []) {
      triageItemOf[r.ledger_id] = add(f, "ROUTE", { source: { file: r.reason.startsWith("orchestrator") ? rel(routesFile) : `${TRIAGE_REL}/${f}.json`, key: r.ledger_id }, ledger_id: r.ledger_id, lens: ledgerById[r.ledger_id].source.lens, rows: r.rows, depth: ledgerById[r.ledger_id].check_id === "E3" ? "challenged_grade" : "routed", what: `${r.text ? `${r.text} ` : ""}On the verifier's list (${r.reason}): ${r.rows.length ? `fresh verdict and grade on ${r.rows.join(" and ")}, the verifier opening every source of the challenged bound (M-01 'challenged grade')` : "the verifier's own task as written"}.`, owner: VF, route: "verifier", route_reason: r.reason, check: ledgerById[r.ledger_id].check_id, closing_pass: true, ruling: "M-10; M-01" });
    }
  }
  for (const id of Object.keys(ROUTES)) if (!ledgerById[id] || ledgerById[id].status !== "physician_question" || !/^J[1-6]$/.test(ledgerById[id].source.lens)) warnings.push(`${rel(routesFile)}: ${id} is not a judge-raised physician question; its route is ignored`);''',
'''    for (const r of routedVerifier[f] || []) {
      const rowsTxt = r.rows.length ? `fresh verdict and grade on ${r.rows.join(" and ")}, the verifier opening every source of the challenged bound (M-01 'challenged grade')` : "";
      const recTxt = r.records.length ? `the records ${recordLine(f, r.records)}. ${RECORD_RULE}` : "";
      const vit = verdictItemOf(f);
      triageItemOf[r.ledger_id] = add(f, "ROUTE", { source: { file: r.reason.startsWith("orchestrator") ? ROUTES_REL : `${TRIAGE_REL}/${f}.json`, key: r.ledger_id }, ledger_id: r.ledger_id, lens: ledgerById[r.ledger_id].source.lens, rows: r.rows, records: r.records.length ? r.records : undefined, depth: r.rows.length ? (ledgerById[r.ledger_id].check_id === "E3" ? "challenged_grade" : "routed") : undefined, what: `${r.text ? `${r.text} ` : ""}On the verifier's list (${r.reason}): ${[rowsTxt, recTxt].filter(Boolean).join("; and ") || "the verifier's own task as written"}.${r.records.length && vit ? ` (${vit.id})` : ""}`, owner: VF, route: "verifier", route_reason: r.reason, consolidated_item: ciOf(r.ledger_id).join(", ") || undefined, check: ledgerById[r.ledger_id].check_id, closing_pass: true, ruling: "M-10; M-01 (5)" });
    }
  }
  // routes on script-raised ledger items: the item the builder made from the check follows the route
  const scriptItemOf = {};
  for (const f of fams) for (const x of LED[f].issues.filter((y) => !/^J[1-6]$/.test(y.source.lens))) {
    const r = fresh.results.find((y) => y.id === x.check_id);
    const fl = (r?.failures || []).find((y) => L.issueId(f, x.check_id, y.key, null) === x.id);
    if (fl && failureItem[`${x.check_id}|${fl.key}`]) scriptItemOf[x.id] = failureItem[`${x.check_id}|${fl.key}`];
  }
  const itemById = (id) => central.find((it) => it.id === id) || fams.map((f) => items[f].find((it) => it.id === id)).find(Boolean) || null;
  const routesApplied = { judge_raised: 0, script_raised: 0, plan_items_moved: [] };
  for (const [id, ov] of Object.entries(ROUTES)) {
    const x = ledgerById[id];
    if (!x) { errors.push(`${ROUTES_REL}: ${id} is not a ledger id`); continue; }
    if (/^J[1-6]$/.test(x.source.lens)) { if (x.status !== "physician_question") warnings.push(`${ROUTES_REL}: ${id} is ${x.status}, not a physician question; its route is applied only to the plan's item`); routesApplied.judge_raised++; continue; }
    const it = scriptItemOf[id] ? itemById(scriptItemOf[id]) : null;
    if (!it) { warnings.push(`${ROUTES_REL}: ${id} is script-raised and no item of this build comes from its check failure; its route is not applied`); continue; }
    const was = it.owner;
    applyRoute(it, ov, id);
    routesApplied.script_raised++;
    if (was !== it.owner) routesApplied.plan_items_moved.push({ id: it.id, from: was, to: it.owner });
  }
  for (const it of Object.values(judgeItem)) if (it.route && it.route_moved_from) routesApplied.plan_items_moved.push({ id: it.id, from: it.route_moved_from, to: it.owner });
  // records no ledger item routes (CI-40) and links named from an observation (CI-51)
  for (const u of UNROUTED_VERIFIER_RECORDS) {
    const missing = u.records.filter((id) => !fileOfRecord(u.family, id));
    if (missing.length) { errors.push(`builder table UNROUTED_VERIFIER_RECORDS: ${missing.join(", ")} not in the files of ${u.family}`); continue; }
    const vit = verdictItemOf(u.family);
    add(u.family, "ROUTE", { source: { file: rel(CI_FILE), key: u.ci }, records: u.records, what: `On the verifier's list (${u.ci}): the records ${recordLine(u.family, u.records)}, ${u.why}. ${RECORD_RULE}${vit ? ` (${vit.id})` : ""}`, owner: VF, route: "verifier", route_reason: `${u.ci}: ${u.why}`, consolidated_item: u.ci, check: "E3; G6 (published grade)", ruling: "M-01 (5); M-10" });
  }
  for (const e of EXTRA_LINKS) {
    const f = e.family;
    const rec = (RES[f].evidence || []).find((x) => x.id === e.evidence_id);
    const si = rec ? (rec.supports || []).findIndex((s) => s.row_key === e.row_key && s.bound === e.bound) : -1;
    if (si < 0) { warnings.push(`builder table EXTRA_LINKS: ${e.evidence_id} has no supports link to ${e.row_key} ${e.bound} any more; nothing to do`); continue; }
    const recs2 = (RES[f].evidence || []).map((x) => (x.id !== rec.id ? x : { ...x, supports: x.supports.filter((_, j) => j !== si) }));
    const before = [], after = [], vBefore = [], vAfter = [];
    RC.checkBoundCoverage(RES[f].rows, RES[f].evidence || [], "x", before); RC.checkBoundCoverage(RES[f].rows, recs2, "x", after);
    RC.checkBoundCoverage(VER[f].final_rows, [...(RES[f].evidence || []), ...(VER[f].evidence || [])], "x", vBefore); RC.checkBoundCoverage(VER[f].final_rows, [...recs2, ...(VER[f].evidence || [])], "x", vAfter);
    const ok = after.length <= before.length && vAfter.length <= vBefore.length;
    add(f, "LINKS", { source: { file: `docs/signoff/work/research/${f}.json`, key: `${e.evidence_id} supports ${e.row_key} ${e.bound}` }, links: [{ file: `docs/signoff/work/research/${f}.json`, evidence_id: e.evidence_id, row_key: e.row_key, bound: e.bound, why: e.why }], what: ok ? `Evidence pass (M-13; ${e.ci}, observation ${e.observation}): remove the supports[] link of ${e.evidence_id} to ${e.row_key} ${e.bound}: ${e.why}. The builder checked that the research and verify files stay valid under the frozen coverage check without it. Change no quote, grade, verdict or row; the verifier sees the changed record in the same session.` : `The supports[] link of ${e.evidence_id} to ${e.row_key} ${e.bound} cannot be removed: ${e.why}, but without it the frozen coverage check fails (no other record supports the bound). Central: the record's note, or another record for the bound (${e.ci}).`, owner: ok ? FF : CE, stage: ok ? "evidence pass (research and verify files)" : undefined, consolidated_item: e.ci, check: "E1; E2 (records)", ruling: "M-13" });
  }''')
open(p, 'w').write(s)
print('patched', p)
