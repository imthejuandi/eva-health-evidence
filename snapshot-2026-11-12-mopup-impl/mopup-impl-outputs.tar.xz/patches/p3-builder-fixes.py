import sys
p = '/home/user/eva-health/.claude/worktrees/mopup/docs/signoff/work/mopup/build-items.cjs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    c = s.count(a)
    if c != n: sys.exit(f'expected {n} occurrence(s), found {c}: {a[:120]!r}')
    s = s.replace(a, b)
rep('''linked_item_in_this_list: t && t.linked_item ? parts.some((p) => p.kind === "item" || itemIds.has(p)) && parts.filter((p) => linkKind(p) === "item").every((p) => itemIds.has(p)) : null,''',
'''linked_item_in_this_list: parts.some((p) => linkKind(p) === "item") ? parts.filter((p) => linkKind(p) === "item").every((p) => itemIds.has(p)) : null,''')
rep('''      const rowsTxt = r.rows.length ? `fresh verdict and grade on ${r.rows.join(" and ")}, the verifier opening every source of the challenged bound (M-01 'challenged grade')` : "";
      const recTxt = r.records.length ? `the records ${recordLine(f, r.records)}. ${RECORD_RULE}` : "";
      const vit = verdictItemOf(f);
      triageItemOf[r.ledger_id] = add(f, "ROUTE", { source: { file: r.reason.startsWith("orchestrator") ? ROUTES_REL : `${TRIAGE_REL}/${f}.json`, key: r.ledger_id }, ledger_id: r.ledger_id, lens: ledgerById[r.ledger_id].source.lens, rows: r.rows, records: r.records.length ? r.records : undefined, depth: r.rows.length ? (ledgerById[r.ledger_id].check_id === "E3" ? "challenged_grade" : "routed") : undefined, what: `${r.text ? `${r.text} ` : ""}On the verifier's list (${r.reason}): ${[rowsTxt, recTxt].filter(Boolean).join("; and ") || "the verifier's own task as written"}.${r.records.length && vit ? ` (${vit.id})` : ""}`,''',
'''      const rowsTxt = r.rows.length ? `a fresh verdict and grade on ${r.rows.join(" and ")}, opening every source of the challenged bound (M-01 'challenged grade')` : "";
      const recTxt = r.records.length ? `the records ${recordLine(f, r.records)}` : "";
      const vit = verdictItemOf(f);
      triageItemOf[r.ledger_id] = add(f, "ROUTE", { source: { file: r.reason.startsWith("orchestrator") ? ROUTES_REL : `${TRIAGE_REL}/${f}.json`, key: r.ledger_id }, ledger_id: r.ledger_id, lens: ledgerById[r.ledger_id].source.lens, rows: r.rows, records: r.records.length ? r.records : undefined, depth: r.rows.length ? (ledgerById[r.ledger_id].check_id === "E3" ? "challenged_grade" : "routed") : undefined, what: `${r.text ? `${r.text} ` : ""}On the verifier's list (M-01 (5)): ${[rowsTxt, recTxt].filter(Boolean).join(", and ") || "the verifier's own task as written"}.${r.records.length ? ` ${RECORD_RULE}${vit ? ` (${vit.id})` : ""}` : ""} Why: ${r.reason.replace(/^orchestrator's route: /, `the orchestrator's route (${ROUTES_REL}): `)}`,''')
rep('''    add(u.family, "ROUTE", { source: { file: rel(CI_FILE), key: u.ci }, records: u.records, what: `On the verifier's list (${u.ci}): the records ${recordLine(u.family, u.records)}, ${u.why}. ${RECORD_RULE}${vit ? ` (${vit.id})` : ""}`,''',
'''    add(u.family, "ROUTE", { source: { file: rel(CI_FILE), key: u.ci }, records: u.records, what: `On the verifier's list (M-01 (5); ${u.ci}): the records ${recordLine(u.family, u.records)}, ${u.why}. ${RECORD_RULE}${vit ? ` (${vit.id})` : ""}`,''')
rep('''  console.log("triage", JSON.stringify({ files: out.triage.files.length, missing: out.triage.missing.length, invalid: out.triage.invalid, stale: out.triage.stale.map((x) => x.family), review: out.triage.review.length }));''',
'''  console.log("triage", JSON.stringify({ files: out.triage.files.length, missing: out.triage.missing.length, invalid: out.triage.invalid, stale: out.triage.stale.map((x) => x.family), review: out.triage.review.length }));
  if (out.built_from.routes) console.log("routes", JSON.stringify({ entries: out.built_from.routes.entries, by_route: out.built_from.routes.by_route, applied: out.built_from.routes.applied }));''')
open(p, 'w').write(s)
print('patched')
