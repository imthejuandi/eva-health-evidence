// One-off: builds docs/signoff/workflows/ws1-mopup.js from the template, splicing in the blocks of ws1-batch.js
// byte for byte (each "//@@COPY a-b" line becomes lines a to b of ws1-batch.js). Kept in scratch as the proof of how
// the copies were made; the reviewer's check is docs/signoff/work/mopup/dry-run/copied-blocks.cjs.
"use strict";
const fs = require("fs");
const path = require("path");
const [template, source, target] = process.argv.slice(2);
const src = fs.readFileSync(source, "utf8").split("\n");
const out = [];
for (const line of fs.readFileSync(template, "utf8").split("\n")) {
  const m = line.match(/^\/\/@@COPY (\d+)-(\d+)$/);
  if (!m) { out.push(line); continue; }
  const a = Number(m[1]), b = Number(m[2]);
  out.push(...src.slice(a - 1, b));
}
fs.writeFileSync(target, out.join("\n"));
console.log(`wrote ${path.basename(target)}: ${out.length} lines`);
