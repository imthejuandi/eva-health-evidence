export const meta = {
  name: 'ws1-mopup',
  description: 'EVA sign-off workstream 1 mop-up round: one bounded pass per family from its items file (evidence pass, author of new rows, fixer, verifier, seal, check, closing pass), DR-2026-11-11-01',
  whenToUse: 'A mop-up session of workstream 1 (docs/signoff/work/mopup/README.md), with args {batch, started_at}',
  phases: [
    { title: 'Setup', detail: 'stage 0: the items files, the hash and ancestry tests, validation, a clean checkout' },
    { title: 'Evidence', detail: 'stage 1: the evidence pass on the research and verify files; no grade and no verdict changes' },
    { title: 'Author', detail: 'stage 2: the new row keys the items file lists, and nothing else' },
    { title: 'Fix', detail: 'stage 3: the fixer items in parts of at most 12 by row, one part after another' },
    { title: 'Verify', detail: 'stage 4: a fresh verdict on every row the comparison lists, on claude-fable-5-2' },
    { title: 'Seal', detail: 'stage 5: verify_sha256, and only the fields the verifier names in corrections[]' },
    { title: 'Check', detail: 'stage 6: validate, ownership, compile, DSRT, ledger sync, the comparison and the guards' },
    { title: 'Closing', detail: 'stage 7: the raising lens re-reads its listed items; J1 and J2 read the new rows' },
    { title: 'Scorecard', detail: 'stage 8: ledger, finalize, run summary, state file, scorecard-<batch>.mopup.md' },
  ],
}

// docs/signoff/workflows/ws1-mopup.js runs the workstream 1 mop-up round (docs/signoff/work/mopup/plan.md section 4,
// as amended by the 14 rulings of DR-2026-11-11-01 in docs/signoff/work/governance/mopup-rulings.md, and the four
// guards of docs/signoff/work/mopup/execution-decision.json). One pass per family, no loop and no judge round: the
// work list is the family's items file, docs/signoff/work/mopup/items/<family>.json, built by build-items.cjs.
// Like ws1-batch.js the script only orchestrates: agents read and write every file; the mechanical steps are
// docs/signoff/workflows/ws1-mopup-tools.cjs and the tools of docs/signoff/tools/, run by runner agents. No clock, no
// random numbers, no file access of its own. Blocks marked "copied unchanged" are byte-identical to ws1-batch.js
// (docs/signoff/work/mopup/README.md lists them with their lines). AI work product for a licensed physician.
//
// The four guards (execution decision):
// - per-model halt: a verifier, closing-lens or new-row reading agent on claude-fable-5-2 that returns nothing twice
//   (a result that reports another model counts as nothing, M-03) holds its families (no seal, no finalize, no commit)
//   and halts every later stage on that model in the session; nothing ever substitutes for it;
// - the seal copies into the decision only the fields the verifier names in corrections[] written in this session;
//   any other difference stops the family (ws1-mopup-tools.cjs seal);
// - a held family runs again from a named stage (args.from_stage), and stage 0 then compares its files with the hashes
//   recorded after the last finished stage (checks/<batch>-mopup-state.json), not with the items file;
// - the scorecard is scorecard-<batch>.mopup.md, so scorecard-<batch>.md stays the record of the batch.

// ─── arguments ───

const A = args || {}
if (!A.batch || typeof A.batch !== 'string') throw new Error('args.batch is required, e.g. {"batch": "B05", "started_at": "2026-11-12T09:00:00Z"}')
if (!A.started_at || typeof A.started_at !== 'string') throw new Error('args.started_at is required (an ISO time; the script has no clock)')
const BATCH = A.batch
const STARTED_AT = A.started_at
const TODAY = STARTED_AT.slice(0, 10)
// M-02: one bounded pass; the round is fixed per batch (round 5 for B01's families, round 3 for the others)
const ROUND = BATCH === 'B01' ? 5 : 3
if (A.round !== undefined && A.round !== ROUND) throw new Error(`args.round is fixed per batch (ruling M-02): ${BATCH} runs mop-up round ${ROUND}`)
const AGENT_CAP = Number.isInteger(A.agent_cap) && A.agent_cap > 0 ? A.agent_cap : 40
const CAP_AUTHOR = Number.isInteger(A.search_cap_author) ? A.search_cap_author : 10
const CAP_VERIFIER = Number.isInteger(A.search_cap_verifier) ? A.search_cap_verifier : 8
const CAP_FIXER = Number.isInteger(A.search_cap_fixer) ? A.search_cap_fixer : 6
const CAP_JUDGE = Number.isInteger(A.search_cap_judge) ? A.search_cap_judge : 4
const ITEMS_DIR = typeof A.items_dir === 'string' && A.items_dir ? A.items_dir : 'docs/signoff/work/mopup'
const OVERRIDE = Array.isArray(A.families) ? A.families.filter((f) => typeof f === 'string').sort() : null
const STAGES = ['evidence', 'author', 'fixer', 'verifier', 'seal', 'check', 'closing']
// Re-run guard: a held family runs again from a named stage, one stage for all, or {family: stage}
const FROM = typeof A.from_stage === 'string' ? A.from_stage : A.from_stage && typeof A.from_stage === 'object' ? { ...A.from_stage } : null
if (FROM && !OVERRIDE) throw new Error('args.from_stage needs args.families: a re-run names the held families it runs')
for (const s of typeof FROM === 'string' ? [FROM] : FROM ? Object.values(FROM) : []) if (!STAGES.includes(s)) throw new Error(`args.from_stage: '${s}' is not one of ${STAGES.join(', ')}`)
const fromOf = (f) => (FROM === null ? null : typeof FROM === 'string' ? FROM : FROM[f] || null)
const runsStage = (f, stage) => { const s = fromOf(f); return !s || STAGES.indexOf(stage) >= STAGES.indexOf(s) }
// Mock mode (M-14 (5)): args.mock maps an agent label to the result that agent returns; no model is called.
const MOCK = A.mock && typeof A.mock === 'object' ? A.mock : null

// ─── models (ruling M-03): by full id; the verifier and the judge roles are never overridden ───

const STRONGEST = 'claude-fable-5-2'
const ROLE_MODELS = {
  runner: { model: 'claude-opus-5-5', effort: 'medium' }, // setup, guards, seal, check, final
  author: { model: 'claude-opus-5-5', effort: 'max' }, // the author of new rows
  fixer: { model: 'claude-opus-5-5', effort: 'max' }, // the fixer and the evidence pass
  verifier: { model: STRONGEST, effort: 'max' },
  judge: { model: STRONGEST, effort: 'max' }, // the closing lens and the J1 and J2 reading of new rows
}
const FULL_ID = /^claude-[a-z]+-\d+-\d+$/
for (const [r, v] of Object.entries(A.role_models || {})) {
  if (r === 'verifier' || r === 'judge') throw new Error(`args.role_models.${r}: the ${r} runs on ${STRONGEST} at maximum effort and is never overridden; no other model stands in for it (ruling M-03)`)
  if (!ROLE_MODELS[r]) throw new Error(`args.role_models: unknown role '${r}'`)
  if (!Array.isArray(v) || !FULL_ID.test(String(v[0])) || typeof v[1] !== 'string') throw new Error(`args.role_models.${r}: give [full model id, effort], for example ["claude-opus-5-5", "max"] (ruling M-03)`)
  ROLE_MODELS[r] = { model: v[0], effort: v[1] }
}
const FABLE_ROLES = new Set(['verifier', 'judge'])
const baseRole = (role) => String(role).replace(/-repair$/, '')
function modelFor(role) {
  const m = ROLE_MODELS[baseRole(role)]
  if (!m || !m.model || !m.effort) throw new Error(`no model and effort for role ${role}`)
  return m
}
const RESERVE = 2 // agents kept back for the final runner and its retry

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 76-84

const TOOL = 'docs/signoff/workflows/ws1-mopup-tools.cjs'
const ITEMS = (family) => `${ITEMS_DIR}/items/${family}.json`
const RUN_FILE = `${W}/checks/${BATCH}-mopup-run.json`
const STATE_FILE = `${W}/checks/${BATCH}-mopup-state.json`
const SCORECARD = `${W}/scorecard-${BATCH}.mopup.md`

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 94-102

// The ledger's own patterns (docs/signoff/tools/ledger.js ROW_KEY_RE and CHECK_ID_RE, copied): an observation that
// names another row key or check id is entered with none, so that ledger.js apply accepts it.
const ROW_KEY_RE = /^[a-z][a-z0-9_]*\|(both|male|female)\|(All Adults|\d{1,3}-\d{1,3}|\d{1,3}\+)\|(none|pregnancy|lactation|premenopausal|perimenopausal|postmenopausal|hormone_therapy|oral_contraception|follicular|ovulatory|luteal)$/
const CHECK_ID_RE = /^([DCEKMLPSBXNQG]\d{1,2}|definition:[a-z0-9_ -]+)$/
const defPart = (s) => String(s).toLowerCase().replace(/[^a-z0-9_ -]+/g, ' ').replace(/\s+/g, ' ').trim()

// ─── schemas ───

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 106-107

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 139-150

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 152-184

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 201-223

const OBJ = { type: 'object' }
const OBJ_LIST = { type: 'array', items: { type: 'object' } }
const COMPARISON = { type: 'array', description: 'the "comparison" or "rows" list the command printed, copied exactly', items: { type: 'object', required: ['row', 'fields'], properties: { row: { type: 'string' }, fields: STR_LIST } } }
const HASHES = { type: 'object', description: 'the "hashes" object the command printed, copied exactly' }

const SETUP_SCHEMA = {
  type: 'object',
  required: ['batch', 'round', 'start_commit', 'head', 'rerun', 'clean', 'dirty_paths', 'families', 'errors'],
  properties: {
    batch: { type: 'string' }, round: { type: 'integer' }, start_commit: { type: 'string' }, head: { type: 'string' },
    rerun: { type: 'boolean' }, clean: { type: 'boolean' }, dirty_paths: STR_LIST,
    families: {
      type: 'array',
      description: 'the "families" list the command printed, every field copied exactly',
      items: {
        type: 'object',
        required: ['family', 'items_present'],
        properties: {
          family: { type: 'string' }, title: { type: ['string', 'null'] }, keys: STR_LIST, items_present: { type: 'boolean' },
          stop: { type: 'string' }, items_commit: { type: 'string' }, in_round: { type: 'boolean' }, mopup_round: { type: 'integer' },
          valid: OBJ, validation_errors: STR_LIST, evidence_pass: { type: 'boolean' }, evidence_items: STR_LIST,
          author_rows: STR_LIST, author_items: STR_LIST, fixer_items: OBJ_LIST, fixer_parts: { type: 'array', items: STR_LIST }, fixer_notes: OBJ_LIST,
          verifier_rows: OBJ_LIST, verifier_records: OBJ_LIST, closing: OBJ_LIST, new_rows: STR_LIST,
          evidence_changed_before: STR_LIST, comparison: COMPARISON, hashes_now: HASHES, prior: { type: ['object', 'null'] },
        },
      },
    },
    previous_runs: OBJ_LIST,
    errors: STR_LIST,
    model: MODEL_PROP,
  },
}

const GUARD_SCHEMA = {
  type: 'object',
  required: ['family', 'stage', 'ok', 'problems', 'comparison', 'hashes'],
  properties: {
    family: { type: 'string' }, stage: { type: 'string' }, ok: { type: 'boolean' }, problems: STR_LIST,
    evidence_changed: STR_LIST, new_rows: STR_LIST, valid: OBJ, validation_errors: STR_LIST,
    comparison: COMPARISON, hashes: HASHES, model: MODEL_PROP,
  },
}

const SEAL_SCHEMA = {
  type: 'object',
  required: ['family', 'ok', 'copied', 'slips', 'problems', 'comparison', 'hashes'],
  properties: {
    family: { type: 'string' }, ok: { type: 'boolean' },
    copied: { type: 'array', items: { type: 'object', required: ['row_key', 'field'], properties: { row_key: { type: 'string' }, field: { type: 'string' }, correction_index: { type: 'integer' } } } },
    slips: { type: 'array', items: { type: 'object', required: ['row_key', 'field'], properties: { row_key: { type: 'string' }, field: { type: 'string' } } } },
    problems: STR_LIST, verify_sha256: { type: 'string' }, decision_valid: { type: ['boolean', 'null'] }, validation_errors: STR_LIST,
    verify_diff: OBJ, comparison: COMPARISON, hashes: HASHES, model: MODEL_PROP,
  },
}

const EXTRA = {
  type: 'object',
  description: 'the JSON object step 7 printed, copied exactly',
  required: ['family', 'ok', 'problems', 'comparison', 'hashes'],
  properties: { family: { type: 'string' }, ok: { type: 'boolean' }, problems: STR_LIST, comparison: COMPARISON, verify_diff: OBJ, locked: OBJ_LIST, state_rows: OBJ_LIST, hashes: HASHES },
}
const MOPUP_CHECK_SCHEMA = { ...CHECK_SCHEMA, required: [...CHECK_SCHEMA.required, 'extra'], properties: { ...CHECK_SCHEMA.properties, extra: EXTRA } }

const CLOSING_SCHEMA = {
  type: 'object',
  required: ['file', 'lens', 'answers', 'observations', 'searches_used'],
  properties: {
    file: { type: 'string' },
    lens: { type: 'string' },
    answers: {
      type: 'array',
      description: 'one entry per listed ledger id, as written in your output file',
      items: {
        type: 'object',
        required: ['ledger_id', 'answer', 'file', 'line', 'value'],
        properties: {
          ledger_id: { type: 'string' }, answer: { type: 'string', enum: ['raised_again', 'not_raised_again'] },
          file: { type: 'string', description: 'the file you read, repo-relative' }, line: { type: ['integer', 'string'], description: 'the line you read' },
          value: { type: 'string', description: 'the value or text you read there, verbatim' }, note: { type: 'string' },
        },
      },
    },
    observations: {
      type: 'array',
      description: 'anything else you saw that could mislead or harm a client, or would stop the physician signing',
      items: {
        type: 'object',
        required: ['family', 'row_key', 'check_id', 'summary', 'file', 'line'],
        properties: { family: { type: 'string' }, row_key: { type: ['string', 'null'] }, check_id: { type: 'string' }, summary: { type: 'string' }, file: { type: 'string' }, line: { type: ['integer', 'string'] } },
      },
    },
    searches_used: { type: 'integer', minimum: 0 },
    model: MODEL_PROP,
  },
}

const FINAL_SCHEMA = {
  type: 'object',
  required: ['ok', 'applied', 'finalized', 'ledgers_valid', 'scorecard_file', 'state_file', 'errors'],
  properties: {
    ok: { type: 'boolean', description: 'true when every command exited 0' },
    applied: { type: 'object', required: ['added', 'updated', 'errors'], properties: { added: STR_LIST, updated: STR_LIST, errors: STR_LIST }, description: 'from the ledger.js apply output, copied exactly (empty lists when step 1 was skipped)' },
    finalized: { type: 'array', items: { type: 'object', required: ['family', 'converted'], properties: { family: { type: 'string' }, converted: { type: 'integer' } } } },
    ledgers_valid: { type: 'boolean' },
    scorecard_file: { type: 'string' },
    state_file: { type: 'string' },
    errors: STR_LIST,
    model: MODEL_PROP,
  },
}

// ─── prompts (LOOP-PROMPT.md section 2 where a role prompt exists; the mop-up notes of plan.md 4.2 and the rulings) ───

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 286-306

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 308-327

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 329-340

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 342-344

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 460-484

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 486-502

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 504-535

let START = null // the session's start commit (stage 0); the files at it are the copy of every family's files at stage 0
const bash = (lines) => ['```bash', ...lines, '```'].join('\n')
const quote = (s) => `'${String(s).replace(/'/g, `'"'"'`)}'`
const retryNote = (half) => (half ? '\n\nThis is a retry: a previous runner returned nothing. Run the same commands.' : '')
const copyJson = 'Run this block from the repository root and reply with the JSON object its last command printed, copied exactly, as the structured result. Do not edit any file by hand, do not fix anything, do not commit.'

function setupPrompt(half) {
  const extra = [OVERRIDE ? `--families ${OVERRIDE.join(',')}` : '', FROM ? `--from-stage ${quote(typeof FROM === 'string' ? FROM : JSON.stringify(FROM))}` : ''].filter(Boolean).join(' ')
  return [
    `You are the mechanical runner of EVA's mop-up round, batch ${BATCH}, round ${ROUND}: stage 0. Read-only.`,
    copyJson,
    '',
    bash([`node ${TOOL} setup --batch ${BATCH} --round ${ROUND} --items-dir ${ITEMS_DIR}${extra ? ` ${extra}` : ''}`]),
  ].join('\n') + retryNote(half)
}

function guardPrompt(f, stage, half) {
  const h = fam[f.family].hashes || {}
  const rows = stage === 'author' ? ` --author-rows ${quote(JSON.stringify(f.author_rows || []))}` : stage === 'fixer' ? ` --expect-verify ${h[`${W}/verify/${f.family}.json`] || 'null'} --expect-research ${h[`${W}/research/${f.family}.json`] || 'null'}` : ''
  return [
    `You are the mechanical runner of EVA's mop-up round, batch ${BATCH}, family ${f.family}: the guard after the ${stage} stage.`,
    copyJson,
    '',
    bash([`node ${TOOL} guard --family ${f.family} --stage ${stage} --since ${START}${rows}`]),
  ].join('\n') + retryNote(half)
}

/** Stage 1: the evidence-repair prompt of ws1-batch.js, unchanged, with the mop-up's items and rulings after it. */
function evidencePrompt(f, half) {
  return [
    evidenceRepairPrompt(f, ROUND, []),
    '',
    `Mop-up round ${ROUND} (DR-2026-11-11-01; rulings M-01 and M-13). Your items are those of \`${ITEMS(f.family)}\` whose stage is "evidence pass": ${(f.evidence_items || []).join(', ') || 'none listed'}. Read each item's "what" and "links" there.`,
    '- Step 3 above stands. The items may also ask you to add a missing supports[] link or split record, to remove a supports[] link the item lists (to a row the decision no longer holds, or a bound that is now none), or to point an unopenable identifier to the PubMed or Europe PMC record of the same paper. Do only what an item asks.',
    '- You never change a grade or a verdict, up or down. In the verify file you may change only quote_found and note of an evidence_verdicts entry, and the quotes, identifiers, notes and supports links of records. Every record you change is graded by the verifier in this session. A guard compares both files with their version at the session\'s start after you.',
    '- Do not edit the cache files under docs/signoff/work/sources-cache/ by hand; quote-check.js fills them, and the session does not commit them (M-13).',
  ].join('\n') + (half ? halfNote('Repair the items in id order, as many as you can; leave the rest as they are.') : '')
}

/** Stage 2: the author of new rows (role prompt 2.1, limited to the new row keys of the items file). */
function authorRowsPrompt(f, half) {
  const cap = half ? Math.floor(CAP_AUTHOR / 2) : CAP_AUTHOR
  return [
    shared(cap),
    '',
    literature(cap),
    '',
    `Role: a physician specialised in preventive and longevity medicine, auditing EVA's rows for the family \`${f.family}\` (biomarker keys \`${(f.keys || []).join(', ')}\`).`,
    '',
    `Input: the brief \`${W}/briefs/${f.family}.json\` (read its reading_guide first) and \`${ITEMS(f.family)}\`, whose author items say why each new row is needed: ${(f.author_items || []).join(', ')}.`,
    briefRule(f),
    '',
    `Task (mop-up round ${ROUND}, plan.md 4.2 stage 2): add to \`${W}/research/${f.family}.json\` only these new rows: ${(f.author_rows || []).join('; ') || 'the rows the author items describe'}.`,
    'Change no existing row, record or field of the file. For each new row decide and record, as for every row of role prompt 2.1: the class, the reference basis and bounds, the optimal band and its band rule (from outcome evidence only), the critical and action limits or "none, because", the pre-analytical rules, the reference change value inputs, and the messages in Spanish and English for reachable zones only, following `docs/signoff/work/governance/wording-rules.md`.',
    'For every bound of a new row, give one evidence record as in PLAN.md section 5, with a verbatim quote that contains the number. Propose a grade; the verifier decides it.',
    '',
    NOTES_RULE,
    '',
    `Output: \`${W}/research/${f.family}.json\`, valid against \`${T}/schema/research.schema.json\`. Check it with \`node ${T}/validate.js research ${f.family}\` and fix every error. A guard checks after you that no existing row changed and that the new rows are exactly the listed ones.`,
    '',
    'Reply with the structured result: file, valid (from the validator\'s last run), errors (its error lines), searches_used, files_written.',
  ].join('\n') + (half ? halfNote(`Use at most ${cap} searches. Write the bounds and their evidence first, then the messages.`) : '')
}

/** Stage 3: one part of the fixer list (role prompt 2.5, with the mop-up notes of plan.md 4.2 and the rulings). */
function fixerPartPrompt(f, part, i, n, half) {
  const cap = half ? Math.floor(CAP_FIXER / 2) : CAP_FIXER
  return [
    shared(cap),
    '',
    literature(cap),
    '',
    `Role: a physician fixing the family \`${f.family}\`. The definitions and the evidence standard decide what the right fix is; the items do not. A fix that only satisfies a check without meeting the definitions is wrong.`,
    '',
    'Every loosening needs a grade A or B quote: a wider optimal band, a removed bound, or a bound moved toward the reference limit. Record each change with its reason and source.',
    '',
    NOTES_RULE,
    '',
    `Output: \`${W}/decisions/${f.family}.json\`, the only file you may write, valid against \`decision.schema.json\`.`,
    '',
    `Input for the rows: the brief \`${W}/briefs/${f.family}.json\` (read its reading_guide first), with the files named below.`,
    briefRule(f),
    '',
    `Mop-up notes (round ${ROUND}, DR-2026-11-11-01). This is part ${i + 1} of ${n} of the family's fixer list; the parts run one after another on the same file.`,
    `- Read \`${ITEMS(f.family)}\`. Fix the items of this part: ${part.join(', ')}. Leave every other item as it is: other parts, the evidence pass, the verifier or central own them.`,
    '- Move no bound unless an item says so. A loosening still needs a grade A or B quote. Move no bound to change a coherence result (M-09).',
    '- Give every field you change on a row its own change record, with reason and source. A fresh verdict never stands in for a change record on a bound, a unit or an added or removed row (M-01 (4); CEO-4, CEO-6, CEO-11).',
    '- Write texts to the rule the physician signs (state-rules.md, wording-rules.md, critical-limits.json, action-limits.json), never to the app\'s code. A critical field needs a table entry; write critical texts to the table\'s class and comparison, and a text that states a critical comparison says "or higher" or "or lower" (D-17; M-07, M-08).',
    '- Do not change reference_low on a locked row (apoB, LDL-C, non-HDL-C, HOMA-IR) unless the item says the E6 baseline change is approved (M-04). Do not delete messages or rows of pregnancy and lactation rows (M-05).',
    ...(f.fixer_notes || []).map((n) => `- Ruling ${n.ruling}: ${n.text}.`),
    '- Do not write the research or verify file, and set no grade: the verifier grades every row you change, in this session.',
    `- Central issues: read \`${KNOWN}\`. Items listed there are fixed outside the family; do not try to satisfy them in your file, except where the list says the family supplies something.`,
    `- Start from \`${W}/decisions/${f.family}.json\`. Set round to ${ROUND} and decided_at to ${TODAY}; leave verify_sha256 as it is (the seal sets it after the verifier). List in issues_addressed the ledger id of each item that has one, and name the other item ids in notes.`,
    `- Validate with \`node ${T}/validate.js decision ${f.family}\` and fix every error.`,
    '',
    'Reply with the structured result: file, valid (from the validator\'s last run), errors (its error lines), searches_used, files_written.',
  ].join('\n') + (half ? halfNote(`Use at most ${cap} searches. Fix only the first half of this part's items in id order; the rest stay open.`) : '')
}

const OPT_FIELDS = ['optimal_low', 'optimal_high', 'grade']
const REF_FIELDS = ['reference_low', 'reference_high', 'critical_low', 'critical_high', 'band_rule', 'unit', 'marker_class', 'reference_basis']
/** The depth of M-01 (2) for a row the comparison lists: from the items file, else from the fields that differ. */
function depthOf(f, row, fields) {
  const fromItems = (f.verifier_rows || []).find((r) => r.row_key === row)
  if (fromItems && fromItems.depth) return fromItems.depth
  if (fields.includes('no verifier row')) return 'new_row'
  if (fields.includes('no decided row')) return 'dropped_row'
  if (fields.some((x) => OPT_FIELDS.includes(x))) return 'bounds_or_grade'
  if (fields.some((x) => REF_FIELDS.includes(x))) return 'reference'
  return 'texts_only'
}

/** Stage 4: the verifier's second verdict on the decided rows as compiled (role prompt 2.2; M-01, M-13, WS3-09-F4). */
function verifierPrompt(f, list, records, half) {
  const cap = half ? Math.floor(CAP_VERIFIER / 2) : CAP_VERIFIER
  return [
    shared(cap),
    '',
    literature(cap),
    '',
    'Role: an independent physician-verifier. You did not write the file you check.',
    '',
    `Input: the decided rows as compiled, \`${W}/decisions/${f.family}.json\` final_rows; your file \`${W}/verify/${f.family}.json\`; \`${W}/research/${f.family}.json\`; the brief \`${W}/briefs/${f.family}.json\` (read its reading_guide first).`,
    briefRule(f),
    '',
    'Try to refute every claim:',
    '- Open each load-bearing source and confirm that the quote is in it, word for word.',
    '- Confirm that the number, unit and population fit the row.',
    '- Re-derive the band rule, and assign the grade yourself.',
    '- Check the class, the basis, the splits, the limits and the messages against PLAN.md and the wording rules.',
    '',
    `Mop-up round ${ROUND} (DR-2026-11-11-01): a second verdict, on the decided rows as compiled. Run the comparison first: \`node ${TOOL} compare --family ${f.family}\`. It lists each decided row that differs from your file's row, with the fields, and your rows the decision no longer holds. Your list, with the depth of each row (M-01 (2)):`,
    ...list.map((x) => `- \`${x.row}\` (${x.depth}): ${x.fields.join(', ')}${x.own ? `; the only evidence record of ${x.own} is the fixer's` : ''}`),
    ...(records.length ? ['Evidence records on your list (M-01 (5)); for the catalogue records the cache now lets the quote check open the source (M-13):', ...records.map((r) => `- \`${r.id}\` (${r.file || 'research'} file): ${recordTask(r)}${r.why ? ` Why it is listed: ${r.why}` : ''}`)] : ['No evidence record is on your list beyond the records of these rows.']),
    '',
    '- Read each listed row whole, in English and in Spanish, as the decision holds it. Open the sources yourself and assign the grade yourself (M-01 (1)).',
    '- bounds_or_grade, reference and challenged_grade: open every source of each changed bound and grade the bound as compiled. texts_only: check each changed text against wording-rules.md, state-rules.md, critical-limits.json and the row\'s own numbers, and confirm that bounds, unit and grade are those of your file (M-01 (2)).',
    '- Where an optimal bound\'s only evidence record is the fixer\'s, write your own record in your file under a new id, from a source you opened, or correct the row by removing the bound (M-01 (3)). Without one the validator rejects the row.',
    `- If you accept a row as compiled, copy it with the command, never by retyping it (execution decision): \`node ${TOOL} accept --family ${f.family} --row '<row key>' --grade <A|B|C|D> <<'NOTE'\` followed by your verdict note and a line \`NOTE\`. It copies the decided row into your final_rows with your grade and writes the row verdict ("confirmed" only when the bounds equal the research row, else "corrected": the verdict of ${TODAY} on the decided row).`,
    '- If you do not accept it, write your corrected row in final_rows and one corrections[] entry for every field where your row differs from the decided row, the grade included, each with its reason and evidence ids; set the row verdict yourself. The seal copies exactly those fields into the decision with a change record that cites your correction, and stops the family on any other difference.',
    `- A row with "no decided row" (WS3-09-F4): if the drop is right under state rule 2.1 (D-12, M-05), confirm it with \`accept --drop\` (the research row is then refuted); if not, keep it and raise a physician question. A row with "no verifier row" (a new row): give it a full verdict, as role prompt 2.2 asks for every row.`,
    '- Touch no other row and no other row verdict, and no evidence verdict but those of the records above, of records the evidence pass changed and of records you add. A guard compares your file with its version at the session\'s start (M-01 (5)). A fresh verdict never stands in for a change record on a bound, a unit or an added or removed row (M-01 (4)).',
    '',
    NOTES_RULE,
    '',
    `Output: \`${W}/verify/${f.family}.json\`, valid against \`verify.schema.json\`. Check it with \`node ${T}/validate.js verify ${f.family}\`.`,
    '',
    'Reply with the structured result: file, valid (from the validator\'s last run), errors (its error lines), searches_used, files_written.',
  ].join('\n') + (half ? halfNote(`Use at most ${cap} searches. Give your verdict on the rows in the order listed; leave the rest for the orchestrator.`) : '')
}

const recId = (r) => (typeof r === 'string' ? r : r.id)
/** What the verifier may do with a listed record: the frozen validator accepts evidence_verdicts only for research records. */
function recordTask(r) {
  if (r.file === 'verify') return 'your own record. Re-open its source and check its quote and its supports links; correct it in place if they are wrong. Write no evidence_verdicts entry for it: the validator accepts verdicts only for research records, so its published grade stays with the central VERDICT item.'
  if (r.file === 'decision') return 'the fixer\'s record (decision file). Re-open its source and check its quote; where a bound of a row in your file rests on it alone, write your own record from the source you opened, under a new id. Write no evidence_verdicts entry for it (the validator accepts verdicts only for research records) and change nothing in the decision file.'
  if (r.file === 'research or verify') return 'changed by the evidence pass: re-read it; a research record keeps an evidence verdict, which you set again (the evidence pass changes no grade, M-13).'
  return 'a verdict and a grade you set yourself.'
}

function allowedOf(st) {
  return { rows: [...new Set(st.allowed_rows)].sort(), records: [...new Set(st.allowed_records)].sort() }
}

function sealPrompt(f, half) {
  return [
    `You are the mechanical runner of EVA's mop-up round, batch ${BATCH}, family ${f.family}: the seal (stage 5).`,
    copyJson,
    '',
    bash([`node ${TOOL} seal --family ${f.family} --round ${ROUND} --date ${TODAY} --since ${START} --allowed ${quote(JSON.stringify(allowedOf(fam[f.family])))}`]),
  ].join('\n') + retryNote(half)
}

/** Stage 6: the check prompt of ws1-batch.js, unchanged, and the mop-up checks after it. */
function mopupCheckPrompt(f, half) {
  return [
    checkPrompt(f, ROUND, half),
    '',
    `7. The mop-up checks (rulings M-01, M-04 and M-05), whatever steps 1 to 6 gave: \`node ${TOOL} check-extra --family ${f.family} --since ${START} --allowed ${quote(JSON.stringify(allowedOf(fam[f.family])))}\`. Copy the JSON object it printed, exactly, as extra.`,
  ].join('\n')
}

/** Stage 7: the closing pass (ruling M-11): the lens that raised each item re-reads only its listed items. */
function closingPrompt(lens, jobs, half) {
  const families = jobs.map((j) => j.family)
  const out = `${W}/judges/mopup/${lens}-${BATCH}.${families.join('.')}.closing.json`
  return [
    shared(CAP_JUDGE),
    '',
    `Role: \`the lens ${lens} of ${W}/judges/lenses.json: read lenses.${lens}.role_text and adopt it, under its shared_rules (verdict label, blocking criteria B1-B7, what a judge never does)\`.`,
    '',
    `This is the closing pass of the mop-up round ${ROUND} (ruling M-11), not a judge round. You re-read only the ledger items listed below, which your lens raised in an earlier round; you see your own earlier issue. For each one you say whether you raise it again on the files as they are now.`,
    '',
    'Your items, by family (read each in the family\'s ledger file, only these ids: summary, check_id, row_key, side and source.judge_file, and the judge file that raised it):',
    ...jobs.map((j) => `- ${j.family}: ${j.ids.join(', ')}`),
    '',
    'Where the material is:',
    ...families.map((fam2) => `- ${fam2}: the compiled copy \`${W}/compiled/${BATCH}-r${ROUND}/${fam2}/\` (biomarker-ranges-en.json, rangos-biomarcadores-es.json, biomarker-sources.json, CHANGES.md), the check results \`${W}/checks/${fam2}-r${ROUND}.json\`, the ledger \`${W}/ledger/${fam2}.json\`;`),
    `- do not open \`${W}/research/\`, \`${W}/verify/\` or \`${W}/refutations/\`, and no judge file but those that raised your items; in \`${W}/decisions/<family>.json\` do not read the notes fields, issues_addressed or the reasons of changes[] (M-11 (1)).`,
    '',
    'For each listed item answer "raised_again" or "not_raised_again", with the file, the line and the value or text you read there. An answer without that evidence leaves the item open (M-11 (2)). Answer only for the listed ids.',
    'Do not look for new issues on old content. But anything you see that could mislead or harm a client, or would stop the physician signing, goes in observations, with the family, the row key (or null), a check id (for example "M3", or "definition:<name>"), what you saw, the file and the line. It enters the ledger as "unreviewed" and the orchestrator reads it (M-11 (4)).',
    '',
    `Output: \`${out}\`, a JSON file {"schema_version": "mopup-closing-1", "lens": "${lens}", "batch": "${BATCH}", "round": ${ROUND}, "families": [...], "answers": [...], "observations": [...]}. Reply with the structured result: file, lens, the same answers and observations, searches_used.`,
  ].join('\n') + (half ? halfNote('Answer the listed items in the order given; write the file after each answer.') : '')
}

/** M-11 (5): J1 and J2 read each new row in full under the frozen judge prompt (LOOP-PROMPT.md 2.3). */
function newRowPrompt(lens, f, half) {
  const shard = `${BATCH}.${f.family}.newrows`
  const out = `${W}/judges/mopup/${lens}-${shard}.json`
  return [
    shared(CAP_JUDGE),
    '',
    `Role: \`the lens ${lens} of ${W}/judges/lenses.json: read lenses.${lens}.role_text and adopt it, under its shared_rules (verdict label, blocking criteria B1-B7, what a judge never does)\`. You are reviewing this material for the physician before he sees it. Your job is to find`,
    'what would stop him signing. Assume nothing is right until you have checked it.',
    '',
    `Input: the new rows of \`${f.family}\` that the mop-up round added (ruling M-11 (5)): ${(f.new_rows || []).join('; ')}. Read each in full in the compiled copy \`${W}/compiled/${BATCH}-r${ROUND}/${f.family}/\` (biomarker-ranges-en.json, rangos-biomarcadores-es.json, biomarker-sources.json, CHANGES.md), in \`${W}/decisions/${f.family}.json\`, and the check results \`${W}/checks/${f.family}-r${ROUND}.json\`. You do not see the authors' reasoning or earlier verdicts; do not open \`${W}/research/\`, \`${W}/verify/\`, \`${W}/ledger/\` or \`${W}/refutations/\`.`,
    '',
    'Report blocking issues only where the physician could not sign as written. For each one, give the family, the row, the check id or definition it breaks, the exact value disputed, the evidence (a file and line, or a source with a quote) and what would resolve it. Minor issues go in a separate list. Raise issues on the new rows only.',
    '',
    `Output: \`${out}\`, valid against \`judge.schema.json\`: schema_version "1", round ${ROUND}, lens "${lens}", shard "${shard}", families_reviewed ["${f.family}"], sample_file null. Give every issue a side ("low", "high", "both") when it concerns one bound, else null.`,
    `Then run \`node ${T}/validate.js judge ${out}\` and fix every error, and run \`node ${T}/ledger.js extract ${out}\`. Your issues enter the ledger as "unreviewed": no refuter runs in this round.`,
    'Reply with the structured result: file, valid, errors, lens, families_reviewed, and the blocking and minor arrays the extract command printed, copied exactly.',
  ].join('\n') + (half ? halfNote('Read the first new row first and write the file after each row.') : '')
}

function finalPrompt(payload, run, state, section, finalize, half) {
  const hasPayload = payload.issues.length + payload.updates.length > 0
  return [
    `You are the mechanical runner that closes EVA's mop-up round for batch ${BATCH} (stage 8). Do not edit files by hand, do not judge anything, do not commit.`,
    'Run this block from the repository root, command by command, and note each exit status and output:',
    '',
    bash([
      ...(hasPayload ? ['p=$(mktemp)', 'cat > "$p" <<\'MOPUP_LEDGER_PAYLOAD\'', JSON.stringify(payload), 'MOPUP_LEDGER_PAYLOAD', `node ${T}/ledger.js apply --payload "$p"`] : ['# no ledger payload in this run']),
      ...finalize.map((s) => `node ${T}/ledger.js finalize --family ${s.family} --round ${ROUND} --reason "${s.reason}"`),
      ...finalize.map((s) => `node ${T}/validate.js ledger ${s.family}`),
      `cat > ${RUN_FILE} <<'MOPUP_RUN_SUMMARY'`, JSON.stringify(run), 'MOPUP_RUN_SUMMARY',
      's=$(mktemp)', 'cat > "$s" <<\'MOPUP_STATE\'', JSON.stringify(state), 'MOPUP_STATE',
      `node ${TOOL} state-merge --file ${STATE_FILE} --payload "$s"`,
      `node ${T}/scorecard.js --batch ${BATCH} --run ${RUN_FILE} --out ${SCORECARD}`,
      `cat >> ${SCORECARD} <<'MOPUP_SECTION'`, section, 'MOPUP_SECTION',
    ]),
    '',
    `Reply with the structured result: ok (every command exited 0); applied: added, updated and errors from the apply output (empty lists when there was no payload); finalized: one entry per family with the number of ids in "converted" from the finalize output; ledgers_valid (every validate line said VALID); scorecard_file (${SCORECARD}); state_file (${STATE_FILE}); errors: any failing command or INVALID line.`,
  ].join('\n') + retryNote(half)
}

// ─── agent accounting ───

const runLog = { agents: [], nulls: 0, retries: 0, capped: false, left: [], halted: false, consecutive_nulls: 0, fable_halted: false }
// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 699-702

/**
 * As ws1-batch.js's call(), with three changes: the per-model halt (once the strongest model has returned nothing
 * twice on one task, no later agent on it runs: {__halted}); the model check of M-03 (a verifier or judge result
 * that reports another model counts as a null; "unknown" is marked for confirmation before the family is
 * committed); and the mock mode (args.mock), in which no model is called.
 */
async function call(prompt, opts, info) {
  const limit = info.final ? AGENT_CAP : AGENT_CAP - RESERVE
  if (runLog.halted) return { __capped: true }
  const role = baseRole(info.role)
  if (FABLE_ROLES.has(role) && runLog.fable_halted) return { __halted: true }
  if (runLog.agents.length >= limit) {
    runLog.capped = true
    return { __capped: true }
  }
  const { model, effort } = modelFor(info.role)
  const entry = { label: opts.label, role: info.role, family: info.family || null, round: ROUND, retry: !!info.retry, ok: false, model_requested: model, effort_requested: effort, model_reported: null }
  runLog.agents.push(entry)
  if (info.retry) runLog.retries++
  let res = MOCK
    ? (Object.prototype.hasOwnProperty.call(MOCK, opts.label) && MOCK[opts.label] !== null ? JSON.parse(JSON.stringify(MOCK[opts.label])) : null)
    : await agent(prompt, { label: opts.label, phase: opts.phase, schema: opts.schema, model, effort })
  if (res !== null && res !== undefined) {
    entry.model_reported = typeof res.model === 'string' ? res.model : null
    if (FABLE_ROLES.has(role) && entry.model_reported && entry.model_reported !== 'unknown' && entry.model_reported !== STRONGEST) {
      entry.model_mismatch = true
      log(`${opts.label}: the agent reports ${entry.model_reported}, not ${STRONGEST}: not a verdict, counted as a null (M-03)`)
      res = null
    } else if (FABLE_ROLES.has(role) && entry.model_reported !== STRONGEST) entry.confirm_model = true
  }
  if (res === null || res === undefined) {
    runLog.nulls++
    runLog.consecutive_nulls++
    if (runLog.consecutive_nulls >= HALT_AFTER_NULLS) {
      runLog.halted = true
      runLog.capped = true
      log(`halted: ${runLog.consecutive_nulls} agents in a row returned nothing (systemic failure, such as the usage limit); resume this run with resumeFromRunId`)
      return { __capped: true }
    }
    return null
  }
  runLog.consecutive_nulls = 0
  entry.ok = true
  return res
}

// copied unchanged from docs/signoff/workflows/ws1-batch.js
//@@COPY 733-740
const halted = (r) => !!(r && r.__halted)

// ─── state ───

const fam = {} // family -> state
const pending = { issues: [], updates: [] } // ledger items for the final runner
const observations = [] // closing-lens observations and new-row issues, for the scorecard
const closingLog = [] // {family, lens, id, answer, applied}
const sealLog = [] // {family, copied, slips}

function hold(f, stage, reason) {
  const st = fam[f]
  if (st.status !== 'active') return
  st.status = 'held'
  st.held = true
  st.held_stage = stage
  st.stop_reason = reason
  log(`${f}: held at the ${stage} stage: ${reason}`)
}
function done(f, stage, hashes) {
  const st = fam[f]
  st.last_stage = stage
  if (hashes && typeof hashes === 'object') st.hashes = { ...hashes }
}
function unreviewed(f, part, summary) {
  const st = fam[f]
  st.unreviewed.push(part)
  pending.issues.push({ family: f, check_id: `definition:unreviewed ${defPart(part)}`, row_key: null, side: null, lens: 'orchestrator', judge_file: '(none)', round: ROUND, severity: 'blocking', status: 'unreviewed', summary })
}
/** The per-model halt (execution decision): the families wait, and no later agent on the strongest model runs. */
function strongestStopped(families, stage, label) {
  if (!runLog.fable_halted) log(`${label}: ${STRONGEST} returned nothing twice; the remaining stages on it are halted for this session (no substitute, no partial commit); resume after the reset (docs/signoff/work/mopup/README.md)`)
  runLog.fable_halted = true
  for (const f of families) hold(f, stage, `${STRONGEST} returned nothing twice or is halted at the ${stage} stage (${label}): no seal, no finalize and no commit of the family`)
}

// ─── stage 0 ───

phase('Setup')
const setup = await withRetry(setupPrompt, { label: `setup ${BATCH}`, phase: 'Setup', schema: SETUP_SCHEMA }, { role: 'runner' })
if (!setup || capped(setup)) {
  log(`setup for ${BATCH} returned nothing twice; nothing was run`)
  return { batch: BATCH, error: 'setup failed', agents_run: runLog.agents.length }
}
if ((setup.errors || []).length) {
  log(`stage 0: ${setup.errors.join('; ')}`)
  return { batch: BATCH, error: 'stage 0 errors', errors: setup.errors, agents_run: runLog.agents.length }
}
if (!setup.rerun && !setup.clean) {
  log(`stage 0: the checkout is not clean (${(setup.dirty_paths || []).slice(0, 5).join(', ')}); a fresh mop-up session starts from a clean checkout`)
  return { batch: BATCH, error: 'checkout not clean', dirty_paths: setup.dirty_paths, agents_run: runLog.agents.length }
}
START = setup.start_commit
const FAMILIES = [...setup.families].sort((a, b) => (a.family < b.family ? -1 : 1))
if (!FAMILIES.length) return { batch: BATCH, error: 'no families for this batch', agents_run: runLog.agents.length }
for (const f of FAMILIES) {
  const st = { status: 'active', stop_reason: null, held: false, held_stage: null, last_stage: null, hashes: { ...(f.hashes_now || {}) }, comparison: [...(f.comparison || [])], evidence_changed: [...(f.evidence_changed_before || [])], allowed_rows: [], allowed_records: [], verified: false, searches: { author: 0, verifier: 0, fixer: 0, judges: 0 }, unreviewed: [], failing: null, failingFamily: null, end: null, seal: null }
  fam[f.family] = st
  if (f.stop) { st.status = 'stopped'; st.stop_reason = `stage 0: ${f.stop}`; log(`${f.family}: stopped at stage 0: ${f.stop}`); continue }
  if (!f.in_round) { st.status = 'not in round'; st.stop_reason = 'the items file has no item for the round'; continue }
  if (fromOf(f.family)) {
    const last = f.prior ? f.prior.last_finished_stage : null
    if (last) st.last_stage = last
    // the check counts of the earlier run, when this re-run starts after the check stage
    if (f.prior && !runsStage(f.family, 'check')) { st.failing = f.prior.failing ?? null; st.failingFamily = f.prior.failing_family ?? null }
    log(`${f.family}: re-run from the ${fromOf(f.family)} stage; files compared with ${f.compared_with || 'the hashes after the last finished stage'}`)
  }
}
const ACTIVE = FAMILIES.filter((f) => fam[f.family].status === 'active')
log(`${BATCH}: mop-up round ${ROUND}; ${ACTIVE.length} of ${FAMILIES.length} families in the pass (${ACTIVE.map((f) => f.family).join(', ') || 'none'}); start commit ${START}; agent cap ${AGENT_CAP}`)

// ─── stages 1 to 6, per family, as a pipeline ───

async function stageEvidence(f) {
  const st = fam[f.family]
  if (!runsStage(f.family, 'evidence') || !f.evidence_pass) return true
  const r = await withRetry((half) => evidencePrompt(f, half), { label: `evidence ${f.family} r${ROUND}`, phase: 'Evidence', schema: FILE_SCHEMA }, { role: 'fixer', family: f.family })
  if (capped(r)) { runLog.left.push(`${f.family}: evidence pass (agent cap)`); hold(f.family, 'evidence', 'agent cap'); return false }
  if (!r) unreviewed(f.family, 'evidence pass', `the evidence pass returned nothing twice in round ${ROUND}; its items stay open`)
  else st.searches.fixer += r.searches_used || 0
  const g = await withRetry((half) => guardPrompt(f, 'evidence', half), { label: `guard-evidence ${f.family} r${ROUND}`, phase: 'Evidence', schema: GUARD_SCHEMA }, { role: 'runner', family: f.family })
  if (!g || capped(g)) { hold(f.family, 'evidence', 'the guard after the evidence pass did not run'); return false }
  st.evidence_changed = [...new Set([...st.evidence_changed, ...(g.evidence_changed || [])])].sort()
  st.comparison = g.comparison || []
  if (!g.ok) { hold(f.family, 'evidence', `guard: ${(g.problems || []).join('; ')}`); return false }
  done(f.family, 'evidence', g.hashes)
  return true
}

async function stageAuthor(f) {
  const st = fam[f.family]
  if (!runsStage(f.family, 'author') || !(f.author_rows || []).length) return true
  const file = `${W}/research/${f.family}.json`
  const r = await withRetry((half) => authorRowsPrompt(f, half), { label: `author ${f.family} r${ROUND}`, phase: 'Author', schema: FILE_SCHEMA }, { role: 'author', family: f.family })
  if (capped(r)) { runLog.left.push(`${f.family}: author (agent cap)`); hold(f.family, 'author', 'agent cap'); return false }
  if (!r) { unreviewed(f.family, 'author', `the author returned nothing twice in round ${ROUND}; the new rows ${(f.author_rows || []).join(', ')} are not written`); return true }
  st.searches.author += r.searches_used || 0
  if (!r.valid) {
    const fix = await call(repairPrompt('research', f, file, r.errors || [], CAP_AUTHOR), { label: `author-repair ${f.family} r${ROUND}`, phase: 'Author', schema: FILE_SCHEMA }, { role: 'author-repair', family: f.family })
    if (capped(fix)) { runLog.left.push(`${f.family}: author repair (agent cap)`); hold(f.family, 'author', 'agent cap'); return false }
    if (!fix || !fix.valid) { hold(f.family, 'author', `${file} invalid after one repair pass`); return false }
  }
  const g = await withRetry((half) => guardPrompt(f, 'author', half), { label: `guard-author ${f.family} r${ROUND}`, phase: 'Author', schema: GUARD_SCHEMA }, { role: 'runner', family: f.family })
  if (!g || capped(g)) { hold(f.family, 'author', 'the guard after the author did not run'); return false }
  st.comparison = g.comparison || []
  if (!g.ok) { hold(f.family, 'author', `guard: ${(g.problems || []).join('; ')}`); return false }
  done(f.family, 'author', g.hashes)
  return true
}

const PART_MAX = 12
/** M-10 (7): the fixer list in parts of at most 12 items, by row (a row's items stay in one part where they fit). */
function splitParts(list) {
  const groups = []
  const byRow = new Map()
  for (const it of list || []) {
    const g = it.row_key ? `row:${it.row_key}` : `item:${it.id}`
    if (!byRow.has(g)) { byRow.set(g, []); groups.push(byRow.get(g)) }
    byRow.get(g).push(it)
  }
  const parts = []
  let cur = []
  for (const g of groups) {
    if (cur.length && cur.length + g.length > PART_MAX) { parts.push(cur); cur = [] }
    if (g.length > PART_MAX) { for (let i = 0; i < g.length; i += PART_MAX) parts.push(g.slice(i, i + PART_MAX)); continue }
    cur.push(...g)
  }
  if (cur.length) parts.push(cur)
  return parts.map((p) => p.map((it) => it.id))
}

async function stageFixer(f) {
  const st = fam[f.family]
  if (!runsStage(f.family, 'fixer') || !(f.fixer_items || []).length) return true
  const parts = splitParts(f.fixer_items)
  if (JSON.stringify(parts) !== JSON.stringify(f.fixer_parts || parts)) log(`${f.family}: the split differs from the items file's fixer_parts; the script's split is used`)
  const file = `${W}/decisions/${f.family}.json`
  for (let i = 0; i < parts.length; i++) {
    const label = `fixer ${f.family} part ${i + 1}/${parts.length} r${ROUND}`
    const r = await withRetry((half) => fixerPartPrompt(f, parts[i], i, parts.length, half), { label, phase: 'Fix', schema: FILE_SCHEMA }, { role: 'fixer', family: f.family })
    if (capped(r)) { runLog.left.push(`${f.family}: fixer part ${i + 1} and after (agent cap)`); hold(f.family, 'fixer', 'agent cap'); return false }
    if (!r) { unreviewed(f.family, `fixer part ${i + 1}`, `fixer part ${i + 1} of ${parts.length} returned nothing twice in round ${ROUND}; its items stay open: ${parts[i].join(', ')}`); continue }
    st.searches.fixer += r.searches_used || 0
    if (r.valid) continue
    const fix = await call(repairPrompt('decision', f, file, r.errors || [], CAP_FIXER), { label: `fixer-repair ${f.family} part ${i + 1} r${ROUND}`, phase: 'Fix', schema: FILE_SCHEMA }, { role: 'fixer-repair', family: f.family })
    if (capped(fix)) { runLog.left.push(`${f.family}: fixer repair (agent cap)`); hold(f.family, 'fixer', 'agent cap'); return false }
    if (fix) st.searches.fixer += fix.searches_used || 0
    if (!fix || !fix.valid) { hold(f.family, 'fixer', `${file} invalid after one repair pass (part ${i + 1}); it must not be compiled until fixed`); return false }
  }
  const g = await withRetry((half) => guardPrompt(f, 'fixer', half), { label: `guard-fixer ${f.family} r${ROUND}`, phase: 'Fix', schema: GUARD_SCHEMA }, { role: 'runner', family: f.family })
  if (!g || capped(g)) { hold(f.family, 'fixer', 'the guard after the fixer did not run'); return false }
  st.comparison = g.comparison || []
  if (!g.ok) { hold(f.family, 'fixer', `guard: ${(g.problems || []).join('; ')}`); return false }
  done(f.family, 'fixer', g.hashes)
  return true
}

async function stageVerifier(f) {
  const st = fam[f.family]
  if (!runsStage(f.family, 'verifier')) return true
  // M-01: every row the comparison lists (after the fixer), the items file's rows and records, and every record the
  // evidence pass changed; the verifier runs wherever an earlier stage wrote a row, a record or a supports link
  const byRow = new Map()
  for (const c of st.comparison || []) byRow.set(c.row, { row: c.row, fields: [...c.fields] })
  for (const r of f.verifier_rows || []) if (!byRow.has(r.row_key)) byRow.set(r.row_key, { row: r.row_key, fields: ['on the items file\'s list'] })
  const ownOf = (row) => { const ir = (f.verifier_rows || []).find((r) => r.row_key === row); return ir && ir.own_record_needed ? ir.own_record_needed.map((o) => `${o.bound} ${o.value} (${(o.fixer_records || []).join(', ')})`).join(' and ') : null }
  const list = [...byRow.values()].map((x) => ({ ...x, depth: depthOf(f, x.row, x.fields), own: ownOf(x.row) }))
  // the items file's records, with the file each is in (M-01 (5)), and every record the evidence pass changed
  const listed = new Map((f.verifier_records || []).map((r) => [recId(r), typeof r === 'string' ? { id: r, file: null } : r]))
  for (const id of st.evidence_changed) if (!listed.has(id)) listed.set(id, { id, file: 'research or verify', why: 'changed by the evidence pass' })
  const records = [...listed.values()].sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
  st.allowed_rows = [...list.map((x) => x.row), ...(f.author_rows || [])]
  st.allowed_records = records.map((r) => r.id)
  if (!list.length && !records.length) return true
  const r = await withRetry((half) => verifierPrompt(f, list, records, half), { label: `verifier ${f.family} r${ROUND}`, phase: 'Verify', schema: FILE_SCHEMA }, { role: 'verifier', family: f.family })
  if (halted(r)) { strongestStopped([f.family], 'verifier', `verifier ${f.family}`); return false }
  if (capped(r)) { runLog.left.push(`${f.family}: verifier (agent cap)`); hold(f.family, 'verifier', 'agent cap'); return false }
  if (!r) { strongestStopped([f.family], 'verifier', `verifier ${f.family}`); return false }
  st.searches.verifier += r.searches_used || 0
  if (!r.valid) {
    const file = `${W}/verify/${f.family}.json`
    const fix = await call(repairPrompt('verify', f, file, r.errors || [], CAP_VERIFIER), { label: `verifier-repair ${f.family} r${ROUND}`, phase: 'Verify', schema: FILE_SCHEMA }, { role: 'verifier-repair', family: f.family })
    if (halted(fix) || fix === null) { strongestStopped([f.family], 'verifier', `verifier-repair ${f.family}`); return false }
    if (capped(fix)) { runLog.left.push(`${f.family}: verifier repair (agent cap)`); hold(f.family, 'verifier', 'agent cap'); return false }
    if (!fix.valid) { hold(f.family, 'verifier', `${file} invalid after one repair pass`); return false }
  }
  st.verified = true
  done(f.family, 'verifier', null)
  return true
}

async function stageSeal(f) {
  const st = fam[f.family]
  if (!runsStage(f.family, 'seal')) return true
  if (!st.verified && fromOf(f.family) !== 'seal') return true // the seal runs where the verifier wrote
  if (fromOf(f.family) === 'seal') { st.allowed_rows = [...(st.comparison || []).map((c) => c.row), ...(f.verifier_rows || []).map((r) => r.row_key), ...(f.author_rows || [])]; st.allowed_records = [...new Set([...(f.verifier_records || []).map(recId), ...st.evidence_changed])] }
  const r = await withRetry((half) => sealPrompt(f, half), { label: `seal ${f.family} r${ROUND}`, phase: 'Seal', schema: SEAL_SCHEMA }, { role: 'runner', family: f.family })
  if (!r || capped(r)) { hold(f.family, 'seal', 'the seal runner did not run'); return false }
  st.seal = r
  sealLog.push({ family: f.family, copied: r.copied || [], slips: r.slips || [], ok: !!r.ok })
  st.comparison = r.comparison || []
  // a refused seal writes nothing: the files are those the verifier left, the hashes after the last finished stage
  if (!r.ok) { if (r.hashes) st.hashes = { ...r.hashes }; hold(f.family, 'seal', `seal: ${(r.problems || []).join('; ')}`); return false }
  done(f.family, 'seal', r.hashes)
  return true
}

async function stageCheck(f) {
  const st = fam[f.family]
  if (!runsStage(f.family, 'check')) return true
  if (!st.allowed_rows.length) st.allowed_rows = [...(st.comparison || []).map((c) => c.row), ...(f.verifier_rows || []).map((r) => r.row_key), ...(f.author_rows || [])]
  if (!st.allowed_records.length) st.allowed_records = [...new Set([...(f.verifier_records || []).map(recId), ...st.evidence_changed])]
  const r = await withRetry((half) => mopupCheckPrompt(f, half), { label: `check ${f.family} r${ROUND}`, phase: 'Check', schema: MOPUP_CHECK_SCHEMA }, { role: 'runner', family: f.family })
  if (capped(r)) { runLog.left.push(`${f.family}: checks (agent cap)`); hold(f.family, 'check', 'agent cap'); return false }
  if (!r) { hold(f.family, 'check', 'the check runner returned nothing twice'); return false }
  if (!r.ownership_ok) {
    const outside = [...(r.outside_paths || [])].sort()
    log(`${f.family}: paths outside the ownership map: ${outside.slice(0, 10).join(', ')}`)
    pending.issues.push({ family: f.family, check_id: 'G1', row_key: null, side: null, lens: 'orchestrator', judge_file: `${W}/checks/${BATCH}-r${ROUND}-changes.json`, round: ROUND, severity: 'blocking', summary: `mop-up round ${ROUND}: ${outside.length} changed paths outside the ownership map: ${outside.slice(0, 5).join(', ')}` })
  }
  const notesListed = (r.notes_not_reviewed || []).length
  const compiled = (r.compile_exit === 0 && notesListed === 0) || (r.compile_exit === 1 && notesListed > 0)
  if (!r.compile_ok || !compiled || !r.checks_file) { hold(f.family, 'check', `the compile or the checks failed (compile exit ${r.compile_exit}, ${notesListed} notes listed): ${(r.errors || []).slice(0, 3).join('; ')}`); return false }
  const keyed = r.family_keyed || []
  const notes = [...new Set(r.notes_not_reviewed || [])].sort()
  st.failing = r.failing_count + keyed.reduce((n, c) => n + (c.count || 0), 0) + notes.length
  st.failingFamily = [...(r.failing || []), ...keyed].filter((c) => !CENTRAL_CHECK.test(c.check)).reduce((n, c) => n + (c.count || 0), 0) + notes.length
  st.check = { failing_count: r.failing_count, failing: r.failing || [], blocked: r.blocked_checks || [], family_keyed: keyed, checks_file: r.checks_file }
  const x = r.extra || { ok: false, problems: ['step 7 did not run'], comparison: st.comparison }
  st.comparison = x.comparison || []
  if (!x.ok) { hold(f.family, 'check', `mop-up checks: ${(x.problems || []).join('; ')}`); return false }
  done(f.family, 'check', x.hashes)
  return true
}

// Checks that no family's decisions file can satisfy (ws1-batch.js CENTRAL_CHECK, the same list)
const CENTRAL_CHECK = /^(K1|N1|X\d+|S\d+|B\d+|Q\d+|D4|D6|G1|G[3-9])$/

await pipeline(
  ACTIVE,
  async (f) => stageEvidence(f),
  async (ok, f) => (ok ? stageAuthor(f) : false),
  async (ok, f) => (ok ? stageFixer(f) : false),
  async (ok, f) => (ok ? stageVerifier(f) : false),
  async (ok, f) => (ok ? stageSeal(f) : false),
  async (ok, f) => (ok ? stageCheck(f) : false),
)

// ─── stage 7: the closing pass and the reading of new rows (barrier: one agent per lens for the session) ───

phase('Closing')
const lensJobs = {}
for (const f of ACTIVE) {
  if (fam[f.family].status !== 'active' || !runsStage(f.family, 'closing')) continue
  for (const c of f.closing || []) if ((c.ids || []).length) (lensJobs[c.lens] = lensJobs[c.lens] || []).push({ family: f.family, ids: [...c.ids].sort() })
}
const listed = {} // "<family>|<id>" -> lens: the closing pass takes its ids from the items file only
for (const [lens, jobs] of Object.entries(lensJobs)) for (const j of jobs) for (const id of j.ids) listed[`${j.family}|${id}`] = lens
const closingJobs = Object.keys(lensJobs).sort().map((lens) => ({ lens, jobs: lensJobs[lens] }))
const newRowJobs = []
for (const f of ACTIVE) if (fam[f.family].status === 'active' && runsStage(f.family, 'closing') && (f.new_rows || []).length) for (const lens of ['J1', 'J2']) newRowJobs.push({ lens, f })
const closingResults = await parallel([
  ...closingJobs.map((j) => async () => ({ kind: 'closing', j, res: await withRetry((half) => closingPrompt(j.lens, j.jobs, half), { label: `closing ${j.lens} ${BATCH} r${ROUND}`, phase: 'Closing', schema: CLOSING_SCHEMA }, { role: 'judge', family: j.jobs.map((x) => x.family).join('+') }) })),
  ...newRowJobs.map((j) => async () => ({ kind: 'newrows', j, res: await withRetry((half) => newRowPrompt(j.lens, j.f, half), { label: `newrows ${j.lens} ${j.f.family} r${ROUND}`, phase: 'Closing', schema: JUDGE_SCHEMA }, { role: 'judge', family: j.f.family }) })),
])
for (const out of closingResults.filter(Boolean)) {
  const { kind, j, res } = out
  const families = kind === 'closing' ? j.jobs.map((x) => x.family) : [j.f.family]
  const label = kind === 'closing' ? `closing ${j.lens}` : `newrows ${j.lens} ${j.f.family}`
  if (halted(res) || res === null) { strongestStopped(families, 'closing', label); continue }
  if (capped(res)) { for (const f of families) { runLog.left.push(`${f}: ${label} (agent cap)`); hold(f, 'closing', 'agent cap') } continue }
  for (const f of families) fam[f].searches.judges += res.searches_used || 0
  if (kind === 'closing') {
    const seenIds = new Set()
    for (const a of res.answers || []) {
      const fam2 = String(a.ledger_id || '').split('--')[0]
      const lens = listed[`${fam2}|${a.ledger_id}`]
      if (!lens || lens !== j.lens || !families.includes(fam2)) { log(`${label}: ${a.ledger_id} is not on its list from the items file; ignored`); continue }
      if (seenIds.has(a.ledger_id)) continue
      seenIds.add(a.ledger_id)
      const evidence = String(a.file || '').trim() && String(a.line ?? '').trim() && String(a.value || '').trim()
      if (!evidence) { closingLog.push({ family: fam2, lens, id: a.ledger_id, answer: a.answer, applied: 'left open: no file, line and value (M-11 (2))' }); continue }
      const read = `${a.file}:${a.line} '${String(a.value).slice(0, 160)}'`
      if (a.answer === 'not_raised_again') {
        pending.updates.push({ id: a.ledger_id, family: fam2, status: 'closed', round: ROUND, closed_by: `${lens} round ${ROUND}, mop-up closing pass`, resolution: `not raised again by ${lens} in the mop-up closing pass of round ${ROUND}: read ${read}` })
        closingLog.push({ family: fam2, lens, id: a.ledger_id, answer: a.answer, applied: 'closed through ledger.js apply' })
      } else {
        pending.updates.push({ id: a.ledger_id, family: fam2, round: ROUND, resolution: `raised again by ${lens} in the mop-up closing pass of round ${ROUND}: read ${read}` })
        closingLog.push({ family: fam2, lens, id: a.ledger_id, answer: a.answer, applied: 'stays open' })
      }
    }
    for (const fam2 of families) for (const id of (j.jobs.find((x) => x.family === fam2) || { ids: [] }).ids) if (!seenIds.has(id) && !closingLog.some((c) => c.id === id)) closingLog.push({ family: fam2, lens: j.lens, id, answer: null, applied: 'left open: not answered' })
    for (const o of res.observations || []) {
      if (!families.includes(o.family)) { log(`${label}: observation on ${o.family} outside its families; ignored`); continue }
      const check = CHECK_ID_RE.test(String(o.check_id || '')) ? o.check_id : 'definition:mopup observation'
      const row = ROW_KEY_RE.test(String(o.row_key || '')) ? o.row_key : null
      const summary = `${j.lens}, mop-up closing pass: ${String(o.summary).slice(0, 360)} (${o.file}:${o.line})`
      pending.issues.push({ family: o.family, check_id: check, row_key: row, side: null, lens: j.lens, judge_file: res.file, round: ROUND, severity: 'blocking', status: 'unreviewed', summary, evidence_paths: [res.file] })
      observations.push({ family: o.family, lens: j.lens, kind: 'closing-pass observation', id: issueId(o.family, check, row, null), row_key: row, check_id: check, summary: String(o.summary), where: `${o.file}:${o.line}` })
    }
  } else {
    if (!res.valid) { log(`${label}: the judge file is invalid; the new rows stay unread by ${j.lens}`); unreviewed(j.f.family, `${j.lens.toLowerCase()} new rows`, `${j.lens} wrote an invalid file reading the new rows in round ${ROUND}`); continue }
    for (const [list, severity] of [[res.blocking || [], 'blocking'], [res.minor || [], 'minor']]) for (const it of list) {
      if (it.family !== j.f.family) continue
      const id = issueId(it.family, it.check_id, it.row_key, it.side)
      pending.issues.push({ id, family: it.family, check_id: it.check_id, row_key: it.row_key, side: it.side, lens: j.lens, judge_file: res.file, round: ROUND, severity, status: 'unreviewed', summary: it.summary, evidence_paths: [res.file] })
      observations.push({ family: it.family, lens: j.lens, kind: `new-row issue (${severity})`, id, row_key: it.row_key, check_id: it.check_id, summary: it.summary, where: res.file })
    }
  }
}
for (const f of ACTIVE) if (fam[f.family].status === 'active') done(f.family, 'closing', null)

// ─── end statuses (M-01 (7), M-02) ───

for (const f of ACTIVE) {
  const st = fam[f.family]
  if (st.status !== 'active') continue
  const left = st.comparison || []
  for (const c of left) pending.issues.push({ family: f.family, check_id: 'definition:unreviewed row', row_key: ROW_KEY_RE.test(c.row) ? c.row : null, side: null, lens: 'orchestrator', judge_file: `${W}/checks/${f.family}-r${ROUND}.json`, round: ROUND, severity: 'blocking', status: 'unreviewed', summary: `still differs from the verifier's row at the end of the mop-up round (${c.fields.join(', ')}): it cannot score (D-02) and becomes a physician question (M-01 (7))` })
  if (left.length) st.unreviewed.push(...left.map((c) => `row ${c.row}`))
  if (st.failing === null) { st.status = 'open'; st.stop_reason = `open, mop-up done: the check counts are not known in this run (${left.length} rows still listed by the comparison)`; st.end = st.status; continue }
  const failing = st.failing
  if (!left.length && failing === 0) { st.status = 'pass'; st.stop_reason = 'one pass: no failing check and the comparison is empty' }
  else if (!left.length && (st.failingFamily ?? 0) === 0) { st.status = 'content complete'; st.stop_reason = `one pass: nothing left on family checks and the comparison is empty; ${failing} failures remain on central checks (${KNOWN})` }
  else { st.status = 'open'; st.stop_reason = `open, mop-up done: ${left.length} rows still listed by the comparison (unreviewed), ${st.failingFamily ?? 0} failures on family checks; no further round without a new recorded decision (M-02)` }
  st.end = st.status
}

// ─── stage 8: ledger, finalize, run summary, state, scorecard ───

phase('Scorecard')
const finished = FAMILIES.filter((f) => ['pass', 'content complete', 'open'].includes(fam[f.family].status)).map((f) => f.family)
const heldFams = FAMILIES.filter((f) => fam[f.family].status === 'held').map((f) => f.family)
const confirm = [...new Set(runLog.agents.filter((a) => a.confirm_model).map((a) => a.family).filter(Boolean).flatMap((x) => x.split('+')))].sort()
function runSummary() {
  const families = {}
  for (const f of Object.keys(fam).sort()) {
    const s = fam[f]
    families[f] = { status: s.status, stop_reason: s.stop_reason, rounds: s.status === 'not in round' ? 0 : 1, searches: { ...s.searches }, reused: {}, blocking_open: s.failing, unreviewed: [...s.unreviewed].sort(), held: s.held, held_stage: s.held_stage, last_finished_stage: s.last_stage, comparison_left: (s.comparison || []).length }
  }
  return {
    batch: BATCH, started_at: STARTED_AT, round: ROUND, max_rounds: ROUND, agent_cap: AGENT_CAP, from_stage: FROM, mock: !!MOCK, start_commit: START,
    models: Object.fromEntries(Object.keys(ROLE_MODELS).map((r) => [r, `${ROLE_MODELS[r].model} at effort ${ROLE_MODELS[r].effort}`])),
    agents_run: runLog.agents.length, retries: runLog.retries, nulls: runLog.nulls, capped: runLog.capped, halted: runLog.halted, strongest_model_halted: runLog.fable_halted,
    families, agents: runLog.agents.map((a) => ({ ...a })), left: [...runLog.left].sort(), confirm_model_before_commit: confirm,
  }
}
const statePayload = {
  batch: BATCH, round: ROUND, start_commit: START,
  run: { started_at: STARTED_AT, from_stage: FROM, families: FAMILIES.map((f) => f.family), agents_run: runLog.agents.length, nulls: runLog.nulls, held: heldFams, strongest_model_halted: runLog.fable_halted, mock: !!MOCK },
  families: Object.fromEntries(FAMILIES.filter((f) => !['not in round'].includes(fam[f.family].status) && !(fam[f.family].status === 'stopped' && !fam[f.family].last_stage)).map((f) => {
    const s = fam[f.family]
    return [f.family, { end_status: s.held ? null : s.status, held: s.held, held_stage: s.held_stage, held_reason: s.held ? s.stop_reason : null, last_finished_stage: s.last_stage, hashes_after_last_stage: s.hashes, evidence_changed: s.evidence_changed, comparison: s.comparison, failing: s.failing, failing_family: s.failingFamily }]
  })),
}
const esc = (s) => String(s ?? '').replace(/\|/g, '\\|').replace(/\s+/g, ' ').trim()
function mopupSection() {
  const out = []
  out.push('', `## Mop-up round ${ROUND} (DR-2026-11-11-01)`, '')
  out.push(`One bounded pass per family from \`${ITEMS_DIR}/items/<family>.json\` (docs/signoff/workflows/ws1-mopup.js). Start commit ${START}; run of ${STARTED_AT}${FROM ? `, a re-run from ${typeof FROM === 'string' ? `the ${FROM} stage` : `the stages ${Object.entries(FROM).map(([k, v]) => `${k} ${v}`).join(', ')}`}` : ''}${MOCK ? '; mock mode (no model called)' : ''}. ${runLog.fable_halted ? `**${STRONGEST} stopped in this run: the families waiting on it are held (no seal, no finalize, no commit); resume after the reset.**` : ''}`, '')
  out.push('| Family | End status | Last finished stage | Held | Rows still listed | Closed by the closing pass | Raised again or left open |', '|---|---|---|---|---|---|---|')
  for (const f of FAMILIES) {
    const s = fam[f.family]
    const cl = closingLog.filter((c) => c.family === f.family)
    out.push(`| ${f.family} | ${esc(s.status)} | ${s.last_stage || '-'} | ${s.held ? esc(`${s.held_stage}: ${s.stop_reason}`) : 'no'} | ${(s.comparison || []).length} | ${cl.filter((c) => c.applied.startsWith('closed')).length} | ${cl.filter((c) => !c.applied.startsWith('closed')).length} |`)
  }
  out.push('', '### Agents: model requested and reported, per agent (M-03)', '', '| # | Label | Role | Requested | Effort | Reported | Result |', '|---|---|---|---|---|---|---|')
  runLog.agents.forEach((a, i) => out.push(`| ${i + 1} | ${esc(a.label)} | ${a.role} | ${a.model_requested} | ${a.effort_requested} | ${esc(a.model_reported || 'not reported')} | ${a.ok ? 'ok' : a.model_mismatch ? 'null (other model)' : 'null'}${a.confirm_model ? '; confirm the model from the run record before committing' : ''} |`))
  out.push('', '### Closing pass (M-11)', '')
  if (!closingLog.length) out.push('No closing items in this run.')
  for (const c of closingLog) out.push(`- ${c.family}, ${c.lens}: \`${c.id}\`: ${c.answer || 'no answer'}; ${c.applied}`)
  out.push('', '### Observations and new-row issues, entered as unreviewed (the orchestrator reads each one; M-11 (4), (5))', '')
  if (!observations.length) out.push('None.')
  for (const o of observations) out.push(`- ${o.family}, ${o.lens}, ${o.kind}: \`${o.id}\` (${esc(o.check_id)}${o.row_key ? `, ${esc(o.row_key)}` : ''}): ${esc(o.summary).slice(0, 300)} (${esc(o.where)})`)
  out.push('', '### Seal (only fields named in corrections[])', '')
  if (!sealLog.length) out.push('No seal in this run.')
  for (const s of sealLog) out.push(`- ${s.family}: ${s.ok ? 'sealed' : 'stopped'}; copied ${s.copied.length ? s.copied.map((c) => `${esc(c.row_key)} ${c.field} (corrections[${c.correction_index}])`).join('; ') : 'nothing'}${s.slips.length ? `; differences not named in corrections[]: ${s.slips.map((x) => `${esc(x.row_key)} ${x.field}`).join('; ')}` : ''}`)
  out.push('', '### Held families and how to resume', '')
  if (!heldFams.length) out.push('None.')
  for (const f of heldFams) out.push(`- ${f}: held at the ${fam[f].held_stage} stage (${esc(fam[f].stop_reason)}). Resume after the cause is gone with args {"batch": "${BATCH}", "started_at": "<ISO time>", "families": ["${f}"], "from_stage": {"${f}": "${fam[f].held_stage}"}}; stage 0 compares its files with the hashes recorded after the ${fam[f].last_stage || 'last finished'} stage.`)
  if (confirm.length) out.push('', `Confirm the model from the run's own record before committing: ${confirm.join(', ')} (an agent on ${STRONGEST} reported "unknown").`)
  return out.join('\n')
}
const finalizeList = finished.map((f) => ({ family: f, reason: `mop-up round ${ROUND}: ${fam[f].status}`.replace(/"/g, "'") }))
const payload = { round: ROUND, issues: pending.issues.filter((x) => !fam[x.family]?.held).map((x) => ({ ...x })), updates: pending.updates.filter((x) => !fam[x.family]?.held).map((x) => ({ ...x })), count_families: finished }
const fin = await withRetry((half) => finalPrompt(payload, runSummary(), statePayload, mopupSection(), finalizeList, half), { label: `scorecard ${BATCH} mop-up r${ROUND}`, phase: 'Scorecard', schema: FINAL_SCHEMA }, { role: 'runner', final: true })
if (!fin || capped(fin)) log(`the final runner returned nothing; run the commands of the final step by hand (docs/signoff/work/mopup/README.md)`)
else if ((fin.applied?.errors || []).length || !fin.ok) log(`final step: ${[...(fin.applied?.errors || []), ...(fin.errors || [])].slice(0, 5).join('; ')}`)

const summary = runSummary()
return {
  batch: BATCH,
  started_at: STARTED_AT,
  round: ROUND,
  families: summary.families,
  commit_families: finished,
  held: heldFams.map((f) => ({ family: f, stage: fam[f].held_stage, reason: fam[f].stop_reason })),
  confirm_model_before_commit: confirm,
  strongest_model_halted: runLog.fable_halted,
  closing: closingLog,
  seal: sealLog,
  observations: observations.length,
  agents_run: summary.agents_run,
  retries: summary.retries,
  nulls: summary.nulls,
  capped: summary.capped,
  left: summary.left,
  scorecard: fin && !capped(fin) ? fin.scorecard_file : null,
  final_errors: fin && !capped(fin) ? [...(fin.applied?.errors || []), ...(fin.errors || [])] : ['final runner returned nothing'],
}
